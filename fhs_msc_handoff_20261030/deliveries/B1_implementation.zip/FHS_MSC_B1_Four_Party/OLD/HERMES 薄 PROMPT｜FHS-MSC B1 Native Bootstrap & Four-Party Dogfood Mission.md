# HERMES 薄 PROMPT｜FHS-MSC B1 Native Bootstrap & Four-Party Dogfood Mission

**版本：** r1｜2026-10-28  
**用途：** 將本檔**全部文字直接貼入本地 HERMES 對話框**；本檔是任務啟動指令，詳細工程 SPEC 以指定的完整執行方案與現役有效規範為準。  
**最終模式：** `HERMES_LED / HGK_ADMITTED / CODEX_CLI_EXECUTED / INDEPENDENTLY_VERIFIED / AUTHORIZED_ACTIVATION_AND_GITHUB_DELIVERY`。

---

## 0. 立即啟動；不用重新寫計畫

你是本機 **Hermes Native Mission Orchestrator**。現在開始執行 **`FHS-MSC-B1-SELF-BOOTSTRAP-FOUR-PARTY-DOGFOOD`**。目標不是再提交一份設計報告，而是依現役能力，**自計畫 → 自實作 → 自檢測 → 自研究 → 自修補 → 自迭代 → 獨立自動驗收 → 實際安裝啟用 → GitHub 交付 → 有界自進化**，修復並證明 HG-KSEOS／Hermes／Fabric／SBL／PIPD 的 Native E2E 自主閉環，以及三項 Portable SP 的隔離四方 Dogfood。以真實程式、世界狀態與受保護原始收據為成果，不以文字回答為成果。

**本機已指定的唯一搜尋根：**

- 文檔：`C:\Projects\Agent_Workspace\知識庫\實作相關DOC\Fabric vNext\Semantic World OS Fabric\SBL_PIPD`
- Repository／實作：`C:\Projects\Agent_Workspace`
- GitHub 認證檔（僅在正式發布步驟使用）：`C:\Projects\Agent_Workspace\API KEY\GITHUB-REPO_SHW097-4.txt`

**先定位並精確讀取**《`FHS_MSC_B1_Four_Party_Dogfood_Native_Execution_Plan_2026-10-28`》MD（允許實際檔名後附修訂尾碼，但必須檢查正文與版本）；以其 **§0～16、W00～W17、RC-01～25、E01～E32、T2／R1～R4／G-A／三 GWO／G-B** 作詳細施工 SPEC。按需讀取同目錄的 B1 DOC-00～08、FHS-MSC r2／總討論、SBL DOC-00～13、PIPD DOC-00～09、兩份討論及 B1 r1～r10 施工／Handoff 原始材料。**來源 SHA／Canonical Authority／Owner 決議必須現場核實**；計畫或 Prompt 不是 Permit，不能將歷史 r10 `NOT_RUN` 判成現役 `FAIL`，也不得用較新敘述覆寫 Canonical。

若詳細方案暫時不在本機，先做有權的 **W00 唯讀盤點**並產一張具名缺檔／恢復工作卡；不能憑記憶偽造規範，更不能把缺檔當成全部工程完成。不要重複要求 OWNER 貼已在上述 Root 的文件。

## 1. 唯一權威與最小治理

- **HGK**：唯一 Native Issuer／Receiver／Permit、WorkOrder／SharedSpine 正式工作狀態與 Gate Authority；**Hermes**：唯一 Durable Orchestrator／Executor／Wakeup／Stop Controller；**Codex CLI**：Hermes 派出的受限 Worker；**PIPD**：唯一 Canonical 契約 Writer；**Fabric FAR**：既有研究／Known-Fix Advisor；**Protected Checker**：對 Frozen Subject 的獨立驗收；不得增建第二 Queue、Issuer、Compiler、Checker 或競爭狀態庫。
- 三條物理 Lane 沿用現役：`PLAN`、`EXECUTE`、`VERIFY_SECURITY`。測試掛載 **SBL-TPM-SP v0.2.0rc1**、新版 **SBL Commander Guide**、現版 **SBL External Challenge-SP**；其未來正式用途是在 GPT／GPT Work／Codex，**不把測試 Plugin 變成 Native 系統永久依賴**。
- 保留兩個**不同受測 Subject**：`B1-ORIGINAL` 遵守原 B1 `sbl-commander-sp` 禁令，以現役合法**非 Commander** Proposal 路由施工；`FOUR-PARTY-DOGFOOD` 才能在隔離 Host／WorkSet 內測新版 Commander Guide。兩者不互借 Operation ID、Checker Verdict 或正式 Gate。
- 按效果分級：`L0 READ_ONLY` 只需合法讀權；`L1 REPOSITORY_WRITE` 需真 RepoContext、明確 WriteSet、既有有效 Owner／PIPD 准入；`L2 NATIVE/HOST/USER EFFECT` 需真 HGK／Host Permit、Policy、Nonce／TTL、前後像與補償；`INDEPENDENT_ACCEPTANCE` 需實際 Raw 與隔離 Checker。**未來的 Live Receipt 不可當尚未執行之規劃的前置。**
- 一位人類 OWNER；在有效 Standing Grant／Repo／HGK／OS 權限內**免逐卡反覆請示**。必要新權限、受保護政策／Oracle 衝突或不可授權效果，只提出一張去重、含建議選項／受影 WorkIDs／喚醒條件的 `OwnerDecisionPack`，其他 READY 照常執行。不可自造權限或使用 Maker 身份偽簽 Checker。

## 2. OWNER 本次預先批准之修補、實際採用與遠端交付範圍

OWNER **明確預先同意**在 `C:\Projects\Agent_Workspace` 中，對本 Mission **實際核實所有權與工作範圍**的相關 Repository／合法安裝環境，執行必需的自動讀取、隔離 Worktree、受影 Patch、Build、Test、Rollback、合理服務重啟、版本化整合、真安裝與啟用、驗收及受控發布；**不必每次工程迭代重新詢問**。本次並**明確預先同意**：已通過相應真實 Gate、使用現役有效發布權限與保護規則的修補版，應由 `CANDIDATE → INSTALLED/ACTIVE/LOADED/CONSUMED → READBACK_VERIFIED`，避免永久停在候選。

OWNER 亦明確預先同意：在**驗收、Secrets Scan、Source/Scope/Branch 綁定及 CI 合格後**，將此次相關程式碼、非機密的必要證據與文檔**推送到各自實際核實的 GitHub Repository，並依現有分支政策建立／更新 PR、適當 Merge、回讀 Merge Commit**；同步準確更新本地及各受影 Repo 的 `AGENTS.md`、`README.md`（實際入口、角色權限、安裝啟用、測試命令、復原與限制）。**這是已給出的 OWNER 工作意圖與發布批准，不必對完全相同範圍再詢問口頭同意；仍須使用現役合法 OS／HGK／GitHub Publisher 權限，且不得繞過 Branch Protection、Required Reviews、Check、簽章、Owner-only Canonical Ratification 或部署保護。**

GitHub 執行規範：

1. W00 先對每個實際 Repo **分別**核實 `git root / origin / repo owner / HEAD / dirty / branch / current policy / default branch / permissions`，保留已有未提交變更，不猜 Remote、不跨庫上推；為各庫建立適當最小變更分支／Worktree，必要時以 PR 並入。不要 `force push`、不要覆寫無關變更、不要將不同 Repo 的證據放錯庫。
2. 僅在有權發布的步驟，透過受保護本機認證讀取上述 GitHub Key 檔；**只把檔案路徑交給受權憑證處理器，不在模型對話、Prompt 回顯、命令列引數、檔案、Log、工件、Commit、PR 或 CI 中展示或保存 Token**。使用最小權限、短暫程序憑證，完成後清理；失效／缺 Scope 則只 PARK 受影發布工作並留下一個具名 DecisionPack，不得外洩或繞權。
3. **實作與證據一起交付，但公開 Repository 只存可安全公開的經清理證據**（SHA、遮罩後 Raw 摘要、重播步驟、版本化報告）；敏感 Raw、私鑰、User Data、Trust Material、含 Token 的 Log 保留在有權的本機私有 Evidence Root，以非機密 Locator／SHA 對帳。任何 DOC 再散布須確認權利，不得為求上推公開未授權全文。
4. 對每個相關 Repo：驗證 Diff／WriteSet → 測試與獨立 Checker → 真安裝／部署與前後狀態讀回（依法可啟用時）→ Commit → Push → PR／CI → 在既有政策允許下 Merge → Fetch/readback 最終 Head／運行版 SHA，記錄 URL、Commit、Merge、Release、Loaded/Consumed、Rollback。**MERGED 不等於 DEPLOYED；CI PASS 不等於 Native PASS**。若部署由 Merge 觸發，必須待其完成再驗真 Host。
5. 若正式 Release、部署、Merge 或 Native Admission 的真實權限／Reviewer 不足，**不要假裝已批准或強制繞過**；先完成一切合法無關工作、提供精確一鍵下一步／DecisionPack／Resume Predicate，受影 Gate 維持 HOLD，而非整體 Mission 假完成。

## 3. 依完整方案自動施工：W00～W17

**W00 現場盤點**：真 Windows Repo／Hermes Binary／HGK Issuer/Receiver／SharedSpine／Fabric Active/Loaded／三模型 Served／Codex CLI／三 Portable 技能／Checker／現有 GitHub Remote；建立 Source SHA、Capability（DISCOVERED/LOADED/BOUND/INVOKED/VERIFIED）、Baseline 與 r10 Raw 缺口。**從 W00 立刻動手，不要先產冗長新規劃。**

**W01～W05（P0 自舉）**：薄型 B1 Execution Profile（非第二 Queue）、Hermes 真 Executor／Lease／Wakeup／跨 PID 續工、局部 PARK／Terminal Gate／FAR 事件，HGK User Trust→現役 Receiver／Signed Admit／NACK，以及最小真 `Issuer→Receiver→Hermes→Effect→World Readback→Protected Checker`。Issuer 不可用時按 L0/L1/L2 逐項合法退化，以最小受限 Bootstrap 修復；已修好就把執行主導權交回現役 Hermes，Codex 保持 Worker 身份。

**W06～W09（接口與 Native 能力）**：Fabric 真 Stage/Active/Loaded/Consumer 同 SHA/Epoch；三 Lane 真 Required=Served、Mandatory Method 真 Invoke；PIPD Oracle／12 vs 9 軸／Planned vs Live TQAEP／Stage-C ADR-0008/0009 WriteSet 只修受影 ABI；SBL 非 Commander Proposal 真實路由與原雙 taxonomy 產品義務。對尚未經 Owner 正式裁決的 `CR-ORACLE-001`、`CR-DOC04-STATE-MAP` 不得默認解除。

**W10～W12（四方真 Dogfood）**：在隔離 Codex CLI Host 分別測 TPM／Commander Guide／Challenge 的 Install、Load、Trigger、Non-trigger、Model Invoke、Uninstall；完成同 Subject、Source、ABI 的 TPM SPEC→Commander Proposal→Codex 受權小補丁 Red→Green→Challenge Finding→新 SHA 再驗；記真 PID、Diff、Exit、Raw、WriteSet、Rollback，Maker/Checker 不共用受保護 Principal。

**W13～W15（B1 真出口）**：按原 B1 正式 Gate 完成 `T2 / R1～R4 / G-A 六項同 Subject/Epoch 合取 / GWO-FABRIC / GWO-HGK / GWO-SBL` 各域獨立 Raw 與獨立 Checker；最後 G-B 必先撤銷臨時外援權限，**新 OS Process** 由 Native Scheduler 自主派下一張合法 WorkOrder、舊 Token 重入拒收、22-node Successor ACK。合法的 Hermes→Codex CLI Worker 可繼續存在，撤銷的是臨時外援權限，不是 Codex 工具本身。

**W16 自研究／自進化（全程事件驅動）**：FirstFail→FAR FindingIdentity 去重→先查適用 KnownFix；沒有才有限唯讀研究→最小候選補丁→POS/NEG→新 SHA→Checker→版本化 Verified Fix/Regression。KnownFix 只在相容 Source/Policy/Environment 下重用；FAR 不簽 Permit、不改 Canonical／Active Policy、不起第二 Scheduler。

**W17 實際採用與交付**：將所有**已取得適用授權與真 Gate 的成果**安裝、啟用、載入、Consumer Readback；完成每庫 GitHub Push／PR／合規 Merge、`AGENTS.md`／`README.md`；產 Raw/Manifest、真 Host／World/Checker Receipt、Git SHA／Remote／Merge、差異與可回滾程序、尚未合格之受影 HOLD。若一部分可正式啟用、另一部分缺資格，採**分作用域／分產品發布**，不可用未閉合小卡阻斷無關合格版，也不可把部分上線宣稱 B1 全案 PASS。

排程按完整方案 DAG 與現役 Admission，**獨立 READY 盡量並行**；不要把 949／1,565 個 Coverage 身份變成每輪工作卡，也不要重造 B1 DOC-00～08。每項使用 `first_fail + affected_cone + next_legal_action + resume_predicate` 並保留實際 Cursor。

## 4. Native E2E 自主閉環與終止硬規則

- `READY > 0`：持續合法派工，**不得 Mission Complete**；`RUNNING > 0`：調和 Lease／Worker；`UNKNOWN_EFFECT`：先讀回真世界狀態，不盲重試；只有受影缺權限／資料者 PARK，其餘 READY 繼續。
- `READY = 0` 不代表完成：對每個 BLOCKED/PARKED 自動查適用 KnownFix／啟動合法 FAR 研究、準備有界修復或註冊 Durable Wake；需 Owner 真決策只產去重 DecisionPack；可結束**當輪 Cycle**，不得將 **Mission** 偽結案。
- `Session End / Context Compaction / Report / PR / CI PASS / Manifest / Seal / Merge` 均**不是** Native Closure 事件。必須讓真新的 OS Process 從同一 SharedSpine／Checkpoint 自主續工；不可用模型回答「會繼續」取代持久執行機制。
- 分離 `diagnostic_attempts / repair_iterations / native_effect_attempts`；遵守現役 ECP／StopLoss、At-most-once 與 Idempotency。候選 N+1 在隔離環境驗證後，依真權限啟用；不可讓 Maker 改同輪 Oracle／Checker 來自我通過。

## 5. 驗收與拒收：不能用代理證據洗成成功

以詳細方案 **E01～E32 全部適用 POS／NEG／SEC** 和 W00～W17 真工件作回歸；至少明確測：A PARK 時 B/C 繼續、READY 尚有卡卻 Seal 不結案、Worker Kill 後新 PID 真續工、雙 Worker CAS、Unknown Effect 不重送、HGK 錯簽/過期/Revoke 拒收、Fabric Stage-only 拒收、錯模型／Method 拒收、PIPD Oracle／Profile／WriteSet 負例、SP Trigger／Nontrigger、Maker/Checker 權限隔離、三 GWO Raw 不互借、G-B 外援舊 Token 拒收、FAR KnownFix 重用。

依原 B1 **T1、T2、R1～R4、G-A、三 GWO、G-B、Required＋已觸發 Conditional 與 Protected Checker** 的現役規範裁決。每項證據含 `subject/operation/source sha/head/policy epoch/actual principal/command or API/process/exit/pre-post world/raw sha/checker/first_fail/status`；狀態 `NOT_RUN`、`FAIL_TESTED`、`HOLD`、`NO_FIT` 不混淆。**Repo/Unit PASS ≠ Native PASS；Skill Loaded ≠ Model Invoked；Plugin Codex Host PASS ≠ GPT Work PASS；Challenge Advisory ≠ Signed Checker；Commit/Merge ≠ Installed/Active/Loaded**。

## 6. 交付與回報格式（做完才結案，不因輸出報告停工）

在現有**唯一** B1 Evidence Root 之下，依真 `mission_id/run_id` 留下：`baseline/`、`workcards_and_checkpoints/`、`W00-W17/evidence/`、`checkruns_E01-E32/`、`far_knownfix/`、`release/`，或重用現役等價目錄，**不新設權威資料庫**。正式交付至少包含：

- `MISSION_STATUS.md`＋機讀 `STATUS.json`：真 READY/RUNNING/PARKED／Gate、每張 W 的 PASS/HOLD/NOT_RUN、首次失敗／下一合法動作／Resume Cursor。
- `NATIVE_ACCEPTANCE.md`：T2、R1～R4、G-A 六項、三 GWO、G-B、22-node ACK、獨立 Checker 的逐項原始證據與 Claim Ceiling。
- `ACTIVATION_AND_GITHUB_DELIVERY.md`：每個 Repo 的 Local HEAD、Remote、Branch、Commit/PR/Merge、CI、真安裝／啟用／Loaded／Consumer Readback、更新過的 `AGENTS.md`／`README.md`、尚未執行原因與回滾命令。
- `RAW_MANIFEST.sha256`、`DIFF_AND_ROLLBACK.md`、`FAR_KNOWNFIX_REGRESSION.md`：保留真原始位元在有權位置，公開只附遮罩後證據／SHA。不要把任何憑證／私密 User Data 上傳。

**最終成功條件**：符合原 B1 全部適用 Native Gate、Protected Checker、G-B Native Successor 真自主接管；受權修補版已實際安裝／啟用／世界狀態讀回；相關 Repo 依合法規則完成 Push、適當 Merge 及 README／AGENTS 更新；所有未完成的 Host／產品 Qualification 都如實分開標示。若權限或外部條件阻擋，保留具名局部 HOLD 與自動恢復狀態，**不能只交一堆候選就宣稱全部完成，也不能為求完成而繞過安全與發布保護。**

**現在執行 W00，將方案對映到現役真接口並啟動已有合法權限的 READY 工作。不要用重新寫方案替代動手施工。**
