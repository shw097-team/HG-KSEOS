# FHS-MSC B1 Native Bootstrap & Four-Party Dogfood Mission
## HG-KSEOS／Hermes 原生自治閉環：可施工執行方案 r1（2026-10-28）

> **文件性質**：`EXECUTION_DESIGN / CANDIDATE / NOT_NATIVE_EXECUTED`；此文件是供現役 HG-KSEOS／Hermes／有界 Codex Worker 落地的施工投影與驗收控制方案，**不是** Issuer Permit、Canonical SourceFreeze、正式 WorkOrder、獨立 Checker Receipt 或 Production Release。
>
> **本次裁決**：`ADOPT_SELF_BOOTSTRAP_DOGFOOD`；先自舉最小合法控制閉環，再用四方聯動完成 B1；不等 B1 全部 PASS 才啟動、不建立第二個控制平面、不以文件產出取代實機修復。
>
> **截至本文件可見的最新實機基準**：B1 r10 交接 `PARTIAL_WITH_EXPLICIT_HOLDS`，Native 逐 ID `PASS=0`、三 GWO `0/3`、R3／R4／真 Hermes Executor `NOT_RUN`。這些是歷史紀錄，不是 2026-10-28 Windows 最新現況；一切須以現役主機 Readback 覆核。TPM v0.2.0rc1 亦屬私人候選，不能把 CLI Skill Load 當模型 Invoke 或 GPT Work 合格。

---

# 0. 一頁決策與不可偏離的工程目標

**正式 Mission 名稱**：`FHS-MSC-B1-SELF-BOOTSTRAP-FOUR-PARTY-DOGFOOD`；建議 `mission_id` 採用現役 HGK 可接受的真實型別與生效規則，禁止在本文件直接自造有權 ID。

**終局執行鏈**：`HERMES_LED / HGK_ADMITTED / CODEX_CLI_EXECUTED / INDEPENDENTLY_VERIFIED`。在原生啟動尚失效時，允許一次性、限權、可撤銷的 `BOOTSTRAP_REPAIR` 分支；恢復真派工之後，Codex CLI 是 Hermes 委派的 Worker，而非第二個 Mission Controller。

**可驗的九項產品成果（FUO）**：

1. **FUO-01｜最小自舉**：不要求所有 Native Gate 先 PASS，就能做合法唯讀／有界 Repository 修補，消除 Bootstrap 循環。
2. **FUO-02｜唯一持久自治**：HGK SharedSpine 的 READY 卡經 Hermes 真 Executor 自主調用 Codex CLI，持久記錄、跨程序恢復；無第二 Queue。
3. **FUO-03｜四方 Role Dogfood**：以 TPM、Commander、Codex、External Challenge 的 Portable 測試掛載進行 PLAN／EXECUTE／VERIFY；測試版 Plugin 不冒充未來 Native 正式角色。
4. **FUO-04｜原生能力恢復**：真 Issuer／Receiver、Fabric Stage→Active→Loaded、三 Lane Required→Served／Mandatory Methods、獨立 Checker 可實跑。
5. **FUO-05｜局部不中斷**：受影 A PARK 不阻礙獨立 B/C；`READY>0`、`RUNNING>0` 不得 Mission Complete，報告／Seal 不會關掉隊列。
6. **FUO-06｜三種真效果**：B1 三張不同 Golden WorkOrder（Fabric／HGK／SBL）各有原生 Operation Identity、世界效果 Readback 和獨立 Checker。
7. **FUO-07｜G-B 接管**：臨時外援 Revoke 後，由新的 OS Process／Session 透過 Native Scheduler 自主完成下一張合法卡；舊 Token 重入拒絕。
8. **FUO-08｜單人 OWNER 低阻力**：已核准 Standing Authorization 下不逐卡重問；僅超出授權、正式政策／Oracle／發行等需當前有權決策時 HITL。
9. **FUO-09｜自進化而不自授權**：FirstFail→FAR Known-Fix→有界候選修補→新 SHA 回歸→隔離 Checker→可重用經驗；不得默改 Canonical Policy 或自簽正式 PASS。

**不在本次範圍**：全面改寫 FHS r2 或 B1 DOC-00～08；把原 SBL 949 產品身份都當本次安裝工作；把 1,565 Ledger 全部轉成佇列；導入 Temporal／LangGraph 作第二 Scheduler；建立第二 HGK Issuer、PIPD Compiler、Oracle Writer、Checker；解除原 B1 `sbl-commander-sp` 禁令；未取得真憑證即運行 Host/User Effect；將 Codex CLI 測試代替 GPT 網頁／Work 真宿主驗收。

**成敗判定原則**：`DESIGN_READY`、`ENGINEERING_GREEN`、`HOST_INVOKED`、`NATIVE_EFFECT_VERIFIED`、`INDEPENDENT_ACCEPTED`、`RELEASED` 分別證明，不跨級推論。來源：[A01: FHS r2 §5.1～5.6、§7、§12]、[A02: B1 DOC-00 §1～4]、[A03: B1 DOC-08 §1～5]、[E01: r10 Handoff §§0～5]。

# 1. 權威、來源、精確版本與證據可信度

## 1.1 權威堆疊／衝突解法

| 類別 | 作用 | 生效／限制 |
|---|---|---|
| 唯一人類 OWNER 的真授權＋現役 OS／HGK／Host 權限 | 實際可做什麼 | Prompt 與報告不是 Token；超範圍需有效新授權 |
| PIPD_LS_DOC-00～09、SBL_PIPD-LS-PKG_DOC-00～13 之適用有效 Owner Canonical | Source／PI／PD／ECP／TQAEP／產品和權責 | 本地 Markdown 的 SHA 僅證明內容位元，不證明正式 SourceFreeze／Ratification |
| FHS-MSC 藍圖 r2、B1 r3 DOC-00～08 | 領域架構、具名分母、施工設計與 Gate | B1 頁首 `task_kind: DESIGN`、`claim_ceiling: AUTHOR_SIDE_REPAIR_CANDIDATE`；不可直接簽 Native Permit |
| FHS-MSC 總討論、B1 施工紀錄、2026-10-27 交接、新兩篇討論 | 歷史決策、根因、候選方法、最後已知狀態 | 不同日期與相互引用不構成多個獨立驗收；後來分析不能默取代 Canonical |
| 本文件、技能／版本候選、外部網站 | 施工投影與工程參考 | `DESIGN_PROPOSED`；一律用實機能力發現與 Native Owner 判定 |

**衝突算法**：精確 `source_id + source_sha + clause` → 現役 domain Owner／policy epoch → 版本／supersession → 如仍衝突，僅 HOLD 受影 `dependency_closure` 並產出單一 OwnerDecisionPack。禁止用較新文件日期或模型推理自動改寫 Canonical Authority。

**兩條必須保持 OPEN 的已知規範衝突**：`CR-ORACLE-001`（PIPD DOC-07 Canonical Writer／舊 P4 `DOC-03 DOMAIN_ORACLES`）、`CR-DOC04-STATE-MAP`（SBL T4／T5 轉移未批准）。本 Mission 可在不受影的 Draft／隔離工程繼續，不能用其自身文件宣告正式解封。[A01 §2.1、§5.1；PIPD DOC-06、07；SBL DOC-04]

## 1.2 來源族群與閱讀順序

| Source ID | 來源 | 本 Mission 的最低讀取用途 |
|---|---|---|
| `B1-00…08` | 九冊 r3 B1 控制包 | Gate、27 Atoms、31 Slots、120+124 TQAEP、38 Node、3 GWO、G-A／G-B |
| `FHS-R2` | 《FHS-MSC_藍圖_r2》 | Single Authority、3 Lane、FAR、Codex Bootstrap、12.5 Durable Resume、R15 Coverage |
| `FHS-CHAT` | 《FHS-MSC_總討論》 | Bootstrap 禁循環、Known-Fix、OWNER 低阻力、Runtime 控制與退出 |
| `SBL-00…13` | SBL_PIPD-LS-PKG | One Core／3 SP、TPM、Commander、Challenge、雙 taxonomy／6 Module、Host／產品 Acceptance |
| `PIPD-00…09` | PIPD_LS_DOC | Canonical 編譯、來源／Oracle／Profile／ECP／TQAEP 與證據 |
| `B1-LOG/B1-PROMPT/B1-RCA/B1-HANDOFF` | 四份歷史施工／r10 交接 | r1～r10 證據、25 RC、未完項、真命令／退出碼與仍未取得 Raw |
| `CHAT-FOUR/CHAT-RCA` | 兩份新討論 | Self-bootstrap／Dogfood 與 FAR 主動研究、r2.1 受影修補的候選決議 |
| `TPM-DELIVERY` | v0.2.0rc1 私人交付報告及候選 ZIP | 14 Skills／24 DOC／CLI Load、未通過 HOST_INVOCATION 的區分 |

**來源管理規則**：當輪只載入 `Mission Resume Minimum Readset`（Mission/WorkState、當前 FirstFail／Policy、受影來源 Locator、實際 Workspace SHA、Gate／Raw）；其餘按需讀。全量基準保存在下面附錄 SHA 表，不把幾十 MB 文檔塞進每次 Codex Prompt。

## 1.3 歷史事實 vs 現場待驗：不可猜測

| 對象 | 最後可見紀錄 | 現場必須重新查驗 |
|---|---|---|
| r10 Native | `PASS=0`、`GWO=0/3`、`native_artifact=false`、Handoff HOLD | 現役 B1 Native Ledger、真 Signed Raw、當前 Policy Epoch |
| Hermes | r9 SharedSpine、跨 PID Dispatcher／OS Task 有局部測試 | 真已載入 Hermes Binary／Executor／Wakeup；r10 曾報告刪除測試 Task，不假設仍在 |
| HGK | User-scoped Ed25519／DPAPI 候選 `de37c48`、7 項測試 | 現役 Receiver Registry 是否真消費；同 SID 不能自證 Checker 隔離 |
| Fabric | Source pin／Consumer 候選 | 真 Stage／Active／Loaded／Consumer ACK，各自同 SHA/Epoch |
| 三模型 Lane | Route Pin 候選 | PLAN／EXECUTE／VERIFY_SECURITY 真 Required/Served/Method `INVOKED` |
| PIPD | CE-2 局部修補，Stage-C `public-plugin-verify` 報錯 | PR／CI 現況、ADR-0008/0009 歸屬、Oracle／Profile ABI |
| Portable TPM | v0.2.0rc1 載入 14 Skills／107 local tests（交付報告主張） | 真模型 Trigger/NonTrigger/Invoke；Checker、GPT/Work Host 尚未驗收 |
| Commander Guide | 使用者稱新版，當前未有版本化原件／真 HOST ABI | 版本、SHA、實際 Skill 路徑與 Host Invoke；禁用原 B1 Commander-SP 不變 |
| External Challenge | Read-only adversarial skill（已核對） | 真 checker principal、不可改 Oracle、Signed Verdict |
| r10 Raw | Manifest 9 筆，交接中僅 4 筆原始位元可比對 | 取回另外 5 筆實體再逐一 SHA 核對；封存不代替世界效果 |

## 1.4 本次物理來源文件 SHA-256

實際 SHA 於文件生成時由目前上傳位元計算。目的是讓 HGK／Hermes 在本地重建 Input Manifest 時比對精確位元；**這些 SHA 不構成上位 Owner 簽章**。

| # | Source filename（沙盒中實際已讀／可讀） | Bytes | SHA-256 | 本文件定位 |
|---:|---|---:|---|---|
| 01 | `FHS_MSC_B1_PIPD_LS_PKG_00_GOVERNANCE_AND_CONTROL(1).md` | 10,324 | `3096e98096ad48b3b3cfda07c6075ccffba8b44c1851a804d63f0ab103aef576` | B1-R3 CONTROL |
| 02 | `FHS_MSC_B1_PIPD_LS_PKG_01_DOC_B1_PI(1).md` | 53,244 | `e1d8931c036a1e9dc97f79a3d0d00f151ea5a29dc81fb3d7aa488d5446d7b666` | B1-R3 CONTROL |
| 03 | `FHS_MSC_B1_PIPD_LS_PKG_02_DOC_B1_PD(1).md` | 62,807 | `8e15b92a69302bbb0f9a6352f80c9687fdfb3a217006703a87b3ba559f42eb2b` | B1-R3 CONTROL |
| 04 | `FHS_MSC_B1_PIPD_LS_PKG_03_DOC_B1_OPS_ECP(1).md` | 24,829 | `54a17818473f2a4b7c4f0f8f504bc96e4e1450540facfd30cf38234fa89e8b8a` | B1-R3 CONTROL |
| 05 | `FHS_MSC_B1_PIPD_LS_PKG_04_DOC_B1_DEV_ECP(1).md` | 9,287 | `7a1e44dfd91bd24011c019f3ff73446e6cebf4b7847d7220f7c78dc25927def5` | B1-R3 CONTROL |
| 06 | `FHS_MSC_B1_PIPD_LS_PKG_05_DOC_B1_TQAEP(1).md` | 455,090 | `1e09126f0c8e92fcd6e8531072a3f1f3033d82a671c2b4bb62c9916e675b7127` | B1-R3 CONTROL |
| 07 | `FHS_MSC_B1_PIPD_LS_PKG_06_PRODUCT_COVERAGE_AND_R15(1).md` | 859,287 | `f929d9cffd462d23bbdb52171f72a450e96e59c8333bc05ebd739a2d38338337` | B1-R3 CONTROL |
| 08 | `FHS_MSC_B1_PIPD_LS_PKG_07_NATIVE_TOOLCHAIN_EXACT_USAGE(1).md` | 19,392 | `d1e0283200ad57cf1a3a1fc62bc09c6980ff118d4b7af4401d011ea87a009ea7` | B1-R3 CONTROL |
| 09 | `FHS_MSC_B1_PIPD_LS_PKG_08_GOLDEN_WORKORDERS_E2E(1).md` | 6,741 | `bc12a5fca45e4f68c1b1a4772b00ca72e0c07be8293527bbaafceadc7347290f` | B1-R3 CONTROL |
| 10 | `FHS-MSC_總討論(1).md` | 283,613 | `9ecd1f6f1d9c854206eee4a12519b08e6caf61951a3735502654272416ae0597` | FHS UPPER DESIGN |
| 11 | `FHS-MSC_藍圖_r2(2).md` | 1,320,878 | `a80b3b4d7cc93e52a297a3e5176e27f207b36b8cd81a3d5440c70b4a80290ff9` | FHS UPPER DESIGN |
| 12 | `SBL_PIPD-LS-PKG_DOC-00.md` | 465,363 | `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01` | SBL DESIGN |
| 13 | `SBL_PIPD-LS-PKG_DOC-01.md` | 1,041,962 | `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f` | SBL DESIGN |
| 14 | `SBL_PIPD-LS-PKG_DOC-02.md` | 1,148,207 | `4ff0cda5ab00ba5f577151e5b004d2167d933e912e302c9e3529b237ccb9e035` | SBL DESIGN |
| 15 | `SBL_PIPD-LS-PKG_DOC-03.md` | 1,704,253 | `ea69e1d3718ed86aecd74a3ebcc933960eacc30b586ab80fcb9f733037e33476` | SBL DESIGN |
| 16 | `SBL_PIPD-LS-PKG_DOC-04.md` | 618,110 | `ee90cb1c86f6f7350c11c9c962233a89b035ca41ff82c8968f7968608fc6f6e0` | SBL DESIGN |
| 17 | `SBL_PIPD-LS-PKG_DOC-05.md` | 2,382,349 | `3b47a0b6224b1984a4047cf53aac5ac50615c93a560fea46e1b43d079a5d9f27` | SBL DESIGN |
| 18 | `SBL_PIPD-LS-PKG_DOC-06.md` | 1,554,880 | `64ea4977dab3093301f82dc7469413cc754998fc53946467842e06d83645102b` | SBL DESIGN |
| 19 | `SBL_PIPD-LS-PKG_DOC-07.md` | 1,265,128 | `a366d3783c82089c5593ffabb0704d8507632cce45622684f7a0186f2ae310f8` | SBL DESIGN |
| 20 | `SBL_PIPD-LS-PKG_DOC-08.md` | 925,526 | `c7029c1ff07abe3135d33d3abf858a5fecedd911b494cd69c16eb1ddb8158288` | SBL DESIGN |
| 21 | `SBL_PIPD-LS-PKG_DOC-09.md` | 904,598 | `6450f7c15915ec8b304f4e5fd4093ea707434db8bae9d2bb6e66c30ab6eed2e1` | SBL DESIGN |
| 22 | `SBL_PIPD-LS-PKG_DOC-10.md` | 1,397,936 | `a64aa21c977334dd74d660a86377ee10c4d329aa5fde0dae25ff81a3e69e8d8f` | SBL DESIGN |
| 23 | `SBL_PIPD-LS-PKG_DOC-11.md` | 1,831,131 | `12f8705d780b76f264457c194a6ff359da8d74b5d6d8c83fa245b74d2a37508e` | SBL DESIGN |
| 24 | `SBL_PIPD-LS-PKG_DOC-12.md` | 982,931 | `d1e470d82ca14319582cb8947aa52007927aa38e726249b1430804cfe8c8ca56` | SBL DESIGN |
| 25 | `SBL_PIPD-LS-PKG_DOC-13.md` | 1,251,068 | `7cc0c8b17311130c875910b2548b93c28bd4e1c8ee04d300f85fc33d4c09beb1` | SBL DESIGN |
| 26 | `PIPD_LS_DOC-00_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md` | 251,982 | `be3a672ec20aa0e6b5e0e35097fc08de749bfe7f59f827d18e38aef67dd68ea4` | PIPD DESIGN |
| 27 | `PIPD_LS_DOC-01_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md` | 177,451 | `b753f2e5cdd5598a818f8a113d57b7f815aeb3f1dfa061ce74c76bb3553ac8c7` | PIPD DESIGN |
| 28 | `PIPD_LS_DOC-02_2026-10-07_r2_HIGH_RETENTION_AUDIT_PATCHED_FULL_REPAIR_FULL_SUBSTANTIVE_BODY (1).md` | 1,306,240 | `a021998dd3b63015e89af1dd40e0b413744a69b872da46c6bf5f4d92f7f23d0b` | PIPD DESIGN |
| 29 | `PIPD_LS_DOC-03_2026-10-07_r2_AUDIT_REPAIR_FULL_SUBSTANTIVE_BODY.md` | 454,167 | `d89d82dcd2c8603ec6b86c5ec8c40845e4594bc181adf5272bd48a3de7c88f0f` | PIPD DESIGN |
| 30 | `PIPD_LS_DOC-04_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md` | 181,988 | `fa64d84da3d747b183e4affff62f4d2fb86c80bb5075f5dd933c09b20caeddcf` | PIPD DESIGN |
| 31 | `PIPD_LS_DOC-05_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md` | 227,894 | `7b40584540c162cda6debfd09a4c04321416706acdb03a7a3c2b41383dc585f4` | PIPD DESIGN |
| 32 | `PIPD_LS_DOC-06_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md` | 405,028 | `20e44ea4dd8e53c9b0a076ce861136bbea86f52687019307f6e995cd9079d303` | PIPD DESIGN |
| 33 | `PIPD_LS_DOC-07_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md` | 689,563 | `a68dae1c3670d07bcfa3476a1e37463c534594df5cd65d8dab0dca064b5a9fc1` | PIPD DESIGN |
| 34 | `PIPD_LS_DOC-08_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md` | 197,972 | `e46caa7e440392a6cfa7a86421aead5bce8a2a229fec97b133429db6b6748e42` | PIPD DESIGN |
| 35 | `PIPD_LS_DOC-09_2026-10-07_r2_HIGH_RETENTION_AUDIT_PATCHED_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md` | 144,948 | `eaf0aefe2b4711c140fc3274223d88fdc38ad4ec2b7184f756a0f2471f3b0b54` | PIPD DESIGN |
| 36 | `B1指揮施工_總紀錄.md` | 365,435 | `5e83ec59cf226d666146f0d73436cd87b30e35d30918657c6762f04ee576208c` | B1 HISTORICAL |
| 37 | `B1施工_PROMPT.md` | 248,187 | `6f24b2aac28dd8b3aa4823250dc6c18115580f743f141d2db2fb3011e8804409` | B1 HISTORICAL |
| 38 | `B1施工狀況_總鑑定分析.md` | 355,565 | `a7b17816b46d8f4ff38a3b62b336b7d36895d9730e82e6b8f892141f013f4936` | B1 HISTORICAL |
| 39 | `B1狀況根因解決_討論(1).md` | 140,843 | `f692f87ea6753454c3415738e3db3ca2621f58a4c7fda03b2516992ae27b8691` | B1 HISTORICAL |
| 40 | `FHS_MSC_B1_Task_Handoff_Report_v1_2026-10-27.md` | 80,850 | `aa006bc849c5bb6404265de6a28678e0a4ed8b75b13521b39d5dcf28fc07162d` | B1 HISTORICAL |
| 41 | `CODEX_薄PROMPT_SBL-TPM-SP_P4整合升級_2026-10-28.md` | 10,790 | `1b4252c21f7d6e242ebf8b92ad52d542a4b7e19cef7087736918d398b6cac5ad` | REVIEW / DELIVERY |
| 42 | `FHS-MSC B1 Native Bootstrap & Four-Party Dogfood Mission_討論.md` | 225,686 | `ca8a3fe33d95c9563fc4c40b7dda859f66684ab0ea2e21ccb29953ce3203e540` | REVIEW / DELIVERY |
| 43 | `SBL-TPM-SP & Native SBL-TPM_升級討論.md` | 241,225 | `92305bce348b0dc4af27f9cf56432ba195b2ad5def3150440f0a61450c0b15c4` | REVIEW / DELIVERY |
| 44 | `SBL-TPM-SP_Codex_高自動化升級修補執行方案_r1_2026-10-27.md` | 106,913 | `e15b8b694da6396f58a010df0a22fb7ee404d7da8a0fca325f6b96471138dd16` | REVIEW / DELIVERY |
| 45 | `SBL-TPM-SP_Native-SBL-TPM_升級藍圖_r1_2026-10-27.md` | 108,939 | `76277ebeba22bd20a1a2204ca8c5d3893938e4fb3e3d410d08a7a9ff9b2412a7` | REVIEW / DELIVERY |
| 46 | `DELIVERY_REPORT.md` | 13,335 | `cd6cbaeb0c889952a9c7b91427d5d5a4f066dc76f242e0541df9e8db74f635f2` | REVIEW / DELIVERY |
| 47 | `sbl-tpm-sp-0.2.0rc1-private.zip` | 4,987,096 | `7cc15a09dafee9f724306d802374c3161a7f5d0c964fd32f4287618e3b5f8c25` | PORTABLE CANDIDATE |

**檔案清單是目前對話沙盒物理位元的基線**。Windows 本地真 Root 的對應檔名、版本與 SHA 可能不同，必須 W00 再實讀。

---

# 2. 單一 OWNER 與四方架構的實際權責

## 2.1 一個 Mission、一個 Durable 工作權威、三條物理車道

```text
唯一人類 OWNER ── Versioned Standing Authorization / actual OS & Host grants
       │
HG-KSEOS：唯一 Native WorkOrder、Issuer／Receiver、Permit、Policy admission
       │（同 Mission / Subject / Policy Epoch）
       ├── SharedSpine：唯一 Durable WorkState / CAS Lease / Journal / Checkpoint
       │          │
       │          └── Hermes Native Controller：Ready→Dispatch→Readback→Repair→Resume
       │                         │
       │                         ├─ PLAN：TPM-SP (test) + PIPD + Commander Guide (test)
       │                         ├─ EXECUTE：Codex CLI Maker / bounded repo or admitted effect
       │                         └─ VERIFY_SECURITY：Challenge-SP (test) + protected Checker
       │
       ├── Fabric：Policy Stage/Active/Loaded；FAR advisor / Known-Fix reuse
       ├── SBL：產品入口與 User Outcome；不能自簽 HGK Permit
       └── Independent Checker：對 frozen candidate 的獨立 RAW/World readback
             │
         HGK native Gate reducer → Mission continue/PARK/qualified handoff
```

`Role != Profile != Worker != Principal != Lane`：三個 Portable SP 只是本輪 **temporary test bindings**；未來網頁 GPT／GPT Work／Codex 使用 Portable 技能，而 Hermes／HGK／SBL 的正式 Runtime 使用其**原生** TPM、Commander、Challenge。**不要讓測試技能成為 Native Mission 的永久依賴**。

| 能力 | 對此次聯測的責任 | 禁區 |
|---|---|---|
| HGK | 唯一 Native Admission／Issuer／WorkOrder／Gate Status | 不替模型自行推理並簽答案；不開第二 Issuer |
| Hermes | 唯一 Native mission orchestration、durable dispatch、wakeup、Stop Controller | 不自造 Permit；不將 Report/Session 當完成 |
| PLAN TPM-SP v0.2.0rc1（測試掛載） | 產品／系統／程式規劃、Source-bound Spec、Handoff Candidate | 不直接寫 PIPD Canonical、不能簽 Live Verdict |
| PLAN Commander Guide（測試掛載） | 具名 Proposal、DAG、RepairCone／WorkCard 候選 | 不當 Native Issuer；不解除 B1 原 Commander-SP 禁令 |
| EXECUTE Codex CLI | 專用工作樹的實碼修補、Build、Test、Raw、Rollback | 不能改 Checker 判準／Issuer 簽章；不能無限制補丁 |
| VERIFY External Challenge-SP（測試掛載） | Frozen Subject、反證、Finding、未證範圍 | Skill 不等於 Protected Checker、不能自行簽 `PASS_CHALLENGE` |
| Independent Checker/AO | 真權限隔離的可驗收收據和判準 | 不能與 Maker 共享可寫 Subject 或憑證 |
| Fabric FAR | FirstFail 去重、Known-Fix、必要時研究候選與 DecisionPack | 不簽 Permit、不更新 Active Policy、不另立 Queue |
| PIPD | 唯一確定性 PI/PD/ECP/TQAEP 等 Canonical Writer | 不當 Hermes Scheduler |

## 2.2 三種 Mission 分母必須分開

- `FHS-MSC MVP`：全域最小共同工廠成果，不會因 B1 完成就自動宣稱完整產品。
- `B1 Bootstrap Repair`：R1～R4、T2、G-A、三 GWO、G-B 與適用 Required/Conditional 的正式 B1 完成。
- `SBL Full Product`：原 R15.1／Host×Kind×Mode 的正式產品結果，不能因 B1 GWO-SBL 通過就整體 PASS。

保存原始 B1 `27 Atoms／31 WO-OBS／120 Parent／124 Child／38 Node／949 R15.1／192 Product Cells／81 Assets／3 GWO` 的各自命名空間，及歷史 r10 合併 Ledger `1565=625 Required+285 Conditional+655 Deferred`。**不刪分母，不把 949 與 1,565 相加，也不把它們全部變成每輪排程卡**。Scheduler 僅消費 `required_when==true` 且真正 READY 的受影卡；條件未觸發不默改成 Deferred。[A02、B1 DOC-05/06；E01 §2、§7]

# 3. 自舉策略、權限切面和避免相互等待

## 3.1 分階段 Admission：允許修復待修系統，但不允許越權

| 層 | 可做的操作 | 必須具備的現役條件 | 沒有條件時 |
|---|---|---|---|
| **L0 OBS** | Read-only Root/HEAD/Dirty/Config/Loaded Probe、研究及報告 | 核准讀取範圍／不讀出秘密 | `READ_SCOPE_HOLD`，不作效果 |
| **L1 REPO** | 隔離 Worktree 最小修補、Red/Green、候選版本、可逆建置 | 真 RepoContext、Standing Grant、精確 WriteSet、適用 PIPD ExecutionAdmission | 受影 PARK；不等待 L2 Native Issuer 來批准普通 OBS |
| **L2 NATIVE** | HGK 正式 Issuer／Receiver、Fabric Policy Activation、Host Ops／User Data | 當前 HGK Permit/Policy/Principal/TTL/Nonce、前像／回滾、Effect Journal | `NATIVE_EFFECT_HOLD`；未經准入不呼叫 |
| **A INDEPENDENT** | 原生 Checker、產品 Qualification、正式 Release Decision | 已發生的 Raw、Frozen Subject、受保護 Checker Principal、有效驗收規格 | 僅 `SELF_TESTED`／`ADVISORY`；不偽造 PASS |

**時序禁忌**：`PREPARATION` 只需 Plan 的 Oracle/Expected Evidence；`EXECUTION_ADMISSION` 需真權限；`EFFECT_EXECUTION` 才會產生 Effect Raw；`INDEPENDENT_ACCEPTANCE` 才取得 Checker Receipt。不能在「產生 Plan」時要求該次尚未執行的 Live Receipt。

## 3.2 沒有 Native Issuer 怎麼啟動？

依序採用：

1. 以已存在且有權的唯讀能力建立精確現況，確認現役 Receiver 入口與 OS Permission。
2. 已有有效 HGK Permit 時，直接依現有 API 執行；沒有時，不得自造 Token 或改 Registry 冒充。
3. 對合法 L1 Repo 修補，使用現有 PIPD/Repo 授權；若現役 Issuer 缺失使 **L1 本身也無合法 Admission**，只保留唯讀診斷與隔離不產生 Live Side Effect 的候選研究。
4. 如現行制度有被 Owner 正式准許的**限時 Maintenance／Recovery Procedure**，其許可效力與範圍以制度及實際 Token 為準；沒有就提出一次性、具名 OwnerDecisionPack。禁止系統私造永久例外。
5. 以最低可行、合法的 Reversible WorkCard 修好 Hermes/HGK；成功後由 Native 主導其餘任務，外援退回純 Worker。

**單人 OWNER ≠ 單個 OS Principal**：一位人類可常設委任多個合法機器身份，但 Maker／Signer／Checker 必須在 OS ACL、私鑰、Oracle/Policy 可寫性上真的隔離。Windows User-scoped DPAPI Key 可以滿足一部分操作便利性，**不足以自行證明同 SID 下的高保證 Checker 獨立**。

## 3.3 B1 原 Commander-SP 禁令與新四方測試衝突

原 B1 DOC-08 §2 使用 `SBL Commander plan.propose`，後來 B1 r10 明確禁用 `sbl-commander-sp`。兩者不可依時間或目標自行默修。

**落地解法**：`B1-ORIGINAL` 保留禁令，檢測 SBL 是否有可證明的**非 Commander** 合法 Proposal ABI；沒有就提交版本化、最小 Proposal Adapter 的修復候選與 Owner Ratification。新 `FOUR-PARTY-DOGFOOD` 只在隔離 Subject/WorkSet 測試新版 Commander Guide；**不得**由測試成功推翻原 B1 受約束 Contract。二者在同一 HGK/Hermes Durable 控制權威下以不同 WorkCard／Gate ACL 管理，不建另一條持久佇列。

# 4. Native 自主閉環：必須落地的 Runtime 規格

## 4.1 只在既有 SharedSpine 上實作（無第二 Scheduler）

Runtime 動作的最低介面（**設計期契約，不假設現役 API 名稱**）：

| 能力 | 呼叫前依據 | 動作及必要結果 | 必須驗的 NEG |
|---|---|---|---|
| `ReadWorkState` | 現役 Mission/Policy | `READY/RUNNING/PARKED/UNKNOWN_EFFECT` 快照＋Epoch | 錯 Mission 或過期快照拒收 |
| `ClaimCAS` | 可合法執行的 READY | `worker_id+lease_generation+ttl`，至多一合法 Claimer | 雙 Worker、stale lease 拒收 |
| `InvokeHermesWorker` | Lease/Grant/EffectClass | 真 **Hermes** Executor PID→Codex CLI 或原生工具 Invocation Trace | 測試 Dispatcher 不冒稱 Hermes Worker |
| `ReadbackEffect` | Operation Identity | World state 前後像、raw receipt、effect journal | CLI Exit0 但世界效果缺失拒收 |
| `CommitCheckpoint` | 非秘密 Journal | Status、Attempt、依賴、Cursor、Resume Predicate 持久化 | 斷線後禁止無狀態重播 |
| `ReconcileUnknown` | UNKNOWN_EFFECT | 先讀世界／判定已生效、未生效或需補償 | 不得 blind retry |
| `ResolveAffectedCone` | FirstFail + DAG | 只 PARK downstream affected cards；unrelated READY 繼續 | A HOLD 不能凍結 B/C |
| `NativeWake` | 真 OS Timer／Event（既有能力） | 新 PID 從唯一 Journal 自主取卡 | 依賴原 Chat Session 就 FAIL |
| `TerminalReducer` | 全工作＋適用 Gate＋AO | 分別給 `CYCLE_PARKED` 或 `MISSION_ACCEPTANCE_ELIGIBLE` | READY/RUNNING>0 或 Seal 即完成必 DENY |

`WORK_QUEUE.json`（若存在）只能是從 SharedSpine 導出的可重建觀測報表，不可被另一個 Agent 自行改寫成競爭的權威工作狀態。

## 4.2 Runtime 狀態與退出算法（要轉成現役程式碼測試，不只寫 Prompt）

```python
# Proposed decision logic only. Bind to the REAL SharedSpine/Native APIs.
# No authority is created by this pseudocode.
def next_native_action(snapshot):
    if snapshot.unknown_effects:
        return 'RECONCILE_UNKNOWN_BEFORE_RETRY'
    if snapshot.running:
        return 'RECONCILE_LEASES_AND_WAIT_OR_RECOVER'
    if snapshot.ready_and_admitted:
        return 'DISPATCH_NEXT_READY_FAIRLY'
    if snapshot.ready_but_not_admitted:
        return 'PARK_AFFECTED_AND_DISPATCH_UNRELATED'
    if snapshot.parked_with_auto_research_needed:
        return 'ENQUEUE_EXISTING_FAR_RESEARCH_VIA_HGK'
    if snapshot.parked_with_known_wakeup:
        return 'REGISTER_DURABLE_WAKE_AND_CLOSE_ONLY_THIS_CYCLE'
    if snapshot.acceptance_pending:
        return 'AWAIT_INDEPENDENT_ACCEPTANCE_NOT_MISSION_COMPLETE'
    if snapshot.all_applicable_requirements_verified and snapshot.authorized_closure:
        return 'REQUEST_NATIVE_MISSION_CLOSE'
    return 'RECONCILE_FIRST_FAIL_WITHOUT_FALSE_SUCCESS'
```

**禁止的 State Laundering**：`READY>0` 卻 `COMPLETE`；`PARTIAL_WITH_EXPLICIT_HOLDS` 當 `PASS`；`NOT_RUN` 冒充 `FAIL`；`CI_PASS` 當 `Native Effect`；`SEAL_EXISTS` 當 Final；`STAGE` 當 Loaded；`PROVIDER_REQUIRED` 當 Served；`INSTALLED_SKILL` 當 Invoked。

## 4.3 三種可分別更新的狀態，不建三個 Authority DB

| 投影欄位 | 實際由誰更新／擁有原始權威 | 完成意味 |
|---|---|---|
| `engineering_status` | 真 Worker 結果／Hermes Durable Journal | 工程操作或測試有 Raw |
| `native_acceptance_status` | HGK 現役 Gate／合法 Independent Checker | 適用 Native Claim 成立 |
| `mission_status` | 單一既有 WorkState Reducer | READY/RUNNING/PARKED/外部阻斷及結案資格 |

三種屬性可以存在同一既有儲存／讀取投影中；不得另建競爭的 Gate Registry。

## 4.4 分開三種重試，及版本隔離

- `diagnostic_attempts`：唯讀探針，受時間／Token 上限限制。
- `repair_iterations`：有界 Worktree Diff、POS/NEG、FAR 候選修補；產生**新 candidate_sha** 後重新適用驗收。
- `native_effect_attempts`：受 ECP、Nonce、Effect Journal、At-most-once 約束；TimeOut/未知效果先 Reconcile，不能靠換 WorkOrder ID 偷重試。
- **Generation N/N+1**：目前生效的 protected Runtime/Policy/Checker 是 N；Codex 候選是 N+1，先在隔離 Host 或可回滾 Canary 驗證，再由現役權威有條件啟用；Maker 不得改同輪 Checker/Oracle 再自簽。

# 5. 薄型 WorkCard、Gate、Evidence 與恢復介面（可直接實作的投影）

## 5.1 只增一個 Read-only/B1 Execution Profile 視圖

建議專案路徑（**待現役 Repo Root Discovery 後才採用**）：

```text
<HGK_REAL_ROOT>/integrations/fhs_b1_dogfood/  [proposed, not observed]
  README.md                     # 只說如何投影到現役 WorkOrder，不自發 Permit
  mission-profile.json          # source-bound、薄型、不可授權的執行投影
  workcards.jsonl               # 可再生候選，不是第二 Queue
  coverage-crosswalk.tsv        # 原 27/31/120/124/38/949/1565 命名空間
  checkrun-contract.tsv         # Gate → 真 CLI/ABI → POS/NEG → RAW
  scripts/preflight.ps1         # 唯讀發現／狀態讀回
  tests/                         # 後述 E01~E32 等負例
<EXISTING_SHAREDSPINE>/...      # 真實 Durable WorkState (NOT invented)
<EXISTING_EVIDENCE_ROOT>/...    # Raw live journal, read-only frozen snapshots
```

如果現有 HGK／B1 Repo 已有同等配置，就**在原位置增加欄位與測試**；不要因本文件示意路徑而新增平行儲存。使命啟動前，執行 Connector Discovery，將抽象動作綁到真 CLI／Module／API；未綁定時 `MISSING/NOT_RUN`，不能編造可執行命令。

## 5.2 Read-only WorkCard Schema 最小欄位（示例，不是 Native Issued Card）

```json
{
  "schema": "FHS.B1.ExecutionProjection@1",
  "record_type": "PROPOSAL_ONLY",
  "mission_ref": "<actual_native_mission_id_after_discovery>",
  "work_id": "B1-DG-HERMES-MINILOOP",
  "source_refs": [{"doc": "B1-00", "clause": "§4", "sha256": "<verified_source_sha>"}],
  "subject_sha256": "<frozen_candidate_sha256>",
  "effect_class": "READ_ONLY_PROBE",
  "requirement_ids": ["B1-A3"],
  "depends_on": [],
  "required_when": "ACTUAL_APPLICABILITY_TRUE",
  "repo_context_ref": null,
  "native_grant_ref": null,
  "principal_ref": "<read_scope_principal>",
  "allowed_write_set": [],
  "expected_prestate_ref": "<real_snapshot>",
  "positive_oracle": "Only one valid CAS claim; lease state persists across processes",
  "negative_oracle": "Ghost worker, stale lease and duplicate claim are rejected",
  "test_cases": ["E03", "E04", "E05", "E06"],
  "raw_evidence_expected": ["work_state", "lease", "worker_pid", "world_readback"],
  "max_diagnostic_attempts": 3,
  "max_repair_iterations": 3,
  "native_effect_attempt_policy": "BIND_REAL_ECP",
  "resume_predicate": "same_subject_and_actual_ready_or_wakeup",
  "checker_requirement": "REAL_PROTECTED_CHECKER_FOR_NATIVE_PASS",
  "claim_ceiling": "DESIGN_PROPOSAL"
}
```

**Schema 欄位不是平台自動識別的 API**。由 Codex 根據現役 `schema/input.schema.json`、WorkOrder Writer、CLI 作向後相容 Adapter；先製作 POS/NEG，不靠硬塞字串給 Issuer。`allowed_write_set` 在 Repo 卡非空且不得為 `**`；Host/User 卡使用各自合法 Adapter，不能假造 RepoContext。

## 5.3 Result／Error／Evidence Contract

每個已執行操作必須保存：

```text
mission_ref, work_id, actual_operation_id, effect_class, actual_principal,
source_sha, candidate_sha, repo_head_if_applicable, policy_epoch_if_applicable,
required_provider, served_provider, required_model, served_model,
method_registry_sha, mandatory_methods, actual_invoked_methods,
command_or_api_locator, process_id, started_at, ended_at, exit_code,
prestate_sha, poststate_sha, raw_path, raw_sha256, effect_readback,
checker_principal, checker_receipt_ref, first_fail, affected_work_ids,
checkpoint_id, wakeup_condition, attempted_repair_version, next_legal_action.
```

`NOT_RUN`、`MISSING`、`BLOCKED_HITL`、`BLOCKED_EXTERNAL`、`NO_FIT`、`FAIL_TESTED`、`PASS_SELF_TEST`、`PASS_INDEPENDENT` 都是**報告型別建議**，必須映射到現役 Canonical Status Enum；禁止擅自取代 Native Enum。保留 B1 DOC-00 §2 的 FirstFail canonical 優先序與 alias 歸一：`source/authority → path/currentness → security/issuer/token → effect_class/ECP → required_method → execution/idempotency → readback → checker/trace → gate`。

## 5.4 輕型檔案及 Evidence 防污染

- Raw Live Journal 永遠不混入 Frozen Snapshot；完成一段後原位 freeze 並 hash，不在 Hash Manifest 中包含自己的 Digest。
- 每個 Record 的 `raw_sha256` 對應真的原始位元，並保存 Manifest 以外的原件；部分可驗不冒充全量可驗。
- Report／Ledger／Static Evidence → Manifest → 獨立外部 Seal，不能先封再繼續改被封存檔。
- 每次修補／重簽，建立新 `candidate_sha + evidence_sha`；現役 Loaded Binary、Policy Epoch、Git HEAD 分別讀回。
- 若輸出含憑證、Token、使用者資料、受保護路徑，做最小遮罩；保留可驗證的摘要／Locator，不公開機密。

---
# 6. 可直接派工的施工 DAG：W00～W17（不重造 949 張卡）

> **派工原則**：每張 W 卡只是本方案的 `proposed work package`；正式操作必須由現役 HGK 將它綁成合法 Native WorkOrder／Repo Engineering WorkCard。`Owner` 指領域權責，與「唯一人類 OWNER」不衝突。**依賴是局部的**；W10 的 Guest Host HOLD 不應阻斷 W04 的純 Repo 試驗。
>
> **實際執行順序**：`W00 → [W01,W02,W03,W04] → [W05,W06,W07,W08,W09] → W10 → [W11,W12,W13] → W14 → W15 → W16 → W17`；方括號中的工作僅在當下有效准入及資源允許時並行。正式 G-A／G-B／GWO 必須遵照原 B1 Gate 依賴，而不是僅依本圖。

## W00｜Live Baseline／來源版本／接線能力發現（P0, L0）

- **Goal**：從現役 Windows Host 讀取四庫（Fabric/HG-KSEOS/SBL/PIPD）與 Hermes 真 Root/HEAD/Dirty、Import/Loaded Binary、Running PID／Scheduled Task、Policy Epoch、SharedSpine 入口、Issuer/Receiver、三 Lane 及三 Portable Plugin 真掛載。盤點 r10 九筆 Raw 的原始存在性。不得以 GitHub `main` 或上次對話推定今天運作版本。
- **Actions**：執行 §12.1 PowerShell 唯讀腳本；依 Repo README／現役入口找 `src/hg_kseos/...` 等候選，查 `git status`, `git rev-parse`, `Get-Command`, `Get-ScheduledTask`、有效配置路徑，盤點是否存在可調用的 native API；絕不輸出秘密。讀 B1 r10 Checkpoint 的具名命令，但先核對仍然有效。
- **Exit**：`live_baseline.json`（保留真 SHA、PID/Version、所缺元件）、`capabilities.tsv`（`EXISTS/LOADABLE/INVOKABLE/ACTUAL_INVOKED/PROVEN` 分級）、`source_drift.tsv`、`r10_raw_recovery.tsv`；全部未知填 `MISSING`。
- **NEG**：`GitHub PR=Host Loaded`、看見 PATH 上的 `codex.exe` 就宣稱已調用、對話指稱 r10 PASS 就偽升正式收據，全部拒收。
- **Owner**：Hermes Read-only；**Resume**：Source SHA／HEAD 變動時只重查受影 Locator。

## W01｜B1 Thin Execution Profile 與關聯適用性索引（P0, L0/L1）

- **Goal**：在不改 B1 r3 原文前提下，把 27 Atom、31 Slot、Gates、FirstFail、949 與 1565 的身份映射成**可查詢的非權威視圖**；避免全量文件被當每輪工作清單。
- **Actions**：依 DOC-00 §1/2/4、DOC-02 分類 `READ_ONLY_PROBE / REPOSITORY_WRITE / HOST_OPERATIONS / USER_DATA_EFFECT`；新增 `required_when, affected_nodes, owner, first_fail, wakeup`；相同來源及同名欄位不另造語義；以帶 SHA Locator 逐項比對；用工具讀出 `required|conditional-triggered|deferred` 的有效集合。
- **Exit**：`coverage-crosswalk.tsv`、`execution-profile.json`、含「不刪分母／不混命名空間」回歸；Owner 批准前只有 `PROJECTION_CANDIDATE`。
- **NEG**：將 `SBL 949` 與 `B1 r10 1565` 相加作 Queue 長度、把 Deferred 轉 Required 或無故全域 HOLD，均拒收。
- **Owner**：B1 Owner／PIPD 編譯接口；**依賴**：W00，**不阻斷** W02/W03 唯讀。

## W02｜Hermes 真 Executor／SharedSpine／Wakeup 初次觀測與修復（P0）

- **Goal**：區分 `Dispatcher Test PASS` 與 **Hermes Native Worker 真呼叫**；使 READY 經原本 SharedSpine/CAS Lease 進入真 Hermes Executor，進程退出可合法續工。
- **Actions**：先定位現役 Hermes launcher/Host Hooks、讀 SharedSpine API、探測 PID/Job/Lease；以不產生治理外效的隔離卡作 `READY→CLAIM→SPAWN→RAW→CHECKPOINT`；實測不同 PID；如缺 Hook，以 L1 適用合法 Worktree 修最小接線，不另寫 Scheduler；保存修補前 RED、後 GREEN、Diff、Rollback。
- **Exit**：`raw_hermes_native_spawn.json`、`lease_checkpoint.json`、`cross_process_resume_raw.json`；只有 test dispatcher 時標 `MINILOOP_TEST_ONLY`，不聲稱 T2/R2/G-B。
- **NEG**：故意 Kill Worker、二 Worker 爭 Claim、Stale Lease、Report 封存時 READY 尚有卡；需無丟卡、無重複原生效果且不提前 COMPLETE。
- **Owner**：Hermes Runtime/HGK WorkState；**依賴**：W00（隔離探測可先做），正式受治理 Effect 依 W04／W05 真准入。

## W03｜局部 PARK、Terminal Gate、自動喚醒與 FAR 事件修補（P0）

- **Goal**：把 r10 提前交付機制從 Prompt 變成 Runtime 強制控制；`NO_ELIGIBLE_READY` 時自動查 PARK 原因、Known Fix、OwnerDecisionPack 或 Durable Wake。
- **Actions**：在現役 WorkState Reducer／Event Path 實作／接線 §4.2；令 A 卡因 Native Permit 缺失 PARK、B/C 合法繼續；中途產 Report 與 Manifest，證明 State 不變。FirstFail 觸發去重 FAR，`FAR` 是 Advisor，不得直接派生 Permit。對 `PARKED` 註冊條件喚醒和最後診斷時間，禁止 Busy Loop。
- **Exit**：`E02/E03/E05/E14` POS/NEG Raw；`NO_READY_RESEARCH` 有真啟動、建議或可機械等待條件。
- **NEG**：`READY>0→MISSION_COMPLETE`、A HOLD 導致 B/C 停止、同一 FirstFail 每 Tick 重研究、沒有 wakeup 的假 PARK 都拒收。
- **Owner**：Hermes Controller＋Fabric FAR 接口；**依賴**：W02 的最小可觀測狀態；無真 FAR 掛載時不得偽裝自研究，改停在受影 Adapter。

## W04｜HGK Trust Profile → Receiver → Signed Admission 修復（P0）

- **Goal**：驗證 r10 `user_trust.py`（若仍存在）、候選 `de37c48` 與**現役** `native_admission.REGISTRY` 是否接線；不是重新設計第二 Signer。
- **Actions**：唯讀比對 `%LOCALAPPDATA%`／`%ProgramData%` 實際 Resolver；測 User-scoped key 與現役 Receiver 一致性；在安全隔離環境修最小 Profile→Registry Adapter。真正 Native Admit 必須有同 Subject／Epoch／Nonce／TTL／Scope 有效的現役權限。測錯簽、過期、撤銷、重入、錯 SID、錯 Root、Maker 可否修改 Trust Anchor。
- **Exit**：有效 `ADMIT/NACK` 的 Signed Raw 和 Receiver 身份、不同操作負例、原本 Trust Profile 不被偽生效；未證 Principal SoD 時僅 `USER_SCOPED_TECHNICAL_PASS`，不升 G-A。
- **NEG**：自製測試 Token 替代真 Issuer、同 SID 的兩 Session 冒稱不同 Signer/Checker、擴大 ACL、無回復路徑，均拒收。
- **Owner**：HGK Domain/Issuer；**依賴**：W00；與 W02 的 L1 診斷可並行，真 L2 需合法權限。

## W05｜T2：真 Issuer／Receiver／Hermes／Effect／Checker 最小鏈路（P0）

- **Goal**：使用已確認的合法最小可逆操作，從真 Issuer 至真 Checker 完成第一條 Native E2E；分別保存 Issuer、Queue、Effect、World Readback、Checker Raw。
- **Actions**：基於 W02+W04 的真功能與 Permit，從現有 HGK API 發具名 WorkOrder；Hermes 領 Lease；Codex/原生 Worker 真執行受限操作；保留同 Subject／Epoch 的世界狀態；由受保護 Checker 讀回。回復為**獨立補償 ECP**，不是重用已消耗 Nonce。
- **Exit**：`T2` 適用官方 Gate 可重播 Raw；若沒有真 Checker，只有 `NATIVE_EFFECT_OBSERVED/AO_HOLD`。
- **NEG**：僅 Queue/CLI Exit 0 卻無真 World Effect、重放 Nonce、Ghost Worker、未知效果重試，一律 fail-closed。
- **Owner**：HGK Issuer／Hermes／Checker；**依賴**：W02、W04、真 Effect Admission。

## W06｜Fabric R3 Stage→Active→Loaded→Consumer 真實投影（P1）

- **Goal**：先判斷現役路由是否真存在，只有觀測到缺失才修；不因 `NOT_RUN` 就預判 Fabric 壞了。
- **Actions**：找現役 Fabric Activator、Loaded Reader/Consumer；保存 Active/Loaded 前像；依法 Stage→Activate→Consumer ACK，同 Subject/Policy Epoch；確定 GitHub PR #18 或 Source SHA 不被借作 Active 證據；回復依獨立 Owner ECP。
- **Exit**：分開 `RAW-FAB-STAGE`、`RAW-FAB-LOADED`、`RAW-FAB-CONSUMER`、相同 SHA/Epoch、負例與回復 Raw。
- **NEG**：Stage-only、錯 Epoch、Projection 反寫 Canonical、虛構 Consumer ACK，均不給 R3/GWO-FABRIC PASS。
- **Owner**：Fabric Policy Domain；**依賴**：W00 和相應 L2 Admission；可與 W07 的 L0 探測並行。

## W07｜三 Lane Required／Served + Mandatory Method 真的呼叫（P1）

- **Goal**：證明 PLAN／EXECUTE／VERIFY_SECURITY 的 `required_provider/model` 確實由同樣 `served_provider/model` 回應；依**現役有效** policy method registry 做必要方法的 Real Invoke。
- **Actions**：讀 Policy ID/Epoch/Owner Signature/Method Registry SHA；只對 `KANBAN/SWARM/GSTACK/OPENSPEC/CODEX` 中現役 Mandatory 或 Selected 的方法觸發真執行並記 Request ID；對非選項保存 `NOT_SELECTED_WITH_REASON`，但現役 Mandatory 不可轉 NO_FIT 洗白。
- **Exit**：三 Lane 各自 Request→Served→Method Raw；至少有缺件／錯 Provider／錯 Method 的拒收。
- **NEG**：Config required 直接當 Served、工具 Installed 直接當 Invoked、默改 Provider、從過去 Epoch 借 Receipt，均拒收。
- **Owner**：Hermes Model Router／HGK/Fabric Policy；**依賴**：W00、現役路由可調；失聯只 PARK 受影 Lane。

## W08｜PIPD／B1 交接 ABI 與 Stage-C WriteSet 受影修補（P1）

- **Goal**：解除 `CR-ORACLE-001` 相關字面不相容、PIPD DOC06 12 風險軸／P4 9 Skill 輸入軸、Planned/Live TQAEP、`public-plugin-verify` Stage-C ADR-0008/0009 失敗的真受影接口；不強行宣布正式 Owner Ratification 已存在。
- **Actions**：重新讀當前 PIPD Repo HEAD、CLI help／Schemas、PIPD DOC-06/07、原有 Stage-C CI Base/HEAD Diff；列出每項 `current ABI vs source requirement`；修相容 Adapter＋POS/NEG 而非大改 Canonical；保留 P4 原 16 Schema 需版本證據；TQAEP `PLAN→EXECUTE→CHECKER` 階段分離；對所有 12 軸 Risk Guard 明示映射或保守 HOLD。原 CI WriteSet NEG 持續拒收越權 ADR 變更。
- **Exit**：實 CLI（非手寫 JSON）Intake→Profile→PI→PD→ECP 的受影流程可運行；違反來源、Oracle、Risk、Trace、WriteSet 的 Mutant 被拒；正式 Owner 未批准時 Native Ratification 仍 HOLD。
- **NEG**：直接放寬 Allowlist 使 CI 綠、把 DOC07 內容無授權塞入 Canonical、將缺獨立收據的 Planned TQAEP 寫成 PASS，均拒收。
- **Owner**：PIPD Canonical Owner；**依賴**：W00、W01，普通 L1 修補不依 W06 R3。

## W09｜合法非 Commander SBL Proposal 與雙 taxonomy（P1）

- **Goal**：遵守原 B1 Commander-SP 禁令，同時解決 DOC-08 `plan.propose` ABI 入口衝突，並保留 SBL 舊 M5 Repair／舊 M6 HostDistribution 產品義務。
- **Actions**：讀現役 SBL CLI/SP Manifest、DOC-01/04/12、探測非 Commander Proposal；存在則真 Invoke/NEG；不存在時提出最小 Adapter 候選、受影變更清單、Source Revision 建議，不偷改 DOC-08；只在獨立 Dogfood Subject 測新版 Commander Guide，隔離於原 B1 WorkCard。
- **Exit**：有合法 Alternative Proposal ABI 或明確具名 Owner HOLD；`old M5 != new M5`、`old M6 HostDistribution` 覆蓋仍完整。
- **NEG**：從未啟用的 `sbl-commander-sp` 隱式路由獲 Permit、以 `plan.propose` 名稱虛構真 CLI、以新 Flow Module 取代舊 HostDistribution，皆拒收。
- **Owner**：SBL Product/Proposal Owner；**依賴**：W00，正式 GWO-HGK 依 W09 合法入口。

## W10｜三個 Portable SP 的 Codex-CLI 真宿主 UAT（P1）

- **Goal**：測試用 TPM v0.2.0rc1、Commander Guide、External Challenge；各自確認 `DISCOVERED→INSTALLED→BOUND→TRIGGERED→INVOKED→VERIFIED`，包括**非觸發**測試。
- **Actions**：使用隔離 Codex HOME／Skill Roots，先讀現役 CLI 支援的 flags（版本可變）；對三者分別做 Load、適用 Explicit/Implicit Trigger、Non-trigger、模型 Invoke、固定 Source/Host 身份、卸載和殘留；讀真 Model Trace，不能把安裝結果冒充正向調用。TPM 的 14 Skills 與 24 DOC SHA 可對照交付報告；Challenge 只能 Advisory，正式 Checker 另驗。
- **Exit**：`host_uat/{tpm,commander,challenge}` 每個真版本、按次原始 Invoke Trace、NEG、卸載 Receipt；CLI Host 成功不升格 GPT 網頁／Work。
- **NEG**：`skills/list` 成功就標 `HOST_QUALIFIED`、同 SID Checker Session 冒稱獨立、Skill 沒觸發卻生成假 Finding，皆拒收。
- **Owner**：Portable Host Test Owner；**依賴**：W00；可在 W02/04 修復並行作 L0/L1 隔離測試。

## W11｜四方跨 Role Shadow Handoff（P1）

- **Goal**：證明 TPM Spec → PIPD Proposal → Commander Task DAG → Codex ExecutionCandidate → External Challenge Finding 能以同 Subject/Source/ABI 串接，不使用真 L2 權限做冒險的影子測試。
- **Actions**：以一個 SourceBound Goal 產 Product/Architecture/Program SPEC、PI/PD Candidate；Commander 產依賴圖與合法執行請求；Codex 只在隔離 Worktree 修已知小缺陷；Challenge 以只讀 Frozen Readset 寫反證 Finding；涵蓋 changed SHA/changed Oracle/changed WriteSet 負例。
- **Exit**：`four_party_handoff.jsonl` 各角色 ACK/NACK、same-subject identity、in/out schema、拒收錯版本；未達正式 Owner Ratification 時標 `SHADOW_VERIFIED_ONLY`。
- **NEG**：TPM 自寫 PIPD Canonical、Commander 自簽 Permit、Maker 自判 Checker PASS、越權寫 Host，均拒收。
- **Owner**：SBL/SP Handoff + PIPD；**依賴**：W08/W09 的必要 ABI、W10 真 CLI UAT；受影 CR 可局部 HOLD。

## W12｜四方真 Repo 工程 Dogfood、自研究／自修補／自迭代（P1）

- **Goal**：在**合法且隔離**的 Repository Worktree 中，讓 Hermes 透過 HGK／WorkState 派受限 Codex 修復小缺陷，並由 Challenge 對新版凍結候選反證，實測 FAR Known-Fix Reuse 和受影 RepairCone。
- **Actions**：先固定 Red Oracle（不得由同一 Maker 同時修改）；合法 WCard 與 WriteSet；Hermes 真 Worker 調用 Codex；Red→小補丁→Green→負例→新 SHA；由隔離 Checker 或僅 Advisory Challenge 依保證等級給 Finding；如失敗只 reopen affected DAG；最多按有效 StopLoss 迭代，未知 Effect 不重送。
- **Exit**：真 Worker PID、Codex command、Diff、Tests/Exit/Raw、Rollback、FAR Decision／Known Fix、受影 Checker Receipt；無 protected Checker 則只計 self-tested。
- **NEG**：一個 A HOLD 殺光 B/C、修補跨 WriteSet、改 Oracle 後假綠、相同 SHA 反覆重驗、無界 Loop。
- **Owner**：Hermes/Code Maker＋Independent Checker；**依賴**：W02/03、W11，真 Native Admission 依 WorkCard 類型可先做隔離 Repo 工程。

## W13｜G-A 六項合取正式 Native Gate（P0/P1，L2+A）

- **Goal**：依 B1 DOC-00 §4 的原規範，由真 HGK／Independent Checker 做六項同 Subject/Epoch 合取。
- **Actions**：從現役 Raw 查 Issuer、Fair Durable Queue、Fabric Stage→Active→Loaded 同 SHA、三 Lane Required/Served、Mandatory Methods、Independent Checker Raw/Principal；任何無法證明的項目都 HOLD 該 G-A，不補假收據。
- **Exit**：六項 Gate 真因果鏈、各 Raw Ref、Checker Identity、Effective Policy Epoch；正式 G-A 只能由現役有權 Reducer 給出。
- **NEG**：用 r9 Dispatcher PASS、配置檔／PR SHA、Maker self-test 替代任一項。
- **Owner**：Native Gate Owner；**依賴**：W04～W07 的適用真證據、W05 真 Checker。

## W14｜三張 B1 原有 Golden WorkOrders（P0/P1，三域獨立）

- **GWO-FABRIC**：真 `Source→Stage→Activate→Loaded→Consumer ACK`，三類 Raw 不合併；同 Subject/Epoch；錯 Epoch/Stage-only/逆寫皆 NACK。依 W06。
- **GWO-HGK**：合法 SBL 受治理 Proposal（不違反禁用）、HGK Issuer→Hermes CAS/Lease→受限可逆 World Effect→不同 Principal Checker；舊 Nonce/ghost/duplicate 驗負例。依 W05/W09/W13 適用 Gate。
- **GWO-SBL**：真 Host Install／Load／Doctor，另在**新建授權合成 DataDir** 以 `--data-dir <dir>` **置於 subcommand 前**執行 `init → add → list --json → remove --id <實際 add ID> → list → uninstall --yes`；前後跨程序 Readback，無殘留，不以 install 替 user-data。真 User Consent/Issuer 沒綁則該 USER 子卡 `NOFIT/HOLD`，其他不變。依 W09/W13。
- **Exit**：三個 Domain **不同 Operation IDs／RAW／Checker Receipts**，均以現役真程序執行；一張不可代替另外兩張；原先 B1 Required／Conditional 仍個別按適用性計。
- **NEG**：GWO-FABRIC 的 Stage 當 Loaded、GWO-HGK 的 Fixture 當 Issuer、GWO-SBL 安裝當 Add、未知 `delete` 子命令當合法 CLI、共用 User Data 目錄。
- **Owner**：Fabric／HGK／SBL Domain Owners；**依賴**：對應各域 L2 + Gate；可各自維護不同受影阻斷，不偽作全域 PASS。

## W15｜G-B 外援 Revoke／新 OS Process 原生 Successor（P0, L2+A）

- **Goal**：用真跨程序試驗證明 Native 自主閉環已不依賴臨時外援 Session／Token。保留合法 Codex CLI Worker，但它**只能**由 HGK/Hermes 正常派工調用。
- **Actions**：三 GWO 及適用正式條件通過後，正式 revoke 臨時 Helper Principal／Scope／Nonce；讀回撤銷；結束外援 Session；由**新 OS Process** 透過現役 Native Wakeup 與 SharedSpine 自主挑出下一張合法卡，重新 Issuer/Lease/Effect/Independent Checker；使用已撤銷的舊 Token 企圖重入，應在 Spawn 前拒絕且零未授權效果。接續原 B1 規範要求的 22-node successor ACK。
- **Exit**：`RAW-REVOKE`、`RAW-NATIVE-SUCCESSOR`、跨 PID／新 Session、拒收舊 Token、Rollback/Residue、同 Subject/Policy Epoch Chain；**無外援執行控制**。
- **NEG**：同 Session 手動呼叫下一卡、靠原外援排程觸發、已撤銷 Token 被接受，全部 G-B FAIL/HOLD。
- **Owner**：HGK Native Gate／Hermes／Independent Checker；**依賴**：W13 與 W14 三 GWO 真閉合，G-B 官方條款優先。

## W16｜FAR 自研究與已驗證修補的自進化（P1，循環能力）

- **Goal**：在 W02～W15 實作過程中「邊執行邊沉澱」，而非等全結束再設計超大 Auto-Evolving Framework。
- **Actions**：讀現役 FAR Event/Adapter；建立 `FindingIdentity(source_sha, candidate_sha, first_fail, scope, policy_epoch, environment)` 去重；優先查既有合法 Known-Fix；確無命中才進 `READ_ONLY_RESEARCH`（相關文檔／Git Diff／反例），最多產出有界 1～3 個候選；由 Commander Proposal／實際可用 DecisionPack 轉 WorkCard；HGK Admission 後才 Codex 修補；Checker 對新版本測試；證據完整且適用條件相符才登記 `VERIFIED_FIX_PATTERN`；下輪先復用，不自動 Promotion 權限。
- **Exit**：至少一個重複 FirstFail 的去重與既有 Verified Fix 重用回放；一個未知阻斷自研究，能提出合法下一動作或一次性 OwnerDecisionPack；不得無限研究 Tick。
- **NEG**：同 FirstFail 每 10 秒重查全網、FAR 自造 Native Permit、無 Checker 把修補寫成正式有效、不同 Epoch 誤用 Known-Fix。
- **Owner**：Fabric FAR Advisor／Hermes Native Commander；**依賴**：W03 有真 Event/Journal，修補動作依各自 Gate；不成為額外永久服務。

## W17｜分層驗收、回歸、封存與正式接管交付（P0/P1）

- **Goal**：在不提前結案前提下，把已證實成果轉成可重播候選、Evidence／Diff／Checkpoint；只有全部**適用**正式條件達成後才請求 Final Native Acceptance。
- **Actions**：執行 §9／§10 機械回歸；重新計算 Required+TriggeredConditional、三 GWO、G-A、G-B、Checker；先產中期快照（不改 WorkState），正式結案再依 Report→Ledger→Manifest→External Seal；封存前 `READY/RUNNING/UNKNOWN_EFFECT` 必為零或該正式原契約可接受的狀態，未決外部阻斷則 Mission PARK 而非接受完成；保存完整 Source/Repo、安裝二進位、World Readback、撤權、回滾與 unqualified 聲明。
- **Exit**：`delivery/` 的機讀狀態、真結果與 `NEXT_LEGAL_ACTION`，以及由有權者簽發的 Acceptance／Release（若不存在，`RELEASE_FAIL_CLOSED`）；任何時候報告可產、但不導致 Mission 停止。
- **NEG**：只收 CI 綠／Seal、漏 r10 五筆 Raw 卻稱全量驗證、Ready>0 結案、B1 PASS 代替 GPT Work Host PASS、改寫歷史 Frozen Snapshot。
- **Owner**：Hermes 提交，受保護 Checker／HGK Domain Owner／正式 Publisher 各自裁決；**依賴**：按被宣稱的 Qualification/Release Gate，不以無關產品 Deferred 阻斷 B1。

---

# 7. DOGFOOD 真實任務設計與相依性隔離

## 7.1 四方聯動是施工目標也是測試物，不是上位 Gate 的替代品

核心實測以**同一個專案的兩種正交受測 Subject**進行，避免誤用 Commander 禁令：

| 受測 Subject | 本輪目的 | 可使用 Portable Commander Guide？ | Native 判定 |
|---|---|---|---|
| `B1-ORIGINAL` | 修復 r1～r10 原生鏈，遵守 DOC-08/後續禁令與原 B1 Gate | **不得直接啟動原禁用 SP**；只使用已核准非 Commander SBL Proposal | 正式 R1～R4/G-A/GWO/G-B |
| `FOUR-PARTY-DOGFOOD` | 隔離驗證新版 TPM／Commander Guide／Challenge 的 Plan→Build→Verify | 可以在其**自己**的 Plugin Host／權限測試 Subject 內測掛載 | Portable Host UAT＋介面 Shadow；若做真 Native，需額外合法 Admission |

兩個 Subject 可共用的只有 HGK／Hermes **原生現役控制平面**及經授權的原始證據 Locator；不能共用 Operation ID 及正式 Checker Verdict。這不是建立第二個 Scheduler。對外宣稱結果分開：`B1_NATIVE_QUALIFIED`、`FOUR_PARTY_CODEX_HOST_TESTED`、`GPT_WORK_HOST_QUALIFIED` 各有不同受測對象。

## 7.2 最小 Golden Journey（按真正測到能力定義）

| ID | Golden Journey | 真 FUO | 至少一個 NEG |
|---|---|---|---|
| `DG-01` | TPM 自包含來源→Product/System/Program SPEC→PIPD Candidate | SourceBound SPEC 可追溯、24 DOC 可現場 SHA Reader | 錯 SHA／空 Source／過期 RepoContext 拒收 |
| `DG-02` | Commander Proposal→合法 WorkRequest→Codex Repair | 受限 WCard 和 Red→Green 真 Repo 結果 | Commander 不得 Issue Permit；WriteSet 違規拒收 |
| `DG-03` | Challenge Frozen Candidate→找到缺陷→修補→重驗 | Maker/Checker 角色及不同 SHA 的真 Raw | Maker 改 Oracle 或使用舊 Verdict 拒收 |
| `DG-04` | Hermes 真 Executor→被 Kill→新 PID 續工 | 真 Durable WorkState 自主性 | 報告完成、A PARK 或 Session 關閉不能關任務 |
| `DG-05` | B1 G-A 六項合取 | 原生六控制能力同 Subject/Epoch | 任何一項缺原始 Receipt 必 HOLD |
| `DG-06` | GWO-FABRIC／HGK／SBL | 三種不同原生 World Effect 與不同 Raw | 任何跨域證據互借 FAIL |
| `DG-07` | G-B Revoke→Native Successor | 不依賴原外援而自主接管 | 舊 Token 仍可重入 FAIL |
| `DG-08` | 受影 FirstFail→FAR→Verified Fix Pattern | 自研究、自迭代及下一輪重用 | 無權限自進化 Policy／無界研究拒收 |

**三種測試分母的區分**：`DG-01～03` 的 Portable/Shadow 成功不證明 B1 的 T2；`DG-04～07` 的 Native 成功不證明 GPT Web／Work Host；`DG-08` 的 Known-Fix 成功不自動證明可修改 Canonical Governance。原 B1 DOC-08 的 GWO 是正式真效果、DG 僅為整合測試標籤。

## 7.3 一個真正有用的 Dogfood 缺陷實例

在新的受限 Git Worktree 建立一個可重播的**小型真缺陷**（不要在本次修壞現役 Issuer／Checker 以製造測試），例如 Repo 已有 Red test 的 parser/CLI edge case：

1. TPM-SP 在 Codex CLI test Host 讀內建來源、產 `FUO/NonGoals/ACC+NEG/SourceRef`。
2. PIPD 使用現役 deterministic CLI 產合法或候選的 PI/PD/ECP；若 Oracle/Source Ratification HOLD，按其受影阻斷，不把候選提升正式權威。
3. Commander Guide 產 WorkCard／Task DAG（Proposal Only），限定 Worktree 與 `allowed_write_set`。
4. HGK 依現有合法 Repo 工程 Grant/Admission 作准入；如當輪僅影子測試則只作 Test Subject，不能冒稱 Signed Native WorkOrder。
5. Hermes 真派發 Codex CLI，紀錄 PID、CLI version、diff、測試退出碼、raw SHA。
6. Challenge-SP 在唯讀 Checker 角色下對 Frozen SHA 做安全／契約負例；真 Protected Checker 另驗 OS Principal。
7. 修補者依 `FindingIdentity` 查 FAR Known Fix，再做一次最小修補；新 SHA 強制重新檢查受影 POS/NEG。
8. 故意 Kill 其中一個 Worker，從 SharedSpine 由另一 PID 恢復；同時令獨立一張卡 READY，以證明正常推進。
9. 原 Native 真可逆 Effect 另由 `DG-05～07` 閉合，不把 Repo Patch 當 Native World Effect。

**Dogfood 反證標準**：這九步中任一步沒有真 Raw，就只能報告「已覆蓋至第 N 層」，不得宣稱 E2E 完成。若遭 Source Ratification HOLD，仍可繼續做所有合法的隔離工程、Stub/Shadow 測試及其他 READY 卡；但不得自行解除正式 Gate。

---
# 8. 25 項 B1 RC 根因：逐項施工責任、反證與宣稱上限

> 來源：`《B1施工狀況_總鑑定分析》`、`《B1指揮施工_總紀錄》`、`《B1狀況根因解決_討論》` 與 `《FHS-MSC B1 ..._討論》` 中一致的 RC-01～25 分類。下表的「修補」是**要執行的工作**而不是已完成的事實；`NOT_RUN` 不能寫成故障已證實。

| RC | 來源辨識的根因／問題 | 本次最小處置 | 責任 W | 必須失敗的反例／正式出口 |
|---|---|---|---|---|
| **01** | 真 Hermes Executor／Durable Wakeup 未證 | 真 Native Hook/Worker／OS restart | W02/W15 | 只跑 Dispatcher 測試不能 PASS R2/G-B；新 PID 自主完成 |
| **02** | READY 未耗盡仍提前 Report/Close | 在 Runtime 加 TerminalReducer | W03/W17 | READY>0＋Seal 必拒 Mission Complete |
| **03** | Native HOLD 被擴為全域停工 | Affected Cone＋獨立 READY 派工 | W01/W03 | A PARK 時 B/C 必繼續 |
| **04** | Bootstrap 修 Issuer 卻先需 Issuer | L0/L1/L2 分階段適用准入 | W01/W04 | 無 L2 時合法 L0/L1 不被錯擋；Host Effect 仍拒 |
| **05** | User Trust 未接現役 Receiver | Profile Resolver 真接線／Admit | W04 | UserKey tests 通過但 Receiver 不讀取不能 PASS R1 |
| **06** | Maker/Signer/Checker 分權未證 | OS Principal/ACL/Key 保護真驗 | W04/W05 | 同 SID 可改 Oracle／私鑰的第二 Session 不是獨立驗收 |
| **07** | B1 Design 當 Runtime 授權 | Claim Ceiling 型別與 `task_kind` | W01/W11 | `AUTHOR_SIDE...` 不能簽 Native Permit |
| **08** | 依賴圖缺局部 PARK | Dependency/Affected DAG | W01/W03 | SourceBlock 不得凍結無關工作 |
| **09** | Fabric Activator/Loaded 未真測 | Stage/Active/Loaded/Consumer 分開讀回 | W06/W14 | Stage-only 或 PR SHA 冒充 Loaded FAIL |
| **10** | 模型 Required/Served 未真測 | 三 Lane 真模型／Method Invoke | W07 | 無 Request/Served Raw 時 R4 NOT_RUN/HOLD |
| **11** | PIPD Oracle Canonical／P4 ABI 差 | 版本化 bridge＋Owner Ratification | W08 | Wrong Oracle/Source 不能靜默編譯正式 PI |
| **12** | 十二風險軸／九輸入軸映射 | 逐軸 trace＋Safety Veto | W08 | 遺失任一防護軸或降級必拒 |
| **13** | Planned TQAEP 混作 Live PASS | Test Plan／Actual Exec／Checker 階段隔離 | W08/W13 | 無真 Checker Receipt 只能 PLANNED |
| **14** | PIPD Stage-C WriteSet CI 真失敗 | 差異對帳 ADR-0008/0009／限權修補 | W08 | 擴大 Allowlist 洗綠不合格 |
| **15** | DOC-08 Proposal 與 Commander 禁令衝突 | 原 B1 禁令＋新隔離 Dogfood，修非 Commander ABI | W09/W11 | 原 B1 隱性調用 `sbl-commander-sp` 拒 |
| **16** | Repair Retry 與 Native At-most-once 混用 | 三種 Attempt Counter/UnknownEffect reconcile | W02/W12 | Effect Timeout 盲重試不得發生 |
| **17** | 949／1565 Product Identity 被當每輪 Queue | 保留 Coverage、只派適用真依賴卡 | W01/W17 | 變更適用性來減分母拒收 |
| **18** | 假定 SourceFreeze／TaskKind／Issuer 端點都存在 | Capability Discovery＋真 ABI Bind | W00/W08 | 無端點用假 JSON 取得 PASS 拒 |
| **19** | Code/CI/PR/Loaded/Effect 混認 | 多層 Evidence Claim Ceiling | W06/W17 | CI PASS→Native PASS 拒 |
| **20** | Manifest/Seal 綁工作結案＋自含 SHA | Live Journal/Snapshot/Seal 分離 | W03/W17 | 封存後改 Snapshot、Ready 尚存即 Complete 拒 |
| **21** | 重複大 Context、失去恢復狀態 | Minimum Readset／源 SHA 增量 | W00/W03 | 重開 Session 無真 Cursor 卻宣稱續工拒 |
| **22** | Windows Admin 被泛化為全部施工必要 | 按 EffectClass User/Machine Trust | W04 | L0/L1 無關作業不應因無 Admin 被擋 |
| **23** | Mandatory Method 安裝當調用 | Policy Applicability＋真 Invoke Raw | W07 | Installed≠Invoked，Mandatory 缺則 HOLD |
| **24** | NOT_RUN／FAIL／NOFIT／HOLD 混用 | 型別化 Result/FirstFail/Resume | W01/W17 | 未測 Fabric 不得判已壞；狀態清楚 |
| **25** | Issuer/Checker/GWO 真 Raw 缺 | 原生 T2/G-A/三 GWO/G-B 與 AO | W05/W13～17 | 任何缺原件的正式 claim 都 FAIL-CLOSED |

## 8.1 原因與影響的工程因果閉合方式

每張修補 W 必須提供 `baseline observation → causal hypothesis → reproducible NEG → minimal change → POS/NEG replay → actual effect readback where applicable → checker → claim ceiling`。不能只用「模型分析認為已解決」當 Root Cause Closed。對 RC-09/10/19/23 的 Native 範圍，若此前只是未跑而後來一跑就 PASS，記為 **`VERIFIED_EXISTING_CAPABILITY`**，不作無謂 Patch。

## 8.2 何時不應修補？

若真 Host/Root/Provider 觀測結果與設計假設不同：先更新 `Observed Currentness`、保留現場事實、只修改受影 Adapter；如果隨意 Patch 會造成更大風險、需要新 Canonical 權威或不合法權限，保留 `NO_FIT/BLOCKED_HITL` 與一張必要的 OwnerDecisionPack。**沒有明確第一個真失敗，不應為追求進度改動四庫程式。**

---

# 9. 機械驗收 Gate、G-A／G-B 與可重播 CheckRun

## 9.1 原 B1 Native Gate 不可因新 Mission 偷縮

| Gate | 必備真原始證據 | 不合格主張 |
|---|---|---|
| T1 | Durable Queue／CAS／Lease／Fairness／Cross-process 基礎（沿用但重查 currentness） | Dispatcher Test 不等於真 Executor |
| T2 | 真 Issuer→Receiver→Hermes→Effect→World Raw→獨立 Checker | 假 signed bundle／只有 Unit Test |
| R1 | 現役 Grant/Issuer/Receiver、Nonce TTL Scope Epoch Revocation 和所有受影 NEG | User Trust 7 個隔離測試就全域 R1 PASS |
| R2 | Hermes 真 loaded Executor、合法派工、Durable Wake、跨程序續工 | Shell script／Windows task 只喚起測試 Dispatcher |
| R3 | Fabric Source→Stage→Active→Loaded→真 Consumer 同 SHA/Policy Epoch | PR、Stage、檔案存在 |
| R4 | PLAN/EXECUTE/VERIFY_SECURITY Required＝Served，現役 mandatory Method 真 INVOKED | Config 正確但 Provider 未實際 Served |
| **G-A** | **原六項合取**：Native Issuer Live AND Fair Durable Queue AND Fabric Stage→Active→Loaded same SHA AND 三 Lane Required=Served AND Method-applicability Receipt same Epoch AND Independent Checker Raw same Subject | 任一 missing 就 G-A HOLD，不從局部 PASS 推全局 |
| GWO-FABRIC | STAGE／LOADED／CONSUMER 三身份分離 | Stage-only／反向寫 Canonical |
| GWO-HGK | ISSUER／QUEUE／EFFECT／Checker 不同 Raw，真小可逆 World Effect | 只測 Dispatcher、不執行 Effect |
| GWO-SBL | INSTALL、ADD、LIST1、REMOVE、LIST2、UNINSTALL 真 User Data 操作 | Host 安裝≠User Add |
| **G-B** | 三 GWO 先閉合→外援撤銷→新 OS Process 自主下一卡→舊 Token 拒收→Rollback/Residue→22-node successor ACK | 同一 Session／舊外援仍掌控不合格 |
| Final B1 | 原 Required+適用 Conditional、真正 Protected Checker、Manifest/Raw、合法有權 Acceptance | 文件／CI／Seal 自簽 `native_accepted=true` |

**已證 Gate 的重用**：在同 Subject/Policy Epoch/Loaded Binary/Raw/Checker/currentness 完整且真正未受影時，不要求每輪重跑所有 120 Parent +124 Child；先做 affected-only qualification。若來源變更污染了全域信任根，才擴大重驗；範圍由現役 Oracle 及影響圖決定，不能口頭說「全免」。

## 9.2 正反例／故障注入 CheckRun E01～E32

| ID | 測試主體 | 正例 POS | 反例 NEG／SEC，第一拒收 | 結果消費 |
|---|---|---|---|---|
| E01 | L1 隔離 Repo 修補 | 合法 RED→PATCH→GREEN、Rollback | 缺 WriteSet/Currentness 不准 Repo 寫 | W01/W12 |
| E02 | L2 Gate 缺失與 L0/L1 續行 | HGK 未 READY 時安全觀測繼續 | 未簽 Permit 的 Host Effect DENY | W03/W04 |
| E03 | A PARK、B/C Ready | B/C 真完成、A 受影 PARK | A HOLD 導致全域 STOP FAIL | W02/W03 |
| E04 | Kill Hermes Worker | 新 PID 真 Native Resume、相同 WorkID | 同 Session 模擬 Resume 不算 | W02/W15 |
| E05 | 中途 Report/Seal | WorkState 不變，READY 續行 | Seal 觸發 Mission Complete DENY | W03/W17 |
| E06 | 兩 Worker 同 Claim | CAS/Lease 只一方有效 | Ghost/Stale lease/duplicate effect DENY | W02/W05 |
| E07 | Effect Timeout | UNKNOWN_EFFECT→World Reconcile | Timeout 直接再發 Effect DENY | W05/W12 |
| E08 | HGK Signed Admission | valid Signed SameSubject Admit | 錯 Key/Epoch/TTL/Nonce/Revoke/Scope DENY | W04/W05 |
| E09 | Fabric 4 步 | Stage、Active、Loaded、Consumer 都有 Raw | Stage-only/錯 Epoch/逆 Projection DENY | W06/W14 |
| E10 | Model Required/Served | 三 Lane 真 Served Match | 假配置／默改 Provider/Method 降級 DENY | W07 |
| E11 | PIPD Oracle/Profile | 所有風險保守覆蓋，真 CLI | Canonical Oracle 不對／12 軸丟失 DENY | W08 |
| E12 | SBL USER 生命週期 | Install+User CRUD+Uninstall 分離 | `delete` 未知、空 title、Foreign File 防刪拒收 | W14 |
| E13 | Revoke 與 Successor | 新 PID Native Next Work | 舊外援 Token 重入在 spawn 前 DENY | W15 |
| E14 | 結案辨識 | READY/RUNNING=0、Gate 完成方可申請 | 未完成 Required 或 Acceptance Pending 直接 Complete DENY | W03/W17 |
| E15 | Source SHA/Path | 正確 Frozen Reader | 遍歷／符號連結逸出／SHA Drift 拒收 | W00/W08 |
| E16 | PIPD PI/PD Subject | Hash/Atom/Trace 同主體 | WrongHash/WrongSubject/無 RepoContext 拒收 | W08/W11 |
| E17 | TQAEP Live | 受保護 Checker 真 Receipt | Planned 文字或 Fixture Receipt 冒 Live DENY | W08/W13 |
| E18 | Stage-C CI | 允許清單內精確變更 PASS | ADR-0008/0009 越界真 FAIL | W08 |
| E19 | Commander 隔離 | 新 Dogfood 可測 Guide | 原 B1 隱式執行 `sbl-commander-sp` DENY | W09/W11 |
| E20 | Portable 14 Skills | 真安裝、Load、Invoke、Uninstall | 只有 SkillList／未觸發不算 Host PASS | W10 |
| E21 | Portable Non-trigger | 無關任務不觸發 TPM/Commander/Challenge | False Positive Invocation 拒 | W10 |
| E22 | Challenge read-only | Frozen Candidate／Finding 命令/Exit/Raw | Checker 改 Subject/Oracle/Policy DENY | W10/W11 |
| E23 | Maker/Checker Principal | 真 ACL／不可寫 Oracle／不可取 key | 同 SID+同 writable token 冒獨立 DENY | W04/W12 |
| E24 | Evidence SHA 封存 | Raw→Manifest→External Seal 可重算 | Manifest self-hash/封後變更／缺 Raw 拒 | W17 |
| E25 | Different GWO Identity | 三域不同 Operation/Raw/Checker | 借另一域 Receipt 冒 PASS DENY | W14 |
| E26 | Loaded Binary | 安裝版本／實際 Loaded Module SHA 相符 | Repo/PR SHA 冒 Loaded SHA DENY | W02/W06 |
| E27 | Registered Method | Policy Mandatory 同 Epoch 真 INVOKED | Installed 但無 Real Invoke 拒 | W07 |
| E28 | FAR dedup | 同 FirstFail 命中 Verified Fix | 每 Tick 重新研究、無來源推理重覆 FAIL | W16 |
| E29 | FAR Scope | FAR 只 Proposal，HGK 才可 Admit | FAR/Commander 自造 Permit 或 Policy DENY | W16 |
| E30 | 自進化 Versioned Fix | 新 Candidate SHA 的正反回歸及 Checker | 使用舊 SHA PASS／同 Maker 調 Oracle DENY | W12/W16 |
| E31 | CR_OPEN 範圍隔離 | Oracle HOLD 只阻 Canonical 受影卡 | 所有 READ_ONLY／Repo 隨之 HOLD 拒 | W01/W08 |
| E32 | 長任務持久化 | 合法 Task 在新 Session 依既有 Checkpoint 續行 | 純 Prompt「繼續」且無 Durable Cursor 不算 | W02/W17 |

**故障注入安全原則**：E06/E08/E13/E23 等安全負例只在受權隔離／現有拒收接口上操作，不要求破壞正式服務、公開秘密或嘗試未批准的實際效果。E14 不把異常情境變成正常放行理由。每項測試出具 `test_id, subject_sha, first_fail_expected, actual_command, exit, raw_sha, checker_ref, status`，且有 FAIL 的負例才算驗證防線。

## 9.3 Acceptance Fence：不准跨界的八種代理結果

| 已看到的事 | 只可宣稱 | 不可宣稱 |
|---|---|---|
| B1 DOC-00～08 產包與靜態 Schema | Design Candidate | Issuer/Native PASS |
| 107 本地 TPM tests／14 Skill Loaded | Source/CLI Local Tested | GPT Web/Work Host Qualified |
| PIPD Offline Gate 成功 | 該 Job Green | Stage-C／Product Acceptance 全 PASS |
| HGK User Trust isolated tests | User Trust technical candidate | Receiver actually admitted／Protected Checker |
| Hermes r9 Dispatcher／OS Task | Dispatch Primitive | Live Hermes Native Executor Successor |
| Fabric PR 或 Stage | Repo/Stage | Active Loaded Consumer |
| SBL Install | Host Install | User Add/Remove/Uninstall Outcome |
| External Challenge Skill Finding | Advisory/Unqualified Challenge | Signed AO／PASS_CHALLENGE |

---

# 10. FAR 自研究／自進化與單一 OWNER 的決策閉環

## 10.1 事件驅動，不再「每次遇到問題請人再打 Prompt」

採用 FHS r2 §6.2 及 FHS 總討論的既有決策集合：`NOOP / READ_ONLY_RESEARCH / REPLAN / REPAIR_SCOPED / HUMAN_DECISION / STOP_ESCALATE`。由現役 Hermes／HGK 的 FirstFail／WorkJournal 事件喚起 FAR Adapter；不另建 FAR Controller、FAR Queue 或自有權威 DB。

```text
Typed FirstFail / NO_ELIGIBLE_READY / REPEAT_FIRSTFAIL / UNKNOWN_EFFECT
    → Existing Event Adapter / FHS FAR
    → 查 FindingIdentity、已驗證 KnownFix、目前 Source/Policy currentness
       ├─ Exact Valid KnownFix → bounded Repair Proposal
       ├─ 可自動唯讀研究 → 受限 Research ＋反證＋最多三候選
       ├─ 缺實際權限／Policy 衝突 → 一份 OwnerDecisionPack（精確選項）
       ├─ 暫時外部缺件 → PARK affected cone＋WakeUp Predicate
       └─ 不能安全處置 → STOP_ESCALATE（不影響無關合法工作）
    → Native Commander proposal（或現役允許的合法替代）
    → HGK 判定正式准入
    → Hermes/Codex 真執行 → Raw/Checker → new versioned KnownFix
```

**FAR 只能「研究及推薦」，不應宣稱具有終局裁決權**。`auto-evolution` 的成果是基於證據改善下次排障能力，而不是讓模型自行變更 Native Policy。必要時可由 Publisher/Owner 在正式 Release 迴圈批准已驗證的規則/測試進入 Canonical；不需每個小修補都人工批准。

## 10.2 No READY 不是 Mission Complete

若查出 `Ready=0, Blocked=3`，下一個自動行動不是直接封存，而是：

- 每個 Blocked 必有 `first_fail + affected_scope + owner + candidate_next_action + resume_predicate`。
- 對能由觀測或已驗證 KnownFix 自行解決者，建立**合法**診斷／修復工作；不得在未准入時自行生效。
- 對等待 Provider/Owner/Policy 的外部阻斷，建立 Durable Wake 條件；下輪依事件／間隔重新檢查，不無限空轉。
- 若需要 OWNER 決議，呈**單一決策卡**並包含建議方案、成本／風險、可逆性、受影 WorkIDs、需要的真權限、替代方案與「不決定」的預設降級。這不是無限次重新詢問使用者。
- 本輪 Cycle 可 `PARKED`，**Mission 仍未 COMPLETE**；可以產中期報告供 OWNER 查看。

## 10.3 OwnerDecisionPack 最小結構

```json
{
  "decision_type": "SBL.OwnerDecisionPack@candidate",
  "mission_ref": "<real_mission_id>",
  "subject_sha": "<exact_subject>",
  "policy_epoch": "<observed_epoch>",
  "decision_key": "<dedupe_from_subject_sha_and_question_key>",
  "first_fail": "<canonical_first_fail>",
  "recommended_option": "<one_reversible_or_noeffect_option>",
  "alternatives": ["<other_lawful_option>", "DEFER_AFFECTED_ONLY"],
  "required_authority": "<actual_domain_owner_and_host_grant>",
  "affected_work_ids": ["<ids>"],
  "evidence_refs": ["<readable_sha_bound_raw_ref>"],
  "stop_loss": "<bounded_budget>",
  "after_decision_resume_predicate": "<mechanically_checkable_condition>",
  "decision_state": "PROPOSED_NOT_GRANTED"
}
```

**低阻力原則**：已回答且 `subject_sha+question_key+schema_version` 未變者不得重複問；超出授權須真 HGK/Host Decision；現役 UX 沒有可點選決策介面時可退化為合法的通知／待審卡，但不能假設已具一鍵同意功能。

## 10.4 自進化最低驗收與不應當輪導入的能力

- **最低採納**：新增 1 個經獨立回歸的 Known Fix Pattern；下一輪同條件問題命中並可跳過重複研究，產生的修補仍受效力／版本准入。
- **嚴格版本**：在來源、Policy Epoch、Runtime Version、Capability Set 改變時，KnownFix 自動失效／縮小適用，而非硬套。
- **可追蹤改進**：新負例收錄、FirstFail 精準率、重複研究次數、人工決策率、修補返工、Effect 誤重試等實際指標改善。
- **本輪不引入**：Auto-Evolving Agent Swarm、全新模型路由平台、第二 FAR Database、背景常駐無權 Agent、由自身訓練／更新現役安全政策。

## 10.5 單人 OWNER 的 Standing Authorization 建議欄位

`mission_scope, approved_roots, read_scope, repo_write_set, effect_classes, permitted_principals, policy_epoch_binding, max_duration, max_cost, max_repair_iterations, process_restart_scope, allowed_network_dests, excluded_resources, compensation_plan, revoke_procedure, checker_requirements, release_boundary`。

實際 Standing Grant 的格式／Issuer 必須沿用現役 HGK/OS 授權機制；本文件欄位不是有效 Token。**每一張被授權的普通工程卡不重新詢問，前提是其 Scope/TTL/Principal 沒變**。超出既有決議的機密、真 User Data、Policy Promotion、遠端 Push/Merge/Release 或高保證簽署仍必須由適格權限核准，不能用文字「全部預先同意」取代平台操作權限。

---
# 11. 交付規格、可量測 KPI、風險與停損

## 11.1 交付目錄（最小充分，非新權威 Repository）

建議在經 W00 發現的合法 B1 evidence root 下，用新的 `run_id` 建立一次性的交付目錄；若已有等價結構，重用現有，不再另建一套報告系統。

```text
<APPROVED_B1_EVIDENCE_ROOT>/<ACTUAL_RUN_ID>/
  baseline/
    live_roots_heads_dirty.json       # 已遮罩敏感資訊，真觀測
    capabilities.tsv                 # 真 Mounted/Loaded/Invoked/Verified
    source-sha256.tsv                # 原始位置/來源 SHA／差異
  control/
    mission-profile.json             # DESIGN PROJECTION，不是 Permit
    workcard-crosswalk.tsv           # 27/31/120/124/38/949/1565 namespaces
    native-gate-status.json          # 從現役 Reducer 讀回，非自行簽 PASS
    first-fail-and-resume.jsonl      # 真 first fail、受影 cone、wakeup
  evidence/live/
    W02_hermes_executor/...          # Raw PID、Claim、Lease、readback
    W04_hgk_receiver/...             # Raw Admit/NACK、scope、revoke
    W06_fabric/...                   # RAW-STAGE/LOADED/CONSUMER 分立
    W07_models/...                   # required/served/method real invoke
    W08_pipd/...                     # raw schema/CI/ABI
    W10_plugins/...                  # 3 Portable Host UAT raw
    W12_repair/...                   # patch、red/green、checker
    W13_GA/...                       # 6 native identities
    W14_gwo_fabric/...
    W14_gwo_hgk/...
    W14_gwo_sbl/...
    W15_GB/...                       # revoke、新 PID、22-node successor
  evidence/frozen/<candidate_sha>/  # 冷凍一致快照，禁止改寫
  far/
    first-fail-registry.jsonl        # 由既有 registry 投影，不是新的 SSOT
    known-fix-reuse.jsonl
    owner-decision-packs/            # 必要時才產生
  tests/
    checkrun-results.tsv            # E01-E32 POS/NEG/SEC 真命令和 SHA
    summary.json                    # 非自簽 claim ceiling
  delivery/
    RELEASE_DECISION.md             # 由驗證身份與 Gate 決定
    REPAIR_SUMMARY.md               # 改動／範圍／未閉合／下個合法動作
    STATUS_MACHINE.json             # 機讀與相同真 WorkState 對帳
    DIFF_AND_ROLLBACK.md
    RAW_MANIFEST.sha256
    SEAL_EXTERNAL.txt               # 生效與否由有權者判定
    RESUME_MINIMUM_READSET.md        # 下輪 1 分鐘重新進入工作
```

此處的路徑皆為**建議交付布局**，不是現役 HGK API／路徑；未經發現不可直接部署在 `ProgramData` 或 Active Policy Root。真正私鑰、User Data、受保護 Checker Material 不複製到這個一般交付目錄。

## 11.2 KPI：先量測，不預設無根據的百分比

| 指標 | 算法／觀測方式 | 驗收下限與目標 |
|---|---|---|
| Autonomous Continuation Rate | 非人工新 Prompt 下、符合准入且跨進程完成的應續行卡／全部應續行卡 | G-B 路徑 **100%**，其他階段報告實際分母與比率 |
| False Global Block Count | 無依賴 A 的 B/C 因 A HOLD 停工次數 | **0**（E03/E31） |
| Premature Finalization Count | READY/RUNNING/UNKNOWN_EFFECT 或必要 Gate 未閉卻 COMPLETE | **0**（E05/E14） |
| Duplicate Native Effect Count | 相同 Operation Subject 的世界效果重複次數 | **0**（E06/E07） |
| Unauthorized Effect Count | L2 未合法准入仍發生真 Native Effect | **0**（E08/E13） |
| Actual Invoke Coverage | Required/Selected skill/method 中有真模型/工具 Invoke Raw 比例 | 每個被宣稱 Qualified 的目標 **100%**；未測者 NOT_RUN |
| Evidence Validity Rate | 有原始位元+SHA+同 Subject+真 Checker 的所需收據比例 | 正式宣稱的範圍 **100%**；不可用代理 Raw |
| Readiness/Dispatch Latency | READY T0 到合法 worker started T1 | 記錄 p50/p95；與 r9 原有可比基準比較，不發明固定秒數 |
| Duplicate Research Rate | 同 FindingIdentity 以相同版本重研而未先查 KnownFix 比率 | 應下降，並呈現原始基線 |
| OWNER Human Interruptions | 同一 QuestionKey／Grant 範圍內的重複人工詢問 | 同問題未變重問 **0**；新權限有權提醒不計異常 |
| Claim-Laundering Count | CLI/CI/Seal/Host 等局部結果被誤升上位 Gate | **0** |
| Affected-only Requalification Cost | 被變更影響的正式 Case 數／全部須驗 Case 數 | 不預定縮減比例；以 DAG 正確性與未刪 Required 為準 |

## 11.3 StopLoss／安全停止不等於永遠停工

**每張 WorkCard**：先用現役 Policy/ECP Budget；若無已定值，建議隔離工程修補最多 3 次有差異的 Red→Green 迭代、單次 Read-only Diagnosis 最多 3 次，超過只 PARK 受影卡並記真 FirstFail；這些數字是**候選預設**，不可覆蓋現役更嚴格規則。Native Effect 按各自 ECP 至多一次合法 Effect 嘗試／受管 Idempotency；未知效果先 Reconcile。

**停損情境**：未簽發 Permit、Policy 不匹配、原生 Receiver 未存在、Maker 可改 Checker、不可回復的 User Effect、來源 SHA 漂移、預測 WriteSet 越界、Native Effect 未知狀態、Raw/Hash 不一致。策略是 `PARK affected / freeze prestate / alert Owner if needed / run unrelated READY`，不是在報告中寫「已完成」。

## 11.4 Change／CR_OPEN 追蹤（不會自動變更法位）

| CR_OPEN | 必修或待裁決 | 阻斷範圍 | 下一合法動作 |
|---|---|---|---|
| `CR-HERMES-EXECUTOR` | 真 Hermes Worker／Wakeup Hook | R2/T2/G-B 真 Native | W02 現役探測、最小接線、跨 PID Raw |
| `CR-HGK-RECEIVER` | User Trust Profile→Receiver＋SoD | Issuer 相關 L2／G-A | W04 同 Subject ADMIT/NACK＋Principal 證據 |
| `CR-FABRIC-R3` | 現役 Stage→Loaded／Consumer | R3/GWO-FABRIC | W06 真讀回/必要最小修補 |
| `CR-MODEL-R4` | 三 Lane Required/Served | R4/G-A 受影模型 | W07 真模型 Invoke／Method Receipt |
| `CR-ORACLE-001` | DOC07/舊 P4 Writer | 受影 PIPD 編譯／Release | W08 Owner ABI 裁決，不默選 |
| `CR-PIPD-PROFILE` | 十二軸／九軸保守無損映射 | 受影 Profile／Safety Gate | W08 POS/NEG＋正式版本化批准 |
| `CR-PIPD-STAGE-C` | ADR-0008/0009 WriteSet | 該 CI／Publisher Gate | W08 現役 Base/HEAD 重演，精準歸屬 |
| `CR-DOC04-STATE-MAP` | SBL Stage T4/T5 Hold | 正式 Stage Transition | 在 Draft 工作之外向有權 Owner 查案 |
| `CR-COMMANDER-LEGACY` | 原 B1 禁令、DOC08 入口衝突 | 原 B1 Proposal／GWO-HGK | W09 非 Commander 合法 ABI 或正式裁決 |
| `CR-PORTABLE-HOST` | TPM/Commander/Challenge 實 Host Invoke | 四方 Portable claims | W10 分 Host 真 Load/Trigger/Nontrigger/Invoke |
| `CR-CHECKER` | Protected Principal/Signed Receipt | Native/High-Assurance Acceptance | W04/W05 安全隔離與真 Checker Reader |
| `CR-R10-RAW5` | 五個實體 Raw 未取回 | r10 證據可驗度 | W00 從有權 Windows Evidence Root 原位重算 |
| `CR-GA-3GWO-GB` | 六項合取、三 GWO、新程序 | B1 Final | W13～W15 真 E2E |
| `CR-GPT-WORK-HOST` | Future portable deployment 主機能力 | GPT Web／Work 的 Host Claim | 由實際 Web/Work Host 取得真 Receipt；不阻 B1 Native |
| `CR-SOURCE-RATIFICATION` | 規範原件/分發權/SourceFreeze 的正式授權 | 受影正式 PIPD/Portable Release | 有權 Source Owner 確認，不用本 SHA 表自證 |

---

# 12. 可複製的初始操作與自動派工方式（真接口以 W00 發現為準）

## 12.1 Windows PowerShell：唯讀 Preflight（可直接存為 `preflight.ps1`）

**用途**：給 Hermes／Codex 的第一輪 L0 探測。會在目前使用者的 `%TEMP%` 建立**診斷輸出**，不改任何原始 Repo／Policy。此腳本只驗證 Git Root/HEAD/Dirty 及已明示的候選路徑，**不是**真 HGK Native Readiness Script，不能因此 PASS R1～R4。

```powershell
# Compatible with Windows PowerShell 5.1+ and PowerShell 7 (verify on local Host).
# Read-only against candidate roots. Writes ONLY a report under $env:TEMP.
$ErrorActionPreference = 'Stop'
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$out = Join-Path $env:TEMP "fhs-b1-preflight-$stamp"
New-Item -ItemType Directory -Path $out -Force | Out-Null

$workspace = 'C:\Projects\Agent_Workspace'
$known = @(
  (Join-Path $workspace 'PIPD'),
  (Join-Path $workspace 'SBL'),
  (Join-Path $workspace 'HG-KSEOS'),
  (Join-Path $workspace 'Fabric')
)
# HG-KSEOS/Fabric paths are guesses for discovery only; DO NOT assume these are the live roots.
$results = @()
$gitCmd = Get-Command git -ErrorAction SilentlyContinue
foreach ($path in $known) {
  $exists = Test-Path -LiteralPath $path -PathType Container
  $item = [ordered]@{
    candidate_path = $path; exists = $exists; git_root = $null
    head = $null; dirty_count = $null; note = 'READ_ONLY_CANDIDATE'
  }
  if ($exists -and $gitCmd) {
    $gitRoot = & git -C $path rev-parse --show-toplevel 2>$null
    if ($LASTEXITCODE -eq 0 -and $gitRoot) {
      $item.git_root = ($gitRoot | Select-Object -First 1)
      $item.head = (& git -C $path rev-parse HEAD | Select-Object -First 1)
      $dirty = @(& git -C $path status --porcelain=v1 -uno)
      $item.dirty_count = @($dirty | Where-Object { $_ -and $_.Trim() }).Count
    } else { $item.note = 'EXISTS_NOT_GIT_OR_GIT_UNAVAILABLE' }
  } elseif ($exists) { $item.note = 'GIT_COMMAND_MISSING' }
  $results += [pscustomobject]$item
}
$results | ConvertTo-Json -Depth 5 | Set-Content -Encoding UTF8 (Join-Path $out 'candidate-roots.json')
$cli = Get-Command codex -ErrorAction SilentlyContinue
$codexVersion = if ($cli) { (& codex --version 2>&1 | Out-String).Trim() } else { 'MISSING' }
[pscustomobject]@{
  observed_at = (Get-Date).ToString('o')
  codex_version = $codexVersion
  codex_command = if ($cli) { $cli.Source } else { $null }
  report_path = $out
} | ConvertTo-Json | Set-Content -Encoding UTF8 (Join-Path $out 'cli.json')
Write-Output "PRECHECK_ONLY_NOT_NATIVE_PASS: $out"
```

**最重要的後續步驟**：依 `candidate-roots.json` 實際 Root 再定位 Hermes 的**真現役**安裝、HGK Receiver、SharedSpine、Fabric Activator、三 Lane、Checker；不能從 `HG-KSEOS` 路徑是否存在推論是否 Native Active。若需要探測受保護 Windows 配置，必須使用有權的唯讀 Principal，不能將疑似權限錯誤當程式壞掉。

## 12.2 Codex CLI Worker：限定 Worktree、出現真權限後才可執行

Codex 官方文件支援用 `codex exec` 以非互動方式執行受限任務，並明確區分 read-only 與 `workspace-write` Sandbox（參見附錄 Web Support）。以下**僅為命令外殼**，不是 HGK Issuer、也不是讓 Codex 任意開 L2 權限。

```powershell
# ONLY after WorkCard's RepoContext, scope, legal admission, and bounded Worktree are real.
$repoRoot = '<ACTUAL_ISOLATED_GIT_WORKTREE>'
$workCardPath = '<ACTUAL_FROZEN_WORKCARD_PATH>'
if (-not (Test-Path -LiteralPath $repoRoot -PathType Container)) { throw 'Missing verified repo worktree' }
if (-not (Test-Path -LiteralPath $workCardPath -PathType Leaf)) { throw 'Missing frozen authorized work card' }
# The host/Hermes worker must verify admission and WriteSet BEFORE this call.
$task = @"
Read the frozen work-card: $workCardPath
Perform ONLY its admitted Repository WriteSet; capture baseline RED first.
Apply the minimum bounded patch, run POS+NEG and local regression.
Do not modify protected Checker/Oracle/Permit/Policy. Never perform native Host Effect.
Write actual diff, command, exit and evidence path; report first_fail honestly.
"@
& codex exec --cd $repoRoot --sandbox workspace-write $task
# On exit, Hermes MUST reconcile real worktree diff/Raw/subject/permission.
# CLI exit=0 is NOT native acceptance; signed effect work follows HGK separately.
```

若現役 Codex CLI flags 與以上不同，先以 `codex exec --help` 真讀取並更新受影 Adapter；不可盲傳不存在的 flags。不要使用 `--yolo`、`danger-full-access`、跳過 execpolicy、或把長期 API Key 放進不受信任 Worktree／Log。Worker 必須在真 HGK／Hermes 操作記錄中有 PID/Operation 及結果。新版本的 CLI 特性**只能當 SUPPORT，不代替部署現況**。

## 12.3 Hermes/HGK 真啟動 Connector（動作綁定順序）

因目前附件**沒有**現役 Windows Hermes/HGK CLI 完整真 ABI，不能憑本文件虛構例如 `hgk mission run --native` 的正式命令。實施者應按下列順序完成一次性 Binding 表，然後由**現役**控制器執行：

| 動作 | 誰真正提供接口 | Binding 證據 | 缺件結果 |
|---|---|---|---|
| `READ_CURRENT_MISSION` | HGK Existing SharedSpine/WorkState | 可重播 read-only API/CLI、真 Mission Ref | W00 `MISSING` |
| `ADMIT_REPO_WORK` | 現役 PIPD/Repo Engineering Admission | Signed/valid action scope 或真核准流程 | 僅受影 Repo 卡 PARK |
| `ADMIT_NATIVE_EFFECT` | HGK Native Issuer／Receiver | 真 Permit/Token、same subject/Epoch、negatives | L2 禁止 |
| `DISPATCH_WORKER` | **Hermes** installed Executor | 真 Worker PID、Lease、Codex process、checkpoint | W02 失敗，先修 Hook |
| `FAR_RESEARCH` | Fabric Existing FAR Adapter | Event→Proposal/DecisionPack 的真 Raw | 原因未解，保留 PARK/Wake |
| `VERIFY_INDEPENDENT` | Protected Checker/AO | 各候選 SHA、無 Maker Write、Signed Receipt | 僅自測，不得正式 PASS |
| `READ_WORLD_STATE` | 各 Domain 現役 Owner/Host | 受控 Resource 的前後像／Epoch | `UNKNOWN_EFFECT` 不重試 |
| `PERSIST_RESUME` | 同一 SharedSpine | 新 PID 讀回 Cursor／Lease/WorkStatus | 不把 Prompt 當續航 |
| `NATIVE_CLOSE` | HGK Canonical Gate Reducer | Required/Conditional/GWO/G-B/AO 全真 | Mission PARK/HOLD |

**Definition of Integration Complete**：不只填出路徑，必須有 `DISCOVERED/LOADED/BOUND/INVOKED/RAW_VERIFIED` 的真結果與負例；`MISSING` 能自動生成有界診斷或 OwnerDecisionPack，不因訊息缺少就結案。

---

# 13. 可直接交給本地 HG-KSEOS／Hermes 的啟動薄指揮（本文件為完整工程規格）

以下是啟動用文字；設計目的在於「少 Context、高自動化、可持久接續」，不是要求 Hermes 在一輪模型訊息內完成整個 B1。**完整控制內容仍以本文件 §0～15、B1 r3 DOC00～08、現役 Source/Policy 為準；這段文字本身沒有簽發權限。**

```text
任務：啟動 FHS-MSC B1 Native Bootstrap & Four-Party Dogfood Mission。
唯一目的：利用 B1 Native 控制鏈的真實自修復和四方 Dogfood，完成合法的
自 PLAN／自實作／自檢測／自研究／自修補／自迭代／獨立驗收／自交付／有界自進化。

請讀取：
1) 本 MD 第 0、3、4、6、8、9、12、14 章；
2) B1 r3 DOC-00 §1~4 和 DOC-08 §§1~5；
3) 最新 B1 r10 Handoff 的 §0/2/5/7/8/10；
4) 當前 Windows 真 Root/HEAD/Policy Epoch/SharedSpine/Checker Readback。
採按需來源檢索；不要重灌歷史長 Prompt，也不要用舊 HEAD 當現在。

嚴格角色：HGK 唯一 Native Issuer/WorkState；Hermes 唯一 Durable Mission
Orchestrator；Codex CLI 是被派遣的受限 Worker；Fabric FAR 只研究／提案；
Portable TPM v0.2.0rc1、Commander Guide、External Challenge 只作四方測試掛載；
Protected Checker 和正式 Domain Owner 才能產生合法 Acceptance。

本次即刻執行 W00；依真能力並行 W01/W02/W03/W04、其他合法 READY；
維持既有 SharedSpine，禁止第二 Queue/Issuer/Compiler/Checker。
先分 L0 OBS／L1 REPO／L2 NATIVE Effect；不可為了修 Issuer 要求
尚未產生的 Native Effect Receipt。缺真權限時，只 PARK 受影卡，
可修的隔離工程繼續；需要新授權只提一次具名 OwnerDecisionPack。

逐 W00~W17 依本 MD 的合法依賴執行；產 POS、NEG、Raw、真 Exit、前後
世界狀態、FirstFail、受影 Cone、Resume Predicate。發生問題先查
KnownFix，必要才 FAR Read-only Research；修補須新 Candidate SHA，
Checker 分隔權限重驗；無真 Checker 時保持 Self-tested/Advisory。

Runtime 規則：READY>0 必繼續合法派工；RUNNING/UNKNOWN_EFFECT 先
Reconcile；NO_ELIGIBLE_READY 必研究 Blocked/決策或 Durable PARK。
任何 Session End、Report、CI PASS、Manifest、Seal 均不得直接 Mission Close。
採真跨程序續工；本輪若只能 PARK，保存真喚醒條件與下一合法動作。

原 B1 Commander-SP 禁令不變；新版 Commander Guide 只在新隔離
Four-Party Subject 測試，原 B1 `plan.propose` 需找到合法非 Commander
實際入口或正式批准替代。

Native 正式目標不縮水：T2、R1~R4、G-A 六項、三 GWO、G-B 外援
Revoke 後新 OS Process 自主 successor、22-node ACK、獨立 Checker；
各域不同 Raw；Required+已觸發 Conditional 全按原生效規範。
自進化只沉澱經驗／測試／候選，不允許自授權改 Canonical。

輸出唯一 Mission Ledger / checkpoint，最後做分層 Claim；若缺實機
Permit／Checker／Host，坦承 FAIL-CLOSED，不可偽造。
已授權工程卡不反覆請示單人 OWNER；超出 Scope、Policy、Release
或不可逆效果依真平台權限處理。立即從 W00 的真能力發現開始。
```

**如何使用**：把完整 MD 放在 Hermes／HGK 可讀取且有授權的本地文檔路徑，以上薄指揮再引用那個**真路徑**。必須確認真 Worker 可讀取檔案；不可把本回合 `sandbox:/...` 路徑當 Windows 現成路徑。該指揮不是一次性聊天持續的替代；真正跨程序續工須在現有 Runtime 程式中實作。

---

# 14. 正式 Gate Checksheet／退出狀態與本輪可宣稱結果

## 14.1 完成層級（不創造新的 Native Status Enum）

| 結果 | 合法說法 | 正式 Gate |
|---|---|---|
| Baseline 盤點 | `BASELINE_OBSERVED` | 無 Native acceptance |
| 有界 Repo Red→Green | `ENGINEERING_SELF_TEST_PASS` | 不等 Native |
| 真 Hermes 最小 Queue/Executor | `MINIMAL_NATIVE_LOOP_PROVEN`（只有真 Raw） | 不等完整 G-A |
| Portable 3 SP Codex Host Invoke | `FOUR_PARTY_CODEX_HOST_TESTED` | 不等 GPT/Work 或 G-B |
| B1 R1～R4／T2 原生 Raw | `NATIVE_GATES_OBSERVED` | 需現役有權 Reducer/Checker 判定 |
| G-A 六合取 | `GA_NATIVE_QUALIFIED` | 只在真原合取通過後 |
| 三 GWO | `THREE_GWO_VERIFIED` | 不等 G-B |
| 外援撤銷新 Process 真續工 | `GB_NATIVE_SUCCESSOR_VERIFIED` | 不等所有產品 Release |
| 完整 B1適用義務與獨立驗收 | `B1_NATIVE_ACCEPTED`（由有權者真簽） | 不等 SBL Full Product、GPT Web/Work |
| 產品及 Host 正式發布 | `RELEASED` 需真正 Publisher/Host | 不得自行提升 |

## 14.2 交付前 24 項檢核

- [ ] 當前 Repo/Loaded/Issuer/Policy/Worker/Checker 真身份已現場核對
- [ ] SHA 差異與缺原件未被本 MD 清單掩蓋
- [ ] Original B1 `task_kind=DESIGN` 沒被升格為 Native Permit
- [ ] 27/31/120/124/38/949/1565 保留分母、未混名命空間
- [ ] 原 B1 Commander-SP 禁令及隔離四方測試 Subject 成立
- [ ] W00～W17 真成果、受影 PARK／下一合法動作逐張具名
- [ ] L0/L1/L2 真 Admission 邊界與無效簽章拒收成立
- [ ] Hermes 真 Executor／Worker PID、Lease、Cross-Process Wake 可重播
- [ ] A PARK，獨立 B/C Ready 仍執行
- [ ] Report/Manifest/Seal 產生時 READY 不被改成 COMPLETE
- [ ] UNKNOWN_EFFECT 先世界讀回，不盲 Native retry
- [ ] User Trust Profile→Receiver 真接線，SoD 保證等級不偽稱
- [ ] Fabric Stage/Active/Loaded/Consumer Raw 不混用
- [ ] 三 Lane required/served、Mandatory Method Real Invoke 記錄存在
- [ ] PIPD Oracle/Profile/Stage-C 的精確修補及 NEG 沒被弱化
- [ ] TPM／Commander／Challenge 的真 Host Invoke/Nontrigger 不冒稱 GPT Work
- [ ] 各方 Handoff 同 Subject/Source/ABI、Maker 不越權
- [ ] FAR 自研究/KnownFix 重用有版本與真證據
- [ ] 有界補丁、Red→Green、Rollback、Affected-only 重新驗收可重播
- [ ] Checker 的 OS Principal／Oracle/Key 隔離及真 Receipt 已證實
- [ ] G-A 六項原合取 Raw 完整
- [ ] GWO-FABRIC/HGK/SBL 三組 RAW/Operation/Checker 完全獨立
- [ ] G-B 外援 Revoke、不同 OS Process Native successor、舊 Token NACK、22-node ACK
- [ ] 只有適用全量 Gate 真通過且有權批准後才正式 Mission Accepted/Released

## 14.3 本文件交付時的真正 Release Decision

```json
{
  "schema": "FHS.B1.Dogfood.PlanDelivery@1",
  "plan_created_at": "2026-10-28",
  "design_decision": "RECOMMEND_SELF_BOOTSTRAP_AND_DOGFOOD",
  "execution_plan_available": true,
  "actual_windows_native_execution_in_this_turn": "NOT_RUN",
  "current_hermes_binary_and_hgk_receiver_reverified": false,
  "b1_native_gate_qualified_in_this_turn": false,
  "four_party_live_host_qualified_in_this_turn": false,
  "independent_checker_receipt": null,
  "formal_source_ratification": "UNVERIFIED",
  "release": "FAIL_CLOSED",
  "first_execution_step": "W00_ACTUAL_HOST_CAPABILITY_DISCOVERY",
  "next_legal_action": "Install/read this execution plan in approved local work area; run W00 using actual Host, then follow W00-W17 with effect-class-specific admission"
}
```

本文件已完整規劃，但**未在此對話實際控制你的 Windows 主機、啟動 Hermes/HGK、修改 Repo、派發真 WorkOrder 或簽出 Native Checker**。正式執行狀態以本地原始收據為準；若將來提交新證據，應用同一 Source/Subject/Policy 版本做差異評估，而非在下一輪重寫本 Mission。

---

# 15. 外部實務參照（SUPPORT，不具本專案權威）

| SUPPORT | 已確認的外部實務內容 | 本計畫的合法採用範圍 |
|---|---|---|
| [OpenAI Codex Non-interactive mode](https://learn.chatgpt.com/docs/non-interactive-mode) | `codex exec` 可用於腳本化、沙箱工作；官方強調權限分級與憑證安全 | 作 Hermes 下層受限 Worker，不取代 HGK 授權 |
| [OpenAI Codex CLI Options](https://learn.chatgpt.com/docs/cli/reference) | CLI／app-server／exec 的旗標及產品能力有版本差異 | 先 `--help` 讀取、真 Host ABI 再呼叫 |
| [OpenAI Skills](https://learn.chatgpt.com/docs/build-skills) | Skill 漸進載入與顯式／隱式呼叫、測試觸發 | 按 Host 做 Trigger／Nontrigger／Invoke，不以 Loaded 自動合格 |
| [GitHub Actions Security Hardening](https://docs.github.com/en/actions/security-for-github-actions/security-guides/security-hardening-for-github-actions) | 工作流最小權限、Secrets／供應鏈保護 | Repo/CI 修補的參照；不能用 CI 替代 Native Effect |
| [Microsoft Scheduled Tasks](https://learn.microsoft.com/en-us/powershell/module/scheduledtasks/) | Windows 提供現成排程／喚醒 API | 若 Hermes 已有合法 Watcher，僅重用；OS Task 不是第二權威 Queue |
| [Temporal Workflows](https://docs.temporal.io/) | Durable Workflow 的設計思想 | B1 借用觀念，不在本輪引入第二持久任務系統 |

**網路 SUPPORT 使用限制**：本地 B1 現役接口／權限／Host 不由公共文件證實。對官方產品的規格、工具版本、Flag、相容性及發布權限，執行前必須以當前環境再核對；上表不是正式安全認證，也不替代 B1 r3 Source Authority。

# 16. 唯一正式工程裁決

**本次完整方案採納：`FHS-MSC B1 SELF-BOOTSTRAP + FOUR-PARTY DOGFOOD E2E`。**

工程上的有效最短路徑是：

`W00 現役唯讀發現 → W01 薄投影 → W02/W03 Hermes 自治/Terminal/FAR → W04 HGK Receiver → W05 真最小 Native Effect → W06/W07 Fabric/Model → W08/W09 PIPD/SBL ABI → W10/W11 三 Portable SP 測試與 Shadow Handoff → W12 四方真修補迴圈 → W13 G-A → W14 三 GWO → W15 G-B → W16 KnownFix 自進化（全程並行沉澱） → W17 真原生驗收與交付`。

這是一條**從修復工廠到工廠修復自身的漸進路徑**，而不是要求故障中的工廠預先具備正式完工證書。最少安全不變量必須保持：唯一 HGK Issuer／Hermes Durable Authority／PIPD Writer，效果分權、限定 WriteSet、At-most-once、World Readback、獨立 Checker、受影 PARK 與分層 Claim Ceiling。

**批准施工設計 ≠ 批准任意 Host Effect**；**Hermes 管理所有工程 ≠ Hermes 自行編碼或簽 Permit**；**Codex CLI 是 Worker ≠ Codex 控制 Mission**；**FAR 自進化 ≠ FAR 自行改安全規範**；**Dogfood 成功 ≠ 全部 GPT Host/SBL Full Product Release**。

本輪文件的最終裁決：

`PLAN_COMPLETE / HISTORICAL_R10_PARTIAL / NATIVE_REVERIFICATION_REQUIRED / START_W00 / AUTOEXECUTION_DESIGN_READY / PRODUCTION_RELEASE_FAIL_CLOSED`。
