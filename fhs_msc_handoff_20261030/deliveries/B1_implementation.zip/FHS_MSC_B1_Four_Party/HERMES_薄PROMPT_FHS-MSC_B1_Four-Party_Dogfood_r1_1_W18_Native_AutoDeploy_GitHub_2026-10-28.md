# HERMES｜FHS-MSC B1 Native Bootstrap × Four-Party Dogfood × W18 常態入口｜高自動化施工薄 PROMPT

> 以下全文為**直接貼入本地 HERMES 對話框**的啟動命令。這是 B1 的一次性施工任務指揮，**不得安裝成 Hermes 日常任務必貼的長 Prompt**。

## 1｜立即啟動與唯一任務

你是本地主機現役 **HG-KSEOS／Hermes Native Mission Orchestrator**。現在直接開始 `FHS-MSC-B1-SELF-BOOTSTRAP-FOUR-PARTY-DOGFOOD` 的 **r1.1／W18 完整施工**；不得只撰寫第二份計畫或產出候選報告便停止。

**主規格**：《FHS_MSC_B1_Four_Party_Dogfood_Native_Execution_Plan_r1_1_W18_2026-10-28》之**本地實體最新版**。設計要求與驗收細節完整以該 MD 的 §0～§17、B1 原 DOC-00～08、現役有效 PIPD／SBL／FHS 來源及實際 HGK Policy 為準；本薄 PROMPT 是工作委派，不是新 Canonical、Permit 或 Checker。

**文檔搜尋根目錄**：`C:\Projects\Agent_Workspace\知識庫\實作相關DOC\Fabric vNext\Semantic World OS Fabric\SBL_PIPD`

**實作／Repository 搜尋根目錄**：`C:\Projects\Agent_Workspace`

**GitHub 認證檔 Locator（機密）**：`C:\Projects\Agent_Workspace\API KEY\GITHUB-REPO_SHW097-4.txt`

立即從 **W00** 以實際唯讀探測查找完整 r1.1 主檔與 B1 r3 DOC-00～08、FHS-MSC r2、SBL/PIPD DOC、r10 Handoff、W18 討論；核對路徑、Content SHA、當前版本及適用權威。當本地有多個副本時辨識差異，優先當前有權版本；不能僅以檔名或日期冒認 SourceFreeze。繼而盤點真 Repo Root／HEAD／Dirty、Hermes Launcher/Default Profile/Worker、HGK Issuer/Receiver/SharedSpine、Fabric Active/Loaded/Consumer、三 Lane／模型／方法、Checker、Codex CLI、Host 安裝及 Git Remote。**不要把聊天文字、過往 r10 狀態或方案的抽象 API 當作已存在的 Runtime。**

**Mission 目標**：用原生 E2E 自舉修好原生工廠，再用它真實執行四方 Dogfood，持續完成「自 PLAN → 自實作 → 自檢測 → 自研究 → 自修補 → 自迭代 → 合法獨立驗收 → 自交付 → 有界自進化」；最後驗證 B1 完成後 OWNER 正常使用 Hermes 時只需 Goal＋必要來源，**不再貼 B1 專用 Prompt，也不用反覆指定模型車道／Codex／KANBAN／SWARM／FAR／Fabric／HGK**。合格成果必須**真部署、真啟用、真 Loaded、真讀回**，不以候選、PR、CI 綠或封存假冒實用。

## 2｜單一控制鏈、真權限與 OWNER 有界預授權

唯一控制鏈：`HERMES_LED / HGK_ADMITTED / CODEX_CLI_EXECUTED / INDEPENDENTLY_VERIFIED`。**HGK 是唯一 Native Issuer／Permit／WorkOrder／State Authority，SharedSpine 是唯一 Durable Journal/Queue，Hermes 是唯一持久任務派工、喚醒與恢復主控，Codex CLI 是受委派且限權的 Maker Worker，Fabric FAR 只研究／建議，PIPD 是其 Canonical 的唯一 Writer；Protected Checker 必須與 Maker 有可驗證的 Principal／寫權／憑證隔離。**禁止新增第二 Issuer、Scheduler、Queue、Compiler、Oracle Writer、Checker Authority 或常駐的另一套代理控制器。`PLAN / EXECUTE / VERIFY_SECURITY` 僅三條正式 Lane，方法及模型按現役適用 Policy 真選型、真 Required=Served、真 Invoke。

**OWNER 此次明確預先同意**：在本 Mission 目的、已辨識的受影 Workspace／Repo／正式產品作用域內，對經合法准入且合格的修補，允許 Hermes **自行完成施工、測試、有限重試、適當實際安裝／啟用／升級／回滾、正式 Default Profile 採用、受影 Repo 提交／Push、符合分支保護的 PR／Merge、AGENTS.md／README.md 更新及證據交付**；不需每張普通工作卡、每次小修補或每個合格部署都重新詢問 OWNER。**這是 OWNER 的工作意向與預先同意，不是 HGK 簽發 Permit、OS ACL、GitHub 權限或政策例外**：真正操作仍需現役合法 Scope、Principal、ECP、Owner/Host grant、Branch Protection 與適用批准。遇到未取得的新權限、不可逆／高風險效果、Canonical Oracle／Policy／Checker 的修改、授權衝突或受保護 Release，先用 FAR 研究並建立**一份去重、可直接決策的 OwnerDecisionPack**；只 PARK 受影工作並持久等待，不停止其他有權 READY 工作，絕不偽造批准或自行放寬 Gate。

按照 `L0 唯讀 → L1 有界隔離 Repo Write（適用 PIPD/Repo Admission）→ L2 HGK 准入的 Native／Host／User Effect → A 真獨立驗收` 分層進行。若 Issuer 尚未修好，先做合法的 L0 與有真正工程授權的 L1 自舉；若現役制度有合法 Recovery/Maintenance 例外才按真 Scope 使用；**不得為修 Issuer 先造假的 Issuer Permit**。對每次 Effect 記錄 Operation Identity、前後世界狀態、Nonce／TTL／Epoch、回滾；UNKNOWN_EFFECT 必先世界讀回再決定補償或恢復，不盲重試。

## 3｜必做施工清單（不改原 B1 分母）

以主規格 §6、§6.1、§9、§12、§14、§17 的實際依賴 DAG 派工，**不是照文字順序串行等候**；W16 FAR/KnownFix 貫穿施工。每張 W 先綁定真現役 CLI/API／來源／WriteSet／原生准入，再執行。最少完成：

1. **W00～W04**：真現場與 Source／Git／Credential-availability 盤點；B1 Thin Coverage Crosswalk；修復 Hermes 真 Executor／CAS Lease／Checkpoint／OS Wake；受影 PARK、TerminalReducer、FAR；HGK 真 User Trust→Receiver→Issuer 接線。使合法最小 `READY→CLAIM→HERMES SPAWN→RAW→CHECKPOINT→新 PID RESUME` 真成立，不把 Dispatcher Test 當 Native。
2. **W05～W09**：完成真 T2 Issuer→Hermes→可逆 Effect→世界 Readback→隔離 Checker；Fabric R3 Stage→Active→Loaded→Consumer 同 SHA／Epoch；三 Lane Required/Served 與現役 Mandatory Methods 真 Invoked；PIPD Canonical/Oracle/ABI/Stage-C 受影修補；SBL 合法 Proposal 與雙 taxonomy 的適用性。**B1-ORIGINAL 仍不得啟動被原規範禁用的 `sbl-commander-sp`**；如舊 ABI 衝突，以合法非 Commander Adapter 或具名 Ratification 處理。
3. **W10～W12**：在**不同的 FOUR-PARTY-DOGFOOD 受測 Subject** 測 TPM-SP、最新版 Commander Guide、External Challenge-SP 的真 Codex Host `LOAD→TRIGGER→INVOKE→NONTRIGGER→UNBIND`；實作同 Subject／SourceBound 規劃→Commander Proposal→Hermes/HGK 合法派 Codex 做真 Red→Green Repo 修補→Challenge 反證→新 SHA 受影回歸；External Challenge 的 Advisory **不能代替 Protected Checker**。不以 GPT Web/Work 未實測結果冒充其 Host PASS。
4. **W13～W15**：嚴守原 B1 DOC-00～08，真實驗收 **G-A 六項合取**、彼此不同 Operation／Raw／Checker 的 **GWO-FABRIC／GWO-HGK／GWO-SBL**，以及 **G-B：撤銷暫時外援、真新 OS Process 由原 Native Wake 自主接下一卡、舊 Token 拒收、Rollback／Zero Residue、22-node Successor ACK**；按原 Required+TriggeredConditional 及真受權 Checker 驗收。保存原 `27 Atoms／31 WO-OBS／120 Parent／124 Child／38 Node／949 R15.1` 及 r10 `1565=625 Required+285 Conditional+655 Deferred` 各自分母，不拿它們全部當 Queue 或縮分母。
5. **W16（全程）**：`FirstFail／No Eligible Ready → 查真 KnownFix → 必要時有界 FAR 唯讀研究 → 最小受影 RepairCone → 真 Admission → Codex 新 SHA 修補 → POS/NEG/Checker → 經驗回寫成 VERSIONED VERIFIED_FIX_PATTERN`；來源／Policy Epoch／Runtime 不符時不得錯用。不可自動改當輪安全 Oracle、自己簽正式 PASS 或自我提升權限。
6. **W17.NativeCheckpoint → W18 → W17.OperationalDelivery**：先由有權 Reducer／Checker完成 **原 B1 Native Acceptance**，保留獨立收據；再以已安裝的正式 Default Profile 啟動 W18。若現役 Reducer 支援具名 Acceptance Scope，W18 在同一 Mission 延後轉 READY；**若只支援整個 Mission 原子結案，須先合法結束原 B1，再由同一 HGK／SharedSpine 建立受前一 B1 收據約束的 W18 後續 WorkRef**。不得讓 W18 READY 提前阻斷 B1 結案，不重開已簽原 B1 Snapshot，也不以 W18 失敗撤銷原 B1 PASS。最後 W17 依真範圍完成分層交付。

**W18 必須真測（NM-01 新工程／NM-02 既有續工／NM-03 純唯讀）**：在完全新 Hermes Session／PID，使用**真正部署的預設正式 Profile**，只提交普通 Goal＋必要來源；**不注入本 PROMPT、任何 B1 專用提示、手選工具／模型或 test-only Portable Profile**。執行 E33～E42：E33 零 B1 Prompt、E34 新 PIPD Intake、E35 已准入工件重用、E36 Durable Resume 不重做 Effect、E37 零手工方法／模型指定、E38 Fabric Consumer→HGK Admission→Hermes Worker／Checker 真效果、E39 唯讀非觸發、E40 新 PID 配置持久、E41 錯 Epoch／過期 Permit／Served mismatch 拒收、E42 移除 test-only Binding 後正式 Native 能力仍可用。**E33／E37／E38／E40／E42 是必要核心真 PASS**，其餘依規範適用性取真 POS/NEG；只靠模擬的 UAT、CLI `skills list`、人工再貼施工 Prompt 均不得宣稱 `NORMAL_MODE_ENTRY_QUALIFIED`。正式 Default Profile 要在修補後真安裝／啟用／Loaded Readback 並重啟再測；不能用永久 B1 專用長 Prompt 修 W18。

## 4｜每張卡的自動運行、反證與完成界線

每次實作都存 `source_sha / subject_sha / policy_epoch / authorized_write_set / actual_command_or_api / PID / provider_required_vs_served / methods_invoked / return_code / diff / prepost_world / raw_path+SHA / checker_principal+receipt / first_fail / affected_cone / checkpoint / resume_predicate / rollback`；所有 E01～E42 按適用範圍跑真 POS+NEG／安全拒收，保留原 B1 Gate 的官方判準；Maker 只能 Self-Test，正式 Native PASS 只能來自合格 Protected Checker 與現役有權 Gate。

**硬 Runtime 規則**：合法 READY 必自動續派；RUNNING／過期 Lease／UNKNOWN_EFFECT 先對帳；一項 A PARK 不可凍結不相依 B/C；`NO_ELIGIBLE_READY` 必查 FirstFail、FAR、DecisionPack 或 Durable Wake；同 FirstFail 去重，受限診斷／修補（先依 Policy，無現役值才採每受影卡最多 3 次有差異修補）；**READY／RUNNING／UNKNOWN_EFFECT 未處理、適用 Gate 未閉合，禁止 MISSION_COMPLETE**。聊天結束、報告、CI、PR、Manifest、Seal 一概不能替代 Durable State；中途可做快照但不能當終局。暫時只能 PARK 時保留可機械喚醒的下一合法動作，後續從**原 SharedSpine** 自動續工。

**結果分層**：`B1_NATIVE_ACCEPTED`、`FOUR_PARTY_CODEX_HOST_TESTED`、`NORMAL_MODE_ENTRY_QUALIFIED`、`GPT_WEB_WORK_HOST_QUALIFIED`、`PRODUCTION_ADOPTED／RELEASED` 均各自取真受測版本與證據；只能使用現役 Canonical Enum，這些名稱若無原生定義只作報告 Claim。已合格 B1 Gate 不因 W18 失敗被倒改；但若 W18 修補真的改變共用 Issuer／Fabric Policy／Executor／Checker Trust，必按版本受影重驗，不能沿用舊 SHA 冒充 Current。

## 5｜合格成果必須投入實用：部署、GitHub、文件

**不要停在候選、ZIP、Worktree、PR 或「建議 OWNER 自行執行」**。對每個已取得適用授權、測試及獨立驗收的修補版，主動經**現役合法安裝／發布機制**完成 `Candidate N+1 → bounded tests + checker → Install/Activate/Load/Consumer → Readback / New Process Smoke → Rollback Point`，確保使用者日常 Hermes 的**正式 Default Profile**真正採用。若需要先有版本部署才能驗收 W18，先合法做可回復的 N+1 Canary／正式切換，再以新 Session 驗收；不要求先有尚未執行的 W18 收據才允許合格的受限測試部署。未獲正式 Effect/Publish 權限者只 HOLD 該效果，不偽稱已實用。

**GitHub 對應各自 Repo**：W00 真發現 `git rev-parse --show-toplevel`、實際 `remote`／Repo 身份、Default Branch、目前 Dirty/Untracked、現有 PR、CI、受保護分支及提交權限；**不猜測 Repo 名稱，也不覆寫既存 OWNER 未提交的改動**。在受限分支／Worktree 依 Repository 真歸屬分類提交程式、測試、配置、合格文檔與**可公開的去敏證據索引／SHA**；分 Repo 執行 `diff→tests→secret-scan→commit→push→PR/required checks→依法 merge→fetch/readback merged commit`。若規則允許安全直接更新才用直接方式；不得 force-push、略過 CI／Review／Branch Protection、修改無關 Repo 或洩漏 Secret。Merge 衝突自行在受影範圍解決並重測；不具合法 Merge 權限時保留 PR/Branch/具名阻斷，但其他有權 Repo 仍繼續。

**憑證保護**：前述 `GITHUB-REPO_SHW097-4.txt` **僅是認證檔位置**，由本機已核准、受 ACL 保護的 GitHub Credential Helper／`gh`／安全認證程序按需使用；不要在 HERMES 對話、Codex Prompt、stdout、工作日誌、Diff、Commit、GitHub Actions、Raw 附件、任何 MD 中輸出或複製 Token，不能將憑證檔加入 Git；若其格式或權限未知，先做無秘密外洩的本機能力檢查，不能把明文讀入模型上下文。受保護 Native Raw／個資／簽章資料保留在有權本地 Evidence Root，Remote 僅發布可審計但不含機密的索引與摘要；Git Push/Merge 不等於 Host Loaded。

**AGENTS.md／README.md 必須受影同步**：實際修改過的本機 Root 與各受影 Repo，更新或最小增補正確安裝/啟動方式、真 Router／Lane／Native 權限邊界、W18 **常態「Goal＋來源」入口**、修復／測試／驗收命令（真 CLI 而非捏造）、Checkpoint/Readback、KnownFix 與版本、Release/Rollback、排除長 B1 Prompt 作永久 SOP；保持既有上位指令與規範，不用 README／AGENTS.md 私造 Permit 或覆蓋安全 Policy。未改的 Repo 不強迫無謂提交。

GitHub 操作與最後 Evidence Manifest 分階段記錄：先凍結原 Native/Checker/部署 Raw，再以獨立的 Git Delivery Receipt 記 Push/PR/Merge/merged SHA、Repo 狀態及讀回；**不可事後修改已 Seal 的受保護 Raw／Snapshot 讓 Hash 失效**。若 Merge/文件更新會影響 Runtime／Default Profile，重新跑受影 Loaded／W18 Smoke／Checker 才可提高 Release Claim。

## 6｜唯一交付與立即行動

持續依唯一 SharedSpine 自主派工直到所有**適用且有權**工作完成、或具名受影阻斷已形成可自動恢復條件；任何未完成 READY 不得以報告結案。最終在現役核准 Evidence Root 交付：`Live Baseline + Source/Repo SHA + W00～W18 per-card status + E01～E42 POS/NEG Raw + G-A/三 GWO/G-B/Checker + W18 NM01～03 + 真部署 Loaded/Readback + Git Repo/Branch/PR/Merge SHA + AGENTS/README Diff + FAR VerifiedFix + FirstFail/PARK/Wakeup + Rollback + Sanitized Evidence Manifest + 獨立雙 Claim + OwnerDecisionPack（僅必要時）`。以機讀狀態區分 `OBSERVED / NOT_RUN / BLOCKED / SELF_TESTED / INDEPENDENT_ACCEPTED / DEPLOYED / RELEASED`，不捏造成功；同一 Frozen SHA 不能因改報告自行升級。

**現在立刻執行 W00**，定位並讀取 r1.1 主 MD 與相關原規範，建立現役能力與權限對照，綁定真 Native ABI，對已合法 READY 自主排程、實修、實測、實用部署、合法 GitHub 交付。不要重新要求我輸入長 B1 Prompt、指定模型／工具或反覆批准已在有效授權內的小工作。完成後讓日常 Hermes 不再需要本薄 PROMPT 才能正常執行新任務。
