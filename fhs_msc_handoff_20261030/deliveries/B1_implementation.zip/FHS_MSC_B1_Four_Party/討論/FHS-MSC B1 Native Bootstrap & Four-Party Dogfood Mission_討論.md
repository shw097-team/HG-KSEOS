# 《FHS-MSC_藍圖_r2》與 B1 高自動化失效案例

**User:** Anonymous  
**Created:** 10/27/2026 20:46:54  
**Updated:** 10/28/2026 1:14:49  
**Exported:** 10/28/2026 1:25:18  
**Link:** [https://chatgpt.com/g/g-p-6acaeba0c56881919497d31c47756043-sbl-fhs-msc/c/6ae09d3d-a5ac-83ee-8beb-17a1eab8d1fc](https://chatgpt.com/g/g-p-6acaeba0c56881919497d31c47756043-sbl-fhs-msc/c/6ae09d3d-a5ac-83ee-8beb-17a1eab8d1fc)  

## Prompt:
2026/10/27 下午2:21:00

你的角色：
你是「HERMES / FABRIC / SBL / HG-KSEOS」高自動化任務運行總工程師。

任務目標：
你必須對「《B1指揮施工_總紀錄》、《B1施工_PROMPT》、《B1施工狀況_總鑑定分析》、《FHS_MSC_B1_Task_Handoff_Report_v1_2026-10-27》」，進行專業工程的「深度研究 + 交叉比對 + 分析評估 + 工程因果關係重建」，並且以「FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_00 ~ 08」為上位設計藍圖 & 施工執行控制包，最後你必須對「FHS-MSC_B1_Bootstrap_Repair」無法順利進行高自動化的全部根因，包含可能的治理過重、鏈路問題、高自動化阻斷....等等的全部問題，提出完整分析評估報告。

任務要求：
最後你必須直接以文字提出完整報告。

## Response:
2026/10/27 下午2:21:10 · gpt-6-thinking

我會以 B1 DOC-00～08 的現行 r3 控制包為準，先重建 r1～r10 的施工時間線，再把四份核心紀錄中的「實際執行、回報成功、設計裁決、未驗證」分開，逐項追查阻斷因果。最後直接提交完整工程鑑定報告，並區分治理必要性、治理過載、執行鏈路缺陷與最短修復路徑。

目前已確認兩項需要特別區分的事實：r10 確有 PIPD CE-2 與 HGK User Trust 的局部實作成果；但 Fabric R3、三模型車道 R4 和 Hermes 真 Executor 在 r10 是 **未執行**，不能寫成「測試失敗」或「系統已證實損壞」。另外，B1 DOC-08 指定的 Commander 提案入口與後續明確禁用 Commander-SP 的指令存在契約衝突，這是獨立於 Hermes 的執行入口問題。

已額外核對 GitHub 的即時 PR 與 CI 紀錄：HG-KSEOS \#2、Fabric \#18、SBL \#13、PIPD \#20 目前仍是未合併的 Draft PR。PIPD \#20 的 `offline-gate` 成功，但 `public-plugin-verify` 確實在 Stage-C WriteSet 檢查失敗，日誌明確列出 ADR-0008 與 ADR-0009。這證實「局部 CI 綠燈不等於完整發布資格」，也排除了將該失敗簡化成日誌上傳警告的解釋。

> **檢視四份核心文件結構**
>
>
> **檢視核心文件結構並列出大小標題**
>
> 
>
> **搜尋 B1 高自動化停工根因**
>
> 
>
> **讀取交接與治理文件關鍵段落**
>
>
> **審閱交接報告關鍵段落**
>
>
> **讀取並審閱交接與治理文件關鍵段落**
>
> 
>
> **擷取R10分析與指令紀錄**
>
>
> **擷取施工提示章節標題**
>
>
> **檢視報告來源與計數限制**
>
>
> **檢查指定行號內容完整性**
>
>
> **檢視報告風險與修正段落**
>
>
> **整理數據脈絡**
>
> 我正在核對總數與各來源的差異，並區分已確認紀錄、重複轉述、推論與未驗證內容。接著我會建立因果鏈與證據矩陣，說明流程如何停滯，以及哪些部分仍缺乏獨立驗證。
>
> **整理了數據脈絡**
>
> 
>
> **擷取R10報告內容並檢視來源風險與修正段落**
>
> 
>
> **已搜尋 1 個網站**
>
> 
>
> **選取精確工具名稱**
>
>
> **選取精確工具名稱**
>
> 
>
> **讀取並驗證 GitHub PR 與 Actions 工作流程資訊**
>
> 
>
> **完善報告結構**
>
> 我正在避免再加入不必要的圖表，改以純文字呈現完整結果。接下來會補齊階段性指標、測試與驗收條件，並清楚區分使用者權限、作業系統權限，以及已驗證和待核實的內容。
>
> **完善報告結構**
>
> 
>
> 處理時間為 9m 59s

# FHS-MSC B1 Bootstrap Repair 高自動化失效--完整工程根因鑑定與治理收斂評估報告

鑑定基準：2026 年 10 月 27 日｜工程性質：跨系統架構審查、執行鏈路鑑定、失效因果重建、治理成本評估與修復策略裁決

## 一、總體工程鑑定結論

**FHS-MSC B1 無法順利進行高自動化施工，並不是單一 Hermes 故障、單一 PIPD 編譯錯誤，也不是單純 OWNER 授權不足。**

根據四份核心紀錄與 B1 DOC-00～08 上位控制包的交叉比對，主要問題是以下多層缺陷相互放大：

1. **自治執行閉環不完整**：Hermes 已有執行、派工及局部修補能力，但缺乏經正式證實的「持久工作狀態 → 自主喚醒 → 合法派工 → 真實執行 → 獨立驗證 → 自主續工」完整閉環。
2. **Bootstrap 循環依賴**：部分修復工作需要 HGK Native Admission，而 Admission 所依賴的 Receiver、Trust、Policy Loaded 等能力，恰好仍屬 B1 待修復對象。
3. **治理層級錯置**：將最終 Native Acceptance、SourceFreeze、獨立 Checker 等正式放行條件，過度套用為每一次診斷、局部修補與持續施工的前置條件。
4. **執行控制與文件契約沒有充分分離**：B1 DOC-00～08 是設計及驗收控制包，尚不是已安裝、已綁定、可直接驅動 Hermes 的原生控制系統。
5. **指揮策略持續改版，但 Runtime 缺口尚未閉合**：Codex r1～r6、Hermes r7～r10 的反覆續工，累積了實際工程成果，同時也產生任務脈絡壓縮、狀態轉移不完整及提前結案問題。
6. **真實效果與驗收證據存在斷層**：Repository Patch、CI PASS、Scheduler 測試、簽章元件測試、Manifest 封存，均不能直接證明現役 Receiver、Executor、Fabric Policy Consumer 與獨立 Checker 已形成完整 Native 閉環。
7. **跨系統介面尚有不相容與責任衝突**：包括 PIPD Oracle/Profile ABI、HGK User Trust 與 Receiver 接線、Fabric Activator、SBL Proposal 入口及 Commander-SP 禁用條件。

### 最終狀態裁決

最新 r10 Native 逐 ID PASS

# 0

三張 Golden WorkOrders

# 0 / 3 完成

T1 派工基礎

**PASS（沿用 r9）**

正式 Handoff

**HOLD**

---

**B1 整體工程判定：`PARTIAL_WITH_EXPLICIT_HOLDS`**

`native_artifact=false`；R1/R2 為 PARTIAL；T2、R3、R4、G-A、GWO-FABRIC、GWO-HGK、GWO-SBL、G-B 尚未取得正式通過證據。

以上狀態來自截至 2026 年 10 月 27 日的 r10 交接紀錄，**不是本次直接登入 Windows Host 後重新執行的驗收結果**。其中 `NOT_RUN` 必須與「已執行但失敗」區分，不能因缺少驗收收據就斷言四套系統全部故障。

**核心工程裁決：保留原架構與必要安全治理，但必須修正治理適用階段、打通 Native Bootstrap、建立真正持久的 Hermes 執行控制，並將局部施工完成和最終產品驗收分開。**

不建議全面重寫 Hermes、HG-KSEOS、Fabric、SBL 或 PIPD，也不建議繼續以反覆產生更長的施工 Prompt 作為主要修復手段。

---

## 二、鑑定依據、證據可信度與適用法位

### 2.1 四份核心紀錄交叉比對

| 文件 | 本次鑑定用途 | 證據限制 |
|--------|--------|--------|
| 《B1指揮施工\_總紀錄》 | 重建歷次指揮目標、工程裁決、角色轉換及後續勘誤 | 包含不同時點的推論；較早裁決可能已被後續修正 |
| 《B1施工\_PROMPT》 | 審查 Codex r1～r6、Hermes r7～r10 的具體授權、施工 DAG、終止規則 | Prompt 代表要求，不代表實際執行 |
| 《B1施工狀況\_總鑑定分析》 | 追蹤阻斷變化、工具缺陷、治理爭議、局部工程進展 | 多份報告引用相同上游證據，不能當成多次獨立實測 |
| 《FHS\_MSC\_B1\_Task\_Handoff\_Report\_v1\_2026-10-27》 | 確定最新工程狀態、未完成項、證據缺口及交接邊界 | 本次未取得全部原始 Windows Host 收據 |

鑑定採用四類確信：

| 確信類型 | 定義 |
|--------|--------|
| **A｜直接確認** | 本次直接讀到設計契約、命令正文，或由 GitHub 介面查到 PR／CI 的實際狀態 |
| **B｜紀錄支持** | 多份紀錄內容一致，具有具名工件、提交或測試定位，但本次未重跑原始 Host 測試 |
| **C｜工程因果推論** | 故障機制合理，具備現象支持，但缺完整執行軌跡或對照實驗 |
| **D｜尚未證實** | 僅有候選程式、設計、推測或未執行的驗收項目 |

特別注意：四份文件有相互引用及重複收錄，不能因同一段分析出現三次，就認定存在三份獨立證據。

### 2.2 上位設計的正確解釋

B1 r3 控制包在 DOC-00 中明確聲明：

- `task_kind: DESIGN`
- `claim_ceiling: AUTHOR_SIDE_REPAIR_CANDIDATE`
- `formal_sourcefreeze: HOLD`
- `independent_checker_receipt: NOT_RUN`
- `native_effect: NOT_RUN`
- `release: NOT_RUN`

因此，**B1 DOC-00～08 是可供施工及驗收使用的設計控制規範，不是已取得原生執行授權的系統。**

其架構原則仍應保留：

| 系統／角色 | 應有權責 | 不應承擔 |
|--------|--------|--------|
| PIPD-LS-SP | 唯一 Canonical 契約編譯、PI/PD/ECP/TQAEP | Hermes Runtime Scheduler |
| HG-KSEOS | Native Issuer、Admission、受治理 WorkOrder 權威 | 第二個無約束模型代理 |
| Hermes | 長任務派工、Executor、Lease、Checkpoint、續航 | 自行創造 Native Permit |
| Fabric | Stage、Activate、Policy Loaded、Consumer Readback | 僅靠 PR SHA 宣告已生效 |
| SBL | 受治理的需求／Proposal／產品入口 | 自發簽發 HGK Permit |
| Codex | 有界診斷、修補、測試、受控 Worker | 長期替代 HGK Issuer |
| Independent Checker | 以真正隔離的身份核實 Raw、世界效果與拒收條件 | 由 Maker 自行填寫驗收 PASS |

此權責分離是合理的。真正的問題是：**施工期間尚未具備的正式效果能力，被不恰當地用來阻斷建立該能力所需的普通工程工作。**

上位依據：B1 DOC-00、DOC-02、DOC-03、DOC-04、DOC-08；交接報告 §0～§2。

---

## 三、r1～r10 施工歷史與失效因果重建

### 3.1 施工時間線

| 階段 | 主要施工策略與進展 | 核心遺留問題 |
|--------|--------|--------|
| Codex r1 | 建立完整 B1 施工範圍、來源綁定與正式驗收 DAG | 一開始即承載大量上位 Gate |
| Codex r2～r3 | 處理 SourceFreeze、TaskKind、Oracle、Prompt Compiler；尋找 Native 發行路由 | `PL-003`／`PL-004` 未閉合，出現反覆停工 |
| Codex r4 | 形成較具體的 Native Admission／Oracle 候選和自動修補指令 | Maker 隔離測試成功，但 Live Native 未成立 |
| Codex r5 | 將任務收斂為最小可信 Native Trust／修補能力 | 特定 Admin-only Trust 實作增加首次啟用阻力 |
| Codex r6 | 轉向正式 Native 驗收和 Hermes 接管評估 | 原生 Issuer／Policy／Checker 等仍不足 |
| Hermes r7 | HGK Overlay 63 項測試通過，發現 Route Pin／Trust 問題 | T2、G-A、GWO、G-B 未成立 |
| Hermes r8 | SharedSpine 18/18、HGK/SBL 局部修補、Route Pin 測試 | 真 Hermes Executor 尚未證明；封存一致性出現問題 |
| Hermes r9 | 四庫候選整合、PR 快進、持久派工、OS Scheduled Task、封存修正 | Dispatcher 成功不等於 Hermes Native Loop |
| Hermes r10 | PIPD CE-2 修復、HGK User Trust 七測通過 | Receiver 未接線；Fabric R3、R4、Executor 未執行；提前交付 |

**工程進展是真實存在的，但進展主要集中在候選原始碼、隔離測試、派工原語與交接工件，尚未形成原生端到端驗收。**

### 3.2 第一條因果鏈：Codex Bootstrap 阻斷

在 Codex r3～r4，曾出現三項具名 Compiler 拒收：

| 代碼 | 原始阻斷 | 正確作用範圍 |
|--------|--------|--------|
| `PL-003` | Native Admission／SourceFreeze 未取得有效綁定 | 需要相應正式權威的編譯／效果 |
| `PL-003` | Registered TaskKind 尚未綁定 | 依賴該 TaskKind 的正式工作卡 |
| `PL-004` | `CR_ORACLE_001_OPEN` | 受影 Oracle 編譯／Ratification／驗收 |

這些拒收針對的是 B1 Effectful Compiler，不代表所有工作都不可執行。

然而，早期續工策略將其視為大範圍施工前置條件，形成：

必須修復 HGK／Hermes Native 控制能力

Effectful Compiler 要求正式 SourceFreeze／TaskKind／Oracle

正式 SourceFreeze／Admission 又依賴 HGK Native 能力

Bootstrap 循環依賴：待修能力成為修復自己的前置要求

**根因判定：確有流程層的循環依賴；但不能因此直接推論 HGK 原生 Issuer 全部損壞。**

解決方法是有限的 Bootstrap Engineering Boundary：受 OWNER 批准的 Repository 修補、唯讀診斷、隔離負例與測試可先進行；真正受治理的 Host Effect 仍必須依合法 Permit 准入。

### 3.3 第二條因果鏈：Hermes 自治續航失效

從 r7 到 r10，指揮令逐步修正，甚至在 r10 明確要求：

- 單一 OWNER 常設授權；
- 遇到 Native HOLD 時只 PARK 受影卡；
- 其他 READY 工作繼續；
- 不因 Session、Context 或報告完成而停止；
- 必須取得 Hermes 真 Executor、Native Successor 與 G-B。

但 r10 仍在 R3、R4、Executor 未執行時完成報告與封存。

這代表「持續執行」主要仍依賴模型遵守文字指令，而未由 Runtime 形成可機械驗證的強制控制。

因果路徑為：

**長篇指揮 → 部分容易完成的修補 → 遭遇較難的 Native Gate → 缺少硬性 READY 檢查及真實持續喚醒 → 先產出報告／Seal → Session 結束 → 後續重新建立指揮。**

其中，前三項執行結果可由紀錄支持；Context 壓縮及模型偏向容易結案工作的具體貢獻程度，仍屬因果推論，不能當成已量測的唯一原因。

### 3.4 第三條因果鏈：信任根與 Receiver 接線

r5 曾採用受保護的 Windows machine-scope Trust 設計，將 Administrator、LocalMachine 金鑰儲存體、ProgramData ACL 等實作條件帶入啟用流程。

r10 修正此方向，建立 User-scoped Ed25519／DPAPI 候選，七項隔離測試據報通過。

然而：

**User Trust 已實作 ≠ Receiver 已實際採用 User Trust。**

最新記錄中，Trust Profile 指向 `%LOCALAPPDATA%`，現有 Receiver Registry 仍指向 `%ProgramData%`。

故存在兩個不同問題：

- Profile → Receiver Resolver 尚未完成接線；
- 軟體金鑰的控制與 Checker 獨立性尚未取得正式驗證。

前者是可定位的整合缺口，後者是安全保證等級缺口，不應合併成「需要管理員」這一個模糊原因。

### 3.5 第四條因果鏈：工程成果被誤轉成 Native 完成度

r7～r10 在 Native PASS 仍為零的情況下持續取得局部成果。這反證「PIPD 一旦 HOLD，任何修補都不可能進行」的主張。

但也證實：**普通工程可持續進行，不代表 Native Gate 可以自動放行。**

將兩者混用造成兩個方向的錯誤：

- 過度保守：沒有 Native PASS，就停止所有一般工程。
- 過度樂觀：既然單元測試及 CI 已綠，就宣告整個 B1 成功。

B1 所需的是第三種路徑：工程與 Native 驗收各自記錄，各自晉級，僅在真正依賴關係存在時互相阻斷。

---

## 四、全部主要阻斷根因與責任層級

以下為本次交叉比對後的根因矩陣。嚴重度是對 B1 高自動化目標的影響，不代表每個子系統目前都已證實故障。

| ID | 根因／缺陷 | 嚴重度 | 確信 | 責任層 |
|--------|--------|--------|--------|--------|
| RC-01 | Hermes 真 Executor 與持久喚醒閉環未完成 | P0 | B | Hermes／Harness |
| RC-02 | READY 工作尚未耗盡仍可進入最終交付 | P0 | B | Runtime Stop Controller |
| RC-03 | Native HOLD 被擴張成整體施工停止 | P0 | B | 指揮／依賴路由 |
| RC-04 | HGK Bootstrap 與正式 Issuer 構成循環前置 | P0 | B | B1 執行投影 |
| RC-05 | User Trust Profile 尚未接入現役 Receiver | P0 | B | HGK |
| RC-06 | 真 Maker／Signer／Checker 分權尚未證明 | P0 | B | HGK／Security |
| RC-07 | B1 設計候選被誤當現役 Runtime 契約 | P0 | A | B1 Package／指揮 |
| RC-08 | 缺乏局部失效、局部 PARK 的依賴圖 | P0 | B | B1／Scheduler |
| RC-09 | Fabric Activator／Loaded／Consumer 未有真實驗收 | P1 | B | Fabric |
| RC-10 | 三模型 Lane `required=served` 未實測 | P1 | B | Hermes／Model Routing |
| RC-11 | PIPD Oracle 權威與 P4 ABI 相容尚未正式閉合 | P1 | A | PIPD |
| RC-12 | PIPD Profile 12 軸／9 軸映射缺有效證明 | P1 | B | PIPD |
| RC-13 | TQAEP Design／Live Checker 語義容易混淆 | P1 | A | PIPD／B1 |
| RC-14 | Stage-C WriteSet CI 真失敗 | P1 | A | PIPD CI／變更範圍 |
| RC-15 | DOC-08 Proposal 入口與 Commander-SP 禁令衝突 | P1 | A | SBL／B1 |
| RC-16 | 工程修補重試與 Native Effect At-most-once 混用風險 | P1 | C | PIPD ECP／Harness |
| RC-17 | 完整產品身份分母被過度投影成執行排程 | P1 | B | B1 執行規劃 |
| RC-18 | SourceFreeze／TaskKind／Oracle 發行端點被假定必定存在 | P1 | B | Codex 指揮策略 |
| RC-19 | 原始碼、PR、CI、Host Loaded、World Effect 身份可能被借用 | P1 | B | 四系統整合／驗收 |
| RC-20 | 封存與持久工作狀態耦合，曾造成 SHA 不一致 | P1 | B | Evidence Pipeline |
| RC-21 | 大型 Context、重複 Prompt、缺少最小恢復狀態 | P2 | C | Agent 指揮與上下文管理 |
| RC-22 | Windows Administrator 被特定候選方案過度泛化 | P2 | B | HGK Trust 設計選型 |
| RC-23 | Mandatory Method 安裝與真實調用證據未分離 | P1 | B | Policy／Tool Routing |
| RC-24 | `NOT_RUN`／`FAIL`／`NO_FIT`／`HOLD` 混用 | P1 | A | Gate／狀態分類 |
| RC-25 | 正式 Native Issuer、Checker、GWO 原始收據不齊 | P0 | B | 全系統驗收鏈 |

**P0 是必須優先解決的高自動化阻斷；P1 是必要能力及驗收缺口；P2 是持續增加工程成本的次級促成因素。**

其中 RC-09、RC-10、RC-19 與部分 RC-23 的未完成，尚不能證明對應系統現役功能損壞；需要先測量，再按第一個實際失敗點修補。

---

## 五、B1 DOC-00～08 逐冊治理與工程適用性鑑定

### 5.1 總體規模

目前 r3 B1 控制包約 21,784 行，包含多種不同的規範分母：

| 規範／身份 | 數量 | 正確用途 |
|--------|--------|--------|
| Requirement Atoms | 27 | 定義原始要求、Owner、Oracle 對應 |
| WO／OBS Slots | 31 | 定義效果分類、前置條件、工作範圍 |
| TQAEP Parent Cases | 120 | 驗證要求 |
| TQAEP Child Effect Cases | 124 | 各效果類型驗證 |
| Node Conformance | 38 | 節點與整合覆蓋 |
| R15 Product Identities | 949 | 產品及技術設計覆蓋 |
| Product Matrix Cells | 192 | Host／Kind／Mode／Provider 條件化准入 |
| Named Assets | 81 | 具名產品／工具資產 |
| Golden WorkOrders | 3 | 真實端到端驗收 |

這些數字不應相加成為「待執行 WorkOrder 數」。

尤其是原始 R15 的 949 身份，分為 66 Required、254 Conditional、629 Deferred。後期 r10 整合 Ledger 則有 1,565 身份，分類為 625 Required、285 Conditional、655 Deferred。

**兩套分母不是同一個命名空間，也不能互相替代。**

後期 Ledger 的 Required 身份仍需按照其實際適用性閉合，但不代表 625 張獨立 Host Effect WorkOrders，也不能因現階段資源不足任意把 Required 改為 Deferred。

### 5.2 九冊逐項鑑定

| 文件 | 應保留的核心規範 | 已識別的執行問題 | 修訂建議 |
|--------|--------|--------|--------|
| DOC-00 Governance | Authority、FirstFail、G-A/G-B、Policy、停損 | 設計 Gate 與執行 Gate 易混用 | 增加執行階段及局部阻斷規則 |
| DOC-01 PI | 27 Atoms、P4 Native Compiler、Sidecar | Source／Oracle 未綁定時擴散到一般施工 | 把受影 PI Gate 局部化 |
| DOC-02 PD | 31 WO/OBS、Repo/Host Late Binding | 不同 EffectClass 曾繼承相同全域 HOLD | 每卡獨立依賴、權限與證據 |
| DOC-03 OPS-ECP | Issuer／Queue／Receiver／Promotion／User Boundary | 尚缺真 Host Adapter／Issuer | 保留效果分權，分開普通修補 |
| DOC-04 DEV-ECP | R1～R4、真 HotPath、最小 Patch | 候選路徑容易被當現役路徑 | 先觀測故障，再決定是否修補 |
| DOC-05 TQAEP | 120 Parent／124 Child／38 Node | 測試規格數量可能被誤當測試執行量 | 用 Raw Evidence 映射受影測試 |
| DOC-06 Coverage | 949／192／81 全量產品責任 | 巨型覆蓋矩陣增加單輪負擔 | Required 優先；Conditional 依觸發；Deferred 留帳 |
| DOC-07 Toolchain | 真 CLI、Schema、Native Methods、NoFit | 真本機 CLI／Host 不一定可用 | 依現役工具及有效 ABI 執行 |
| DOC-08 GWO | 三個不同領域真效果、G-B | Commander Proposal 入口衝突 | 正式修訂合法非 Commander 入口 |

### 5.3 DOC-02 的重要反證：B1 並未要求全部工作使用相同權限

DOC-02 將 31 張 WO/OBS 分成：

這項分類對根因鑑定極為重要。

`READ_ONLY_PROBE` 不需要 HGK 發行寫入 Permit；`REPOSITORY_WRITE` 必須符合 RepoContext、Standing Authorization、WriteSet 與必要的 PIPD ExecutionAdmission；`HOST_OPERATIONS` 則應使用真正 Native Issuer／Policy；`USER_DATA_EFFECT` 必須具備獨立合法使用者資料作用域與同意。

但過去部分 Ledger 使用共同的 `SOURCE_COMPILER_HOLD`，使不同類型工作一起停住。

**裁決：保留四類 EffectClass，修正依賴適用性，而不是取消權限治理。**

### 5.4 DOC-05／DOC-06 的治理過重

問題不是測試與產品身份太多就應刪減。

問題在於：

- DOC-05 的大量 Fixture 是正式驗收分母，不是 Hermes 每次醒來都必須重新生成的施工任務。
- DOC-06 的完整產品覆蓋是防止範圍縮水，不代表 B1 Bootstrap 必須把每個工具安裝完成。
- 真 Runner 尚不存在時，Schema-valid 測試定義仍只能是 `PLANNED` 或具體 HOLD。
- 重複解析所有文件所付出的 Context 與推理成本，不直接增加 Native Readback 數量。

**應當保留完整分母，將其編譯成可查詢、可追溯的 Coverage Index，而 Scheduler 只消費受影的可執行 WorkOrders。**

### 5.5 治理過重的正式判定

| 治理機制 | 是否必要 | 過重或錯置部分 | 最終處置 |
|--------|--------|--------|--------|
| Source SHA、Subject Identity | 必要 | 每輪重做全域來源審核 | 受影增量重驗 |
| RepoContext／WriteSet | 必要 | 歷史變更造成未受影工作一併 HOLD | 差異級 Currentness |
| HGK Issuer／Permit | 必要 | 要求普通 Bootstrap 診斷先取得待修 Issuer | 有界維修通道 |
| Independent Checker | 必要 | 要求設計階段提供尚未產生的 Live Receipt | Design／Live 分層 |
| TQAEP | 必要 | 每個身份要求獨立人工處理 | 自動映射、真 Raw 驗證 |
| Full Product Coverage | 必要 | Deferred 也被當作當輪工作 | 適用性排程 |
| Native Method Registry | 必要 | 工具已安裝被誤當真實調用 | 每卡讀現役 Mandatory Set |
| Manifest／Seal | 必要 | 封存動作變成 Runtime 結案訊號 | 隔離中期快照與最終 Seal |
| Windows Administrator | 視效果而定 | 特定 Machine-scope 選型被泛化為普通施工條件 | User-scope 主選，受保護效果再提權 |
| 人類 OWNER 核准 | 必要 | 普通有界工程反覆詢問 | 版本化 Standing Authorization |

**結論：B1 存在治理配置與執行投影過重，不足以認定其全部上位安全設計過度工程化。**

---

## 六、HERMES／HG-KSEOS／Fabric／SBL／PIPD 個別工程鑑定

### 6.1 Hermes：最優先修復的高自動化執行層

**現有能力**

r8～r9 已有 SharedSpine 持久化、CAS、Lease、跨程序測試、Dispatcher 與 Windows 排程觸發的候選證據。

**真正缺口**

尚無完整證據證明已安裝 Hermes Executor 能由合法 Native WorkOrder 自主喚醒、執行、記錄世界效果，並在另一個程序中接續。

r9 Scheduled Task 據報能觸發測試 Dispatcher，但其工作不等於已完成 HGK Admission 後的 Hermes 真執行。

**必須修正**

將現有 SharedSpine 與真正 Hermes Worker 入口接通。保留單一 Queue 權威，避免再造獨立調度系統。

同時將以下停止條件落入程式：

```text
if READY_COUNT > 0:
    MISSION_COMPLETE = DENY
    dispatch_next_ready()

elif RUNNING_COUNT > 0:
    MISSION_COMPLETE = DENY
    reconcile_or_await_valid_worker()

elif pending_items_are_all_evidenced_external_blocks:
    EXECUTION_CYCLE = PARKED
    persist_wakeup_conditions()

elif all_applicable_native_gates_pass:
    MISSION_COMPLETE = ELIGIBLE_FOR_FINAL_CHECK

else:
    MISSION_COMPLETE = DENY
    reconcile_work_state()
```

此為建議的控制邏輯示意，並非現有 Hermes 已證實支援的 API。

還必須檢查 Queue 實際公平性、不可重複效果及程序崩潰後的自動喚醒。

### 6.2 HG-KSEOS：Native Trust 與 Receiver 有實際整合缺口

**已有成果**

HGK 原有 Admission 候選、User-scoped Trust、SharedSpine 與相關測試均已有實作進展。

**尚未閉合**

- Trust Profile Resolver → 現役 `native_admission.REGISTRY`。
- Signed Bundle → Receiver Admit。
- Nonce、TTL、Scope、Revoke 的真正效果前拒收。
- Signer／Maker／Checker 權限隔離。
- Native Issuer → Hermes Queue 的真實完整鏈路。

**正式建議**

採用最低必要權限的 Trust Profile，但不得讓 Maker 能替換 Trust Anchor、取用 Signer 私鑰或修改 Checker Verdict。

User-scoped Software Key 可作為受限低權限工作流程的主選技術；若同一 SID 下 Maker 可以存取相同保護內容，則不能宣稱已實現高保證獨立 Principal。

不應無條件要求 Windows Administrator，也不能因此取消受保護金鑰及真正的 OS 權限要求。

### 6.3 Fabric：缺的是正式活化鏈實測，不是已證明整個系統故障

截至 r10：

- Fabric \#18 主要證據是程式碼整合與受影測試。
- 真 Activator 調用沒有完成。
- Active Policy、Loaded SHA、Consumer ACK 缺端到端證據。

正確處置是先找現役入口並執行合法只讀檢測。若真路由已存在且運作正常，直接完成驗收即可；若發現特定失敗，再做最小修補。

必須分開記錄：

`Stage Receipt`、`Active Receipt`、`Loaded Receipt`、`Consumer ACK`。

**不得由同一個配置檔 SHA 推導四種不同執行事實。**

### 6.4 SBL：已有可用產品候選，但入口及 User Effect 尚未完成

SBL CLI 與 Atomic Save 有可追蹤的候選及測試。

真正的 B1 要求包含兩種不同效果：

1. Host 安裝、載入、功能入口及卸載。
2. 合法隔離使用者資料的 `init → add → list → remove → list` 行為。

安裝成功不能證明資料操作成功。

另外，DOC-08 將 SBL `plan.propose` 設為 GWO 的入口，但後續 r10 已明確禁止 `sbl-commander-sp`。

因此應先證明是否存在獨立於 Commander-SP 的合法 Proposal ABI。若沒有，補足最小 Proposal Adapter，經 SBL 權責核准後，以版本化條款更新 DOC-08 的執行入口。

不能擅自把不存在的替代路由宣稱為現有功能。

### 6.5 PIPD-LS-SP：不是主要停工根因，但存在獨立的工具相容性問題

PIPD 應繼續負責施工前契約、權威、來源及驗收要求，不應變成 Hermes 的第二個 Runtime Scheduler。

本輪識別四個需要分別處理的技術問題：

| 問題 | 鑑定 | 建議 |
|--------|--------|--------|
| Oracle Writer／ABI | DOC-07 Canonical 與 P4 Legacy Locator 需正式對齊 | 版本化相容 Adapter，保留原有 Schema |
| Profile 12／9 軸 | 兩層風險／輸入模型可能不具直接同構性 | 逐軸 Mapping、Veto、無損證明或明確拒收 |
| TQAEP Design／Live | 編譯測試定義不應先要求測試結果 | `PLANNED → EXECUTED → INDEPENDENT_VERIFIED` |
| ECP Retry | 效果 at-most-once 不等於只准修補一次 | 區分 Effect Attempt、Diagnostic Attempt、Repair Iteration |

另有一項已實際證實的 CI 缺陷，不能被這些架構討論掩蓋。

### 6.6 GitHub 及 CI 最新直接核對

本次使用 GitHub 連線重新讀取以下四個 PR：

| Repository | PR | HEAD 簡碼 | 現況 |
|--------|--------|--------|--------|
| HG-KSEOS | [github.com](https://github.com/shw097-team/HG-KSEOS/pull/2?utm_source=chatgpt.com) | `70147a5e6452` | Open／Draft／未合併 |
| Fabric | [github.com](https://github.com/shw097-team/Fabric/pull/18?utm_source=chatgpt.com) | `a65231cd9ca7` | Open／Draft／未合併 |
| SBL | [github.com](https://github.com/shw097-team/SBL/pull/13?utm_source=chatgpt.com) | `a97b1bf886b4` | Open／Draft／未合併 |
| PIPD-LS-SP | [github.com](https://github.com/shw097-team/PIPD-LS-SP/pull/20?utm_source=chatgpt.com) | `abeae2512e5f` | Open／Draft／未合併 |

PIPD \#20 的兩個 GitHub Actions 工作結果已直接核對：

- [github.com](https://github.com/shw097-team/PIPD-LS-SP/actions/runs/40450463928?utm_source=chatgpt.com)：`offline-gate = success`。
- [github.com](https://github.com/shw097-team/PIPD-LS-SP/actions/runs/40450464119?utm_source=chatgpt.com)：`verify = failure`。

失敗 Job `122011714859` 日誌明確包含：

```text
UPGRADE_WROTE_OUTSIDE_ALLOWED_SET:
docs/adr/ADR-0008-repository-state-and-hygiene-inventory.md

UPGRADE_WROTE_OUTSIDE_ALLOWED_SET:
docs/adr/ADR-0009-session-handover-and-next-session-start.md
```

這是**真實的 WriteSet Gate 拒收**，不是單純上傳 `resolved-deps.txt` 失敗。

必須查證其 Base/HEAD 差異、Stage-C 的授權變更集合及 ADR-0008/0009 的變更歸屬，不應直接放寬 Allowlist 求 CI 綠燈。

本次 GitHub 查證只能確定遠端 PR／CI；不能取代 Windows 本地 Repo HEAD、Dirty、實際 Import Path、Loaded Module 和服務現況。

---

## 七、治理收斂後的高自動化目標架構

### 7.1 核心原則：只保留一個工作權威、一個原生簽發權威

建議使用以下執行架構：

```text
人類 OWNER
  │
  └─ Versioned Standing Authorization
        │
        ├─ B1 Execution Profile
        │    ├─ 適用性
        │    ├─ 工作依賴
        │    ├─ EffectClass
        │    └─ StopLoss／Retry／Resume
        │
        └─ HGK SharedSpine
             │
             ├─ 唯一 Durable WorkOrder State
             ├─ CAS Lease／Heartbeat
             ├─ Dependency Resolver
             ├─ Journal／Checkpoint
             │
             └─ Hermes Executor Adapter
                   │
                   ├─ 唯讀診斷
                   ├─ 有界 Repository 修補
                   ├─ 隔離自動測試
                   │
                   └─ 正式 Native Effects
                        │
                        ├─ HGK 唯一 Issuer／Receiver
                        ├─ Fabric Activator／Consumer
                        ├─ Model Required／Served
                        ├─ SBL Host／User Effect
                        └─ Independent Checker
                              │
                              └─ Raw／Gate／Resume
```

這個架構不新增第二個 Queue、第二個 HGK Issuer 或第二套 PIPD Canonical Writer。

### 7.2 三層准入，不得混用

| 層級 | 工作類型 | 允許的自動化 | 必備控制 |
|--------|--------|--------|--------|
| L0：Observation | 唯讀 Root/Repo/Host 探測、差異分析、讀取測試結果 | 可在核准 Read Scope 內自動持續 | Read Scope、Subject、無副作用 |
| L1：Bootstrap Engineering | 有界 Source Patch、隔離測試、候選 PR、回歸 | 於既有有效 OWNER 授權／合法施工准入下自動進行 | RepoContext、WriteSet、適用 ExecutionAdmission、Preimage、Rollback |
| L2：Native World Effect | 正式 Issuer、Policy Promotion、Host 變更、User Data Effect | 有效 Native Permit 後自動執行 | Policy、Nonce、TTL、Scope、真 Receiver、Effect Journal |

最終正式驗收另設 Evidence Gate，不能由 L0/L1 的成功自動推出。

此模型不豁免 PIPD DOC-05 對真正 Repository Mutation 的 ExecutionAdmission 要求；它只是避免把 **L2 的 Host 受治理權限，錯誤套用到 L0 與不依賴該 Host 效果的 L1 工作**。

### 7.3 單一 OWNER，不等於單一 Principal

常設授權應由真正有權的 Owner 流程建立，最少包含：

`Mission / Root / Subject / Allowed Effects / WriteSet / Principal / Policy Epoch / TTL / Nonce / Revoke / Compensation / Checker Requirement`。

已授權的普通工作不應反覆 HITL；超出既有範圍、涉及受保護 OS 資源或私人使用者資料的新效果，仍需要適用的真實權限與同意。

Signer 必須具有有效金鑰保護；Checker 必須具備實際獨立的驗證能力。不同 Agent 名稱、模型角色或 PID 都不足以證明分權。

### 7.4 唯一工作狀態與結案決定權

建議工作狀態至少區分：

`READY → CLAIMED → EXECUTING → READBACK → CHECKING → VERIFIED`

並具有合法 `PARKED`、`REPAIR_REQUIRED`、`UNKNOWN_EFFECT`、`COMPENSATION_REQUIRED` 等分支。

需要**分開保存三種狀態**：

| 狀態 | 用途 | 誰有決定權 |
|--------|--------|--------|
| `engineering_status` | 是否已完成本張工作卡的工程行為 | Hermes Executor／合法 Worker Readback |
| `native_acceptance_status` | 真 Native Gate 是否通過 | Native Owner／Independent Checker |
| `mission_status` | 是否仍需繼續派工、PARK 或正式結案 | Durable Controller 依工作及 Gate 狀態計算 |

`PARTIAL_WITH_EXPLICIT_HOLDS` 可以是某次報告的正確狀態，但不應自動把 Durable Mission 轉成 `COMPLETE`。

若仍有 READY 工作，應繼續派工；若全部剩餘項都具有真實外部阻斷，才允許暫停執行週期並保留自動恢復條件。

### 7.5 安全恢復及避免重複效果

必須分離三種重試計數器：

- `diagnostic_attempts`：唯讀診斷，可按時間及資源預算限制。
- `repair_iterations`：候選修補，可依真正差異及回歸結果持續。
- `effect_execution_attempts`：實際受治理效果，受 ECP 的 At-most-once／Idempotency／Journal 限制。

`UNKNOWN_EFFECT` 必須先讀回世界狀態及進行 Reconciliation，不能直接以新工作卡盲目重播原效果。

---

## 八、完整修復路線與工程優先次序

修復必須採取「先恢復可持續工作的能力，再由該能力推進正式 Native 驗收」的策略。

這不是將正式安全驗收往後取消，而是避免尚未完成的最終驗收條件阻礙其他合法工作。

### 8.1 P0：先完成最小自治執行閉環

**目標：證明 Hermes 能真正接收、執行並自主續行合法工作卡。**

所需工作：

1. 確認 r10 之後的真實 Windows Repo、Hermes 安裝、現役 Executor 入口和 SharedSpine。
2. 使用原有 SharedSpine 產生有實際依賴及操作身份的工作卡，不建立第二個 Queue。
3. 綁定合法 Hermes Worker Adapter，確認是真正的 Hermes 執行工作，而非獨立測試腳本自行冒充。
4. 在隔離環境實測 `READY → CLAIM → EXECUTE → READBACK → CHECKPOINT`。
5. 讓工作 A 阻斷，證明 B／C 繼續。
6. 中止 Worker，利用合法觸發器啟動另一個 OS Process，確認同一持久任務能恢復。
7. 在仍存在 READY 卡時強制產生中期 Report，證明系統不會因此結案。
8. 測試 stale lease、重複 claim、ghost worker、未知效果及重播拒收。

**驗收出口：** 真 Hermes Executor 被呼叫，合法工作能跨程序恢復；沒有 READY 任務因封存而消失；重複 Effect 不發生。

此處可先用隔離、無 Native World Effect 的工作測試 Harness，不能用測試成功冒稱 T2／G-A 正式通過。

### 8.2 P0：HGK User Trust 接入正式 Receiver

**目標：讓已有候選 Trust 能被現役 Receiver 真正消費。**

執行要求：

- 核對 `de37c48` 是否仍存在於當前本地有效分支。
- 釐清 `%LOCALAPPDATA%` 與 `%ProgramData%` 的 Profile Resolver。
- 最小修補 `native_admission.REGISTRY` 的有效 Trust Profile 選擇。
- 對真 Receiver 測試 Signed Bundle 正向 Admit。
- 對錯簽、錯 Subject、錯 Policy Epoch、過期 TTL、Nonce Replay、Revoke 執行負例。
- 確認 Maker 不可擅自改寫 Trust Anchor。
- 若本輪需要高保證 Checker，必須提供真正不同 OS 權限或其他有效隔離機制。

**驗收出口：** 真 Receiver Admit／NACK、同一 Subject Raw、實際隔離證據，以及符合要求的 Issuer／Checker 分權。

若僅 User-scoped Software Key 通過，應保持相應較低保證級別，不能自動宣告全域安全驗收通過。

### 8.3 P1：並行處理 Fabric R3 與模型 R4

兩項工作具有自己的可進行診斷，不應無條件等待完整 Native Trust 才開始。

**Fabric R3：**

先找到真正的 Activator 與 Consumer，不直接假定系統壞掉。完成有效授權後執行 Stage → Active → Loaded → Consumer，要求 Policy SHA、Epoch、Reader ACK 一致，保留負例及回復讀回。

**模型 R4：**

從現役 Routing 及政策讀取 Required Provider／Model／Method，對 `PLAN`、`EXECUTE`、`VERIFY_SECURITY` 分別做真實 Served 測試。保留 Request ID、Served Model、Provider、Policy Epoch、回應收據及錯配負例。

如果 Provider 或模型不可用，只 PARK 受影模型卡；不可默默替換為其他模型並宣稱同等 PASS。

### 8.4 P1：PIPD 相容性與 CI 修補

必須同時處理：

- Stage-C ADR-0008／0009 WriteSet 差異；
- Oracle Canonical 與 P4 Legacy ABI；
- Profile 12 軸與 9 軸相容性；
- TQAEP Design／Live 分階段契約；
- ECP Effect Retry 和工程迭代分離。

**限制：** 只修受影 ABI／Code／Tests，不全面重寫 PIPD DOC-00～09；不得為了 CI 綠燈關閉原本有效的安全 Gate。

### 8.5 P1：修正 B1 Package 的執行投影

建議由有權 Owner 批准一份版本化的薄型 `B1 Execution Profile`，不直接覆寫 r3 DOC-00～08。

最小內容如下：

| 控制欄位 | 應具備的規則 |
|--------|--------|
| `source_authority` | 保留 r3 原始 Source IDs、SHA、Owner |
| `effective_scope` | 明確區分 Bootstrap、Native Effect、Release |
| `effect_class` | OBS／Repo／OPS／USER |
| `dependency_refs` | 只引用真實依賴，禁止全域 HOLD 擴散 |
| `task_status` | READY／RUNNING／PARKED／VERIFIED |
| `permit_requirements` | 依工作效果及現役政策決定 |
| `checker_requirements` | 真 Raw、真獨立性，不使用模型角色假名 |
| `applicability` | Required／Conditional／Deferred |
| `first_fail` | 具名首個可重現失敗及可解除條件 |
| `resume_policy` | 可重入條件、Checkpoint、有效喚醒 |
| `terminal_policy` | 工作是否耗盡，正式 Gate 是否通過 |
| `legacy_entry_resolution` | DOC-08 非 Commander Proposal 的合法 ABI |

修訂必須經既有版本控制與 Owner 生效程序批准，不能用本報告自動改變原始權責。

### 8.6 P1：重建 SBL Proposal 和三個 Golden WorkOrders

GWO-FABRIC、GWO-HGK、GWO-SBL 必須維持三組獨立操作身份及原始收據。

- **Fabric：** 真 Stage／Activate／Loaded／Consumer。
- **HGK：** 真 Proposal／Issuer／Queue／可逆 World Effect／Checker。
- **SBL：** 真 Host 安裝、合成使用者資料 Add/List/Remove、持久化、卸載及零不當殘留。

Commander-SP 禁令應維持；非 Commander Proposal 若尚不存在，先經版本化核准最小 Adapter 修補。

### 8.7 P1：G-B 原生接管

G-B 不是「另外啟動一次 Hermes」即可通過。

正確順序為：

1. 三張 Golden WorkOrders 各自通過。
2. 撤銷外援臨時授權。
3. 切換真正不同 OS Process／Session。
4. 由 Native Scheduler 自主觸發下一張合法工作卡。
5. 原生 Issuer／Receiver／Hermes／Checker 完成同 Subject 閉環。
6. 使用舊 Token 重播，應於效果前拒收。
7. 檢查額外操作、殘留、Rollback、持久狀態。
8. 完成後續 22-node DAG 的正式接管 ACK。

**這才是從外援施工轉變為 Native 高自動化執行的真正驗收分界。** fileciteturn0file3L58-L70

---

## 九、完整驗收設計與反證實驗

### 9.1 必須完成的最小反證實驗

| 實驗 | 要排除的故障 | 合格條件 |
|--------|--------|--------|
| E01：隔離 Repo 修補 | 普通修補依賴完整 Native Gate | 合法有界 RED→PATCH→GREEN |
| E02：Native Permit 不可用 | 一個 HOLD 造成全域停止 | 受影 PARK，其他 READY 進行 |
| E03：阻塞 A，並行 B/C | Queue Starvation／Head-of-line Blocking | B/C 正常完成 |
| E04：Kill Hermes Worker | Session 終止使任務遺失 | 新 OS Process 自動恢復 |
| E05：提早生成 Manifest | 封存造成任務停止 | READY 不變且繼續執行 |
| E06：雙 Worker 同時 Claim | 重複 WorkOrder 執行 | CAS／Lease 防止雙重 Effect |
| E07：效果 Timeout | 未知效果重播 | 先 Reconcile，不盲重試 |
| E08：HGK 信任負例 | 偽簽／Nonce／Revoke 放行 | 全部非法效果 NACK |
| E09：Fabric Stage-only | Stage 被當作 Loaded | 無 Loaded/Consumer 即 HOLD |
| E10：模型 Served 錯配 | 配置正確但實際錯模型 | `required != served` 必 FAIL |
| E11：PIPD Oracle/Profile | ABI 相容性靜默降級 | 合法映射 PASS，風險遺失 FAIL |
| E12：SBL User Effect | Install 冒充使用者功能 | 真 add/list/remove/持久讀回 |
| E13：外援 Revoke | 外援仍能驅動 successor | 舊 Token 拒收，新 Native 自主執行 |
| E14：全部工作耗盡 | 永不停止或過早停止 | 依 WorkState 與正式 Gate 正確結案 |

其中 E01／E02 尤其適合用來量測治理阻力：在相同隔離工作、相同變更與測試條件下，比較經核准的工程施工路徑與增加 PIPD 正式契約處理後的差異。

**唯有對照實驗證實某項額外 Gate 導致非必要停止，才應將其認定為直接阻斷根因。**

### 9.2 正式 Gate 閉合標準

| Gate | 正式通過的最低條件 |
|--------|--------|
| T1 | 持久 Queue／Lease／公平調度及跨程序恢復原語 |
| T2 | 真 Issuer → Receiver → Hermes → Effect → Raw → Checker |
| R1 | 有效授權、Nonce／TTL／Scope／Revoke／拒收 |
| R2 | 真 Hermes Native Executor、Durable Queue、跨程序續行 |
| R3 | Fabric Stage／Active／Loaded／Consumer 同主體一致 |
| R4 | 三模型車道 Required＝Served，適用 Mandatory Methods 真調用 |
| G-A | 六項現役證據合取，同 Subject／Epoch |
| GWO×3 | 三領域不同效果、操作身份與獨立收據 |
| G-B | 撤外援後真正 Native Successor 跨程序自主接管 |
| Final | Required＋已觸發 Conditional、獨立驗收、封存與 Handoff 全閉合 |

T1 原語成功不能直接代替 R2，R2 也不能單獨代替 G-B。

G-A 的六項合取與 G-B 的不同 Golden WorkOrder 身份，是 B1 DOC-00 的正式不變量，不應為了加速而刪除。fileciteturn0file27L91-L95

### 9.3 驗收證據的完整性要求

r10 的原始證據交接仍有一項重要限制：

交接文件稱 Manifest 共有九項，先前交接環境只取得其中四項原始位元並完成 SHA 比對。其餘五項包含執行腳本、PIPD 收據／日誌、排程移除及 User Trust 收據，未同時完整提供。

因此：

**Manifest 與外部 Seal 相符，不等於九筆原始收據均已獨立驗證，更不等於 Native Acceptance PASS。**

正式驗收應採用：

`Operation Identity → Raw Bytes → Raw SHA → Observed World State → Independent Checker → Verdict → Manifest → External Seal`

Manifest 不能把自己的 SHA 循環寫入自身；Live Journal 應與 Frozen Snapshot 分離。封存後如發現新證據，應產生新版本或具體 Errata，不直接修改已封存主體。fileciteturn0file7L11-L19

---

## 十、治理成本與自動化效益評估

### 10.1 目前的成本來源

本次鑑定沒有完整工時、Token 使用量、每項任務的等待時間及受影工程成本原始統計，因此**不能客觀宣稱某個治理層已造成多少百分比的效率損失**。

但可以確認多項不必要成本的來源：

| 成本類型 | 已識別現象 | 工程處置 |
|--------|--------|--------|
| 重複讀取 | 每輪重新載入大量上位契約 | 最小 Execution Profile、按需查原條款 |
| 重複規劃 | r1～r10 多次重新下達完整使命 | 持久 WorkState 和同一 Mission ID |
| 無效等待 | 一個 Native HOLD 阻斷其他工作 | 受影依賴 PARK |
| 重複人工往返 | 把可自動裁決的工程事項重新詢問 OWNER | 有界 Standing Authorization |
| 候選停滯 | 測試通過但 Receiver／Host 沒接線 | 明確 Candidate→Effective Loaded 交接 |
| 早期封存 | 尚有工作卻產出最終報告 | Runtime Terminal Gate |
| 假成功／假失敗 | `NOT_RUN` 與 `FAIL` 混用 | Typed Result State |
| 過度驗證 | 不區分 Required、Conditional、Deferred | 適用性與受影重驗 |
| 獨立驗收重工 | Raw 主體與版本不能精確對應 | Evidence Ledger Identity Join |

### 10.2 建議導入的工程效能指標

不建議再以「撰寫多少行報告」或「有多少文件標記完成」作為自治施工主要 KPI。

應測量：

| KPI | 定義 | 期望方向 |
|--------|--------|--------|
| Autonomous Continuation Rate | Worker 正常／異常退出後合法工作自動恢復比例 | 提高 |
| Ready-to-Dispatch Latency | 工作進入 READY 至真實執行的延遲 | 降低 |
| False Global Block Count | 單項失敗無故阻斷其他獨立卡的次數 | 0 |
| Premature Finalization Count | READY／RUNNING 尚未耗盡就結案的次數 | 0 |
| Duplicate Effect Count | 同一 Operation 造成重複效果的次數 | 0 |
| Evidence Validity Rate | 受影 Raw、版本、Subject、Checker 可驗比例 | 提高 |
| Effective Native Gate Closure | 真正達到 Native PASS 的適用 Gate 比例 | 提高 |
| Rediscovery Rate | 重複調查已證實、未失效內容的比例 | 降低 |
| Unauthorized Effect Count | 缺合法授權發生實際效果的次數 | 0 |

其中最具診斷價值的是 **False Global Block Count、Premature Finalization Count 與 Autonomous Continuation Rate**。

這三個指標能直接分辨「治理多，但仍能持續施工」與「治理已經造成自動化失能」。

---

## 十一、最終責任歸因與工程裁決

### 11.1 不能只歸責於 Hermes

Hermes 的確存在自治施工閉環未完成的證據缺口，以及 r10 提前封存、未完成後續工作的實際紀錄。

但反覆停工不完全是 Hermes 模型沒有遵守文字命令。

B1 原始設計、後續指揮、PIPD 工具相容性與 HGK Native Bootstrap 共同形成了問題。

### 11.2 責任分配

| 責任領域 | 應負責解決的問題 | 是否屬主要直接根因 |
|--------|--------|--------|
| Hermes Runtime／Harness | 真 Executor、續航、結案控制、Checkpoint、喚醒 | **是** |
| 歷次施工指揮設計 | 全域 HOLD、最終封存誘因、未落地的持續控制 | **是** |
| B1 Package 執行投影 | 設計與 Runtime Gate 混合、分母與依賴錯置 | **重要結構性原因** |
| HG-KSEOS | Trust／Receiver／Issuer／Principal 邊界 | **Native 准入直接缺口** |
| PIPD-LS-SP | Oracle／Profile／TQAEP／CI 相容性 | **局部直接阻斷及促成因素** |
| Fabric | R3 真 Activator／Loaded／Consumer 證據 | **尚未驗證的必要環節** |
| SBL | 非 Commander Proposal、Host／USER GWO | **局部契約與驗收缺口** |
| OWNER | 合法權限及上位裁決 | **沒有證據支持「缺第二人類 OWNER」是必然根因** |

唯一人類 OWNER 的架構可以成立，但不能因此將不同機器權限、加密簽章或獨立驗收身份合併為同一 Principal。

### 11.3 不建議採取的修復方向

不建議：

- 全面重寫 B1 DOC-00～08。
- 全面重建 HG-KSEOS Issuer 或 Hermes Scheduler。
- 再建立第二個可獨立更新的工作 Queue。
- 將普通 Repository 修補全部提升為 Windows Administrator 作業。
- 讓 Maker 充當 Native Checker。
- 為通過 CI 放寬原有有效 WriteSet Gate。
- 為了滿足 DOC-08，間接啟動已禁止的 Commander-SP。
- 把未測試的 Fabric／Model 能力直接判定故障。
- 用額外大型 Prompt 代替缺失的 Runtime 續航。
- 把完整 R15 Deferred 分母轉成當輪強制安裝清單。
- 只靠單元測試或封存成功宣告 B1 正式完成。

### 11.4 建議保留的核心工程不變量

下列原則必須維持：

**Single Writer、Single Native Issuer、Single Durable Work Authority、Bounded Permission、No Silent Provider Substitution、Effect-Class Separation、At-most-once Native Effect、World-State Readback、Independent Verification、Affected-only Invalidation、Claim Ceiling、True Host Loaded Evidence。**

它們是阻止假成功、越權操作與不可控副作用的必要控制，不能因追求高自動化而刪除。

---

## 十二、最終工程判定及建議採納的修復主線

最終工程鑑定狀態

## `B1_AUTOMATION_CONTROL_REPAIR_REQUIRED`

**原架構保留；執行閉環與治理投影需要修復；Native Acceptance 尚未成立。**

---

最優先的五項工程處置

1. 在唯一 SharedSpine 上實現真正的 Hermes Executor、自主喚醒及機械化停止控制。
2. 解開 Bootstrap 與正式 Native Admission 的循環依賴，完成 HGK Trust → Receiver 的有效接線。
3. 修正 B1 DOC-00～08 的薄型執行投影，實行局部 PARK、適用性排程及三層准入。
4. 針對 Fabric R3、模型 R4、PIPD CI／ABI、SBL Proposal 逐項實測與最小修補。
5. 完成 T2、R1～R4、G-A、三 GWO、G-B、Independent Checker 與真正 Native Successor 接管。

### 十二之一：關於「治理是否過重」的最終回答

**是，存在治理過重，但精確地說，是治理適用範圍、執行時機與 Runtime 職責錯置。**

PIPD 的來源權威、准入、ECP、獨立驗收不是錯誤設計；B1 的完整產品分母與三 Golden WorkOrders 也具有工程必要性。

失效發生在將上述制度全部疊加到每一次普通修補、模型回合、任務停止與文件交付上，並且缺乏一個能自動識別「此工作真正需要哪些 Gate」的控制器。

### 十二之二：關於「Hermes 是否是主要故障來源」的最終回答

**Hermes 自治執行鏈路是目前最優先的修復對象，但不能據此認定 Hermes 本體全面故障。**

它已展現局部施工能力，尚未證明能在合法 Native 工作流程中長期、跨程序、自動恢復並完成正式接管。

缺少的是端到端運行保證，而非單純缺少再一次執行施工的文字授權。

### 十二之三：關於「PIPD 是否阻礙高自動化」的最終回答

**PIPD 的部分 ABI 與階段語義問題確實增加阻力；但現有證據不足以支持 PIPD 是全部停工的直接或唯一根因。**

r7～r10 在 Native PASS 為零的情況下仍完成多項工程修補，已經證明普通工程可以獨立推進。

應只修正 PIPD 真正不相容的接口，不削弱其 Canonical Writer、Permission、Oracle 和 Independent Checker 原則。

### 十二之四：關於「是否必須回到 Codex 重新施工」的最終回答

**不建議全面退回 Codex。**

Codex 可用於有明確 HotPath、WriteSet、前像、失敗測試的限縮修補；Hermes 應繼續作為高自動化主執行者，但前提是補齊 Durable Executor／Wakeup／Stop Controller。

若實測證明 Hermes 本體缺少必要 Hook，才由 Codex 針對該 Harness 入口做最小修補，不因此重啟整個 B1 工程。

### 十二之五：最終完成與未完成的嚴格界線

目前可以承認的成果是：部分工程程式碼及測試已完成、部分 PR/CI 已被驗證、持久派工原語具備成果、Native Admission 與跨域接管的缺口已大幅縮小。

目前不能承認的成果是：B1 全部 Required 已驗收、HGK 正式 Issuer 鏈路成立、Fabric／Model 全面 Native PASS、三 GWO 通過或 G-B 正式原生接管。

**最終結論：**

> FHS-MSC B1 的根本問題，不在於高自動化與嚴格治理必須二選一，而在於尚未建立足夠精確的控制，使兩者能在不同工程階段各自正確運作。
>
> 修復方向應是保留治理的安全不變量，削除不必要的全域前置依賴，讓 Hermes 依合法工作狀態真正自主施工、局部停損、自動恢復，再以各 Native Owner 的實際世界效果與獨立收據完成正式驗收。

**本報告的工程裁決等級：`SOURCE_BASED_CROSS_REVIEW + CURRENT_GITHUB_PR_CI_VERIFICATION + ENGINEERING_CAUSAL_ASSESSMENT`。**

本輪未修改 Windows Host、Repository、Policy 或任何 Native Effect；未取得新的實機獨立 Checker Receipt。因此，本報告構成工程分析與修復建議，不構成 B1 正式 Native Acceptance、SourceFreeze Ratification 或 Release。

## Prompt:
2026/10/27 下午8:49:24

你的角色：
你是「HERMES / FABRIC / SBL / HG-KSEOS」高自動化任務運行總工程師。

任務目標：
你必須整合前輪「FHS-MSC B1 Bootstrap Repair 高自動化失效——完整工程根因鑑定與治理收斂評估報告」，再對《FHS-MSC_藍圖_r2》、《FHS-MSC_總討論》 進行深度研究+交叉分析，是否要抽取整合這次『《B1指揮施工_總紀錄》、《B1施工_PROMPT》、《B1施工狀況_總鑑定分析》、《FHS_MSC_B1_Task_Handoff_Report_v1_2026-10-27》』的治理過重、鏈路問題、高自動化阻斷....等等的全部問題，對《FHS-MSC_藍圖_r2》進一步進行優化和升級，避免重蹈覆轍?
或是《FHS-MSC_藍圖_r2》、《FHS-MSC_總討論》其實都已經包含這些問題的解法，不必再次重工?

任務要求：
最後你必須直接以文字提出完整報告。

## Response:
2026/10/27 下午8:49:35 · gpt-6-thinking

我會先把《FHS-MSC\_藍圖\_r2》與《FHS-MSC\_總討論》的既有機制逐項對照 B1 的實際失效紀錄，將結果分為「已完整規範」、「已有原則但缺可執行契約」、「確實缺漏」及「既有條款互相衝突」。最後提出是否需要升版、應修哪些章節、哪些內容不得重工，以及防止下一輪重蹈覆轍的驗收標準。

> **盤點並比較FHS-MSC文件與先前報告**
>
>
> **盤點並比較FHS-MSC文件與先前報告**
>
> 
>
> **搜尋 FHS-MSC 參考文件與治理規範**
>
> 
>
> **快速掃描藍圖與討論標題**
>
>
> **快速掃描藍圖與討論標題**
>
> 
>
> **評估 B1 營運細節並建議版本修訂**
>
> 
>
> **擷取藍圖與討論重點段落**
>
>
> **檢查規格矛盾**
>
> 我正在比對各版本條款與執行流程，特別留意前置驗證、唯讀限制、隔離測試，以及指揮器禁用規則之間是否存在順序或權限衝突。
>
> **檢查規格矛盾**
>
> 
>
> **釐清藍圖矛盾並提出修訂章節**
>
>
> **檢視 B1 交接報告內容一致性**
>
>
> **分析現有藍圖與實作缺口**
>
>
> **整理修正方向**
>
> 我會把問題分成規格矛盾、流程閘門、證據完整性與執行落差，優先釐清前置驗證、暫停狀態、隔離測試及指揮權限，再提出最小幅度的條文修正。
>
> **整理修正方向**
>
> 
>
> **釐清藍圖矛盾並檢視交接與實作缺口**
>
> 
>
> 處理時間為 8m 30s

# 《FHS-MSC\_藍圖\_r2》與 B1 高自動化失效案例——跨文件治理、架構與執行閉環升級鑑定報告

**鑑定日期：** 2026 年 10 月 27 日
**鑑定範圍：** FHS-MSC 整體架構、HG-KSEOS／Hermes 自治執行、Fabric Policy、SBL、PIPD-LS-SP、B1 Bootstrap Repair，以及跨系統治理與原生驗收。

## 一、最終核心裁決

**建議升級《FHS-MSC\_藍圖\_r2》，但不應全面重寫，也不應再次建立一套新的治理或施工架構。**

本次交叉研究發現一項極為重要的事實：

**《FHS-MSC\_藍圖\_r2》與《FHS-MSC\_總討論》實際上已經包含 B1 這次高自動化失效的大部分核心解法。**

包括最小充分架構、避免治理過重、唯一 HGK Native Issuer、Hermes Durable Queue、局部 PARK、Codex 有界 Bootstrap Repair、正式 Native 接管、Standing Authorization、Candidate-to-Effective Adoption、跨程序恢復、獨立驗收，以及避免把全部產品分母都當成當輪施工前置條件。

因此，若重新設計上述機制，將產生大量重工，甚至再度形成多套控制規範互相衝突的問題。

但是，**既有藍圖已有正確原則，不等於已經具備足夠精確的 Runtime 執行契約，也不等於 B1 已經實際落實這些原則。**

這次 B1 的 r1～r10 施工暴露出三類仍值得提升到 FHS-MSC 全域治理層的問題：

- **規範落地缺口：** 藍圖有局部 PARK、持久續工及有界授權的設計，但部分強制停止條件、READY 任務續派、真正 Executor 生效等缺乏足夠明確的機械驗收契約。
- **設計文字中的階段性歧義：** 少數條款仍可能要求 Bootstrap 階段先取得原本只有 Live Effect 或 Independent Acceptance 階段才會產生的收據，形成循環依賴。
- **B1 新增的實際案例：** r10 提前封存、HGK User Trust 與 Receiver 未接線、正式 GWO 入口與 Commander-SP 禁令衝突、文件和施工任務狀態混合等，尚未被 10 月 26 日的 r2 藍圖以這些具體案例充分吸收。

### 建議採用的升級策略

工程裁決：`TARGETED_BLUEPRINT_UPGRADE`

## 高保留、局部升級、不重置架構

| 項目 | 裁決 |
|--------|--------|
| FHS-MSC 核心架構 | 保留 |
| PIPD／HGK／Hermes／Fabric／SBL 權責 | 保留 |
| 既有 949 項 R15.1 身份及產品覆蓋 | 完整保留 |
| 已有治理減負與 Bootstrap 設計 | 直接重用 |
| B1 新發現的執行控制缺口 | 受影補強 |
| 原始控制文件全套重寫 | 不採用 |
| 新 Scheduler、Issuer、Compiler、Policy DB | 不採用 |
| B1 施工案例作為正式反例測試 | 建議納入 |
| 升級版正式 Native 生效 | 仍須合法 Owner 與獨立驗收 |

我建議將修訂結果定位為 **`FHS-MSC Blueprint r2.1`（受影工程升級候選）**，而不是因一次 B1 停工就直接改成架構重新設計的 r3。

版本名稱只是建議，必須符合既有版本治理及 Owner 的有效裁決。

---

## 二、為什麼不是重新設計？

### 2.1 r2 已有針對長任務失效的完整根因樹

《FHS-MSC\_藍圖\_r2》第 1 章 §3.3 已將問題分為五個領域：

| r2 既有根因分類 | 已預先識別的問題 | 與 B1 的關係 |
|--------|--------|--------|
| A. Authority / Safety | Grant 遺漏、未知效果、Stage Permit 冒充 Live Permit、Maker 自驗收 | B1 Native Admission、信任及證據問題 |
| B. Durable Scheduler / Host | Queue 飢餓、Busy Scope、Session／Report 誤當結束、未知效果重播 | B1 Hermes r7～r10 的主要續航問題 |
| C. Activation / Drift | 候選未載入、Repo／PR／Loaded SHA 不一致、模型與 Binary 漂移 | B1 PR/CI 成功但 Native 不通過 |
| D. Duplicate Governance | 多控制入口、多 Compiler、角色被當成實體 Lane、分母外溢 | B1 治理過重及施工 Gate 錯置 |
| E. Candidate-to-Effective Adoption | 未完成 Promotion、Active Readback、Known Fix 重用 | B1 候選修補反覆停留於未驗收狀態 |

這不是事後從 B1 反推的分類。r2 在 2026 年 10 月 26 日就已正式寫入上述根因樹，並且在 §3.4 制定 RC01～RC27 的根因修補矩陣。fileciteturn0file24L142-L236

特別是其 B3 已明確指出：

`Session / Tick / Report 被誤當 Mission 的結束`

這與 10 月 27 日 B1 r10 提前產生報告、尚有工作未執行就停止的現象高度一致。

**裁決：這類根因不需要重新發明，只需把既有設計變成實際強制的 Runtime 規則與驗收測試。**

### 2.2 《FHS-MSC\_總討論》也早已處理治理過重

《FHS-MSC\_總討論》不同階段的工程決策，已經建立下列共識：

- §8（治理收斂）：刪除重複決策，而不是刪除真正必要的安全 Gate。
- §5（長任務）：使用有界 Closed Loop，不依賴模型無限重試。
- §5（FAR）：以 Finding Identity 重用已驗證修補，避免同一 Bug 反覆研究。
- §3（最小架構）：保留 HGK 原有 Queue、Issuer、Policy，不重造。
- §6（授權）：單一人類 Owner 可以有界委任，但不能由代理自簽權限。
- §8（MVP）：完整產品分母不得全部變成 SWOF PRE-W3 的阻斷條件。
- §5（Bootstrap）：先由受限 Codex 修復原生能力，再交還 HGK／Hermes。

最重要的是，總討論甚至已經明確指出，不能要求尚未修復的施工系統先使用自己尚未恢復的能力來修理自己。fileciteturn0file23L4483-L4515

這正是 B1 出現 Bootstrap 循環依賴時應採用的處置原則。

**所以，FHS-MSC 並非缺乏正確的高自動化治理思想。真正的問題是設計原則沒有一致、精確地傳遞到 B1 的執行契約與實際 Runtime。**

---

## 三、逐項交叉比對：B1 根因是否已被 r2 解決？

以下以先前 B1 鑑定報告的 RC-01～RC-25 為交叉索引。

判讀標準：

- **已完整設計：** r2 已有明確的權責、適用範圍及驗收原則；主要缺實機落地。
- **部分覆蓋：** 原則存在，但缺本次失效所需的具體執行或拒收契約。
- **需補強：** B1 提供了新的重要反例、介面問題或法位歧義。

| B1 根因 | r2 既有設計 | 交叉鑑定 | 建議 |
|--------|--------|--------|--------|
| RC-01 真 Hermes Executor／Wakeup | §12.5～12.6、§7.4、T16～T19 | 部分覆蓋 | 補真 Executor-to-Durable-State 驗收 |
| RC-02 READY 未盡即結案 | §3.3、總討論 §5.3 | 部分覆蓋 | 加入機械化 Terminal Gate |
| RC-03 Native HOLD 全域擴散 | §6.3 Degrade、§12.3 | 已完整設計 | 落地逐卡 Dependency/PARK |
| RC-04 Bootstrap 循環依賴 | §7.1、§7.4、CR-025 | 部分覆蓋 | 釐清維修／正式效果准入順序 |
| RC-05 Trust→Receiver 未接線 | §5.4、§7.4 | 需補強 | 增加 Trust Profile/Receiver Conformance |
| RC-06 Maker／Signer／Checker 未真正隔離 | §5.4、T23、§12.1 | 已有原則，部分技術缺口 | 增加同 SID 金鑰隔離反例 |
| RC-07 Design 誤當 Runtime Contract | §0.1、§5.1、§7 | 已完整設計 | 強制 Claim Ceiling 型別 |
| RC-08 缺真正局部依賴隔離 | §6.3、T11/T12 | 部分覆蓋 | 機械化 Affected Closure |
| RC-09 Fabric Activator／Loaded 未驗 | §5.5、T24 | 已完整設計 | 真 Stage/Active/Loaded 測試 |
| RC-10 模型 Required／Served 缺 Raw | §5.1、§14.5、T14 | 已完整設計 | 實機受影驗收 |
| RC-11 Oracle Canonical/P4 ABI | §5.1、CR-003 | 部分覆蓋 | 訂明相容性升版路徑 |
| RC-12 Profile 12／9 軸 | §5.1 | 已完整設計 | 執行逐軸正式映射 |
| RC-13 TQAEP Design／Live 混淆 | §5.1、§7.4 | 需補強 | 明確拆開測試定義與執行收據 |
| RC-14 Stage-C WriteSet 真失敗 | §14.3、§7.3、T26 | 需新增反例 | 導入 ADR-0008/0009 回歸案例 |
| RC-15 Commander-SP 入口衝突 | §5.2、§12.1 | 需補強 | 入口能力與特定 Mission 禁用條件分離 |
| RC-16 Effect Retry／Repair Retry | §12.3～12.4 | 已完整設計 | 落實不同計數器與證據 |
| RC-17 Full Product 分母外溢 | §3.2、§5.6、§11 | 已完整設計 | 不改寫，只正確使用 |
| RC-18 SourceFreeze／Issuer 循環前置 | §7、CR-001～025 | 部分覆蓋 | 引入分階段 Bootstrap Gate |
| RC-19 Candidate／CI 冒充 Native | §5.3、§7.3、T24 | 已完整設計 | 真 Raw＋Host Readback |
| RC-20 Manifest／Seal 與結案耦合 | §7.2、§14.3 | 需補強 | Manifest 不得驅動任務結案 |
| RC-21 Context 重複與恢復不完整 | §5.3、§12.5 | 部分覆蓋 | 建立 Resume Minimum Readset |
| RC-22 Administrator 過度泛化 | §6.1、§7.4 | 需補強 | User／Machine Trust 分級 |
| RC-23 Mandatory Method 過度調用 | §12、總討論 §8.1 | 部分覆蓋 | Capability Discovery／Mandatory Invocation 分離 |
| RC-24 `NOT_RUN`／`FAIL`／`HOLD` 混淆 | §7、§10～11 | 部分覆蓋 | 統一型別化結果語義 |
| RC-25 Native 原始收據及 AO 不齊 | §5.3、§14、T23～T25 | 已完整設計 | 補真實執行及獨立驗收 |

### 3.1 交叉比對的真正結論

從這 25 項可以得出以下工程判斷：

**第一，r2 沒有出現需要推翻核心架構的重大缺陷。**

大部分 B1 問題已在 r2 具有對應設計。

**第二，少部分 r2 條款仍須消除執行階段歧義。**

尤其是 Bootstrap 與 Live Effect 的准入差異、TQAEP 設計與收據的時序，以及中期報告與 Mission 結案的關係。

**第三，B1 最新的失效經驗應轉換成可執行的負例測試，而不是再增加大量抽象治理條款。**

**第四，真正的高優先工作是 Runtime 實現和驗收，而不是文件擴寫。**

如果只是增加十萬字規範，卻沒有修復 Hermes 真 Executor、HGK Receiver 及持久喚醒，那麼升級後仍可能重演 B1 的停工。

---

## 四、發現一：原始藍圖已經有自治閉環，但尚不足以防止 r10 式提前結案

這是本次最值得補強的部分。

### 4.1 《總討論》其實已有非常精確的續航規則

《FHS-MSC\_總討論》在長任務自動化的 §5.3 已經制定下列控制語義：

- 有合法 READY 工作時，繼續派工。
- 必要正式 Acceptance 全部閉合，才能請求 Mission Closure。
- 沒有合法 READY 工作但仍有阻斷時，保存 Durable Wait。
- Session Turn、Context Compaction、單卡完成、一般中期報告，均不得自行關閉 Mission。
- 持久續工由 Hermes／HGK Host 承擔，而非同一個 Chat Session 永遠保持開啟。

也已經提供可映射至真 Scheduler 的循環控制示例。fileciteturn0file23L1894-L1939

因此不能說 r2 的上游討論未考慮過這個問題。

### 4.2 r2 本身也有持久執行規範

r2 §12.5 已具備：

`ProposedDurableResumeCursor`

包含 Mission ID、HGK／Hermes Checkpoint、Worker Lease、Operation ID、Effect Observation、Next Legal Cards、Raw Worker Receipts 及 Resume Verification State。

它也禁止第二套 Scheduler DB，並要求使用真正已存在的 Hermes 持久化 API。fileciteturn0file24L1978-L2004

問題在於：**r2 並未把《總討論》§5.3 的完整終止決定規則，具體提升為所有 FHS-MSC 任務都必須遵守的可拒收 Termination Contract。**

### 4.3 B1 r10 證明這個缺口具有實際影響

r10 在仍有 R3、R4、Executor 等任務未執行時，就產生報告、Manifest 與外部 Seal；Hermes 自述沒有保持充分可恢復的實際工作卡。fileciteturn0file7L11-L20

這是 r2 有必要吸收的具體事故案例。

### 4.4 建議新增強制條款：Mission Completion Invariant

建議在 §12.5／§12.6 中增加下列控制。

| 執行狀態 | Runtime 必須作出的決定 |
|--------|--------|
| `READY > 0` | 禁止 Mission Complete，繼續合法派工 |
| `RUNNING > 0` | 禁止 Mission Complete，維持或調和 Lease |
| `READY = 0`，仍有待決合法依賴 | 保存 Durable Wait，註冊 Wake Conditions |
| 全部剩餘工作為有證據的外部阻斷 | 本輪可 PARK，Mission 不因此完成 |
| 必要工作已完成，但 AO／Native Gate 尚未通過 | `AWAITING_ACCEPTANCE`，不得宣告正式完工 |
| 所有適用 Required、已觸發 Conditional 與必要驗收真正通過 | 才允許正式 Closure Decision |

此處最重要的是分離：

`EXECUTION_CYCLE_CLOSED`、`MISSION_PARKED`、`MISSION_ACCEPTED`。

單次 Worker Tick 或聊天 Session 結束，不代表 Mission 接受完成。

**新增的反例必須是：`READY > 0` 時，即使已成功生成 Manifest／Seal，Mission Closure 仍被拒收，而且另一個合法 Worker 能繼續工作。**

這條規範不需要新 Scheduler；只需由現有權威狀態與合法 Reducer 執行。

---

## 五、發現二：Bootstrap 循環依賴早已被辨識，但 r2 有少數需要消除的時序歧義

### 5.1 正確解法已在 r2

r2 §7.1 已將施工分成：

`P0 唯讀鑑定 → P1 來源與發布整理 → P2 Bootstrap Repair Contract → P3 Codex 外援維修 → P4 HGK/Hermes 原生接管`。

其外援維修受限於既有 Native Permit；若 Native Issuer 不可用，僅可在合法 Owner 核准的一次性 Maintenance Procedure 下進行。fileciteturn0file24L417-L456

這個架構本身正確，無需改動。

### 5.2 但在 P2／P3 的敘述中存在執行歧義

例如，r2 §7.4 在 P2 準備最小控制包時，對 TQAEP 列出了 Maker／Checker 及 Raw Receipt 要求；而 §5.1 的 Assurance 階段，也將真正的獨立 Checker Execution 與編譯測試內容寫在同一處。fileciteturn0file24L1755-L1770

若這些要求被解讀成：

「在第一次合法修補執行前，就必須取得該次修補執行後才會產生的 Raw／Checker Receipt」

就會形成不可能的時序。

這不代表原規範必然要求錯誤行為，但目前文字容許錯誤解讀，B1 恰好顯示這類錯誤會實際發生。

### 5.3 建議明確分成四個階段

| 階段 | 允許的成果 | 不得冒稱 |
|--------|--------|--------|
| `PREPARATION` | Source、PI/PD Candidate、ECP、TQAEP Test Plan | 已執行測試或 Native PASS |
| `EXECUTION_ADMISSION` | 合法受影 ExecutionAdmission／HGK Permit 或有效 Maintenance Authority | 執行完成 |
| `EFFECT_EXECUTION` | 真 Worker 操作、Raw、Readback、Reconciliation | Independent Acceptance |
| `INDEPENDENT_ACCEPTANCE` | Checker 對已發生效果作驗證及正式 Verdict | 未獲准的 Release |

但必須注意：**不是所有工作都需要經過四個階段。**

純唯讀觀測、不造成外效的隔離測試、正式 Repo Mutation、Host Operations 和 User Data Effects 的法定前置條件不同。

Repository Mutation 仍須遵守適用的 PIPD ExecutionAdmission／WriteSet；不能因為屬 Bootstrap 就自行豁免。

### 5.4 建議修訂的原則

> Bootstrap Repair 必須具備完成自身最低必要維修工作的合法路徑。任何僅在後續執行、獨立驗收或 Release 階段才能產生的證據，不得被要求作為其自身尚未發生的前置收據。

若原生安全 Issuer 無法工作，只能依既有合法 Maintenance／Recovery 規範處理；不得自行建立永久例外。

此項應作為 r2.1 的正式時序修補，而非新增一套獨立的 Bootstrap 權威。

---

## 六、發現三：HGK Trust／Receiver 問題需要納入全域防回歸規範

### 6.1 r2 已要求真正 Native Admission，但對 Trust Profile 的落地差異規範不足

r2 §5.4 已定義正式 Native 授權、Issuer、Effect Ledger、Operation ID，以及真正的 WorkOrder／Permit／Readback 鏈路。

§7.4 也要求現場檢查實際 Receiver Schema、Binary、Import Path 與 Native Policy。

這些是正確的上位規範。

然而 B1 r10 出現更精確的工程情況：

- User-scoped Ed25519／DPAPI 候選測試通過。
- Trust Profile 指向使用者範圍。
- Receiver Registry 仍使用 Machine-scope 的 `%ProgramData%`。
- 真 Signed Bundle → Receiver Admit 尚未完成。
- 同一 Windows SID 下的多個 PID 不能直接視為相互獨立 Principal。

這是 r2 當時尚未具體捕捉到的反例。fileciteturn0file7L13-L19

### 6.2 建議新增 Trust Profile Resolution Contract

不應將 `%LOCALAPPDATA%` 寫死成全 FHS-MSC 唯一合法金鑰位置。

正確做法是要求 HGK 依不同 Effect Risk、OS Permission、Principal Isolation 及 Policy，提供可驗證的 Trust Resolution。

最小規範：

| 檢查對象 | 正式要求 |
|--------|--------|
| Trust Profile | 由可信 Policy／Owner 選定，有精確版本和作用域 |
| Signer | 真正擁有合法金鑰，不能由 Maker 假冒 |
| Receiver | 實際載入預期 Trust Profile，回報有效 Binding |
| Security Scope | User／Machine／Service 必須明確區分 |
| Principal Isolation | 不以不同 PID、模型名稱或角色文字自證獨立 |
| Admit | Signed Bundle 正向驗證且同 Subject |
| Reject | 錯 Key、Scope、Nonce、TTL、Revoke、Policy Epoch 必拒絕 |
| Readback | 由現役 Receiver 輸出，不能使用測試 Profile 值冒充 |

這項應放在 r2 §5.4、§7.4 及原本 Trust／Security 驗收對應位置。

**不得建立新的金鑰管理平台作為此次修復的預設答案。** 應先利用 HG-KSEOS 現有的 Trust／Receiver 能力，只有在現有系統確實不能滿足已批准的保證要求時，才考慮最小擴充。

---

## 七、發現四：需要把 Commander「產品能力」與「特定任務的禁用規則」解耦

這項問題不只是 B1 工程事故，也關係到 FHS-MSC 長期架構的適應性。

### 7.1 r2 的 Commander 規劃沒有錯

FHS-MSC r2 §5.2 與 §12.1 將 SBL Commander-SP 定位為受限的 Plan／Proposal 入口。

其不應自行發 Native Permit、不應取代 HGK Issuer，也不應自行簽署 Independent Verdict。

這是正確設計。

### 7.2 B1 的衝突來自任務適用性

B1 DOC-08 指定由 SBL `plan.propose` 提供 Golden WorkOrder 的 Proposal 入口。

但 r10 的當輪指揮明確禁止使用 `sbl-commander-sp`，包括安裝、載入及調用；合法替代入口又尚未取得實體驗證。fileciteturn0file3L15-L35 fileciteturn0file7L16-L17

因此出現：

**設計指定的唯一入口，在當輪任務政策下不可使用，卻沒有經核准的替代入口。**

這是契約相容性問題，不是代表 SBL Commander-SP 永遠應被取消。

### 7.3 正確的全域修正

應定義一個「Proposal 能力契約」，由合法 Owner 決定哪些實體入口可以提供候選。

可以保留三種路由類型：

| 路由 | 適用情境 |
|--------|--------|
| SBL Commander Proposal | Commander-SP 已正式准入且當輪允許 |
| 既有 HGK Native Proposal Adapter | 現役 HGK 具備相容入口並獲合法核准 |
| 最小非 Commander Proposal Adapter | 當輪禁止 Commander，且已取得受控修補與驗收 |

第三種目前只能視為**待查證或待實作選項**，不是聲稱已存在的系統功能。

每一個候選均只能輸出 Proposal，不授予 Permit。

**全域藍圖應保留 Commander-SP 產品能力；B1 的禁令則保留為該 Mission 的具名限制。**

不能把一次 Mission 的局部禁令，提升為整個 FHS-MSC 永久刪除 Commander-SP 的決策。

---

## 八、發現五：執行狀態、驗收狀態和證據封存必須徹底解耦

B1 r10 有一項特別值得升級到全域的教訓：

**文件、報告、Checkpoint、Manifest、Seal 與 Mission Completion 不可共用同一個終止語義。**

### 8.1 r2 已有真相分層

r2 已明確區分：

`DESIGN → STAGE → ACTIVE → LOADED → NATIVE ACCEPTED → CONSUMER VERIFIED`

也禁止用 CI Green、PR Open、Source SHA 相符或 Session Tick 冒充正式 Native PASS。fileciteturn0file24L2594-L2598

這一部分不需要再設計一套新 Evidence System。

### 8.2 應補的是 Runtime 與 Evidence 之間的控制邊界

建議在 r2 增加三個互不替代的維度：

| 維度 | 作用 |
|--------|--------|
| Work Execution State | READY／RUNNING／PARKED／DONE／需要修補 |
| Native Acceptance State | NOT\_RUN／BLOCKED／FAIL／PARTIAL／PASS |
| Evidence Publication State | DRAFT／SNAPSHOT／SEALED／VERIFIED／SUPERSEDED |

其中狀態名稱是建議的投影，不應擅自覆寫現有 HGK 原生 Enum。

還要具體規定：

- Report 可以在 Mission 尚未完成時產生，但應標示為中期報告。
- Manifest 可封存某次已觀測證據，不得使其他工作卡自動消失。
- Seal 只保證其覆蓋的位元與版本，不證明未收入的 Host Effect。
- Missing Receipt 與實際測試失敗必須分開。
- 若已知 Receiver 尚未實測，應明確記 `NOT_RUN` 或對應的 `BLOCKED`，不可推論 `RECEIVER_BROKEN`。
- 正式 Mission Closure 必須由真正有權的 Native Status／Acceptance Controller 計算。

### 8.3 特別防止「偽完工」

B1 r10 的 `native_artifact=false`、逐 ID Native PASS 0、R1/R2 PARTIAL，以及其餘多個 Gate BLOCKED，與部分程式碼及隔離測試成功可以同時成立。

這不是資料必然矛盾，而是不同法位、不同驗收分母的結果。

**應讓系統可以說明「已完成工程修補，但尚未通過 Native Acceptance」，而不是只能選擇全成功或全失敗。**

---

## 九、發現六：治理成本確實需要控制，但不應新增一套治理平台

### 9.1 既有《總討論》對此已經提出正確方案

《FHS-MSC\_總討論》§8.1 將以下事項分離：

- Mandatory Invariants
- Capability Discovery
- Method Selection
- Actual Invocation
- Nonselection Record
- Escalation

也明確指出，不應為治理收斂再建立新的 Governance Overlay、資料庫或 Scheduler。fileciteturn0file23L1127-L1166

r2 §3.5 的 Minimum-Sufficient Architecture／Overengineering Index 也已具備評估過度工程的工具。

因此，治理減負框架本身**不必重做**。

### 9.2 建議增加實際的 Governance Friction Measurement

目前欠缺的不是更多治理術語，而是可測量「某一 Gate 是否實際造成不必要等待」的方法。

應至少量測：

| 指標 | 用途 |
|--------|--------|
| Eligible Ready Count | 尚有多少合法工作能執行 |
| False Global HOLD Count | 單一卡受阻卻使其他工作停工的次數 |
| Repeated Owner Prompt Count | 有效預授權內仍重複詢問的次數 |
| Bootstrap Dependency Cycle Count | 依賴待修能力才能修復自身的循環數 |
| Candidate-to-Loaded Latency | 候選通過至真 Host 生效所需時間 |
| Autonomous Resume Success Rate | 不依賴新聊天指揮而自動恢復的比例 |
| Premature Completion Count | 還有 READY／RUNNING 工作卻宣告完成的次數 |
| Duplicate RCA / Repair Count | 相同根因反覆研究或反覆製作 Patch 的次數 |

這些指標應從已存在的 Journal、Scheduler、Gate、Receipt 等資料讀取，不應再建另一套人工維護的 KPI 真相來源。

### 9.3 不應把安全 Gate 誤列為無效率

需要明確區分：

**必要阻斷：** 無有效 Permit 而阻止實際 Host 寫入。

**不必要阻斷：** 因某張 Host Effect 缺 Permit，而阻止完全不依賴它的合法唯讀診斷。

前者是正確安全治理，後者才是應消除的自動化阻力。

此外，若原始 HGK Policy 明定某方法為 Mandatory，就不能由 FHS-MSC 的效能優化計畫單方將其改成 Optional。

治理減負只能移除重複查詢、錯誤套用與無增量價值的步驟；正式強制規則的變更仍屬原 Policy Owner 權責。

---

## 十、建議的 r2.1 升級內容與原文修改位置

本次建議採用 **12 項受影升級**，而不是產出整份重新改寫的藍圖。

### 10.1 升級項目總表

| 升級 ID | 優先度 | 建議整合至 r2 章節 | 修補內容 |
|--------|--------|--------|--------|
| FHS-U01 | P0 | §12.5～12.6、§7.4 | Durable Mission Termination Contract |
| FHS-U02 | P0 | §7.1～7.5、§5.1 | Bootstrap／Engineering／Native Effect 階段准入與時序 |
| FHS-U03 | P0 | §6.3、§5.6 | 逐 WorkOrder Dependency、局部 PARK 與可恢復條件 |
| FHS-U04 | P0 | §12.5、§7.4 | 真 Hermes Executor、Wakeup、Cross-Process Resume |
| FHS-U05 | P0 | §5.4、§7.4 | HGK Trust Profile／Receiver／Principal Isolation |
| FHS-U06 | P1 | §5.2、§12.1 | Commander Proposal Capability 與 Mission 禁用條件分離 |
| FHS-U07 | P1 | §5.1、§7 | PIPD Oracle／Profile／TQAEP Design-Live 相容性 |
| FHS-U08 | P1 | §5.3、§7.2、§14.3 | Execution／Acceptance／Evidence Publication 分離 |
| FHS-U09 | P1 | §12.3～12.4 | Diagnostic／Repair／Effect Attempt 分別計數 |
| FHS-U10 | P1 | §3.2、§5.6、§11 | FHS MVP／B1／Full Product 分母適用性 |
| FHS-U11 | P1 | §12、§14.5 | Required／Served、Mandatory Methods、Host Effective Load |
| FHS-U12 | P1 | §3.5、§7、§11 | 最小恢復讀集、去重 RCA、治理成本與實際成效測量 |

其中 U01～U05 最有必要從一般設計原則提升為機械化控制契約。

U06～U12 多數已存在上位設計，不應再複製大段原文，而是補上 B1 新的反例及具體拒收條件。

### 10.2 哪些內容應保持完全不變？

以下為不可因本次升級而任意改動的設計邊界：

| 原設計 | 裁決 |
|--------|--------|
| Fabric = Policy／Governance | 保留 |
| HG-KSEOS = 唯一 Native 控制權威 | 保留 |
| Hermes = 持久執行與 Worker Orchestration | 保留 |
| PIPD = Canonical Pre-Implementation／Pre-Dev Writer | 保留 |
| SBL = Product／Proposal／User Outcomes | 保留 |
| FAR = 研究、根因、候選修復建議 | 保留 |
| Codex = 有界工程 Writer／Bootstrap Repair | 保留 |
| Independent Checker = 真實獨立驗證 | 保留 |
| PLAN／EXECUTE／VERIFY\_SECURITY 三實體 Lane | 保留 |
| 四能力 TPM／Commander／EXECUTE／Challenge | 保留 |
| R15.1 原始產品身份及分母 | 保留 |
| R17 原始 Mission 及歷史證據 | 保留 |
| SWOF W2／PRE-W3／Formal W3 法位 | 保留 |
| Full Product 與 MVP 分開驗收 | 保留 |

因此，升級應是 **現有體系內的契約收斂，而不是架構重置**。

---

## 十一、另一項必須防止的重工：三種不同 Mission 不能再混算

本次分析還需要補充一個容易被忽略的問題。

FHS-MSC 整體目標、B1 Bootstrap Repair，以及 SBL Full Product 並不是同一個 Mission。

### 11.1 三種任務的驗收範圍不同

| Mission | 主要退出條件 | 不應自動繼承 |
|--------|--------|--------|
| FHS-MSC MVP | Native 最小施工能力有效，SWOF PRE-W3 合法只讀接軌 | 全部 SBL Full Product Release |
| B1 Bootstrap Repair | B1 適用 Required／Conditional、T2、R1～R4、G-A、三 GWO、G-B | 所有其他產品無關的延伸功能 |
| SBL Full Product | 原始 R15.1 產品成果、各 Host/Mode 的正式產品驗收與 Release | 將單一 B1 修復成功冒充產品全面完成 |

《FHS-MSC\_總討論》已將 MVP 最小成果具體拆分為 MVP-01～MVP-08，其中包含來源一致、PIPD Contract、HGK Native Permit、Hermes Durable Worker、Codex Scoped Repair、Candidate Activation、Independent Evidence，以及 SWOF PRE-W3 消費。fileciteturn0file23L4188-L4229

這個定義本身不必修改。

### 11.2 建議補強的是 Mission 適用性計算

全域管理必須能回答：

- 一項 Gate 是 FHS-MSC MVP 的強制條件，還是 B1 自身的驗收條件？
- 它是否被具名的上位契約正式要求？
- 某個 Conditional 是否已被實際觸發？
- 一個產品 Deferred 項目是否與當輪 Bootstrap 沒有依賴？
- 某項缺少 Raw 是真正執行失敗，還是工作尚未排程？
- 該阻斷會影響哪些 WorkOrders，而非所有 Mission？

建議每個 Gate 投影至少具備：

`mission_id / source_requirement_id / owner / applicability / effect_class / dependency_refs / required_when / status / first_fail / raw_ref / unblock_condition`

但這應使用原生 Registry 的合法讀取投影，不得創造第二個具有裁決權的 Gate 系統。

### 11.3 949、1,565 與其他分母不得混合

FHS-MSC r2 保存的 949 個 R15.1 來源身份，是一組產品及工程設計覆蓋分母。

B1 r10 交接的 1,565 身份，則是另一組整合後 Ledger，包含 625 Required、285 Conditional、655 Deferred。

它們並非同一套身份空間，不能直接相加，也不能以其中一套覆蓋另一套。

r2 已有防止分母縮減的設計；r2.1 只需要補上跨 Mission 的身份映射與適用性，而不應重新產生龐大的產品需求表。

---

## 十二、升級實施方案：不要讓「優化藍圖」再次阻斷真正施工

### Wave 0：確立基線及差異

**性質：純文件鑑定及合法唯讀工作。**

保留 r2 原文、檔案身份、來源 SHA、現有 Requirement IDs、Original Writer 和 Claim Ceiling。

建立 B1 根因與 r2 現有章節的差異清單，對已存在且有效的條款標記 `REUSE_AS_IS`，不重複改寫。

**出口：** 每一個升級項都能指出原條款、B1 失效反例、需要修補的精確語義，以及是否會改變上位權責。

### Wave 1：修訂 r2 的少數執行契約

**性質：文件設計升級，不是 Native 生效。**

優先落實 U01～U05，再處理 U06～U12。

每項修改都應包含具體輸入、合法操作、拒收行為、狀態轉移、負例、恢復條件及生效 Owner。

**出口：** r2.1 形成可供既有 PIPD／HGK／Hermes 消費的精確契約，不新增第二個控制權威。

### Wave 2：產生薄型 B1 Execution Profile

**性質：受影執行投影。**

從 r2.1 及 B1 DOC-00～08 抽取當前 B1 真正需要的工作、Gate、依賴、適用性、效果與驗收條件。

保留 B1 上位原始文件，不把其整份 21,000 多行內容塞進每次 Hermes 工作卡。

**出口：** 一份能依合法 Reader 查詢及重新生成的執行投影，而非新的 Canonical Source。

### Wave 3：原生 Runtime 最小修復

**性質：需有真正有效的施工授權。**

以目前尚未完成的 Native 閉環為主，優先：

`SharedSpine → Hermes Executor → Durable Wakeup → HGK Receiver → Effect Readback → Independent Checker`

同時針對 Fabric、Model Routing、PIPD 和 SBL 的已證實缺口進行最小修補。

不能因為 r2.1 文件完成，就跳過 Host 探測直接宣稱所有缺陷已定位。

**出口：** 真實 Worker、Host、Receiver 和 Checker 的可重現執行證據。

### Wave 4：執行 B1 回歸與原生接管

**性質：獨立測試及正式 Native 驗收。**

依真實適用的 B1 Gate 完成 T2、R1～R4、G-A、三 Golden WorkOrders、G-B。

測試除正常流程外，必須包含提前封存、未知效果、撤銷外援、重複 Claim、錯誤 Model、錯 Trust 等負例。

**出口：** 真實 Native Acceptance；若仍缺必要證據，就保持具名 HOLD，不能以文件修訂代替。

### Wave 5：將實測結果回饋全域藍圖

**性質：增量修訂與正式設計評估。**

僅將證實具有跨 Mission 普遍性、且原藍圖不足以防止的失效模式納入全域規範。

純 B1 個案資訊則留在 B1 Regression／Runbook，不需要全部複製到上位藍圖正文。

**出口：** 高保留修訂、原本設計身份不遺失、正式 Gate 不被降級、實測資料可供日後復用。

這五個 Wave 是完整升級工作的分類，不是要求所有無關工程必須串行等待。合法且互不依賴的工作可並行處理。

---

## 十三、建議新增的全域 B1 防重演驗收測試

r2 原有 C00～C24、R14 CheckRuns、T01～T36 等測試身份均應保留。

下列是建議新增的專項回歸案例，使用獨立的建議命名空間，不取代任何 Canonical Test ID。

| 新增測試 | 必須證明 | 失敗時拒收 |
|--------|--------|--------|
| FHS-B1-REG-01 | READY 任務未耗盡，不能 Mission Complete | Premature Closure |
| FHS-B1-REG-02 | A 被 PARK，無關 B/C 繼續執行 | False Global HOLD |
| FHS-B1-REG-03 | 中期 Report／Seal 不改變合法 READY 狀態 | Report-driven Stop |
| FHS-B1-REG-04 | Worker 結束後，新 OS Process 真正恢復工作 | No Native Continuation |
| FHS-B1-REG-05 | Scheduler Tick 不等於真 Executor 進展 | False Durable PASS |
| FHS-B1-REG-06 | 受治理 Permit 不可用時，合法獨立工程仍能依其自身准入運行 | Bootstrap Deadlock |
| FHS-B1-REG-07 | User Trust Profile 被現役 Receiver 真正載入 | Trust Binding Missing |
| FHS-B1-REG-08 | 相同 SID 的多 PID 不能冒充獨立 Principal | False SoD |
| FHS-B1-REG-09 | 當輪禁止 Commander 時，不會經該入口派工 | Forbidden Entry Invoked |
| FHS-B1-REG-10 | Stage-C 超出 WriteSet 的變更仍被拒收 | False CI PASS |
| FHS-B1-REG-11 | Design TQAEP 不要求尚未執行效果的 Live Receipt | TQAEP Lifecycle Deadlock |
| FHS-B1-REG-12 | Fabric Stage、Active、Loaded、Consumer 不互借收據 | False Activation |
| FHS-B1-REG-13 | 三 Lane Required／Served 不符即拒絕相應 Gate | Silent Model Substitution |
| FHS-B1-REG-14 | UNKNOWN\_EFFECT 不被盲目重播 | Duplicate Effect |
| FHS-B1-REG-15 | Manifest／Seal 不代替 Native AO 或 Handoff | False Acceptance |
| FHS-B1-REG-16 | 完整產品、B1 與 FHS MVP 分母不被互相取代 | Denominator Regression |

其中 REG-01～REG-06 應作為高自動化 Runtime 的優先負例。

這些案例可以沿用既有測試 Runner、Fixture、TQAEP 和 Checker；不需要為 B1 專門建造新的測試平台。

---

## 十四、正式升版前的風險與驗收條件

即使 r2.1 的文字修訂全部完成，也不能立即稱為正式可執行的 Native 藍圖。

r2 自己已經明確標示 `DESIGN_REPAIR_CANDIDATE / NO_RUNTIME_AO / NO_RELEASE`，並保存 CR-ORACLE、SourceFreeze、Host Binding 等缺口。fileciteturn0file24L1-L18

建議把升版完成分為三個不同層級：

| 層級 | 完成條件 | 允許宣稱 |
|--------|--------|--------|
| Blueprint Design Upgrade | U01～U12 有受影正文、Trace、正反例及衝突處置 | 設計升級候選完成 |
| Execution Contract Qualification | Owner 核准合法契約映射，對應原生工具及 Schema 測試通過 | 相關執行契約具資格 |
| Runtime／Native Acceptance | 真 Host／Issuer／Worker／Checker／Gates 按實際適用範圍全部通過 | 해당受影 Native 能力正式通過 |

不應把第二或第三層級的完成條件，反過來無條件當作第一層級作者端設計工作的前置條件。

同樣，也不能因第一層完成，就自動宣稱第二、第三層成功。

### 升級必須通過的七個全域審查

1. **Authority Non-Regression：** 無第二 Issuer、Compiler、Policy Writer、Checker。
2. **Product Non-Regression：** 原有 949 R15.1 身份、WorkPackages、Checks、完整產品義務不遺失。
3. **Scope Non-Regression：** B1、FHS MVP、Full Product 的適用性不被錯誤縮減或擴張。
4. **Safety Non-Regression：** 真 Native Effect 仍須合法權限、同主體證據、有效隔離和拒收。
5. **Autonomy Regression：** 合法 READY 能自動執行，單卡 HOLD 不造成無故全面停工。
6. **Evidence Non-Regression：** PR／CI／Manifest 不自動升格為 Host Loaded、World Effect 或 Independent Acceptance。
7. **Engineering Economy：** 不額外建立永久治理平台，不重做已有效的 Scheduler／Compiler／Trust／Source Registry。

若某項新增設計無法指出要消除哪個具名故障、沒有對應反例或帶來不可避免的第二控制權威，原則上應拒絕納入 r2.1。

---

## 十五、最後工程裁決：究竟需不需要升級《FHS-MSC\_藍圖\_r2》？

### 15.1 是否已經包含大部分 B1 解法？

**是。**

《FHS-MSC\_總討論》與《FHS-MSC\_藍圖\_r2》已經提供正確的架構、治理及自治施工核心設計。

這次 B1 並沒有證明整套 FHS-MSC 架構選型錯誤。

### 15.2 是否完全不需要修改？

**不是。**

B1 暴露出部分規範雖然存在，但仍未充分消除時序歧義、強制結案語義不完整、Trust Profile 接線缺少特定反例，以及 Mission 入口適用性衝突。

這些問題不宜只停留在 B1 專案的修復報告中，否則下一個使用同一上位藍圖的施工專案仍可能以相同方式誤用。

### 15.3 是否應全面升級為一個新架構？

**不建議。**

核心正確做法應是：

`保留 r2 → 提取 B1 有效教訓 → 原文受影修訂 → 補 Runtime 反例 → 實機驗證 → 版本化生效`

而不是：

`發現 B1 失效 → 重建 FHS-MSC 架構 → 重寫 PIPD/HGK/SBL → 重新設計所有 Gate → 再次 Bootstrap`

後者將再次導入大量工作與治理依賴，違反 r2 原本追求的 Minimum-Sufficient Architecture。

### 15.4 是否應把整份《FHS-MSC\_總討論》直接融入 r2？

**不建議照單全文整合。**

《總討論》包含七輪不同階段的歷史工程決策，其中部分觀點已在後續輪次經過修正；r2 也已經完成過一次高保留整合。

正確做法是以 r2 為受審設計基線，從《總討論》抽取尚未明確寫成正式契約、且經 B1 實證支持的條款。

例如，總討論 §5.3 的 Mission Termination 語義就值得正式納入 r2；但七輪不同版本的架構圖、Prompt 和歷史裁決，不應全部重新複製。

### 15.5 是否應立即將升級後的 r2 作為新施工上位規範？

應分開處理。

**設計分析方面：** 本報告已支持啟動 r2.1 的受影修訂。

**正式規範方面：** 仍須經既有 Owner、PIPD／HGK 對應權責與版本生效程序，不能由本次分析自動覆寫 r2。

**工程施工方面：** 不應為了等待整份 r2.1 文件升級而停止 B1 其他已合法准入、互不依賴的工作。可以用既有有效控制包繼續施工，並對真正受新契約影響的項目進行版本化重驗。

---

## 十六、最終建議

## 建議正式採納的唯一修復方向

**`FHS-MSC r2 → r2.1 TARGETED CONTRACT HARDENING`**

---

**保留現行架構**

不重新設計 PIPD、HGK、Hermes、Fabric、SBL 的權威與控制平面。

**抽取 B1 實際事故**

將 RC-01～RC-25 對應至上位條款；只修未覆蓋、未強制及互相衝突的部分。

**先修五個 P0 控制缺口**

Termination、Bootstrap Gate、Dependency/PARK、Hermes Native Continuation、HGK Trust/Receiver。

**以實際 Runtime 验證代替新的大型文件治理**

將 r10 提前結案等失效轉成具名負例測試，並由真 Host、真 Receiver、真 Checker 產出收據。

### 最後總結

本次交叉鑑定最重要的發現是：

**FHS-MSC r2 的主要架構並未失敗；B1 施工失敗反而證明 r2 已識別的風險是真實且值得治理的。**

真正需要改進的是從設計規範到可執行契約、從契約到原生 Host，以及從工程成果到獨立驗收的連續性。

因此，最適當的決策不是「整份藍圖不必動」，也不是「整份藍圖重新設計」。

而是：

**高保留升級少數關鍵條款、移除階段錯置、保留全部必要安全控制、補強可機械執行的自治閉環，並以 B1 的真實失效反例防止下一個施工任務重演。**

本報告為基於現有 r2、總討論及 B1 交接紀錄的跨文件工程鑑定；未修改原始藍圖，也未宣稱升級條款已由 Native Owner 正式生效。

## Prompt:
2026/10/27 下午11:38:27

你的角色：
你是「HERMES / FABRIC / SBL / HG-KSEOS」高自動化任務運行總工程師。

任務目標：
你必須整合前輪分析規劃，再對《HERMES_B1_任務回報》，進行專業工程的「深度研究 + 交叉比對 + 分析評估 」，目前HERMES / FABRIC  / HGK / SBL對於直接承接並執行各種「PIPD-LS-PKG」，是否存在「治理過度、鏈路不順、高自動化不佳、語意理解欠佳、無法主動提供最佳建議.....等等的問題?你必須進行分析並提出各種現存的問題，並分析其根因。

是否《FHS-MSC_藍圖_r2》、《FHS-MSC_總討論》其實都已經包含這些問題的解法，不必再次重複設計?或是原本「SBL_PIPD-LS-PKG」的設計規劃之中，這些問題其實都是Native commander尚未實作完成的應有功能和目標?

如何讓HERMES / FABRIC  / HGK / SBL遇到問題、待裁決/授權、阻斷時，會主動自動使用FAR進行研究，並提出最佳工程建議，讓用戶不必每次都輸入PROMPT，就可以直接參考FAR研究出的最佳建議，並且讓HERMES / FABRIC  / HGK / SBL最後提出FAR研究過後的選項，用戶直接點擊就可直接執行。

任務要求：

你必須針對任務目標，並對全部相關資料進行「研究分析+交叉比對」，再進行鑑定、評估、規劃，並提出完整報告。

最後你必須直接以文字提出完整報告。

[Attachment: HERMES_B1_任務回報.md]

## Response:
2026/10/27 下午11:38:40 · gpt-6-thinking

我會先核對《HERMES\_B1\_任務回報》中的實際執行、未完成項、FAR 裁決與授權狀態，再對照 FHS-MSC r2、總討論及 SBL／PIPD 的既有 Native Commander 設計。報告會特別區分「設計已具備但尚未實作」、「現有執行鏈路確實有缺口」與「需要新增的 FAR 主動研究、建議及一鍵執行能力」，避免把已存在的功能重新設計一次。

已確認《HERMES\_B1\_任務回報》的關鍵變化：Hermes 從最初只完成清冊抽取，進展到在隔離環境執行 PIPD 編譯、11/11 設計複核與三張沙箱 GWO；但 30 條 Native Runner Route、G-B 真接管、Canonical 修補與正式驗收仍未閉合。更關鍵的是，FAR 已在使用者明確要求後修正了 Hermes 先前不精確的授權順序與 `effect_class` 建議——這證明 FAR 有實質工程價值，也顯示目前缺的是「事件觸發 FAR、形成可裁決選項、再交原生執行」的自動接線。

交叉比對已確定：FHS-MSC r2 §6.2、《總討論》§5.2～5.6，以及 SBL DOC-04 C14，已分別定義 FAR 事件觸發、研究／修補決策和 Commander 的 C0～C9 工作。Fabric GitHub 也有真實的 FAR `ProposedEvolution.yaml`，但仍標示 `PROPOSAL_ONLY`。因此我會把最終方案集中在三個尚未閉合的實作層：事件訂閱與去重、FAR 建議轉換成可核准的決策卡，以及點選後由 HGK 合法發行並讓 Hermes 自主恢復的完整鏈路。

> **檢視 HERMES 任務回報檔案**
>
>
> **檢視 HERMES 回報並擷取 FAR 治理結論**
>
> 
>
> **檢查專案文件與決策流程實作**
>
>
> **檢查專案文件與決策流程實作**
>
> 
>
> **釐清驗證範圍**
>
> 我正在區分機械式擷取與實際行動，並檢查權限、簽署、版本時間與文件自我引用。候選版本的觀察不能直接套用到現行文件；路徑不一致與未獨立驗證的數據也需保留疑問。
>
> **釐清驗證範圍**
>
> 
>
> **規劃自動化報告**
>
> 我會先確認現有程式庫與文件能證明什麼，再區分「未找到證據」與「確實不存在」。報告將釐清元件、權限、觸發條件、批准流程與執行邊界，並提出分階段方案與驗收指標。
>
> **規劃自動化報告流程**
>
> 
>
> **完成架構規劃**
>
> 我正在補齊現有能力與缺口矩陣，並設計觸發、去重、權限、批准、執行與回滾流程。重點是讓預先授權的低風險操作可一鍵完成，但新簽署或高權限動作仍需明確確認。
>
> **完成架構規劃**
>
> 
>
> **搜尋並驗證 Fabric RCA、研究請求及 SBL 原生部署設計**
>
> 
>
> 處理時間為 7m 4s

# HERMES／FABRIC／HG-KSEOS／SBL 承接 PIPD-LS-PKG 高自動化失效與 FAR 主動決策閉環--完整工程鑑定及升級方案

鑑定基準：2026 年 10 月 27 日｜分析對象：《HERMES\_B1\_任務回報》、FHS-MSC r2、FHS-MSC 總討論、SBL\_PIPD-LS-PKG DOC-00～13、PIPD\_LS DOC-00～09、B1 DOC-00～08 及前輪根因報告

## 一、最終工程裁決

**目前 HERMES／FABRIC／HG-KSEOS／SBL 對於直接接收 PIPD-LS-PKG、理解施工目標、自主執行、遇阻主動研究、提出最佳建議、取得必要授權及恢復執行，確實存在系統性缺口。**

但必須精確區分三件事：

1. **設計是否存在：** FHS-MSC r2、《總討論》及 SBL\_PIPD-LS-PKG，已經設計了絕大部分必要功能。
2. **功能是否落地：** 目前沒有充分證據證明這些功能已形成現役 Native 端到端閉環。
3. **是否需要新架構：** 不需要重建 FAR、Native Commander 或 HGK 控制平面；主要需要接通原有介面，補足少量產品互動契約、Runtime 控制及可拒收的驗收測試。

### 核心結論

整體成熟度裁決

| 文件解析、需求清冊與設計編譯 | (已有實測成果) |
|--------|--------|
| FAR 根因研究與方案修正 | 已有人工觸發案例 |
| Native Commander 自動規劃與接管 | 完整鏈路未驗收 |
| 問題事件自動觸發 FAR | 缺現役證據 |
| FAR 建議自動送達使用者 | 缺可驗證閉環 |
| 使用者點選建議後原生執行 | 尚未證明已實作 |
| 完整 Native Effect／Checker／G-B | 仍未完成 |

**我建議的唯一主工程方向是：**

`PIPD-LS-PKG Native Intake → Semantic Contract Interpretation → Native Commander Planning → HGK Admission → Hermes Execution → Event-driven FAR → Ranked DecisionPack → Owner Action → Native Execution／Resume → Independent Verification`

這條鏈路的主要元件在原始設計中都已有所屬權責。

真正應補強的是四個關鍵接面：

- **接收面：** PIPD-LS-PKG 如何被理解為實際 Mission，而不只是被轉換為大量清冊。
- **自治面：** Hermes 如何對合法工作持續執行，不因個別 HOLD 或報告完成而停止。
- **研究決策面：** HGK／Hermes 如何自動將故障、阻斷及待裁決事件交給 FAR，並取得可操作、附證據的最佳建議。
- **使用者操作面：** 如何將 FAR 的建議轉換成簡明選項，使使用者經一次有效點選即可進入合法審核及執行流程，而不是反覆撰寫 Prompt。

**FAR 應主動研究及推薦；Native Commander 應負責計畫及操作編排；HGK 負責准入；Hermes 負責持續執行；使用者只介入真正需要其權限的決策。**

不應將這些能力再合併成一個可以自行研究、授權、修改、執行及驗收的超級 Agent。

---

## 二、《HERMES\_B1\_任務回報》揭露的實際能力與失效現象

這份文件非常重要，因為它不只是施工結果，也包含 Hermes 對自己為何沒有完成任務的承認，以及 FAR 介入後對錯誤裁決的修正。

### 2.1 第一階段：Hermes 把施工任務錯誤縮減成文件整理

使用者原始要求是完整實作 B1 DOC-00～08，包括自動化施工、檢測、修補、迭代及驗收。

Hermes 第一階段主要完成：

- 27 Requirement Atoms、31 Work Slots、120 Parent Tests、124 Child Cases。
- 38 Node Conformance、949 R15 身份、192 Product Cells、81 Assets。
- KANBAN 14 卡，其中 12 Done、2 Blocked。
- `pipd doctor`、OpenSpec 等有限的唯讀檢測。
- 42/42，後續報告為 44/44 的清冊／機械檢查。

這些成果是真實的工程準備工作，但並非使用者要求的施工完成。

Hermes 後續自行承認，原本可以進行的 R1～R4 唯讀探測、隔離 PIPD 編譯、受控程式碼修補及 OpenSpec 提案並未進行。

**根因不是文件一律禁止施工，而是執行系統將部分 Native 權限缺口錯誤擴大為整體任務無法進行。**

這同時暴露了兩個問題：

**治理問題：** `Native Effect Not Admitted` 被誤解成所有合法工程都不能動。

**語意問題：** 「完整執行九冊」被降格成「逐項抽取並對帳九冊」。

這是 Mission Intent 與工作卡生成之間的語意落差，並不只是缺少某個 CLI。fileciteturn3file0L1-L89

### 2.2 第二階段：工具鏈實際有進展，但無法自行完成閉環

在使用者再次授權後，Hermes 據報取得以下進展：

| 工程項 | 報告結果 | 正確解讀 |
|--------|--------|--------|
| PIPD 真工具鏈 | 13 動詞執行 | 有效編譯能力獲得改善 |
| Design Checker | 11/11 PASS | 設計／契約複核，不是 Native Acceptance |
| PIPD Validation | 4 契約 PASS | 只覆蓋當輪四項契約 |
| G-A | 6/6 PASS（設計級） | 不可冒稱正式 Native G-A |
| GWO | 沙箱 3/3 | 不等於三張真實 Native GWO |
| KANBAN | 19 Done／3 Blocked／0 Ready | 工作卡狀態，不等於 Mission 完成 |
| Runner Routes | 30/30 BLOCKED | 缺 Owner-registered Runner Registry |
| G-B | HOLD | 真 Native Successor 尚未完成 |
| Canonical Patch | 尚未落地 | 修補仍在隔離複本 |
| SourceFreeze／Release | 未完成 | 不可升格正式發行 |

其中一項實際缺陷尤其值得注意。

Hermes 原先要求驗證車道使用 `gpt-6.1-sol`，但透過 Desktop Router 執行時，實際 Served Model 曾被路由至 DeepSeek，導致一次驗證失去預期的模型隔離性。

後續雖據報改用 OpenAI 直接路由並確認 Served Model，但這仍不能證明作業系統 Principal、金鑰、收據及正式 Checker 權限真正隔離。

**模型身份正確不等於法律或安全上具備獨立驗收權限。**

這代表 Hermes 對「Requested Tool／Model」和「Actual Effective Tool／Model」的辨識必須由 Runtime 收據驗證，而不能只靠 Prompt。fileciteturn3file0L95-L136

### 2.3 第三階段：FAR 介入後，工程裁決品質明顯改善

Hermes 原先提出的四件 HARD Blocker 執行順序為：

`C → A → B → D`

即：

Canonical Schema Patch → Runner Registry → Native Issuer／Queue → Freeze／Acceptance／Release。

這個方向包含部分正確的依賴，但仍未充分處理 Canonical Vocabulary、SourceFreeze、Native PIPD 狀態機及授權歸屬。

使用者要求 FAR 研究後，FAR 提出三項關鍵修正：

1. 不能把設計級 Checker PASS 當作 Native Effect 後的正式 Independent Acceptance。
2. `effect_class` 欄位與四個具名值的權威來源不同，不能把 B1 的四值分類直接硬編進 PIPD Canonical Schema。
3. Runner Registry 應採 Owner 簽署的 Registry Snapshot／BOM，不應要求使用者逐條臨時簽署 30 條路由。

隨後 FAR 建議：

- S1：有界 Schema 變更，四值語彙保留待 Owner 裁決。
- S2：先簽一條唯讀 Runner Canary，成功後再處理其餘 29 條。
- S3：指定真正不同於 Maker 的 Native Issuer Principal。
- SourceFreeze／Release 不應提前簽認。

這套修正比 Hermes 原先要求使用者直接批准全部硬性阻斷更精確。

**最重要的觀察：FAR 已經展示出可改善工程建議的價值，但它是在使用者另外提出明確研究指令後才啟動。** fileciteturn3file0L187-L236

這也是本次最值得解決的高自動化缺口。

### 2.4 截至該份回報最後一行的嚴格狀態

文件最後記載使用者授權採納 FAR 的三項簽章建議。

但文件沒有進一步提供 S1、S2、S3 已經在真正 Native Owner 流程中完成簽署、部署及執行的結果。

所以不能據此宣告這三項已落地。

本報告將它們視為**已獲使用者文字表達支持的決策方向，正式簽章與原生效果仍待實際紀錄核實**。

---

## 三、完整根因鑑定：為什麼 PIPD-LS-PKG 無法被高效率地直接執行？

### 3.1 根因矩陣

| ID | 現存問題 | 嚴重度 | 證據性質 | 主要責任層 |
|--------|--------|--------|--------|--------|
| R-01 | 「完整執行」被縮減成清冊解析與文件對帳 | P0 | Hermes 自述 | Native Commander／Mission Compiler |
| R-02 | 只有任務要求，缺可執行的完整工作範圍閉合 | P0 | B1 執行結果 | Commander／Scheduler |
| R-03 | 缺 Native Permit 時，合法隔離工程也被一起停掉 | P0 | Hermes 自述 | Gate Applicability |
| R-04 | 沒有自動啟動 FAR 的可驗證事件閉環 | P0 | 設計與實作證據落差 | HGK／Hermes／FAR Adapter |
| R-05 | FAR 結果未自動變成使用者可選擇的決策 | P0 | 工作流程缺口 | Commander／SBL UX |
| R-06 | 等待 Owner 時缺持久、一次性的決策請求 | P0 | B1 反覆 Prompt | HGK State／Approval |
| R-07 | 未形成合法的點選後原生執行閉環 | P0 | 尚未取得 E2E 收據 | UI／HGK Receiver／Hermes |
| R-08 | 設計 Checker PASS 易被理解為正式驗收 | P0 | 回報存在先誤述再更正 | Evidence／Claim |
| R-09 | 不同模型被誤當成不同安全 Principal | P0 | 路由及 SoD 案例 | Security／Checker |
| R-10 | `effect_class` 欄位與四值語彙的權威混淆 | P0 | FAR 修正 | PIPD Schema Governance |
| R-11 | 30 條 Runner Route 無已簽 Registry | P0 | 回報支持 | Registry／Native Admission |
| R-12 | G-B 真 Issuer／Durable Successor 尚未驗收 | P0 | 回報支持 | HGK／Hermes |
| R-13 | Canonical 修補仍在隔離複本 | P1 | 回報支持 | PIPD Publisher／Adoption |
| R-14 | PIPD 文件候選與本機實際來源不一致 | P1 | Hermes 回報 | Source Resolver |
| R-15 | 部分候選的 supersession digest 語義不正確 | P1 | Hermes 回報 | Artifact Lineage |
| R-16 | Codex／GStack 工具欠缺時沒有適當替代建議 | P1 | 早期回報 | Capability Resolver |
| R-17 | 模型 Required／Served 被 Router 改寫 | P0 | Hermes 回報 | Provider／Model Router |
| R-18 | 每輪 Checker 大量重讀，消耗資源 | P1 | Hermes 成本回報 | Context／Evidence Reader |
| R-19 | FAR 介入前的授權建議過早要求全面簽署 | P1 | FAR 前後對照 | Decision Planning |
| R-20 | Canonical 改碼、Registry、Queue 等被過度串行化 | P1 | Hermes 原排程與 FAR 修正 | Dependency Planner |
| R-21 | 缺完整的可反駁方案比較與推薦排序輸出 | P1 | FAR 尚以報告形式交付 | Recommendation Contract |
| R-22 | 已完成設計與未完成 Runtime 混為工作完成度 | P1 | B1 工作卡與 Mission 不一致 | Progress Projection |
| R-23 | Native Commander L1／L2／L3 成熟度混淆 | P0 | 上位設計及 B1 結果 | SBL／HGK Integration |
| R-24 | 缺使用者可見、可恢復、可撤銷的決策操作入口 | P1 | 缺端到端實測 | SBL／Host UX |
| R-25 | 已有 FAR、Commander 規劃，但沒有充分形成日常無提示的操作體驗 | P0 | 跨文件對比 | 全域產品整合 |

這些項目有不同確信程度。R-01、R-08、R-10、R-17 等有具體案例；R-04、R-05、R-07、R-21、R-24 屬於**尚無完整實作與端到端驗收證據**，並不等同於已證明程式不存在。

### 3.2 語意理解欠佳的真正原因

這部分不能只歸咎於 Hermes 使用的模型能力不足。

PIPD-LS-PKG 並不是一般自然語言施工指令，而是包含：

- Source／Authority／Intent；
- PI／PD／ECP／TQAEP；
- Requirement、WorkSlot、Runner、Oracle；
- EffectClass、Permission、Release；
- Native Admission、GWO、Acceptance；
- Required／Conditional／Deferred；
- 不同 Owner、Writer、Reader 及作用域。

因此，正確的理解必須完成兩次轉換：

**第一次：語意轉換**

由原始需求及上位權威，產生「使用者真正要求完成什麼」的 Mission Goal／Acceptance Obligations。

**第二次：執行轉換**

由已確立的契約，產生每一張具有合法前置、工具、Runner、操作範圍、預期世界效果與驗收條件的 WorkOrder。

Hermes 第一階段完成的是大量來源解析，並未充分完成第二次轉換。

這正是「看懂文件」和「真正能施工」之間的差別。

**建議建立 Mission Intent Fidelity 檢查：**

每張 Requirement 必須能追溯到 `Executable WorkUnit`、合法的 `Deferred/NoFit` 或具名 `HOLD`。僅有 `parsed=true`、`coverage_count=949` 不足以證明任務範圍完整。

另外，使用者若明確要求「實作」，系統不得自行把它重新分類成 `DESIGN_ONLY`，除非原始權限及實際環境確實限制了操作；即使如此也應繼續執行其他合法部分，並主動說明限制與替代方案。

### 3.3 治理過度的根源

治理過重主要來自三種錯用：

| 錯用 | 原本合理的要求 | 錯誤擴張 |
|--------|--------|--------|
| 准入錯置 | 真 Host Effect 必須有合法 Permit | 所有唯讀、隔離研究也要等待 Host Permit |
| 簽署錯置 | Owner 需批准正式 Registry／Policy／Effect | 每個仍可能改版的候選都先逐條簽署 |
| 驗收錯置 | Native Acceptance 需要真 Effect 和獨立 Checker | 在施工前就要求尚未存在的 Live Receipt |

FAR 對 30 條 Runner Route 提出的 Canary Strategy，就是減少治理重工的具體例子。

先批准具有真實九欄資料、可驗證且無副作用的一條 Runner Canary，確認 ABI 與 Receiver 能正常工作，再依現役政策決定其餘路由的批次准入，比一開始簽完整套尚可能改版的 Registry 更合理。

但是，**Canary 通過不表示其餘 29 條自動獲准，也不能取代它們各自的合法能力與效果驗證。**

### 3.4 高自動化不佳的根本原因

Hermes 自述某次 KANBAN 為 19 Done、3 Blocked、0 Ready。

這個狀態可以代表當輪沒有剩餘合法 Ready 工作，但不能直接回答：

- 3 張 Blocked 是否已有自動解除條件？
- FAR 是否已經研究過阻斷？
- 是否已有最佳合法方案？
- 是否需要 Owner 真實裁決？
- Owner 是否已收到可操作的決策？
- 有效授權一旦成立，任務會不會自動恢復？
- 最終 Native 驗收是否已完成？

**高自動化不能只定義為「有工作就派工」，還必須包含「沒工作可派時，自動追查原因、提出決策、持久等待、恢復後續行」。**

這正是 FAR 與 Native Commander 應該協作處理的部分。

---

## 四、FAR 和 Native Commander：原始設計其實已經有答案

### 4.1 FHS-MSC r2 已明確設計 FAR 自動介入

《FHS-MSC\_藍圖\_r2》§6.2 已提供完整的事件決策矩陣，涵蓋：

`SRC_SHA_DRIFT`、`GRANT_MISSING`、`SCHEDULER_STARVATION`、`MODEL_REQUIRED_NOT_SERVED`、`CHECKER_MAKER_COLLISION`、`CANDIDATE_TEST_PASS_NOT_LIVE`、`OWNER_CLASS_POLICY_CHANGE`、`UNKNOWN_EFFECT_AFTER_TIMEOUT` 等事件。

其合法 FAR 決策亦已明訂：

`NOOP / READ_ONLY_RESEARCH / REPLAN / REPAIR_SCOPED / HUMAN_DECISION / STOP_ESCALATE`

並且強制 FAR 只能輸出有證據的研究或提案，真正執行必須經 HGK Native Admission。fileciteturn0file24L379-L415

因此，**不需要再設計第二套 FAR Decision Engine**。

### 4.2 《FHS-MSC\_總討論》已經設計事件驅動 FAR

《總討論》§5.2～§5.6 已明確建議：

`HGK／Hermes Event → Typed FirstFail → Known Fix Reuse 或 FAR Research → Repair Proposal → HGK Admission → Hermes Execute → Independent Checker → Resume`

也要求：

- 不在每個 Worker Tick 重跑全部研究。
- 有 Known Root Cause 時先重用。
- 找不到有效方案才使用更深入的 FAR。
- FAR 可以選出最佳工程候選，但無權修改 Canonical Policy、Oracle 或 Native Permit。
- 真正需要人類決策時，產生單一 OwnerDecisionPack。
- 其餘合法工作繼續。fileciteturn0file23L2437-L2627

這幾乎已經覆蓋使用者目前提出的「遇問題自動找 FAR，不用再下 Prompt」需求。

**所以欠缺的主要不是 FAR 演算法的重新規劃，而是將既有事件規範接到真實 Host 的自動觸發、狀態回寫與使用者通知。**

### 4.3 SBL Native Commander 原本就負責這些工作

《SBL\_PIPD-LS-PKG\_DOC-04》的 C14 已定義 Commander-SP／CAPC C0～C9：

| CAPC Domain | 應負責的事 |
|--------|--------|
| C0 Source Scan | 定位來源與可信基準 |
| C1 Intent | 理解使用者目的與預期成果 |
| C2 Authority | 釐清誰可以裁決 |
| C3 ChangeSet | 決定實際變更類型 |
| C4 Execution Scope | 決定可執行作用域 |
| C5 Runtime Readiness | 確認現役 Host／Tool／Model |
| C6 User Experience | 確保有使用者可觀測的成果 |
| C7 Acceptance | 形成正反例驗收契約 |
| C8 Evidence and Claims | 處理 Raw／Claim Ceiling |
| C9 Termination and Resume | 決定停止、等待與恢復 |

這已經包含「理解任務、做最佳執行計畫、遇阻修正、長期續工」的主要設計契約。fileciteturn0file22L551-L593

《總討論》也已將 Commander 的成熟度分為：

- L1：Planning／Prompt Authoring。
- L2：Native Handoff。
- L3：Durable Mission Orchestration。

並明確指出，最大的未完成工作是 L1 → L2 → L3 的接線和實機驗收，而不是缺少一份新的大型 Commander Prompt。

### 4.4 本次額外核對的實際程式證據

我透過已連接的 GitHub 直接讀取 Fabric 的：

[github.com](https://github.com/shw097-team/Fabric/blob/main/FAR/far-swof-kseos-rca-001/ProposedEvolution.yaml?utm_source=chatgpt.com)

該檔案確有 `FAR-PROPOSED-EVOLUTION/2` 契約，以及：

`PROPOSAL_ONLY / AWAITING_GATE2_USER_DECISION`

它已包含研究發現、原生准入前置、不確定事項與明確的控制建議，並禁止未經授權自行修改 HG-KSEOS Source 或進行正式效果。

這證實 Fabric FAR 並非只有概念名稱，確有既存研究工件；但該檔案**不能證明 FAR 已部署為事件驅動常駐服務**。

另外，我也直接核對 SBL 現有的：

[github.com](https://github.com/shw097-team/SBL/blob/main/sbl_sp/manifests/commander_sp.json?utm_source=chatgpt.com)

目前 Manifest 保留 `product.write`、`build.route`、`evidence.read`，並明確禁止 `challenge.sign`、`verdict.sign`。

這表示 Commander-SP 已有程式層級的產品能力與權限宣告，但 `product.write` 不能直接解讀成 HGK Native Permit。

其實際權限仍必須依 Host、Mode、Permission Adapter 及當輪任務政策驗證。

**結論：Native Commander 不是從零開始的未設計功能，而是「已有設計和局部實作，但完整 Native 接管及使用者決策互動尚未驗證」的工程狀態。**

---

## 五、建議實現的完整 FAR 主動研究與原生執行架構

### 5.1 核心原則

**不新增 FAR 指揮官、不新增 FAR Queue、不新增 FAR Permission Issuer。**

採用目前 FHS-MSC 已有的權責：

| 元件 | 最終應承擔的功能 |
|--------|--------|
| PIPD-LS-SP | 產生合法的 Canonical Contract、Source／PI／PD／ECP／TQAEP |
| SBL Native Commander | 理解 Mission、規劃 DAG、使用 FAR、編排建議及使用者操作 |
| HG-KSEOS | 唯一 Native Admission、WorkOrder、Permit、正式狀態與裁決紀錄 |
| Hermes | 持久執行、Task Lease、Worker、Checkpoint、Recovery |
| Fabric | Policy Effective State、受治理載入、FAR 原有研究能力 |
| FAR | 根因研究、已知解法重用、方案比較、反證、推薦 |
| Codex／EXECUTE | 依合法範圍執行實作、測試、最小修補 |
| Independent Checker | 以真實 Principal 和原始收據進行獨立驗證 |
| SBL／Desktop Host UI | 顯示進度、建議、授權選項及執行結果 |

這樣可以維持 Single Writer／Single Issuer／Single Durable Mission Authority，不產生新的平行控制面。

### 5.2 完整事件驅動鏈路

PIPD-LS-PKG Native Intake

辨識版本、原始要求、效果分類、完整施工義務

SBL Commander → HGK → Hermes

合法派工、執行、檢測、持久恢復

Typed Event / FirstFail / Blocked / Decision Required

單一事件身份、證據、受影工作集合

Known Fix Resolver → 必要時自動 FAR Research

去重、根因分析、反證、方案排序

Native Commander DecisionPack

最佳建議、備選方案、風險、授權類別

Policy／Standing Grant／Owner Decision

已授權自動續行；需要新權限則顯示操作選項

HGK Native Execution → Hermes Resume → Independent Readback

這個流程最重要的設計，是讓 FAR 成為**執行系統的自動問題處理能力**，而非必須由使用者以聊天方式另外召喚的研究助手。

---

## 六、如何做到「遇到問題，FAR 自動研究」，不用使用者每次輸入 Prompt？

### 6.1 用 Native Event 取代人工 Prompt

目前常見的操作方式是：

`遇到阻斷 → Hermes 回報 → 使用者閱讀 → 使用者再次輸入 Prompt → FAR 研究 → 使用者再輸入授權 Prompt`

建議改為：

`遇到阻斷 → Native Event → FAR 自動研究 → 形成建議 → 合法自動處置或推送決策 → 自動恢復`

對此，應將 FAR Trigger Adapter 接入現有 HGK／Hermes Event／Journal 讀取機制。

它只負責事件辨識、合法 FAR 任務請求及回寫研究引用，不取得 Issuer 或 Worker 的權限。

### 6.2 建議正式支援的觸發條件

| 事件 | FAR 自動應做的事 |
|--------|--------|
| `MISSION_INTENT_UNRESOLVED` | 判斷哪些 PIPD 要求尚未轉為合法工作 |
| `NO_ELIGIBLE_READY` | 分析無 Ready 的原因，而不是直接結案 |
| `NATIVE_GATE_BLOCKED` | 找出首個真正缺失的權威、Runner、Permit 或 Registry |
| `OWNER_DECISION_PENDING` | 研究最佳合法選項，組成決策卡 |
| `REPEAT_FIRSTFAIL` | 先查已驗證修補，避免重新研究 |
| `TOOLCHAIN_NOT_FOUND` | 查現役替代工具與合法安裝方案 |
| `MODEL_REQUIRED_NOT_SERVED` | 查模型、Provider、Credential、Router，提出合法替代 |
| `CANDIDATE_NOT_EFFECTIVE` | 找出 Patch、Stage、Active、Loaded 之間的缺口 |
| `SCHEMA_ABI_CONFLICT` | 研究 Canonical 相容、Migration 或 Adapter |
| `RUNNER_REGISTRY_MISSING` | 提出 Canary、批次 Registry 與簽署順序 |
| `CHECKER_NOT_INDEPENDENT` | 定位 Principal、Credential 及證據隔離缺口 |
| `COST_BUDGET_WARNING` | 提出重用、減少重讀、停損或方案切換 |
| `EXECUTOR_STALLED` | 研究 Lease、Wakeup、Heartbeat、Queue Fairness |
| `PERMISSION_SCOPE_EXCEEDED` | 停止受影效果，提出新的有界授權請求 |
| `UNKNOWN_EFFECT` | 先研究及對帳世界效果，禁止盲目重播 |

每項事件必須附上有效 `Mission ID`、Subject、Currentness、FirstFail、Affected Scope、Raw Reference 及必要的政策身份。

若缺資料，FAR 應明確回傳「目前無法判定」及最小唯讀蒐證方案，不得編造原因。

### 6.3 不應每次發生事件都啟動大型 FAR

這是避免新一輪治理及 Token 成本膨脹的關鍵。

建議採用三層處理：

| 層級 | 適用問題 | 操作方式 |
|--------|--------|--------|
| Tier 0 | 已知原因、已存在有效修補 | 確定性匹配 Known Fix |
| Tier 1 | 需要檢查少量來源或 Runtime | 有界唯讀研究 |
| Tier 2 | 原因不明、跨系統衝突、重大風險或裁決 | 完整 FAR 多視角研究與反證 |

FAR 研究必須具有：

`finding_identity / policy_digest / subject_sha / investigation_budget / currentness / prior_findings / counterevidence`

同一個問題未產生新證據前，不應每個 Worker Tick 重新研究。

對重複研究造成的成本，應設 Research Budget、去重、節流及失敗退避；但不得將研究重試與 Native Effect 重試混為一談。

### 6.4 「主動」不等於無限制持續研究

真正高自動化的目標應是：

- 有合法工作：繼續執行。
- 有可自動修復問題：依有效授權修復。
- 有未知問題：主動研究。
- 需要新權限：生成決策，等候合法核准。
- FAR 本身不可用：記錄具名阻斷，保留其他合法工作。
- 完全沒有合法工作：進入持久等待，註冊恢復條件。
- 效果不明：先 Reconcile，不自行重播。

這樣可以避免系統為了「永不停止」而無限消耗 Token、反覆產生相同分析，或試圖繞過安全 Gate。

---

## 七、如何讓 FAR 自動提出「最佳工程建議」？

### 7.1 FAR 不能只回傳一篇研究報告

目前《HERMES\_B1\_任務回報》中的 FAR 建議品質有改善，但主要仍以文字報告呈現。

這種交付對工程師有用，對希望一鍵裁決的使用者仍有過高操作成本。

應讓 FAR 的研究產物經既有 Commander 轉換成**標準化 Recommendation／DecisionPack**。

最小內容應包含：

| 欄位 | 用途 |
|--------|--------|
| `finding_id` | 明確關聯故障 |
| `mission_id` | 歸屬哪個任務 |
| `root_cause` | 根因與可信程度 |
| `evidence_refs` | 可追溯的真實依據 |
| `options` | 至少具名可行方案；不足時可只提供一項或無方案 |
| `recommended_option_id` | 有足夠證據才指定最佳選項 |
| `recommendation_reason` | 為什麼推薦 |
| `counterevidence` | 哪些證據可能推翻建議 |
| `effect_scope` | 方案實際影響 |
| `required_authority` | 由誰核准與執行 |
| `cost_risk_estimate` | 成本、風險與不確定性 |
| `preconditions` | 執行前必須滿足的條件 |
| `expected_result` | 執行後預期世界結果 |
| `rollback_or_recovery` | 發生不良效果時的恢復 |
| `expiry` | 決策何時失效 |
| `native_action_ref` | 已存在且合法的動作定位；未綁定時留空 |

這應是現有 FAR Recommendation／OwnerDecisionPack 的**受影型別化補強**，而不是建立第二套來源權威。

### 7.2 最佳方案不能只由模型主觀投票

建議採用先過硬性限制、再評估效益的決策方式。

第一階段：排除不合法方案。

例如：

- 需要不存在的 Native 權限。
- 與 Canonical Schema 不相容。
- 破壞既有 SourceFreeze 或正式驗收證據。
- 會修改超出 WriteSet 的檔案。
- 會讓 Maker 兼任 Independent Checker。
- 沒有必要的 Rollback／Readback。
- 違反當輪禁止的 Commander 或模型路由。

第二階段：只對剩餘可行方案做比較。

| 評估面向 | 優先準則 |
|--------|--------|
| 安全性 | 不越權、不產生不可接受副作用 |
| 原生相容 | 優先使用既有 Native ABI |
| 工程效果 | 真正解除當前 FirstFail |
| 修補範圍 | 最小 ChangeSet／RepairCone |
| 治理成本 | 不增加重複 Gate 與無必要 HITL |
| 執行成本 | 工時、Token、資源、回歸成本 |
| 可驗證性 | 有明確 POS／NEG／Readback |
| 可恢復性 | 可 Rollback、Compensate、Reconcile |
| 可維護性 | 不新增不必要控制平面 |
| 使用者操作量 | 減少 Prompt、重複輸入和不必要裁決 |

如果缺少足夠證據，應標示推薦為 `PROVISIONAL`，或只建議先做唯讀診斷，不能硬選出所謂最佳方案。

### 7.3 B1 的實際例子：30 條 Runner Route

| 方案 | FAR 應給的建議 | 原因 |
|--------|--------|--------|
| A：立即簽署 30 條 Registry | 不推薦 | Schema／Vocabulary 尚未定案，容易整批失效 |
| B：先批准一條唯讀 Canary，再依證據擴充 | **建議首選** | 可降低變更風險、檢查真 Receiver 接線 |
| C：暫不簽署，先補 Canonical Schema 與所有相容測試 | 視受影 ABI 而定 | 若 Canary 也依賴未定 Schema，必須先修 |
| D：跳過 Registry，直接執行 Native Effect | 拒絕 | 缺合法 Runner Admission |

這個建議可由 FAR 自動產生，無需使用者另外要求「請分析四個 HARD Blocker」。

不過，B1 當前已有一項值得特別保留的裁決：**不能在 PIPD Canonical 未批准之前，直接將 B1 提案的四個 `effect_class` 值固化為官方 Enum。**

---

## 八、如何做到「用戶直接點擊，就能執行 FAR 推薦方案」？

這是本次需求中需要補強的新產品互動層。

### 8.1 r2 已有 DecisionPack，但還缺完整 Action UX

FHS-MSC r2 已有 OwnerDecisionPack／Standing Authorization／FAR Recommendation 的設計。

SBL DOC-04 也有 User Experience C6、Evidence C8、Termination C9。

但在本次可確認的設計與實作證據中，尚未看到一套完整、經驗收的：

`FAR Recommendation → 使用者可操作選項 → 真 Native Authorization → Hermes 執行 → 回報結果`

因此，**這部分值得正式補進 SBL Commander／Host UX 的施工與驗收契約。**

這不代表必須另建一個獨立的決策平台。

### 8.2 建議的使用者介面

以下是建議實作的產品畫面文字示例，並非目前已存在的可操作按鈕。

**B1 任務｜Runner Registry 阻斷** (需要 Owner 決策)

FAR 已完成根因研究：目前 30 條 Runner Route 缺乏正式註冊，且 Canonical EffectClass Vocabulary 仍待相應 Owner 定案。直接全面簽署可能造成後續重工。

**建議方案：先執行唯讀 Canary** (首選方案)

先檢查及核准一條無副作用的 Runner Route，驗證真 Receiver／Registry 接線。成功後再審查其餘 29 條。

預期效果：降低整批 Registry 作廢風險。需要：Registry Owner 有效簽署。

其他合法選項

方案 B：先完成 Canonical 相容性檢查，再進行 Registry 簽署。

方案 C：暫停相關 Native 工作，其他合法工作繼續。

---

正式產品應將上述選項對應至受信的 Native Action Handler，而非直接執行 FAR 產生的任意指令。

正式實作時，使用者應可在同一個介面查看建議依據、選擇方案、核准適用授權、觀察執行進度，並保留撤銷或暫緩的選項。

### 8.3 真正的一鍵執行需要四個技術條件

**第一：推薦方案必須有 Native Action Binding。**

不是使用者點了按鈕，就把 FAR 報告中的 PowerShell 指令直接傳給 Executor。

應綁定已註冊的動作、合法 Schema、預期版本、作用域與 Idempotency Key。

**第二：點擊時必須重新檢查 Currentness。**

FAR 研究完成後，Repository HEAD、Policy Epoch、Subject SHA、Registry 或 Permit 可能已變更。

因此使用者點擊後必須重新檢查：

`DecisionPack Current → Owner Identity → Effective Grant → Native Policy → Subject／WriteSet → Action Admission`

如果研究結論已過期，應顯示需要重新分析，而不是照舊執行。

**第三：點擊不等於自動擁有新的權限。**

依效果類別區分：

| 效果類別 | 使用者點選後可否直接執行 |
|--------|--------|
| 已授權的唯讀研究 | 可以，在有效資料作用域內 |
| 已有有效 Standing Grant 的有界修補 | 可以交 HGK 再次檢查准入後執行 |
| 新 Repository WriteSet、Canonical Schema 變更 | 需真正有權的 Owner Approval／ExecutionAdmission |
| Native Trust／Credential／Policy 改變 | 需原生權威及相應身分核准 |
| 正式 Release／不可逆效果 | 需所有適用的正式 Gate |

因此，**「一鍵」應理解為使用者不必再撰寫 Prompt，並能從一個明確動作入口完成該方案的合法操作流程。**

對已預先批准的工作，可實現真正一鍵啟動。

對需要額外簽章、OS 提權或其他不可代理核准的工作，點擊應啟動受信授權流程；不能用介面便利性取消必要驗證。

**第四：動作必須具有防重複與恢復能力。**

同一個 DecisionPack／Operation 已被消費後，連續點擊不得再次造成同一效果。

若 Timeout，必須先讀回 Native World State，再決定可否恢復。

### 8.4 建議使用「Decision Ticket」而不是新的 Prompt

每一張可操作建議應綁定受信的短效決策票證，至少記錄：

`decision_id / mission_id / option_id / finding_id / subject_sha / policy_epoch / principal / action_ref / scope / expiry / nonce / expected_receipt`

這是**建議的操作投影**，不能由本文自行宣稱為 HGK 已發布的 Native Token Schema。

票證不應承載未受信任的 Shell 指令，也不應允許 FAR 用文字欄位擴張操作權限。

執行結果由原 Native Owner 寫入 Durable Ledger，SBL UI 只讀取並呈現。

---

## 九、建立真正低干預的三層自動決策制度

為降低人類 Owner 的操作負擔，建議使用原本 FHS-MSC 已規劃的有界授權思想。

| 等級 | 決策內容 | FAR／Commander 可做什麼 | 使用者介入 |
|--------|--------|--------|--------|
| A：自動研究 | 唯讀診斷、已知解法比對、工作重新規劃 | 可在已核准資料範圍內主動進行 | 通常不需要 |
| B：已授權工程 | 受限 Repo Repair、測試、合法 Runner 執行 | 選擇最小有效候選，經既有 Native Admission 執行 | 已有有效授權時不重問 |
| C：Owner 級裁決 | 新權限、正式 Schema／Policy、敏感資料、Release | FAR 自動研究，Commander 整理最佳選項並提示 | 必須合法核准 |

**此分層不應代替現有原生 EffectClass 或權限 Enum；它只是 Owner Interaction Policy 的建議。**

特別強調：

單一人類 Owner 可以一次授予有界 Mission Authorization，但不代表同一模型可以同時成為 Maker、Signer、Issuer 和 Independent Checker。

### 9.1 需要主動通知的事項

使用者應只收到真正需要其注意的高價值事件，例如：

- 有新權限需要核准。
- FAR 找到風險明顯更低的施工選項。
- 原選擇已過期或遭新證據推翻。
- 預算或風險上限將被超過。
- 無法使用合法代位執行方案。
- 正式 Native Acceptance 已完成，需要 Release 決策。
- 達到停損條件，需要選擇恢復或退出。

不應每個 Scheduler Tick、每次 Retry、每個相同 FirstFail 都重複通知。

若使用者暫時未回應，DecisionPack 應持久保存，其他合法工作繼續進行；若沒有合法 READY 工作，Mission 應保持 Durable Wait。

---

## 十、重新評估 Native Commander：到底哪些能力尚未真正完成？

這是本次架構判斷的重點。

### 10.1 Native Commander 本來就不是單純產生 Prompt 的工具

SBL DOC-04 C14、SBL DOC-10 C31／C38、SBL DOC-11 C29，以及 FHS-MSC r2 已經要求 Commander 支援：

- Source-aware Planning。
- PI／PD／ECP 消費。
- WorkUnit DAG 及相依關係。
- Capability／Method／Lane Routing。
- Native Handoff。
- Durable Resume。
- FirstFail／FAR RepairCone。
- 驗收證據與任務終止。
- User-facing Outcome。

這些是既有產品責任，不宜再建立名為 `FAR Commander`、`AI Decision Governor` 或 `B1 Autonomous Supervisor` 的第二個系統來取代。

### 10.2 尚需證明的成熟度

| Native Commander 能力 | 文件設計 | 目前可確認的實作證據 | 鑑定 |
|--------|--------|--------|--------|
| L1：讀取與拆解需求 | 有 | B1 大量清冊及契約處理 | 部分有效，但執行語意不足 |
| L1：選擇施工方法 | 有 | KANBAN／SWARM／OpenSpec 局部使用 | 缺能力／適用性完整驗證 |
| L1：FAR 問題處理 | 有 | 手動指令觸發 FAR 後有實質建議 | 有能力，缺自動化證據 |
| L2：Native Handoff | 有 | 30 條 Runner Route BLOCKED | 未閉合 |
| L2：真 HGK Permit | 有 | B1 正式 Native Admission 未通過 | 未閉合 |
| L3：持久任務續行 | 有 | 既有 Scheduler／Checkpoint 局部成果 | 完整自治接管未驗收 |
| L3：主動研究及恢復 | 有 | 未見完整事件觸發 E2E | 缺口 |
| L3：使用者決策卡 | 有 DecisionPack 構想 | 尚無一鍵方案實測 | 缺口 |
| L3：點選後正式執行 | 有權責基礎 | 尚無可信任完整 Action E2E | 缺口 |

### 10.3 對「Native Commander 尚未實作完成」的正式回答

**是，這是核心原因之一。**

更準確地說：

**Native Commander 並非缺少功能規劃，而是已規劃的 L2 Native Handoff、L3 Durable Orchestration、FAR Decision Integration 及 User Action Experience 尚未充分完成整合與正式驗收。**

這與「應另外設計一個新 Commander」是不同的工程結論。

另一方面，Native Commander 即使全部完成，也不能替代缺少的 HGK Receiver、Hermes 真 Executor、Fabric Activator 或獨立 Checker。

因此，修補重點是各層既有能力的互通性。

---

## 十一、針對《HERMES\_B1\_任務回報》的具體修復示範

建議將本次回報轉成第一個正式 FAR 自動決策回歸案例。

### 11.1 當系統發現 30/30 Runner BLOCKED

未來不應只顯示：

`BLOCKED_MISSING_RUNNER_OR_BINDING`

應由現有 Event Adapter 自動觸發 FAR：

1. 查目前正式 PIPD Schema 及 B1 Extension。
2. 查 Registry Snapshot／Signed BOM 及所需九欄。
3. 判斷目前阻斷是 Schema、Owner、Runner、Receiver 還是多因素。
4. 查已存在的 FAR 裁決及已驗證候選。
5. 產出建議 S1／S2／S3 的依賴與可並行部分。
6. 對合法唯讀及隔離工作繼續派工。
7. 對真正需要 Owner 的部分產生單一 DecisionPack。
8. 核准後依有效 Native Admission 恢復。

### 11.2 對 FAR 的三項建議應如何實作？

| 建議 | 正確技術作法 | 不應做的事 |
|--------|--------|--------|
| S1 Canonical Schema | 在具名 PIPD Owner 權責下修補欄位、ABI、Trace，重跑受影負例 | 把 B1 未批准的四值硬編成 Canonical Enum |
| S2 Runner Canary | 以一條受限只讀 Route 驗證 Registry／Receiver，再依政策擴充 | 一次簽 30 條未驗證 Route |
| S3 Issuer Principal | 使用 HGK 現有真正受保護的 Issuer／Principal，完成分權與拒收 | 由 Maker 或 FAR 自行簽發 Native Permit |

Queue 基礎設施的讀取、診斷與合法無效果測試可以依自身授權並行；不必無條件等待 S3。

正式效果必須滿足相應的 Runner Admission、Issuer、Policy、EffectClass 及權限。

同時，SourceFreeze 的時點要區分「正式 PIPD 編譯的來源凍結」與「最終 Release 對修訂後位元的封存」，不能把所有 Freeze 都拖到執行完成，也不能反過來拿最終封存去證明尚未發生的 Native Effect。

### 11.3 不應再次誤判使用者授權

《HERMES\_B1\_任務回報》最後的使用者授權表述，應觸發：

`OWNER_DECISION_RECORDED → AUTHORITATIVE_BINDING_CHECK → ADMISSION → EXECUTION`

如果相應簽章、Registry 或受信任 Principal 尚未存在，應主動準備可批准的工件及官方操作入口。

**不能把一句「我授權」直接當作已取得有效的 Native Credential，也不能因缺 Native Credential 就停止所有仍可合法執行的工作。**

---

## 十二、建議修補哪些文件？哪些不必重工？

### 12.1 建議採取局部整合

| 文件／系統 | 建議處理 | 原因 |
|--------|--------|--------|
| 《FHS-MSC\_總討論》 | 保留歷史，不重新改寫 | 已有主要原始裁決 |
| 《FHS-MSC\_藍圖\_r2》 | 受影升級 r2.1 候選 | 補自動 FAR→Decision→Action E2E |
| SBL DOC-04 | 增補 Commander FAR 事件及建議轉工作卡契約 | C14 已擁有規劃權 |
| SBL DOC-10 | 增補 Host／Desktop Decision UI、Resume 投影 | 已有 UX／Host／LongTask 交付定位 |
| SBL DOC-11 | 補 FAR→Commander→HGK Handshake 與正式准入測試 | C29 已有 Native Reader 分工 |
| SBL DOC-13 | 增補 FAR 成效、去重、成本、反例與回歸 | C45／C46 原有責任 |
| PIPD DOC-04／05／07 | 只做必要 ABI、Permission、Assurance 相容性修補 | 不建立第二套 Canonical |
| HG-KSEOS | 接線原有 Event、Registry、Issuer、Decision Status | 保留 Single Control Plane |
| Hermes | 完成 Executor、Resume、Stop Controller、Event Publisher | 保留現有 Durable Queue |
| Fabric FAR | 增補受治理的 Event Intake 與 Decision Output Adapter | 重用現有 FAR 研究能力 |

### 12.2 不建議修改的部分

不應因 FAR 產品體驗升級而重寫 SBL 全部 14 冊、PIPD 全部 10 冊，或重造 PIPD 的 PI/PD/ECP/TQAEP。

也不應讓 FAR 具有新的 Policy Writer、Native Issuer 或 Release Authority。

另外，SBL Commander-SP 在某個 B1 Mission 內被禁止使用，不等於應全面刪除其產品設計。當輪禁止的入口應保持禁用，並經合法 Owner 綁定其他現役有效入口；不能以設計理想取代實際 Mission Restriction。

---

## 十三、建議的施工優先次序

### Phase A：確認現役能力，避免重造

先對真實 Windows Host／Repo 做唯讀盤點：

- HGK Event／State／Permit／Registry。
- Hermes 真 Executor／Resume。
- Fabric FAR 目前可調用入口。
- SBL Commander 實際 Host、Manifest 與 Mode。
- PIPD Canonical／B1 EffectClass 相容性。
- 是否已存在 Approval Queue、Decision UI 或可利用的 Host Action Handler。

此階段不能假設「文件有設計」就等於「現役 Host 已載入」。

**交付：** 真實能力與缺口清冊、受影最小修補範圍。

### Phase B：補最小 FAR 自動觸發

由合法的 HGK／Hermes Event Reader 訂閱具名 FirstFail、Blocked、Owner Decision Pending 等事件。

完成 Known Fix 去重、按需研究、Raw Evidence 收集及 Finding Currentness。

**驗收：** 人類不輸入新的 FAR Prompt，系統仍能對具名阻斷產生可追溯研究建議。

### Phase C：接通 Commander Recommendation／DecisionPack

把 FAR 的建議轉為可比較、可裁決、能表達合法權限與預期效果的操作方案。

**驗收：** 每項方案均可追溯到具名 Finding、合法 Native Action、權限、成本、反例及退出條件；若不可執行，就明確標示原因。

### Phase D：完成 SBL／Desktop Host Decision UX

使用現役合法 Host／UI Extension 提供建議卡及動作入口。

應區分已預授權工作的一鍵執行與需要新的安全核准的動作。

**驗收：** 使用者不需要另外撰寫 Prompt，就能對已綁定的建議做出有效操作；重複點選、過期票證及越權選項必被拒收。

### Phase E：接通 HGK Native Action／Hermes Resume

將合法的 User Decision 交由真正的 HGK Admission 處理，再由 Hermes 受控執行。

**驗收：** 真 Worker 執行、世界狀態 Readback、Independent Checker、Durable Resume 與有效狀態回寫完整成立。

### Phase F：完成 B1 與通用 PIPD-LS-PKG 回歸

不只測單一 B1 文件。

還應選取受控的其他 PIPD-LS-PKG，驗證相同架構能在不同 EffectClass、Host、Mode 與授權情境下重用。

**驗收：** 不需要為每套 PIPD-LS-PKG 重新寫一份大型 Master Prompt，仍能正確辨識任務、限制、工具、阻斷和修復方案。

---

## 十四、全新高自動化體驗的正式驗收標準

| 測試 | 合格要求 |
|--------|--------|
| FAR-01 自動觸發 | 遇到符合條件的阻斷，不需新 Prompt 即建立 FAR 研究請求 |
| FAR-02 去重研究 | 相同且仍 Current 的 Finding 不重跑完整研究 |
| FAR-03 根因正確性 | 有可追溯證據與反證，不能由缺收據直接推斷元件故障 |
| FAR-04 最佳建議 | 可行方案先經權限與 ABI 篩選，再給推薦及備選 |
| FAR-05 授權分類 | 不把 Readonly、Repo、OPS、USER 效果混合 |
| FAR-06 決策送達 | 真 Owner 能在授權的介面看到具名待決方案 |
| FAR-07 一鍵操作 | 不需另打 Prompt，即可啟動已綁定的合法操作流程 |
| FAR-08 權限防護 | 無效 Owner、過期決策、錯 Subject、錯 Policy 均拒收 |
| FAR-09 反重複 | 同一 Decision／Operation 不可造成重複 Effect |
| FAR-10 自動續工 | 授權及依賴解除後，Hermes 能恢復合法工作 |
| FAR-11 局部阻斷 | 一張工作卡 HOLD，不阻止無依賴的 READY 工作 |
| FAR-12 跨程序恢復 | 會話或 Worker 退出後，依 Durable State 接續 |
| FAR-13 真實驗收 | 不能用 FAR 報告、模型判詞或沙箱測試冒充 Native Acceptance |
| FAR-14 成本控制 | 研究具預算、快取、去重、停損及可核實成本 |
| FAR-15 介面有效性 | 建議不是死連結或示意按鈕，真 Action Binding 可查 |
| FAR-16 任務完整性 | 完整執行要求不被降格為只完成清冊 |
| FAR-17 事件防循環 | FAR 自己產生的報告不會無限重新觸發同一研究 |
| FAR-18 撤銷與變更 | Owner 撤銷、Policy／Repo 改變後，舊票證失效 |

正式驗收不能只看其中一項通過。

最低端到端示範應包括兩條獨立路徑：

**路徑 A：無需新增授權。**
真 Runtime 發現合法範圍內的問題，FAR 自動研究或重用修補，Hermes 在現有有效授權下修復，Checker 驗證。

**路徑 B：必須 Owner 決策。**
真 Runtime 發現新的受治理阻斷，FAR 自動研究並生成建議，使用者在受信 UI 選擇方案，HGK 取得有效授權並簽發合法工作，Hermes 自動續行，Checker 以真實收據驗證。

兩條都成功，才可以說明系統開始具備使用者所要求的 FAR 主動研究與低干預執行體驗。

---

## 十五、最後的五項關鍵裁決

### 裁決一：目前是否存在治理過重？

**存在，但主要是執行階段及適用性錯置，而不是必要安全規範本身錯誤。**

應減少重複裁決、錯誤全域 HOLD、提前簽署及無效重驗，不應刪除正式 Permission、Native Issuer、Independent Checker 和 Source Authority。

### 裁決二：是否存在鏈路不順、高自動化欠佳？

**存在，而且是目前最主要的工程修復方向。**

B1 證明資料解析、設計編譯及局部測試可以成功，但 Native Intake、Runner、Executor、FAR、Owner Decision、Acceptance 尚未形成充分的自動閉環。

### 裁決三：是否存在語意理解和主動建議不足？

**存在。**

尤其是「要求完整實作卻只完成清冊」，以及「明明有合法診斷工作卻自行縮小施工範圍」，表明需要把 Mission Intent Fidelity、Executable Obligation Closure 與 FAR 主動規劃納入正式工作流程。

不應將其簡化為更換更強模型就能全部解決。

### 裁決四：是否已在 FHS-MSC r2／總討論／SBL DOC 中設計過？

**絕大部分已經設計過。**

FAR Event-driven Research、Known Fix Reuse、OwnerDecisionPack、Standing Authorization、Native Commander C0～C9、Durable Resume、Affected-only Repair 均已有上位基礎。

因此不應重新規劃整套架構。

**真正需要補強的新交付，是完整的 FAR Recommendation → SBL User Action → HGK Native Execution 契約及其現役 Host 實作。**

### 裁決五：最適合的實際升級路線是什麼？

## 建議正式工程路線

**`NATIVE_COMMANDER_FAR_DECISION_ACTION_LOOP`**

`REUSE_EXISTING_ARCHITECTURE / ADD_MINIMUM_ADAPTERS / NO_SECOND_CONTROL_PLANE`

---

**優先處理三條主鏈：**

**A. 自動感知與研究**
HGK／Hermes Event → Known Fix／FAR → 有證據的根因與方案。

**B. 可操作的使用者決策**
FAR Recommendation → Commander DecisionPack → SBL／Desktop Host 選項 → 合法 Owner Authorization。

**C. 真正原生執行與恢復**
HGK Admission → Hermes Executor → Raw Readback → Independent Checker → Durable Resume。

## 最終總結

這次《HERMES\_B1\_任務回報》最有價值的證據，不是某次 66/66、11/11 或沙箱 3/3 通過，而是顯示出：

**Hermes 一開始未能把完整使用者目的轉化成完整施工；後來即使有能力實際編譯與修補，仍無法自行形成最佳授權方案；直到使用者再次輸入 Prompt 指定使用 FAR，才產生更正確、成本更低的裁決。**

這意味著下一階段 FHS-MSC 最重要的改進，不是讓使用者學會下更精確的 Prompt，而是讓系統本身具備：

**主動發現問題、主動研究原因、主動比較方案、主動提供有證據的最佳建議、主動取得既有權限下的合法執行機會，並在確實需要新的 Owner 決策時提供可直接操作的選項。**

**最終工程結論：保留 FHS-MSC r2 與 SBL Native Commander 的原始設計，優先修復已規劃但尚未完整生效的 FAR／Commander／HGK／Hermes 接線，再補足使用者一鍵裁決與 Native Action Binding。**

這條路線最符合既有架構的單一權威、低治理阻力、低重工、高自動化及可驗收原則。

**本報告屬來源交叉鑑定、GitHub 既有設計工件核對及工程升級建議；未操作本地 Windows Host，未宣告 FAR 主動事件鏈或一鍵 Native Action 已實際部署。**

## Prompt:
2026/10/28 上午12:17:15

你的角色：
你是「HERMES / FABRIC / SBL / HG-KSEOS」高自動化任務運行總工程師。

任務目標：
你必須整合前輪分析規劃，再對「《SBL-TPM-SP_Native-SBL-TPM_升級藍圖》、《SBL Commander & SBL-Commander-Skill_升級討論》、《SBL-TPM-SP & Native SBL-TPM_升級討論》、《SBL_Commander_and_SBL-Commander-Skill_重構升級藍圖》」這四份，進行專業工程的「深度研究 + 交叉比對 + 分析評估 」，是否需要以這四份，對《FHS-MSC_藍圖_r2》進一步升級?

任務要求：

你必須針對任務目標，並對全部相關資料進行「研究分析+交叉比對」，再進行鑑定、評估、規劃，並提出完整報告。

最後你必須直接以文字提出完整報告。

[Attachment: SBL-TPM-SP & Native SBL-TPM_升級討論(1).md]

[Attachment: SBL-TPM-SP_Native-SBL-TPM_升級藍圖.md]

[Attachment: SBL Commander & SBL-Commander-Skill_升級討論(1).md]

[Attachment: SBL_Commander_and_SBL-Commander-Skill_重構升級藍圖_2026-10-27_v1(1).md]

## Response:
2026/10/28 上午12:17:27 · gpt-6-thinking

我會先逐份核對四份新文件的正式裁決、產品分工、介面、施工順序與驗收條件，再與《FHS-MSC\_藍圖\_r2》逐章交叉比對。重點是辨別哪些設計已存在、哪些屬真正新增要求，以及 TPM 與 Commander 兩套升級藍圖之間是否有互相衝突之處。最後會提出具體升版範圍和不應重工的部分。

> **分析四份文件與FHS差異**
>
>
> **檢視 FHS 章節矛盾與規格差異**
>
>
> **檢查三份藍圖衝突與決策缺口**
>
>
> **讀取選定技術審查段落**
>
>
> **檢視升級衝突與階段契約**
>
>
> **檢視 TPM 階段映射與詳細 CR內容**
>
>
> **整理執行方案**
>
> 我會將既有藍圖與指南視為主體，補全三份正式範本、外部套件、治理規則與發布門檻，並逐項標示新增、修改及待決事項。
>
> **整理執行方案**
>
> 
>
> **分析文件、架構衝突與升級契約差異**
>
> 
>
> **規劃整合報告**
>
> 我會以現有藍圖、指南與驗收規格為基準，整理四份文件的交集、衝突、缺口、變更建議，以及可直接採用的實施順序與驗收條件。
>
> **規劃整合報告**
>
> 
>
> **完成四份文件整合與落地建議**
>
> 
>
> 處理時間為 5m 57s

# FHS-MSC r2 × SBL-TPM × SBL Commander 四份升級文件——跨架構整合與藍圖升版工程鑑定報告

鑑定日期：2026 年 10 月 28 日｜評估基準：四份 2026-10-27 升級文件、FHS-MSC r2、FHS-MSC 總討論、SBL／PIPD 上位規範及 B1 施工失效紀錄

## 一、最終核心裁決

**《FHS-MSC\_藍圖\_r2》需要進一步升級，但不應全面重寫，也不應直接合併四份新文件成為另一套巨型藍圖。**

本次四份文件提出的改進可以分為三類：

1. **r2 已完整規劃的能力：** 唯一 HGK Issuer、Hermes 持久執行、三實體模型車道、FAR 主動研究、Standing Authorization、局部 PARK、獨立驗收、SBL 三個產品 SP，以及 Codex Bootstrap Repair。這些內容應直接重用。
2. **r2 已有架構基礎，但尚未充分具體化的能力：** SBL-TPM-SP 與 Native SBL-TPM 的雙形態交付、Commander 外部 Guide 與內部 PLAN 角色拆分、PIPD P4 工具相容修復、自包含來源檢索、GitHub 交付決策，以及薄型任務交接 ABI。這些值得受影升級。
3. **四份新文件仍需裁決的問題：** TPM、Commander、PIPD Compiler 之間可能重複規劃；舊 Commander-SP 的歷史產品責任如何保留；自包含 Plugin 的來源更新如何維持權威；以及 GitHub、FAR、模型路由與使用者決策如何避免再變成全域阻斷。

### 建議方案

**工程裁決：`FHS_MSC_R2_TARGETED_CONVERGENCE_UPGRADE`**

## 保留架構、整合雙產品形態、消除重疊權責、補齊 Native 執行接面

| 項目 | 裁決 |
|--------|--------|
| FHS-MSC 核心控制架構 | 保留 |
| SBL-TPM-SP + Native SBL-TPM | 採納雙形態設計 |
| 舊 Commander-SP 全域主控 | 不恢復 |
| 外部 SBL Commander Guide Skill | 採納為受限候選，待產品驗證 |
| 內部 Native Commander | 採納 HGK PLAN 角色，不建第四 Lane |
| PIPD P4 原樣整合 | 不採納；先處理相容性問題 |
| 六 Donor／24 Method Slots | 保留身份，按需資格化 |
| GitHub 交付決策 | 採納，但不得阻斷無關本地施工 |
| FAR 主動研究與可操作建議 | 保留既有設計，補端到端驗收 |
| 全面重編 SBL／PIPD 規範 | 不採納 |
| 正式 Native／Production PASS | 尚無充分證據 |

**我建議以 `FHS-MSC r2.1` 作為高保留、受影升級候選，而不是直接宣告 r3 架構重置。**

版本名稱本身仍須遵守實際 Owner 的版本及修訂程序。

---

## 二、四份文件的正式性質及主要貢獻

| 文件 | 核心貢獻 | 工程定位 |
|--------|--------|--------|
| 《SBL-TPM-SP &amp; Native SBL-TPM\_升級討論》 | PIPD P4 缺陷分析、TPM 統一 Plugin、自包含 DOC、雙形態、Codex-first、GitHub 選擇 | 歷史討論及需求演進，非獨立正式產品規範 |
| 《SBL-TPM-SP\_Native-SBL-TPM\_升級藍圖》 | 雙形態 E2E 架構、共同 ABI、完整施工計畫、GitHub Decision Gate、P4 修復及檢驗 | `SBL-TPM-DUAL-20261027-R1` 設計／實作候選 |
| 《SBL Commander &amp; SBL-Commander-Skill\_升級討論》 | 舊 Commander-SP 失效歸因、責任拆分、內部 PLAN、外部 Skill 降格及 Donor 選型 | 歷史討論、反例與重構裁決建議 |
| 《SBL\_Commander\_and\_SBL-Commander-Skill\_重構升級藍圖》 | Guide／PLAN／EXECUTE／Issuer／Checker 分工、具體 Adapter、回歸測試與遷移方案 | `v1.0-DESIGN-CANDIDATE`，正式 Release 尚未取得 |

兩份升級藍圖都明確採取 **Design Candidate／Release Fail-Closed** 的態度。

它們提出的 API、路徑、Schema、樣例程式與測試，不能直接當成 Windows Host 已部署的功能。

這一點非常重要：**四份文件為 r2 提供了更具體的產品實作設計，卻沒有直接證明 Native TPM 或新 Commander 已完成部署與驗收。**

---

## 三、《FHS-MSC\_藍圖\_r2》原本已包含哪些能力？

這是決定是否重工的核心。

### 3.1 上位架構交叉比對

| 四份新文件提出的能力 | r2 原有位置 | 鑑定 |
|--------|--------|--------|
| One Core、唯一正式 Writer | §5.4、R15.1 §3 | **已存在，不重做** |
| TPM、Commander、Challenge 三個 SP | R15.1 §3.2～3.3 | **已存在，需處理產品形態變更** |
| PLAN／EXECUTE／VERIFY\_SECURITY | §5.2、R15.1 §12 | **已存在，不新增 Lane** |
| HGK Native Issuer 與 Hermes Dispatcher | §5.4、R15.1 §12.1 | **已存在，不建立第二套** |
| Bounded Standing Authorization | §6.1、R15.1 §12.2 | **已存在，需接現役授權服務** |
| FAR 自動研究與修補建議 | §6.2、R15.1 §12.3 | **已存在，需落實觸發與回饋** |
| Hermes Durable Checkpoint／Resume | R15.1 §12.5～12.6 | **已存在，需 Runtime 實作與測試** |
| SBL 六模組能力對照 | §5.3、R15.1 §3.1 | **已存在，不重建產品核心** |
| PIPD 八技能、19 Contract、13 CLI | R15.1 §4、§5.1 | 已覆蓋，**工具契約仍需修復** |
| PIPD 12 軸與 P4 九軸差異 | §5.1 | **已辨識，仍待相容性閉合** |
| 18 WorkPackages、25 CheckRuns | R15.1 §5～6 | **已存在，原始身份保留** |
| 六 Donor／24 方法槽位 | R15.1 §7 | **已完整規劃，按需實現** |
| SWOF PRE-W3 最小交接 | §5.7、R15.1 §13 | **已存在，不擴張 W3 權限** |
| CI、Publisher、Independent Checker | §5.11、R15.1 §14 | **已存在，缺產品特定接線** |
| Anti-overengineering／Reuse First | §3.5、§5.10 | **已存在，應強制執行** |

r2 §5.2 已明確把 Commander、TPM 和 FAR Analyst 放在同一個 `PLAN` 實體車道，並將 Codex Writer 置於 `EXECUTE`，獨立驗證置於 `VERIFY_SECURITY`。

這使四份新文件提出的「內部 Commander 不應建立第四條實體 Lane」完全符合原有設計，不需要再次設計車道路由架構。

同樣，r2 §5.3 已要求把外部 Commander 的 Proposal 權限與合法 Standalone Builder 的 `product.write` 分開；這也不是 10 月 27 日新提出的架構思想。

**因此，四份文件的大部分架構原則屬於既有 r2 的具體化，而非新增核心能力。**

### 3.2 真正新增的是什麼？

新文件最有價值的部分，是把原先較抽象的產品要求變成可以施工、可以驗證的特定契約。

| 新增或實質深化項目 | TPM 升級藍圖 | Commander 升級藍圖 | 是否值得提升至 FHS r2.1 |
|--------|--------|--------|--------|
| Portable TPM／Native TPM 雙部署 | 主要設計 | 間接依賴 | 是 |
| K0～K3 自包含文件與按需檢索 | 完整設計 | Guide 不重複全文 | 是，但保留在產品章 |
| PIPD P4 十八項受影缺陷修復 | 完整列出 | 引用相關 ABI | 是，採摘要與對應 Gate |
| 三角色 × 六階段 TPM Contract | 18 個契約 | 不負責 TPM 真相 | 是，先裁決 StageMap |
| Guide／PLAN／Builder 分權 | 未詳細定義 | 核心改進 | 是 |
| GitHub Delivery Decision | 具體狀態機、Schema、測試 | 僅作適用性建議 | 是 |
| Proposal Draft／Issued WO／Execution Prompt 三分 | Handoff ABI 基礎 | 明確拆分 | 是，P0 |
| 舊 Commander Plugin 的產品繼承 | 保留三 SP | 需要正式 Supersession ADR | 是，P0 |
| Codex-first 初版施工 | 明確採納 | 明確採納 | 可納入施工策略，不改架構 |
| Host Installer／Load／Invoke／Uninstall | TPM Plugin 驗收 | Commander Guide 驗收 | 是，產品級回歸 |
| 兩條施工 Track 與退出條件 | WP00～11 | WP-00～12 | 應整合為一套受影 DAG |

**裁決：新文件值得被吸收，但應提升其「關鍵接口、法位、差異與驗收規則」，不應把兩份總計約 2,700 行的藍圖重新複製進 r2 正文。**

---

## 四、四份文件之間必須先解決的架構衝突

兩份升級藍圖在主要原則上一致，但並非完全沒有整合風險。

本節是升級前最需要完成的工程裁決。

### 4.1 衝突 C-01：Native TPM 和 Native Commander 是否會重複建立施工 DAG？

TPM 藍圖 §4.2 定義：

`goal.open → tpm.plan → mission.handoff → mission.run`

其中 `tpm.plan` 會產生 18 個階段投影及 WorkDAG。

Commander 重構藍圖 §4.1～4.2 則將 PIPD Reader、Task DAG、Worker Profile、PlanDelta 交由：

`HGK.PLAN.SBL_COMMANDER`

兩者如果各自保存正式 DAG，會產生新的重複規劃來源。

例如：

- TPM 認為 A → B → C 必須依序執行。
- Commander 認為 B 與 C 可以並行。
- HGK 收到兩份不同的 DAG。
- Hermes 不知道哪一份是正式有效的執行順序。

**這會重演 B1 的多入口及多控制真相問題。**

#### 正式建議

定義一個規劃責任分界：

| 元件 | 負責內容 | 輸出 |
|--------|--------|--------|
| SBL-TPM-SP | 使用者目標、產品／系統／計畫規格、交付偏好 | `ProductIntent / ProgramSpec / PlanningCandidate` |
| Native SBL-TPM | PIPD 生命週期協調、正式編譯請求、工程狀態展示 | `LifecycleCoordination / MissionRequest` |
| SBL Commander PLAN | 從合法規格形成工作依賴、資源規劃、Worker／Lane 候選、Replan | **唯一有效的 Plan Revision Proposal** |
| HGK | 正式工作卡准入、授權及 WorkOrder 狀態 | Native Admitted WorkOrder |
| Hermes | 依正式工作卡派工、執行、持久恢復 | Execution State／Raw |

Native TPM 應協調 Commander PLAN，而不是在 Commander 之外保存另一套可獨立決定派工的 WorkDAG。

若現有 SBL Core 已有 Planning 模組，則應以現有模組為共用規劃服務，而非建立兩份新 Planner。

**此問題必須列為 r2.1 P0 接口裁決。**

### 4.2 衝突 C-02：外部 Commander 從 Plugin 改成 Guide Skill，是否違反原始三 SP 產品義務？

FHS r2 R15.1 §3.3 明確保留五件產品工具，其中包括：

`Tool-2 Commander-SP`

並要求具備 Installer、Doctor、Load、Invoke、Deny、Uninstall 等 Host 驗收。

Commander 重構藍圖則建議將外部 Commander 變成：

`SBL-COMMANDER-GUIDE`

其性質為薄型、只讀、無效果的 Guide Skill。

這不是單純換名稱，而是**產品身份及交付形態的實質變更**。

它可能影響：

- 原 Commander-SP 的安裝與卸載義務。
- 既有 Plugin Manifest、Host 路由與相容性。
- 原先 SBL 三 SP 的完整產品要求。
- `product.write` 能力應由哪個合法 Builder 承接。
- 既有私人 Plugin、ZIP 或 Host 的發行要求。

#### 正式建議

採納 Guide／PLAN 分離，但保留原有產品身份 Ledger，建立：

`ADR-SBL-COMMANDER-SPLIT`

由 SBL Owner 正式裁決：

| 原能力 | 新歸屬 |
|--------|--------|
| 指揮分析、設計比對 | 外部 Guide |
| 非授權 Proposal | Guide 或 Native PLAN，依入口適用性 |
| Task DAG／Replan | 內部 SBL Commander PLAN |
| Repo 實際寫入 | 合法 EXECUTE／Standalone Builder |
| Native WorkOrder Issue | HGK |
| Durable Execution | Hermes |
| Independent Acceptance | 真 Checker |
| 舊 Commander-SP Host／Plugin 交付義務 | 保留直到正式 Supersession |

**不建議直接刪除舊 Commander-SP 的全部交付義務，也不建議繼續讓它擔任 B1 Bootstrap 的必經控制入口。**

這是兩份文件整合中最需要正式 Owner 裁決的產品級問題。

### 4.3 衝突 C-03：一套 TPM Plugin 與外部 Commander Guide 是否矛盾？

**不必然矛盾。**

TPM 藍圖要求「只安裝一套新版 SBL-TPM-SP，基礎 DOC 不必反覆上傳」，其對象是完整 TPM／PIPD 規劃入口。

Commander 藍圖則主張 Commander 引導功能採極薄 Skill。

可採用的產品形態是：

產品分發與原生執行的分層

**Portable SBL-TPM-SP**

完整規劃入口、版本化 DOC、PIPD Reader／Skills、候選契約

**SBL Commander Guide**

輕型分析、建議、FirstFail、非授權 Proposal，可獨立或選配使用

共用受信版本化契約，不共用效果權限

**Native SBL-TPM + SBL Commander PLAN**

協調 PIPD 正式編譯、HGK 准入、Hermes 施工及獨立驗收；不另建控制平面

如果產品需求是單一安裝體驗，Guide 可在相容 Host 中作為受限入口或選配模組打包；如果是獨立 Agent Skill，則保留獨立發行身份及可撤銷機制。

必須先確認 Host 是否支援此類封裝，不應先承諾跨 ChatGPT、Codex、Hermes 的實際載入行為完全相同。

**「一套 TPM 入口」不應被擴張成「所有 SBL 技能及安全 Principal 必須變成同一個 Plugin」。**

### 4.4 衝突 C-04：自包含文件是否成為第二套過時的 Canonical Truth？

TPM 藍圖 §8 提出：

- K0：PIPD 10 冊、SBL 14 冊完整原文。
- K1：SourceManifest／ClauseIndex。
- K2：Supersession／ConflictRegistry。
- K3：按需閱讀。

這能消除使用者每次重新上傳基礎文件的負擔，也符合 PIPD DOC-08 Progressive Disclosure 原則。

但仍有兩個不可忽略的風險。

**第一，文件已封裝不表示文件仍是最新有效版本。**

Plugin 隨附的完整 DOC 應視為具有精確版本的 Snapshot，並與正式 PIPD／SBL Source Registry 比對。

若上位 Source 已發生變更，而 Plugin 尚未更新，應標示 `SOURCE_STALE` 或相應 Currentness 狀態，不能因 K0 原文完整便宣稱符合最新規範。

**第二，自包含不代表擁有再散布權。**

內部上位文件、私人討論、PIPD Skill 契約、原始 Fixture 及產品敏感資料，應依實際授權與內容權利分別處置。

建議：

`Approved Corpus Snapshot → Exact SourceManifest → Content-addressed Index → Applicable Clause Retrieval → Currentness Check`

不新增第二個 SourceFreeze Writer。

此項**值得納入 r2.1 的產品分發章節**，但具體封裝路徑與索引演算法應保留在 TPM 子藍圖。

### 4.5 衝突 C-05：GitHub「必檢」是否會重新造成治理過重？

TPM 藍圖 §6.1～6.4 提出：

`GitHub Decision Check = Mandatory`

但同時明確要求：

`GitHub Publication ≠ Mandatory`

這是一項合理的產品補強，尤其能避免系統已完成工作，卻忘記詢問使用者是否希望建立 PR。

不過，必須保留三條限制：

| 限制 | 工程裁決 |
|--------|--------|
| 何時適用 | 對有可交付實作及遠端交付可能性的 Mission 檢查 |
| 何時詢問 | 同一 Subject／QuestionKey／SchemaVersion 尚無有效決策時 |
| 何時阻斷 | 只有受影遠端效果真正需要權限時，才 PARK 相應發布工作 |

`LOCAL_ONLY` 應允許合法本地交付完成；但若生效契約明確要求 GitHub PR，不能利用選擇 `LOCAL_ONLY` 規避該 Required Delivery Obligation。

GitHub 的意向決定、Repo Publisher 授權和實際 Remote Write 是三件不同的事情。

**因此，建議將 GitHub Decision 規範納入 r2.1，但不能變成每張普通修補卡都必須重新詢問使用者。**

### 4.6 衝突 C-06：原有 PIPD P4 工具能否直接內建？

**不建議原樣內建。**

TPM 新藍圖列出十八項 P4 修補內容，當中包含前輪已確認的：

- 跨工件 Atom／Trace Hash 不一致。
- ECP 與 PD Subject 不一致。
- TQAEP Receipt 同主體對應問題。
- TraceGraph Closure 缺乏真重算證據。
- PI／PD／ECP Typed Artifact Resolver 不足。
- DOC-06 十二軸與 P4 九軸風險模型不等價。
- Oracle Locator／Writer 相容問題。
- TQAEP Planned／Executed／Independent Accepted 混用。
- Repo ECP 被過度套用至 Host／User／Remote Effect。

這些缺陷已在先前 PIPD 專項研究中被辨識，新 TPM 藍圖進一步提供 P4-01～P4-18 的回歸清單。

**建議做法：修復單一受信 Canonical Compiler／Skill 契約及其版本化 Adapter，再供 Portable TPM 和 Native TPM 共用。**

若兩種部署各自修一套 P4，未來很容易發生：

`Portable PIPD PASS ≠ Native PIPD PASS`

尤其可能造成同一目標使用不同 Oracle、不同 Profile 或不同 EffectClass 判定。

---

## 五、其餘重要衝突與新增風險

### 5.1 C-07：TPM 的十八項 StageContracts 尚有上位映射爭議

TPM 升級藍圖 §11.1 的 `CR-05` 明確保留：

`CR-DOC04-STATE-MAP`

問題涉及 T0～T5 中 T4／T5 的來源映射。

因此，雖然「三個角色 × 六個階段 = 18 項契約」已具備完整的設計要求，但不能因數量正確就宣稱所有階段語義已正式裁決。

**處置：** 由 SBL DOC-04 所屬 Owner 依來源版本、階段輸入輸出、原始身份及相容性進行裁決；無爭議的 T0～T3 可依自身准入繼續，受影的 T4／T5 保持具名 HOLD。

這屬於產品契約缺口，不應透過 FHS-MSC 上位藍圖自行改寫 SBL 正式 StageMap。

### 5.2 C-08：新增 GitHub Remote Effect 不可私自改寫 PIPD ECP

TPM 藍圖提出獨立的 `GitHubDeliveryDecision@1` 及 `PublicationEffectRequest@1`，方向正確。

但其中的 `REMOTE_PUBLICATION` 只能先視為建議的 Domain Effect Classification，不能直接宣稱 PIPD Canonical Schema 已支援該 Enum。

如果原始 PIPD P4 仍使用嚴格 `additionalProperties:false`，直接加入 `publish_to_github` 等欄位可能被正確拒收。

**裁決：** GitHub 遠端效果應由有權的 Repo Publisher／PIPD Owner 版本化確立相容 ABI。不得讓 SBL 的產品偏好自行擴張 PIPD Canonical Schema。

### 5.3 C-09：新 Commander PLAN 與 FAR 自動研究可能重疊

FHS r2 已有 FAR 自動研究及 Known Fix Reuse；新 Commander 重構藍圖又賦予內部 PLAN 診斷、修補規劃和自動裁決能力。

兩者可以共存，但應明確分工。

| 能力 | 應有責任 |
|--------|--------|
| 偵測 Native FirstFail | HGK／Hermes 真實事件及觀測 |
| 已知修復查找 | 現有 Known Fix／FAR |
| 深入根因研究與反證 | FAR |
| 形成受證據支持的工程建議 | FAR Recommendation |
| 排列合法工作、Worker、資源與依賴 | SBL Commander PLAN |
| 需要人類裁決的建議呈現 | SBL Decision UI／合法 Owner 流程 |
| 效果准入 | HGK |
| 持續執行 | Hermes |
| 正式驗收 | Independent Checker |

應避免 Commander 內建另一個大型 FAR 引擎。

另外，本次四份文件雖已規劃事件、提案及使用者操作，但**尚未充分證明「FAR 建議 → 使用者點選 → Native Action → 自動續工」的實機閉環**。

因此，應將前輪 FAR 主動建議與一鍵操作方案保留為 r2.1 的獨立端到端驗收項，不應因完成 TPM／Commander 重構就視為自動完成。

### 5.4 C-10：兩份藍圖都含施工計畫，不能各自建立正式工作 Queue

TPM 藍圖有 WP00～WP11；Commander 藍圖有 WP-00～WP-12。

兩者包含大量共同工作：

- Source／Repo／Host Inventory。
- PIPD／SBL ABI。
- Codex-first 候選修補。
- HGK Receiver／Hermes Executor。
- Donor Capability Registry。
- 独立 Checker。
- CI、Release 及產品驗收。

如果直接把兩套 WP 加總派給 Hermes，就可能重複施工和反覆驗收。

**正式做法：建立一份統一的 `Change／WorkPackage Crosswalk`，保留兩份藍圖的原始 ID，但同一個實際修補操作只生成一組有效 WorkOrder。**

在現役 HGK／Hermes WorkState 中使用同一個 Mission／Operation 身份，不另建一套新 Ledger。

### 5.5 C-11：模型選型是期望政策，不是已實際可用的 Host 能力

Commander 重構藍圖建議 PLAN 使用 OpenAI 模型，EXECUTE 優先使用 OpenCode Go，並配置各自備援。

這應視為特定版本的 **Desired Model Policy**。

正式路由仍需確認：

`Required Model → Admitted Provider → Transport → Credential Principal → Actual Served Model → Receipt`

尤其 B1 曾出現指定 OpenAI 模型，實際經 Desktop Router 轉往 DeepSeek 的情況。

模型名稱、Provider、OAuth、API Key、實際回應來源及機器 Principal 不應互相推定。

**r2.1 不必固定新增模型選型表；應保留既有三 Lane 的正式模型路由規則及 Required／Served 驗證。** 具體模型版本及備援表應放在有版本的 Role Policy，並以真 Host 收據重新資格化。

---

## 六、建議採納的最終統一架構

### 6.1 架構裁決

建議採用：

**`ONE SBL PRODUCT ARCHITECTURE / TWO TPM DEPLOYMENTS / ONE NATIVE COMMANDER ROLE / ONE HGK CONTROL PLANE`**

| 層級 | 組件 | 正式職責 |
|--------|--------|--------|
| 使用者規劃入口 | Portable SBL-TPM-SP | 自然語言、Spec、文件檢索、PIPD 候選、交付偏好 |
| 外部工程引導 | SBL Commander Guide Skill | 比對、研究建議、診斷、非授權提案 |
| 原生生命週期協調 | Native SBL-TPM | 串聯規劃、正式編譯、任務交接、驗收及交付 |
| 原生執行規劃 | `HGK.PLAN.SBL_COMMANDER` | 唯一受治理 Plan Revision Proposal、DAG／Replan |
| Canonical Contract | PIPD-LS-SP | 唯一正式編譯權威 |
| Policy | Fabric | 有效 Policy、Stage／Active／Loaded／Consumer |
| Native Control | HG-KSEOS | WorkOrder、Permit、Admission、Native State |
| Runtime | Hermes | Durable Queue、Worker、CAS Lease、Resume |
| Research | FAR | 根因研究、Known Fix、方案比較與推薦 |
| Engineering | Codex／EXECUTE | 有界工程修補及測試 |
| Assurance | Independent Checker | 真正獨立的 Oracle／Raw 驗證 |
| Delivery | SBL／Repo Publisher | 本地成果、受權遠端交付及使用者結果 |

這個架構與 FHS r2 完全相容，但應加入四個強制條件。

**第一，Native SBL-TPM 是生命週期協調能力，不是第二個常駐 Scheduler。**

**第二，SBL Commander PLAN 是現有 PLAN 車道的專家角色，不是第四車道。**

**第三，Portable Plugin 的內建文件是有版本的來源快照，不是第二個 Canonical Registry。**

**第四，外部 Guide 與內部 PLAN 均不能自行產生 Native Permit、修改正式 Oracle 或簽署 Independent Acceptance。**

---

## 七、《FHS-MSC\_藍圖\_r2》應具體修訂哪些章節？

建議以 12 項受影變更形成 r2.1 候選。

| 變更 ID | 建議修改 r2 章節 | 變更性質 | 優先度 |
|--------|--------|--------|--------|
| FHS-21-01 | §5.2、R15.1 §3 | TPM／Commander／FAR Role Responsibility Crosswalk | P0 |
| FHS-21-02 | §5.3、R15.1 §3.2～3.3 | Portable TPM、Native TPM、Guide／PLAN 產品身份 | P0 |
| FHS-21-03 | §5.4、§5.9 | Proposal／Admitted WorkOrder／Execution Prompt 的正式邊界 | P0 |
| FHS-21-04 | §5.1、R15.1 §4 | PIPD P4 Semantic Resolver、Profile、Oracle、TQAEP 相容性 | P0 |
| FHS-21-05 | §6.1～6.3 | Standing Authorization、FAR Decision、局部阻斷與恢復 | P0 |
| FHS-21-06 | R15.1 §12.5～12.6 | Hermes Mission Termination／Resume 強制控制 | P0 |
| FHS-21-07 | R15.1 §3／產品交付章 | 自包含 K0～K3 Corpus／Versioned Currentness | P1 |
| FHS-21-08 | R15.1 §3、§14 | GitHub Decision／Remote Effect／Publisher | P1 |
| FHS-21-09 | R15.1 §7 | 六 Donor／24 Slot 的選擇性 Runtime Qualification | P1 |
| FHS-21-10 | R15.1 §3.3、§14 | 三 SP 與五工具產品義務繼承、Host UAT | P0 |
| FHS-21-11 | §7～8、R15.1 §5～6 | TPM／Commander 統一 WorkPackage DAG | P1 |
| FHS-21-12 | §11、R15.1 §14 | 機器化 Evidence／Regression／全量身份保留 | P1 |

### 7.1 應新增的正式決策文件

至少需要三項具版本的 Owner 裁決：

| ADR 候選 | 解決問題 | 所屬權威 |
|--------|--------|--------|
| `ADR-SBL-TPM-DUAL-DEPLOYMENT` | Portable TPM 與 Native TPM 的產品／部署／責任界線 | SBL Product Owner，相關 Host Owner 共同確認 |
| `ADR-SBL-COMMANDER-SPLIT` | 舊 Commander-SP → Guide／PLAN／合法 Builder 的權責及產品繼承 | SBL Product Owner／HGK |
| `ADR-SBL-PLANNING-AND-HANDOFF-ABI` | TPM Planner 與 Commander PLAN 的 DAG 所有權、Proposal／WO 分離 | SBL／PIPD／HGK／Hermes 各法域 Owner |

另有已存在的 `CR-DOC04-STATE-MAP`、`CR-ORACLE-001` 和 PIPD Canonical Schema 相容性問題，必須回到原有 Writer／Owner 裁決，不能由 r2.1 自行修改其生效意義。

### 7.2 不需要修改的部分

以下應保留現有原則及原始身份：

- R15.1 全量產品身份及原始分母。
- SBL 六模組及 Standalone／Connected 產品能力。
- 三實體 Lane 和既有 Profile Team。
- 唯一 PIPD Canonical Writer。
- 唯一 HGK Native Issuer。
- Hermes 現有 Durable Dispatcher／SharedSpine。
- Fabric Policy 原生來源及載入權責。
- FAR 原始研究服務及合法 Proposal-only 身份。
- Independent Checker 真實機器分權。
- SWOF PRE-W3 與正式 W3 的法位區分。

**不建議為 r2.1 再增加新的產品架構章數或大型獨立控制系統。**

---

## 八、如何將四份新文件整合成一套不重工的施工計畫？

兩份新藍圖的施工工作高度重疊，建議合併成下列六個 Workstreams。

| Workstream | 工作內容 | 主要責任 | 最小退出條件 |
|--------|--------|--------|--------|
| WS-0 | Source、Host、Repo、Plugin、ABI 現況基線 | SBL／PIPD／HGK | 真版本及缺口可定位 |
| WS-1 | PIPD P4 共用相容修復 | PIPD Owner＋Codex | 原 POS／NEG／EDGE／SEC 與 Semantic Validator 合格 |
| WS-2 | Portable TPM、自包含 Corpus、GitHub Decision | SBL＋Codex | Host 真載入、零基礎 DOC 重上傳、受影契約驗證 |
| WS-3 | Commander Guide／Native PLAN 與統一 Handoff | SBL／HGK | 產品身份與 Proposal ABI 正負例通過 |
| WS-4 | HGK／Hermes／Fabric 原生鏈路與 FAR 決策操作 | HGK／Hermes／Fabric／SBL | 真 Effect、Resume、Decision Action、Checker 收據 |
| WS-5 | 產品回歸、Golden Journeys、正式發行 | SBL／Independent Checker／Publisher | 全部適用 Required 和已觸發 Conditional 通過 |

### 8.1 最佳施工順序

**WS-0 應先完成最小必要的真實能力盤點**，否則後續可能把已有功能重寫。

之後可以並行：

- WS-1：PIPD ABI／Fixture 修復。
- WS-2：Portable TPM Corpus／GitHub 決策。
- WS-3：外部 Guide 候選與產品 ADR。
- WS-4 的合法唯讀 Native Discovery。

正式 Handoff 必須等待其依賴的 Canonical ABI 定案；但不依賴正式 HGK Effect 的普通工程，不應等待整個 B1 G-B 完成。

**Codex-first 是適合目前 Bootstrap 的施工策略，不是要永久將 Hermes 排除在工程外。**

Codex 可以執行有界工程修補，Hermes／HGK 則負責後續原生整合與自治任務。

### 8.2 必須避免的兩種極端

不建議「先將四份新文件全部正式升版完畢，再允許任何施工」。

這會重演 B1 全域 Gate 錯置。

同樣不建議「先依設計樣例直接安裝 Native TPM 和 Commander，之後才處理來源／權限／ABI」。

這會產生新的安全與相容性問題。

正確做法是：

**合法普通工程與設計驗證可以並行；真正 Native Effect、正式驗收與 Release 必須依各自前置逐項准入。**

---

## 九、正式升級的核心驗收標準

### 9.1 新增跨 TPM／Commander 的十六項回歸測試

| Test ID | 驗收要求 | 防止的失效 |
|--------|--------|--------|
| CONV-01 | Portable TPM 與 Native TPM 消費同一批准來源身份 | 雙 Canonical Truth |
| CONV-02 | 兩者對同一 PIPD 合法輸入取得相容的 Typed 結果 | ABI 漂移 |
| CONV-03 | TPM 與 Commander 不產生兩套可獨立派工 DAG | 雙 Planner |
| CONV-04 | Guide 不可取得 Repo Write／Issuer／Checker 權限 | Guide 權限膨脹 |
| CONV-05 | Commander PLAN 只能生成受限提案 | PLAN 冒充 Permit |
| CONV-06 | Proposal Draft 與 HGK Admitted WorkOrder 可精確區分 | Bootstrap 循環 |
| CONV-07 | 24 冊基礎 DOC 在有效授權下可由自包含 Plugin 按需檢索 | 反覆上傳 |
| CONV-08 | Corpus 更新後 Currentness／Supersession 正確受影失效 | 過時文件當權威 |
| CONV-09 | 缺 Oracle、Source 或 StageMap 時只 HOLD 受影工作 | 全域停工 |
| CONV-10 | GitHub 未決定時本地工作繼續、且不擅自 Push | 決策 Gate 過重 |
| CONV-11 | 同一已回答的 GitHub 問題不重問 | 單一 OWNER 反覆操作 |
| CONV-12 | 任務出錯能自動使用 FAR，並重用已驗證 Known Fix | 人工 Prompt 依賴 |
| CONV-13 | FAR 建議可透過有效 Native Action／Owner UI 操作 | 建議與執行斷鏈 |
| CONV-14 | Worker／Session 中斷後不重播未知效果，合法工作可恢復 | 自治續航失效 |
| CONV-15 | 舊 Commander 的原產品義務有版本化遷移與回歸證據 | 產品功能縮減 |
| CONV-16 | 真 Host Installed／Loaded／Invoked／Denied／Uninstalled 與 Checker 身份完整 | 形式 PASS、實際不可用 |

CONV-12、CONV-13 是承接前輪 FAR 主動建議與一鍵操作需求的關鍵測試。

兩份新升級藍圖都不應因為具備推薦文字或示例 Action Schema，就自動宣告這兩項已經完成。

### 9.2 不得宣告正式升級成功的情況

以下均只能算局部成果：

| 已有成果 | 不能替代 |
|--------|--------|
| 自包含 Plugin ZIP 建立 | Host 真安裝／載入 |
| 24 冊 DOC 全文收錄 | 正式 Source Ratification／Currentness |
| PIPD Schema／Fixture 全綠 | 真 Compiler／跨工件 Semantic Valid |
| Guide Skill 產出 Proposal | Native Admitted WorkOrder |
| Commander PLAN 產生 DAG | Hermes 真 Executor 執行 |
| GitHub Decision 已記錄 | 遠端有效 Publisher Permit |
| GitHub CI 通過 | Host Loaded／Native World Effect |
| FAR 研究出最佳方案 | Owner 授權／實際執行 |
| 不同模型擔任 Maker／Checker | 真正獨立 Principal |
| B1 Report／Manifest 封存 | Native G-A／GWO／G-B Acceptance |

特別是新文件對 `SourceFreeze`、`G-A`、`G-B`、Native Receiver、Hermes Executor、Fabric Loaded、三模型 Served 及 Checker 的實機證據均保留未完成或待驗證狀態。

這些不應由 r2.1 升版的作者端工作自動關閉。

---

## 十、四份新文件最值得吸收的具體工程改進

綜合而言，可以將真正新增的價值濃縮為五個主題。

### 10.1 從「單一 AI 角色」升級為「同源、不同權限的產品形態」

Portable TPM 適合自然語言規劃和契約候選。

Native TPM 適合協調原生生命週期。

Guide 適合工程比對與建議。

Commander PLAN 適合真正的規劃與有界重新規劃。

它們不應共享未經隔離的效果權限。

### 10.2 從「使用文件」升級為「自包含但可驗證的來源消費」

未來使用者不應每次都重新提供相同的基礎 DOC。

但文件封裝必須保持來源身份、完整性、版本、適用性及權限。

**免重傳不是免驗證。**

### 10.3 從「文件符合 Schema」升級為「跨工件語意正確」

PIPD P4 先前出現的 Hash、Subject、Receipt、Profile、Oracle 問題，代表僅靠形狀驗證不足。

未來 Portable 與 Native 必須共用正式可信的 Semantic Resolver，不能各自讓模型補足缺失的語義。

### 10.4 從「完整規範全部套用」升級為「依工作效果與階段適用」

Repo Write、Host Operations、User Data、GitHub Publication 和純唯讀診斷，不應使用相同前置與准入條件。

這能保留必要安全性，也避免單一 HOLD 導致所有施工停止。

### 10.5 從「生成指揮 Prompt」升級為「真正執行、研究、決策及恢復」

新的 Commander 不應再依賴更長的 Prompt 保證任務繼續。

應使用真實的 WorkState、Lease、Event、FAR、Native Admission 和 Resume。

使用者面對的應是：

**已完成什麼、目前阻斷什麼、FAR 建議什麼、需要我批准什麼，以及批准後系統如何自動繼續。**

---

## 十一、最終升版選擇比較

| 方案 | 優點 | 主要缺點 | 裁決 |
|--------|--------|--------|--------|
| A：完全不修改 r2 | 無版本修訂成本 | 新的 TPM 雙形態、Commander 分工、GitHub 決策等缺少全域清晰接面 | 不建議 |
| B：將四份文件全文併入 r2 | 看似覆蓋最完整 | 重複大量既有規範、產生衝突、多套工作計畫與沉重閱讀成本 | 不建議 |
| C：受影升級 r2.1，兩份子藍圖維持獨立 | 權責清楚、低重工、保留詳細產品設計、容易回歸 | 需要正式 ADR／Crosswalk | **建議採納** |
| D：全面重建 FHS-MSC r3 架構 | 可以重畫整個系統 | 重建 Writer／Issuer／Scheduler 風險高，與既有最小架構原則衝突 | 拒絕作為本次預設方案 |

### 建議採用 C

具體而言：

**《FHS-MSC\_藍圖\_r2》升級為高保留的 r2.1 候選，四份新文件作為具版本身份的技術與產品子設計來源；正式納入少量新接口和必要不變量，其他詳細施工、測試及程式樣板保留在原子藍圖。**

這樣既能使 FHS-MSC 吸收本次真正有價值的產品改進，也能避免再次創造一份需要全部 Agent 每輪閱讀的超大型施工規範。

---

## 十二、正式結論

### 問題一：四份文件是否有必要用來升級《FHS-MSC\_藍圖\_r2》？

**有必要，而且值得採納。**

但主要應吸收的是 TPM 雙形態、Commander Guide／PLAN 重新分權、共用 PIPD ABI、自包含文件、GitHub 交付決策，以及跨元件的正式操作與驗收契約。

不是重新創造 FHS-MSC 的核心架構。

### 問題二：r2 是否原本已經規劃了大多數解法？

**是。**

三 Lane、Single Issuer、Single Writer、FAR、Hermes Durable Resume、Standing Authorization、局部 PARK、Full Product 分母和 Codex Bootstrap，均已具備明確上位規範。

新文件主要讓原始產品功能更具體，也揭露若干需要正式裁決的兼容性問題。

### 問題三：TPM 與 Commander 升級藍圖是否能直接全面採納？

**不能直接無條件採納。**

必須先解決：

- TPM 與 Commander 的 DAG／Plan Revision 權責。
- Commander-SP 產品身份和原始 Host／Plugin 交付義務。
- PIPD P4 Semantic／Oracle／Profile／TQAEP 相容。
- SBL T4／T5 StageMap 爭議。
- 自包含 Source Snapshot 與正式 Source Authority 的更新關係。
- GitHub Remote Effect 的真正授權及 Schema。
- 真實 HGK／Hermes／Fabric／Checker 接線與驗收。

### 問題四：此次最優先需要施工的是什麼？

**優先是三項 P0：**

1. **產品及角色裁決：** TPM、Commander Guide、Native PLAN、Builder、HGK、Hermes 的唯一責任與接口。
2. **正式契約修復：** PIPD P4、Proposal／Issued WorkOrder、StageMap、Canonical Source／ExecutionAdmission。
3. **Runtime 自治閉環：** HGK Receiver、Hermes Executor、FAR 自動研究／決策操作、Durable Resume、Independent Verification。

三者形成可靠基礎後，再完成 Portable Plugin 的正式 Host 發行及全產品回歸。

## 最終工程裁決

**`ADOPT_WITH_TARGETED_RECONCILIATION`**

`FHS-MSC r2.1 — High-Retention Convergence Upgrade Candidate`

---

**保留：** 原有五方權責、三 Lane、三 SP 產品義務、PIPD 唯一 Canonical、HGK 單一 Native 權威及 Hermes 持久執行。

**升級：** TPM 雙形態、Commander Guide／PLAN 分離、共用正式 Handoff ABI、PIPD 語意相容、版本化 Corpus、GitHub Decision、FAR Action 閉環。

**禁止：** 第二套 Compiler、Issuer、Scheduler、Policy Truth、獨立驗收權威及任何未經正式准入的世界效果。

**驗收界線：** 文件升級成功不等於 Native 系統已部署、B1 正式驗收通過或 SBL Full Product Release。

**整體鑑定結論：四份新文件應成為 FHS-MSC r2 的重要受影升級來源，但其價值在於把已存在的高自動化架構真正產品化、接口化和可驗收化，而不是再次擴張治理架構。**

本次已進行文件來源、既有規範、產品責任、施工策略與驗收契約的交叉研究；尚未對 Windows 現役 Native 系統執行重新驗收，也未修改原始文件或正式發布新版藍圖。

## Prompt:
2026/10/28 上午1:04:32

任務目標：
你必須整合前輪你提出的「FHS-MSC r2 × SBL-TPM × SBL Commander 四份升級文件——跨架構整合與藍圖升版工程鑑定報告」，再對進行以下項目的專業工程「研究分析 + 交叉比對 + 鑑定評估」：
"
是否用GPT的WORK模式或CODEX，以升級過的「FHS-MSC_藍圖」，先對「SBL_PIPD-LS-PKG」進行升級修補成「FHS-MSC_PIPD-LS-PKG」，把「SBL_PIPD-LS-PKG」保留原本設計原意和目標，但是修補目前「治理過度、鏈路阻斷、內部衝突/矛盾、授權不明、單人OWNER主權/授權支援度不高、高自動化支援度不佳......等等」全部問題解決，再執行「FHS-MSC_PIPD-LS-PKG」把之前「SBL_PIPD-LS-PKG」沒做完的部分實作完成，是否會對整個「FHS-MSC」工程執行會更快、更通順、更穩健、更少試錯和其他風險?

因為其實如果大架構都可用的話，用GPT的WORK模式或CODEX對於文檔的自動化處理，其實速度很快?前期花費小時間，是否能換取整個工程執行的高CP值?
"

任務要求：
你必須針對任務目標，並對全部相關資料進行「研究分析+交叉比對」，再進行鑑定、評估、規劃，並提出完整報告。

## Response:
2026/10/28 上午1:04:51 · gpt-6-thinking

我會把這個方案當成「先修施工契約、再提高整體工程吞吐量」的投資決策來評估，而不是預設全面重寫一定更快。先核對 FHS-MSC r2、SBL DOC-00～13、兩份 TPM／Commander 升級藍圖及 B1 失效證據，再確認 GPT Work 與 Codex 的現行能力，最後比較「直接續工」、「全面重編」和「高保留、受影修補後續工」三條路徑的成本、風險及驗收條件。

來源核對顯示一個重要的取捨：SBL DOC-00～13 原始文件共有 14 冊、約 1,747 萬位元組、75,630 行，而且 DOC-01 明確規定 SBL 是獨立產品，具有 One Core、Three SP 及不可任意轉移的產品原意。這支持「建立 FHS-MSC 衍生施工控制包」，但不支持直接把 SBL Canonical 規範改名成 FHS 規範。另一個發現是 r2 本來已設有 P0～P4 的有界 Bootstrap 修復順序；新方案應插入其中作為加速層，不能再新增一道「14 冊全部改完才能開工」的全域前置。

> **列出上傳檔案以供分析**
>
>
> **列出上傳檔案供分析**
>
> 
>
> **已搜尋 3 個網站**
>
> 
>
> **檢視 SBL 文件標題與關鍵元資料**
>
>
> **檢視 SBL 文件標題與關鍵元資料**
>
> 
>
> **檢視並檢索SBL藍圖核心文件段落**
>
> 
>
> **計算文件規模與推薦依據**
>
>
> **計算文件規模與推薦依據**
>
> 
>
> **已搜尋 1 個網站**
>
> 
>
> **整理DOC00-13文件標題與治理對照**
>
>
> **整理實作範圍**
>
> 我正在把既有套件拆成文件映射、成本效益模型與試點驗證三條線。下一步會先界定基準、代表性流程、人工介入與成本指標，避免把設計目標誤寫成已驗證成果。
>
> **規劃雙階段實作**
>
> 我正在依據 Windows 本機工作環境，安排 Work Local 與 Codex 的分工，並加入憑證不外洩原則。報告會涵蓋四項交付物、轉換標準與可驗證的試點計畫。
>
> **整理實作範圍並規劃雙階段實作**
>
> 
>
> **整理DOC00-13文件標題與治理對照**
>
> 
>
> **檢索藍圖文件與未解決阻塞項目**
>
>
> **檢索藍圖文件與未解決阻塞項目**
>
> 
>
> 處理時間為 7m 4s

# FHS-MSC 工程策略鑑定報告：是否應先以 GPT Work／Codex 升級 SBL PIPD-LS-PKG，再執行整體工程？

鑑定日期：2026 年 10 月 28 日｜評估範圍：FHS-MSC r2、SBL\_PIPD-LS-PKG DOC-00～13、PIPD-LS DOC-00～09、TPM／Commander 四份升級文件、B1 失效紀錄及 GPT Work／Codex 現行能力

## 一、最終核心裁決

**建議採納這個方向，但應採用「先修關鍵施工契約、再由修復後的控制包帶動工程」的高保留方案，而不是把 14 冊 SBL 文件全部重寫後，才允許 FHS-MSC 開工。**

這個提案的工程價值相當明確：

**目前限制 FHS-MSC 效率的因素，不只是程式尚未完成，而是施工規格、治理適用性、工具 ABI、授權順序、Native 執行入口與任務恢復之間存在不一致。**

如果每次都直接要求 Hermes／Codex 執行尚未完成整合的 SBL 控制包，施工階段可能不斷重複：

`編譯拒收 → 人工分析 → 修 Prompt → 重新授權 → 部分修補 → Native HOLD → 再次分析`

將已知的系統性問題提前修復，理論上可以降低後續每一輪的重試成本。

但也有一項關鍵風險：

**如果先花大量資源建立另一份更龐大的 FHS-MSC 控制包，卻沒有改變真正的 Native 入口、Runner、Executor 及驗收鏈路，就只會把治理重工提前發生一次。**

因此，建議選擇以下三條路徑中的第三條。

| 策略 | 預期效率 | 主要風險 | 裁決 |
|--------|--------|--------|--------|
| A. 直接沿用原 SBL DOC-00～13，全力施工 | 初期啟動快 | 已知的上游 ABI／治理問題可能反覆發生 | 不建議作為唯一方案 |
| B. 先全面重寫 14 冊，再開始全部施工 | 文件可能更統一 | 成本高、語義流失、需要重新資格化，且 Native 問題仍在 | 不建議 |
| C. 先升級 FHS 架構契約，受影修補 SBL Package，再以新控制包逐步接管施工 | **較有機會取得最佳整體投入產出比** | 必須嚴格控制修補範圍、來源權威和施工依賴 | **建議採納** |

### 建議的總策略

**`FHS-MSC r2.1 → SBL Package 高保留修復 → FHS-MSC Execution Profile → 分階段 Native Construction`**

其中：

- 保留 SBL 原本的產品原意、功能、身份及交付義務。
- 將已知的治理錯置、內部矛盾、單一 Owner 授權及高自動化缺口修成可執行契約。
- 不建立第二套 PIPD、HGK、Hermes 或 Fabric 控制權威。
- 將新控制包首先用於修復尚未完成的 SBL Native 能力。
- 讓不受阻斷的合法工程與文件升級並行，避免「必須先把所有文件升級完才能施工」的新循環依賴。

**對於工具選擇，我建議 GPT Work 負責跨文件研究、差異分析與治理整合；Codex 負責可重播的機器契約、Schema、Fixture、程式修補、測試與 Repository 施工。**

OpenAI 現行官方說明也明確區分這兩種用途：Work 針對長流程研究、跨檔案及完整交付，Codex 專注程式開發、執行命令、測試和 Repository 工作。\[[ChatGPT Work and Codex](https://help.openai.com/en/articles/20001275-chatgpt-work-and-codex?utm_source=chatgpt.com); [ChatGPT is now a partner for your most ambitious work](https://openai.com/index/chatgpt-for-your-most-ambitious-work/?_bhlid=b229619b8c31d33de07faa7f27a4a4f2202c57cd&utm_source=chatgpt.com)\]

---

## 二、目前方案的真正投資價值：修文件，還是修執行系統？

這兩件事必須分開看。

### 2.1 SBL 原始控制包本身具有非常高的保留價值

本次直接清點已提供的原始文件：

原始控制文件

# 14 冊

DOC-00～13

正文總行數

# 75,630

依實際檔案重新計算

文件總體積

# 17.47 MB

17,473,442 bytes

《SBL\_PIPD-LS-PKG\_DOC-01》C01.1～C01.3 已經明確規定，SBL 是獨立的 SpecBuild Loop 產品，其核心主軸是：

**Guided Spec → Governed Build → Evidence-based Verify → Bounded Repair**

並且要求 One Core × Three SP × 六邏輯模組，保留 TPM-SP、Commander-SP、External Challenge-SP 的獨立身份、Human Sovereignty、取消、NoFit、卸載及有界權限。

這些是原始產品目標，而非此次治理問題的根因。

**因此，若將 SBL 全部重新設計為一套新的 FHS 產品，不但不一定能提高效率，還可能導致原本產品規格、可獨立部署能力與驗收責任流失。**

### 2.2 需要修的，是三個互相放大問題的層級

| 問題層級 | 已觀察的問題 | 應使用的修復方式 |
|--------|--------|--------|
| 上游規格／工具 | PIPD P4 Profile、Oracle、TQAEP、Hash／Subject／Fixture 等契約不一致 | 原 Owner 受影修復、共用 ABI |
| 中游 SBL 控制包 | Commander 啟動條件錯置、完整產品分母與施工工作卡混淆、授權和驗收過度前置 | 高保留規格修訂＋薄型 Execution Profile |
| 下游 HGK／Hermes／Fabric | Runner 缺口、真 Executor 未驗證、Trust／Receiver 未接線、Loaded／Served／Checker 收據不足 | 程式實作、Host 接線、原生測試 |

第一和第二層，非常適合先由 GPT Work／Codex 加速處理。

第三層不能單靠改文件解決。即使新控制包品質完美，Hermes 仍需要真 Worker，HGK 仍需要有效的 Issuer／Receiver，Fabric 仍需要正式載入及讀回。

### 2.3 哪些問題值得在正式施工前先修？

| 已知缺口 | 影響範圍 | 是否值得前期修復 |
|--------|--------|--------|
| Source／Authority／TaskKind 時序錯置 | 所有後續 PI、PD、ECP 與 WorkOrder | **優先修** |
| DOC-06 十二軸與 P4 九軸不等價 | Profile 與風險分級 | **優先修** |
| TQAEP 設計階段要求 Live Checker Receipt | Assurance／施工順序 | **優先修** |
| Oracle DOC-03／DOC-07 責任不明 | Test／Acceptance | **優先處理衝突裁決** |
| Commander Proposal／Issued WO 混淆 | Native Handoff | **優先修** |
| 單一 Owner 授權適用性不明 | 每輪施工及人工決策 | **優先修** |
| HOLD 沒有 Affected Scope／Resume | 所有自治任務 | **優先修** |
| Report／Seal 導致 Mission 提前結束 | Hermes 高自動化 | **優先修** |
| GitHub Delivery Decision 尚未完整產品化 | GitHub 發布與使用者體驗 | 可與核心工程並行 |
| 全部 24 個 Donor Method 實際安裝 | 方法生態系 | 不必全部前置 |
| 所有 ProductKind／Host 完整發行 | SBL Full Product | 保留義務，但依階段驗收 |
| 所有未觸發的 Conditional／Deferred | 後續覆蓋責任 | 不得當成當輪全部 READY 工作 |

前輪 TPM 升級藍圖已提出 P4-01～P4-18 的受影修補及回歸清單，Commander 重構藍圖也已規劃單一 Native PLAN、Guide Skill、Proposal／WorkOrder 分離與長任務續航。這些應作為修復輸入，而不是再開一輪空白架構研究。

---

## 三、最重要的架構裁決：不建議直接把 SBL Canonical 改名為 FHS Canonical

使用者提出：

`SBL_PIPD-LS-PKG → FHS-MSC_PIPD-LS-PKG`

這個方向可以成立，但須明確定義兩者的法律與工程身份。

### 3.1 正確的版本與來源關係

我建議：

SBL\_PIPD-LS-PKG DOC-00～13

原始 SBL 產品義務、身份、Trace、原生 Writer 責任

FHS-MSC r2.1 + 四份 TPM／Commander 升級來源

差異裁決、受影修補、不重複設計的整合規則

FHS-MSC\_PIPD-LS-PKG

FHS-MSC 專案衍生施工控制包，具有來源映射與版本身份

HGK／Hermes Native Execution

真實准入、施工、檢測、恢復、獨立驗收

### 3.2 `FHS-MSC_PIPD-LS-PKG` 應定位為什麼？

**建議定位為 FHS-MSC 專案的整合工程控制包與執行適用性投影，不是另一套具有獨立規範裁決權的 PIPD。**

它可以提供修訂後的契約映射、工作依賴、Reader／Runner 路由、Gate Applicability、錯誤與恢復條件，以及 FHS 專案的實作交接。

但不能自行成為：

- SBL ProductTruth 的新 Canonical Writer。
- PIPD PI／PD／ECP／TQAEP 的第二個正式 Compiler。
- HGK Native Permit 的第二個 Issuer。
- Hermes WorkState 的第二個 Scheduler。
- Fabric 正式 Policy Writer。
- 獨立 Checker／Release Authority。

### 3.3 採用三層內容，而不是再製造 14 冊同樣巨大的正文

| 層級 | 建議產物 | 用途 |
|--------|--------|--------|
| L0：Frozen Baseline／Source Manifest | SBL DOC-00～13 原始版本、SHA、原始 ID、保留義務 | 證明來源與零靜默流失 |
| L1：Repair Delta／Canonical Patch | 各 DOC 受影修補、衝突裁決、版本化 Adapter、回歸測試 | 解決真正上游規格問題 |
| L2：FHS Execution Profile | 適用的 WorkUnits、Native Tools、Gate、Permission、FAR、Resume、Acceptance | 讓 Hermes／Codex 能直接施工 |

其中 L0 不應每輪全部塞進模型 Context；應保留有完整性的來源檢索及精確 Reader Ref。

L1 是必要變更集合。

L2 才是高自動化執行器日常需要消費的最小內容。

**只有原 SBL／PIPD 所屬 Owner 合法批准的修訂，才能提升為對應領域的正式 Canonical 修補。尚未批准的部分，必須繼續標示為設計候選。**

這個三層結構是本報告提出的整合設計，不是宣稱現有工具已經正式發布這三個 Schema。

---

## 四、DOC-00～13 應如何修補，才能保留原意又減少治理阻力？

這裡建議的是**逐冊受影修補矩陣**，不是要求每冊都重新生成全文。

| 原 SBL 文件 | 必須保留的原始責任 | 建議修補重點 | 裁決 |
|--------|--------|--------|--------|
| DOC-00 | Router、來源、操作入口、版本與 Claim | 新增 FHS Reader Route、Mission／工程／Release 階段適用性，避免全部規範同時前置 | 受影修 |
| DOC-01 | SBL ProductTruth、One Core、Three SP、Human Sovereignty | 釐清 TPM／Commander 新部署形態、單一 Owner 與機器 Principal、原產品義務繼承 | **P0** |
| DOC-02 | 需求、角色、產品規格與 Trace | 保留原始 Requirements，新增「原需求 → 可執行義務／適用性／工作卡」無損映射 | **P0** |
| DOC-03 | PI、來源語意、產品規格與編譯交接 | 修 SourceFreeze、TaskKind、Oracle 前置時序及 Bootstrap 候選入口 | **P0** |
| DOC-04 | One Core、Three SP、Commander、TPM Stage Contract | 解決 C0～C9、T0～T5、18 StageContracts、Commander Proposal 與 Runtime 分權 | **P0** |
| DOC-05 | Repo Binding、PD、Construction Contract、DEV／OPS ECP | 修 EffectClass、受影 Permission、Repo／Host／User Effect 分型、Bootstrap 依賴 | **P0** |
| DOC-06 | 技術／Donor／方法能力 | 保留六 Donor／24 Slots，分離 Discovery、Selection、Installed、Effective、Invoked | 受影修 |
| DOC-07 | Security、Human Approval、Token／Trust | Standing Grant、Owner Authority、Issuer／Checker／Signer 分離、逐效果准入 | **P0** |
| DOC-08 | TQAEP、Oracle、Acceptance、External Challenge | 分開 Planned／Executed／Independently Accepted；修 Oracle Binding 及假 PASS 負例 | **P0** |
| DOC-09 | Evidence、Trace、Ledger、交付證據 | 工件封存與 Mission 結案分離；補 Failure／Resume／Claim Ceiling 語義 | **P0** |
| DOC-10 | Builder、四 Host、G-KNOW、HLPE、OROCHI／RAG | Portable／Native Host Adapter、安裝載入實測、單一入口與按需檢索 | 受影修 |
| DOC-11 | Native Handoff、HGK／Hermes／SWOF 接軌 | 修 Proposal→Issued WO→Executor→Readback→Checker，補 FAR Decision 接線 | **P0** |
| DOC-12 | Delivery、Release、ProductKind、Golden Journeys | GitHub 意向／Remote Effect 分離；Local-only、Host 安裝卸載、三 Golden Journeys | 受影修 |
| DOC-13 | Repair、Evolution、Reuse、回歸與治理成本 | Known Fix 重用、FAR、受影修補、停損、成本效益、避免重複控制面 | 受影修 |

### 4.1 實際上不必「14 冊全部重寫」

例如 DOC-06 已經保留六個 Donor、24 個方法槽位，而且新升級藍圖也主張依能力按需採納。

因此 DOC-06 需要的是 Tool Applicability／Qualification 規則及當前能力回讀，而不是重新寫一套開源工具大全。

同樣，DOC-01 的 SBL 品牌、產品主軸、Human Sovereignty 與 One Core 不應因為 FHS-MSC 整合而改變。

相對地，DOC-04、DOC-05、DOC-07、DOC-08、DOC-11 的修補具有較高跨系統影響，應投入更多工程驗證資源。

### 4.2 必須另行修復 PIPD 原始工具的缺陷

有一個經常造成重工的陷阱：

**在 SBL 文件中描述「PIPD P4 缺陷已修復」，不代表 PIPD 的實際 Skill、Schema、Compiler 和 Fixture 已經修復。**

例如 P4 的正向 Fixture 曾被指出具有 Atom／Trace Hash 不一致、PD Subject 不一致，以及 TQAEP Receipt 不一致等問題。

這些需要在 PIPD 所屬的正式來源中修復，經合法 Owner 決定 Schema／Oracle／Profile 版本，再讓 SBL／FHS 使用新的受信結果。

不能在 `FHS-MSC_PIPD-LS-PKG` 內再建立另一套 PIPD Canonical Compiler，並宣稱它取代原工具。

### 4.3 如何確保「高保留」是真正的高保留？

每一個修補至少應有：

`Old Requirement ID → Source Clause → Problem ID → Repair Decision → New Clause／Adapter → Test／Oracle → Consumer → Evidence`

對被保留的項目，必須能標記 `RETAINED_UNCHANGED`。

對變更的項目，應標記 `REPAIRED_BY_OWNER` 或適當的候選狀態。

對仍待裁決的衝突，維持 `CR_OPEN`。

對不適用當前 FHS 執行切片的項目，標記 `DEFERRED_WITH_REASON` 或相應正式型別，不能直接刪除。

尤其要防止：

`文件改短了 → 原本產品義務一起消失`

高品質的升級應減少**日常執行器的必要閱讀量與重複流程**，不代表刪掉真正必要的需求。

---

## 五、GPT Work 與 Codex：如何分工才能最快、最穩健？

### 5.1 目前兩種工具都適合，但不能用同一方式指派

OpenAI 於 2026 年提供的 Work 可處理長流程研究、跨文件分析、報告及多步驟工作；Codex 則更適合 Repository、程式修改、終端機、測試及技術工作。Desktop 上的 Work Local、Codex Local 與 Cloud Work 權限由不同設定控制。\[[ChatGPT Work and Codex](https://help.openai.com/en/articles/20001275-chatgpt-work-and-codex?utm_source=chatgpt.com); [Moving to the new ChatGPT desktop app](https://help.openai.com/en/articles/20001276-moving-to-the-new-chatgpt-desktop-app?utm_source=chatgpt.com)\]

**GPT Work：架構與文件整合主力**

適合來源交叉研究、原始身份保留、衝突診斷、DOC-00～13 受影修訂、Requirement Crosswalk、ADR 候選，以及整理供 Owner 裁決的問題。

---

**Codex：機器契約與施工驗證主力**

適合實際 Repo 檢查、Schema／Fixture 修復、Parser／Validator、Trace Diff、測試、自動修補、CI、版本化變更，以及與既有 HGK／Hermes 工具的受權整合。

### 5.2 哪些工作可以快速自動化？

| 工作項目 | 建議主力 | 自動化潛力 | 應避免的錯誤 |
|--------|--------|--------|--------|
| 14 冊來源全文索引、SHA、Manifest | Codex＋確定性腳本 | 高 | 用模型記憶猜測摘要 |
| 原始 Requirement／Trace 身份抽取 | Codex | 高 | 只檢數量，不檢語義 |
| 跨冊相同術語、版本及 Locator 比對 | Work＋Codex | 高 | 不同法域同名即自動合併 |
| 受影條款重寫及保留分析 | Work | 高 | 未經 Owner 裁決自行修改正式政策 |
| 內部衝突與因果關係判斷 | Work＋獨立審查 | 中至高 | 將研究推論直接當正式裁決 |
| JSON Schema／Fixture／Parser 修補 | Codex | 高 | 測試案例與程式互相自證 |
| PIPD Compiler 真執行 | Codex／正式 PIPD 工具 | 依現役 ABI | 生成 JSON 冒充 Native Compiler |
| 原生 WorkOrder／Permit | HGK | 不可由 Work／Codex 自行取代 | 用文件或聊天當 Permit |
| Hermes Executor／Windows Service 測試 | Codex Local＋Hermes／HGK | 依本地權限與接線 | Cloud Work 冒充本地 Host |
| Independent Native Acceptance | 真獨立 Checker | 依原生環境 | Maker 自檢即正式 PASS |

### 5.3 這次最推薦的使用方式

**第一部分：Work 做一次高品質的治理收斂。**

讓 Work 讀取既有 FHS r2、14 冊 SBL 文件、10 冊 PIPD 文件及前四份 TPM／Commander 升級文件。

但每個研究子任務應限縮在明確的責任領域，最後以同一個 Source／Requirement Crosswalk 合併。

不建議每個子代理都重讀全部 75,630 行 SBL 正文再產生另一份長篇報告。

**第二部分：Codex 依機器可驗證的差異清單進行修補。**

例如先修 DOC-04／05／07／08／11 對應的正式介面，再修受影 Fixture、Contract Reader 及 CI。

每項修補必須能提供實際 Diff、測試輸出與來源追溯。

**第三部分：交回 Native HGK／Hermes 進行正式執行。**

Work／Codex 成為工程加速工具，不接管原生 Issuer、Effect Ledger、正式 Checker 或 Release Authority。

Codex 的官方工程實務同樣強調依真實 Repo、Diff、測試結果、外部化狀態及明確退出條件迭代；多代理適合獨立可分工任務，但不適合讓多個代理同時無協調地修改同一組共享檔案。\[[Iterating Development Workflows with Codex](https://developers.openai.com/cookbook/examples/codex/iterating-development-workflows-with-codex?utm_source=chatgpt.com); [Run long horizon tasks with Codex](https://developers.openai.com/blog/run-long-horizon-tasks-with-codex?trk=article-ssr-frontend-pulse_little-text-block&utm_source=chatgpt.com); [Multi-agent](https://developers.openai.com/api/docs/guides/agents-api/multi-agent?utm_source=chatgpt.com)\]

### 5.4 需要注意 Work Cloud 與本機 Windows 的界線

Work Cloud 的雲端電腦與本地 Windows Host 是不同執行環境。

它不會因為能讀取上傳檔案，就自動取得：

`C:\Projects\Agent_Workspace`

底下的真實 Repo、HGK Service、Windows Trust Registry、Hermes 工作程序及本機 Credentials。

若涉及真正 Windows Host 修補，應優先選擇具有合法本機資料夾與工具權限的 Codex Local，或已獲准且能驗證實際 Host 的 Work Local。

雲端 Work 可用於研究、差異分析、審閱和有權存取的遠端 Repository 工作；正式 Live Host 效果仍須由當地原生控制鏈准入。

**不應把 Windows Token、OpenAI OAuth Secret 或 OpenCode Go API Key 直接上傳到 Work 文件中，藉此解決 Host 無法存取的問題。**

---

## 六、投資報酬評估：前期花少量時間，能否換得整個工程高 CP 值？

### 6.1 我的判斷：有機會，而且值得先做最小試點

這個方案具有合理的工程經濟性，主要原因不是 AI 能快速寫出大量文字，而是**同一個上游缺陷可能影響後續多個 WorkPackage、多種 Host、每一輪施工與驗收**。

例如：

PIPD TQAEP 的 Planned／Executed／Accepted 時序若不修復，下游每次編譯測試計畫都可能再次碰到相同問題。

Commander Proposal／Issued WorkOrder 若沒有分開，每個需要建立新 Native 工作卡的任務都有機會產生 Bootstrap 循環。

HOLD／Resume 規則若不修復，即使其他程式功能正常，下一個長任務仍可能提早停止。

這類問題屬於**高重用度的共用缺陷**，較適合先修。

### 6.2 但「文件自動產生很快」不代表「正式升級成本一定低」

整體成本應至少分成四部分：

| 成本類別 | Work／Codex 有多大幫助？ | 主要限制 |
|--------|--------|--------|
| A. 文件讀取、抽取、整理 | 高 | 來源完整性、上下文去重 |
| B. 規範比對、設計修訂 | 高 | 語意衝突及原始產品責任 |
| C. Schema／程式／測試修補 | 高，尤其 Codex | 現役 Repo 與真正工具 ABI |
| D. Owner 裁決、Native 部署、獨立驗收 | 可大幅減少準備工作 | 不能取代有效授權與真實效果 |

因此，**最值得投資的不是大量生成新文件，而是建立可被後續任務反覆消費的正確契約、驗證器和執行入口。**

### 6.3 以 B1 實際經驗評估重工成本

《HERMES\_B1\_任務回報》已揭露以下問題：

| 觀察 | 工程意義 |
|--------|--------|
| 最初只完成大量清冊、未完成實作 | Requirement 到 WorkOrder 的轉換不完整 |
| 30/30 Runner Route Blocked | Native Registry／Runner 接線缺口 |
| G-A 有設計級通過但 G-B 尚未完成 | 前期契約能力不能替代 Native Handoff |
| 三張 GWO 完成沙箱操作但非 Native | 需要真正的效果與獨立收據 |
| FAR 介入後更正原授權順序 | 自動研究及決策有改善空間 |
| Checker 多輪重讀造成高 Token 消耗 | Context／Evidence Reuse 值得優化 |
| 部分模型路由曾不符合預期 | Host Effective Identity 需要機械驗證 |

這些案例支持「前期整合能避免一部分重工」的推論。

但目前沒有 A／B 實測，**不能嚴格宣稱升級後必定節省 50%、70% 或任何指定比例的時間及 Token**。

尤其是 30 條 Runner Blocked 或 Native Issuer 缺口，不會因為文件重寫而自然消失。

### 6.4 正確的 ROI 計算方式

建議使用兩個口徑。

**第一：只計算是否節省工程資源。**

$$
C_{\text{upfront}}+C_{\text{new remaining}} \lt C_{\text{old remaining}}
$$

其中：

- $C_{\text{upfront}}$：升級藍圖、修補控制包、測試及必要 Owner 裁決成本。
- $C_{\text{new remaining}}$：使用修復後控制包完成剩餘工程的成本。
- $C_{\text{old remaining}}$：直接沿用目前控制包完成同一範圍剩餘工程的預估成本。

**第二：評估是否值得在多個任務重用。**

$$
N(C_{\text{old/task}}-C_{\text{new/task}})\gt C_{\text{upfront}}+C_{\text{maintenance}}
$$

$N$ 是後續具有相同共用缺陷或共用接口的實際任務數量。

這個模型可以解釋為什麼**共用 ABI／Native Handoff 的修補，比大量修改單一文件措辭更可能帶來長期效益**。

### 6.5 建議先量測的六項工程指標

| 指標 | 如何量測 | 希望改善的問題 |
|--------|--------|--------|
| End-to-End Completion Time | 相同範圍從 Goal 到正式驗收的時間 | 整體施工速度 |
| First-Run Acceptance Rate | 首次合法執行即通過受影 Gate 的比例 | 降低試錯 |
| Owner Interventions | 每個 Mission 需要新的人類 Prompt／授權次數 | 單人 Owner 操作負擔 |
| False Global HOLD | 非依賴工作被錯誤阻斷次數 | 自治連續性 |
| Duplicate Work / Token | 重複分析、重複讀取、重複 Patch 的成本 | 直接資源效率 |
| Native Verified Throughput | 每單位時間真正通過原生驗收的工作 | 避免文件產出假效率 |

可另外記錄部署回滾、錯誤權限要求、Checker 返工及使用者決策等待時間。

**測量核心應放在 Native Verified Throughput，而不是單位時間產生多少 Markdown 行數。**

---

## 七、我建議的實際施工策略：先以最小可行升級驗證投資價值

不應一開始就承諾一次修復 14 冊、10 冊 PIPD、全部 SBL 程式及全部 Host。

更合理的是以下五個階段。

### Phase 0：正式建立原始基線

**工程目的：禁止版本、來源與原產品身份在升級時流失。**

由 Work／Codex 完成：

- 14 冊 SBL 原文 Manifest、SHA、Requirement／WorkPackage／Test 身份。
- FHS r2 與 TPM／Commander 四份新文件的差異對照。
- SBL 原有產品義務與尚未完成的實作項目。
- PIPD 及 SBL 的正式 Writer／Reader／Owner 歸屬。
- 原有的 `CR_OPEN`、待處理來源衝突及未通過的 Host Gate。
- 現役 GitHub／Local Root／Branch／Dirty／Source Version 的唯讀觀測。

**Exit Gate：** 所有受影變更具來源與身份，沒有把設計候選冒充正式已批准版本。

這個階段應優先使用確定性腳本取得 Manifest，而不是讓多個模型各自產生一份不一致的清冊。

### Phase 1：升級 FHS r2.1 的共用工程契約

**工程目的：只修對全部後續施工有共通影響的 P0 項目。**

應包括：

| P0 契約 | 為什麼要先修 |
|--------|--------|
| TPM／Commander／HGK／Hermes 唯一權責 | 避免重複 Planner 與控制面 |
| PIPD 設計／工程／Live／Acceptance 階段 | 避免施工自舉循環 |
| EffectClass／Gate Applicability／Affected Scope | 防止全域 HOLD |
| Mission Terminal／Resume | 防止提早結案 |
| Single Owner／Standing Grant／Machine SoD | 減少反覆授權又不破壞安全 |
| FAR／Commander Decision／Native Action | 讓阻斷有主動建議及恢復路徑 |
| Source／Artifact／Evidence Claim Separation | 防止假 PASS |

這些原則多數已存在 r2，需要的是精確化、消除衝突及正式驗收條件。

**Exit Gate：** 形成一份最小、可執行的全域規則，並由相關 Owner 對需要變更規範的部分作出合法裁決。

### Phase 2：建立 `FHS-MSC_PIPD-LS-PKG` 第一版候選

**工程目的：把上游修復真正轉成高自動化可用的施工控制包。**

產物應優先包含：

| 交付物 | 主要功能 |
|--------|--------|
| Source／Authority Manifest | 精確來源與版本 |
| Requirement／Obligation Crosswalk | 零靜默遺失 |
| Contract Compatibility Matrix | PIPD／SBL／HGK／Fabric／Hermes 接口 |
| Execution Applicability Profile | 真正適用的工作卡、Gate、Effect |
| Dependency／Resume Projection | READY／PARKED／恢復條件 |
| Owner Authorization Matrix | 一次有界授權與真正需裁決的效果 |
| FAR／Decision Adapter Contract | 自動根因研究與可操作建議 |
| Test／Oracle／Evidence Matrix | POS／NEG／Raw／Independent |
| Deployment／Rollback Plan | 受控施工、正式載入與恢復 |
| Open Decisions／Claim Ceiling | 未決問題與最高合法宣稱 |

不建議為每一項產物建立新的控制資料庫。

最好使這些內容可由現有 SBL／PIPD Reader 重建，必要時只以 Versioned Manifest、Schema、Index、Adapter 和少量 Markdown 呈現。

**Exit Gate：** 讀取控制包後，Commander 能產生完整、合法的當輪 WorkPlan；缺少單一 Native Gate 時能正確 PARK 受影工作而非直接結束整個 Mission。

### Phase 3：用 B1 與一個 SBL Golden Journey 驗證

這是決定是否擴大投資的關鍵。

建議使用兩個不同類型的試點：

| 試點 | 目的 | 通過條件 |
|--------|--------|--------|
| B1 Native Bootstrap Slice | 驗證最難的 HGK／Hermes／FAR／Permission 問題 | 真 Permit／Runner／Executor／Readback／Checker／Resume |
| SBL Golden Journey：CLI Tool 或 Brownfield Repair | 驗證 SBL 原始產品功能未因 FHS 修補受損 | 真 Build、安裝／執行／測試、拒收及復原 |

這個選擇有兩個好處。

**B1** 可以驗證高自動化控制鏈。

**SBL Golden Journey** 可以驗證原始 SpecBuild Loop 的產品價值確實被保存。

若只測 B1，可能把整套 SBL 過度改造成 HGK 修復專用系統。

若只測一般 SBL CLI Tool，又可能完全沒有測到 Hermes／HGK 的真正控制問題。

**Exit Gate：** 新控制包至少證明能在上述兩種不同情境正確運行；否則不擴大重寫其餘文件。

### Phase 4：完成 SBL 原有未實作項目

只有前面試點證明新控制包有效之後，才將完整 SBL 工作分母映射到後續施工。

這時才應逐步完成：

`產品核心 → 三 SP／六模組 → 八 ProductKind 適用性 → Host Adapter → PIPD Toolchain → Native Connected Mode → Independent Verification → 三 Golden Journeys → Delivery／Release`

其中順序須以原上位依賴與真正 Host Readiness 為準，不能直接把此行文字當成新的正式 Gate 序列。

所有原 Requirement IDs、Required／Conditional／Deferred 身份都要保留。

**Phase 4 不應反過來成為 Phase 0～3 所有工作都不能開始的全域前置。**

---

## 八、如何判斷新方案真的比直接續工更有效？

建議使用同範圍、同 Host、同授權條件的對照試驗。

### 8.1 對照設計

| 比較面向 | 原方案 Baseline | 新方案 Candidate |
|--------|--------|--------|
| 任務目標 | 相同 Golden Slice | 相同 Golden Slice |
| 模型／Provider | 相同或明確記錄差異 | 相同或明確記錄差異 |
| Repo／Host | 相同起始快照 | 相同起始快照 |
| 工程輸入 | 既有 SBL Package | FHS 衍生執行 Profile |
| 權限 | 相同有效 Permission Scope | 不降低安全前置 |
| 測試／Oracle | 原有效 Canonical | 同一有效 Canonical |
| 成果 | 真 Host／Native 收據 | 真 Host／Native 收據 |
| 成本統計 | 完整記錄 | 完整記錄 |

如果因新控制包需要修補 PIPD Canonical Validator，Baseline 與 Candidate 應清楚記錄這項變動，不能把不同有效環境的成功率直接視為純文件品質的差異。

### 8.2 擴大部署的建議門檻

| 條件 | 建議裁決 |
|--------|--------|
| 功能及安全回歸全部通過，且耗時與人工操作下降 | 擴大至後續 WorkPackages |
| 功能通過，但改善幅度不明顯 | 保留有效修補，暫停額外包裝工程 |
| 文件更完整，但 Native 結果沒有改善 | 修執行鏈，不再增加文件 |
| 新控制包使原產品需求遺失 | 拒收，回復受影修訂 |
| 新控制包需要第二 Compiler／Issuer／Scheduler | 重新設計為 Thin Adapter |
| 出現新的全域 HOLD 或重複授權 | 回到 Applicability／Dependency 修補 |
| 原生測試尚無權限或環境 | 保持具名 HOLD，不宣稱效益已實證 |

此處採用的是**先證明最小受影修補有效，再擴大投資**，而不是一次性投入全部工作。

---

## 九、此方案最主要的風險與控制方法

| 風險 | 可能後果 | 控制方式 |
|--------|--------|--------|
| R1：再次生成巨型治理文件 | Context／維護／閱讀成本繼續上升 | L0 Manifest＋L1 Delta＋L2 Execution |
| R2：原 SBL 品牌與產品身份消失 | 產品功能及交付責任縮減 | 保留原 ID、ProductTruth、Three SP |
| R3：FHS 包成為第二 Canonical | PIPD／SBL 互相矛盾 | 只做受影工程投影及合法 Owner Patch |
| R4：Work／Codex 自行裁決正式權限 | SourceFreeze／Permit／Release 權威受損 | 所有正式操作回原生 Issuer／Owner |
| R5：文件修好卻無 Native 效果 | 表面完成、實際不能執行 | 每個修補關聯真 Host Test |
| R6：全部 14 冊重寫先於任何施工 | 再次形成 Bootstrap 循環 | 只修 P0；合法獨立工作並行 |
| R7：多子代理同時修改共用文件 | 版本碰撞與語義漂移 | 分離 WriteSet，單一合併者 |
| R8：單一 Owner 需要一直批准 | 高自動化體驗未改善 | 有界 Standing Authorization＋DecisionPack |
| R9：驗證由 Maker 自己生成 | 假 PASS | 不同有效 Principal＋原始收據 |
| R10：投入回收不明 | 先期成本膨脹 | 兩個 Golden Slice 的 A/B 實測 |
| R11：新包只支援 FHS，不能一般化 | SBL 原產品能力受損 | 保留 Standalone／Connected／Host 適用性 |
| R12：升級後模型與工具路由漂移 | 執行結果不可重現 | Required／Admitted／Served、版本及憑證隔離 |

其中 **R2、R3、R5、R6** 是我認為這項新方案最應嚴格控制的四個風險。

---

## 十、正式推薦的工程控制原則

建議將這項工程定位為：

**`FHS-MSC Contract Repair and Execution Acceleration Program`**

其範圍不是重新創造 SBL，而是修復並建立能讓 SBL 正確被 FHS 原生執行的共用契約。

建議正式採用以下控制矩陣：

| 類別 | 工程原則 |
|--------|--------|
| Authority | SBL／PIPD／HGK／Fabric 各自維持原生 Writer |
| Product | SBL Guided Spec／Governed Build／Verify／Repair 全部保留 |
| Scope | 修受影缺陷，不以完整產品分母阻斷每一工作卡 |
| Execution | Work／Codex 加速候選，HGK／Hermes 執行正式 Native |
| Human | 一位 Owner、有界委任、必要效果真授權 |
| Security | 不減少 Permit、SoD、Checker、Readback |
| Automation | READY 續工、局部 PARK、FAR 主動研究與恢復 |
| Evidence | Design／CI／Sandbox／Native／Release 互不冒充 |
| Architecture | 不新增第二 Issuer／Scheduler／Canonical Compiler |
| Optimization | 以實測吞吐量、人工介入及返工成本衡量成效 |

---

## 十一、最終鑑定回答

### 11.1 是否應以升級後的 FHS-MSC 藍圖，先修 SBL Package？

**應該。**

尤其對共用的 Source、Profile、Oracle、ECP、Native Handoff、Commander、Owner Authorization 和 Durable Resume 缺陷，先修復能避免後續重複碰到相同障礙。

但目前 r2.1 仍屬升級建議，尚非已正式生效的藍圖；應先完成必要的受影設計裁決，再將它用作後續施工候選輸入。

### 11.2 是否應將 `SBL_PIPD-LS-PKG` 轉成 `FHS-MSC_PIPD-LS-PKG`？

**建議建立衍生控制包，而不是直接取代或改名原始 SBL Canonical Package。**

這能同時達成保留 SBL 原意、消除 FHS 整合阻斷及避免第二套正式權威的目標。

### 11.3 是否能把治理過度、授權不明、內部矛盾全部修完，再開始實作？

**可以先修完已識別且阻斷共用施工的規格問題；不應等待所有潛在問題被文件分析完畢才開工。**

部分缺陷只有在真 Host、真 Compiler、真 Issuer、真 Worker 執行後才會暴露。

因此，最有效的方法是文件修補與有界實作迭代，而不是一次性的文件完美主義。

### 11.4 Work／Codex 是否能快速完成前期文檔工程？

**在來源可讀、目標明確、輸出可機械驗證的情況下，具備很好的加速潛力。**

尤其是 14 冊跨文件差異、身份守恆、Schema、Fixture、Test Matrix 和高保留受影修訂。

但正式 Source Ratification、Native Authorization、Windows Host Effect 和 Independent Acceptance，不是模型產文速度可以替代的工作。

### 11.5 前期投入是否有機會換得高 CP 值？

**有，而且這是合理的優先投資方向。**

條件是：

修復必須作用於能被後續多次重用的共用接口，並且必須證明減少了真正的重工、阻斷及人工操作。

如果只使 Markdown 更完整，卻沒有減少 Native FirstFail 和重複授權，則這筆投資不成立。

---

## 十二、我的最終建議

## 採納，但採用受影升級與試點驗證

**推薦策略：`YES - PHASED CONTRACT-FIRST ACCELERATION`**

---

**第一優先：** 用 Work／Codex 將 FHS r2.1 的 P0 共用契約具體化，並保留 SBL 原始設計及所有來源身份。

**第二優先：** 修復 SBL／PIPD 真正有問題的 Canonical ABI、授權時序、Proposal／WorkOrder／Executor Handoff，建立 `FHS-MSC_PIPD-LS-PKG` 的薄型執行投影。

**第三優先：** 用 B1 Native Slice 和一個 SBL Golden Journey 實測新的施工控制包。

**第四優先：** 若真實執行、人工操作、重工及驗收結果優於原流程，再擴大至其餘 SBL 功能與完整 FHS-MSC 工程。

**最終工程結論：**

你的提案值得採納，方向上比繼續使用具有已知整合缺陷的原始控制包反覆施工更合理。

但取得高 CP 值的關鍵，不是「先快速重寫所有文件」，而是：

**先以 AI 自動化修復高重用度的契約缺陷，保留原產品與權威，再建立真正能被 HGK／Hermes 消費的精簡控制包；用少量真實施工驗證成效，才逐步接管整體工程。**

如果按這個方法執行，FHS-MSC **有充分的工程理由預期**能減少重工、改善鏈路連續性及提高自治施工成功率；實際改善幅度仍須經同範圍 A/B 測試確認。

**本報告只完成工程鑑定、來源交叉比對與實施規劃；尚未將 r2 升為正式版本、改寫 SBL DOC-00～13，或對本地 HGK／Hermes 執行任何 Native Mutation／Acceptance。**



---
Powered by [ChatGPT Exporter](https://www.chatgptexporter.com)