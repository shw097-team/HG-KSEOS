# FHS-MSC R00／R00.1 最終限定交接驗收報告

**報告版本：** 2026-10-26-r1-final-consolidated  
**用途：** 合併前兩輪已執行的驗收結果，交予指揮官／Owner 與總設計師。  
**彙整日期：** 2026-10-26（Asia/Taipei）。  
**證據時點：** 第一輪結案讀回 2026-10-26 12:08:23 +08:00；第二輪主要觀察 12:38–12:48 +08:00。  
**本次動作：** 文件彙整與本地下載包製作；未重新驗收遠端或擴大驗收範圍。報告不保證上述觀察窗口之後的外部狀態。

## A. 最終裁決與適用邊界

**限定證據／設計交接接受，保留明確 Holds。** 兩輪未發現阻擋固定八檔交接的主體不一致、原件不受控修改、公開秘密或重大權威升格宣稱；第二輪補足本機來源、差異矩陣與隔離 adapter 重演證據。

```text
TASK: FHS-MSC-R00-R001-FINAL-HANDOFF-ACCEPTANCE-CONSOLIDATION
SUBJECT_PR: https://github.com/shw097-team/SBL/pull/12
EXACT_HEAD: 986d8ed3e351271846170fd89f93c7ceeef759bb
EXACT_TREE: a78a35ec590f05629faf91d8c4bd9d8a420eae76
EVIDENCE_HANDOFF_VERDICT: R00_R001_EVIDENCE_HANDOFF_ACCEPTED_WITH_EXPLICIT_HOLDS
CONSOLIDATED_RECOMMENDATION: PASS_WITH_EXPLICIT_HOLDS
DESIGN_HANDOFF_RECOMMENDATION: GO_WITH_HOLDS
DESIGN_HANDOFF_SCOPE: READY_FOR_AFFECTED_NON_EFFECT_DESIGN
FORMAL_DESIGN_ADMISSION: OWNER_COMMANDER_DECISION_REQUIRED
CLAIM_CEILING: INDEPENDENT_HANDOFF_REVIEW_ONLY
FORMAL_NATIVE_AO: NOT_ISSUED
FORMAL_PI_PD_ECP_TQAEP: NOT_COMPILED
PR12_AT_LAST_OBSERVATION: OPEN_DRAFT_UNMERGED
SWOF_PREW3_W3_READY: NOT_ESTABLISHED
```

此推薦允許使用已釘定的遠端 main、PR12 證據及受影來源，準備 PI Draft／PD Binding Plan／ECP Candidate／TQAEP Plan。正式 Design Admission 由上級指揮官／Owner 決定；本報告不簽發 Native Permit、SourceFreeze、正式 AO、產品驗收、Merge 或 Release。

### 里程碑分項裁決

| 里程碑 | 合併裁決 | 可使用範圍與限制 |
|---|---|---|
| P0_READONLY_INVENTORY | PASS_WITH_EXPLICIT_HOLDS | 真 Root／HEAD／Origin／tracked 數與指定差異可信；完整 Dirty／Untracked／歷史盤點未閉合 |
| P1_GOVERNED_TRIAGE | PASS_WITH_EXPLICIT_HOLDS | Candidate／Main／Stage／Loaded 與各 Owner 邊界具名分離；Oracle／Host／Checker 缺口保留 |
| P1_SANITIZED_PUBLICATION | PASS_SCOPED | 僅固定 HEAD 的指定八檔；去敏檢查不等於所有資料的發布權利保證 |
| P1_REMOTE_READBACK | PASS_SCOPED | 八檔 bytes／Git blob OID／SHA-256 與遠端 Tree 相符；原 R00 四檔未改 |
| P1_DESIGN_HANDOFF | PASS_WITH_EXPLICIT_HOLDS | 可開始受影無效果設計準備；不准據此施工、正式編譯閉合或宣布 Runtime Ready |

### Reviewer 與獨立性

兩輪皆為同一聊天中的技術 Reviewer 工作，Reviewer 未參與受驗產品候選的製作。第二輪明確是第一輪之後的同 Session 追加查核，**不能計作兩個獨立 Checker、兩個新 Session 或兩個 Principal**。第一輪的 `new-Codex-session` 角色標記不構成可核證的身分隔離證明。

第二輪 GitHub 登入讀回為 `shw097`，與 PR 作者相同。未證明 Credential／法律 Principal 分離，亦未取得正式 Native Checker／Spine 收據。工具未提供可核證的實際 `served_model`，故維持 `SERVED_MODEL_UNVERIFIED`；檔名中的模型名稱不作實效證據。

## B. 兩輪範圍、結果銜接與已核實身分

| 輪次 | 任務依據 | 已完成範圍 | 結果 |
|---|---|---|---|
| 第一輪 | FHS-MSC-R00-R001-EVIDENCE-HANDOFF-REVIEW | CHECK-1～5：Exact PR／八檔／CI／Claim Ceiling／內容一致性／限定去敏；CHECK-6 未觸發 | R00_R001_EVIDENCE_HANDOFF_ACCEPTED_WITH_EXPLICIT_HOLDS |
| 第二輪 | FHS-MSC-CODEX-INDEPENDENT-HANDOFF-REVIEW/2026-10-26-r1 | V01～V09；真 Root 身分；471 列機械核查；13 筆樣本；Canonical 受影段落；隔離 15 tests；三項確定性反證；前後守衛 | PASS_WITH_EXPLICIT_HOLDS；GO_WITH_HOLDS；V03 全量現況仍 INCONCLUSIVE |

第一輪 `NOT_REQUIRED / 15_MAKER_TESTS_REPORTED_NOT_INDEPENDENTLY_RERUN` 是當時的真實狀態。第二輪已安全取得獨立暫存副本並重跑 15 tests，因此最終狀態更新為「技術 Reviewer 隔離重演 15／15 通過」。此更新不使原第一輪記錄失實，也不把重演升格為正式 Native AO。

### 固定 Git 主體

```text
Base main dc5428f23d15f0ec56cbc3d25b22f5381fce8771
  → R00 6d820f14ddca611e7780e08c7c0c9f233b794e06
    → R00.1 986d8ed3e351271846170fd89f93c7ceeef759bb
```

R00.1 唯一 Parent 為 R00。相對 Base 是兩筆 commits、八個新增檔案、0 產品來源修改／刪除；R00.1 僅追加四檔。HEAD 完整 recursive Tree 為 287 entries，R00 Tree 為 283 entries，均 `truncated=false`。原 R00 四檔在第二筆提交保持 byte-identical。

原 `PUBLICATION_MANIFEST.tsv` 僅涵蓋 R00 另三檔，三列 bytes／SHA-256 均有效；`READBACK.json` 是 `PREPUBLICATION_REMOTE_BASELINE`。未要求它們自證未來 commit，也未因 manifest 未列 R00.1 四檔而判違規。

### Repository／Host 身分矩陣

| 主體 | 已核實身分 | 限制 |
|---|---|---|
| Fabric main | `bcd91043b89b69c9d2f08309e46e31898ac87d89` | 遠端設計參照，非本機候選／Live |
| SBL main | `dc5428f23d15f0ec56cbc3d25b22f5381fce8771` | 與 PR12 固定候選分列 |
| PIPD-LS-SP main | `e95942abcb6aa07e69304607ab8afc22a74fc67d` | 不是本機 PIPD 工作樹 HEAD |
| SWOF main | `acdbfaadd19d12927eb5bd542b09ed230bbc481e` | 本輪不驗 W3 |
| HGK 本機 | `086a9402189a2bb0ac3b198a7a9805b3dcbe38d8`；785 tracked | Branch `codex/hgk-final-closure-002`；無 Origin |
| Fabric 本機 | `bb06b7a6c17c45c777a636e9dae3196e21eb77b9`；4264 tracked | Branch `pub/far-minimax-mandate-20261021`；Origin 相符 |
| SBL 本機 | `10d510f7b052e6139fd4eb536f970c0245002e17`；456 tracked | Branch `candidate/r14-ts15-kinds`；Origin 相符 |
| PIPD 本機 | `39079c02b8f2a3a3e63d3f2a2d5537805d3a3594`；947 tracked | Branch `rescue/r5p-uncommitted-20261016`；Origin 綁定 PIPD-LS-SP，不等於 SourceFreeze |
| Hermes Source | `f97608f178d1ffeca59860195ab7da295f7c8e5f` | 靜態 `__version__=0.21.5`；不是 Loaded 版本 |
| Hermes Installed executable | 114995 bytes；SHA-256 `c02538dd297474191546684681344c0ad859580a635047e577947b8bebd559e8` | 僅硬碟檔案身分；未執行 Launcher |
| Hermes Loaded／Active／Issuer | `UNVERIFIED / UNBOUND` | 第二輪 CIM／Scheduler 讀回受限；未取得現役 module／job／lease／Issuer 證據 |

四個本機 Root 的身分、Branch、Origin、tracked 數在第二輪前後一致，未報告 superproject；已讀工作樹 metadata 保留其獨立邊界，未重新盤點全部 Nested／Ignored。完整 status／untracked 查詢因沙箱拒絕進入來源目錄而不可得，不能把空輸出解讀為零筆或 clean。另以指定檔案比較，確認 HGK 兩項、Fabric 一項既有 dirty 差異仍存在；沒有宣稱已核實全部 dirty 分母。

### CI／Review／去敏

- Run `40264423718` 的 `head_sha` 與受測 HEAD 相同；Windows py3.11 job `121383554245`、Ubuntu py3.11 job `121383554464` 均 success。
- Job 步驟僅支援 SBL tests／wheel runtime data／source manifest；不能當作 R00.1 四份證據的正式獨立 AO 或 adapter 15 tests 的 CI 證明。
- 第二輪 GitHub Reviews 回讀為空：`NO_GITHUB_REVIEW`。Reviewer 未補寫 Review／Comment／Approval。
- 對固定八檔依既有 SBL scanner 規則重掃：8 files、0 hard findings；限定補查未見實質 Token、私人絕對路徑、原始 Runtime dump／私人正文外洩。未以 scan 0 命中代換完整安全稽核或權利授權。

## C. 合併驗收矩陣

| Predicate | Expected | Actual | Raw evidence locator | Status | FirstFail／限制 |
|---|---|---|---|---|---|
| V01／CHECK-1 主體綁定 | Exact HEAD／Tree／Parent／Repo 明確 | 固定主體；兩筆提交；兩輪最後觀察均 OPEN／DRAFT／未合併 | PR12 API、Git commit／recursive Tree | PASS | 無主體變動 |
| V02／CHECK-1 出版完整性 | 八檔重算相符；原四檔保留 | 八檔 bytes／Blob／SHA-256 相符；R00 4／4 不變 | 固定 HEAD 八檔、R00 Tree、manifest 三列 | PASS | 無；原 manifest 範圍未被錯誤擴大 |
| V03 本機 Root／Currentness | 真 Root／HEAD／Origin／Dirty 可讀回 | 身分與 tracked 數相符；指定 dirty 差異存在；全量 Dirty／Untracked 不可得 | 四 Root Git metadata、指定 tracked 檔比較 | INCONCLUSIVE，限完整現況 | FULL_STATUS_READBACK_UNAVAILABLE |
| V04／CHECK-4 差異矩陣 | 全行機械核查＋至少 12 筆重算 | 471 資料列、453 筆引用／分類檢查、13 筆樣本相符 | DRIFT_MATRIX 資料列 1、72、122、161、428、429、431、463–468 | PASS | 453 引用檢查不等於 453 次 Blob bytes 重算 |
| V05／CHECK-3 Host 實效 | Candidate／Stage／Disk 不升格 Loaded | R17 Stage 與 PR11 相符；目前 Loaded／Issuer 缺證照實保留 | Host Map、PR11 Tree、Binary、Hermes 靜態來源 | PASS，限誠實聲明 | CURRENT_LOADED_ISSUER_RECEIPT_UNAVAILABLE |
| V06／CHECK-5 出版去敏 | 指定八檔無實質外洩 | Scanner 0 hard findings；限定補查未見實質命中 | 八檔公開 bytes、受測 scanner 規則 | PASS_SCOPED | 不代換完整權利／安全保證 |
| V07／CHECK-3～4 Oracle／Adapter | DOC-07 Writer；保留 ABI；候選不自封 Erratum | Canonical 摘要相符；installed const 保留；候選四新增；隔離 15 tests 全通過 | DOC-02／03／07 指定段落、P4 schema、adapter commit | PASS，限候選主張 | Namespace／正式 Erratum 未核准 |
| V08 無越權／主體守衛 | Checker 不改候選、不自簽 AO | PR、四 Root 身分、13 指定檔案與 adapter 候選前後未見變動 | 前後 snapshots、候選 tracked status／hash | PASS，限可觀察範圍 | CONCURRENT_CHANGE_UNVERIFIED |
| V09／CHECK-4 交接契約 | Prepared 不冒充 Admitted／Compiled | 五項 DEC、16 列 Host Map 與 Handoff 一致；NWR／ECP 仍候選 | BASELINE_HANDOFF、限定非秘密候選收據 | PASS | Native admission／正式 Compiler 閉合未取得 |

本表 PASS 僅適用列明的 predicate。V03 的全量現況缺證未被其他 PASS 覆蓋；V05 只判定觀測與 Claim Ceiling 誠實，並不表示 Loaded 驗證成功。

### 六個 Claim Ceiling 核對

| Claim | 可支持的結論 | 不可推論 |
|---|---|---|
| PIPD_ROOT_FOUND | 真 Git Root／Origin／HEAD 已讀回 | SourceFreeze 已發 |
| HERMES_DISK_SHA_OBSERVED | 指定 executable bytes 身分可核實 | Loaded／Active module 相同 |
| LOCAL_MAIN_CANDIDATES_DIVERGED | 本機候選與 main 分歧存在 | 可自動 merge／rebase／push |
| PRIVATE_INVENTORY_BOUNDED | 限定 metadata 收據 150 項 | 全量私人盤點或安全設定重認證 |
| PIPD_RFC_CANDIDATE_15_MAKER_TESTS | Maker 收據存在，第二輪技術 Reviewer 已隔離重演 | 正式 AO／已核准 Erratum／真 domain registry |
| NATIVE_GATE_HOLD | Permit／Issuer 仍未綁定 | 可依聊天或文件自行放行效果 |

### 三項確定性反證

| ID | 實際比較 | 結果與 Claim Ceiling |
|---|---|---|
| NEG-01 | R00 舊 SHA／四檔 Tree 與 R00.1 固定 HEAD／八檔 Tree 比較 | PASS；舊主體不能沿用目前八檔驗收結論 |
| NEG-02 | CI success、Stage 相符、Disk digest、Maker tests 與 Loaded／Native 證據欄位比對 | PASS；未形成 Loaded／Native AO／Release 證據 |
| NEG-03 | 相同 GitHub 登入、UNBOUND Checker Principal、缺 Native Receipt 與治理禁止自驗規則比對 | PASS；新 Session 或同帳號登入不能變成原生獨立 AO |

反證使用唯讀證據比較與既有隔離候選負例，未建立新的 Native Oracle／Checker 控制平面。

## D. Findings、Holds 與最小合法處置

**本次限定交接的 BLOCKING Findings：0。** 下列事項仍具名開放，不因本報告接受交接而關閉。

| ID／分類 | 受影主體與確切證據 | Owner | 最小合法處置 | 重驗條件 |
|---|---|---|---|---|
| H01／DESIGN_ONLY_HOLD | CR_ORACLE_001_OPEN；Legacy Namespace／正式 Erratum 未核准；RFC 自述不是已簽 Canonical Erratum | DOC-02／DOC-07／Schema Owners | 核准完全限定 domain-source 身分與版本化相容契約，保留現有 ABI | Producer／PD／TQAEP consumers／identity／fixtures 同主體受影重驗 |
| H02／DESIGN_ONLY_HOLD | Disk／Stage 可核實，Current Loaded module／job／lease／Issuer 缺證 | Host／Native Issuer Owner | 提供最小去敏、綁定 exact subject 的現役原生 readback | 真 Loaded／Issuer／lease currentness 回執成立；不可僅用 PID 缺席或 Task Ready |
| H03／DESIGN_ONLY_HOLD | HGK_NATIVE_ISSUER_PERMIT_UNBOUND；FORMAL_INDEPENDENT_CHECKER_UNBOUND；同帳號且 served_model 不可核證 | Native Issuer／Commander／Checker Owner | 正式效果前取得適用 admission／Permit；正式驗收前綁定真正 Checker 與 readset／receipt | 禁止自驗與 Required＝Served 等適用條件有真實回執 |
| H04／DESIGN_ONLY_HOLD | FULL_STATUS_READBACK_UNAVAILABLE；本機與 main 分歧；完整工作樹 currentness 不可證 | Repo／Host Owners | 正式 PD 綁定前補足受影 WriteSet 的 currentness，不要求歷史全面清洗 | exact Root／HEAD／Dirty／WriteSet 受影身分閉合 |
| D01／DEFERRED_PRODUCT_SCOPE | PRIVATE_HISTORICAL_INVENTORY_INCOMPLETE；歷史 reparse／long-path／ignored 分母未重驗 | Product／Data Owners | 僅按必要受影來源晚綁，不重掃 55k／180k 歷史檔 | 適用任務需要的來源身分可證；原分母與缺口仍保留 |

最關鍵的後續 FirstFail 為：`LEGACY_DOMAIN_SOURCE_NAMESPACE_UNRATIFIED / SCHEMA_OWNER_ERRATUM_NOT_ISSUED`、`NO_CURRENT_PROCESS_MODULE_OR_NATIVE_ISSUER_RECEIPT`、`ISSUER_ADMISSION_AND_INDEPENDENT_CHECKER_UNBOUND`。它們是後續相應工作的 Gate，非本次八檔限定交接失敗。

## E. 下一階段設計交接與唯一優先工作卡

**唯一優先工作卡：B1 Bootstrap Repair 最小 Native／Host／Issuer 資格與設計準備。** Source-Oracle Namespace／版本化 Erratum 為獨立受影工作線，不以全面歷史清洗作本輪通過前提。

**下一個最小合法動作：**提交此報告予指揮官／Owner 裁定限定 Design Admission；通過後，由總設計師以已釘定 main＋PR12＋受影 Canonical 身分，整理下列四個 RepairCone 的無效果設計候選，逐項記錄 Source Locator、Owner、FirstFail、RepoContext、所需回執及驗收計畫。此處不下達施工指令。

| RepairCone | 必須保留的設計要求 |
|---|---|
| R1 Grant／Effect Fail-Closed | grant_required 傳遞、UNCLASSIFIED 拒絕、權限負例 |
| R2 Fair Queue／Worker Busy | Blocked A 不餓死獨立 B／C、Lease／Worker 分類、同 WriteSet 避免雙寫 |
| R3 Stage→Live Activation | Candidate≠Approved≠Active≠Loaded、STACK_CHANGE／Promotion、Live SHA、Rollback |
| R4 Hermes／Codex／Checker Handoff | Required＝Served、現役 Host、合法小 WorkOrder、受影 T2／T3／T4 與獨立 Readback |

正式 SourceFreeze／受影 Oracle Erratum 與相容契約未完成前，不得宣稱正式 PIPD Compiler 閉合；Native Issuer／Permit 未取得前不得施工。正式 Acceptance／Promotion／Release 仍需真正獨立 Checker 與適用 Native 收據。

既有候選 NWR／ECP 的 expiry 為 **2026-10-27T11:23:52.576155+08:00**，僅適用該 isolated proposal request；觀察當時未過期不表示 admitted，日後逾期不得沿用。本彙整不延長期限，也不重新簽發請求。

明列尚未建立：SourceFreeze；Formal PI／PD／ECP／TQAEP；Native Permit／AO；Active／Loaded Runtime；Merge／Release；SWOF PRE-W3／W3 readiness。

完整原分母保留原 ID 與 `NOT_RUN / NOT_REQUALIFIED`：SBL 949 atoms、42 audit findings、R17 145-ID、三 SP、六 Modules、三 Golden Journeys、四 Host×三 SP、R13 18 Red。471 drift rows 不是 471 修復通過項；15 adapter tests 不是上述產品分母的驗收替代。

## F. Integrity & Stop Receipt

- 第一輪僅執行限定證據審查；第二輪補做獲授權的唯讀本機檢查、來源段落核對與隔離測試。未修改 PR、原提交、產品來源、Policy、Oracle 或 Live。
- 第二輪前後觀察：PR HEAD／OPEN／DRAFT／未合併狀態一致；四 Root 的 HEAD／Branch／Origin／tracked 數與 13 個指定檔案摘要一致；adapter 候選 tracked status 為 clean，四檔 bytes 與 Git 物件一致，重演後未變。
- 守衛僅覆蓋列明主體；不能排除範圍外或兩次觀察間的外部同時寫入，保留 `CONCURRENT_CHANGE_UNVERIFIED`，不宣稱整機完全無變動。
- 未啟動 Hermes Launcher／Recovery／Runner，未修改 Scheduler，未讀取 Token 原文、OAuth 值、Secret Queue／Raw Runtime DB／Checkpoint／Claim 明細；未披露私人 Store 位置或逐項清單。
- 暫存比較器、收據與測試副本僅建立於已准許的隔離 `work/`。第二輪未另存正式報告；本輪依使用者新增授權，建立此最終 Markdown 及下載包。
- 第二輪工作停止於 2026-10-26 12:48 +08:00；本輪僅彙整，未再查詢外部狀態、進入 Bootstrap Repair、建立 PR 或發布新資料。

## 附錄 1：八檔重算摘要

以下 Git blob OID 是 Git SHA-1，與 SHA-256 不同。八檔皆位於固定 HEAD 的 `evidence/fhs-msc-recon-20261026-r00/`；此表不要求任何受驗文件自記未來身分。

| 固定 HEAD 檔案 | bytes | SHA-256 | Git blob SHA-1 |
|---|---:|---|---|
| [BASELINE_HANDOFF.md](https://github.com/shw097-team/SBL/blob/986d8ed3e351271846170fd89f93c7ceeef759bb/evidence/fhs-msc-recon-20261026-r00/BASELINE_HANDOFF.md) | 5323 | `d1d81e9017abafec74fd2deeb4a54510ead144ceed1bc0b329f392d6bcf1848d` | `d820948e8964201eef1e1dc41e6804f6528b0105` |
| [DECISION_DISPOSITION.md](https://github.com/shw097-team/SBL/blob/986d8ed3e351271846170fd89f93c7ceeef759bb/evidence/fhs-msc-recon-20261026-r00/DECISION_DISPOSITION.md) | 8377 | `f3cda6f5829d56108413e280083379529e9c9adce3a7b9494327c0b0d12a19b8` | `d6850dbdf611603916fbf66092e6e5b74670ec6b` |
| [DRIFT_MATRIX.tsv](https://github.com/shw097-team/SBL/blob/986d8ed3e351271846170fd89f93c7ceeef759bb/evidence/fhs-msc-recon-20261026-r00/DRIFT_MATRIX.tsv) | 196950 | `1dfbe968697deb55c93c42f422c24bbc3c6de87f19706e4932174f0821a9d5b5` | `b41f5ab4c8fd3388c8ba5ca639cd05d80ae3049e` |
| [EFFECTIVE_HOST_MAP.tsv](https://github.com/shw097-team/SBL/blob/986d8ed3e351271846170fd89f93c7ceeef759bb/evidence/fhs-msc-recon-20261026-r00/EFFECTIVE_HOST_MAP.tsv) | 3938 | `e77e00128e6cf0415815ee91c3fea55b236a9b1ef3802f04dd9fef33c422a5e2` | `6d9dd3f237ed6a3dbd015b607b56cda0fe4a9c95` |
| [PIPD_ORACLE_CONFLICT_RFC.md](https://github.com/shw097-team/SBL/blob/986d8ed3e351271846170fd89f93c7ceeef759bb/evidence/fhs-msc-recon-20261026-r00/PIPD_ORACLE_CONFLICT_RFC.md) | 7975 | `e354fd37cc7c868c9cbdacf2561a681894cb968a54dd9429b1ca3a5cb1788b77` | `3800a668b9031321d3792907a29f56667087ce0b` |
| [PUBLICATION_MANIFEST.tsv](https://github.com/shw097-team/SBL/blob/986d8ed3e351271846170fd89f93c7ceeef759bb/evidence/fhs-msc-recon-20261026-r00/PUBLICATION_MANIFEST.tsv) | 967 | `a7142502a8edcb4213882cb0d24d614ed7918efd5c12cf6c12b94120bd7b0aa6` | `8a6fc66ee4f8fff6931b3bc2d46bdf43e9a197b3` |
| [RECONCILIATION_REPORT.md](https://github.com/shw097-team/SBL/blob/986d8ed3e351271846170fd89f93c7ceeef759bb/evidence/fhs-msc-recon-20261026-r00/RECONCILIATION_REPORT.md) | 14581 | `47f5c642f46c4db4530ee8beac93fb4af3aae07297d441e87f397af9d4898c26` | `d325fef0f5ce39ebce69eaec5e0c606dd37b76e3` |
| [READBACK.json](https://github.com/shw097-team/SBL/blob/986d8ed3e351271846170fd89f93c7ceeef759bb/evidence/fhs-msc-recon-20261026-r00/READBACK.json) | 8359 | `d5384fd98032b6853088dfe7483cd0ff7ffe8527509eaeebd4b8bf496fd93e82` | `9c38156aabc18d40ac163936113547fe6f71d0cd` |

## 附錄 2：差異矩陣與 13 筆關鍵樣本

471 列全部核對固定欄位、非空值、正整數 entry_count 與摘要型別。411 個 Local drift locator 及 42 個 Remote-only locator 共 453 筆引用／分類檢查；其中 79 個 Local locator 刻意以 NONE／NOT_VERIFIED 隱去摘要，只檢查路徑存在、差異與 OWNER_APPROVAL_REQUIRED 邊界，**不宣稱重算這 79 個被隱去的摘要**。有公開 Git blob 摘要的列為 374；另外列有 commit／tree／stage 及非摘要集合。

| committed tree 比較 | local-only | remote-only | changed | identical |
|---|---:|---:|---:|---:|
| Fabric 本機 vs pinned main | 119 | 0 | 4 | 4141 |
| SBL 本機 vs pinned main | 273 | 42 | 18 | 165 |

SBL 相對 main 為 46 ahead／26 behind；Fabric 為 14 ahead／0 behind。這些關係不能直接證明全部 ahead commits 都未發布，也不構成自動合併授權。

下表資料列號排除 header；GitHub 實體行號為資料列號＋1。全部 13 筆重算相符。Mirror tree OID 由遠端完整 tree 的 immediate entries 依 Git tree 編碼重建；Stage 另外比對 PR11 Git blob。

| 資料列 | 類型 | 原始 locator | 重算結果 |
|---:|---|---|---|
| 72 | changed | `FABRIC_ROOT/FABRIC/fabric/consumers/hgk_policy_consumer.py@bb06b7a6c17c45c777a636e9dae3196e21eb77b9` | MATCH；`81f851e3f0d48c624fadb54e673570161e2b8a32` |
| 428 | changed | `SBL_ROOT/pyproject.toml@10d510f7b052e6139fd4eb536f970c0245002e17` | MATCH；`c69f6434e0cc3ebb367ae71e531fecc921b67f52` |
| 429 | changed | `SBL_ROOT/sbl_core/__init__.py@10d510f7b052e6139fd4eb536f970c0245002e17` | MATCH；`5cd6f3c54463c4a7e81778d430369ee3f2806c91` |
| 431 | changed | `SBL_ROOT/sbl_core/m03_routing.py@10d510f7b052e6139fd4eb536f970c0245002e17` | MATCH；`5227640a2df0d778eeea0537aee8cb374937385f` |
| 1 | local-only | `FABRIC_ROOT/EVIDENCE/FAR-MINIMAX-MANDATE-20261021/AO2_findings_transcribed.json@bb06b7a6c17c45c777a636e9dae3196e21eb77b9` | MATCH；`87d9d5484df7acbabb9f77d129d18e179c3ffca1` |
| 122 | remote-only | `github:shw097-team/SBL/.gitattributes@dc5428f23d15f0ec56cbc3d25b22f5381fce8771` | MATCH；`54598b29a2bb6132b78f8259dae7b1b445b5286a` |
| 161 | remote-only | `github:shw097-team/SBL/_governance/round-20261021-r12-far/30_WRITER_RECEIPT.md@dc5428f23d15f0ec56cbc3d25b22f5381fce8771` | MATCH；`de39519f5f1310be4b7eec0959e6c2ca9f7f3c00` |
| 463 | mirror | `github:shw097-team/Fabric/FABRIC@bcd91043b89b69c9d2f08309e46e31898ac87d89` | MATCH；`2a6e206580953e4a9adda393ab7b60635bef0328` |
| 464 | mirror | `github:shw097-team/Fabric/HG-KSEOS@bcd91043b89b69c9d2f08309e46e31898ac87d89` | MATCH；`bdd55c16e7800980fb5dff2a80eb470d263bf58c` |
| 465 | mirror | `github:shw097-team/Fabric/FAR@bcd91043b89b69c9d2f08309e46e31898ac87d89` | MATCH；`d0a510965e54a865523bb19011ad1d0327539f10` |
| 466 | mirror | `github:shw097-team/Fabric/DESKTOP@bcd91043b89b69c9d2f08309e46e31898ac87d89` | MATCH；`e1dd606b6806069dd93f9813d401c51e189f616e` |
| 467 | stage | `R17_STAGE/tools/runner.py` | MATCH；`3522dfa6ff7de7a7eaeccddc5dd5a49764a89161d80619056f033622f4ed7615` |
| 468 | stage | `R17_STAGE/tools/advance.py` | MATCH；`337e67630663f12bdfebcaf4410e5b7f1963ed288a253d0b89070ab161ec8484` |

Stage runner.py：33436 bytes，Git blob `533d8c8340cd78405fccda97af88c145e3388d6b`；advance.py：19396 bytes，Git blob `1636c6e08a36669993d104cf4d3028a52150e48d`。兩者只證明 Stage 與 PR11 候選相符，沒有證明現役 import／Loaded。

Host Map 的 HGK spine／SBL scanner 欄位標明 Git blob SHA-1。第二輪發現 working bytes 因 CRLF 而與 Git blob raw digest 不同；LF 內容與 HEAD blob 相符，已查明為換行差異，未把它誤報為產品內容漂移，也未宣稱 raw working bytes 與 Git object bytes 相同。

## 附錄 3：Oracle 來源與隔離候選重演

| 來源 | SHA-256 | 核對定位 |
|---|---|---|
| FHS r2 Blueprint | `a80b3b4d7cc93e52a297a3e5176e27f207b36b8cd81a3d5440c70b4a80290ff9` | 0.1／0.3；L419–456；L478–490 |
| PIPD DOC-02 | `a021998dd3b63015e89af1dd40e0b413744a69b872da46c6bf5f4d92f7f23d0b` | VerificationPlan L2143–2147；OracleRegistry L2485–2489 |
| PIPD DOC-03 | `d89d82dcd2c8603ec6b86c5ec8c40845e4594bc181adf5272bd48a3de7c88f0f` | PD-08 L540–558；OracleType L607–618 |
| PIPD DOC-07 | `a68dae1c3670d07bcfa3476a1e37463c534594df5cd65d8dab0dca064b5a9fc1` | Canonical role L58；Oracle L619–658；Writer 邊界 L2298–2324 |
| Installed／PIPD P4 output schema | `4ae7d32a4ad04b6878a17ddac42b36e085f3485f2ad9f8cd60840dbd74149e71` | acceptance.oracle_source 保持 `DOC-03 DOMAIN_ORACLES` |

DOC-07 負責 TEST／ORACLE／FIXTURE 語義，DOC-02 編 PI，DOC-03 編 PD／TQAEP。未將 unqualified Legacy Literal 綁定為 PIPD DOC-03、SBL DOC-03 或猜測的 domain registry；未修改 installed const；RFC 仍為 local-only proposal，而非正式已簽 Erratum。

```text
Candidate branch: candidate/fhs-msc-r001-oracle-adapter
Commit: 6e20c2c6264b9e54992b627e6dae04a20800c02c
Sole parent: e95942abcb6aa07e69304607ab8afc22a74fc67d
Bundle SHA256: 6ab0332f9eaab34ab1c59c46faaa1ad854a8390f3e9746a2029f03558e0d09fe
Delta: 4 added proposal/test files; no existing source mutation in the commit
Maker receipt: 15 tests; exit 0; independent_acceptance=false
Reviewer isolated rerun: 15 tests; exit 0
Formal Native AO: NOT_ISSUED
```

四檔為 `candidate/fhs_msc_r001/ERRATUM_RFC.md`、`binding-proposal.schema.json`、`oracle_adapter.py`、`test_oracle_adapter.py`。來源 bytes、Git 物件與 Maker 收據所列 bundle 重算相符。重演只複製四檔及兩個必要 schema 至獨立暫存，使用既有 jsonschema，未安裝或聯網，也未改原候選。

15 tests 包括保留原 PI／獨立 NONE-effect proposal、直接 const 改寫拒絕、schema pin、stale subject、DOC-07 外來摘要、Namespace 模糊、零映射、遺漏／孤兒 atom、fixture polarity、sidecar、trace identity、S0／P4 shape 差異、Native claim／Permit 注入拒絕及 Oracle ID collision。公開 RFC 表格有分組列，不能把表格行數直接當測試方法數。

私人 Store 僅核對必要非秘密收據與有界統計：HGK 92、Fabric 1、SBL 18、PIPD 39，共 150；max_relative_depth=2、cap=300/root、所記 errors=0、reparse_skipped=0。此為 2026-10-26T11:29:03.870329+08:00 的有界收據，非現時全量私人盤點或 ACL／Storage Safety 重新認證。逐項私人檔名／內容不納入此報告或下載包。

NWR／ECP 收據核對為 `HOLD_NATIVE_GATE`、`NO_LIVE_EFFECT_ISOLATED_PROPOSAL`、`checker_principal=UNBOUND`、`permit_issued=false`；ECP 另明載 `PROPOSAL_NOT_NATIVE_CONTRACT`、`formal_ECP_compiled=false`、`permission_state=NOT_ISSUED`。

## 附錄 4：可重現遠端定位

- [PR12 metadata](https://api.github.com/repos/shw097-team/SBL/pulls/12)
- [R00.1 Git commit／parent／tree](https://api.github.com/repos/shw097-team/SBL/git/commits/986d8ed3e351271846170fd89f93c7ceeef759bb)
- [R00 Git commit](https://api.github.com/repos/shw097-team/SBL/git/commits/6d820f14ddca611e7780e08c7c0c9f233b794e06)
- [R00.1 recursive Tree](https://api.github.com/repos/shw097-team/SBL/git/trees/986d8ed3e351271846170fd89f93c7ceeef759bb?recursive=1)
- [R00 recursive Tree](https://api.github.com/repos/shw097-team/SBL/git/trees/6d820f14ddca611e7780e08c7c0c9f233b794e06?recursive=1)
- [兩筆提交 changed paths](https://github.com/shw097-team/SBL/compare/dc5428f23d15f0ec56cbc3d25b22f5381fce8771...986d8ed3e351271846170fd89f93c7ceeef759bb)
- [CI Run](https://github.com/shw097-team/SBL/actions/runs/40264423718)
- [Windows job](https://github.com/shw097-team/SBL/actions/runs/40264423718/job/121383554245)
- [Ubuntu job](https://github.com/shw097-team/SBL/actions/runs/40264423718/job/121383554464)
- [PR Reviews](https://api.github.com/repos/shw097-team/SBL/pulls/12/reviews)
- [SBL scanner 規則](https://github.com/shw097-team/SBL/blob/986d8ed3e351271846170fd89f93c7ceeef759bb/tools/secret_scan.py)
- [PR11 runner 固定來源](https://github.com/shw097-team/SBL/blob/bf3cccfe7abd94053eb147b586da4f9f95815921/evidence/R17-S207/tools/runner.py)
- [PR11 advance 固定來源](https://github.com/shw097-team/SBL/blob/bf3cccfe7abd94053eb147b586da4f9f95815921/evidence/R17-S207/tools/advance.py)
- [Fabric main ref](https://api.github.com/repos/shw097-team/Fabric/git/ref/heads/main)
- [SBL main ref](https://api.github.com/repos/shw097-team/SBL/git/ref/heads/main)
- [PIPD-LS-SP main ref](https://api.github.com/repos/shw097-team/PIPD-LS-SP/git/ref/heads/main)
- [SWOF main ref](https://api.github.com/repos/shw097-team/SWOF/git/ref/heads/main)

## 附錄 5：彙整與封裝說明

本報告來源為前兩輪聊天中的驗收結論、第一輪已保存的驗收結果，以及本任務隔離 work 內的 digest／remote metadata／matrix／candidate rerun／guard 記錄。它合併後續新增證據並保留當時未核實項目，不將兩輪計作兩位獨立驗收者。

本輪未再次執行產品測試或外部讀回；下載包僅包含本最終 Markdown 與其外部 SHA-256 校驗清單，不包含 Canonical 原文、產品原始碼、私人 Store、Raw Runtime、原始工具 dump 或帳號憑證。SHA-256 清單排除自身，報告亦不自記自身 digest。

**最終交接狀態：固定八檔可信，受影無效果設計可推薦啟動；正式 Native／產品／Release／SWOF 放行仍未發出。**
