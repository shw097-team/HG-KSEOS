---
artifact_family: FHS-MSC-B1-Bootstrap-Repair-PIPD-LS-PKG
version: 2026-10-26_r3_HIGH_RETENTION_SUBSTANTIVE_AUDIT_REPAIR
supersedes_version: 2026-10-26-r2-HIGH-RETENTION-SOURCE-BOUND
supersedes_subject_sha256: 273591a3f0cc7f43c87d6ac5e9e5704cf7ede15440a8a159b1de71d4c7d52da5
change_type: HIGH_RETENTION_INTEGRATE_COVER_REPLACE_NO_ARCHITECTURE_RESET
task_kind: DESIGN
claim_ceiling: AUTHOR_SIDE_REPAIR_CANDIDATE
formal_sourcefreeze: HOLD
independent_checker_receipt: NOT_RUN
native_effect: NOT_RUN
release: NOT_RUN
---

# B1 r3｜全域實質控制契約（正文；取代 r2 的共用假判準）

**本版唯一取代規則**：r2 的所有 source ID、27 Atoms、31 WO/OBS、120 Parent TQAEP、38 Skeleton Node、949 R15.1 身份均保留；當 r2 通用語句與 r3 逐領域 Effect/Oracle/NoFit 衝突，以本 r3 條款作業，r2 僅作歷史來源，禁止重新採用其偽 runner 或通用 rollback。

**權責**：HGK 原生唯一 issuer、Hermes queue/lease、Fabric active policy、SBL 既有 real entry、PIPD 唯一 deterministic compiler；P4 八 Skills 只是編譯技能契約，非本 Host 的可變更權限。Owner permission、ActivePolicy、Loaded SHA、RepoContext 缺失時不得簽 native effect。

## 1. 生命週期與雙域 Late Binding

1. SOURCE：逐檔讀取 → 各 source sha／行位置 → 衝突登記 → 候選 Freeze；沒有現役 Owner Signature 不輸出正式 SourceFreezeManifest。
2. PI：五個 P4 原生 `REQ-*` 由 goal/source 推導；27 `PI-B1-*` 另置 extension crosswalk。原生 schema 使用 **PIPD-EC** owner，不把 B1 Atom enum 注入原生輸入。
3. PD：僅 `REPOSITORY_WRITE` 且真實 Host Root/HEAD/Dirty/WriteSet 充分時，調用 P4 `pd-bind`；純 OBS 不發 PD；Host native/state/user 效果使用 **Owner-approved separate HostEffectAdapter** 而非假 RepoContext。
4. ECP：每張受治理 WO 一個 EffectClass/一個生效 ECP，DEV/OPS/USER 必分立，異種 effect 以 dependency receipt 串接；`unknown effect` 禁止盲重播。
5. TQAEP：每個獨立 raw result 只能覆蓋相同 WO、operation_id、resource、candidate_sha/epoch；Checker 與 Maker principal 真隔離；沒有實際 CheckerExecutionReceipt 即只可 `PLANNED`。
6. Package：本輪包可驗明檔案 SHA，但因正式 approval 不存在，上限 `AUTHOR_SIDE_REPAIR_CANDIDATE`，不得用 `LOCAL_QUALIFIED`。

## 2. Canonical Failure Registry 與別名優先順序

**機械決策序**：`source/authority → path/currentness → security/issuer/token → effect_class/ECP → required_method → execution/idempotency → readback → checker/trace → gate`。回傳**第一個真的失敗項**；情境細分碼在機器輸出歸一成 canonical code，不能把不同拼字當另一條 PASS。

| Atom | canonical_code | 來源負例碼 → canonical |
|---|---|---|
| B1-A1 | `ROOT_ALIAS_OR_PATH_ESCAPE` | `ROOT_ALIAS_OR_PATH_ESCAPE` → `ROOT_ALIAS_OR_PATH_ESCAPE` |
| B1-A2 | `PERMIT_SUBJECT_NONCE_REPLAY` | `PERMIT_SUBJECT_NONCE_REPLAY` → `PERMIT_SUBJECT_NONCE_REPLAY` |
| B1-A3 | `LOST_LEASE_OR_DUPLICATE_CLAIM` | `LOST_LEASE_OR_DUPLICATE_CLAIM` → `LOST_LEASE_OR_DUPLICATE_CLAIM` |
| B1-A4 | `RECEIVER_NOT_LIVE` | `LIVE_RECEIVER_NOT_VERIFIED` → `RECEIVER_NOT_LIVE` |
| B1-A5 | `MODEL_REQUIRED_NOT_SERVED` | `SERVED_MODEL_MISMATCH` → `MODEL_REQUIRED_NOT_SERVED` |
| B1-A6 | `UNKNOWN_EFFECT_REPLAY` | `DUPLICATE_OR_UNKNOWN_EFFECT` → `UNKNOWN_EFFECT_REPLAY` |
| B1-A7 | `RAW_OR_CHECKER_MISMATCH` | `RAW_SUBJECT_OR_WITNESS_MISSING` → `RAW_OR_CHECKER_MISMATCH` |
| B1-A8 | `HOTPATH_UNRESOLVED` | `UNMEASURED_REPAIR_OR_SCOPE_ESCAPE` → `HOTPATH_UNRESOLVED` |
| B1-A9 | `EXTERNAL_TRIGGER_STILL_REQUIRED` | `EXTERNAL_REENTRY_OR_NONNATIVE_SUCCESSOR` → `EXTERNAL_TRIGGER_STILL_REQUIRED` |
| B1-B1 | `PI_SOURCE_OR_ORACLE_UNBOUND` | `UNKNOWN_ATOM_SOURCE` → `PI_SOURCE_OR_ORACLE_UNBOUND` |
| B1-B2 | `REPO_CONTEXT_NOT_FRESH` | `PD_CONTEXT_STALE_OR_PATH_ESCAPE` → `REPO_CONTEXT_NOT_FRESH` |
| B1-B3 | `SECOND_ISSUER_OR_MIXED_EFFECT` | `HANDOFF_ABI_OR_MOCK_ACK` → `SECOND_ISSUER_OR_MIXED_EFFECT` |
| B1-B4 | `ECP_MULTIPLE_OR_CLASS_UNKNOWN` | `ECP_DOUBLE_ACTIVE_OR_CLASS_MISMATCH` → `ECP_MULTIPLE_OR_CLASS_UNKNOWN` |
| B1-B5 | `SP_HOST_LOAD_UNPROVEN` | `SP_ROLE_OR_HOST_NOT_ACTUALLY_LOADED` → `SP_HOST_LOAD_UNPROVEN` |
| B1-B6 | `CLI_EFFECT_MISCLASSIFIED` | `USER_TASK_EXECUTION_NOT_OBSERVED` → `CLI_EFFECT_MISCLASSIFIED` |
| B1-B7 | `NOFIT_OR_PROVIDER_OFF` | `GUARDRAIL_BYPASS_OR_NOFIT_INCOMPLETE` → `NOFIT_OR_PROVIDER_OFF` |
| B1-B8 | `TRACE_CLOSURE_FAIL` | `SUBJECT_HASH_BREAK_OR_ORPHAN` → `TRACE_CLOSURE_FAIL` |
| B1-B9 | `R15_DENOMINATOR_SHRINK` | `FULL_PRODUCT_PROXY_PASS` → `R15_DENOMINATOR_SHRINK` |
| B1-C1 | `FABRIC_LOADED_ABSENT` | `FABRIC_REVERSE_PROJECTION_OR_POLICY_EPOCH` → `FABRIC_LOADED_ABSENT` |
| B1-C2 | `GWO_HGK_NOT_NATIVE` | `HGK_FORGED_PERMIT_OR_GHOST_WORKER` → `GWO_HGK_NOT_NATIVE` |
| B1-C3 | `GWO_SBL_USER_STATE_UNPROVEN` | `SBL_EMPTY_TEST_OR_NO_USER_OUTCOME` → `GWO_SBL_USER_STATE_UNPROVEN` |
| B1-C4 | `EXTERNAL_SCOPE_ESCAPED` | `EXTERNAL_GRANT_SCOPE_OR_TTL` → `EXTERNAL_SCOPE_ESCAPED` |
| B1-C5 | `UNBOUNDED_PATCH_OR_REGRESSION` | `CODEX_UNMEASURED_PATCH_OR_CHECKER_MUTATION` → `UNBOUNDED_PATCH_OR_REGRESSION` |
| B1-C6 | `REVOKED_TOKEN_REPLAY` | `POST_REVOKE_TOKEN_REPLAY` → `REVOKED_TOKEN_REPLAY` |
| B1-C7 | `LOADED_BINARY_MISMATCH` | `PATCH_GREEN_NOT_LOADED` → `LOADED_BINARY_MISMATCH` |
| B1-C8 | `NATIVE_SUCCESSOR_NOT_PROVEN` | `NATIVE_SUCCESSOR_NOT_AUTONOMOUS` → `NATIVE_SUCCESSOR_NOT_PROVEN` |
| B1-C9 | `GWO_RECEIPT_ALIAS` | `THREE_GWO_PROXY_PASS` → `GWO_RECEIPT_ALIAS` |

- 方法 misspell 的唯一 canonical：`METHOD_REQUIRED_NOT_INVOKED`；`REQUIRED_METHOD_NOT_INVOKED` 是輸入相容 alias，必機械轉正且 **Fail-closed**。`*_EDGE/*_SEC` 是 case class suffix，不能視為新的 canonical FirstFail。

## 3. 五原生方法的每卡法位 Resolver（不得以安裝當調用）

實際 `effective_policy_snapshot` 必由 HGK/Fabric Owner 取得，欄位 `{policy_id,policy_epoch,policy_sha,scope,method_registry_sha,mandatory_set,optional_set,owner_signature}`。未取得完整 snapshot 回 `POLICY_UNBOUND`，**不能推測方法 mandatory**。

```python
def resolve_methods(wo, policy, receipts):
    if not policy or not policy.get('owner_signature') or not policy.get('policy_epoch'):
        return {'gate':'HOLD', 'first_fail':'POLICY_UNBOUND'}
    result=[]
    for name in ('KANBAN','SWARM','GSTACK','OPENSPEC','CODEX'):
        required=name in policy['mandatory_set'] or name in policy.get('per_wo_required',{}).get(wo['id'], [])
        selected=required or name in policy.get('per_wo_selected',{}).get(wo['id'], [])
        proof=receipts.get((wo['id'],name,policy['policy_epoch']))
        if required and (not proof or proof.get('operation') != 'REAL_INVOKE' or not proof.get('same_subject') or not proof.get('raw_sha')):
            return {'gate':'HOLD','first_fail':'METHOD_REQUIRED_NOT_INVOKED','method':name,'workorder':wo['id']}
        if not required and not selected:
            result.append({'method':name,'state':'NOT_SELECTED_WITH_REASON','reason':'policy_not_selected'})
        elif not proof or proof.get('nack'):
            return {'gate':'HOLD','first_fail':'METHOD_SELECTED_BUT_UNPROVEN','method':name}
        else:
            result.append({'method':name,'state':'INVOKED','receipt_sha':proof['raw_sha']})
    return {'gate':'METHODS_EVIDENCED','decisions':result}
```
`METHOD-06 OpenSpec` 在 R15 商品分類為 conditional 也不能降低 Owner 現役 Mandatory Policy：當前 policy epoch 強制即必調用；工具未安裝只能 `HOLD/NO_FIT`，絕不可偽造 `NOT_SELECTED_WITH_REASON`。所有 WO/OBS 逐筆配置待綁政策 slot，見 PD Writer。

## 4. G-A/G-B 真正合取與 StopLoss

**G-A = native issuer live AND fair durable queue progress AND Fabric stage→active→loaded same SHA AND PLAN/EXECUTE/VERIFY_SECURITY required=served AND method-applicability receipts in same policy epoch AND independent checker raw same subject**。任何缺項 G-A HOLD；已通過一項不能補另一項。
**G-B = 三張不同 Golden WO 的 domain 正結果 AND distinct receipt identities AND external revoke before next session AND native successor executed without external trigger AND rollback/readback zero residue**。其中使用者 SBL TODO 不能用安裝成功充作數據新增。
`SL-ISSUER/SL-QUEUE/SL-LOAD/SL-USER/SL-METHOD/SL-CHECKER/SL-EFFECT` 各只阻斷受影 cone；`UNKNOWN_EFFECT` 先 read-world-state/reconcile 才能提補償 WorkOrder。

## 5. SBL 六模組雙 taxonomy：舊 M5 修補與舊 M6 HostDistribution 不可消失

| 舊產品模組 | 新 Flow Module 承接 | 實際產品結果 | 未滿足的拒收 |
|---|---|---|---|
| `SBLM01 / old M1` Intent/UX | New M1 Intake + TPM | GoalCard、QuestionLedger、Quick/Guided/Critical | 無來源/duplicate question→INTAKE_HOLD |
| `SBLM02 / old M2` Resolver | New M2 Authority + M4 ReuseResolver | source/fit/no-fit per capability | conflict/unsigned admission→SOURCE_FREEZE_HOLD |
| `SBLM03 / old M3` Canonical Bridge | New M3 SpecProjection | 只讀 PIPD-PI refs 無第二寫者 | second PI writer→DENY |
| `SBLM04 / old M4` Execution Bridge | New M5 ExecutionHandoff | HGK native issuer 受理的 WorkOrder + ACK/NACK | SBL 自己發 Permit→DENY |
| `SBLM05 / old M5` Evidence + Repair | New M6 EvidenceClosure + Commander RepairCone | Raw→FirstFail→bounded diff→red/green→requalification | 只計 test pass 無受影修補→REPAIR_NOT_PROVEN |
| `SBLM06 / old M6` Distribution/Host | **DOC-12 HostDistribution independent service** | install/doctor/load/invoke/deny/uninstall/residue | ZIP presence/manifest-only→HOST_NOT_LOADED |
依原 SBL 產品來源，新六 Flow Module 命名不等於舊六產品模組；保留兩套 `M1..M6` ID 與獨立 pre/post/NEG。

## 6. Source/Policy provenance and no parallel planes

有活 `HG-KSEOS` issuer, `Fabric` policy consumer, `Hermes` queue owner, SBL six modules 與 PIPD 編譯器時，任何 GStack、Spec Kit、OpenSpec、Superpowers、MCP、ACP、SQLite/FTS5、CodeQL、SLSA 均只能做有條件工具，不可生成第二 issuer、checker、scheduler 或 knowledge authority。其 Version/License/Host ABI 未獨立查驗前保持 `TECH_ADMISSION_HOLD`。
