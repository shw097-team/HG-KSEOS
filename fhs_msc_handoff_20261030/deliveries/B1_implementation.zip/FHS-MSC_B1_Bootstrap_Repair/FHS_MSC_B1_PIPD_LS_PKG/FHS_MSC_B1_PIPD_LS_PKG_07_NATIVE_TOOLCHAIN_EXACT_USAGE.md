---
artifact_family: FHS-MSC-B1-Bootstrap-Repair-PIPD-LS-PKG
version: 2026-10-26_r3_HIGH_RETENTION_SUBSTANTIVE_AUDIT_REPAIR
supersedes_version: 2026-10-26-r2-HIGH-RETENTION-SOURCE-BOUND
supersedes_subject_sha256: 273591a3f0cc7f43c87d6ac5e9e5704cf7ede15440a8a159b1de71d4c7d52da5
change_type: HIGH_RETENTION_INTEGRATE_COVER_REPLACE_NO_ARCHITECTURE_RESET
task_kind: DESIGN
claim_ceiling: AUTHOR_SIDE_REPAIR_CANDIDATE
formal_sourcefreeze: HOLD
independent_checker_receipt: NOT_RUN
native_effect: NOT_RUN
release: NOT_RUN
---

# Native PIPD CLI / Contracts / Method / Donor｜逐工具有效入參、拒收與退出

此冊補完 A-15/A-19：**真 CLI 已讀到 parser 和 P4 schema**，但目前沒有本機 PIPD CLI binary，以下命令是可供 Owner 拿去執行的合法 syntax/negative pair；所有 `<...>` 占位必先從真正產物解析，不可以原樣帶進正式執行。

## 1. 十三 CLI 逐 Verb 合法用法（未經 Owner 授權只允許 read-only/dry-run）

| Verb | Exact syntax（模板） | 必備前提／副作用種類 | 應讀回／有意輸入錯誤的拒收 |
|---|---|---|---|
| \`init\` | \`pipd --root <ISOLATED_ROOT> init\` | empty Owner-approved new workspace; workspace manifest write | manifest/status; second init -> INIT_CONFLICT |
| \`intake\` | \`pipd --root <ROOT> intake --goal <GOAL> --source <EXACT_EXISTING_SOURCE>\` | nonblank goal + source under admitted root; deterministic candidate | IntentCard id+hash; missing --goal -> argparse nonzero |
| \`profile\` | \`pipd --root <ROOT> profile --profile ASSURED --axis intent --axis verification\` | enum ASSURED + unique nine native axes; no effect | ProfileBinding typed; duplicate axis/ELITE -> PROFILE_VETO |
| \`compile-pi\` | \`pipd --root <ROOT> compile-pi --intent <FROZEN_INTENT_JSON> --profile ASSURED --replay --explain\` | actual frozen IntentCard; PIPD-EC atoms five native enum only | PI-PKG with identity_equal; fake _profile_meta/zero atom -> PI_SCHEMA/PI_SEMANTIC |
| \`bind-pd\` | \`pipd --root <ROOT> bind-pd --pi <PI_JSON> --repo-root <REAL_REPO>\` | derive actual RepoContext, not caller --head claim; artifact compile | PD-PKG currentness; missing real repo -> REPO_CONTEXT_MISSING |
| \`compile-ecp\` | \`pipd --root <ROOT> compile-ecp --pd <PD_JSON> --pi <PI_JSON> --explain\` | real same-subject PD/PI and explicit writable scope | ConstructionContract+ECP; wrong scope/absent rollback -> EFFECT_UNKNOWN |
| \`compile-tqaep\` | \`pipd --root <ROOT> compile-tqaep --pi <PI_JSON> --ecp <ECP_JSON> --maker <MAKER> --checker <CHECKER> --checker-receipt <RAW_RECEIPT>\` | distinct immutable maker/checker principal & non-self-attested receipt | TQAEP; same principal or missing checker receipt -> TQ_SOD |
| \`validate\` | \`pipd --root <ROOT> validate --bundle <BUNDLE_JSON> --explain\` | actual schema registry; read-only validation | schema_source + verdict; unknown schema -> VALIDATION_FAIL |
| \`doctor\` | \`pipd --root <ROOT> doctor\` | read current tool/environment/schema registry; no world mutation | doctor status; missing registry -> TOOL_DRIFT/HOST_UNSUPPORTED |
| \`project\` | \`pipd --root <ROOT> project --dry-run --out <OWNER_ALLOWED_OUT>\` | dry-run projection; full run only allowlisted dest | PROJECTION_IR / dry-run plan; unsafe destination -> UNSAFE_DESTINATION |
| \`export\` | \`pipd --root <ROOT> export --dry-run --out <OWNER_ALLOWED_OUT>\` | dry-run; real portable export requires allow-root/owner permission | manifest and sha; secret scan/unsafe destination -> EXPORT_HASH/SECRET_SCAN |
| \`diff\` | \`pipd --root <ROOT> diff --a <BUNDLE_A_JSON> --b <BUNDLE_B_JSON> --explain\` | two real versioned subjects; read-only | typed diff; incompatible schema -> DIFF_INCOMPATIBLE_SCHEMA |
| \`repair\` | \`pipd --root <ROOT> repair --subject <SUBJECT> --authorized-root <ROOT> --scope <AFFECTED_PATH> --dry-run\` | no mutation in dry-run; actual repair only authorized Owner scope | repair plan; empty/wildcard/out-of-root scope -> REPAIR_SCOPE |

### Native stdout/exit 共同判讀

成功 = `exit_code=0` 仍需逐項解析實際 JSON output `$schema`, `subject_id`, `content_hash`、`schema_source`、`readback`；錯誤 = 非零且 schema/error code 能指到 first fail。`pipd --help` 僅檢 CLI 已安裝，不證明任何 token/effect/Host Loaded。`pipeline.strip_sidecar` 僅用 deterministic replay comparison，不准把 sidecar 當被簽的 native atom。

## 2. 19 個 Native Contract 身份與必檢鍵位

| contract | Native Schema/責任 | 正例及 Negative |
|---|---|---|
| ArtifactIdentity | identity/supersedes/invalidates; Registry \`$id\` + required/enum/additionalProperties + deterministic subject/hash | valid ArtifactIdentity produces trace-bound typed result; missing required field or foreign SHA fails |
| AuthorityBinding | rank/conflict/currentness; Registry \`$id\` + required/enum/additionalProperties + deterministic subject/hash | valid AuthorityBinding produces trace-bound typed result; missing required field or foreign SHA fails |
| RequirementAtom | req/source/owner/acceptance/risk; Registry \`$id\` + required/enum/additionalProperties + deterministic subject/hash | valid RequirementAtom produces trace-bound typed result; missing required field or foreign SHA fails |
| ProfileBinding | weight/axes/veto/assurance; Registry \`$id\` + required/enum/additionalProperties + deterministic subject/hash | valid ProfileBinding produces trace-bound typed result; missing required field or foreign SHA fails |
| TechnologyAdmission | need/selected disposition/pin/license/fallback; Registry \`$id\` + required/enum/additionalProperties + deterministic subject/hash | valid TechnologyAdmission produces trace-bound typed result; missing required field or foreign SHA fails |
| PI-PKG | stable semantic + trace; Registry \`$id\` + required/enum/additionalProperties + deterministic subject/hash | five original REQ enum only + bound DOC-03 DOMAIN_ORACLES; foreign B1 atom rejects |
| PD-PKG | RepoContext/currentness/affected scope; Registry \`$id\` + required/enum/additionalProperties + deterministic subject/hash | valid RepoContext(root/head/tracked_files/currentness/writable_scope); empty or escaping scope refuses |
| TraceLink | typed ref+from_hash+to_hash; Registry \`$id\` + required/enum/additionalProperties + deterministic subject/hash | valid TraceLink produces trace-bound typed result; missing required field or foreign SHA fails |
| TaskSpecSeed | goals/input/output/tests/rollback; Registry \`$id\` + required/enum/additionalProperties + deterministic subject/hash | valid TaskSpecSeed produces trace-bound typed result; missing required field or foreign SHA fails |
| ConstructionContract | writes/tests/evidence/rollback; Registry \`$id\` + required/enum/additionalProperties + deterministic subject/hash | valid ConstructionContract produces trace-bound typed result; missing required field or foreign SHA fails |
| WorkOrderCandidate | candidate_only/never native; Registry \`$id\` + required/enum/additionalProperties + deterministic subject/hash | valid WorkOrderCandidate produces trace-bound typed result; missing required field or foreign SHA fails |
| ECP | effect/permission/retries/idempotency/readback; Registry \`$id\` + required/enum/additionalProperties + deterministic subject/hash | token_required=true, rollback.required=true, at-most-once; missing token or rollback -> ECP_PERMISSION |
| TQAEP | tests/oracles/POS/NEG/requalification; Registry \`$id\` + required/enum/additionalProperties + deterministic subject/hash | valid TQAEP produces trace-bound typed result; missing required field or foreign SHA fails |
| ExecutionHandoff | receiver/ack-nack/payload refs; Registry \`$id\` + required/enum/additionalProperties + deterministic subject/hash | valid ExecutionHandoff produces trace-bound typed result; missing required field or foreign SHA fails |
| EvidenceExpectation | producer/postcondition/freshness; Registry \`$id\` + required/enum/additionalProperties + deterministic subject/hash | valid EvidenceExpectation produces trace-bound typed result; missing required field or foreign SHA fails |
| ClaimCeiling | allowed/forbidden/close; Registry \`$id\` + required/enum/additionalProperties + deterministic subject/hash | valid ClaimCeiling produces trace-bound typed result; missing required field or foreign SHA fails |
| SurfaceProjectionManifest | source/variant/parity_loss/stale; Registry \`$id\` + required/enum/additionalProperties + deterministic subject/hash | valid SurfaceProjectionManifest produces trace-bound typed result; missing required field or foreign SHA fails |
| GENIEProjectionRef | GENIE-only adapter/schema seam; Registry \`$id\` + required/enum/additionalProperties + deterministic subject/hash | valid GENIEProjectionRef produces trace-bound typed result; missing required field or foreign SHA fails |
| ExecutionBindingRef | HGK-only receiver lease/ref seam; Registry \`$id\` + required/enum/additionalProperties + deterministic subject/hash | valid ExecutionBindingRef produces trace-bound typed result; missing required field or foreign SHA fails |

## 3. 二十五個 METHOD 具名功能與 Trigger/Nontrigger/Exit

任何工具方法先以 per-WO effective Owner Policy 判斷 REQUIRED；其後才參考 R15 `CONDITIONAL/FULL_PRODUCT_DEFERRED`。`KANBAN/SWARM/GSTACK/OPENSPEC/CODEX` 的 method invocation 另有唯一 runtime receipt，不能用本表替代。

| METHOD | 業務能力 | Trigger/Needed evidence | Nontrigger/Exit |
|---|---|---|---|
| METHOD-01 BMAD-METHOD | BMAD-METHOD | spec/test process selected with actual route and source license/version | do not replace PIPD-EC deterministic compiler |
| METHOD-02 mattpocock/skills:grill-with-docs | mattpocock/skills:grill-with-docs | spec/test process selected with actual route and source license/version | do not replace PIPD-EC deterministic compiler |
| METHOD-03 mattpocock/skills:domain-modeling | mattpocock/skills:domain-modeling | spec/test process selected with actual route and source license/version | do not replace PIPD-EC deterministic compiler |
| METHOD-04 mattpocock/skills:to-spec | mattpocock/skills:to-spec | spec/test process selected with actual route and source license/version | do not replace PIPD-EC deterministic compiler |
| METHOD-05 mattpocock/skills:to-tickets | mattpocock/skills:to-tickets | spec/test process selected with actual route and source license/version | do not replace PIPD-EC deterministic compiler |
| METHOD-06 OpenSpec | OpenSpec | spec/test process selected with actual route and source license/version | do not replace PIPD-EC deterministic compiler |
| METHOD-07 Spec Kit | Spec Kit | spec/test process selected with actual route and source license/version | do not replace PIPD-EC deterministic compiler |
| METHOD-08 Superpowers | Superpowers | spec/test process selected with actual route and source license/version | do not replace PIPD-EC deterministic compiler |
| METHOD-09 GitHub Actions | GitHub Actions | pinned CI job and raw same-commit readback | CI green != native runtime |
| METHOD-10 MCP | MCP | Host runtime/tool protocol needed, ABI+permissions+license | no Native issue/authorization, MCP != ACP |
| METHOD-11 ACP | ACP | Host runtime/tool protocol needed, ABI+permissions+license | no Native issue/authorization, MCP != ACP |
| METHOD-12 OpenSSF Scorecard | OpenSSF Scorecard | security source audit/repro; signed scan tool pin + negative finding fixture | advisory scan not independent native accept |
| METHOD-13 SLSA | SLSA | immutable release artefact, sbom/provenance signature chain | build provenance != Host Loaded or G-A |
| METHOD-14 OWASP | OWASP | security source audit/repro; signed scan tool pin + negative finding fixture | advisory scan not independent native accept |
| METHOD-15 CodeQL | CodeQL | security source audit/repro; signed scan tool pin + negative finding fixture | advisory scan not independent native accept |
| METHOD-16 Semgrep | Semgrep | security source audit/repro; signed scan tool pin + negative finding fixture | advisory scan not independent native accept |
| METHOD-17 Renovate | Renovate | deps version drift, approved manifest scope and changelog | no package auto-upgrade unless Owner scope |
| METHOD-18 Dependabot | Dependabot | deps version drift, approved manifest scope and changelog | no package auto-upgrade unless Owner scope |
| METHOD-19 Cosign | Cosign | immutable release artefact, sbom/provenance signature chain | build provenance != Host Loaded or G-A |
| METHOD-20 Syft | Syft | immutable release artefact, sbom/provenance signature chain | build provenance != Host Loaded or G-A |
| METHOD-21 Trivy | Trivy | security source audit/repro; signed scan tool pin + negative finding fixture | advisory scan not independent native accept |
| METHOD-22 SQLite/FTS5 | SQLite/FTS5 | native journal/index need and existing HGK ledger gap proof | cannot fork second task state truth |
| METHOD-23 FAR/FDA | FAR/FDA | Owner-driven capability gap, exact version/license/host+negative gate | no auto donor installation |
| METHOD-24 OpenAI Agents SDK | OpenAI Agents SDK | Host runtime/tool protocol needed, ABI+permissions+license | no Native issue/authorization, MCP != ACP |
| METHOD-25 Agent Skills specification | Agent Skills specification | Owner-driven capability gap, exact version/license/host+negative gate | no auto donor installation |

## 4. 二十四 Donor Slot 逐 Slot 現場決策及負例

| Slot | Named candidate | 狀態與被選條件 | distinct NACK / exit |
|---|---|---|
| SLOT-OS-01 | OpenSpec | CONDITIONAL_ONLY; brownfield change proposal -> typed request + real OpenSpec route evidence; license/version/Host pin required | NO_FIT if no native gap/unknown ABI; undo only actual installed bytes |
| SLOT-OS-02 | OpenSpec | CONDITIONAL_ONLY; brownfield change proposal -> typed request + real OpenSpec route evidence; license/version/Host pin required | NO_FIT if no native gap/unknown ABI; undo only actual installed bytes |
| SLOT-OS-03 | OpenSpec | CONDITIONAL_ONLY; brownfield change proposal -> typed request + real OpenSpec route evidence; license/version/Host pin required | NO_FIT if no native gap/unknown ABI; undo only actual installed bytes |
| SLOT-OS-04 | OpenSpec | CONDITIONAL_ONLY; brownfield change proposal -> typed request + real OpenSpec route evidence; license/version/Host pin required | NO_FIT if no native gap/unknown ABI; undo only actual installed bytes |
| SLOT-SK-01 | Spec Kit | CONDITIONAL_ONLY; requirements spec drafting only -> not PIPD second compiler; license/version/Host pin required | NO_FIT if no native gap/unknown ABI; undo only actual installed bytes |
| SLOT-SK-02 | Spec Kit | CONDITIONAL_ONLY; requirements spec drafting only -> not PIPD second compiler; license/version/Host pin required | NO_FIT if no native gap/unknown ABI; undo only actual installed bytes |
| SLOT-SK-03 | Spec Kit | CONDITIONAL_ONLY; requirements spec drafting only -> not PIPD second compiler; license/version/Host pin required | NO_FIT if no native gap/unknown ABI; undo only actual installed bytes |
| SLOT-SK-04 | Spec Kit | CONDITIONAL_ONLY; requirements spec drafting only -> not PIPD second compiler; license/version/Host pin required | NO_FIT if no native gap/unknown ABI; undo only actual installed bytes |
| SLOT-MP-01 | mattpocock/skills | CONDITIONAL_ONLY; Skill-specific trigger/nontrigger -> output read-only candidate; license/version/Host pin required | NO_FIT if no native gap/unknown ABI; undo only actual installed bytes |
| SLOT-MP-02 | mattpocock/skills | CONDITIONAL_ONLY; Skill-specific trigger/nontrigger -> output read-only candidate; license/version/Host pin required | NO_FIT if no native gap/unknown ABI; undo only actual installed bytes |
| SLOT-MP-03 | mattpocock/skills | CONDITIONAL_ONLY; Skill-specific trigger/nontrigger -> output read-only candidate; license/version/Host pin required | NO_FIT if no native gap/unknown ABI; undo only actual installed bytes |
| SLOT-MP-04 | mattpocock/skills | CONDITIONAL_ONLY; Skill-specific trigger/nontrigger -> output read-only candidate; license/version/Host pin required | NO_FIT if no native gap/unknown ABI; undo only actual installed bytes |
| SLOT-GS-01 | GSD | CONDITIONAL_ONLY; delivery planning, explicit tasks and no native issuer; license/version/Host pin required | NO_FIT if no native gap/unknown ABI; undo only actual installed bytes |
| SLOT-GS-02 | GSD | CONDITIONAL_ONLY; delivery planning, explicit tasks and no native issuer; license/version/Host pin required | NO_FIT if no native gap/unknown ABI; undo only actual installed bytes |
| SLOT-GS-03 | GSD | CONDITIONAL_ONLY; delivery planning, explicit tasks and no native issuer; license/version/Host pin required | NO_FIT if no native gap/unknown ABI; undo only actual installed bytes |
| SLOT-GS-04 | GSD | CONDITIONAL_ONLY; delivery planning, explicit tasks and no native issuer; license/version/Host pin required | NO_FIT if no native gap/unknown ABI; undo only actual installed bytes |
| SLOT-GT-01 | gstack | CONDITIONAL_ONLY; actual roleized method registry ACTIVE_SELECTED and route(flow); license/version/Host pin required | NO_FIT if no native gap/unknown ABI; undo only actual installed bytes |
| SLOT-GT-02 | gstack | CONDITIONAL_ONLY; actual roleized method registry ACTIVE_SELECTED and route(flow); license/version/Host pin required | NO_FIT if no native gap/unknown ABI; undo only actual installed bytes |
| SLOT-GT-03 | gstack | CONDITIONAL_ONLY; actual roleized method registry ACTIVE_SELECTED and route(flow); license/version/Host pin required | NO_FIT if no native gap/unknown ABI; undo only actual installed bytes |
| SLOT-GT-04 | gstack | CONDITIONAL_ONLY; actual roleized method registry ACTIVE_SELECTED and route(flow); license/version/Host pin required | NO_FIT if no native gap/unknown ABI; undo only actual installed bytes |
| SLOT-SP-01 | Superpowers | CONDITIONAL_ONLY; bounded test/design workflow, avoid duplicated authority; license/version/Host pin required | NO_FIT if no native gap/unknown ABI; undo only actual installed bytes |
| SLOT-SP-02 | Superpowers | CONDITIONAL_ONLY; bounded test/design workflow, avoid duplicated authority; license/version/Host pin required | NO_FIT if no native gap/unknown ABI; undo only actual installed bytes |
| SLOT-SP-03 | Superpowers | CONDITIONAL_ONLY; bounded test/design workflow, avoid duplicated authority; license/version/Host pin required | NO_FIT if no native gap/unknown ABI; undo only actual installed bytes |
| SLOT-SP-04 | Superpowers | CONDITIONAL_ONLY; bounded test/design workflow, avoid duplicated authority; license/version/Host pin required | NO_FIT if no native gap/unknown ABI; undo only actual installed bytes |

## 5. Source to Tool ownership／Author side examples

Each selected method/donor must write `TechnologyAdmission{source_id,Need,existing_capability,feature_gap,version_pin,licence,host_probe,selected_state,Owner,rollback}` *candidate* into the current Owner/Native reviewer flow, not into a parallel uncontrolled registry. Any non-selected item produces reason and retains its old named denominator.

### 5.1 Negative, do not execute

```json
{
  "claim": "NONE",
  "command": "pipd compile-pi",
  "error": "missing required --intent and actual frozen IntentCard",
  "expected_cli": "nonzero",
  "expected_pipd_semantics": "PI_SCHEMA",
  "world_mutations": 0
}
```
