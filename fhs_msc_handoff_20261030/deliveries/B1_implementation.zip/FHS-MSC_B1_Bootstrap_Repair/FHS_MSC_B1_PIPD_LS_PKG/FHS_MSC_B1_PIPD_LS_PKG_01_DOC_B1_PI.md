---
artifact_family: FHS-MSC-B1-Bootstrap-Repair-PIPD-LS-PKG
version: 2026-10-26_r3_HIGH_RETENTION_SUBSTANTIVE_AUDIT_REPAIR
supersedes_version: 2026-10-26-r2-HIGH-RETENTION-SOURCE-BOUND
supersedes_subject_sha256: 273591a3f0cc7f43c87d6ac5e9e5704cf7ede15440a8a159b1de71d4c7d52da5
change_type: HIGH_RETENTION_INTEGRATE_COVER_REPLACE_NO_ARCHITECTURE_RESET
task_kind: DESIGN
claim_ceiling: AUTHOR_SIDE_REPAIR_CANDIDATE
formal_sourcefreeze: HOLD
independent_checker_receipt: NOT_RUN
native_effect: NOT_RUN
release: NOT_RUN
---

# DOC-B1-PI｜27 Requirement Atoms／P4 Native Compiler 及五軸 Sidecar

## 1. P4 原生 strict input（允許真的 JSON Schema 驗證；不假造 output identity）

**Profile input `urn:pipd:skill:pipd-profile-tailor:input:1`**：

```json
{
  "axes": [
    "intent",
    "knowledge",
    "verification",
    "release",
    "trust_boundary",
    "preexisting_repo",
    "profile",
    "tech_candidates",
    "host_surface"
  ],
  "profile": "ASSURED",
  "provider_off_required": true
}
```
**Profile 期望條件（不是捏造 ProfileBinding）**：有效 profile ASSURED、artifact_depth L4_FAILURE_RECOVERY、canonical_truth single；output 必由 plugin 產生真正 subject_id/content_hash/version/schema_version/escalated/escalation_reason/axes/vetoes/assurance。
**Negative fixture**：注入 `profile_request`／`project_atom_adapter` 當額外頂層欄位、雙軸或 `profile=ELITE`，`additionalProperties:false`/enum/uniqueItems 必拒；原生 schema 決不能被自製 sidecar 擴欄。

## 2. 原生 Intake/PI adapter 轉換程序

`B1 Goal + source locators` → P4 `pipd-route-intake` (strict goal/sources) → 由原生路由推導五軸 `REQ-INTENT,REQ-KNOWLEDGE,REQ-VERIFY,REQ-DELIVER,REQ-GOVERN` 中受影集合；不足立即 fail closed。P4 `pipd-authority-source` 只能在 family digest/locator/Owner 無衝突時建立正式 SourceFreezeManifest；本文件只有候選清單。

**PI native input 形狀（僅適用持有真 IntentCard 的 Host；以下值為設計規則，沒有編造 subject/hash）**：

```python
def make_p4_pi_input(intent_from_native, profile_binding_from_native, project_atoms, owner_oracles):
    allowed={'REQ-INTENT','REQ-KNOWLEDGE','REQ-VERIFY','REQ-DELIVER','REQ-GOVERN'}
    assert intent_from_native['subject_id'].startswith('INTENT-')
    assert profile_binding_from_native['schema_version']=='ProfileBinding@1'
    # Important: P4 input atoms are native REQ-* ONLY, and owner must be PIPD-EC.
    native=[]
    for req in intent_from_native['atoms']:
        key=req['req_id']; assert key in allowed
        oracle=owner_oracles.get(key)
        if not oracle or not oracle.get('source_clause') or not oracle.get('acceptance_cue'):
            raise ValueError('PI_SEMANTIC_OR_ORACLE_UNBOUND')
        native.append({'req_id':key,'source_clause':oracle['source_clause'],
                       'owner':'PIPD-EC','acceptance_cue':oracle['acceptance_cue'],
                       'risk_guard':oracle['risk_guard']})
    return {'intent':{'subject_id':intent_from_native['subject_id'],
                      'content_hash':intent_from_native['content_hash']},
            'profile':profile_binding_from_native['profile'],
            'atoms':native,'goal':intent_from_native['goal']}
# Output mapping to B1 is separately owned, never sent as a native P4 top-level key.
```
**Sidecar**：對每個 27 Atom 記 `{project_atom_id,source_clause_hash,original_owner,mapped_native_req_id,loss_flags,owner_approval_ref}`。loss_flags 非空或 oracle 未簽，native PI 即使可編譯也不能替本 B1 domain 直接出 ECP。

## 3. 27 個獨立可反證的 Atom（所附 runner 為 Owner 綁定候選）

### PI-B1-A1｜ROOT_RAW

- **上位來源**：FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_BLUEPRINT_AND_SKELETON_r2.md@dddc6b5993c88b9a2365aa9435ee492a543add3ebe4c89d79c58c58f9d16dbab#L257-L263 excerpt_sha256=a407811782933d9d0f3fe0a44acebcd59d73125f60021b0adc1f337cd97d2ecc; Owner：`Host/RootMap Owner`。
- **必要輸入與狀態**：`Windows realpath, git -C status --porcelain=v1 -z -uall, HEAD, index, reparse ancestors`；合法狀態：`CandidateRoot→ResolvedHandle→SnapshottedIndex→FRESH_OR_STALE`。
- **業務作用/可觀察成功**：Same handle/file-ID inside signed root; two scans no change；本域判準：same file ID and signed root; staged/unstaged/untracked snapshot stable。
- **候選 Owner ABI**：`root_probe`；其專屬 typed fields：`real_root,git_head,status_index,reparse_chain,root_handle`；明確定位前 `RUNNER_NOT_BOUND`，不可使用通用 OWNER_APPROVED_NATIVE_DOMAIN_ADAPTER 當假指令。
- **NEG/EDGE/SEC**：`alias/junction traversal or changed HEAD -> ROOT_ALIAS_OR_PATH_ESCAPE`。NEG 細分碼 `ROOT_ALIAS_OR_PATH_ESCAPE` → canonical `ROOT_ALIAS_OR_PATH_ESCAPE`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- **權限與回復**：- **Scope & rollback**：effect_class=READ_ONLY_PROBE、effect_key=ROOT_RAW；No mutation; drop stale probe, repeat fresh read。合法重試不得越過 at-most-once，對 UNKNOWN_EFFECT 先觀測 reconcile。；formal oracle/Owner status=UNBOUND。；真 effect 未執行時停止、隔離 observation，不要求無效的 rollback token。
- **可閉合 Join**：來源 Clause→PI-B1-A1→PD 的 WO/OBS→每個 effect ECP/NO_EFFECT→`TQ-B1-A1-POS/NEG/EDGE/SEC`→相同 subject immutable raw→Independent Checker；無 raw 永遠 `PLANNED/NOT_RUN`。

### PI-B1-A2｜ISSUER_SUBJECT

- **上位來源**：FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_BLUEPRINT_AND_SKELETON_r2.md@dddc6b5993c88b9a2365aa9435ee492a543add3ebe4c89d79c58c58f9d16dbab#L270-L276 excerpt_sha256=5b927350aee06a401945b3e3261b9809bb5af16adad5f9ae0b4f71c5a2b2b0e7; Owner：`HGK Native Issuer Owner`。
- **必要輸入與狀態**：`subject+epoch+scope+operation+ttl+nonce+issuer identity`；合法狀態：`Unissued→ValidatedRequest→NativePermitOrNack→ConsumedNonce`。
- **業務作用/可觀察成功**：Token signature/principal/nonce/subject/TTL checked native-side before spawn；本域判準：issuer-signed exact subject/scope checked before spawn; nonce consumed once。
- **候選 Owner ABI**：`native_issuer`；其專屬 typed fields：`issuer_identity,subject_sha,nonce,ttl,policy_epoch,grant_signature`；明確定位前 `RUNNER_NOT_BOUND`，不可使用通用 OWNER_APPROVED_NATIVE_DOMAIN_ADAPTER 當假指令。
- **NEG/EDGE/SEC**：`wrong issuer or replayed nonce -> PERMIT_SUBJECT_NONCE_REPLAY`。NEG 細分碼 `PERMIT_SUBJECT_NONCE_REPLAY` → canonical `PERMIT_SUBJECT_NONCE_REPLAY`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- **權限與回復**：- **Scope & rollback**：effect_class=OPS_NATIVE_HANDOFF、effect_key=ISSUER_SUBJECT；Invalidate grant; reconcile any in-flight effect; no replay。合法重試不得越過 at-most-once，對 UNKNOWN_EFFECT 先觀測 reconcile。；formal oracle/Owner status=UNBOUND。；真 effect 未執行時停止、隔離 observation，不要求無效的 rollback token。
- **可閉合 Join**：來源 Clause→PI-B1-A2→PD 的 WO/OBS→每個 effect ECP/NO_EFFECT→`TQ-B1-A2-POS/NEG/EDGE/SEC`→相同 subject immutable raw→Independent Checker；無 raw 永遠 `PLANNED/NOT_RUN`。

### PI-B1-A3｜QUEUE_WO

- **上位來源**：FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_BLUEPRINT_AND_SKELETON_r2.md@dddc6b5993c88b9a2365aa9435ee492a543add3ebe4c89d79c58c58f9d16dbab#L283-L289 excerpt_sha256=49402a7a88250a14862e94a00d1478b9aa47bfcc0f5daff2581da0e06005ee26; Owner：`Hermes Queue Owner`。
- **必要輸入與狀態**：`durable queue cursor, lease_generation, bounded K scan, resource lock`；合法狀態：`Queued→ClaimCAS→Running→Checkpoint/Parked→Terminal`。
- **業務作用/可觀察成功**：Scan at most K blocked cards, B/C independent advance; CAS generation single holder；本域判準：blocked A parked; independent B/C progressed within bounded K; generation CAS unique。
- **候選 Owner ABI**：`hermes_queue`；其專屬 typed fields：`queue_id,persisted_cursor,lease_generation,claimed_by,park_reason`；明確定位前 `RUNNER_NOT_BOUND`，不可使用通用 OWNER_APPROVED_NATIVE_DOMAIN_ADAPTER 當假指令。
- **NEG/EDGE/SEC**：`duplicate claim, starved B/C or stale generation -> LOST_LEASE_OR_DUPLICATE_CLAIM`。NEG 細分碼 `LOST_LEASE_OR_DUPLICATE_CLAIM` → canonical `LOST_LEASE_OR_DUPLICATE_CLAIM`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- **權限與回復**：- **Scope & rollback**：effect_class=OPS_RUNTIME_ACTIVATE、effect_key=QUEUE_WO；PARK blocked card with wake predicate; fence stale generation。合法重試不得越過 at-most-once，對 UNKNOWN_EFFECT 先觀測 reconcile。；formal oracle/Owner status=UNBOUND。；真 effect 未執行時停止、隔離 observation，不要求無效的 rollback token。
- **可閉合 Join**：來源 Clause→PI-B1-A3→PD 的 WO/OBS→每個 effect ECP/NO_EFFECT→`TQ-B1-A3-POS/NEG/EDGE/SEC`→相同 subject immutable raw→Independent Checker；無 raw 永遠 `PLANNED/NOT_RUN`。

### PI-B1-A4｜RECEIVER_ABI

- **上位來源**：FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_BLUEPRINT_AND_SKELETON_r2.md@dddc6b5993c88b9a2365aa9435ee492a543add3ebe4c89d79c58c58f9d16dbab#L296-L302 excerpt_sha256=0b2c8e188fc383e3527787eea20b618ff837b84830a8c96e4816819aa324aea2; Owner：`HGK Receiver Owner`。
- **必要輸入與狀態**：`HGK receiver typed ABI and issued WO, not mock mapping`；合法狀態：`ContractProposed→NativeAdmitted→AckOrNack→SameWOReadback`。
- **業務作用/可觀察成功**：Ack contains issuer and host identity; mocked ACK rejected；本域判準：true receiver ACK signed for exact subject; mock ACK never qualifies。
- **候選 Owner ABI**：`native_receiver`；其專屬 typed fields：`abi_id,issuer,wo_id,subject_sha,ack_or_nack,native_event`；明確定位前 `RUNNER_NOT_BOUND`，不可使用通用 OWNER_APPROVED_NATIVE_DOMAIN_ADAPTER 當假指令。
- **NEG/EDGE/SEC**：`mocked ACK/wrong ABI/absent native event -> RECEIVER_NOT_LIVE`。NEG 細分碼 `LIVE_RECEIVER_NOT_VERIFIED` → canonical `RECEIVER_NOT_LIVE`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- **權限與回復**：- **Scope & rollback**：effect_class=OPS_NATIVE_HANDOFF、effect_key=RECEIVER_ABI；No effect on NACK; rollback only affected admitted WO。合法重試不得越過 at-most-once，對 UNKNOWN_EFFECT 先觀測 reconcile。；formal oracle/Owner status=UNBOUND。；真 effect 未執行時停止、隔離 observation，不要求無效的 rollback token。
- **可閉合 Join**：來源 Clause→PI-B1-A4→PD 的 WO/OBS→每個 effect ECP/NO_EFFECT→`TQ-B1-A4-POS/NEG/EDGE/SEC`→相同 subject immutable raw→Independent Checker；無 raw 永遠 `PLANNED/NOT_RUN`。

### PI-B1-A5｜MODEL_LANES

- **上位來源**：FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_BLUEPRINT_AND_SKELETON_r2.md@dddc6b5993c88b9a2365aa9435ee492a543add3ebe4c89d79c58c58f9d16dbab#L309-L315 excerpt_sha256=466b5f697418b83d4ab49dbcae5945edeb48ae526dfacbcee2829951ebebb569; Owner：`Model/Lane Owner`。
- **必要輸入與狀態**：`required vs served PLAN/EXECUTE/VERIFY, version, epoch, digest`；合法狀態：`RequiredSet→HostServedProbe→EpochJoined→CoherentOrHold`。
- **業務作用/可觀察成功**：Every required lane served in exact epoch/host; one lane failure blocks Gate；本域判準：each mandatory lane actually served, same host and policy epoch。
- **候選 Owner ABI**：`host_lane_readback`；其專屬 typed fields：`PLAN,EXECUTE,VERIFY_SECURITY,required_arm,served_arm,epoch,loaded_sha`；明確定位前 `RUNNER_NOT_BOUND`，不可使用通用 OWNER_APPROVED_NATIVE_DOMAIN_ADAPTER 當假指令。
- **NEG/EDGE/SEC**：`silent model fallback or missing served arm -> MODEL_REQUIRED_NOT_SERVED`。NEG 細分碼 `SERVED_MODEL_MISMATCH` → canonical `MODEL_REQUIRED_NOT_SERVED`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- **權限與回復**：- **Scope & rollback**：effect_class=READ_ONLY_PROBE、effect_key=MODEL_LANES；Hold lane and independent affected dependent WO。合法重試不得越過 at-most-once，對 UNKNOWN_EFFECT 先觀測 reconcile。；formal oracle/Owner status=UNBOUND。；真 effect 未執行時停止、隔離 observation，不要求無效的 rollback token。
- **可閉合 Join**：來源 Clause→PI-B1-A5→PD 的 WO/OBS→每個 effect ECP/NO_EFFECT→`TQ-B1-A5-POS/NEG/EDGE/SEC`→相同 subject immutable raw→Independent Checker；無 raw 永遠 `PLANNED/NOT_RUN`。

### PI-B1-A6｜EFFECT_JOURNAL

- **上位來源**：FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_BLUEPRINT_AND_SKELETON_r2.md@dddc6b5993c88b9a2365aa9435ee492a543add3ebe4c89d79c58c58f9d16dbab#L322-L328 excerpt_sha256=36433fc130be7d86047b82bebf6e10490313b917528b9d98fba2583a9ef252d4; Owner：`Effect Journal Owner`。
- **必要輸入與狀態**：`operation ID, effect fingerprint, pre/posthash, outcome receipt, CAS fence`；合法狀態：`Prepared→Claimed→InFlight→ObservedSuccess/Unknown→Reconciled`。
- **業務作用/可觀察成功**：UNKNOWN_EFFECT cannot retry until world-state reconciled；本域判準：at-most-once effect; UNKNOWN_EFFECT reconciled before any next claim。
- **候選 Owner ABI**：`effect_journal`；其專屬 typed fields：`operation_id,preimage,observed_postimage,CAS_fence,unknown_effect`；明確定位前 `RUNNER_NOT_BOUND`，不可使用通用 OWNER_APPROVED_NATIVE_DOMAIN_ADAPTER 當假指令。
- **NEG/EDGE/SEC**：`duplicate operation or retry-on-timeout -> UNKNOWN_EFFECT_REPLAY`。NEG 細分碼 `DUPLICATE_OR_UNKNOWN_EFFECT` → canonical `UNKNOWN_EFFECT_REPLAY`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- **權限與回復**：- **Scope & rollback**：effect_class=OPS_RUNTIME_ACTIVATE、effect_key=EFFECT_JOURNAL；At-most-once, no retry of unknown; compensating rollback separate permit。合法重試不得越過 at-most-once，對 UNKNOWN_EFFECT 先觀測 reconcile。；formal oracle/Owner status=UNBOUND。；真 effect 未執行時停止、隔離 observation，不要求無效的 rollback token。
- **可閉合 Join**：來源 Clause→PI-B1-A6→PD 的 WO/OBS→每個 effect ECP/NO_EFFECT→`TQ-B1-A6-POS/NEG/EDGE/SEC`→相同 subject immutable raw→Independent Checker；無 raw 永遠 `PLANNED/NOT_RUN`。

### PI-B1-A7｜RAW_EVIDENCE

- **上位來源**：FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_BLUEPRINT_AND_SKELETON_r2.md@dddc6b5993c88b9a2365aa9435ee492a543add3ebe4c89d79c58c58f9d16dbab#L335-L341 excerpt_sha256=3c2e93ea528eec98d6f251c4e3ee1ffd2676fc028a38e4887b0c20194a37976b; Owner：`Independent AO`。
- **必要輸入與狀態**：`immutable raw hashes, witness signatures, subject/source/evidence SHA`；合法狀態：`ReceiptObserved→SourceSHAJoined→CheckerValidated→AcceptedOrRejected`。
- **業務作用/可觀察成功**：Maker!=Checker; no self-attested checker receipt；本域判準：distinct principal checker receipt matches same candidate and non-empty RAW。
- **候選 Owner ABI**：`immutable_evidence`；其專屬 typed fields：`raw_receipt,subject_sha,candidate_sha,checker_principal,witness`；明確定位前 `RUNNER_NOT_BOUND`，不可使用通用 OWNER_APPROVED_NATIVE_DOMAIN_ADAPTER 當假指令。
- **NEG/EDGE/SEC**：`self-attested or mismatched witness -> RAW_OR_CHECKER_MISMATCH`。NEG 細分碼 `RAW_SUBJECT_OR_WITNESS_MISSING` → canonical `RAW_OR_CHECKER_MISMATCH`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- **權限與回復**：- **Scope & rollback**：effect_class=READ_ONLY_PROBE、effect_key=RAW_EVIDENCE；Reject stale evidence and rerun only affected independent evaluation。合法重試不得越過 at-most-once，對 UNKNOWN_EFFECT 先觀測 reconcile。；formal oracle/Owner status=UNBOUND。；真 effect 未執行時停止、隔離 observation，不要求無效的 rollback token。
- **可閉合 Join**：來源 Clause→PI-B1-A7→PD 的 WO/OBS→每個 effect ECP/NO_EFFECT→`TQ-B1-A7-POS/NEG/EDGE/SEC`→相同 subject immutable raw→Independent Checker；無 raw 永遠 `PLANNED/NOT_RUN`。

### PI-B1-A8｜NATIVE_HOTPATH

- **上位來源**：FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_BLUEPRINT_AND_SKELETON_r2.md@dddc6b5993c88b9a2365aa9435ee492a543add3ebe4c89d79c58c58f9d16dbab#L348-L354 excerpt_sha256=f5e7c8c1351b8a63b6cdb6bb4b9b4bc17f7969074815dba121cadbf8105c09e1; Owner：`Fabric/HGK Dev Owner`。
- **必要輸入與狀態**：`identified deployed module and file digest; no historical blind replacement`；合法狀態：`RedReproducer→ScopedPreimage→MinimalPatch→Green→Review`。
- **業務作用/可觀察成功**：Exact current hotpath with rollback pointer and independent regression；本域判準：exact loaded callsite identified and scoped regression independent。
- **候選 Owner ABI**：`repo_diff`；其專屬 typed fields：`root,head,preimage,diff,writeset,red_green,postimage`；明確定位前 `RUNNER_NOT_BOUND`，不可使用通用 OWNER_APPROVED_NATIVE_DOMAIN_ADAPTER 當假指令。
- **NEG/EDGE/SEC**：`unbounded writes or missing red reproducer -> HOTPATH_UNRESOLVED`。NEG 細分碼 `UNMEASURED_REPAIR_OR_SCOPE_ESCAPE` → canonical `HOTPATH_UNRESOLVED`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- **權限與回復**：- **Scope & rollback**：effect_class=DEV_SOURCE_PATCH、effect_key=NATIVE_HOTPATH；Restore preimage; preserve untracked unrelated files。合法重試不得越過 at-most-once，對 UNKNOWN_EFFECT 先觀測 reconcile。；formal oracle/Owner status=UNBOUND。；真 effect 未執行時停止、隔離 observation，不要求無效的 rollback token。
- **可閉合 Join**：來源 Clause→PI-B1-A8→PD 的 WO/OBS→每個 effect ECP/NO_EFFECT→`TQ-B1-A8-POS/NEG/EDGE/SEC`→相同 subject immutable raw→Independent Checker；無 raw 永遠 `PLANNED/NOT_RUN`。

### PI-B1-A9｜NATIVE_CONTINUATION

- **上位來源**：FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_BLUEPRINT_AND_SKELETON_r2.md@dddc6b5993c88b9a2365aa9435ee492a543add3ebe4c89d79c58c58f9d16dbab#L361-L367 excerpt_sha256=a847c96af6ea83e51c5715836e8ab69d64ca6bf1f156becf292c6a7aeecfbbc3; Owner：`Hermes Continuation Owner`。
- **必要輸入與狀態**：`post-turn native trigger, mandate, persisted cursor and epoch`；合法狀態：`T0Proposal→T1Admit→T2NativeSpawn→T3Checkpoint→T4NativeResume`。
- **業務作用/可觀察成功**：Resume after external token revoked, initiated by native source；本域判準：native successor advances after external revoke with new session and no external trigger。
- **候選 Owner ABI**：`native_continuation`；其專屬 typed fields：`external_revoke,post_turn_source,issued_wo,native_claim,session_exit`；明確定位前 `RUNNER_NOT_BOUND`，不可使用通用 OWNER_APPROVED_NATIVE_DOMAIN_ADAPTER 當假指令。
- **NEG/EDGE/SEC**：`external actor still triggering -> EXTERNAL_TRIGGER_STILL_REQUIRED`。NEG 細分碼 `EXTERNAL_REENTRY_OR_NONNATIVE_SUCCESSOR` → canonical `EXTERNAL_TRIGGER_STILL_REQUIRED`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- **權限與回復**：- **Scope & rollback**：effect_class=OPS_RUNTIME_ACTIVATE、effect_key=NATIVE_CONTINUATION；Stop new external grant; reconcile in-flight; deny external replay。合法重試不得越過 at-most-once，對 UNKNOWN_EFFECT 先觀測 reconcile。；formal oracle/Owner status=UNBOUND。；真 effect 未執行時停止、隔離 observation，不要求無效的 rollback token。
- **可閉合 Join**：來源 Clause→PI-B1-A9→PD 的 WO/OBS→每個 effect ECP/NO_EFFECT→`TQ-B1-A9-POS/NEG/EDGE/SEC`→相同 subject immutable raw→Independent Checker；無 raw 永遠 `PLANNED/NOT_RUN`。

### PI-B1-B1｜SOURCE_ATOMS

- **上位來源**：FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_BLUEPRINT_AND_SKELETON_r2.md@dddc6b5993c88b9a2365aa9435ee492a543add3ebe4c89d79c58c58f9d16dbab#L374-L380 excerpt_sha256=bb7372aa3db524290bf4ad3a02fca0616c407398bb77c4af2e31e3169cdb808d; Owner：`PIPD Source Owner`。
- **必要輸入與狀態**：`16 REQ/27 atom, clause span+SHA, DOC03 domain oracles`；合法狀態：`RawSources→AtomCrosswalk→OracleBoundOrHold→PIProposed`。
- **業務作用/可觀察成功**：Missing/ambiguous clause opens TT; no fabricated PI issuer；本域判準：one-to-one source clause/owner/oracle joins; missing clause is HOLD。
- **候選 Owner ABI**：`source_oracle`；其專屬 typed fields：`clause_sha,atom_id,source_owner,domain_oracle,trace_edges`；明確定位前 `RUNNER_NOT_BOUND`，不可使用通用 OWNER_APPROVED_NATIVE_DOMAIN_ADAPTER 當假指令。
- **NEG/EDGE/SEC**：`missing oracle or fabricated source -> PI_SOURCE_OR_ORACLE_UNBOUND`。NEG 細分碼 `UNKNOWN_ATOM_SOURCE` → canonical `PI_SOURCE_OR_ORACLE_UNBOUND`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- **權限與回復**：- **Scope & rollback**：effect_class=READ_ONLY_PROBE、effect_key=SOURCE_ATOMS；HOLD only affected PI atoms。合法重試不得越過 at-most-once，對 UNKNOWN_EFFECT 先觀測 reconcile。；formal oracle/Owner status=UNBOUND。；真 effect 未執行時停止、隔離 observation，不要求無效的 rollback token。
- **可閉合 Join**：來源 Clause→PI-B1-B1→PD 的 WO/OBS→每個 effect ECP/NO_EFFECT→`TQ-B1-B1-POS/NEG/EDGE/SEC`→相同 subject immutable raw→Independent Checker；無 raw 永遠 `PLANNED/NOT_RUN`。

### PI-B1-B2｜REPO_CONTEXT

- **上位來源**：FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_BLUEPRINT_AND_SKELETON_r2.md@dddc6b5993c88b9a2365aa9435ee492a543add3ebe4c89d79c58c58f9d16dbab#L387-L393 excerpt_sha256=6c9fb64be67e0403e9c1c3770dca91d62f000442b9033f400f3795adb4125f4b; Owner：`PIPD PD Binder Owner`。
- **必要輸入與狀態**：`git status staged,unstaged,untracked, head, root handle`；合法狀態：`RepoRequested→RootRead→HEADAndStatusRead→BindingProposed`。
- **業務作用/可觀察成功**：No DEV effect for observation; no PD when no writable scope；本域判準：P4 PD only with actual repo root, HEAD and affected-only allowed write scope。
- **候選 Owner ABI**：`repo_context_probe`；其專屬 typed fields：`realpath,head,index,untracked,writable_scope,currentness`；明確定位前 `RUNNER_NOT_BOUND`，不可使用通用 OWNER_APPROVED_NATIVE_DOMAIN_ADAPTER 當假指令。
- **NEG/EDGE/SEC**：`stale/escaping context -> REPO_CONTEXT_NOT_FRESH`。NEG 細分碼 `PD_CONTEXT_STALE_OR_PATH_ESCAPE` → canonical `REPO_CONTEXT_NOT_FRESH`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- **權限與回復**：- **Scope & rollback**：effect_class=READ_ONLY_PROBE、effect_key=REPO_CONTEXT；Invalidate PD draft and rescan; no source edit。合法重試不得越過 at-most-once，對 UNKNOWN_EFFECT 先觀測 reconcile。；formal oracle/Owner status=UNBOUND。；真 effect 未執行時停止、隔離 observation，不要求無效的 rollback token。
- **可閉合 Join**：來源 Clause→PI-B1-B2→PD 的 WO/OBS→每個 effect ECP/NO_EFFECT→`TQ-B1-B2-POS/NEG/EDGE/SEC`→相同 subject immutable raw→Independent Checker；無 raw 永遠 `PLANNED/NOT_RUN`。

### PI-B1-B3｜SBL_TO_NATIVE

- **上位來源**：FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_BLUEPRINT_AND_SKELETON_r2.md@dddc6b5993c88b9a2365aa9435ee492a543add3ebe4c89d79c58c58f9d16dbab#L400-L406 excerpt_sha256=63c3bc490b96a2d0ea478857938af921681a7d228560fcc663e5722c5f6e2493; Owner：`SBL Bridge & HGK Owner`。
- **必要輸入與狀態**：`SBL m03/m04, candidate ECP, HGK receiver request`；合法狀態：`AdapterPatchCandidate→ReadOnlyTranslator→NativeHandoff→Ack/Nack`。
- **業務作用/可觀察成功**：DEV file patch != OPS native admission; two WO, two ECP where affected；本域判準：DEV/OPS different WOs, separate source diff and real native ACK。
- **候選 Owner ABI**：`bridge_handoff`；其專屬 typed fields：`sbl_entry,candidate,dev_diff,ops_handoff,native_receiver_ack`；明確定位前 `RUNNER_NOT_BOUND`，不可使用通用 OWNER_APPROVED_NATIVE_DOMAIN_ADAPTER 當假指令。
- **NEG/EDGE/SEC**：`second issuer or shared receipt -> SECOND_ISSUER_OR_MIXED_EFFECT`。NEG 細分碼 `HANDOFF_ABI_OR_MOCK_ACK` → canonical `SECOND_ISSUER_OR_MIXED_EFFECT`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- **權限與回復**：- **Scope & rollback**：effect_class=SPLIT_DEV_OPS、effect_key=SBL_TO_NATIVE；Undo adapter diff or cancel only native WO as appropriate。合法重試不得越過 at-most-once，對 UNKNOWN_EFFECT 先觀測 reconcile。；formal oracle/Owner status=UNBOUND。；真 effect 未執行時停止、隔離 observation，不要求無效的 rollback token。
- **可閉合 Join**：來源 Clause→PI-B1-B3→PD 的 WO/OBS→每個 effect ECP/NO_EFFECT→`TQ-B1-B3-POS/NEG/EDGE/SEC`→相同 subject immutable raw→Independent Checker；無 raw 永遠 `PLANNED/NOT_RUN`。

### PI-B1-B4｜ECP_SELECTOR

- **上位來源**：FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_BLUEPRINT_AND_SKELETON_r2.md@dddc6b5993c88b9a2365aa9435ee492a543add3ebe4c89d79c58c58f9d16dbab#L413-L419 excerpt_sha256=c9ce7d9b56e9debce81bac87d09e24c93eabde5b45107b53608ade2222ed415c; Owner：`HGK ECP Selection Owner`。
- **必要輸入與狀態**：`one WorkOrder one active ECP/effect class, source and target locks`；合法狀態：`EffectInventory→PerWOClass→OneActiveECP→IssuerGate`。
- **業務作用/可觀察成功**：Ambiguous/multiple ECP gets NACK before dispatch；本域判準：one active ECP per WO; split iff distinct effects。
- **候選 Owner ABI**：`ecp_selection`；其專屬 typed fields：`wo_id,effect_class,active_ecp_count,issuer_ack`；明確定位前 `RUNNER_NOT_BOUND`，不可使用通用 OWNER_APPROVED_NATIVE_DOMAIN_ADAPTER 當假指令。
- **NEG/EDGE/SEC**：`two active ECPs/unknown class -> ECP_MULTIPLE_OR_CLASS_UNKNOWN`。NEG 細分碼 `ECP_DOUBLE_ACTIVE_OR_CLASS_MISMATCH` → canonical `ECP_MULTIPLE_OR_CLASS_UNKNOWN`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- **權限與回復**：- **Scope & rollback**：effect_class=SPLIT_DEV_OPS、effect_key=ECP_SELECTOR；No issue; split and recompile affected WO。合法重試不得越過 at-most-once，對 UNKNOWN_EFFECT 先觀測 reconcile。；formal oracle/Owner status=UNBOUND。；真 effect 未執行時停止、隔離 observation，不要求無效的 rollback token。
- **可閉合 Join**：來源 Clause→PI-B1-B4→PD 的 WO/OBS→每個 effect ECP/NO_EFFECT→`TQ-B1-B4-POS/NEG/EDGE/SEC`→相同 subject immutable raw→Independent Checker；無 raw 永遠 `PLANNED/NOT_RUN`。

### PI-B1-B5｜THREE_SP

- **上位來源**：FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_BLUEPRINT_AND_SKELETON_r2.md@dddc6b5993c88b9a2365aa9435ee492a543add3ebe4c89d79c58c58f9d16dbab#L426-L432 excerpt_sha256=952cd82b4dae2a0dfbdff09a927d98d8a887ac29fdadb174c2956fd269147590; Owner：`SP Host Owner`。
- **必要輸入與狀態**：`TPM, Commander, Challenge independent Host principals`；合法狀態：`Package→InstallCandidate→HostLoadedReadback→Invoke/Deny→Uninstall`。
- **業務作用/可觀察成功**：Three separate true host-issued identities; ZIP-only denied；本域判準：three host identities and isolated permission readbacks; ZIP-only not pass。
- **候選 Owner ABI**：`sp_host_load`；其專屬 typed fields：`TPM_SP,COMMANDER_SP,CHALLENGE_SP,host_invocation,loaded_sha`；明確定位前 `RUNNER_NOT_BOUND`，不可使用通用 OWNER_APPROVED_NATIVE_DOMAIN_ADAPTER 當假指令。
- **NEG/EDGE/SEC**：`missing host invocation -> SP_HOST_LOAD_UNPROVEN`。NEG 細分碼 `SP_ROLE_OR_HOST_NOT_ACTUALLY_LOADED` → canonical `SP_HOST_LOAD_UNPROVEN`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- **權限與回復**：- **Scope & rollback**：effect_class=SPLIT_DEV_OPS、effect_key=THREE_SP；Revoke host grants then uninstall/residue readback。合法重試不得越過 at-most-once，對 UNKNOWN_EFFECT 先觀測 reconcile。；formal oracle/Owner status=UNBOUND。；真 effect 未執行時停止、隔離 observation，不要求無效的 rollback token。
- **可閉合 Join**：來源 Clause→PI-B1-B5→PD 的 WO/OBS→每個 effect ECP/NO_EFFECT→`TQ-B1-B5-POS/NEG/EDGE/SEC`→相同 subject immutable raw→Independent Checker；無 raw 永遠 `PLANNED/NOT_RUN`。

### PI-B1-B6｜TODO_PERSISTENCE

- **上位來源**：FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_BLUEPRINT_AND_SKELETON_r2.md@dddc6b5993c88b9a2365aa9435ee492a543add3ebe4c89d79c58c58f9d16dbab#L439-L445 excerpt_sha256=2997cb3163cbc87b6f42ff3f35dda7f4bbda31f8307e64523c45b3d47c29cdd4; Owner：`SBL CLI/User Data Owner`。
- **必要輸入與狀態**：`sbl-todo package install and isolated state dir`；合法狀態：`Installed→ListBefore→AddCommitted→ListAfter→DeleteCommitted→Uninstall`。
- **業務作用/可觀察成功**：User data add/delete not DEV; rollback state + uninstall exact sandbox；本域判準：isolated store add -> separate list -> delete -> zero residue。
- **候選 Owner ABI**：`sbl_todo`；其專屬 typed fields：`data_dir,task_id,add_response,list_response,delete_response,uninstall`；明確定位前 `RUNNER_NOT_BOUND`，不可使用通用 OWNER_APPROVED_NATIVE_DOMAIN_ADAPTER 當假指令。
- **NEG/EDGE/SEC**：`user effect misclassified or no actual state -> CLI_EFFECT_MISCLASSIFIED`。NEG 細分碼 `USER_TASK_EXECUTION_NOT_OBSERVED` → canonical `CLI_EFFECT_MISCLASSIFIED`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- **權限與回復**：- **Scope & rollback**：effect_class=USER_DATA_EFFECT、effect_key=TODO_PERSISTENCE；Restore user data backup; revoke install permission。合法重試不得越過 at-most-once，對 UNKNOWN_EFFECT 先觀測 reconcile。；formal oracle/Owner status=UNBOUND。；真 effect 未執行時停止、隔離 observation，不要求無效的 rollback token。
- **可閉合 Join**：來源 Clause→PI-B1-B6→PD 的 WO/OBS→每個 effect ECP/NO_EFFECT→`TQ-B1-B6-POS/NEG/EDGE/SEC`→相同 subject immutable raw→Independent Checker；無 raw 永遠 `PLANNED/NOT_RUN`。

### PI-B1-B7｜NOFIT_ROUTE

- **上位來源**：FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_BLUEPRINT_AND_SKELETON_r2.md@dddc6b5993c88b9a2365aa9435ee492a543add3ebe4c89d79c58c58f9d16dbab#L452-L458 excerpt_sha256=1970685e4fbf0fc946c6bd719330aa9358c54294b1e271848aa9208f39414e12; Owner：`PIPD TechnologyAdmission Owner`。
- **必要輸入與狀態**：`Tool×Kind×Mode×Host×Provider, pinned license/currentness`；合法狀態：`CapabilityWanted→ProviderHostProbe→SelectOrNoFit→OwnerReview`。
- **業務作用/可觀察成功**：Provider-off never silent swap or third-party issue；本域判準：deterministic capability NOFIT with user-readable reason and zero unauthorized delta。
- **候選 Owner ABI**：`no_fit`；其專屬 typed fields：`required_capability,host,provider_off,owner,refusal,zero_effect`；明確定位前 `RUNNER_NOT_BOUND`，不可使用通用 OWNER_APPROVED_NATIVE_DOMAIN_ADAPTER 當假指令。
- **NEG/EDGE/SEC**：`silent fallback -> NOFIT_OR_PROVIDER_OFF`。NEG 細分碼 `GUARDRAIL_BYPASS_OR_NOFIT_INCOMPLETE` → canonical `NOFIT_OR_PROVIDER_OFF`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- **權限與回復**：- **Scope & rollback**：effect_class=READ_ONLY_PROBE、effect_key=NOFIT_ROUTE；Emit NoFitReceipt and stop affected effect。合法重試不得越過 at-most-once，對 UNKNOWN_EFFECT 先觀測 reconcile。；formal oracle/Owner status=UNBOUND。；真 effect 未執行時停止、隔離 observation，不要求無效的 rollback token。
- **可閉合 Join**：來源 Clause→PI-B1-B7→PD 的 WO/OBS→每個 effect ECP/NO_EFFECT→`TQ-B1-B7-POS/NEG/EDGE/SEC`→相同 subject immutable raw→Independent Checker；無 raw 永遠 `PLANNED/NOT_RUN`。

### PI-B1-B8｜TRACE_GRAPH

- **上位來源**：FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_BLUEPRINT_AND_SKELETON_r2.md@dddc6b5993c88b9a2365aa9435ee492a543add3ebe4c89d79c58c58f9d16dbab#L465-L471 excerpt_sha256=0d98c897b2c33d2601e515e1caa76fd699aed6e7e1063885fcda9a18e4f668f6; Owner：`PIPD Trace Owner`。
- **必要輸入與狀態**：`PI→PD→CC→ECP→WO→TQAEP→Raw→Checker→Gate`；合法狀態：`EdgesCollected→HashesValidated→OrphansChecked→ClosureOrFail`。
- **業務作用/可觀察成功**：Any orphan/alias/hash-mismatch yields TRACE_CLOSURE_FAIL；本域判準：nonempty exact IDs and hashes, zero orphans and zero bad edges。
- **候選 Owner ABI**：`trace_closure`；其專屬 typed fields：`pi,pd,cc,ecp,wo,tqaep,raw,checker,edges`；明確定位前 `RUNNER_NOT_BOUND`，不可使用通用 OWNER_APPROVED_NATIVE_DOMAIN_ADAPTER 當假指令。
- **NEG/EDGE/SEC**：`foreign/sibling witness -> TRACE_CLOSURE_FAIL`。NEG 細分碼 `SUBJECT_HASH_BREAK_OR_ORPHAN` → canonical `TRACE_CLOSURE_FAIL`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- **權限與回復**：- **Scope & rollback**：effect_class=READ_ONLY_PROBE、effect_key=TRACE_GRAPH；Quarantine affected chain; no claim escalation。合法重試不得越過 at-most-once，對 UNKNOWN_EFFECT 先觀測 reconcile。；formal oracle/Owner status=UNBOUND。；真 effect 未執行時停止、隔離 observation，不要求無效的 rollback token。
- **可閉合 Join**：來源 Clause→PI-B1-B8→PD 的 WO/OBS→每個 effect ECP/NO_EFFECT→`TQ-B1-B8-POS/NEG/EDGE/SEC`→相同 subject immutable raw→Independent Checker；無 raw 永遠 `PLANNED/NOT_RUN`。

### PI-B1-B9｜R15_COVERAGE

- **上位來源**：FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_BLUEPRINT_AND_SKELETON_r2.md@dddc6b5993c88b9a2365aa9435ee492a543add3ebe4c89d79c58c58f9d16dbab#L478-L484 excerpt_sha256=e913b0d4725c5b01dcd67d27a04e5718545e21775c050e769e574c37a0e175f0; Owner：`SBL Product Owner`。
- **必要輸入與狀態**：`18-family individual source meaning & owner & disposition`；合法狀態：`R15Indexed→949Distinct→DispositionBound→ReviewPending`。
- **業務作用/可觀察成功**：No silent ID drops; deferred != verified; no orphan family；本域判準：949 unique 18-family IDs, 66/254/629 and source-specific disposition。
- **候選 Owner ABI**：`baseline_denominator`；其專屬 typed fields：`949_ids,18_families,required,conditional,deferred,owners`；明確定位前 `RUNNER_NOT_BOUND`，不可使用通用 OWNER_APPROVED_NATIVE_DOMAIN_ADAPTER 當假指令。
- **NEG/EDGE/SEC**：`missing ID or generic proxy pass -> R15_DENOMINATOR_SHRINK`。NEG 細分碼 `FULL_PRODUCT_PROXY_PASS` → canonical `R15_DENOMINATOR_SHRINK`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- **權限與回復**：- **Scope & rollback**：effect_class=READ_ONLY_PROBE、effect_key=R15_COVERAGE；Recover original source row and review disposition。合法重試不得越過 at-most-once，對 UNKNOWN_EFFECT 先觀測 reconcile。；formal oracle/Owner status=UNBOUND。；真 effect 未執行時停止、隔離 observation，不要求無效的 rollback token。
- **可閉合 Join**：來源 Clause→PI-B1-B9→PD 的 WO/OBS→每個 effect ECP/NO_EFFECT→`TQ-B1-B9-POS/NEG/EDGE/SEC`→相同 subject immutable raw→Independent Checker；無 raw 永遠 `PLANNED/NOT_RUN`。

### PI-B1-C1｜FABRIC_PROMOTION

- **上位來源**：FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_BLUEPRINT_AND_SKELETON_r2.md@dddc6b5993c88b9a2365aa9435ee492a543add3ebe4c89d79c58c58f9d16dbab#L491-L497 excerpt_sha256=cc185ce3c026aac6a530981840cef2159dfe3f916b938263f8a1a614ae066b46; Owner：`Fabric Activation Owner`。
- **必要輸入與狀態**：`policy sha, stage/active/loaded epoch, native loader witness`；合法狀態：`SourceCandidate→StageSeal→OwnerApprove→Active→HostLoadedReadback`。
- **業務作用/可觀察成功**：Stage/CI only never equals loaded; per-effect token；本域判準：independent stage approval; active and loaded exact digest; consumer projection ACK。
- **候選 Owner ABI**：`fabric_activator`；其專屬 typed fields：`approved_stage,active_policy,loaded_sha,consumer_trace,rollback`；明確定位前 `RUNNER_NOT_BOUND`，不可使用通用 OWNER_APPROVED_NATIVE_DOMAIN_ADAPTER 當假指令。
- **NEG/EDGE/SEC**：`stage mistaken as active or missing consumer -> FABRIC_LOADED_ABSENT`。NEG 細分碼 `FABRIC_REVERSE_PROJECTION_OR_POLICY_EPOCH` → canonical `FABRIC_LOADED_ABSENT`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- **權限與回復**：- **Scope & rollback**：effect_class=OPS_NATIVE_HANDOFF、effect_key=FABRIC_PROMOTION；Revert only candidate promotion; do not overwrite active without permit。合法重試不得越過 at-most-once，對 UNKNOWN_EFFECT 先觀測 reconcile。；formal oracle/Owner status=UNBOUND。；真 effect 未執行時停止、隔離 observation，不要求無效的 rollback token。
- **可閉合 Join**：來源 Clause→PI-B1-C1→PD 的 WO/OBS→每個 effect ECP/NO_EFFECT→`TQ-B1-C1-POS/NEG/EDGE/SEC`→相同 subject immutable raw→Independent Checker；無 raw 永遠 `PLANNED/NOT_RUN`。

### PI-B1-C2｜HGK_GWO

- **上位來源**：FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_BLUEPRINT_AND_SKELETON_r2.md@dddc6b5993c88b9a2365aa9435ee492a543add3ebe4c89d79c58c58f9d16dbab#L504-L510 excerpt_sha256=e11481b248bb5c8b2eeffc818f6abc15cc243aaaafa58eac7d0de0982d156466; Owner：`HGK Runtime Owner`。
- **必要輸入與狀態**：`HGK actual issuer+Hermes lease+journal`；合法狀態：`PermissionSigned→LeaseClaim→NativeWorker→RawReceipt`。
- **業務作用/可觀察成功**：Canary native same WO signature; fake mock ignored；本域判準：true SBL entry -> native HGK issuer -> Hermes lease -> reversible observable result。
- **候選 Owner ABI**：`hgk_native_golden`；其專屬 typed fields：`sbl_start,issued_wo,issuer,lease,worker_receipt,readback`；明確定位前 `RUNNER_NOT_BOUND`，不可使用通用 OWNER_APPROVED_NATIVE_DOMAIN_ADAPTER 當假指令。
- **NEG/EDGE/SEC**：`ghost worker/forged permit -> GWO_HGK_NOT_NATIVE`。NEG 細分碼 `HGK_FORGED_PERMIT_OR_GHOST_WORKER` → canonical `GWO_HGK_NOT_NATIVE`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- **權限與回復**：- **Scope & rollback**：effect_class=OPS_RUNTIME_ACTIVATE、effect_key=HGK_GWO；Reconcile in-flight effect, then release affected lock。合法重試不得越過 at-most-once，對 UNKNOWN_EFFECT 先觀測 reconcile。；formal oracle/Owner status=UNBOUND。；真 effect 未執行時停止、隔離 observation，不要求無效的 rollback token。
- **可閉合 Join**：來源 Clause→PI-B1-C2→PD 的 WO/OBS→每個 effect ECP/NO_EFFECT→`TQ-B1-C2-POS/NEG/EDGE/SEC`→相同 subject immutable raw→Independent Checker；無 raw 永遠 `PLANNED/NOT_RUN`。

### PI-B1-C3｜SBL_GWO

- **上位來源**：FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_BLUEPRINT_AND_SKELETON_r2.md@dddc6b5993c88b9a2365aa9435ee492a543add3ebe4c89d79c58c58f9d16dbab#L517-L523 excerpt_sha256=1975f524a2a0a74c966b68ff49f559adef2677fa3edf5d63006ec17c6e8c6af3; Owner：`SBL Product/User Owner`。
- **必要輸入與狀態**：`wheel, install identity, isolated todo db, delete tombstone`；合法狀態：`Build→Install→ListBefore→Add→ListAfter→Delete→Uninstall`。
- **業務作用/可觀察成功**：CLI add/delete and install/uninstall are effects; exact data restored；本域判準：separate Host install and USER effects with independent readbacks。
- **候選 Owner ABI**：`sbl_user_golden`；其專屬 typed fields：`sbl_entry,stack_install,consent,todo_add,list,delete,uninstall`；明確定位前 `RUNNER_NOT_BOUND`，不可使用通用 OWNER_APPROVED_NATIVE_DOMAIN_ADAPTER 當假指令。
- **NEG/EDGE/SEC**：`install count used as add success -> GWO_SBL_USER_STATE_UNPROVEN`。NEG 細分碼 `SBL_EMPTY_TEST_OR_NO_USER_OUTCOME` → canonical `GWO_SBL_USER_STATE_UNPROVEN`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- **權限與回復**：- **Scope & rollback**：effect_class=SPLIT_INSTALL_USERDATA、effect_key=SBL_GWO；Delete only owned sandbox and restore preimage。合法重試不得越過 at-most-once，對 UNKNOWN_EFFECT 先觀測 reconcile。；formal oracle/Owner status=UNBOUND。；真 effect 未執行時停止、隔離 observation，不要求無效的 rollback token。
- **可閉合 Join**：來源 Clause→PI-B1-C3→PD 的 WO/OBS→每個 effect ECP/NO_EFFECT→`TQ-B1-C3-POS/NEG/EDGE/SEC`→相同 subject immutable raw→Independent Checker；無 raw 永遠 `PLANNED/NOT_RUN`。

### PI-B1-C4｜EXTERNAL_GRANT

- **上位來源**：FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_BLUEPRINT_AND_SKELETON_r2.md@dddc6b5993c88b9a2365aa9435ee492a543add3ebe4c89d79c58c58f9d16dbab#L530-L536 excerpt_sha256=bca5b8b0bbc5e73220f14ddb7c3d3dfca5b5d4c7eb508a04ade1cba49cd77caf; Owner：`External Delegation Owner`。
- **必要輸入與狀態**：`external principal, repo/scope/TTL/epoch bound`；合法狀態：`RequestScope→GrantTimed→TaskScoped→RevokeNew`。
- **業務作用/可觀察成功**：No broader GitHub/Windows authority via standing mission；本域判準：bounded external grant and no residual capability on revoke。
- **候選 Owner ABI**：`delegation`；其專屬 typed fields：`owner_scope,ttl,principal,revocation,zero_scope_escape`；明確定位前 `RUNNER_NOT_BOUND`，不可使用通用 OWNER_APPROVED_NATIVE_DOMAIN_ADAPTER 當假指令。
- **NEG/EDGE/SEC**：`scope expansion -> EXTERNAL_SCOPE_ESCAPED`。NEG 細分碼 `EXTERNAL_GRANT_SCOPE_OR_TTL` → canonical `EXTERNAL_SCOPE_ESCAPED`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- **權限與回復**：- **Scope & rollback**：effect_class=OPS_NATIVE_HANDOFF、effect_key=EXTERNAL_GRANT；Stop new delegated work; revoke key; no blanket cancel。合法重試不得越過 at-most-once，對 UNKNOWN_EFFECT 先觀測 reconcile。；formal oracle/Owner status=UNBOUND。；真 effect 未執行時停止、隔離 observation，不要求無效的 rollback token。
- **可閉合 Join**：來源 Clause→PI-B1-C4→PD 的 WO/OBS→每個 effect ECP/NO_EFFECT→`TQ-B1-C4-POS/NEG/EDGE/SEC`→相同 subject immutable raw→Independent Checker；無 raw 永遠 `PLANNED/NOT_RUN`。

### PI-B1-C5｜CODEX_MINPATCH

- **上位來源**：FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_BLUEPRINT_AND_SKELETON_r2.md@dddc6b5993c88b9a2365aa9435ee492a543add3ebe4c89d79c58c58f9d16dbab#L543-L549 excerpt_sha256=35386b7a209b25024893873cefa1d47e493d5ba83da77c0add6bd9c684caf0fd; Owner：`Codex Maker + Dev Owner`。
- **必要輸入與狀態**：`actual current hotpath and preimage, working tree tree-id`；合法狀態：`RedNativeFixture→Preimage→ScopedPatch→Green→IndependentReview`。
- **業務作用/可觀察成功**：No edit outside allowlist; narrow rollback；本域判準：only affected files changed and full regression independent。
- **候選 Owner ABI**：`bounded_coding`；其專屬 typed fields：`write_scope,preimage,red_test,patch,green_test,checker`；明確定位前 `RUNNER_NOT_BOUND`，不可使用通用 OWNER_APPROVED_NATIVE_DOMAIN_ADAPTER 當假指令。
- **NEG/EDGE/SEC**：`checker edits same diff or no red test -> UNBOUNDED_PATCH_OR_REGRESSION`。NEG 細分碼 `CODEX_UNMEASURED_PATCH_OR_CHECKER_MUTATION` → canonical `UNBOUNDED_PATCH_OR_REGRESSION`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- **權限與回復**：- **Scope & rollback**：effect_class=DEV_SOURCE_PATCH、effect_key=CODEX_MINPATCH；Restore patch preimage and retain red fixture。合法重試不得越過 at-most-once，對 UNKNOWN_EFFECT 先觀測 reconcile。；formal oracle/Owner status=UNBOUND。；真 effect 未執行時停止、隔離 observation，不要求無效的 rollback token。
- **可閉合 Join**：來源 Clause→PI-B1-C5→PD 的 WO/OBS→每個 effect ECP/NO_EFFECT→`TQ-B1-C5-POS/NEG/EDGE/SEC`→相同 subject immutable raw→Independent Checker；無 raw 永遠 `PLANNED/NOT_RUN`。

### PI-B1-C6｜REVOKE_RACE

- **上位來源**：FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_BLUEPRINT_AND_SKELETON_r2.md@dddc6b5993c88b9a2365aa9435ee492a543add3ebe4c89d79c58c58f9d16dbab#L556-L562 excerpt_sha256=2f5d7d883429aeb5c263b9c06057c3b1037264453f9b5fc3a13a3111b1617e1b; Owner：`Revoke/Effect Owner`。
- **必要輸入與狀態**：`token consumed map, outstanding effect IDs, event cursor`；合法狀態：`StopNew→RevokeNew→InFlightUnknownReconcile→PostDeny`。
- **業務作用/可觀察成功**：Unknown effect not erased, previously admitted in-flight reconciled；本域判準：post-revoke use fails before spawn; existing effects reconciled。
- **候選 Owner ABI**：`revoke_boundary`；其專屬 typed fields：`old_nonce,revocation_epoch,attempt_after_revoke,denied_effect`；明確定位前 `RUNNER_NOT_BOUND`，不可使用通用 OWNER_APPROVED_NATIVE_DOMAIN_ADAPTER 當假指令。
- **NEG/EDGE/SEC**：`reused token after revoke -> REVOKED_TOKEN_REPLAY`。NEG 細分碼 `POST_REVOKE_TOKEN_REPLAY` → canonical `REVOKED_TOKEN_REPLAY`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- **權限與回復**：- **Scope & rollback**：effect_class=OPS_NATIVE_HANDOFF、effect_key=REVOKE_RACE；Leave affected lock held until reconciled。合法重試不得越過 at-most-once，對 UNKNOWN_EFFECT 先觀測 reconcile。；formal oracle/Owner status=UNBOUND。；真 effect 未執行時停止、隔離 observation，不要求無效的 rollback token。
- **可閉合 Join**：來源 Clause→PI-B1-C6→PD 的 WO/OBS→每個 effect ECP/NO_EFFECT→`TQ-B1-C6-POS/NEG/EDGE/SEC`→相同 subject immutable raw→Independent Checker；無 raw 永遠 `PLANNED/NOT_RUN`。

### PI-B1-C7｜FOUR_LAYER_ID

- **上位來源**：FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_BLUEPRINT_AND_SKELETON_r2.md@dddc6b5993c88b9a2365aa9435ee492a543add3ebe4c89d79c58c58f9d16dbab#L569-L575 excerpt_sha256=d8dd698fe26bd66a63c8939c49c25a298e09026daa0059853ab62ffd65ddf9a7; Owner：`Native Loader Owner`。
- **必要輸入與狀態**：`source, build, installed, loaded four separately witnessed hashes`；合法狀態：`SourceSHA→BuildSHA→InstallSHA→LoadedSHA`。
- **業務作用/可觀察成功**：No source hash used as proof of loaded binary；本域判準：all four identity layers tied to same subject, not merely file on disk。
- **候選 Owner ABI**：`loaded_identity`；其專屬 typed fields：`source_sha,installed_binary_sha,host_loaded_sha,served_model,policy_epoch`；明確定位前 `RUNNER_NOT_BOUND`，不可使用通用 OWNER_APPROVED_NATIVE_DOMAIN_ADAPTER 當假指令。
- **NEG/EDGE/SEC**：`green patch with stale loaded binary -> LOADED_BINARY_MISMATCH`。NEG 細分碼 `PATCH_GREEN_NOT_LOADED` → canonical `LOADED_BINARY_MISMATCH`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- **權限與回復**：- **Scope & rollback**：effect_class=READ_ONLY_PROBE、effect_key=FOUR_LAYER_ID；HOLD activation; do not advertise runtime ready。合法重試不得越過 at-most-once，對 UNKNOWN_EFFECT 先觀測 reconcile。；formal oracle/Owner status=UNBOUND。；真 effect 未執行時停止、隔離 observation，不要求無效的 rollback token。
- **可閉合 Join**：來源 Clause→PI-B1-C7→PD 的 WO/OBS→每個 effect ECP/NO_EFFECT→`TQ-B1-C7-POS/NEG/EDGE/SEC`→相同 subject immutable raw→Independent Checker；無 raw 永遠 `PLANNED/NOT_RUN`。

### PI-B1-C8｜NATIVE_SUCCESSOR

- **上位來源**：FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_BLUEPRINT_AND_SKELETON_r2.md@dddc6b5993c88b9a2365aa9435ee492a543add3ebe4c89d79c58c58f9d16dbab#L582-L588 excerpt_sha256=00d8e06843af4cc584634ba47c33d9995efe665fca78b8b1ec45501317f49b9d; Owner：`Hermes Continuation Owner`。
- **必要輸入與狀態**：`native scheduler event without external session, same subject hash`；合法狀態：`ExternalRevoked→NativeTrigger→NativeRun→DurableCheckpoint`。
- **業務作用/可觀察成功**：Post-turn continuation must originate in Hermes native source；本域判準：fresh separate session native trigger progresses after external account revoked。
- **候選 Owner ABI**：`post_revoke_successor`；其專屬 typed fields：`external_stop,ledger_cursor,issuer,successor_wo,native_origin`；明確定位前 `RUNNER_NOT_BOUND`，不可使用通用 OWNER_APPROVED_NATIVE_DOMAIN_ADAPTER 當假指令。
- **NEG/EDGE/SEC**：`successor still external-triggered -> NATIVE_SUCCESSOR_NOT_PROVEN`。NEG 細分碼 `NATIVE_SUCCESSOR_NOT_AUTONOMOUS` → canonical `NATIVE_SUCCESSOR_NOT_PROVEN`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- **權限與回復**：- **Scope & rollback**：effect_class=OPS_RUNTIME_ACTIVATE、effect_key=NATIVE_SUCCESSOR；Do not reenable external principal as hidden fallback。合法重試不得越過 at-most-once，對 UNKNOWN_EFFECT 先觀測 reconcile。；formal oracle/Owner status=UNBOUND。；真 effect 未執行時停止、隔離 observation，不要求無效的 rollback token。
- **可閉合 Join**：來源 Clause→PI-B1-C8→PD 的 WO/OBS→每個 effect ECP/NO_EFFECT→`TQ-B1-C8-POS/NEG/EDGE/SEC`→相同 subject immutable raw→Independent Checker；無 raw 永遠 `PLANNED/NOT_RUN`。

### PI-B1-C9｜TRIPLE_GWO

- **上位來源**：FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_BLUEPRINT_AND_SKELETON_r2.md@dddc6b5993c88b9a2365aa9435ee492a543add3ebe4c89d79c58c58f9d16dbab#L595-L601 excerpt_sha256=06ab64321c1cf87e60d87e74a209c0a17b28244ee0da01dab18ed8c3d6e1d4a7; Owner：`Independent AO + 3 Domain Owners`。
- **必要輸入與狀態**：`Fabric,HGK,SBL distinct effect and owner receipts`；合法狀態：`ThreeDistinctSubjects→ThreeRawSets→IndependentVerdict→GBGate`。
- **業務作用/可觀察成功**：Swapped receipts, same principal, absent third yields FAIL；本域判準：3 different domain receipts, all same intended crosswalk, not aliases。
- **候選 Owner ABI**：`triple_golden_join`；其專屬 typed fields：`fabric_receipt,hgk_receipt,sbl_receipt,revoke_receipt,join_subject`；明確定位前 `RUNNER_NOT_BOUND`，不可使用通用 OWNER_APPROVED_NATIVE_DOMAIN_ADAPTER 當假指令。
- **NEG/EDGE/SEC**：`same receipt reused -> GWO_RECEIPT_ALIAS`。NEG 細分碼 `THREE_GWO_PROXY_PASS` → canonical `GWO_RECEIPT_ALIAS`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- **權限與回復**：- **Scope & rollback**：effect_class=READ_ONLY_PROBE、effect_key=TRIPLE_GWO；Gate HOLD; rerun only missing subject independently。合法重試不得越過 at-most-once，對 UNKNOWN_EFFECT 先觀測 reconcile。；formal oracle/Owner status=UNBOUND。；真 effect 未執行時停止、隔離 observation，不要求無效的 rollback token。
- **可閉合 Join**：來源 Clause→PI-B1-C9→PD 的 WO/OBS→每個 effect ECP/NO_EFFECT→`TQ-B1-C9-POS/NEG/EDGE/SEC`→相同 subject immutable raw→Independent Checker；無 raw 永遠 `PLANNED/NOT_RUN`。

