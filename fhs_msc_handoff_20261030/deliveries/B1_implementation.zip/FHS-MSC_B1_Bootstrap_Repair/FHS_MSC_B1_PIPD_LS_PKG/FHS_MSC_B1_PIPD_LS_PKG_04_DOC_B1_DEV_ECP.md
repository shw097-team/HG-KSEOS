---
artifact_family: FHS-MSC-B1-Bootstrap-Repair-PIPD-LS-PKG
version: 2026-10-26_r3_HIGH_RETENTION_SUBSTANTIVE_AUDIT_REPAIR
supersedes_version: 2026-10-26-r2-HIGH-RETENTION-SOURCE-BOUND
supersedes_subject_sha256: 273591a3f0cc7f43c87d6ac5e9e5704cf7ede15440a8a159b1de71d4c7d52da5
change_type: HIGH_RETENTION_INTEGRATE_COVER_REPLACE_NO_ARCHITECTURE_RESET
task_kind: DESIGN
claim_ceiling: AUTHOR_SIDE_REPAIR_CANDIDATE
formal_sourcefreeze: HOLD
independent_checker_receipt: NOT_RUN
native_effect: NOT_RUN
release: NOT_RUN
---

# DOC-B1-DEV-ECP｜R1–R4 限縮可施工診斷與 source patch workflow

下列列出的 Repository paths 是基於既有文件與先前遠端索引的**候選起點**，不是當前 Windows Loaded Hotpath 的已證據事實。Codex 必先由 Host 現場 probe 驗證真路徑/模組 import chain，否則 `HOTPATH_UNRESOLVED` 而不施工。

## 施工安全序列：作者端有指令、Host 不執行

```powershell
# Per authorised repo; run only after Owner supplies real root; READ ONLY
$root = '<OWNER_RESOLVED_REPO_ROOT>'
git -C $root rev-parse --show-toplevel
git -C $root rev-parse HEAD
git -C $root status --porcelain=v1 -z -uall
git -C $root ls-files -z
# Do not reset/clean/checkout/patch before owner authorises write scope.
```

**Deterministic currentness**：`git status --porcelain=v1 -z -uall` 的 index staged / modified / untracked 全域均掃描；只允許受影 WriteSet，reparse/junction/realpath ACL 逐祖先測，必比對 Loaded Module SHA, process executable, imported module origin；有兩個同名 symbol 時須追 imported origin，不能第一個 grep hit 當施工點。

## 四個獨立 Repair Cone 施工合約

### R1｜HGK Grant→WorkOrder hotpath

- **Candidate paths, NOT runtime bound**：`HG-KSEOS/src/hg_kseos/cli.py`、`HG-KSEOS/AGENTS.md`。先以 RepoContext 的 tracked tree 與 process actual imported path 交集決定真熱點，若查無交集 `HOLD_HOTPATH_NOT_LOADED`。
- **Symbol discovery**：`git -C <ROOT> grep -n -I -E "issuer|grant|permission|nonce|effect_class|admit" -- <AFFECTED_RELATIVE_PATHS>`；再由 `python -c "import importlib.util; print(importlib.util.find_spec('<ACTUAL_MODULE>'))"` 檢測實際 import（只在 Owner 指定環境）；Windows process loader 必另做 loaded file SHA，比靜態 repo 強。
- **赤測/最小差異**：Inject unsigned grant and wrong subject; expect 0 spawn; valid grant routes issuer exactly once。先記真 red exit code/stdout/stderr/hash，再在唯一 Codex worktree 及 Owner-limited files 中最小修補，不碰其它 staged/untracked；red→green→all affected regression+replay negative。
- **Acceptance postcondition**：UNCLASSIFIED cannot spawn; valid B/C independently progress；不同主體/模式不可借綠。
- **Effect classification**：ISSUER_SUBJECT / RECEIVER_ABI。源檔變更 = DEV ECP；安裝重載/激活 = 另一 OPS ECP；UserData 另隔離，兩張 WorkOrder 要不同 operation_id 和 readback。
- **Rollback**：真 `preimage_sha/changed_paths` 先記，僅在 Owner 指定隔離樹 revert these known deltas；不得 `git reset --hard`／`git clean -fd` 對共享本機工作樹。Checker 對前後同 SHA 做獨立 regression。

### R2｜Hermes Fair Queue/Lease

- **Candidate paths, NOT runtime bound**：`HG-KSEOS/scripts/hermes-core.ps1`、`HG-KSEOS/config/hermes-codex-lane.json`。先以 RepoContext 的 tracked tree 與 process actual imported path 交集決定真熱點，若查無交集 `HOLD_HOTPATH_NOT_LOADED`。
- **Symbol discovery**：`git -C <ROOT> grep -n -I -E "queue|lease|heartbeat|claim|cursor|park|post.turn" -- <AFFECTED_RELATIVE_PATHS>`；再由 `python -c "import importlib.util; print(importlib.util.find_spec('<ACTUAL_MODULE>'))"` 檢測實際 import（只在 Owner 指定環境）；Windows process loader 必另做 loaded file SHA，比靜態 repo 強。
- **赤測/最小差異**：Block A, seed B/C, restart; verify persisted cursor; stale generation cannot commit。先記真 red exit code/stdout/stderr/hash，再在唯一 Codex worktree 及 Owner-limited files 中最小修補，不碰其它 staged/untracked；red→green→all affected regression+replay negative。
- **Acceptance postcondition**：A blocked, B/C progress, two claimants CAS single lease; persisted continuation across new process；不同主體/模式不可借綠。
- **Effect classification**：QUEUE_WO / EFFECT_JOURNAL / NATIVE_CONTINUATION。源檔變更 = DEV ECP；安裝重載/激活 = 另一 OPS ECP；UserData 另隔離，兩張 WorkOrder 要不同 operation_id 和 readback。
- **Rollback**：真 `preimage_sha/changed_paths` 先記，僅在 Owner 指定隔離樹 revert these known deltas；不得 `git reset --hard`／`git clean -fd` 對共享本機工作樹。Checker 對前後同 SHA 做獨立 regression。

### R3｜Fabric Stage→Active→Loaded

- **Candidate paths, NOT runtime bound**：`FABRIC/fabric/consumers/hgk_policy_consumer.py`、`FABRIC/control/ACCEPTANCE_POLICY.yaml`。先以 RepoContext 的 tracked tree 與 process actual imported path 交集決定真熱點，若查無交集 `HOLD_HOTPATH_NOT_LOADED`。
- **Symbol discovery**：`git -C <ROOT> grep -n -I -E "stage|active|loaded|policy_epoch|activate|consume|approval" -- <AFFECTED_RELATIVE_PATHS>`；再由 `python -c "import importlib.util; print(importlib.util.find_spec('<ACTUAL_MODULE>'))"` 檢測實際 import（只在 Owner 指定環境）；Windows process loader 必另做 loaded file SHA，比靜態 repo 強。
- **赤測/最小差異**：Supply stage digest without activator readback; expect HOLD and no fake policy consumption。先記真 red exit code/stdout/stderr/hash，再在唯一 Codex worktree 及 Owner-limited files 中最小修補，不碰其它 staged/untracked；red→green→all affected regression+replay negative。
- **Acceptance postcondition**：Stage only does not qualify; current Loaded SHA==Active SHA and true consumer ACK；不同主體/模式不可借綠。
- **Effect classification**：FABRIC_PROMOTION / FOUR_LAYER_ID。源檔變更 = DEV ECP；安裝重載/激活 = 另一 OPS ECP；UserData 另隔離，兩張 WorkOrder 要不同 operation_id 和 readback。
- **Rollback**：真 `preimage_sha/changed_paths` 先記，僅在 Owner 指定隔離樹 revert these known deltas；不得 `git reset --hard`／`git clean -fd` 對共享本機工作樹。Checker 對前後同 SHA 做獨立 regression。

### R4｜Hermes PLAN/EXECUTE/VERIFY Security and checker

- **Candidate paths, NOT runtime bound**：`HG-KSEOS/config/hermes-codex-lane.json`、`HG-KSEOS/src/hg_kseos/cli.py`。先以 RepoContext 的 tracked tree 與 process actual imported path 交集決定真熱點，若查無交集 `HOLD_HOTPATH_NOT_LOADED`。
- **Symbol discovery**：`git -C <ROOT> grep -n -I -E "require.arm|served|verify|swarm|gstack|openspec|codex|checker" -- <AFFECTED_RELATIVE_PATHS>`；再由 `python -c "import importlib.util; print(importlib.util.find_spec('<ACTUAL_MODULE>'))"` 檢測實際 import（只在 Owner 指定環境）；Windows process loader 必另做 loaded file SHA，比靜態 repo 強。
- **赤測/最小差異**：Force wrong served arm, fake checker receipt and session alias; expect firstfail and no gate PASS。先記真 red exit code/stdout/stderr/hash，再在唯一 Codex worktree 及 Owner-limited files 中最小修補，不碰其它 staged/untracked；red→green→all affected regression+replay negative。
- **Acceptance postcondition**：every declared arm served in same epoch, no silent DeepSeek/GLM or maker self-accept；不同主體/模式不可借綠。
- **Effect classification**：MODEL_LANES / RAW_EVIDENCE / CODEX_MINPATCH。源檔變更 = DEV ECP；安裝重載/激活 = 另一 OPS ECP；UserData 另隔離，兩張 WorkOrder 要不同 operation_id 和 readback。
- **Rollback**：真 `preimage_sha/changed_paths` 先記，僅在 Owner 指定隔離樹 revert these known deltas；不得 `git reset --hard`／`git clean -fd` 對共享本機工作樹。Checker 對前後同 SHA 做獨立 regression。

## R17 與 R00 防回歸橋接

R17 S2-14（Issuer/unknown-effect→R1）、S2-15（bounded queue→R2）、S2-16（stage/active/read→R3）、S2-17（required/served lanes and continuation→R4）均要以受影原行的 `symptom + firstfail + raw path + current imported module` 形成各自 RED/NEG 記錄。上游五冊 R17 全文源定位在 Evidence，不可把歷史回報當目前 Reloaded 的正例。
R00 H01–H04/D01 的 handoff 條文各有單獨 Gate：Host root、Native Issuer、loaded identity、owner permission、readback；所有缺件 `HOLD`，本輪不延伸其他 stage。

## DEV ECP strict bound payload（需 Native PIPD PD，不能自簽）

```json
{
  "expected_changes": [
    "ONLY_OWNER_APPROVED_PATHS"
  ],
  "kind": "DEV_ECP_CANDIDATE",
  "native_pipd_compile": "AFTER_PD_PKG_AND_OWNER_PERMISSION",
  "permission": {
    "token_required": true
  },
  "repo_context": "FROM_CURRENT_REPO_PROBE",
  "rollback": "PREIMAGE_AND_AFFECTED_FILES_ONLY",
  "status": "HOLD_NOT_BOUND",
  "subject_sha": "FROM_PI_AND_PD_AFTER_NATIVE_COMPILE",
  "tests": [
    "domain_red",
    "domain_green",
    "domain_negative",
    "affected_regression"
  ],
  "workorder": "WO-B1-A8",
  "writable_scope": "FROM_OWNER_PD_BINDING"
}
```
