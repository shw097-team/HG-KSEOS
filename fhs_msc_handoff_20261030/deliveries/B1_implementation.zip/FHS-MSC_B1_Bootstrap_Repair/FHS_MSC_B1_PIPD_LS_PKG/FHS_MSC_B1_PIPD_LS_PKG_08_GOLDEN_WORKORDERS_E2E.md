---
artifact_family: FHS-MSC-B1-Bootstrap-Repair-PIPD-LS-PKG
version: 2026-10-26_r3_HIGH_RETENTION_SUBSTANTIVE_AUDIT_REPAIR
supersedes_version: 2026-10-26-r2-HIGH-RETENTION-SOURCE-BOUND
supersedes_subject_sha256: 273591a3f0cc7f43c87d6ac5e9e5704cf7ede15440a8a159b1de71d4c7d52da5
change_type: HIGH_RETENTION_INTEGRATE_COVER_REPLACE_NO_ARCHITECTURE_RESET
task_kind: DESIGN
claim_ceiling: AUTHOR_SIDE_REPAIR_CANDIDATE
formal_sourcefreeze: HOLD
independent_checker_receipt: NOT_RUN
native_effect: NOT_RUN
release: NOT_RUN
---

# GWO-FABRIC／GWO-HGK／GWO-SBL 三個獨立 Golden WorkOrders — r3 端到端設計正文

唯一合法入口是現有 SBL Command/Proposal `plan.propose`，而非 SBL 自發 Native Permit。每張 GWO 都須有獨立 `operation_id, subject_sha, policy_epoch, ECP_ref, pre/poststate, raw_receipt, independent_checker`，不同 Domain 不得互借。

## 1. GWO-FABRIC：來源 → Stage → Activate → Consumer effective readback

1. 使用者透過 SBL 提出 Fabric 政策投影變更，TPM 產生 SourceBound Goal／Spec，PIPD native Intent/PI/PD 產出候選；無正式 SourceFreeze 不進 Native 效果。
2. Fabric Policy Owner 讀取真 Source revision、Stage 候選／批准記錄、現役 Active Policy/Epoch、HGK policy consumer 已載入 digest，全部 subject 釘同一版，不用 GitHub `main` 冒充 Host Loaded。
3. 若需 Source 變更，獨立 `WO-FAB-DEV` 在 Codex bounded WorkSet 做 red→minimal patch→green；`RAW-FAB-DEV` **不能**作 Activator 證據。
4. 經正式批准後由唯一 Fabric Activator 執行 `OP-FAB-ACTIVATE`：合法 stage→active；HGK Consumer 由現役 APL 讀取/投影，不允許投影倒寫 canonical；此效果是不同 OPS ECP。
5. 分別讀回 `RAW-FAB-STAGE`（Source+Stage 授權）、`RAW-FAB-LOADED`（active/loaded SHA、Policy epoch）、`RAW-FAB-CONSUMER`（真正消費者 Reader 的受管投影與 ACK）。三者有不同 resource kind 和 event ID，不可替代。
6. NEG：把 Stage SHA 冒充 Loaded SHA、以檔案存在冒充 Reader ACK、錯 Policy Epoch 或倒寫投影，均 **NACK / zero unauthorized delta**。
7. Rollback 只由 Owner 對受影 Active generation 發獨立補償 Permit，驗證回復前版的 Active／Loaded／Consumer，不以文件中的示意 token 執行。

## 2. GWO-HGK：SBL 受治理提案 → Issuer → Hermes durable scheduler → 真可逆工作

1. SBL Commander 提出可逆小 WorkOrder 候選與 PIPD PI/PD/ECP refs；必要的 native `WorkOrder` 只由 HGK 唯一 Issuer 簽發。
2. 逐卡讀取現役有效 Policy ID/Epoch、Native method applicability (`KANBAN/SWARM/GSTACK/OPENSPEC/CODEX`)，強制方法沒有真調用收據時拒收；Issuer 僅在 Principal/Scope/Nonce/TTL 同 subject 成立時發 `RAW-HGK-ISSUER`。
3. Hermes 實際 durable queue 對 `WO-HGK-GOLDEN` 作 CAS lease_generation/heartbeat、bounded K scan；阻塞 A 時獨立 B/C 應能繼續；記 `RAW-HGK-QUEUE` 和 cursor/lease generation。
4. `OP-HGK-01` 由既有 Executor 進行小範圍可逆動作，Journal 保證 at-most-once；Timeout 只能 `UNKNOWN_EFFECT`→world-state reconcile，不得直接 retry；獨立 `RAW-HGK-EFFECT`。
5. 真 Independent Checker 對 issuer/queue/effect 不同 raw 收據驗證同 candidate SHA，並確認沒有其它不受影資源變更。
6. NEG：偽造 Issuer、用舊 nonce、ghost worker、stale lease、外援偽 native successor、兩次 Effect 皆首先 NACK。回復需獨立補償 ECP，不可重送已消耗卡。

## 3. GWO-SBL：真 Host 安裝 + user data add/list/remove + uninstall（分兩種效果）

1. SBL real entry 選擇 `CLI_TOOL × STANDALONE`。如安裝受影，`WO-B1-C3-OPS` 的 `OP-SBL-INSTALL` 取得真允許路徑、binary/version、doctor、status readback；此安裝不等於 user data 已被修改。
2. `WO-B1-C3-USER` 的 UserEffectBoundary 另查現役合法 User data Owner、同意目的/保存目錄與可撤銷性。若 Host 不存在合法 User issuer，回 `NOFIT_USER_ISSUER_UNBOUND` 且不做 add/remove；不能把 OPS/DEV Issuer 借給 USER。
3. **CLI source**：GitHub SBL `main` 已讀 `sbl_cli/sbl_todo.py`，可見 `_COMMANDS={init,add,list,remove,uninstall}`，`SCHEMA=SBL-TODO-STATE/1`；這是遠端程式碼而非本地 Host 安裝驗收。經 Owner 及使用者批准後，真 `sbl-todo` 命令的 `--data-dir` 必在 subcommand **前面**；真正刪除子命令是 `remove --id`，**沒有** `delete` 子命令：

```powershell
$home = '<USER_CONSENTED_ISOLATED_DATA_DIR>'
python -m sbl_cli.sbl_todo --data-dir $home init
python -m sbl_cli.sbl_todo --data-dir $home add --title 'B1 reversible smoke'
python -m sbl_cli.sbl_todo --data-dir $home list --json
# Use actual id from add JSON, never a guessed id.
python -m sbl_cli.sbl_todo --data-dir $home remove --id <ACTUAL_TASK_ID_FROM_ADD>
python -m sbl_cli.sbl_todo --data-dir $home list --json
python -m sbl_cli.sbl_todo --data-dir $home uninstall --yes
```

4. 獨立 Raw：`RAW-SBL-INSTALL`（安裝/載入）、`RAW-SBL-ADD`（task id/title）、`RAW-SBL-LIST1`（跨程序持久性）、`RAW-SBL-REMOVE`（該 id 移除）、`RAW-SBL-LIST2`（確實不再存在）、`RAW-SBL-UNINSTALL`（零殘留）。各 receipt 對應自己的 effect/command，無一可以合併為 generic success。
5. NEG：重覆 title `SBL_E_DUPLICATE_TITLE`/exit 3；空標題 `SBL_E_EMPTY_TITLE`/exit 2；`delete` 未知命令/exit 2；`uninstall` 遇 foreign files→`SBL_E_FOREIGN_FILES`/exit 5，避免誤刪共享資料。

## 4. 外援 Revoke → 下一段 Native Successor（G-B 必要、另 session）

先由權責 Owner 撤銷 helper 的外部 Principal/Scope/Nonce，記 `RAW-REVOKE`；切換另一個 Process/Session，**不得**以同 session 繼續稱自治。Native Scheduler 從已提交的 Durable Journal 自主發起 `WO-B1-C8` → HGK Issuer → Hermes Lease → Raw SameSubject Checker；再用撤銷的舊 Token 試重入應在 Spawn 之前 `REVOKED_TOKEN_REPLAY` 且無新增效果。若 successor 仍由 external helper 呼叫，G-B HOLD。

## 5. 三域 receipt identity 隔離

| GWO | operation IDs | 必需 RAW receipts | success | fail |
|---|---|---|---|---|
| GWO-FABRIC | OP-FAB-ACTIVATE（另 WO-FAB-DEV 如受影） | STAGE, LOADED, CONSUMER | 真 Reader 消費生效 Policy | stage-only/foreign epoch |
| GWO-HGK | OP-HGK-01 | ISSUER, QUEUE, EFFECT | 真 Issuer/公平 queue/可逆結果 | ghost/duplicate nonce/lease |
| GWO-SBL | OP-SBL-INSTALL, OP-SBL-ADD, OP-SBL-REMOVE | INSTALL, ADD, LIST1, REMOVE, LIST2, UNINSTALL | 真 CLI user task 持續存在後移除 | install receipt 冒充 user effect |

**結論**：全部上述都是施工／驗收計畫；沒有當前真 Host/Checker RAW 時三張 GWO **均未執行，G-B=HOLD**。
