---
artifact_family: FHS-MSC-B1-Bootstrap-Repair-PIPD-LS-PKG
version: 2026-10-26_r3_HIGH_RETENTION_SUBSTANTIVE_AUDIT_REPAIR
supersedes_version: 2026-10-26-r2-HIGH-RETENTION-SOURCE-BOUND
supersedes_subject_sha256: 273591a3f0cc7f43c87d6ac5e9e5704cf7ede15440a8a159b1de71d4c7d52da5
change_type: HIGH_RETENTION_INTEGRATE_COVER_REPLACE_NO_ARCHITECTURE_RESET
task_kind: DESIGN
claim_ceiling: AUTHOR_SIDE_REPAIR_CANDIDATE
formal_sourcefreeze: HOLD
independent_checker_receipt: NOT_RUN
native_effect: NOT_RUN
release: NOT_RUN
---

# DOC-B1-PD｜31 個 WO／OBS 完整影響分類、晚綁、效果轉移

**禁止**：對 Host state/User state 假造 `RepoContext`；觀測卡不得因此產生 P4 PD。Host 需要 Native Owner Adapter，未拿到 runtime ABI 時限 `HOLD_NOT_BOUND`。

## 1. 正式 late-bind 決策函式（設計工具，非 Host 實測）

```python
def choose_binding(slot, repo_probe=None, host_probe=None):
    k=slot['effect_class']
    if k == 'READ_ONLY_PROBE':
        return {'status':'READ_ONLY', 'permission':'NONE','effect':'NO_EFFECT',
                'required':'source_owner_scope+same_subject+fresh_snapshot'}
    if k == 'REPOSITORY_WRITE':
        if not repo_probe or not repo_probe.get('real_root') or not repo_probe.get('head') or not repo_probe.get('writable_scope'):
            return {'status':'HOLD','first_fail':'REPO_CONTEXT_MISSING'}
        if repo_probe.get('dirty_conflict') or repo_probe.get('currentness') != 'FRESH':
            return {'status':'HOLD','first_fail':'REPO_CONTEXT_NOT_FRESH'}
        return {'status':'READY_FOR_OWNER_REVIEW','writer':'Codex','scope':repo_probe['writable_scope']}
    if k == 'USER_DATA_EFFECT':
        if not host_probe or not host_probe.get('user_consent') or not host_probe.get('user_issuer'):
            return {'status':'NOFIT','first_fail':'USER_ISSUER_OR_CONSENT_MISSING'}
        return {'status':'READY_FOR_OWNER_REVIEW','effect':'USER_ONLY'}
    if k == 'HOST_OPERATIONS':
        if not host_probe or not host_probe.get('active_policy_epoch') or not host_probe.get('issuer'):
            return {'status':'HOLD','first_fail':'NATIVE_ISSUER_OR_POLICY_UNBOUND'}
        return {'status':'READY_FOR_OWNER_REVIEW','effect':'OPS_ONLY'}
    raise ValueError('EFFECT_CLASS_UNKNOWN')
```

## 2. 每個原始 WO/OBS 的個別判準（Operation、Schema、Readback、Rollback）

### PD-01｜OBS-B1-A1 — ROOT_RAW / READ_ONLY_PROBE

**原 r2 段落位置**：L411；**需求 Owner**：Host/RootMap Owner；domain invariant：same file ID and signed root; staged/unstaged/untracked snapshot stable。
**作用程序**：READ ONLY exact root_probe source/host probe; no WorkOrder issue, no ECP, no rollback token。
```json
{
  "atom": "B1-A1",
  "cross_effect_receipt_reuse": false,
  "current_binding_state": "READ_ONLY_SCOPE_PENDING",
  "effect_class": "READ_ONLY_PROBE",
  "effect_key": "ROOT_RAW",
  "needed_fields": [
    "subject_ref",
    "source_hash",
    "read_scope",
    "owner",
    "observation_time"
  ],
  "operation": "READ ONLY exact root_probe source/host probe; no WorkOrder issue, no ECP, no rollback token",
  "permission": "NONE_READ_ONLY",
  "readback_fields": [
    "real_root",
    "git_head",
    "status_index",
    "reparse_chain",
    "root_handle",
    "no_effect_witness"
  ],
  "schema": "B1.PD.EFFECT_SLOT@r3",
  "slot_id": "OBS-B1-A1"
}
```
**個別 NEG**：alias/junction traversal or changed HEAD -> ROOT_ALIAS_OR_PATH_ESCAPE; alias and stale observations must close without world mutation。`OBS-B1-A1` 產生獨立 `operation_id:OBS-B1-A1`、`RAW:OBS-B1-A1`、`OR:OBS-B1-A1`；只允許事前 hash 相同且合法 dependency 的上游 receipt，不可當作自己的 effect receipt。
**閉合條件**：Source→PI-B1-A1→OBS-B1-A1→只一 ECP 或 NO_EFFECT→`TQ-CHILD-OBS-B1-A1-POS/NEG/EDGE/SEC`→checker。Missing current binding ⇒ `HOLD`，不得把本 schema 範本稱為 issued WorkOrder。

### PD-02｜WO-B1-A2 — ISSUER_SUBJECT / HOST_OPERATIONS

**原 r2 段落位置**：L416；**需求 Owner**：HGK Native Issuer Owner；domain invariant：issuer-signed exact subject/scope checked before spawn; nonce consumed once。
**作用程序**：validate token{subject,policy_epoch,principal,nonce,scope,ttl} -> issuer signed ACK/NACK; consume nonce only on accepted native operation。
```json
{
  "atom": "B1-A2",
  "cross_effect_receipt_reuse": false,
  "current_binding_state": "HOLD_PENDING_TRUE_OWNER_AND_HOST",
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "ISSUER_SUBJECT",
  "needed_fields": [
    "subject_sha",
    "active_policy_epoch",
    "issuer_identity",
    "token_ref",
    "operation_id",
    "nonce",
    "ttl",
    "host_id",
    "expected_prestate_sha"
  ],
  "operation": "validate token{subject,policy_epoch,principal,nonce,scope,ttl} -> issuer signed ACK/NACK; consume nonce only on accepted native operation",
  "permission": "OWNER_BOUND_TOKEN_REQUIRED",
  "readback_fields": [
    "issuer_identity",
    "subject_sha",
    "nonce",
    "ttl",
    "policy_epoch",
    "grant_signature",
    "native_event_id",
    "operation_id",
    "effect_postimage_sha",
    "evidence_ref"
  ],
  "schema": "B1.PD.EFFECT_SLOT@r3",
  "slot_id": "WO-B1-A2"
}
```
**個別 NEG**：wrong issuer or replayed nonce -> PERMIT_SUBJECT_NONCE_REPLAY; expired/mismatched token or unknown effect -> NACK/RECONCILE。`WO-B1-A2` 產生獨立 `operation_id:WO-B1-A2`、`RAW:WO-B1-A2`、`OR:WO-B1-A2`；只允許事前 hash 相同且合法 dependency 的上游 receipt，不可當作自己的 effect receipt。
**閉合條件**：Source→PI-B1-A2→WO-B1-A2→只一 ECP 或 NO_EFFECT→`TQ-CHILD-WO-B1-A2-POS/NEG/EDGE/SEC`→checker。Missing current binding ⇒ `HOLD`，不得把本 schema 範本稱為 issued WorkOrder。

### PD-03｜WO-B1-A3 — QUEUE_WO / HOST_OPERATIONS

**原 r2 段落位置**：L424；**需求 Owner**：Hermes Queue Owner；domain invariant：blocked A parked; independent B/C progressed within bounded K; generation CAS unique。
**作用程序**：enqueue durable WO -> bounded K round-robin scan -> ClaimCAS lease_generation -> heartbeat -> checkpoint/PARK with predicate。
```json
{
  "atom": "B1-A3",
  "cross_effect_receipt_reuse": false,
  "current_binding_state": "HOLD_PENDING_TRUE_OWNER_AND_HOST",
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "QUEUE_WO",
  "needed_fields": [
    "subject_sha",
    "active_policy_epoch",
    "issuer_identity",
    "token_ref",
    "operation_id",
    "nonce",
    "ttl",
    "host_id",
    "expected_prestate_sha"
  ],
  "operation": "enqueue durable WO -> bounded K round-robin scan -> ClaimCAS lease_generation -> heartbeat -> checkpoint/PARK with predicate",
  "permission": "OWNER_BOUND_TOKEN_REQUIRED",
  "readback_fields": [
    "queue_id",
    "persisted_cursor",
    "lease_generation",
    "claimed_by",
    "park_reason",
    "native_event_id",
    "operation_id",
    "effect_postimage_sha",
    "evidence_ref"
  ],
  "schema": "B1.PD.EFFECT_SLOT@r3",
  "slot_id": "WO-B1-A3"
}
```
**個別 NEG**：duplicate claim, starved B/C or stale generation -> LOST_LEASE_OR_DUPLICATE_CLAIM; expired/mismatched token or unknown effect -> NACK/RECONCILE。`WO-B1-A3` 產生獨立 `operation_id:WO-B1-A3`、`RAW:WO-B1-A3`、`OR:WO-B1-A3`；只允許事前 hash 相同且合法 dependency 的上游 receipt，不可當作自己的 effect receipt。
**閉合條件**：Source→PI-B1-A3→WO-B1-A3→只一 ECP 或 NO_EFFECT→`TQ-CHILD-WO-B1-A3-POS/NEG/EDGE/SEC`→checker。Missing current binding ⇒ `HOLD`，不得把本 schema 範本稱為 issued WorkOrder。

### PD-04｜WO-B1-A4 — RECEIVER_ABI / HOST_OPERATIONS

**原 r2 段落位置**：L432；**需求 Owner**：HGK Receiver Owner；domain invariant：true receiver ACK signed for exact subject; mock ACK never qualifies。
**作用程序**：serialize existing typed receiver request -> native receiver validates ABI+Permit -> native event ACK/NACK -> same WO readback。
```json
{
  "atom": "B1-A4",
  "cross_effect_receipt_reuse": false,
  "current_binding_state": "HOLD_PENDING_TRUE_OWNER_AND_HOST",
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "RECEIVER_ABI",
  "needed_fields": [
    "subject_sha",
    "active_policy_epoch",
    "issuer_identity",
    "token_ref",
    "operation_id",
    "nonce",
    "ttl",
    "host_id",
    "expected_prestate_sha"
  ],
  "operation": "serialize existing typed receiver request -> native receiver validates ABI+Permit -> native event ACK/NACK -> same WO readback",
  "permission": "OWNER_BOUND_TOKEN_REQUIRED",
  "readback_fields": [
    "abi_id",
    "issuer",
    "wo_id",
    "subject_sha",
    "ack_or_nack",
    "native_event",
    "native_event_id",
    "operation_id",
    "effect_postimage_sha",
    "evidence_ref"
  ],
  "schema": "B1.PD.EFFECT_SLOT@r3",
  "slot_id": "WO-B1-A4"
}
```
**個別 NEG**：mocked ACK/wrong ABI/absent native event -> RECEIVER_NOT_LIVE; expired/mismatched token or unknown effect -> NACK/RECONCILE。`WO-B1-A4` 產生獨立 `operation_id:WO-B1-A4`、`RAW:WO-B1-A4`、`OR:WO-B1-A4`；只允許事前 hash 相同且合法 dependency 的上游 receipt，不可當作自己的 effect receipt。
**閉合條件**：Source→PI-B1-A4→WO-B1-A4→只一 ECP 或 NO_EFFECT→`TQ-CHILD-WO-B1-A4-POS/NEG/EDGE/SEC`→checker。Missing current binding ⇒ `HOLD`，不得把本 schema 範本稱為 issued WorkOrder。

### PD-05｜OBS-B1-A5 — MODEL_LANES / READ_ONLY_PROBE

**原 r2 段落位置**：L440；**需求 Owner**：Model/Lane Owner；domain invariant：each mandatory lane actually served, same host and policy epoch。
**作用程序**：READ ONLY exact host_lane_readback source/host probe; no WorkOrder issue, no ECP, no rollback token。
```json
{
  "atom": "B1-A5",
  "cross_effect_receipt_reuse": false,
  "current_binding_state": "READ_ONLY_SCOPE_PENDING",
  "effect_class": "READ_ONLY_PROBE",
  "effect_key": "MODEL_LANES",
  "needed_fields": [
    "subject_ref",
    "source_hash",
    "read_scope",
    "owner",
    "observation_time"
  ],
  "operation": "READ ONLY exact host_lane_readback source/host probe; no WorkOrder issue, no ECP, no rollback token",
  "permission": "NONE_READ_ONLY",
  "readback_fields": [
    "PLAN",
    "EXECUTE",
    "VERIFY_SECURITY",
    "required_arm",
    "served_arm",
    "epoch",
    "loaded_sha",
    "no_effect_witness"
  ],
  "schema": "B1.PD.EFFECT_SLOT@r3",
  "slot_id": "OBS-B1-A5"
}
```
**個別 NEG**：silent model fallback or missing served arm -> MODEL_REQUIRED_NOT_SERVED; alias and stale observations must close without world mutation。`OBS-B1-A5` 產生獨立 `operation_id:OBS-B1-A5`、`RAW:OBS-B1-A5`、`OR:OBS-B1-A5`；只允許事前 hash 相同且合法 dependency 的上游 receipt，不可當作自己的 effect receipt。
**閉合條件**：Source→PI-B1-A5→OBS-B1-A5→只一 ECP 或 NO_EFFECT→`TQ-CHILD-OBS-B1-A5-POS/NEG/EDGE/SEC`→checker。Missing current binding ⇒ `HOLD`，不得把本 schema 範本稱為 issued WorkOrder。

### PD-06｜WO-B1-A6 — EFFECT_JOURNAL / HOST_OPERATIONS

**原 r2 段落位置**：L445；**需求 Owner**：Effect Journal Owner；domain invariant：at-most-once effect; UNKNOWN_EFFECT reconciled before any next claim。
**作用程序**：prepare operation fingerprint -> CAS claim -> execute at most once -> read world state -> reconcile UNKNOWN without blind retry。
```json
{
  "atom": "B1-A6",
  "cross_effect_receipt_reuse": false,
  "current_binding_state": "HOLD_PENDING_TRUE_OWNER_AND_HOST",
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "EFFECT_JOURNAL",
  "needed_fields": [
    "subject_sha",
    "active_policy_epoch",
    "issuer_identity",
    "token_ref",
    "operation_id",
    "nonce",
    "ttl",
    "host_id",
    "expected_prestate_sha"
  ],
  "operation": "prepare operation fingerprint -> CAS claim -> execute at most once -> read world state -> reconcile UNKNOWN without blind retry",
  "permission": "OWNER_BOUND_TOKEN_REQUIRED",
  "readback_fields": [
    "operation_id",
    "preimage",
    "observed_postimage",
    "CAS_fence",
    "unknown_effect",
    "native_event_id",
    "operation_id",
    "effect_postimage_sha",
    "evidence_ref"
  ],
  "schema": "B1.PD.EFFECT_SLOT@r3",
  "slot_id": "WO-B1-A6"
}
```
**個別 NEG**：duplicate operation or retry-on-timeout -> UNKNOWN_EFFECT_REPLAY; expired/mismatched token or unknown effect -> NACK/RECONCILE。`WO-B1-A6` 產生獨立 `operation_id:WO-B1-A6`、`RAW:WO-B1-A6`、`OR:WO-B1-A6`；只允許事前 hash 相同且合法 dependency 的上游 receipt，不可當作自己的 effect receipt。
**閉合條件**：Source→PI-B1-A6→WO-B1-A6→只一 ECP 或 NO_EFFECT→`TQ-CHILD-WO-B1-A6-POS/NEG/EDGE/SEC`→checker。Missing current binding ⇒ `HOLD`，不得把本 schema 範本稱為 issued WorkOrder。

### PD-07｜OBS-B1-A7 — RAW_EVIDENCE / READ_ONLY_PROBE

**原 r2 段落位置**：L453；**需求 Owner**：Independent AO；domain invariant：distinct principal checker receipt matches same candidate and non-empty RAW。
**作用程序**：READ ONLY exact immutable_evidence source/host probe; no WorkOrder issue, no ECP, no rollback token。
```json
{
  "atom": "B1-A7",
  "cross_effect_receipt_reuse": false,
  "current_binding_state": "READ_ONLY_SCOPE_PENDING",
  "effect_class": "READ_ONLY_PROBE",
  "effect_key": "RAW_EVIDENCE",
  "needed_fields": [
    "subject_ref",
    "source_hash",
    "read_scope",
    "owner",
    "observation_time"
  ],
  "operation": "READ ONLY exact immutable_evidence source/host probe; no WorkOrder issue, no ECP, no rollback token",
  "permission": "NONE_READ_ONLY",
  "readback_fields": [
    "raw_receipt",
    "subject_sha",
    "candidate_sha",
    "checker_principal",
    "witness",
    "no_effect_witness"
  ],
  "schema": "B1.PD.EFFECT_SLOT@r3",
  "slot_id": "OBS-B1-A7"
}
```
**個別 NEG**：self-attested or mismatched witness -> RAW_OR_CHECKER_MISMATCH; alias and stale observations must close without world mutation。`OBS-B1-A7` 產生獨立 `operation_id:OBS-B1-A7`、`RAW:OBS-B1-A7`、`OR:OBS-B1-A7`；只允許事前 hash 相同且合法 dependency 的上游 receipt，不可當作自己的 effect receipt。
**閉合條件**：Source→PI-B1-A7→OBS-B1-A7→只一 ECP 或 NO_EFFECT→`TQ-CHILD-OBS-B1-A7-POS/NEG/EDGE/SEC`→checker。Missing current binding ⇒ `HOLD`，不得把本 schema 範本稱為 issued WorkOrder。

### PD-08｜WO-B1-A8 — NATIVE_HOTPATH / REPOSITORY_WRITE

**原 r2 段落位置**：L458；**需求 Owner**：Fabric/HGK Dev Owner；domain invariant：exact loaded callsite identified and scoped regression independent。
**作用程序**：Codex bounded patch ONLY for NATIVE_HOTPATH: identify actual import/callsite; freeze preimage and red test; scoped source diff; green+negative+rollback。
```json
{
  "atom": "B1-A8",
  "cross_effect_receipt_reuse": false,
  "current_binding_state": "HOLD_PENDING_TRUE_OWNER_AND_HOST",
  "effect_class": "REPOSITORY_WRITE",
  "effect_key": "NATIVE_HOTPATH",
  "needed_fields": [
    "real_root",
    "git_head",
    "status_porcelain_z",
    "writable_scope",
    "preimage_sha",
    "red_test",
    "candidate_sha",
    "authorization_ref"
  ],
  "operation": "Codex bounded patch ONLY for NATIVE_HOTPATH: identify actual import/callsite; freeze preimage and red test; scoped source diff; green+negative+rollback",
  "permission": "REPO_WRITER_SCOPE",
  "readback_fields": [
    "git_head_after",
    "changed_paths",
    "prepost_sha",
    "red_green_receipts",
    "rollback_readback"
  ],
  "schema": "B1.PD.EFFECT_SLOT@r3",
  "slot_id": "WO-B1-A8"
}
```
**個別 NEG**：write out of root, stale HEAD, changed untracked, or no preimage → deny; rollback only approved changed paths。`WO-B1-A8` 產生獨立 `operation_id:WO-B1-A8`、`RAW:WO-B1-A8`、`OR:WO-B1-A8`；只允許事前 hash 相同且合法 dependency 的上游 receipt，不可當作自己的 effect receipt。
**閉合條件**：Source→PI-B1-A8→WO-B1-A8→只一 ECP 或 NO_EFFECT→`TQ-CHILD-WO-B1-A8-POS/NEG/EDGE/SEC`→checker。Missing current binding ⇒ `HOLD`，不得把本 schema 範本稱為 issued WorkOrder。

### PD-09｜WO-B1-A9 — NATIVE_CONTINUATION / HOST_OPERATIONS

**原 r2 段落位置**：L466；**需求 Owner**：Hermes Continuation Owner；domain invariant：native successor advances after external revoke with new session and no external trigger。
**作用程序**：external session stop -> durable T2 post-turn native scheduler -> T3 checkpoint -> T4 resume under fresh native WO。
```json
{
  "atom": "B1-A9",
  "cross_effect_receipt_reuse": false,
  "current_binding_state": "HOLD_PENDING_TRUE_OWNER_AND_HOST",
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "NATIVE_CONTINUATION",
  "needed_fields": [
    "subject_sha",
    "active_policy_epoch",
    "issuer_identity",
    "token_ref",
    "operation_id",
    "nonce",
    "ttl",
    "host_id",
    "expected_prestate_sha"
  ],
  "operation": "external session stop -> durable T2 post-turn native scheduler -> T3 checkpoint -> T4 resume under fresh native WO",
  "permission": "OWNER_BOUND_TOKEN_REQUIRED",
  "readback_fields": [
    "external_revoke",
    "post_turn_source",
    "issued_wo",
    "native_claim",
    "session_exit",
    "native_event_id",
    "operation_id",
    "effect_postimage_sha",
    "evidence_ref"
  ],
  "schema": "B1.PD.EFFECT_SLOT@r3",
  "slot_id": "WO-B1-A9"
}
```
**個別 NEG**：external actor still triggering -> EXTERNAL_TRIGGER_STILL_REQUIRED; expired/mismatched token or unknown effect -> NACK/RECONCILE。`WO-B1-A9` 產生獨立 `operation_id:WO-B1-A9`、`RAW:WO-B1-A9`、`OR:WO-B1-A9`；只允許事前 hash 相同且合法 dependency 的上游 receipt，不可當作自己的 effect receipt。
**閉合條件**：Source→PI-B1-A9→WO-B1-A9→只一 ECP 或 NO_EFFECT→`TQ-CHILD-WO-B1-A9-POS/NEG/EDGE/SEC`→checker。Missing current binding ⇒ `HOLD`，不得把本 schema 範本稱為 issued WorkOrder。

### PD-10｜OBS-B1-B1 — SOURCE_ATOMS / READ_ONLY_PROBE

**原 r2 段落位置**：L474；**需求 Owner**：PIPD Source Owner；domain invariant：one-to-one source clause/owner/oracle joins; missing clause is HOLD。
**作用程序**：READ ONLY exact source_oracle source/host probe; no WorkOrder issue, no ECP, no rollback token。
```json
{
  "atom": "B1-B1",
  "cross_effect_receipt_reuse": false,
  "current_binding_state": "READ_ONLY_SCOPE_PENDING",
  "effect_class": "READ_ONLY_PROBE",
  "effect_key": "SOURCE_ATOMS",
  "needed_fields": [
    "subject_ref",
    "source_hash",
    "read_scope",
    "owner",
    "observation_time"
  ],
  "operation": "READ ONLY exact source_oracle source/host probe; no WorkOrder issue, no ECP, no rollback token",
  "permission": "NONE_READ_ONLY",
  "readback_fields": [
    "clause_sha",
    "atom_id",
    "source_owner",
    "domain_oracle",
    "trace_edges",
    "no_effect_witness"
  ],
  "schema": "B1.PD.EFFECT_SLOT@r3",
  "slot_id": "OBS-B1-B1"
}
```
**個別 NEG**：missing oracle or fabricated source -> PI_SOURCE_OR_ORACLE_UNBOUND; alias and stale observations must close without world mutation。`OBS-B1-B1` 產生獨立 `operation_id:OBS-B1-B1`、`RAW:OBS-B1-B1`、`OR:OBS-B1-B1`；只允許事前 hash 相同且合法 dependency 的上游 receipt，不可當作自己的 effect receipt。
**閉合條件**：Source→PI-B1-B1→OBS-B1-B1→只一 ECP 或 NO_EFFECT→`TQ-CHILD-OBS-B1-B1-POS/NEG/EDGE/SEC`→checker。Missing current binding ⇒ `HOLD`，不得把本 schema 範本稱為 issued WorkOrder。

### PD-11｜OBS-B1-B2 — REPO_CONTEXT / READ_ONLY_PROBE

**原 r2 段落位置**：L479；**需求 Owner**：PIPD PD Binder Owner；domain invariant：P4 PD only with actual repo root, HEAD and affected-only allowed write scope。
**作用程序**：READ ONLY exact repo_context_probe source/host probe; no WorkOrder issue, no ECP, no rollback token。
```json
{
  "atom": "B1-B2",
  "cross_effect_receipt_reuse": false,
  "current_binding_state": "READ_ONLY_SCOPE_PENDING",
  "effect_class": "READ_ONLY_PROBE",
  "effect_key": "REPO_CONTEXT",
  "needed_fields": [
    "subject_ref",
    "source_hash",
    "read_scope",
    "owner",
    "observation_time"
  ],
  "operation": "READ ONLY exact repo_context_probe source/host probe; no WorkOrder issue, no ECP, no rollback token",
  "permission": "NONE_READ_ONLY",
  "readback_fields": [
    "realpath",
    "head",
    "index",
    "untracked",
    "writable_scope",
    "currentness",
    "no_effect_witness"
  ],
  "schema": "B1.PD.EFFECT_SLOT@r3",
  "slot_id": "OBS-B1-B2"
}
```
**個別 NEG**：stale/escaping context -> REPO_CONTEXT_NOT_FRESH; alias and stale observations must close without world mutation。`OBS-B1-B2` 產生獨立 `operation_id:OBS-B1-B2`、`RAW:OBS-B1-B2`、`OR:OBS-B1-B2`；只允許事前 hash 相同且合法 dependency 的上游 receipt，不可當作自己的 effect receipt。
**閉合條件**：Source→PI-B1-B2→OBS-B1-B2→只一 ECP 或 NO_EFFECT→`TQ-CHILD-OBS-B1-B2-POS/NEG/EDGE/SEC`→checker。Missing current binding ⇒ `HOLD`，不得把本 schema 範本稱為 issued WorkOrder。

### PD-12｜WO-B1-B3-DEV — SBL_TO_NATIVE__DEV / REPOSITORY_WRITE

**原 r2 段落位置**：L484；**需求 Owner**：SBL Bridge & HGK Owner；domain invariant：DEV/OPS different WOs, separate source diff and real native ACK。
**作用程序**：Codex bounded patch ONLY for SBL_TO_NATIVE__DEV: identify actual import/callsite; freeze preimage and red test; scoped source diff; green+negative+rollback。
```json
{
  "atom": "B1-B3",
  "cross_effect_receipt_reuse": false,
  "current_binding_state": "HOLD_PENDING_TRUE_OWNER_AND_HOST",
  "effect_class": "REPOSITORY_WRITE",
  "effect_key": "SBL_TO_NATIVE__DEV",
  "needed_fields": [
    "real_root",
    "git_head",
    "status_porcelain_z",
    "writable_scope",
    "preimage_sha",
    "red_test",
    "candidate_sha",
    "authorization_ref"
  ],
  "operation": "Codex bounded patch ONLY for SBL_TO_NATIVE__DEV: identify actual import/callsite; freeze preimage and red test; scoped source diff; green+negative+rollback",
  "permission": "REPO_WRITER_SCOPE",
  "readback_fields": [
    "git_head_after",
    "changed_paths",
    "prepost_sha",
    "red_green_receipts",
    "rollback_readback"
  ],
  "schema": "B1.PD.EFFECT_SLOT@r3",
  "slot_id": "WO-B1-B3-DEV"
}
```
**個別 NEG**：write out of root, stale HEAD, changed untracked, or no preimage → deny; rollback only approved changed paths。`WO-B1-B3-DEV` 產生獨立 `operation_id:WO-B1-B3-DEV`、`RAW:WO-B1-B3-DEV`、`OR:WO-B1-B3-DEV`；只允許事前 hash 相同且合法 dependency 的上游 receipt，不可當作自己的 effect receipt。
**閉合條件**：Source→PI-B1-B3→WO-B1-B3-DEV→只一 ECP 或 NO_EFFECT→`TQ-CHILD-WO-B1-B3-DEV-POS/NEG/EDGE/SEC`→checker。Missing current binding ⇒ `HOLD`，不得把本 schema 範本稱為 issued WorkOrder。

### PD-13｜WO-B1-B3-OPS — SBL_TO_NATIVE__OPS / HOST_OPERATIONS

**原 r2 段落位置**：L492；**需求 Owner**：SBL Bridge & HGK Owner；domain invariant：DEV/OPS different WOs, separate source diff and real native ACK。
**作用程序**：consume DEV handoff digest -> native receiver validates ABI; SBL never signs issuer event。
```json
{
  "atom": "B1-B3",
  "cross_effect_receipt_reuse": false,
  "current_binding_state": "HOLD_PENDING_TRUE_OWNER_AND_HOST",
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "SBL_TO_NATIVE__OPS",
  "needed_fields": [
    "subject_sha",
    "active_policy_epoch",
    "issuer_identity",
    "token_ref",
    "operation_id",
    "nonce",
    "ttl",
    "host_id",
    "expected_prestate_sha"
  ],
  "operation": "consume DEV handoff digest -> native receiver validates ABI; SBL never signs issuer event",
  "permission": "OWNER_BOUND_TOKEN_REQUIRED",
  "readback_fields": [
    "sbl_entry",
    "candidate",
    "dev_diff",
    "ops_handoff",
    "native_receiver_ack",
    "native_event_id",
    "operation_id",
    "effect_postimage_sha",
    "evidence_ref"
  ],
  "schema": "B1.PD.EFFECT_SLOT@r3",
  "slot_id": "WO-B1-B3-OPS"
}
```
**個別 NEG**：second issuer or shared receipt -> SECOND_ISSUER_OR_MIXED_EFFECT; expired/mismatched token or unknown effect -> NACK/RECONCILE。`WO-B1-B3-OPS` 產生獨立 `operation_id:WO-B1-B3-OPS`、`RAW:WO-B1-B3-OPS`、`OR:WO-B1-B3-OPS`；只允許事前 hash 相同且合法 dependency 的上游 receipt，不可當作自己的 effect receipt。
**閉合條件**：Source→PI-B1-B3→WO-B1-B3-OPS→只一 ECP 或 NO_EFFECT→`TQ-CHILD-WO-B1-B3-OPS-POS/NEG/EDGE/SEC`→checker。Missing current binding ⇒ `HOLD`，不得把本 schema 範本稱為 issued WorkOrder。

### PD-14｜WO-B1-B4-DEV — ECP_SELECTOR__DEV / REPOSITORY_WRITE

**原 r2 段落位置**：L500；**需求 Owner**：HGK ECP Selection Owner；domain invariant：one active ECP per WO; split iff distinct effects。
**作用程序**：Codex bounded patch ONLY for ECP_SELECTOR__DEV: identify actual import/callsite; freeze preimage and red test; scoped source diff; green+negative+rollback。
```json
{
  "atom": "B1-B4",
  "cross_effect_receipt_reuse": false,
  "current_binding_state": "HOLD_PENDING_TRUE_OWNER_AND_HOST",
  "effect_class": "REPOSITORY_WRITE",
  "effect_key": "ECP_SELECTOR__DEV",
  "needed_fields": [
    "real_root",
    "git_head",
    "status_porcelain_z",
    "writable_scope",
    "preimage_sha",
    "red_test",
    "candidate_sha",
    "authorization_ref"
  ],
  "operation": "Codex bounded patch ONLY for ECP_SELECTOR__DEV: identify actual import/callsite; freeze preimage and red test; scoped source diff; green+negative+rollback",
  "permission": "REPO_WRITER_SCOPE",
  "readback_fields": [
    "git_head_after",
    "changed_paths",
    "prepost_sha",
    "red_green_receipts",
    "rollback_readback"
  ],
  "schema": "B1.PD.EFFECT_SLOT@r3",
  "slot_id": "WO-B1-B4-DEV"
}
```
**個別 NEG**：write out of root, stale HEAD, changed untracked, or no preimage → deny; rollback only approved changed paths。`WO-B1-B4-DEV` 產生獨立 `operation_id:WO-B1-B4-DEV`、`RAW:WO-B1-B4-DEV`、`OR:WO-B1-B4-DEV`；只允許事前 hash 相同且合法 dependency 的上游 receipt，不可當作自己的 effect receipt。
**閉合條件**：Source→PI-B1-B4→WO-B1-B4-DEV→只一 ECP 或 NO_EFFECT→`TQ-CHILD-WO-B1-B4-DEV-POS/NEG/EDGE/SEC`→checker。Missing current binding ⇒ `HOLD`，不得把本 schema 範本稱為 issued WorkOrder。

### PD-15｜WO-B1-B4-OPS — ECP_SELECTOR__OPS / HOST_OPERATIONS

**原 r2 段落位置**：L508；**需求 Owner**：HGK ECP Selection Owner；domain invariant：one active ECP per WO; split iff distinct effects。
**作用程序**：consume DEV selector correction receipt -> native Issuer enforces one active ECP and one effect class。
```json
{
  "atom": "B1-B4",
  "cross_effect_receipt_reuse": false,
  "current_binding_state": "HOLD_PENDING_TRUE_OWNER_AND_HOST",
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "ECP_SELECTOR__OPS",
  "needed_fields": [
    "subject_sha",
    "active_policy_epoch",
    "issuer_identity",
    "token_ref",
    "operation_id",
    "nonce",
    "ttl",
    "host_id",
    "expected_prestate_sha"
  ],
  "operation": "consume DEV selector correction receipt -> native Issuer enforces one active ECP and one effect class",
  "permission": "OWNER_BOUND_TOKEN_REQUIRED",
  "readback_fields": [
    "wo_id",
    "effect_class",
    "active_ecp_count",
    "issuer_ack",
    "native_event_id",
    "operation_id",
    "effect_postimage_sha",
    "evidence_ref"
  ],
  "schema": "B1.PD.EFFECT_SLOT@r3",
  "slot_id": "WO-B1-B4-OPS"
}
```
**個別 NEG**：two active ECPs/unknown class -> ECP_MULTIPLE_OR_CLASS_UNKNOWN; expired/mismatched token or unknown effect -> NACK/RECONCILE。`WO-B1-B4-OPS` 產生獨立 `operation_id:WO-B1-B4-OPS`、`RAW:WO-B1-B4-OPS`、`OR:WO-B1-B4-OPS`；只允許事前 hash 相同且合法 dependency 的上游 receipt，不可當作自己的 effect receipt。
**閉合條件**：Source→PI-B1-B4→WO-B1-B4-OPS→只一 ECP 或 NO_EFFECT→`TQ-CHILD-WO-B1-B4-OPS-POS/NEG/EDGE/SEC`→checker。Missing current binding ⇒ `HOLD`，不得把本 schema 範本稱為 issued WorkOrder。

### PD-16｜WO-B1-B5-DEV — THREE_SP__DEV / REPOSITORY_WRITE

**原 r2 段落位置**：L516；**需求 Owner**：SP Host Owner；domain invariant：three host identities and isolated permission readbacks; ZIP-only not pass。
**作用程序**：Codex bounded patch ONLY for THREE_SP__DEV: identify actual import/callsite; freeze preimage and red test; scoped source diff; green+negative+rollback。
```json
{
  "atom": "B1-B5",
  "cross_effect_receipt_reuse": false,
  "current_binding_state": "HOLD_PENDING_TRUE_OWNER_AND_HOST",
  "effect_class": "REPOSITORY_WRITE",
  "effect_key": "THREE_SP__DEV",
  "needed_fields": [
    "real_root",
    "git_head",
    "status_porcelain_z",
    "writable_scope",
    "preimage_sha",
    "red_test",
    "candidate_sha",
    "authorization_ref"
  ],
  "operation": "Codex bounded patch ONLY for THREE_SP__DEV: identify actual import/callsite; freeze preimage and red test; scoped source diff; green+negative+rollback",
  "permission": "REPO_WRITER_SCOPE",
  "readback_fields": [
    "git_head_after",
    "changed_paths",
    "prepost_sha",
    "red_green_receipts",
    "rollback_readback"
  ],
  "schema": "B1.PD.EFFECT_SLOT@r3",
  "slot_id": "WO-B1-B5-DEV"
}
```
**個別 NEG**：write out of root, stale HEAD, changed untracked, or no preimage → deny; rollback only approved changed paths。`WO-B1-B5-DEV` 產生獨立 `operation_id:WO-B1-B5-DEV`、`RAW:WO-B1-B5-DEV`、`OR:WO-B1-B5-DEV`；只允許事前 hash 相同且合法 dependency 的上游 receipt，不可當作自己的 effect receipt。
**閉合條件**：Source→PI-B1-B5→WO-B1-B5-DEV→只一 ECP 或 NO_EFFECT→`TQ-CHILD-WO-B1-B5-DEV-POS/NEG/EDGE/SEC`→checker。Missing current binding ⇒ `HOLD`，不得把本 schema 範本稱為 issued WorkOrder。

### PD-17｜WO-B1-B5-OPS — THREE_SP__OPS / HOST_OPERATIONS

**原 r2 段落位置**：L524；**需求 Owner**：SP Host Owner；domain invariant：three host identities and isolated permission readbacks; ZIP-only not pass。
**作用程序**：consume DEV packaging receipt -> host loader installs/loads 3 independent SP identities and proves actual invoke + deny。
```json
{
  "atom": "B1-B5",
  "cross_effect_receipt_reuse": false,
  "current_binding_state": "HOLD_PENDING_TRUE_OWNER_AND_HOST",
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "THREE_SP__OPS",
  "needed_fields": [
    "subject_sha",
    "active_policy_epoch",
    "issuer_identity",
    "token_ref",
    "operation_id",
    "nonce",
    "ttl",
    "host_id",
    "expected_prestate_sha"
  ],
  "operation": "consume DEV packaging receipt -> host loader installs/loads 3 independent SP identities and proves actual invoke + deny",
  "permission": "OWNER_BOUND_TOKEN_REQUIRED",
  "readback_fields": [
    "TPM_SP",
    "COMMANDER_SP",
    "CHALLENGE_SP",
    "host_invocation",
    "loaded_sha",
    "native_event_id",
    "operation_id",
    "effect_postimage_sha",
    "evidence_ref"
  ],
  "schema": "B1.PD.EFFECT_SLOT@r3",
  "slot_id": "WO-B1-B5-OPS"
}
```
**個別 NEG**：missing host invocation -> SP_HOST_LOAD_UNPROVEN; expired/mismatched token or unknown effect -> NACK/RECONCILE。`WO-B1-B5-OPS` 產生獨立 `operation_id:WO-B1-B5-OPS`、`RAW:WO-B1-B5-OPS`、`OR:WO-B1-B5-OPS`；只允許事前 hash 相同且合法 dependency 的上游 receipt，不可當作自己的 effect receipt。
**閉合條件**：Source→PI-B1-B5→WO-B1-B5-OPS→只一 ECP 或 NO_EFFECT→`TQ-CHILD-WO-B1-B5-OPS-POS/NEG/EDGE/SEC`→checker。Missing current binding ⇒ `HOLD`，不得把本 schema 範本稱為 issued WorkOrder。

### PD-18｜WO-B1-B6-USER — TODO_PERSISTENCE / USER_DATA_EFFECT

**原 r2 段落位置**：L532；**需求 Owner**：SBL CLI/User Data Owner；domain invariant：isolated store add -> separate list -> remove --id -> zero residue。
**作用程序**：SBL existing sbl-todo --data-dir <isolated> init/add/list/remove --id <ACTUAL_TASK_ID>; user consent and separate USER issuer decision, no OPS/DEV ECP。
```json
{
  "atom": "B1-B6",
  "cross_effect_receipt_reuse": false,
  "current_binding_state": "HOLD_PENDING_TRUE_OWNER_AND_HOST",
  "effect_class": "USER_DATA_EFFECT",
  "effect_key": "TODO_PERSISTENCE",
  "needed_fields": [
    "consenting_principal",
    "isolated_data_dir",
    "sbl_todo_binary_sha",
    "user_effect_issuer_ref",
    "record_id",
    "prestate_snapshot",
    "consent_scope"
  ],
  "operation": "SBL existing sbl-todo --data-dir <isolated> init/add/list/remove --id <ACTUAL_TASK_ID>; user consent and separate USER issuer decision, no OPS/DEV ECP",
  "permission": "USER_CONSENT_AND_USER_ISSUER",
  "readback_fields": [
    "task_id",
    "add_ack",
    "list_json",
    "delete_ack",
    "record_version",
    "uninstall_residue"
  ],
  "schema": "B1.PD.EFFECT_SLOT@r3",
  "slot_id": "WO-B1-B6-USER"
}
```
**個別 NEG**：missing user consent/issuer, wrong data_dir, duplicated id → no effect / distinct NoFitReceipt。`WO-B1-B6-USER` 產生獨立 `operation_id:WO-B1-B6-USER`、`RAW:WO-B1-B6-USER`、`OR:WO-B1-B6-USER`；只允許事前 hash 相同且合法 dependency 的上游 receipt，不可當作自己的 effect receipt。
**閉合條件**：Source→PI-B1-B6→WO-B1-B6-USER→只一 ECP 或 NO_EFFECT→`TQ-CHILD-WO-B1-B6-USER-POS/NEG/EDGE/SEC`→checker。Missing current binding ⇒ `HOLD`，不得把本 schema 範本稱為 issued WorkOrder。

### PD-19｜OBS-B1-B7 — NOFIT_ROUTE / READ_ONLY_PROBE

**原 r2 段落位置**：L540；**需求 Owner**：PIPD TechnologyAdmission Owner；domain invariant：deterministic capability NOFIT with user-readable reason and zero unauthorized delta。
**作用程序**：READ ONLY exact no_fit source/host probe; no WorkOrder issue, no ECP, no rollback token。
```json
{
  "atom": "B1-B7",
  "cross_effect_receipt_reuse": false,
  "current_binding_state": "READ_ONLY_SCOPE_PENDING",
  "effect_class": "READ_ONLY_PROBE",
  "effect_key": "NOFIT_ROUTE",
  "needed_fields": [
    "subject_ref",
    "source_hash",
    "read_scope",
    "owner",
    "observation_time"
  ],
  "operation": "READ ONLY exact no_fit source/host probe; no WorkOrder issue, no ECP, no rollback token",
  "permission": "NONE_READ_ONLY",
  "readback_fields": [
    "required_capability",
    "host",
    "provider_off",
    "owner",
    "refusal",
    "zero_effect",
    "no_effect_witness"
  ],
  "schema": "B1.PD.EFFECT_SLOT@r3",
  "slot_id": "OBS-B1-B7"
}
```
**個別 NEG**：silent fallback -> NOFIT_OR_PROVIDER_OFF; alias and stale observations must close without world mutation。`OBS-B1-B7` 產生獨立 `operation_id:OBS-B1-B7`、`RAW:OBS-B1-B7`、`OR:OBS-B1-B7`；只允許事前 hash 相同且合法 dependency 的上游 receipt，不可當作自己的 effect receipt。
**閉合條件**：Source→PI-B1-B7→OBS-B1-B7→只一 ECP 或 NO_EFFECT→`TQ-CHILD-OBS-B1-B7-POS/NEG/EDGE/SEC`→checker。Missing current binding ⇒ `HOLD`，不得把本 schema 範本稱為 issued WorkOrder。

### PD-20｜OBS-B1-B8 — TRACE_GRAPH / READ_ONLY_PROBE

**原 r2 段落位置**：L545；**需求 Owner**：PIPD Trace Owner；domain invariant：nonempty exact IDs and hashes, zero orphans and zero bad edges。
**作用程序**：READ ONLY exact trace_closure source/host probe; no WorkOrder issue, no ECP, no rollback token。
```json
{
  "atom": "B1-B8",
  "cross_effect_receipt_reuse": false,
  "current_binding_state": "READ_ONLY_SCOPE_PENDING",
  "effect_class": "READ_ONLY_PROBE",
  "effect_key": "TRACE_GRAPH",
  "needed_fields": [
    "subject_ref",
    "source_hash",
    "read_scope",
    "owner",
    "observation_time"
  ],
  "operation": "READ ONLY exact trace_closure source/host probe; no WorkOrder issue, no ECP, no rollback token",
  "permission": "NONE_READ_ONLY",
  "readback_fields": [
    "pi",
    "pd",
    "cc",
    "ecp",
    "wo",
    "tqaep",
    "raw",
    "checker",
    "edges",
    "no_effect_witness"
  ],
  "schema": "B1.PD.EFFECT_SLOT@r3",
  "slot_id": "OBS-B1-B8"
}
```
**個別 NEG**：foreign/sibling witness -> TRACE_CLOSURE_FAIL; alias and stale observations must close without world mutation。`OBS-B1-B8` 產生獨立 `operation_id:OBS-B1-B8`、`RAW:OBS-B1-B8`、`OR:OBS-B1-B8`；只允許事前 hash 相同且合法 dependency 的上游 receipt，不可當作自己的 effect receipt。
**閉合條件**：Source→PI-B1-B8→OBS-B1-B8→只一 ECP 或 NO_EFFECT→`TQ-CHILD-OBS-B1-B8-POS/NEG/EDGE/SEC`→checker。Missing current binding ⇒ `HOLD`，不得把本 schema 範本稱為 issued WorkOrder。

### PD-21｜OBS-B1-B9 — R15_COVERAGE / READ_ONLY_PROBE

**原 r2 段落位置**：L550；**需求 Owner**：SBL Product Owner；domain invariant：949 unique 18-family IDs, 66/254/629 and source-specific disposition。
**作用程序**：READ ONLY exact baseline_denominator source/host probe; no WorkOrder issue, no ECP, no rollback token。
```json
{
  "atom": "B1-B9",
  "cross_effect_receipt_reuse": false,
  "current_binding_state": "READ_ONLY_SCOPE_PENDING",
  "effect_class": "READ_ONLY_PROBE",
  "effect_key": "R15_COVERAGE",
  "needed_fields": [
    "subject_ref",
    "source_hash",
    "read_scope",
    "owner",
    "observation_time"
  ],
  "operation": "READ ONLY exact baseline_denominator source/host probe; no WorkOrder issue, no ECP, no rollback token",
  "permission": "NONE_READ_ONLY",
  "readback_fields": [
    "949_ids",
    "18_families",
    "required",
    "conditional",
    "deferred",
    "owners",
    "no_effect_witness"
  ],
  "schema": "B1.PD.EFFECT_SLOT@r3",
  "slot_id": "OBS-B1-B9"
}
```
**個別 NEG**：missing ID or generic proxy pass -> R15_DENOMINATOR_SHRINK; alias and stale observations must close without world mutation。`OBS-B1-B9` 產生獨立 `operation_id:OBS-B1-B9`、`RAW:OBS-B1-B9`、`OR:OBS-B1-B9`；只允許事前 hash 相同且合法 dependency 的上游 receipt，不可當作自己的 effect receipt。
**閉合條件**：Source→PI-B1-B9→OBS-B1-B9→只一 ECP 或 NO_EFFECT→`TQ-CHILD-OBS-B1-B9-POS/NEG/EDGE/SEC`→checker。Missing current binding ⇒ `HOLD`，不得把本 schema 範本稱為 issued WorkOrder。

### PD-22｜WO-B1-C1 — FABRIC_PROMOTION / HOST_OPERATIONS

**原 r2 段落位置**：L555；**需求 Owner**：Fabric Activation Owner；domain invariant：independent stage approval; active and loaded exact digest; consumer projection ACK。
**作用程序**：Fabric Owner stage policy+approval -> native activate -> independent active/loaded SHA reader -> rollback to previous generation。
```json
{
  "atom": "B1-C1",
  "cross_effect_receipt_reuse": false,
  "current_binding_state": "HOLD_PENDING_TRUE_OWNER_AND_HOST",
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "FABRIC_PROMOTION",
  "needed_fields": [
    "subject_sha",
    "active_policy_epoch",
    "issuer_identity",
    "token_ref",
    "operation_id",
    "nonce",
    "ttl",
    "host_id",
    "expected_prestate_sha"
  ],
  "operation": "Fabric Owner stage policy+approval -> native activate -> independent active/loaded SHA reader -> rollback to previous generation",
  "permission": "OWNER_BOUND_TOKEN_REQUIRED",
  "readback_fields": [
    "approved_stage",
    "active_policy",
    "loaded_sha",
    "consumer_trace",
    "rollback",
    "native_event_id",
    "operation_id",
    "effect_postimage_sha",
    "evidence_ref"
  ],
  "schema": "B1.PD.EFFECT_SLOT@r3",
  "slot_id": "WO-B1-C1"
}
```
**個別 NEG**：stage mistaken as active or missing consumer -> FABRIC_LOADED_ABSENT; expired/mismatched token or unknown effect -> NACK/RECONCILE。`WO-B1-C1` 產生獨立 `operation_id:WO-B1-C1`、`RAW:WO-B1-C1`、`OR:WO-B1-C1`；只允許事前 hash 相同且合法 dependency 的上游 receipt，不可當作自己的 effect receipt。
**閉合條件**：Source→PI-B1-C1→WO-B1-C1→只一 ECP 或 NO_EFFECT→`TQ-CHILD-WO-B1-C1-POS/NEG/EDGE/SEC`→checker。Missing current binding ⇒ `HOLD`，不得把本 schema 範本稱為 issued WorkOrder。

### PD-23｜WO-B1-C2 — HGK_GWO / HOST_OPERATIONS

**原 r2 段落位置**：L563；**需求 Owner**：HGK Runtime Owner；domain invariant：true SBL entry -> native HGK issuer -> Hermes lease -> reversible observable result。
**作用程序**：SBL real entry -> HGK typed request -> native issue+durable queue -> Hermes worker outcome -> independent readback。
```json
{
  "atom": "B1-C2",
  "cross_effect_receipt_reuse": false,
  "current_binding_state": "HOLD_PENDING_TRUE_OWNER_AND_HOST",
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "HGK_GWO",
  "needed_fields": [
    "subject_sha",
    "active_policy_epoch",
    "issuer_identity",
    "token_ref",
    "operation_id",
    "nonce",
    "ttl",
    "host_id",
    "expected_prestate_sha"
  ],
  "operation": "SBL real entry -> HGK typed request -> native issue+durable queue -> Hermes worker outcome -> independent readback",
  "permission": "OWNER_BOUND_TOKEN_REQUIRED",
  "readback_fields": [
    "sbl_start",
    "issued_wo",
    "issuer",
    "lease",
    "worker_receipt",
    "readback",
    "native_event_id",
    "operation_id",
    "effect_postimage_sha",
    "evidence_ref"
  ],
  "schema": "B1.PD.EFFECT_SLOT@r3",
  "slot_id": "WO-B1-C2"
}
```
**個別 NEG**：ghost worker/forged permit -> GWO_HGK_NOT_NATIVE; expired/mismatched token or unknown effect -> NACK/RECONCILE。`WO-B1-C2` 產生獨立 `operation_id:WO-B1-C2`、`RAW:WO-B1-C2`、`OR:WO-B1-C2`；只允許事前 hash 相同且合法 dependency 的上游 receipt，不可當作自己的 effect receipt。
**閉合條件**：Source→PI-B1-C2→WO-B1-C2→只一 ECP 或 NO_EFFECT→`TQ-CHILD-WO-B1-C2-POS/NEG/EDGE/SEC`→checker。Missing current binding ⇒ `HOLD`，不得把本 schema 範本稱為 issued WorkOrder。

### PD-24｜WO-B1-C3-OPS — SBL_GWO__INSTALL / HOST_OPERATIONS

**原 r2 段落位置**：L571；**需求 Owner**：SBL Product/User Owner；domain invariant：separate Host install and USER effects with independent readbacks。
**作用程序**：install allowed SBL stack in isolated root -> doctor -> status -> uninstall+residue readback。
```json
{
  "atom": "B1-C3",
  "cross_effect_receipt_reuse": false,
  "current_binding_state": "HOLD_PENDING_TRUE_OWNER_AND_HOST",
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "SBL_GWO__INSTALL",
  "needed_fields": [
    "subject_sha",
    "active_policy_epoch",
    "issuer_identity",
    "token_ref",
    "operation_id",
    "nonce",
    "ttl",
    "host_id",
    "expected_prestate_sha"
  ],
  "operation": "install allowed SBL stack in isolated root -> doctor -> status -> uninstall+residue readback",
  "permission": "OWNER_BOUND_TOKEN_REQUIRED",
  "readback_fields": [
    "sbl_entry",
    "stack_install",
    "consent",
    "todo_add",
    "list",
    "delete",
    "uninstall",
    "native_event_id",
    "operation_id",
    "effect_postimage_sha",
    "evidence_ref"
  ],
  "schema": "B1.PD.EFFECT_SLOT@r3",
  "slot_id": "WO-B1-C3-OPS"
}
```
**個別 NEG**：install count used as add success -> GWO_SBL_USER_STATE_UNPROVEN; expired/mismatched token or unknown effect -> NACK/RECONCILE。`WO-B1-C3-OPS` 產生獨立 `operation_id:WO-B1-C3-OPS`、`RAW:WO-B1-C3-OPS`、`OR:WO-B1-C3-OPS`；只允許事前 hash 相同且合法 dependency 的上游 receipt，不可當作自己的 effect receipt。
**閉合條件**：Source→PI-B1-C3→WO-B1-C3-OPS→只一 ECP 或 NO_EFFECT→`TQ-CHILD-WO-B1-C3-OPS-POS/NEG/EDGE/SEC`→checker。Missing current binding ⇒ `HOLD`，不得把本 schema 範本稱為 issued WorkOrder。

### PD-25｜WO-B1-C3-USER — SBL_GWO__USER / USER_DATA_EFFECT

**原 r2 段落位置**：L579；**需求 Owner**：SBL Product/User Owner；domain invariant：separate Host install and USER effects with independent readbacks。
**作用程序**：SBL existing sbl-todo --data-dir <isolated> init/add/list/remove --id <ACTUAL_TASK_ID>; user consent and separate USER issuer decision, no OPS/DEV ECP。
```json
{
  "atom": "B1-C3",
  "cross_effect_receipt_reuse": false,
  "current_binding_state": "HOLD_PENDING_TRUE_OWNER_AND_HOST",
  "effect_class": "USER_DATA_EFFECT",
  "effect_key": "SBL_GWO__USER",
  "needed_fields": [
    "consenting_principal",
    "isolated_data_dir",
    "sbl_todo_binary_sha",
    "user_effect_issuer_ref",
    "record_id",
    "prestate_snapshot",
    "consent_scope"
  ],
  "operation": "SBL existing sbl-todo --data-dir <isolated> init/add/list/remove --id <ACTUAL_TASK_ID>; user consent and separate USER issuer decision, no OPS/DEV ECP",
  "permission": "USER_CONSENT_AND_USER_ISSUER",
  "readback_fields": [
    "task_id",
    "add_ack",
    "list_json",
    "delete_ack",
    "record_version",
    "uninstall_residue"
  ],
  "schema": "B1.PD.EFFECT_SLOT@r3",
  "slot_id": "WO-B1-C3-USER"
}
```
**個別 NEG**：missing user consent/issuer, wrong data_dir, duplicated id → no effect / distinct NoFitReceipt。`WO-B1-C3-USER` 產生獨立 `operation_id:WO-B1-C3-USER`、`RAW:WO-B1-C3-USER`、`OR:WO-B1-C3-USER`；只允許事前 hash 相同且合法 dependency 的上游 receipt，不可當作自己的 effect receipt。
**閉合條件**：Source→PI-B1-C3→WO-B1-C3-USER→只一 ECP 或 NO_EFFECT→`TQ-CHILD-WO-B1-C3-USER-POS/NEG/EDGE/SEC`→checker。Missing current binding ⇒ `HOLD`，不得把本 schema 範本稱為 issued WorkOrder。

### PD-26｜WO-B1-C4 — EXTERNAL_GRANT / HOST_OPERATIONS

**原 r2 段落位置**：L587；**需求 Owner**：External Delegation Owner；domain invariant：bounded external grant and no residual capability on revoke。
**作用程序**：grant scoped principal with TTL and nonce -> revoke -> check post-revoke rejection and reconcile in-flight。
```json
{
  "atom": "B1-C4",
  "cross_effect_receipt_reuse": false,
  "current_binding_state": "HOLD_PENDING_TRUE_OWNER_AND_HOST",
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "EXTERNAL_GRANT",
  "needed_fields": [
    "subject_sha",
    "active_policy_epoch",
    "issuer_identity",
    "token_ref",
    "operation_id",
    "nonce",
    "ttl",
    "host_id",
    "expected_prestate_sha"
  ],
  "operation": "grant scoped principal with TTL and nonce -> revoke -> check post-revoke rejection and reconcile in-flight",
  "permission": "OWNER_BOUND_TOKEN_REQUIRED",
  "readback_fields": [
    "owner_scope",
    "ttl",
    "principal",
    "revocation",
    "zero_scope_escape",
    "native_event_id",
    "operation_id",
    "effect_postimage_sha",
    "evidence_ref"
  ],
  "schema": "B1.PD.EFFECT_SLOT@r3",
  "slot_id": "WO-B1-C4"
}
```
**個別 NEG**：scope expansion -> EXTERNAL_SCOPE_ESCAPED; expired/mismatched token or unknown effect -> NACK/RECONCILE。`WO-B1-C4` 產生獨立 `operation_id:WO-B1-C4`、`RAW:WO-B1-C4`、`OR:WO-B1-C4`；只允許事前 hash 相同且合法 dependency 的上游 receipt，不可當作自己的 effect receipt。
**閉合條件**：Source→PI-B1-C4→WO-B1-C4→只一 ECP 或 NO_EFFECT→`TQ-CHILD-WO-B1-C4-POS/NEG/EDGE/SEC`→checker。Missing current binding ⇒ `HOLD`，不得把本 schema 範本稱為 issued WorkOrder。

### PD-27｜WO-B1-C5 — CODEX_MINPATCH / REPOSITORY_WRITE

**原 r2 段落位置**：L595；**需求 Owner**：Codex Maker + Dev Owner；domain invariant：only affected files changed and full regression independent。
**作用程序**：Codex bounded patch ONLY for CODEX_MINPATCH: identify actual import/callsite; freeze preimage and red test; scoped source diff; green+negative+rollback。
```json
{
  "atom": "B1-C5",
  "cross_effect_receipt_reuse": false,
  "current_binding_state": "HOLD_PENDING_TRUE_OWNER_AND_HOST",
  "effect_class": "REPOSITORY_WRITE",
  "effect_key": "CODEX_MINPATCH",
  "needed_fields": [
    "real_root",
    "git_head",
    "status_porcelain_z",
    "writable_scope",
    "preimage_sha",
    "red_test",
    "candidate_sha",
    "authorization_ref"
  ],
  "operation": "Codex bounded patch ONLY for CODEX_MINPATCH: identify actual import/callsite; freeze preimage and red test; scoped source diff; green+negative+rollback",
  "permission": "REPO_WRITER_SCOPE",
  "readback_fields": [
    "git_head_after",
    "changed_paths",
    "prepost_sha",
    "red_green_receipts",
    "rollback_readback"
  ],
  "schema": "B1.PD.EFFECT_SLOT@r3",
  "slot_id": "WO-B1-C5"
}
```
**個別 NEG**：write out of root, stale HEAD, changed untracked, or no preimage → deny; rollback only approved changed paths。`WO-B1-C5` 產生獨立 `operation_id:WO-B1-C5`、`RAW:WO-B1-C5`、`OR:WO-B1-C5`；只允許事前 hash 相同且合法 dependency 的上游 receipt，不可當作自己的 effect receipt。
**閉合條件**：Source→PI-B1-C5→WO-B1-C5→只一 ECP 或 NO_EFFECT→`TQ-CHILD-WO-B1-C5-POS/NEG/EDGE/SEC`→checker。Missing current binding ⇒ `HOLD`，不得把本 schema 範本稱為 issued WorkOrder。

### PD-28｜WO-B1-C6 — REVOKE_RACE / HOST_OPERATIONS

**原 r2 段落位置**：L603；**需求 Owner**：Revoke/Effect Owner；domain invariant：post-revoke use fails before spawn; existing effects reconciled。
**作用程序**：revoke current grant -> attempt old token -> ensure zero new spawn and record denied native event。
```json
{
  "atom": "B1-C6",
  "cross_effect_receipt_reuse": false,
  "current_binding_state": "HOLD_PENDING_TRUE_OWNER_AND_HOST",
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "REVOKE_RACE",
  "needed_fields": [
    "subject_sha",
    "active_policy_epoch",
    "issuer_identity",
    "token_ref",
    "operation_id",
    "nonce",
    "ttl",
    "host_id",
    "expected_prestate_sha"
  ],
  "operation": "revoke current grant -> attempt old token -> ensure zero new spawn and record denied native event",
  "permission": "OWNER_BOUND_TOKEN_REQUIRED",
  "readback_fields": [
    "old_nonce",
    "revocation_epoch",
    "attempt_after_revoke",
    "denied_effect",
    "native_event_id",
    "operation_id",
    "effect_postimage_sha",
    "evidence_ref"
  ],
  "schema": "B1.PD.EFFECT_SLOT@r3",
  "slot_id": "WO-B1-C6"
}
```
**個別 NEG**：reused token after revoke -> REVOKED_TOKEN_REPLAY; expired/mismatched token or unknown effect -> NACK/RECONCILE。`WO-B1-C6` 產生獨立 `operation_id:WO-B1-C6`、`RAW:WO-B1-C6`、`OR:WO-B1-C6`；只允許事前 hash 相同且合法 dependency 的上游 receipt，不可當作自己的 effect receipt。
**閉合條件**：Source→PI-B1-C6→WO-B1-C6→只一 ECP 或 NO_EFFECT→`TQ-CHILD-WO-B1-C6-POS/NEG/EDGE/SEC`→checker。Missing current binding ⇒ `HOLD`，不得把本 schema 範本稱為 issued WorkOrder。

### PD-29｜OBS-B1-C7 — FOUR_LAYER_ID / READ_ONLY_PROBE

**原 r2 段落位置**：L611；**需求 Owner**：Native Loader Owner；domain invariant：all four identity layers tied to same subject, not merely file on disk。
**作用程序**：READ ONLY exact loaded_identity source/host probe; no WorkOrder issue, no ECP, no rollback token。
```json
{
  "atom": "B1-C7",
  "cross_effect_receipt_reuse": false,
  "current_binding_state": "READ_ONLY_SCOPE_PENDING",
  "effect_class": "READ_ONLY_PROBE",
  "effect_key": "FOUR_LAYER_ID",
  "needed_fields": [
    "subject_ref",
    "source_hash",
    "read_scope",
    "owner",
    "observation_time"
  ],
  "operation": "READ ONLY exact loaded_identity source/host probe; no WorkOrder issue, no ECP, no rollback token",
  "permission": "NONE_READ_ONLY",
  "readback_fields": [
    "source_sha",
    "installed_binary_sha",
    "host_loaded_sha",
    "served_model",
    "policy_epoch",
    "no_effect_witness"
  ],
  "schema": "B1.PD.EFFECT_SLOT@r3",
  "slot_id": "OBS-B1-C7"
}
```
**個別 NEG**：green patch with stale loaded binary -> LOADED_BINARY_MISMATCH; alias and stale observations must close without world mutation。`OBS-B1-C7` 產生獨立 `operation_id:OBS-B1-C7`、`RAW:OBS-B1-C7`、`OR:OBS-B1-C7`；只允許事前 hash 相同且合法 dependency 的上游 receipt，不可當作自己的 effect receipt。
**閉合條件**：Source→PI-B1-C7→OBS-B1-C7→只一 ECP 或 NO_EFFECT→`TQ-CHILD-OBS-B1-C7-POS/NEG/EDGE/SEC`→checker。Missing current binding ⇒ `HOLD`，不得把本 schema 範本稱為 issued WorkOrder。

### PD-30｜WO-B1-C8 — NATIVE_SUCCESSOR / HOST_OPERATIONS

**原 r2 段落位置**：L616；**需求 Owner**：Hermes Continuation Owner；domain invariant：fresh separate session native trigger progresses after external account revoked。
**作用程序**：revoke external helper -> separate session native issuer advances next WO -> ledger readback。
```json
{
  "atom": "B1-C8",
  "cross_effect_receipt_reuse": false,
  "current_binding_state": "HOLD_PENDING_TRUE_OWNER_AND_HOST",
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "NATIVE_SUCCESSOR",
  "needed_fields": [
    "subject_sha",
    "active_policy_epoch",
    "issuer_identity",
    "token_ref",
    "operation_id",
    "nonce",
    "ttl",
    "host_id",
    "expected_prestate_sha"
  ],
  "operation": "revoke external helper -> separate session native issuer advances next WO -> ledger readback",
  "permission": "OWNER_BOUND_TOKEN_REQUIRED",
  "readback_fields": [
    "external_stop",
    "ledger_cursor",
    "issuer",
    "successor_wo",
    "native_origin",
    "native_event_id",
    "operation_id",
    "effect_postimage_sha",
    "evidence_ref"
  ],
  "schema": "B1.PD.EFFECT_SLOT@r3",
  "slot_id": "WO-B1-C8"
}
```
**個別 NEG**：successor still external-triggered -> NATIVE_SUCCESSOR_NOT_PROVEN; expired/mismatched token or unknown effect -> NACK/RECONCILE。`WO-B1-C8` 產生獨立 `operation_id:WO-B1-C8`、`RAW:WO-B1-C8`、`OR:WO-B1-C8`；只允許事前 hash 相同且合法 dependency 的上游 receipt，不可當作自己的 effect receipt。
**閉合條件**：Source→PI-B1-C8→WO-B1-C8→只一 ECP 或 NO_EFFECT→`TQ-CHILD-WO-B1-C8-POS/NEG/EDGE/SEC`→checker。Missing current binding ⇒ `HOLD`，不得把本 schema 範本稱為 issued WorkOrder。

### PD-31｜OBS-B1-C9 — TRIPLE_GWO / READ_ONLY_PROBE

**原 r2 段落位置**：L624；**需求 Owner**：Independent AO + 3 Domain Owners；domain invariant：3 different domain receipts, all same intended crosswalk, not aliases。
**作用程序**：READ ONLY exact triple_golden_join source/host probe; no WorkOrder issue, no ECP, no rollback token。
```json
{
  "atom": "B1-C9",
  "cross_effect_receipt_reuse": false,
  "current_binding_state": "READ_ONLY_SCOPE_PENDING",
  "effect_class": "READ_ONLY_PROBE",
  "effect_key": "TRIPLE_GWO",
  "needed_fields": [
    "subject_ref",
    "source_hash",
    "read_scope",
    "owner",
    "observation_time"
  ],
  "operation": "READ ONLY exact triple_golden_join source/host probe; no WorkOrder issue, no ECP, no rollback token",
  "permission": "NONE_READ_ONLY",
  "readback_fields": [
    "fabric_receipt",
    "hgk_receipt",
    "sbl_receipt",
    "revoke_receipt",
    "join_subject",
    "no_effect_witness"
  ],
  "schema": "B1.PD.EFFECT_SLOT@r3",
  "slot_id": "OBS-B1-C9"
}
```
**個別 NEG**：same receipt reused -> GWO_RECEIPT_ALIAS; alias and stale observations must close without world mutation。`OBS-B1-C9` 產生獨立 `operation_id:OBS-B1-C9`、`RAW:OBS-B1-C9`、`OR:OBS-B1-C9`；只允許事前 hash 相同且合法 dependency 的上游 receipt，不可當作自己的 effect receipt。
**閉合條件**：Source→PI-B1-C9→OBS-B1-C9→只一 ECP 或 NO_EFFECT→`TQ-CHILD-OBS-B1-C9-POS/NEG/EDGE/SEC`→checker。Missing current binding ⇒ `HOLD`，不得把本 schema 範本稱為 issued WorkOrder。

## 3. 31 張卡逐卡 Mandatory Method Policy slot

| WO/OBS | 現役 policy snapshot | KANBAN | SWARM | GSTACK | OPENSPEC | CODEX |
|---|---|---|---|---|---|---|
| `OBS-B1-A1` | `HOLD_POLICY_EPOCH` | evaluate(actual_policy,`OBS-B1-A1`) | evaluate(actual_policy,`OBS-B1-A1`) | evaluate(actual_policy,`OBS-B1-A1`) | evaluate(actual_policy,`OBS-B1-A1`) | evaluate(actual_policy,`OBS-B1-A1`) |
| `WO-B1-A2` | `HOLD_POLICY_EPOCH` | evaluate(actual_policy,`WO-B1-A2`) | evaluate(actual_policy,`WO-B1-A2`) | evaluate(actual_policy,`WO-B1-A2`) | evaluate(actual_policy,`WO-B1-A2`) | evaluate(actual_policy,`WO-B1-A2`) |
| `WO-B1-A3` | `HOLD_POLICY_EPOCH` | evaluate(actual_policy,`WO-B1-A3`) | evaluate(actual_policy,`WO-B1-A3`) | evaluate(actual_policy,`WO-B1-A3`) | evaluate(actual_policy,`WO-B1-A3`) | evaluate(actual_policy,`WO-B1-A3`) |
| `WO-B1-A4` | `HOLD_POLICY_EPOCH` | evaluate(actual_policy,`WO-B1-A4`) | evaluate(actual_policy,`WO-B1-A4`) | evaluate(actual_policy,`WO-B1-A4`) | evaluate(actual_policy,`WO-B1-A4`) | evaluate(actual_policy,`WO-B1-A4`) |
| `OBS-B1-A5` | `HOLD_POLICY_EPOCH` | evaluate(actual_policy,`OBS-B1-A5`) | evaluate(actual_policy,`OBS-B1-A5`) | evaluate(actual_policy,`OBS-B1-A5`) | evaluate(actual_policy,`OBS-B1-A5`) | evaluate(actual_policy,`OBS-B1-A5`) |
| `WO-B1-A6` | `HOLD_POLICY_EPOCH` | evaluate(actual_policy,`WO-B1-A6`) | evaluate(actual_policy,`WO-B1-A6`) | evaluate(actual_policy,`WO-B1-A6`) | evaluate(actual_policy,`WO-B1-A6`) | evaluate(actual_policy,`WO-B1-A6`) |
| `OBS-B1-A7` | `HOLD_POLICY_EPOCH` | evaluate(actual_policy,`OBS-B1-A7`) | evaluate(actual_policy,`OBS-B1-A7`) | evaluate(actual_policy,`OBS-B1-A7`) | evaluate(actual_policy,`OBS-B1-A7`) | evaluate(actual_policy,`OBS-B1-A7`) |
| `WO-B1-A8` | `HOLD_POLICY_EPOCH` | evaluate(actual_policy,`WO-B1-A8`) | evaluate(actual_policy,`WO-B1-A8`) | evaluate(actual_policy,`WO-B1-A8`) | evaluate(actual_policy,`WO-B1-A8`) | evaluate(actual_policy,`WO-B1-A8`) |
| `WO-B1-A9` | `HOLD_POLICY_EPOCH` | evaluate(actual_policy,`WO-B1-A9`) | evaluate(actual_policy,`WO-B1-A9`) | evaluate(actual_policy,`WO-B1-A9`) | evaluate(actual_policy,`WO-B1-A9`) | evaluate(actual_policy,`WO-B1-A9`) |
| `OBS-B1-B1` | `HOLD_POLICY_EPOCH` | evaluate(actual_policy,`OBS-B1-B1`) | evaluate(actual_policy,`OBS-B1-B1`) | evaluate(actual_policy,`OBS-B1-B1`) | evaluate(actual_policy,`OBS-B1-B1`) | evaluate(actual_policy,`OBS-B1-B1`) |
| `OBS-B1-B2` | `HOLD_POLICY_EPOCH` | evaluate(actual_policy,`OBS-B1-B2`) | evaluate(actual_policy,`OBS-B1-B2`) | evaluate(actual_policy,`OBS-B1-B2`) | evaluate(actual_policy,`OBS-B1-B2`) | evaluate(actual_policy,`OBS-B1-B2`) |
| `WO-B1-B3-DEV` | `HOLD_POLICY_EPOCH` | evaluate(actual_policy,`WO-B1-B3-DEV`) | evaluate(actual_policy,`WO-B1-B3-DEV`) | evaluate(actual_policy,`WO-B1-B3-DEV`) | evaluate(actual_policy,`WO-B1-B3-DEV`) | evaluate(actual_policy,`WO-B1-B3-DEV`) |
| `WO-B1-B3-OPS` | `HOLD_POLICY_EPOCH` | evaluate(actual_policy,`WO-B1-B3-OPS`) | evaluate(actual_policy,`WO-B1-B3-OPS`) | evaluate(actual_policy,`WO-B1-B3-OPS`) | evaluate(actual_policy,`WO-B1-B3-OPS`) | evaluate(actual_policy,`WO-B1-B3-OPS`) |
| `WO-B1-B4-DEV` | `HOLD_POLICY_EPOCH` | evaluate(actual_policy,`WO-B1-B4-DEV`) | evaluate(actual_policy,`WO-B1-B4-DEV`) | evaluate(actual_policy,`WO-B1-B4-DEV`) | evaluate(actual_policy,`WO-B1-B4-DEV`) | evaluate(actual_policy,`WO-B1-B4-DEV`) |
| `WO-B1-B4-OPS` | `HOLD_POLICY_EPOCH` | evaluate(actual_policy,`WO-B1-B4-OPS`) | evaluate(actual_policy,`WO-B1-B4-OPS`) | evaluate(actual_policy,`WO-B1-B4-OPS`) | evaluate(actual_policy,`WO-B1-B4-OPS`) | evaluate(actual_policy,`WO-B1-B4-OPS`) |
| `WO-B1-B5-DEV` | `HOLD_POLICY_EPOCH` | evaluate(actual_policy,`WO-B1-B5-DEV`) | evaluate(actual_policy,`WO-B1-B5-DEV`) | evaluate(actual_policy,`WO-B1-B5-DEV`) | evaluate(actual_policy,`WO-B1-B5-DEV`) | evaluate(actual_policy,`WO-B1-B5-DEV`) |
| `WO-B1-B5-OPS` | `HOLD_POLICY_EPOCH` | evaluate(actual_policy,`WO-B1-B5-OPS`) | evaluate(actual_policy,`WO-B1-B5-OPS`) | evaluate(actual_policy,`WO-B1-B5-OPS`) | evaluate(actual_policy,`WO-B1-B5-OPS`) | evaluate(actual_policy,`WO-B1-B5-OPS`) |
| `WO-B1-B6-USER` | `HOLD_POLICY_EPOCH` | evaluate(actual_policy,`WO-B1-B6-USER`) | evaluate(actual_policy,`WO-B1-B6-USER`) | evaluate(actual_policy,`WO-B1-B6-USER`) | evaluate(actual_policy,`WO-B1-B6-USER`) | evaluate(actual_policy,`WO-B1-B6-USER`) |
| `OBS-B1-B7` | `HOLD_POLICY_EPOCH` | evaluate(actual_policy,`OBS-B1-B7`) | evaluate(actual_policy,`OBS-B1-B7`) | evaluate(actual_policy,`OBS-B1-B7`) | evaluate(actual_policy,`OBS-B1-B7`) | evaluate(actual_policy,`OBS-B1-B7`) |
| `OBS-B1-B8` | `HOLD_POLICY_EPOCH` | evaluate(actual_policy,`OBS-B1-B8`) | evaluate(actual_policy,`OBS-B1-B8`) | evaluate(actual_policy,`OBS-B1-B8`) | evaluate(actual_policy,`OBS-B1-B8`) | evaluate(actual_policy,`OBS-B1-B8`) |
| `OBS-B1-B9` | `HOLD_POLICY_EPOCH` | evaluate(actual_policy,`OBS-B1-B9`) | evaluate(actual_policy,`OBS-B1-B9`) | evaluate(actual_policy,`OBS-B1-B9`) | evaluate(actual_policy,`OBS-B1-B9`) | evaluate(actual_policy,`OBS-B1-B9`) |
| `WO-B1-C1` | `HOLD_POLICY_EPOCH` | evaluate(actual_policy,`WO-B1-C1`) | evaluate(actual_policy,`WO-B1-C1`) | evaluate(actual_policy,`WO-B1-C1`) | evaluate(actual_policy,`WO-B1-C1`) | evaluate(actual_policy,`WO-B1-C1`) |
| `WO-B1-C2` | `HOLD_POLICY_EPOCH` | evaluate(actual_policy,`WO-B1-C2`) | evaluate(actual_policy,`WO-B1-C2`) | evaluate(actual_policy,`WO-B1-C2`) | evaluate(actual_policy,`WO-B1-C2`) | evaluate(actual_policy,`WO-B1-C2`) |
| `WO-B1-C3-OPS` | `HOLD_POLICY_EPOCH` | evaluate(actual_policy,`WO-B1-C3-OPS`) | evaluate(actual_policy,`WO-B1-C3-OPS`) | evaluate(actual_policy,`WO-B1-C3-OPS`) | evaluate(actual_policy,`WO-B1-C3-OPS`) | evaluate(actual_policy,`WO-B1-C3-OPS`) |
| `WO-B1-C3-USER` | `HOLD_POLICY_EPOCH` | evaluate(actual_policy,`WO-B1-C3-USER`) | evaluate(actual_policy,`WO-B1-C3-USER`) | evaluate(actual_policy,`WO-B1-C3-USER`) | evaluate(actual_policy,`WO-B1-C3-USER`) | evaluate(actual_policy,`WO-B1-C3-USER`) |
| `WO-B1-C4` | `HOLD_POLICY_EPOCH` | evaluate(actual_policy,`WO-B1-C4`) | evaluate(actual_policy,`WO-B1-C4`) | evaluate(actual_policy,`WO-B1-C4`) | evaluate(actual_policy,`WO-B1-C4`) | evaluate(actual_policy,`WO-B1-C4`) |
| `WO-B1-C5` | `HOLD_POLICY_EPOCH` | evaluate(actual_policy,`WO-B1-C5`) | evaluate(actual_policy,`WO-B1-C5`) | evaluate(actual_policy,`WO-B1-C5`) | evaluate(actual_policy,`WO-B1-C5`) | evaluate(actual_policy,`WO-B1-C5`) |
| `WO-B1-C6` | `HOLD_POLICY_EPOCH` | evaluate(actual_policy,`WO-B1-C6`) | evaluate(actual_policy,`WO-B1-C6`) | evaluate(actual_policy,`WO-B1-C6`) | evaluate(actual_policy,`WO-B1-C6`) | evaluate(actual_policy,`WO-B1-C6`) |
| `OBS-B1-C7` | `HOLD_POLICY_EPOCH` | evaluate(actual_policy,`OBS-B1-C7`) | evaluate(actual_policy,`OBS-B1-C7`) | evaluate(actual_policy,`OBS-B1-C7`) | evaluate(actual_policy,`OBS-B1-C7`) | evaluate(actual_policy,`OBS-B1-C7`) |
| `WO-B1-C8` | `HOLD_POLICY_EPOCH` | evaluate(actual_policy,`WO-B1-C8`) | evaluate(actual_policy,`WO-B1-C8`) | evaluate(actual_policy,`WO-B1-C8`) | evaluate(actual_policy,`WO-B1-C8`) | evaluate(actual_policy,`WO-B1-C8`) |
| `OBS-B1-C9` | `HOLD_POLICY_EPOCH` | evaluate(actual_policy,`OBS-B1-C9`) | evaluate(actual_policy,`OBS-B1-C9`) | evaluate(actual_policy,`OBS-B1-C9`) | evaluate(actual_policy,`OBS-B1-C9`) | evaluate(actual_policy,`OBS-B1-C9`) |
