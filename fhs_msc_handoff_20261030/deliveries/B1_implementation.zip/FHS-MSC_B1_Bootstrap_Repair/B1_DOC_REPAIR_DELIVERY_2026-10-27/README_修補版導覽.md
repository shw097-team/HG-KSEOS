# B1 DOC-00～08 修補版導覽

RESULT: PASS（文件）／DOC_REPAIR_COMPLETE；B1 Native Acceptance 尚未完成。唯一新版：PKG/ 九個完整 Markdown，版本 `2026-10-27_r3_DOC_REPAIR_CANDIDATE_1`。九冊不是摘要／補丁清單；原 27/31/120/124/38/949/192/81/3 GWO 身份及實質定義保留。

法位：OWNER_PREAUTHORIZED_B1_DESIGN_USE / FORMAL_NATIVE_NOT_GRANTED。本次 OWNER 明確預授權寫集與候選設計使用；不取代 Domain ratification／SourceFreeze／PIPD Admission／HGK Permit／OS privilege／User Consent／獨立 Checker／Native Release。

交付副本目標：`C:\Projects\Agent_Workspace\知識庫\實作相關DOC\Fabric vNext\Semantic World OS Fabric\SBL_PIPD\FHS-MSC\B1\B1_DOC_REPAIR_DELIVERY_2026-10-27`。來源原件仍原位保留，BASELINE/*.source 為相同位元備份；來源版本由內文 family/version/lineage＋SHA 核定，整合版只作重複載體。

| DOC | 完整新版 |
|---|---|
| 00 | [FHS_MSC_B1_PIPD_LS_PKG_00_GOVERNANCE_AND_CONTROL.md](PKG/FHS_MSC_B1_PIPD_LS_PKG_00_GOVERNANCE_AND_CONTROL.md) |
| 01 | [FHS_MSC_B1_PIPD_LS_PKG_01_DOC_B1_PI.md](PKG/FHS_MSC_B1_PIPD_LS_PKG_01_DOC_B1_PI.md) |
| 02 | [FHS_MSC_B1_PIPD_LS_PKG_02_DOC_B1_PD.md](PKG/FHS_MSC_B1_PIPD_LS_PKG_02_DOC_B1_PD.md) |
| 03 | [FHS_MSC_B1_PIPD_LS_PKG_03_DOC_B1_OPS_ECP.md](PKG/FHS_MSC_B1_PIPD_LS_PKG_03_DOC_B1_OPS_ECP.md) |
| 04 | [FHS_MSC_B1_PIPD_LS_PKG_04_DOC_B1_DEV_ECP.md](PKG/FHS_MSC_B1_PIPD_LS_PKG_04_DOC_B1_DEV_ECP.md) |
| 05 | [FHS_MSC_B1_PIPD_LS_PKG_05_DOC_B1_TQAEP.md](PKG/FHS_MSC_B1_PIPD_LS_PKG_05_DOC_B1_TQAEP.md) |
| 06 | [FHS_MSC_B1_PIPD_LS_PKG_06_PRODUCT_COVERAGE_AND_R15.md](PKG/FHS_MSC_B1_PIPD_LS_PKG_06_PRODUCT_COVERAGE_AND_R15.md) |
| 07 | [FHS_MSC_B1_PIPD_LS_PKG_07_NATIVE_TOOLCHAIN_EXACT_USAGE.md](PKG/FHS_MSC_B1_PIPD_LS_PKG_07_NATIVE_TOOLCHAIN_EXACT_USAGE.md) |
| 08 | [FHS_MSC_B1_PIPD_LS_PKG_08_GOLDEN_WORKORDERS_E2E.md](PKG/FHS_MSC_B1_PIPD_LS_PKG_08_GOLDEN_WORKORDERS_E2E.md) |

先讀 DOC-00 的作用域／Stop Rule，再按 DOC-02 原槽 locator 取受影原文。P0：00/02/08；P1：01/03/04/07；05/06 只新增薄型適用性與 verifier 必要修補，不重生成大表。

- [驗證與數量](VALIDATION_REPORT.md)：99/99 DOC/fixture PASS；28 Native NOT_RUN；PowerShell parse 2/2、Diff check 9/9。
- [原件／新版完整 SHA](SOURCE_AND_CANDIDATE_SHA.md)、[Source Manifest](SOURCE_SHA_MANIFEST.json)、[39 份來源比較](PLAN_39_SOURCE_COMPARISON.json)。
- [RCA 48/48](RCA_48_COVERAGE.md)：27 PATCHED、7 ALREADY_SATISFIED、14 OWNER_OR_NATIVE_DEPENDENCY；精確證據在 RCA_EVIDENCE.json。
- [修補裁決](CHANGES_AND_DECISIONS.md)、CHANGES.json、DIFF/FULL.diff：逐條前後 clause、scope/Owner/反例，及 metadata lineage。
- [未決 Owner/Native Gate](ISSUE_AND_CR_REGISTER.md)：Oracle、Profile、SBL 入口、DEV/Host/User 准入、Runner/Checker 及歷史兩份 raw 未驗證。
- [Hermes 下一合法工作](NEXT_B1_HERMES_HANDOFF.md)：OBS-B1-A1 合法唯讀先取當前真實 Scope/Root/SharedSpine/ABI；不造第二 Queue。
- [重跑說明](tests/README.md)、IDENTITY_INVENTORY.json、AUTHOR_SIDE_REVIEW.md。

FILE_SHA_MANIFEST.json 覆蓋封裝內每個工件（自身排除以免循環）。ZIP_CONTENTS.json 是預期清單；封裝後 ZIP_VERIFY_REPORT.json／ZIP_SHA256.txt 為外置 sidecar，逐檔讀回後產生，不回填 ZIP 或 manifest 造成循環。ZIP 中 PKG/*.md 恰九冊；其餘 Markdown 是導覽／證據／報告，不是新增冊。所有 Native 簽章／正式 Compiler／Runner/CI/loaded/served/效果實測都未執行；不得據此宣布 G-A/GWO/G-B 完成。
