from pathlib import Path
import re, json, hashlib, difflib, shutil, sys
import yaml

ROOT=Path(r'C:\Projects\Agent_Workspace\知識庫\實作相關DOC\Fabric vNext\Semantic World OS Fabric\SBL_PIPD\FHS-MSC\B1')
UP=ROOT.parent.parent
SRC=ROOT/'FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG'/'FHS_MSC_B1_PIPD_LS_PKG'
OUT=Path('outputs/B1_DOC_REPAIR_DELIVERY_2026-10-27').resolve()
PLAN=next(ROOT.rglob('FHS_MSC_B1_DOC00-08_Codex_High_Automation_Repair_Plan_v1_2026-10-27.md'))
COMMAND=next(ROOT.rglob('FHS_MSC_B1_Codex_Thin_Autonomous_DOC00-08_Repair_Command_2026-10-27.md'))
REV='2026-10-27_r3_DOC_REPAIR_CANDIDATE_1'
def digest(b): return hashlib.sha256(b).hexdigest()
def read(p): return p.read_text(encoding='utf-8-sig')
def write(p,s): p.parent.mkdir(parents=True,exist_ok=True); p.write_text(s,encoding='utf-8',newline='\n')
def dump(p,v): write(p,json.dumps(v,ensure_ascii=False,indent=2,default=str)+'\n')
def mdlink(i,anchor=''): return f'[{i:02d}]({files[i].name}{"#"+anchor if anchor else ""})'
files=sorted(SRC.glob('FHS_MSC_B1_PIPD_LS_PKG_0[0-8]_*.md'))
assert len(files)==9
base={i:read(p) for i,p in enumerate(files)}
changes=[]
def replace(i,old,new,reason,tests):
 assert base[i].count(old)==1,(i,old[:60],base[i].count(old))
 work[i]=work[i].replace(old,new,1)
 line=base[i][:base[i].index(old)].count('\n')+1
 changes.append(dict(doc=f'{i:02d}',kind='REPLACE',source_locator=dict(path=str(files[i]),sha256=digest(files[i].read_bytes()),line_start=line,line_end=line+old.count('\n')),old_clause=old,new_clause=new,reason=reason,test_case=tests,effect_scope='L0_DOCUMENT_CANDIDATE',owner='B1 OWNER preauthorization; Domain authority unchanged',adverse_effect='No runtime authority; affected ABI remains HOLD'))
work=base.copy()

snippets={
0:'''<a id="repair-control"></a>
## 本候選修訂：效力、單人 OWNER 與受影續工（RCA-01/03～09/19～21/24～31/38/41/43/47）

本次版本只在 B1 設計／施工候選包範圍承接 OWNER 一次性預授權：`OWNER_PREAUTHORIZED_B1_DESIGN_USE / FORMAL_NATIVE_NOT_GRANTED`。普通文件編修不以未發行 Native 工件自鎖；既有 Domain SSOT、現役 Policy、OS ACL 及真 PIPD Admission 仍優先。指揮 Prompt 為 `TASK_INSTRUCTION`，Knowledge Pack 為 SUPPORT，兩者都不能升格 Domain Canonical Writer。此節是原契約的適用性澄清，原 §4 G-A 六項與 G-B 全部保留。

| 層級 | 可做工作／必要條件 | 缺件處置 |
|---|---|---|
| L0 SOURCE/DESIGN | 合法文件讀寫、隔離靜態 fixture；本次 WriteSet 已授權 | 只停無權讀寫的實體路徑 |
| L1 BOOTSTRAP_DIAGNOSIS | 真 Read Scope、Root／currentness、OS 讀取權；零未准入副作用 | 受影 probe HOLD；不推論系統故障 |
| L2 BOUNDED_DEV_REPAIR | 真 RepoContext／HEAD／Dirty／WriteSet、有效 OWNER 授權、適用 DEV ECP／ExecutionAdmission | 無合法 DEV admission 則該 Repo 寫入 HOLD；L0/L1 可續 |
| L3 GOVERNED_EFFECT | 真 HGK Issuer／Receiver、EffectClass、Scope、Nonce、TTL、Revoke、ActivePolicy、適用 ECP；USER 另查 Consent | 缺真 Permit 必 NACK，零未授權效果 |
| L4 FORMAL_ACCEPTANCE | 真 SameSubject Raw、獨立 Principal／ACL／Key、正式 Owner Gate | 只可 PLANNED／NOT_RUN／HOLD |

`C0 SOURCE_EXISTS → C2 AUTHORITY_CONFLICT → C5 RUNTIME_CAPABILITY → EFFECT_ADMISSION → INDEPENDENT_ACCEPTANCE` 各自判定。`PL-003 ×2` 中未發行 Admission/SourceFreeze 與 Native TaskKind 是未來 runtime 輸出，不得偽作現存 required_source_families；真正缺少來源仍拒收。Native Effect 前仍須取得真 SourceFreeze、TaskKind 與 Admission。`PL-004` 的 Oracle 衝突見 DOC-01／07；文檔測試不能充作原 C0～C9 Compiler 的 `PROMPT_COMPILE_PASS`。

Standing Authorization 只繼承相同 mission、scope、effect_class、risk_ceiling、change_set 與有效期限；本次有效窗口為此文檔修補任務，不推定永久 TTL 或機器 Token。已授權同範圍工作不重問；新 protected key、提權、User Data、Source Owner 衝突、正式 Release 依各真權責 Gate。單一人類 OWNER 不要求第二人類，但 Maker／Signer／Checker 必是可查驗的技術職責；同 SID、共用 credential、Maker 可寫 Checker verdict/Trust Anchor 均不能證獨立。

`HOLD` 只沿真實 `depends_on` 消費邊傳遞；不得因 Issuer／Oracle 一項未綁而把不消費它的合法 OBS 或 DEV 全域 PARK。發現未知 ABI 時先做合法 Discovery；`NOT_RUN` 不是已證實 FAIL，歷史 HOLD 不得覆蓋當前 Host readback。沒有 READY 時可輸出 `PARKED_WAITING_FOR_TRIGGER`，附受影 ID／Owner／first_fail／喚醒條件；此為 partial，非 Mission PASS。

唯一 durable work authority 仍是 Hermes＋原 SharedSpine。`WORK_QUEUE.json`／todo／Execution Projection 僅唯讀可再生視圖；不得新增第二 Queue、Scheduler、Issuer、Policy DB 或 PIPD Compiler。CAS lease、fenced generation、Journal 及 world-state reconcile 保留；UNKNOWN_EFFECT 不得換 operation ID 盲重播。報告、Manifest、Seal 不控制停工；READY 或 RUNNING 非零時禁止 MISSION_COMPLETE。

以下純設計 predicate 可做隔離負例，不讀寫 Live SharedSpine、不產 Native PASS：

```python
def mission_completion(snapshot, native_gates):
    if not snapshot or snapshot.get('authority') != 'SharedSpine' or snapshot.get('fresh') is not True:
        return 'UNVERIFIED'
    counts=[snapshot.get(k) for k in ('ready','running','parked')]
    if any(type(v) is not int or v < 0 for v in counts):
        return 'UNVERIFIED'
    if counts[0] or counts[1]:
        return 'CONTINUE_LEGAL_READY'
    if counts[2]:
        return 'PARKED_WAITING_FOR_TRIGGER'
    required={'G_A','GWO_FABRIC','GWO_HGK','GWO_SBL','G_B'}
    if set(native_gates) != required or any(v is not True for v in native_gates.values()):
        return 'NATIVE_ACCEPTANCE_INCOMPLETE'
    return 'ELIGIBLE_FOR_FORMAL_OWNER_RELEASE_REVIEW'
```

合約僅在相同 Subject／Source SHA／Scope／Policy Epoch／ChangeSet 且原契約允許時複用；任一改變只對消費者重新資格化。使用單卡 context card：原 ID、受影 clause、准入、依賴、first_fail、repro、next_trigger；不把全產品清冊當工作佇列。`DOC_STATIC_PASS ≠ SOURCEFREEZE_ISSUED ≠ EXECUTION_ADMITTED ≠ HOST_LOADED ≠ MODEL_SERVED ≠ INDEPENDENT_PASS ≠ RELEASE`。
''',
1:'''<a id="repair-source-abi"></a>
## 本候選修訂：Source／Oracle／Profile 明確分層（RCA-01/02/12/34/46）

依 DOC-00 `repair-control` 分 C0 現存 Source、C2 authority conflict、C5 runtime readiness 及 L3 Effect Admission。27 `PI-B1-*` 維持原身分／順序與 SourceRef；原生五 REQ enum 不被 B1 Atom 取代。下方 Profile JSON 是已安裝 P4 input schema 的形狀，並非十二風險軸的完成評估。

Oracle Canonical Authoring Owner 為 **PIPD DOC-07**；已讀 P4 0.1.1 PI output schema 的 `acceptance.oracle_source` 仍固定 `DOC-03 DOMAIN_ORACLES`。記為 `CANONICAL_DOC07 + LEGACY_DOC03_ABI_CANDIDATE / CR-ORACLE-001_OPEN`。分支 A：PIPD Owner 提供可驗版本化 alias／adapter，包含 Writer 身分、來源 clause hash、schema digest、批准及正負 roundtrip，才可綁定；分支 B：無批准或 Writer／來源不符，`ORACLE_UNBOUND`，只 HOLD 消費此 Oracle 的正式編譯／ECP／TQAEP，不阻無關唯讀。不得由 B1 作者把兩字串直接認定同 Writer。

PIPD DOC-06 十二 calibrated complexity axes 與 P4 九個輸入 enum 為不同 schema。保留完整十二軸 level/rationale/evidence/veto、九軸選擇及版本化逐軸 loss map；`PROFILE_MAPPING_UNBOUND` 時不選較輕 Profile。分支 A：現役 Owner-approved resolver 可證所有風險／Safety Veto 不降級，才可產生正式 ProfileBinding；分支 B：缺映射、未知 veto、任一風險在投影消失即拒收受影映射。不可直接把十二軸塞入 strict P4 JSON，也不可刪三軸洗綠。

Model 邊界為三個實體 Lane `PLAN / EXECUTE / VERIFY_SECURITY`；TPM／Commander／Execute／Challenge 是角色配置，Pin／Pool／Session 是路由層，不創第四 Lane。每 Lane 真 request／Required／Served／PolicyEpoch／raw 分開讀回，Provider-off 不准靜默 fallback。R4 未實跑只記 NOT_RUN。
''',
2:'''<a id="repair-binding"></a>
## 本候選修訂：31 槽執行投影與受影准入（RCA-05/15/17/21/25/27）

本冊 §2 的 31 個完整 payload、Oracle、NEG、rollback 是原身分定義；分派函式只計算設計候選的 binding eligibility，不發 Token、不寫 Queue、不代表准入成功。READ_ONLY 的 `permission=NONE` 只指無 Native effect token，仍須合法 Read Scope。Repo 寫入要真 DEV admission；Host/User 不得借 RepoContext／DEV Token。

每槽之衍生投影欄位為 `slot_id, effect_class, source_ref, binding_required, depends_on, blocked_by, evidence_kind, next_action, policy_epoch, runtime_state`。原 ID／分類由 §2 的唯一 slot JSON 解析；隨包 EXECUTION_PROJECTION_CANDIDATE.json 含 31 筆完整 locator。本次 policy_epoch／actual_binding／SharedSpine 狀態均未讀回，保持 null／UNVERIFIED，禁止假造 READY。`depends_on=null` 表示待 discovery，與已證沒有依賴的 `[]` 不同。先做合法唯讀確認實際消費邊，僅該受影子圖 HOLD。

十 OBS、五 REPO、十四 HOST、兩 USER 不合併；`BLOCKED_NO_ISSUER` 只適用消費 Native Permit 的槽。R3/R4 沒有真合法 probe，狀態 NOT_RUN，不能寫 ACTIVATOR_FAILED／MODEL_SERVE_MISMATCH。當前政策強制方法仍須另做 DOC-00 resolver；binding eligibility 不繞過方法或獨立驗收。
''',
3:'''<a id="repair-ops-boundary"></a>
## 本候選修訂：Trust 接線、Risk 與重試邊界（RCA-06～11/14/17/29/33/37～39）

適用性依 DOC-00 L0～L4。普通文件與有准入的受限 DEV red→minimal patch→green 可反覆迭代；Native effect 仍 at-most-once，timeout／unknown 一律先 read-world-state/reconcile，補償須獨立 ECP／Permit，不重播 consumed nonce。ISSUER_UNBOUND 只停真消費 Issuer 的操作。

R1 Discovery 依序讀回真 `Trust Profile → Registry Resolver → Receiver imported origin`，記 Host／SID／key fingerprint／ACL／binary SHA／policy epoch／registry path 與 Owner 契約。`HGK_TRUST_PROFILE=user` 不是已存在的有效開關；缺真 ABI 不設臆造環境變數、不改 Trust Anchor。可用已授權 Standard User 做無副作用診斷；只有真高權限效果才要求其現役 OS Gate，不強迫所有工程 Administrator／LocalMachine。

若現役 Receiver 支援 Owner-approved User Trust，以實測的 Profile／Resolver／Receiver 一致性再進 effect；否則 `RECEIVER_NOT_LIVE / OWNER_OR_NATIVE_DEPENDENCY`，只停 R1 受影效果並開 Owner 決策。User-scope key 不等於高保證隔離；Maker 不能改 Trust Anchor 或 Checker verdict，Checker 要不同 principal UUID／credential、唯讀 ACL／獨立 key 的真證據，不以同 SID 三個 PID 或 DPAPI 自證。

每個 Host payload 保留獨立 Permit、preimage、operation、nonce、TTL、Revoke、Raw、readback、rollback。錯 key/token/scope/nonce/TTL/revoke 均 Native NACK／zero unauthorized delta。USER 的目的、Synthetic DataDir、保存與撤銷需獨立 Consent 及合法 User issuer；普通文件的預授權不涵蓋 add/remove。USER 無准入即 NOFIT，不能借 DEV/OPS。

R3 至少真 STAGE／LOADED／CONSUMER 三 Raw 同 candidate SHA／epoch 且不同 event/resource；Repo／PR inspect、exit 0、stage 檔存在不作 loaded。Code／Installed／Loaded／Consumer 四階逐一讀回，沒有證據保持 UNVERIFIED。SBL `remove --id` 語法與 User outcome 依 DOC-08 的當前 parser discovery，不以泛稱 delete 發命令。
''',
4:'''<a id="repair-hotpath"></a>
## 本候選修訂：R1～R4 合法起跑與持久續航（RCA-10/14/24/27/28/32～35/37/38/42/43/46/48）

四 Cone 各自 `DISCOVER → FIRST_FAIL → BOUNDED_FIX → RED/GREEN → REAL_READBACK → CHECKER`。沒有真實 repro 不預設缺陷；`NOT_RUN ≠ BLOCKED ≠ KNOWN_FAILED`。歷史 r10 R3/R4/Executor NOT_RUN 不得冒稱當前 Host 故障。先讀真 root／reparse ancestor／HEAD／index+untracked／ACL／process executable／imported origin／Loaded SHA，再在已授權隔離樹修受影檔；外部 Repo 缺真 DEV ECP／Admission 即只做 L1。此次文件工作無外部 Repo 寫入權，也不推升 Native privilege。

R1：確認現役 User Trust→Resolver→Receiver 路徑；真 ADMIT 及 wrong key／scope／nonce／TTL／Revoke NEG，缺身份或接線只記受影 HOLD。R2：先查現有 Hermes Executor／SharedSpine／OS wakeup，不另造 Scheduler。Native 測試必經 READY→CAS lease→真 Executor→effect readback→checkpoint；Worker crash 後由既有合法 wakeup 起**不同 OS PID**並自發續卡，舊 generation 不得 commit，未知 effect 先 reconcile。Scheduled Task 單次成功、dispatcher fixture 18/18、報告或 Seal 都不能代理此閉環；READY/RUNNING 非零禁止 Final。

R3：先唯讀定位現役 Creator／Stage／Activator／Active／Loaded Consumer；權限充分才另以 OPS 卡做最小 promotion 及 Recovery Receipt。無 Consumer ACK 保持 HOLD。R4：PLAN／EXECUTE／VERIFY_SECURITY 各自 Required=Served，同現役 epoch；真 request+served readback 分開保存，不以 route config 或 role 名充收據。Pin／Pool／Session 不互替，Provider-off／NoFit 保留，禁止靜默換模型。

R1～R4 依實際消費邊排程，合法 discovery 保持可行；對長期未跑 cone 要記公平性／下一探測，不能總選封存卡。Context 壓縮後只取新 SharedSpine 讀回和 current Host facts。若所有工作真受阻則 PARKED_WITH_TRIGGER，不無限自旋、不稱 Native 完工。

PIPD PR #20 Stage-C 必保存 base/head/allowed WriteSet/實際 changed_paths 對照；ADR-0008/0009 若超範圍仍應 FAIL，不放寬 guard。PR／CI 只是遠端程式層，與 Installed／Loaded 分列。未證 Repo root 或 junction 逃逸時禁止寫入；原 Dirty／Untracked 保留。下一可做行為是合法 read-only discovery，而非推論主線已生效。
''',
5:'''<a id="repair-evidence-stages"></a>
## 本候選修訂：測試階段與 Checker 真身份（RCA-08/11/13/21/23/26/36/40/45）

| 階段 | 可核驗內容 | 不得冒稱 |
|---|---|---|
| DEFINED／DESIGN_PLANNED | 120 Parent／124 Child／38 Node 定義、frozen Oracle、fixture/schema | 已取得 Runtime Raw |
| APPLICABLE | 當前 Effect／觸發條件、Source/Policy 版本有定位 | 全清冊已排程 |
| RUNNER_BOUND | 原 Owner registry 的 runner_id／abi_version／schema_id／executable_path／sha256／allowed_os／read_scope／permission_scope／owner_signature 全部可驗 | command string 就是 Runner |
| EXECUTED | 真 exit/stdout/stderr/raw bytes、時間、operation/resource/subject/epoch | Fixture/CI 即 Native PASS |
| INDEPENDENT_VERIFIED | 不同真 Principal／credential／key／只讀 ACL 及不可由 Maker 改寫的 verdict | 作者側 Reviewer 就是獨立 Checker |

本冊原測例完整保留，僅測定義可在本次 DOC 層實測；Native counterparts 全 NOT_RUN。`TEST_PLAN_PASS / FIXTURE_PASS / CI_PASS / NATIVE_VERDICT_PASS` 各自不同。缺 Runner/Owner 為 BLOCKED_MISSING_RUNNER_OR_BINDING，不改成真 FAIL/PASS。原 verifier 為前置拒收器，永遠不自行輸出 PASS。

Raw 只在相同 workorder／operation_id／resource／candidate_sha／epoch 下共用引用；三 GWO 不同 Domain/event 不能借 generic success。Manifest entries 不是 Raw bytes，所有必需原始位元須存在且 SHA 重算；歷史 r10 缺五筆只記歷史 MISSING，當前未重新定位不推定已找齊。Catalog denominator 不是 Scheduler queue；受影增量回歸保留未觸發條件與原 120/124/38 身分。
''',
6:'''<a id="repair-product-denominator"></a>
## 本候選修訂：產品清冊與 Bootstrap 適用集合正交（RCA-18/20～22/30/44）

949 R15.1、192 Cell、81 Named Asset（19 Contract＋13 CLI＋25 Method＋24 Donor）的原身份、順序、Required／Conditional／Deferred 與每筆實質要求全部保留。下列衍生排程值不回寫產品義務：`EXECUTE_NOW / CONDITIONAL_TRIGGERED / DEFERRED_WITH_REASON / NOT_APPLICABLE_TO_BOOT`。當期 Required 仍須按有效 policy／Effect 依賴准入；Conditional 必先有實際 trigger／版本／Owner／證據；Deferred 保存 acceptance/re-entry；未觸發者不灌入 READY。r10 1,565 或 625/285/655 不替換本冊 949 分母。

Commander-SP（含 R15-917）的原產品 Required 保留；本輪明令禁用未修復 `sbl-commander-sp`，受影 GWO 入口依 DOC-08 條件分支，不刪產品需求、不使其它合法工程停工。Knowledge Pack 僅 SUPPORT；極性異常另登品質議題，不修改其原件。舊 M5 Repair、舊 M6 Distribution/Host 與 New Flow M1～M6 仍依 DOC-00 雙 taxonomy，不因同名合併。

Provider-off／NoFit、CLI_TOOL／STANDALONE 真 user outcome 不得用 Host install 代理。B1 Bootstrap 不代表 Full SBL Product、R17 145-ID／原 50 Parent+149 Child／18 WP／25 C00～C24／16 User Moments 或 SWOF READY_W3 全完工；保留全部來源需求與受影重入條件。下游按單卡 locator 讀原產品結果，不把巨量清冊放入每回合 Context。
''',
7:'''<a id="repair-tool-binding"></a>
## 本候選修訂：Exact Usage 的版本／法位與 ABI 分支（RCA-01～03/12/13/16/20/23/30/35/42/43/46/47）

下方十三 verb／十九 contract／二十五 METHOD／二十四 donor 保留原具名語義；所謂 exact syntax 為歷史 parser/source 模板，**本輪未查真 binary/version/parser**，不能當已可直接執行。每個 binding 分 DISCOVERED→INSTALLED→LOADABLE→INVOKED，保存 executable 絕對路徑、version、SHA、schema/ABI、OS／權限、Owner、Subject/Epoch 與真 raw。`--help` 只驗安裝及當前參數；dry-run 也須先驗是否寫快取／輸出，不能因名稱就保證零寫入。TOOL_MISSING／RUNNER_NOT_BOUND 為 NOT_RUN，不是 EXECUTION_FAILED。

合法探測：先查現有命令／tracked parser／已裝 registry，對已證 read-only 的 `--help`／schema 做讀回，才選原生操作；無 binding 則受影 HOLD，其他 L0/L1 續行。禁止推測 CLI flag、安裝路徑、環境開關或用 shell 假 stdout。C0～C9 真 Compiler 不在本包內，本次 DOC tests 不產 PROMPT_COMPILE_PASS。

Oracle 依 DOC-01 分 `CANONICAL_DOC07 + LEGACY_DOC03_ABI_CANDIDATE`；CR-ORACLE-001 未獲 PIPD Owner 版本化 ratification 前，表列 DOC-03 常數僅 Legacy serialization，不能據此改 Canonical Writer。十二風險軸→九 enum 必 Owner-approved 無 veto loss 映射；否則 PROFILE_MAPPING_UNBOUND。TQAEP 設計沒有 Checker receipt 只可 PLANNED；若現役 compile-tqaep 必須真 receipt，則該正式 CLI 步驟 HOLD，不能捏造或取消要求；測試設計可先在本候選正文定義。

五方法 KANBAN／SWARM／GSTACK／OPENSPEC／CODEX 與其它 METHOD/Donor 按真 Signed Mandatory Policy（同 scope/epoch）判 mandatory/selected；僅 installed 不算 REAL_INVOKE。不選需 reason／trigger；未知 policy 不自行填 optional。LITE／STANDARD／ASSURED 依影響與 Safety Veto，只升不降，不為減文書降級；同 Subject/Scope/Epoch/ChangeSet 的合法契約僅依原規則複用。KP 不升格 NORMATIVE。

PIPD Stage-C 依 DOC-04 做 base/head/WriteSet CI crosswalk，ADR-0008/0009 超範圍仍拒收；Source／PR／CI／Installed／Loaded／Consumer 各列證據級別，不能互借。
''',
8:'''<a id="repair-gwo-entry"></a>
## 本候選修訂：非 Commander 提案條件與 Mission Stop Rule（RCA-17～19/26/29/32/33/36～41/45/48）

本 B1 Bootstrap 禁止呼叫未修復、未正式准入的 `sbl-commander-sp`。此為候選包預授權的設計採納，不代表 SBL Domain 已批准新入口。原 plan.propose 產品需求保持，實際 GWO Proposal 只能走下列可核驗分支：

| 分支 | 前提／合法動作 | first_fail／受影範圍／重入 |
|---|---|---|
| A 既有非 Commander ABI | 唯讀查現有 SBL registry/parser/controller，取得 Owner 版本化契約、executable/version/SHA、真 readback，證不依賴禁用 SP；經真授權才 invoke | 任一缺件 SBL_PROPOSAL_ABI_UNBOUND；只 PARK 消費提案之 GWO，繼續不相依 OBS/DEV |
| B 現役 ABI 缺失 | 記 discovery 與 Owner Decision Gate；最小 Adapter 只可由 SBL Owner 在既有 Domain/Repo 合法 DEV Scope 內批准及實作，經正負 roundtrip 再回 A | 不捏造 Proposal／Permit；無 Owner ratification 保持 HOLD |
| C 僅 Commander-SP 可用 | 不呼叫該禁用 SP；保留產品 Required，等待 repair＋formal admission＋Owner entry binding | GWO 局部 HOLD；不是全域停止 |

以上是條件設計，不宣稱查到可用 ABI；未證前本輪三 GWO 均 NOT_RUN。SBL 永遠不簽 HGK Native Permit。G-A 六項、三個獨立 GWO 與 G-B 合取不降低，互不借 PASS；Fabric 三 Raw 同 SHA/Epoch 且 distinct event，SBL Host install 與 User Consent／add/list/remove 分開。

G-B 必先真 Revoke external helper，再**不同 OS PID／Session**由 Native Executor 自發續同 Subject；只換 session 名、同 PID、Scheduled Task 叫回外援、舊 token 仍可 spawn，全部不合格。真 rollback/readback zero residue 保留，舊 Token NEG 應在 spawn 前拒收。Crash 的未知效果先 reconcile，不任意重播。

報告、Manifest、Seal 只彙整證據，READY/RUNNING 非零時不得 Mission Complete。全部合法工作 PARK 可具名 PARKED_WAITING_FOR_TRIGGER，不算 Native Success。Raw Manifest 必逐項有原始位元／hash，歷史 manifest-only 不補缺件；重新開始須先當前 Host readback，不能以 r10 或遠端 PR 推定 Loaded。作者側覆核不冒稱獨立 Checker。
'''
}

replace(0,'6. Package：本輪包可驗明檔案 SHA，但因正式 approval 不存在，上限 `AUTHOR_SIDE_REPAIR_CANDIDATE`，不得用 `LOCAL_QUALIFIED`。','6. Package：本候選修訂有 OWNER 預授權的 B1 設計使用採納；原生正式 approval 尚未取得，上限仍為 `AUTHOR_SIDE_REPAIR_CANDIDATE`，不得用 `LOCAL_QUALIFIED`。','區分本次預授權設計採納與未取得的正式 Domain approval',['DOC-ID-06'])
replace(0,"        elif not proof or proof.get('nack'):","        elif not proof or proof.get('nack') or proof.get('operation') != 'REAL_INVOKE' or not proof.get('same_subject') or not proof.get('raw_sha'):",'已選 optional Method 也要真調用證據，不能以 installed receipt 記 INVOKED',['DOC-NEG-05','OPTIONAL-SELECTED-METHOD-REAL-INVOKE'])
old_binding=re.search(r'```python\n(def choose_binding[\s\S]*?)\n```',base[2]).group(1)
new_binding='''def choose_binding(slot, repo_probe=None, host_probe=None, read_probe=None):
    # DESIGN eligibility only. Flags denote already-validated native evidence,
    # never caller self-issued grants; no effect or live dispatch occurs here.
    k=slot['effect_class']
    if k == 'READ_ONLY_PROBE':
        if not read_probe or not all(read_probe.get(x) is True for x in
                                     ('read_scope_valid','same_subject','fresh','no_mutation')):
            return {'status':'HOLD','first_fail':'READ_SCOPE_OR_CURRENTNESS_UNBOUND'}
        return {'status':'READ_ONLY','permission':'NONE','effect':'NO_EFFECT'}
    if k == 'REPOSITORY_WRITE':
        if not repo_probe or not all(repo_probe.get(x) for x in ('real_root','head','writable_scope')):
            return {'status':'HOLD','first_fail':'REPO_CONTEXT_MISSING'}
        if repo_probe.get('dirty_conflict') or repo_probe.get('path_escape') or repo_probe.get('currentness') != 'FRESH':
            return {'status':'HOLD','first_fail':'REPO_CONTEXT_NOT_FRESH'}
        if not all(repo_probe.get(x) is True for x in ('owner_scope_valid','dev_admission_valid','dev_ecp_valid')):
            return {'status':'HOLD','first_fail':'L2_ADMISSION_HOLD'}
        return {'status':'READY_FOR_OWNER_REVIEW','writer':'Codex','scope':repo_probe['writable_scope']}
    if k in ('HOST_OPERATIONS','USER_DATA_EFFECT'):
        required=('active_policy_epoch','issuer','receiver','ecp_ref','evidence_ref')
        if not host_probe or not all(host_probe.get(x) for x in required):
            return {'status':'HOLD','first_fail':'NATIVE_ISSUER_OR_POLICY_UNBOUND'}
        if k == 'USER_DATA_EFFECT' and not all(host_probe.get(x) is True for x in
                                               ('user_consent','user_issuer','synthetic_scope_valid')):
            return {'status':'NOFIT','first_fail':'USER_ISSUER_OR_CONSENT_MISSING'}
        if not all(host_probe.get(x) is True for x in
                   ('permit_valid','same_subject','scope_valid','nonce_fresh','ttl_valid','not_revoked','preimage_valid')):
            return {'status':'NACK','first_fail':'PERMIT_SUBJECT_NONCE_REPLAY'}
        return {'status':'READY_FOR_OWNER_REVIEW','effect':'USER_ONLY' if k == 'USER_DATA_EFFECT' else 'OPS_ONLY'}
    raise ValueError('EFFECT_CLASS_UNKNOWN')'''
replace(2,old_binding,new_binding,'原分派缺 DEV Admission 與真 Permit 證據前置，READ_ONLY 仍須合法 scope',['DOC-ID-03','SCENARIO-NO-PERMIT'])
old_verify="    if not r or not r.get('owner_signature') or not r.get('executable_path'):\n        return 'BLOCKED_MISSING_RUNNER'"
new_verify="    needed=('runner_id','abi_version','schema_id','executable_path','sha256','allowed_os','read_scope','permission_scope','owner_signature')\n    if not r or not all(r.get(k) for k in needed):\n        return 'BLOCKED_MISSING_RUNNER'"
replace(5,old_verify,new_verify,'實作已明定的完整 Runner Binding 拒收規則',['DOC-ID-08','DOC-NEG-04'])
old="    if raw.get('maker_id','').casefold().strip()==raw.get('checker_id','').casefold().strip():\n        return 'FAIL_SELF_ACCEPTANCE'"
new="""    import unicodedata
    norm=lambda v: unicodedata.normalize('NFKC',str(v)).casefold().strip()
    if not raw.get('maker_id') or not raw.get('checker_id') or norm(raw['maker_id'])==norm(raw['checker_id']):
        return 'FAIL_SELF_ACCEPTANCE'
    if not raw.get('maker_principal_uuid') or not raw.get('checker_principal_uuid'):
        return 'BLOCKED_CHECKER_IDENTITY_UNVERIFIED'
    if raw['maker_principal_uuid']==raw['checker_principal_uuid'] or raw.get('maker_sid')==raw.get('checker_sid') and raw.get('maker_sid'):
        return 'FAIL_SELF_ACCEPTANCE'
    if not all(raw.get(k) is True for k in ('credential_fingerprints_distinct','checker_readonly_acl_verified','maker_cannot_write_checker')):
        return 'BLOCKED_CHECKER_IDENTITY_UNVERIFIED'"""
replace(5,old,new,'真 Principal/ACL 前置補強；保留 verifier 不產 PASS',['DOC-NEG-07'])
replace(7,'此冊補完 A-15/A-19：**真 CLI 已讀到 parser 和 P4 schema**，但目前沒有本機 PIPD CLI binary，以下命令是可供 Owner 拿去執行的合法 syntax/negative pair；所有 `<...>` 占位必先從真正產物解析，不可以原樣帶進正式執行。','此冊保留 A-15/A-19 的歷史 parser／P4 schema 模板；本輪未證本機 CLI binary／parser 版本，全部命令須先依本冊 repair-tool-binding 讀回當前能力，再選合法參數；所有 `<...>` 占位必從真產物解析，不能原樣正式執行。','移除未重測的現在式 CLI 宣稱',['DOC-ID-08'])
replace(7,'five original REQ enum only + bound DOC-03 DOMAIN_ORACLES; foreign B1 atom rejects','five original REQ enum only; DOC-03 DOMAIN_ORACLES is legacy serialization pending DOC-07 Writer ratification (CR-ORACLE-001); foreign B1 atom rejects','明示 Legacy ABI 不取代 Canonical Writer',['DOC-NEG-02'])
replace(8,'唯一合法入口是現有 SBL Command/Proposal `plan.propose`，而非 SBL 自發 Native Permit。每張 GWO 都須有獨立 `operation_id, subject_sha, policy_epoch, ECP_ref, pre/poststate, raw_receipt, independent_checker`，不同 Domain 不得互借。','GWO 提案保留 SBL 原 Proposal Owner；實際入口按本冊 repair-gwo-entry 的非 Commander 真 ABI／Owner ratification 分支綁定，未證即局部 HOLD，不呼叫禁用 SP，不由 SBL 發 Native Permit。每張 GWO 都須有獨立 `operation_id, subject_sha, policy_epoch, ECP_ref, pre/poststate, raw_receipt, independent_checker`，不同 Domain 不得互借。','解除固定 Commander 前置矛盾，保留 Domain Gate',['SCENARIO-COMMANDER'])
replace(8,'1. SBL Commander 提出可逆小 WorkOrder 候選與 PIPD PI/PD/ECP refs；必要的 native `WorkOrder` 只由 HGK 唯一 Issuer 簽發。','1. 由 repair-gwo-entry 分支 A 已證且獲 SBL Owner 批准的非 Commander Proposal 入口提出可逆小 WorkOrder 候選與 PIPD PI/PD/ECP refs；未證時此 GWO 局部 HOLD；必要的 native `WorkOrder` 只由 HGK 唯一 Issuer 簽發。','不用文字宣稱新 ABI 已存在',['SCENARIO-COMMANDER'])
replace(8,"$home = '<USER_CONSENTED_ISOLATED_DATA_DIR>'\npython -m sbl_cli.sbl_todo --data-dir $home init\npython -m sbl_cli.sbl_todo --data-dir $home add --title 'B1 reversible smoke'\npython -m sbl_cli.sbl_todo --data-dir $home list --json\n# Use actual id from add JSON, never a guessed id.\npython -m sbl_cli.sbl_todo --data-dir $home remove --id <ACTUAL_TASK_ID_FROM_ADD>\npython -m sbl_cli.sbl_todo --data-dir $home list --json\npython -m sbl_cli.sbl_todo --data-dir $home uninstall --yes", "# DESIGN TEMPLATE: run only after actual parser discovery and USER admission.\n$syntheticDataDir = '<USER_CONSENTED_ISOLATED_DATA_DIR>'\npython -m sbl_cli.sbl_todo --data-dir $syntheticDataDir init\npython -m sbl_cli.sbl_todo --data-dir $syntheticDataDir add --title 'B1 reversible smoke'\npython -m sbl_cli.sbl_todo --data-dir $syntheticDataDir list --json\n# Assign the actual id returned by add JSON before remove.\n$actualTaskId = '<ACTUAL_TASK_ID_FROM_ADD>'\npython -m sbl_cli.sbl_todo --data-dir $syntheticDataDir remove --id $actualTaskId\npython -m sbl_cli.sbl_todo --data-dir $syntheticDataDir list --json\npython -m sbl_cli.sbl_todo --data-dir $syntheticDataDir uninstall --yes",'修正 PowerShell 唯讀 HOME 變數衝突與未引號 placeholder；不執行 USER 命令',['DOC-ID-08','DOC-NEG-10'])

for i in range(9):
 s=work[i]
 oldmeta=s.split('---',2)[1]
 meta=yaml.safe_load(oldmeta)
 originalmeta=dict(meta)
 meta.update(artifact_id=files[i].stem,version=REV,supersedes_version=originalmeta['version'],supersedes_subject_sha256=digest(files[i].read_bytes()),baseline_lineage=originalmeta,design_use='OWNER_PREAUTHORIZED_B1_DESIGN_USE',native_authority='FORMAL_NATIVE_NOT_GRANTED',source_path=str(files[i]))
 rest=s.split('---',2)[2].lstrip('\n')
 # Integrate the scope clauses before existing numbered body; preserve body order.
 h=rest.find('\n\n')
 anchor_names=['repair-control','repair-source-abi','repair-binding','repair-ops-boundary','repair-hotpath','repair-evidence-stages','repair-product-denominator','repair-tool-binding','repair-gwo-entry']
 refs=[j for j in range(9) if j!=i] if i==0 else [0,2,7,8]
 refs=[j for j in refs if j!=i]
 links='受影交叉引用：'+ '、'.join(mdlink(j,anchor_names[j]) for j in refs)+'。'
 rest=rest[:h]+ '\n\n'+snippets[i].strip()+'\n\n'+links+'\n\n'+rest[h+2:]
 work[i]='---\n'+yaml.safe_dump(meta,allow_unicode=True,sort_keys=False).strip()+'\n---\n\n'+rest
 write(OUT/'PKG'/files[i].name,work[i])
 (OUT/'BASELINE').mkdir(parents=True,exist_ok=True)
 (OUT/'BASELINE'/(files[i].stem+'.source')).write_bytes(files[i].read_bytes())
 changes.append(dict(doc=f'{i:02d}',kind='INTEGRATE_SECTION',source_locator=dict(path=str(files[i]),sha256=digest(files[i].read_bytes()),line_start=15,plan_section=f'§5 D{i:02d}'),old_clause='本冊原文無此分層小節（原正文其餘保留）',new_clause=snippets[i].strip(),reason='Repair Plan §5 受影執行適用性修補',test_case=['DOC-ID-06','DOC-ID-10'],effect_scope='L0_DOCUMENT_CANDIDATE',owner='B1 OWNER preauthorization; no Domain ratification',adverse_effect='Only design eligibility; no live dispatch'))
 changes.append(dict(doc=f'{i:02d}',kind='VERSION_AND_LINEAGE',source_locator=dict(path=str(files[i]),sha256=digest(files[i].read_bytes()),line_start=1,line_end=13),old_clause=oldmeta.strip(),new_clause=yaml.safe_dump(meta,allow_unicode=True,sort_keys=False).strip(),reason='Versioned per-book candidate identity; preserve full baseline lineage and native ceiling',test_case=['DOC-ID-01','DOC-ID-06'],effect_scope='L0_DOCUMENT_CANDIDATE',owner='B1 OWNER preauthorization',adverse_effect='No new Domain signature or native sourcefreeze'))

# Inventory sources by exact bytes. Additional installed P4 schemas are diagnostic sources only.
sources=[]
relocations=[]
for v in json.loads(Path('work/source_inventory.json').read_text(encoding='utf-8')):
 p=Path(v['path'])
 if not p.exists():
  matches=[q for q in ROOT.rglob(p.name) if digest(q.read_bytes())==v['sha256']]
  assert len(matches)==1,('SOURCE_MOVED_OR_CHANGED',str(p),len(matches))
  relocations.append(dict(previous_path=str(p),current_path=str(matches[0]),sha256=v['sha256'],status='SAME_BYTES_RELOCATED_DURING_RUN'))
  p=matches[0]
 sources.append(p)
dump(OUT/'SOURCE_RELOCATION_LOG.json',relocations)
p4=Path(r'C:\Users\user\.codex\plugins\cache\created-by-me-remote\pipd-ls-sp-public-skills-p4\0.1.1\skills')
sources += [p4/'pipd-profile-tailor'/'schemas'/'input.schema.json',p4/'pipd-pi-compile'/'schemas'/'output.schema.json']
manifest=[]
for p in dict.fromkeys(sources):
 b=p.read_bytes(); text=b.decode('utf-8-sig'); fields={}
 if text.startswith('---'): 
  try: fields=yaml.safe_load(text.split('---',2)[1]) or {}
  except yaml.YAMLError: fields={'metadata_status':'UNPARSEABLE_SOURCE'}
 manifest.append(dict(path=str(p),resolved_path=str(p.resolve()),bytes=len(b),sha256=digest(b),lines=len(text.splitlines()),metadata=fields,authority='B1_R3_DESIGN_CANDIDATE' if p in files else 'SOURCE_ONLY_NOT_NATIVE_FREEZE'))
dump(OUT/'SOURCE_SHA_MANIFEST.json',dict(kind='AUTHOR_SIDE_SOURCE_INVENTORY_NOT_SOURCEFREEZE',source_root=str(ROOT),git=dict(status='NOT_A_GIT_REPOSITORY',head=None,dirty=None,readback='git rev-parse / status exit 128; ancestors .git absent'),root_alias_probe='All source ancestors inspected: no reparse/link targets',sources=manifest,originals=[dict(file=p.name,sha256=digest(p.read_bytes())) for p in files],candidate=[dict(file=p.name,sha256=digest((OUT/'PKG'/p.name).read_bytes())) for p in files]))
dump(OUT/'CHANGES.json',changes)
write(OUT/'CHANGES_AND_DECISIONS.md','# 修補與裁決記錄\n\n本次只編修隔離文件候選。九冊基線 SHA 全數等於 Plan 附錄 B；不以檔名／修改時間選版。內文 family/version/lineage 均一致；整合版是重複載體，不是另一本來源。\n\n原 supersedes 指向 r2 rollup 而非單冊 hash，已存入 baseline_lineage；新候選 supersedes_subject_sha256 逐冊釘 r3 原件。原 task_kind／claim ceiling／Native NOT_RUN/HOLD 保留。\n\n逐條 source_locator／old_clause／new_clause／reason／effect_scope／owner／test_case／adverse_effect 見 CHANGES.json 與 DIFF；新增 artifact_id 是本次衍生 locator，原件未有該欄位，沒有冒充既有簽章。\n\nOD-01/02：文件寫集與設計使用已由本次指揮一次預授權。OD-03 SBL Proposal、OD-04 Oracle、OD-05 Profile 仍需原 Domain Owner ratification；OD-06 外部 Repo DEV admission、OD-07 真 Host privilege、OD-08 User Consent/issuer、OD-09 獨立 Checker、OD-10 Native Release 不由本文簽發。\n\n新增 ISSUE-DELTA-01：原 DOC-08 PowerShell 使用唯讀 $HOME（大小寫不敏感），已改 syntheticDataDir；未執行 UserData。ISSUE-DELTA-02：原 verifier 只檢 Runner 兩欄及 Checker 名字，已補現有文字要求的全欄及真技術身份前置。ISSUE-DELTA-03：r2 blueprint 歷史固定 hash/檔名在本地未得相同 raw，保留 SOURCE_REF_UNVERIFIED，不把本地不同 blueprint 視為同位元。\n')
for i,p in enumerate(files):
 diff=''.join(difflib.unified_diff(base[i].splitlines(True),work[i].splitlines(True),fromfile='original/'+p.name,tofile='PKG/'+p.name))
 write(OUT/'DIFF'/(p.stem+'.diff'),diff)
write(OUT/'DIFF'/'FULL.diff','\n'.join(read(OUT/'DIFF'/(p.stem+'.diff')) for p in files))

# Actual original slot definitions, not text match counts.
def jsonblocks(s):
 return [(m.start(),json.loads(m.group(1))) for m in re.finditer(r'^```json\s*\n([\s\S]*?)^```\s*$',s,re.M)]
slots=[v for _,v in jsonblocks(base[2]) if 'slot_id' in v]
assert len(slots)==31 and len({v['slot_id'] for v in slots})==31
projection=[]
requirements={'READ_ONLY_PROBE':'Read Scope + fresh same-subject observation','REPOSITORY_WRITE':'RepoContext + authorized WriteSet + true DEV ECP/Admission','HOST_OPERATIONS':'HGK native issuer/receiver + true OPS Permit/ECP','USER_DATA_EFFECT':'User issuer + Consent + synthetic path + true USER Permit/ECP'}
for v in slots:
 line=next(i+1 for i,x in enumerate(base[2].splitlines()) if x.startswith('### PD-') and v['slot_id']+' ' in x)
 projection.append(dict(slot_id=v['slot_id'],effect_class=v['effect_class'],source_ref=dict(file=files[2].name,original_sha256=digest(files[2].read_bytes()),line=line),binding_required=requirements[v['effect_class']],depends_on=None,blocked_by=['ACTUAL_BINDING_AND_DEPENDENCIES_NOT_READ_BACK'],evidence_kind=v.get('schema'),next_action='Legal read-only scope/currentness/ABI/dependency discovery; do not dispatch effect',policy_epoch=None,runtime_state='UNVERIFIED',authority='DERIVED_VIEW_ONLY_NO_QUEUE_WRITE'))
dump(OUT/'EXECUTION_PROJECTION_CANDIDATE.json',dict(kind='B1_EXECUTION_PROJECTION_CANDIDATE_NOT_NATIVE_PD_OR_PERMIT',entries=projection))

# Snapshot the exact repair command/plan as non-book source attachments.
for p in (PLAN,COMMAND): (OUT/'BASELINE'/(p.stem+'.source')).write_bytes(p.read_bytes())
dump(OUT/'BUILD_CONTEXT.json',dict(revision=REV,source_root=str(ROOT),book_names=[p.name for p in files],command_sha256=digest(COMMAND.read_bytes()),plan_sha256=digest(PLAN.read_bytes()),authorization='USER_EXPLICITLY_INVOKED_COMMAND; OWNER_PREAUTHORIZED_B1_DESIGN_USE / FORMAL_NATIVE_NOT_GRANTED'))
print('BUILT',str(OUT));print('BOOKS',len(files));print('SOURCE_FILES',len(manifest));print('SLOTS',len(slots))
