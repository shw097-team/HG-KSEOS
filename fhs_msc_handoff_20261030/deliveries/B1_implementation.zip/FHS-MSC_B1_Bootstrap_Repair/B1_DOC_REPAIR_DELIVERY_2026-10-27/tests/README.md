# 重跑方式

Python 3.11+，依賴 PyYAML、markdown-it-py、jsonschema。使用現有已安裝環境；不需要 pip 或 network，也不調用 Native Host。

```text
python tests/validate_delivery.py <解壓後根目錄> GREEN
python tests/validate_delivery.py <解壓後根目錄> RED
```

GREEN 應 exit 0；RED 對 BASELINE/*.source 原件應 exit 1。兩種模式使用同一期望。測試直接解析正文中的 Python 設計函式；其餘 model 僅隔離證據 predicate。重跑會更新 evidence/<mode>_TEST_REPORT.json，不簽發 Native receipt；若更動任何交付物請重算封裝 manifest。

```powershell
& './tests/verify_powershell.ps1' -DeliveryRoot '<解壓後根目錄>'
```

PowerShell 只 AST parse 兩個原生命令模板，不執行命令。BASELINE 使用 .source 副檔名保存真位元，PKG 中恰九冊 Markdown；不要以整包的報告 Markdown 數量當書冊數。
