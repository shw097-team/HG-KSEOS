from pathlib import Path
import re,json,hashlib,collections,subprocess,sys,shutil,zipfile,difflib
ROOT=Path('outputs/B1_DOC_REPAIR_DELIVERY_2026-10-27').resolve()
def load(p):return p.read_text(encoding='utf-8-sig')
def write(name,s): (ROOT/name).write_text(s,encoding='utf-8',newline='\n')
def dump(name,v):write(name,json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
ctx=json.loads(load(ROOT/'BUILD_CONTEXT.json'));man=json.loads(load(ROOT/'SOURCE_SHA_MANIFEST.json'));names=ctx['book_names']
green=json.loads(load(ROOT/'evidence'/'GREEN_TEST_REPORT.json'));red=json.loads(load(ROOT/'evidence'/'RED_TEST_REPORT.json'))
assert green['counts']['failed']==0
assert red['counts']['failed']>0
bytest={v['id']:v for v in green['results']}
rca=json.loads(load(ROOT/'RCA_EVIDENCE.json'))
for row in rca:
 row['test_result']=bytest[row['test']]['status']
 assert row['test_result']=='PASS'
dump('RCA_EVIDENCE.json',rca)
coverage=load(ROOT/'RCA_48_COVERAGE.md').replace('真測試 |','真測試（全部文檔層 PASS） |')
write('RCA_48_COVERAGE.md',coverage)
plan=load(next((ROOT/'BASELINE').glob('*Repair_Plan*.source')))
expected=re.findall(r'^\|[^\n]*\|\s*(\d+)\s*\|\s*`([a-f0-9]{64})`\s*\|',plan,re.M)
actual={s['sha256']:s for s in man['sources']}
comparison=[dict(expected_lines=int(l),expected_sha256=h,available_path=actual[h]['path'] if h in actual else None,status='EXACT_BYTES_AVAILABLE' if h in actual else 'MISSING') for l,h in expected]
assert len(comparison)==39,len(comparison)
assert all(v['status']=='EXACT_BYTES_AVAILABLE' for v in comparison)
dump('PLAN_39_SOURCE_COMPARISON.json',comparison)

diffchecks=[];stats=[]
for n in names:
 a=ROOT/'BASELINE'/(Path(n).stem+'.source');b=ROOT/'PKG'/n
 command=['git','-c','core.autocrlf=false','diff','--no-index','--check','--',str(a),str(b)]
 cp=subprocess.run(command,capture_output=True,text=True,encoding='utf-8',errors='replace')
 diffchecks.append(dict(book=n,command=command,exit_code=cp.returncode,stdout=cp.stdout,stderr=cp.stderr,status='PASS' if cp.returncode in (0,1) and not cp.stdout.strip() and not cp.stderr.strip() else 'FAIL',interpretation='no-index implies exit-code: 1 means content differs; whitespace errors would emit diagnostics and/or exit 2'))
 aa=load(a).splitlines();bb=load(b).splitlines();d=list(difflib.unified_diff(aa,bb))
 added=sum(x.startswith('+') and not x.startswith('+++') for x in d);removed=sum(x.startswith('-') and not x.startswith('---') for x in d)
 stats.append(dict(book=n,original_lines=len(aa),new_lines=len(bb),added=added,removed=removed,original_sha256=sha(a),candidate_sha256=sha(b)))
assert all(v['status']=='PASS' for v in diffchecks),diffchecks
dump('evidence/DIFF_CHECK_REPORT.json',diffchecks);dump('DIFF_STATS.json',stats)

# Parsed definitions and complete-body digests support independent rechecking.
def objects(s):return [json.loads(m.group(1)) for m in re.finditer(r'^```json\s*\n([\s\S]*?)^```\s*$',s,re.M)]
def recordset(values):
 return {'count':len(values),'ids':list(values),'definition_sha256':{k:hashlib.sha256(json.dumps(v,ensure_ascii=False,sort_keys=True).encode()).hexdigest() for k,v in values.items()}}
books=[load(ROOT/'PKG'/n) for n in names]
atom_ids=re.findall(r'^### (PI-B1-[ABC][1-9])｜',books[1],re.M)
slots={o['slot_id']:o for o in objects(books[2]) if 'slot_id'in o}
sets=dict(atoms=recordset({i:i for i in atom_ids}),slots=recordset(slots))
for label,key in [('parent','test_id'),('child','id'),('node','node_id')]:sets[label]=recordset({o[key]:o for o in objects(books[5]) if key in o})
r15={};ms=list(re.finditer(r'^#### (R15-\d{3})｜',books[6],re.M))
for i,m in enumerate(ms):
 end=ms[i+1].start() if i+1<len(ms) else books[6].index('\n## 4.',m.start());r15[m.group(1)]=books[6][m.start():end]
sets['r15']=recordset(r15);sets['r15']['dispositions']=dict(collections.Counter(re.search(r'disposition：`([^`]+)`',v).group(1) for v in r15.values()))
cells=[l for l in books[6].splitlines() if re.match(r'^\| [a-f0-9]{12} \|',l)]
sets['cell']=recordset({l.split('|')[1].strip():l for l in cells})
sets['asset']=recordset({k:v for k,v in r15.items() if re.match(r'^#### R15-\d{3}｜(?:CONTRACT|PIPD_CLI|METHOD|DONOR_SLOT):',v)})
sets['gwo']=recordset({k:k for k in ('GWO-FABRIC','GWO-HGK','GWO-SBL')})
dump('IDENTITY_INVENTORY.json',sets)

refs=json.loads(load(ROOT/'SOURCE_REFERENCE_AUDIT.json'))
missing=collections.Counter(v['hash'] for v in refs['external_hash_refs'] if v['status']=='SOURCE_REF_UNVERIFIED')
rcount=collections.Counter(r['closure_class'] for r in rca)
write('SOURCE_AND_CANDIDATE_SHA.md','# 原件與新版 SHA-256\n\n九冊原件為真位元 BASELINE/*.source；新版為 PKG/*.md。\n\n| DOC | 原件 SHA-256 | 新版 SHA-256 |\n|---|---|---|\n'+'\n'.join(f"| {i:02d} | `{v['original_sha256']}` | `{v['candidate_sha256']}` |" for i,v in enumerate(stats))+'\n')
write('ISSUE_AND_CR_REGISTER.md','''# 未決 Gate 與新發現

本表均不阻合法、不消費該 Gate 的文件／唯讀工作。作者側修補不能為下列事項簽發 Native PASS。

| Gate | Owner／下一觸發 | 狀態與受影範圍 |
|---|---|---|
| OD-03 SBL_PROPOSAL_ABI_UNBOUND | SBL Domain Owner；非 Commander registry/parser/readback＋版本化批准，或合法最小 Adapter | GWO Proposal 局部 HOLD；禁用未修復 sbl-commander-sp |
| OD-04 CR-ORACLE-001_OPEN | PIPD Owner；DOC07 Writer↔DOC03 legacy alias 的合法 mapping／schema digest／正負測試 | 受影 Formal PI/ECP/TQAEP HOLD |
| OD-05 PROFILE_MAPPING_UNBOUND | PIPD Owner；十二 calibrated 風險軸→九 enum 的無損 veto mapping | 受影正式 ProfileBinding HOLD，不降級 |
| OD-06 DEV_ADMISSION | 各原 Repo Owner／PIPD；真 RepoContext/WriteSet/DEV ECP/Admission | 外部 Repo 寫入本輪未執行；僅有本次文件隔離 Scope |
| OD-07 HGK_TRUST_RECEIVER / HOST_PRIVILEGE | HGK Owner／真 OS Principal；Profile→Resolver→Receiver readback 及簽章正負驗證 | R1 Native 效果 NOT_RUN，文件不改 Trust/Policy |
| OD-08 USER_BOUNDARY | User data Owner／使用者；Synthetic DataDir 目的、同意、issuer／revoke | SBL add/remove 未執行，零私人資料效果 |
| OD-09 CHECKER_AND_RUNNER_UNBOUND | 各 Domain Runner Owner／真獨立 Checker Principal/key/ACL | Native Acceptance NOT_RUN；作者 Reviewer 不是 Checker |
| R2 HERMES_EXECUTOR_AND_NEW_PID | Hermes/HGK；SharedSpine→真 Executor→checkpoint→合法 wakeup→新 PID | NOT_RUN；不拿 dispatcher/fixture/Seal 代理 |
| R3 FABRIC_ACTIVE_LOADED_CONSUMER | Fabric Owner；真同 SHA/epoch STAGE/LOADED/CONSUMER | NOT_RUN，未聲稱當前 Activator 故障 |
| R4 REQUIRED_SERVED | 現役路由 Owner；PLAN/EXECUTE/VERIFY_SECURITY request/served raw | NOT_RUN，無 fallback／第四 Lane |
| PIPD_STAGE_C_WRITESET | PIPD Repo Owner／原 CI；base/head/allowed/changed 及真 CI | NOT_RUN，不放寬 ADR-0008/0009 guard |
| RAW_R10_FIVE_BYTES | 原證據保存者；原五筆實體 raw 及 SHA | 歷史 MISSING，當前未重新驗證，不能以 manifest 補位 |
| OD-10 NATIVE_RELEASE | 正式 Issuer＋Checker＋Owner；G-A 六項＋三 GWO＋Revoke／新 OS PID G-B／zero residue | NOT_RUN／HOLD；文檔完成不等於 B1 Native 完工 |

ISSUE-DELTA-01：DOC-08 $HOME 唯讀變數及 remove placeholder 已修，PowerShell 僅 AST parse。
ISSUE-DELTA-02：DOC-05 runner 全欄／NFKC、Principal／SID／ACL 前置已補，verifier 仍不產 PASS。
ISSUE-DELTA-03：兩份歷史 exact source hash 未找到：
'''+ '\n'.join(f'- `{h}`：{c} 個原始引用；SOURCE_REF_UNVERIFIED，保留原值，不用本地不同 blueprint 取代。' for h,c in missing.items())+'''

ISSUE-DELTA-04：DOC-00 optional selected Method 必須 REAL_INVOKE＋SameSubject/raw，已補拒收 installed-only。

施工期間來源修補計畫與指揮檔的路徑有變動；同 SHA 原位元重新定位，見 SOURCE_RELOCATION_LOG.json。本工具未移動來源。
''')
write('NEXT_B1_HERMES_HANDOFF.md','''# 給 Hermes 的下一個合法 WorkOrder 候選

`OBS-B1-A1`（READ_ONLY_PROBE；不是本工具簽發的 Native WorkOrder）。使用本包 PKG 唯一新版的 SHA 做設計候選控制，先核對合法 Read Scope、真 root/alias/reparse／ACL、四庫 HEAD/Dirty、installed/imported/Loaded origins；不先要求未來 Permit 才能讀來源。

讀回現役 SharedSpine 唯一 READY/RUNNING/PARKED 狀態與 Owner/lease/epoch，再唯讀定位 Hermes 真 Executor、既有 OS wakeup、Receiver Trust Resolver、Fabric Consumer 及三 Lane 的真能力。不得新建第二 queue 或調用禁用 Commander-SP。合法唯讀入口未證即記具名 FirstFail/探測替代路徑，停該 probe 並繼續不相依合法工作。

此候選的輸入：PKG SHA、Owner Read Scope、當前根路徑、現役 policy/SharedSpine locator（尚待讀回）。輸出：subject/host/time/root/HEAD/dirty/reparse/ACL/no-effect witness；Source/Runtime/Admission 四 Gate 分開，不宣稱 Loaded 已修。無變更故不要求無效 rollback token。具體 executable/API 先查已裝 registry/parser／help，不杜撰 ABI。

Discovery 後依真消費邊交 Hermes：R1 Trust/Receiver、R2 SharedSpine→Executor→新 PID、R3 Fabric 三 Raw、R4 三 Lane Required=Served 各自獨立 cone。缺 Native admission 只 PARK 受影 Host/User 工作；Repo 修補仍須其真 DEV admission。READY/RUNNING>0 不得以 Report/Seal 完工；全 PARK 附 Owner/first_fail/喚醒條件，不當成功結案。

目前 G-A、GWO-FABRIC/HGK/SBL、G-B 全 NOT_RUN；Oracle、Profile、SBL 非 Commander 提案及 Checker 等未決詳 ISSUE_AND_CR_REGISTER.md。本包沒有真 PIPD SourceFreeze、ExecutionAdmission、HGK Permit、User Consent 或獨立 Checker 收據。
''')
write('AUTHOR_SIDE_REVIEW.md','''# 作者側反例覆核（不是正式獨立 Checker）

覆核對象：本包完整 DIFF/FULL.diff、九冊前後正文及 RCA_EVIDENCE 的 source SHA/行段。覆核身份：同一作者工具；不能簽發 Independent Pass 或 Native Release。

已逐項檢查 G-A 原六項與 G-B 原合取原文不變；三 GWO 各有原 Domain/operation/raw；OPS JSON payload 全數不變；未知效果仍先 reconcile；Nonce/TTL/Revoke、User Consent、Maker/Checker 真分離保留；Provider Required=Served、SourceFreeze 不被文檔預授權替代。DOC-05 120/124/38 與 DOC-06 949/192/81 完整實質定義保持，未重排巨量清冊；九冊 metadata 保持 DESIGN／AUTHOR_SIDE_REPAIR_CANDIDATE 與 Native NOT_RUN/HOLD。

反例覆核發現並修補：原 optional selected Method 可拿 installed receipt 充 INVOKED，新增 REAL_INVOKE/subject/raw 拒收。另確認缺真 ABI 的 GWO 走局部 HOLD；選用不同檔案名稱、字串 Checker、同 SID、同 OS PID、stage-only、舊 HEAD Raw、錯 Domain Receipt 及 Revoke 後可 spawn 皆不能升格 Native 成功。

檢查範圍止於文件契約與隔離 fixture。test contract_model.py 是 synthetic evidence oracle，不是 Scheduler／Issuer／PIPD compiler，也不寫 Live SharedSpine。真權限、現役 binary/ABI、Policy Epoch、CI、loaded/served、Host effect 及獨立 Checker 均未取證，詳 NOT_RUN 清單。
''')
ps=json.loads(load(ROOT/'evidence'/'POWERSHELL_PARSE_REPORT.json'))
if isinstance(ps,dict):ps=[ps]
assert len(ps)==2 and all(v['Status']=='PASS' for v in ps)
counter=next(r['detail'] for r in green['results'] if r['id']=='DOC-ID-08')
write('VALIDATION_REPORT.md',f'''# 文檔修補驗證

RESULT: PASS（DOC scope）／DOC_REPAIR_COMPLETE。B1_NATIVE_ACCEPTANCE_INCOMPLETE。
Candidate: {ctx['revision']}；OWNER_PREAUTHORIZED_B1_DESIGN_USE / FORMAL_NATIVE_NOT_GRANTED。

執行：`python tests/validate_delivery.py <delivery-root> GREEN`，實際 exit 0；逐項 stdout/result 見 evidence/GREEN_TEST_REPORT.json。最終 {green['counts']['passed']}/{green['counts']['executed']} PASS、0 FAIL。指定 DOC-ID-01～10 與 DOC-NEG-01～18 共 28/28 文檔層 PASS；另 31 槽各 POS/NEG＝62、3 核心情境、6 補充驗證＝71。Native 對應／正式 Gate 共 28 NOT_RUN，不列成功。

同一最終測試程式對 r3 原件 RED 的結果：{red['counts']['passed']}/{red['counts']['executed']} PASS，{red['counts']['failed']} FAIL，exit 1。RED 中缺新 completion predicate／候選 metadata 為預期的設計缺口；未把 TypeError 或測試程式缺陷當功能 RED。初期 harness 的 generator/JSON date 序列化錯誤已修，不作來源缺陷。未修改測試期望洗綠。最終程式／fixture SHA 隨 FILE_SHA_MANIFEST 可重算。

真解析：{json.dumps(counter,ensure_ascii=False)} 個 code fence；JSON loads、Python AST、YAML frontmatter 解析，原機器可讀 JSON 完整相等。兩個 PowerShell 範例通過 PowerShell AST parse，均未執行。已裝 P4 strict Profile schema 正例及 ELITE／duplicate axes／額外 key 負例均實測。

身份比較解析唯一原始定義，沒有使用全文出現次數：27 Atoms；31 slot（10 Read／5 Repo／14 Host／2 User）；120 Parent／124 Child／38 Node；949 R15 完整 record body／192 Cell 完整 table row／81 Asset；三 GWO。來源及候選集合零差；R15 disposition 原 66 Required／254 Conditional／629 Deferred 保持。十三 CLI／十九 Contract／二十五 METHOD／二十四 Donor 唯一名稱集合保留。

來源：Plan 附錄 B 39/39 原 SHA 在本地取得相同位元；本次共記 66 個 source。九冊原件 SHA 全部吻合 r3，原件末次重算未變。來源 root 祖先沒有 junction/reparse；`.git` 不存在，真 git rev-parse/status 為非 repository，HEAD/Dirty=N/A；未初始化來源 Repo。九份 git diff --no-index --check 無 whitespace error（exit 1 表示有內容差異，stdout/stderr 皆空）；未改上位 DOC 或外部 Repo。逐冊 diff 行數見 DIFF_STATS.json。

引用：內部 Parent↔Child↔31 slot joins 零錯；新增檔案／anchor 連結全存在。38 個原外部 source-hash 引用取得真位元；147 個歷史引用依賴兩份缺 exact raw 的 r2/草案，全部明列 SOURCE_REF_UNVERIFIED 並保持原 hash，沒有偽綁不同 blueprint。這些歷史 raw 的正式 SourceFreeze/Native consumption 仍 HOLD；不影響 r3 原件完整高保留。

RCA 48/48 覆蓋：PATCHED={rcount['PATCHED']}、ALREADY_SATISFIED={rcount['ALREADY_SATISFIED']}、OWNER_OR_NATIVE_DEPENDENCY={rcount['OWNER_OR_NATIVE_DEPENDENCY']}；每項具 Plan/historical/upstream SHA、行段、before/after、測試結果、殘留 Owner/Native Gate。覆核為作者側，非獨立 Checker。

未跑：真 C0～C9 Prompt Compiler、R1 Receiver/Trust、R2 新 OS PID 續航、R3 Active/Loaded/Consumer、R4 真 Served、G-A、三 GWO、G-B，及十八 Native 負例對應。未產生正式 SourceFreeze／PIPD Admission／HGK Permit／Host/User Effect／Native Release。下一合法工作為 OBS-B1-A1 read-only discovery，見 NEXT_B1_HERMES_HANDOFF.md。
''')
write('tests/README.md','''# 重跑方式

Python 3.11+，依賴 PyYAML、markdown-it-py、jsonschema。使用現有已安裝環境；不需要 pip 或 network，也不調用 Native Host。

```text
python tests/validate_delivery.py <解壓後根目錄> GREEN
python tests/validate_delivery.py <解壓後根目錄> RED
```

GREEN 應 exit 0；RED 對 BASELINE/*.source 原件應 exit 1。兩種模式使用同一期望。測試直接解析正文中的 Python 設計函式；其餘 model 僅隔離證據 predicate。重跑會更新 evidence/<mode>_TEST_REPORT.json，不簽發 Native receipt；若更動任何交付物請重算封裝 manifest。

```powershell
& './tests/verify_powershell.ps1' -DeliveryRoot '<解壓後根目錄>'
```

PowerShell 只 AST parse 兩個原生命令模板，不執行命令。BASELINE 使用 .source 副檔名保存真位元，PKG 中恰九冊 Markdown；不要以整包的報告 Markdown 數量當書冊數。
''')
external=Path(ctx['source_root'])/'B1_DOC_REPAIR_DELIVERY_2026-10-27'
readme=f'''# B1 DOC-00～08 修補版導覽

RESULT: PASS（文件）／DOC_REPAIR_COMPLETE；B1 Native Acceptance 尚未完成。唯一新版：PKG/ 九個完整 Markdown，版本 `{ctx['revision']}`。九冊不是摘要／補丁清單；原 27/31/120/124/38/949/192/81/3 GWO 身份及實質定義保留。

法位：OWNER_PREAUTHORIZED_B1_DESIGN_USE / FORMAL_NATIVE_NOT_GRANTED。本次 OWNER 明確預授權寫集與候選設計使用；不取代 Domain ratification／SourceFreeze／PIPD Admission／HGK Permit／OS privilege／User Consent／獨立 Checker／Native Release。

交付副本目標：`{external}`。來源原件仍原位保留，BASELINE/*.source 為相同位元備份；來源版本由內文 family/version/lineage＋SHA 核定，整合版只作重複載體。

| DOC | 完整新版 |
|---|---|
'''
for i,n in enumerate(names):readme+=f'| {i:02d} | [{n}](PKG/{n}) |\n'
readme+='''
先讀 DOC-00 的作用域／Stop Rule，再按 DOC-02 原槽 locator 取受影原文。P0：00/02/08；P1：01/03/04/07；05/06 只新增薄型適用性與 verifier 必要修補，不重生成大表。

- [驗證與數量](VALIDATION_REPORT.md)：99/99 DOC/fixture PASS；28 Native NOT_RUN；PowerShell parse 2/2、Diff check 9/9。
- [原件／新版完整 SHA](SOURCE_AND_CANDIDATE_SHA.md)、[Source Manifest](SOURCE_SHA_MANIFEST.json)、[39 份來源比較](PLAN_39_SOURCE_COMPARISON.json)。
- [RCA 48/48](RCA_48_COVERAGE.md)：27 PATCHED、7 ALREADY_SATISFIED、14 OWNER_OR_NATIVE_DEPENDENCY；精確證據在 RCA_EVIDENCE.json。
- [修補裁決](CHANGES_AND_DECISIONS.md)、CHANGES.json、DIFF/FULL.diff：逐條前後 clause、scope/Owner/反例，及 metadata lineage。
- [未決 Owner/Native Gate](ISSUE_AND_CR_REGISTER.md)：Oracle、Profile、SBL 入口、DEV/Host/User 准入、Runner/Checker 及歷史兩份 raw 未驗證。
- [Hermes 下一合法工作](NEXT_B1_HERMES_HANDOFF.md)：OBS-B1-A1 合法唯讀先取當前真實 Scope/Root/SharedSpine/ABI；不造第二 Queue。
- [重跑說明](tests/README.md)、IDENTITY_INVENTORY.json、AUTHOR_SIDE_REVIEW.md。

FILE_SHA_MANIFEST.json 覆蓋封裝內每個工件（自身與 ZIP 排除以免循環）。ZIP_CONTENTS.json／ZIP_VERIFY_REPORT.json 於封裝後逐檔讀回。ZIP 中 PKG/*.md 恰九冊；其餘 Markdown 是導覽／證據／報告，不是新增冊。所有 Native 簽章／正式 Compiler／Runner/CI/loaded/served/效果實測都未執行；不得據此宣布 G-A/GWO/G-B 完成。
'''
write('README_修補版導覽.md',readme)
shutil.copyfile('work/build_delivery.py',ROOT/'tests'/'build_delivery_source.py')
shutil.copyfile('work/prepare_evidence.py',ROOT/'tests'/'prepare_evidence_source.py')
shutil.copyfile('work/finalize_delivery.py',ROOT/'tests'/'finalize_delivery_source.py')
print('FINAL_REPORTS',str(ROOT));print('RCA',dict(rcount));print('DIFF_CHECK',len(diffchecks));print('SOURCE39',len(comparison));print('COUNTS',green['counts'])
