"""Author-side isolated contract oracles; no issuer, compiler, queue, or host I/O.
These functions validate synthetic evidence predicates only. A model result is
never a native receipt, native admission, or independent Checker verdict.
"""
import ntpath

def source_gate(required, existing):
    if set(required) & {'FUTURE_NATIVE_TASK_KIND','FUTURE_ADMISSION_SOURCEFREEZE'}:
        return 'RECLASSIFY_C5_EFFECT_ADMISSION'
    return 'SOURCE_MISSING' if not set(required) <= set(existing) else 'CANDIDATE_SOURCE_READY'

def oracle_gate(v):
    return 'BOUND_DESIGN' if (v.get('canonical_writer')=='DOC-07' and v.get('alias')=='DOC-03 DOMAIN_ORACLES' and all(v.get(k) for k in ('owner_ratification','schema_sha','source_sha','roundtrip'))) else 'ORACLE_UNBOUND'

def profile_gate(v):
    axes=v['axes']; mapping=v.get('mapping',{})
    if not v.get('owner_ratification') or set(mapping)!=set(axes) or any(not mapping[k] for k in axes):
        return 'PROFILE_MAPPING_UNBOUND'
    if not set(v['vetoes']) <= set(v.get('projected_vetoes',[])) or v.get('new_weight',0)<v['required_weight']:
        return 'PROFILE_MAPPING_REJECTED'
    return 'BOUND_DESIGN'

def fabric_gate(v):
    raw=[v.get(k) for k in ('stage','loaded','consumer')]
    if not all(raw) or not v.get('approved') or not v.get('consumer_ack'):
        return 'HOLD'
    if len({r['event'] for r in raw})!=3 or len({r['resource'] for r in raw})!=3:
        return 'NACK'
    return 'EVIDENCE_ELIGIBLE' if len({(r['sha'],r['epoch']) for r in raw})==1 else 'NACK'

def lanes_gate(v):
    if set(v)!= {'PLAN','EXECUTE','VERIFY_SECURITY'}: return 'NOT_RUN'
    for r in v.values():
        if not r.get('raw') or not r.get('request'): return 'NOT_RUN'
        if r['required']!=r['served']: return 'MODEL_REQUIRED_NOT_SERVED'
    return 'EVIDENCE_ELIGIBLE' if len({r['epoch'] for r in v.values()})==1 else 'MODEL_REQUIRED_NOT_SERVED'

def sbl_gate(v):
    if not v.get('consent') or not v.get('user_issuer'): return 'NACK_USER_BOUNDARY'
    required={'INSTALL','ADD','LIST1','REMOVE','LIST2','UNINSTALL'}
    raw=v.get('raw',{})
    if set(raw)!=required: return 'NOT_RUN'
    if len(set(raw.values()))!=6: return 'NACK_RECEIPT_ALIAS'
    return 'EVIDENCE_ELIGIBLE' if v.get('persisted') and v.get('removed') and v.get('zero_residue') else 'HOLD'

def gb_gate(v):
    if not v.get('revoke_effective') or v.get('old_token_can_spawn'): return 'NACK_REVOKED_TOKEN'
    if not v.get('old_pid') or not v.get('new_pid') or v['old_pid']==v['new_pid']: return 'HOLD'
    if v.get('external_trigger') or not v.get('native_successor') or not v.get('zero_residue'): return 'HOLD'
    return 'EVIDENCE_ELIGIBLE'

def writeset_gate(v): return 'CI_DESIGN_ELIGIBLE' if set(v['changed']) <= set(v['allowed']) else 'CI_FAIL'

def path_gate(v):
    root=ntpath.normcase(ntpath.normpath(v['allowed']))
    resolved=ntpath.normcase(ntpath.normpath(v['resolved']))
    try: inside=ntpath.commonpath([root,resolved])==root
    except ValueError: inside=False
    return 'ELIGIBLE' if inside and v.get('all_ancestors_resolved') else 'ROOT_ALIAS_OR_PATH_ESCAPE'

def subject_gate(v): return 'ELIGIBLE' if v['current']==v['raw_subject'] else 'SUBJECT_STALE_HOLD'

def applicability_gate(v):
    if v['disposition']=='FULL_PRODUCT_DEFERRED': return 'DEFERRED_WITH_REASON'
    if v['disposition']=='CONDITIONAL' and not v.get('trigger'): return 'NOT_APPLICABLE_TO_BOOT'
    return 'EXECUTE_NOW_CANDIDATE' if v.get('admitted') else 'HOLD_ADMISSION'

def claimed_artifact_gate(v):
    return 'DESIGN_ONLY_NACK' if v.get('authority')!='NATIVE_VERIFIED_BY_EXISTING_OWNER' or not v.get('native_verification_receipt') else 'EVIDENCE_ELIGIBLE'

def receipt_gate(v):
    keys=('domain','workorder','operation','resource','candidate_sha','epoch')
    return 'ELIGIBLE' if all(v['expected'][k]==v['actual'][k] for k in keys) else 'RECEIPT_IDENTITY_MISMATCH'

def retry_gate(v):
    if v['state']=='UNKNOWN_EFFECT': return 'RECONCILE_FIRST'
    if v['state'] in ('EFFECT_OBSERVED','NONCE_CONSUMED'): return 'NO_REPLAY'
    return 'NEW_ATTEMPT_REQUIRES_VALID_ADMISSION'

def dependency_cut(nodes, held):
    # Synthetic graph oracle only; no scheduler or persistent runtime state.
    affected=set(held)
    while True:
        new=affected | {k for k,v in nodes.items() if set(v)&affected}
        if new==affected: break
        affected=new
    return affected

def proposal_gate(v):
    if v.get('entry')=='sbl-commander-sp': return 'DISABLED_NACK'
    if not all(v.get(k) for k in ('non_commander_abi_proven','sbl_owner_ratification','runtime_readback','admitted')):
        return 'SBL_PROPOSAL_ABI_UNBOUND'
    return 'PROPOSAL_CANDIDATE_ELIGIBLE'
