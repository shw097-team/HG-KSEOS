param([Parameter(Mandatory=$true)][string]$DeliveryRoot)
$exampleResults = @()
Get-ChildItem -LiteralPath (Join-Path $DeliveryRoot 'PKG') -Filter '*.md' -File | ForEach-Object {
    $bookPath = $_.FullName
    $bookText = Get-Content -LiteralPath $bookPath -Raw -Encoding utf8
    $examples = [regex]::Matches($bookText, '(?ms)^```powershell\s*\r?\n(.*?)^```\s*$')
    $exampleIndex = 0
    foreach ($example in $examples) {
        $exampleIndex++
        $parseTokens = $null
        $parseErrors = $null
        $null = [System.Management.Automation.Language.Parser]::ParseInput($example.Groups[1].Value, [ref]$parseTokens, [ref]$parseErrors)
        $exampleResults += [pscustomobject]@{Book=$bookPath;Example=$exampleIndex;Status=$(if ($parseErrors.Count -eq 0) {'PASS'} else {'FAIL'});Errors=@($parseErrors | ForEach-Object {$_.Message});Execution='PARSE_ONLY_NOT_EXECUTED'}
    }
}
$exampleResults | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $DeliveryRoot 'evidence\POWERSHELL_PARSE_REPORT.json') -Encoding utf8
$exampleResults | Select-Object Book,Example,Status,Execution | Format-List
if (@($exampleResults | Where-Object {$_.Status -eq 'FAIL'}).Count -gt 0) {exit 1}
