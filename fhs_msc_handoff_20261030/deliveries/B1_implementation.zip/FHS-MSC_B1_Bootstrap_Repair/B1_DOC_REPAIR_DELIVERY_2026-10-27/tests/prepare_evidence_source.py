from pathlib import Path
import json,re,hashlib,collections,sys
ROOT=Path('outputs/B1_DOC_REPAIR_DELIVERY_2026-10-27').resolve()
CTX=json.loads((ROOT/'BUILD_CONTEXT.json').read_text(encoding='utf-8'))
MAN=json.loads((ROOT/'SOURCE_SHA_MANIFEST.json').read_text(encoding='utf-8'))
names=CTX['book_names']
def load(p):return p.read_text(encoding='utf-8-sig')
def dump(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding='utf-8')
sources={v['path']:v for v in MAN['sources']}
texts={p:load(Path(p)) for p in sources}
sha_index=collections.defaultdict(list)
for p,v in sources.items():sha_index[v['sha256']].append(p)
baseline=[load(ROOT/'BASELINE'/(Path(n).stem+'.source')) for n in names]
current=[load(ROOT/'PKG'/n) for n in names]
def blocks(s):return [json.loads(m.group(1)) for m in re.finditer(r'^```json\s*\n([\s\S]*?)^```\s*$',s,re.M)]
parents={o['test_id'] for o in blocks(current[5]) if 'test_id' in o}
slots={o['slot_id'] for o in blocks(current[2]) if 'slot_id' in o}
errors=[]
for child in (o for o in blocks(current[5]) if 'parent_id' in o):
 if child['parent_id'] not in parents:errors.append(dict(child=child['id'],missing_parent=child['parent_id']))
 if child['workorder_id'] not in slots:errors.append(dict(child=child['id'],missing_slot=child['workorder_id']))
hashrefs=[]
for i,s in enumerate(baseline):
 for n,line in enumerate(s.splitlines(),1):
  # Exact external hash locators in original preserved prose and JSON.
  if 'source_clause' in line or '上位來源' in line:
   for h in re.findall(r'(?:(?<!_)sha256[:=]|\.md@)([0-9a-f]{64})',line):
    hashrefs.append(dict(book=names[i],original_line=n,hash=h,status='RAW_HASH_AVAILABLE' if h in sha_index else 'SOURCE_REF_UNVERIFIED',resolved_sources=sha_index.get(h,[]),clause=line))
dump(ROOT/'SOURCE_REFERENCE_AUDIT.json',dict(internal_join_errors=errors,internal_parent_count=len(parents),internal_slot_count=len(slots),external_hash_refs=hashrefs,unverified_historical_refs_explicit=True,scope='Historical exact hashes preserved. Available hash is source bytes only, not current ratification. Unknown historical refs remain UNVERIFIED, never silently rebound.'))

# One row per plan RCA, plus exact history/upstream/before/after evidence.
# doc = affected document; terms locate original clauses independently of plan prose.
mapping={
1:(0,'PL-003','SOURCE', 'DOC-NEG-01','OWNER_OR_NATIVE_DEPENDENCY'),
2:(1,'PL-004','oracle','DOC-NEG-02','OWNER_OR_NATIVE_DEPENDENCY'),
3:(7,'PROMPT_COMPILE_PASS','CLI','DOC-ID-08','OWNER_OR_NATIVE_DEPENDENCY'),
4:(0,'NORMATIVE','provenance','DOC-ID-06','PATCHED'),
5:(2,'SOURCE_COMPILER_HOLD','binding','SCENARIO-A-HOLD-BC-READY','PATCHED'),
6:(3,'Bootstrap','permission','SCENARIO-NO-PERMIT','OWNER_OR_NATIVE_DEPENDENCY'),
7:(0,'Standing','Owner','DOC-ID-06','PATCHED'),
8:(5,'單一人類','Maker','DOC-NEG-07','PATCHED'),
9:(3,'Administrator','Owner','DOC-ID-06','PATCHED'),
10:(3,'Receiver','RECEIVER','OPS-TOKEN-AND-USER-BOUNDARY','OWNER_OR_NATIVE_DEPENDENCY'),
11:(5,'SID','maker_id','DOC-NEG-07','PATCHED'),
12:(1,'12','Profile','DOC-NEG-03','OWNER_OR_NATIVE_DEPENDENCY'),
13:(5,'TQAEP','定義','DOC-NEG-04','PATCHED'),
14:(3,'at-most-once','at-most-once','DOC-NEG-18','PATCHED'),
15:(2,'EffectClass','effect_class','DOC-ID-03','PATCHED'),
16:(7,'Method','METHOD','DOC-NEG-05','PATCHED'),
17:(3,'User','USER','OPS-TOKEN-AND-USER-BOUNDARY','PATCHED'),
18:(8,'Commander','plan.propose','SCENARIO-COMMANDER','OWNER_OR_NATIVE_DEPENDENCY'),
19:(8,'Commander','Commander','SCENARIO-COMMANDER','PATCHED'),
20:(6,'KP','Required','DOC-ID-05','PATCHED'),
21:(6,'1,565','949','DOC-ID-05','PATCHED'),
22:(6,'Conditional','Conditional','DOC-NEG-15','PATCHED'),
23:(5,'Runner','runner','DOC-NEG-04','PATCHED'),
24:(4,'Context','persisted','SCENARIO-A-HOLD-BC-READY','OWNER_OR_NATIVE_DEPENDENCY'),
25:(2,'停工','HOLD','SCENARIO-A-HOLD-BC-READY','PATCHED'),
26:(0,'Seal','G-A','DOC-NEG-06','PATCHED'),
27:(4,'NOT_RUN','R3','DOC-NEG-09','PATCHED'),
28:(4,'Compaction','Host','DOC-ID-06','PATCHED'),
29:(0,'PARK','StopLoss','DOC-NEG-06','PATCHED'),
30:(6,'Context','949','DOC-ID-05','PATCHED'),
31:(0,'WORK_QUEUE','Hermes','SCENARIO-A-HOLD-BC-READY','PATCHED'),
32:(4,'Trigger','R2','GB-SAME-PID-REJECTED','OWNER_OR_NATIVE_DEPENDENCY'),
33:(8,'Activator','RAW-FAB','DOC-NEG-08','ALREADY_SATISFIED'),
34:(4,'Required','R4','DOC-NEG-09','OWNER_OR_NATIVE_DEPENDENCY'),
35:(4,'ADR-0008','DEV','DOC-NEG-12','OWNER_OR_NATIVE_DEPENDENCY'),
36:(5,'五','Raw','DOC-ID-10','OWNER_OR_NATIVE_DEPENDENCY'),
37:(4,'Loaded','Loaded','DOC-NEG-14','ALREADY_SATISFIED'),
38:(4,'Executor','CAS','DOC-NEG-18','OWNER_OR_NATIVE_DEPENDENCY'),
39:(8,'add','RAW-SBL','DOC-NEG-10','ALREADY_SATISFIED'),
40:(8,'GWO','receipt','DOC-NEG-17','ALREADY_SATISFIED'),
41:(8,'Revoke','Revoke','GB-SAME-PID-REJECTED','ALREADY_SATISFIED'),
42:(4,'Untracked','untracked','DOC-NEG-13','ALREADY_SATISFIED'),
43:(7,'Draft','Host','DOC-ID-06','PATCHED'),
44:(6,'SWOF','R15','DOC-ID-05','PATCHED'),
45:(5,'獨立','Claim Ceiling','DOC-NEG-07','ALREADY_SATISFIED'),
46:(1,'fallback','P4','DOC-NEG-09','PATCHED'),
47:(0,'每張','生命週期','DOC-ID-06','PATCHED'),
48:(4,'HEAD','Candidate paths','DOC-ID-09','OWNER_OR_NATIVE_DEPENDENCY')}
plan_path=next(p for p in sources if Path(p).name.startswith('FHS_MSC_B1_DOC00-08_Codex_High_Automation_Repair_Plan'))
planlines=texts[plan_path].splitlines()
matrix={}
for line_no,line in enumerate(planlines,1):
 m=re.match(r'^\| (\d{2}) \|',line)
 if m:matrix[int(m.group(1))]=(line_no,line)
assert len(matrix)==48
history_names=['B1施工狀況_總鑑定分析.md','B1指揮施工_總紀錄.md','B1施工_PROMPT.md','FHS_MSC_B1_Task_Handoff_Report_v1_2026-10-27.md']
history=[p for name in history_names for p in sources if Path(p).name==name]
upstream=[p for p in sources if Path(p).name in ('FHS-MSC_藍圖_r2.md','FHS-MSC_總討論.md') or Path(p).name.startswith(('PIPD_LS_DOC-','SBL_PIPD-LS-PKG_DOC-'))]
anchors=['repair-control','repair-source-abi','repair-binding','repair-ops-boundary','repair-hotpath','repair-evidence-stages','repair-product-denominator','repair-tool-binding','repair-gwo-entry']
def excerpt(p,term):
 lines=texts[p].splitlines();hits=[i for i,x in enumerate(lines) if term.casefold() in x.casefold() and not re.search(r'[0-9a-f]{40}',x)]
 if not hits:return None
 i=hits[-1] if Path(p).name.startswith('B1') else hits[0]
 a=max(0,i-1);b=min(len(lines),i+2)
 return dict(source=p,sha256=sources[p]['sha256'],line_start=a+1,line_end=b,text='\n'.join(lines[a:b]),evidence_class='REPORTED_NOT_REPLAYED' if p in history else 'CONFIRMED_SOURCE_BYTES_NOT_AUTHORITY_ADMISSION')
rcas=[]
for num,(doc,term,before_term,test,classification) in mapping.items():
 lineno,planrow=matrix[num]
 hist=[e for p in history if (e:=excerpt(p,term))][:2]
 upstream_term='Oracle' if num in (2,13,23,45) else 'axes' if num==12 else '單一' if num in (7,8,9,11) else 'Bootstrap' if num in (1,5,6,19,21,22,24,25,26,27,28,29,30,31,32,44,47,48) else term
 ups=[e for p in upstream if (e:=excerpt(p,upstream_term))][:1]
 if not ups:
  fallback={15:'effect',35:'scope',40:'Oracle'}.get(num,'Bootstrap')
  ups=[e for p in upstream if (e:=excerpt(p,fallback))][:1]
 before_lines=baseline[doc].splitlines()
 exact_before={1:'1. SOURCE：',3:'此冊補完',5:'def choose_binding',7:'**權責**',10:'| RECEIVER |',12:'**Profile input',16:'任何工具方法',20:'## 3.',25:'def choose_binding',27:'### R3',32:'### R2',34:'### R4',35:'## R17',40:'## 5.',43:'### Native stdout',46:'**Profile input'}
 before_term=exact_before.get(num,before_term)
 hits=[i for i,line in enumerate(before_lines) if i>=14 and before_term.casefold() in line.casefold()]
 idx=hits[0] if hits else 14
 after_lines=current[doc].splitlines();a=next(i for i,x in enumerate(after_lines) if f'id="{anchors[doc]}"' in x)
 end=next((i for i in range(a+2,len(after_lines)) if after_lines[i].startswith('## ') and i>a+2),len(after_lines))
 row=dict(rca=f'RCA-{num:02}',closure_class=classification,document_result='ALREADY_SATISFIED_WITH_CLARIFICATION' if classification=='ALREADY_SATISFIED' else 'PATCHED_DESIGN_CONTRACT',plan=dict(source=plan_path,sha256=sources[plan_path]['sha256'],line=lineno,clause=planrow),history_evidence=hist,upstream_evidence=ups,before=dict(file=names[doc],source_sha256=MAN['originals'][doc]['sha256'],line_start=idx+1,line_end=min(idx+3,len(before_lines)),clause='\n'.join(before_lines[idx:idx+3])),after=dict(file='PKG/'+names[doc],line_start=a+1,line_end=end,anchor=anchors[doc],clause='\n'.join(after_lines[a:end])),reason=planrow.split('|')[4].strip(),test=test,residual='Original Domain Owner/ABI/Runner/Host readback remains required; no native conclusion' if classification=='OWNER_OR_NATIVE_DEPENDENCY' else 'Runtime enforcement and formal acceptance remain NOT_RUN even when document clause is closed',test_result='PENDING_ACTUAL_TEST_RUN')
 rcas.append(row)
dump(ROOT/'RCA_EVIDENCE.json',rcas)
lines=['# RCA-01～48 覆蓋與結案分類','', '48/48 是逐項可追溯覆蓋；文檔修法結案不代表 Runtime 已修。每項具 source SHA＋原始行段＋before/after 全 clause，詳 RCA_EVIDENCE.json。','', '| RCA | 結案分類 | 文檔處置 | 修補位置 | 真測試 | 殘留 |','|---|---|---|---|---|---|']
for r in rcas:lines.append(f"| {r['rca']} | {r['closure_class']} | {r['document_result']} | [{Path(r['after']['file']).stem}]({r['after']['file']}#{r['after']['anchor']}) | {r['test']} | {r['residual']} |")
(ROOT/'RCA_48_COVERAGE.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
dump(ROOT/'AUTHORITY_AND_VERSION_MATRIX.json',dict(baseline='Exact 9 source SHA match Plan appendix B; all internal version/family/lineage agree',native_ratification='NOT_GRANTED',command_authority='User explicitly invoked command; bounded design use preauthorized',domain_writers=dict(PI_PD_ECP_TQAEP='PIPD_CANONICAL_ONLY',native_issuer='HGK_ONLY',durable_work='Hermes_AND_EXISTING_SharedSpine_ONLY',active_policy='Fabric_EXISTING_ONLY',product_proposal='SBL_EXISTING_OWNER_ONLY'),divergences=[dict(kind='HISTORICAL_R2_REFERENCE',state='UNVERIFIED',reason='Exact dddc6b... bytes absent; available blueprint b7c788... is not substituted'),dict(kind='SOURCE_RELOCATION',state='SAME_BYTES_RELOCATED_DURING_RUN',details=json.loads((ROOT/'SOURCE_RELOCATION_LOG.json').read_text(encoding='utf-8')))]))
print('RCA coverage',len(rcas),dict(collections.Counter(r['closure_class'] for r in rcas)))
print('Source refs',len(hashrefs),'unverified',sum(r['status']=='SOURCE_REF_UNVERIFIED' for r in hashrefs),'internal errors',len(errors))
print('RCA history missing',[r['rca'] for r in rcas if not r['history_evidence']])
