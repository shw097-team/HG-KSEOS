from pathlib import Path
import sys,re,json,hashlib,ast,collections,copy,traceback,subprocess,datetime
import yaml
from markdown_it import MarkdownIt
import contract_model as model

ROOT=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(__file__).resolve().parent.parent
MODE=sys.argv[2] if len(sys.argv)>2 else 'GREEN'
CTX=json.loads((ROOT/'BUILD_CONTEXT.json').read_text(encoding='utf-8'))
NAMES=CTX['book_names']
BASE=[(ROOT/'BASELINE'/(Path(n).stem+'.source')).read_text(encoding='utf-8-sig') for n in NAMES]
DOC=BASE if MODE=='RED' else [(ROOT/'PKG'/n).read_text(encoding='utf-8') for n in NAMES]
MD=MarkdownIt('commonmark').enable('table')
def tokens(s): return MD.parse(s)
def fences(s,lang=None): return [t for t in tokens(s) if t.type=='fence' and (lang is None or t.info.strip()==lang)]
def objects(s): return [json.loads(t.content) for t in fences(s,'json')]
def headings(s,level):
 ts=tokens(s); return [ts[i+1].content for i,t in enumerate(ts[:-1]) if t.type=='heading_open' and t.tag==f'h{level}']
def unique(values):
 values=list(values);c=collections.Counter(values); assert len(c)==len(values),[k for k,v in c.items() if v!=1]; return set(c)
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def functions(s):
 env={}
 for t in fences(s,'python'): exec(compile(ast.parse(t.content),'<DOC_DESIGN_EXAMPLE>','exec'),env)
 return env
ENV={i:functions(DOC[i]) for i in (0,1,2,5)}
def binding(slot,repo_probe=None,host_probe=None,read_probe=None):
    fn=ENV[2]['choose_binding']
    import inspect
    args=dict(repo_probe=repo_probe,host_probe=host_probe)
    if 'read_probe' in inspect.signature(fn).parameters: args['read_probe']=read_probe
    return fn(slot,**args)
results=[]
def case(id,fn,scope='DOC_STATIC_OR_ISOLATED_FIXTURE'):
 try:
  detail=fn();results.append(dict(id=id,status='PASS',scope=scope,detail=detail or 'Assertions passed'))
 except Exception as e:
  results.append(dict(id=id,status='FAIL',scope=scope,detail=f'{type(e).__name__}: {e}'))
def eq(a,b): assert a==b,(a,b)
def meta(s):return yaml.safe_load(s.split('---',2)[1])
def slot_objects(s):return [o for o in objects(s) if 'slot_id' in o]
def group_objects(s,key):return {o[key]:o for o in objects(s) if key in o}

def identity1():
 eq(len(list((ROOT/'PKG').glob('*.md'))),9)
 manifest=json.loads((ROOT/'SOURCE_SHA_MANIFEST.json').read_text(encoding='utf-8'))
 for i,n in enumerate(NAMES):
  eq(sha(ROOT/'BASELINE'/(Path(n).stem+'.source')),manifest['originals'][i]['sha256'])
  if MODE!='RED':eq(sha(ROOT/'PKG'/n),manifest['candidate'][i]['sha256'])
 return '9 books; original/candidate SHA recomputed'
def identity2():
 a=unique(re.match(r'(PI-B1-[ABC][1-9])',h).group(1) for h in headings(BASE[1],3))
 b=unique(re.match(r'(PI-B1-[ABC][1-9])',h).group(1) for h in headings(DOC[1],3))
 eq(a,b);eq(len(b),27)
def identity3():
 a=slot_objects(BASE[2]);b=slot_objects(DOC[2]);eq(len(b),31);unique(v['slot_id'] for v in b);eq(a,b)
 eq(dict(collections.Counter(v['effect_class'] for v in b)),dict(READ_ONLY_PROBE=10,REPOSITORY_WRITE=5,HOST_OPERATIONS=14,USER_DATA_EFFECT=2))
def identity4():
 for key,count in [('test_id',120),('id',124),('node_id',38)]:
  a=group_objects(BASE[5],key);b=group_objects(DOC[5],key);eq(a,b);eq(len(b),count)
  unique(o[key] for o in objects(DOC[5]) if key in o)
def identity5():
 def r15(s):
  out={}
  ms=list(re.finditer(r'^#### (R15-\d{3})[｜|]',s,re.M))
  for i,m in enumerate(ms):
   end=ms[i+1].start() if i+1<len(ms) else s.index('\n## 4.',m.start())
   assert m.group(1) not in out;out[m.group(1)]=s[m.start():end]
  return out
 a=r15(BASE[6]);b=r15(DOC[6]);eq(a,b);eq(len(b),949)
 def cells(s): return [x for x in s.splitlines() if re.match(r'^\| [0-9a-f]{12} \|',x)]
 eq(cells(BASE[6]),cells(DOC[6]));eq(len(cells(DOC[6])),192);unique(x.split('|')[1].strip() for x in cells(DOC[6]))
 asset=[(k,v) for k,v in b.items() if re.match(r'#### R15-\d{3}｜(?:CONTRACT|PIPD_CLI|METHOD|DONOR_SLOT):',v)]
 eq(len(asset),81)
 return '949 complete record bodies + 192 complete rows + 81 named assets unchanged'
def identity6():
 for i,s in enumerate(DOC):
  m=meta(s);eq(m['task_kind'],'DESIGN');eq(m['claim_ceiling'],'AUTHOR_SIDE_REPAIR_CANDIDATE')
  eq(m['formal_sourcefreeze'],'HOLD');eq(m['native_effect'],'NOT_RUN');eq(m['release'],'NOT_RUN');eq(m['independent_checker_receipt'],'NOT_RUN')
  eq(m['version'],CTX['revision']);eq(m['design_use'],'OWNER_PREAUTHORIZED_B1_DESIGN_USE');eq(m['native_authority'],'FORMAL_NATIVE_NOT_GRANTED')
  eq(m['supersedes_subject_sha256'],sha(ROOT/'BASELINE'/(Path(NAMES[i]).stem+'.source')))
def identity7():
 pattern=r'^\| B1-[ABC][1-9] \|.*$'
 eq(re.findall(pattern,BASE[0],re.M),re.findall(pattern,DOC[0],re.M));eq(len(re.findall(pattern,DOC[0],re.M)),27)
 assert 'METHOD_REQUIRED_NOT_INVOKED' in DOC[0] and 'REQUIRED_METHOD_NOT_INVOKED' in DOC[0]
def identity8():
 counter=collections.Counter()
 for i,s in enumerate(DOC):
  assert len(re.findall(r'^```',s,re.M))%2==0
  for t in fences(s):
   lang=t.info.strip();counter[lang]+=1
   if lang=='json':json.loads(t.content)
   elif lang in ('yaml','yml'):yaml.safe_load(t.content)
   elif lang=='python':ast.parse(t.content)
   elif lang=='powershell':
    assert not re.search(r'\$(?:home|codex_home)\s*=',t.content,re.I),'reserved variable assignment'
  yaml.safe_load(s.split('---',2)[1])
  assert len(fences(s))>=len(fences(BASE[i]))
 return dict(counter)
def identity9():
 expected=set(NAMES);eq({p.name for p in (ROOT/'PKG').glob('*')},expected)
 for n in NAMES:assert (ROOT/'DIFF'/(Path(n).stem+'.diff')).is_file()
 # Candidate write set only; verify the construction did not alter any inventoried source.
 manifest=json.loads((ROOT/'SOURCE_SHA_MANIFEST.json').read_text(encoding='utf-8'))
 checked=0
 for v in manifest['sources']:
  p=Path(v['path'])
  if p.is_file():eq(sha(p),v['sha256']);checked+=1
 return {'source_hashes_reread':checked,'scope':'available sources; offline replay may omit external source paths'}
def identity10():
 for s in DOC:
  for target in re.findall(r'\]\(([^)]+\.md(?:#[^)]*)?)\)',s):
   name,_,anchor=target.partition('#');p=ROOT/'PKG'/name
   assert p.exists(),target
   if anchor:assert f'id="{anchor}"' in p.read_text(encoding='utf-8'),target
 # Parsed source fields retain original external references; unresolved historical hashes aren't silently replaced.
 for i in (1,2,3,5,6):
  original=objects(BASE[i]);repaired=objects(DOC[i]);eq(original,repaired)
 report=json.loads((ROOT/'SOURCE_REFERENCE_AUDIT.json').read_text(encoding='utf-8'))
 assert report['unverified_historical_refs_explicit'] is True
 assert report['internal_join_errors']==[]

for id,fn in enumerate((identity1,identity2,identity3,identity4,identity5,identity6,identity7,identity8,identity9,identity10),1):case(f'DOC-ID-{id:02}',fn)

READ=dict(read_scope_valid=True,same_subject=True,fresh=True,no_mutation=True)
REPO=dict(real_root=r'C:\synthetic\repo',head='a'*40,writable_scope=['docs/x.md'],currentness='FRESH',dirty_conflict=False,path_escape=False,owner_scope_valid=True,dev_admission_valid=True,dev_ecp_valid=True)
HOST=dict(active_policy_epoch=3,issuer='synthetic-validated-native-issuer',receiver='synthetic-receiver',ecp_ref='synthetic-ecp',evidence_ref='SYNTHETIC_NOT_RAW',permit_valid=True,same_subject=True,scope_valid=True,nonce_fresh=True,ttl_valid=True,not_revoked=True,preimage_valid=True,user_consent=True,user_issuer=True,synthetic_scope_valid=True)
FIXTURE=dict(runner_route='synthetic',effect_class='HOST_OPERATIONS',expected_identity={k:k for k in ('candidate_sha','subject_sha','policy_epoch','workorder_id','operation_id')},readback={'schema_id':'synthetic-schema'})
REG={'synthetic':dict(runner_id='synthetic',abi_version='1',schema_id='synthetic-schema',executable_path='SYNTHETIC_NOT_EXECUTED',sha256='a'*64,allowed_os=['Windows'],read_scope=['synthetic'],permission_scope=['synthetic'],owner_signature='SYNTHETIC_NOT_A_SIGNATURE')}
RAW=dict(FIXTURE['expected_identity'],raw_sha='b'*64,domain_payload={'value':1},maker_id='Maker',checker_id='Checker',maker_principal_uuid='principal-m',checker_principal_uuid='principal-c',maker_sid='sid-m',checker_sid='sid-c',credential_fingerprints_distinct=True,checker_readonly_acl_verified=True,maker_cannot_write_checker=True,domain_schema='synthetic-schema')
def neg1():
 eq(model.source_gate(['ACTUAL_DOC','FUTURE_NATIVE_TASK_KIND'],['ACTUAL_DOC']),'RECLASSIFY_C5_EFFECT_ADMISSION')
 eq(model.source_gate(['ACTUAL_DOC'],[]),'SOURCE_MISSING');eq(model.source_gate(['ACTUAL_DOC'],['ACTUAL_DOC']),'CANDIDATE_SOURCE_READY');assert 'PL-003 ×2' in DOC[0]
def neg2():
 v=dict(canonical_writer='DOC-07',alias='DOC-03 DOMAIN_ORACLES',owner_ratification=True,schema_sha='a',source_sha='b',roundtrip=True)
 eq(model.oracle_gate(v),'BOUND_DESIGN');v['owner_ratification']=False;eq(model.oracle_gate(v),'ORACLE_UNBOUND');assert 'LEGACY_DOC03_ABI_CANDIDATE' in DOC[1]
def neg3():
 axes=[f'canonical-{n}' for n in range(12)];v=dict(axes=axes,mapping={a:['verification'] for a in axes},owner_ratification=True,vetoes=['risk-11'],projected_vetoes=['risk-11'],required_weight=3,new_weight=3)
 eq(model.profile_gate(v),'BOUND_DESIGN');v['projected_vetoes']=[];eq(model.profile_gate(v),'PROFILE_MAPPING_REJECTED');del v['mapping'][axes[-1]];eq(model.profile_gate(v),'PROFILE_MAPPING_UNBOUND');assert '十二' in DOC[1] and 'PROFILE_MAPPING_UNBOUND' in DOC[1]
def neg4():
 eq(ENV[5]['verify_receipt'](FIXTURE,None,REG),'BLOCKED_MISSING_BINDING_OR_RAW')
 for field in REG['synthetic']:
  registry=copy.deepcopy(REG);del registry['synthetic'][field]
  eq(ENV[5]['verify_receipt'](FIXTURE,RAW,registry),'BLOCKED_MISSING_RUNNER')
 assert 'DESIGN_PLANNED' in DOC[5]
def neg5():
 policy=dict(owner_signature='SYNTHETIC',policy_epoch=3,mandatory_set=['KANBAN'])
 eq(ENV[0]['resolve_methods']({'id':'WO'},policy,{})['first_fail'],'METHOD_REQUIRED_NOT_INVOKED')
 receipt={('WO','KANBAN',3):dict(operation='REAL_INVOKE',same_subject=True,raw_sha='x')}
 eq(ENV[0]['resolve_methods']({'id':'WO'},policy,receipt)['gate'],'METHODS_EVIDENCED')
def neg6():
 fn=ENV[0]['mission_completion'];s=dict(authority='SharedSpine',fresh=True,ready=1,running=0,parked=0)
 eq(fn(s,{}),'CONTINUE_LEGAL_READY');s.update(ready=0,running=1);eq(fn(s,{}),'CONTINUE_LEGAL_READY');s.update(running=0,parked=1);eq(fn(s,{}),'PARKED_WAITING_FOR_TRIGGER')
def neg7():
 raw=dict(RAW,maker_sid='same',checker_sid='same');eq(ENV[5]['verify_receipt'](FIXTURE,raw,REG),'FAIL_SELF_ACCEPTANCE')
 raw=dict(RAW,checker_id='Ｍａｋｅｒ');eq(ENV[5]['verify_receipt'](FIXTURE,raw,REG),'FAIL_SELF_ACCEPTANCE')
 eq(ENV[5]['verify_receipt'](FIXTURE,RAW,REG),'CHECKER_DOMAIN_PREDICATE_REQUIRED')
def neg8():
 v=dict(approved=True,consumer_ack=True,**{k:dict(event=k,resource=k,sha='s',epoch=3) for k in ('stage','loaded','consumer')})
 eq(model.fabric_gate(v),'EVIDENCE_ELIGIBLE');v['consumer']=None;eq(model.fabric_gate(v),'HOLD');assert 'CONSUMER' in DOC[8]
def neg9():
 v={k:dict(request=k,raw=k,required='model-A',served='model-A',epoch=3) for k in ('PLAN','EXECUTE','VERIFY_SECURITY')}
 eq(model.lanes_gate(v),'EVIDENCE_ELIGIBLE');v['EXECUTE']['served']='model-B';eq(model.lanes_gate(v),'MODEL_REQUIRED_NOT_SERVED');assert 'Required=Served' in DOC[4]
def neg10():
 v=dict(consent=True,user_issuer=True,raw={'INSTALL':'install'},persisted=True,removed=True,zero_residue=True)
 eq(model.sbl_gate(v),'NOT_RUN');v['raw']={k:k for k in ('INSTALL','ADD','LIST1','REMOVE','LIST2','UNINSTALL')};eq(model.sbl_gate(v),'EVIDENCE_ELIGIBLE')
def neg11():
 v=dict(revoke_effective=True,old_token_can_spawn=False,old_pid=1,new_pid=2,external_trigger=False,native_successor=True,zero_residue=True)
 eq(model.gb_gate(v),'EVIDENCE_ELIGIBLE');v['old_token_can_spawn']=True;eq(model.gb_gate(v),'NACK_REVOKED_TOKEN')
def neg12():
 eq(model.writeset_gate(dict(changed=['ADR-0008','ADR-0009'],allowed=['src/a.py'])),'CI_FAIL')
 eq(model.writeset_gate(dict(changed=['src/a.py'],allowed=['src/a.py'])),'CI_DESIGN_ELIGIBLE');assert 'ADR-0008/0009' in DOC[4]
def neg13():
 eq(model.path_gate(dict(allowed=r'C:\allowed',resolved=r'C:\outside\junction',all_ancestors_resolved=True)),'ROOT_ALIAS_OR_PATH_ESCAPE')
 eq(model.path_gate(dict(allowed=r'C:\allowed',resolved=r'C:\allowed-escape\x',all_ancestors_resolved=True)),'ROOT_ALIAS_OR_PATH_ESCAPE')
 eq(model.path_gate(dict(allowed=r'C:\allowed',resolved=r'C:\allowed\x',all_ancestors_resolved=True)),'ELIGIBLE')
def neg14():
 eq(model.subject_gate(dict(current='new-head',raw_subject='old-head')),'SUBJECT_STALE_HOLD');eq(model.subject_gate(dict(current='new-head',raw_subject='new-head')),'ELIGIBLE')
def neg15():
 eq(model.applicability_gate(dict(disposition='CONDITIONAL',trigger=False,admitted=True)),'NOT_APPLICABLE_TO_BOOT')
 eq(model.applicability_gate(dict(disposition='FULL_PRODUCT_DEFERRED',trigger=True,admitted=True)),'DEFERRED_WITH_REASON')
 eq(model.applicability_gate(dict(disposition='CONDITIONAL',trigger=True,admitted=True)),'EXECUTE_NOW_CANDIDATE');assert '不回寫產品義務' in DOC[6]
def neg16():
 eq(model.claimed_artifact_gate(dict(kind='HGK_PERMIT',authority='HAND_WRITTEN_JSON',native_verification_receipt=None)),'DESIGN_ONLY_NACK');assert meta(DOC[0])['native_effect']=='NOT_RUN'
def neg17():
 v={k:k for k in ('domain','workorder','operation','resource','candidate_sha','epoch')}
 eq(model.receipt_gate(dict(expected=v,actual=v)),'ELIGIBLE')
 for k in v:
  bad=dict(v);bad[k]='foreign';eq(model.receipt_gate(dict(expected=v,actual=bad)),'RECEIPT_IDENTITY_MISMATCH')
def neg18():
 eq(model.retry_gate(dict(state='UNKNOWN_EFFECT')),'RECONCILE_FIRST');eq(model.retry_gate(dict(state='NONCE_CONSUMED')),'NO_REPLAY');eq(model.retry_gate(dict(state='NOT_ATTEMPTED')),'NEW_ATTEMPT_REQUIRES_VALID_ADMISSION');assert 'UNKNOWN_EFFECT' in DOC[3]
for i,fn in enumerate((neg1,neg2,neg3,neg4,neg5,neg6,neg7,neg8,neg9,neg10,neg11,neg12,neg13,neg14,neg15,neg16,neg17,neg18),1):case(f'DOC-NEG-{i:02}',fn,'DOC_LAYER_SYNTHETIC_POSITIVE_AND_NEGATIVE_FIXTURE_NOT_NATIVE')

for slot in slot_objects(DOC[2]):
 def positive(slot=slot):
  result=binding(slot,REPO,HOST,READ)
  eq(result['status'],'READ_ONLY' if slot['effect_class']=='READ_ONLY_PROBE' else 'READY_FOR_OWNER_REVIEW')
 def denied(slot=slot):
  result=binding(slot,None,None,None);assert result['status'] in ('HOLD','NACK','NOFIT'),result
 case('BIND-POS-'+slot['slot_id'],positive)
 case('BIND-NEG-'+slot['slot_id'],denied)

def scenario1():
 fn=binding
 eq(fn({'effect_class':'READ_ONLY_PROBE'},read_probe=READ)['status'],'READ_ONLY')
 eq(fn({'effect_class':'REPOSITORY_WRITE'},dict(REPO,dev_admission_valid=False))['first_fail'],'L2_ADMISSION_HOLD')
 for kind in ('HOST_OPERATIONS','USER_DATA_EFFECT'):
  eq(fn({'effect_class':kind},host_probe=dict(HOST,permit_valid=False))['status'],'NACK')
def scenario2():
 eq(model.dependency_cut({'A':[],'A-child':['A'],'B':[],'C':['B']},{'A'}),{'A','A-child'})
 eq(ENV[0]['mission_completion'](dict(authority='SharedSpine',fresh=True,ready=2,running=0,parked=2),{}),'CONTINUE_LEGAL_READY')
def scenario3():
 eq(model.proposal_gate(dict(entry='sbl-commander-sp')),'DISABLED_NACK')
 eq(model.proposal_gate(dict(entry='unknown')),'SBL_PROPOSAL_ABI_UNBOUND')
 eq(model.proposal_gate(dict(entry='approved-non-commander',non_commander_abi_proven=True,sbl_owner_ratification=True,runtime_readback=True,admitted=True)),'PROPOSAL_CANDIDATE_ELIGIBLE')
 assert 'SBL_PROPOSAL_ABI_UNBOUND' in DOC[8]
 eq([s for s in DOC[6].splitlines() if s.startswith('#### R15-917')],[s for s in BASE[6].splitlines() if s.startswith('#### R15-917')])
case('SCENARIO-NO-PERMIT',scenario1);case('SCENARIO-A-HOLD-BC-READY',scenario2);case('SCENARIO-COMMANDER',scenario3)

def host_token_negatives():
 for field in ('permit_valid','same_subject','scope_valid','nonce_fresh','ttl_valid','not_revoked','preimage_valid'):
  for kind in ('HOST_OPERATIONS','USER_DATA_EFFECT'):
   eq(binding({'effect_class':kind},host_probe=dict(HOST,**{field:False}))['status'],'NACK')
 for field in ('user_consent','user_issuer','synthetic_scope_valid'):
  eq(binding({'effect_class':'USER_DATA_EFFECT'},host_probe=dict(HOST,**{field:False}))['status'],'NOFIT')
def gb_same_pid():
 eq(model.gb_gate(dict(revoke_effective=True,old_token_can_spawn=False,old_pid=7,new_pid=7,external_trigger=False,native_successor=True,zero_residue=True)),'HOLD')
case('OPS-TOKEN-AND-USER-BOUNDARY',host_token_negatives);case('GB-SAME-PID-REJECTED',gb_same_pid)
def optional_method():
 policy=dict(owner_signature='SYNTHETIC',policy_epoch=3,mandatory_set=[],per_wo_selected={'WO':['KANBAN']})
 installed={('WO','KANBAN',3):dict(operation='INSTALLED',same_subject=True,raw_sha='x')}
 eq(ENV[0]['resolve_methods']({'id':'WO'},policy,installed)['first_fail'],'METHOD_SELECTED_BUT_UNPROVEN')
 installed[('WO','KANBAN',3)]['operation']='REAL_INVOKE'
 eq(ENV[0]['resolve_methods']({'id':'WO'},policy,installed)['gate'],'METHODS_EVIDENCED')
case('OPTIONAL-SELECTED-METHOD-REAL-INVOKE',optional_method)
def actual_profile_schema():
 import jsonschema
 schema=json.loads((ROOT/'tests'/'schemas'/'profile.input.schema.json').read_text(encoding='utf-8'))
 payload=objects(DOC[1])[0]
 jsonschema.validate(payload,schema)
 for delta in ({'profile':'ELITE'},{'axes':['intent','intent']},{'profile_request':'LITE'}):
  bad=dict(payload,**delta)
  try:jsonschema.validate(bad,schema)
  except jsonschema.ValidationError:continue
  raise AssertionError('Installed strict schema incorrectly accepted '+repr(delta))
def tool_sets():
 def rows(s):return [line for line in s.splitlines() if line.startswith('| ')]
 original=rows(BASE[7]);candidate=rows(DOC[7])
 for family,count,pattern in [('verb',13,r'^\| \\`[a-z-]+\\`'),('method',25,r'^\| METHOD-\d{2} '),('donor',24,r'^\| SLOT-'),('contract',19,r'^\| (?:ArtifactIdentity|AuthorityBinding|RequirementAtom|ProfileBinding|TechnologyAdmission|PI-PKG|PD-PKG|TraceLink|TaskSpecSeed|ConstructionContract|WorkOrderCandidate|ECP|TQAEP|ExecutionHandoff|EvidenceExpectation|ClaimCeiling|SurfaceProjectionManifest|GENIEProjectionRef|ExecutionBindingRef) \|')]:
  a=[r.split('|')[1].strip() for r in original if re.match(pattern,r)]
  b=[r.split('|')[1].strip() for r in candidate if re.match(pattern,r)]
  eq(len(unique(b)),count);eq(a,b)
def safeguards():
 for prefix in ('**G-A =','**G-B ='):
  eq(next(x for x in DOC[0].splitlines() if x.startswith(prefix)),next(x for x in BASE[0].splitlines() if x.startswith(prefix)))
 gwo=[h for h in headings(DOC[8],2) if re.match(r'[123]\. GWO-',h)]
 eq(len(unique(gwo)),3)
 eq(objects(BASE[3]),objects(DOC[3]))
 # Failure registry and effect payloads remain exact; no second authority writer added.
 authority=json.loads((ROOT/'AUTHORITY_AND_VERSION_MATRIX.json').read_text(encoding='utf-8'))['domain_writers']
 eq(len(authority),5);assert all('ONLY' in v for v in authority.values())
case('P4-PROFILE-STRICT-SCHEMA',actual_profile_schema)
case('TOOL-ASSET-SETS-13-19-25-24',tool_sets)
case('PRESERVED-NATIVE-SAFEGUARDS',safeguards)

native=[dict(id=f'DOC-NEG-{i:02}.NATIVE',status='NOT_RUN',scope='NATIVE_COUNTERPART',reason='No live Owner/Runner/Issuer/Raw/independent Checker bound by this document-only repair') for i in range(1,19)]
native += [dict(id=n,status='NOT_RUN',scope='NATIVE_OR_FORMAL_GATE',reason='Document phase; actual runtime ABI/permission/evidence not acquired') for n in ('C0-C9-PROMPT-COMPILER','R1-TRUST-RECEIVER','R2-HERMES-NEW-PID','R3-FABRIC-LOADED','R4-MODEL-SERVED','G-A','GWO-FABRIC','GWO-HGK','GWO-SBL','G-B')]
payload=dict(mode=MODE,python=sys.executable,command='python tests/validate_delivery.py <delivery-root> '+MODE,claim_ceiling='AUTHOR_SIDE_DOC_STATIC_AND_SYNTHETIC_FIXTURE_ONLY',counts=dict(executed=len(results),passed=sum(r['status']=='PASS' for r in results),failed=sum(r['status']=='FAIL' for r in results),native_not_run=len(native)),results=results,native=native)
report=ROOT/'evidence'/f'{MODE}_TEST_REPORT.json';report.parent.mkdir(parents=True,exist_ok=True);report.write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(payload['counts']))
for r in results:
 if r['status']=='FAIL':print(r['id'],r['detail'])
sys.exit(1 if payload['counts']['failed'] else 0)
