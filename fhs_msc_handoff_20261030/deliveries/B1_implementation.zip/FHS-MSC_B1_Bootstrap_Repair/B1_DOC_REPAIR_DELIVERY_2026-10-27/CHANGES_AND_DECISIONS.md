# 修補與裁決記錄

本次只編修隔離文件候選。九冊基線 SHA 全數等於 Plan 附錄 B；不以檔名／修改時間選版。內文 family/version/lineage 均一致；整合版是重複載體，不是另一本來源。

原 supersedes 指向 r2 rollup 而非單冊 hash，已存入 baseline_lineage；新候選 supersedes_subject_sha256 逐冊釘 r3 原件。原 task_kind／claim ceiling／Native NOT_RUN/HOLD 保留。

逐條 source_locator／old_clause／new_clause／reason／effect_scope／owner／test_case／adverse_effect 見 CHANGES.json 與 DIFF；新增 artifact_id 是本次衍生 locator，原件未有該欄位，沒有冒充既有簽章。

OD-01/02：文件寫集與設計使用已由本次指揮一次預授權。OD-03 SBL Proposal、OD-04 Oracle、OD-05 Profile 仍需原 Domain Owner ratification；OD-06 外部 Repo DEV admission、OD-07 真 Host privilege、OD-08 User Consent/issuer、OD-09 獨立 Checker、OD-10 Native Release 不由本文簽發。

新增 ISSUE-DELTA-01：原 DOC-08 PowerShell 使用唯讀 $HOME（大小寫不敏感），已改 syntheticDataDir；未執行 UserData。ISSUE-DELTA-02：原 verifier 只檢 Runner 兩欄及 Checker 名字，已補現有文字要求的全欄及真技術身份前置。ISSUE-DELTA-03：r2 blueprint 歷史固定 hash/檔名在本地未得相同 raw，保留 SOURCE_REF_UNVERIFIED，不把本地不同 blueprint 視為同位元。
