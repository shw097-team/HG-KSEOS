# 給 Hermes 的下一個合法 WorkOrder 候選

`OBS-B1-A1`（READ_ONLY_PROBE；不是本工具簽發的 Native WorkOrder）。使用本包 PKG 唯一新版的 SHA 做設計候選控制，先核對合法 Read Scope、真 root/alias/reparse／ACL、四庫 HEAD/Dirty、installed/imported/Loaded origins；不先要求未來 Permit 才能讀來源。

讀回現役 SharedSpine 唯一 READY/RUNNING/PARKED 狀態與 Owner/lease/epoch，再唯讀定位 Hermes 真 Executor、既有 OS wakeup、Receiver Trust Resolver、Fabric Consumer 及三 Lane 的真能力。不得新建第二 queue 或調用禁用 Commander-SP。合法唯讀入口未證即記具名 FirstFail/探測替代路徑，停該 probe 並繼續不相依合法工作。

此候選的輸入：PKG SHA、Owner Read Scope、當前根路徑、現役 policy/SharedSpine locator（尚待讀回）。輸出：subject/host/time/root/HEAD/dirty/reparse/ACL/no-effect witness；Source/Runtime/Admission 四 Gate 分開，不宣稱 Loaded 已修。無變更故不要求無效 rollback token。具體 executable/API 先查已裝 registry/parser／help，不杜撰 ABI。

Discovery 後依真消費邊交 Hermes：R1 Trust/Receiver、R2 SharedSpine→Executor→新 PID、R3 Fabric 三 Raw、R4 三 Lane Required=Served 各自獨立 cone。缺 Native admission 只 PARK 受影 Host/User 工作；Repo 修補仍須其真 DEV admission。READY/RUNNING>0 不得以 Report/Seal 完工；全 PARK 附 Owner/first_fail/喚醒條件，不當成功結案。

目前 G-A、GWO-FABRIC/HGK/SBL、G-B 全 NOT_RUN；Oracle、Profile、SBL 非 Commander 提案及 Checker 等未決詳 ISSUE_AND_CR_REGISTER.md。本包沒有真 PIPD SourceFreeze、ExecutionAdmission、HGK Permit、User Consent 或獨立 Checker 收據。
