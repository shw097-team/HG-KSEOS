# 作者側反例覆核（不是正式獨立 Checker）

覆核對象：本包完整 DIFF/FULL.diff、九冊前後正文及 RCA_EVIDENCE 的 source SHA/行段。覆核身份：同一作者工具；不能簽發 Independent Pass 或 Native Release。

已逐項檢查 G-A 原六項與 G-B 原合取原文不變；三 GWO 各有原 Domain/operation/raw；OPS JSON payload 全數不變；未知效果仍先 reconcile；Nonce/TTL/Revoke、User Consent、Maker/Checker 真分離保留；Provider Required=Served、SourceFreeze 不被文檔預授權替代。DOC-05 120/124/38 與 DOC-06 949/192/81 完整實質定義保持，未重排巨量清冊；九冊 metadata 保持 DESIGN／AUTHOR_SIDE_REPAIR_CANDIDATE 與 Native NOT_RUN/HOLD。

反例覆核發現並修補：原 optional selected Method 可拿 installed receipt 充 INVOKED，新增 REAL_INVOKE/subject/raw 拒收。另確認缺真 ABI 的 GWO 走局部 HOLD；選用不同檔案名稱、字串 Checker、同 SID、同 OS PID、stage-only、舊 HEAD Raw、錯 Domain Receipt 及 Revoke 後可 spawn 皆不能升格 Native 成功。

檢查範圍止於文件契約與隔離 fixture。test contract_model.py 是 synthetic evidence oracle，不是 Scheduler／Issuer／PIPD compiler，也不寫 Live SharedSpine。真權限、現役 binary/ABI、Policy Epoch、CI、loaded/served、Host effect 及獨立 Checker 均未取證，詳 NOT_RUN 清單。
