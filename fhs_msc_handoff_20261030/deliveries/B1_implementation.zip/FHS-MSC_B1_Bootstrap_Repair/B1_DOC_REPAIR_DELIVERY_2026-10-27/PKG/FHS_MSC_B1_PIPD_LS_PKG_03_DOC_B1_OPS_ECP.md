---
artifact_family: FHS-MSC-B1-Bootstrap-Repair-PIPD-LS-PKG
version: 2026-10-27_r3_DOC_REPAIR_CANDIDATE_1
supersedes_version: 2026-10-26_r3_HIGH_RETENTION_SUBSTANTIVE_AUDIT_REPAIR
supersedes_subject_sha256: 54a17818473f2a4b7c4f0f8f504bc96e4e1450540facfd30cf38234fa89e8b8a
change_type: HIGH_RETENTION_INTEGRATE_COVER_REPLACE_NO_ARCHITECTURE_RESET
task_kind: DESIGN
claim_ceiling: AUTHOR_SIDE_REPAIR_CANDIDATE
formal_sourcefreeze: HOLD
independent_checker_receipt: NOT_RUN
native_effect: NOT_RUN
release: NOT_RUN
artifact_id: FHS_MSC_B1_PIPD_LS_PKG_03_DOC_B1_OPS_ECP
baseline_lineage:
  artifact_family: FHS-MSC-B1-Bootstrap-Repair-PIPD-LS-PKG
  version: 2026-10-26_r3_HIGH_RETENTION_SUBSTANTIVE_AUDIT_REPAIR
  supersedes_version: 2026-10-26-r2-HIGH-RETENTION-SOURCE-BOUND
  supersedes_subject_sha256: 273591a3f0cc7f43c87d6ac5e9e5704cf7ede15440a8a159b1de71d4c7d52da5
  change_type: HIGH_RETENTION_INTEGRATE_COVER_REPLACE_NO_ARCHITECTURE_RESET
  task_kind: DESIGN
  claim_ceiling: AUTHOR_SIDE_REPAIR_CANDIDATE
  formal_sourcefreeze: HOLD
  independent_checker_receipt: NOT_RUN
  native_effect: NOT_RUN
  release: NOT_RUN
design_use: OWNER_PREAUTHORIZED_B1_DESIGN_USE
native_authority: FORMAL_NATIVE_NOT_GRANTED
source_path: C:\Projects\Agent_Workspace\知識庫\實作相關DOC\Fabric vNext\Semantic World OS
  Fabric\SBL_PIPD\FHS-MSC\B1\FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG\FHS_MSC_B1_PIPD_LS_PKG\FHS_MSC_B1_PIPD_LS_PKG_03_DOC_B1_OPS_ECP.md
---

# DOC-B1-OPS-ECP｜每張 HOST_OPERATIONS 卡獨立 payload／issuer／queue／activation

<a id="repair-ops-boundary"></a>
## 本候選修訂：Trust 接線、Risk 與重試邊界（RCA-06～11/14/17/29/33/37～39）

適用性依 DOC-00 L0～L4。普通文件與有准入的受限 DEV red→minimal patch→green 可反覆迭代；Native effect 仍 at-most-once，timeout／unknown 一律先 read-world-state/reconcile，補償須獨立 ECP／Permit，不重播 consumed nonce。ISSUER_UNBOUND 只停真消費 Issuer 的操作。

R1 Discovery 依序讀回真 `Trust Profile → Registry Resolver → Receiver imported origin`，記 Host／SID／key fingerprint／ACL／binary SHA／policy epoch／registry path 與 Owner 契約。`HGK_TRUST_PROFILE=user` 不是已存在的有效開關；缺真 ABI 不設臆造環境變數、不改 Trust Anchor。可用已授權 Standard User 做無副作用診斷；只有真高權限效果才要求其現役 OS Gate，不強迫所有工程 Administrator／LocalMachine。

若現役 Receiver 支援 Owner-approved User Trust，以實測的 Profile／Resolver／Receiver 一致性再進 effect；否則 `RECEIVER_NOT_LIVE / OWNER_OR_NATIVE_DEPENDENCY`，只停 R1 受影效果並開 Owner 決策。User-scope key 不等於高保證隔離；Maker 不能改 Trust Anchor 或 Checker verdict，Checker 要不同 principal UUID／credential、唯讀 ACL／獨立 key 的真證據，不以同 SID 三個 PID 或 DPAPI 自證。

每個 Host payload 保留獨立 Permit、preimage、operation、nonce、TTL、Revoke、Raw、readback、rollback。錯 key/token/scope/nonce/TTL/revoke 均 Native NACK／zero unauthorized delta。USER 的目的、Synthetic DataDir、保存與撤銷需獨立 Consent 及合法 User issuer；普通文件的預授權不涵蓋 add/remove。USER 無准入即 NOFIT，不能借 DEV/OPS。

R3 至少真 STAGE／LOADED／CONSUMER 三 Raw 同 candidate SHA／epoch 且不同 event/resource；Repo／PR inspect、exit 0、stage 檔存在不作 loaded。Code／Installed／Loaded／Consumer 四階逐一讀回，沒有證據保持 UNVERIFIED。SBL `remove --id` 語法與 User outcome 依 DOC-08 的當前 parser discovery，不以泛稱 delete 發命令。

受影交叉引用：[00](FHS_MSC_B1_PIPD_LS_PKG_00_GOVERNANCE_AND_CONTROL.md#repair-control)、[02](FHS_MSC_B1_PIPD_LS_PKG_02_DOC_B1_PD.md#repair-binding)、[07](FHS_MSC_B1_PIPD_LS_PKG_07_NATIVE_TOOLCHAIN_EXACT_USAGE.md#repair-tool-binding)、[08](FHS_MSC_B1_PIPD_LS_PKG_08_GOLDEN_WORKORDERS_E2E.md#repair-gwo-entry)。

**本文件不能發活 ECP**：P4 `pipd-execution-contract` 在真 `PD-PKG` 存在時才適用於 Repo-bound 構造；Host Operations 由既有 HGK Native Owner/Receiver 綁定，不得假 PD。

## EffectClass 原生生命週期及精確拒收

| 專屬類型 | 入參差別 | 事實讀回 | no-effect/rollback |
|---|---|---|---|
| ISSUER | Owner Policy+issuer audience+subject+nonce+scope+TTL | native IssuerDecision(signature,NACK,event) | NACK 未發行則零補償；已發行先 revoke/reconcile |
| QUEUE | accepted WO+queue_id+lease_generation+cursor+K | durable ledger CAS/heartbeat and B,C fairness | park+fence generation，不重播已 in-flight |
| RECEIVER | typed ABI + expected current receiver binary | native ACK/NACK same WO event | no ACK→no dispatch，拒收假 ACK |
| JOURNAL | operation fingerprint/preimage/CAS fence | observed effect or UNKNOWN | UNKNOWN_EFFECT 先 reconciliation、禁止 blind retry |
| PROMOTION | Fabric stage+approved sig+active epoch | policy consumer trace+Loaded SHA | restore prior active generation only with Owner permit |
| CONTINUATION | durable cursor + session stop+native wake | T2→T3→T4 native event+successor WO | after revoke no external reentry，停受影 continuation |
| USER_BOUNDARY | user consent + isolated store + qualified USER owner | add/list/delete and record version, separate process | NOFIT if issuer/consent missing; never borrow OPS/DEV token |

## 每張 OPS 子卡實際候選操作（各有不同 Readback）

### WO-B1-A2｜ISSUER_SUBJECT

**成功事實**：issuer-signed exact subject/scope checked before spawn; nonce consumed once。**專屬攻擊負例**：wrong issuer or replayed nonce -> PERMIT_SUBJECT_NONCE_REPLAY。
```json
{
  "domain_readback_fields": [
    "issuer_identity",
    "subject_sha",
    "nonce",
    "ttl",
    "policy_epoch",
    "grant_signature"
  ],
  "domain_readback_schema": "native_issuer",
  "effect_intent": "validate token{subject,policy_epoch,principal,nonce,scope,ttl} -> issuer signed ACK/NACK; consume nonce only on accepted native operation",
  "effect_key": "ISSUER_SUBJECT",
  "idempotency": {
    "mode": "at-most-once",
    "on_timeout": "UNKNOWN_EFFECT_RECONCILE_FIRST"
  },
  "issuer_owner": "HGK Native Issuer Owner",
  "permission": {
    "same_scope": true,
    "same_subject": true,
    "token_required": true
  },
  "precondition": {
    "active_policy_epoch": "REQUIRED_FROM_OWNER",
    "host_id": "REQUIRED_LIVE",
    "issuer_ref": "REQUIRED_LIVE",
    "method_policy_ref": "REQUIRED_CURRENT",
    "nonce": "REQUIRED_ONE_TIME",
    "preimage": "REQUIRED_BY_EFFECT",
    "subject_hash": "REQUIRED_LIVE",
    "ttl": "REQUIRED_VALID"
  },
  "retries": {
    "backoff": "none",
    "max": 1
  },
  "rollback": {
    "pointer": "OWNER_APPROVED_COMPENSATION_NOT_GRANTED",
    "required": true
  },
  "schema": "B1.OPS.ECP_CANDIDATE@r3",
  "status": "DESIGN_HOLD",
  "wo_id": "WO-B1-A2"
}
```
**StopLoss**：`PERMIT_SUBJECT_NONCE_REPLAY`；此卡不能以 `RAW-WO-B1-*` 兄弟結果、token signature string 或 `exit 0` 作驗收。

### WO-B1-A3｜QUEUE_WO

**成功事實**：blocked A parked; independent B/C progressed within bounded K; generation CAS unique。**專屬攻擊負例**：duplicate claim, starved B/C or stale generation -> LOST_LEASE_OR_DUPLICATE_CLAIM。
```json
{
  "domain_readback_fields": [
    "queue_id",
    "persisted_cursor",
    "lease_generation",
    "claimed_by",
    "park_reason"
  ],
  "domain_readback_schema": "hermes_queue",
  "effect_intent": "enqueue durable WO -> bounded K round-robin scan -> ClaimCAS lease_generation -> heartbeat -> checkpoint/PARK with predicate",
  "effect_key": "QUEUE_WO",
  "idempotency": {
    "mode": "at-most-once",
    "on_timeout": "UNKNOWN_EFFECT_RECONCILE_FIRST"
  },
  "issuer_owner": "Hermes Queue Owner",
  "permission": {
    "same_scope": true,
    "same_subject": true,
    "token_required": true
  },
  "precondition": {
    "active_policy_epoch": "REQUIRED_FROM_OWNER",
    "host_id": "REQUIRED_LIVE",
    "issuer_ref": "REQUIRED_LIVE",
    "method_policy_ref": "REQUIRED_CURRENT",
    "nonce": "REQUIRED_ONE_TIME",
    "preimage": "REQUIRED_BY_EFFECT",
    "subject_hash": "REQUIRED_LIVE",
    "ttl": "REQUIRED_VALID"
  },
  "retries": {
    "backoff": "none",
    "max": 1
  },
  "rollback": {
    "pointer": "OWNER_APPROVED_COMPENSATION_NOT_GRANTED",
    "required": true
  },
  "schema": "B1.OPS.ECP_CANDIDATE@r3",
  "status": "DESIGN_HOLD",
  "wo_id": "WO-B1-A3"
}
```
**StopLoss**：`LOST_LEASE_OR_DUPLICATE_CLAIM`；此卡不能以 `RAW-WO-B1-*` 兄弟結果、token signature string 或 `exit 0` 作驗收。

### WO-B1-A4｜RECEIVER_ABI

**成功事實**：true receiver ACK signed for exact subject; mock ACK never qualifies。**專屬攻擊負例**：mocked ACK/wrong ABI/absent native event -> RECEIVER_NOT_LIVE。
```json
{
  "domain_readback_fields": [
    "abi_id",
    "issuer",
    "wo_id",
    "subject_sha",
    "ack_or_nack",
    "native_event"
  ],
  "domain_readback_schema": "native_receiver",
  "effect_intent": "serialize existing typed receiver request -> native receiver validates ABI+Permit -> native event ACK/NACK -> same WO readback",
  "effect_key": "RECEIVER_ABI",
  "idempotency": {
    "mode": "at-most-once",
    "on_timeout": "UNKNOWN_EFFECT_RECONCILE_FIRST"
  },
  "issuer_owner": "HGK Receiver Owner",
  "permission": {
    "same_scope": true,
    "same_subject": true,
    "token_required": true
  },
  "precondition": {
    "active_policy_epoch": "REQUIRED_FROM_OWNER",
    "host_id": "REQUIRED_LIVE",
    "issuer_ref": "REQUIRED_LIVE",
    "method_policy_ref": "REQUIRED_CURRENT",
    "nonce": "REQUIRED_ONE_TIME",
    "preimage": "REQUIRED_BY_EFFECT",
    "subject_hash": "REQUIRED_LIVE",
    "ttl": "REQUIRED_VALID"
  },
  "retries": {
    "backoff": "none",
    "max": 1
  },
  "rollback": {
    "pointer": "OWNER_APPROVED_COMPENSATION_NOT_GRANTED",
    "required": true
  },
  "schema": "B1.OPS.ECP_CANDIDATE@r3",
  "status": "DESIGN_HOLD",
  "wo_id": "WO-B1-A4"
}
```
**StopLoss**：`RECEIVER_NOT_LIVE`；此卡不能以 `RAW-WO-B1-*` 兄弟結果、token signature string 或 `exit 0` 作驗收。

### WO-B1-A6｜EFFECT_JOURNAL

**成功事實**：at-most-once effect; UNKNOWN_EFFECT reconciled before any next claim。**專屬攻擊負例**：duplicate operation or retry-on-timeout -> UNKNOWN_EFFECT_REPLAY。
```json
{
  "domain_readback_fields": [
    "operation_id",
    "preimage",
    "observed_postimage",
    "CAS_fence",
    "unknown_effect"
  ],
  "domain_readback_schema": "effect_journal",
  "effect_intent": "prepare operation fingerprint -> CAS claim -> execute at most once -> read world state -> reconcile UNKNOWN without blind retry",
  "effect_key": "EFFECT_JOURNAL",
  "idempotency": {
    "mode": "at-most-once",
    "on_timeout": "UNKNOWN_EFFECT_RECONCILE_FIRST"
  },
  "issuer_owner": "Effect Journal Owner",
  "permission": {
    "same_scope": true,
    "same_subject": true,
    "token_required": true
  },
  "precondition": {
    "active_policy_epoch": "REQUIRED_FROM_OWNER",
    "host_id": "REQUIRED_LIVE",
    "issuer_ref": "REQUIRED_LIVE",
    "method_policy_ref": "REQUIRED_CURRENT",
    "nonce": "REQUIRED_ONE_TIME",
    "preimage": "REQUIRED_BY_EFFECT",
    "subject_hash": "REQUIRED_LIVE",
    "ttl": "REQUIRED_VALID"
  },
  "retries": {
    "backoff": "none",
    "max": 1
  },
  "rollback": {
    "pointer": "OWNER_APPROVED_COMPENSATION_NOT_GRANTED",
    "required": true
  },
  "schema": "B1.OPS.ECP_CANDIDATE@r3",
  "status": "DESIGN_HOLD",
  "wo_id": "WO-B1-A6"
}
```
**StopLoss**：`UNKNOWN_EFFECT_REPLAY`；此卡不能以 `RAW-WO-B1-*` 兄弟結果、token signature string 或 `exit 0` 作驗收。

### WO-B1-A9｜NATIVE_CONTINUATION

**成功事實**：native successor advances after external revoke with new session and no external trigger。**專屬攻擊負例**：external actor still triggering -> EXTERNAL_TRIGGER_STILL_REQUIRED。
```json
{
  "domain_readback_fields": [
    "external_revoke",
    "post_turn_source",
    "issued_wo",
    "native_claim",
    "session_exit"
  ],
  "domain_readback_schema": "native_continuation",
  "effect_intent": "external session stop -> durable T2 post-turn native scheduler -> T3 checkpoint -> T4 resume under fresh native WO",
  "effect_key": "NATIVE_CONTINUATION",
  "idempotency": {
    "mode": "at-most-once",
    "on_timeout": "UNKNOWN_EFFECT_RECONCILE_FIRST"
  },
  "issuer_owner": "Hermes Continuation Owner",
  "permission": {
    "same_scope": true,
    "same_subject": true,
    "token_required": true
  },
  "precondition": {
    "active_policy_epoch": "REQUIRED_FROM_OWNER",
    "host_id": "REQUIRED_LIVE",
    "issuer_ref": "REQUIRED_LIVE",
    "method_policy_ref": "REQUIRED_CURRENT",
    "nonce": "REQUIRED_ONE_TIME",
    "preimage": "REQUIRED_BY_EFFECT",
    "subject_hash": "REQUIRED_LIVE",
    "ttl": "REQUIRED_VALID"
  },
  "retries": {
    "backoff": "none",
    "max": 1
  },
  "rollback": {
    "pointer": "OWNER_APPROVED_COMPENSATION_NOT_GRANTED",
    "required": true
  },
  "schema": "B1.OPS.ECP_CANDIDATE@r3",
  "status": "DESIGN_HOLD",
  "wo_id": "WO-B1-A9"
}
```
**StopLoss**：`EXTERNAL_TRIGGER_STILL_REQUIRED`；此卡不能以 `RAW-WO-B1-*` 兄弟結果、token signature string 或 `exit 0` 作驗收。

### WO-B1-B3-OPS｜SBL_TO_NATIVE__OPS

**成功事實**：DEV/OPS different WOs, separate source diff and real native ACK。**專屬攻擊負例**：second issuer or shared receipt -> SECOND_ISSUER_OR_MIXED_EFFECT。
```json
{
  "domain_readback_fields": [
    "sbl_entry",
    "candidate",
    "dev_diff",
    "ops_handoff",
    "native_receiver_ack"
  ],
  "domain_readback_schema": "bridge_handoff",
  "effect_intent": "consume DEV handoff digest -> native receiver validates ABI; SBL never signs issuer event",
  "effect_key": "SBL_TO_NATIVE__OPS",
  "idempotency": {
    "mode": "at-most-once",
    "on_timeout": "UNKNOWN_EFFECT_RECONCILE_FIRST"
  },
  "issuer_owner": "SBL Bridge & HGK Owner",
  "permission": {
    "same_scope": true,
    "same_subject": true,
    "token_required": true
  },
  "precondition": {
    "active_policy_epoch": "REQUIRED_FROM_OWNER",
    "host_id": "REQUIRED_LIVE",
    "issuer_ref": "REQUIRED_LIVE",
    "method_policy_ref": "REQUIRED_CURRENT",
    "nonce": "REQUIRED_ONE_TIME",
    "preimage": "REQUIRED_BY_EFFECT",
    "subject_hash": "REQUIRED_LIVE",
    "ttl": "REQUIRED_VALID"
  },
  "retries": {
    "backoff": "none",
    "max": 1
  },
  "rollback": {
    "pointer": "OWNER_APPROVED_COMPENSATION_NOT_GRANTED",
    "required": true
  },
  "schema": "B1.OPS.ECP_CANDIDATE@r3",
  "status": "DESIGN_HOLD",
  "wo_id": "WO-B1-B3-OPS"
}
```
**StopLoss**：`SECOND_ISSUER_OR_MIXED_EFFECT`；此卡不能以 `RAW-WO-B1-*` 兄弟結果、token signature string 或 `exit 0` 作驗收。

### WO-B1-B4-OPS｜ECP_SELECTOR__OPS

**成功事實**：one active ECP per WO; split iff distinct effects。**專屬攻擊負例**：two active ECPs/unknown class -> ECP_MULTIPLE_OR_CLASS_UNKNOWN。
```json
{
  "domain_readback_fields": [
    "wo_id",
    "effect_class",
    "active_ecp_count",
    "issuer_ack"
  ],
  "domain_readback_schema": "ecp_selection",
  "effect_intent": "consume DEV selector correction receipt -> native Issuer enforces one active ECP and one effect class",
  "effect_key": "ECP_SELECTOR__OPS",
  "idempotency": {
    "mode": "at-most-once",
    "on_timeout": "UNKNOWN_EFFECT_RECONCILE_FIRST"
  },
  "issuer_owner": "HGK ECP Selection Owner",
  "permission": {
    "same_scope": true,
    "same_subject": true,
    "token_required": true
  },
  "precondition": {
    "active_policy_epoch": "REQUIRED_FROM_OWNER",
    "host_id": "REQUIRED_LIVE",
    "issuer_ref": "REQUIRED_LIVE",
    "method_policy_ref": "REQUIRED_CURRENT",
    "nonce": "REQUIRED_ONE_TIME",
    "preimage": "REQUIRED_BY_EFFECT",
    "subject_hash": "REQUIRED_LIVE",
    "ttl": "REQUIRED_VALID"
  },
  "retries": {
    "backoff": "none",
    "max": 1
  },
  "rollback": {
    "pointer": "OWNER_APPROVED_COMPENSATION_NOT_GRANTED",
    "required": true
  },
  "schema": "B1.OPS.ECP_CANDIDATE@r3",
  "status": "DESIGN_HOLD",
  "wo_id": "WO-B1-B4-OPS"
}
```
**StopLoss**：`ECP_MULTIPLE_OR_CLASS_UNKNOWN`；此卡不能以 `RAW-WO-B1-*` 兄弟結果、token signature string 或 `exit 0` 作驗收。

### WO-B1-B5-OPS｜THREE_SP__OPS

**成功事實**：three host identities and isolated permission readbacks; ZIP-only not pass。**專屬攻擊負例**：missing host invocation -> SP_HOST_LOAD_UNPROVEN。
```json
{
  "domain_readback_fields": [
    "TPM_SP",
    "COMMANDER_SP",
    "CHALLENGE_SP",
    "host_invocation",
    "loaded_sha"
  ],
  "domain_readback_schema": "sp_host_load",
  "effect_intent": "consume DEV packaging receipt -> host loader installs/loads 3 independent SP identities and proves actual invoke + deny",
  "effect_key": "THREE_SP__OPS",
  "idempotency": {
    "mode": "at-most-once",
    "on_timeout": "UNKNOWN_EFFECT_RECONCILE_FIRST"
  },
  "issuer_owner": "SP Host Owner",
  "permission": {
    "same_scope": true,
    "same_subject": true,
    "token_required": true
  },
  "precondition": {
    "active_policy_epoch": "REQUIRED_FROM_OWNER",
    "host_id": "REQUIRED_LIVE",
    "issuer_ref": "REQUIRED_LIVE",
    "method_policy_ref": "REQUIRED_CURRENT",
    "nonce": "REQUIRED_ONE_TIME",
    "preimage": "REQUIRED_BY_EFFECT",
    "subject_hash": "REQUIRED_LIVE",
    "ttl": "REQUIRED_VALID"
  },
  "retries": {
    "backoff": "none",
    "max": 1
  },
  "rollback": {
    "pointer": "OWNER_APPROVED_COMPENSATION_NOT_GRANTED",
    "required": true
  },
  "schema": "B1.OPS.ECP_CANDIDATE@r3",
  "status": "DESIGN_HOLD",
  "wo_id": "WO-B1-B5-OPS"
}
```
**StopLoss**：`SP_HOST_LOAD_UNPROVEN`；此卡不能以 `RAW-WO-B1-*` 兄弟結果、token signature string 或 `exit 0` 作驗收。

### WO-B1-C1｜FABRIC_PROMOTION

**成功事實**：independent stage approval; active and loaded exact digest; consumer projection ACK。**專屬攻擊負例**：stage mistaken as active or missing consumer -> FABRIC_LOADED_ABSENT。
```json
{
  "domain_readback_fields": [
    "approved_stage",
    "active_policy",
    "loaded_sha",
    "consumer_trace",
    "rollback"
  ],
  "domain_readback_schema": "fabric_activator",
  "effect_intent": "Fabric Owner stage policy+approval -> native activate -> independent active/loaded SHA reader -> rollback to previous generation",
  "effect_key": "FABRIC_PROMOTION",
  "idempotency": {
    "mode": "at-most-once",
    "on_timeout": "UNKNOWN_EFFECT_RECONCILE_FIRST"
  },
  "issuer_owner": "Fabric Activation Owner",
  "permission": {
    "same_scope": true,
    "same_subject": true,
    "token_required": true
  },
  "precondition": {
    "active_policy_epoch": "REQUIRED_FROM_OWNER",
    "host_id": "REQUIRED_LIVE",
    "issuer_ref": "REQUIRED_LIVE",
    "method_policy_ref": "REQUIRED_CURRENT",
    "nonce": "REQUIRED_ONE_TIME",
    "preimage": "REQUIRED_BY_EFFECT",
    "subject_hash": "REQUIRED_LIVE",
    "ttl": "REQUIRED_VALID"
  },
  "retries": {
    "backoff": "none",
    "max": 1
  },
  "rollback": {
    "pointer": "OWNER_APPROVED_COMPENSATION_NOT_GRANTED",
    "required": true
  },
  "schema": "B1.OPS.ECP_CANDIDATE@r3",
  "status": "DESIGN_HOLD",
  "wo_id": "WO-B1-C1"
}
```
**StopLoss**：`FABRIC_LOADED_ABSENT`；此卡不能以 `RAW-WO-B1-*` 兄弟結果、token signature string 或 `exit 0` 作驗收。

### WO-B1-C2｜HGK_GWO

**成功事實**：true SBL entry -> native HGK issuer -> Hermes lease -> reversible observable result。**專屬攻擊負例**：ghost worker/forged permit -> GWO_HGK_NOT_NATIVE。
```json
{
  "domain_readback_fields": [
    "sbl_start",
    "issued_wo",
    "issuer",
    "lease",
    "worker_receipt",
    "readback"
  ],
  "domain_readback_schema": "hgk_native_golden",
  "effect_intent": "SBL real entry -> HGK typed request -> native issue+durable queue -> Hermes worker outcome -> independent readback",
  "effect_key": "HGK_GWO",
  "idempotency": {
    "mode": "at-most-once",
    "on_timeout": "UNKNOWN_EFFECT_RECONCILE_FIRST"
  },
  "issuer_owner": "HGK Runtime Owner",
  "permission": {
    "same_scope": true,
    "same_subject": true,
    "token_required": true
  },
  "precondition": {
    "active_policy_epoch": "REQUIRED_FROM_OWNER",
    "host_id": "REQUIRED_LIVE",
    "issuer_ref": "REQUIRED_LIVE",
    "method_policy_ref": "REQUIRED_CURRENT",
    "nonce": "REQUIRED_ONE_TIME",
    "preimage": "REQUIRED_BY_EFFECT",
    "subject_hash": "REQUIRED_LIVE",
    "ttl": "REQUIRED_VALID"
  },
  "retries": {
    "backoff": "none",
    "max": 1
  },
  "rollback": {
    "pointer": "OWNER_APPROVED_COMPENSATION_NOT_GRANTED",
    "required": true
  },
  "schema": "B1.OPS.ECP_CANDIDATE@r3",
  "status": "DESIGN_HOLD",
  "wo_id": "WO-B1-C2"
}
```
**StopLoss**：`GWO_HGK_NOT_NATIVE`；此卡不能以 `RAW-WO-B1-*` 兄弟結果、token signature string 或 `exit 0` 作驗收。

### WO-B1-C3-OPS｜SBL_GWO__INSTALL

**成功事實**：separate Host install and USER effects with independent readbacks。**專屬攻擊負例**：install count used as add success -> GWO_SBL_USER_STATE_UNPROVEN。
```json
{
  "domain_readback_fields": [
    "sbl_entry",
    "stack_install",
    "consent",
    "todo_add",
    "list",
    "delete",
    "uninstall"
  ],
  "domain_readback_schema": "sbl_user_golden",
  "effect_intent": "install allowed SBL stack in isolated root -> doctor -> status -> uninstall+residue readback",
  "effect_key": "SBL_GWO__INSTALL",
  "idempotency": {
    "mode": "at-most-once",
    "on_timeout": "UNKNOWN_EFFECT_RECONCILE_FIRST"
  },
  "issuer_owner": "SBL Product/User Owner",
  "permission": {
    "same_scope": true,
    "same_subject": true,
    "token_required": true
  },
  "precondition": {
    "active_policy_epoch": "REQUIRED_FROM_OWNER",
    "host_id": "REQUIRED_LIVE",
    "issuer_ref": "REQUIRED_LIVE",
    "method_policy_ref": "REQUIRED_CURRENT",
    "nonce": "REQUIRED_ONE_TIME",
    "preimage": "REQUIRED_BY_EFFECT",
    "subject_hash": "REQUIRED_LIVE",
    "ttl": "REQUIRED_VALID"
  },
  "retries": {
    "backoff": "none",
    "max": 1
  },
  "rollback": {
    "pointer": "OWNER_APPROVED_COMPENSATION_NOT_GRANTED",
    "required": true
  },
  "schema": "B1.OPS.ECP_CANDIDATE@r3",
  "status": "DESIGN_HOLD",
  "wo_id": "WO-B1-C3-OPS"
}
```
**StopLoss**：`GWO_SBL_USER_STATE_UNPROVEN`；此卡不能以 `RAW-WO-B1-*` 兄弟結果、token signature string 或 `exit 0` 作驗收。

### WO-B1-C4｜EXTERNAL_GRANT

**成功事實**：bounded external grant and no residual capability on revoke。**專屬攻擊負例**：scope expansion -> EXTERNAL_SCOPE_ESCAPED。
```json
{
  "domain_readback_fields": [
    "owner_scope",
    "ttl",
    "principal",
    "revocation",
    "zero_scope_escape"
  ],
  "domain_readback_schema": "delegation",
  "effect_intent": "grant scoped principal with TTL and nonce -> revoke -> check post-revoke rejection and reconcile in-flight",
  "effect_key": "EXTERNAL_GRANT",
  "idempotency": {
    "mode": "at-most-once",
    "on_timeout": "UNKNOWN_EFFECT_RECONCILE_FIRST"
  },
  "issuer_owner": "External Delegation Owner",
  "permission": {
    "same_scope": true,
    "same_subject": true,
    "token_required": true
  },
  "precondition": {
    "active_policy_epoch": "REQUIRED_FROM_OWNER",
    "host_id": "REQUIRED_LIVE",
    "issuer_ref": "REQUIRED_LIVE",
    "method_policy_ref": "REQUIRED_CURRENT",
    "nonce": "REQUIRED_ONE_TIME",
    "preimage": "REQUIRED_BY_EFFECT",
    "subject_hash": "REQUIRED_LIVE",
    "ttl": "REQUIRED_VALID"
  },
  "retries": {
    "backoff": "none",
    "max": 1
  },
  "rollback": {
    "pointer": "OWNER_APPROVED_COMPENSATION_NOT_GRANTED",
    "required": true
  },
  "schema": "B1.OPS.ECP_CANDIDATE@r3",
  "status": "DESIGN_HOLD",
  "wo_id": "WO-B1-C4"
}
```
**StopLoss**：`EXTERNAL_SCOPE_ESCAPED`；此卡不能以 `RAW-WO-B1-*` 兄弟結果、token signature string 或 `exit 0` 作驗收。

### WO-B1-C6｜REVOKE_RACE

**成功事實**：post-revoke use fails before spawn; existing effects reconciled。**專屬攻擊負例**：reused token after revoke -> REVOKED_TOKEN_REPLAY。
```json
{
  "domain_readback_fields": [
    "old_nonce",
    "revocation_epoch",
    "attempt_after_revoke",
    "denied_effect"
  ],
  "domain_readback_schema": "revoke_boundary",
  "effect_intent": "revoke current grant -> attempt old token -> ensure zero new spawn and record denied native event",
  "effect_key": "REVOKE_RACE",
  "idempotency": {
    "mode": "at-most-once",
    "on_timeout": "UNKNOWN_EFFECT_RECONCILE_FIRST"
  },
  "issuer_owner": "Revoke/Effect Owner",
  "permission": {
    "same_scope": true,
    "same_subject": true,
    "token_required": true
  },
  "precondition": {
    "active_policy_epoch": "REQUIRED_FROM_OWNER",
    "host_id": "REQUIRED_LIVE",
    "issuer_ref": "REQUIRED_LIVE",
    "method_policy_ref": "REQUIRED_CURRENT",
    "nonce": "REQUIRED_ONE_TIME",
    "preimage": "REQUIRED_BY_EFFECT",
    "subject_hash": "REQUIRED_LIVE",
    "ttl": "REQUIRED_VALID"
  },
  "retries": {
    "backoff": "none",
    "max": 1
  },
  "rollback": {
    "pointer": "OWNER_APPROVED_COMPENSATION_NOT_GRANTED",
    "required": true
  },
  "schema": "B1.OPS.ECP_CANDIDATE@r3",
  "status": "DESIGN_HOLD",
  "wo_id": "WO-B1-C6"
}
```
**StopLoss**：`REVOKED_TOKEN_REPLAY`；此卡不能以 `RAW-WO-B1-*` 兄弟結果、token signature string 或 `exit 0` 作驗收。

### WO-B1-C8｜NATIVE_SUCCESSOR

**成功事實**：fresh separate session native trigger progresses after external account revoked。**專屬攻擊負例**：successor still external-triggered -> NATIVE_SUCCESSOR_NOT_PROVEN。
```json
{
  "domain_readback_fields": [
    "external_stop",
    "ledger_cursor",
    "issuer",
    "successor_wo",
    "native_origin"
  ],
  "domain_readback_schema": "post_revoke_successor",
  "effect_intent": "revoke external helper -> separate session native issuer advances next WO -> ledger readback",
  "effect_key": "NATIVE_SUCCESSOR",
  "idempotency": {
    "mode": "at-most-once",
    "on_timeout": "UNKNOWN_EFFECT_RECONCILE_FIRST"
  },
  "issuer_owner": "Hermes Continuation Owner",
  "permission": {
    "same_scope": true,
    "same_subject": true,
    "token_required": true
  },
  "precondition": {
    "active_policy_epoch": "REQUIRED_FROM_OWNER",
    "host_id": "REQUIRED_LIVE",
    "issuer_ref": "REQUIRED_LIVE",
    "method_policy_ref": "REQUIRED_CURRENT",
    "nonce": "REQUIRED_ONE_TIME",
    "preimage": "REQUIRED_BY_EFFECT",
    "subject_hash": "REQUIRED_LIVE",
    "ttl": "REQUIRED_VALID"
  },
  "retries": {
    "backoff": "none",
    "max": 1
  },
  "rollback": {
    "pointer": "OWNER_APPROVED_COMPENSATION_NOT_GRANTED",
    "required": true
  },
  "schema": "B1.OPS.ECP_CANDIDATE@r3",
  "status": "DESIGN_HOLD",
  "wo_id": "WO-B1-C8"
}
```
**StopLoss**：`NATIVE_SUCCESSOR_NOT_PROVEN`；此卡不能以 `RAW-WO-B1-*` 兄弟結果、token signature string 或 `exit 0` 作驗收。

## USER_DATA_EFFECT：既有合法 User Issuer 決策樹

1. 先執行 `python -m sbl_cli.sbl_todo --data-dir <isolated> init` 的合法本機安裝/授權判定：使用者同意的隔離資料目錄，不能把此 CLI 本身當 HGK Native Issuer。
2. 查詢現役 SBL user-store API `add/list/remove` 是否有 Host Owner 指定的受控 user-effect issuer；如果沒有，對新增與刪除記錄 `NOFIT_USER_ISSUER_UNBOUND` 並 **zero effect**，可以唯讀 `list`/CLI help，但不能宣告 GWO-SBL PASS。
3. 如果有 issuer，對 add 記 user_id/record_id/nonce/expiry/pre-version→JSON add ACK→另一程序 list JSON；對 `remove --id` 必拿獨立作用許可、preimage/record_version→delete ACK→另一程序 list 無該 ID→uninstall residue 讀回。
4. 新增/刪除需要 UserConsent、UserEffectBoundaryContract、Owner-bound rollback；不能由 repo-dev `git revert` 代表使用者資料回復，也不能用 OPS Token 替代。

## 必須當場 NACK 的範例

```json
{
  "attempted_effect": "queue_claim",
  "decision": "NACK",
  "effect_class": "HOST_OPERATIONS",
  "first_fail": "NATIVE_ISSUER_OR_POLICY_UNBOUND",
  "issuer": "UNBOUND",
  "policy_epoch": "UNBOUND",
  "spawn_count_expected": 0,
  "workorder_id": "WO-B1-A3"
}
```
