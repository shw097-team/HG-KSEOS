---
artifact_family: FHS-MSC-B1-Bootstrap-Repair-PIPD-LS-PKG
version: 2026-10-27_r3_DOC_REPAIR_CANDIDATE_1
supersedes_version: 2026-10-26_r3_HIGH_RETENTION_SUBSTANTIVE_AUDIT_REPAIR
supersedes_subject_sha256: f929d9cffd462d23bbdb52171f72a450e96e59c8333bc05ebd739a2d38338337
change_type: HIGH_RETENTION_INTEGRATE_COVER_REPLACE_NO_ARCHITECTURE_RESET
task_kind: DESIGN
claim_ceiling: AUTHOR_SIDE_REPAIR_CANDIDATE
formal_sourcefreeze: HOLD
independent_checker_receipt: NOT_RUN
native_effect: NOT_RUN
release: NOT_RUN
artifact_id: FHS_MSC_B1_PIPD_LS_PKG_06_PRODUCT_COVERAGE_AND_R15
baseline_lineage:
  artifact_family: FHS-MSC-B1-Bootstrap-Repair-PIPD-LS-PKG
  version: 2026-10-26_r3_HIGH_RETENTION_SUBSTANTIVE_AUDIT_REPAIR
  supersedes_version: 2026-10-26-r2-HIGH-RETENTION-SOURCE-BOUND
  supersedes_subject_sha256: 273591a3f0cc7f43c87d6ac5e9e5704cf7ede15440a8a159b1de71d4c7d52da5
  change_type: HIGH_RETENTION_INTEGRATE_COVER_REPLACE_NO_ARCHITECTURE_RESET
  task_kind: DESIGN
  claim_ceiling: AUTHOR_SIDE_REPAIR_CANDIDATE
  formal_sourcefreeze: HOLD
  independent_checker_receipt: NOT_RUN
  native_effect: NOT_RUN
  release: NOT_RUN
design_use: OWNER_PREAUTHORIZED_B1_DESIGN_USE
native_authority: FORMAL_NATIVE_NOT_GRANTED
source_path: C:\Projects\Agent_Workspace\知識庫\實作相關DOC\Fabric vNext\Semantic World OS
  Fabric\SBL_PIPD\FHS-MSC\B1\FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG\FHS_MSC_B1_PIPD_LS_PKG\FHS_MSC_B1_PIPD_LS_PKG_06_PRODUCT_COVERAGE_AND_R15.md
---

# B1 Product / Technology Coverage｜949 R15 Identities, 192 Matrix Cells, 81 Named Assets

<a id="repair-product-denominator"></a>
## 本候選修訂：產品清冊與 Bootstrap 適用集合正交（RCA-18/20～22/30/44）

949 R15.1、192 Cell、81 Named Asset（19 Contract＋13 CLI＋25 Method＋24 Donor）的原身份、順序、Required／Conditional／Deferred 與每筆實質要求全部保留。下列衍生排程值不回寫產品義務：`EXECUTE_NOW / CONDITIONAL_TRIGGERED / DEFERRED_WITH_REASON / NOT_APPLICABLE_TO_BOOT`。當期 Required 仍須按有效 policy／Effect 依賴准入；Conditional 必先有實際 trigger／版本／Owner／證據；Deferred 保存 acceptance/re-entry；未觸發者不灌入 READY。r10 1,565 或 625/285/655 不替換本冊 949 分母。

Commander-SP（含 R15-917）的原產品 Required 保留；本輪明令禁用未修復 `sbl-commander-sp`，受影 GWO 入口依 DOC-08 條件分支，不刪產品需求、不使其它合法工程停工。Knowledge Pack 僅 SUPPORT；極性異常另登品質議題，不修改其原件。舊 M5 Repair、舊 M6 Distribution/Host 與 New Flow M1～M6 仍依 DOC-00 雙 taxonomy，不因同名合併。

Provider-off／NoFit、CLI_TOOL／STANDALONE 真 user outcome 不得用 Host install 代理。B1 Bootstrap 不代表 Full SBL Product、R17 145-ID／原 50 Parent+149 Child／18 WP／25 C00～C24／16 User Moments 或 SWOF READY_W3 全完工；保留全部來源需求與受影重入條件。下游按單卡 locator 讀原產品結果，不把巨量清冊放入每回合 Context。

受影交叉引用：[00](FHS_MSC_B1_PIPD_LS_PKG_00_GOVERNANCE_AND_CONTROL.md#repair-control)、[02](FHS_MSC_B1_PIPD_LS_PKG_02_DOC_B1_PD.md#repair-binding)、[07](FHS_MSC_B1_PIPD_LS_PKG_07_NATIVE_TOOLCHAIN_EXACT_USAGE.md#repair-tool-binding)、[08](FHS_MSC_B1_PIPD_LS_PKG_08_GOLDEN_WORKORDERS_E2E.md#repair-gwo-entry)。

## 1. 8 Kind × 3 Mode × 4 canonical Host × ProviderOff (192) 逐 Cell 程式化政策表

`ChatGPT Web Private Plugin` 是額外 Host gate，不列入四 canonical Host；Codex CLI/IDE 同屬 Codex Host。ProviderOff=true 不是換供應商的許可。

| CellID | Kind/Mode | Host | ProviderOff | R15 原准入 | 受影本輪產品結果 | 權限/Owner/現役適配 | Positive/Negative/NoFit |
|---|---|---|---|---|---|---|---|
| d0cf30ffd7c1 | CLI_TOOL/STANDALONE | Hermes Agent | ON | LOCAL_DESIGN_ELIGIBLE_NOT_INSTALLED | standalone CLI product eligible after isolated user consent; host plugin not needed | live loader+permission+fresh session / LOCAL_USER_CONSENT; local consent for data path; Native permit only for SWOF effect | POS: python -m build → wheel + console script / NEG: CLI_NO_ENTRYPOINT_STANDALONE; NO_SIDE_EFFECT_WITHOUT_USER_CONSENT / NOFIT: missing installed host/policy/permission |
| e8a4077d37ad | CLI_TOOL/STANDALONE | Hermes Agent | OFF | LOCAL_DESIGN_ELIGIBLE_NOT_INSTALLED | standalone CLI product eligible after isolated user consent; host plugin not needed; PROVIDER_OFF: no provider/model silent replacement | live loader+permission+fresh session / LOCAL_USER_CONSENT; local consent for data path; Native permit only for SWOF effect | POS: python -m build → wheel + console script / NEG: CLI_NO_ENTRYPOINT_STANDALONE; NO_SIDE_EFFECT_WITHOUT_USER_CONSENT / NOFIT: missing installed host/policy/permission |
| 6582a70fd427 | CLI_TOOL/STANDALONE | Codex | ON | LOCAL_DESIGN_ELIGIBLE_NOT_INSTALLED | standalone CLI product eligible after isolated user consent; host plugin not needed | tracked Codex CLI/IDE host identity, separate checker / LOCAL_USER_CONSENT; local consent for data path; Native permit only for SWOF effect | POS: python -m build → wheel + console script / NEG: CLI_NO_ENTRYPOINT_STANDALONE; NO_SIDE_EFFECT_WITHOUT_USER_CONSENT / NOFIT: missing installed host/policy/permission |
| 434c21c50bc3 | CLI_TOOL/STANDALONE | Codex | OFF | LOCAL_DESIGN_ELIGIBLE_NOT_INSTALLED | standalone CLI product eligible after isolated user consent; host plugin not needed; PROVIDER_OFF: no provider/model silent replacement | tracked Codex CLI/IDE host identity, separate checker / LOCAL_USER_CONSENT; local consent for data path; Native permit only for SWOF effect | POS: python -m build → wheel + console script / NEG: CLI_NO_ENTRYPOINT_STANDALONE; NO_SIDE_EFFECT_WITHOUT_USER_CONSENT / NOFIT: missing installed host/policy/permission |
| 41348f62f97c | CLI_TOOL/STANDALONE | Claude Code | ON | LOCAL_DESIGN_ELIGIBLE_NOT_INSTALLED | standalone CLI product eligible after isolated user consent; host plugin not needed | fresh Claude Code real loader/permission proof / LOCAL_USER_CONSENT; local consent for data path; Native permit only for SWOF effect | POS: python -m build → wheel + console script / NEG: CLI_NO_ENTRYPOINT_STANDALONE; NO_SIDE_EFFECT_WITHOUT_USER_CONSENT / NOFIT: missing installed host/policy/permission |
| 4bf76833ac66 | CLI_TOOL/STANDALONE | Claude Code | OFF | LOCAL_DESIGN_ELIGIBLE_NOT_INSTALLED | standalone CLI product eligible after isolated user consent; host plugin not needed; PROVIDER_OFF: no provider/model silent replacement | fresh Claude Code real loader/permission proof / LOCAL_USER_CONSENT; local consent for data path; Native permit only for SWOF effect | POS: python -m build → wheel + console script / NEG: CLI_NO_ENTRYPOINT_STANDALONE; NO_SIDE_EFFECT_WITHOUT_USER_CONSENT / NOFIT: missing installed host/policy/permission |
| 2738990e2c09 | CLI_TOOL/STANDALONE | DeepSeek Harness | ON | LOCAL_DESIGN_ELIGIBLE_NOT_INSTALLED | standalone CLI product eligible after isolated user consent; host plugin not needed | API_ONLY=>NO_FIT; actual harness ABI mandatory / LOCAL_USER_CONSENT; local consent for data path; Native permit only for SWOF effect | POS: python -m build → wheel + console script / NEG: CLI_NO_ENTRYPOINT_STANDALONE; NO_SIDE_EFFECT_WITHOUT_USER_CONSENT / NOFIT: missing installed host/policy/permission |
| 3869542dc2f7 | CLI_TOOL/STANDALONE | DeepSeek Harness | OFF | LOCAL_DESIGN_ELIGIBLE_NOT_INSTALLED | standalone CLI product eligible after isolated user consent; host plugin not needed; PROVIDER_OFF: no provider/model silent replacement | API_ONLY=>NO_FIT; actual harness ABI mandatory / LOCAL_USER_CONSENT; local consent for data path; Native permit only for SWOF effect | POS: python -m build → wheel + console script / NEG: CLI_NO_ENTRYPOINT_STANDALONE; NO_SIDE_EFFECT_WITHOUT_USER_CONSENT / NOFIT: missing installed host/policy/permission |
| 1407c7aa1d27 | CLI_TOOL/PREW3_SHADOW | Hermes Agent | ON | W2_SHADOW_READ_ONLY | W2_FROZEN_READSET_ONLY; deny writes | live loader+permission+fresh session / FROZEN_READSET_NO_WRITE; local consent for data path; Native permit only for SWOF effect | POS: python -m build → wheel + console script / NEG: CLI_NO_ENTRYPOINT_PREW3_SHADOW; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 6b424688af61 | CLI_TOOL/PREW3_SHADOW | Hermes Agent | OFF | W2_SHADOW_READ_ONLY | W2_FROZEN_READSET_ONLY; deny writes; PROVIDER_OFF: no provider/model silent replacement | live loader+permission+fresh session / FROZEN_READSET_NO_WRITE; local consent for data path; Native permit only for SWOF effect | POS: python -m build → wheel + console script / NEG: CLI_NO_ENTRYPOINT_PREW3_SHADOW; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 56eaea595d3d | CLI_TOOL/PREW3_SHADOW | Codex | ON | W2_SHADOW_READ_ONLY | W2_FROZEN_READSET_ONLY; deny writes | tracked Codex CLI/IDE host identity, separate checker / FROZEN_READSET_NO_WRITE; local consent for data path; Native permit only for SWOF effect | POS: python -m build → wheel + console script / NEG: CLI_NO_ENTRYPOINT_PREW3_SHADOW; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 0dff6839fdf7 | CLI_TOOL/PREW3_SHADOW | Codex | OFF | W2_SHADOW_READ_ONLY | W2_FROZEN_READSET_ONLY; deny writes; PROVIDER_OFF: no provider/model silent replacement | tracked Codex CLI/IDE host identity, separate checker / FROZEN_READSET_NO_WRITE; local consent for data path; Native permit only for SWOF effect | POS: python -m build → wheel + console script / NEG: CLI_NO_ENTRYPOINT_PREW3_SHADOW; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 1cf2ae4386cb | CLI_TOOL/PREW3_SHADOW | Claude Code | ON | W2_SHADOW_READ_ONLY | W2_FROZEN_READSET_ONLY; deny writes | fresh Claude Code real loader/permission proof / FROZEN_READSET_NO_WRITE; local consent for data path; Native permit only for SWOF effect | POS: python -m build → wheel + console script / NEG: CLI_NO_ENTRYPOINT_PREW3_SHADOW; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| b6b3031965fa | CLI_TOOL/PREW3_SHADOW | Claude Code | OFF | W2_SHADOW_READ_ONLY | W2_FROZEN_READSET_ONLY; deny writes; PROVIDER_OFF: no provider/model silent replacement | fresh Claude Code real loader/permission proof / FROZEN_READSET_NO_WRITE; local consent for data path; Native permit only for SWOF effect | POS: python -m build → wheel + console script / NEG: CLI_NO_ENTRYPOINT_PREW3_SHADOW; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| e78d746c7bf7 | CLI_TOOL/PREW3_SHADOW | DeepSeek Harness | ON | W2_SHADOW_READ_ONLY | W2_FROZEN_READSET_ONLY; deny writes | API_ONLY=>NO_FIT; actual harness ABI mandatory / FROZEN_READSET_NO_WRITE; local consent for data path; Native permit only for SWOF effect | POS: python -m build → wheel + console script / NEG: CLI_NO_ENTRYPOINT_PREW3_SHADOW; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| fabd535f6b8d | CLI_TOOL/PREW3_SHADOW | DeepSeek Harness | OFF | W2_SHADOW_READ_ONLY | W2_FROZEN_READSET_ONLY; deny writes; PROVIDER_OFF: no provider/model silent replacement | API_ONLY=>NO_FIT; actual harness ABI mandatory / FROZEN_READSET_NO_WRITE; local consent for data path; Native permit only for SWOF effect | POS: python -m build → wheel + console script / NEG: CLI_NO_ENTRYPOINT_PREW3_SHADOW; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 68f927602c56 | CLI_TOOL/SWOF_CONNECTED | Hermes Agent | ON | NATIVE_ADMISSION_REQUIRED | NATIVE_ADMISSION_REQUIRED, not qualified | live loader+permission+fresh session / ONE_ECP_HUMAN_TOKEN_NATIVE_ACK; local consent for data path; Native permit only for SWOF effect | POS: python -m build → wheel + console script / NEG: CLI_NO_ENTRYPOINT_SWOF_CONNECTED; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 09a9c6d13bb7 | CLI_TOOL/SWOF_CONNECTED | Hermes Agent | OFF | NATIVE_ADMISSION_REQUIRED | NATIVE_ADMISSION_REQUIRED, not qualified; PROVIDER_OFF: no provider/model silent replacement | live loader+permission+fresh session / ONE_ECP_HUMAN_TOKEN_NATIVE_ACK; local consent for data path; Native permit only for SWOF effect | POS: python -m build → wheel + console script / NEG: CLI_NO_ENTRYPOINT_SWOF_CONNECTED; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 62767ea0b8e8 | CLI_TOOL/SWOF_CONNECTED | Codex | ON | NATIVE_ADMISSION_REQUIRED | NATIVE_ADMISSION_REQUIRED, not qualified | tracked Codex CLI/IDE host identity, separate checker / ONE_ECP_HUMAN_TOKEN_NATIVE_ACK; local consent for data path; Native permit only for SWOF effect | POS: python -m build → wheel + console script / NEG: CLI_NO_ENTRYPOINT_SWOF_CONNECTED; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 739b3b5375fc | CLI_TOOL/SWOF_CONNECTED | Codex | OFF | NATIVE_ADMISSION_REQUIRED | NATIVE_ADMISSION_REQUIRED, not qualified; PROVIDER_OFF: no provider/model silent replacement | tracked Codex CLI/IDE host identity, separate checker / ONE_ECP_HUMAN_TOKEN_NATIVE_ACK; local consent for data path; Native permit only for SWOF effect | POS: python -m build → wheel + console script / NEG: CLI_NO_ENTRYPOINT_SWOF_CONNECTED; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 944d6c462137 | CLI_TOOL/SWOF_CONNECTED | Claude Code | ON | NATIVE_ADMISSION_REQUIRED | NATIVE_ADMISSION_REQUIRED, not qualified | fresh Claude Code real loader/permission proof / ONE_ECP_HUMAN_TOKEN_NATIVE_ACK; local consent for data path; Native permit only for SWOF effect | POS: python -m build → wheel + console script / NEG: CLI_NO_ENTRYPOINT_SWOF_CONNECTED; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 1444ab821832 | CLI_TOOL/SWOF_CONNECTED | Claude Code | OFF | NATIVE_ADMISSION_REQUIRED | NATIVE_ADMISSION_REQUIRED, not qualified; PROVIDER_OFF: no provider/model silent replacement | fresh Claude Code real loader/permission proof / ONE_ECP_HUMAN_TOKEN_NATIVE_ACK; local consent for data path; Native permit only for SWOF effect | POS: python -m build → wheel + console script / NEG: CLI_NO_ENTRYPOINT_SWOF_CONNECTED; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| f5c5147c11c1 | CLI_TOOL/SWOF_CONNECTED | DeepSeek Harness | ON | NATIVE_ADMISSION_REQUIRED | NATIVE_ADMISSION_REQUIRED, not qualified | API_ONLY=>NO_FIT; actual harness ABI mandatory / ONE_ECP_HUMAN_TOKEN_NATIVE_ACK; local consent for data path; Native permit only for SWOF effect | POS: python -m build → wheel + console script / NEG: CLI_NO_ENTRYPOINT_SWOF_CONNECTED; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 5bd80e6cf274 | CLI_TOOL/SWOF_CONNECTED | DeepSeek Harness | OFF | NATIVE_ADMISSION_REQUIRED | NATIVE_ADMISSION_REQUIRED, not qualified; PROVIDER_OFF: no provider/model silent replacement | API_ONLY=>NO_FIT; actual harness ABI mandatory / ONE_ECP_HUMAN_TOKEN_NATIVE_ACK; local consent for data path; Native permit only for SWOF effect | POS: python -m build → wheel + console script / NEG: CLI_NO_ENTRYPOINT_SWOF_CONNECTED; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| b368d7497e83 | AGENT_SKILL/STANDALONE | Hermes Agent | ON | LOCAL_DESIGN_ELIGIBLE_NOT_INSTALLED | HOST_DISCOVERY+TRIGGER+NONTRIGGER+UNLOAD REQUIRED; no assumed install | live loader+permission+fresh session / LOCAL_USER_CONSENT; host-specific effective load and trigger consent | POS: SKILL.md+references+manifest / NEG: SKILL_NOT_DISCOVERED_STANDALONE; NO_SIDE_EFFECT_WITHOUT_USER_CONSENT / NOFIT: missing installed host/policy/permission |
| a488c020ca0b | AGENT_SKILL/STANDALONE | Hermes Agent | OFF | LOCAL_DESIGN_ELIGIBLE_NOT_INSTALLED | HOST_DISCOVERY+TRIGGER+NONTRIGGER+UNLOAD REQUIRED; no assumed install; PROVIDER_OFF: no provider/model silent replacement | live loader+permission+fresh session / LOCAL_USER_CONSENT; host-specific effective load and trigger consent | POS: SKILL.md+references+manifest / NEG: SKILL_NOT_DISCOVERED_STANDALONE; NO_SIDE_EFFECT_WITHOUT_USER_CONSENT / NOFIT: missing installed host/policy/permission |
| cab792bba33a | AGENT_SKILL/STANDALONE | Codex | ON | LOCAL_DESIGN_ELIGIBLE_NOT_INSTALLED | HOST_DISCOVERY+TRIGGER+NONTRIGGER+UNLOAD REQUIRED; no assumed install | tracked Codex CLI/IDE host identity, separate checker / LOCAL_USER_CONSENT; host-specific effective load and trigger consent | POS: SKILL.md+references+manifest / NEG: SKILL_NOT_DISCOVERED_STANDALONE; NO_SIDE_EFFECT_WITHOUT_USER_CONSENT / NOFIT: missing installed host/policy/permission |
| 220de7b8b1e7 | AGENT_SKILL/STANDALONE | Codex | OFF | LOCAL_DESIGN_ELIGIBLE_NOT_INSTALLED | HOST_DISCOVERY+TRIGGER+NONTRIGGER+UNLOAD REQUIRED; no assumed install; PROVIDER_OFF: no provider/model silent replacement | tracked Codex CLI/IDE host identity, separate checker / LOCAL_USER_CONSENT; host-specific effective load and trigger consent | POS: SKILL.md+references+manifest / NEG: SKILL_NOT_DISCOVERED_STANDALONE; NO_SIDE_EFFECT_WITHOUT_USER_CONSENT / NOFIT: missing installed host/policy/permission |
| e05964530c47 | AGENT_SKILL/STANDALONE | Claude Code | ON | LOCAL_DESIGN_ELIGIBLE_NOT_INSTALLED | HOST_DISCOVERY+TRIGGER+NONTRIGGER+UNLOAD REQUIRED; no assumed install | fresh Claude Code real loader/permission proof / LOCAL_USER_CONSENT; host-specific effective load and trigger consent | POS: SKILL.md+references+manifest / NEG: SKILL_NOT_DISCOVERED_STANDALONE; NO_SIDE_EFFECT_WITHOUT_USER_CONSENT / NOFIT: missing installed host/policy/permission |
| ea5d66500738 | AGENT_SKILL/STANDALONE | Claude Code | OFF | LOCAL_DESIGN_ELIGIBLE_NOT_INSTALLED | HOST_DISCOVERY+TRIGGER+NONTRIGGER+UNLOAD REQUIRED; no assumed install; PROVIDER_OFF: no provider/model silent replacement | fresh Claude Code real loader/permission proof / LOCAL_USER_CONSENT; host-specific effective load and trigger consent | POS: SKILL.md+references+manifest / NEG: SKILL_NOT_DISCOVERED_STANDALONE; NO_SIDE_EFFECT_WITHOUT_USER_CONSENT / NOFIT: missing installed host/policy/permission |
| cb678bd208a8 | AGENT_SKILL/STANDALONE | DeepSeek Harness | ON | LOCAL_DESIGN_ELIGIBLE_NOT_INSTALLED | HOST_DISCOVERY+TRIGGER+NONTRIGGER+UNLOAD REQUIRED; no assumed install | API_ONLY=>NO_FIT; actual harness ABI mandatory / LOCAL_USER_CONSENT; host-specific effective load and trigger consent | POS: SKILL.md+references+manifest / NEG: SKILL_NOT_DISCOVERED_STANDALONE; NO_SIDE_EFFECT_WITHOUT_USER_CONSENT / NOFIT: missing installed host/policy/permission |
| 6e1c0fb8d36b | AGENT_SKILL/STANDALONE | DeepSeek Harness | OFF | LOCAL_DESIGN_ELIGIBLE_NOT_INSTALLED | HOST_DISCOVERY+TRIGGER+NONTRIGGER+UNLOAD REQUIRED; no assumed install; PROVIDER_OFF: no provider/model silent replacement | API_ONLY=>NO_FIT; actual harness ABI mandatory / LOCAL_USER_CONSENT; host-specific effective load and trigger consent | POS: SKILL.md+references+manifest / NEG: SKILL_NOT_DISCOVERED_STANDALONE; NO_SIDE_EFFECT_WITHOUT_USER_CONSENT / NOFIT: missing installed host/policy/permission |
| dd676737681e | AGENT_SKILL/PREW3_SHADOW | Hermes Agent | ON | W2_SHADOW_READ_ONLY | W2_FROZEN_READSET_ONLY; deny writes | live loader+permission+fresh session / FROZEN_READSET_NO_WRITE; host-specific effective load and trigger consent | POS: SKILL.md+references+manifest / NEG: SKILL_NOT_DISCOVERED_PREW3_SHADOW; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 6c0ad0177a48 | AGENT_SKILL/PREW3_SHADOW | Hermes Agent | OFF | W2_SHADOW_READ_ONLY | W2_FROZEN_READSET_ONLY; deny writes; PROVIDER_OFF: no provider/model silent replacement | live loader+permission+fresh session / FROZEN_READSET_NO_WRITE; host-specific effective load and trigger consent | POS: SKILL.md+references+manifest / NEG: SKILL_NOT_DISCOVERED_PREW3_SHADOW; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 702455102b0e | AGENT_SKILL/PREW3_SHADOW | Codex | ON | W2_SHADOW_READ_ONLY | W2_FROZEN_READSET_ONLY; deny writes | tracked Codex CLI/IDE host identity, separate checker / FROZEN_READSET_NO_WRITE; host-specific effective load and trigger consent | POS: SKILL.md+references+manifest / NEG: SKILL_NOT_DISCOVERED_PREW3_SHADOW; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| d7b2369a3d11 | AGENT_SKILL/PREW3_SHADOW | Codex | OFF | W2_SHADOW_READ_ONLY | W2_FROZEN_READSET_ONLY; deny writes; PROVIDER_OFF: no provider/model silent replacement | tracked Codex CLI/IDE host identity, separate checker / FROZEN_READSET_NO_WRITE; host-specific effective load and trigger consent | POS: SKILL.md+references+manifest / NEG: SKILL_NOT_DISCOVERED_PREW3_SHADOW; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 3b2af66f8936 | AGENT_SKILL/PREW3_SHADOW | Claude Code | ON | W2_SHADOW_READ_ONLY | W2_FROZEN_READSET_ONLY; deny writes | fresh Claude Code real loader/permission proof / FROZEN_READSET_NO_WRITE; host-specific effective load and trigger consent | POS: SKILL.md+references+manifest / NEG: SKILL_NOT_DISCOVERED_PREW3_SHADOW; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 46f0028dabe2 | AGENT_SKILL/PREW3_SHADOW | Claude Code | OFF | W2_SHADOW_READ_ONLY | W2_FROZEN_READSET_ONLY; deny writes; PROVIDER_OFF: no provider/model silent replacement | fresh Claude Code real loader/permission proof / FROZEN_READSET_NO_WRITE; host-specific effective load and trigger consent | POS: SKILL.md+references+manifest / NEG: SKILL_NOT_DISCOVERED_PREW3_SHADOW; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| ae3081300a06 | AGENT_SKILL/PREW3_SHADOW | DeepSeek Harness | ON | W2_SHADOW_READ_ONLY | W2_FROZEN_READSET_ONLY; deny writes | API_ONLY=>NO_FIT; actual harness ABI mandatory / FROZEN_READSET_NO_WRITE; host-specific effective load and trigger consent | POS: SKILL.md+references+manifest / NEG: SKILL_NOT_DISCOVERED_PREW3_SHADOW; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 79aa1ca6c95f | AGENT_SKILL/PREW3_SHADOW | DeepSeek Harness | OFF | W2_SHADOW_READ_ONLY | W2_FROZEN_READSET_ONLY; deny writes; PROVIDER_OFF: no provider/model silent replacement | API_ONLY=>NO_FIT; actual harness ABI mandatory / FROZEN_READSET_NO_WRITE; host-specific effective load and trigger consent | POS: SKILL.md+references+manifest / NEG: SKILL_NOT_DISCOVERED_PREW3_SHADOW; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 706d7dabb0a0 | AGENT_SKILL/SWOF_CONNECTED | Hermes Agent | ON | NATIVE_ADMISSION_REQUIRED | NATIVE_ADMISSION_REQUIRED, not qualified | live loader+permission+fresh session / ONE_ECP_HUMAN_TOKEN_NATIVE_ACK; host-specific effective load and trigger consent | POS: SKILL.md+references+manifest / NEG: SKILL_NOT_DISCOVERED_SWOF_CONNECTED; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| aab24b0f82f9 | AGENT_SKILL/SWOF_CONNECTED | Hermes Agent | OFF | NATIVE_ADMISSION_REQUIRED | NATIVE_ADMISSION_REQUIRED, not qualified; PROVIDER_OFF: no provider/model silent replacement | live loader+permission+fresh session / ONE_ECP_HUMAN_TOKEN_NATIVE_ACK; host-specific effective load and trigger consent | POS: SKILL.md+references+manifest / NEG: SKILL_NOT_DISCOVERED_SWOF_CONNECTED; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 75634c7787b2 | AGENT_SKILL/SWOF_CONNECTED | Codex | ON | NATIVE_ADMISSION_REQUIRED | NATIVE_ADMISSION_REQUIRED, not qualified | tracked Codex CLI/IDE host identity, separate checker / ONE_ECP_HUMAN_TOKEN_NATIVE_ACK; host-specific effective load and trigger consent | POS: SKILL.md+references+manifest / NEG: SKILL_NOT_DISCOVERED_SWOF_CONNECTED; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| e341b6d0f605 | AGENT_SKILL/SWOF_CONNECTED | Codex | OFF | NATIVE_ADMISSION_REQUIRED | NATIVE_ADMISSION_REQUIRED, not qualified; PROVIDER_OFF: no provider/model silent replacement | tracked Codex CLI/IDE host identity, separate checker / ONE_ECP_HUMAN_TOKEN_NATIVE_ACK; host-specific effective load and trigger consent | POS: SKILL.md+references+manifest / NEG: SKILL_NOT_DISCOVERED_SWOF_CONNECTED; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| e9941d45073f | AGENT_SKILL/SWOF_CONNECTED | Claude Code | ON | NATIVE_ADMISSION_REQUIRED | NATIVE_ADMISSION_REQUIRED, not qualified | fresh Claude Code real loader/permission proof / ONE_ECP_HUMAN_TOKEN_NATIVE_ACK; host-specific effective load and trigger consent | POS: SKILL.md+references+manifest / NEG: SKILL_NOT_DISCOVERED_SWOF_CONNECTED; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| e51ce0738940 | AGENT_SKILL/SWOF_CONNECTED | Claude Code | OFF | NATIVE_ADMISSION_REQUIRED | NATIVE_ADMISSION_REQUIRED, not qualified; PROVIDER_OFF: no provider/model silent replacement | fresh Claude Code real loader/permission proof / ONE_ECP_HUMAN_TOKEN_NATIVE_ACK; host-specific effective load and trigger consent | POS: SKILL.md+references+manifest / NEG: SKILL_NOT_DISCOVERED_SWOF_CONNECTED; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 48757186c510 | AGENT_SKILL/SWOF_CONNECTED | DeepSeek Harness | ON | NATIVE_ADMISSION_REQUIRED | NATIVE_ADMISSION_REQUIRED, not qualified | API_ONLY=>NO_FIT; actual harness ABI mandatory / ONE_ECP_HUMAN_TOKEN_NATIVE_ACK; host-specific effective load and trigger consent | POS: SKILL.md+references+manifest / NEG: SKILL_NOT_DISCOVERED_SWOF_CONNECTED; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 9df05458d74f | AGENT_SKILL/SWOF_CONNECTED | DeepSeek Harness | OFF | NATIVE_ADMISSION_REQUIRED | NATIVE_ADMISSION_REQUIRED, not qualified; PROVIDER_OFF: no provider/model silent replacement | API_ONLY=>NO_FIT; actual harness ABI mandatory / ONE_ECP_HUMAN_TOKEN_NATIVE_ACK; host-specific effective load and trigger consent | POS: SKILL.md+references+manifest / NEG: SKILL_NOT_DISCOVERED_SWOF_CONNECTED; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 52b5e63d094d | SIMPLE_AGENT/STANDALONE | Hermes Agent | ON | LOCAL_DESIGN_ELIGIBLE_NOT_INSTALLED | HOST_DISCOVERY+TRIGGER+NONTRIGGER+UNLOAD REQUIRED; no assumed install | live loader+permission+fresh session / LOCAL_USER_CONSENT; human decision before write/shell/network effect | POS: agent manifest + stop policy + loop budget / NEG: AGENT_UNBOUNDED_STANDALONE; NO_SIDE_EFFECT_WITHOUT_USER_CONSENT / NOFIT: missing installed host/policy/permission |
| 1c821c1ea7d8 | SIMPLE_AGENT/STANDALONE | Hermes Agent | OFF | LOCAL_DESIGN_ELIGIBLE_NOT_INSTALLED | HOST_DISCOVERY+TRIGGER+NONTRIGGER+UNLOAD REQUIRED; no assumed install; PROVIDER_OFF: no provider/model silent replacement | live loader+permission+fresh session / LOCAL_USER_CONSENT; human decision before write/shell/network effect | POS: agent manifest + stop policy + loop budget / NEG: AGENT_UNBOUNDED_STANDALONE; NO_SIDE_EFFECT_WITHOUT_USER_CONSENT / NOFIT: missing installed host/policy/permission |
| 3a2a9dad37ae | SIMPLE_AGENT/STANDALONE | Codex | ON | LOCAL_DESIGN_ELIGIBLE_NOT_INSTALLED | HOST_DISCOVERY+TRIGGER+NONTRIGGER+UNLOAD REQUIRED; no assumed install | tracked Codex CLI/IDE host identity, separate checker / LOCAL_USER_CONSENT; human decision before write/shell/network effect | POS: agent manifest + stop policy + loop budget / NEG: AGENT_UNBOUNDED_STANDALONE; NO_SIDE_EFFECT_WITHOUT_USER_CONSENT / NOFIT: missing installed host/policy/permission |
| 87b5a1fe58cf | SIMPLE_AGENT/STANDALONE | Codex | OFF | LOCAL_DESIGN_ELIGIBLE_NOT_INSTALLED | HOST_DISCOVERY+TRIGGER+NONTRIGGER+UNLOAD REQUIRED; no assumed install; PROVIDER_OFF: no provider/model silent replacement | tracked Codex CLI/IDE host identity, separate checker / LOCAL_USER_CONSENT; human decision before write/shell/network effect | POS: agent manifest + stop policy + loop budget / NEG: AGENT_UNBOUNDED_STANDALONE; NO_SIDE_EFFECT_WITHOUT_USER_CONSENT / NOFIT: missing installed host/policy/permission |
| 9e24d28c894c | SIMPLE_AGENT/STANDALONE | Claude Code | ON | LOCAL_DESIGN_ELIGIBLE_NOT_INSTALLED | HOST_DISCOVERY+TRIGGER+NONTRIGGER+UNLOAD REQUIRED; no assumed install | fresh Claude Code real loader/permission proof / LOCAL_USER_CONSENT; human decision before write/shell/network effect | POS: agent manifest + stop policy + loop budget / NEG: AGENT_UNBOUNDED_STANDALONE; NO_SIDE_EFFECT_WITHOUT_USER_CONSENT / NOFIT: missing installed host/policy/permission |
| 94a990f58257 | SIMPLE_AGENT/STANDALONE | Claude Code | OFF | LOCAL_DESIGN_ELIGIBLE_NOT_INSTALLED | HOST_DISCOVERY+TRIGGER+NONTRIGGER+UNLOAD REQUIRED; no assumed install; PROVIDER_OFF: no provider/model silent replacement | fresh Claude Code real loader/permission proof / LOCAL_USER_CONSENT; human decision before write/shell/network effect | POS: agent manifest + stop policy + loop budget / NEG: AGENT_UNBOUNDED_STANDALONE; NO_SIDE_EFFECT_WITHOUT_USER_CONSENT / NOFIT: missing installed host/policy/permission |
| f0a4964020d6 | SIMPLE_AGENT/STANDALONE | DeepSeek Harness | ON | LOCAL_DESIGN_ELIGIBLE_NOT_INSTALLED | HOST_DISCOVERY+TRIGGER+NONTRIGGER+UNLOAD REQUIRED; no assumed install | API_ONLY=>NO_FIT; actual harness ABI mandatory / LOCAL_USER_CONSENT; human decision before write/shell/network effect | POS: agent manifest + stop policy + loop budget / NEG: AGENT_UNBOUNDED_STANDALONE; NO_SIDE_EFFECT_WITHOUT_USER_CONSENT / NOFIT: missing installed host/policy/permission |
| 8ba7cd2138c5 | SIMPLE_AGENT/STANDALONE | DeepSeek Harness | OFF | LOCAL_DESIGN_ELIGIBLE_NOT_INSTALLED | HOST_DISCOVERY+TRIGGER+NONTRIGGER+UNLOAD REQUIRED; no assumed install; PROVIDER_OFF: no provider/model silent replacement | API_ONLY=>NO_FIT; actual harness ABI mandatory / LOCAL_USER_CONSENT; human decision before write/shell/network effect | POS: agent manifest + stop policy + loop budget / NEG: AGENT_UNBOUNDED_STANDALONE; NO_SIDE_EFFECT_WITHOUT_USER_CONSENT / NOFIT: missing installed host/policy/permission |
| e704b0923b71 | SIMPLE_AGENT/PREW3_SHADOW | Hermes Agent | ON | W2_SHADOW_READ_ONLY | W2_FROZEN_READSET_ONLY; deny writes | live loader+permission+fresh session / FROZEN_READSET_NO_WRITE; human decision before write/shell/network effect | POS: agent manifest + stop policy + loop budget / NEG: AGENT_UNBOUNDED_PREW3_SHADOW; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 834018317c72 | SIMPLE_AGENT/PREW3_SHADOW | Hermes Agent | OFF | W2_SHADOW_READ_ONLY | W2_FROZEN_READSET_ONLY; deny writes; PROVIDER_OFF: no provider/model silent replacement | live loader+permission+fresh session / FROZEN_READSET_NO_WRITE; human decision before write/shell/network effect | POS: agent manifest + stop policy + loop budget / NEG: AGENT_UNBOUNDED_PREW3_SHADOW; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| a433df5357ac | SIMPLE_AGENT/PREW3_SHADOW | Codex | ON | W2_SHADOW_READ_ONLY | W2_FROZEN_READSET_ONLY; deny writes | tracked Codex CLI/IDE host identity, separate checker / FROZEN_READSET_NO_WRITE; human decision before write/shell/network effect | POS: agent manifest + stop policy + loop budget / NEG: AGENT_UNBOUNDED_PREW3_SHADOW; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| d92746482fe6 | SIMPLE_AGENT/PREW3_SHADOW | Codex | OFF | W2_SHADOW_READ_ONLY | W2_FROZEN_READSET_ONLY; deny writes; PROVIDER_OFF: no provider/model silent replacement | tracked Codex CLI/IDE host identity, separate checker / FROZEN_READSET_NO_WRITE; human decision before write/shell/network effect | POS: agent manifest + stop policy + loop budget / NEG: AGENT_UNBOUNDED_PREW3_SHADOW; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 3083c98d4210 | SIMPLE_AGENT/PREW3_SHADOW | Claude Code | ON | W2_SHADOW_READ_ONLY | W2_FROZEN_READSET_ONLY; deny writes | fresh Claude Code real loader/permission proof / FROZEN_READSET_NO_WRITE; human decision before write/shell/network effect | POS: agent manifest + stop policy + loop budget / NEG: AGENT_UNBOUNDED_PREW3_SHADOW; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 97174a3d45e8 | SIMPLE_AGENT/PREW3_SHADOW | Claude Code | OFF | W2_SHADOW_READ_ONLY | W2_FROZEN_READSET_ONLY; deny writes; PROVIDER_OFF: no provider/model silent replacement | fresh Claude Code real loader/permission proof / FROZEN_READSET_NO_WRITE; human decision before write/shell/network effect | POS: agent manifest + stop policy + loop budget / NEG: AGENT_UNBOUNDED_PREW3_SHADOW; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 84fa01909649 | SIMPLE_AGENT/PREW3_SHADOW | DeepSeek Harness | ON | W2_SHADOW_READ_ONLY | W2_FROZEN_READSET_ONLY; deny writes | API_ONLY=>NO_FIT; actual harness ABI mandatory / FROZEN_READSET_NO_WRITE; human decision before write/shell/network effect | POS: agent manifest + stop policy + loop budget / NEG: AGENT_UNBOUNDED_PREW3_SHADOW; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| f77b24e32aaa | SIMPLE_AGENT/PREW3_SHADOW | DeepSeek Harness | OFF | W2_SHADOW_READ_ONLY | W2_FROZEN_READSET_ONLY; deny writes; PROVIDER_OFF: no provider/model silent replacement | API_ONLY=>NO_FIT; actual harness ABI mandatory / FROZEN_READSET_NO_WRITE; human decision before write/shell/network effect | POS: agent manifest + stop policy + loop budget / NEG: AGENT_UNBOUNDED_PREW3_SHADOW; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| c1788f1272d7 | SIMPLE_AGENT/SWOF_CONNECTED | Hermes Agent | ON | NATIVE_ADMISSION_REQUIRED | NATIVE_ADMISSION_REQUIRED, not qualified | live loader+permission+fresh session / ONE_ECP_HUMAN_TOKEN_NATIVE_ACK; human decision before write/shell/network effect | POS: agent manifest + stop policy + loop budget / NEG: AGENT_UNBOUNDED_SWOF_CONNECTED; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 2a6bfd344f3f | SIMPLE_AGENT/SWOF_CONNECTED | Hermes Agent | OFF | NATIVE_ADMISSION_REQUIRED | NATIVE_ADMISSION_REQUIRED, not qualified; PROVIDER_OFF: no provider/model silent replacement | live loader+permission+fresh session / ONE_ECP_HUMAN_TOKEN_NATIVE_ACK; human decision before write/shell/network effect | POS: agent manifest + stop policy + loop budget / NEG: AGENT_UNBOUNDED_SWOF_CONNECTED; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| e2daf2609c40 | SIMPLE_AGENT/SWOF_CONNECTED | Codex | ON | NATIVE_ADMISSION_REQUIRED | NATIVE_ADMISSION_REQUIRED, not qualified | tracked Codex CLI/IDE host identity, separate checker / ONE_ECP_HUMAN_TOKEN_NATIVE_ACK; human decision before write/shell/network effect | POS: agent manifest + stop policy + loop budget / NEG: AGENT_UNBOUNDED_SWOF_CONNECTED; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| d880b5ac23a4 | SIMPLE_AGENT/SWOF_CONNECTED | Codex | OFF | NATIVE_ADMISSION_REQUIRED | NATIVE_ADMISSION_REQUIRED, not qualified; PROVIDER_OFF: no provider/model silent replacement | tracked Codex CLI/IDE host identity, separate checker / ONE_ECP_HUMAN_TOKEN_NATIVE_ACK; human decision before write/shell/network effect | POS: agent manifest + stop policy + loop budget / NEG: AGENT_UNBOUNDED_SWOF_CONNECTED; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| ef6dac107879 | SIMPLE_AGENT/SWOF_CONNECTED | Claude Code | ON | NATIVE_ADMISSION_REQUIRED | NATIVE_ADMISSION_REQUIRED, not qualified | fresh Claude Code real loader/permission proof / ONE_ECP_HUMAN_TOKEN_NATIVE_ACK; human decision before write/shell/network effect | POS: agent manifest + stop policy + loop budget / NEG: AGENT_UNBOUNDED_SWOF_CONNECTED; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| c1ae4375bd05 | SIMPLE_AGENT/SWOF_CONNECTED | Claude Code | OFF | NATIVE_ADMISSION_REQUIRED | NATIVE_ADMISSION_REQUIRED, not qualified; PROVIDER_OFF: no provider/model silent replacement | fresh Claude Code real loader/permission proof / ONE_ECP_HUMAN_TOKEN_NATIVE_ACK; human decision before write/shell/network effect | POS: agent manifest + stop policy + loop budget / NEG: AGENT_UNBOUNDED_SWOF_CONNECTED; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 09c21bb6612b | SIMPLE_AGENT/SWOF_CONNECTED | DeepSeek Harness | ON | NATIVE_ADMISSION_REQUIRED | NATIVE_ADMISSION_REQUIRED, not qualified | API_ONLY=>NO_FIT; actual harness ABI mandatory / ONE_ECP_HUMAN_TOKEN_NATIVE_ACK; human decision before write/shell/network effect | POS: agent manifest + stop policy + loop budget / NEG: AGENT_UNBOUNDED_SWOF_CONNECTED; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 9be3a648f57b | SIMPLE_AGENT/SWOF_CONNECTED | DeepSeek Harness | OFF | NATIVE_ADMISSION_REQUIRED | NATIVE_ADMISSION_REQUIRED, not qualified; PROVIDER_OFF: no provider/model silent replacement | API_ONLY=>NO_FIT; actual harness ABI mandatory / ONE_ECP_HUMAN_TOKEN_NATIVE_ACK; human decision before write/shell/network effect | POS: agent manifest + stop policy + loop budget / NEG: AGENT_UNBOUNDED_SWOF_CONNECTED; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 90776ef8d07b | PLUGIN/STANDALONE | Hermes Agent | ON | DEFERRED_HOST_ADMISSION_HOLD | DEFERRED_HOST_ADMISSION_HOLD, no assumed loader | live loader+permission+fresh session / NO_EFFECT_UNTIL_ADMISSION; explicit host plugin entitlement and uninstall | POS: plugin manifest + signed/allowlisted host bundle / NEG: PLUGIN_HOST_UNQUALIFIED_STANDALONE; NO_SIDE_EFFECT_WITHOUT_USER_CONSENT / NOFIT: missing installed host/policy/permission |
| f6718f8c8a9f | PLUGIN/STANDALONE | Hermes Agent | OFF | DEFERRED_HOST_ADMISSION_HOLD | DEFERRED_HOST_ADMISSION_HOLD, no assumed loader; PROVIDER_OFF: no provider/model silent replacement | live loader+permission+fresh session / NO_EFFECT_UNTIL_ADMISSION; explicit host plugin entitlement and uninstall | POS: plugin manifest + signed/allowlisted host bundle / NEG: PLUGIN_HOST_UNQUALIFIED_STANDALONE; NO_SIDE_EFFECT_WITHOUT_USER_CONSENT / NOFIT: missing installed host/policy/permission |
| b4c34ec88f14 | PLUGIN/STANDALONE | Codex | ON | DEFERRED_HOST_ADMISSION_HOLD | DEFERRED_HOST_ADMISSION_HOLD, no assumed loader | tracked Codex CLI/IDE host identity, separate checker / NO_EFFECT_UNTIL_ADMISSION; explicit host plugin entitlement and uninstall | POS: plugin manifest + signed/allowlisted host bundle / NEG: PLUGIN_HOST_UNQUALIFIED_STANDALONE; NO_SIDE_EFFECT_WITHOUT_USER_CONSENT / NOFIT: missing installed host/policy/permission |
| 530a88ba777d | PLUGIN/STANDALONE | Codex | OFF | DEFERRED_HOST_ADMISSION_HOLD | DEFERRED_HOST_ADMISSION_HOLD, no assumed loader; PROVIDER_OFF: no provider/model silent replacement | tracked Codex CLI/IDE host identity, separate checker / NO_EFFECT_UNTIL_ADMISSION; explicit host plugin entitlement and uninstall | POS: plugin manifest + signed/allowlisted host bundle / NEG: PLUGIN_HOST_UNQUALIFIED_STANDALONE; NO_SIDE_EFFECT_WITHOUT_USER_CONSENT / NOFIT: missing installed host/policy/permission |
| 1a9181fe48c5 | PLUGIN/STANDALONE | Claude Code | ON | DEFERRED_HOST_ADMISSION_HOLD | DEFERRED_HOST_ADMISSION_HOLD, no assumed loader | fresh Claude Code real loader/permission proof / NO_EFFECT_UNTIL_ADMISSION; explicit host plugin entitlement and uninstall | POS: plugin manifest + signed/allowlisted host bundle / NEG: PLUGIN_HOST_UNQUALIFIED_STANDALONE; NO_SIDE_EFFECT_WITHOUT_USER_CONSENT / NOFIT: missing installed host/policy/permission |
| 5334bc0dc4e0 | PLUGIN/STANDALONE | Claude Code | OFF | DEFERRED_HOST_ADMISSION_HOLD | DEFERRED_HOST_ADMISSION_HOLD, no assumed loader; PROVIDER_OFF: no provider/model silent replacement | fresh Claude Code real loader/permission proof / NO_EFFECT_UNTIL_ADMISSION; explicit host plugin entitlement and uninstall | POS: plugin manifest + signed/allowlisted host bundle / NEG: PLUGIN_HOST_UNQUALIFIED_STANDALONE; NO_SIDE_EFFECT_WITHOUT_USER_CONSENT / NOFIT: missing installed host/policy/permission |
| ecca30d3d545 | PLUGIN/STANDALONE | DeepSeek Harness | ON | DEFERRED_HOST_ADMISSION_HOLD | DEFERRED_HOST_ADMISSION_HOLD, no assumed loader | API_ONLY=>NO_FIT; actual harness ABI mandatory / NO_EFFECT_UNTIL_ADMISSION; explicit host plugin entitlement and uninstall | POS: plugin manifest + signed/allowlisted host bundle / NEG: PLUGIN_HOST_UNQUALIFIED_STANDALONE; NO_SIDE_EFFECT_WITHOUT_USER_CONSENT / NOFIT: missing installed host/policy/permission |
| 6acbaf567779 | PLUGIN/STANDALONE | DeepSeek Harness | OFF | DEFERRED_HOST_ADMISSION_HOLD | DEFERRED_HOST_ADMISSION_HOLD, no assumed loader; PROVIDER_OFF: no provider/model silent replacement | API_ONLY=>NO_FIT; actual harness ABI mandatory / NO_EFFECT_UNTIL_ADMISSION; explicit host plugin entitlement and uninstall | POS: plugin manifest + signed/allowlisted host bundle / NEG: PLUGIN_HOST_UNQUALIFIED_STANDALONE; NO_SIDE_EFFECT_WITHOUT_USER_CONSENT / NOFIT: missing installed host/policy/permission |
| f686d9f67c17 | PLUGIN/PREW3_SHADOW | Hermes Agent | ON | DEFERRED_HOST_ADMISSION_HOLD | DEFERRED_HOST_ADMISSION_HOLD, no assumed loader | live loader+permission+fresh session / NO_EFFECT_UNTIL_ADMISSION; explicit host plugin entitlement and uninstall | POS: plugin manifest + signed/allowlisted host bundle / NEG: PLUGIN_HOST_UNQUALIFIED_PREW3_SHADOW; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 675386c0f943 | PLUGIN/PREW3_SHADOW | Hermes Agent | OFF | DEFERRED_HOST_ADMISSION_HOLD | DEFERRED_HOST_ADMISSION_HOLD, no assumed loader; PROVIDER_OFF: no provider/model silent replacement | live loader+permission+fresh session / NO_EFFECT_UNTIL_ADMISSION; explicit host plugin entitlement and uninstall | POS: plugin manifest + signed/allowlisted host bundle / NEG: PLUGIN_HOST_UNQUALIFIED_PREW3_SHADOW; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 412732ed745d | PLUGIN/PREW3_SHADOW | Codex | ON | DEFERRED_HOST_ADMISSION_HOLD | DEFERRED_HOST_ADMISSION_HOLD, no assumed loader | tracked Codex CLI/IDE host identity, separate checker / NO_EFFECT_UNTIL_ADMISSION; explicit host plugin entitlement and uninstall | POS: plugin manifest + signed/allowlisted host bundle / NEG: PLUGIN_HOST_UNQUALIFIED_PREW3_SHADOW; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 9cc9f40bc2ac | PLUGIN/PREW3_SHADOW | Codex | OFF | DEFERRED_HOST_ADMISSION_HOLD | DEFERRED_HOST_ADMISSION_HOLD, no assumed loader; PROVIDER_OFF: no provider/model silent replacement | tracked Codex CLI/IDE host identity, separate checker / NO_EFFECT_UNTIL_ADMISSION; explicit host plugin entitlement and uninstall | POS: plugin manifest + signed/allowlisted host bundle / NEG: PLUGIN_HOST_UNQUALIFIED_PREW3_SHADOW; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 2259ef3f0dc2 | PLUGIN/PREW3_SHADOW | Claude Code | ON | DEFERRED_HOST_ADMISSION_HOLD | DEFERRED_HOST_ADMISSION_HOLD, no assumed loader | fresh Claude Code real loader/permission proof / NO_EFFECT_UNTIL_ADMISSION; explicit host plugin entitlement and uninstall | POS: plugin manifest + signed/allowlisted host bundle / NEG: PLUGIN_HOST_UNQUALIFIED_PREW3_SHADOW; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 4f536bbc5402 | PLUGIN/PREW3_SHADOW | Claude Code | OFF | DEFERRED_HOST_ADMISSION_HOLD | DEFERRED_HOST_ADMISSION_HOLD, no assumed loader; PROVIDER_OFF: no provider/model silent replacement | fresh Claude Code real loader/permission proof / NO_EFFECT_UNTIL_ADMISSION; explicit host plugin entitlement and uninstall | POS: plugin manifest + signed/allowlisted host bundle / NEG: PLUGIN_HOST_UNQUALIFIED_PREW3_SHADOW; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| bc4919027c0c | PLUGIN/PREW3_SHADOW | DeepSeek Harness | ON | DEFERRED_HOST_ADMISSION_HOLD | DEFERRED_HOST_ADMISSION_HOLD, no assumed loader | API_ONLY=>NO_FIT; actual harness ABI mandatory / NO_EFFECT_UNTIL_ADMISSION; explicit host plugin entitlement and uninstall | POS: plugin manifest + signed/allowlisted host bundle / NEG: PLUGIN_HOST_UNQUALIFIED_PREW3_SHADOW; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 06bbd5e5ecb2 | PLUGIN/PREW3_SHADOW | DeepSeek Harness | OFF | DEFERRED_HOST_ADMISSION_HOLD | DEFERRED_HOST_ADMISSION_HOLD, no assumed loader; PROVIDER_OFF: no provider/model silent replacement | API_ONLY=>NO_FIT; actual harness ABI mandatory / NO_EFFECT_UNTIL_ADMISSION; explicit host plugin entitlement and uninstall | POS: plugin manifest + signed/allowlisted host bundle / NEG: PLUGIN_HOST_UNQUALIFIED_PREW3_SHADOW; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| d19d2e42002a | PLUGIN/SWOF_CONNECTED | Hermes Agent | ON | DEFERRED_HOST_ADMISSION_HOLD | DEFERRED_HOST_ADMISSION_HOLD, no assumed loader | live loader+permission+fresh session / NO_EFFECT_UNTIL_ADMISSION; explicit host plugin entitlement and uninstall | POS: plugin manifest + signed/allowlisted host bundle / NEG: PLUGIN_HOST_UNQUALIFIED_SWOF_CONNECTED; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 49cdd601f213 | PLUGIN/SWOF_CONNECTED | Hermes Agent | OFF | DEFERRED_HOST_ADMISSION_HOLD | DEFERRED_HOST_ADMISSION_HOLD, no assumed loader; PROVIDER_OFF: no provider/model silent replacement | live loader+permission+fresh session / NO_EFFECT_UNTIL_ADMISSION; explicit host plugin entitlement and uninstall | POS: plugin manifest + signed/allowlisted host bundle / NEG: PLUGIN_HOST_UNQUALIFIED_SWOF_CONNECTED; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 54d1a08c379f | PLUGIN/SWOF_CONNECTED | Codex | ON | DEFERRED_HOST_ADMISSION_HOLD | DEFERRED_HOST_ADMISSION_HOLD, no assumed loader | tracked Codex CLI/IDE host identity, separate checker / NO_EFFECT_UNTIL_ADMISSION; explicit host plugin entitlement and uninstall | POS: plugin manifest + signed/allowlisted host bundle / NEG: PLUGIN_HOST_UNQUALIFIED_SWOF_CONNECTED; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 2ce069d50986 | PLUGIN/SWOF_CONNECTED | Codex | OFF | DEFERRED_HOST_ADMISSION_HOLD | DEFERRED_HOST_ADMISSION_HOLD, no assumed loader; PROVIDER_OFF: no provider/model silent replacement | tracked Codex CLI/IDE host identity, separate checker / NO_EFFECT_UNTIL_ADMISSION; explicit host plugin entitlement and uninstall | POS: plugin manifest + signed/allowlisted host bundle / NEG: PLUGIN_HOST_UNQUALIFIED_SWOF_CONNECTED; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| afca4537e0b5 | PLUGIN/SWOF_CONNECTED | Claude Code | ON | DEFERRED_HOST_ADMISSION_HOLD | DEFERRED_HOST_ADMISSION_HOLD, no assumed loader | fresh Claude Code real loader/permission proof / NO_EFFECT_UNTIL_ADMISSION; explicit host plugin entitlement and uninstall | POS: plugin manifest + signed/allowlisted host bundle / NEG: PLUGIN_HOST_UNQUALIFIED_SWOF_CONNECTED; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| ae862affcd7c | PLUGIN/SWOF_CONNECTED | Claude Code | OFF | DEFERRED_HOST_ADMISSION_HOLD | DEFERRED_HOST_ADMISSION_HOLD, no assumed loader; PROVIDER_OFF: no provider/model silent replacement | fresh Claude Code real loader/permission proof / NO_EFFECT_UNTIL_ADMISSION; explicit host plugin entitlement and uninstall | POS: plugin manifest + signed/allowlisted host bundle / NEG: PLUGIN_HOST_UNQUALIFIED_SWOF_CONNECTED; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 8bf8d2ec3581 | PLUGIN/SWOF_CONNECTED | DeepSeek Harness | ON | DEFERRED_HOST_ADMISSION_HOLD | DEFERRED_HOST_ADMISSION_HOLD, no assumed loader | API_ONLY=>NO_FIT; actual harness ABI mandatory / NO_EFFECT_UNTIL_ADMISSION; explicit host plugin entitlement and uninstall | POS: plugin manifest + signed/allowlisted host bundle / NEG: PLUGIN_HOST_UNQUALIFIED_SWOF_CONNECTED; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 085bc8fd7622 | PLUGIN/SWOF_CONNECTED | DeepSeek Harness | OFF | DEFERRED_HOST_ADMISSION_HOLD | DEFERRED_HOST_ADMISSION_HOLD, no assumed loader; PROVIDER_OFF: no provider/model silent replacement | API_ONLY=>NO_FIT; actual harness ABI mandatory / NO_EFFECT_UNTIL_ADMISSION; explicit host plugin entitlement and uninstall | POS: plugin manifest + signed/allowlisted host bundle / NEG: PLUGIN_HOST_UNQUALIFIED_SWOF_CONNECTED; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| f6053f9a9dbf | PROFILE/STANDALONE | Hermes Agent | ON | DEFERRED_HOST_ADMISSION_HOLD | DEFERRED_HOST_ADMISSION_HOLD, no assumed loader | live loader+permission+fresh session / NO_EFFECT_UNTIL_ADMISSION; PIPD profile-tailor cannot downgrade safety | POS: profile projection+applicability axis / NEG: PROFILE_SAFETY_VETO_STANDALONE; NO_SIDE_EFFECT_WITHOUT_USER_CONSENT / NOFIT: missing installed host/policy/permission |
| 48759a93f265 | PROFILE/STANDALONE | Hermes Agent | OFF | DEFERRED_HOST_ADMISSION_HOLD | DEFERRED_HOST_ADMISSION_HOLD, no assumed loader; PROVIDER_OFF: no provider/model silent replacement | live loader+permission+fresh session / NO_EFFECT_UNTIL_ADMISSION; PIPD profile-tailor cannot downgrade safety | POS: profile projection+applicability axis / NEG: PROFILE_SAFETY_VETO_STANDALONE; NO_SIDE_EFFECT_WITHOUT_USER_CONSENT / NOFIT: missing installed host/policy/permission |
| ce7ed7519316 | PROFILE/STANDALONE | Codex | ON | DEFERRED_HOST_ADMISSION_HOLD | DEFERRED_HOST_ADMISSION_HOLD, no assumed loader | tracked Codex CLI/IDE host identity, separate checker / NO_EFFECT_UNTIL_ADMISSION; PIPD profile-tailor cannot downgrade safety | POS: profile projection+applicability axis / NEG: PROFILE_SAFETY_VETO_STANDALONE; NO_SIDE_EFFECT_WITHOUT_USER_CONSENT / NOFIT: missing installed host/policy/permission |
| e9109bda38f1 | PROFILE/STANDALONE | Codex | OFF | DEFERRED_HOST_ADMISSION_HOLD | DEFERRED_HOST_ADMISSION_HOLD, no assumed loader; PROVIDER_OFF: no provider/model silent replacement | tracked Codex CLI/IDE host identity, separate checker / NO_EFFECT_UNTIL_ADMISSION; PIPD profile-tailor cannot downgrade safety | POS: profile projection+applicability axis / NEG: PROFILE_SAFETY_VETO_STANDALONE; NO_SIDE_EFFECT_WITHOUT_USER_CONSENT / NOFIT: missing installed host/policy/permission |
| 67282ac08b7e | PROFILE/STANDALONE | Claude Code | ON | DEFERRED_HOST_ADMISSION_HOLD | DEFERRED_HOST_ADMISSION_HOLD, no assumed loader | fresh Claude Code real loader/permission proof / NO_EFFECT_UNTIL_ADMISSION; PIPD profile-tailor cannot downgrade safety | POS: profile projection+applicability axis / NEG: PROFILE_SAFETY_VETO_STANDALONE; NO_SIDE_EFFECT_WITHOUT_USER_CONSENT / NOFIT: missing installed host/policy/permission |
| 77fe98764ab5 | PROFILE/STANDALONE | Claude Code | OFF | DEFERRED_HOST_ADMISSION_HOLD | DEFERRED_HOST_ADMISSION_HOLD, no assumed loader; PROVIDER_OFF: no provider/model silent replacement | fresh Claude Code real loader/permission proof / NO_EFFECT_UNTIL_ADMISSION; PIPD profile-tailor cannot downgrade safety | POS: profile projection+applicability axis / NEG: PROFILE_SAFETY_VETO_STANDALONE; NO_SIDE_EFFECT_WITHOUT_USER_CONSENT / NOFIT: missing installed host/policy/permission |
| 24e9aedd8086 | PROFILE/STANDALONE | DeepSeek Harness | ON | DEFERRED_HOST_ADMISSION_HOLD | DEFERRED_HOST_ADMISSION_HOLD, no assumed loader | API_ONLY=>NO_FIT; actual harness ABI mandatory / NO_EFFECT_UNTIL_ADMISSION; PIPD profile-tailor cannot downgrade safety | POS: profile projection+applicability axis / NEG: PROFILE_SAFETY_VETO_STANDALONE; NO_SIDE_EFFECT_WITHOUT_USER_CONSENT / NOFIT: missing installed host/policy/permission |
| 75540fe3412c | PROFILE/STANDALONE | DeepSeek Harness | OFF | DEFERRED_HOST_ADMISSION_HOLD | DEFERRED_HOST_ADMISSION_HOLD, no assumed loader; PROVIDER_OFF: no provider/model silent replacement | API_ONLY=>NO_FIT; actual harness ABI mandatory / NO_EFFECT_UNTIL_ADMISSION; PIPD profile-tailor cannot downgrade safety | POS: profile projection+applicability axis / NEG: PROFILE_SAFETY_VETO_STANDALONE; NO_SIDE_EFFECT_WITHOUT_USER_CONSENT / NOFIT: missing installed host/policy/permission |
| e3f461767442 | PROFILE/PREW3_SHADOW | Hermes Agent | ON | DEFERRED_HOST_ADMISSION_HOLD | DEFERRED_HOST_ADMISSION_HOLD, no assumed loader | live loader+permission+fresh session / NO_EFFECT_UNTIL_ADMISSION; PIPD profile-tailor cannot downgrade safety | POS: profile projection+applicability axis / NEG: PROFILE_SAFETY_VETO_PREW3_SHADOW; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 491bbc480824 | PROFILE/PREW3_SHADOW | Hermes Agent | OFF | DEFERRED_HOST_ADMISSION_HOLD | DEFERRED_HOST_ADMISSION_HOLD, no assumed loader; PROVIDER_OFF: no provider/model silent replacement | live loader+permission+fresh session / NO_EFFECT_UNTIL_ADMISSION; PIPD profile-tailor cannot downgrade safety | POS: profile projection+applicability axis / NEG: PROFILE_SAFETY_VETO_PREW3_SHADOW; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 24862363699e | PROFILE/PREW3_SHADOW | Codex | ON | DEFERRED_HOST_ADMISSION_HOLD | DEFERRED_HOST_ADMISSION_HOLD, no assumed loader | tracked Codex CLI/IDE host identity, separate checker / NO_EFFECT_UNTIL_ADMISSION; PIPD profile-tailor cannot downgrade safety | POS: profile projection+applicability axis / NEG: PROFILE_SAFETY_VETO_PREW3_SHADOW; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| b41a32121615 | PROFILE/PREW3_SHADOW | Codex | OFF | DEFERRED_HOST_ADMISSION_HOLD | DEFERRED_HOST_ADMISSION_HOLD, no assumed loader; PROVIDER_OFF: no provider/model silent replacement | tracked Codex CLI/IDE host identity, separate checker / NO_EFFECT_UNTIL_ADMISSION; PIPD profile-tailor cannot downgrade safety | POS: profile projection+applicability axis / NEG: PROFILE_SAFETY_VETO_PREW3_SHADOW; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 8605451d5dd2 | PROFILE/PREW3_SHADOW | Claude Code | ON | DEFERRED_HOST_ADMISSION_HOLD | DEFERRED_HOST_ADMISSION_HOLD, no assumed loader | fresh Claude Code real loader/permission proof / NO_EFFECT_UNTIL_ADMISSION; PIPD profile-tailor cannot downgrade safety | POS: profile projection+applicability axis / NEG: PROFILE_SAFETY_VETO_PREW3_SHADOW; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 9ca3d0377ed8 | PROFILE/PREW3_SHADOW | Claude Code | OFF | DEFERRED_HOST_ADMISSION_HOLD | DEFERRED_HOST_ADMISSION_HOLD, no assumed loader; PROVIDER_OFF: no provider/model silent replacement | fresh Claude Code real loader/permission proof / NO_EFFECT_UNTIL_ADMISSION; PIPD profile-tailor cannot downgrade safety | POS: profile projection+applicability axis / NEG: PROFILE_SAFETY_VETO_PREW3_SHADOW; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| dd12df59427a | PROFILE/PREW3_SHADOW | DeepSeek Harness | ON | DEFERRED_HOST_ADMISSION_HOLD | DEFERRED_HOST_ADMISSION_HOLD, no assumed loader | API_ONLY=>NO_FIT; actual harness ABI mandatory / NO_EFFECT_UNTIL_ADMISSION; PIPD profile-tailor cannot downgrade safety | POS: profile projection+applicability axis / NEG: PROFILE_SAFETY_VETO_PREW3_SHADOW; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 5ce6176dde4b | PROFILE/PREW3_SHADOW | DeepSeek Harness | OFF | DEFERRED_HOST_ADMISSION_HOLD | DEFERRED_HOST_ADMISSION_HOLD, no assumed loader; PROVIDER_OFF: no provider/model silent replacement | API_ONLY=>NO_FIT; actual harness ABI mandatory / NO_EFFECT_UNTIL_ADMISSION; PIPD profile-tailor cannot downgrade safety | POS: profile projection+applicability axis / NEG: PROFILE_SAFETY_VETO_PREW3_SHADOW; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 40ec4e4388b4 | PROFILE/SWOF_CONNECTED | Hermes Agent | ON | DEFERRED_HOST_ADMISSION_HOLD | DEFERRED_HOST_ADMISSION_HOLD, no assumed loader | live loader+permission+fresh session / NO_EFFECT_UNTIL_ADMISSION; PIPD profile-tailor cannot downgrade safety | POS: profile projection+applicability axis / NEG: PROFILE_SAFETY_VETO_SWOF_CONNECTED; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 0836e4dc5096 | PROFILE/SWOF_CONNECTED | Hermes Agent | OFF | DEFERRED_HOST_ADMISSION_HOLD | DEFERRED_HOST_ADMISSION_HOLD, no assumed loader; PROVIDER_OFF: no provider/model silent replacement | live loader+permission+fresh session / NO_EFFECT_UNTIL_ADMISSION; PIPD profile-tailor cannot downgrade safety | POS: profile projection+applicability axis / NEG: PROFILE_SAFETY_VETO_SWOF_CONNECTED; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 57abd1af6eca | PROFILE/SWOF_CONNECTED | Codex | ON | DEFERRED_HOST_ADMISSION_HOLD | DEFERRED_HOST_ADMISSION_HOLD, no assumed loader | tracked Codex CLI/IDE host identity, separate checker / NO_EFFECT_UNTIL_ADMISSION; PIPD profile-tailor cannot downgrade safety | POS: profile projection+applicability axis / NEG: PROFILE_SAFETY_VETO_SWOF_CONNECTED; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 9bf92fc1f576 | PROFILE/SWOF_CONNECTED | Codex | OFF | DEFERRED_HOST_ADMISSION_HOLD | DEFERRED_HOST_ADMISSION_HOLD, no assumed loader; PROVIDER_OFF: no provider/model silent replacement | tracked Codex CLI/IDE host identity, separate checker / NO_EFFECT_UNTIL_ADMISSION; PIPD profile-tailor cannot downgrade safety | POS: profile projection+applicability axis / NEG: PROFILE_SAFETY_VETO_SWOF_CONNECTED; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| ac9b0f671ba6 | PROFILE/SWOF_CONNECTED | Claude Code | ON | DEFERRED_HOST_ADMISSION_HOLD | DEFERRED_HOST_ADMISSION_HOLD, no assumed loader | fresh Claude Code real loader/permission proof / NO_EFFECT_UNTIL_ADMISSION; PIPD profile-tailor cannot downgrade safety | POS: profile projection+applicability axis / NEG: PROFILE_SAFETY_VETO_SWOF_CONNECTED; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| c798b8d56448 | PROFILE/SWOF_CONNECTED | Claude Code | OFF | DEFERRED_HOST_ADMISSION_HOLD | DEFERRED_HOST_ADMISSION_HOLD, no assumed loader; PROVIDER_OFF: no provider/model silent replacement | fresh Claude Code real loader/permission proof / NO_EFFECT_UNTIL_ADMISSION; PIPD profile-tailor cannot downgrade safety | POS: profile projection+applicability axis / NEG: PROFILE_SAFETY_VETO_SWOF_CONNECTED; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 44b29464a95a | PROFILE/SWOF_CONNECTED | DeepSeek Harness | ON | DEFERRED_HOST_ADMISSION_HOLD | DEFERRED_HOST_ADMISSION_HOLD, no assumed loader | API_ONLY=>NO_FIT; actual harness ABI mandatory / NO_EFFECT_UNTIL_ADMISSION; PIPD profile-tailor cannot downgrade safety | POS: profile projection+applicability axis / NEG: PROFILE_SAFETY_VETO_SWOF_CONNECTED; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| db54604c0f5b | PROFILE/SWOF_CONNECTED | DeepSeek Harness | OFF | DEFERRED_HOST_ADMISSION_HOLD | DEFERRED_HOST_ADMISSION_HOLD, no assumed loader; PROVIDER_OFF: no provider/model silent replacement | API_ONLY=>NO_FIT; actual harness ABI mandatory / NO_EFFECT_UNTIL_ADMISSION; PIPD profile-tailor cannot downgrade safety | POS: profile projection+applicability axis / NEG: PROFILE_SAFETY_VETO_SWOF_CONNECTED; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| afca55403585 | AGENT_OS/STANDALONE | Hermes Agent | ON | NO_FIT_UNSUPPORTED_V0.1 | NO_FIT_UNSUPPORTED_V0.1, no install | live loader+permission+fresh session / STOP_NO_EFFECT; separate Native OS admission required | POS: Agent OS native lifecycle / NEG: AGENT_OS_UNSUPPORTED_STANDALONE; NO_SIDE_EFFECT_WITHOUT_USER_CONSENT / NOFIT: missing installed host/policy/permission |
| df93f59a1365 | AGENT_OS/STANDALONE | Hermes Agent | OFF | NO_FIT_UNSUPPORTED_V0.1 | NO_FIT_UNSUPPORTED_V0.1, no install; PROVIDER_OFF: no provider/model silent replacement | live loader+permission+fresh session / STOP_NO_EFFECT; separate Native OS admission required | POS: Agent OS native lifecycle / NEG: AGENT_OS_UNSUPPORTED_STANDALONE; NO_SIDE_EFFECT_WITHOUT_USER_CONSENT / NOFIT: missing installed host/policy/permission |
| 6c851f664a31 | AGENT_OS/STANDALONE | Codex | ON | NO_FIT_UNSUPPORTED_V0.1 | NO_FIT_UNSUPPORTED_V0.1, no install | tracked Codex CLI/IDE host identity, separate checker / STOP_NO_EFFECT; separate Native OS admission required | POS: Agent OS native lifecycle / NEG: AGENT_OS_UNSUPPORTED_STANDALONE; NO_SIDE_EFFECT_WITHOUT_USER_CONSENT / NOFIT: missing installed host/policy/permission |
| 0af202afbd93 | AGENT_OS/STANDALONE | Codex | OFF | NO_FIT_UNSUPPORTED_V0.1 | NO_FIT_UNSUPPORTED_V0.1, no install; PROVIDER_OFF: no provider/model silent replacement | tracked Codex CLI/IDE host identity, separate checker / STOP_NO_EFFECT; separate Native OS admission required | POS: Agent OS native lifecycle / NEG: AGENT_OS_UNSUPPORTED_STANDALONE; NO_SIDE_EFFECT_WITHOUT_USER_CONSENT / NOFIT: missing installed host/policy/permission |
| 97fb84872359 | AGENT_OS/STANDALONE | Claude Code | ON | NO_FIT_UNSUPPORTED_V0.1 | NO_FIT_UNSUPPORTED_V0.1, no install | fresh Claude Code real loader/permission proof / STOP_NO_EFFECT; separate Native OS admission required | POS: Agent OS native lifecycle / NEG: AGENT_OS_UNSUPPORTED_STANDALONE; NO_SIDE_EFFECT_WITHOUT_USER_CONSENT / NOFIT: missing installed host/policy/permission |
| c226c99e3199 | AGENT_OS/STANDALONE | Claude Code | OFF | NO_FIT_UNSUPPORTED_V0.1 | NO_FIT_UNSUPPORTED_V0.1, no install; PROVIDER_OFF: no provider/model silent replacement | fresh Claude Code real loader/permission proof / STOP_NO_EFFECT; separate Native OS admission required | POS: Agent OS native lifecycle / NEG: AGENT_OS_UNSUPPORTED_STANDALONE; NO_SIDE_EFFECT_WITHOUT_USER_CONSENT / NOFIT: missing installed host/policy/permission |
| 9e3a12ad436c | AGENT_OS/STANDALONE | DeepSeek Harness | ON | NO_FIT_UNSUPPORTED_V0.1 | NO_FIT_UNSUPPORTED_V0.1, no install | API_ONLY=>NO_FIT; actual harness ABI mandatory / STOP_NO_EFFECT; separate Native OS admission required | POS: Agent OS native lifecycle / NEG: AGENT_OS_UNSUPPORTED_STANDALONE; NO_SIDE_EFFECT_WITHOUT_USER_CONSENT / NOFIT: missing installed host/policy/permission |
| f18950ce731b | AGENT_OS/STANDALONE | DeepSeek Harness | OFF | NO_FIT_UNSUPPORTED_V0.1 | NO_FIT_UNSUPPORTED_V0.1, no install; PROVIDER_OFF: no provider/model silent replacement | API_ONLY=>NO_FIT; actual harness ABI mandatory / STOP_NO_EFFECT; separate Native OS admission required | POS: Agent OS native lifecycle / NEG: AGENT_OS_UNSUPPORTED_STANDALONE; NO_SIDE_EFFECT_WITHOUT_USER_CONSENT / NOFIT: missing installed host/policy/permission |
| 4199689808cf | AGENT_OS/PREW3_SHADOW | Hermes Agent | ON | NO_FIT_UNSUPPORTED_V0.1 | NO_FIT_UNSUPPORTED_V0.1, no install | live loader+permission+fresh session / STOP_NO_EFFECT; separate Native OS admission required | POS: Agent OS native lifecycle / NEG: AGENT_OS_UNSUPPORTED_PREW3_SHADOW; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| b6ed07348d18 | AGENT_OS/PREW3_SHADOW | Hermes Agent | OFF | NO_FIT_UNSUPPORTED_V0.1 | NO_FIT_UNSUPPORTED_V0.1, no install; PROVIDER_OFF: no provider/model silent replacement | live loader+permission+fresh session / STOP_NO_EFFECT; separate Native OS admission required | POS: Agent OS native lifecycle / NEG: AGENT_OS_UNSUPPORTED_PREW3_SHADOW; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| ae25f61ef832 | AGENT_OS/PREW3_SHADOW | Codex | ON | NO_FIT_UNSUPPORTED_V0.1 | NO_FIT_UNSUPPORTED_V0.1, no install | tracked Codex CLI/IDE host identity, separate checker / STOP_NO_EFFECT; separate Native OS admission required | POS: Agent OS native lifecycle / NEG: AGENT_OS_UNSUPPORTED_PREW3_SHADOW; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| ec0547fd0acf | AGENT_OS/PREW3_SHADOW | Codex | OFF | NO_FIT_UNSUPPORTED_V0.1 | NO_FIT_UNSUPPORTED_V0.1, no install; PROVIDER_OFF: no provider/model silent replacement | tracked Codex CLI/IDE host identity, separate checker / STOP_NO_EFFECT; separate Native OS admission required | POS: Agent OS native lifecycle / NEG: AGENT_OS_UNSUPPORTED_PREW3_SHADOW; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 2331ca9034c4 | AGENT_OS/PREW3_SHADOW | Claude Code | ON | NO_FIT_UNSUPPORTED_V0.1 | NO_FIT_UNSUPPORTED_V0.1, no install | fresh Claude Code real loader/permission proof / STOP_NO_EFFECT; separate Native OS admission required | POS: Agent OS native lifecycle / NEG: AGENT_OS_UNSUPPORTED_PREW3_SHADOW; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| c7f9eff2fddd | AGENT_OS/PREW3_SHADOW | Claude Code | OFF | NO_FIT_UNSUPPORTED_V0.1 | NO_FIT_UNSUPPORTED_V0.1, no install; PROVIDER_OFF: no provider/model silent replacement | fresh Claude Code real loader/permission proof / STOP_NO_EFFECT; separate Native OS admission required | POS: Agent OS native lifecycle / NEG: AGENT_OS_UNSUPPORTED_PREW3_SHADOW; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| f93b6704ee69 | AGENT_OS/PREW3_SHADOW | DeepSeek Harness | ON | NO_FIT_UNSUPPORTED_V0.1 | NO_FIT_UNSUPPORTED_V0.1, no install | API_ONLY=>NO_FIT; actual harness ABI mandatory / STOP_NO_EFFECT; separate Native OS admission required | POS: Agent OS native lifecycle / NEG: AGENT_OS_UNSUPPORTED_PREW3_SHADOW; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 91838cb6a697 | AGENT_OS/PREW3_SHADOW | DeepSeek Harness | OFF | NO_FIT_UNSUPPORTED_V0.1 | NO_FIT_UNSUPPORTED_V0.1, no install; PROVIDER_OFF: no provider/model silent replacement | API_ONLY=>NO_FIT; actual harness ABI mandatory / STOP_NO_EFFECT; separate Native OS admission required | POS: Agent OS native lifecycle / NEG: AGENT_OS_UNSUPPORTED_PREW3_SHADOW; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 78e42a13bbff | AGENT_OS/SWOF_CONNECTED | Hermes Agent | ON | NO_FIT_UNSUPPORTED_V0.1 | NO_FIT_UNSUPPORTED_V0.1, no install | live loader+permission+fresh session / STOP_NO_EFFECT; separate Native OS admission required | POS: Agent OS native lifecycle / NEG: AGENT_OS_UNSUPPORTED_SWOF_CONNECTED; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 8c30f1274481 | AGENT_OS/SWOF_CONNECTED | Hermes Agent | OFF | NO_FIT_UNSUPPORTED_V0.1 | NO_FIT_UNSUPPORTED_V0.1, no install; PROVIDER_OFF: no provider/model silent replacement | live loader+permission+fresh session / STOP_NO_EFFECT; separate Native OS admission required | POS: Agent OS native lifecycle / NEG: AGENT_OS_UNSUPPORTED_SWOF_CONNECTED; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 9fdb959e54cd | AGENT_OS/SWOF_CONNECTED | Codex | ON | NO_FIT_UNSUPPORTED_V0.1 | NO_FIT_UNSUPPORTED_V0.1, no install | tracked Codex CLI/IDE host identity, separate checker / STOP_NO_EFFECT; separate Native OS admission required | POS: Agent OS native lifecycle / NEG: AGENT_OS_UNSUPPORTED_SWOF_CONNECTED; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 16b0d6f0aa4b | AGENT_OS/SWOF_CONNECTED | Codex | OFF | NO_FIT_UNSUPPORTED_V0.1 | NO_FIT_UNSUPPORTED_V0.1, no install; PROVIDER_OFF: no provider/model silent replacement | tracked Codex CLI/IDE host identity, separate checker / STOP_NO_EFFECT; separate Native OS admission required | POS: Agent OS native lifecycle / NEG: AGENT_OS_UNSUPPORTED_SWOF_CONNECTED; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 9f3a107b084e | AGENT_OS/SWOF_CONNECTED | Claude Code | ON | NO_FIT_UNSUPPORTED_V0.1 | NO_FIT_UNSUPPORTED_V0.1, no install | fresh Claude Code real loader/permission proof / STOP_NO_EFFECT; separate Native OS admission required | POS: Agent OS native lifecycle / NEG: AGENT_OS_UNSUPPORTED_SWOF_CONNECTED; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 378b78d029ac | AGENT_OS/SWOF_CONNECTED | Claude Code | OFF | NO_FIT_UNSUPPORTED_V0.1 | NO_FIT_UNSUPPORTED_V0.1, no install; PROVIDER_OFF: no provider/model silent replacement | fresh Claude Code real loader/permission proof / STOP_NO_EFFECT; separate Native OS admission required | POS: Agent OS native lifecycle / NEG: AGENT_OS_UNSUPPORTED_SWOF_CONNECTED; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 10cbe7b8ba17 | AGENT_OS/SWOF_CONNECTED | DeepSeek Harness | ON | NO_FIT_UNSUPPORTED_V0.1 | NO_FIT_UNSUPPORTED_V0.1, no install | API_ONLY=>NO_FIT; actual harness ABI mandatory / STOP_NO_EFFECT; separate Native OS admission required | POS: Agent OS native lifecycle / NEG: AGENT_OS_UNSUPPORTED_SWOF_CONNECTED; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 95ae8bfac0e7 | AGENT_OS/SWOF_CONNECTED | DeepSeek Harness | OFF | NO_FIT_UNSUPPORTED_V0.1 | NO_FIT_UNSUPPORTED_V0.1, no install; PROVIDER_OFF: no provider/model silent replacement | API_ONLY=>NO_FIT; actual harness ABI mandatory / STOP_NO_EFFECT; separate Native OS admission required | POS: Agent OS native lifecycle / NEG: AGENT_OS_UNSUPPORTED_SWOF_CONNECTED; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| d0ea4e9314ef | AI_SYSTEM/STANDALONE | Hermes Agent | ON | NO_FIT_UNSUPPORTED_V0.1 | NO_FIT_UNSUPPORTED_V0.1, no install | live loader+permission+fresh session / STOP_NO_EFFECT; separate product/security approval | POS: multi-agent solution deployment / NEG: AI_SYSTEM_UNSUPPORTED_STANDALONE; NO_SIDE_EFFECT_WITHOUT_USER_CONSENT / NOFIT: missing installed host/policy/permission |
| e90fb5ce4fd3 | AI_SYSTEM/STANDALONE | Hermes Agent | OFF | NO_FIT_UNSUPPORTED_V0.1 | NO_FIT_UNSUPPORTED_V0.1, no install; PROVIDER_OFF: no provider/model silent replacement | live loader+permission+fresh session / STOP_NO_EFFECT; separate product/security approval | POS: multi-agent solution deployment / NEG: AI_SYSTEM_UNSUPPORTED_STANDALONE; NO_SIDE_EFFECT_WITHOUT_USER_CONSENT / NOFIT: missing installed host/policy/permission |
| 980e1f8cdbf6 | AI_SYSTEM/STANDALONE | Codex | ON | NO_FIT_UNSUPPORTED_V0.1 | NO_FIT_UNSUPPORTED_V0.1, no install | tracked Codex CLI/IDE host identity, separate checker / STOP_NO_EFFECT; separate product/security approval | POS: multi-agent solution deployment / NEG: AI_SYSTEM_UNSUPPORTED_STANDALONE; NO_SIDE_EFFECT_WITHOUT_USER_CONSENT / NOFIT: missing installed host/policy/permission |
| 80e6856b5e3c | AI_SYSTEM/STANDALONE | Codex | OFF | NO_FIT_UNSUPPORTED_V0.1 | NO_FIT_UNSUPPORTED_V0.1, no install; PROVIDER_OFF: no provider/model silent replacement | tracked Codex CLI/IDE host identity, separate checker / STOP_NO_EFFECT; separate product/security approval | POS: multi-agent solution deployment / NEG: AI_SYSTEM_UNSUPPORTED_STANDALONE; NO_SIDE_EFFECT_WITHOUT_USER_CONSENT / NOFIT: missing installed host/policy/permission |
| ec2d6ac66d18 | AI_SYSTEM/STANDALONE | Claude Code | ON | NO_FIT_UNSUPPORTED_V0.1 | NO_FIT_UNSUPPORTED_V0.1, no install | fresh Claude Code real loader/permission proof / STOP_NO_EFFECT; separate product/security approval | POS: multi-agent solution deployment / NEG: AI_SYSTEM_UNSUPPORTED_STANDALONE; NO_SIDE_EFFECT_WITHOUT_USER_CONSENT / NOFIT: missing installed host/policy/permission |
| 4ed5ad806797 | AI_SYSTEM/STANDALONE | Claude Code | OFF | NO_FIT_UNSUPPORTED_V0.1 | NO_FIT_UNSUPPORTED_V0.1, no install; PROVIDER_OFF: no provider/model silent replacement | fresh Claude Code real loader/permission proof / STOP_NO_EFFECT; separate product/security approval | POS: multi-agent solution deployment / NEG: AI_SYSTEM_UNSUPPORTED_STANDALONE; NO_SIDE_EFFECT_WITHOUT_USER_CONSENT / NOFIT: missing installed host/policy/permission |
| f478ba7d0b9a | AI_SYSTEM/STANDALONE | DeepSeek Harness | ON | NO_FIT_UNSUPPORTED_V0.1 | NO_FIT_UNSUPPORTED_V0.1, no install | API_ONLY=>NO_FIT; actual harness ABI mandatory / STOP_NO_EFFECT; separate product/security approval | POS: multi-agent solution deployment / NEG: AI_SYSTEM_UNSUPPORTED_STANDALONE; NO_SIDE_EFFECT_WITHOUT_USER_CONSENT / NOFIT: missing installed host/policy/permission |
| 057db0593627 | AI_SYSTEM/STANDALONE | DeepSeek Harness | OFF | NO_FIT_UNSUPPORTED_V0.1 | NO_FIT_UNSUPPORTED_V0.1, no install; PROVIDER_OFF: no provider/model silent replacement | API_ONLY=>NO_FIT; actual harness ABI mandatory / STOP_NO_EFFECT; separate product/security approval | POS: multi-agent solution deployment / NEG: AI_SYSTEM_UNSUPPORTED_STANDALONE; NO_SIDE_EFFECT_WITHOUT_USER_CONSENT / NOFIT: missing installed host/policy/permission |
| cb6fcd8de73c | AI_SYSTEM/PREW3_SHADOW | Hermes Agent | ON | NO_FIT_UNSUPPORTED_V0.1 | NO_FIT_UNSUPPORTED_V0.1, no install | live loader+permission+fresh session / STOP_NO_EFFECT; separate product/security approval | POS: multi-agent solution deployment / NEG: AI_SYSTEM_UNSUPPORTED_PREW3_SHADOW; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 41ed105d02da | AI_SYSTEM/PREW3_SHADOW | Hermes Agent | OFF | NO_FIT_UNSUPPORTED_V0.1 | NO_FIT_UNSUPPORTED_V0.1, no install; PROVIDER_OFF: no provider/model silent replacement | live loader+permission+fresh session / STOP_NO_EFFECT; separate product/security approval | POS: multi-agent solution deployment / NEG: AI_SYSTEM_UNSUPPORTED_PREW3_SHADOW; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 836112ec4da9 | AI_SYSTEM/PREW3_SHADOW | Codex | ON | NO_FIT_UNSUPPORTED_V0.1 | NO_FIT_UNSUPPORTED_V0.1, no install | tracked Codex CLI/IDE host identity, separate checker / STOP_NO_EFFECT; separate product/security approval | POS: multi-agent solution deployment / NEG: AI_SYSTEM_UNSUPPORTED_PREW3_SHADOW; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 83cb46793f3b | AI_SYSTEM/PREW3_SHADOW | Codex | OFF | NO_FIT_UNSUPPORTED_V0.1 | NO_FIT_UNSUPPORTED_V0.1, no install; PROVIDER_OFF: no provider/model silent replacement | tracked Codex CLI/IDE host identity, separate checker / STOP_NO_EFFECT; separate product/security approval | POS: multi-agent solution deployment / NEG: AI_SYSTEM_UNSUPPORTED_PREW3_SHADOW; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 39e031d42387 | AI_SYSTEM/PREW3_SHADOW | Claude Code | ON | NO_FIT_UNSUPPORTED_V0.1 | NO_FIT_UNSUPPORTED_V0.1, no install | fresh Claude Code real loader/permission proof / STOP_NO_EFFECT; separate product/security approval | POS: multi-agent solution deployment / NEG: AI_SYSTEM_UNSUPPORTED_PREW3_SHADOW; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| f250e0e5814a | AI_SYSTEM/PREW3_SHADOW | Claude Code | OFF | NO_FIT_UNSUPPORTED_V0.1 | NO_FIT_UNSUPPORTED_V0.1, no install; PROVIDER_OFF: no provider/model silent replacement | fresh Claude Code real loader/permission proof / STOP_NO_EFFECT; separate product/security approval | POS: multi-agent solution deployment / NEG: AI_SYSTEM_UNSUPPORTED_PREW3_SHADOW; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 9742bec81e5a | AI_SYSTEM/PREW3_SHADOW | DeepSeek Harness | ON | NO_FIT_UNSUPPORTED_V0.1 | NO_FIT_UNSUPPORTED_V0.1, no install | API_ONLY=>NO_FIT; actual harness ABI mandatory / STOP_NO_EFFECT; separate product/security approval | POS: multi-agent solution deployment / NEG: AI_SYSTEM_UNSUPPORTED_PREW3_SHADOW; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 237ac6308b3f | AI_SYSTEM/PREW3_SHADOW | DeepSeek Harness | OFF | NO_FIT_UNSUPPORTED_V0.1 | NO_FIT_UNSUPPORTED_V0.1, no install; PROVIDER_OFF: no provider/model silent replacement | API_ONLY=>NO_FIT; actual harness ABI mandatory / STOP_NO_EFFECT; separate product/security approval | POS: multi-agent solution deployment / NEG: AI_SYSTEM_UNSUPPORTED_PREW3_SHADOW; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 762256559527 | AI_SYSTEM/SWOF_CONNECTED | Hermes Agent | ON | NO_FIT_UNSUPPORTED_V0.1 | NO_FIT_UNSUPPORTED_V0.1, no install | live loader+permission+fresh session / STOP_NO_EFFECT; separate product/security approval | POS: multi-agent solution deployment / NEG: AI_SYSTEM_UNSUPPORTED_SWOF_CONNECTED; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 42f5aee6701f | AI_SYSTEM/SWOF_CONNECTED | Hermes Agent | OFF | NO_FIT_UNSUPPORTED_V0.1 | NO_FIT_UNSUPPORTED_V0.1, no install; PROVIDER_OFF: no provider/model silent replacement | live loader+permission+fresh session / STOP_NO_EFFECT; separate product/security approval | POS: multi-agent solution deployment / NEG: AI_SYSTEM_UNSUPPORTED_SWOF_CONNECTED; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 7b1a7a42e067 | AI_SYSTEM/SWOF_CONNECTED | Codex | ON | NO_FIT_UNSUPPORTED_V0.1 | NO_FIT_UNSUPPORTED_V0.1, no install | tracked Codex CLI/IDE host identity, separate checker / STOP_NO_EFFECT; separate product/security approval | POS: multi-agent solution deployment / NEG: AI_SYSTEM_UNSUPPORTED_SWOF_CONNECTED; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| f171ddc0382c | AI_SYSTEM/SWOF_CONNECTED | Codex | OFF | NO_FIT_UNSUPPORTED_V0.1 | NO_FIT_UNSUPPORTED_V0.1, no install; PROVIDER_OFF: no provider/model silent replacement | tracked Codex CLI/IDE host identity, separate checker / STOP_NO_EFFECT; separate product/security approval | POS: multi-agent solution deployment / NEG: AI_SYSTEM_UNSUPPORTED_SWOF_CONNECTED; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| a50d9bf4ec2f | AI_SYSTEM/SWOF_CONNECTED | Claude Code | ON | NO_FIT_UNSUPPORTED_V0.1 | NO_FIT_UNSUPPORTED_V0.1, no install | fresh Claude Code real loader/permission proof / STOP_NO_EFFECT; separate product/security approval | POS: multi-agent solution deployment / NEG: AI_SYSTEM_UNSUPPORTED_SWOF_CONNECTED; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 90274105bfbf | AI_SYSTEM/SWOF_CONNECTED | Claude Code | OFF | NO_FIT_UNSUPPORTED_V0.1 | NO_FIT_UNSUPPORTED_V0.1, no install; PROVIDER_OFF: no provider/model silent replacement | fresh Claude Code real loader/permission proof / STOP_NO_EFFECT; separate product/security approval | POS: multi-agent solution deployment / NEG: AI_SYSTEM_UNSUPPORTED_SWOF_CONNECTED; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| b85f95d3b255 | AI_SYSTEM/SWOF_CONNECTED | DeepSeek Harness | ON | NO_FIT_UNSUPPORTED_V0.1 | NO_FIT_UNSUPPORTED_V0.1, no install | API_ONLY=>NO_FIT; actual harness ABI mandatory / STOP_NO_EFFECT; separate product/security approval | POS: multi-agent solution deployment / NEG: AI_SYSTEM_UNSUPPORTED_SWOF_CONNECTED; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 1746d4d5a88d | AI_SYSTEM/SWOF_CONNECTED | DeepSeek Harness | OFF | NO_FIT_UNSUPPORTED_V0.1 | NO_FIT_UNSUPPORTED_V0.1, no install; PROVIDER_OFF: no provider/model silent replacement | API_ONLY=>NO_FIT; actual harness ABI mandatory / STOP_NO_EFFECT; separate product/security approval | POS: multi-agent solution deployment / NEG: AI_SYSTEM_UNSUPPORTED_SWOF_CONNECTED; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 336e267c9f1b | GENIE/GENIE.md/STANDALONE | Hermes Agent | ON | NATIVE_COMPAT_READ_ONLY | READ_ONLY_NATIVE_COMPAT_REF, SWOF Owner only | live loader+permission+fresh session / READ_ONLY_NO_NATIVE_WRITE; SWOF native owner writes GENIE only | POS: GENIE.md identity/version projection / NEG: GENIE_NAMESPACE_COLLISION_STANDALONE; NO_SIDE_EFFECT_WITHOUT_USER_CONSENT / NOFIT: missing installed host/policy/permission |
| 8f240272c803 | GENIE/GENIE.md/STANDALONE | Hermes Agent | OFF | NATIVE_COMPAT_READ_ONLY | READ_ONLY_NATIVE_COMPAT_REF, SWOF Owner only; PROVIDER_OFF: no provider/model silent replacement | live loader+permission+fresh session / READ_ONLY_NO_NATIVE_WRITE; SWOF native owner writes GENIE only | POS: GENIE.md identity/version projection / NEG: GENIE_NAMESPACE_COLLISION_STANDALONE; NO_SIDE_EFFECT_WITHOUT_USER_CONSENT / NOFIT: missing installed host/policy/permission |
| 5c0c72c957ed | GENIE/GENIE.md/STANDALONE | Codex | ON | NATIVE_COMPAT_READ_ONLY | READ_ONLY_NATIVE_COMPAT_REF, SWOF Owner only | tracked Codex CLI/IDE host identity, separate checker / READ_ONLY_NO_NATIVE_WRITE; SWOF native owner writes GENIE only | POS: GENIE.md identity/version projection / NEG: GENIE_NAMESPACE_COLLISION_STANDALONE; NO_SIDE_EFFECT_WITHOUT_USER_CONSENT / NOFIT: missing installed host/policy/permission |
| d9f0da8c1631 | GENIE/GENIE.md/STANDALONE | Codex | OFF | NATIVE_COMPAT_READ_ONLY | READ_ONLY_NATIVE_COMPAT_REF, SWOF Owner only; PROVIDER_OFF: no provider/model silent replacement | tracked Codex CLI/IDE host identity, separate checker / READ_ONLY_NO_NATIVE_WRITE; SWOF native owner writes GENIE only | POS: GENIE.md identity/version projection / NEG: GENIE_NAMESPACE_COLLISION_STANDALONE; NO_SIDE_EFFECT_WITHOUT_USER_CONSENT / NOFIT: missing installed host/policy/permission |
| 070f95d5c154 | GENIE/GENIE.md/STANDALONE | Claude Code | ON | NATIVE_COMPAT_READ_ONLY | READ_ONLY_NATIVE_COMPAT_REF, SWOF Owner only | fresh Claude Code real loader/permission proof / READ_ONLY_NO_NATIVE_WRITE; SWOF native owner writes GENIE only | POS: GENIE.md identity/version projection / NEG: GENIE_NAMESPACE_COLLISION_STANDALONE; NO_SIDE_EFFECT_WITHOUT_USER_CONSENT / NOFIT: missing installed host/policy/permission |
| 479fa09ec346 | GENIE/GENIE.md/STANDALONE | Claude Code | OFF | NATIVE_COMPAT_READ_ONLY | READ_ONLY_NATIVE_COMPAT_REF, SWOF Owner only; PROVIDER_OFF: no provider/model silent replacement | fresh Claude Code real loader/permission proof / READ_ONLY_NO_NATIVE_WRITE; SWOF native owner writes GENIE only | POS: GENIE.md identity/version projection / NEG: GENIE_NAMESPACE_COLLISION_STANDALONE; NO_SIDE_EFFECT_WITHOUT_USER_CONSENT / NOFIT: missing installed host/policy/permission |
| 9af02fa9e8ed | GENIE/GENIE.md/STANDALONE | DeepSeek Harness | ON | NATIVE_COMPAT_READ_ONLY | READ_ONLY_NATIVE_COMPAT_REF, SWOF Owner only | API_ONLY=>NO_FIT; actual harness ABI mandatory / READ_ONLY_NO_NATIVE_WRITE; SWOF native owner writes GENIE only | POS: GENIE.md identity/version projection / NEG: GENIE_NAMESPACE_COLLISION_STANDALONE; NO_SIDE_EFFECT_WITHOUT_USER_CONSENT / NOFIT: missing installed host/policy/permission |
| c38a7e723977 | GENIE/GENIE.md/STANDALONE | DeepSeek Harness | OFF | NATIVE_COMPAT_READ_ONLY | READ_ONLY_NATIVE_COMPAT_REF, SWOF Owner only; PROVIDER_OFF: no provider/model silent replacement | API_ONLY=>NO_FIT; actual harness ABI mandatory / READ_ONLY_NO_NATIVE_WRITE; SWOF native owner writes GENIE only | POS: GENIE.md identity/version projection / NEG: GENIE_NAMESPACE_COLLISION_STANDALONE; NO_SIDE_EFFECT_WITHOUT_USER_CONSENT / NOFIT: missing installed host/policy/permission |
| 510726a815d2 | GENIE/GENIE.md/PREW3_SHADOW | Hermes Agent | ON | NATIVE_COMPAT_READ_ONLY | READ_ONLY_NATIVE_COMPAT_REF, SWOF Owner only | live loader+permission+fresh session / READ_ONLY_NO_NATIVE_WRITE; SWOF native owner writes GENIE only | POS: GENIE.md identity/version projection / NEG: GENIE_NAMESPACE_COLLISION_PREW3_SHADOW; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| f842f5e447d1 | GENIE/GENIE.md/PREW3_SHADOW | Hermes Agent | OFF | NATIVE_COMPAT_READ_ONLY | READ_ONLY_NATIVE_COMPAT_REF, SWOF Owner only; PROVIDER_OFF: no provider/model silent replacement | live loader+permission+fresh session / READ_ONLY_NO_NATIVE_WRITE; SWOF native owner writes GENIE only | POS: GENIE.md identity/version projection / NEG: GENIE_NAMESPACE_COLLISION_PREW3_SHADOW; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 82305af511e2 | GENIE/GENIE.md/PREW3_SHADOW | Codex | ON | NATIVE_COMPAT_READ_ONLY | READ_ONLY_NATIVE_COMPAT_REF, SWOF Owner only | tracked Codex CLI/IDE host identity, separate checker / READ_ONLY_NO_NATIVE_WRITE; SWOF native owner writes GENIE only | POS: GENIE.md identity/version projection / NEG: GENIE_NAMESPACE_COLLISION_PREW3_SHADOW; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| bf764d5ba2c2 | GENIE/GENIE.md/PREW3_SHADOW | Codex | OFF | NATIVE_COMPAT_READ_ONLY | READ_ONLY_NATIVE_COMPAT_REF, SWOF Owner only; PROVIDER_OFF: no provider/model silent replacement | tracked Codex CLI/IDE host identity, separate checker / READ_ONLY_NO_NATIVE_WRITE; SWOF native owner writes GENIE only | POS: GENIE.md identity/version projection / NEG: GENIE_NAMESPACE_COLLISION_PREW3_SHADOW; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| d69adf2f1965 | GENIE/GENIE.md/PREW3_SHADOW | Claude Code | ON | NATIVE_COMPAT_READ_ONLY | READ_ONLY_NATIVE_COMPAT_REF, SWOF Owner only | fresh Claude Code real loader/permission proof / READ_ONLY_NO_NATIVE_WRITE; SWOF native owner writes GENIE only | POS: GENIE.md identity/version projection / NEG: GENIE_NAMESPACE_COLLISION_PREW3_SHADOW; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 1ef60244801f | GENIE/GENIE.md/PREW3_SHADOW | Claude Code | OFF | NATIVE_COMPAT_READ_ONLY | READ_ONLY_NATIVE_COMPAT_REF, SWOF Owner only; PROVIDER_OFF: no provider/model silent replacement | fresh Claude Code real loader/permission proof / READ_ONLY_NO_NATIVE_WRITE; SWOF native owner writes GENIE only | POS: GENIE.md identity/version projection / NEG: GENIE_NAMESPACE_COLLISION_PREW3_SHADOW; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 98d011df32e5 | GENIE/GENIE.md/PREW3_SHADOW | DeepSeek Harness | ON | NATIVE_COMPAT_READ_ONLY | READ_ONLY_NATIVE_COMPAT_REF, SWOF Owner only | API_ONLY=>NO_FIT; actual harness ABI mandatory / READ_ONLY_NO_NATIVE_WRITE; SWOF native owner writes GENIE only | POS: GENIE.md identity/version projection / NEG: GENIE_NAMESPACE_COLLISION_PREW3_SHADOW; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 880fcebbf48e | GENIE/GENIE.md/PREW3_SHADOW | DeepSeek Harness | OFF | NATIVE_COMPAT_READ_ONLY | READ_ONLY_NATIVE_COMPAT_REF, SWOF Owner only; PROVIDER_OFF: no provider/model silent replacement | API_ONLY=>NO_FIT; actual harness ABI mandatory / READ_ONLY_NO_NATIVE_WRITE; SWOF native owner writes GENIE only | POS: GENIE.md identity/version projection / NEG: GENIE_NAMESPACE_COLLISION_PREW3_SHADOW; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| a8a335dada5e | GENIE/GENIE.md/SWOF_CONNECTED | Hermes Agent | ON | NATIVE_COMPAT_READ_ONLY | READ_ONLY_NATIVE_COMPAT_REF, SWOF Owner only | live loader+permission+fresh session / READ_ONLY_NO_NATIVE_WRITE; SWOF native owner writes GENIE only | POS: GENIE.md identity/version projection / NEG: GENIE_NAMESPACE_COLLISION_SWOF_CONNECTED; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| f9d246f739b8 | GENIE/GENIE.md/SWOF_CONNECTED | Hermes Agent | OFF | NATIVE_COMPAT_READ_ONLY | READ_ONLY_NATIVE_COMPAT_REF, SWOF Owner only; PROVIDER_OFF: no provider/model silent replacement | live loader+permission+fresh session / READ_ONLY_NO_NATIVE_WRITE; SWOF native owner writes GENIE only | POS: GENIE.md identity/version projection / NEG: GENIE_NAMESPACE_COLLISION_SWOF_CONNECTED; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 8ed9eebf58e7 | GENIE/GENIE.md/SWOF_CONNECTED | Codex | ON | NATIVE_COMPAT_READ_ONLY | READ_ONLY_NATIVE_COMPAT_REF, SWOF Owner only | tracked Codex CLI/IDE host identity, separate checker / READ_ONLY_NO_NATIVE_WRITE; SWOF native owner writes GENIE only | POS: GENIE.md identity/version projection / NEG: GENIE_NAMESPACE_COLLISION_SWOF_CONNECTED; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| b6fc7bd2585b | GENIE/GENIE.md/SWOF_CONNECTED | Codex | OFF | NATIVE_COMPAT_READ_ONLY | READ_ONLY_NATIVE_COMPAT_REF, SWOF Owner only; PROVIDER_OFF: no provider/model silent replacement | tracked Codex CLI/IDE host identity, separate checker / READ_ONLY_NO_NATIVE_WRITE; SWOF native owner writes GENIE only | POS: GENIE.md identity/version projection / NEG: GENIE_NAMESPACE_COLLISION_SWOF_CONNECTED; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| ea0c6cc43029 | GENIE/GENIE.md/SWOF_CONNECTED | Claude Code | ON | NATIVE_COMPAT_READ_ONLY | READ_ONLY_NATIVE_COMPAT_REF, SWOF Owner only | fresh Claude Code real loader/permission proof / READ_ONLY_NO_NATIVE_WRITE; SWOF native owner writes GENIE only | POS: GENIE.md identity/version projection / NEG: GENIE_NAMESPACE_COLLISION_SWOF_CONNECTED; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 425204fe1c0f | GENIE/GENIE.md/SWOF_CONNECTED | Claude Code | OFF | NATIVE_COMPAT_READ_ONLY | READ_ONLY_NATIVE_COMPAT_REF, SWOF Owner only; PROVIDER_OFF: no provider/model silent replacement | fresh Claude Code real loader/permission proof / READ_ONLY_NO_NATIVE_WRITE; SWOF native owner writes GENIE only | POS: GENIE.md identity/version projection / NEG: GENIE_NAMESPACE_COLLISION_SWOF_CONNECTED; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| fc762041aa9d | GENIE/GENIE.md/SWOF_CONNECTED | DeepSeek Harness | ON | NATIVE_COMPAT_READ_ONLY | READ_ONLY_NATIVE_COMPAT_REF, SWOF Owner only | API_ONLY=>NO_FIT; actual harness ABI mandatory / READ_ONLY_NO_NATIVE_WRITE; SWOF native owner writes GENIE only | POS: GENIE.md identity/version projection / NEG: GENIE_NAMESPACE_COLLISION_SWOF_CONNECTED; NO_EFFECT / NOFIT: missing installed host/policy/permission |
| 5370fdd74e46 | GENIE/GENIE.md/SWOF_CONNECTED | DeepSeek Harness | OFF | NATIVE_COMPAT_READ_ONLY | READ_ONLY_NATIVE_COMPAT_REF, SWOF Owner only; PROVIDER_OFF: no provider/model silent replacement | API_ONLY=>NO_FIT; actual harness ABI mandatory / READ_ONLY_NO_NATIVE_WRITE; SWOF native owner writes GENIE only | POS: GENIE.md identity/version projection / NEG: GENIE_NAMESPACE_COLLISION_SWOF_CONNECTED; NO_EFFECT / NOFIT: missing installed host/policy/permission |

## 2. 五個工具 + 三個 SP + 六模組的各自可用性

| 工具 | 真入口 | 新增/變更 effect | 產品正例 | 產品負例與退裝 |
|---|---|---|---|---|
| TPM-SP | `goal.open` Host private plugin/skill invoke | goal/spec *candidate* | separate Host-issued TPM invocation + guided question ledger | ZIP copy ≠ Host load；wrong trigger deny；uninstall residue |
| Commander-SP | `plan.propose` existing SBL controller | proposes WO/ECP, never Native issue | authenticated plan→HGK real ACK→readback | user prompt self-issues token→DENY |
| External Challenge-SP | `challenge.evaluate` distinct principal | read-only independent verdict | same candidate RAW checker with distinct identity | Maker checking Maker or missing receipt→HOLD |
| HGK Harness Adapter | `sbl-harness` probe/install/doctor/uninstall | Host-bound only after native issuer | binary/actual host and native permission readback | HOST_PENDING ≠ granted; rollback/uninstall |
| Full SBL Stack | `sbl-stack install/doctor/selftest/status/uninstall` | standalone data root after user consent | CLI status+actual user behavior+reverse uninstall | W2/SWOF native write without token→DENY |
六模組 M1..M6 雙 taxonomy 以正文 00 為主；三 SP 各自有獨立 Host ID 和權限，不把三個 skill 文本當三個安裝。

**三 SP 候選發行檔（非聲稱 Host 已安裝）**：`sbl-tpm-sp.zip`（TPM-SP）、`sbl-commander-sp.zip`（Commander-SP）、`sbl-external-challenge-sp.zip`（External Challenge-SP）；每件另需 Install ID/Host Loaded SHA/真 Invocation/Negative Nontrigger/Uninstall；`sbl-harness` 與 `sbl-stack` 分別要獨立 parser/doctor/Host receipt。四個 DOC-12 canonical Host 為 Hermes Agent、Codex、Claude Code、DeepSeek Harness；ChatGPT Web 私人 Plugin 為額外的 Host UAT Gate，不得偷佔原四 Host 分母。

## 3. R15.1 949 原 ID 全量高保留台帳（66 Required／254 Conditional／629 Deferred）

**本台帳不重複 r2 虛構「清理每筆 state」**。每一筆的 source original 意義與 owner、負例均保留；依 Family 的 *actual need/read/effect classification* 決定下一步：Required 產生實際 B1 consumer/operation 條件，Conditional 逐項 owner/license/host trigger，Deferred 只保留獨立 acceptance 與 re-entry，不假裝已安裝而須卸載。

### 3.1 十八 Family 真判準

| family | 正確候選入口／使用者結果 | 拒收／退場與分母 |
|---|---|---|
| `AUDIT_FINDING` (48) | finding→owner defect cone→red repro→fix/recheck | 未關閉 finding 只繼承，不虛構 cleanup |
| `CHECKRUN` (25) | actual runner invocation→exit/stdout/stderr/subject | missing runtime receipt NOT_RUN |
| `CHILD` (149) | child WO dependency→own effect receipt→join | sibling receipt cannot pass child |
| `CONTRACT` (19) | PIPD registry $id/input/output native validation | schema field missing⇒reject; no false PIPD ID |
| `DELIVERY_SURFACE` (38) | Host install/doctor/loader/invoke/uninstall scoped | copy-only != loaded; deferred no uninstall |
| `DONOR_SLOT` (24) | SearchBeforeBuild→licence/pin/gap→admit or NO_FIT | no automatic donor import |
| `KIND` (8) | Kind eligibility and user product outcome | unsupported != N/A |
| `KIND_MODE` (24) | Mode gate permission+typed no-effect/response | W2 write and SWOF no token DENY |
| `METHOD` (25) | selected route/host installed/policy epoch/true method invocation | Mandatory overrides conditional R15 label |
| `MODE_GATE` (39) | exact same Host mode, issuer, effect classification | unknown effect always deny |
| `PARENT` (50) | parent-child trace, unique subject and evidence | parent PASS cannot imply child PASS |
| `PIPD_CLI` (13) | exact 13 verbs with strict flags and native CLI result | no imaginary 14th verb |
| `PRODUCT_TOOL` (5) | separate product function, install/invoke/deny/uninstall | one tool cannot certify five |
| `R14_CHECK` (31) | historical check id→current requalification after version drift | old green receipt != current host |
| `R14_TASK` (31) | historical task→fresh owner scope/WorkOrder if affected | no automatic replay |
| `TECH_ID` (386) | candidate technical alternative with Need, license, pin, ABI, rollback | no parallel issuer/compiler or auto install |
| `USER_MOMENT` (16) | user action→separate observable effect+negative | no proxy by container/file counts |
| `WP` (18) | work package owner→tracked DoD/NoFit/rollback | not a signed WorkOrder |

### 3.2 每筆 Required／Conditional／Deferred 的個別來源與可採用合約

#### R15-003｜KIND:CLI_TOOL — clean-room binary/script/wheel, entrypoint, help, JSON, nonzero errors, uninstall

- **來源身份**：`R15.1:L105`；owner：`SBL Product Owner`；effect family：`PRODUCT_CONTRACT_READ_ONLY`；disposition：`B1_REQUIRED`。
- **受影必備功能**：`Kind eligibility and user product outcome`；先以 `clean-room binary/script/wheel, entrypoint, help, JSON, nonzero errors, uninstall` 的原 domain 輸入形成 `SourceBoundCandidate`，查真 Host/Repo/Owner；適用於 B1 的精確 operation 以該 family 的 native endpoint 載入後方可執行。
- **拒收**：原負例 `README-only, no executable/undocumented exit` 與 `unsupported != N/A`；缺生效 ABI/Token/Issuer/HostReadback 一律 `HOLD_B1_REQUIRED`，不能因 row 存在 PASS。
- **可反證結果**：只能用此 `id=R15-003` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-004｜KIND:AGENT_SKILL — SKILL.md, reference, allowed host adapter, trigger/nontrigger/unload

- **來源身份**：`R15.1:L106`；owner：`Host Owner+SBL Product`；effect family：`PRODUCT_CONTRACT_READ_ONLY`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「SKILL.md, reference, allowed host adapter, trigger/nontrigger/unload」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`copy-only or false trigger`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-004` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-005｜KIND:SIMPLE_AGENT — bounded config, tool allowlist, timeout, attributable receipts, stop

- **來源身份**：`R15.1:L107`；owner：`SBL Product+Native Effect Owner`；effect family：`PRODUCT_CONTRACT_READ_ONLY`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「bounded config, tool allowlist, timeout, attributable receipts, stop」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`uncapped autonomous loop/privilege creep`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-005` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-006｜KIND:PLUGIN — manifest draft, publisher/version/license/permissions/readback

- **來源身份**：`R15.1:L108`；owner：`DOC-06/10 Host Owner`；effect family：`PRODUCT_CONTRACT_READ_ONLY`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「manifest draft, publisher/version/license/permissions/readback」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`assume installer available from spec`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-006` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-007｜KIND:PROFILE — typed profile candidate, ProfileBinding, scoped effective load

- **來源身份**：`R15.1:L109`；owner：`PIPD Profile+Host Owner`；effect family：`PRODUCT_CONTRACT_READ_ONLY`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「typed profile candidate, ProfileBinding, scoped effective load」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`role card minted as Principal`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-007` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-008｜KIND:AGENT_OS — read-only interoperability idea; no runnable OS

- **來源身份**：`R15.1:L110`；owner：`SBL Product Owner`；effect family：`PRODUCT_CONTRACT_READ_ONLY`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「read-only interoperability idea; no runnable OS」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`show multi-skill graph as OS`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-008` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-009｜KIND:AI_SYSTEM — research/planning input only; no complete system

- **來源身份**：`R15.1:L111`；owner：`SBL Product Owner`；effect family：`PRODUCT_CONTRACT_READ_ONLY`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「research/planning input only; no complete system」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`promise system production`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-009` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-010｜KIND:GENIE/GENIE.md — native versioned read refs, no native generation

- **來源身份**：`R15.1:L112`；owner：`SWOF Product/Native Owner`；effect family：`PRODUCT_CONTRACT_READ_ONLY`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「native versioned read refs, no native generation」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`SBL published native GENIE`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-010` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-011｜KIND_MODE:CLI_TOOL × STANDALONE — python -m build → wheel + console script

- **來源身份**：`R15.1:L120`；owner：`NO_HOST_REQUIRED`；effect family：`MODE_ROUTE_DECISION`；disposition：`B1_REQUIRED`。
- **受影必備功能**：`Mode gate permission+typed no-effect/response`；先以 `python -m build → wheel + console script` 的原 domain 輸入形成 `SourceBoundCandidate`，查真 Host/Repo/Owner；適用於 B1 的精確 operation 以該 family 的 native endpoint 載入後方可執行。
- **拒收**：原負例 `CLI_NO_ENTRYPOINT_STANDALONE; NO_SIDE_EFFECT_WITHOUT_USER_CONSENT` 與 `W2 write and SWOF no token DENY`；缺生效 ABI/Token/Issuer/HostReadback 一律 `HOLD_B1_REQUIRED`，不能因 row 存在 PASS。
- **可反證結果**：只能用此 `id=R15-011` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-012｜KIND_MODE:CLI_TOOL × PREW3_SHADOW — python -m build → wheel + console script

- **來源身份**：`R15.1:L121`；owner：`NO_HOST_REQUIRED`；effect family：`MODE_ROUTE_DECISION`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「python -m build → wheel + console script」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`CLI_NO_ENTRYPOINT_PREW3_SHADOW; NO_EFFECT`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-012` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-013｜KIND_MODE:CLI_TOOL × SWOF_CONNECTED — python -m build → wheel + console script

- **來源身份**：`R15.1:L122`；owner：`NO_HOST_REQUIRED`；effect family：`MODE_ROUTE_DECISION`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「python -m build → wheel + console script」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`CLI_NO_ENTRYPOINT_SWOF_CONNECTED; NO_EFFECT`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-013` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-014｜KIND_MODE:AGENT_SKILL × STANDALONE — SKILL.md+references+manifest

- **來源身份**：`R15.1:L123`；owner：`HOST_SPECIFIC_PROBE_REQUIRED`；effect family：`MODE_ROUTE_DECISION`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「SKILL.md+references+manifest」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`SKILL_NOT_DISCOVERED_STANDALONE; NO_SIDE_EFFECT_WITHOUT_USER_CONSENT`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-014` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-015｜KIND_MODE:AGENT_SKILL × PREW3_SHADOW — SKILL.md+references+manifest

- **來源身份**：`R15.1:L124`；owner：`HOST_SPECIFIC_PROBE_REQUIRED`；effect family：`MODE_ROUTE_DECISION`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「SKILL.md+references+manifest」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`SKILL_NOT_DISCOVERED_PREW3_SHADOW; NO_EFFECT`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-015` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-016｜KIND_MODE:AGENT_SKILL × SWOF_CONNECTED — SKILL.md+references+manifest

- **來源身份**：`R15.1:L125`；owner：`HOST_SPECIFIC_PROBE_REQUIRED`；effect family：`MODE_ROUTE_DECISION`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「SKILL.md+references+manifest」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`SKILL_NOT_DISCOVERED_SWOF_CONNECTED; NO_EFFECT`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-016` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-017｜KIND_MODE:SIMPLE_AGENT × STANDALONE — agent manifest + stop policy + loop budget

- **來源身份**：`R15.1:L126`；owner：`HOST_SPECIFIC_PROBE_REQUIRED`；effect family：`MODE_ROUTE_DECISION`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「agent manifest + stop policy + loop budget」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`AGENT_UNBOUNDED_STANDALONE; NO_SIDE_EFFECT_WITHOUT_USER_CONSENT`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-017` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-018｜KIND_MODE:SIMPLE_AGENT × PREW3_SHADOW — agent manifest + stop policy + loop budget

- **來源身份**：`R15.1:L127`；owner：`HOST_SPECIFIC_PROBE_REQUIRED`；effect family：`MODE_ROUTE_DECISION`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「agent manifest + stop policy + loop budget」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`AGENT_UNBOUNDED_PREW3_SHADOW; NO_EFFECT`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-018` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-019｜KIND_MODE:SIMPLE_AGENT × SWOF_CONNECTED — agent manifest + stop policy + loop budget

- **來源身份**：`R15.1:L128`；owner：`HOST_SPECIFIC_PROBE_REQUIRED`；effect family：`MODE_ROUTE_DECISION`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「agent manifest + stop policy + loop budget」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`AGENT_UNBOUNDED_SWOF_CONNECTED; NO_EFFECT`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-019` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-020｜KIND_MODE:PLUGIN × STANDALONE — plugin manifest + signed/allowlisted host bundle

- **來源身份**：`R15.1:L129`；owner：`HOST_SPECIFIC_PROBE_REQUIRED`；effect family：`MODE_ROUTE_DECISION`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「plugin manifest + signed/allowlisted host bundle」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`PLUGIN_HOST_UNQUALIFIED_STANDALONE; NO_SIDE_EFFECT_WITHOUT_USER_CONSENT`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-020` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-021｜KIND_MODE:PLUGIN × PREW3_SHADOW — plugin manifest + signed/allowlisted host bundle

- **來源身份**：`R15.1:L130`；owner：`HOST_SPECIFIC_PROBE_REQUIRED`；effect family：`MODE_ROUTE_DECISION`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「plugin manifest + signed/allowlisted host bundle」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`PLUGIN_HOST_UNQUALIFIED_PREW3_SHADOW; NO_EFFECT`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-021` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-022｜KIND_MODE:PLUGIN × SWOF_CONNECTED — plugin manifest + signed/allowlisted host bundle

- **來源身份**：`R15.1:L131`；owner：`HOST_SPECIFIC_PROBE_REQUIRED`；effect family：`MODE_ROUTE_DECISION`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「plugin manifest + signed/allowlisted host bundle」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`PLUGIN_HOST_UNQUALIFIED_SWOF_CONNECTED; NO_EFFECT`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-022` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-023｜KIND_MODE:PROFILE × STANDALONE — profile projection+applicability axis

- **來源身份**：`R15.1:L132`；owner：`HOST_OPTIONAL_OR_NO_FIT`；effect family：`MODE_ROUTE_DECISION`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「profile projection+applicability axis」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`PROFILE_SAFETY_VETO_STANDALONE; NO_SIDE_EFFECT_WITHOUT_USER_CONSENT`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-023` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-024｜KIND_MODE:PROFILE × PREW3_SHADOW — profile projection+applicability axis

- **來源身份**：`R15.1:L133`；owner：`HOST_OPTIONAL_OR_NO_FIT`；effect family：`MODE_ROUTE_DECISION`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「profile projection+applicability axis」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`PROFILE_SAFETY_VETO_PREW3_SHADOW; NO_EFFECT`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-024` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-025｜KIND_MODE:PROFILE × SWOF_CONNECTED — profile projection+applicability axis

- **來源身份**：`R15.1:L134`；owner：`HOST_OPTIONAL_OR_NO_FIT`；effect family：`MODE_ROUTE_DECISION`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「profile projection+applicability axis」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`PROFILE_SAFETY_VETO_SWOF_CONNECTED; NO_EFFECT`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-025` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-026｜KIND_MODE:AGENT_OS × STANDALONE — Agent OS native lifecycle

- **來源身份**：`R15.1:L135`；owner：`HOST_OPTIONAL_OR_NO_FIT`；effect family：`MODE_ROUTE_DECISION`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Agent OS native lifecycle」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`AGENT_OS_UNSUPPORTED_STANDALONE; NO_SIDE_EFFECT_WITHOUT_USER_CONSENT`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-026` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-027｜KIND_MODE:AGENT_OS × PREW3_SHADOW — Agent OS native lifecycle

- **來源身份**：`R15.1:L136`；owner：`HOST_OPTIONAL_OR_NO_FIT`；effect family：`MODE_ROUTE_DECISION`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Agent OS native lifecycle」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`AGENT_OS_UNSUPPORTED_PREW3_SHADOW; NO_EFFECT`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-027` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-028｜KIND_MODE:AGENT_OS × SWOF_CONNECTED — Agent OS native lifecycle

- **來源身份**：`R15.1:L137`；owner：`HOST_OPTIONAL_OR_NO_FIT`；effect family：`MODE_ROUTE_DECISION`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Agent OS native lifecycle」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`AGENT_OS_UNSUPPORTED_SWOF_CONNECTED; NO_EFFECT`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-028` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-029｜KIND_MODE:AI_SYSTEM × STANDALONE — multi-agent solution deployment

- **來源身份**：`R15.1:L138`；owner：`HOST_OPTIONAL_OR_NO_FIT`；effect family：`MODE_ROUTE_DECISION`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「multi-agent solution deployment」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`AI_SYSTEM_UNSUPPORTED_STANDALONE; NO_SIDE_EFFECT_WITHOUT_USER_CONSENT`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-029` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-030｜KIND_MODE:AI_SYSTEM × PREW3_SHADOW — multi-agent solution deployment

- **來源身份**：`R15.1:L139`；owner：`HOST_OPTIONAL_OR_NO_FIT`；effect family：`MODE_ROUTE_DECISION`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「multi-agent solution deployment」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`AI_SYSTEM_UNSUPPORTED_PREW3_SHADOW; NO_EFFECT`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-030` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-031｜KIND_MODE:AI_SYSTEM × SWOF_CONNECTED — multi-agent solution deployment

- **來源身份**：`R15.1:L140`；owner：`HOST_OPTIONAL_OR_NO_FIT`；effect family：`MODE_ROUTE_DECISION`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「multi-agent solution deployment」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`AI_SYSTEM_UNSUPPORTED_SWOF_CONNECTED; NO_EFFECT`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-031` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-032｜KIND_MODE:GENIE/GENIE.md × STANDALONE — GENIE.md identity/version projection

- **來源身份**：`R15.1:L141`；owner：`NO_HOST_INSTALL`；effect family：`MODE_ROUTE_DECISION`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「GENIE.md identity/version projection」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`GENIE_NAMESPACE_COLLISION_STANDALONE; NO_SIDE_EFFECT_WITHOUT_USER_CONSENT`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-032` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-033｜KIND_MODE:GENIE/GENIE.md × PREW3_SHADOW — GENIE.md identity/version projection

- **來源身份**：`R15.1:L142`；owner：`NO_HOST_INSTALL`；effect family：`MODE_ROUTE_DECISION`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「GENIE.md identity/version projection」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`GENIE_NAMESPACE_COLLISION_PREW3_SHADOW; NO_EFFECT`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-033` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-034｜KIND_MODE:GENIE/GENIE.md × SWOF_CONNECTED — GENIE.md identity/version projection

- **來源身份**：`R15.1:L143`；owner：`NO_HOST_INSTALL`；effect family：`MODE_ROUTE_DECISION`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「GENIE.md identity/version projection」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`GENIE_NAMESPACE_COLLISION_SWOF_CONNECTED; NO_EFFECT`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-034` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-035｜WP:W00 — Freeze current source SHA/dirty/untracked; verify R14 R13 and upstream original owner

- **來源身份**：`R15.1:L275`；owner：`PIPD Source Owner+HGK Repo Owner`；effect family：`DEV_OR_OPS_PER_WO_EFFECT`；disposition：`B1_REQUIRED`。
- **受影必備功能**：`work package owner→tracked DoD/NoFit/rollback`；先以 `Freeze current source SHA/dirty/untracked; verify R14 R13 and upstream original owner` 的原 domain 輸入形成 `SourceBoundCandidate`，查真 Host/Repo/Owner；適用於 B1 的精確 operation 以該 family 的 native endpoint 載入後方可執行。
- **拒收**：原負例 `foreign branch/untracked collisions→SOURCE_INCONSISTENCY` 與 `not a signed WorkOrder`；缺生效 ABI/Token/Issuer/HostReadback 一律 `HOLD_B1_REQUIRED`，不能因 row 存在 PASS。
- **可反證結果**：只能用此 `id=R15-035` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-036｜WP:W01 — Close native conformance 18 reds, issuer/lease/nonce/replay/expiry/dirty blocking

- **來源身份**：`R15.1:L276`；owner：`HGK Native Owner`；effect family：`DEV_OR_OPS_PER_WO_EFFECT`；disposition：`B1_REQUIRED`。
- **受影必備功能**：`work package owner→tracked DoD/NoFit/rollback`；先以 `Close native conformance 18 reds, issuer/lease/nonce/replay/expiry/dirty blocking` 的原 domain 輸入形成 `SourceBoundCandidate`，查真 Host/Repo/Owner；適用於 B1 的精確 operation 以該 family 的 native endpoint 載入後方可執行。
- **拒收**：原負例 `stale schema/revoked lease→DENY` 與 `not a signed WorkOrder`；缺生效 ABI/Token/Issuer/HostReadback 一律 `HOLD_B1_REQUIRED`，不能因 row 存在 PASS。
- **可反證結果**：只能用此 `id=R15-036` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-037｜WP:W02 — Policy selection→HGK APL→WO→Permitted effect→EffectObserver six-edge

- **來源身份**：`R15.1:L277`；owner：`Fabric RP002 Policy Owner+HGK APL`；effect family：`DEV_OR_OPS_PER_WO_EFFECT`；disposition：`B1_REQUIRED`。
- **受影必備功能**：`work package owner→tracked DoD/NoFit/rollback`；先以 `Policy selection→HGK APL→WO→Permitted effect→EffectObserver six-edge` 的原 domain 輸入形成 `SourceBoundCandidate`，查真 Host/Repo/Owner；適用於 B1 的精確 operation 以該 family 的 native endpoint 載入後方可執行。
- **拒收**：原負例 `Stage-1 frozen misread as active→POLICY_NOT_ACTIVE` 與 `not a signed WorkOrder`；缺生效 ABI/Token/Issuer/HostReadback 一律 `HOLD_B1_REQUIRED`，不能因 row 存在 PASS。
- **可反證結果**：只能用此 `id=R15-037` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-038｜WP:W03 — True PLAN prehandoff Commander invocation, bounded plan & WO candidate

- **來源身份**：`R15.1:L278`；owner：`Commander Host+HGK PLAN`；effect family：`DEV_OR_OPS_PER_WO_EFFECT`；disposition：`B1_REQUIRED`。
- **受影必備功能**：`work package owner→tracked DoD/NoFit/rollback`；先以 `True PLAN prehandoff Commander invocation, bounded plan & WO candidate` 的原 domain 輸入形成 `SourceBoundCandidate`，查真 Host/Repo/Owner；適用於 B1 的精確 operation 以該 family 的 native endpoint 載入後方可執行。
- **拒收**：原負例 `model ping/served only→SP_NOT_INVOKED` 與 `not a signed WorkOrder`；缺生效 ABI/Token/Issuer/HostReadback 一律 `HOLD_B1_REQUIRED`，不能因 row 存在 PASS。
- **可反證結果**：只能用此 `id=R15-038` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-039｜WP:W04 — VERIFY_SECURITY actual external challenge+Raw dynamic check

- **來源身份**：`R15.1:L279`；owner：`External Challenge+Codex CLI AO`；effect family：`DEV_OR_OPS_PER_WO_EFFECT`；disposition：`B1_REQUIRED`。
- **受影必備功能**：`work package owner→tracked DoD/NoFit/rollback`；先以 `VERIFY_SECURITY actual external challenge+Raw dynamic check` 的原 domain 輸入形成 `SourceBoundCandidate`，查真 Host/Repo/Owner；適用於 B1 的精確 operation 以該 family 的 native endpoint 載入後方可執行。
- **拒收**：原負例 `self-accept/proxy raw/unknown oracle→FAIL_INDEPENDENCE` 與 `not a signed WorkOrder`；缺生效 ABI/Token/Issuer/HostReadback 一律 `HOLD_B1_REQUIRED`，不能因 row 存在 PASS。
- **可反證結果**：只能用此 `id=R15-039` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-040｜WP:W05 — Natural-language intake→PIPD 19 schema trace+G-KNOW source anchors

- **來源身份**：`R15.1:L280`；owner：`PIPD Compiler/TPM/G-KNOW`；effect family：`DEV_OR_OPS_PER_WO_EFFECT`；disposition：`B1_REQUIRED`。
- **受影必備功能**：`work package owner→tracked DoD/NoFit/rollback`；先以 `Natural-language intake→PIPD 19 schema trace+G-KNOW source anchors` 的原 domain 輸入形成 `SourceBoundCandidate`，查真 Host/Repo/Owner；適用於 B1 的精確 operation 以該 family 的 native endpoint 載入後方可執行。
- **拒收**：原負例 `empty atom/unknown source/poison→BLOCK` 與 `not a signed WorkOrder`；缺生效 ABI/Token/Issuer/HostReadback 一律 `HOLD_B1_REQUIRED`，不能因 row 存在 PASS。
- **可反證結果**：只能用此 `id=R15-040` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-041｜WP:W06 — 8 Kind selector + 24 mode cells; actually build first three types

- **來源身份**：`R15.1:L281`；owner：`SBL Product+Host owners`；effect family：`DEV_OR_OPS_PER_WO_EFFECT`；disposition：`B1_REQUIRED`。
- **受影必備功能**：`work package owner→tracked DoD/NoFit/rollback`；先以 `8 Kind selector + 24 mode cells; actually build first three types` 的原 domain 輸入形成 `SourceBoundCandidate`，查真 Host/Repo/Owner；適用於 B1 的精確 operation 以該 family 的 native endpoint 載入後方可執行。
- **拒收**：原負例 `AGENT_OS silently runnable/deferred install→FAIL_KIND` 與 `not a signed WorkOrder`；缺生效 ABI/Token/Issuer/HostReadback 一律 `HOLD_B1_REQUIRED`，不能因 row 存在 PASS。
- **可反證結果**：只能用此 `id=R15-041` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-042｜WP:W07 — Detect first fail→repair minimal diff→red/green→full regression

- **來源身份**：`R15.1:L282`；owner：`SBL M6 Repair+HGK Effect Owner`；effect family：`DEV_OR_OPS_PER_WO_EFFECT`；disposition：`B1_REQUIRED`。
- **受影必備功能**：`work package owner→tracked DoD/NoFit/rollback`；先以 `Detect first fail→repair minimal diff→red/green→full regression` 的原 domain 輸入形成 `SourceBoundCandidate`，查真 Host/Repo/Owner；適用於 B1 的精確 operation 以該 family 的 native endpoint 載入後方可執行。
- **拒收**：原負例 `oracle edited to green/foreign paths→DENY` 與 `not a signed WorkOrder`；缺生效 ABI/Token/Issuer/HostReadback 一律 `HOLD_B1_REQUIRED`，不能因 row 存在 PASS。
- **可反證結果**：只能用此 `id=R15-042` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-043｜WP:W08 — Cross-plane required/served rank, epoch/digest coherence

- **來源身份**：`R15.1:L283`；owner：`HGK Model Pool Owner`；effect family：`DEV_OR_OPS_PER_WO_EFFECT`；disposition：`B1_REQUIRED`。
- **受影必備功能**：`work package owner→tracked DoD/NoFit/rollback`；先以 `Cross-plane required/served rank, epoch/digest coherence` 的原 domain 輸入形成 `SourceBoundCandidate`，查真 Host/Repo/Owner；適用於 B1 的精確 operation 以該 family 的 native endpoint 載入後方可執行。
- **拒收**：原負例 `single-plane stale pinned green→FAIL_COHERENCE` 與 `not a signed WorkOrder`；缺生效 ABI/Token/Issuer/HostReadback 一律 `HOLD_B1_REQUIRED`，不能因 row 存在 PASS。
- **可反證結果**：只能用此 `id=R15-043` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-044｜WP:W09 — Real claims, lease, heartbeat, cancel, raw fan-in

- **來源身份**：`R15.1:L284`；owner：`Hermes Kanban/Swarm Controller`；effect family：`DEV_OR_OPS_PER_WO_EFFECT`；disposition：`B1_REQUIRED`。
- **受影必備功能**：`work package owner→tracked DoD/NoFit/rollback`；先以 `Real claims, lease, heartbeat, cancel, raw fan-in` 的原 domain 輸入形成 `SourceBoundCandidate`，查真 Host/Repo/Owner；適用於 B1 的精確 operation 以該 family 的 native endpoint 載入後方可執行。
- **拒收**：原負例 `ghost Ready/missing worker raw→FANIN_BLOCKED` 與 `not a signed WorkOrder`；缺生效 ABI/Token/Issuer/HostReadback 一律 `HOLD_B1_REQUIRED`，不能因 row 存在 PASS。
- **可反證結果**：只能用此 `id=R15-044` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-045｜WP:W10 — Scoped OpenSpec propose/strict validate + actual Gstack role review

- **來源身份**：`R15.1:L285`；owner：`Named Method/Spec Owner`；effect family：`DEV_OR_OPS_PER_WO_EFFECT`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Scoped OpenSpec propose/strict validate + actual Gstack role review」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`skip_specs/fake success/method without loader→NACK`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-045` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-046｜WP:W11 — Bounded standing mandate→FAR typed recommendation→issuer→resume

- **來源身份**：`R15.1:L286`；owner：`HGK Permission/FAR/Hermes Resume Owner`；effect family：`DEV_OR_OPS_PER_WO_EFFECT`；disposition：`B1_REQUIRED`。
- **受影必備功能**：`work package owner→tracked DoD/NoFit/rollback`；先以 `Bounded standing mandate→FAR typed recommendation→issuer→resume` 的原 domain 輸入形成 `SourceBoundCandidate`，查真 Host/Repo/Owner；適用於 B1 的精確 operation 以該 family 的 native endpoint 載入後方可執行。
- **拒收**：原負例 `expired grant/replay unknown effect→HALT_AFFECTED` 與 `not a signed WorkOrder`；缺生效 ABI/Token/Issuer/HostReadback 一律 `HOLD_B1_REQUIRED`，不能因 row 存在 PASS。
- **可反證結果**：只能用此 `id=R15-046` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-047｜WP:W12 — Re-challenge W2; new W3 request; first real SWOF scoped patch

- **來源身份**：`R15.1:L287`；owner：`SWOF W2/W3 Domain Receiver+HGK`；effect family：`DEV_OR_OPS_PER_WO_EFFECT`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Re-challenge W2; new W3 request; first real SWOF scoped patch」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`no W3 but wrote repo→CRITICAL_INVALID_EFFECT`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-047` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-048｜WP:W13 — 5 distinct tools, three deterministic ZIP, three private plugin legitimate host UAT

- **來源身份**：`R15.1:L288`；owner：`SP Host Packaging Owner`；effect family：`DEV_OR_OPS_PER_WO_EFFECT`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「5 distinct tools, three deterministic ZIP, three private plugin legitimate host UAT」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`ZIP-only, artifact non-hosted→HOST_PENDING`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-048` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-049｜WP:W14 — 50/149/441=6+24+25+386/38/39 with real owners and unmerged identity

- **來源身份**：`R15.1:L289`；owner：`Product Denominator/Technology Owner`；effect family：`DEV_OR_OPS_PER_WO_EFFECT`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「50/149/441=6+24+25+386/38/39 with real owners and unmerged identity」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`defer installed, missing source child→FAIL_DENOMINATOR`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-049` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-050｜WP:W15 — secure CI/branch/attestation/no-secret/independent raw all hard gates

- **來源身份**：`R15.1:L290`；owner：`CI/Release Security+Independent AO`；effect family：`DEV_OR_OPS_PER_WO_EFFECT`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「secure CI/branch/attestation/no-secret/independent raw all hard gates」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`untrusted PR receives secrets/unpinned action→FAIL_SECURITY`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-050` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-051｜WP:W16 — B0 HGK vs B1 prerepair vs B2 integrated, matched per task

- **來源身份**：`R15.1:L291`；owner：`SBL Performance Owner+HGK Benchmark`；effect family：`DEV_OR_OPS_PER_WO_EFFECT`；disposition：`B1_REQUIRED`。
- **受影必備功能**：`work package owner→tracked DoD/NoFit/rollback`；先以 `B0 HGK vs B1 prerepair vs B2 integrated, matched per task` 的原 domain 輸入形成 `SourceBoundCandidate`，查真 Host/Repo/Owner；適用於 B1 的精確 operation 以該 family 的 native endpoint 載入後方可執行。
- **拒收**：原負例 `39 rounds vs15 attempts compared→INVALID_BENCHMARK` 與 `not a signed WorkOrder`；缺生效 ABI/Token/Issuer/HostReadback 一律 `HOLD_B1_REQUIRED`，不能因 row 存在 PASS。
- **可反證結果**：只能用此 `id=R15-051` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-052｜WP:W17 — 31 TS/31 CHK preserve results, TS04 independently mapped

- **來源身份**：`R15.1:L292`；owner：`R14 Continuation Owner+Independent AO`；effect family：`DEV_OR_OPS_PER_WO_EFFECT`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「31 TS/31 CHK preserve results, TS04 independently mapped」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`single TS orphan/override R13 fail→FAIL_REGRESSION`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-052` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-053｜CHECKRUN:C00 — Source+Compiler

- **來源身份**：`R15.1:L387`；owner：`PIPD Source Owner`；effect family：`READ_ONLY_OR_TEST_SANDBOX`；disposition：`B1_REQUIRED`。
- **受影必備功能**：`actual runner invocation→exit/stdout/stderr/subject`；先以 `Source+Compiler` 的原 domain 輸入形成 `SourceBoundCandidate`，查真 Host/Repo/Owner；適用於 B1 的精確 operation 以該 family 的 native endpoint 載入後方可執行。
- **拒收**：原負例 `mutated authority/source digest must deny` 與 `missing runtime receipt NOT_RUN`；缺生效 ABI/Token/Issuer/HostReadback 一律 `HOLD_B1_REQUIRED`，不能因 row 存在 PASS。
- **可反證結果**：只能用此 `id=R15-053` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-054｜CHECKRUN:C01 — HGK Native baseline

- **來源身份**：`R15.1:L388`；owner：`HGK Native AO`；effect family：`READ_ONLY_OR_TEST_SANDBOX`；disposition：`B1_REQUIRED`。
- **受影必備功能**：`actual runner invocation→exit/stdout/stderr/subject`；先以 `HGK Native baseline` 的原 domain 輸入形成 `SourceBoundCandidate`，查真 Host/Repo/Owner；適用於 B1 的精確 operation 以該 family 的 native endpoint 載入後方可執行。
- **拒收**：原負例 `old interpreter/nonce replay/dirty write deny` 與 `missing runtime receipt NOT_RUN`；缺生效 ABI/Token/Issuer/HostReadback 一律 `HOLD_B1_REQUIRED`，不能因 row 存在 PASS。
- **可反證結果**：只能用此 `id=R15-054` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-055｜CHECKRUN:C02 — Fabric RP002

- **來源身份**：`R15.1:L389`；owner：`Fabric Owner+HGK APL`；effect family：`READ_ONLY_OR_TEST_SANDBOX`；disposition：`B1_REQUIRED`。
- **受影必備功能**：`actual runner invocation→exit/stdout/stderr/subject`；先以 `Fabric RP002` 的原 domain 輸入形成 `SourceBoundCandidate`，查真 Host/Repo/Owner；適用於 B1 的精確 operation 以該 family 的 native endpoint 載入後方可執行。
- **拒收**：原負例 `frozen Stage-1 or changed digest denied` 與 `missing runtime receipt NOT_RUN`；缺生效 ABI/Token/Issuer/HostReadback 一律 `HOLD_B1_REQUIRED`，不能因 row 存在 PASS。
- **可反證結果**：只能用此 `id=R15-055` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-056｜CHECKRUN:C03 — Commander real invoke

- **來源身份**：`R15.1:L390`；owner：`Commander Lane AO`；effect family：`READ_ONLY_OR_TEST_SANDBOX`；disposition：`B1_REQUIRED`。
- **受影必備功能**：`actual runner invocation→exit/stdout/stderr/subject`；先以 `Commander real invoke` 的原 domain 輸入形成 `SourceBoundCandidate`，查真 Host/Repo/Owner；適用於 B1 的精確 operation 以該 family 的 native endpoint 載入後方可執行。
- **拒收**：原負例 `model ping only → fail` 與 `missing runtime receipt NOT_RUN`；缺生效 ABI/Token/Issuer/HostReadback 一律 `HOLD_B1_REQUIRED`，不能因 row 存在 PASS。
- **可反證結果**：只能用此 `id=R15-056` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-057｜CHECKRUN:C04 — Codex admitted effect

- **來源身份**：`R15.1:L391`；owner：`HGK Native Effect Owner`；effect family：`READ_ONLY_OR_TEST_SANDBOX`；disposition：`B1_REQUIRED`。
- **受影必備功能**：`actual runner invocation→exit/stdout/stderr/subject`；先以 `Codex admitted effect` 的原 domain 輸入形成 `SourceBoundCandidate`，查真 Host/Repo/Owner；適用於 B1 的精確 operation 以該 family 的 native endpoint 載入後方可執行。
- **拒收**：原負例 `expired/revoked/foreign repo no write` 與 `missing runtime receipt NOT_RUN`；缺生效 ABI/Token/Issuer/HostReadback 一律 `HOLD_B1_REQUIRED`，不能因 row 存在 PASS。
- **可反證結果**：只能用此 `id=R15-057` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-058｜CHECKRUN:C05 — Independent Challenge

- **來源身份**：`R15.1:L392`；owner：`Independent AO`；effect family：`READ_ONLY_OR_TEST_SANDBOX`；disposition：`B1_REQUIRED`。
- **受影必備功能**：`actual runner invocation→exit/stdout/stderr/subject`；先以 `Independent Challenge` 的原 domain 輸入形成 `SourceBoundCandidate`，查真 Host/Repo/Owner；適用於 B1 的精確 operation 以該 family 的 native endpoint 載入後方可執行。
- **拒收**：原負例 `self-accept/old sha/proxy evidence deny` 與 `missing runtime receipt NOT_RUN`；缺生效 ABI/Token/Issuer/HostReadback 一律 `HOLD_B1_REQUIRED`，不能因 row 存在 PASS。
- **可反證結果**：只能用此 `id=R15-058` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-059｜CHECKRUN:C06 — R14/R13 AO regression

- **來源身份**：`R15.1:L393`；owner：`Independent AO`；effect family：`READ_ONLY_OR_TEST_SANDBOX`；disposition：`B1_REQUIRED`。
- **受影必備功能**：`actual runner invocation→exit/stdout/stderr/subject`；先以 `R14/R13 AO regression` 的原 domain 輸入形成 `SourceBoundCandidate`，查真 Host/Repo/Owner；適用於 B1 的精確 operation 以該 family 的 native endpoint 載入後方可執行。
- **拒收**：原負例 `old failed seal overwritten fail` 與 `missing runtime receipt NOT_RUN`；缺生效 ABI/Token/Issuer/HostReadback 一律 `HOLD_B1_REQUIRED`，不能因 row 存在 PASS。
- **可反證結果**：只能用此 `id=R15-059` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-060｜CHECKRUN:C07 — Model coherence

- **來源身份**：`R15.1:L394`；owner：`HGK Model Owner`；effect family：`READ_ONLY_OR_TEST_SANDBOX`；disposition：`B1_REQUIRED`。
- **受影必備功能**：`actual runner invocation→exit/stdout/stderr/subject`；先以 `Model coherence` 的原 domain 輸入形成 `SourceBoundCandidate`，查真 Host/Repo/Owner；適用於 B1 的精確 operation 以該 family 的 native endpoint 載入後方可執行。
- **拒收**：原負例 `only one rank pinned green fail` 與 `missing runtime receipt NOT_RUN`；缺生效 ABI/Token/Issuer/HostReadback 一律 `HOLD_B1_REQUIRED`，不能因 row 存在 PASS。
- **可反證結果**：只能用此 `id=R15-060` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-061｜CHECKRUN:C08 — Hermes Kanban

- **來源身份**：`R15.1:L395`；owner：`Hermes Controller`；effect family：`READ_ONLY_OR_TEST_SANDBOX`；disposition：`B1_REQUIRED`。
- **受影必備功能**：`actual runner invocation→exit/stdout/stderr/subject`；先以 `Hermes Kanban` 的原 domain 輸入形成 `SourceBoundCandidate`，查真 Host/Repo/Owner；適用於 B1 的精確 operation 以該 family 的 native endpoint 載入後方可執行。
- **拒收**：原負例 `ghost Ready/orphan receipt absent fail` 與 `missing runtime receipt NOT_RUN`；缺生效 ABI/Token/Issuer/HostReadback 一律 `HOLD_B1_REQUIRED`，不能因 row 存在 PASS。
- **可反證結果**：只能用此 `id=R15-061` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-062｜CHECKRUN:C09 — Hermes Swarm

- **來源身份**：`R15.1:L396`；owner：`Hermes Controller`；effect family：`READ_ONLY_OR_TEST_SANDBOX`；disposition：`B1_REQUIRED`。
- **受影必備功能**：`actual runner invocation→exit/stdout/stderr/subject`；先以 `Hermes Swarm` 的原 domain 輸入形成 `SourceBoundCandidate`，查真 Host/Repo/Owner；適用於 B1 的精確 operation 以該 family 的 native endpoint 載入後方可執行。
- **拒收**：原負例 `drop any raw -> blocked` 與 `missing runtime receipt NOT_RUN`；缺生效 ABI/Token/Issuer/HostReadback 一律 `HOLD_B1_REQUIRED`，不能因 row 存在 PASS。
- **可反證結果**：只能用此 `id=R15-062` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-063｜CHECKRUN:C10 — gstack methods

- **來源身份**：`R15.1:L397`；owner：`Method Owner`；effect family：`READ_ONLY_OR_TEST_SANDBOX`；disposition：`B1_REQUIRED`。
- **受影必備功能**：`actual runner invocation→exit/stdout/stderr/subject`；先以 `gstack methods` 的原 domain 輸入形成 `SourceBoundCandidate`，查真 Host/Repo/Owner；適用於 B1 的精確 operation 以該 family 的 native endpoint 載入後方可執行。
- **拒收**：原負例 `method chosen but no invocation fail` 與 `missing runtime receipt NOT_RUN`；缺生效 ABI/Token/Issuer/HostReadback 一律 `HOLD_B1_REQUIRED`，不能因 row 存在 PASS。
- **可反證結果**：只能用此 `id=R15-063` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-064｜CHECKRUN:C11 — OpenSpec strict

- **來源身份**：`R15.1:L398`；owner：`OpenSpec Owner`；effect family：`READ_ONLY_OR_TEST_SANDBOX`；disposition：`B1_REQUIRED`。
- **受影必備功能**：`actual runner invocation→exit/stdout/stderr/subject`；先以 `OpenSpec strict` 的原 domain 輸入形成 `SourceBoundCandidate`，查真 Host/Repo/Owner；適用於 B1 的精確 operation 以該 family 的 native endpoint 載入後方可執行。
- **拒收**：原負例 `missing delta but exit 0 fail` 與 `missing runtime receipt NOT_RUN`；缺生效 ABI/Token/Issuer/HostReadback 一律 `HOLD_B1_REQUIRED`，不能因 row 存在 PASS。
- **可反證結果**：只能用此 `id=R15-064` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-065｜CHECKRUN:C12 — bounded repair

- **來源身份**：`R15.1:L399`；owner：`Repair Owner/AO`；effect family：`READ_ONLY_OR_TEST_SANDBOX`；disposition：`B1_REQUIRED`。
- **受影必備功能**：`actual runner invocation→exit/stdout/stderr/subject`；先以 `bounded repair` 的原 domain 輸入形成 `SourceBoundCandidate`，查真 Host/Repo/Owner；適用於 B1 的精確 operation 以該 family 的 native endpoint 載入後方可執行。
- **拒收**：原負例 `oracle edit/ignore STOP_ESCALATE fail` 與 `missing runtime receipt NOT_RUN`；缺生效 ABI/Token/Issuer/HostReadback 一律 `HOLD_B1_REQUIRED`，不能因 row 存在 PASS。
- **可反證結果**：只能用此 `id=R15-065` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-066｜CHECKRUN:C13 — FAR Standing

- **來源身份**：`R15.1:L400`；owner：`HGK APL Owner`；effect family：`READ_ONLY_OR_TEST_SANDBOX`；disposition：`B1_REQUIRED`。
- **受影必備功能**：`actual runner invocation→exit/stdout/stderr/subject`；先以 `FAR Standing` 的原 domain 輸入形成 `SourceBoundCandidate`，查真 Host/Repo/Owner；適用於 B1 的精確 operation 以該 family 的 native endpoint 載入後方可執行。
- **拒收**：原負例 `revoked/foreign/critical escalation deny` 與 `missing runtime receipt NOT_RUN`；缺生效 ABI/Token/Issuer/HostReadback 一律 `HOLD_B1_REQUIRED`，不能因 row 存在 PASS。
- **可反證結果**：只能用此 `id=R15-066` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-067｜CHECKRUN:C14 — long resume

- **來源身份**：`R15.1:L401`；owner：`Hermes/HGK checkpoint owner`；effect family：`READ_ONLY_OR_TEST_SANDBOX`；disposition：`B1_REQUIRED`。
- **受影必備功能**：`actual runner invocation→exit/stdout/stderr/subject`；先以 `long resume` 的原 domain 輸入形成 `SourceBoundCandidate`，查真 Host/Repo/Owner；適用於 B1 的精確 operation 以該 family 的 native endpoint 載入後方可執行。
- **拒收**：原負例 `UNKNOWN_EFFECT replay→HOLD` 與 `missing runtime receipt NOT_RUN`；缺生效 ABI/Token/Issuer/HostReadback 一律 `HOLD_B1_REQUIRED`，不能因 row 存在 PASS。
- **可反證結果**：只能用此 `id=R15-067` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-068｜CHECKRUN:C15 — evolution safety

- **來源身份**：`R15.1:L402`；owner：`Evolution Owner`；effect family：`READ_ONLY_OR_TEST_SANDBOX`；disposition：`B1_REQUIRED`。
- **受影必備功能**：`actual runner invocation→exit/stdout/stderr/subject`；先以 `evolution safety` 的原 domain 輸入形成 `SourceBoundCandidate`，查真 Host/Repo/Owner；適用於 B1 的精確 operation 以該 family 的 native endpoint 載入後方可執行。
- **拒收**：原負例 `self promotion / poisoned feedback fail` 與 `missing runtime receipt NOT_RUN`；缺生效 ABI/Token/Issuer/HostReadback 一律 `HOLD_B1_REQUIRED`，不能因 row 存在 PASS。
- **可反證結果**：只能用此 `id=R15-068` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-069｜CHECKRUN:C16 — PIPD trace

- **來源身份**：`R15.1:L403`；owner：`PIPD Writer+AO`；effect family：`READ_ONLY_OR_TEST_SANDBOX`；disposition：`B1_REQUIRED`。
- **受影必備功能**：`actual runner invocation→exit/stdout/stderr/subject`；先以 `PIPD trace` 的原 domain 輸入形成 `SourceBoundCandidate`，查真 Host/Repo/Owner；適用於 B1 的精確 operation 以該 family 的 native endpoint 載入後方可執行。
- **拒收**：原負例 `zero atom/unbounded scope/orphan false-PASS deny` 與 `missing runtime receipt NOT_RUN`；缺生效 ABI/Token/Issuer/HostReadback 一律 `HOLD_B1_REQUIRED`，不能因 row 存在 PASS。
- **可反證結果**：只能用此 `id=R15-069` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-070｜CHECKRUN:C17 — Kinds×Hosts

- **來源身份**：`R15.1:L404`；owner：`Host/Product AO`；effect family：`READ_ONLY_OR_TEST_SANDBOX`；disposition：`B1_REQUIRED`。
- **受影必備功能**：`actual runner invocation→exit/stdout/stderr/subject`；先以 `Kinds×Hosts` 的原 domain 輸入形成 `SourceBoundCandidate`，查真 Host/Repo/Owner；適用於 B1 的精確 operation 以該 family 的 native endpoint 載入後方可執行。
- **拒收**：原負例 `prebaked fixture or fake Host ID fail` 與 `missing runtime receipt NOT_RUN`；缺生效 ABI/Token/Issuer/HostReadback 一律 `HOLD_B1_REQUIRED`，不能因 row 存在 PASS。
- **可反證結果**：只能用此 `id=R15-070` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-071｜CHECKRUN:C18 — product semantic coverage

- **來源身份**：`R15.1:L405`；owner：`Product Owner+AO`；effect family：`READ_ONLY_OR_TEST_SANDBOX`；disposition：`B1_REQUIRED`。
- **受影必備功能**：`actual runner invocation→exit/stdout/stderr/subject`；先以 `product semantic coverage` 的原 domain 輸入形成 `SourceBoundCandidate`，查真 Host/Repo/Owner；適用於 B1 的精確 operation 以該 family 的 native endpoint 載入後方可執行。
- **拒收**：原負例 `invent N/A or alias original ID fail` 與 `missing runtime receipt NOT_RUN`；缺生效 ABI/Token/Issuer/HostReadback 一律 `HOLD_B1_REQUIRED`，不能因 row 存在 PASS。
- **可反證結果**：只能用此 `id=R15-071` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-072｜CHECKRUN:C19 — SWOF W3 effect

- **來源身份**：`R15.1:L406`；owner：`SWOF Owner`；effect family：`READ_ONLY_OR_TEST_SANDBOX`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「SWOF W3 effect」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`no W3 then NO_EFFECT`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-072` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-073｜CHECKRUN:C20 — five tools/ZIP

- **來源身份**：`R15.1:L407`；owner：`Packaging AO`；effect family：`READ_ONLY_OR_TEST_SANDBOX`；disposition：`B1_REQUIRED`。
- **受影必備功能**：`actual runner invocation→exit/stdout/stderr/subject`；先以 `five tools/ZIP` 的原 domain 輸入形成 `SourceBoundCandidate`，查真 Host/Repo/Owner；適用於 B1 的精確 operation 以該 family 的 native endpoint 載入後方可執行。
- **拒收**：原負例 `ZIP without Host installed fail` 與 `missing runtime receipt NOT_RUN`；缺生效 ABI/Token/Issuer/HostReadback 一律 `HOLD_B1_REQUIRED`，不能因 row 存在 PASS。
- **可反證結果**：只能用此 `id=R15-073` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-074｜CHECKRUN:C21 — three ChatGPT private SPs

- **來源身份**：`R15.1:L408`；owner：`ChatGPT Host Owner`；effect family：`READ_ONLY_OR_TEST_SANDBOX`；disposition：`B1_REQUIRED`。
- **受影必備功能**：`actual runner invocation→exit/stdout/stderr/subject`；先以 `three ChatGPT private SPs` 的原 domain 輸入形成 `SourceBoundCandidate`，查真 Host/Repo/Owner；適用於 B1 的精確 operation 以該 family 的 native endpoint 載入後方可執行。
- **拒收**：原負例 `draft/0 IDs -> HOST_PENDING` 與 `missing runtime receipt NOT_RUN`；缺生效 ABI/Token/Issuer/HostReadback 一律 `HOLD_B1_REQUIRED`，不能因 row 存在 PASS。
- **可反證結果**：只能用此 `id=R15-074` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-075｜CHECKRUN:C22 — CI/supply chain

- **來源身份**：`R15.1:L409`；owner：`Release Owner`；effect family：`READ_ONLY_OR_TEST_SANDBOX`；disposition：`B1_REQUIRED`。
- **受影必備功能**：`actual runner invocation→exit/stdout/stderr/subject`；先以 `CI/supply chain` 的原 domain 輸入形成 `SourceBoundCandidate`，查真 Host/Repo/Owner；適用於 B1 的精確 operation 以該 family 的 native endpoint 載入後方可執行。
- **拒收**：原負例 `untrusted PR secret, unpinned action deny` 與 `missing runtime receipt NOT_RUN`；缺生效 ABI/Token/Issuer/HostReadback 一律 `HOLD_B1_REQUIRED`，不能因 row 存在 PASS。
- **可反證結果**：只能用此 `id=R15-075` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-076｜CHECKRUN:C23 — matched performance

- **來源身份**：`R15.1:L410`；owner：`Benchmark Owner`；effect family：`READ_ONLY_OR_TEST_SANDBOX`；disposition：`B1_REQUIRED`。
- **受影必備功能**：`actual runner invocation→exit/stdout/stderr/subject`；先以 `matched performance` 的原 domain 輸入形成 `SourceBoundCandidate`，查真 Host/Repo/Owner；適用於 B1 的精確 operation 以該 family 的 native endpoint 載入後方可執行。
- **拒收**：原負例 `different denominator/hardware->INVALID_COMPARE` 與 `missing runtime receipt NOT_RUN`；缺生效 ABI/Token/Issuer/HostReadback 一律 `HOLD_B1_REQUIRED`，不能因 row 存在 PASS。
- **可反證結果**：只能用此 `id=R15-076` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-077｜CHECKRUN:C24 — final claim ceiling

- **來源身份**：`R15.1:L411`；owner：`HGK Final Owner`；effect family：`READ_ONLY_OR_TEST_SANDBOX`；disposition：`B1_REQUIRED`。
- **受影必備功能**：`actual runner invocation→exit/stdout/stderr/subject`；先以 `final claim ceiling` 的原 domain 輸入形成 `SourceBoundCandidate`，查真 Host/Repo/Owner；適用於 B1 的精確 operation 以該 family 的 native endpoint 載入後方可執行。
- **拒收**：原負例 `partial scoped pass claiming full→FAIL` 與 `missing runtime receipt NOT_RUN`；缺生效 ABI/Token/Issuer/HostReadback 一律 `HOLD_B1_REQUIRED`，不能因 row 存在 PASS。
- **可反證結果**：只能用此 `id=R15-077` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-078｜DONOR_SLOT:SLOT-OS-01 — OpenSpec

- **來源身份**：`R15.1:L505`；owner：`Explore when ambiguous`；effect family：`METHOD_ONLY_NO_WORLD_EFFECT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `OpenSpec` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `SearchBeforeBuild→licence/pin/gap→admit or NO_FIT`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`DOC06:L178` 或 `no automatic donor import`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-078` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-079｜DONOR_SLOT:SLOT-OS-02 — OpenSpec

- **來源身份**：`R15.1:L506`；owner：`CurrentHEAD+desired scope bounded diff`；effect family：`METHOD_ONLY_NO_WORLD_EFFECT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `OpenSpec` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `SearchBeforeBuild→licence/pin/gap→admit or NO_FIT`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`DOC06:L179` 或 `no automatic donor import`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-079` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-080｜DONOR_SLOT:SLOT-OS-03 — OpenSpec

- **來源身份**：`R15.1:L507`；owner：`Approved Change+WriteSet+Native ECP`；effect family：`METHOD_ONLY_NO_WORLD_EFFECT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `OpenSpec` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `SearchBeforeBuild→licence/pin/gap→admit or NO_FIT`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`DOC06:L180` 或 `no automatic donor import`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-080` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-081｜DONOR_SLOT:SLOT-OS-04 — OpenSpec

- **來源身份**：`R15.1:L508`；owner：`Verified change + trace closed archive`；effect family：`METHOD_ONLY_NO_WORLD_EFFECT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `OpenSpec` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `SearchBeforeBuild→licence/pin/gap→admit or NO_FIT`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`DOC06:L181` 或 `no automatic donor import`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-081` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-082｜DONOR_SLOT:SLOT-SK-01 — Spec Kit

- **來源身份**：`R15.1:L509`；owner：`Product kind + Constitution + non-goals`；effect family：`METHOD_ONLY_NO_WORLD_EFFECT`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Spec Kit」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`DOC06:L182`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-082` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-083｜DONOR_SLOT:SLOT-SK-02 — Spec Kit

- **來源身份**：`R15.1:L510`；owner：`Unknown requirement + value of information`；effect family：`METHOD_ONLY_NO_WORLD_EFFECT`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Spec Kit」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`DOC06:L183`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-083` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-084｜DONOR_SLOT:SLOT-SK-03 — Spec Kit

- **來源身份**：`R15.1:L511`；owner：`Bounded task nodes + dependency and owner`；effect family：`METHOD_ONLY_NO_WORLD_EFFECT`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Spec Kit」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`DOC06:L184`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-084` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-085｜DONOR_SLOT:SLOT-SK-04 — Spec Kit

- **來源身份**：`R15.1:L512`；owner：`Approved workflow manifests with versions`；effect family：`METHOD_ONLY_NO_WORLD_EFFECT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Spec Kit` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `SearchBeforeBuild→licence/pin/gap→admit or NO_FIT`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`DOC06:L185` 或 `no automatic donor import`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-085` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-086｜DONOR_SLOT:SLOT-MP-01 — mattpocock/skills

- **來源身份**：`R15.1:L513`；owner：`Goal+intent type+host capability`；effect family：`METHOD_ONLY_NO_WORLD_EFFECT`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「mattpocock/skills」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`DOC06:L186`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-086` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-087｜DONOR_SLOT:SLOT-MP-02 — mattpocock/skills

- **來源身份**：`R15.1:L514`；owner：`Document context+known answers+uncertainty`；effect family：`METHOD_ONLY_NO_WORLD_EFFECT`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「mattpocock/skills」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`DOC06:L187`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-087` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-088｜DONOR_SLOT:SLOT-MP-03 — mattpocock/skills

- **來源身份**：`R15.1:L515`；owner：`Glossary terms+boundary+events`；effect family：`METHOD_ONLY_NO_WORLD_EFFECT`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「mattpocock/skills」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`DOC06:L188`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-088` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-089｜DONOR_SLOT:SLOT-MP-04 — mattpocock/skills

- **來源身份**：`R15.1:L516`；owner：`Approved SpecCandidate+ACC+task owner`；effect family：`METHOD_ONLY_NO_WORLD_EFFECT`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「mattpocock/skills」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`DOC06:L189`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-089` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-090｜DONOR_SLOT:SLOT-GS-01 — GSD

- **來源身份**：`R15.1:L517`；owner：`SourceHash+Goal+Phase context`；effect family：`METHOD_ONLY_NO_WORLD_EFFECT`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「GSD」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`DOC06:L190`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-090` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-091｜DONOR_SLOT:SLOT-GS-02 — GSD

- **來源身份**：`R15.1:L518`；owner：`Milestone DAG + gate prerequisites`；effect family：`METHOD_ONLY_NO_WORLD_EFFECT`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「GSD」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`DOC06:L191`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-091` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-092｜DONOR_SLOT:SLOT-GS-03 — GSD

- **來源身份**：`R15.1:L519`；owner：`Saved Checkpoint+nonce+effect result`；effect family：`METHOD_ONLY_NO_WORLD_EFFECT`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「GSD」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`DOC06:L192`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-092` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-093｜DONOR_SLOT:SLOT-GS-04 — GSD

- **來源身份**：`R15.1:L520`；owner：`Build SubjectSHA+verification+release rights`；effect family：`METHOD_ONLY_NO_WORLD_EFFECT`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「GSD」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`DOC06:L193`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-093` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-094｜DONOR_SLOT:SLOT-GT-01 — gstack

- **來源身份**：`R15.1:L521`；owner：`ProductKind+JTBD/FUO target`；effect family：`METHOD_ONLY_NO_WORLD_EFFECT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `gstack` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `SearchBeforeBuild→licence/pin/gap→admit or NO_FIT`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`DOC06:L194` 或 `no automatic donor import`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-094` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-095｜DONOR_SLOT:SLOT-GT-02 — gstack

- **來源身份**：`R15.1:L522`；owner：`Arch+NFR+UX baseline`；effect family：`METHOD_ONLY_NO_WORLD_EFFECT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `gstack` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `SearchBeforeBuild→licence/pin/gap→admit or NO_FIT`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`DOC06:L195` 或 `no automatic donor import`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-095` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-096｜DONOR_SLOT:SLOT-GT-03 — gstack

- **來源身份**：`R15.1:L523`；owner：`Test plan+candidate hash+independent checker`；effect family：`METHOD_ONLY_NO_WORLD_EFFECT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `gstack` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `SearchBeforeBuild→licence/pin/gap→admit or NO_FIT`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`DOC06:L196` 或 `no automatic donor import`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-096` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-097｜DONOR_SLOT:SLOT-GT-04 — gstack

- **來源身份**：`R15.1:L524`；owner：`Status checks+user value+release evidence`；effect family：`METHOD_ONLY_NO_WORLD_EFFECT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `gstack` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `SearchBeforeBuild→licence/pin/gap→admit or NO_FIT`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`DOC06:L197` 或 `no automatic donor import`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-097` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-098｜DONOR_SLOT:SLOT-SP-01 — Superpowers

- **來源身份**：`R15.1:L525`；owner：`Design options+source-risk-ADR`；effect family：`METHOD_ONLY_NO_WORLD_EFFECT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Superpowers` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `SearchBeforeBuild→licence/pin/gap→admit or NO_FIT`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`DOC06:L198` 或 `no automatic donor import`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-098` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-099｜DONOR_SLOT:SLOT-SP-02 — Superpowers

- **來源身份**：`R15.1:L526`；owner：`Failing test OldHEAD+exact code scope`；effect family：`METHOD_ONLY_NO_WORLD_EFFECT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Superpowers` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `SearchBeforeBuild→licence/pin/gap→admit or NO_FIT`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`DOC06:L199` 或 `no automatic donor import`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-099` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-100｜DONOR_SLOT:SLOT-SP-03 — Superpowers

- **來源身份**：`R15.1:L527`；owner：`Observed failure+repro+root cause`；effect family：`METHOD_ONLY_NO_WORLD_EFFECT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Superpowers` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `SearchBeforeBuild→licence/pin/gap→admit or NO_FIT`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`DOC06:L200` 或 `no automatic donor import`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-100` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-101｜DONOR_SLOT:SLOT-SP-04 — Superpowers

- **來源身份**：`R15.1:L528`；owner：`Plan+independent evidence+review request`；effect family：`METHOD_ONLY_NO_WORLD_EFFECT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Superpowers` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `SearchBeforeBuild→licence/pin/gap→admit or NO_FIT`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`DOC06:L201` 或 `no automatic donor import`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-101` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-102｜METHOD:METHOD-01 — BMAD-METHOD

- **來源身份**：`R15.1:L584`；owner：`MP-02 / SK-02`；effect family：`METHOD_ONLY_NO_WORLD_EFFECT`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「BMAD-METHOD」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`Full BMAD runtime duplicated with PIPD → PARALLEL_COMPILER`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-102` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-103｜METHOD:METHOD-02 — mattpocock/skills:grill-with-docs

- **來源身份**：`R15.1:L585`；owner：`MP-02`；effect family：`METHOD_ONLY_NO_WORLD_EFFECT`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「mattpocock/skills:grill-with-docs」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`harness Skill tool missing → fall back to relative SKILL.md`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-103` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-104｜METHOD:METHOD-03 — mattpocock/skills:domain-modeling

- **來源身份**：`R15.1:L586`；owner：`MP-03`；effect family：`METHOD_ONLY_NO_WORLD_EFFECT`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「mattpocock/skills:domain-modeling」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`No primary source for ontology → NACK_DOMAIN_CONFLICT`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-104` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-105｜METHOD:METHOD-04 — mattpocock/skills:to-spec

- **來源身份**：`R15.1:L587`；owner：`MP-03 → SPEC_ADAPTER → SK-02`；effect family：`METHOD_ONLY_NO_WORLD_EFFECT`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「mattpocock/skills:to-spec」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`ACC absent or wrong domain → SPEC_SEED_INCOMPLETE`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-105` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-106｜METHOD:METHOD-05 — mattpocock/skills:to-tickets

- **來源身份**：`R15.1:L588`；owner：`MP-04`；effect family：`METHOD_ONLY_NO_WORLD_EFFECT`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「mattpocock/skills:to-tickets」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`No issue-token + publish attempt → ISSUE_PUBLISH_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-106` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-107｜METHOD:METHOD-06 — OpenSpec

- **來源身份**：`R15.1:L589`；owner：`OS-01/02/03/04`；effect family：`METHOD_ONLY_NO_WORLD_EFFECT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `OpenSpec` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `selected route/host installed/policy epoch/true method invocation`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`Stale HEAD or unauthorized archive → NACK_SCOPE` 或 `Mandatory overrides conditional R15 label`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-107` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-108｜METHOD:METHOD-07 — Spec Kit

- **來源身份**：`R15.1:L590`；owner：`SK-01/02/03/04`；effect family：`METHOD_ONLY_NO_WORLD_EFFECT`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Spec Kit」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`Constitution overwrite → NACK_AUTHORITY`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-108` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-109｜METHOD:METHOD-08 — Superpowers

- **來源身份**：`R15.1:L591`；owner：`SP-01/02/03/04`；effect family：`METHOD_ONLY_NO_WORLD_EFFECT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Superpowers` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `selected route/host installed/policy epoch/true method invocation`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`fabricated RED log → NACK_RED_PHASE` 或 `Mandatory overrides conditional R15 label`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-109` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-110｜METHOD:METHOD-09 — GitHub Actions

- **來源身份**：`R15.1:L592`；owner：`GS-04`；effect family：`METHOD_ONLY_NO_WORLD_EFFECT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `GitHub Actions` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `selected route/host installed/policy epoch/true method invocation`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`Untrusted PR elevated secret → CI_TRUST_BOUNDARY` 或 `Mandatory overrides conditional R15 label`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-110` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-111｜METHOD:METHOD-10 — MCP

- **來源身份**：`R15.1:L593`；owner：`MP-01 / Host Tool Gateway`；effect family：`METHOD_ONLY_NO_WORLD_EFFECT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `MCP` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `selected route/host installed/policy epoch/true method invocation`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`untrusted server tool calls privileged → MCP_SCOPE_DENIED` 或 `Mandatory overrides conditional R15 label`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-111` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-112｜METHOD:METHOD-11 — ACP

- **來源身份**：`R15.1:L594`；owner：`MP-01 / Agent Interop`；effect family：`METHOD_ONLY_NO_WORLD_EFFECT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `ACP` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `selected route/host installed/policy epoch/true method invocation`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`spoofed agent authority → MESSAGE_TRUST_DENIED` 或 `Mandatory overrides conditional R15 label`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-112` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-113｜METHOD:METHOD-12 — OpenSSF Scorecard

- **來源身份**：`R15.1:L595`；owner：`GT-04`；effect family：`METHOD_ONLY_NO_WORLD_EFFECT`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「OpenSSF Scorecard」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`risk score falsely treated as Release PASS → SCORECARD_PROXY`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-113` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-114｜METHOD:METHOD-13 — SLSA

- **來源身份**：`R15.1:L596`；owner：`GS-04`；effect family：`METHOD_ONLY_NO_WORLD_EFFECT`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「SLSA」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`missing builder/subject mismatch → PROVENANCE_MISSING`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-114` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-115｜METHOD:METHOD-14 — OWASP

- **來源身份**：`R15.1:L597`；owner：`GT-03`；effect family：`METHOD_ONLY_NO_WORLD_EFFECT`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「OWASP」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`taxonomy label equals run proof → SECURITY_PROXY`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-115` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-116｜METHOD:METHOD-15 — CodeQL

- **來源身份**：`R15.1:L598`；owner：`GT-03`；effect family：`METHOD_ONLY_NO_WORLD_EFFECT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `CodeQL` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `selected route/host installed/policy epoch/true method invocation`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`untrusted query pack ⇒ QUERY_PACK_UNTRUSTED` 或 `Mandatory overrides conditional R15 label`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-116` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-117｜METHOD:METHOD-16 — Semgrep

- **來源身份**：`R15.1:L599`；owner：`GT-03`；effect family：`METHOD_ONLY_NO_WORLD_EFFECT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Semgrep` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `selected route/host installed/policy epoch/true method invocation`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`unapproved rule overrides policy→RULE_PIN_MISSING` 或 `Mandatory overrides conditional R15 label`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-117` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-118｜METHOD:METHOD-17 — Renovate

- **來源身份**：`R15.1:L600`；owner：`GS-04`；effect family：`METHOD_ONLY_NO_WORLD_EFFECT`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Renovate」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`untrusted dependency silently updated→SUPPLY_DEPENDENCY_FAIL`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-118` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-119｜METHOD:METHOD-18 — Dependabot

- **來源身份**：`R15.1:L601`；owner：`GS-04`；effect family：`METHOD_ONLY_NO_WORLD_EFFECT`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Dependabot」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`no original owner auth → OWNER_DECISION_REQUIRED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-119` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-120｜METHOD:METHOD-19 — Cosign

- **來源身份**：`R15.1:L602`；owner：`GS-04`；effect family：`METHOD_ONLY_NO_WORLD_EFFECT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Cosign` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `selected route/host installed/policy epoch/true method invocation`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`self-sign without approved producer identity→SIGNER_SOD_FAIL` 或 `Mandatory overrides conditional R15 label`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-120` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-121｜METHOD:METHOD-20 — Syft

- **來源身份**：`R15.1:L603`；owner：`GS-04`；effect family：`METHOD_ONLY_NO_WORLD_EFFECT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Syft` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `selected route/host installed/policy epoch/true method invocation`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`foreign BOM digest→SBOM_SUBJECT_MISMATCH` 或 `Mandatory overrides conditional R15 label`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-121` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-122｜METHOD:METHOD-21 — Trivy

- **來源身份**：`R15.1:L604`；owner：`GT-03 / GS-04`；effect family：`METHOD_ONLY_NO_WORLD_EFFECT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Trivy` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `selected route/host installed/policy epoch/true method invocation`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`empty scan accepted → SCAN_TARGET_UNKNOWN` 或 `Mandatory overrides conditional R15 label`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-122` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-123｜METHOD:METHOD-22 — SQLite/FTS5

- **來源身份**：`R15.1:L605`；owner：`MP-03`；effect family：`METHOD_ONLY_NO_WORLD_EFFECT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `SQLite/FTS5` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `selected route/host installed/policy epoch/true method invocation`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`FTS rows lack source FK→FTS_PROVENANCE_FAIL` 或 `Mandatory overrides conditional R15 label`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-123` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-124｜METHOD:METHOD-23 — FAR/FDA

- **來源身份**：`R15.1:L606`；owner：`GT-03`；effect family：`METHOD_ONLY_NO_WORLD_EFFECT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `FAR/FDA` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `selected route/host installed/policy epoch/true method invocation`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`self-issued FAR/FDA receipt→FABRIC_OWNER_REQUIRED` 或 `Mandatory overrides conditional R15 label`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-124` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-125｜METHOD:METHOD-24 — OpenAI Agents SDK

- **來源身份**：`R15.1:L607`；owner：`MP-01`；effect family：`METHOD_ONLY_NO_WORLD_EFFECT`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「OpenAI Agents SDK」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`SDK sample treated as native host→SDK_HOST_UNVERIFIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-125` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-126｜METHOD:METHOD-25 — Agent Skills specification

- **來源身份**：`R15.1:L608`；owner：`MP-01`；effect family：`METHOD_ONLY_NO_WORLD_EFFECT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Agent Skills specification` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `selected route/host installed/policy epoch/true method invocation`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`valid SKILL.md but unregistered→HOST_NOT_LOADED` 或 `Mandatory overrides conditional R15 label`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-126` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-127｜TECH_ID:NOBJ-001 — HLPE Native PLAN/BOOTSTRAP/FACTORY

- **來源身份**：`R15.1:L620`；owner：`SBL TPM / HLPE`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `HLPE Native PLAN/BOOTSTRAP/FACTORY` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`把上游 legacy phase 當 SBL PI Compiler→PARALLEL_COMPILER` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-127` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-128｜TECH_ID:NOBJ-002 — Matt grill-with-docs

- **來源身份**：`R15.1:L621`；owner：`TPM interview`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Matt grill-with-docs` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`unknown referenced SKILL path→NACK_DEPENDENCY` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-128` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-129｜TECH_ID:NOBJ-003 — OpenSpec

- **來源身份**：`R15.1:L622`；owner：`SBL SpecDelta Consumer`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `OpenSpec` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`stale source revision→NACK_SCOPE` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-129` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-130｜TECH_ID:NOBJ-004 — Spec Kit

- **來源身份**：`R15.1:L623`；owner：`SBL SPEC / TPM`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Spec Kit` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`unversioned extension or Constitution overwrite→NACK_AUTHORITY` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-130` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-131｜TECH_ID:NOBJ-005 — Superpowers test-driven-development

- **來源身份**：`R15.1:L624`；owner：`Commander / HGK`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Superpowers test-driven-development` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`no executed RED on old HEAD→NACK_RED_PHASE` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-131` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-132｜TECH_ID:NOBJ-006 — Superpowers systematic-debugging

- **來源身份**：`R15.1:L625`；owner：`Commander-SP / RootCause Reader`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Superpowers systematic-debugging` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`unknown root cause followed by broad edits→NACK_ROOT_CAUSE` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-132` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-133｜TECH_ID:NOBJ-007 — Superpowers verification-before-completion

- **來源身份**：`R15.1:L626`；owner：`Challenge-SP / Completion Gate Reader`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Superpowers verification-before-completion` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`maker self-verification as independent PASS→MAKER_SELF_ACCEPT` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-133` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-134｜TECH_ID:NOBJ-008 — GStack

- **來源身份**：`R15.1:L627`；owner：`SBL Review & Challenge`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `GStack` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`self-issued independent PASS→MAKER_SELF_ACCEPT` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-134` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-135｜TECH_ID:NOBJ-009 — GSD / planning-with-files

- **來源身份**：`R15.1:L628`；owner：`SBL Milestone/Resume`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `GSD / planning-with-files` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`archived source treated as current installer→ARCHIVED_SOURCE_DENIED` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-135` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-136｜TECH_ID:NOBJ-010 — AGENTS.md

- **來源身份**：`R15.1:L629`；owner：`Codex host loader`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `AGENTS.md` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`AGENTS tries to confer tool permission→INSTRUCTION_PRIVILEGE` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-136` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-137｜TECH_ID:NOBJ-011 — SKILL.md

- **來源身份**：`R15.1:L630`；owner：`Host Skill Registry`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `SKILL.md` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`injection or missing dependency→SKILL_LOAD_NACK` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-137` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-138｜TECH_ID:NOBJ-012 — DESIGN.md

- **來源身份**：`R15.1:L631`；owner：`TPM design reader`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `DESIGN.md` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`DESIGN.md claims approval token→NACK_AUTHORITY` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-138` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-139｜TECH_ID:NOBJ-013 — Prompt projection

- **來源身份**：`R15.1:L632`；owner：`SBL Host/Procedure Reader`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Prompt projection` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`Prompt projection 越權到 Host token/Policy Writer→HOST_AUTH_DENIED` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-139` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-140｜TECH_ID:NOBJ-014 — OpenAI skill-creator

- **來源身份**：`R15.1:L633`；owner：`SBL Host/Procedure Reader`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `OpenAI skill-creator` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`OpenAI skill-creator 越權到 Host token/Policy Writer→HOST_AUTH_DENIED` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-140` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-141｜TECH_ID:NOBJ-015 — OpenAI plugin-creator

- **來源身份**：`R15.1:L634`；owner：`SBL Host/Procedure Reader`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `OpenAI plugin-creator` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`OpenAI plugin-creator 越權到 Host token/Policy Writer→HOST_AUTH_DENIED` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-141` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-142｜TECH_ID:NOBJ-016 — Agent Skills specification

- **來源身份**：`R15.1:L635`；owner：`SBL Host Adapter`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Agent Skills specification` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`format valid but host unloaded→HOST_NOT_LOADED` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-142` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-143｜TECH_ID:NOBJ-017 — Agent Plugins 1.0 Working Draft

- **來源身份**：`R15.1:L636`；owner：`Host experiment only`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Agent Plugins 1.0 Working Draft` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`plugin draft promoted to installed→QUARANTINED_DEFAULT_DENIED` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-143` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-144｜TECH_ID:NOBJ-018 — JSON Schema 2020-12

- **來源身份**：`R15.1:L637`；owner：`PIPD/Schema Reader`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `JSON Schema 2020-12` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`undeclared sidecar key or unknown schema→NACK_SCHEMA` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-144` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-145｜TECH_ID:NOBJ-019 — pytest

- **來源身份**：`R15.1:L638`；owner：`Native Test Runner`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `pytest` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`zero collected tests→TEST_DENOMINATOR_ZERO` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-145` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-146｜TECH_ID:NOBJ-020 — GitHub Actions

- **來源身份**：`R15.1:L639`；owner：`CI Evidence Producer`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `GitHub Actions` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`fork PR secret elevation→CI_TRUST_BOUNDARY` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-146` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-147｜TECH_ID:NOBJ-021 — CycloneDX

- **來源身份**：`R15.1:L640`；owner：`Supply Chain Normalizer`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `CycloneDX` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`wrong schema/subject→SBOM_SCHEMA_FAIL` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-147` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-148｜TECH_ID:NOBJ-022 — Gitleaks

- **來源身份**：`R15.1:L641`；owner：`Security CI`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Gitleaks` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`secret hit suppressed without owner exception→SECRET_POLICY_DENIED` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-148` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-149｜TECH_ID:NOBJ-023 — markdownlint

- **來源身份**：`R15.1:L642`；owner：`Docs CI`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `markdownlint` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`invalid frontmatter ignored→MD_LINT_FAIL` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-149` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-150｜TECH_ID:NOBJ-024 — Ruff + type checker

- **來源身份**：`R15.1:L643`；owner：`Native CI`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Ruff + type checker` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`skipped lint result masquerades success→QUALITY_GATE_FAIL` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-150` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-151｜TECH_ID:341 — OpenTelemetry GenAI

- **來源身份**：`R15.1:L644`；owner：`Ops Observability Reader`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `OpenTelemetry GenAI` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`evidence SHA derived from trace proxy→PROXY_EVIDENCE_DENIED` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-151` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-152｜TECH_ID:342 — Spec Kit 1.1 patterns

- **來源身份**：`R15.1:L645`；owner：`SBL SPEC / TPM`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Spec Kit 1.1 patterns` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`unversioned extension or Constitution overwrite→NACK_AUTHORITY` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-152` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-153｜TECH_ID:343 — LangGraph checkpoint tests

- **來源身份**：`R15.1:L646`；owner：`SBL Scoped Context Reader`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `LangGraph checkpoint tests` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`LangGraph checkpoint tests 未取證仍顯示 resumed → CHECKPOINT_NO_EVIDENCE` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-153` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-154｜TECH_ID:344 — Groundability method

- **來源身份**：`R15.1:L647`；owner：`SBL Reuse Scout`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Groundability method` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`Groundability method 無 FeatureDiff 直接成為 Default→ADMISSION_MISSING` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-154` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-155｜TECH_ID:345 — Global Coherence

- **來源身份**：`R15.1:L648`；owner：`SBL Reuse Scout`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Global Coherence` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`Global Coherence 無 FeatureDiff 直接成為 Default→ADMISSION_MISSING` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-155` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-156｜TECH_ID:346 — Finding-the-Right-Fit

- **來源身份**：`R15.1:L649`；owner：`SBL Reuse Scout`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Finding-the-Right-Fit` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`Finding-the-Right-Fit 無 FeatureDiff 直接成為 Default→ADMISSION_MISSING` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-156` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-157｜TECH_ID:347 — HF 6,204 trajectories

- **來源身份**：`R15.1:L650`；owner：`SBL Reuse Scout`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `HF 6,204 trajectories` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`HF 6,204 trajectories 無 FeatureDiff 直接成為 Default→ADMISSION_MISSING` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-157` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-158｜TECH_ID:348 — Promptfoo

- **來源身份**：`R15.1:L651`；owner：`Security Evaluator`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Promptfoo` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`no negatives yet PASS→NEGATIVE_FIXTURE_MISSING` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-158` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-159｜TECH_ID:349 — Inspect AI

- **來源身份**：`R15.1:L652`；owner：`Eval Runner`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Inspect AI` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`self-judge cited as independent→EVAL_SELF_PASS` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-159` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-160｜TECH_ID:350 — Garak

- **來源身份**：`R15.1:L653`；owner：`Security Evaluator`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Garak` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`malicious probe run without safe environment→PROBE_SCOPE_DENIED` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-160` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-161｜TECH_ID:351 — Phoenix

- **來源身份**：`R15.1:L654`；owner：`Eval Orchestrator`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Phoenix` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`judge metric alone accepted→LLM_JUDGE_PROXY` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-161` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-162｜TECH_ID:352 — Langfuse

- **來源身份**：`R15.1:L655`；owner：`Eval/Obs Reader`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Langfuse` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`prompt PII logged unredacted→TRACE_PRIVACY_DENIED` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-162` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-163｜TECH_ID:353 — LangGraph runtime

- **來源身份**：`R15.1:L656`；owner：`SBL Knowledge Reader`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「LangGraph runtime」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`LangGraph runtime 丟失 SourceRef/ACL→RETRIEVAL_PROVENANCE_FAIL`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-163` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-164｜TECH_ID:354 — extra swarm framework

- **來源身份**：`R15.1:L657`；owner：`SBL Scoped Context Reader`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「extra swarm framework」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`extra swarm framework 未取證仍顯示 resumed → CHECKPOINT_NO_EVIDENCE`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-164` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-165｜TECH_ID:355 — reviewer voting cluster

- **來源身份**：`R15.1:L658`；owner：`Independent Assurance Reader`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「reviewer voting cluster」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`reviewer voting cluster 無負例卻自行宣告 PASS→EVALUATOR_PROXY_FAIL`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-165` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-166｜TECH_ID:356 — AutoCompact method

- **來源身份**：`R15.1:L659`；owner：`SBL Reuse Scout`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `AutoCompact method` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`AutoCompact method 無 FeatureDiff 直接成為 Default→ADMISSION_MISSING` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-166` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-167｜TECH_ID:357 — Harness Primitives / STITCH idea

- **來源身份**：`R15.1:L660`；owner：`SBL Scoped Context Reader`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Harness Primitives / STITCH idea` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`Harness Primitives / STITCH idea 未取證仍顯示 resumed → CHECKPOINT_NO_EVIDENCE` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-167` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-168｜TECH_ID:358 — RuleEvolve

- **來源身份**：`R15.1:L661`；owner：`SBL Reuse Scout`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `RuleEvolve` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`RuleEvolve 無 FeatureDiff 直接成為 Default→ADMISSION_MISSING` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-168` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-169｜TECH_ID:359 — A2A for local subagents

- **來源身份**：`R15.1:L662`；owner：`Host Interop Gateway`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `A2A for local subagents` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`unauthenticated agent message→A2A_TRUST_DENIED` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-169` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-170｜TECH_ID:PD06-01 — Mem0

- **來源身份**：`R15.1:L663`；owner：`Memory Privacy Owner`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Mem0` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`secret persistence or forgotten provenance→MEMORY_POLICY_DENIED` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-170` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-171｜TECH_ID:PD06-02 — Letta

- **來源身份**：`R15.1:L664`；owner：`Memory Privacy Owner`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Letta` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`durable state without consent→MEMORY_CONSENT_MISSING` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-171` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-172｜TECH_ID:PD06-03 — LangGraph

- **來源身份**：`R15.1:L665`；owner：`SBL Knowledge Reader`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `LangGraph` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`LangGraph 丟失 SourceRef/ACL→RETRIEVAL_PROVENANCE_FAIL` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-172` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-173｜TECH_ID:PD06-04 — LlamaIndex

- **來源身份**：`R15.1:L666`；owner：`SBL Reuse Scout`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `LlamaIndex` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`LlamaIndex 無 FeatureDiff 直接成為 Default→ADMISSION_MISSING` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-173` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-174｜TECH_ID:PD06-05 — Hermes Agent OS

- **來源身份**：`R15.1:L667`；owner：`HGK/Hermes Native Orchestrator`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Hermes Agent OS` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`missing effect nonce or forged runner status→NO_NATIVE_RUNNER` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-174` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-175｜TECH_ID:PD06-06 — DeepSeek Harness

- **來源身份**：`R15.1:L668`；owner：`SBL Scoped Context Reader`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `DeepSeek Harness` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`DeepSeek Harness 未取證仍顯示 resumed → CHECKPOINT_NO_EVIDENCE` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-175` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-176｜TECH_ID:PD06-07 — Codex Harness / OpenAI Agents API

- **來源身份**：`R15.1:L669`；owner：`Agent Host Adapter`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Codex Harness / OpenAI Agents API` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`SDK sample elevated to Plugin 1.0 Approval→SDK_PLUGIN_CONFUSION` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-176` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-177｜TECH_ID:PD06-08 — Pi Agent Harness

- **來源身份**：`R15.1:L670`；owner：`SBL Scoped Context Reader`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Pi Agent Harness` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`Pi Agent Harness 未取證仍顯示 resumed → CHECKPOINT_NO_EVIDENCE` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-177` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-178｜TECH_ID:PD06-09 — MCP

- **來源身份**：`R15.1:L671`；owner：`Host Tool Gateway`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `MCP` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`tool-list method grants elevated scope→MCP_SCOPE_DENIED` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-178` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-179｜TECH_ID:PD06-10 — A2A

- **來源身份**：`R15.1:L672`；owner：`Host Interop Gateway`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `A2A` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`unauthenticated agent message→A2A_TRUST_DENIED` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-179` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-180｜TECH_ID:PD06-11 — Agent Skills

- **來源身份**：`R15.1:L673`；owner：`SBL Host Adapter`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Agent Skills` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`format valid but host unloaded→HOST_NOT_LOADED` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-180` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-181｜TECH_ID:PD06-12 — OpenTelemetry Semantic Conventions

- **來源身份**：`R15.1:L674`；owner：`Ops Observability Reader`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `OpenTelemetry Semantic Conventions` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`evidence SHA derived from trace proxy→PROXY_EVIDENCE_DENIED` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-181` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-182｜TECH_ID:PD06-13 — OpenSpec

- **來源身份**：`R15.1:L675`；owner：`SBL SpecDelta Consumer`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `OpenSpec` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`stale source revision→NACK_SCOPE` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-182` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-183｜TECH_ID:PD06-14 — GitHub Spec Kit

- **來源身份**：`R15.1:L676`；owner：`SBL SPEC / TPM`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `GitHub Spec Kit` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`unversioned extension or Constitution overwrite→NACK_AUTHORITY` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-183` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-184｜TECH_ID:PD06-15 — gstack

- **來源身份**：`R15.1:L677`；owner：`SBL Review & Challenge`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `gstack` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`self-issued independent PASS→MAKER_SELF_ACCEPT` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-184` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-185｜TECH_ID:PD06-16 — GSD

- **來源身份**：`R15.1:L678`；owner：`SBL Milestone/Resume`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `GSD` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`archived source treated as current installer→ARCHIVED_SOURCE_DENIED` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-185` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-186｜TECH_ID:PD06-17 — Superpowers

- **來源身份**：`R15.1:L679`；owner：`Commander / HGK`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Superpowers` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`no executed RED on old HEAD→NACK_RED_PHASE` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-186` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-187｜TECH_ID:PD06-18 — mattpocock-skills

- **來源身份**：`R15.1:L680`；owner：`TPM Skill method reader`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `mattpocock-skills` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`harness Skill tool absent→HOST_DEPENDENCY_FALLBACK` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-187` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-188｜TECH_ID:PD06-19 — PostgreSQL

- **來源身份**：`R15.1:L681`；owner：`Knowledge Data Owner`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `PostgreSQL` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`tenant leakage or migration loss→DB_MIGRATION_DENIED` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-188` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-189｜TECH_ID:PD06-20 — SQLite

- **來源身份**：`R15.1:L682`；owner：`Knowledge/State Baseline`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `SQLite` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`index corruption/row orphan→FTS_PROVENANCE_FAIL` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-189` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-190｜TECH_ID:PD06-21 — Qdrant

- **來源身份**：`R15.1:L683`；owner：`Knowledge Retrieval Owner`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Qdrant` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`cross-tenant search result→RETRIEVAL_ACL_DENIED` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-190` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-191｜TECH_ID:PD06-22 — Neo4j

- **來源身份**：`R15.1:L684`；owner：`Knowledge Graph Owner`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Neo4j` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`ontology becomes second canonical→GRAPH_WRITER_CONFLICT` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-191` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-192｜TECH_ID:PD06-23 — Weaviate

- **來源身份**：`R15.1:L685`；owner：`Knowledge Retrieval Owner`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Weaviate` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`object class mismatch→VECTOR_SCHEMA_MISMATCH` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-192` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-193｜TECH_ID:PD06-24 — pgvector

- **來源身份**：`R15.1:L686`；owner：`Knowledge Retrieval Owner`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `pgvector` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`embedding dimension drift→VECTOR_DIM_MISMATCH` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-193` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-194｜TECH_ID:PD06-25 — Redis

- **來源身份**：`R15.1:L687`；owner：`Session State Owner`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Redis` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`cache treated as source of truth→CACHE_AUTHORITY_BYPASS` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-194` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-195｜TECH_ID:PD06-26 — Chroma

- **來源身份**：`R15.1:L688`；owner：`Knowledge Retrieval Owner`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Chroma` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`original REJECT alias promoted→CANONICAL_REJECTED` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-195` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-196｜TECH_ID:PD06-27 — Milvus

- **來源身份**：`R15.1:L689`；owner：`Knowledge Retrieval Owner`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Milvus` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`unjustified scale complexity→CAPABILITY_NO_FIT` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-196` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-197｜TECH_ID:PD06-28 — Ragas

- **來源身份**：`R15.1:L690`；owner：`Knowledge Eval Reader`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Ragas` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`score without source citations→RAG_PROXY_PASS` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-197` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-198｜TECH_ID:PD06-29 — DeepEval

- **來源身份**：`R15.1:L691`；owner：`Eval Runner`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `DeepEval` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`judge-only no gold sample→EVAL_GOLD_MISSING` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-198` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-199｜TECH_ID:PD06-30 — Arize Phoenix

- **來源身份**：`R15.1:L692`；owner：`Eval Orchestrator`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Arize Phoenix` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`judge metric alone accepted→LLM_JUDGE_PROXY` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-199` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-200｜TECH_ID:PD06-31 — Hindsight (DEFER_W4 unless exact mandatory W3 gap).

- **來源身份**：`R15.1:L693`；owner：`Memory Privacy Owner`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Hindsight (DEFER_W4 unless exact mandatory W3 gap).` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`W4-deferred promoted into W3→DEFERRED_ACTIVATION_DENIED` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-200` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-201｜TECH_ID:TECH-01 — TECH-01 Windows App SDK

- **來源身份**：`R15.1:L694`；owner：`Windows Desktop Host`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `TECH-01 Windows App SDK` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`non-Windows host tries native WinRT→WINDOWS_HOST_UNSUPPORTED` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-201` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-202｜TECH_ID:TECH-02 — TECH-02 AppLifecycle + AppInstance

- **來源身份**：`R15.1:L695`；owner：`Windows Host App Instance`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `TECH-02 AppLifecycle + AppInstance` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`activation from untrusted URI→ACTIVATION_INPUT_DENIED` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-202` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-203｜TECH_ID:TECH-03 — TECH-03 IExplorerCommand / shell seam

- **來源身份**：`R15.1:L696`；owner：`Explorer Shell Owner`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `TECH-03 IExplorerCommand / shell seam` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`UNC/symlink traversal→SHELL_PATH_DENIED` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-203` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-204｜TECH_ID:TECH-04 — TECH-04 external-location / sparse package identity

- **來源身份**：`R15.1:L697`；owner：`Windows Package Owner`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `TECH-04 external-location / sparse package identity` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`unsigned external location→PACKAGE_TRUST_DENIED` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-204` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-205｜TECH_ID:TECH-05 — TECH-05 Full MSIX

- **來源身份**：`R15.1:L698`；owner：`Windows Package Owner`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `TECH-05 Full MSIX` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`package signature invalid→INSTALL_SIGNATURE_DENIED` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-205` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-206｜TECH_ID:TECH-06 — TECH-06 WinUI 3

- **來源身份**：`R15.1:L699`；owner：`Windows UX Host`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `TECH-06 WinUI 3` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`inaccessible critical CTA→UIA_ACCESSIBILITY_FAIL` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-206` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-207｜TECH_ID:TECH-07 — TECH-07 Microsoft UI Automation

- **來源身份**：`R15.1:L700`；owner：`Windows UI Test`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `TECH-07 Microsoft UI Automation` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`UI-only screenshot passed as interaction→UI_TEST_PROXY` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-207` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-208｜TECH_ID:TECH-08 — TECH-08 AG-UI

- **來源身份**：`R15.1:L701`；owner：`UI Adapter`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `TECH-08 AG-UI` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`transport event treated as permission→TRANSPORT_PERMISSION_CONFUSION` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-208` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-209｜TECH_ID:TECH-09 — TECH-09 A2UI current production line

- **來源身份**：`R15.1:L702`；owner：`UI Adapter`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `TECH-09 A2UI current production line` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`candidate UI schema activated without host test→A2UI_VERSION_UNQUALIFIED` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-209` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-210｜TECH_ID:TECH-10 — TECH-10 A2UI next/candidate line

- **來源身份**：`R15.1:L703`；owner：`UI Adapter`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `TECH-10 A2UI next/candidate line` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`candidate UI schema activated without host test→A2UI_VERSION_UNQUALIFIED` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-210` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-211｜TECH_ID:TECH-11 — TECH-11 OpenTelemetry Semantic Conventions

- **來源身份**：`R15.1:L704`；owner：`Ops Observability Reader`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `TECH-11 OpenTelemetry Semantic Conventions` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`evidence SHA derived from trace proxy→PROXY_EVIDENCE_DENIED` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-211` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-212｜TECH_ID:TECH-12 — TECH-12 OpenTelemetry Session Semantics

- **來源身份**：`R15.1:L705`；owner：`Ops Observability Reader`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `TECH-12 OpenTelemetry Session Semantics` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`evidence SHA derived from trace proxy→PROXY_EVIDENCE_DENIED` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-212` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-213｜TECH_ID:TECH-13 — TECH-13 MCP

- **來源身份**：`R15.1:L706`；owner：`Host Tool Gateway`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `TECH-13 MCP` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`tool-list method grants elevated scope→MCP_SCOPE_DENIED` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-213` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-214｜TECH_ID:TECH-14 — TECH-14 A2A

- **來源身份**：`R15.1:L707`；owner：`Host Interop Gateway`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `TECH-14 A2A` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`unauthenticated agent message→A2A_TRUST_DENIED` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-214` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-215｜TECH_ID:TECH-15 — TECH-15 OpenAI Agents SDK HITL / resumable-state donor pattern

- **來源身份**：`R15.1:L708`；owner：`Agent Host Adapter`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `TECH-15 OpenAI Agents SDK HITL / resumable-state donor pattern` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`SDK sample elevated to Plugin 1.0 Approval→SDK_PLUGIN_CONFUSION` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-215` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-216｜TECH_ID:TECH-16 — TECH-16 Windows named pipe

- **來源身份**：`R15.1:L709`；owner：`Windows IPC Owner`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `TECH-16 Windows named pipe` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`world-writable endpoint→IPC_ACL_DENIED` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-216` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-217｜TECH_ID:TECH-17 — TECH-17 Electron / Tauri alternate host (DEFER_BY_BLOCKER).

- **來源身份**：`R15.1:L710`；owner：`Windows Host/Product Owner`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `TECH-17 Electron / Tauri alternate host (DEFER_BY_BLOCKER).` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`DEFER_BY_BLOCKER bypass→DEFERRED_HOST_DENIED` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-217` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-218｜TECH_ID:SUPPLY-01 — Syft

- **來源身份**：`R15.1:L711`；owner：`Build Supply Consumer`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Syft` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`SBOM not tied to exact build digest→SBOM_SUBJECT_MISMATCH` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-218` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-219｜TECH_ID:SUPPLY-02 — Trivy

- **來源身份**：`R15.1:L712`；owner：`Security/Supply Chain CI`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Trivy` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`empty scan from invalid target→SCAN_TARGET_UNKNOWN` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-219` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-220｜TECH_ID:SUPPLY-03 — Grype

- **來源身份**：`R15.1:L713`；owner：`Supply Chain CI`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Grype` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`SBOM subject hash mismatch→SBOM_FOREIGN_SUBJECT` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-220` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-221｜TECH_ID:SUPPLY-04 — OSV-Scanner

- **來源身份**：`R15.1:L714`；owner：`Supply Security Reader`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `OSV-Scanner` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`package coordinates absent→ADVISORY_UNBOUND` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-221` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-222｜TECH_ID:SUPPLY-05 — Cosign

- **來源身份**：`R15.1:L715`；owner：`Publisher + separate Verifier`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Cosign` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`self-signed wrong digest→SIGNATURE_SUBJECT_MISMATCH` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-222` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-223｜TECH_ID:SUPPLY-06 — Semgrep

- **來源身份**：`R15.1:L716`；owner：`Security CI`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Semgrep` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`untrusted rule set auto-accepted→RULE_PIN_MISSING` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-223` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-224｜TECH_ID:SUPPLY-07 — Gitleaks

- **來源身份**：`R15.1:L717`；owner：`Security CI`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Gitleaks` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`secret hit suppressed without owner exception→SECRET_POLICY_DENIED` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-224` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-225｜TECH_ID:SUPPLY-08 — OPA/Rego

- **來源身份**：`R15.1:L718`；owner：`Native Policy Owner`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `OPA/Rego` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`rule context incomplete→POLICY_INPUT_MISSING` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-225` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-226｜TECH_ID:SUPPLY-09 — OpenTelemetry Collector

- **來源身份**：`R15.1:L719`；owner：`Ops Observability Reader`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `OpenTelemetry Collector` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`evidence SHA derived from trace proxy→PROXY_EVIDENCE_DENIED` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-226` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-227｜TECH_ID:SUPPLY-10 — SPDX

- **來源身份**：`R15.1:L720`；owner：`Supply Chain Normalizer`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `SPDX` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`invalid package relationship→SPDX_RELATION_INVALID` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-227` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-228｜TECH_ID:SUPPLY-11 — CycloneDX

- **來源身份**：`R15.1:L721`；owner：`Supply Chain Normalizer`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `CycloneDX` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`wrong schema/subject→SBOM_SCHEMA_FAIL` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-228` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-229｜TECH_ID:SUPPLY-12 — TUF

- **來源身份**：`R15.1:L722`；owner：`Native Release Owner`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `TUF` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`expired target metadata→TUF_METADATA_EXPIRED` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-229` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-230｜TECH_ID:SUPPLY-13 — OpenSSF Scorecard

- **來源身份**：`R15.1:L723`；owner：`Security Admission`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `OpenSSF Scorecard` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`score alone treated as PASS→SCORECARD_PROXY_PASS` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-230` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-231｜TECH_ID:SUPPLY-14 — GitHub Artifact Attestations

- **來源身份**：`R15.1:L724`；owner：`GitHub Release Verifier`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `GitHub Artifact Attestations` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`foreign artifact attestation→ATTESTATION_FOREIGN` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-231` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-232｜TECH_ID:SUPPLY-15 — ORAS

- **來源身份**：`R15.1:L725`；owner：`Registry Adapter`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `ORAS` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`tag only without digest→REGISTRY_TAG_DRIFT` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-232` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-233｜TECH_ID:SUPPLY-16 — Harbor

- **來源身份**：`R15.1:L726`；owner：`Registry Owner`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Harbor` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`unsigned artifact promoted→REGISTRY_POLICY_DENIED` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-233` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-234｜TECH_ID:SUPPLY-17 — GitHub Actions/OIDC.

- **來源身份**：`R15.1:L727`；owner：`CI Evidence Producer`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `GitHub Actions/OIDC.` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`fork PR secret elevation→CI_TRUST_BOUNDARY` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-234` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-235｜TECH_ID:P0-TOOL-001 — Hermes Agent

- **來源身份**：`R15.1:L728`；owner：`HGK/Hermes Native Orchestrator`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Hermes Agent` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`missing effect nonce or forged runner status→NO_NATIVE_RUNNER` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-235` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-236｜TECH_ID:P0-TOOL-002 — SDLC_PRW

- **來源身份**：`R15.1:L729`；owner：`TPM-SP / PIPD`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `SDLC_PRW` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`unbound phase transition→LIFECYCLE_CONFLICT` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-236` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-237｜TECH_ID:P0-TOOL-003 — SRU Kernel

- **來源身份**：`R15.1:L730`；owner：`HGK-SRU Native`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `SRU Kernel` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`resume without exact nonce→REPLAY_DENIED` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-237` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-238｜TECH_ID:P0-TOOL-004 — DocETL

- **來源身份**：`R15.1:L731`；owner：`TPM Knowledge Consumer`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `DocETL` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`truncated or mixed-source chunk→PROVENANCE_MISSING` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-238` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-239｜TECH_ID:P0-TOOL-005 — Codex

- **來源身份**：`R15.1:L732`；owner：`HGK coding worker / scoped agent`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Codex` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`write outside writable_scope→WRITESET_DENIED` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-239` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-240｜TECH_ID:P0-TOOL-006 — OpenCode

- **來源身份**：`R15.1:L733`；owner：`HGK separate fallback diagnostic`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `OpenCode` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`conflicted primary writer→PARALLEL_WRITER_DENIED` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-240` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-241｜TECH_ID:P0-TOOL-007 — Obsidian

- **來源身份**：`R15.1:L734`；owner：`Human local reader`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Obsidian」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`Obsidian vault treated as canonical DB→WRITER_CONFLICT`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-241` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-242｜TECH_ID:P0-TOOL-008 — LLM Wiki

- **來源身份**：`R15.1:L735`；owner：`TPM/Knowledge Wiki Reader`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `LLM Wiki` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`citation without source offset→GROUNDING_MISSING` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-242` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-243｜TECH_ID:P0-TOOL-009 — Typed Knowledge Graph

- **來源身份**：`R15.1:L736`；owner：`SBL knowledge projection`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Typed Knowledge Graph` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`claim graph as Native ontology→OWNER_SCOPE_DENIED` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-243` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-244｜TECH_ID:P0-TOOL-010 — Spec Kit

- **來源身份**：`R15.1:L737`；owner：`SBL SPEC / TPM`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Spec Kit` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`unversioned extension or Constitution overwrite→NACK_AUTHORITY` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-244` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-245｜TECH_ID:P0-TOOL-011 — OpenSpec

- **來源身份**：`R15.1:L738`；owner：`SBL SpecDelta Consumer`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `OpenSpec` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`stale source revision→NACK_SCOPE` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-245` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-246｜TECH_ID:P0-TOOL-012 — GSD Core

- **來源身份**：`R15.1:L739`；owner：`SBL Milestone/Resume`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「GSD Core」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`archived source treated as current installer→ARCHIVED_SOURCE_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-246` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-247｜TECH_ID:P0-TOOL-013 — GSD Pi

- **來源身份**：`R15.1:L740`；owner：`SBL Milestone/Resume`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「GSD Pi」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`archived source treated as current installer→ARCHIVED_SOURCE_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-247` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-248｜TECH_ID:P0-TOOL-014 — get-shit-done

- **來源身份**：`R15.1:L741`；owner：`SBL Reuse Scout`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「get-shit-done」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`get-shit-done 無 FeatureDiff 直接成為 Default→ADMISSION_MISSING`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-248` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-249｜TECH_ID:P0-TOOL-015 — gsd-2

- **來源身份**：`R15.1:L742`；owner：`SBL Milestone/Resume`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「gsd-2」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`archived source treated as current installer→ARCHIVED_SOURCE_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-249` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-250｜TECH_ID:P0-TOOL-016 — mattpocock-skills v1.1

- **來源身份**：`R15.1:L743`；owner：`TPM Skill method reader`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `mattpocock-skills v1.1` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`harness Skill tool absent→HOST_DEPENDENCY_FALLBACK` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-250` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-251｜TECH_ID:P0-TOOL-017 — Grill Me

- **來源身份**：`R15.1:L744`；owner：`TPM interview`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Grill Me` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`duplicate question→NACK_DUPLICATE_QUESTION` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-251` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-252｜TECH_ID:P0-TOOL-018 — grill-with-docs

- **來源身份**：`R15.1:L745`；owner：`TPM interview`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「grill-with-docs」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`unknown referenced SKILL path→NACK_DEPENDENCY`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-252` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-253｜TECH_ID:P0-TOOL-019 — planning-with-files

- **來源身份**：`R15.1:L746`；owner：`SBL Reuse Scout`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「planning-with-files」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`planning-with-files 無 FeatureDiff 直接成為 Default→ADMISSION_MISSING`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-253` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-254｜TECH_ID:P0-TOOL-020 — Superpowers

- **來源身份**：`R15.1:L747`；owner：`Commander / HGK`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Superpowers` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`no executed RED on old HEAD→NACK_RED_PHASE` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-254` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-255｜TECH_ID:P0-TOOL-021 — gstack

- **來源身份**：`R15.1:L748`；owner：`SBL Review & Challenge`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「gstack」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`self-issued independent PASS→MAKER_SELF_ACCEPT`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-255` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-256｜TECH_ID:P0-TOOL-022 — Nature Skills

- **來源身份**：`R15.1:L749`；owner：`SBL Host/Procedure Reader`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Nature Skills」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`Nature Skills 越權到 Host token/Policy Writer→HOST_AUTH_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-256` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-257｜TECH_ID:P0-TOOL-023 — Zotero

- **來源身份**：`R15.1:L750`；owner：`SBL Reuse Scout`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Zotero」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`Zotero 無 FeatureDiff 直接成為 Default→ADMISSION_MISSING`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-257` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-258｜TECH_ID:P0-TOOL-024 — Agent Skills

- **來源身份**：`R15.1:L751`；owner：`SBL Host Adapter`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Agent Skills` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`format valid but host unloaded→HOST_NOT_LOADED` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-258` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-259｜TECH_ID:P0-TOOL-025 — Model Context Protocol

- **來源身份**：`R15.1:L752`；owner：`SBL Scoped Context Reader`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Model Context Protocol` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`Model Context Protocol 未取證仍顯示 resumed → CHECKPOINT_NO_EVIDENCE` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-259` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-260｜TECH_ID:P0-TOOL-026 — AGENTS.md

- **來源身份**：`R15.1:L753`；owner：`Codex host loader`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `AGENTS.md` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`AGENTS tries to confer tool permission→INSTRUCTION_PRIVILEGE` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-260` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-261｜TECH_ID:P0-TOOL-027 — CLAUDE.md

- **來源身份**：`R15.1:L754`；owner：`Claude host loader`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「CLAUDE.md」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`host scope traversal→HOST_SCOPE_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-261` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-262｜TECH_ID:P0-TOOL-028 — DESIGN.md

- **來源身份**：`R15.1:L755`；owner：`TPM design reader`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `DESIGN.md` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`DESIGN.md claims approval token→NACK_AUTHORITY` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-262` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-263｜TECH_ID:P0-TOOL-029 — AutoResearch

- **來源身份**：`R15.1:L756`；owner：`SBL Reuse Scout`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「AutoResearch」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`AutoResearch 無 FeatureDiff 直接成為 Default→ADMISSION_MISSING`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-263` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-264｜TECH_ID:P0-TOOL-030 — Loop Engineering

- **來源身份**：`R15.1:L757`；owner：`SBL Reuse Scout`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Loop Engineering` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`Loop Engineering 無 FeatureDiff 直接成為 Default→ADMISSION_MISSING` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-264` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-265｜TECH_ID:P0-TOOL-031 — Harness Engineering

- **來源身份**：`R15.1:L758`；owner：`SBL Scoped Context Reader`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Harness Engineering` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`Harness Engineering 未取證仍顯示 resumed → CHECKPOINT_NO_EVIDENCE` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-265` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-266｜TECH_ID:P0-TOOL-032 — Multi-Agent

- **來源身份**：`R15.1:L759`；owner：`SBL Host/Procedure Reader`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Multi-Agent` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`Multi-Agent 越權到 Host token/Policy Writer→HOST_AUTH_DENIED` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-266` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-267｜TECH_ID:P0-TOOL-033 — Agent Swarm

- **來源身份**：`R15.1:L760`；owner：`SBL Scoped Context Reader`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Agent Swarm」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`Agent Swarm 未取證仍顯示 resumed → CHECKPOINT_NO_EVIDENCE`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-267` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-268｜TECH_ID:P0-TOOL-034 — Sub-Agent

- **來源身份**：`R15.1:L761`；owner：`SBL Host/Procedure Reader`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Sub-Agent` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`Sub-Agent 越權到 Host token/Policy Writer→HOST_AUTH_DENIED` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-268` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-269｜TECH_ID:P0-TOOL-035 — OpenHands / Agent Canvas

- **來源身份**：`R15.1:L762`；owner：`SBL Host/Procedure Reader`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「OpenHands / Agent Canvas」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`OpenHands / Agent Canvas 越權到 Host token/Policy Writer→HOST_AUTH_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-269` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-270｜TECH_ID:P0-TOOL-036 — Microsoft Agent Framework

- **來源身份**：`R15.1:L763`；owner：`SBL Host/Procedure Reader`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Microsoft Agent Framework」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`Microsoft Agent Framework 越權到 Host token/Policy Writer→HOST_AUTH_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-270` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-271｜TECH_ID:P0-TOOL-037 — AutoGen

- **來源身份**：`R15.1:L764`；owner：`SBL Reuse Scout`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「AutoGen」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`AutoGen 無 FeatureDiff 直接成為 Default→ADMISSION_MISSING`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-271` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-272｜TECH_ID:P0-TOOL-038 — Semantic Kernel

- **來源身份**：`R15.1:L765`；owner：`SBL Reuse Scout`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Semantic Kernel」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`Semantic Kernel 無 FeatureDiff 直接成為 Default→ADMISSION_MISSING`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-272` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-273｜TECH_ID:P0-TOOL-039 — LangGraph

- **來源身份**：`R15.1:L766`；owner：`SBL Knowledge Reader`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「LangGraph」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`LangGraph 丟失 SourceRef/ACL→RETRIEVAL_PROVENANCE_FAIL`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-273` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-274｜TECH_ID:P0-TOOL-040 — CrewAI

- **來源身份**：`R15.1:L767`；owner：`SBL Reuse Scout`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「CrewAI」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`CrewAI 無 FeatureDiff 直接成為 Default→ADMISSION_MISSING`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-274` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-275｜TECH_ID:P0-TOOL-041 — n8n

- **來源身份**：`R15.1:L768`；owner：`SBL Reuse Scout`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「n8n」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`n8n 無 FeatureDiff 直接成為 Default→ADMISSION_MISSING`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-275` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-276｜TECH_ID:P0-TOOL-042 — Dify

- **來源身份**：`R15.1:L769`；owner：`SBL Reuse Scout`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Dify」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`Dify 無 FeatureDiff 直接成為 Default→ADMISSION_MISSING`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-276` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-277｜TECH_ID:P0-TOOL-043 — RAGFlow

- **來源身份**：`R15.1:L770`；owner：`SBL Knowledge Reader`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「RAGFlow」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`RAGFlow 丟失 SourceRef/ACL→RETRIEVAL_PROVENANCE_FAIL`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-277` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-278｜TECH_ID:P0-TOOL-044 — WeKnora

- **來源身份**：`R15.1:L771`；owner：`SBL Reuse Scout`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「WeKnora」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`WeKnora 無 FeatureDiff 直接成為 Default→ADMISSION_MISSING`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-278` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-279｜TECH_ID:P0-TOOL-045 — LightRAG

- **來源身份**：`R15.1:L772`；owner：`SBL Knowledge Reader`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「LightRAG」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`LightRAG 丟失 SourceRef/ACL→RETRIEVAL_PROVENANCE_FAIL`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-279` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-280｜TECH_ID:P0-TOOL-046 — GraphRAG

- **來源身份**：`R15.1:L773`；owner：`SBL Knowledge Reader`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「GraphRAG」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`GraphRAG 丟失 SourceRef/ACL→RETRIEVAL_PROVENANCE_FAIL`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-280` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-281｜TECH_ID:P0-TOOL-047 — Qdrant

- **來源身份**：`R15.1:L774`；owner：`Knowledge Retrieval Owner`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Qdrant」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`cross-tenant search result→RETRIEVAL_ACL_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-281` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-282｜TECH_ID:P0-TOOL-048 — pgvector

- **來源身份**：`R15.1:L775`；owner：`Knowledge Retrieval Owner`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「pgvector」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`embedding dimension drift→VECTOR_DIM_MISMATCH`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-282` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-283｜TECH_ID:P0-TOOL-049 — Milvus

- **來源身份**：`R15.1:L776`；owner：`Knowledge Retrieval Owner`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Milvus」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`unjustified scale complexity→CAPABILITY_NO_FIT`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-283` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-284｜TECH_ID:P0-TOOL-050 — Chroma

- **來源身份**：`R15.1:L777`；owner：`Knowledge Retrieval Owner`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Chroma」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`original REJECT alias promoted→CANONICAL_REJECTED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-284` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-285｜TECH_ID:P0-TOOL-051 — Neo4j

- **來源身份**：`R15.1:L778`；owner：`Knowledge Graph Owner`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Neo4j」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`ontology becomes second canonical→GRAPH_WRITER_CONFLICT`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-285` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-286｜TECH_ID:P0-TOOL-052 — Temporal

- **來源身份**：`R15.1:L779`；owner：`Future Platform Owner`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Temporal」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`second workflow control plane→PARALLEL_CONTROL_PLANE`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-286` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-287｜TECH_ID:P0-TOOL-053 — OpenTelemetry

- **來源身份**：`R15.1:L780`；owner：`Ops Observability Reader`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `OpenTelemetry` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`evidence SHA derived from trace proxy→PROXY_EVIDENCE_DENIED` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-287` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-288｜TECH_ID:P0-TOOL-054 — Sentry

- **來源身份**：`R15.1:L781`；owner：`SRE Incident Reader`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Sentry」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`source map or version missing→INCIDENT_PROVENANCE_GAP`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-288` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-289｜TECH_ID:P0-TOOL-055 — SWE-bench

- **來源身份**：`R15.1:L782`；owner：`SBL Reuse Scout`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「SWE-bench」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`SWE-bench 無 FeatureDiff 直接成為 Default→ADMISSION_MISSING`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-289` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-290｜TECH_ID:P0-TOOL-056 — OSWorld

- **來源身份**：`R15.1:L783`；owner：`SBL Reuse Scout`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「OSWorld」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`OSWorld 無 FeatureDiff 直接成為 Default→ADMISSION_MISSING`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-290` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-291｜TECH_ID:P0-TOOL-057 — Terminal-Bench

- **來源身份**：`R15.1:L784`；owner：`SBL Reuse Scout`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Terminal-Bench」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`Terminal-Bench 無 FeatureDiff 直接成為 Default→ADMISSION_MISSING`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-291` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-292｜TECH_ID:P0-TOOL-058 — Promptfoo

- **來源身份**：`R15.1:L785`；owner：`Security Evaluator`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Promptfoo」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`no negatives yet PASS→NEGATIVE_FIXTURE_MISSING`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-292` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-293｜TECH_ID:P0-TOOL-059 — Semgrep

- **來源身份**：`R15.1:L786`；owner：`Security CI`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Semgrep` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`untrusted rule set auto-accepted→RULE_PIN_MISSING` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-293` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-294｜TECH_ID:P0-TOOL-060 — CodeQL

- **來源身份**：`R15.1:L787`；owner：`Security CI`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `CodeQL` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`CodeQL query pack unpinned→QUERY_PACK_UNTRUSTED` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-294` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-295｜TECH_ID:P0-TOOL-061 — Trivy

- **來源身份**：`R15.1:L788`；owner：`Security/Supply Chain CI`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Trivy` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`empty scan from invalid target→SCAN_TARGET_UNKNOWN` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-295` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-296｜TECH_ID:P0-TOOL-062 — GitHub Actions

- **來源身份**：`R15.1:L789`；owner：`CI Evidence Producer`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `GitHub Actions` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`fork PR secret elevation→CI_TRUST_BOUNDARY` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-296` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-297｜TECH_ID:P0-TOOL-063 — OpenSSF Scorecard

- **來源身份**：`R15.1:L790`；owner：`Security Admission`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `OpenSSF Scorecard` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`score alone treated as PASS→SCORECARD_PROXY_PASS` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-297` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-298｜TECH_ID:P0-TOOL-064 — SBOM

- **來源身份**：`R15.1:L791`；owner：`SBL Reuse Scout`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `SBOM` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`SBOM 無 FeatureDiff 直接成為 Default→ADMISSION_MISSING` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-298` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-299｜TECH_ID:P0-TOOL-065 — Artifact Attestation

- **來源身份**：`R15.1:L792`；owner：`Independent Assurance Reader`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Artifact Attestation` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`Artifact Attestation 無負例卻自行宣告 PASS→EVALUATOR_PROXY_FAIL` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-299` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-300｜TECH_ID:P0-TOOL-066 — SLSA

- **來源身份**：`R15.1:L793`；owner：`Release Owner`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「SLSA」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`no actual builder provenance→SLSA_NO_ATTESTATION`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-300` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-301｜TECH_ID:P0-TOOL-067 — Sigstore

- **來源身份**：`R15.1:L794`；owner：`Supply Chain Owner`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Sigstore」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`issuer subject claim mismatch→SIGNER_IDENTITY_FAIL`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-301` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-302｜TECH_ID:P0-TOOL-068 — OSV

- **來源身份**：`R15.1:L795`；owner：`Supply Security Reader`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `OSV` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`package coordinates absent→ADVISORY_UNBOUND` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-302` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-303｜TECH_ID:P0-TOOL-069 — Docker

- **來源身份**：`R15.1:L796`；owner：`Native Build Owner`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Docker」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`docker sock grants host root→CONTAINER_ESCAPE_RISK`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-303` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-304｜TECH_ID:P0-TOOL-070 — Kubernetes

- **來源身份**：`R15.1:L797`；owner：`Future Platform Owner`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Kubernetes」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`deferred distributed platform turned on→DEFERRED_ARCH_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-304` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-305｜TECH_ID:P0-TOOL-071 — Nix

- **來源身份**：`R15.1:L798`；owner：`Environment Owner`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Nix」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`unlocked derivation→ENV_NONREPRODUCIBLE`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-305` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-306｜TECH_ID:P0-TOOL-072 — SQLite

- **來源身份**：`R15.1:L799`；owner：`Knowledge/State Baseline`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `SQLite` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`index corruption/row orphan→FTS_PROVENANCE_FAIL` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-306` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-307｜TECH_ID:P0-TOOL-073 — PostgreSQL

- **來源身份**：`R15.1:L800`；owner：`Knowledge Data Owner`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「PostgreSQL」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`tenant leakage or migration loss→DB_MIGRATION_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-307` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-308｜TECH_ID:P0-TOOL-074 — gbrain

- **來源身份**：`R15.1:L801`；owner：`SBL Reuse Scout`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「gbrain」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`gbrain 無 FeatureDiff 直接成為 Default→ADMISSION_MISSING`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-308` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-309｜TECH_ID:P0-TOOL-075 — hindsight

- **來源身份**：`R15.1:L802`；owner：`Memory Privacy Owner`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「hindsight」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`W4-deferred promoted into W3→DEFERRED_ACTIVATION_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-309` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-310｜TECH_ID:P0-TOOL-076 — graphiti

- **來源身份**：`R15.1:L803`；owner：`SBL Knowledge Reader`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「graphiti」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`graphiti 丟失 SourceRef/ACL→RETRIEVAL_PROVENANCE_FAIL`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-310` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-311｜TECH_ID:P0-TOOL-077 — cognee

- **來源身份**：`R15.1:L804`；owner：`SBL Reuse Scout`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「cognee」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`cognee 無 FeatureDiff 直接成為 Default→ADMISSION_MISSING`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-311` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-312｜TECH_ID:P0-TOOL-078 — codegraph_exact_provider

- **來源身份**：`R15.1:L805`；owner：`Code Intelligence Reader`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「codegraph_exact_provider」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`graph old commit→CODE_GRAPH_STALE`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-312` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-313｜TECH_ID:NTD-001 — Obsidian

- **來源身份**：`R15.1:L806`；owner：`Human local reader`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Obsidian」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`Obsidian vault treated as canonical DB→WRITER_CONFLICT`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-313` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-314｜TECH_ID:NTD-002 — Tree-sitter

- **來源身份**：`R15.1:L807`；owner：`Code Intelligence Reader`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Tree-sitter」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`AST position drift→SYNTAX_REV_MISMATCH`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-314` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-315｜TECH_ID:NTD-003 — Language Server Protocol

- **來源身份**：`R15.1:L808`；owner：`Code Intelligence Reader`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Language Server Protocol」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`stale workspace symbol→SYMBOL_STALE`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-315` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-316｜TECH_ID:NTD-004 — CodeGraph

- **來源身份**：`R15.1:L809`；owner：`Code Intelligence Reader`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「CodeGraph」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`graph old commit→CODE_GRAPH_STALE`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-316` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-317｜TECH_ID:NTD-005 — Typer

- **來源身份**：`R15.1:L810`；owner：`CLI Product Factory`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Typer」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`parameter shadowing→CLI_SCHEMA_FAIL`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-317` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-318｜TECH_ID:NTD-006 — Rich

- **來源身份**：`R15.1:L811`；owner：`CLI Product Factory`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Rich」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`color escape corrupts JSON mode→OUTPUT_CONTRACT_FAIL`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-318` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-319｜TECH_ID:NTD-007 — yq

- **來源身份**：`R15.1:L812`；owner：`Config Reader`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「yq」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`unsafe eval shell expansion→YAML_TRUST_BOUNDARY`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-319` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-320｜TECH_ID:NTD-008 — Docker Desktop

- **來源身份**：`R15.1:L813`；owner：`Native Build Owner`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Docker Desktop」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`docker sock grants host root→CONTAINER_ESCAPE_RISK`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-320` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-321｜TECH_ID:NTD-009 — WSL 2

- **來源身份**：`R15.1:L814`；owner：`Windows Local Owner`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「WSL 2」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`drive mount escaping scope→WSL_SCOPE_ESCAPE`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-321` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-322｜TECH_ID:NTD-010 — Spec Kit

- **來源身份**：`R15.1:L815`；owner：`SBL SPEC / TPM`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Spec Kit` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`unversioned extension or Constitution overwrite→NACK_AUTHORITY` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-322` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-323｜TECH_ID:NTD-011 — Grill Me

- **來源身份**：`R15.1:L816`；owner：`TPM interview`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Grill Me` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`duplicate question→NACK_DUPLICATE_QUESTION` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-323` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-324｜TECH_ID:NTD-012 — Grill with Docs

- **來源身份**：`R15.1:L817`；owner：`TPM interview`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Grill with Docs` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`duplicate question→NACK_DUPLICATE_QUESTION` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-324` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-325｜TECH_ID:NTD-013 — Skill Creator

- **來源身份**：`R15.1:L818`；owner：`SBL Host/Procedure Reader`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Skill Creator` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`Skill Creator 越權到 Host token/Policy Writer→HOST_AUTH_DENIED` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-325` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-326｜TECH_ID:NTD-014 — LangGraph

- **來源身份**：`R15.1:L819`；owner：`SBL Knowledge Reader`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「LangGraph」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`LangGraph 丟失 SourceRef/ACL→RETRIEVAL_PROVENANCE_FAIL`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-326` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-327｜TECH_ID:NTD-015 — CrewAI

- **來源身份**：`R15.1:L820`；owner：`SBL Reuse Scout`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「CrewAI」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`CrewAI 無 FeatureDiff 直接成為 Default→ADMISSION_MISSING`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-327` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-328｜TECH_ID:NTD-016 — AutoGen

- **來源身份**：`R15.1:L821`；owner：`SBL Reuse Scout`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「AutoGen」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`AutoGen 無 FeatureDiff 直接成為 Default→ADMISSION_MISSING`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-328` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-329｜TECH_ID:NTD-017 — Semantic Kernel

- **來源身份**：`R15.1:L822`；owner：`SBL Reuse Scout`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Semantic Kernel」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`Semantic Kernel 無 FeatureDiff 直接成為 Default→ADMISSION_MISSING`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-329` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-330｜TECH_ID:NTD-018 — Open Policy Agent

- **來源身份**：`R15.1:L823`；owner：`SBL Host/Procedure Reader`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Open Policy Agent」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`Open Policy Agent 越權到 Host token/Policy Writer→HOST_AUTH_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-330` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-331｜TECH_ID:NTD-019 — Rego

- **來源身份**：`R15.1:L824`；owner：`Native Policy Owner`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Rego」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`rule context incomplete→POLICY_INPUT_MISSING`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-331` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-332｜TECH_ID:NTD-020 — Grype

- **來源身份**：`R15.1:L825`；owner：`Supply Chain CI`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Grype」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`SBOM subject hash mismatch→SBOM_FOREIGN_SUBJECT`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-332` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-333｜TECH_ID:NTD-021 — Cosign

- **來源身份**：`R15.1:L826`；owner：`Publisher + separate Verifier`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Cosign」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`self-signed wrong digest→SIGNATURE_SUBJECT_MISMATCH`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-333` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-334｜TECH_ID:NTD-022 — SLSA

- **來源身份**：`R15.1:L827`；owner：`Release Owner`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `SLSA` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`no actual builder provenance→SLSA_NO_ATTESTATION` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-334` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-335｜TECH_ID:NTD-023 — OpenSSF Scorecard

- **來源身份**：`R15.1:L828`；owner：`Security Admission`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「OpenSSF Scorecard」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`score alone treated as PASS→SCORECARD_PROXY_PASS`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-335` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-336｜TECH_ID:NTD-024 — Grafana Tempo

- **來源身份**：`R15.1:L829`；owner：`SRE Dashboard`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Grafana Tempo」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`dashboard considered authorization→UI_AUTH_CONFUSION`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-336` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-337｜TECH_ID:NTD-025 — Jaeger

- **來源身份**：`R15.1:L830`；owner：`SRE Trace Reader`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Jaeger」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`trace absent treated as no errors→TRACE_GAP`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-337` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-338｜TECH_ID:NTD-026 — Prometheus

- **來源身份**：`R15.1:L831`；owner：`SRE Metrics Reader`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Prometheus」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`metrics not tied subject accepted as test→METRIC_PROXY_FAIL`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-338` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-339｜TECH_ID:NTD-027 — Grafana

- **來源身份**：`R15.1:L832`；owner：`SRE Dashboard`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Grafana」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`dashboard considered authorization→UI_AUTH_CONFUSION`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-339` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-340｜TECH_ID:NTD-028 — Loki

- **來源身份**：`R15.1:L833`；owner：`SRE Logs`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Loki」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`PII dumped into log→LOG_DATA_LEAK`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-340` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-341｜TECH_ID:NTD-029 — Sentry

- **來源身份**：`R15.1:L834`；owner：`SRE Incident Reader`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Sentry」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`source map or version missing→INCIDENT_PROVENANCE_GAP`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-341` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-342｜TECH_ID:NTD-030 — OpenAI API/Models

- **來源身份**：`R15.1:L835`；owner：`SBL Host/Procedure Reader`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「OpenAI API/Models」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`OpenAI API/Models 越權到 Host token/Policy Writer→HOST_AUTH_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-342` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-343｜TECH_ID:NTD-031 — Anthropic API/Models

- **來源身份**：`R15.1:L836`；owner：`SBL Host/Procedure Reader`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Anthropic API/Models」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`Anthropic API/Models 越權到 Host token/Policy Writer→HOST_AUTH_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-343` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-344｜TECH_ID:NTD-032 — Browser/CUA runtime

- **來源身份**：`R15.1:L837`；owner：`SBL Reuse Scout`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Browser/CUA runtime」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`Browser/CUA runtime 無 FeatureDiff 直接成為 Default→ADMISSION_MISSING`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-344` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-345｜TECH_ID:NTD-033 — OpenClaw-like orchestration

- **來源身份**：`R15.1:L838`；owner：`SBL Scoped Context Reader`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「OpenClaw-like orchestration」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`OpenClaw-like orchestration 未取證仍顯示 resumed → CHECKPOINT_NO_EVIDENCE`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-345` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-346｜TECH_ID:NTD-034 — Chroma

- **來源身份**：`R15.1:L839`；owner：`Knowledge Retrieval Owner`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Chroma」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`original REJECT alias promoted→CANONICAL_REJECTED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-346` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-347｜TECH_ID:NTD-035 — pgvector

- **來源身份**：`R15.1:L840`；owner：`Knowledge Retrieval Owner`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「pgvector」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`embedding dimension drift→VECTOR_DIM_MISMATCH`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-347` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-348｜TECH_ID:NTD-036 — GraphRAG

- **來源身份**：`R15.1:L841`；owner：`SBL Knowledge Reader`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `GraphRAG` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`GraphRAG 丟失 SourceRef/ACL→RETRIEVAL_PROVENANCE_FAIL` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-348` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-349｜TECH_ID:NTD-037 — TypeScript compiler

- **來源身份**：`R15.1:L842`；owner：`SBL Reuse Scout`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「TypeScript compiler」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`TypeScript compiler 無 FeatureDiff 直接成為 Default→ADMISSION_MISSING`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-349` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-350｜TECH_ID:NTD-038 — Vitest

- **來源身份**：`R15.1:L843`；owner：`Independent Assurance Reader`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Vitest」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`Vitest 無負例卻自行宣告 PASS→EVALUATOR_PROXY_FAIL`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-350` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-351｜TECH_ID:NTD-039 — CodeQL

- **來源身份**：`R15.1:L844`；owner：`Security CI`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「CodeQL」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`CodeQL query pack unpinned→QUERY_PACK_UNTRUSTED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-351` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-352｜TECH_ID:NTD-040 — cdxgen

- **來源身份**：`R15.1:L845`；owner：`SBL Reuse Scout`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「cdxgen」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`cdxgen 無 FeatureDiff 直接成為 Default→ADMISSION_MISSING`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-352` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-353｜TECH_ID:GPTB-KP00-R01 — L369; MUST; Route question to exact KP before answering

- **來源身份**：`R15.1:L846`；owner：`Migration-only / no active writer`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L369; MUST; Route question to exact KP before answering」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP00-R01 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-353` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-354｜TECH_ID:GPTB-KP00-R02 — L370; MUST; Select source group by task kind

- **來源身份**：`R15.1:L847`；owner：`Migration-only / no active writer`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L370; MUST; Select source group by task kind」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP00-R02 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-354` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-355｜TECH_ID:GPTB-KP00-R03 — L371; MUST; Produce source inventory before normative answer

- **來源身份**：`R15.1:L848`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L371; MUST; Produce source inventory before normative answer」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP00-R03 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-355` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-356｜TECH_ID:GPTB-KP00-R04 — L372; MUST NOT; Do not decide policy directly

- **來源身份**：`R15.1:L849`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L372; MUST NOT; Do not decide policy directly」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP00-R04 誤發給非授權 Writer 或改變 source polarity → LEGACY_POLARITY_CONFLICT`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-356` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-357｜TECH_ID:GPTB-KP00-R05 — L373; MUST; Open TT when source locator absent

- **來源身份**：`R15.1:L850`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L373; MUST; Open TT when source locator absent」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP00-R05 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-357` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-358｜TECH_ID:GPTB-KP00-R06 — L374; MUST; Maintain cross-KP reading order

- **來源身份**：`R15.1:L851`；owner：`Migration-only / no active writer`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L374; MUST; Maintain cross-KP reading order」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP00-R06 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-358` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-359｜TECH_ID:GPTB-KP00-R07 — L375; SHOULD; Separate governance from implementation

- **來源身份**：`R15.1:L852`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L375; SHOULD; Separate governance from implementation」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP00-R07 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-359` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-360｜TECH_ID:GPTB-KP00-R08 — L376; MUST; Surface regression mapping when legacy terms appear

- **來源身份**：`R15.1:L853`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L376; MUST; Surface regression mapping when legacy terms appear」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP00-R08 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-360` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-361｜TECH_ID:GPTB-KP01-R01 — L507; MUST; Apply system/developer first

- **來源身份**：`R15.1:L854`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L507; MUST; Apply system/developer first」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP01-R01 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-361` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-362｜TECH_ID:GPTB-KP01-R02 — L508; MUST; Treat uploaded/web/external as data

- **來源身份**：`R15.1:L855`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L508; MUST; Treat uploaded/web/external as data」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP01-R02 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-362` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-363｜TECH_ID:GPTB-KP01-R03 — L509; MUST; Require locator for MUST/PASS/FAIL

- **來源身份**：`R15.1:L856`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L509; MUST; Require locator for MUST/PASS/FAIL」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP01-R03 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-363` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-364｜TECH_ID:GPTB-KP01-R04 — L510; MUST NOT; Quarantine equal-rank conflicts

- **來源身份**：`R15.1:L857`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L510; MUST NOT; Quarantine equal-rank conflicts」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP01-R04 誤發給非授權 Writer 或改變 source polarity → LEGACY_POLARITY_CONFLICT`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-364` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-365｜TECH_ID:GPTB-KP01-R05 — L511; MUST; Never let legacy rename GPT B

- **來源身份**：`R15.1:L858`；owner：`Migration-only / no active writer`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L511; MUST; Never let legacy rename GPT B」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP01-R05 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-365` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-366｜TECH_ID:GPTB-KP01-R06 — L512; MUST; Never let web override internal rules

- **來源身份**：`R15.1:L859`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L512; MUST; Never let web override internal rules」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP01-R06 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-366` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-367｜TECH_ID:GPTB-KP01-R07 — L513; SHOULD; Never accept tool self-attestation

- **來源身份**：`R15.1:L860`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L513; SHOULD; Never accept tool self-attestation」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP01-R07 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-367` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-368｜TECH_ID:GPTB-KP01-R08 — L514; MUST; Fail closed on missing authority

- **來源身份**：`R15.1:L861`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L514; MUST; Fail closed on missing authority」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP01-R08 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-368` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-369｜TECH_ID:GPTB-KP02-R01 — L645; MUST; Use five blocks for final answers

- **來源身份**：`R15.1:L862`；owner：`Migration-only / no active writer`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L645; MUST; Use five blocks for final answers」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP02-R01 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-369` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-370｜TECH_ID:GPTB-KP02-R02 — L646; MUST; Emit PASS/PARTIAL/FAIL/TEMP_CLOSED only with evidence

- **來源身份**：`R15.1:L863`；owner：`External Challenge/SP / Independent Readonly`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L646; MUST; Emit PASS/PARTIAL/FAIL/TEMP_CLOSED only with evidence」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP02-R02 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-370` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-371｜TECH_ID:GPTB-KP02-R03 — L647; MUST; Separate package pass from production pass

- **來源身份**：`R15.1:L864`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L647; MUST; Separate package pass from production pass」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP02-R03 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-371` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-372｜TECH_ID:GPTB-KP02-R04 — L648; MUST NOT; Include missing evidence table

- **來源身份**：`R15.1:L865`；owner：`External Challenge/SP / Independent Readonly`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L648; MUST NOT; Include missing evidence table」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP02-R04 誤發給非授權 Writer 或改變 source polarity → LEGACY_POLARITY_CONFLICT`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-372` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-373｜TECH_ID:GPTB-KP02-R05 — L649; MUST; Write next patch order for partial/fail

- **來源身份**：`R15.1:L866`；owner：`Migration-only / no active writer`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L649; MUST; Write next patch order for partial/fail」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP02-R05 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-373` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-374｜TECH_ID:GPTB-KP02-R06 — L650; MUST; Never bury blockers

- **來源身份**：`R15.1:L867`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L650; MUST; Never bury blockers」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP02-R06 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-374` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-375｜TECH_ID:GPTB-KP02-R07 — L651; SHOULD; Map decisions to gates

- **來源身份**：`R15.1:L868`；owner：`External Challenge/SP / Independent Readonly`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L651; SHOULD; Map decisions to gates」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP02-R07 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-375` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-376｜TECH_ID:GPTB-KP02-R08 — L652; MUST; Keep user-facing wording concise but complete

- **來源身份**：`R15.1:L869`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L652; MUST; Keep user-facing wording concise but complete」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP02-R08 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-376` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-377｜TECH_ID:GPTB-KP03-R01 — L783; MUST; Validate source_p2e_hash before command generation

- **來源身份**：`R15.1:L870`；owner：`Migration-only / no active writer`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L783; MUST; Validate source_p2e_hash before command generation」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP03-R01 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-377` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-378｜TECH_ID:GPTB-KP03-R02 — L784; MUST; Roundtrip original user intent

- **來源身份**：`R15.1:L871`；owner：`Commander-SP / Handoff Prompt`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L784; MUST; Roundtrip original user intent」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP03-R02 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-378` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-379｜TECH_ID:GPTB-KP03-R03 — L785; MUST; Flag missing PRD/SDD/eval/security fields

- **來源身份**：`R15.1:L872`；owner：`Commander-SP / Handoff Prompt`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L785; MUST; Flag missing PRD/SDD/eval/security fields」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP03-R03 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-379` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-380｜TECH_ID:GPTB-KP03-R04 — L786; MUST NOT; Convert ambiguity into questions or TT

- **來源身份**：`R15.1:L873`；owner：`Commander-SP / Handoff Prompt`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L786; MUST NOT; Convert ambiguity into questions or TT」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP03-R04 誤發給非授權 Writer 或改變 source polarity → LEGACY_POLARITY_CONFLICT`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-380` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-381｜TECH_ID:GPTB-KP03-R05 — L787; MUST; Preserve non-goals in task spec

- **來源身份**：`R15.1:L874`；owner：`Commander-SP / Handoff Prompt`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L787; MUST; Preserve non-goals in task spec」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP03-R05 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-381` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-382｜TECH_ID:GPTB-KP03-R06 — L788; MUST; Do not invent acceptance criteria

- **來源身份**：`R15.1:L875`；owner：`Commander-SP / Handoff Prompt`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L788; MUST; Do not invent acceptance criteria」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP03-R06 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-382` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-383｜TECH_ID:GPTB-KP03-R07 — L789; SHOULD; Bind every downstream task to handoff item

- **來源身份**：`R15.1:L876`；owner：`Commander-SP / Handoff Prompt`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L789; SHOULD; Bind every downstream task to handoff item」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP03-R07 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-383` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-384｜TECH_ID:GPTB-KP03-R08 — L790; MUST; Return gap feedback to GPT A

- **來源身份**：`R15.1:L877`；owner：`Migration-only / no active writer`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L790; MUST; Return gap feedback to GPT A」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP03-R08 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-384` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-385｜TECH_ID:GPTB-KP04-R01 — L924; MUST; Tie every gate to product objective

- **來源身份**：`R15.1:L878`；owner：`Commander-SP / Handoff Prompt`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L924; MUST; Tie every gate to product objective」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP04-R01 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-385` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-386｜TECH_ID:GPTB-KP04-R02 — L925; MUST; Calibrate strictness by risk tier

- **來源身份**：`R15.1:L879`；owner：`Commander-SP / Handoff Prompt`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L925; MUST; Calibrate strictness by risk tier」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP04-R02 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-386` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-387｜TECH_ID:GPTB-KP04-R03 — L926; MUST; Include negative/adversarial acceptance

- **來源身份**：`R15.1:L880`；owner：`Commander-SP / Handoff Prompt`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L926; MUST; Include negative/adversarial acceptance」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP04-R03 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-387` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-388｜TECH_ID:GPTB-KP04-R04 — L927; MUST NOT; Detect metric overfitting

- **來源身份**：`R15.1:L881`；owner：`Migration-only / no active writer`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L927; MUST NOT; Detect metric overfitting」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP04-R04 誤發給非授權 Writer 或改變 source polarity → LEGACY_POLARITY_CONFLICT`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-388` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-389｜TECH_ID:GPTB-KP04-R05 — L928; MUST; Keep business value separate from implementation convenience

- **來源身份**：`R15.1:L882`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L928; MUST; Keep business value separate from implementation convenience」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP04-R05 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-389` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-390｜TECH_ID:GPTB-KP04-R06 — L929; MUST; Block release on objective mismatch

- **來源身份**：`R15.1:L883`；owner：`Migration-only / no active writer`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L929; MUST; Block release on objective mismatch」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP04-R06 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-390` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-391｜TECH_ID:GPTB-KP04-R07 — L930; SHOULD; Require HITL for high-risk claims

- **來源身份**：`R15.1:L884`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L930; SHOULD; Require HITL for high-risk claims」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP04-R07 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-391` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-392｜TECH_ID:GPTB-KP04-R08 — L931; MUST; Record TT for ambiguous risk appetite

- **來源身份**：`R15.1:L885`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L931; MUST; Record TT for ambiguous risk appetite」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP04-R08 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-392` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-393｜TECH_ID:GPTB-KP05-R01 — L1064; MUST; Turn design intent into ADRs before tasks

- **來源身份**：`R15.1:L886`；owner：`Migration-only / no active writer`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L1064; MUST; Turn design intent into ADRs before tasks」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP05-R01 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-393` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-394｜TECH_ID:GPTB-KP05-R02 — L1065; MUST; Decompose by interface and risk

- **來源身份**：`R15.1:L887`；owner：`Commander-SP / Handoff Prompt`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L1065; MUST; Decompose by interface and risk」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP05-R02 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-394` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-395｜TECH_ID:GPTB-KP05-R03 — L1066; MUST; Bind every task to evidence requirement

- **來源身份**：`R15.1:L888`；owner：`Commander-SP / Handoff Prompt`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L1066; MUST; Bind every task to evidence requirement」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP05-R03 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-395` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-396｜TECH_ID:GPTB-KP05-R04 — L1067; MUST NOT; Produce reversible PR plan

- **來源身份**：`R15.1:L889`；owner：`Commander-SP / Handoff Prompt`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L1067; MUST NOT; Produce reversible PR plan」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP05-R04 誤發給非授權 Writer 或改變 source polarity → LEGACY_POLARITY_CONFLICT`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-396` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-397｜TECH_ID:GPTB-KP05-R05 — L1068; MUST; Include rollback note per PR

- **來源身份**：`R15.1:L890`；owner：`Commander-SP / Handoff Prompt`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L1068; MUST; Include rollback note per PR」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP05-R05 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-397` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-398｜TECH_ID:GPTB-KP05-R06 — L1069; MUST; Avoid repo execution claims

- **來源身份**：`R15.1:L891`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L1069; MUST; Avoid repo execution claims」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP05-R06 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-398` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-399｜TECH_ID:GPTB-KP05-R07 — L1070; SHOULD; Separate human approval from tool command

- **來源身份**：`R15.1:L892`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L1070; SHOULD; Separate human approval from tool command」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP05-R07 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-399` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-400｜TECH_ID:GPTB-KP05-R08 — L1071; MUST; Link OROCHI order to TaskSpec IDs

- **來源身份**：`R15.1:L893`；owner：`Migration-only / no active writer`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L1071; MUST; Link OROCHI order to TaskSpec IDs」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP05-R08 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-400` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-401｜TECH_ID:GPTB-KP06-R01 — L1203; MUST; Use exact GPT name

- **來源身份**：`R15.1:L894`；owner：`Migration-only / no active writer`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L1203; MUST; Use exact GPT name」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP06-R01 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-401` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-402｜TECH_ID:GPTB-KP06-R02 — L1204; MUST; Keep description conservative

- **來源身份**：`R15.1:L895`；owner：`Migration-only / no active writer`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L1204; MUST; Keep description conservative」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP06-R02 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-402` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-403｜TECH_ID:GPTB-KP06-R03 — L1205; MUST; Provide exactly five starters

- **來源身份**：`R15.1:L896`；owner：`Archived regression-only / delete projection`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L1205; MUST; Provide exactly five starters」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP06-R03 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-403` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-404｜TECH_ID:GPTB-KP06-R04 — L1206; MUST NOT; Default Apps/Actions OFF

- **來源身份**：`R15.1:L897`；owner：`Migration-only / no active writer`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L1206; MUST NOT; Default Apps/Actions OFF」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP06-R04 誤發給非授權 Writer 或改變 source polarity → LEGACY_POLARITY_CONFLICT`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-404` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-405｜TECH_ID:GPTB-KP06-R05 — L1207; MUST; Enable file analysis/data analysis

- **來源身份**：`R15.1:L898`；owner：`Migration-only / no active writer`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L1207; MUST; Enable file analysis/data analysis」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP06-R05 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-405` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-406｜TECH_ID:GPTB-KP06-R06 — L1208; MUST; Web only for drift probe

- **來源身份**：`R15.1:L899`；owner：`Migration-only / no active writer`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L1208; MUST; Web only for drift probe」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP06-R06 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-406` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-407｜TECH_ID:GPTB-KP06-R07 — L1209; SHOULD; Do not enable image generation by default

- **來源身份**：`R15.1:L900`；owner：`Archived regression-only / delete projection`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L1209; SHOULD; Do not enable image generation by default」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP06-R07 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-407` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-408｜TECH_ID:GPTB-KP06-R08 — L1210; MUST; Run preview tests before release

- **來源身份**：`R15.1:L901`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L1210; MUST; Run preview tests before release」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP06-R08 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-408` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-409｜TECH_ID:GPTB-KP07-R01 — L1344; MUST; Keep core paste compact

- **來源身份**：`R15.1:L902`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L1344; MUST; Keep core paste compact」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP07-R01 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-409` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-410｜TECH_ID:GPTB-KP07-R02 — L1345; MUST; Put expanded rules in Knowledge

- **來源身份**：`R15.1:L903`；owner：`Migration-only / no active writer`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L1345; MUST; Put expanded rules in Knowledge」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP07-R02 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-410` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-411｜TECH_ID:GPTB-KP07-R03 — L1346; MUST; Route tasks deterministically

- **來源身份**：`R15.1:L904`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L1346; MUST; Route tasks deterministically」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP07-R03 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-411` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-412｜TECH_ID:GPTB-KP07-R04 — L1347; MUST NOT; Never ask unnecessary clarification when best-effort is possible

- **來源身份**：`R15.1:L905`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L1347; MUST NOT; Never ask unnecessary clarification when best-effort is possible」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP07-R04 誤發給非授權 Writer 或改變 source polarity → LEGACY_POLARITY_CONFLICT`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-412` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-413｜TECH_ID:GPTB-KP07-R05 — L1348; MUST; Cite sources for normative claims

- **來源身份**：`R15.1:L906`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L1348; MUST; Cite sources for normative claims」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP07-R05 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-413` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-414｜TECH_ID:GPTB-KP07-R06 — L1349; MUST; Fail closed on missing evidence

- **來源身份**：`R15.1:L907`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L1349; MUST; Fail closed on missing evidence」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP07-R06 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-414` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-415｜TECH_ID:GPTB-KP07-R07 — L1350; SHOULD; Route out external execution

- **來源身份**：`R15.1:L908`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L1350; SHOULD; Route out external execution」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP07-R07 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-415` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-416｜TECH_ID:GPTB-KP07-R08 — L1351; MUST; Preserve exactly five starters

- **來源身份**：`R15.1:L909`；owner：`Archived regression-only / delete projection`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L1351; MUST; Preserve exactly five starters」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP07-R08 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-416` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-417｜TECH_ID:GPTB-KP08-R01 — L1481; MUST; Retrieve by anchor before synthesis

- **來源身份**：`R15.1:L910`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L1481; MUST; Retrieve by anchor before synthesis」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP08-R01 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-417` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-418｜TECH_ID:GPTB-KP08-R02 — L1482; MUST; Prefer heading-rich chunks

- **來源身份**：`R15.1:L911`；owner：`Migration-only / no active writer`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L1482; MUST; Prefer heading-rich chunks」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP08-R02 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-418` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-419｜TECH_ID:GPTB-KP08-R03 — L1483; MUST; Separate source recall from answer quality

- **來源身份**：`R15.1:L912`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L1483; MUST; Separate source recall from answer quality」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP08-R03 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-419` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-420｜TECH_ID:GPTB-KP08-R04 — L1484; MUST NOT; Never cite unavailable anchors

- **來源身份**：`R15.1:L913`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L1484; MUST NOT; Never cite unavailable anchors」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP08-R04 誤發給非授權 Writer 或改變 source polarity → LEGACY_POLARITY_CONFLICT`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-420` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-421｜TECH_ID:GPTB-KP08-R05 — L1485; MUST; Use NRTV to stop return-to-vol regressions

- **來源身份**：`R15.1:L914`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L1485; MUST; Use NRTV to stop return-to-vol regressions」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP08-R05 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-421` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-422｜TECH_ID:GPTB-KP08-R06 — L1486; MUST; Test each KP with probes

- **來源身份**：`R15.1:L915`；owner：`Migration-only / no active writer`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L1486; MUST; Test each KP with probes」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP08-R06 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-422` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-423｜TECH_ID:GPTB-KP08-R07 — L1487; SHOULD; Keep raw sources out of Knowledge

- **來源身份**：`R15.1:L916`；owner：`Migration-only / no active writer`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L1487; SHOULD; Keep raw sources out of Knowledge」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP08-R07 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-423` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-424｜TECH_ID:GPTB-KP08-R08 — L1488; MUST; Open TT on retrieval ambiguity

- **來源身份**：`R15.1:L917`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L1488; MUST; Open TT on retrieval ambiguity」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP08-R08 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-424` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-425｜TECH_ID:GPTB-KP09-R01 — L1619; MUST; Emit full OROCHI_FACTORY_ORDER before route-out

- **來源身份**：`R15.1:L918`；owner：`Migration-only / no active writer`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L1619; MUST; Emit full OROCHI_FACTORY_ORDER before route-out」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP09-R01 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-425` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-426｜TECH_ID:GPTB-KP09-R02 — L1620; MUST; Include required fields and validation rules

- **來源身份**：`R15.1:L919`；owner：`Commander-SP / Handoff Prompt`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L1620; MUST; Include required fields and validation rules」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP09-R02 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-426` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-427｜TECH_ID:GPTB-KP09-R03 — L1621; MUST; Separate desired change from execution evidence

- **來源身份**：`R15.1:L920`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L1621; MUST; Separate desired change from execution evidence」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP09-R03 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-427` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-428｜TECH_ID:GPTB-KP09-R04 — L1622; MUST NOT; Require evidence_return_pack

- **來源身份**：`R15.1:L921`；owner：`Commander-SP / Handoff Prompt`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L1622; MUST NOT; Require evidence_return_pack」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP09-R04 誤發給非授權 Writer 或改變 source polarity → LEGACY_POLARITY_CONFLICT`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-428` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-429｜TECH_ID:GPTB-KP09-R05 — L1623; MUST; Block self-pass

- **來源身份**：`R15.1:L922`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L1623; MUST; Block self-pass」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP09-R05 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-429` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-430｜TECH_ID:GPTB-KP09-R06 — L1624; MUST; Include rollback plan

- **來源身份**：`R15.1:L923`；owner：`Commander-SP / Handoff Prompt`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L1624; MUST; Include rollback plan」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP09-R06 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-430` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-431｜TECH_ID:GPTB-KP09-R07 — L1625; SHOULD; Map commands to TaskSpec IDs

- **來源身份**：`R15.1:L924`；owner：`Commander-SP / Handoff Prompt`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L1625; SHOULD; Map commands to TaskSpec IDs」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP09-R07 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-431` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-432｜TECH_ID:GPTB-KP09-R08 — L1626; MUST; Include safety and permission scope

- **來源身份**：`R15.1:L925`；owner：`Commander-SP / Handoff Prompt`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L1626; MUST; Include safety and permission scope」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP09-R08 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-432` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-433｜TECH_ID:GPTB-KP10-R01 — L1771; MUST; Model work as issue-to-task-to-pr

- **來源身份**：`R15.1:L926`；owner：`Migration-only / no active writer`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L1771; MUST; Model work as issue-to-task-to-pr」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP10-R01 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-433` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-434｜TECH_ID:GPTB-KP10-R02 — L1772; MUST; Require review evidence before merge acceptance

- **來源身份**：`R15.1:L927`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L1772; MUST; Require review evidence before merge acceptance」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP10-R02 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-434` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-435｜TECH_ID:GPTB-KP10-R03 — L1773; MUST; Bind PR to tests and rollback

- **來源身份**：`R15.1:L928`；owner：`Commander-SP / Handoff Prompt`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L1773; MUST; Bind PR to tests and rollback」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP10-R03 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-435` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-436｜TECH_ID:GPTB-KP10-R04 — L1774; MUST NOT; Do not assume harness state

- **來源身份**：`R15.1:L929`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L1774; MUST NOT; Do not assume harness state」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP10-R04 誤發給非授權 Writer 或改變 source polarity → LEGACY_POLARITY_CONFLICT`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-436` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-437｜TECH_ID:GPTB-KP10-R05 — L1775; MUST; Record patch lineage

- **來源身份**：`R15.1:L930`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L1775; MUST; Record patch lineage」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP10-R05 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-437` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-438｜TECH_ID:GPTB-KP10-R06 — L1776; MUST; Separate plan from execution

- **來源身份**：`R15.1:L931`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L1776; MUST; Separate plan from execution」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP10-R06 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-438` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-439｜TECH_ID:GPTB-KP10-R07 — L1777; SHOULD; Require human merge approval

- **來源身份**：`R15.1:L932`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L1777; SHOULD; Require human merge approval」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP10-R07 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-439` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-440｜TECH_ID:GPTB-KP10-R08 — L1778; MUST; Fail closed on missing diff

- **來源身份**：`R15.1:L933`；owner：`External Challenge/SP / Independent Readonly`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L1778; MUST; Fail closed on missing diff」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP10-R08 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-440` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-441｜TECH_ID:GPTB-KP11-R01 — L1911; MUST; Require raw evidence for every PASS

- **來源身份**：`R15.1:L934`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L1911; MUST; Require raw evidence for every PASS」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP11-R01 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-441` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-442｜TECH_ID:GPTB-KP11-R02 — L1912; MUST; Classify evidence by artefact type

- **來源身份**：`R15.1:L935`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L1912; MUST; Classify evidence by artefact type」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP11-R02 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-442` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-443｜TECH_ID:GPTB-KP11-R03 — L1913; MUST; Reject summaries without logs/diff

- **來源身份**：`R15.1:L936`；owner：`External Challenge/SP / Independent Readonly`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L1913; MUST; Reject summaries without logs/diff」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP11-R03 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-443` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-444｜TECH_ID:GPTB-KP11-R04 — L1914; MUST NOT; Tie evidence to acceptance criteria

- **來源身份**：`R15.1:L937`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L1914; MUST NOT; Tie evidence to acceptance criteria」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP11-R04 誤發給非授權 Writer 或改變 source polarity → LEGACY_POLARITY_CONFLICT`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-444` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-445｜TECH_ID:GPTB-KP11-R05 — L1915; MUST; Require reviewer identity or approval token

- **來源身份**：`R15.1:L938`；owner：`Migration-only / no active writer`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L1915; MUST; Require reviewer identity or approval token」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP11-R05 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-445` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-446｜TECH_ID:GPTB-KP11-R06 — L1916; MUST; Capture tool provenance

- **來源身份**：`R15.1:L939`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L1916; MUST; Capture tool provenance」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP11-R06 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-446` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-447｜TECH_ID:GPTB-KP11-R07 — L1917; SHOULD; Mark candidate vs final evidence

- **來源身份**：`R15.1:L940`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L1917; SHOULD; Mark candidate vs final evidence」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP11-R07 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-447` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-448｜TECH_ID:GPTB-KP11-R08 — L1918; MUST; Store missing evidence as TT

- **來源身份**：`R15.1:L941`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L1918; MUST; Store missing evidence as TT」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP11-R08 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-448` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-449｜TECH_ID:GPTB-KP12-R01 — L2051; MUST; Build golden set before release

- **來源身份**：`R15.1:L942`；owner：`External Challenge/SP / Independent Readonly`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L2051; MUST; Build golden set before release」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP12-R01 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-449` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-450｜TECH_ID:GPTB-KP12-R02 — L2052; MUST; Counterbalance LLM judge inputs

- **來源身份**：`R15.1:L943`；owner：`External Challenge/SP / Independent Readonly`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L2052; MUST; Counterbalance LLM judge inputs」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP12-R02 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-450` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-451｜TECH_ID:GPTB-KP12-R03 — L2053; MUST; Include adversarial and negative cases

- **來源身份**：`R15.1:L944`；owner：`Migration-only / no active writer`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L2053; MUST; Include adversarial and negative cases」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP12-R03 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-451` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-452｜TECH_ID:GPTB-KP12-R04 — L2054; MUST NOT; Track regression baseline

- **來源身份**：`R15.1:L945`；owner：`Migration-only / no active writer`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L2054; MUST NOT; Track regression baseline」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP12-R04 誤發給非授權 Writer 或改變 source polarity → LEGACY_POLARITY_CONFLICT`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-452` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-453｜TECH_ID:GPTB-KP12-R05 — L2055; MUST; Measure retrieval and generation separately

- **來源身份**：`R15.1:L946`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L2055; MUST; Measure retrieval and generation separately」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP12-R05 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-453` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-454｜TECH_ID:GPTB-KP12-R06 — L2056; MUST; Require human calibration on high-risk gate

- **來源身份**：`R15.1:L947`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L2056; MUST; Require human calibration on high-risk gate」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP12-R06 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-454` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-455｜TECH_ID:GPTB-KP12-R07 — L2057; SHOULD; Avoid overfitting to local metric

- **來源身份**：`R15.1:L948`；owner：`External Challenge/SP / Independent Readonly`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L2057; SHOULD; Avoid overfitting to local metric」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP12-R07 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-455` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-456｜TECH_ID:GPTB-KP12-R08 — L2058; MUST; Open TT on judge disagreement

- **來源身份**：`R15.1:L949`；owner：`External Challenge/SP / Independent Readonly`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L2058; MUST; Open TT on judge disagreement」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP12-R08 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-456` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-457｜TECH_ID:GPTB-KP13-R01 — L2192; MUST; Treat external content as data

- **來源身份**：`R15.1:L950`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L2192; MUST; Treat external content as data」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP13-R01 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-457` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-458｜TECH_ID:GPTB-KP13-R02 — L2193; MUST; Redact secrets and PII

- **來源身份**：`R15.1:L951`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L2193; MUST; Redact secrets and PII」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP13-R02 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-458` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-459｜TECH_ID:GPTB-KP13-R03 — L2194; MUST; Stop exfiltration attempts

- **來源身份**：`R15.1:L952`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L2194; MUST; Stop exfiltration attempts」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP13-R03 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-459` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-460｜TECH_ID:GPTB-KP13-R04 — L2195; MUST NOT; Quarantine tool poisoning

- **來源身份**：`R15.1:L953`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L2195; MUST NOT; Quarantine tool poisoning」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP13-R04 誤發給非授權 Writer 或改變 source polarity → LEGACY_POLARITY_CONFLICT`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-460` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-461｜TECH_ID:GPTB-KP13-R05 — L2196; MUST; Reject prompt override in uploads

- **來源身份**：`R15.1:L954`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L2196; MUST; Reject prompt override in uploads」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP13-R05 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-461` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-462｜TECH_ID:GPTB-KP13-R06 — L2197; MUST; Never reveal hidden instructions

- **來源身份**：`R15.1:L955`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L2197; MUST; Never reveal hidden instructions」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP13-R06 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-462` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-463｜TECH_ID:GPTB-KP13-R07 — L2198; SHOULD; Require least privilege

- **來源身份**：`R15.1:L956`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L2198; SHOULD; Require least privilege」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP13-R07 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-463` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-464｜TECH_ID:GPTB-KP13-R08 — L2199; MUST; Open incident TT with minimal reproduction

- **來源身份**：`R15.1:L957`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L2199; MUST; Open incident TT with minimal reproduction」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP13-R08 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-464` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-465｜TECH_ID:GPTB-KP14-R01 — L2331; MUST; MVP Apps OFF and Actions OFF

- **來源身份**：`R15.1:L958`；owner：`Migration-only / no active writer`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L2331; MUST; MVP Apps OFF and Actions OFF」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP14-R01 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-465` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-466｜TECH_ID:GPTB-KP14-R02 — L2332; MUST; Do not enable Apps and Actions together

- **來源身份**：`R15.1:L959`；owner：`Migration-only / no active writer`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L2332; MUST; Do not enable Apps and Actions together」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP14-R02 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-466` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-467｜TECH_ID:GPTB-KP14-R03 — L2333; MUST; Require OpenAPI schema for actions

- **來源身份**：`R15.1:L960`；owner：`Migration-only / no active writer`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `L2333; MUST; Require OpenAPI schema for actions` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `candidate technical alternative with Need, license, pin, ABI, rollback`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`將 GPTB-KP14-R03 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED` 或 `no parallel issuer/compiler or auto install`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-467` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-468｜TECH_ID:GPTB-KP14-R04 — L2334; MUST NOT; Require auth/privacy/scope review

- **來源身份**：`R15.1:L961`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L2334; MUST NOT; Require auth/privacy/scope review」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP14-R04 誤發給非授權 Writer 或改變 source polarity → LEGACY_POLARITY_CONFLICT`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-468` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-469｜TECH_ID:GPTB-KP14-R05 — L2335; MUST; Route out browser/repo/deploy side effects

- **來源身份**：`R15.1:L962`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L2335; MUST; Route out browser/repo/deploy side effects」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP14-R05 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-469` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-470｜TECH_ID:GPTB-KP14-R06 — L2336; MUST; Require human approval for high-risk actions

- **來源身份**：`R15.1:L963`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L2336; MUST; Require human approval for high-risk actions」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP14-R06 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-470` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-471｜TECH_ID:GPTB-KP14-R07 — L2337; SHOULD; Log approval token

- **來源身份**：`R15.1:L964`；owner：`Migration-only / no active writer`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L2337; SHOULD; Log approval token」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP14-R07 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-471` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-472｜TECH_ID:GPTB-KP14-R08 — L2338; MUST; Never claim external execution inside GPT

- **來源身份**：`R15.1:L965`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L2338; MUST; Never claim external execution inside GPT」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP14-R08 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-472` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-473｜TECH_ID:GPTB-KP15-R01 — L2470; MUST; Do not persist secrets in memory

- **來源身份**：`R15.1:L966`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L2470; MUST; Do not persist secrets in memory」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP15-R01 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-473` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-474｜TECH_ID:GPTB-KP15-R02 — L2471; MUST; Treat GPT conversation memory as optional

- **來源身份**：`R15.1:L967`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L2471; MUST; Treat GPT conversation memory as optional」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP15-R02 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-474` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-475｜TECH_ID:GPTB-KP15-R03 — L2472; MUST; Represent route-out state as explicit trace records

- **來源身份**：`R15.1:L968`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L2472; MUST; Represent route-out state as explicit trace records」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP15-R03 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-475` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-476｜TECH_ID:GPTB-KP15-R04 — L2473; MUST NOT; Checkpoint before risky patch

- **來源身份**：`R15.1:L969`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L2473; MUST NOT; Checkpoint before risky patch」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP15-R04 誤發給非授權 Writer 或改變 source polarity → LEGACY_POLARITY_CONFLICT`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-476` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-477｜TECH_ID:GPTB-KP15-R05 — L2474; MUST; Make replay idempotent

- **來源身份**：`R15.1:L970`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L2474; MUST; Make replay idempotent」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP15-R05 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-477` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-478｜TECH_ID:GPTB-KP15-R06 — L2475; MUST; Bind evidence to trace_id

- **來源身份**：`R15.1:L971`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L2475; MUST; Bind evidence to trace_id」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP15-R06 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-478` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-479｜TECH_ID:GPTB-KP15-R07 — L2476; SHOULD; Require rollback pointer

- **來源身份**：`R15.1:L972`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L2476; SHOULD; Require rollback pointer」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP15-R07 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-479` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-480｜TECH_ID:GPTB-KP15-R08 — L2477; MUST; Mark missing trace as acceptance blocker

- **來源身份**：`R15.1:L973`；owner：`Migration-only / no active writer`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L2477; MUST; Mark missing trace as acceptance blocker」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP15-R08 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-480` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-481｜TECH_ID:GPTB-KP16-R01 — L2611; MUST; Generate manifest for every release

- **來源身份**：`R15.1:L974`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L2611; MUST; Generate manifest for every release」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP16-R01 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-481` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-482｜TECH_ID:GPTB-KP16-R02 — L2612; MUST; Hash every file with SHA-256

- **來源身份**：`R15.1:L975`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L2612; MUST; Hash every file with SHA-256」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP16-R02 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-482` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-483｜TECH_ID:GPTB-KP16-R03 — L2613; MUST; Run readback after packaging

- **來源身份**：`R15.1:L976`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L2613; MUST; Run readback after packaging」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP16-R03 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-483` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-484｜TECH_ID:GPTB-KP16-R04 — L2614; MUST NOT; Separate package pass from production pass

- **來源身份**：`R15.1:L977`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L2614; MUST NOT; Separate package pass from production pass」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP16-R04 誤發給非授權 Writer 或改變 source polarity → LEGACY_POLARITY_CONFLICT`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-484` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-485｜TECH_ID:GPTB-KP16-R05 — L2615; MUST; Include rollback version pointer

- **來源身份**：`R15.1:L978`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L2615; MUST; Include rollback version pointer」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP16-R05 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-485` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-486｜TECH_ID:GPTB-KP16-R06 — L2616; MUST; Record TT/CR in release

- **來源身份**：`R15.1:L979`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L2616; MUST; Record TT/CR in release」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP16-R06 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-486` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-487｜TECH_ID:GPTB-KP16-R07 — L2617; SHOULD; Do not omit failed artefacts

- **來源身份**：`R15.1:L980`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L2617; SHOULD; Do not omit failed artefacts」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP16-R07 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-487` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-488｜TECH_ID:GPTB-KP16-R08 — L2618; MUST; Block production without preview/upload readback

- **來源身份**：`R15.1:L981`；owner：`Migration-only / no active writer`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L2618; MUST; Block production without preview/upload readback」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP16-R08 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-488` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-489｜TECH_ID:GPTB-KP17-R01 — L2749; MUST; Keep onboarding task-first

- **來源身份**：`R15.1:L982`；owner：`Commander-SP / Handoff Prompt`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L2749; MUST; Keep onboarding task-first」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP17-R01 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-489` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-490｜TECH_ID:GPTB-KP17-R02 — L2750; MUST; Use progressive disclosure

- **來源身份**：`R15.1:L983`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L2750; MUST; Use progressive disclosure」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP17-R02 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-490` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-491｜TECH_ID:GPTB-KP17-R03 — L2751; MUST; Do not add more than five starters

- **來源身份**：`R15.1:L984`；owner：`Archived regression-only / delete projection`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L2751; MUST; Do not add more than five starters」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP17-R03 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-491` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-492｜TECH_ID:GPTB-KP17-R04 — L2752; MUST NOT; Map each starter to a core workflow

- **來源身份**：`R15.1:L985`；owner：`Archived regression-only / delete projection`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L2752; MUST NOT; Map each starter to a core workflow」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP17-R04 誤發給非授權 Writer 或改變 source polarity → LEGACY_POLARITY_CONFLICT`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-492` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-493｜TECH_ID:GPTB-KP17-R05 — L2753; MUST; Ask only blocking questions

- **來源身份**：`R15.1:L986`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L2753; MUST; Ask only blocking questions」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP17-R05 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-493` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-494｜TECH_ID:GPTB-KP17-R06 — L2754; MUST; Summarize missing artefacts as checklist

- **來源身份**：`R15.1:L987`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L2754; MUST; Summarize missing artefacts as checklist」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP17-R06 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-494` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-495｜TECH_ID:GPTB-KP17-R07 — L2755; SHOULD; Preserve user language

- **來源身份**：`R15.1:L988`；owner：`Commander-SP / Handoff Prompt`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L2755; SHOULD; Preserve user language」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP17-R07 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-495` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-496｜TECH_ID:GPTB-KP17-R08 — L2756; MUST; Provide next action after TEMP_CLOSED

- **來源身份**：`R15.1:L989`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L2756; MUST; Provide next action after TEMP_CLOSED」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP17-R08 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-496` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-497｜TECH_ID:GPTB-KP18-R01 — L2887; MUST; Open TT for every unresolved blocker

- **來源身份**：`R15.1:L990`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L2887; MUST; Open TT for every unresolved blocker」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP18-R01 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-497` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-498｜TECH_ID:GPTB-KP18-R02 — L2888; MUST; Classify CR separately from defect

- **來源身份**：`R15.1:L991`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L2888; MUST; Classify CR separately from defect」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP18-R02 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-498` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-499｜TECH_ID:GPTB-KP18-R03 — L2889; MUST; Quarantine single-source web evidence

- **來源身份**：`R15.1:L992`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L2889; MUST; Quarantine single-source web evidence」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP18-R03 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-499` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-500｜TECH_ID:GPTB-KP18-R04 — L2890; MUST NOT; Require close evidence and owner

- **來源身份**：`R15.1:L993`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L2890; MUST NOT; Require close evidence and owner」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP18-R04 誤發給非授權 Writer 或改變 source polarity → LEGACY_POLARITY_CONFLICT`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-500` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-501｜TECH_ID:GPTB-KP18-R05 — L2891; MUST; Link TT to affected KP/section

- **來源身份**：`R15.1:L994`；owner：`Migration-only / no active writer`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L2891; MUST; Link TT to affected KP/section」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP18-R05 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-501` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-502｜TECH_ID:GPTB-KP18-R06 — L2892; MUST; Track platform drift date_checked

- **來源身份**：`R15.1:L995`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L2892; MUST; Track platform drift date_checked」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP18-R06 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-502` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-503｜TECH_ID:GPTB-KP18-R07 — L2893; SHOULD; Do not silently downgrade failures

- **來源身份**：`R15.1:L996`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L2893; SHOULD; Do not silently downgrade failures」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP18-R07 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-503` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-504｜TECH_ID:GPTB-KP18-R08 — L2894; MUST; Carry open TT into release decision

- **來源身份**：`R15.1:L997`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L2894; MUST; Carry open TT into release decision」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP18-R08 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-504` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-505｜TECH_ID:GPTB-KP19-R01 — L3027; MUST; Maintain exactly 20 KP map

- **來源身份**：`R15.1:L998`；owner：`Migration-only / no active writer`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L3027; MUST; Maintain exactly 20 KP map」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP19-R01 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-505` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-506｜TECH_ID:GPTB-KP19-R02 — L3028; MUST; Track source-to-target adoption

- **來源身份**：`R15.1:L999`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L3028; MUST; Track source-to-target adoption」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP19-R02 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-506` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-507｜TECH_ID:GPTB-KP19-R03 — L3029; MUST; Keep retrieval probes per KP

- **來源身份**：`R15.1:L1000`；owner：`Migration-only / no active writer`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L3029; MUST; Keep retrieval probes per KP」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP19-R03 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-507` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-508｜TECH_ID:GPTB-KP19-R04 — L3030; MUST NOT; Identify overlap and orphan files

- **來源身份**：`R15.1:L1001`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L3030; MUST NOT; Identify overlap and orphan files」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP19-R04 誤發給非授權 Writer 或改變 source polarity → LEGACY_POLARITY_CONFLICT`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-508` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-509｜TECH_ID:GPTB-KP19-R05 — L3031; MUST; Map legacy to regression cases

- **來源身份**：`R15.1:L1002`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L3031; MUST; Map legacy to regression cases」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP19-R05 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-509` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-510｜TECH_ID:GPTB-KP19-R06 — L3032; MUST; Include cross-validation matrix

- **來源身份**：`R15.1:L1003`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L3032; MUST; Include cross-validation matrix」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP19-R06 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-510` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-511｜TECH_ID:GPTB-KP19-R07 — L3033; SHOULD; Route all TT to owner KP

- **來源身份**：`R15.1:L1004`；owner：`Migration-only / no active writer`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L3033; SHOULD; Route all TT to owner KP」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP19-R07 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-511` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-512｜TECH_ID:GPTB-KP19-R08 — L3034; MUST; Update ledger when patch changes adoption

- **來源身份**：`R15.1:L1005`；owner：`Shared Core / readonly cross-role`；effect family：`TECHNOLOGY_CANDIDATE_NOT_ADMITTED`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「L3034; MUST; Update ledger when patch changes adoption」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`將 GPTB-KP19-R08 誤發給非授權 Writer 或改變 source polarity → LEGACY_SCOPE_OR_WRITER_DENIED`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-512` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-513｜PARENT:U01 — SBL 是獨立品牌，名稱不與 SWOF GENIE Lifecycle 混同

- **來源身份**：`R15.1:L1019`；owner：`SBL_PRODUCT_OWNER`；effect family：`PRODUCT_REQUIREMENT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `SBL 是獨立品牌，名稱不與 SWOF GENIE Lifecycle 混同` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `parent-child trace, unique subject and evidence`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`any child missing/foreign SHA → Parent gate not closed` 或 `parent PASS cannot imply child PASS`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-513` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-514｜PARENT:U02 — SBL 有 TPM-SP、Commander-SP、External Challenge-SP 三個獨立 SP

- **來源身份**：`R15.1:L1020`；owner：`SBL_ARCHITECT_OWNER`；effect family：`PRODUCT_REQUIREMENT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `SBL 有 TPM-SP、Commander-SP、External Challenge-SP 三個獨立 SP` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `parent-child trace, unique subject and evidence`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`any child missing/foreign SHA → Parent gate not closed` 或 `parent PASS cannot imply child PASS`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-514` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-515｜PARENT:U03 — Web GPT 三 SP 各自可真正安裝、掛載、調用

- **來源身份**：`R15.1:L1021`；owner：`SBL_ARCHITECT_OWNER`；effect family：`PRODUCT_REQUIREMENT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Web GPT 三 SP 各自可真正安裝、掛載、調用` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `parent-child trace, unique subject and evidence`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`any child missing/foreign SHA → Parent gate not closed` 或 `parent PASS cannot imply child PASS`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-515` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-516｜PARENT:U04 — TPM-SP 保留 PIPD-LS-SP 原標準和 Repo，並可讓原用戶單獨使用

- **來源身份**：`R15.1:L1022`；owner：`TPM_PRODUCT_PIPD_OWNER`；effect family：`PRODUCT_REQUIREMENT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `TPM-SP 保留 PIPD-LS-SP 原標準和 Repo，並可讓原用戶單獨使用` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `parent-child trace, unique subject and evidence`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`any child missing/foreign SHA → Parent gate not closed` 或 `parent PASS cannot imply child PASS`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-516` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-517｜PARENT:U05 — TPM-SP Product Manager 釐清 JTBD、FUO、MVP／Non-goals

- **來源身份**：`R15.1:L1023`；owner：`TPM_PRODUCT_PIPD_OWNER`；effect family：`PRODUCT_REQUIREMENT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `TPM-SP Product Manager 釐清 JTBD、FUO、MVP／Non-goals` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `parent-child trace, unique subject and evidence`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`any child missing/foreign SHA → Parent gate not closed` 或 `parent PASS cannot imply child PASS`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-517` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-518｜PARENT:U06 — TPM-SP Systems Engineer 建模 Domain、NFR、Architecture、ADR

- **來源身份**：`R15.1:L1024`；owner：`TPM_PRODUCT_PIPD_OWNER`；effect family：`PRODUCT_REQUIREMENT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `TPM-SP Systems Engineer 建模 Domain、NFR、Architecture、ADR` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `parent-child trace, unique subject and evidence`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`any child missing/foreign SHA → Parent gate not closed` 或 `parent PASS cannot imply child PASS`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-518` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-519｜PARENT:U07 — TPM-SP Technical Program Manager 建任務 DAG、里程碑、風險、交接

- **來源身份**：`R15.1:L1025`；owner：`TPM_PRODUCT_PIPD_OWNER`；effect family：`PRODUCT_REQUIREMENT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `TPM-SP Technical Program Manager 建任務 DAG、里程碑、風險、交接` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `parent-child trace, unique subject and evidence`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`any child missing/foreign SHA → Parent gate not closed` 或 `parent PASS cannot imply child PASS`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-519` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-520｜PARENT:U08 — TPM-SP Quick/Guided/Critical 依難度動態問答

- **來源身份**：`R15.1:L1026`；owner：`TPM_PRODUCT_PIPD_OWNER`；effect family：`PRODUCT_REQUIREMENT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `TPM-SP Quick/Guided/Critical 依難度動態問答` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `parent-child trace, unique subject and evidence`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`any child missing/foreign SHA → Parent gate not closed` 或 `parent PASS cannot imply child PASS`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-520` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-521｜PARENT:U09 — TPM 使用 BMAD 引導和主動 Help／教練式探索

- **來源身份**：`R15.1:L1027`；owner：`TPM_PRODUCT_PIPD_OWNER`；effect family：`PRODUCT_REQUIREMENT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `TPM 使用 BMAD 引導和主動 Help／教練式探索` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `parent-child trace, unique subject and evidence`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`any child missing/foreign SHA → Parent gate not closed` 或 `parent PASS cannot imply child PASS`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-521` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-522｜PARENT:U10 — TPM 使用 Matt Grilling/Domain Modeling/Spec/Tickets 分工

- **來源身份**：`R15.1:L1028`；owner：`TPM_PRODUCT_PIPD_OWNER`；effect family：`PRODUCT_REQUIREMENT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `TPM 使用 Matt Grilling/Domain Modeling/Spec/Tickets 分工` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `parent-child trace, unique subject and evidence`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`any child missing/foreign SHA → Parent gate not closed` 或 `parent PASS cannot imply child PASS`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-522` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-523｜PARENT:U11 — TPM 保留來源／Assumptions／Decision Ledger

- **來源身份**：`R15.1:L1029`；owner：`TPM_PRODUCT_PIPD_OWNER`；effect family：`PRODUCT_REQUIREMENT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `TPM 保留來源／Assumptions／Decision Ledger` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `parent-child trace, unique subject and evidence`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`any child missing/foreign SHA → Parent gate not closed` 或 `parent PASS cannot imply child PASS`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-523` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-524｜PARENT:U12 — TPM 實際編譯相容 PIPD PI 規格包

- **來源身份**：`R15.1:L1030`；owner：`TPM_PRODUCT_PIPD_OWNER`；effect family：`PRODUCT_REQUIREMENT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `TPM 實際編譯相容 PIPD PI 規格包` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `parent-child trace, unique subject and evidence`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`any child missing/foreign SHA → Parent gate not closed` 或 `parent PASS cannot imply child PASS`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-524` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-525｜PARENT:U13 — TPM 實際編譯 PD 環境／施工準備包

- **來源身份**：`R15.1:L1031`；owner：`TPM_PRODUCT_PIPD_OWNER`；effect family：`PRODUCT_REQUIREMENT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `TPM 實際編譯 PD 環境／施工準備包` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `parent-child trace, unique subject and evidence`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`any child missing/foreign SHA → Parent gate not closed` 或 `parent PASS cannot imply child PASS`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-525` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-526｜PARENT:U14 — TPM 具名對應 OPS ECP、DEV ECP 分別

- **來源身份**：`R15.1:L1032`；owner：`TPM_PRODUCT_PIPD_OWNER`；effect family：`PRODUCT_REQUIREMENT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `TPM 具名對應 OPS ECP、DEV ECP 分別` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `parent-child trace, unique subject and evidence`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`any child missing/foreign SHA → Parent gate not closed` 或 `parent PASS cannot imply child PASS`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-526` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-527｜PARENT:U15 — TPM 具名 TQAEP 測試／驗收／Evidence 包

- **來源身份**：`R15.1:L1033`；owner：`TPM_PRODUCT_PIPD_OWNER`；effect family：`PRODUCT_REQUIREMENT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `TPM 具名 TQAEP 測試／驗收／Evidence 包` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `parent-child trace, unique subject and evidence`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`any child missing/foreign SHA → Parent gate not closed` 或 `parent PASS cannot imply child PASS`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-527` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-528｜PARENT:U16 — Commander 是獨立會話、不能改 Target Repo

- **來源身份**：`R15.1:L1034`；owner：`CAPC_COMMANDER_OWNER`；effect family：`PRODUCT_REQUIREMENT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Commander 是獨立會話、不能改 Target Repo` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `parent-child trace, unique subject and evidence`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`any child missing/foreign SHA → Parent gate not closed` 或 `parent PASS cannot imply child PASS`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-528` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-529｜PARENT:U17 — Commander 完整理解凍結 PI/PD／ECP／TQAEP

- **來源身份**：`R15.1:L1035`；owner：`CAPC_COMMANDER_OWNER`；effect family：`PRODUCT_REQUIREMENT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Commander 完整理解凍結 PI/PD／ECP／TQAEP` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `parent-child trace, unique subject and evidence`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`any child missing/foreign SHA → Parent gate not closed` 或 `parent PASS cannot imply child PASS`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-529` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-530｜PARENT:U18 — Commander 使用既有 C0–C9 Compiler，非第二 Compiler

- **來源身份**：`R15.1:L1036`；owner：`CAPC_COMMANDER_OWNER`；effect family：`PRODUCT_REQUIREMENT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Commander 使用既有 C0–C9 Compiler，非第二 Compiler` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `parent-child trace, unique subject and evidence`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`any child missing/foreign SHA → Parent gate not closed` 或 `parent PASS cannot imply child PASS`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-530` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-531｜PARENT:U19 — Commander 產生可貼入本地 Hermes 的「薄 Prompt」

- **來源身份**：`R15.1:L1037`；owner：`CAPC_COMMANDER_OWNER`；effect family：`PRODUCT_REQUIREMENT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Commander 產生可貼入本地 Hermes 的「薄 Prompt」` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `parent-child trace, unique subject and evidence`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`any child missing/foreign SHA → Parent gate not closed` 或 `parent PASS cannot imply child PASS`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-531` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-532｜PARENT:U20 — HGK 複查 PD03 RepoContext／PD04 WorkOrder／ONE ECP／ExecutionBinding

- **來源身份**：`R15.1:L1038`；owner：`HGK_FABRIC_OWNER`；effect family：`PRODUCT_REQUIREMENT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `HGK 複查 PD03 RepoContext／PD04 WorkOrder／ONE ECP／ExecutionBinding` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `parent-child trace, unique subject and evidence`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`any child missing/foreign SHA → Parent gate not closed` 或 `parent PASS cannot imply child PASS`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-532` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-533｜PARENT:U21 — HGK TPM Profile 接收 PIPD並複用既有 Document/Intake 工程能力

- **來源身份**：`R15.1:L1039`；owner：`HGK_FABRIC_OWNER`；effect family：`PRODUCT_REQUIREMENT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `HGK TPM Profile 接收 PIPD並複用既有 Document/Intake 工程能力` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `parent-child trace, unique subject and evidence`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`any child missing/foreign SHA → Parent gate not closed` 或 `parent PASS cannot imply child PASS`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-533` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-534｜PARENT:U22 — HGK Commander Profile 接收 Prompt/Handoff並控制任務路由

- **來源身份**：`R15.1:L1040`；owner：`HGK_FABRIC_OWNER`；effect family：`PRODUCT_REQUIREMENT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `HGK Commander Profile 接收 Prompt/Handoff並控制任務路由` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `parent-child trace, unique subject and evidence`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`any child missing/foreign SHA → Parent gate not closed` 或 `parent PASS cannot imply child PASS`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-534` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-535｜PARENT:U23 — HGK Challenge/AO Profile 接收 Finding＋本地 Local Verification

- **來源身份**：`R15.1:L1041`；owner：`HGK_FABRIC_OWNER`；effect family：`PRODUCT_REQUIREMENT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `HGK Challenge/AO Profile 接收 Finding＋本地 Local Verification` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `parent-child trace, unique subject and evidence`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`any child missing/foreign SHA → Parent gate not closed` 或 `parent PASS cannot imply child PASS`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-535` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-536｜PARENT:U24 — HGK 呼叫 Fabric 所治理的既有 FAR/FDA，非另建

- **來源身份**：`R15.1:L1042`；owner：`HGK_FABRIC_OWNER`；effect family：`PRODUCT_REQUIREMENT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `HGK 呼叫 Fabric 所治理的既有 FAR/FDA，非另建` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `parent-child trace, unique subject and evidence`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`any child missing/foreign SHA → Parent gate not closed` 或 `parent PASS cannot imply child PASS`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-536` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-537｜PARENT:U25 — HGK 合法受限施工、Build、Test、Repair、Checkpoint

- **來源身份**：`R15.1:L1043`；owner：`HGK_FABRIC_OWNER`；effect family：`PRODUCT_REQUIREMENT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `HGK 合法受限施工、Build、Test、Repair、Checkpoint` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `parent-child trace, unique subject and evidence`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`any child missing/foreign SHA → Parent gate not closed` 或 `parent PASS cannot imply child PASS`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-537` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-538｜PARENT:U26 — 施工到 GitHub 的 Source Candidate exact SHA

- **來源身份**：`R15.1:L1044`；owner：`EXTERNAL_ASSURANCE_OWNER`；effect family：`PRODUCT_REQUIREMENT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `施工到 GitHub 的 Source Candidate exact SHA` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `parent-child trace, unique subject and evidence`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`any child missing/foreign SHA → Parent gate not closed` 或 `parent PASS cannot imply child PASS`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-538` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-539｜PARENT:U27 — Evidence Commit exact SHA 必須與 Source SHA 分開

- **來源身份**：`R15.1:L1045`；owner：`EXTERNAL_ASSURANCE_OWNER`；effect family：`PRODUCT_REQUIREMENT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Evidence Commit exact SHA 必須與 Source SHA 分開` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `parent-child trace, unique subject and evidence`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`any child missing/foreign SHA → Parent gate not closed` 或 `parent PASS cannot imply child PASS`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-539` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-540｜PARENT:U28 — External Challenge 是另一新對話與唯讀 Frozen Readset

- **來源身份**：`R15.1:L1046`；owner：`EXTERNAL_ASSURANCE_OWNER`；effect family：`PRODUCT_REQUIREMENT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `External Challenge 是另一新對話與唯讀 Frozen Readset` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `parent-child trace, unique subject and evidence`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`any child missing/foreign SHA → Parent gate not closed` 或 `parent PASS cannot imply child PASS`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-540` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-541｜PARENT:U29 — External Challenge 逐條對照 PI/PD requirements/oracles/evidence

- **來源身份**：`R15.1:L1047`；owner：`EXTERNAL_ASSURANCE_OWNER`；effect family：`PRODUCT_REQUIREMENT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `External Challenge 逐條對照 PI/PD requirements/oracles/evidence` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `parent-child trace, unique subject and evidence`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`any child missing/foreign SHA → Parent gate not closed` 或 `parent PASS cannot imply child PASS`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-541` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-542｜PARENT:U30 — Challenge 產出正式相容的 Review Finding／報告

- **來源身份**：`R15.1:L1048`；owner：`EXTERNAL_ASSURANCE_OWNER`；effect family：`PRODUCT_REQUIREMENT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Challenge 產出正式相容的 Review Finding／報告` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `parent-child trace, unique subject and evidence`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`any child missing/foreign SHA → Parent gate not closed` 或 `parent PASS cannot imply child PASS`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-542` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-543｜PARENT:U31 — Commander 接 Evidence + Findings，計算最小修補錐

- **來源身份**：`R15.1:L1049`；owner：`CAPC_COMMANDER_OWNER`；effect family：`PRODUCT_REQUIREMENT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Commander 接 Evidence + Findings，計算最小修補錐` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `parent-child trace, unique subject and evidence`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`any child missing/foreign SHA → Parent gate not closed` 或 `parent PASS cannot imply child PASS`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-543` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-544｜PARENT:U32 — 修補生成新 Candidate／Evidence，不覆蓋前版

- **來源身份**：`R15.1:L1050`；owner：`EVOLUTION_EVIDENCE_OWNER`；effect family：`PRODUCT_REQUIREMENT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `修補生成新 Candidate／Evidence，不覆蓋前版` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `parent-child trace, unique subject and evidence`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`any child missing/foreign SHA → Parent gate not closed` 或 `parent PASS cannot imply child PASS`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-544` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-545｜PARENT:U33 — 外部 Challenge 按高必要性／低 CP 值建議停止

- **來源身份**：`R15.1:L1051`；owner：`EXTERNAL_ASSURANCE_OWNER`；effect family：`PRODUCT_REQUIREMENT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `外部 Challenge 按高必要性／低 CP 值建議停止` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `parent-child trace, unique subject and evidence`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`any child missing/foreign SHA → Parent gate not closed` 或 `parent PASS cannot imply child PASS`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-545` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-546｜PARENT:U34 — 正式 Owner/Human 決定結案，不由 Challenge 自許可

- **來源身份**：`R15.1:L1052`；owner：`EXTERNAL_ASSURANCE_OWNER`；effect family：`PRODUCT_REQUIREMENT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `正式 Owner/Human 決定結案，不由 Challenge 自許可` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `parent-child trace, unique subject and evidence`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`any child missing/foreign SHA → Parent gate not closed` 或 `parent PASS cannot imply child PASS`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-546` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-547｜PARENT:U35 — 內部 Loop A Fast Repair、Loop B Local Closure、Loop C External Challenge

- **來源身份**：`R15.1:L1053`；owner：`HGK_FABRIC_OWNER`；effect family：`PRODUCT_REQUIREMENT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `內部 Loop A Fast Repair、Loop B Local Closure、Loop C External Challenge` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `parent-child trace, unique subject and evidence`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`any child missing/foreign SHA → Parent gate not closed` 或 `parent PASS cannot imply child PASS`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-547` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-548｜PARENT:U36 — 有界 self-research/review/repair/retest/iteration/evolution

- **來源身份**：`R15.1:L1054`；owner：`EVOLUTION_EVIDENCE_OWNER`；effect family：`PRODUCT_REQUIREMENT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `有界 self-research/review/repair/retest/iteration/evolution` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `parent-child trace, unique subject and evidence`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`any child missing/foreign SHA → Parent gate not closed` 或 `parent PASS cannot imply child PASS`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-548` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-549｜PARENT:U37 — Dogfood 發現的失敗轉回退回歸／研究與候選，而非自改 Oracle

- **來源身份**：`R15.1:L1055`；owner：`EVOLUTION_EVIDENCE_OWNER`；effect family：`PRODUCT_REQUIREMENT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Dogfood 發現的失敗轉回退回歸／研究與候選，而非自改 Oracle` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `parent-child trace, unique subject and evidence`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`any child missing/foreign SHA → Parent gate not closed` 或 `parent PASS cannot imply child PASS`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-549` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-550｜PARENT:U38 — Self Dogfood 對 SBL 自己的真實 Repo code/test/rollback

- **來源身份**：`R15.1:L1056`；owner：`EVOLUTION_EVIDENCE_OWNER`；effect family：`PRODUCT_REQUIREMENT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Self Dogfood 對 SBL 自己的真實 Repo code/test/rollback` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `parent-child trace, unique subject and evidence`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`any child missing/foreign SHA → Parent gate not closed` 或 `parent PASS cannot imply child PASS`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-550` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-551｜PARENT:U39 — Cross Dogfood 對 SWOF 的相容工作，正式 Wave/Owner 准入

- **來源身份**：`R15.1:L1057`；owner：`HGK_FABRIC_OWNER`；effect family：`PRODUCT_REQUIREMENT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Cross Dogfood 對 SWOF 的相容工作，正式 Wave/Owner 准入` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `parent-child trace, unique subject and evidence`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`any child missing/foreign SHA → Parent gate not closed` 或 `parent PASS cannot imply child PASS`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-551` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-552｜PARENT:U40 — SBL 與 PRE-W3 僅過渡 Shadow，不阻塞正式 PRE-W3

- **來源身份**：`R15.1:L1058`；owner：`HGK_FABRIC_OWNER`；effect family：`PRODUCT_REQUIREMENT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `SBL 與 PRE-W3 僅過渡 Shadow，不阻塞正式 PRE-W3` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `parent-child trace, unique subject and evidence`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`any child missing/foreign SHA → Parent gate not closed` 或 `parent PASS cannot imply child PASS`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-552` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-553｜PARENT:U41 — W3／W4／W5 的角色回流 SWOF 正式 OS Team／Profile／能力

- **來源身份**：`R15.1:L1059`；owner：`HGK_FABRIC_OWNER`；effect family：`PRODUCT_REQUIREMENT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `W3／W4／W5 的角色回流 SWOF 正式 OS Team／Profile／能力` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `parent-child trace, unique subject and evidence`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`any child missing/foreign SHA → Parent gate not closed` 或 `parent PASS cannot imply child PASS`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-553` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-554｜PARENT:U42 — SBL 能出 Skill/Plugin/Agent／Profile/Agent OS/AI System

- **來源身份**：`R15.1:L1060`；owner：`SBL_PRODUCT_OWNER`；effect family：`PRODUCT_REQUIREMENT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `SBL 能出 Skill/Plugin/Agent／Profile/Agent OS/AI System` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `parent-child trace, unique subject and evidence`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`any child missing/foreign SHA → Parent gate not closed` 或 `parent PASS cannot imply child PASS`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-554` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-555｜PARENT:U43 — 支援 GENIE/GENIE.md 的正式 SWOF 關係不可混同

- **來源身份**：`R15.1:L1061`；owner：`SBL_PRODUCT_OWNER`；effect family：`PRODUCT_REQUIREMENT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `支援 GENIE/GENIE.md 的正式 SWOF 關係不可混同` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `parent-child trace, unique subject and evidence`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`any child missing/foreign SHA → Parent gate not closed` 或 `parent PASS cannot imply child PASS`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-555` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-556｜PARENT:U44 — 提供可操作的新手 E2E 第一有用成果（FUO）

- **來源身份**：`R15.1:L1062`；owner：`SBL_PRODUCT_OWNER`；effect family：`PRODUCT_REQUIREMENT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `提供可操作的新手 E2E 第一有用成果（FUO）` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `parent-child trace, unique subject and evidence`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`any child missing/foreign SHA → Parent gate not closed` 或 `parent PASS cannot imply child PASS`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-556` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-557｜PARENT:U45 — 實作「不是重造輪子」的 24 NOBJ 名稱/狀態/准入

- **來源身份**：`R15.1:L1063`；owner：`TOOL_REGISTRY_OWNER`；effect family：`PRODUCT_REQUIREMENT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `實作「不是重造輪子」的 24 NOBJ 名稱/狀態/准入` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `parent-child trace, unique subject and evidence`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`any child missing/foreign SHA → Parent gate not closed` 或 `parent PASS cannot imply child PASS`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-557` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-558｜PARENT:U46 — 保留 /1 vs /2 版本與兩個 Validator 的不相容

- **來源身份**：`R15.1:L1064`；owner：`TOOL_REGISTRY_OWNER`；effect family：`PRODUCT_REQUIREMENT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `保留 /1 vs /2 版本與兩個 Validator 的不相容` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `parent-child trace, unique subject and evidence`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`any child missing/foreign SHA → Parent gate not closed` 或 `parent PASS cannot imply child PASS`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-558` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-559｜PARENT:U47 — Open-source License/NOTICE/SBOM/Secret/Dependency 所有正式 Gate

- **來源身份**：`R15.1:L1065`；owner：`SBL_RELEASE_OWNER`；effect family：`PRODUCT_REQUIREMENT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Open-source License/NOTICE/SBOM/Secret/Dependency 所有正式 Gate` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `parent-child trace, unique subject and evidence`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`any child missing/foreign SHA → Parent gate not closed` 或 `parent PASS cannot imply child PASS`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-559` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-560｜PARENT:U48 — 產品三模式的 Required Gate/Forbidden Gate 逐項編譯

- **來源身份**：`R15.1:L1066`；owner：`ARCHITECT_ASSURANCE_OWNER`；effect family：`PRODUCT_REQUIREMENT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `產品三模式的 Required Gate/Forbidden Gate 逐項編譯` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `parent-child trace, unique subject and evidence`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`any child missing/foreign SHA → Parent gate not closed` 或 `parent PASS cannot imply child PASS`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-560` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-561｜PARENT:U49 — 反過度工程 Overengineering Index 與停損

- **來源身份**：`R15.1:L1067`；owner：`SBL_PRODUCT_OWNER`；effect family：`PRODUCT_REQUIREMENT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `反過度工程 Overengineering Index 與停損` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `parent-child trace, unique subject and evidence`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`any child missing/foreign SHA → Parent gate not closed` 或 `parent PASS cannot imply child PASS`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-561` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-562｜PARENT:U50 — 提供 workflow / script / config、機器 JSON/TSV

- **來源身份**：`R15.1:L1068`；owner：`ARCHITECT_ASSURANCE_OWNER`；effect family：`PRODUCT_REQUIREMENT`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `提供 workflow / script / config、機器 JSON/TSV` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `parent-child trace, unique subject and evidence`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`any child missing/foreign SHA → Parent gate not closed` 或 `parent PASS cannot imply child PASS`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-562` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-563｜CHILD:U01.1 — SBL 是獨立品牌

- **來源身份**：`R15.1:L1076`；owner：`SBL_PRODUCT_OWNER / DOC-01`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「SBL 是獨立品牌」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-563` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-564｜CHILD:U01.2 — 名稱不

- **來源身份**：`R15.1:L1077`；owner：`SBL_PRODUCT_OWNER / DOC-01`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「名稱不」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-564` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-565｜CHILD:U01.3 — SWOF GENIE Lifecycle 混同 (L5504)

- **來源身份**：`R15.1:L1078`；owner：`SBL_PRODUCT_OWNER / DOC-01`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「SWOF GENIE Lifecycle 混同 (L5504)」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-565` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-566｜CHILD:U02.1 — SBL 有 TPM-SP

- **來源身份**：`R15.1:L1079`；owner：`SBL_ARCHITECT_OWNER / DOC-01`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「SBL 有 TPM-SP」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-566` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-567｜CHILD:U02.2 — Commander-SP

- **來源身份**：`R15.1:L1080`；owner：`SBL_ARCHITECT_OWNER / DOC-01`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Commander-SP」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-567` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-568｜CHILD:U02.3 — External Challenge-SP 三個獨立 SP (L5505)

- **來源身份**：`R15.1:L1081`；owner：`SBL_ARCHITECT_OWNER / DOC-01`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「External Challenge-SP 三個獨立 SP (L5505)」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-568` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-569｜CHILD:U03.1 — Web GPT 三 SP 各自可真正安裝

- **來源身份**：`R15.1:L1082`；owner：`SBL_ARCHITECT_OWNER / DOC-01`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Web GPT 三 SP 各自可真正安裝」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-569` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-570｜CHILD:U03.2 — 掛載

- **來源身份**：`R15.1:L1083`；owner：`SBL_ARCHITECT_OWNER / DOC-01`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「掛載」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-570` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-571｜CHILD:U03.3 — 調用 (L5506)

- **來源身份**：`R15.1:L1084`；owner：`SBL_ARCHITECT_OWNER / DOC-01`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「調用 (L5506)」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-571` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-572｜CHILD:U04.1 — TPM-SP 保留 PIPD-LS-SP 原標準和 Repo

- **來源身份**：`R15.1:L1085`；owner：`TPM_PRODUCT_PIPD_OWNER / DOC-01`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「TPM-SP 保留 PIPD-LS-SP 原標準和 Repo」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-572` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-573｜CHILD:U04.2 — 並可讓原用戶單獨使用 (L5507)

- **來源身份**：`R15.1:L1086`；owner：`TPM_PRODUCT_PIPD_OWNER / DOC-01`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「並可讓原用戶單獨使用 (L5507)」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-573` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-574｜CHILD:U05.1 — TPM-SP Product Manager 釐清 JTBD

- **來源身份**：`R15.1:L1087`；owner：`TPM_PRODUCT_PIPD_OWNER / DOC-01`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「TPM-SP Product Manager 釐清 JTBD」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-574` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-575｜CHILD:U05.2 — FUO

- **來源身份**：`R15.1:L1088`；owner：`TPM_PRODUCT_PIPD_OWNER / DOC-01`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「FUO」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-575` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-576｜CHILD:U05.3 — MVP

- **來源身份**：`R15.1:L1089`；owner：`TPM_PRODUCT_PIPD_OWNER / DOC-01`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「MVP」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-576` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-577｜CHILD:U05.4 — Non-goals (L5508)

- **來源身份**：`R15.1:L1090`；owner：`TPM_PRODUCT_PIPD_OWNER / DOC-01`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Non-goals (L5508)」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-577` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-578｜CHILD:U06.1 — TPM-SP Systems Engineer 建模 Domain

- **來源身份**：`R15.1:L1091`；owner：`TPM_PRODUCT_PIPD_OWNER / DOC-01`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「TPM-SP Systems Engineer 建模 Domain」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-578` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-579｜CHILD:U06.2 — NFR

- **來源身份**：`R15.1:L1092`；owner：`TPM_PRODUCT_PIPD_OWNER / DOC-01`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「NFR」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-579` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-580｜CHILD:U06.3 — Architecture

- **來源身份**：`R15.1:L1093`；owner：`TPM_PRODUCT_PIPD_OWNER / DOC-01`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Architecture」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-580` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-581｜CHILD:U06.4 — ADR (L5509)

- **來源身份**：`R15.1:L1094`；owner：`TPM_PRODUCT_PIPD_OWNER / DOC-01`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「ADR (L5509)」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-581` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-582｜CHILD:U07.1 — TPM-SP Technical Program Manager 建任務 DAG

- **來源身份**：`R15.1:L1095`；owner：`TPM_PRODUCT_PIPD_OWNER / DOC-01`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「TPM-SP Technical Program Manager 建任務 DAG」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-582` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-583｜CHILD:U07.2 — 里程碑

- **來源身份**：`R15.1:L1096`；owner：`TPM_PRODUCT_PIPD_OWNER / DOC-01`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「里程碑」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-583` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-584｜CHILD:U07.3 — 風險

- **來源身份**：`R15.1:L1097`；owner：`TPM_PRODUCT_PIPD_OWNER / DOC-01`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「風險」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-584` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-585｜CHILD:U07.4 — 交接 (L5510)

- **來源身份**：`R15.1:L1098`；owner：`TPM_PRODUCT_PIPD_OWNER / DOC-01`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「交接 (L5510)」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-585` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-586｜CHILD:U08.1 — TPM-SP Quick

- **來源身份**：`R15.1:L1099`；owner：`TPM_PRODUCT_PIPD_OWNER / DOC-01`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「TPM-SP Quick」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-586` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-587｜CHILD:U08.2 — Guided

- **來源身份**：`R15.1:L1100`；owner：`TPM_PRODUCT_PIPD_OWNER / DOC-01`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Guided」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-587` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-588｜CHILD:U08.3 — Critical 依難度動態問答 (L5511)

- **來源身份**：`R15.1:L1101`；owner：`TPM_PRODUCT_PIPD_OWNER / DOC-01`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Critical 依難度動態問答 (L5511)」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-588` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-589｜CHILD:U09.1 — TPM 使用 BMAD 引導和主動 Help

- **來源身份**：`R15.1:L1102`；owner：`TPM_PRODUCT_PIPD_OWNER / DOC-01`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「TPM 使用 BMAD 引導和主動 Help」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-589` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-590｜CHILD:U09.2 — 教練式探索 (L5512)

- **來源身份**：`R15.1:L1103`；owner：`TPM_PRODUCT_PIPD_OWNER / DOC-01`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「教練式探索 (L5512)」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-590` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-591｜CHILD:U10.1 — TPM 使用 Matt Grilling

- **來源身份**：`R15.1:L1104`；owner：`TPM_PRODUCT_PIPD_OWNER / DOC-01`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「TPM 使用 Matt Grilling」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-591` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-592｜CHILD:U10.2 — Domain Modeling

- **來源身份**：`R15.1:L1105`；owner：`TPM_PRODUCT_PIPD_OWNER / DOC-01`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Domain Modeling」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-592` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-593｜CHILD:U10.3 — Spec

- **來源身份**：`R15.1:L1106`；owner：`TPM_PRODUCT_PIPD_OWNER / DOC-01`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Spec」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-593` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-594｜CHILD:U10.4 — Tickets 分工 (L5513)

- **來源身份**：`R15.1:L1107`；owner：`TPM_PRODUCT_PIPD_OWNER / DOC-01`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Tickets 分工 (L5513)」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-594` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-595｜CHILD:U11.1 — TPM 保留來源

- **來源身份**：`R15.1:L1108`；owner：`TPM_PRODUCT_PIPD_OWNER / DOC-01`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「TPM 保留來源」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-595` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-596｜CHILD:U11.2 — Assumptions

- **來源身份**：`R15.1:L1109`；owner：`TPM_PRODUCT_PIPD_OWNER / DOC-01`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Assumptions」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-596` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-597｜CHILD:U11.3 — Decision Ledger (L5514)

- **來源身份**：`R15.1:L1110`；owner：`TPM_PRODUCT_PIPD_OWNER / DOC-01`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Decision Ledger (L5514)」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-597` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-598｜CHILD:U12.1 — TPM 實際編譯相容 PIPD PI 規格包 (L5515)

- **來源身份**：`R15.1:L1111`；owner：`TPM_PRODUCT_PIPD_OWNER / DOC-01`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「TPM 實際編譯相容 PIPD PI 規格包 (L5515)」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-598` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-599｜CHILD:U13.1 — TPM 實際編譯 PD 環境

- **來源身份**：`R15.1:L1112`；owner：`TPM_PRODUCT_PIPD_OWNER / DOC-01`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「TPM 實際編譯 PD 環境」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-599` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-600｜CHILD:U13.2 — 施工準備包 (L5516)

- **來源身份**：`R15.1:L1113`；owner：`TPM_PRODUCT_PIPD_OWNER / DOC-01`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「施工準備包 (L5516)」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-600` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-601｜CHILD:U14.1 — TPM 具名

- **來源身份**：`R15.1:L1114`；owner：`TPM_PRODUCT_PIPD_OWNER / DOC-01`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「TPM 具名」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-601` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-602｜CHILD:U14.2 — OPS ECP

- **來源身份**：`R15.1:L1115`；owner：`TPM_PRODUCT_PIPD_OWNER / DOC-01`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「OPS ECP」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-602` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-603｜CHILD:U14.3 — DEV ECP

- **來源身份**：`R15.1:L1116`；owner：`TPM_PRODUCT_PIPD_OWNER / DOC-01`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「DEV ECP」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-603` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-604｜CHILD:U14.4 — (L5517)

- **來源身份**：`R15.1:L1117`；owner：`TPM_PRODUCT_PIPD_OWNER / DOC-01`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「(L5517)」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-604` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-605｜CHILD:U15.1 — TPM 具名 TQAEP 測試

- **來源身份**：`R15.1:L1118`；owner：`TPM_PRODUCT_PIPD_OWNER / DOC-01`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「TPM 具名 TQAEP 測試」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-605` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-606｜CHILD:U15.2 — 驗收

- **來源身份**：`R15.1:L1119`；owner：`TPM_PRODUCT_PIPD_OWNER / DOC-01`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「驗收」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-606` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-607｜CHILD:U15.3 — Evidence 包 (L5518)

- **來源身份**：`R15.1:L1120`；owner：`TPM_PRODUCT_PIPD_OWNER / DOC-01`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Evidence 包 (L5518)」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-607` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-608｜CHILD:U16.1 — Commander 是獨立會話

- **來源身份**：`R15.1:L1121`；owner：`CAPC_COMMANDER_OWNER / DOC-04`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Commander 是獨立會話」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-608` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-609｜CHILD:U16.2 — 不能改 Target Repo (L5519)

- **來源身份**：`R15.1:L1122`；owner：`CAPC_COMMANDER_OWNER / DOC-04`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「不能改 Target Repo (L5519)」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-609` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-610｜CHILD:U17.1 — Commander 完整理解凍結 PI

- **來源身份**：`R15.1:L1123`；owner：`CAPC_COMMANDER_OWNER / DOC-04`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Commander 完整理解凍結 PI」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-610` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-611｜CHILD:U17.2 — PD

- **來源身份**：`R15.1:L1124`；owner：`CAPC_COMMANDER_OWNER / DOC-04`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「PD」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-611` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-612｜CHILD:U17.3 — ECP

- **來源身份**：`R15.1:L1125`；owner：`CAPC_COMMANDER_OWNER / DOC-04`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「ECP」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-612` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-613｜CHILD:U17.4 — TQAEP (L5520)

- **來源身份**：`R15.1:L1126`；owner：`CAPC_COMMANDER_OWNER / DOC-04`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「TQAEP (L5520)」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-613` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-614｜CHILD:U18.1 — Commander 使用既有 C0–C9 Compiler

- **來源身份**：`R15.1:L1127`；owner：`CAPC_COMMANDER_OWNER / DOC-04`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Commander 使用既有 C0–C9 Compiler」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-614` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-615｜CHILD:U18.2 — 非第二 Compiler (L5521)

- **來源身份**：`R15.1:L1128`；owner：`CAPC_COMMANDER_OWNER / DOC-04`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「非第二 Compiler (L5521)」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-615` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-616｜CHILD:U19.1 — Commander 產生可貼入本地 Hermes 的「薄 Prompt」 (L5522)

- **來源身份**：`R15.1:L1129`；owner：`CAPC_COMMANDER_OWNER / DOC-04`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Commander 產生可貼入本地 Hermes 的「薄 Prompt」 (L5522)」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-616` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-617｜CHILD:U20.1 — HGK 複查 PD03 RepoContext

- **來源身份**：`R15.1:L1130`；owner：`HGK_FABRIC_OWNER / DOC-04`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「HGK 複查 PD03 RepoContext」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-617` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-618｜CHILD:U20.2 — PD04 WorkOrder

- **來源身份**：`R15.1:L1131`；owner：`HGK_FABRIC_OWNER / DOC-04`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「PD04 WorkOrder」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-618` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-619｜CHILD:U20.3 — ONE ECP

- **來源身份**：`R15.1:L1132`；owner：`HGK_FABRIC_OWNER / DOC-04`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「ONE ECP」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-619` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-620｜CHILD:U20.4 — ExecutionBinding (L5523)

- **來源身份**：`R15.1:L1133`；owner：`HGK_FABRIC_OWNER / DOC-04`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「ExecutionBinding (L5523)」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-620` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-621｜CHILD:U21.1 — HGK TPM Profile 接收 PIPD並複用既有 Document

- **來源身份**：`R15.1:L1134`；owner：`HGK_FABRIC_OWNER / DOC-04`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「HGK TPM Profile 接收 PIPD並複用既有 Document」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-621` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-622｜CHILD:U21.2 — Intake 工程能力 (L5524)

- **來源身份**：`R15.1:L1135`；owner：`HGK_FABRIC_OWNER / DOC-04`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Intake 工程能力 (L5524)」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-622` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-623｜CHILD:U22.1 — HGK Commander Profile 接收 Prompt

- **來源身份**：`R15.1:L1136`；owner：`HGK_FABRIC_OWNER / DOC-04`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「HGK Commander Profile 接收 Prompt」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-623` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-624｜CHILD:U22.2 — Handoff並控制任務路由 (L5525)

- **來源身份**：`R15.1:L1137`；owner：`HGK_FABRIC_OWNER / DOC-04`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Handoff並控制任務路由 (L5525)」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-624` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-625｜CHILD:U23.1 — HGK Challenge

- **來源身份**：`R15.1:L1138`；owner：`HGK_FABRIC_OWNER / DOC-04`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「HGK Challenge」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-625` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-626｜CHILD:U23.2 — AO Profile 接收 Finding＋本地 Local Verification (L5526)

- **來源身份**：`R15.1:L1139`；owner：`HGK_FABRIC_OWNER / DOC-04`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「AO Profile 接收 Finding＋本地 Local Verification (L5526)」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-626` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-627｜CHILD:U24.1 — HGK 呼叫 Fabric 所治理的既有 FAR

- **來源身份**：`R15.1:L1140`；owner：`HGK_FABRIC_OWNER / DOC-04`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「HGK 呼叫 Fabric 所治理的既有 FAR」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-627` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-628｜CHILD:U24.2 — FDA

- **來源身份**：`R15.1:L1141`；owner：`HGK_FABRIC_OWNER / DOC-04`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「FDA」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-628` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-629｜CHILD:U24.3 — 非另建 (L5527)

- **來源身份**：`R15.1:L1142`；owner：`HGK_FABRIC_OWNER / DOC-04`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「非另建 (L5527)」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-629` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-630｜CHILD:U25.1 — HGK 合法受限施工

- **來源身份**：`R15.1:L1143`；owner：`HGK_FABRIC_OWNER / DOC-04`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「HGK 合法受限施工」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-630` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-631｜CHILD:U25.2 — Build

- **來源身份**：`R15.1:L1144`；owner：`HGK_FABRIC_OWNER / DOC-04`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Build」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-631` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-632｜CHILD:U25.3 — Test

- **來源身份**：`R15.1:L1145`；owner：`HGK_FABRIC_OWNER / DOC-04`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Test」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-632` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-633｜CHILD:U25.4 — Repair

- **來源身份**：`R15.1:L1146`；owner：`HGK_FABRIC_OWNER / DOC-04`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Repair」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-633` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-634｜CHILD:U25.5 — Checkpoint (L5528)

- **來源身份**：`R15.1:L1147`；owner：`HGK_FABRIC_OWNER / DOC-04`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Checkpoint (L5528)」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-634` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-635｜CHILD:U26.1 — 施工到 GitHub 的 Source Candidate exact SHA (L5529)

- **來源身份**：`R15.1:L1148`；owner：`EXTERNAL_ASSURANCE_OWNER / DOC-11`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `施工到 GitHub 的 Source Candidate exact SHA (L5529)` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `child WO dependency→own effect receipt→join`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`移除/偽造 ` 或 `sibling receipt cannot pass child`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-635` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-636｜CHILD:U27.1 — Evidence Commit exact SHA 必須

- **來源身份**：`R15.1:L1149`；owner：`EXTERNAL_ASSURANCE_OWNER / DOC-11`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Evidence Commit exact SHA 必須` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `child WO dependency→own effect receipt→join`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`移除/偽造 ` 或 `sibling receipt cannot pass child`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-636` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-637｜CHILD:U27.2 — Source SHA 分開 (L5530)

- **來源身份**：`R15.1:L1150`；owner：`EXTERNAL_ASSURANCE_OWNER / DOC-11`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Source SHA 分開 (L5530)` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `child WO dependency→own effect receipt→join`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`移除/偽造 ` 或 `sibling receipt cannot pass child`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-637` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-638｜CHILD:U28.1 — External Challenge 是另一新對話

- **來源身份**：`R15.1:L1151`；owner：`EXTERNAL_ASSURANCE_OWNER / DOC-11`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「External Challenge 是另一新對話」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-638` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-639｜CHILD:U28.2 — 唯讀 Frozen Readset (L5531)

- **來源身份**：`R15.1:L1152`；owner：`EXTERNAL_ASSURANCE_OWNER / DOC-11`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「唯讀 Frozen Readset (L5531)」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-639` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-640｜CHILD:U29.1 — External Challenge 逐條對照 PI

- **來源身份**：`R15.1:L1153`；owner：`EXTERNAL_ASSURANCE_OWNER / DOC-11`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「External Challenge 逐條對照 PI」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-640` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-641｜CHILD:U29.2 — PD requirements

- **來源身份**：`R15.1:L1154`；owner：`EXTERNAL_ASSURANCE_OWNER / DOC-11`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「PD requirements」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-641` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-642｜CHILD:U29.3 — oracles

- **來源身份**：`R15.1:L1155`；owner：`EXTERNAL_ASSURANCE_OWNER / DOC-11`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「oracles」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-642` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-643｜CHILD:U29.4 — evidence (L5532)

- **來源身份**：`R15.1:L1156`；owner：`EXTERNAL_ASSURANCE_OWNER / DOC-11`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「evidence (L5532)」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-643` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-644｜CHILD:U30.1 — Challenge 產出正式相容的 Review Finding

- **來源身份**：`R15.1:L1157`；owner：`EXTERNAL_ASSURANCE_OWNER / DOC-11`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Challenge 產出正式相容的 Review Finding」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-644` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-645｜CHILD:U30.2 — 報告 (L5533)

- **來源身份**：`R15.1:L1158`；owner：`EXTERNAL_ASSURANCE_OWNER / DOC-11`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「報告 (L5533)」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-645` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-646｜CHILD:U31.1 — Commander 接 Evidence

- **來源身份**：`R15.1:L1159`；owner：`CAPC_COMMANDER_OWNER / DOC-11`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Commander 接 Evidence」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-646` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-647｜CHILD:U31.2 — Findings

- **來源身份**：`R15.1:L1160`；owner：`CAPC_COMMANDER_OWNER / DOC-11`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Findings」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-647` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-648｜CHILD:U31.3 — 計算最小修補錐 (L5534)

- **來源身份**：`R15.1:L1161`；owner：`CAPC_COMMANDER_OWNER / DOC-11`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「計算最小修補錐 (L5534)」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-648` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-649｜CHILD:U32.1 — 修補生成新 Candidate

- **來源身份**：`R15.1:L1162`；owner：`EVOLUTION_EVIDENCE_OWNER / DOC-11`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「修補生成新 Candidate」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-649` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-650｜CHILD:U32.2 — Evidence

- **來源身份**：`R15.1:L1163`；owner：`EVOLUTION_EVIDENCE_OWNER / DOC-11`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Evidence」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-650` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-651｜CHILD:U32.3 — 不覆蓋前版 (L5535)

- **來源身份**：`R15.1:L1164`；owner：`EVOLUTION_EVIDENCE_OWNER / DOC-11`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「不覆蓋前版 (L5535)」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-651` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-652｜CHILD:U33.1 — 外部 Challenge 按高必要性

- **來源身份**：`R15.1:L1165`；owner：`EXTERNAL_ASSURANCE_OWNER / DOC-11`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「外部 Challenge 按高必要性」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-652` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-653｜CHILD:U33.2 — 低 CP 值建議停止 (L5536)

- **來源身份**：`R15.1:L1166`；owner：`EXTERNAL_ASSURANCE_OWNER / DOC-11`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「低 CP 值建議停止 (L5536)」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-653` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-654｜CHILD:U34.1 — 正式 Owner

- **來源身份**：`R15.1:L1167`；owner：`EXTERNAL_ASSURANCE_OWNER / DOC-11`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「正式 Owner」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-654` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-655｜CHILD:U34.2 — Human 決定結案

- **來源身份**：`R15.1:L1168`；owner：`EXTERNAL_ASSURANCE_OWNER / DOC-11`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Human 決定結案」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-655` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-656｜CHILD:U34.3 — 不由 Challenge 自許可 (L5537)

- **來源身份**：`R15.1:L1169`；owner：`EXTERNAL_ASSURANCE_OWNER / DOC-11`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「不由 Challenge 自許可 (L5537)」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-656` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-657｜CHILD:U35.1 — 內部 Loop A Fast Repair

- **來源身份**：`R15.1:L1170`；owner：`HGK_FABRIC_OWNER / DOC-11`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「內部 Loop A Fast Repair」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-657` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-658｜CHILD:U35.2 — Loop B Local Closure

- **來源身份**：`R15.1:L1171`；owner：`HGK_FABRIC_OWNER / DOC-11`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Loop B Local Closure」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-658` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-659｜CHILD:U35.3 — Loop C External Challenge (L5538)

- **來源身份**：`R15.1:L1172`；owner：`HGK_FABRIC_OWNER / DOC-11`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Loop C External Challenge (L5538)」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-659` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-660｜CHILD:U36.1 — 有界 self-research

- **來源身份**：`R15.1:L1173`；owner：`EVOLUTION_EVIDENCE_OWNER / DOC-11`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「有界 self-research」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-660` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-661｜CHILD:U36.2 — review

- **來源身份**：`R15.1:L1174`；owner：`EVOLUTION_EVIDENCE_OWNER / DOC-11`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「review」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-661` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-662｜CHILD:U36.3 — repair

- **來源身份**：`R15.1:L1175`；owner：`EVOLUTION_EVIDENCE_OWNER / DOC-11`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「repair」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-662` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-663｜CHILD:U36.4 — retest

- **來源身份**：`R15.1:L1176`；owner：`EVOLUTION_EVIDENCE_OWNER / DOC-11`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「retest」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-663` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-664｜CHILD:U36.5 — iteration

- **來源身份**：`R15.1:L1177`；owner：`EVOLUTION_EVIDENCE_OWNER / DOC-11`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「iteration」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-664` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-665｜CHILD:U37.1 — Dogfood 發現的失敗轉回退回歸

- **來源身份**：`R15.1:L1178`；owner：`EVOLUTION_EVIDENCE_OWNER / DOC-11`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Dogfood 發現的失敗轉回退回歸」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-665` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-666｜CHILD:U37.2 — 研究

- **來源身份**：`R15.1:L1179`；owner：`EVOLUTION_EVIDENCE_OWNER / DOC-11`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「研究」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-666` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-667｜CHILD:U37.3 — 候選

- **來源身份**：`R15.1:L1180`；owner：`EVOLUTION_EVIDENCE_OWNER / DOC-11`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「候選」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-667` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-668｜CHILD:U37.4 — 而非自改 Oracle (L5540)

- **來源身份**：`R15.1:L1181`；owner：`EVOLUTION_EVIDENCE_OWNER / DOC-11`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「而非自改 Oracle (L5540)」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-668` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-669｜CHILD:U38.1 — Self Dogfood 對 SBL 自己的真實 Repo code

- **來源身份**：`R15.1:L1182`；owner：`EVOLUTION_EVIDENCE_OWNER / DOC-11`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Self Dogfood 對 SBL 自己的真實 Repo code」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-669` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-670｜CHILD:U38.2 — test

- **來源身份**：`R15.1:L1183`；owner：`EVOLUTION_EVIDENCE_OWNER / DOC-11`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「test」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-670` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-671｜CHILD:U38.3 — rollback (L5541)

- **來源身份**：`R15.1:L1184`；owner：`EVOLUTION_EVIDENCE_OWNER / DOC-11`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「rollback (L5541)」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-671` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-672｜CHILD:U39.1 — Cross Dogfood 對 SWOF 的相容工作

- **來源身份**：`R15.1:L1185`；owner：`HGK_FABRIC_OWNER / DOC-11`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Cross Dogfood 對 SWOF 的相容工作」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-672` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-673｜CHILD:U39.2 — 正式 Wave

- **來源身份**：`R15.1:L1186`；owner：`HGK_FABRIC_OWNER / DOC-11`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「正式 Wave」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-673` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-674｜CHILD:U39.3 — Owner 准入 (L5542)

- **來源身份**：`R15.1:L1187`；owner：`HGK_FABRIC_OWNER / DOC-11`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Owner 准入 (L5542)」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-674` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-675｜CHILD:U40.1 — SBL

- **來源身份**：`R15.1:L1188`；owner：`HGK_FABRIC_OWNER / DOC-11`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「SBL」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-675` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-676｜CHILD:U40.2 — PRE-W3 僅過渡 Shadow

- **來源身份**：`R15.1:L1189`；owner：`HGK_FABRIC_OWNER / DOC-11`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「PRE-W3 僅過渡 Shadow」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-676` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-677｜CHILD:U40.3 — 不阻塞正式 PRE-W3 (L5543)

- **來源身份**：`R15.1:L1190`；owner：`HGK_FABRIC_OWNER / DOC-11`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「不阻塞正式 PRE-W3 (L5543)」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-677` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-678｜CHILD:U41.1 — W3

- **來源身份**：`R15.1:L1191`；owner：`HGK_FABRIC_OWNER / DOC-12`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「W3」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-678` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-679｜CHILD:U41.2 — W4

- **來源身份**：`R15.1:L1192`；owner：`HGK_FABRIC_OWNER / DOC-12`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「W4」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-679` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-680｜CHILD:U41.3 — W5 的角色回流 SWOF 正式 OS Team

- **來源身份**：`R15.1:L1193`；owner：`HGK_FABRIC_OWNER / DOC-12`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「W5 的角色回流 SWOF 正式 OS Team」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-680` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-681｜CHILD:U41.4 — Profile

- **來源身份**：`R15.1:L1194`；owner：`HGK_FABRIC_OWNER / DOC-12`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Profile」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-681` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-682｜CHILD:U41.5 — 能力 (L5544)

- **來源身份**：`R15.1:L1195`；owner：`HGK_FABRIC_OWNER / DOC-12`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「能力 (L5544)」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-682` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-683｜CHILD:U42.1 — SBL 能出 Skill

- **來源身份**：`R15.1:L1196`；owner：`SBL_PRODUCT_OWNER / DOC-12`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「SBL 能出 Skill」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-683` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-684｜CHILD:U42.2 — Plugin

- **來源身份**：`R15.1:L1197`；owner：`SBL_PRODUCT_OWNER / DOC-12`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Plugin」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-684` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-685｜CHILD:U42.3 — Agent

- **來源身份**：`R15.1:L1198`；owner：`SBL_PRODUCT_OWNER / DOC-12`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Agent」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-685` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-686｜CHILD:U42.4 — Profile

- **來源身份**：`R15.1:L1199`；owner：`SBL_PRODUCT_OWNER / DOC-12`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Profile」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-686` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-687｜CHILD:U42.5 — Agent OS

- **來源身份**：`R15.1:L1200`；owner：`SBL_PRODUCT_OWNER / DOC-12`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Agent OS」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-687` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-688｜CHILD:U43.1 — 支援 GENIE

- **來源身份**：`R15.1:L1201`；owner：`SBL_PRODUCT_OWNER / DOC-12`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「支援 GENIE」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-688` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-689｜CHILD:U43.2 — GENIE.md 的正式 SWOF 關係不可混同 (L5546)

- **來源身份**：`R15.1:L1202`；owner：`SBL_PRODUCT_OWNER / DOC-12`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「GENIE.md 的正式 SWOF 關係不可混同 (L5546)」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-689` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-690｜CHILD:U44.1 — 提供可操作的新手 E2E 第一有用成果（FUO） (L5547)

- **來源身份**：`R15.1:L1203`；owner：`SBL_PRODUCT_OWNER / DOC-12`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「提供可操作的新手 E2E 第一有用成果（FUO） (L5547)」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-690` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-691｜CHILD:U45.1 — 實作「不是重造輪子」的 24 NOBJ 名稱

- **來源身份**：`R15.1:L1204`；owner：`TOOL_REGISTRY_OWNER / DOC-12`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「實作「不是重造輪子」的 24 NOBJ 名稱」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-691` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-692｜CHILD:U45.2 — 狀態

- **來源身份**：`R15.1:L1205`；owner：`TOOL_REGISTRY_OWNER / DOC-12`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「狀態」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-692` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-693｜CHILD:U45.3 — 准入 (L5548)

- **來源身份**：`R15.1:L1206`；owner：`TOOL_REGISTRY_OWNER / DOC-12`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「准入 (L5548)」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-693` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-694｜CHILD:U46.1 — 保留

- **來源身份**：`R15.1:L1207`；owner：`TOOL_REGISTRY_OWNER / DOC-12`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「保留」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-694` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-695｜CHILD:U46.2 — 1 vs

- **來源身份**：`R15.1:L1208`；owner：`TOOL_REGISTRY_OWNER / DOC-12`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「1 vs」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-695` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-696｜CHILD:U46.3 — 2 版本

- **來源身份**：`R15.1:L1209`；owner：`TOOL_REGISTRY_OWNER / DOC-12`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「2 版本」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-696` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-697｜CHILD:U46.4 — 兩個 Validator 的不相容 (L5549)

- **來源身份**：`R15.1:L1210`；owner：`TOOL_REGISTRY_OWNER / DOC-12`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「兩個 Validator 的不相容 (L5549)」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-697` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-698｜CHILD:U47.1 — Open-source License

- **來源身份**：`R15.1:L1211`；owner：`SBL_RELEASE_OWNER / DOC-12`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Open-source License」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-698` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-699｜CHILD:U47.2 — NOTICE

- **來源身份**：`R15.1:L1212`；owner：`SBL_RELEASE_OWNER / DOC-12`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「NOTICE」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-699` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-700｜CHILD:U47.3 — SBOM

- **來源身份**：`R15.1:L1213`；owner：`SBL_RELEASE_OWNER / DOC-12`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「SBOM」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-700` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-701｜CHILD:U47.4 — Secret

- **來源身份**：`R15.1:L1214`；owner：`SBL_RELEASE_OWNER / DOC-12`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Secret」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-701` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-702｜CHILD:U47.5 — Dependency 所有正式 Gate (L5550)

- **來源身份**：`R15.1:L1215`；owner：`SBL_RELEASE_OWNER / DOC-12`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Dependency 所有正式 Gate (L5550)」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-702` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-703｜CHILD:U48.1 — 產品三模式的 Required Gate

- **來源身份**：`R15.1:L1216`；owner：`ARCHITECT_ASSURANCE_OWNER / DOC-12`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「產品三模式的 Required Gate」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-703` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-704｜CHILD:U48.2 — Forbidden Gate 逐項編譯 (L5551)

- **來源身份**：`R15.1:L1217`；owner：`ARCHITECT_ASSURANCE_OWNER / DOC-12`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Forbidden Gate 逐項編譯 (L5551)」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-704` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-705｜CHILD:U49.1 — 反過度工程 Overengineering Index

- **來源身份**：`R15.1:L1218`；owner：`SBL_PRODUCT_OWNER / DOC-12`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「反過度工程 Overengineering Index」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-705` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-706｜CHILD:U49.2 — 停損 (L5552)

- **來源身份**：`R15.1:L1219`；owner：`SBL_PRODUCT_OWNER / DOC-12`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「停損 (L5552)」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-706` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-707｜CHILD:U50.1 — 提供 workflow

- **來源身份**：`R15.1:L1220`；owner：`ARCHITECT_ASSURANCE_OWNER / DOC-12`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「提供 workflow」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-707` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-708｜CHILD:U50.2 — script

- **來源身份**：`R15.1:L1221`；owner：`ARCHITECT_ASSURANCE_OWNER / DOC-12`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「script」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-708` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-709｜CHILD:U50.3 — config

- **來源身份**：`R15.1:L1222`；owner：`ARCHITECT_ASSURANCE_OWNER / DOC-12`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「config」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-709` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-710｜CHILD:U50.4 — 機器 JSON

- **來源身份**：`R15.1:L1223`；owner：`ARCHITECT_ASSURANCE_OWNER / DOC-12`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「機器 JSON」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-710` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-711｜CHILD:U50.5 — TSV (L5553)

- **來源身份**：`R15.1:L1224`；owner：`ARCHITECT_ASSURANCE_OWNER / DOC-12`；effect family：`INDEPENDENT_REQUIREMENT_ATOM`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「TSV (L5553)」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`移除/偽造 `；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-711` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-712｜USER_MOMENT:M00 — Understand

- **來源身份**：`R15.1:L1236`；owner：`nonempty raw goal with locators`；effect family：`USER_EXPERIENCE_STATE`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Understand」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`empty source refuses ⇒ MOMENT_00_BLOCKED; abort preserves previous SHA; resume rechecks source/permission`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-712` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-713｜USER_MOMENT:M01 — Explore

- **來源身份**：`R15.1:L1237`；owner：`source-bound unknowns identified`；effect family：`USER_EXPERIENCE_STATE`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Explore」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`same hash answer must not reask ⇒ MOMENT_01_BLOCKED; abort preserves previous SHA; resume rechecks source/permission`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-713` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-714｜USER_MOMENT:M02 — Define

- **來源身份**：`R15.1:L1238`；owner：`accepted JTBD+measurable FUO`；effect family：`USER_EXPERIENCE_STATE`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Define」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`FUO cannot be generic ⇒ MOMENT_02_BLOCKED; abort preserves previous SHA; resume rechecks source/permission`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-714` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-715｜USER_MOMENT:M03 — Specify

- **來源身份**：`R15.1:L1239`；owner：`accepted requirement atom(s) with owner`；effect family：`USER_EXPERIENCE_STATE`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Specify」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`PI atom needs risk_guard/source_clause ⇒ MOMENT_03_BLOCKED; abort preserves previous SHA; resume rechecks source/permission`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-715` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-716｜USER_MOMENT:M04 — Architect

- **來源身份**：`R15.1:L1240`；owner：`selected constraints, NFR and architecture alternatives`；effect family：`USER_EXPERIENCE_STATE`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Architect」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`RepoContext unknown => design only ⇒ MOMENT_04_BLOCKED; abort preserves previous SHA; resume rechecks source/permission`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-716` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-717｜USER_MOMENT:M05 — Plan

- **來源身份**：`R15.1:L1241`；owner：`acyclic tasks and owners`；effect family：`USER_EXPERIENCE_STATE`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Plan」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`cycles block plan ⇒ MOMENT_05_BLOCKED; abort preserves previous SHA; resume rechecks source/permission`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-717` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-718｜USER_MOMENT:M06 — Prepare

- **來源身份**：`R15.1:L1242`；owner：`observed RepoContext/HEAD and scope`；effect family：`USER_EXPERIENCE_STATE`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Prepare」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`stale HEAD or no writable_scope block ⇒ MOMENT_06_BLOCKED; abort preserves previous SHA; resume rechecks source/permission`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-718` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-719｜USER_MOMENT:M07 — Build

- **來源身份**：`R15.1:L1243`；owner：`valid token/work order / authorized local user action`；effect family：`USER_EXPERIENCE_STATE`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Build」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`missing permit blocks effect ⇒ MOMENT_07_BLOCKED; abort preserves previous SHA; resume rechecks source/permission`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-719` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-720｜USER_MOMENT:M08 — Test

- **來源身份**：`R15.1:L1244`；owner：`candidate SHA + nonempty test suite`；effect family：`USER_EXPERIENCE_STATE`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Test」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`zero tests / foreign subject block ⇒ MOMENT_08_BLOCKED; abort preserves previous SHA; resume rechecks source/permission`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-720` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-721｜USER_MOMENT:M09 — Review

- **來源身份**：`R15.1:L1245`；owner：`frozen source/candidate diff`；effect family：`USER_EXPERIENCE_STATE`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Review」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`self review cannot become independent ⇒ MOMENT_09_BLOCKED; abort preserves previous SHA; resume rechecks source/permission`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-721` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-722｜USER_MOMENT:M10 — Verify

- **來源身份**：`R15.1:L1246`；owner：`raw evidence with same subject SHA`；effect family：`USER_EXPERIENCE_STATE`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Verify」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`missing checker receipt remains NOT_QUALIFIED ⇒ MOMENT_10_BLOCKED; abort preserves previous SHA; resume rechecks source/permi`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-722` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-723｜USER_MOMENT:M11 — Repair

- **來源身份**：`R15.1:L1247`；owner：`first_fail / affected_only scope`；effect family：`USER_EXPERIENCE_STATE`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Repair」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`retry at-most-one no shotgun ⇒ MOMENT_11_BLOCKED; abort preserves previous SHA; resume rechecks source/permission`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-723` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-724｜USER_MOMENT:M12 — Ship

- **來源身份**：`R15.1:L1248`；owner：`owner release decision+supplier gate`；effect family：`USER_EXPERIENCE_STATE`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Ship」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`missing Human Release Gate=>hold ⇒ MOMENT_12_BLOCKED; abort preserves previous SHA; resume rechecks source/permission`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-724` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-725｜USER_MOMENT:M13 — Maintain

- **來源身份**：`R15.1:L1249`；owner：`published previous version and incident`；effect family：`USER_EXPERIENCE_STATE`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Maintain」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`requalification affected-only ⇒ MOMENT_13_BLOCKED; abort preserves previous SHA; resume rechecks source/permission`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-725` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-726｜USER_MOMENT:M14 — Host Portability

- **來源身份**：`R15.1:L1250`；owner：`HostCapabilityMatrix host+adapter ID`；effect family：`USER_EXPERIENCE_STATE`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Host Portability」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`copy-only != effective load ⇒ MOMENT_14_BLOCKED; abort preserves previous SHA; resume rechecks source/permission`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-726` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-727｜USER_MOMENT:M15 — Private Use

- **來源身份**：`R15.1:L1251`；owner：`consented user private bundle/installation`；effect family：`USER_EXPERIENCE_STATE`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Private Use」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`private ZIP name != usable hosted SP ⇒ MOMENT_15_BLOCKED; abort preserves previous SHA; resume rechecks source/permission`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-727` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-728｜DELIVERY_SURFACE:C-001 — TPM-SP 獨立 Skill（L229；§6.2、§10）

- **來源身份**：`R15.1:L1267`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「TPM-SP 獨立 Skill（L229；§6.2、§10）」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`same candidate Hash + permitted Host real load/invoke/deny/disable/uninstall or signed owner NoFit`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-728` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-729｜DELIVERY_SURFACE:C-002 — Commander-SP 獨立 Skill（L230；§6.2、§10）

- **來源身份**：`R15.1:L1268`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Commander-SP 獨立 Skill（L230；§6.2、§10）」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`same candidate Hash + permitted Host real load/invoke/deny/disable/uninstall or signed owner NoFit`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-729` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-730｜DELIVERY_SURFACE:C-003 — Acceptance Challenge-SP 獨立 Skill（L231；§6.2、§10）

- **來源身份**：`R15.1:L1269`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Acceptance Challenge-SP 獨立 Skill（L231；§6.2、§10）」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`same candidate Hash + permitted Host real load/invoke/deny/disable/uninstall or signed owner NoFit`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-730` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-731｜DELIVERY_SURFACE:C-004 — TPM-SP / Hermes Agent（L232；§10.4）

- **來源身份**：`R15.1:L1270`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「TPM-SP / Hermes Agent（L232；§10.4）」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`same candidate Hash + permitted Host real load/invoke/deny/disable/uninstall or signed owner NoFit`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-731` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-732｜DELIVERY_SURFACE:C-005 — TPM-SP / Codex（L233；§10.4）

- **來源身份**：`R15.1:L1271`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「TPM-SP / Codex（L233；§10.4）」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`same candidate Hash + permitted Host real load/invoke/deny/disable/uninstall or signed owner NoFit`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-732` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-733｜DELIVERY_SURFACE:C-006 — TPM-SP / Claude Code（L234；§10.4）

- **來源身份**：`R15.1:L1272`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「TPM-SP / Claude Code（L234；§10.4）」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`same candidate Hash + permitted Host real load/invoke/deny/disable/uninstall or signed owner NoFit`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-733` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-734｜DELIVERY_SURFACE:C-007 — TPM-SP / DeepSeek Harness（L235；§10.4）

- **來源身份**：`R15.1:L1273`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「TPM-SP / DeepSeek Harness（L235；§10.4）」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`same candidate Hash + permitted Host real load/invoke/deny/disable/uninstall or signed owner NoFit`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-734` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-735｜DELIVERY_SURFACE:C-008 — Commander-SP / Hermes Agent（L236；§10.4）

- **來源身份**：`R15.1:L1274`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Commander-SP / Hermes Agent（L236；§10.4）」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`same candidate Hash + permitted Host real load/invoke/deny/disable/uninstall or signed owner NoFit`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-735` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-736｜DELIVERY_SURFACE:C-009 — Commander-SP / Codex（L237；§10.4）

- **來源身份**：`R15.1:L1275`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Commander-SP / Codex（L237；§10.4）」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`same candidate Hash + permitted Host real load/invoke/deny/disable/uninstall or signed owner NoFit`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-736` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-737｜DELIVERY_SURFACE:C-010 — Commander-SP / Claude Code（L238；§10.4）

- **來源身份**：`R15.1:L1276`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Commander-SP / Claude Code（L238；§10.4）」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`same candidate Hash + permitted Host real load/invoke/deny/disable/uninstall or signed owner NoFit`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-737` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-738｜DELIVERY_SURFACE:C-011 — Commander-SP / DeepSeek Harness（L239；§10.4）

- **來源身份**：`R15.1:L1277`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Commander-SP / DeepSeek Harness（L239；§10.4）」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`same candidate Hash + permitted Host real load/invoke/deny/disable/uninstall or signed owner NoFit`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-738` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-739｜DELIVERY_SURFACE:C-012 — Acceptance Challenge-SP / Hermes（L240；§10.4）

- **來源身份**：`R15.1:L1278`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Acceptance Challenge-SP / Hermes（L240；§10.4）」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`same candidate Hash + permitted Host real load/invoke/deny/disable/uninstall or signed owner NoFit`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-739` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-740｜DELIVERY_SURFACE:C-013 — Acceptance Challenge-SP / Codex（L241；§10.4）

- **來源身份**：`R15.1:L1279`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Acceptance Challenge-SP / Codex（L241；§10.4）」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`same candidate Hash + permitted Host real load/invoke/deny/disable/uninstall or signed owner NoFit`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-740` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-741｜DELIVERY_SURFACE:C-014 — Acceptance Challenge-SP / Claude Code（L242；§10.4）

- **來源身份**：`R15.1:L1280`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Acceptance Challenge-SP / Claude Code（L242；§10.4）」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`same candidate Hash + permitted Host real load/invoke/deny/disable/uninstall or signed owner NoFit`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-741` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-742｜DELIVERY_SURFACE:C-015 — Acceptance Challenge-SP / DeepSeek Harness（L243；§10.4）

- **來源身份**：`R15.1:L1281`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Acceptance Challenge-SP / DeepSeek Harness（L243；§10.4）」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`same candidate Hash + permitted Host real load/invoke/deny/disable/uninstall or signed owner NoFit`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-742` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-743｜DELIVERY_SURFACE:C-016 — TPM-SP ChatGPT private ZIP（L244；§10.1、§12.5）

- **來源身份**：`R15.1:L1282`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「TPM-SP ChatGPT private ZIP（L244；§10.1、§12.5）」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`same candidate Hash + permitted Host real load/invoke/deny/disable/uninstall or signed owner NoFit`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-743` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-744｜DELIVERY_SURFACE:C-017 — Commander-SP ChatGPT private ZIP（L245；§10.1、§12.5）

- **來源身份**：`R15.1:L1283`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Commander-SP ChatGPT private ZIP（L245；§10.1、§12.5）」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`same candidate Hash + permitted Host real load/invoke/deny/disable/uninstall or signed owner NoFit`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-744` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-745｜DELIVERY_SURFACE:C-018 — Challenge-SP ChatGPT private ZIP（L246；§10.1、§12.5）

- **來源身份**：`R15.1:L1284`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Challenge-SP ChatGPT private ZIP（L246；§10.1、§12.5）」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`same candidate Hash + permitted Host real load/invoke/deny/disable/uninstall or signed owner NoFit`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-745` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-746｜DELIVERY_SURFACE:C-019 — TPM-SP ChatGPT Web MD（L247；§10.6）

- **來源身份**：`R15.1:L1285`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「TPM-SP ChatGPT Web MD（L247；§10.6）」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`same candidate Hash + permitted Host real load/invoke/deny/disable/uninstall or signed owner NoFit`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-746` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-747｜DELIVERY_SURFACE:C-020 — Commander-SP ChatGPT Web MD（L248；§10.6）

- **來源身份**：`R15.1:L1286`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Commander-SP ChatGPT Web MD（L248；§10.6）」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`same candidate Hash + permitted Host real load/invoke/deny/disable/uninstall or signed owner NoFit`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-747` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-748｜DELIVERY_SURFACE:C-021 — Challenge-SP ChatGPT Web MD（L249；§10.6）

- **來源身份**：`R15.1:L1287`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Challenge-SP ChatGPT Web MD（L249；§10.6）」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`same candidate Hash + permitted Host real load/invoke/deny/disable/uninstall or signed owner NoFit`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-748` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-749｜DELIVERY_SURFACE:C-022 — TPM-SP Claude Web MD（L250；§10.6）

- **來源身份**：`R15.1:L1288`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「TPM-SP Claude Web MD（L250；§10.6）」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`same candidate Hash + permitted Host real load/invoke/deny/disable/uninstall or signed owner NoFit`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-749` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-750｜DELIVERY_SURFACE:C-023 — Commander-SP Claude Web MD（L251；§10.6）

- **來源身份**：`R15.1:L1289`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Commander-SP Claude Web MD（L251；§10.6）」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`same candidate Hash + permitted Host real load/invoke/deny/disable/uninstall or signed owner NoFit`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-750` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-751｜DELIVERY_SURFACE:C-024 — Challenge-SP Claude Web MD（L252；§10.6）

- **來源身份**：`R15.1:L1290`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Challenge-SP Claude Web MD（L252；§10.6）」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`same candidate Hash + permitted Host real load/invoke/deny/disable/uninstall or signed owner NoFit`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-751` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-752｜DELIVERY_SURFACE:C-025 — TPM-SP Claude Web Native Skill ZIP（L253；§10.6）

- **來源身份**：`R15.1:L1291`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「TPM-SP Claude Web Native Skill ZIP（L253；§10.6）」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`same candidate Hash + permitted Host real load/invoke/deny/disable/uninstall or signed owner NoFit`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-752` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-753｜DELIVERY_SURFACE:C-026 — Commander-SP Claude Web Native Skill ZIP（L254；§10.6）

- **來源身份**：`R15.1:L1292`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Commander-SP Claude Web Native Skill ZIP（L254；§10.6）」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`same candidate Hash + permitted Host real load/invoke/deny/disable/uninstall or signed owner NoFit`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-753` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-754｜DELIVERY_SURFACE:C-027 — Challenge-SP Claude Web Native Skill ZIP（L255；§10.6）

- **來源身份**：`R15.1:L1293`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Challenge-SP Claude Web Native Skill ZIP（L255；§10.6）」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`same candidate Hash + permitted Host real load/invoke/deny/disable/uninstall or signed owner NoFit`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-754` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-755｜DELIVERY_SURFACE:C-028 — TPM-SP 重用 `PIPD-LS-SP`（L256；§2.4、§6.2、§7）

- **來源身份**：`R15.1:L1294`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「TPM-SP 重用 `PIPD-LS-SP`（L256；§2.4、§6.2、§7）」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`same candidate Hash + permitted Host real load/invoke/deny/disable/uninstall or signed owner NoFit`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-755` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-756｜DELIVERY_SURFACE:C-029 — FABRIC_HG-KSEOS 獨立 Stack / Hermes（L257；§6.3、§10）

- **來源身份**：`R15.1:L1295`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「FABRIC_HG-KSEOS 獨立 Stack / Hermes（L257；§6.3、§10）」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`same candidate Hash + permitted Host real load/invoke/deny/disable/uninstall or signed owner NoFit`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-756` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-757｜DELIVERY_SURFACE:C-030 — FABRIC_HG-KSEOS Stack / Codex（L258；§10.4）

- **來源身份**：`R15.1:L1296`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「FABRIC_HG-KSEOS Stack / Codex（L258；§10.4）」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`same candidate Hash + permitted Host real load/invoke/deny/disable/uninstall or signed owner NoFit`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-757` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-758｜DELIVERY_SURFACE:C-031 — FABRIC_HG-KSEOS Stack / Claude Code（L259；§10.4）

- **來源身份**：`R15.1:L1297`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「FABRIC_HG-KSEOS Stack / Claude Code（L259；§10.4）」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`same candidate Hash + permitted Host real load/invoke/deny/disable/uninstall or signed owner NoFit`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-758` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-759｜DELIVERY_SURFACE:C-032 — FABRIC_HG-KSEOS Stack / DeepSeek（L260；§10.4）

- **來源身份**：`R15.1:L1298`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「FABRIC_HG-KSEOS Stack / DeepSeek（L260；§10.4）」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`same candidate Hash + permitted Host real load/invoke/deny/disable/uninstall or signed owner NoFit`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-759` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-760｜DELIVERY_SURFACE:C-033 — SBL Full Stack / Hermes（L261；§10.2～§10.4）

- **來源身份**：`R15.1:L1299`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「SBL Full Stack / Hermes（L261；§10.2～§10.4）」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`same candidate Hash + permitted Host real load/invoke/deny/disable/uninstall or signed owner NoFit`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-760` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-761｜DELIVERY_SURFACE:C-034 — SBL Full Stack / Codex（L262；§10.4）

- **來源身份**：`R15.1:L1300`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「SBL Full Stack / Codex（L262；§10.4）」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`same candidate Hash + permitted Host real load/invoke/deny/disable/uninstall or signed owner NoFit`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-761` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-762｜DELIVERY_SURFACE:C-035 — SBL Full Stack / Claude Code（L263；§10.4）

- **來源身份**：`R15.1:L1301`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「SBL Full Stack / Claude Code（L263；§10.4）」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`same candidate Hash + permitted Host real load/invoke/deny/disable/uninstall or signed owner NoFit`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-762` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-763｜DELIVERY_SURFACE:C-036 — SBL Full Stack / DeepSeek（L264；§10.4）

- **來源身份**：`R15.1:L1302`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「SBL Full Stack / DeepSeek（L264；§10.4）」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`same candidate Hash + permitted Host real load/invoke/deny/disable/uninstall or signed owner NoFit`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-763` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-764｜DELIVERY_SURFACE:C-037 — Selective Install/Upgrade/Rollback（L265；§10.3、§12.7）

- **來源身份**：`R15.1:L1303`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Selective Install/Upgrade/Rollback（L265；§10.3、§12.7）」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`same candidate Hash + permitted Host real load/invoke/deny/disable/uninstall or signed owner NoFit`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-764` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-765｜DELIVERY_SURFACE:C-038 — SBL 自身 CLI (`install/doctor/validate`)（L266；§12.7）

- **來源身份**：`R15.1:L1304`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「SBL 自身 CLI (`install/doctor/validate`)（L266；§12.7）」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`same candidate Hash + permitted Host real load/invoke/deny/disable/uninstall or signed owner NoFit`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-765` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-766｜MODE_GATE:STANDALONE/G00 — R` `ALWAYS`；SBL Master embedded checkrun `MAIN-r2:L559

- **來源身份**：`R15.1:L1312`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「R` `ALWAYS`；SBL Master embedded checkrun `MAIN-r2:L559」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`standalone only user-owned bounded scope`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-766` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-767｜MODE_GATE:PREW3_SHADOW/G00 — R` `ALWAYS`；SBL Master embedded checkrun `MAIN-r2:L559

- **來源身份**：`R15.1:L1313`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「R` `ALWAYS`；SBL Master embedded checkrun `MAIN-r2:L559」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`Shadow zero effect; connected requires real W3 permission`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-767` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-768｜MODE_GATE:SWOF_CONNECTED/G00 — R` `ALWAYS`；SBL Master embedded checkrun `MAIN-r2:L559

- **來源身份**：`R15.1:L1314`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「R` `ALWAYS`；SBL Master embedded checkrun `MAIN-r2:L559」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`Shadow zero effect; connected requires real W3 permission`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-768` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-769｜MODE_GATE:STANDALONE/G01 — R` `ALWAYS`；SBL Master embedded checkrun `MAIN-r2:L560

- **來源身份**：`R15.1:L1315`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「R` `ALWAYS`；SBL Master embedded checkrun `MAIN-r2:L560」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`standalone only user-owned bounded scope`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-769` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-770｜MODE_GATE:PREW3_SHADOW/G01 — R` `ALWAYS`；SBL Master embedded checkrun `MAIN-r2:L560

- **來源身份**：`R15.1:L1316`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「R` `ALWAYS`；SBL Master embedded checkrun `MAIN-r2:L560」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`Shadow zero effect; connected requires real W3 permission`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-770` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-771｜MODE_GATE:SWOF_CONNECTED/G01 — R` `ALWAYS`；SBL Master embedded checkrun `MAIN-r2:L560

- **來源身份**：`R15.1:L1317`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「R` `ALWAYS`；SBL Master embedded checkrun `MAIN-r2:L560」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`Shadow zero effect; connected requires real W3 permission`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-771` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-772｜MODE_GATE:STANDALONE/G02 — C` `CLAIM_HOST_LOADED`；SBL Master embedded checkrun `MAIN-r2:L561

- **來源身份**：`R15.1:L1318`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「C` `CLAIM_HOST_LOADED`；SBL Master embedded checkrun `MAIN-r2:L561」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`standalone only user-owned bounded scope`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-772` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-773｜MODE_GATE:PREW3_SHADOW/G02 — C` `CLAIM_HOST_LOADED`；SBL Master embedded checkrun `MAIN-r2:L561

- **來源身份**：`R15.1:L1319`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「C` `CLAIM_HOST_LOADED`；SBL Master embedded checkrun `MAIN-r2:L561」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`Shadow zero effect; connected requires real W3 permission`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-773` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-774｜MODE_GATE:SWOF_CONNECTED/G02 — C` `CLAIM_HOST_LOADED`；SBL Master embedded checkrun `MAIN-r2:L561

- **來源身份**：`R15.1:L1320`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「C` `CLAIM_HOST_LOADED`；SBL Master embedded checkrun `MAIN-r2:L561」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`Shadow zero effect; connected requires real W3 permission`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-774` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-775｜MODE_GATE:STANDALONE/G03 — C` `COMMANDER_COMPILE_REQUIRED`；SBL Master embedded checkrun `MAIN-r2:L562

- **來源身份**：`R15.1:L1321`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「C` `COMMANDER_COMPILE_REQUIRED`；SBL Master embedded checkrun `MAIN-r2:L562」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`standalone only user-owned bounded scope`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-775` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-776｜MODE_GATE:PREW3_SHADOW/G03 — C` `COMMANDER_COMPILE_REQUIRED`；SBL Master embedded checkrun `MAIN-r2:L562

- **來源身份**：`R15.1:L1322`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「C` `COMMANDER_COMPILE_REQUIRED`；SBL Master embedded checkrun `MAIN-r2:L562」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`Shadow zero effect; connected requires real W3 permission`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-776` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-777｜MODE_GATE:SWOF_CONNECTED/G03 — R` `ALWAYS`；SBL Master embedded checkrun `MAIN-r2:L562

- **來源身份**：`R15.1:L1323`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「R` `ALWAYS`；SBL Master embedded checkrun `MAIN-r2:L562」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`Shadow zero effect; connected requires real W3 permission`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-777` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-778｜MODE_GATE:STANDALONE/G04 — N` `NOT_APPLICABLE`；SBL Master embedded checkrun `MAIN-r2:L563

- **來源身份**：`R15.1:L1324`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「N` `NOT_APPLICABLE`；SBL Master embedded checkrun `MAIN-r2:L563」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`standalone only user-owned bounded scope`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-778` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-779｜MODE_GATE:PREW3_SHADOW/G04 — N` `NOT_APPLICABLE`；SBL Master embedded checkrun `MAIN-r2:L563

- **來源身份**：`R15.1:L1325`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「N` `NOT_APPLICABLE`；SBL Master embedded checkrun `MAIN-r2:L563」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`Shadow zero effect; connected requires real W3 permission`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-779` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-780｜MODE_GATE:SWOF_CONNECTED/G04 — R` `ALWAYS`；SBL Master embedded checkrun `MAIN-r2:L563

- **來源身份**：`R15.1:L1326`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「R` `ALWAYS`；SBL Master embedded checkrun `MAIN-r2:L563」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`Shadow zero effect; connected requires real W3 permission`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-780` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-781｜MODE_GATE:STANDALONE/G05 — C` `CLAIM_INDEPENDENT_OR_CONNECTED`；SBL Master embedded checkrun `MAIN-r2:L564

- **來源身份**：`R15.1:L1327`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「C` `CLAIM_INDEPENDENT_OR_CONNECTED`；SBL Master embedded checkrun `MAIN-r2:L564」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`standalone only user-owned bounded scope`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-781` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-782｜MODE_GATE:PREW3_SHADOW/G05 — C` `CLAIM_INDEPENDENT_OR_CONNECTED`；SBL Master embedded checkrun `MAIN-r2:L564

- **來源身份**：`R15.1:L1328`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「C` `CLAIM_INDEPENDENT_OR_CONNECTED`；SBL Master embedded checkrun `MAIN-r2:L564」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`Shadow zero effect; connected requires real W3 permission`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-782` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-783｜MODE_GATE:SWOF_CONNECTED/G05 — R` `ALWAYS`；SBL Master embedded checkrun `MAIN-r2:L564

- **來源身份**：`R15.1:L1329`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「R` `ALWAYS`；SBL Master embedded checkrun `MAIN-r2:L564」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`Shadow zero effect; connected requires real W3 permission`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-783` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-784｜MODE_GATE:STANDALONE/G06 — R` `ALWAYS`；SBL Master embedded checkrun `MAIN-r2:L565

- **來源身份**：`R15.1:L1330`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「R` `ALWAYS`；SBL Master embedded checkrun `MAIN-r2:L565」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`standalone only user-owned bounded scope`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-784` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-785｜MODE_GATE:PREW3_SHADOW/G06 — C` `RUNNER_OR_FROZEN_EVIDENCE`；SBL Master embedded checkrun `MAIN-r2:L565

- **來源身份**：`R15.1:L1331`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「C` `RUNNER_OR_FROZEN_EVIDENCE`；SBL Master embedded checkrun `MAIN-r2:L565」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`Shadow zero effect; connected requires real W3 permission`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-785` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-786｜MODE_GATE:SWOF_CONNECTED/G06 — R` `ALWAYS`；SBL Master embedded checkrun `MAIN-r2:L565

- **來源身份**：`R15.1:L1332`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「R` `ALWAYS`；SBL Master embedded checkrun `MAIN-r2:L565」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`Shadow zero effect; connected requires real W3 permission`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-786` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-787｜MODE_GATE:STANDALONE/G07 — C` `TARGET_MUTATION_REQUESTED`；SBL Master embedded checkrun `MAIN-r2:L566

- **來源身份**：`R15.1:L1333`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「C` `TARGET_MUTATION_REQUESTED`；SBL Master embedded checkrun `MAIN-r2:L566」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`standalone only user-owned bounded scope`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-787` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-788｜MODE_GATE:PREW3_SHADOW/G07 — F` `REQUEST_DENIED`；SBL Master embedded checkrun `MAIN-r2:L566

- **來源身份**：`R15.1:L1334`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「F` `REQUEST_DENIED`；SBL Master embedded checkrun `MAIN-r2:L566」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`Shadow zero effect; connected requires real W3 permission`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-788` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-789｜MODE_GATE:SWOF_CONNECTED/G07 — R` `ALWAYS`；SBL Master embedded checkrun `MAIN-r2:L566

- **來源身份**：`R15.1:L1335`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「R` `ALWAYS`；SBL Master embedded checkrun `MAIN-r2:L566」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`Shadow zero effect; connected requires real W3 permission`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-789` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-790｜MODE_GATE:STANDALONE/G08 — C` `REPAIR_REQUESTED`；SBL Master embedded checkrun `MAIN-r2:L567

- **來源身份**：`R15.1:L1336`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「C` `REPAIR_REQUESTED`；SBL Master embedded checkrun `MAIN-r2:L567」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`standalone only user-owned bounded scope`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-790` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-791｜MODE_GATE:PREW3_SHADOW/G08 — F` `REQUEST_DENIED`；SBL Master embedded checkrun `MAIN-r2:L567

- **來源身份**：`R15.1:L1337`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「F` `REQUEST_DENIED`；SBL Master embedded checkrun `MAIN-r2:L567」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`Shadow zero effect; connected requires real W3 permission`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-791` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-792｜MODE_GATE:SWOF_CONNECTED/G08 — C` `REPAIR_REQUESTED`；SBL Master embedded checkrun `MAIN-r2:L567

- **來源身份**：`R15.1:L1338`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「C` `REPAIR_REQUESTED`；SBL Master embedded checkrun `MAIN-r2:L567」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`Shadow zero effect; connected requires real W3 permission`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-792` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-793｜MODE_GATE:STANDALONE/G09 — N` `NOT_APPLICABLE`；SBL Master embedded checkrun `MAIN-r2:L568

- **來源身份**：`R15.1:L1339`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「N` `NOT_APPLICABLE`；SBL Master embedded checkrun `MAIN-r2:L568」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`standalone only user-owned bounded scope`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-793` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-794｜MODE_GATE:PREW3_SHADOW/G09 — R` `ALWAYS`；SBL Master embedded checkrun `MAIN-r2:L568

- **來源身份**：`R15.1:L1340`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「R` `ALWAYS`；SBL Master embedded checkrun `MAIN-r2:L568」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`Shadow zero effect; connected requires real W3 permission`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-794` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-795｜MODE_GATE:SWOF_CONNECTED/G09 — C` `PREW3_COMPATIBILITY_REQUESTED`；SBL Master embedded checkrun `MAIN-r2:L568

- **來源身份**：`R15.1:L1341`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「C` `PREW3_COMPATIBILITY_REQUESTED`；SBL Master embedded checkrun `MAIN-r2:L568」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`Shadow zero effect; connected requires real W3 permission`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-795` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-796｜MODE_GATE:STANDALONE/G10 — C` `DOGFOOD_OR_EVOLUTION_REQUESTED`；SBL Master embedded checkrun `MAIN-r2:L569

- **來源身份**：`R15.1:L1342`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「C` `DOGFOOD_OR_EVOLUTION_REQUESTED`；SBL Master embedded checkrun `MAIN-r2:L569」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`standalone only user-owned bounded scope`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-796` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-797｜MODE_GATE:PREW3_SHADOW/G10 — C` `DOGFOOD_OR_EVOLUTION_REQUESTED`；SBL Master embedded checkrun `MAIN-r2:L569

- **來源身份**：`R15.1:L1343`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「C` `DOGFOOD_OR_EVOLUTION_REQUESTED`；SBL Master embedded checkrun `MAIN-r2:L569」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`Shadow zero effect; connected requires real W3 permission`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-797` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-798｜MODE_GATE:SWOF_CONNECTED/G10 — C` `DOGFOOD_OR_EVOLUTION_REQUESTED`；SBL Master embedded checkrun `MAIN-r2:L569

- **來源身份**：`R15.1:L1344`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「C` `DOGFOOD_OR_EVOLUTION_REQUESTED`；SBL Master embedded checkrun `MAIN-r2:L569」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`Shadow zero effect; connected requires real W3 permission`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-798` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-799｜MODE_GATE:STANDALONE/G11 — C` `RELEASE_REQUESTED`；SBL Master embedded checkrun `MAIN-r2:L570

- **來源身份**：`R15.1:L1345`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「C` `RELEASE_REQUESTED`；SBL Master embedded checkrun `MAIN-r2:L570」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`standalone only user-owned bounded scope`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-799` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-800｜MODE_GATE:PREW3_SHADOW/G11 — F` `REQUEST_DENIED`；SBL Master embedded checkrun `MAIN-r2:L570

- **來源身份**：`R15.1:L1346`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「F` `REQUEST_DENIED`；SBL Master embedded checkrun `MAIN-r2:L570」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`Shadow zero effect; connected requires real W3 permission`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-800` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-801｜MODE_GATE:SWOF_CONNECTED/G11 — C` `RELEASE_REQUESTED`；SBL Master embedded checkrun `MAIN-r2:L570

- **來源身份**：`R15.1:L1347`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「C` `RELEASE_REQUESTED`；SBL Master embedded checkrun `MAIN-r2:L570」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`Shadow zero effect; connected requires real W3 permission`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-801` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-802｜MODE_GATE:STANDALONE/G12 — N` `NOT_APPLICABLE`；SBL Master embedded checkrun `MAIN-r2:L571

- **來源身份**：`R15.1:L1348`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「N` `NOT_APPLICABLE`；SBL Master embedded checkrun `MAIN-r2:L571」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`standalone only user-owned bounded scope`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-802` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-803｜MODE_GATE:PREW3_SHADOW/G12 — F` `REQUEST_DENIED`；SBL Master embedded checkrun `MAIN-r2:L571

- **來源身份**：`R15.1:L1349`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「F` `REQUEST_DENIED`；SBL Master embedded checkrun `MAIN-r2:L571」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`Shadow zero effect; connected requires real W3 permission`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-803` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-804｜MODE_GATE:SWOF_CONNECTED/G12 — R` `ALWAYS`；SBL Master embedded checkrun `MAIN-r2:L571

- **來源身份**：`R15.1:L1350`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「R` `ALWAYS`；SBL Master embedded checkrun `MAIN-r2:L571」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`Shadow zero effect; connected requires real W3 permission`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-804` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-805｜R14_TASK:R14-TS00 — 最新狀態唯讀准入 E01

- **來源身份**：`R15.1:L1521`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「最新狀態唯讀准入 E01」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`W00`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-805` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-806｜R14_TASK:R14-TS01 — 14 DOC＋KP／Compiler 正式編譯 E01

- **來源身份**：`R15.1:L1522`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「14 DOC＋KP／Compiler 正式編譯 E01」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`W00`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-806` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-807｜R14_TASK:R14-TS02 — R13 18 紅 conformance 關閉 E01/M1

- **來源身份**：`R15.1:L1523`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「R13 18 紅 conformance 關閉 E01/M1」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`W01`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-807` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-808｜R14_TASK:R14-TS03 — R13 Native 四元組語義驗證 E04/M1

- **來源身份**：`R15.1:L1524`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `R13 Native 四元組語義驗證 E04/M1` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `historical task→fresh owner scope/WorkOrder if affected`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`W01` 或 `no automatic replay`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-808` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-809｜R14_TASK:R14-TS04 — 真安全 Checker 動態重驗 E07/M1

- **來源身份**：`R15.1:L1525`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「真安全 Checker 動態重驗 E07/M1」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`W17, W04`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-809` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-810｜R14_TASK:R14-TS05 — 目前三車道與 Writer 證據 E01/M1

- **來源身份**：`R15.1:L1526`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「目前三車道與 Writer 證據 E01/M1」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`W03, W04, W08`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-810` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-811｜R14_TASK:R14-TS06 — PLAN↔Commander-SP 真介面 E03/M1

- **來源身份**：`R15.1:L1527`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `PLAN↔Commander-SP 真介面 E03/M1` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `historical task→fresh owner scope/WorkOrder if affected`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`W03` 或 `no automatic replay`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-811` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-812｜R14_TASK:R14-TS07 — VERIFY↔Acceptance Challenge-SP 真介面 E03/M1

- **來源身份**：`R15.1:L1528`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「VERIFY↔Acceptance Challenge-SP 真介面 E03/M1」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`W04`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-812` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-813｜R14_TASK:R14-TS08 — HGK Native 升級 Delta E04/M1

- **來源身份**：`R15.1:L1529`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `HGK Native 升級 Delta E04/M1` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `historical task→fresh owner scope/WorkOrder if affected`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`W01` 或 `no automatic replay`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-813` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-814｜R14_TASK:R14-TS09 — Fabric F0 Consumption E04/M1

- **來源身份**：`R15.1:L1530`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Fabric F0 Consumption E04/M1` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `historical task→fresh owner scope/WorkOrder if affected`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`W02` 或 `no automatic replay`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-814` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-815｜R14_TASK:R14-TS10 — 五工具獨立 Host 部署 E06/M1

- **來源身份**：`R15.1:L1531`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「五工具獨立 Host 部署 E06/M1」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`W13`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-815` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-816｜R14_TASK:R14-TS11 — 三 SP ZIP 正式可分發 E06/M1/M4

- **來源身份**：`R15.1:L1532`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「三 SP ZIP 正式可分發 E06/M1/M4」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`W13`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-816` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-817｜R14_TASK:R14-TS12 — 三私人 ChatGPT Plugin 正式資格 E06/M4

- **來源身份**：`R15.1:L1533`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「三私人 ChatGPT Plugin 正式資格 E06/M4」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`W13`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-817` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-818｜R14_TASK:R14-TS13 — 八 PIPD Skills＋Native Writer E02/M2

- **來源身份**：`R15.1:L1534`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `八 PIPD Skills＋Native Writer E02/M2` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `historical task→fresh owner scope/WorkOrder if affected`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`W05` 或 `no automatic replay`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-818` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-819｜R14_TASK:R14-TS14 — TPM／Guided SPEC E02/M2

- **來源身份**：`R15.1:L1535`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `TPM／Guided SPEC E02/M2` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `historical task→fresh owner scope/WorkOrder if affected`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`W05` 或 `no automatic replay`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-819` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-820｜R14_TASK:R14-TS15 — 通用真 Engine／One Core E05/M2

- **來源身份**：`R15.1:L1536`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `通用真 Engine／One Core E05/M2` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `historical task→fresh owner scope/WorkOrder if affected`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`W06` 或 `no automatic replay`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-820` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-821｜R14_TASK:R14-TS16 — Bounded Fix／Recovery E05/M2

- **來源身份**：`R15.1:L1537`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Bounded Fix／Recovery E05/M2」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`W07, W11, W16`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-821` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-822｜R14_TASK:R14-TS17 — TQAEP／Independent Challenge E07/M2

- **來源身份**：`R15.1:L1538`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「TQAEP／Independent Challenge E07/M2」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`W04, W15`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-822` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-823｜R14_TASK:R14-TS18 — SourceBound G-KNOW E02/M2

- **來源身份**：`R15.1:L1539`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `SourceBound G-KNOW E02/M2` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `historical task→fresh owner scope/WorkOrder if affected`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`W05` 或 `no automatic replay`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-823` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-824｜R14_TASK:R14-TS19 — 50 Parent／149 Child 全程追溯 M4

- **來源身份**：`R15.1:L1540`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「50 Parent／149 Child 全程追溯 M4」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`W14`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-824` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-825｜R14_TASK:R14-TS20 — 441 source identities／OSS 導入 M4

- **來源身份**：`R15.1:L1541`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「441 source identities／OSS 導入 M4」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`W14`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-825` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-826｜R14_TASK:R14-TS21 — 38 surfaces／五工具分發 M4

- **來源身份**：`R15.1:L1542`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `38 surfaces／五工具分發 M4` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `historical task→fresh owner scope/WorkOrder if affected`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`W13, W14` 或 `no automatic replay`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-826` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-827｜R14_TASK:R14-TS22 — M1 Native 指揮鏈里程碑

- **來源身份**：`R15.1:L1543`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「M1 Native 指揮鏈里程碑」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`W08, W09`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-827` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-828｜R14_TASK:R14-TS23 — M2 隔離 SWOF 型 Dogfood 里程碑 E08

- **來源身份**：`R15.1:L1544`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「M2 隔離 SWOF 型 Dogfood 里程碑 E08」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`W09, W10, W12`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-828` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-829｜R14_TASK:R14-TS24 — SWOF W2 接收與 W3 准入 E09

- **來源身份**：`R15.1:L1545`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `SWOF W2 接收與 W3 准入 E09` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `historical task→fresh owner scope/WorkOrder if affected`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`W12` 或 `no automatic replay`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-829` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-830｜R14_TASK:R14-TS25 — 第一次真正 SWOF 受治理變更** E09/M3

- **來源身份**：`R15.1:L1546`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「第一次真正 SWOF 受治理變更** E09/M3」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`W12`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-830` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-831｜R14_TASK:R14-TS26 — M3 正式接續里程碑

- **來源身份**：`R15.1:L1547`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `M3 正式接續里程碑` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `historical task→fresh owner scope/WorkOrder if affected`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`W12` 或 `no automatic replay`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-831` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-832｜R14_TASK:R14-TS27 — 全 DOC 語義分母／M4

- **來源身份**：`R15.1:L1548`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `全 DOC 語義分母／M4` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `historical task→fresh owner scope/WorkOrder if affected`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`W14` 或 `no automatic replay`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-832` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-833｜R14_TASK:R14-TS28 — 發行、供應鏈與 GitHub 每輪證據 E06/E07

- **來源身份**：`R15.1:L1549`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「發行、供應鏈與 GitHub 每輪證據 E06/E07」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`W13, W15`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-833` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-834｜R14_TASK:R14-TS29 — R12/R13 積欠逐項閉合

- **來源身份**：`R15.1:L1550`；owner：`D-17/D-18/D-19 + 18 cases + SP ID gaps 各 Owner/receipt，不得「已過」跳過；R12 FAR §2、R13 POST §5–7`；effect family：`HISTORICAL_TASK_WITH_AFFECTED_ONLY_REENTRY`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「R12/R13 積欠逐項閉合」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`W00, W11, W17`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-834` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-835｜R14_TASK:R14-TS30 — M4 FULL Contract＋恢復式終止

- **來源身份**：`R15.1:L1551`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「M4 FULL Contract＋恢復式終止」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`W15, W16, W17`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-835` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-836｜AUDIT_FINDING:A01 — §5 W00..17 table

- **來源身份**：`R15.1:L1570`；owner：`R15 design consumer`；effect family：`EVIDENCE_OR_DESIGN_REMEDIATION`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「§5 W00..17 table」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`deny unauthorized promotion`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-836` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-837｜AUDIT_FINDING:A02 — §6 C00..24 table

- **來源身份**：`R15.1:L1571`；owner：`R15 design consumer`；effect family：`EVIDENCE_OR_DESIGN_REMEDIATION`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「§6 C00..24 table」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`deny unauthorized promotion`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-837` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-838｜AUDIT_FINDING:A03 — §15 31 TS/CHK explicit (TS04 W17)

- **來源身份**：`R15.1:L1572`；owner：`R15 design consumer`；effect family：`EVIDENCE_OR_DESIGN_REMEDIATION`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「§15 31 TS/CHK explicit (TS04 W17)」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`deny unauthorized promotion`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-838` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-839｜AUDIT_FINDING:A04 — §1 10 PIPD docs hashes; §4 eight Skills

- **來源身份**：`R15.1:L1573`；owner：`R15 design consumer`；effect family：`EVIDENCE_OR_DESIGN_REMEDIATION`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「§1 10 PIPD docs hashes; §4 eight Skills」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`deny unauthorized promotion`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-839` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-840｜AUDIT_FINDING:A05 — §1 authority version separation

- **來源身份**：`R15.1:L1574`；owner：`R15 design consumer`；effect family：`EVIDENCE_OR_DESIGN_REMEDIATION`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「§1 authority version separation」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`deny unauthorized promotion`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-840` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-841｜AUDIT_FINDING:A06 — §9 386 ID source-bound records

- **來源身份**：`R15.1:L1575`；owner：`R15 design consumer`；effect family：`EVIDENCE_OR_DESIGN_REMEDIATION`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「§9 386 ID source-bound records」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`deny unauthorized promotion`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-841` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-842｜AUDIT_FINDING:A07 — §7 24 slots

- **來源身份**：`R15.1:L1576`；owner：`R15 design consumer`；effect family：`EVIDENCE_OR_DESIGN_REMEDIATION`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「§7 24 slots」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`deny unauthorized promotion`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-842` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-843｜AUDIT_FINDING:A08 — §8 25 methods

- **來源身份**：`R15.1:L1577`；owner：`R15 design consumer`；effect family：`EVIDENCE_OR_DESIGN_REMEDIATION`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「§8 25 methods」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`deny unauthorized promotion`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-843` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-844｜AUDIT_FINDING:A09 — §7 six named donors

- **來源身份**：`R15.1:L1578`；owner：`R15 design consumer`；effect family：`EVIDENCE_OR_DESIGN_REMEDIATION`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「§7 six named donors」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`deny unauthorized promotion`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-844` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-845｜AUDIT_FINDING:A10 — §2 8×3 product cells

- **來源身份**：`R15.1:L1579`；owner：`R15 design consumer`；effect family：`EVIDENCE_OR_DESIGN_REMEDIATION`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「§2 8×3 product cells」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`deny unauthorized promotion`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-845` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-846｜AUDIT_FINDING:A11 — §14 canonical four Host×3 SP

- **來源身份**：`R15.1:L1580`；owner：`R15 design consumer`；effect family：`EVIDENCE_OR_DESIGN_REMEDIATION`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「§14 canonical four Host×3 SP」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`deny unauthorized promotion`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-846` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-847｜AUDIT_FINDING:A12 — §11 16 Moments

- **來源身份**：`R15.1:L1581`；owner：`R15 design consumer`；effect family：`EVIDENCE_OR_DESIGN_REMEDIATION`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「§11 16 Moments」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`deny unauthorized promotion`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-847` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-848｜AUDIT_FINDING:A13 — §10 50 Parent/149 Child

- **來源身份**：`R15.1:L1582`；owner：`R15 design consumer`；effect family：`EVIDENCE_OR_DESIGN_REMEDIATION`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「§10 50 Parent/149 Child」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`deny unauthorized promotion`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-848` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-849｜AUDIT_FINDING:A14 — §11 38 surfaces/39 gates

- **來源身份**：`R15.1:L1583`；owner：`R15 design consumer`；effect family：`EVIDENCE_OR_DESIGN_REMEDIATION`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「§11 38 surfaces/39 gates」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`deny unauthorized promotion`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-849` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-850｜AUDIT_FINDING:A15 — §3 Core/6 modules/3 SP

- **來源身份**：`R15.1:L1584`；owner：`R15 design consumer`；effect family：`EVIDENCE_OR_DESIGN_REMEDIATION`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「§3 Core/6 modules/3 SP」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`deny unauthorized promotion`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-850` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-851｜AUDIT_FINDING:A16 — §4 19 schemas

- **來源身份**：`R15.1:L1585`；owner：`R15 design consumer`；effect family：`EVIDENCE_OR_DESIGN_REMEDIATION`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「§4 19 schemas」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`deny unauthorized promotion`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-851` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-852｜AUDIT_FINDING:A17 — §4 13 CLI verbs and orphan guard

- **來源身份**：`R15.1:L1586`；owner：`R15 design consumer`；effect family：`EVIDENCE_OR_DESIGN_REMEDIATION`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「§4 13 CLI verbs and orphan guard」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`deny unauthorized promotion`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-852` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-853｜AUDIT_FINDING:A18 — §12 active Fabric RP002 consumer

- **來源身份**：`R15.1:L1587`；owner：`R15 design consumer`；effect family：`EVIDENCE_OR_DESIGN_REMEDIATION`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「§12 active Fabric RP002 consumer」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`deny unauthorized promotion`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-853` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-854｜AUDIT_FINDING:A19 — §12 HGK Native single issuer

- **來源身份**：`R15.1:L1588`；owner：`R15 design consumer`；effect family：`EVIDENCE_OR_DESIGN_REMEDIATION`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `§12 HGK Native single issuer` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `finding→owner defect cone→red repro→fix/recheck`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`deny unauthorized promotion` 或 `未關閉 finding 只繼承，不虛構 cleanup`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-854` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-855｜AUDIT_FINDING:A20 — §14 3 lane model/Principal binding

- **來源身份**：`R15.1:L1589`；owner：`R15 design consumer`；effect family：`EVIDENCE_OR_DESIGN_REMEDIATION`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「§14 3 lane model/Principal binding」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`deny unauthorized promotion`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-855` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-856｜AUDIT_FINDING:A21 — §7/8/14 donor methods, OpenSpec

- **來源身份**：`R15.1:L1590`；owner：`R15 design consumer`；effect family：`EVIDENCE_OR_DESIGN_REMEDIATION`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「§7/8/14 donor methods, OpenSpec」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`deny unauthorized promotion`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-856` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-857｜AUDIT_FINDING:A22 — §12 Kanban/Swarm leases/fan-in

- **來源身份**：`R15.1:L1591`；owner：`R15 design consumer`；effect family：`EVIDENCE_OR_DESIGN_REMEDIATION`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「§12 Kanban/Swarm leases/fan-in」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`deny unauthorized promotion`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-857` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-858｜AUDIT_FINDING:A23 — §12 bounded standing grant exact fields

- **來源身份**：`R15.1:L1592`；owner：`R15 design consumer`；effect family：`EVIDENCE_OR_DESIGN_REMEDIATION`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「§12 bounded standing grant exact fields」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`deny unauthorized promotion`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-858` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-859｜AUDIT_FINDING:A24 — §12 FAR routing/first fail

- **來源身份**：`R15.1:L1593`；owner：`R15 design consumer`；effect family：`EVIDENCE_OR_DESIGN_REMEDIATION`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「§12 FAR routing/first fail」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`deny unauthorized promotion`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-859` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-860｜AUDIT_FINDING:A25 — §12 checkpoint/Native resume

- **來源身份**：`R15.1:L1594`；owner：`R15 design consumer`；effect family：`EVIDENCE_OR_DESIGN_REMEDIATION`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「§12 checkpoint/Native resume」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`deny unauthorized promotion`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-860` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-861｜AUDIT_FINDING:A26 — §12 at-most-once effect vs research retry

- **來源身份**：`R15.1:L1595`；owner：`R15 design consumer`；effect family：`EVIDENCE_OR_DESIGN_REMEDIATION`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「§12 at-most-once effect vs research retry」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`deny unauthorized promotion`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-861` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-862｜AUDIT_FINDING:A27 — §5 W07/§14 bounded repair

- **來源身份**：`R15.1:L1596`；owner：`R15 design consumer`；effect family：`EVIDENCE_OR_DESIGN_REMEDIATION`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「§5 W07/§14 bounded repair」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`deny unauthorized promotion`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-862` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-863｜AUDIT_FINDING:A28 — §14 independent evolution candidate

- **來源身份**：`R15.1:L1597`；owner：`R15 design consumer`；effect family：`EVIDENCE_OR_DESIGN_REMEDIATION`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「§14 independent evolution candidate」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`deny unauthorized promotion`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-863` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-864｜AUDIT_FINDING:A29 — §13 SWOF W2/W3 owner ABI

- **來源身份**：`R15.1:L1598`；owner：`R15 design consumer`；effect family：`EVIDENCE_OR_DESIGN_REMEDIATION`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「§13 SWOF W2/W3 owner ABI」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`deny unauthorized promotion`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-864` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-865｜AUDIT_FINDING:A30 — §3/14 5 tools & 3 ZIP

- **來源身份**：`R15.1:L1599`；owner：`R15 design consumer`；effect family：`EVIDENCE_OR_DESIGN_REMEDIATION`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「§3/14 5 tools & 3 ZIP」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`deny unauthorized promotion`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-865` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-866｜AUDIT_FINDING:A31 — §3/4/13 GENIE/G-KNOW/Builder seams

- **來源身份**：`R15.1:L1600`；owner：`R15 design consumer`；effect family：`EVIDENCE_OR_DESIGN_REMEDIATION`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「§3/4/13 GENIE/G-KNOW/Builder seams」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`deny unauthorized promotion`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-866` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-867｜AUDIT_FINDING:A32 — §11 3 GJ + Moment user flow

- **來源身份**：`R15.1:L1601`；owner：`R15 design consumer`；effect family：`EVIDENCE_OR_DESIGN_REMEDIATION`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「§11 3 GJ + Moment user flow」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`deny unauthorized promotion`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-867` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-868｜AUDIT_FINDING:A33 — §8/9/14 OSS supply-chain

- **來源身份**：`R15.1:L1602`；owner：`R15 design consumer`；effect family：`EVIDENCE_OR_DESIGN_REMEDIATION`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「§8/9/14 OSS supply-chain」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`deny unauthorized promotion`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-868` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-869｜AUDIT_FINDING:A34 — §14 action SHA pin+dependency+Windows

- **來源身份**：`R15.1:L1603`；owner：`R15 design consumer`；effect family：`EVIDENCE_OR_DESIGN_REMEDIATION`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「§14 action SHA pin+dependency+Windows」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`deny unauthorized promotion`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-869` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-870｜AUDIT_FINDING:A35 — §5 real full preflight/dirty/junction

- **來源身份**：`R15.1:L1604`；owner：`R15 design consumer`；effect family：`EVIDENCE_OR_DESIGN_REMEDIATION`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「§5 real full preflight/dirty/junction」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`deny unauthorized promotion`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-870` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-871｜AUDIT_FINDING:A36 — §14 branch ruleset current verification

- **來源身份**：`R15.1:L1605`；owner：`R15 design consumer`；effect family：`EVIDENCE_OR_DESIGN_REMEDIATION`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「§14 branch ruleset current verification」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`deny unauthorized promotion`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-871` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-872｜AUDIT_FINDING:A37 — §14 paired B0/B1/B2

- **來源身份**：`R15.1:L1606`；owner：`R15 design consumer`；effect family：`EVIDENCE_OR_DESIGN_REMEDIATION`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `§14 paired B0/B1/B2` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `finding→owner defect cone→red repro→fix/recheck`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`deny unauthorized promotion` 或 `未關閉 finding 只繼承，不虛構 cleanup`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-872` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-873｜AUDIT_FINDING:A38 — §14 objective anti-overfit checker

- **來源身份**：`R15.1:L1607`；owner：`R15 design consumer`；effect family：`EVIDENCE_OR_DESIGN_REMEDIATION`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「§14 objective anti-overfit checker」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`deny unauthorized promotion`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-873` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-874｜AUDIT_FINDING:A39 — §5 task→Issue→PR/OROCHI

- **來源身份**：`R15.1:L1608`；owner：`R15 design consumer`；effect family：`EVIDENCE_OR_DESIGN_REMEDIATION`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「§5 task→Issue→PR/OROCHI」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`deny unauthorized promotion`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-874` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-875｜AUDIT_FINDING:A40 — §5 bounded path discovery

- **來源身份**：`R15.1:L1609`；owner：`R15 design consumer`；effect family：`EVIDENCE_OR_DESIGN_REMEDIATION`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「§5 bounded path discovery」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`deny unauthorized promotion`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-875` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-876｜AUDIT_FINDING:A41 — §2 usable NoFit fallback

- **來源身份**：`R15.1:L1610`；owner：`R15 design consumer`；effect family：`EVIDENCE_OR_DESIGN_REMEDIATION`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「§2 usable NoFit fallback」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`deny unauthorized promotion`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-876` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-877｜AUDIT_FINDING:A42 — §1/15 R14 branch transplant

- **來源身份**：`R15.1:L1611`；owner：`R15 design consumer`；effect family：`EVIDENCE_OR_DESIGN_REMEDIATION`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「§1/15 R14 branch transplant」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`deny unauthorized promotion`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-877` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-878｜AUDIT_FINDING:A43 — §12/14 Token ACL/host permission

- **來源身份**：`R15.1:L1612`；owner：`R15 design consumer`；effect family：`EVIDENCE_OR_DESIGN_REMEDIATION`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「§12/14 Token ACL/host permission」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`deny unauthorized promotion`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-878` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-879｜AUDIT_FINDING:A44 — §5/6 verified machine execution vs TSV

- **來源身份**：`R15.1:L1613`；owner：`R15 design consumer`；effect family：`EVIDENCE_OR_DESIGN_REMEDIATION`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「§5/6 verified machine execution vs TSV」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`deny unauthorized promotion`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-879` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-880｜AUDIT_FINDING:A45 — §1/7–11 exact Source line locators

- **來源身份**：`R15.1:L1614`；owner：`R15 design consumer`；effect family：`EVIDENCE_OR_DESIGN_REMEDIATION`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `§1/7–11 exact Source line locators` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `finding→owner defect cone→red repro→fix/recheck`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`deny unauthorized promotion` 或 `未關閉 finding 只繼承，不虛構 cleanup`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-880` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-881｜AUDIT_FINDING:A46 — §12 event-specific mandatory HITL

- **來源身份**：`R15.1:L1615`；owner：`R15 design consumer`；effect family：`EVIDENCE_OR_DESIGN_REMEDIATION`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「§12 event-specific mandatory HITL」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`deny unauthorized promotion`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-881` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-882｜AUDIT_FINDING:A47 — §5 per-root cause WorkPackage local repair

- **來源身份**：`R15.1:L1616`；owner：`R15 design consumer`；effect family：`EVIDENCE_OR_DESIGN_REMEDIATION`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「§5 per-root cause WorkPackage local repair」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`deny unauthorized promotion`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-882` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-883｜AUDIT_FINDING:A48 — §16 M1–M4 Full Product exit

- **來源身份**：`R15.1:L1617`；owner：`R15 design consumer`；effect family：`EVIDENCE_OR_DESIGN_REMEDIATION`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「§16 M1–M4 Full Product exit」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`deny unauthorized promotion`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-883` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-884｜CONTRACT:ArtifactIdentity — identity/supersedes/invalidates

- **來源身份**：`R15.1:L227`；owner：`all planes`；effect family：`SCHEMA_VALIDATION_ONLY`；disposition：`B1_REQUIRED`。
- **受影必備功能**：`PIPD registry $id/input/output native validation`；先以 `identity/supersedes/invalidates` 的原 domain 輸入形成 `SourceBoundCandidate`，查真 Host/Repo/Owner；適用於 B1 的精確 operation 以該 family 的 native endpoint 載入後方可執行。
- **拒收**：原負例 `POS canonical schema instance validates; NEG altered $id/owner/scope fails registry reconciliation` 與 `schema field missing⇒reject; no false PIPD ID`；缺生效 ABI/Token/Issuer/HostReadback 一律 `HOLD_B1_REQUIRED`，不能因 row 存在 PASS。
- **可反證結果**：只能用此 `id=R15-884` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-885｜CONTRACT:AuthorityBinding — rank/conflict/currentness

- **來源身份**：`R15.1:L228`；owner：`all compilers/adapters`；effect family：`SCHEMA_VALIDATION_ONLY`；disposition：`B1_REQUIRED`。
- **受影必備功能**：`PIPD registry $id/input/output native validation`；先以 `rank/conflict/currentness` 的原 domain 輸入形成 `SourceBoundCandidate`，查真 Host/Repo/Owner；適用於 B1 的精確 operation 以該 family 的 native endpoint 載入後方可執行。
- **拒收**：原負例 `POS canonical schema instance validates; NEG altered $id/owner/scope fails registry reconciliation` 與 `schema field missing⇒reject; no false PIPD ID`；缺生效 ABI/Token/Issuer/HostReadback 一律 `HOLD_B1_REQUIRED`，不能因 row 存在 PASS。
- **可反證結果**：只能用此 `id=R15-885` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-886｜CONTRACT:RequirementAtom — req/source/owner/acceptance/risk

- **來源身份**：`R15.1:L229`；owner：`PI/TQAEP`；effect family：`SCHEMA_VALIDATION_ONLY`；disposition：`B1_REQUIRED`。
- **受影必備功能**：`PIPD registry $id/input/output native validation`；先以 `req/source/owner/acceptance/risk` 的原 domain 輸入形成 `SourceBoundCandidate`，查真 Host/Repo/Owner；適用於 B1 的精確 operation 以該 family 的 native endpoint 載入後方可執行。
- **拒收**：原負例 `POS canonical schema instance validates; NEG altered $id/owner/scope fails registry reconciliation` 與 `schema field missing⇒reject; no false PIPD ID`；缺生效 ABI/Token/Issuer/HostReadback 一律 `HOLD_B1_REQUIRED`，不能因 row 存在 PASS。
- **可反證結果**：只能用此 `id=R15-886` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-887｜CONTRACT:ProfileBinding — weight/axes/veto/assurance

- **來源身份**：`R15.1:L230`；owner：`Skills/JIT/HGK`；effect family：`SCHEMA_VALIDATION_ONLY`；disposition：`B1_REQUIRED`。
- **受影必備功能**：`PIPD registry $id/input/output native validation`；先以 `weight/axes/veto/assurance` 的原 domain 輸入形成 `SourceBoundCandidate`，查真 Host/Repo/Owner；適用於 B1 的精確 operation 以該 family 的 native endpoint 載入後方可執行。
- **拒收**：原負例 `POS canonical schema instance validates; NEG altered $id/owner/scope fails registry reconciliation` 與 `schema field missing⇒reject; no false PIPD ID`；缺生效 ABI/Token/Issuer/HostReadback 一律 `HOLD_B1_REQUIRED`，不能因 row 存在 PASS。
- **可反證結果**：只能用此 `id=R15-887` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-888｜CONTRACT:TechnologyAdmission — need/selected disposition/pin/license/fallback

- **來源身份**：`R15.1:L231`；owner：`tool/provider`；effect family：`SCHEMA_VALIDATION_ONLY`；disposition：`B1_REQUIRED`。
- **受影必備功能**：`PIPD registry $id/input/output native validation`；先以 `need/selected disposition/pin/license/fallback` 的原 domain 輸入形成 `SourceBoundCandidate`，查真 Host/Repo/Owner；適用於 B1 的精確 operation 以該 family 的 native endpoint 載入後方可執行。
- **拒收**：原負例 `POS canonical schema instance validates; NEG altered $id/owner/scope fails registry reconciliation` 與 `schema field missing⇒reject; no false PIPD ID`；缺生效 ABI/Token/Issuer/HostReadback 一律 `HOLD_B1_REQUIRED`，不能因 row 存在 PASS。
- **可反證結果**：只能用此 `id=R15-888` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-889｜CONTRACT:PI-PKG — stable semantic + trace

- **來源身份**：`R15.1:L232`；owner：`PD binder`；effect family：`SCHEMA_VALIDATION_ONLY`；disposition：`B1_REQUIRED`。
- **受影必備功能**：`PIPD registry $id/input/output native validation`；先以 `stable semantic + trace` 的原 domain 輸入形成 `SourceBoundCandidate`，查真 Host/Repo/Owner；適用於 B1 的精確 operation 以該 family 的 native endpoint 載入後方可執行。
- **拒收**：原負例 `POS canonical schema instance validates; NEG altered $id/owner/scope fails registry reconciliation` 與 `schema field missing⇒reject; no false PIPD ID`；缺生效 ABI/Token/Issuer/HostReadback 一律 `HOLD_B1_REQUIRED`，不能因 row 存在 PASS。
- **可反證結果**：只能用此 `id=R15-889` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-890｜CONTRACT:PD-PKG — RepoContext/currentness/affected scope

- **來源身份**：`R15.1:L233`；owner：`execution`；effect family：`SCHEMA_VALIDATION_ONLY`；disposition：`B1_REQUIRED`。
- **受影必備功能**：`PIPD registry $id/input/output native validation`；先以 `RepoContext/currentness/affected scope` 的原 domain 輸入形成 `SourceBoundCandidate`，查真 Host/Repo/Owner；適用於 B1 的精確 operation 以該 family 的 native endpoint 載入後方可執行。
- **拒收**：原負例 `POS canonical schema instance validates; NEG altered $id/owner/scope fails registry reconciliation` 與 `schema field missing⇒reject; no false PIPD ID`；缺生效 ABI/Token/Issuer/HostReadback 一律 `HOLD_B1_REQUIRED`，不能因 row 存在 PASS。
- **可反證結果**：只能用此 `id=R15-890` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-891｜CONTRACT:TraceLink — typed ref+from_hash+to_hash

- **來源身份**：`R15.1:L234`；owner：`checker`；effect family：`SCHEMA_VALIDATION_ONLY`；disposition：`B1_REQUIRED`。
- **受影必備功能**：`PIPD registry $id/input/output native validation`；先以 `typed ref+from_hash+to_hash` 的原 domain 輸入形成 `SourceBoundCandidate`，查真 Host/Repo/Owner；適用於 B1 的精確 operation 以該 family 的 native endpoint 載入後方可執行。
- **拒收**：原負例 `POS canonical schema instance validates; NEG altered $id/owner/scope fails registry reconciliation` 與 `schema field missing⇒reject; no false PIPD ID`；缺生效 ABI/Token/Issuer/HostReadback 一律 `HOLD_B1_REQUIRED`，不能因 row 存在 PASS。
- **可反證結果**：只能用此 `id=R15-891` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-892｜CONTRACT:TaskSpecSeed — goals/input/output/tests/rollback

- **來源身份**：`R15.1:L235`；owner：`receiver adapter`；effect family：`SCHEMA_VALIDATION_ONLY`；disposition：`B1_REQUIRED`。
- **受影必備功能**：`PIPD registry $id/input/output native validation`；先以 `goals/input/output/tests/rollback` 的原 domain 輸入形成 `SourceBoundCandidate`，查真 Host/Repo/Owner；適用於 B1 的精確 operation 以該 family 的 native endpoint 載入後方可執行。
- **拒收**：原負例 `POS canonical schema instance validates; NEG altered $id/owner/scope fails registry reconciliation` 與 `schema field missing⇒reject; no false PIPD ID`；缺生效 ABI/Token/Issuer/HostReadback 一律 `HOLD_B1_REQUIRED`，不能因 row 存在 PASS。
- **可反證結果**：只能用此 `id=R15-892` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-893｜CONTRACT:ConstructionContract — writes/tests/evidence/rollback

- **來源身份**：`R15.1:L236`；owner：`HGK adapter`；effect family：`SCHEMA_VALIDATION_ONLY`；disposition：`B1_REQUIRED`。
- **受影必備功能**：`PIPD registry $id/input/output native validation`；先以 `writes/tests/evidence/rollback` 的原 domain 輸入形成 `SourceBoundCandidate`，查真 Host/Repo/Owner；適用於 B1 的精確 operation 以該 family 的 native endpoint 載入後方可執行。
- **拒收**：原負例 `POS canonical schema instance validates; NEG altered $id/owner/scope fails registry reconciliation` 與 `schema field missing⇒reject; no false PIPD ID`；缺生效 ABI/Token/Issuer/HostReadback 一律 `HOLD_B1_REQUIRED`，不能因 row 存在 PASS。
- **可反證結果**：只能用此 `id=R15-893` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-894｜CONTRACT:WorkOrderCandidate — candidate_only/never native

- **來源身份**：`R15.1:L237`；owner：`HGK admission`；effect family：`SCHEMA_VALIDATION_ONLY`；disposition：`B1_REQUIRED`。
- **受影必備功能**：`PIPD registry $id/input/output native validation`；先以 `candidate_only/never native` 的原 domain 輸入形成 `SourceBoundCandidate`，查真 Host/Repo/Owner；適用於 B1 的精確 operation 以該 family 的 native endpoint 載入後方可執行。
- **拒收**：原負例 `POS canonical schema instance validates; NEG altered $id/owner/scope fails registry reconciliation` 與 `schema field missing⇒reject; no false PIPD ID`；缺生效 ABI/Token/Issuer/HostReadback 一律 `HOLD_B1_REQUIRED`，不能因 row 存在 PASS。
- **可反證結果**：只能用此 `id=R15-894` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-895｜CONTRACT:ECP — effect/permission/retries/idempotency/readback

- **來源身份**：`R15.1:L238`；owner：`HGK/TQAEP`；effect family：`SCHEMA_VALIDATION_ONLY`；disposition：`B1_REQUIRED`。
- **受影必備功能**：`PIPD registry $id/input/output native validation`；先以 `effect/permission/retries/idempotency/readback` 的原 domain 輸入形成 `SourceBoundCandidate`，查真 Host/Repo/Owner；適用於 B1 的精確 operation 以該 family 的 native endpoint 載入後方可執行。
- **拒收**：原負例 `POS canonical schema instance validates; NEG altered $id/owner/scope fails registry reconciliation` 與 `schema field missing⇒reject; no false PIPD ID`；缺生效 ABI/Token/Issuer/HostReadback 一律 `HOLD_B1_REQUIRED`，不能因 row 存在 PASS。
- **可反證結果**：只能用此 `id=R15-895` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-896｜CONTRACT:TQAEP — tests/oracles/POS/NEG/requalification

- **來源身份**：`R15.1:L239`；owner：`checker/release`；effect family：`SCHEMA_VALIDATION_ONLY`；disposition：`B1_REQUIRED`。
- **受影必備功能**：`PIPD registry $id/input/output native validation`；先以 `tests/oracles/POS/NEG/requalification` 的原 domain 輸入形成 `SourceBoundCandidate`，查真 Host/Repo/Owner；適用於 B1 的精確 operation 以該 family 的 native endpoint 載入後方可執行。
- **拒收**：原負例 `POS canonical schema instance validates; NEG altered $id/owner/scope fails registry reconciliation` 與 `schema field missing⇒reject; no false PIPD ID`；缺生效 ABI/Token/Issuer/HostReadback 一律 `HOLD_B1_REQUIRED`，不能因 row 存在 PASS。
- **可反證結果**：只能用此 `id=R15-896` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-897｜CONTRACT:ExecutionHandoff — receiver/ack-nack/payload refs

- **來源身份**：`R15.1:L240`；owner：`HGK receiver`；effect family：`SCHEMA_VALIDATION_ONLY`；disposition：`B1_REQUIRED`。
- **受影必備功能**：`PIPD registry $id/input/output native validation`；先以 `receiver/ack-nack/payload refs` 的原 domain 輸入形成 `SourceBoundCandidate`，查真 Host/Repo/Owner；適用於 B1 的精確 operation 以該 family 的 native endpoint 載入後方可執行。
- **拒收**：原負例 `POS canonical schema instance validates; NEG altered $id/owner/scope fails registry reconciliation` 與 `schema field missing⇒reject; no false PIPD ID`；缺生效 ABI/Token/Issuer/HostReadback 一律 `HOLD_B1_REQUIRED`，不能因 row 存在 PASS。
- **可反證結果**：只能用此 `id=R15-897` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-898｜CONTRACT:EvidenceExpectation — producer/postcondition/freshness

- **來源身份**：`R15.1:L241`；owner：`runner`；effect family：`SCHEMA_VALIDATION_ONLY`；disposition：`B1_REQUIRED`。
- **受影必備功能**：`PIPD registry $id/input/output native validation`；先以 `producer/postcondition/freshness` 的原 domain 輸入形成 `SourceBoundCandidate`，查真 Host/Repo/Owner；適用於 B1 的精確 operation 以該 family 的 native endpoint 載入後方可執行。
- **拒收**：原負例 `POS canonical schema instance validates; NEG altered $id/owner/scope fails registry reconciliation` 與 `schema field missing⇒reject; no false PIPD ID`；缺生效 ABI/Token/Issuer/HostReadback 一律 `HOLD_B1_REQUIRED`，不能因 row 存在 PASS。
- **可反證結果**：只能用此 `id=R15-898` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-899｜CONTRACT:ClaimCeiling — allowed/forbidden/close

- **來源身份**：`R15.1:L242`；owner：`all planes`；effect family：`SCHEMA_VALIDATION_ONLY`；disposition：`B1_REQUIRED`。
- **受影必備功能**：`PIPD registry $id/input/output native validation`；先以 `allowed/forbidden/close` 的原 domain 輸入形成 `SourceBoundCandidate`，查真 Host/Repo/Owner；適用於 B1 的精確 operation 以該 family 的 native endpoint 載入後方可執行。
- **拒收**：原負例 `POS canonical schema instance validates; NEG altered $id/owner/scope fails registry reconciliation` 與 `schema field missing⇒reject; no false PIPD ID`；缺生效 ABI/Token/Issuer/HostReadback 一律 `HOLD_B1_REQUIRED`，不能因 row 存在 PASS。
- **可反證結果**：只能用此 `id=R15-899` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-900｜CONTRACT:SurfaceProjectionManifest — source/variant/parity_loss/stale

- **來源身份**：`R15.1:L243`；owner：`surface compiler`；effect family：`SCHEMA_VALIDATION_ONLY`；disposition：`B1_REQUIRED`。
- **受影必備功能**：`PIPD registry $id/input/output native validation`；先以 `source/variant/parity_loss/stale` 的原 domain 輸入形成 `SourceBoundCandidate`，查真 Host/Repo/Owner；適用於 B1 的精確 operation 以該 family 的 native endpoint 載入後方可執行。
- **拒收**：原負例 `POS canonical schema instance validates; NEG altered $id/owner/scope fails registry reconciliation` 與 `schema field missing⇒reject; no false PIPD ID`；缺生效 ABI/Token/Issuer/HostReadback 一律 `HOLD_B1_REQUIRED`，不能因 row 存在 PASS。
- **可反證結果**：只能用此 `id=R15-900` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-901｜CONTRACT:GENIEProjectionRef — GENIE-only adapter/schema seam

- **來源身份**：`R15.1:L244`；owner：`GENIE compiler`；effect family：`SCHEMA_VALIDATION_ONLY`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「GENIE-only adapter/schema seam」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`POS canonical schema instance validates; NEG altered $id/owner/scope fails registry reconciliation`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-901` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-902｜CONTRACT:ExecutionBindingRef — HGK-only receiver lease/ref seam

- **來源身份**：`R15.1:L245`；owner：`HGK`；effect family：`SCHEMA_VALIDATION_ONLY`；disposition：`B1_REQUIRED`。
- **受影必備功能**：`PIPD registry $id/input/output native validation`；先以 `HGK-only receiver lease/ref seam` 的原 domain 輸入形成 `SourceBoundCandidate`，查真 Host/Repo/Owner；適用於 B1 的精確 operation 以該 family 的 native endpoint 載入後方可執行。
- **拒收**：原負例 `POS canonical schema instance validates; NEG altered $id/owner/scope fails registry reconciliation` 與 `schema field missing⇒reject; no false PIPD ID`；缺生效 ABI/Token/Issuer/HostReadback 一律 `HOLD_B1_REQUIRED`，不能因 row 存在 PASS。
- **可反證結果**：只能用此 `id=R15-902` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-903｜PIPD_CLI:pipd init — project root manifests

- **來源身份**：`R15.1:L253`；owner：`PIPD_CLI_OWNER`；effect family：`CLI_EFFECT_BY_VERB`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `project root manifests` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `exact 13 verbs with strict flags and native CLI result`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`wrong root/secret path` 或 `no imaginary 14th verb`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-903` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-904｜PIPD_CLI:pipd intake — Goal→IntentCard

- **來源身份**：`R15.1:L254`；owner：`PIPD_CLI_OWNER`；effect family：`CLI_EFFECT_BY_VERB`；disposition：`B1_REQUIRED`。
- **受影必備功能**：`exact 13 verbs with strict flags and native CLI result`；先以 `Goal→IntentCard` 的原 domain 輸入形成 `SourceBoundCandidate`，查真 Host/Repo/Owner；適用於 B1 的精確 operation 以該 family 的 native endpoint 載入後方可執行。
- **拒收**：原負例 `zero locator/injection` 與 `no imaginary 14th verb`；缺生效 ABI/Token/Issuer/HostReadback 一律 `HOLD_B1_REQUIRED`，不能因 row 存在 PASS。
- **可反證結果**：只能用此 `id=R15-904` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-905｜PIPD_CLI:pipd profile — risk/axes→binding

- **來源身份**：`R15.1:L255`；owner：`PIPD_CLI_OWNER`；effect family：`CLI_EFFECT_BY_VERB`；disposition：`B1_REQUIRED`。
- **受影必備功能**：`exact 13 verbs with strict flags and native CLI result`；先以 `risk/axes→binding` 的原 domain 輸入形成 `SourceBoundCandidate`，查真 Host/Repo/Owner；適用於 B1 的精確 operation 以該 family 的 native endpoint 載入後方可執行。
- **拒收**：原負例 `unknown axes` 與 `no imaginary 14th verb`；缺生效 ABI/Token/Issuer/HostReadback 一律 `HOLD_B1_REQUIRED`，不能因 row 存在 PASS。
- **可反證結果**：只能用此 `id=R15-905` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-906｜PIPD_CLI:pipd compile-pi — frozen intent→PI

- **來源身份**：`R15.1:L256`；owner：`PIPD_CLI_OWNER`；effect family：`CLI_EFFECT_BY_VERB`；disposition：`B1_REQUIRED`。
- **受影必備功能**：`exact 13 verbs with strict flags and native CLI result`；先以 `frozen intent→PI` 的原 domain 輸入形成 `SourceBoundCandidate`，查真 Host/Repo/Owner；適用於 B1 的精確 operation 以該 family 的 native endpoint 載入後方可執行。
- **拒收**：原負例 `orphan/zero atom` 與 `no imaginary 14th verb`；缺生效 ABI/Token/Issuer/HostReadback 一律 `HOLD_B1_REQUIRED`，不能因 row 存在 PASS。
- **可反證結果**：只能用此 `id=R15-906` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-907｜PIPD_CLI:pipd bind-pd — RepoContext→PD

- **來源身份**：`R15.1:L257`；owner：`PIPD_CLI_OWNER`；effect family：`CLI_EFFECT_BY_VERB`；disposition：`B1_REQUIRED`。
- **受影必備功能**：`exact 13 verbs with strict flags and native CLI result`；先以 `RepoContext→PD` 的原 domain 輸入形成 `SourceBoundCandidate`，查真 Host/Repo/Owner；適用於 B1 的精確 operation 以該 family 的 native endpoint 載入後方可執行。
- **拒收**：原負例 `stale HEAD/scope **` 與 `no imaginary 14th verb`；缺生效 ABI/Token/Issuer/HostReadback 一律 `HOLD_B1_REQUIRED`，不能因 row 存在 PASS。
- **可反證結果**：只能用此 `id=R15-907` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-908｜PIPD_CLI:pipd compile-ecp — PD→ECP candidate

- **來源身份**：`R15.1:L258`；owner：`PIPD_CLI_OWNER`；effect family：`CLI_EFFECT_BY_VERB`；disposition：`B1_REQUIRED`。
- **受影必備功能**：`exact 13 verbs with strict flags and native CLI result`；先以 `PD→ECP candidate` 的原 domain 輸入形成 `SourceBoundCandidate`，查真 Host/Repo/Owner；適用於 B1 的精確 operation 以該 family 的 native endpoint 載入後方可執行。
- **拒收**：原負例 `effect without admission` 與 `no imaginary 14th verb`；缺生效 ABI/Token/Issuer/HostReadback 一律 `HOLD_B1_REQUIRED`，不能因 row 存在 PASS。
- **可反證結果**：只能用此 `id=R15-908` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-909｜PIPD_CLI:pipd compile-tqaep — PI/ECP→tests

- **來源身份**：`R15.1:L259`；owner：`PIPD_CLI_OWNER`；effect family：`CLI_EFFECT_BY_VERB`；disposition：`B1_REQUIRED`。
- **受影必備功能**：`exact 13 verbs with strict flags and native CLI result`；先以 `PI/ECP→tests` 的原 domain 輸入形成 `SourceBoundCandidate`，查真 Host/Repo/Owner；適用於 B1 的精確 operation 以該 family 的 native endpoint 載入後方可執行。
- **拒收**：原負例 `self-attested receipt` 與 `no imaginary 14th verb`；缺生效 ABI/Token/Issuer/HostReadback 一律 `HOLD_B1_REQUIRED`，不能因 row 存在 PASS。
- **可反證結果**：只能用此 `id=R15-909` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-910｜PIPD_CLI:pipd validate — schema+semantic tree

- **來源身份**：`R15.1:L260`；owner：`PIPD_CLI_OWNER`；effect family：`CLI_EFFECT_BY_VERB`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `schema+semantic tree` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `exact 13 verbs with strict flags and native CLI result`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`preview.3 false PASS` 或 `no imaginary 14th verb`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-910` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-911｜PIPD_CLI:pipd diff — two subject versions

- **來源身份**：`R15.1:L261`；owner：`PIPD_CLI_OWNER`；effect family：`CLI_EFFECT_BY_VERB`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `two subject versions` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `exact 13 verbs with strict flags and native CLI result`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`foreign subject` 或 `no imaginary 14th verb`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-911` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-912｜PIPD_CLI:pipd repair — corrupted candidate→proposal

- **來源身份**：`R15.1:L262`；owner：`PIPD_CLI_OWNER`；effect family：`CLI_EFFECT_BY_VERB`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `corrupted candidate→proposal` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `exact 13 verbs with strict flags and native CLI result`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`oracle tamper` 或 `no imaginary 14th verb`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-912` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-913｜PIPD_CLI:pipd doctor — environment inspection

- **來源身份**：`R15.1:L263`；owner：`PIPD_CLI_OWNER`；effect family：`CLI_EFFECT_BY_VERB`；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `environment inspection` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `exact 13 verbs with strict flags and native CLI result`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`import success ≠ Host` 或 `no imaginary 14th verb`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-913` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-914｜PIPD_CLI:pipd export — materialize projection

- **來源身份**：`R15.1:L264`；owner：`PIPD_CLI_OWNER`；effect family：`CLI_EFFECT_BY_VERB`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「materialize projection」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`secret leak`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-914` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-915｜PIPD_CLI:pipd project — source-bound stage view

- **來源身份**：`R15.1:L265`；owner：`PIPD_CLI_OWNER`；effect family：`CLI_EFFECT_BY_VERB`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「source-bound stage view」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`downward claim inflation`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-915` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-916｜PRODUCT_TOOL:Tool-1 TPM-SP — portable `sbl-tpm-sp.zip` / Host invocation `goal.open`

- **來源身份**：`R15.1:L198`；owner：`非真 Host 只能 PACKAGE_CANDIDATE`；effect family：`HOST_PRODUCT_DELIVERY`；disposition：`B1_REQUIRED`。
- **受影必備功能**：`separate product function, install/invoke/deny/uninstall`；先以 `portable `sbl-tpm-sp.zip` / Host invocation `goal.open`` 的原 domain 輸入形成 `SourceBoundCandidate`，查真 Host/Repo/Owner；適用於 B1 的精確 operation 以該 family 的 native endpoint 載入後方可執行。
- **拒收**：原負例 `非真 Host 只能 PACKAGE_CANDIDATE` 與 `one tool cannot certify five`；缺生效 ABI/Token/Issuer/HostReadback 一律 `HOLD_B1_REQUIRED`，不能因 row 存在 PASS。
- **可反證結果**：只能用此 `id=R15-916` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-917｜PRODUCT_TOOL:Tool-2 Commander-SP — portable `sbl-commander-sp.zip` / `plan.propose`

- **來源身份**：`R15.1:L199`；owner：`只有模型 PLAN probe→LANE_ONLY`；effect family：`HOST_PRODUCT_DELIVERY`；disposition：`B1_REQUIRED`。
- **受影必備功能**：`separate product function, install/invoke/deny/uninstall`；先以 `portable `sbl-commander-sp.zip` / `plan.propose`` 的原 domain 輸入形成 `SourceBoundCandidate`，查真 Host/Repo/Owner；適用於 B1 的精確 operation 以該 family 的 native endpoint 載入後方可執行。
- **拒收**：原負例 `只有模型 PLAN probe→LANE_ONLY` 與 `one tool cannot certify five`；缺生效 ABI/Token/Issuer/HostReadback 一律 `HOLD_B1_REQUIRED`，不能因 row 存在 PASS。
- **可反證結果**：只能用此 `id=R15-917` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-918｜PRODUCT_TOOL:Tool-3 External Challenge-SP — portable `sbl-external-challenge-sp.zip` / `challenge.evaluate`

- **來源身份**：`R15.1:L200`；owner：`同 principal 或無真 Checker→FAIL`；effect family：`HOST_PRODUCT_DELIVERY`；disposition：`B1_REQUIRED`。
- **受影必備功能**：`separate product function, install/invoke/deny/uninstall`；先以 `portable `sbl-external-challenge-sp.zip` / `challenge.evaluate`` 的原 domain 輸入形成 `SourceBoundCandidate`，查真 Host/Repo/Owner；適用於 B1 的精確 operation 以該 family 的 native endpoint 載入後方可執行。
- **拒收**：原負例 `同 principal 或無真 Checker→FAIL` 與 `one tool cannot certify five`；缺生效 ABI/Token/Issuer/HostReadback 一律 `HOLD_B1_REQUIRED`，不能因 row 存在 PASS。
- **可反證結果**：只能用此 `id=R15-918` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-919｜PRODUCT_TOOL:Tool-4 HGK upgraded Harness Adapter — `sbl-harness` CLI + HGK **本體原位 Native 升級**

- **來源身份**：`R15.1:L201`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`B1_REQUIRED`。
- **受影必備功能**：`separate product function, install/invoke/deny/uninstall`；先以 ``sbl-harness` CLI + HGK **本體原位 Native 升級**` 的原 domain 輸入形成 `SourceBoundCandidate`，查真 Host/Repo/Owner；適用於 B1 的精確 operation 以該 family 的 native endpoint 載入後方可執行。
- **拒收**：原負例 `NEG_FROM_SOURCE` 與 `one tool cannot certify five`；缺生效 ABI/Token/Issuer/HostReadback 一律 `HOLD_B1_REQUIRED`，不能因 row 存在 PASS。
- **可反證結果**：只能用此 `id=R15-919` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-920｜PRODUCT_TOOL:Tool-5 Full SBL Product Stack — `sbl-stack` CLI + sbl core adapter/modules

- **來源身份**：`R15.1:L202`；owner：`既有 standalone fixture ≠ full engine`；effect family：`HOST_PRODUCT_DELIVERY`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「`sbl-stack` CLI + sbl core adapter/modules」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`既有 standalone fixture ≠ full engine`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-920` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-921｜R14_CHECK:R14-CHK00 — 最新狀態唯讀准入 E01

- **來源身份**：`R15.1:L1521`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「最新狀態唯讀准入 E01」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`W00`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-921` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-922｜R14_CHECK:R14-CHK01 — 14 DOC＋KP／Compiler 正式編譯 E01

- **來源身份**：`R15.1:L1522`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「14 DOC＋KP／Compiler 正式編譯 E01」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`W00`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-922` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-923｜R14_CHECK:R14-CHK02 — R13 18 紅 conformance 關閉 E01/M1

- **來源身份**：`R15.1:L1523`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「R13 18 紅 conformance 關閉 E01/M1」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`W01`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-923` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-924｜R14_CHECK:R14-CHK03 — R13 Native 四元組語義驗證 E04/M1

- **來源身份**：`R15.1:L1524`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `R13 Native 四元組語義驗證 E04/M1` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `historical check id→current requalification after version drift`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`W01` 或 `old green receipt != current host`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-924` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-925｜R14_CHECK:R14-CHK04 — 真安全 Checker 動態重驗 E07/M1

- **來源身份**：`R15.1:L1525`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「真安全 Checker 動態重驗 E07/M1」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`W17, W04`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-925` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-926｜R14_CHECK:R14-CHK05 — 目前三車道與 Writer 證據 E01/M1

- **來源身份**：`R15.1:L1526`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「目前三車道與 Writer 證據 E01/M1」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`W03, W04, W08`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-926` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-927｜R14_CHECK:R14-CHK06 — PLAN↔Commander-SP 真介面 E03/M1

- **來源身份**：`R15.1:L1527`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `PLAN↔Commander-SP 真介面 E03/M1` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `historical check id→current requalification after version drift`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`W03` 或 `old green receipt != current host`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-927` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-928｜R14_CHECK:R14-CHK07 — VERIFY↔Acceptance Challenge-SP 真介面 E03/M1

- **來源身份**：`R15.1:L1528`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「VERIFY↔Acceptance Challenge-SP 真介面 E03/M1」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`W04`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-928` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-929｜R14_CHECK:R14-CHK08 — HGK Native 升級 Delta E04/M1

- **來源身份**：`R15.1:L1529`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `HGK Native 升級 Delta E04/M1` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `historical check id→current requalification after version drift`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`W01` 或 `old green receipt != current host`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-929` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-930｜R14_CHECK:R14-CHK09 — Fabric F0 Consumption E04/M1

- **來源身份**：`R15.1:L1530`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `Fabric F0 Consumption E04/M1` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `historical check id→current requalification after version drift`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`W02` 或 `old green receipt != current host`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-930` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-931｜R14_CHECK:R14-CHK10 — 五工具獨立 Host 部署 E06/M1

- **來源身份**：`R15.1:L1531`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「五工具獨立 Host 部署 E06/M1」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`W13`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-931` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-932｜R14_CHECK:R14-CHK11 — 三 SP ZIP 正式可分發 E06/M1/M4

- **來源身份**：`R15.1:L1532`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「三 SP ZIP 正式可分發 E06/M1/M4」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`W13`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-932` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-933｜R14_CHECK:R14-CHK12 — 三私人 ChatGPT Plugin 正式資格 E06/M4

- **來源身份**：`R15.1:L1533`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「三私人 ChatGPT Plugin 正式資格 E06/M4」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`W13`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-933` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-934｜R14_CHECK:R14-CHK13 — 八 PIPD Skills＋Native Writer E02/M2

- **來源身份**：`R15.1:L1534`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `八 PIPD Skills＋Native Writer E02/M2` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `historical check id→current requalification after version drift`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`W05` 或 `old green receipt != current host`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-934` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-935｜R14_CHECK:R14-CHK14 — TPM／Guided SPEC E02/M2

- **來源身份**：`R15.1:L1535`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `TPM／Guided SPEC E02/M2` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `historical check id→current requalification after version drift`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`W05` 或 `old green receipt != current host`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-935` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-936｜R14_CHECK:R14-CHK15 — 通用真 Engine／One Core E05/M2

- **來源身份**：`R15.1:L1536`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `通用真 Engine／One Core E05/M2` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `historical check id→current requalification after version drift`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`W06` 或 `old green receipt != current host`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-936` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-937｜R14_CHECK:R14-CHK16 — Bounded Fix／Recovery E05/M2

- **來源身份**：`R15.1:L1537`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「Bounded Fix／Recovery E05/M2」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`W07, W11, W16`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-937` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-938｜R14_CHECK:R14-CHK17 — TQAEP／Independent Challenge E07/M2

- **來源身份**：`R15.1:L1538`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「TQAEP／Independent Challenge E07/M2」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`W04, W15`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-938` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-939｜R14_CHECK:R14-CHK18 — SourceBound G-KNOW E02/M2

- **來源身份**：`R15.1:L1539`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `SourceBound G-KNOW E02/M2` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `historical check id→current requalification after version drift`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`W05` 或 `old green receipt != current host`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-939` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-940｜R14_CHECK:R14-CHK19 — 50 Parent／149 Child 全程追溯 M4

- **來源身份**：`R15.1:L1540`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「50 Parent／149 Child 全程追溯 M4」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`W14`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-940` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-941｜R14_CHECK:R14-CHK20 — 441 source identities／OSS 導入 M4

- **來源身份**：`R15.1:L1541`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「441 source identities／OSS 導入 M4」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`W14`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-941` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-942｜R14_CHECK:R14-CHK21 — 38 surfaces／五工具分發 M4

- **來源身份**：`R15.1:L1542`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `38 surfaces／五工具分發 M4` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `historical check id→current requalification after version drift`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`W13, W14` 或 `old green receipt != current host`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-942` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-943｜R14_CHECK:R14-CHK22 — M1 Native 指揮鏈里程碑

- **來源身份**：`R15.1:L1543`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「M1 Native 指揮鏈里程碑」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`W08, W09`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-943` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-944｜R14_CHECK:R14-CHK23 — M2 隔離 SWOF 型 Dogfood 里程碑 E08

- **來源身份**：`R15.1:L1544`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「M2 隔離 SWOF 型 Dogfood 里程碑 E08」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`W09, W10, W12`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-944` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-945｜R14_CHECK:R14-CHK24 — SWOF W2 接收與 W3 准入 E09

- **來源身份**：`R15.1:L1545`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `SWOF W2 接收與 W3 准入 E09` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `historical check id→current requalification after version drift`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`W12` 或 `old green receipt != current host`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-945` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-946｜R14_CHECK:R14-CHK25 — 第一次真正 SWOF 受治理變更** E09/M3

- **來源身份**：`R15.1:L1546`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「第一次真正 SWOF 受治理變更** E09/M3」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`W12`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-946` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-947｜R14_CHECK:R14-CHK26 — M3 正式接續里程碑

- **來源身份**：`R15.1:L1547`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `M3 正式接續里程碑` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `historical check id→current requalification after version drift`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`W12` 或 `old green receipt != current host`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-947` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-948｜R14_CHECK:R14-CHK27 — 全 DOC 語義分母／M4

- **來源身份**：`R15.1:L1548`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`CONDITIONAL`。
- **條件選用**：僅在本 id 所涉 `全 DOC 語義分母／M4` 被現役 Owner policy／同一 WO 的 Need 選中時執行 `historical check id→current requalification after version drift`；VersionPin、License/NOTICE、HostCapability、OwnerPermission 任一缺即 `NO_FIT_CANDIDATE`。
- **NEG/退出**：`W14` 或 `old green receipt != current host`；未安裝不卸載，已合法受影使用才需有 scope-specific undo。
- **可反證結果**：只能用此 `id=R15-948` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-949｜R14_CHECK:R14-CHK28 — 發行、供應鏈與 GitHub 每輪證據 E06/E07

- **來源身份**：`R15.1:L1549`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「發行、供應鏈與 GitHub 每輪證據 E06/E07」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`W13, W15`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-949` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-950｜R14_CHECK:R14-CHK29 — R12/R13 積欠逐項閉合

- **來源身份**：`R15.1:L1550`；owner：`D-17/D-18/D-19 + 18 cases + SP ID gaps 各 Owner/receipt，不得「已過」跳過；R12 FAR §2、R13 POST §5–7`；effect family：`HISTORICAL_EVIDENCE_REQUALIFICATION`；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「R12/R13 積欠逐項閉合」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`W00, W11, W17`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-950` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

#### R15-951｜R14_CHECK:R14-CHK30 — M4 FULL Contract＋恢復式終止

- **來源身份**：`R15.1:L1551`；owner：`OWNER_TO_BIND`；effect family：``；disposition：`FULL_PRODUCT_DEFERRED`。
- **Full Product Deferred**：此 B1 未選本 id「M4 FULL Contract＋恢復式終止」的執行；保留原生使用者結果/受影 oracle，當 future Owner 建正式 Need/SourceFreeze/WriteSet 後重新准入。
- **拒收/退出**：`W15, W16, W17`；本輪零操作/零默認安裝，不能虛構每筆 state 需要清理。
- **可反證結果**：只能用此 `id=R15-951` 的源語義和其 Owner 的個別 outcome/NoFit 關閉；驗證失敗不得以其它 R15 ID/Host 的收據覆蓋。

## 4. 19 Contract / 13 CLI / 25 Method / 24 Donor：有名稱也要有真的命令／選型

**PIPD native CLI**（主程式讀到的 exact 13 verbs）：`init,intake,profile,compile-pi,bind-pd,compile-ecp,compile-tqaep,validate,doctor,project,export,diff,repair`。`intake --goal --source`；`profile --profile --axis`；`compile-pi --intent <FILE> --profile ASSURED`；`bind-pd --pi <FILE> --repo-root <ACTUAL_OWNER_ROOT>`；`compile-ecp --pd <FILE> --pi <FILE>`；`compile-tqaep --pi <FILE> --ecp <FILE> --maker <ID> --checker <DISTINCT_ID> --checker-receipt <REAL>`；`validate --bundle <FILE>`；`doctor`；`project --dry-run [--out <PATH>]`；`export --dry-run [--out <PATH>]`；`diff --a <FILE> --b <FILE>`；`repair --subject <ID> --dry-run --authorized-root <ROOT> --scope <PATH>`。這些是 CLI 形狀，不表示 Host executable installed。
13 verbs 的受影效果：`init` workspace write、`intake/profile/compile-pi/bind-pd/compile-ecp/compile-tqaep` deterministic artifact compile 不可擴權、`validate/doctor/diff` read-only、`project/export` dry-run 必 no write、`repair` 若未真授權僅 dry-run；每動作需按 `pipd` 真 parser/registry 回傳 exit + JSON，不能使用 shell 假 stdout。

| Admission item | Feature/Need | License/Version/Host 資訊門檻 | Default B1 |
|---|---|---|---|
| OpenSpec | Brownfield change-spec routing | exact CLI+Host route+pinned OpenSpec skill and policy epoch | mandatory policy overrides conditional metadata, else not selected |
| GStack | roleized flow + route(flow) | ACTIVE_SELECTED registry + actual invoked receipt | required only if policy says yes, otherwise no shadow issuer |
| Superpowers | engineering workflows/test discipline | reviewed source+license/version+tool permissions | conditional, no duplicate control plane |
| Spec Kit | requirements/spec authoring | version/license/ability diff to PIPD compiler | optional candidate, never second PI compiler |
| mattpocock/skills | bounded to-spec/to-tickets donor | skill trigger/nontrigger, pinned source/license | conditional; no automatic transplant |
| SLSA | supply chain provenance | builder provenance and immutable digest, version pin | conditional release gate, not runtime evidence |
| MCP | external tool/resource protocol | transport/tool permissions + allowlist & Host readback | conditional, no Native issuer |
| ACP | agent interop protocol | Host binding/current protocol version & scope | conditional, not synonym for MCP |
| SQLite/FTS5 | durable local index/journal | check existing Hermes/HGK ledger and owner; no duplicate DB truth | optional implementation mechanism only |
| CodeQL | security static analysis | existing CI/licence/availability + negative fixture | conditional quality gate; not live admission |

**19/25/24 個別具名來源**：每一項原身份及原需求、NEG、狀態分別可在上方 `R15-...` 原 ID 錨點查到；再按本節 feature matrix 和 per-WO OwnerPolicy 選擇，不能以本節的共同技術門檻取代 ID 個別觸發。
