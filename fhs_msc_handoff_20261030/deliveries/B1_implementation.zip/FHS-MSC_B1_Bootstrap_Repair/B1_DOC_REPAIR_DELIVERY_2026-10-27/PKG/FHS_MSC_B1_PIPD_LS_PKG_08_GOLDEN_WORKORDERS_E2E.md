---
artifact_family: FHS-MSC-B1-Bootstrap-Repair-PIPD-LS-PKG
version: 2026-10-27_r3_DOC_REPAIR_CANDIDATE_1
supersedes_version: 2026-10-26_r3_HIGH_RETENTION_SUBSTANTIVE_AUDIT_REPAIR
supersedes_subject_sha256: bc12a5fca45e4f68c1b1a4772b00ca72e0c07be8293527bbaafceadc7347290f
change_type: HIGH_RETENTION_INTEGRATE_COVER_REPLACE_NO_ARCHITECTURE_RESET
task_kind: DESIGN
claim_ceiling: AUTHOR_SIDE_REPAIR_CANDIDATE
formal_sourcefreeze: HOLD
independent_checker_receipt: NOT_RUN
native_effect: NOT_RUN
release: NOT_RUN
artifact_id: FHS_MSC_B1_PIPD_LS_PKG_08_GOLDEN_WORKORDERS_E2E
baseline_lineage:
  artifact_family: FHS-MSC-B1-Bootstrap-Repair-PIPD-LS-PKG
  version: 2026-10-26_r3_HIGH_RETENTION_SUBSTANTIVE_AUDIT_REPAIR
  supersedes_version: 2026-10-26-r2-HIGH-RETENTION-SOURCE-BOUND
  supersedes_subject_sha256: 273591a3f0cc7f43c87d6ac5e9e5704cf7ede15440a8a159b1de71d4c7d52da5
  change_type: HIGH_RETENTION_INTEGRATE_COVER_REPLACE_NO_ARCHITECTURE_RESET
  task_kind: DESIGN
  claim_ceiling: AUTHOR_SIDE_REPAIR_CANDIDATE
  formal_sourcefreeze: HOLD
  independent_checker_receipt: NOT_RUN
  native_effect: NOT_RUN
  release: NOT_RUN
design_use: OWNER_PREAUTHORIZED_B1_DESIGN_USE
native_authority: FORMAL_NATIVE_NOT_GRANTED
source_path: C:\Projects\Agent_Workspace\知識庫\實作相關DOC\Fabric vNext\Semantic World OS
  Fabric\SBL_PIPD\FHS-MSC\B1\FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG\FHS_MSC_B1_PIPD_LS_PKG\FHS_MSC_B1_PIPD_LS_PKG_08_GOLDEN_WORKORDERS_E2E.md
---

# GWO-FABRIC／GWO-HGK／GWO-SBL 三個獨立 Golden WorkOrders — r3 端到端設計正文

<a id="repair-gwo-entry"></a>
## 本候選修訂：非 Commander 提案條件與 Mission Stop Rule（RCA-17～19/26/29/32/33/36～41/45/48）

本 B1 Bootstrap 禁止呼叫未修復、未正式准入的 `sbl-commander-sp`。此為候選包預授權的設計採納，不代表 SBL Domain 已批准新入口。原 plan.propose 產品需求保持，實際 GWO Proposal 只能走下列可核驗分支：

| 分支 | 前提／合法動作 | first_fail／受影範圍／重入 |
|---|---|---|
| A 既有非 Commander ABI | 唯讀查現有 SBL registry/parser/controller，取得 Owner 版本化契約、executable/version/SHA、真 readback，證不依賴禁用 SP；經真授權才 invoke | 任一缺件 SBL_PROPOSAL_ABI_UNBOUND；只 PARK 消費提案之 GWO，繼續不相依 OBS/DEV |
| B 現役 ABI 缺失 | 記 discovery 與 Owner Decision Gate；最小 Adapter 只可由 SBL Owner 在既有 Domain/Repo 合法 DEV Scope 內批准及實作，經正負 roundtrip 再回 A | 不捏造 Proposal／Permit；無 Owner ratification 保持 HOLD |
| C 僅 Commander-SP 可用 | 不呼叫該禁用 SP；保留產品 Required，等待 repair＋formal admission＋Owner entry binding | GWO 局部 HOLD；不是全域停止 |

以上是條件設計，不宣稱查到可用 ABI；未證前本輪三 GWO 均 NOT_RUN。SBL 永遠不簽 HGK Native Permit。G-A 六項、三個獨立 GWO 與 G-B 合取不降低，互不借 PASS；Fabric 三 Raw 同 SHA/Epoch 且 distinct event，SBL Host install 與 User Consent／add/list/remove 分開。

G-B 必先真 Revoke external helper，再**不同 OS PID／Session**由 Native Executor 自發續同 Subject；只換 session 名、同 PID、Scheduled Task 叫回外援、舊 token 仍可 spawn，全部不合格。真 rollback/readback zero residue 保留，舊 Token NEG 應在 spawn 前拒收。Crash 的未知效果先 reconcile，不任意重播。

報告、Manifest、Seal 只彙整證據，READY/RUNNING 非零時不得 Mission Complete。全部合法工作 PARK 可具名 PARKED_WAITING_FOR_TRIGGER，不算 Native Success。Raw Manifest 必逐項有原始位元／hash，歷史 manifest-only 不補缺件；重新開始須先當前 Host readback，不能以 r10 或遠端 PR 推定 Loaded。作者側覆核不冒稱獨立 Checker。

受影交叉引用：[00](FHS_MSC_B1_PIPD_LS_PKG_00_GOVERNANCE_AND_CONTROL.md#repair-control)、[02](FHS_MSC_B1_PIPD_LS_PKG_02_DOC_B1_PD.md#repair-binding)、[07](FHS_MSC_B1_PIPD_LS_PKG_07_NATIVE_TOOLCHAIN_EXACT_USAGE.md#repair-tool-binding)。

GWO 提案保留 SBL 原 Proposal Owner；實際入口按本冊 repair-gwo-entry 的非 Commander 真 ABI／Owner ratification 分支綁定，未證即局部 HOLD，不呼叫禁用 SP，不由 SBL 發 Native Permit。每張 GWO 都須有獨立 `operation_id, subject_sha, policy_epoch, ECP_ref, pre/poststate, raw_receipt, independent_checker`，不同 Domain 不得互借。

## 1. GWO-FABRIC：來源 → Stage → Activate → Consumer effective readback

1. 使用者透過 SBL 提出 Fabric 政策投影變更，TPM 產生 SourceBound Goal／Spec，PIPD native Intent/PI/PD 產出候選；無正式 SourceFreeze 不進 Native 效果。
2. Fabric Policy Owner 讀取真 Source revision、Stage 候選／批准記錄、現役 Active Policy/Epoch、HGK policy consumer 已載入 digest，全部 subject 釘同一版，不用 GitHub `main` 冒充 Host Loaded。
3. 若需 Source 變更，獨立 `WO-FAB-DEV` 在 Codex bounded WorkSet 做 red→minimal patch→green；`RAW-FAB-DEV` **不能**作 Activator 證據。
4. 經正式批准後由唯一 Fabric Activator 執行 `OP-FAB-ACTIVATE`：合法 stage→active；HGK Consumer 由現役 APL 讀取/投影，不允許投影倒寫 canonical；此效果是不同 OPS ECP。
5. 分別讀回 `RAW-FAB-STAGE`（Source+Stage 授權）、`RAW-FAB-LOADED`（active/loaded SHA、Policy epoch）、`RAW-FAB-CONSUMER`（真正消費者 Reader 的受管投影與 ACK）。三者有不同 resource kind 和 event ID，不可替代。
6. NEG：把 Stage SHA 冒充 Loaded SHA、以檔案存在冒充 Reader ACK、錯 Policy Epoch 或倒寫投影，均 **NACK / zero unauthorized delta**。
7. Rollback 只由 Owner 對受影 Active generation 發獨立補償 Permit，驗證回復前版的 Active／Loaded／Consumer，不以文件中的示意 token 執行。

## 2. GWO-HGK：SBL 受治理提案 → Issuer → Hermes durable scheduler → 真可逆工作

1. 由 repair-gwo-entry 分支 A 已證且獲 SBL Owner 批准的非 Commander Proposal 入口提出可逆小 WorkOrder 候選與 PIPD PI/PD/ECP refs；未證時此 GWO 局部 HOLD；必要的 native `WorkOrder` 只由 HGK 唯一 Issuer 簽發。
2. 逐卡讀取現役有效 Policy ID/Epoch、Native method applicability (`KANBAN/SWARM/GSTACK/OPENSPEC/CODEX`)，強制方法沒有真調用收據時拒收；Issuer 僅在 Principal/Scope/Nonce/TTL 同 subject 成立時發 `RAW-HGK-ISSUER`。
3. Hermes 實際 durable queue 對 `WO-HGK-GOLDEN` 作 CAS lease_generation/heartbeat、bounded K scan；阻塞 A 時獨立 B/C 應能繼續；記 `RAW-HGK-QUEUE` 和 cursor/lease generation。
4. `OP-HGK-01` 由既有 Executor 進行小範圍可逆動作，Journal 保證 at-most-once；Timeout 只能 `UNKNOWN_EFFECT`→world-state reconcile，不得直接 retry；獨立 `RAW-HGK-EFFECT`。
5. 真 Independent Checker 對 issuer/queue/effect 不同 raw 收據驗證同 candidate SHA，並確認沒有其它不受影資源變更。
6. NEG：偽造 Issuer、用舊 nonce、ghost worker、stale lease、外援偽 native successor、兩次 Effect 皆首先 NACK。回復需獨立補償 ECP，不可重送已消耗卡。

## 3. GWO-SBL：真 Host 安裝 + user data add/list/remove + uninstall（分兩種效果）

1. SBL real entry 選擇 `CLI_TOOL × STANDALONE`。如安裝受影，`WO-B1-C3-OPS` 的 `OP-SBL-INSTALL` 取得真允許路徑、binary/version、doctor、status readback；此安裝不等於 user data 已被修改。
2. `WO-B1-C3-USER` 的 UserEffectBoundary 另查現役合法 User data Owner、同意目的/保存目錄與可撤銷性。若 Host 不存在合法 User issuer，回 `NOFIT_USER_ISSUER_UNBOUND` 且不做 add/remove；不能把 OPS/DEV Issuer 借給 USER。
3. **CLI source**：GitHub SBL `main` 已讀 `sbl_cli/sbl_todo.py`，可見 `_COMMANDS={init,add,list,remove,uninstall}`，`SCHEMA=SBL-TODO-STATE/1`；這是遠端程式碼而非本地 Host 安裝驗收。經 Owner 及使用者批准後，真 `sbl-todo` 命令的 `--data-dir` 必在 subcommand **前面**；真正刪除子命令是 `remove --id`，**沒有** `delete` 子命令：

```powershell
# DESIGN TEMPLATE: run only after actual parser discovery and USER admission.
$syntheticDataDir = '<USER_CONSENTED_ISOLATED_DATA_DIR>'
python -m sbl_cli.sbl_todo --data-dir $syntheticDataDir init
python -m sbl_cli.sbl_todo --data-dir $syntheticDataDir add --title 'B1 reversible smoke'
python -m sbl_cli.sbl_todo --data-dir $syntheticDataDir list --json
# Assign the actual id returned by add JSON before remove.
$actualTaskId = '<ACTUAL_TASK_ID_FROM_ADD>'
python -m sbl_cli.sbl_todo --data-dir $syntheticDataDir remove --id $actualTaskId
python -m sbl_cli.sbl_todo --data-dir $syntheticDataDir list --json
python -m sbl_cli.sbl_todo --data-dir $syntheticDataDir uninstall --yes
```

4. 獨立 Raw：`RAW-SBL-INSTALL`（安裝/載入）、`RAW-SBL-ADD`（task id/title）、`RAW-SBL-LIST1`（跨程序持久性）、`RAW-SBL-REMOVE`（該 id 移除）、`RAW-SBL-LIST2`（確實不再存在）、`RAW-SBL-UNINSTALL`（零殘留）。各 receipt 對應自己的 effect/command，無一可以合併為 generic success。
5. NEG：重覆 title `SBL_E_DUPLICATE_TITLE`/exit 3；空標題 `SBL_E_EMPTY_TITLE`/exit 2；`delete` 未知命令/exit 2；`uninstall` 遇 foreign files→`SBL_E_FOREIGN_FILES`/exit 5，避免誤刪共享資料。

## 4. 外援 Revoke → 下一段 Native Successor（G-B 必要、另 session）

先由權責 Owner 撤銷 helper 的外部 Principal/Scope/Nonce，記 `RAW-REVOKE`；切換另一個 Process/Session，**不得**以同 session 繼續稱自治。Native Scheduler 從已提交的 Durable Journal 自主發起 `WO-B1-C8` → HGK Issuer → Hermes Lease → Raw SameSubject Checker；再用撤銷的舊 Token 試重入應在 Spawn 之前 `REVOKED_TOKEN_REPLAY` 且無新增效果。若 successor 仍由 external helper 呼叫，G-B HOLD。

## 5. 三域 receipt identity 隔離

| GWO | operation IDs | 必需 RAW receipts | success | fail |
|---|---|---|---|---|
| GWO-FABRIC | OP-FAB-ACTIVATE（另 WO-FAB-DEV 如受影） | STAGE, LOADED, CONSUMER | 真 Reader 消費生效 Policy | stage-only/foreign epoch |
| GWO-HGK | OP-HGK-01 | ISSUER, QUEUE, EFFECT | 真 Issuer/公平 queue/可逆結果 | ghost/duplicate nonce/lease |
| GWO-SBL | OP-SBL-INSTALL, OP-SBL-ADD, OP-SBL-REMOVE | INSTALL, ADD, LIST1, REMOVE, LIST2, UNINSTALL | 真 CLI user task 持續存在後移除 | install receipt 冒充 user effect |

**結論**：全部上述都是施工／驗收計畫；沒有當前真 Host/Checker RAW 時三張 GWO **均未執行，G-B=HOLD**。
