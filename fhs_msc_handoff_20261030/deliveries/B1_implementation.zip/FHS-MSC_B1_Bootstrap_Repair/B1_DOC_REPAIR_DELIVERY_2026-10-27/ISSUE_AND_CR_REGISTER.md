# 未決 Gate 與新發現

本表均不阻合法、不消費該 Gate 的文件／唯讀工作。作者側修補不能為下列事項簽發 Native PASS。

| Gate | Owner／下一觸發 | 狀態與受影範圍 |
|---|---|---|
| OD-03 SBL_PROPOSAL_ABI_UNBOUND | SBL Domain Owner；非 Commander registry/parser/readback＋版本化批准，或合法最小 Adapter | GWO Proposal 局部 HOLD；禁用未修復 sbl-commander-sp |
| OD-04 CR-ORACLE-001_OPEN | PIPD Owner；DOC07 Writer↔DOC03 legacy alias 的合法 mapping／schema digest／正負測試 | 受影 Formal PI/ECP/TQAEP HOLD |
| OD-05 PROFILE_MAPPING_UNBOUND | PIPD Owner；十二 calibrated 風險軸→九 enum 的無損 veto mapping | 受影正式 ProfileBinding HOLD，不降級 |
| OD-06 DEV_ADMISSION | 各原 Repo Owner／PIPD；真 RepoContext/WriteSet/DEV ECP/Admission | 外部 Repo 寫入本輪未執行；僅有本次文件隔離 Scope |
| OD-07 HGK_TRUST_RECEIVER / HOST_PRIVILEGE | HGK Owner／真 OS Principal；Profile→Resolver→Receiver readback 及簽章正負驗證 | R1 Native 效果 NOT_RUN，文件不改 Trust/Policy |
| OD-08 USER_BOUNDARY | User data Owner／使用者；Synthetic DataDir 目的、同意、issuer／revoke | SBL add/remove 未執行，零私人資料效果 |
| OD-09 CHECKER_AND_RUNNER_UNBOUND | 各 Domain Runner Owner／真獨立 Checker Principal/key/ACL | Native Acceptance NOT_RUN；作者 Reviewer 不是 Checker |
| R2 HERMES_EXECUTOR_AND_NEW_PID | Hermes/HGK；SharedSpine→真 Executor→checkpoint→合法 wakeup→新 PID | NOT_RUN；不拿 dispatcher/fixture/Seal 代理 |
| R3 FABRIC_ACTIVE_LOADED_CONSUMER | Fabric Owner；真同 SHA/epoch STAGE/LOADED/CONSUMER | NOT_RUN，未聲稱當前 Activator 故障 |
| R4 REQUIRED_SERVED | 現役路由 Owner；PLAN/EXECUTE/VERIFY_SECURITY request/served raw | NOT_RUN，無 fallback／第四 Lane |
| PIPD_STAGE_C_WRITESET | PIPD Repo Owner／原 CI；base/head/allowed/changed 及真 CI | NOT_RUN，不放寬 ADR-0008/0009 guard |
| RAW_R10_FIVE_BYTES | 原證據保存者；原五筆實體 raw 及 SHA | 歷史 MISSING，當前未重新驗證，不能以 manifest 補位 |
| OD-10 NATIVE_RELEASE | 正式 Issuer＋Checker＋Owner；G-A 六項＋三 GWO＋Revoke／新 OS PID G-B／zero residue | NOT_RUN／HOLD；文檔完成不等於 B1 Native 完工 |

ISSUE-DELTA-01：DOC-08 $HOME 唯讀變數及 remove placeholder 已修，PowerShell 僅 AST parse。
ISSUE-DELTA-02：DOC-05 runner 全欄／NFKC、Principal／SID／ACL 前置已補，verifier 仍不產 PASS。
ISSUE-DELTA-03：兩份歷史 exact source hash 未找到：
- `dddc6b5993c88b9a2365aa9435ee492a543add3ebe4c89d79c58c58f9d16dbab`：27 個原始引用；SOURCE_REF_UNVERIFIED，保留原值，不用本地不同 blueprint 取代。
- `b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6`：120 個原始引用；SOURCE_REF_UNVERIFIED，保留原值，不用本地不同 blueprint 取代。

ISSUE-DELTA-04：DOC-00 optional selected Method 必須 REAL_INVOKE＋SameSubject/raw，已補拒收 installed-only。

施工期間來源修補計畫與指揮檔的路徑有變動；同 SHA 原位元重新定位，見 SOURCE_RELOCATION_LOG.json。本工具未移動來源。
