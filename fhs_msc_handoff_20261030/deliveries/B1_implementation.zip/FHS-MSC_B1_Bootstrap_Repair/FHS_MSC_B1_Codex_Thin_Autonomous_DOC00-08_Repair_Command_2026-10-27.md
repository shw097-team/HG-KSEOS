# CODEX｜FHS-MSC B1 DOC-00～08 高自動化完整修補｜薄施工指揮 PROMPT

你是本地 **Codex 專案文檔修補總工程師**。**立即執行**本指令，不要先只提出規劃，也不必逐階段詢問。目標：以《FHS_MSC_B1_DOC00-08_Codex_High_Automation_Repair_Plan_v1_2026-10-27》為施工 SPEC，對既有 B1 DOC-00～08 進行**高保留、低阻力、無架構重置**的自動化修補，**真正產出九冊完整、可讀、可追溯、可供後續 B1 工程使用的新版 FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG**，而非只產出計畫、摘要或補丁清單。

## 0｜本地根路徑與一次性 OWNER 授權

**工作根路徑（Windows）**：
`C:\Projects\Agent_Workspace\知識庫\實作相關DOC\Fabric vNext\Semantic World OS Fabric\SBL_PIPD\FHS-MSC\B1`

你必須在該根目錄及子目錄**自行遞迴定位**：上述完整修補計畫、B1 r3 原始 DOC-00～08、《FHS-MSC_總討論》《FHS-MSC_藍圖_r2》、《B1指揮施工_總紀錄》《B1施工_PROMPT》《B1施工狀況_總鑑定分析》《FHS_MSC_B1_Task_Handoff_Report_v1_2026-10-27》，及可取得的 SBL/PIPD 上位 DOC。以實際檔案內 `artifact_id/version/SHA` 辨認九冊，**不可只依檔名或修改時間猜現版**。同名多版先按上位來源與內文 lineage 選定唯一 r3 基線，保留分歧記錄。找不到個別佐證就標 MISSING，不杜撰。

**單一人類 OWNER 在此一次預先授權**：於上述 B1 根及其**新建、隔離的本次修補輸出目錄**內，合法讀取、索引、複製原件、編寫九冊新版、建立小型驗證程式、反覆執行靜態／隔離負例、修補、做 SHA／Diff、封裝 ZIP、寫交接報告；若原件處於 Git 倉庫，可在**隔離分支／Worktree**建立本地提交，不得覆蓋他人 Dirty／Untracked、不得自動 push/merge/deploy。以上均已預授權，不逐項 HITL。九冊新版若全部通過本指令的文檔驗收，OWNER **預先同意以該版本作為本次 B1 後續工程的設計／施工候選控制包**，可自動交付下游使用，不必再問同一範圍授權；但不得將此設計層採納冒稱為**跨 Domain Owner ratification、正式 SourceFreeze、PIPD ExecutionAdmission、HGK Permit、Windows 提權、真 Host/User Effect、獨立 Checker 或 Native Release**。凡真實權限欠缺，僅對受影操作 HOLD，繼續其他合法工作。

**禁令**：不可刪除／直接覆蓋既有九冊原件，不可 `git reset --hard`／`git clean`、改動上位 DOC 或外部 Repo、擴張未授權路徑、取用／發布憑證、任意修改現役 Policy 或簽發 Permit；全程禁用未修復的 `sbl-commander-sp`。不另造 Scheduler／Issuer／PIPD Compiler／第二套權威。

## 1｜執行方法（自檢測 → 自修補 → 自迭代 → 自驗收 → 自交付）

1. **真相與基線**：檢查 Windows 根路徑、路徑別名／junction、當前檔案版本及 Git HEAD/Dirty；建立九冊原始 SHA-256、IDs／章節／交叉引用清冊。優先直接讀《修補總方案》完整 §0～15 與附錄 A～C；其 `RCA-01～48` 是逐項修復追蹤矩陣，不能只讀摘要。原始文件不可變，修補在隔離輸出樹中進行。
2. **逐項定位**：交叉比對上位原意、四份施工／鑑定／交接記錄與原 DOC，建立 `RCA-01～48 → 來源位置 → DOC 受影條文 → 修法 → 測試 → 結果`。已滿足標 `ALREADY_SATISFIED`，本地已無法驗證標 `UNVERIFIED`，需真 Owner/Runtime 處理標 `OWNER_OR_NATIVE_DEPENDENCY`；新發現另增 ISSUE，不省略已知根因。不得用歷史推論冒稱當前 Host 故障。
3. **高保留實質修補**：依方案 §5 逐冊修；**P0：DOC-00、DOC-02、DOC-08**（治理作用域、EffectClass／受影 PARK、單人 OWNER、READY 不得提前 Complete、Commander Proposal 衝突）；**P1：DOC-01、03、04、07**（C0/C5、PL-003/004、Oracle DOC07/DOC03、Profile 12→9、Issuer／Checker／ECP、R1～R4 HotPath、CLI/Method 適用性）；**P2：DOC-05、06**僅做精確必要修補／引用，不重排或重生巨量測例與 949 R15 身份。採 `RED → MINIMAL PATCH → TARGETED GREEN → REGRESSION`；不因一項外部 HOLD 終止其他可做工作。
4. **九冊完整物化**：在新輸出目錄 `B1_DOC_REPAIR_DELIVERY_2026-10-27` 下建立 `PKG/`，寫出 **00～08 共九個獨立完整 Markdown 正文**（完整保留原正文與有效機器可讀資料，直接融入所需修改，不准以差異表／短摘要／「見舊版」取代正文）。九冊的 artifact identity／溯源、設計候選的法位及原始 Owner 邊界完整；若建議新候選修訂號，必清楚標 `OWNER_PREAUTHORIZED_B1_DESIGN_USE / FORMAL_NATIVE_NOT_GRANTED`，不得自行假造正式 Domain 採納證據。原本未能決定的 ABI／入口，正文應列可執行的有條件分支、FirstFail／替代探測／受影 HOLD，並維持功能原意，不能只寫「待研究」。
5. **迭代驗證**：機械化檢查原始身份與語義不縮水：**27 Atoms、31 WO/OBS（10 唯讀／5 Repo／14 Host／2 User）、120 Parent、124 Child、38 Node、949 R15.1、192 Cell、81 Asset、3 GWO**；檢查所有原 ID 集合、必要表格／Code Fence／JSON／YAML／Python、跨文件 SourceRefs、Markdown 結構、SHA、版本一致性、重複 Canonical Writer、未授權增刪、Diff 噪音。比較需解析**唯一原始記錄集合**，不可用單純全文命中次數代替。跑《修補總方案》§8 的 **DOC-ID-01～10、DOC-NEG-01～18**（區分可在文檔層實測與 Native 必須 NOT_RUN）；特別測：`No Permit → 合法唯讀可續、Host Effect 必 NACK`、`A HOLD → 無關 B/C READY`、`Commander-SP 禁用 → 合法非 Commander 真 ABI 未證時 GWO 局部 HOLD`、`READY > 0 → 禁止 Mission Complete`。不許修改測試期望來洗綠，修補後再跑至全部**可在文檔層執行的**案例通過。
6. **自行覆核並防假通過**：額外從反例／錯誤權限／Missing ABI 視角獨立審閱 Git Diff、前後 Clause 和 RCA 覆蓋，確認未弱化 G-A 六項、三 GWO、G-B（外援 Revoke + 新 OS PID）、Effect at-most-once、Nonce/TTL/Revoke、User Consent、Maker/Checker 真分權、Provider Required=Served 與 SourceFreeze。自動 Reviewer 是**作者側審查**，不准稱正式獨立 Checker。
7. **自動交付**：以 `PKG/` 九冊**完整最新版**為核心，另產生 `README_修補版導覽.md`、`SOURCE_SHA_MANIFEST.json`、`RCA_48_COVERAGE.md`、`CHANGES_AND_DECISIONS.md`、`VALIDATION_REPORT.md`、`NEXT_B1_HERMES_HANDOFF.md`、可重跑的最小 `tests/`（如必要）、全量 Diff，最後製成包含全部九冊與驗證工件的 `.zip`。檢查 ZIP 內恰好有九冊、重新計算每個文件 SHA，並在終端輸出**確定存在的絕對輸出路徑**。不得只給 Markdown 討論或停止在 Patch Plan。

## 2｜具體 SPEC 與不可退讓的限制

- **最小充分架構**：PIPD 唯一 Canonical PI／PD／ECP／TQAEP，HGK 唯一 Native Issuer，Hermes + 原 SharedSpine 唯一 Durable Work Authority，Fabric 原 ActivePolicy／Loaded Readback，SBL 原產品與合法 Proposal Owner。普通文檔／隔離 Repo 工程／Native Host／User Data 必分不同適用性，現役 PIPD Admission／OS 權限不因「單一 OWNER」而失效。
- **禁止把設計當執行**：`DOC_STATIC_PASS ≠ SOURCEFREEZE_ISSUED ≠ EXECUTION_ADMITTED ≠ HOST_LOADED ≠ MODEL_SERVED ≠ INDEPENDENT_PASS ≠ RELEASE`。Native、CI、Runner、Provider 實測缺件一律保持 `NOT_RUN/HOLD/UNVERIFIED`，不得填 PASS。
- **需要正面解決而非文字掩蓋**：`C0/C5` Source/Runtime 預置循環、`PL-003 ×2／PL-004`、`CR-ORACLE-001`、PIPD 12/9 軸、DEV／OPS／USER 作用域、零第二人類 OWNER 的 Standing Authorization、Maker/Checker 不同技術身份、SBL DOC-08 `plan.propose` 與禁用 Commander-SP 衝突、進度報告不能使 Hermes 提早停工、R3/R4 `NOT_RUN` 不能硬判系統故障，以及 DOC-06 Required 產品責任與本輪 Bootstrap 任務分母分離。Domain 真 ABI 未可證，不可編造；正文提供合法探測與明確 Owner Decision Gate。
- **成本／迭代停止線**：只要 P0/P1 修補足以保證本文級可施工契約，就不做無關美化。若測試長期失敗，輸出真 FirstFail 並完成不依賴它的其餘文件；不能重寫架構或把 Hold 改 Pass。文檔 Scope 完成不等於 Hermes Native Mission 完成。

## 3｜DONE 條件與最終回覆格式

**只有在下列條件同時成立才可稱 `DOC_REPAIR_COMPLETE`**：九冊**非空且完整**；原始身份及需求 100% 保留或有逐項可查的 Owner 批准差異；RCA-01～48 每項均有結案分類和具名證據；所有可運行 DOC-ID／DOC-NEG 項目真 PASS；所有未取得真 Host／Source Authority 的項目明確在非假綠清單；新舊文件 SHA／Diff／ZIP 內容可重算；README 能讓下游直接定位唯一新版文件與局部 OPEN Gate。

最終回覆直接給：`RESULT (PASS/PARTIAL/HOLD)`、九冊新版的**絕對路徑**、ZIP 的**絕對路徑**、原件與新版 SHA、RCA 覆蓋 48/48（含非程式可修項分類）、測試執行/成功/未跑數、尚需 OWNER/Native 的具名事項、可交付 Hermes 的下一個**合法** WorkOrder。**不得以候選文檔完成冒稱 G-A/GWO/G-B Native 完成。**

**現在開始檔案盤點與實作，不要只回覆執行計畫。**
