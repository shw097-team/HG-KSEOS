# FHS-MSC B1 Bootstrap Repair｜DOC-00～08 高自動化、單人 OWNER 友善之高保留修補總方案

> **文件類型**：可交付本地 Codex／ChatGPT Work 施作的完整工程施工方案（**不是**已修改的九冊原件，不是正式 PIPD SourceFreeze／HGK Permit／Native Acceptance）。  
> **版本**：`B1-DOC-REPAIR-PLAN-v1 / 2026-10-27`；**法位**：`ENGINEERING_PROPOSAL / DOC_PATCH_CANDIDATE / OWNER_ADOPTION_REQUIRED`。  
> **目的**：以最少的文檔差異，消除已知不必要阻斷與矛盾，供 Codex 自動修補 B1 r3 DOC-00～08，並將已核准的輕量執行契約交給 Hermes／HGK 進行真正高自動化施工。  
> **禁止混淆**：本方案之 `DOC_REPAIR_PASS` ≠ `PROMPT_COMPILE_PASS` ≠ `RUNTIME_SMOKE_PASS` ≠ `NATIVE_ACCEPTED` ≠ `SWOF_READY_W3`。  
> **任務焦點**：`B1 Bootstrap Repair`；不是全部 SBL Full Product、SWOF W3、R17 145-ID 專案一次完成。

---

## 0. 一頁決策摘要

**工程裁決：採用「先修關鍵 B1 執行契約 → 立即做實機 Bootstrap Smoke Test → 再以 Hermes 自主續工」；不採用「九冊全面重寫」或「沒有正式 Native 全 PASS 就禁止所有普通工程」。**

推薦的分工：

1. **ChatGPT Work（可選）**：在有讀取授權時進行 39 份來源的跨文檔審查，整理衝突裁決候選與差異建議；不直接決定 Native 權限。
2. **Codex Local（本輪文檔修補主要執行器）**：在隔離 Git Branch／Worktree 中修改九冊 Markdown，編寫或重用靜態回歸腳本、保留原 ID、生成 Diff、註記 unresolved decisions、跑負例、製作 PR 候選。
3. **唯一人類 OWNER**：批准真正會改變來源權威、SBL GWO 入口、Effect Scope／Policy 或其他生效規則的受影變更；可一次性、有期限且有範圍地授權低風險工作，不必逐卡重問。
4. **Hermes＋HGK**：在合法部署後用既有 SharedSpine 作**唯一持久工作權威**，由 Hermes 真 Executor 處理 READY，獨立 HGK Issuer／Receiver 控制 Native Effects；不新增平行 Scheduler／Permit Broker。
5. **PIPD／Fabric／SBL／Checker**：各守原本 Canonical 職責；Static DOC PASS 不能代理真 Native Receipt。

**施工順序**：`B0 真來源盤點 → D0 衝突裁決矩陣 → D1 低差異 DOC 修補 → D2 靜態及反例測試 → D3 OWNER 有效採納 → E0 Hermes 續航 Smoke Test → E1 分域修復 → G-A → 3 GWO → G-B → Native Release`。

**阻止文檔工程膨脹的硬界線**：只修會錯誤改變 WorkOrder 可執行性、效力、依賴、授權、驗收判定的條文。對非阻斷、僅文風／排版／重複內容的清理全部 Deferred。DOC-05／DOC-06 **不做全量重寫**。

**本方案的可交付退出**：九冊或其明確受影修補文件通過身份／引用／負例檢查，P0 衝突能從授權資料與實際能力決定合法分支，且可立即進入獨立環境 Hermes Runtime 測試。這與 B1 最終完工是兩個獨立 Gate。

---

## 1. 證據定位、權威層級與實際現況

### 1.1 本輪依據

| 類別 | 已讀來源 | 用途／資格 |
|---|---|---|
| 上位原意 | `FHS-MSC_總討論(1).md`、`FHS-MSC_藍圖_r2(2).md` | 歷史使用者需求、七輪決策、最小充分架構及 B0/B1/U/S 正交範圍；r2 自稱 `DESIGN_REPAIR_CANDIDATE / NO_RUNTIME_AO` |
| 主要目標 | B1 `FHS_MSC_B1_PIPD_LS_PKG_00～08` r3 | 27 Atoms、31 WO/OBS、120 Parent、124 Child、38 Nodes、949 R15、192 Cells、81 Assets、3 GWO 的現行設計候選正文 |
| 施工與 Root Cause | `B1指揮施工_總紀錄.md`、`B1施工_PROMPT.md`、`B1施工狀況_總鑑定分析.md` | r1～r10 反覆停止、C0/C5/PL-003/PL-004、Native 授權、SBL 入口、PIPD ABI、過度治理與執行退出機制的歷史直接記錄及分析 |
| 近期交接 | `FHS_MSC_B1_Task_Handoff_Report_v1_2026-10-27.md` | KI-01～KI-09、下一步步驟、r10 真／缺件證據、驗收尚未完成 |
| 上游設計 | SBL PIPD-LS-PKG DOC-00～13；PIPD_LS_DOC-00～09 | 依各 Domain 真 Writer／版本生效條件驗證，不以 B1 作者分析取代 |
| Repo | `shw097-team/HG-KSEOS`、`Fabric`、`SBL`、`PIPD-LS-SP` | 遠端候選／PR／CI；**不能**替代使用者 Windows Host 的真 HEAD、Dirty、Loaded、CurrentPolicy |
| 外部成熟技術 | Codex CLI／SDK、Git Worktree、GitHub Actions、Windows Task Scheduler、有限工作狀態外置等 | SUPPORT，不升格上位 Canonical |

使用者本輪要求**完整可執行文檔修補方案**，並未授權本對話直接替換原始九冊或操作 Windows Host。因此此文件提供 Codex 可執行程序、合同候選、回歸與驗收，而非聲稱實機變更。

### 1.2 需保留的 FHS-MSC r2 設計原意

1. **Minimal-Sufficient Architecture**：不另造 Writer、Issuer、Scheduler DB、Policy DB 或第二個 PI Compiler；優先原生能力，其次薄 Adapter。
2. **單一人類 OWNER**：一名人類決策者可作有效有界 Standing Delegation；但其意圖／自然語言**不等於** Windows OS Token、HGK Signed Permit、PIPD Native SourceFreeze 或真正 Checker 身份。
3. **三實體 Lane，而非每個角色一條 Lane**：`PLAN`、`EXECUTE`、`VERIFY_SECURITY`；TPM、Commander、Execute、Challenge 是不同能力／角色配置，不能自行擴成四條控制面。
4. **單一 Authority Stack**：同層實際衝突以 Source Identity、Domain Owner、現役綁定與正式 Ratification 決定，不以「較新的 Markdown」或「較聰明的 Agent」解決。
5. **B0/B1 vs U1/U2/U3 vs S0 相互正交**：B1 修 Bootstrap 能力，不將完整 SBL 產品或 SWOF `READY_W3` 當作立即前置；同時不可刪除產品義務。
6. **Codex 外援有界**：先合法診斷與修復原生能力，再退出外援，由 HGK／Hermes 證實真 Native Successor。
7. **主體一致與真 World Effect**：PR、CI、ZIP、Report、文件範例、Stage 候選 ≠ Loaded／Served／Executed／Independent Accepted。
8. **Provider-off／NoFit／方法適用性**：不以靜默替代模型、改選 Provider、或縮減原始 Method／Product Required 來洗成成功。
9. **來源面全量保留、任務面限當期合法適用**：原 949 R15.1、18 WPs、25 C00～C24、50／149 原測試、16 User Moments 等上位身份不得被本輪 B1 31 張卡或 r10 ledger 分母取代。
10. **產品體驗**：PIPD 複雜性應盡可能隱藏在內部 Engine；OWNER 下達一次任務後，由工具在有效範圍內自動定位來源、選 Profile、複用合約、跑受影測試，而不是要求 OWNER 人工管理每份內部文檔。

定位：`FHS-MSC_藍圖_r2` §0、§1.2、§1.3、§5～7、§11；`FHS-MSC_總討論` Q1～Q7。

### 1.3 正確的權威與效力順序

- 使用者有效授權／適用法律與第三方系統真權限。
- SBL、PIPD、HGK、Fabric、SWOF 各原生 Domain 的正式、現行、已批准 SSOT／Owner／政策。
- B1 r3 DOC-00～08：高保留設計**候選**，可作修補來源與驗收設計，尚未自動生效為 Host Policy。
- r1～r10 Prompt／鑑定／交接：具有歷史證據與工程提議法位；不能越級取代上游。
- 本文件與任何 Codex 生成的 DOC Patch：`DOC_PATCH_CANDIDATE`；直到有權 Owner 版本化採納，不能宣稱取代上位版本。
- 技術社群／外部研究：選型 SUPPORT。

**同層歧義**：以 `CONFLICT_OPEN + AFFECTED_ONLY_HOLD` 留待有權 Owner；其他合法工作照常繼續。

### 1.4 目前已知狀態——不可誇大的邊界

- r10 結果：`PARTIAL_WITH_EXPLICIT_HOLDS`；Native G-A/G-B 未成立；三 GWO `0/3`；T2、R3、R4 仍無相應真實驗證。
- r9 SharedSpine durable primitives 據報 18/18 PASS，但 **不等於** Hermes 真 Executor 自主閉環；r10 移除測試 Scheduled Task、未見正式替代的運行證據。
- HGK 本地 User Trust `de37c48` 是報告所述候選；Receiver 仍疑有 `%ProgramData%` 靜態 Registry 接線，需真 Host 驗證。
- Fabric #18 是 read-only inspect 語義修補候選，**不是** `Stage→Active→Loaded→Consumer ACK` 真 R3。
- SBL #13 是 TODO atomic save 候選，不是已安裝及用戶 Data Effect 成功。
- PIPD #20 遠端 `offline-gate` PASS、`public-plugin-verify` FAIL（`UPGRADE_WROTE_OUTSIDE_ALLOWED_SET`；ADR-0008/0009）。不得放寬 WriteSet 洗綠。
- 四個主要 PR 截至本文件查核均為 Open／Draft／未合併：HGK #2 `70147a5e6452`、Fabric #18 `a65231cd9ca7`、SBL #13 `a97b1bf886b4`、PIPD #20 `abeae2512e5f`。遠端 Head 不代表本機載入。
- r10 Manifest 有九份條目，但前輪可實際獨立讀回的原始檔只含其中四份，五份缺原位元。Hash 表不能替代 Raw。

### 1.5 證據級別

| 標記 | 含義 | 報告措辭 |
|---|---|---|
| `A` | 目前可定位原始正文、PR metadata、CI Job 或本地掛載檔的直接證據 | `CONFIRMED_BY_SOURCE` |
| `B` | 歷史 Windows 執行／Zip／Session 回報，未在本容器重現所有 Raw | `REPORTED_NOT_REPLAYED` |
| `C` | 有因果解釋力但缺對照實驗 | `LIKELY_OR_HYPOTHESIS` |
| `D` | 缺真 Runtime／Owner／Checker／Root | `UNVERIFIED`／`MISSING` |

### 1.6 基本分母與相互不可替代性

| 分母 | 值 | 意義 |
|---|---:|---|
| B1 PI Atoms | 27 | 本輪 Bootstrap 原始需求身份 |
| B1 WO／OBS | 31 | 具有不同類別的候選工作／觀測槽 |
| B1 Parent TQAEP | 120 | 測試設計身份 |
| B1 Child Effect Cases | 124 | 子效果測試身份 |
| B1 Node Conformance | 38 | Node 級別一致性 |
| B1 R15.1 Identities | 949 | 本輪保留之全產品來源映射 |
| B1 Product Cells | 192 | Kind×Mode×Host×Provider-off 投影 |
| B1 Named Assets | 81 | 具名資產覆蓋 |
| GWO | 3 | Fabric、HGK、SBL 三域真實效果 |
| r10 Ledger Identities | 1,565 | 625 Required＋285 Conditional＋655 Deferred；**不是** 1,565 張可派工卡 |
| B1 PD EffectClass | 31 | 10 READ_ONLY_PROBE＋5 REPOSITORY_WRITE＋14 HOST_OPERATIONS＋2 USER_DATA_EFFECT |

**驗收不變式**：身份計數不縮減、身份意義不被替代；`Required` 按現役政策及當輪 Effect 依賴排程；`Conditional` 只在條件成真時排程；`Deferred` 保存、可追溯、可重新進入，但不作 B1 當輪假前置。不得從 r10 625/285/655 反推原 B1 949 ID 各自數量。

---

## 2. 目標系統：最低必要修改，不重造治理

### 2.1 五個可執行層次與 Gate

| 層級 | 可做工作 | 最小前提 | 不得宣稱 |
|---|---|---|---|
| `L0 SOURCE/DESIGN` | 讀取、交叉比較、編修候選 DOC、靜態語法／身份檢查 | 合法檔案讀／寫範圍；保留差異與來源 | 已 Formal SourceFreeze／Native Pass |
| `L1 BOOTSTRAP_DIAGNOSIS` | 已核准 Host／Repo 唯讀現況探測、能力定位 | 真 Read Scope、Root、OS 權限；零未授權副作用 | 已修復／已 Loaded |
| `L2 BOUNDED_DEV_REPAIR` | 隔離受限 Repo 修補、受影測試、PR 候選 | 真 RepoContext、OWNER 有效授權、適用 PIPD DEV Admission／WriteSet；若 Native ECP 依法必要則仍須取得 | Native Host Effect 已授權 |
| `L3 GOVERNED_EFFECT` | Host Activate／Native Issuer／User Data 等 | 真 Issuer、EffectClass、Scope、Nonce、TTL、Active Policy、適用 ECP／Permission | 缺 Permit 時可執行 |
| `L4 FORMAL_ACCEPTANCE` | Native Raw readback、獨立 Checker、Gate 合取、Release | 真 SameSubject Raw、獨立 Principal、Owner 正式批准 | Maker 自驗即 PASS |

**重要限制**：`L2` 是工程作用域分層，不是新發明的「免許可通道」。當現役 PIPD 合約實際要求 ExecutionAdmission 才能改 Repo，就必須遵守。若不存在合法免 Native Issuer 的 Repo 修補通道，標示 `L2_ADMISSION_HOLD`，並同時允許合法的 L0/L1、隔離設計與受限無副作用測試；不得以本文件虛構權限。

### 2.2 文檔與實作各自的責任

- DOC r3 正文：WHAT（需求／效果語義／驗收／身份）。
- **薄型修訂／Execution Projection**：WHICH／WHEN（對當前 Host 已具合法准入的哪些卡、依賴、FirstFail、下一觸發）。
- SharedSpine：唯一實際 WorkOrder／Lease／Checkpoint／Terminal Authority。
- Hermes Executor：HOW（依原 Native API 取卡、合法操作、Raw、State 續行）。
- Owner／Issuer／Checker：WHO CAN AUTHORIZE / WHO CAN VERIFY。

**禁止新增** `B1_QUEUE_DB`、新 `AUTHORITY_REGISTRY`、新 `PIPD_COMPILER`、常駐 `AGENT_GOVERNANCE_SERVER`。視圖／Index 可再生，但不得同時成為雙寫來源。

### 2.3 書面規則必須給 Codex 的機械裁決序

`source/authority → path/currentness → security/issuer/token → EffectClass/ECP → mandatory_method → execution/idempotency → readback → checker/trace → gate`。

- 第一個真正失敗項成為 `first_fail`。
- `UNVERIFIED/NOT_RUN` 不改寫 `FAIL`；`KNOWN_FAILED` 才可叫 FAIL。
- `AFFECTED_ONLY_HOLD` 根據依賴圖，而非整份 B1 一律 HOLD。
- `UNKNOWN_EFFECT` 先 read-world-state/reconcile；不得任意 retry。
- 編譯報告可產生 `PLANNED`，但 Native Gate 沒有真 Raw 就不能 `PASS`。
- 如果 `READY > 0` 或 `RUNNING > 0`，禁止 `MISSION_COMPLETE`；若全部受合法外部阻斷，允許 `PARKED_WAITING_FOR_TRIGGER`，不能當成成功結案或模型無限自旋。

---

## 3. 全根因／問題覆蓋矩陣（跨 r1～r10 去重，逐項有處方）

下列 `RCA-xx` 是**本修補方案的追蹤索引，不是新增 B1 Requirement Atom**；與歷史報告 `RC-1～RC-7`、`KI-01～KI-09`、`PL-003/004` 等原編碼以「歷史欄位」連接。對部分歷史推論不標作已證實直接因果。

| RCA | 來源／歷史代碼 | 問題與證據級別 | DOC 修補及 Codex 執行處方 | 驗證／退出 |
|---|---|---|---|---|
| 01 | PL-003 ×2；C0/C5 | 把尚待發行的 SourceFreeze／Native Admission 和 TaskKind 當成 C0 既有來源 [A/B] | DOC-00／01／07 區分現存 Source vs Future Runtime Output；更正輸入 Contract，保留真 Effect Gate | 隔離來源編譯不再因未來工件錯置而拒收；真 Effect 仍拒絕缺件 |
| 02 | PL-004；CR_ORACLE_001_OPEN | DOC-07 Oracle Writer 與 P4 DOC-03 Namespace 尚未釐清 [A] | DOC-01／07 登錄語意／序列化分層；先查是否 Legacy Alias，Owner 決定有效相容 | 合法映射正例＋錯誤 Writer／Source 負例；受影 Formal 仍 HOLD |
| 03 | C0～C9 Prompt Compile | 過去 Master Prompt 未取得真 `PROMPT_COMPILE_PASS` 即被稱施工命令 [B] | DOC-00／07 明示候選／有效編譯、修補後真跑原 Compiler | 真 Exit Code＋Report；不得用 Markdown 檢查充真編譯 |
| 04 | Prompt-as-NORMATIVE | Agent 產生的指揮 Prompt 被提升為規範來源 [B] | DOC-00 加 Authority Kind；Prompt 為 TASK_INSTRUCTION，非 Domain SSOT | 來源權威排序回歸 |
| 05 | `SOURCE_COMPILER_HOLD` | 受影 Compiler HOLD 擴散到大多數 Required 身份 [A/B] | DOC-00／02 明確依賴圖及逐 EffectClass 作用範圍 | A Host HOLD，B Repo／OBS 在有效授權下 READY |
| 06 | Bootstrap 自鎖；KI-07 | 修復 Issuer 必先用尚未修好的 Issuer 核准一切工作 [B/C] | DOC-00／03／04 建立既有合法 Recovery／DEV 途徑的查找與分層；沒有權限不越界 | L0/L1 可跑；合法 L2 才寫；Native L3 仍 Permit Gate |
| 07 | Owner Standing Grant | 單人 OWNER 被要求反覆重新簽核已批准同範圍工作 [B] | DOC-00／03 明確 Mission 有界授權繼承、Scope／TTL、例外 | 低風險同 Scope 不重問；Escalation 只對新決策 |
| 08 | Human vs Principal | 單一人類 OWNER 被錯等同所有 Maker/Signer/Checker [A/B] | DOC-00／03／05 保留真技術職責分離、不可同 SID 假隔離 | Checker 身份可獨立查驗 |
| 09 | Admin-only LocalMachine | 要求一般工程一律 Windows Administrator [B] | DOC-00／03 以 Effect Risk 分級；User Scope 優先但不冒稱高保證 | 非高權限任務 Standard User 跑；敏感效果保持 OS Gate |
| 10 | HGK local `de37c48`／KI-02 | User Trust 有候選，現役 Receiver Registry 接線未證 [B] | DOC-03／04 R1 具名「Profile→Resolver→Receiver」診斷／修補，非文字自我簽發 | 真 ADMIT/NACK、Nonce、Revoke、Scope、SID 測試 |
| 11 | Maker=Checker | 同 SID／DPAPI 或名字不同不足證明獨立 [A/B] | DOC-03／05 明定 Principal／Key ACL／Independent Checker Evidence | Maker 不能修改 Trust Anchor 或 Checker Verdict |
| 12 | PIPD Profile 12→9 | Canonical 12 軸與 P4 九軸不一致 [A] | DOC-01／07 引入 Owner 指向的版本化投影；不得簡化為直接刪軸 | 類型及 Safety Veto 正反例，無靜默資訊流失 |
| 13 | TQAEP Draft/Live | 定義測試時要求已執行 Checker Receipt [A] | DOC-00／05／07 分 `DESIGN_PLANNED`、`EXECUTED`、`INDEPENDENT_VERIFIED` | 無 Raw 只能 PLANNED |
| 14 | PIPD Effect Retry | Native at-most-once 被套到普通工程排錯 [A/C] | DOC-03／04 区分 Dev Iteration 與 Effect Attempt | Red→Patch→Green 可迭代；UNKNOWN 不重播 |
| 15 | Wrong EffectClass | 31 張卡混用 Host／RepoContext／User 權限 [A/B] | DOC-02／03／04 以 10/5/14/2 真分類做准入，不造假的 PD | 全 31 分類及正反 binding |
| 16 | Method Required | Kanban/Swarm/GStack/OpenSpec/Codex 被一律強制或安裝冒充 Invocation [A/B] | DOC-00／02／07 按現役簽名 Policy Epoch 的 mandatory/selected | Required 真 REAL_INVOKE；Not Selected 有合法理由 |
| 17 | UserData Borrowing | 用 OPS／DEV Token 代替 User Issuer [A] | DOC-02／03／08 分 UserEffectBoundary 與獲同意的合成資料 | 無 User 授權 NACK，零使用者資料效果 |
| 18 | DOC-08 SBL Commander | GWO 以 `plan.propose`／Commander 作唯一入口，r10 禁用 `sbl-commander-sp` [A] | DOC-00／06／08 先找現存非 Commander ABI；無則開最小 Adapter＋Owner CR | 能實測合法入口才綁定；禁用 SP 不縮產品義務 |
| 19 | Commander-SP Role | Builder 被當 Bootstrap 全域必經 Planner／Issuer [B] | DOC-00／08 限定為產品能力／可選施工者，不作修原生自身的硬前置 | 未載入 Commander 時可做合法 Boot 診斷 |
| 20 | Knowledge Pack 00～19 | KP-R04 規則極性異常，SUPPORT 被誤作全域 Normative 的風險 [B] | DOC-00／07 附來源法位：KP 為輔助，獨立開受影品質卡，不改 B1 上位 | 不因 KP 阻斷普通修補；不得默改其實體原件 |
| 21 | 27/31/244/38/949 | 測試／產品身份分母被當即時工作數 [A/B] | DOC-00／05／06 分 Catalog Denominator 和 Scheduler Applicable Set | Count 保留；只有合法 Applicable 進 READY |
| 22 | R15 Required/Cond/Deferred | Conditional／Deferred 誤當無條件當輪 Must Run [A/B] | DOC-06 引入明確觸發／Not-Applicable-Reason；不修改原 Policy 的 Required | Trigger 正例和非觸發負例 |
| 23 | TQAEP Runner Gap | 測試定義文字／CLI 字串冒充 Runner [A] | DOC-05／07 需真 Runner ABI、Path、SHA、OS、權限 | 未綁 RUNNER → NOT_RUN/BLOCKED，非 FAIL/PASS |
| 24 | r7～r10 RC-1；KI-01 | 工作在 Context 而非 Durable State，續航不可靠 [B/C] | DOC-00／04 薄型 SharedSpine 工作狀態要求；實機修 HotPath | Context 壓縮／新 PID 續同一 Subject |
| 25 | r7～r10 RC-2 | Native HOLD 當全域停止 [B] | DOC-00／02 受影 Dependency Cut；NoReady 與 GlobalStop 分離 | 阻塞 A，獨立 B/C 真進行 |
| 26 | r7～r10 RC-3 | Report／Manifest／Seal 提前充當完工訊號 [B] | DOC-00／05／08 引入 `READY_COUNT`＋Native Gate 結案先決；實機確認 | Report 不會停止 READY；`NATIVE_ACCEPTED` 只在真 PASS |
| 27 | r7～r10 RC-4 | 選容易封存的卡、R3/R4/Executor 未跑 [B] | DOC-04 定義 `NOT_RUN ≠ BLOCKED`、依賴權重與公平性；實機必探測 | R3/R4 有真探索記錄，不假設故障 |
| 28 | r7～r10 RC-5 | 舊 HOLD 隨 Context Compaction 殘留 [C] | DOC-00／04 僅以當前 SharedSpine＋當前 Host Readback 判定狀態 | 乾淨 Session 與壓縮 Session 對照 |
| 29 | r7～r10 RC-6 | 正式 Native Gate 缺失被誤作唯一終點 [B] | DOC-00／03／08 將 `PARKED_WITH_TRIGGER` 與 Mission PASS 分開 | Permit 缺時其他 Ready 照常進行 |
| 30 | r7～r10 RC-7 | 21,784 行高治理 Context 直接指揮 [C] | DOC-00／06／07 Progressive Disclosure／單卡 Context Card | 真測量單卡讀取量和首次有效施工 |
| 31 | SharedSpine vs WorkQueue | 另建 WORK_QUEUE.json 將造成第二 Queue [A/C] | DOC-00 規定其僅 Derived View、SharedSpine 唯一 Single Writer | View 刪除後可重建且不丟工作狀態 |
| 32 | r9 test trigger removal | OS Wakeup 已示部分能力，r10 移除測試 Task [B] | DOC-04／08 要求真 Executor＋OS Wakeup＋新 PID 測試；不是 DOC 即解決 | 無互動聊天時仍合法取得下一卡 |
| 33 | Fabric R3／KI-03 | PR Inspect 不等於 Stage→Active→Loaded／Consumer ACK [A/B] | DOC-03／04／08 同 SHA/Epoch 三 Raw，真 Activator | R3 正反實驗及 Recovery Receipt |
| 34 | Model R4／KI-04 | 路由版本設定不等於三 Lane 實際 Served [B] | DOC-01／04／07 實際 Required/Served/PolicyEpoch | 三 Lane 真請求、Mismatch NACK |
| 35 | PIPD Stage-C CI／KI-05 | PR #20 `verify` WriteSet Failure；ADR-0008/0009 [A] | DOC-07／04 補 CI Crosswalk，不放寬 PIPD Repo Guard | 真 Git diff/Base/Head/AllowedSet；新 CI PASS 且非法仍 FAIL |
| 36 | Raw Manifest／KI-09 | r10 九條 Manifest 但五原始檔在交接中缺件 [B] | DOC-05／08 `MANIFEST_COMPLETE` 不等於實體證據完整 | 所有 Raw bytes 可重算 SHA，不只目錄表 |
| 37 | Code vs Loaded Drift | Repo PR 綠或 Patch 存在就被推論 Host Loaded [A/B] | DOC-03／04／08 對 Code/Installed/Loaded/Consumer 四階識別 | 同 Subject 真 Reload 或 Host Readback |
| 38 | Fairness / at-most-once | 排程器 ACK、lease/crash-sweep 不能證明 Hermes 執行效果 [B/C] | DOC-00／03／04 真 Executor、CAS Lease、Journal、Reconcile | Kill PID／新 PID／duplicate effect NEG |
| 39 | SBL CLI 真使用者結果 | 只有 CLI 存在／Install，沒有 add/list/remove/uninstall [A/B] | DOC-02／03／08 OPS vs USER 分離，合成獲准 DataDir | 真六種受影 Raw，沒有 private data 污染 |
| 40 | three GWO alias | 不同 Domain 使用同一 Generic Receipt 假合格 [A] | DOC-05／08 三域不同 Op ID、Raw、Checker | Fabric/HGK/SBL 分別 PASS，互借拒收 |
| 41 | G-B external helper | 外援沒有撤銷或同 Process 偽 Native successor [A/B] | DOC-00／08 新 Process／Revoke／舊 Token NEG | 真 Native successor，舊 Token 無效果 |
| 42 | Repo Root/Dirty | 本地大量 Untracked／Root Alias／Windows Reparse 風險 [B] | DOC-04／07 先 read-only Root/HEAD/ACL；寫集最小 | 不 reset/clean；未知路徑 STOP 寫入 |
| 43 | PR／CI promotion | 開放 Draft PR 被當主線已 Loaded／正式 Release [A] | DOC-00／04／07 Source／PR／Installed／Loaded 四法位 | PR Head、CI、Host Installed 分列 |
| 44 | R17/R13／FHS r2 audit | 原紅測試、145-ID Mission、SWOF W3 被 B1 所有工作混入 [A/B] | DOC-06 Scope Boundary：B1 只修原生 Bootstrap；全產品／W3 保留帶重入條件 | 沒有偷偷刪 Red、WP、R15、SWOF Requirement |
| 45 | final source/acceptance | `LOCAL_PRECHECK_PASS_ONLY`／自陳 Manifest 冒 Independent AO [A/B] | DOC-05／08 將 Compiler／Static／CI／Native／Release 五層分開 | 不可信 CI Script／同 Principal 不得自頒 Release |
| 46 | fallback provider / wrong lanes | 模型路由 fallback 或「角色=Lane」錯配 [B] | DOC-01／04／07 定義三個真正 Lane 與 Pin/Pool/Session 分離 | 符合當前 Policy 的實際 Required/Served，不靜默降級 |
| 47 | governance proliferation | 每張卡重造 PI/PD/ECP、重複提問與額外第二憲章 [A/C] | DOC-00／07 合法契約複用、Risk Profile LITE/STANDARD/ASSURED 適用性 | 同 SHA/Scope 可複用；變更僅重新資格化受影 |
| 48 | r10 full root gap | r10 部分原始命令、Raw／本機 HEAD 未附，分析不能判全部 Live 能力 [B/D] | DOC-04／08 引導新 Session 先讀當前真實 Root/Runtime，不用歷史猜測 | 每個主要 Runtime 宣告附 Host 原始讀回 |

> **對「全部根因」的可核驗性說明**：上表完整納入兩份 B1 合冊與交接報告中已明確列出的主要直接缺陷、相依阻斷及反過度工程事項，按相同機制去重；合冊含多輪分析與重複轉錄，不能把每個歷史文字推論當作獨立故障。上表的 `RCA-xx` 是工作追蹤層，必要時 Codex 必須對原始文字各個可驗 `Claim` 建立多對一引用並標注證據級別；任何未定位的新問題補進 `ISSUE_DELTA`，不能默默宣稱不存在。

---

## 4. 文件修補通則與修改審批

### 4.1 一律使用「最小差異」

1. **既有 r3 不做全檔重生**。首選修改文首執行說明、個別失效條文與小型附加小節；保留全部可機械比較的正文、表格、原 ID。
2. 如一份薄型 `B1_EXECUTION_PROFILE` 已足以正確映射，優先建立**衍生投影**而非重複在 DOC-01～08 植入同一份政策。可在 DOC-00 加唯一 Locator、DOC-08 加受影入口更正，其他 DOC 僅精確交叉引用。
3. 原始 DOC-06 949 條、192 Cell、81 Asset，DOC-05 全量 120／124／38，不重排序、不大規模重排換行、不刪節、不以生成摘要取代正文。
4. 原有 `Canonical Failure Registry`、B1 `PI-B1-*`、`WO-B1-*`、`OBS-B1-*`、TQAEP IDs、R15 IDs 保持原字串與身分，除非有具名 Error Correcting CR 及 Owner 批准。
5. 凡涉及 SourceFreeze、Native Issuer、GWO 入口、UserData、Maker/Checker 以及正式 Release 的文字，**不得**由 Codex 任意降低義務；提出有權 Owner 的 `DECISION_REQUIRED`。
6. `task_kind: DESIGN`、`claim_ceiling: AUTHOR_SIDE_REPAIR_CANDIDATE`、`formal_sourcefreeze: HOLD` 等元資料不得因文檔編修被直接改成正式生效／PASS；若採納新版本，真法位以原有批准記錄外置／受控更新。
7. Markdown Code Fence 內的命令、JSON／Python 或合約示例必逐段解析或檢查；不得輸出「看似可用」的虛構真 CLI Flag／Path／Token。
8. 規則改動一律必寫：`source_locator / old_clause / new_clause / reason / effect_scope / owner / test_case / adverse_effect`。

### 4.2 修改准入分級

| 等級 | 範例 | Codex 能否自行修改候選 | 何時有效 |
|---|---|---|---|
| `E0 EDITORIAL` | 拼字、交叉引用、格式 | 可，限 WriteSet | 自動通過靜態檢查，仍是候選 |
| `E1 EXECUTION_CLARIFICATION` | DESIGN vs RUNTIME、NOT_RUN/HOLD、局部依賴 | 可提出及測試，附原文對照 | Owner 採納其執行適用性後 |
| `E2 DOMAIN_CONTRACT_CHANGE` | Oracle Canonical Locator、SBL Proposal ABI、Risk 軸映射 | 可做 Option A/B、不得臆測或自動選高權威 | 原 Domain Owner 版本化批准＋ABI 相容測試 |
| `E3 NATIVE_AUTHORITY_CHANGE` | Issuer、Trust Anchor、正式 Permit、Role/Checker、Release | 僅候選分析；不能以 DOC 假生效 | 真 Native Owner／OS／Checker 有效執行與收據 |

### 4.3 必須保留的正確治理

HGK 唯一 Issuer；PIPD 原生 Source／PI／PD／ECP／TQAEP；Fabric Active／Loaded；根路徑、HEAD、WriteSet；Nonce/TTL/Revoke；at-most-once Native Effect；Maker/Checker 真隔離；USER 效果獨立同意；負例及回復；三 GWO／G-A／G-B。**不得用「輕治理」作為繞過這些限制的理由。**

---

## 5. DOC-00～08：逐冊精確修補施工單

每冊包含**定位／變更／保留／反例／OWNER 判定**。以下文字為可供 Codex 直接實作的**規範候選**，不是編輯後已生效的原文。

### D00｜Governance and Control（最高優先）

**定位**：原 metadata，§1 生命週期、§2 Failure Registry、§3 Method Resolver、§4 G-A/G-B、§6 Source/Policy provenance。

**D00-P01：新增最小「設計與執行效力分層」**。建議在 §1 或後加短小節：

> B1 DOC-00～08 是設計／受影驗收 Source，除有權 Owner 另行批准，不具有 Native Permit 或生效 Policy。Source Scan 中已存在的文件來源與 C5 Runtime 待取得的 Admission／TaskKind／SourceFreeze 證據不得混為同一 required_source_families。設計／唯讀／合法受限 Repo 修補／Host 或 User Effect／正式 Acceptance 分階段准入；前一階段可保存 OPEN 的未來效果缺件。任何有副作用的實際操作仍依現役 PIPD/HGK 需要的合法 Admission 執行。

**D00-P02：新增「單人 OWNER 有界授權及技術 SoD」**：一次性 Standing Mission Delegation 可覆蓋同 `scope+effect_class+risk_ceiling+ttl+change_set` 的重複合法工作；不可自動跨 `USER_DATA_EFFECT`、高權限 Host／Protected Keys、Source Owner 衝突、正式 Release；Maker、Signer、Checker 分離是技術身份，**不強制第二位人類**，但不許同 OS Principal 自證 Checker 獨立。

**D00-P03：新增「受影 StopLoss／依賴」**：`HOLD` 只影響有明確 `depends_on` 邊的 WorkOrder。缺 Oracle 不得阻所有 Read-only；缺 Native Permit 不得阻不消費此 Permit 的 DOC／Repo 工程。若缺真 Repository Admission，也必停該 Repo 寫入，而不是創建特例權限。

**D00-P04：新增「Runtime Completion Gate」**：由 SharedSpine 唯一權威提供 `READY/RUNNING/PARKED/DONE`；Doc Report／Manifest／Seal 不控制工作停止；`READY>0` 或 `RUNNING>0` 禁止最終完工；全部合法工作 PARK 時輸出具名阻斷、喚醒條件、partial status，不假 PASS；真正 Mission Final 仍須全部適用 Native Gate。

**D00-P05：回歸已存在的 canonical first-fail**，避免新造異義 alias；`METHOD_REQUIRED_NOT_INVOKED` 保留唯一正規碼；`UNKNOWN_EFFECT` 不能靠換名字重播。

**禁止**：修改原 G-A 六項合取與 G-B 條件、設第二 Scheduler、把 Standing Delegation 當 Signed Permit。

**驗證**：`T-D00-1` L1 診斷不受無關 Native Hold；`T-D00-2` Native Effect 缺 Permit 即 NACK；`T-D00-3` READY>0 不結案；`T-D00-4` Checker 同 Principal 不升 PASS。

### D01｜PI（次高優先）

**定位**：§1 P4 strict input、§2 原生 adapter、§3 27 Atoms。  
**D01-P01**：保留 27 個 `PI-B1-A1..C9` 完整順序；B1 Atom 不得當 P4 原生五個 REQ enum；Sidecar 證據不能宣稱 Native PI。  
**D01-P02**：Source／Oracle／PI 的當輪適用性分層：`C0 SOURCE_EXISTS`、`C2 AUTHORITY_CONFLICT`、`C5 RUNTIME_CAPABILITY`、`L3 EFFECT_ADMISSION`，不可因期待未來 Issuer Artifacts 而令唯讀探測 Source Scan 失敗。  
**D01-P03**：Oracle 正式 Locator 由 PIPD Owner 釐清，B1 記錄 `CANONICAL_DOC07 + LEGACY_DOC03_ABI_CANDIDATE`，相容由 Native Plugin／Owner 提供；不在 DOC 偽造 Oracle Raw。  
**D01-P04**：十二軸 PIPD 複雜度與 P4 九軸是不同 schema；先調用真 Profile Resolver 或版本化兼容適配，不能直接塞十二軸，也不能默默丟三軸或降低 veto。  
**驗證**：27 ID 零增減；未決 Oracle 的受影子卡 HOLD；不依賴 Oracle 的合法診斷續行；非法映射必 NACK。

### D02｜PD／31 WO-OBS（最高優先）

**定位**：§1 `choose_binding`、§2 31 槽、§3 Method Slots。  
**D02-P01**：正規 EffectClass 分派：十個 `READ_ONLY_PROBE` 無論 RepoContext 能否取得，都只按自身唯讀 Scope 判準；五個 `REPOSITORY_WRITE` 必須真 RepoContext＋適用 DEV Permission／ECP；十四個 `HOST_OPERATIONS` 用真 Host Adapter＋HGK Native Admission；兩個 `USER_DATA_EFFECT` 用合法 User Boundary，**不得**把 Host/User 假裝 Repository PD。  
**D02-P02**：每槽新增或衍生**薄型 Execution Projection**：`slot_id, effect_class, source_ref, binding_required, depends_on, blocked_by, evidence_kind, next_action, policy_epoch, runtime_state`。原 DOC 保留原完整 payload/Oracle/negative/rollback，不在表中複製。  
**D02-P03**：`BLOCKED_NO_ISSUER` 只標在真正消費 Native Permit 的槽；其餘須先實測權限與依賴，不能全部繼承 `SOURCE_COMPILER_HOLD`。  
**D02-P04**：DEV／OPS／USER 混合工作依原有分立 slot，不能為了減卡而合併身份或合併 Native Effect。  
**D02-P05**：R3/R4 `NOT_RUN` 須先排合法 Probe，不能直接稱 `ACTIVATOR_FAILED` 或 `MODEL_SERVE_MISMATCH`。  
**驗證**：PD 31 原標題及 ID 全保留，分組計數 10/5/14/2；對 31 卡各測 Effect Adapter 正例／無權限負例；附錄 A 用為施工索引。

### D03｜OPS-ECP（P1）

**定位**：§ EffectClass、14 OPS 及 USER Issuer 決策樹。  
**D03-P01**：保留每張 Host Operation 各自真 Permit／Preimage／Raw／Rollback；明定 `PIPD Native PD` 只處理真 Repo-bound 受影，Host 用原 Native HGK Owner Adapter，禁止 PIPD 假 PD。  
**D03-P02**：增加 User-scope Trust Profile 與現役 Receiver Registry Resolver 的**檢測及接線要求**，但不把 `HGK_TRUST_PROFILE=user` 當現有生效開關。  
**D03-P03**：Risk 分級，不能將 `%ProgramData%/Administrator` 寫成一切工程的通用要求；User-scope key 需真隔離與 Registry 驗證；高保證 SoD 不得靠同 SID/DPAPI 宣告。  
**D03-P04**：Native Effect `at-most-once` 與 Engineering Red/Green 迭代分開；未知 Native 效果必先 Reconcile。  
**D03-P05**：`ISSUER_UNBOUND` 僅阻涉及受管效果的卡；仍可做合法只讀與經批准的 DEV 準備。  
**驗證**：錯 token、scope、nonce、TTL、revoke、User Consent 負例均 NACK；不發效果時只可證明「設計案例通過」。

### D04｜DEV-ECP／R1～R4（P0/P1）

**定位**：四個 Repair Cone，Host HotPath 注意，DEV strict payload。  
**D04-P01**：改成 `DISCOVER → FIRST_FAIL → BOUNDED_FIX → RED/GREEN → REAL_READBACK → CHECKER`，真 Repo Root、HEAD、Loaded Import Chain 必先從現役機器查出，不把候選路徑作成固定 Host 絕對路徑。  
**D04-P02**：Codex 可以迭代修正**已准入的 Repo 級工程**，但不能在同一修補迴圈內自行 Activate Fabric、簽 HGK Permit 或發真正 USER 效果。  
**D04-P03**：R1 Trust/Receiver、R2 Hermes SharedSpine/Executor/Wakeup、R3 Fabric Stage/Loaded、R4 三 Lane Required/Served，四者是獨立 Repair Cones；真 Probe `NOT_RUN` 與真失敗分類不同。  
**D04-P04**：R2 增最小跨程序測試，確認 `SharedSpine READY→Hermes real executor→OS wakeup→checkpoint→new PID successor`，且 READY>0 不能 Final。  
**D04-P05**：R3/R4 只需查到真有效的 Creator/Consumer API，再做最小修復，不預設已有缺陷。  
**驗證**：四 Cones 分別可做合法 Discovery；故障隔離／Crash／Resume；不可用 Mock 冒 Native Acceptance。

### D05｜TQAEP（P1；大冊只做局部）

**定位**：文首 Typed RawReceipt discriminator、120 Parent/124 Child/38 Nodes，Runner Binding。  
**D05-P01**：新增小表把 `DEFINED/PLANNED`、`APPLICABLE`、`RUNNER_BOUND`、`EXECUTED`、`INDEPENDENT_VERIFIED` 分開；本體 120/124/38 **不重生成、不刪減**。  
**D05-P02**：同一原始 Raw 可被多個受影規格引用，前提同 `workorder/operation_id/resource/candidate_sha/epoch`，但不同世界效果不能共用 generic receipt。  
**D05-P03**：判 `Maker != Checker` 不能只是比較未正規化字串；正式 Acceptance 需 OS/Service Principal 和隔離 Trust Boundary，可復核 Clock／Nonce／SHA。  
**D05-P04**：`TEST_PLAN_PASS`、`FIXTURE_PASS`、`CI_PASS` 與 `NATIVE_VERDICT_PASS` 不同，缺 Runner/Owner 只可 `BLOCKED_MISSING_RUNNER_OR_BINDING`。  
**D05-P05**：受影增量回歸只跑適用 Runner；保留整體索引與未觸發條件，不將 Test Catalog 當 Scheduler Queue。  
**驗證**：所有原始 ID Count、不同 receipt identity 負例、Fake Checker／Fake Raw 負例。

### D06｜Product Coverage/R15（P1；嚴禁重寫 949 行）

**定位**：192 Product Cells、五工具＋三 SP＋六模組、R15 全量清冊。  
**D06-P01**：本輪新增或指向一個非常短的**正交分母說明**：Catalog 949 保留全部 Required/Conditional/Deferred 原義；Boot 適用性的 `EXECUTE_NOW / CONDITIONAL_TRIGGERED / DEFERRED_WITH_REASON / NOT_APPLICABLE_TO_BOOT` 是衍生視圖，**不得回寫原產品義務**。  
**D06-P02**：Commander-SP `R15-917` 等產品 Required 仍保留；本輪明令禁用未修復的 `sbl-commander-sp`，不等於產品從 Required 改 Deferred。  
**D06-P03**：SBL Old M5 Repair、Old M6 Distribution/Host 與 New Flow M1～M6 使用兩套 Taxonomy，不能只因名稱相同而互換。  
**D06-P04**：Provider-off／NoFit 真保留；SBL CLI_TOOL／STANDALONE 與用戶 Outcome 不被僅 Host Install 項目代理。  
**驗證**：949 ID、192 Cell、81 Asset 原實質身分可重算，完整產品義務不變，Scheduler 只消費條件成立的卡。

### D07｜Native Toolchain Exact Usage（P1）

**定位**：13 CLI verbs、19 Native Contract、25 METHODS、24 Donor Slots、§5 Negative Examples。  
**D07-P01**：每條 CLI／Adapter 分 `DISCOVERED/INSTALLED/LOADABLE/INVOKED`；文件列有 Syntax 不代表 binary 存在，所有參數以當前 `--help`／Schema 校驗且必須合法 Scope。  
**D07-P02**：Oracle DOC07 vs Legacy DOC03 ABI 及 Profile 12→9 的真適配只依已批准 Toolchain 生效，文件不自建第二個編譯器。  
**D07-P03**：五個方法 `KANBAN/SWARM/GSTACK/OPENSPEC/CODEX` 和其他 METHOD／Donor Slot 按現役 Signed Mandatory Policy 選用，不因列在 DOC-07 而所有卡 must-run。  
**D07-P04**：`LITE/STANDARD/ASSURED` 按影響與安全 veto 選用；已生效相同 Subject/Scope/Epoch Contract 可依法複用，不必每次全文重編。  
**D07-P05**：Native CLI 的 Mock/Dry-run/Example 不作真 Native Receipt；實體未裝時 `TOOL_MISSING` 不應變 `EXECUTION_FAILED`。  
**驗證**：非空真 CLI Path/Version/SHA；錯 version、錯 schema、Tool not installed 負例；不把 CLI 存在當 Required Method Called。

### D08｜三 GWO／G-B（最高優先）

**定位**：文首唯一 Proposal 入口；§1 GWO-FABRIC；§2 GWO-HGK；§3 GWO-SBL；§4 G-B。  
**D08-P01（需 Owner 決定）**：文首 `SBL Command/Proposal plan.propose` 及 §2「SBL Commander 提出」修成**依真 ABI 分支**的候選條文：

> 本 B1 Bootstrap 任務禁止呼叫仍未修復、未正式准入的 `sbl-commander-sp`。合法 GWO Proposal 優先綁定 SBL Owner 確認、與 Commander-SP 不相依的現役 `plan.propose` 同等 ABI（**必須有真 Runtime readback 和版本化 Owner 契約**）。若無此 ABI，產生受影 `SBL_PROPOSAL_ABI_UNBOUND`，允許不相依的 B1 調查／修補持續，但不得為 GWO 捏造提案，也不得讓 SBL 自行發 HGK Native Permit。建立最小 Proposal Adapter 只限原 SBL Domain Owner 批准範圍。此條文經 Owner Ratification 才取代原入口語義。

**D08-P02**：保留 Fabric `Stage→Active→Loaded→Consumer ACK` 的同 SHA/Epoch 三 Raw；PR Inspect 不作其中任何效果。  
**D08-P03**：保留 HGK 真 Issuer→Hermes Durable Lease→可逆 Effect→獨立 Checker；`at-most-once`、重播拒收及 R2 新 PID。  
**D08-P04**：保留 SBL 真 Host Install／使用者同意／`init add list remove list uninstall` 六種不同 Raw；必須合成獲准 DataDir，不能使用真私人資料。  
**D08-P05**：保留先 `REVOKE external helper` 再另一 OS Process Session 真 `NATIVE_SUCCESSOR`、舊 Token 重入拒收與零污染 Readback；Task Scheduler 只能喚醒 Hermes，不能以外援本體冒充 Native Successor。  
**D08-P06**：各 GWO 一套獨立身份，不因總體 Seal 完成便互借 PASS。  
**驗證**：`T-D08-1` Commander 缺／禁用情境；`T-D08-2` Fabric Stage-only NACK；`T-D08-3` User Issuer 缺時 NACK；`T-D08-4` G-B 同 Process NACK；`T-D08-5` 假外援已 Revoke NACK；`T-D08-6` 真新 PID 據 SharedSpine 續工。

---

## 6. 簡化為一份「薄型 Execution Projection」而非重做九冊

### 6.1 最小 JSON 交換結構（**提議，不是已安裝 ABI**）

以下是可供 Codex 產生 `proposal/` 附件的 Schema 概念，**只有在發現既有 SharedSpine／HGK 交換格式不能直接表示時才建立受控 Adapter**；不得把此 JSON 視為 HGK `TaskSpec`、PIPD native `PD-PKG`、`Permit` 或另一個可寫 Queue。

```json
{
  "kind": "B1_EXECUTION_PROJECTION_CANDIDATE",
  "schema_version": "1",
  "source_package_ref": "<EXACT_APPROVED_DOC_SET_AND_SHA>",
  "authority": "DERIVED_VIEW_ONLY",
  "workorder_slot": "OBS-B1-A1",
  "source_atom_id": "PI-B1-A1",
  "effect_class": "READ_ONLY_PROBE",
  "profile": "<RESOLVED_FROM_ACTUAL_POLICY>",
  "current_policy_epoch": null,
  "actual_tool_binding": null,
  "authorized_scope_ref": null,
  "depends_on": [],
  "first_fail": null,
  "status_from_sharedspine": "<READ_ONLY_PROJECTION_OF_LIVE_STATUS>",
  "evidence_refs": [],
  "checker_requirement_ref": "<EXISTING_SOURCE_LOCATOR>",
  "wakeup_condition": "<WHEN_PARKED_ONLY>",
  "claim_ceiling": "DESIGN_ONLY"
}
```

不得把 `status_from_sharedspine` 由 Codex 外部 JSON 直接寫回 Live SharedSpine。實際寫回必經現役 Hermes／HGK 允許的原生 API、CAS／Lease 與驗收條件。

### 6.2 低成本依賴圖規則

- **實際可排程單位**：DOC-02 中 EffectClass 明確的 31 個候選槽，以及已准入必要補丁卡；不是 949、1,565 條身份各跑一個 Agent。
- **硬依賴**：只有當工作真消費某個工件／Policy／Permit／RepoContext 時才加 `depends_on`。
- **發現依賴**：不確定 HotPath／ABI 時先排合法 Discovery；不可把尚未調查等同不可恢復的 BLOCKED。
- **跨 Domain 依賴**：如 GWO-HGK 真需 Proposal，未決入口只 PARK GWO 受影子圖；R3 read-only 並不因此自動停止。
- **受影重新資格化**：ChangeSet、Source SHA、Policy Epoch 或 Runner SHA 改變時，只重跑消費該版本的 Gate；不可把舊 PASS 擴展到新主體。
- **多 Agent**：同一 Repo 的寫入 Lease 單一 Owner，並行唯讀或已隔離 Worktree 可在合法權限下進行；合併由 Owner／CI 決定。

### 6.3 單人 OWNER 決策的最小記錄格式

```yaml
# DESIGN TEMPLATE ONLY: this is not an HGK signed token or live issuer schema.
mission_id: B1-BOOTSTRAP-REPAIR
human_owner: <CURRENT_AUTHORIZED_OWNER_ID>
source_set_sha: <CURRENT_APPROVED_SOURCE_SHA>
permitted_repository_roots: <OWNER_APPROVED_EXACT_PATHS>
allowed_effect_classes:
  - READ_ONLY_PROBE
  - REPOSITORY_WRITE  # only where native DEV admission actually permits
write_set: <EXACT_GIT_PATH_SET>
risk_ceiling: <LIVE_POLICY_RESOLVED>
valid_until: <OWNER_DECIDED>
forbidden:
  - UNAPPROVED_HOST_MUTATION
  - UNCONSENTED_USER_DATA
  - FORGED_PERMIT_OR_CHECKER
  - SBL_COMMANDER_SP_UNTIL_REPAIRED_AND_ADMITTED
native_issuer: HGK_EXISTING_NATIVE_ONLY
checker: REAL_INDEPENDENT_PRINCIPAL_REQUIRED_FOR_FORMAL_PASS
status: DESIGN_PROPOSAL_NOT_YET_EFFECTIVE
```

**有效化程序**：Codex 只能產生此模板和差異清單；Owner／PIPD／HGK 依當前真正 Schema／政策選擇合法載體及簽章，並讀回有效 Scope。若無現役准入，繼續 L0/L1，不對 L2/L3 私設新發證辦法。

### 6.4 PIPD Profile 正確使用

- `LITE`：僅低風險、隔離、可回復、滿足原生 Safety Veto 的工作；不是任何 B1 文件都自動 LITE。
- `STANDARD`：一般 Repo 工程與普通可回復軟體活動（仍依現役 Policy）。
- `ASSURED`：Trust Anchor、Native Issuer、權限敏感 Host/USER Effect、驗收控制等。  
- PIPD DOC-06 十二複雜軸與 P4 九個輸入軸為不同設計面，若沒有現有經核准的無風險降低映射，保留 `PROFILE_MAPPING_UNBOUND`；不得自動挑較輕 Profile。
- 已有效的契約在主體、Scope、Policy Epoch、ChangeSet 未變時可依法複用，避免每卡重新走完整十四階段文書。

---

## 7. Codex 自動修補工作流／DAG（無本地路徑假設）

### 7.1 施工前唯讀 P0：原件與 Repository 環境發現

1. 在 OWNER 批准讀取的 workspace 找到全部九冊，對每一檔保存 `path, size, sha256, lines, original_metadata, git root(if any), head, branch, dirty`。不得猜固定 `C:\...`。
2. 找上位 `FHS-MSC_藍圖_r2`、`總討論`、B1 兩份合冊、施工 Prompt、Handoff、PIPD DOC-00～09、SBL DOC-00～13；未取得則註記 `SOURCE_MISSING`，不創造替代內容。
3. 若九冊是普通 Markdown、未處在 Git Repo：**不要把原始資料夾直接 `git init` 並修改使用者的其他資料**。先複製到 OWNER 批准的獨立 Doc Repair 工作目錄並產生 immutable hashes；是否建立版本庫由 OWNER Scope 決定。
4. 如果在 Git Repo：先 `git status --short`、`git rev-parse --show-toplevel`、`git rev-parse HEAD`；只在已批准的 clean／獨立 Worktree 修改受影檔案。不能 `git clean`、`git reset --hard`、覆蓋未追蹤檔案。
5. 建立 `source_manifest`、`issue_register`、`authority_map`、`patch_plan` 的**候選交付資料**，不是正式 SourceFreezeManifest。

### 7.2 工作包排序（一次只開啟真正依賴）

| Wave | 輸入 | 改動 | 自動化程度 | 退出標準 |
|---|---|---|---|---|
| `W0` | 39 份來源及本地 Git Readback | 哈希、IDs、權威與差異基線 | 高／唯讀 | 無不明 Root、可重算基線 |
| `W1` | RCA 表、DOC-00、DOC-02、DOC-08 | P0 作用域／依賴／禁用入口 | 高，權威轉移須列 Owner CR | 三個核心 Fixture 具名結果 |
| `W2` | DOC-01、03、04、07 | Oracle／Profile／Effect 分級／R1～R4 探測規則 | 高，僅 Patch Candidate | 受影 CrossRef 與 Policy 不退化 |
| `W3` | DOC-05、06 | 僅新增適用性說明／執行投影，保留大表 | 高但禁止全文再生 | 120/124/38/949/192/81 原身份保留 |
| `W4` | 完整 Diff／Source Manifest | 靜態語法、數量、正反 Fixture、自洽審查 | 高 | 所有 DOC 回歸 PASS，CR_OPEN 完整 |
| `W5` | OWNER 裁決與 Repo 真 CI | 正式版本採納或待採納 PR | 有權簽核部分人工 | `DOC_PATCH_ACCEPTED` 或帶受影 HOLD 的合法候選 |
| `W6` | 已核准執行契約／Host 實際能力 | Hermes Executor＋HGK Receiver 真 Native Bootstrap | 非文檔範圍，Codex 僅有界修補 | 新 PID 自主續行；正式 Gate 留給 Checker |

**減少前置成本**：當 W1 的 P0 規格足以支持最小 L0/L1／合法 L2 Smoke Test，便在允許範圍下與 W2/W3 並行驗證，不等待所有文檔美化；Owner 尚未採納的相應治理修改不能被當正式 Host 權限。

### 7.3 每輪 Codex 的最小上下文

`MISSION → 現行 DOC SHA → CURRENT WORKPACKAGE → 受影原條文 → 權威 Source Locator → Authorized WriteSet → Acceptance Fixtures → Result/Next READY`。

不把全部 B1 DOC-05/06 與 39 份歷史全文放進每個 Worker Context；以工具檢索具名章節。Context Compaction 後以 Git Diff／持久 manifest 重建狀態，不能相信舊訊息的 HOLD 就是現在的 Host 事實。

### 7.4 Codex 紅綠循環（只限合法文檔候選與受准入 Repo 工作）

`REPRODUCE RED → MINIMAL PATCH → RUN TARGETED TEST → VERIFY DIFF/IDS → RETAIN EVIDENCE → NEXT ISSUE`。  
失敗需儲存 `first_fail`, `repro_command`, `actual_stdout`, `expected`, `scope`, `fix_attempt`, `next_step`；可在當前允許範圍內繼續迭代。真正 Native Effect 的 Retry 遵循 OPS ECP，不適用一般 Git 文檔改動的重試邏輯。

---

## 8. 完整負例與回歸驗收計畫（DOC 修補 Gate）

### 8.1 基線與身份 Gate

| Case | 驗收 | 必需否認 |
|---|---|---|
| `DOC-ID-01` | 九冊數量、來源 SHA 可重算，允許有權版本化變動 | 缺一冊但報 Complete |
| `DOC-ID-02` | 27 PI B1 原子原字串不變 | 少一個／多一次混入伪原子 |
| `DOC-ID-03` | 31 WO/OBS 各一個，10/5/14/2 正確 | 同 ID 合併 DEV/USER、變更分類未附 CR |
| `DOC-ID-04` | 120 Parent＋124 Child＋38 Node 原始集合不縮 | 以一個 generic test 代表多個不同 Case |
| `DOC-ID-05` | 949 R15、192 Cell、81 Asset 原身份及原定義保留 | 直接將非 Boot Required 改為永久 Deferred |
| `DOC-ID-06` | `task_kind: DESIGN`，原 Candidate Claim Ceiling 不假升格 | 自動寫 `native_effect: PASS` |
| `DOC-ID-07` | Canonical FirstFail registry 與 alias 規則一致 | 拆成相異 first-fail 碼洗白 |
| `DOC-ID-08` | 所有內嵌 JSON/YAML/Python 等範例語法正確且明示非真 Token | 不存在的 CLI Flag 被聲稱可直接執行 |
| `DOC-ID-09` | Changed Paths 完全落在批准文件 WriteSet | 修改上游 DOC／其他 Repository 當作範圍內 |
| `DOC-ID-10` | Anchor 與內部相依 CrossRef 一致 | 指向不存在或改錯版本來源 |

### 8.2 三個必過的最小契約情境

1. **No Native Permit**：`READ_ONLY_PROBE` 可在有權讀取條件下運作；若當前 Repository 施工本身缺 DEV Admission，則 Repo Write HOLD；Host Effect 和 UserData Effect 缺真 Permit 必 NACK。不得出現「全不能做」或「全可做」。
2. **A blocked，B/C independent**：只有依賴 A 的子圖 PARK；B/C 經合法作用域可繼續；總 Mission 不能 Final。
3. **Commander-SP Disabled**：所有直接 `sbl-commander-sp` 呼叫禁用；產品 Required 不刪；非 Commander Proposal 真 ABI 未發現時 GWO Proposal 受影 HOLD，其他合法工程照常。

### 8.3 擴展反例（必要）

| Case | 情境 | 預期 |
|---|---|---|
| `DOC-NEG-01` | C0 `required_source_families` 含未發行 Native TaskKind | 拒絕錯誤分類，搬至 C5/Effect Admission；實際 Source 缺失仍如實拒絕 |
| `DOC-NEG-02` | P4 DOC-03 字串當作可證 DOC-07 同 Writer | `ORACLE_UNBOUND`，需 Owner Ratification／Adapter |
| `DOC-NEG-03` | 12 軸中任一風險 Veto 在 9 軸投影消失 | 映射拒收，不升 Profile |
| `DOC-NEG-04` | TQAEP 只有預定測試 JSON | `PLANNED`，不得產真 Checker Receipt |
| `DOC-NEG-05` | 某 Method 僅安裝未調用 | Required `METHOD_REQUIRED_NOT_INVOKED` |
| `DOC-NEG-06` | Report/Manifest/Seal 完成而 READY>0 | `MISSION_COMPLETE=false` |
| `DOC-NEG-07` | 同 SID Maker/Checker 以字串不同自證 | 高保證 Checker 狀態 `UNVERIFIED` |
| `DOC-NEG-08` | Fabric Stage File 存在但 Consumer ACK 無 | R3 保持 HOLD |
| `DOC-NEG-09` | PLAN/EXECUTE/VERIFY 配置與 Served 不同 | R4 mismatch NACK |
| `DOC-NEG-10` | 原 SBL CLI 安裝、無真 user task | GWO-SBL User Effect `NOT_RUN` |
| `DOC-NEG-11` | 舊外援 token 被 Revoke 仍可調用 | G-B FAIL/NACK；不准 Release |
| `DOC-NEG-12` | PR #20 修改 ADR-0008／0009 超許可基線 | CI 仍須 FAIL，不放寬 AllowedSet |
| `DOC-NEG-13` | Host Root 是 reparse/junction 到外部 | Readback 發現 path escape；禁止寫入 |
| `DOC-NEG-14` | 某 Repo HEAD 改、驗收仍引用前版 raw | SameSubject 不符；受影 Gate 失效 |
| `DOC-NEG-15` | 非觸發 Conditional 或 Deferred 被全數排 READY | 應只追蹤身份與重入條件 |
| `DOC-NEG-16` | 手寫 JSON 自稱 HGK Permit／PIPD Native PD | NACK：`DESIGN_ONLY` |
| `DOC-NEG-17` | 同 GWO Raw 被另一 Domain 重用 | Receipt identity mismatch，NACK |
| `DOC-NEG-18` | Worker Crash 後重送未知世界效果 | 先 Reconcile，不盲重播 |

### 8.4 靜態合格與真實現場驗收明確分開

- `DOC_STATIC_PASS`：來源、身份、文字契約、Schema、差異／負例達本文件檢查要求；**不**代表現役 ABI 已按新文件部署。
- `DOC_EFFECTIVE_ADOPTED`：有權 Owner 已明確版本化接受受影修訂，能追蹤生效版與代碼版；**不**代表 Host 已修。
- `RUNTIME_BOOTSTRAP_SMOKE_PASS`：真 Host、SharedSpine、Hermes Executor、OS Wakeup 和新 PID 有 Raw。
- `NATIVE_GATE_PASS`：正式 Issuer、World Effect、同 Subject Raw、Independent Checker 真閉合。
- `MISSION_RELEASE`：G-A＋3 GWO＋G-B、撤銷外援、殘留／Manifest／Release 真成立。

---

## 9. OWNER 授權決策包——僅請真正需決策的事項

Codex 請**一次**輸出下列 Decision Register，對沒有歧義且在 Standing Scope 內的 E0/E1 工作自動完成候選；不要每張卡重新詢問。任何高權威變更未核准時保持受影 OPEN，不得假裝通過。

| Decision | 原因 | 預設處置（無裁決時） |
|---|---|---|
| `OD-01 DOC_PATCH_WRITESET` | 九冊文件是否可在指定分支修改／送 PR | 未授權只出 Patch Proposal、無實際寫入 |
| `OD-02 EFFECTIVE_DOC_VERSION` | 受影條文何時取代舊版 | 原 r3 仍 Source Candidate；新補丁待採納 |
| `OD-03 SBL_PROPOSAL_ENTRY` | DOC-08 非 Commander `plan.propose` 真 ABI 或最小 Adapter | GWO Proposal HOLD、其他可行工作繼續 |
| `OD-04 PIPD_ORACLE` | DOC-07 vs Legacy DOC-03 權威／Namespace | 受影 Compiler/PI/TQAEP HOLD，唯讀續行 |
| `OD-05 PIPD_PROFILE` | 12→9 Risk Mapping 和 Veto | 高風險映射未通不降級 |
| `OD-06 BOOTSTRAP_DEV_ADMISSION` | 是否已有真正合法 Repo 修復 Scope／Native Recovery | 沒有不得 Repo Mutation，只做合法 read-only |
| `OD-07 NATIVE_HOST_PRIVILEGE` | 哪些 Native Operation 必須 Windows elevated/admin | 最小權限，未知不得升權 |
| `OD-08 USER_DATA_CONSENT` | GWO-SBL Synthetic DataDir、真 User Effect | 無 Consent 即禁止 User Effect |
| `OD-09 INDEPENDENT_CHECKER` | 原生不同 Principal／Trust Anchor 是誰 | 無實證不能 Native PASS |
| `OD-10 RELEASE_SCOPE` | B1 Bootstrap Gate vs 完整產品／SWOF W3 | B1 僅限 Bootstrap；Full Product 保留追溯 |

OWNER 裁決一經有效批准，轉換為原有系統可驗的範圍／Policy／Token，不留在自然語言報告中當永久口頭憑證。對非現在必須的決策，只登記 `DECISION_DEFERRED_WITH_TRIGGER`，不阻斷當前合法工作。

---

## 10. 完整執行與交付工件結構

**這是建議的修補候選輸出結構，不要求現有 Repo 必須新建一套平行治理資料夾**；Codex 應先復用其既有 `docs/`, `tests/`, `scripts/`, `evidence/` 等慣例，再按 Owner Scope 收斂。

```text
B1_DOC_REPAIR_CANDIDATE/
  SOURCE_MANIFEST.json              # 39 source file exact path/hash; candidate only
  AUTHORITY_AND_VERSION_MATRIX.md   # owner+source+version+status
  ROOT_CAUSE_TO_PATCH.tsv           # RCA-01..48 -> affected files -> test -> evidence
  ISSUE_AND_CR_REGISTER.md          # existing conflict + new findings
  PATCH_CHANGELOG.md               # clause_before/after/reason/owner
  DOC_00..08/                       # nine repaired candidate copies; same original identities
  EXECUTION_PROJECTION_CANDIDATE.json
  DIFF/                             # git diff --check + per-file diff
  TEST_REPORT.json                  # command/exit/stdout/sha for static and fixture tests
  DOC_REPAIR_RESULT.md              # exact PASS/HOLD, no Native claims
  HANDOFF_TO_HERMES.md              # concise bindings, Ready scopes, missing native proofs
```

輸出檔名僅為建議；不可隨意建立第二個 Service Database。最重要的是每個交付物有**有權來源／真測試／SHA／狀態**，不是僅存在同名文件。

**必要最終摘要**：

```text
DOC_SOURCE_IDENTITIES       : <counts and original hashes>
DOC_PATCH                  : PASS / PARTIAL / HOLD
OWNER_ADOPTION             : ADOPTED / PENDING / DENIED
STATIC_TESTS               : X/Y with test log refs
PER_EFFECTCLASS_APPLICABLE : actual 10/5/14/2 mapping
ORACLE_DECISION            : APPROVED_MAPPING / CR_OPEN
SBL_PROPOSAL              : LIVE_ABI_PROVEN / UNBOUND
RUNTIME_BOOTSTRAP          : NOT_RUN until true Hermes raw
NATIVE_ACCEPTANCE          : NOT_RUN / HOLD until Issuer+Checker
G_A / GWO_FAB/HGK/SBL / G_B: NOT_RUN / HOLD until world effects
READY_COUNT_SOURCE         : SharedSpine (if accessible; otherwise MISSING)
FIRST_FAIL                 : exact earliest real blocker with evidence
NEXT_ACTION                : authorized, replay-safe, bounded
```

---

## 11. 可直接交給本地 Codex 的主施工 PROMPT

> **使用方式**：將以下整段交給具有合法工作目錄讀／寫權限的本地 Codex CLI、IDE 或 Codex Worktree Worker。**在真 Windows Host 上**，提供已批准的來源目錄與指定輸出工作區；不可把本對話 `/mnt/data` 當成使用者電腦的既有目錄。若環境根本無寫入授權，就只能生成可審查 Patch Proposal。

```text
你的角色：FHS-MSC B1 DOC-00～08 高保留來源契約修補工程師（Codex Local）。
任務：以本文件《FHS-MSC B1 Bootstrap Repair｜DOC-00～08 高自動化、單人 OWNER 友善之高保留修補總方案》為修補施工計畫，對已獲 OWNER 授權的 B1 r3 DOC-00～08 做低阻力、最小差異、高保留的文檔候選修補與可重現回歸；不得修改真 Native Authority 或冒稱已完成 B1。

硬性原則：
(1) 不新增平行 Issuer/Scheduler/Policy DB/PIPD Compiler；HGK 唯一 Issuer，Hermes+SharedSpine 唯一 durable work authority，Fabric 原 ActivePolicy，SBL 原 Product/Proposal Owner，PIPD 原 Compiler。
(2) 原 DOC-00～08 全部保留核心設計、27 Atoms、31 WO/OBS（10 read-only、5 repo-write、14 host-ops、2 user-data）、120 Parent、124 Child、38 Nodes、949 R15、192 Cells、81 Assets、3 GWO；不能刪、縮分母、改 Required 或默默降低原 Gate。
(3) 本輪禁用尚未修復的 sbl-commander-sp。DOC-08 plan.propose 若無真合法非 Commander ABI，要明確 CR_OPEN，不可杜撰接口，也不可讓 SBL 自簽 HGK Permit。
(4) 唯一人類 OWNER 可對同 Scope 受控工程一次授權，不等於所有機器技術身份共用 key/SID；Maker/Signer/Checker 真獨立及 Native Issuer/Permission 不可省略。
(5) C0 Source、C5 Runtime Readiness、Effect Admission、Independent Acceptance 分層；修正 PL-003 兩個未來工件錯被 required_source_families、PL-004 Oracle 分類歧義；真 Compiler 必拒不合法 Effect，不得修改 Compiler 放寬錯誤。
(6) 普通文檔與合法受限 DEV 修補和真 Native Host/User Effects 分離。先查真 RepoContext/WriteSet/ECP/OS 權限；未獲授權不得寫入或做 Host User Effect。
(7) 靜態文件、PR、CI、Raw、Host Loaded、Model Served、Checker Verdict、B1 Release 分級。不得以文件改動宣稱原生 Gate 已通過。
(8) 不建立第二個可寫 WORK_QUEUE.json；若需 WorkQueue 視圖，只能由既有 SharedSpine 衍生，不可與它競爭 Authority。
(9) 隔離 git worktree/approved directory，先列 SHA/HEAD/Dirty；不得 reset/clean、刪別人的未追蹤檔、推送／合併／部署未核准變更。
(10) 未知事實明列 MISSING/UNVERIFIED/NOT_RUN；只有實際命令有退出碼、Raw 和來源後才能標 PASS。

步驟 1（Read Only）：
掃描 OWNER 指定範圍中的 B1 九冊、FHS-MSC_總討論、FHS-MSC_藍圖_r2、B1指揮施工_總紀錄、B1施工_PROMPT、B1施工狀況_總鑑定分析、FHS_MSC_B1_Task_Handoff、PIPD DOC00..09、SBL DOC00..13。建立檔名/絕對路徑/bytes/sha256/Git HEAD/Dirty/來源法位。未見即 MISSING，不推測。

步驟 2（Source Cross-Review）：
根據本方案 RCA-01..48 逐條核對原始受影條文、歷史證據強度，另外掃描新衝突。輸出 ROOT_CAUSE_TO_PATCH.tsv（RCA, upstream_loc, B1_loc, old_text, proposed_text, reason, owner, patch_class, acceptance_test, evidence_status）。同層權威衝突只開 CR，不自動投票。

步驟 3（Patch Plan）：
優先 DOC-00、DOC-02、DOC-08，接著 DOC-01/03/04/07，最後 DOC-05/06 只加短小 Execution Projection／CrossRef。不對 DOC-05/06 全文重生、不重排原大表。寫集只能是 OWNER 批准的文件和允許的新候選測試腳本／報告。

步驟 4（Actual Patch）：
採編輯最小差異；對每段新條文標記 Authority/EffectClass/When/FirstFail/Owner/NoFit/Positive/Negative/Release ceiling；維護 changelog。若已存在等效原規則只加索引或不用改，避免重複治理。

步驟 5（Regression）：
執行 Markdown/JSON/YAML parse、Git diff --check、身份差集、全 31 EffectClass、FHS r2 產品身份保留、原 Canonical Failure Registry、交叉連結，並實跑本方案 DOC-ID-01..10 和 DOC-NEG-01..18 的靜態或 Fixture 層可執行部分。對須真 Native 的 case 標 TEST_PLAN_ONLY/NOT_RUN，不以 Fixture 假稱 Native PASS。

步驟 6（Autonomous FirstFail Repair）：
對可在授權範圍自行修復的 Syntax、CrossRef、ID 複製錯誤、測試錯誤、文件矛盾，維持 RED→MINIMAL PATCH→GREEN。無法裁決的 Canonical Owner 或真 OS/Issuer/Policy 問題，記決策請求、影響範圍與下一 Trigger，其他合法工作繼續。

步驟 7（Review & Adoption Handoff）：
輸出九冊修補版、source manifest、完整 Diff、RCA coverage、Static Test Report、CR_OPEN、OWNER 決策列表，以及薄型 Hermes handoff。文件成功僅稱 DOC_PATCH_CANDIDATE / DOC_STATIC_PASS。除非真 Owner Ratification 存在，必保留源版本未正式生效；不要自稱完成 SourceFreeze 或 B1。

步驟 8（Stop Rule）：
DOC Phase 可在全部已批准 DOC 修改完成、測試閉合、每個剩餘 CR 均有具名 Owner／原因／不影響其他工作之路徑後結束。這不是 B1 Mission Complete。不要為非阻斷美化延長本輪。若有已授權的真 Hermes 環境，另交由 Native Executor 從 SharedSpine READY 續行；本次文檔修補工具不得以自己的 Session 替代 Hermes Native Successor。

回覆格式：
1) Source/HEAD/Dirty 真讀回；2) Changed Files/Exact Diff；3) RCA-01..48 覆蓋率和任何新 Issue；4) 十個 DOC-ID／18 個 DOC-NEG 的真結果與未執行類別；5) Authority/CR 決策清單；6) 不能冒稱的 Native 缺件；7) 下一個合法、可重現的 Host 操作。若沒有真寫入權限，交付 Patch Proposal 而不是謊稱寫入。
```

---

## 12. Codex 本地指令序列（範例，不假設固定路徑）

以下僅針對**已授權本地工作目錄**的安全初步定位；使用者應透過 Codex 的真互動或設定指定 Repo／檔案，工具應自行查路徑。命令先唯讀，不涉及 Native Host Effect。

```powershell
# Step 0: 進入 OWNER 已核准的文件工作目錄（不得猜測任何真 Root）
Get-Location
Get-ChildItem -File -Filter '*.md' | Select-Object Name,Length
# 在每個真文件上計算 SHA
Get-ChildItem -File -Filter '*.md' | Get-FileHash -Algorithm SHA256 | Select-Object Path,Hash

# 如果經確認這個資料夾位於 Git Repository 內，唯讀查詢
# 請先在已確認的 Repo Root 內執行；不要用下列命令改動檔案
# git rev-parse --show-toplevel
# git rev-parse HEAD
# git status --short
# git branch --show-current

# 對已生成、已批准範圍內的候選 diff 作檢查
# git diff --check
# git diff --stat
# git diff --name-only
```

**寫入步驟**：應先由 Codex 查詢並核實 Git 實際 Worktree 能力、在現有 Repository 的批准分支或已授權的獨立拷貝操作。不得在原 Dirty Root 上直接覆寫文件；不能靠把 Root 複製到另一個位置就自動取得 SourceFreeze 或 Owner Write Permission。

**CLI 版本注意**：真正 `codex exec` 參數、模型、Sandbox／Approval Policy 一律按當前安裝 binary `codex --help`／`codex exec --help` 確認，**不假定任何文件中的 Flag 在 2026-10-27 本地必可用**。

---

## 13. 文檔完成後——不可省略的實機 Bootstrap 銜接

文檔修補的結果應縮短後續 Runtime 工作的解讀成本，但以下缺陷仍須在使用者 Windows Host 由有權主體實作：

| 真實工作 | 下一步 | 必須有的真證據 |
|---|---|---|
| Hermes Durable Continuation | 先查既有真 Executor／Queue/Lease／Task Scheduler；缺失才由 Codex 做最小 Adapter | READY→Lease→Executor→Checkpoint→不同 PID 自發續行，READY 非零不得 Final |
| HGK User Trust | 查本地 User Trust、Current Registry、Receiver Resolver、Root／SID／Key ACL | Signed Admit、Bad Key/Nonce/TTL/Revoke NEG、權限分離 |
| Fabric R3 | 找現役 Stage／Activator／Active／Consumer，合法受限操作 | 真 Stage/Loaded/Consumer SHA/Epoch／不同 Raw |
| Model R4 | 查 Policy Required/Served，三 Lane 真調用 | PLAN/EXECUTE/VERIFY_SECURITY 各獨立 request+served readback |
| PIPD ABI | Oracle DOC07 vs DOC03、Profile 12→9、TQAEP Design/Live | Owner-ratified Adapter、Schema/CI 正反例 |
| PIPD CI | 對 PR #20 的 Stage-C allowed WriteSet 做精確 Base/Head 歸屬 | 兩 CI Gate success，非允許檔仍 NACK |
| SBL GWO | 查非 Commander Proposal；獨立 User Data 授權與 Synthetic DataDir | Proposal 真 ABI；Install/Add/List/Remove/List/Uninstall 各 Raw |
| G-A／3 GWO／G-B | 真 G-A 合取，三域不同 Golden WorkOrder，撤外援並新進程續行 | SameSubject 真 Checker、Revoke old token NEG、zero residue、Native Successor |

**起跑原則**：只在必要的相應文件條款由有權 Owner 採納後，才用其作正式新 Gate；既有合法的 Read-only Probe 不必等待所有九冊 DOC 文字被整理完。缺一項未准入的 Native Effect 不該回頭阻止無關工程。

---

## 14. 施工節省成本的判定與停止損失線

### 14.1 只投入可避免重工的 DOC 修改

- `PATCH_PRIORITY=P0`：C0/C5/Effect Gate、OWNER Standing Scope、局部 HOLD、DOC-08 Proposal、Stop Rule；這些直接關係到 Codex/Hermes 是否能合法繼續。
- `PATCH_PRIORITY=P1`：Oracle／Profile／TQAEP ABI、Runner Binding、Method Policy、各 Domain Evidence 邊界；可按依賴與 P0 實測同步處置。
- `PATCH_PRIORITY=P2`：語句精緻化、全面格式統一、全量重排、非啟動關鍵的 Deferred 產品規格；**本輪不做**。

### 14.2 時間／成本評估邏輯

`DOC_REPAIR_NET_BENEFIT = avoided_repeated_diagnosis + avoided_false_global_hold + avoided_wrong_host_effect + avoided_approval_roundtrips - document_patch_cost - validation_cost - owner_ratification_cost`。

歷史 r1～r10 多次停工足以支持進行 P0 文檔收斂；**沒有可信工時與 Token 資料可以推定實際節省百分比**。本輪應實際記錄 `time_to_first_valid_workorder`、`number_of_unnecessary_HITL`、`false_global_hold_count`、`first_fail_to_green_duration`、`native_gate_progress`，再判斷高 CP 值是否成立。

### 14.3 停止損失線

- 連續修改仍未改善三個 P0 情境：暫停全量文檔修補，回到真 Runner／Owner/Admission 調查。
- 需要更動上位 PIPD/SBL 核心法位：開 Domain Owner 受影 CR，不在 B1 Doc 做隱式取代。
- Writer／Authority 雙重化：回退該候選差異，不新增第二套系統。
- DOC-05/06 巨量重生成：拒收，改為附加短小映射索引。
- 實機已具現成良好 Executor：不為實作新設計而改寫 Runtime；直接驗證已存在能力。
- 真 Native Gate 尚未通過：可交付 `DOC_REPAIR_COMPLETE`，但必保留 `B1_NATIVE_ACCEPTANCE_INCOMPLETE` 和具名下一觸發。

---

## 15. DoD：本方案與 B1 正式任務的雙重退出條件

### 15.1 文檔修補 DoD（可由 Codex 高自動化完成）

- [ ] 九冊原件真位元、SHA、版本、Owner／原法位全部讀回。
- [ ] RCA-01～48 各具名定位為 `PATCHED / ALREADY_SATISFIED / DOMAIN_OWNER_CR / NATIVE_DEPENDENCY / NOT_APPLICABLE`；每項有理由、來源、測試。
- [ ] DOC-00、02、08 的 P0 條款已提出最小差異並通過相應負例。
- [ ] DOC-01、03、04、07 的受影 ABI／權限／方法條款已對齊或登錄 CR。
- [ ] DOC-05、06 的原身分全部保留，沒有重生成造成語義丟失。
- [ ] 27／31／120／124／38／949／192／81／3 GWO 的原身份／語義未縮水，Diff 可追溯。
- [ ] `SOURCE / RUNTIME / ADMISSION / ACCEPTANCE` 四種 Gate 分層，三個 P0 代表情境通過。
- [ ] Git Diff 僅批准 WriteSet，沒有 reset／clean 或非法路徑更動。
- [ ] 所有 `OWNER_DECISION_REQUIRED` 已具名；未批准項不當成正式生效。
- [ ] 產出可交付 Hermes 的薄型執行候選、下一合法工作、剩餘 Gate；沒有冒稱 Native 完工。

### 15.2 B1 Native DoD（不是 Codex 文檔修補能自行簽發）

- [ ] 真 HGK Issuer/Receiver 的正反 Admission、SoD 成立。
- [ ] 真 Hermes Durable Loop、OS Wakeup、跨 PID Resume、防提前結案成立。
- [ ] 真 Fabric Stage→Active→Loaded→Consumer ACK 成立。
- [ ] 三 Model Lane 皆 Required=Served 且正反可重現。
- [ ] PIPD Native 編譯、Oracle/Profile/TQAEP 正規合格，CI WriteSet 不放寬。
- [ ] 有效 SBL Proposal 及三域 Golden WorkOrders 各獨立 Raw/Checker。
- [ ] G-A 六項合取達真 PASS；外援 Revoke、G-B 新進程 Native Successor、零殘留及舊 Token 拒收成立。
- [ ] 不縮原產品身份，不將 Full Product／SWOF W3 誤當已完成。
- [ ] 完整 Raw、Manifest、獨立 Checker、正式 Release／Handoff 具可驗證主體。

**最後裁決**：最短路徑不是削減正式安全驗收，而是先用 Codex 把文檔／Contract 的**執行適用性**修順；再真正修 Hermes/HGK/Fabric/SBL/PIPD 的 Native 接線。此方案刻意不解決不存在的權限、不假造測試結果，也不讓文檔完成使 Agent 錯誤停止。它是可供本地工具落地的施工計畫，**不是已實施的修改紀錄**。

---

## 附錄 A：DOC-02 原始 31 WO／OBS EffectClass 施工索引

> 下表根據本輪掛載 DOC-02 的標題直接擷取；Codex 應對每一列再次與實際已批准版本及 Policy 做版本綁定，不把表格當成唯一 Runtime work-state。

| 原 PD | WorkOrder／Observation | 原領域主題 | EffectClass | 建議先做的合法動作 |
|---|---|---|---|---|
| PD-01 | `OBS-B1-A1` | ROOT_RAW | `READ_ONLY_PROBE` | 先唯讀核對 Current Host/Source；不得假 Report 為 World Effect |
| PD-02 | `WO-B1-A2` | ISSUER_SUBJECT | `HOST_OPERATIONS` | 先查真 Native Owner Adapter／Policy／Permit，缺時本卡 PARK |
| PD-03 | `WO-B1-A3` | QUEUE_WO | `HOST_OPERATIONS` | 先查真 Native Owner Adapter／Policy／Permit，缺時本卡 PARK |
| PD-04 | `WO-B1-A4` | RECEIVER_ABI | `HOST_OPERATIONS` | 先查真 Native Owner Adapter／Policy／Permit，缺時本卡 PARK |
| PD-05 | `OBS-B1-A5` | MODEL_LANES | `READ_ONLY_PROBE` | 先唯讀核對 Current Host/Source；不得假 Report 為 World Effect |
| PD-06 | `WO-B1-A6` | EFFECT_JOURNAL | `HOST_OPERATIONS` | 先查真 Native Owner Adapter／Policy／Permit，缺時本卡 PARK |
| PD-07 | `OBS-B1-A7` | RAW_EVIDENCE | `READ_ONLY_PROBE` | 先唯讀核對 Current Host/Source；不得假 Report 為 World Effect |
| PD-08 | `WO-B1-A8` | NATIVE_HOTPATH | `REPOSITORY_WRITE` | 先查真 RepoContext／WriteSet／DEV Admission；缺則只做診斷 |
| PD-09 | `WO-B1-A9` | NATIVE_CONTINUATION | `HOST_OPERATIONS` | 先查真 Native Owner Adapter／Policy／Permit，缺時本卡 PARK |
| PD-10 | `OBS-B1-B1` | SOURCE_ATOMS | `READ_ONLY_PROBE` | 先唯讀核對 Current Host/Source；不得假 Report 為 World Effect |
| PD-11 | `OBS-B1-B2` | REPO_CONTEXT | `READ_ONLY_PROBE` | 先唯讀核對 Current Host/Source；不得假 Report 為 World Effect |
| PD-12 | `WO-B1-B3-DEV` | SBL_TO_NATIVE__DEV | `REPOSITORY_WRITE` | 先查真 RepoContext／WriteSet／DEV Admission；缺則只做診斷 |
| PD-13 | `WO-B1-B3-OPS` | SBL_TO_NATIVE__OPS | `HOST_OPERATIONS` | 先查真 Native Owner Adapter／Policy／Permit，缺時本卡 PARK |
| PD-14 | `WO-B1-B4-DEV` | ECP_SELECTOR__DEV | `REPOSITORY_WRITE` | 先查真 RepoContext／WriteSet／DEV Admission；缺則只做診斷 |
| PD-15 | `WO-B1-B4-OPS` | ECP_SELECTOR__OPS | `HOST_OPERATIONS` | 先查真 Native Owner Adapter／Policy／Permit，缺時本卡 PARK |
| PD-16 | `WO-B1-B5-DEV` | THREE_SP__DEV | `REPOSITORY_WRITE` | 先查真 RepoContext／WriteSet／DEV Admission；缺則只做診斷 |
| PD-17 | `WO-B1-B5-OPS` | THREE_SP__OPS | `HOST_OPERATIONS` | 先查真 Native Owner Adapter／Policy／Permit，缺時本卡 PARK |
| PD-18 | `WO-B1-B6-USER` | TODO_PERSISTENCE | `USER_DATA_EFFECT` | 先查 UserData Owner／獨立同意／Scope，缺時零資料效果 |
| PD-19 | `OBS-B1-B7` | NOFIT_ROUTE | `READ_ONLY_PROBE` | 先唯讀核對 Current Host/Source；不得假 Report 為 World Effect |
| PD-20 | `OBS-B1-B8` | TRACE_GRAPH | `READ_ONLY_PROBE` | 先唯讀核對 Current Host/Source；不得假 Report 為 World Effect |
| PD-21 | `OBS-B1-B9` | R15_COVERAGE | `READ_ONLY_PROBE` | 先唯讀核對 Current Host/Source；不得假 Report 為 World Effect |
| PD-22 | `WO-B1-C1` | FABRIC_PROMOTION | `HOST_OPERATIONS` | 先查真 Native Owner Adapter／Policy／Permit，缺時本卡 PARK |
| PD-23 | `WO-B1-C2` | HGK_GWO | `HOST_OPERATIONS` | 先查真 Native Owner Adapter／Policy／Permit，缺時本卡 PARK |
| PD-24 | `WO-B1-C3-OPS` | SBL_GWO__INSTALL | `HOST_OPERATIONS` | 先查真 Native Owner Adapter／Policy／Permit，缺時本卡 PARK |
| PD-25 | `WO-B1-C3-USER` | SBL_GWO__USER | `USER_DATA_EFFECT` | 先查 UserData Owner／獨立同意／Scope，缺時零資料效果 |
| PD-26 | `WO-B1-C4` | EXTERNAL_GRANT | `HOST_OPERATIONS` | 先查真 Native Owner Adapter／Policy／Permit，缺時本卡 PARK |
| PD-27 | `WO-B1-C5` | CODEX_MINPATCH | `REPOSITORY_WRITE` | 先查真 RepoContext／WriteSet／DEV Admission；缺則只做診斷 |
| PD-28 | `WO-B1-C6` | REVOKE_RACE | `HOST_OPERATIONS` | 先查真 Native Owner Adapter／Policy／Permit，缺時本卡 PARK |
| PD-29 | `OBS-B1-C7` | FOUR_LAYER_ID | `READ_ONLY_PROBE` | 先唯讀核對 Current Host/Source；不得假 Report 為 World Effect |
| PD-30 | `WO-B1-C8` | NATIVE_SUCCESSOR | `HOST_OPERATIONS` | 先查真 Native Owner Adapter／Policy／Permit，缺時本卡 PARK |
| PD-31 | `OBS-B1-C9` | TRIPLE_GWO | `READ_ONLY_PROBE` | 先唯讀核對 Current Host/Source；不得假 Report 為 World Effect |

---

## 附錄 B：本輪實際掛載的 39 份來源基線（供本地 Codex 交叉比對）

> 下方 SHA-256 是**本對話容器中所掛載原始檔案的來源快照**，並非有權 Owner 簽發的 SourceFreeze；Codex 必須對使用者本地真檔案重新計算，不得假定 SHA 必須一致或直接覆蓋不同本地版本。檔名 `(1)`、`(2)` 等只反映上傳副本命名。

| 類別 | 來源檔名 | 行數 | SHA-256 |
|---|---|---:|---|
| 施工／交接 | `B1指揮施工_總紀錄.md` | 6855 | `5e83ec59cf226d666146f0d73436cd87b30e35d30918657c6762f04ee576208c` |
| 施工／交接 | `B1施工_PROMPT.md` | 1643 | `6f24b2aac28dd8b3aa4823250dc6c18115580f743f141d2db2fb3011e8804409` |
| 施工／交接 | `B1施工狀況_總鑑定分析.md` | 6658 | `a7b17816b46d8f4ff38a3b62b336b7d36895d9730e82e6b8f892141f013f4936` |
| FHS 上位 | `FHS-MSC_總討論(1).md` | 4930 | `9ecd1f6f1d9c854206eee4a12519b08e6caf61951a3735502654272416ae0597` |
| FHS 上位 | `FHS-MSC_藍圖_r2(2).md` | 4191 | `a80b3b4d7cc93e52a297a3e5176e27f207b36b8cd81a3d5440c70b4a80290ff9` |
| B1 r3 | `FHS_MSC_B1_PIPD_LS_PKG_00_GOVERNANCE_AND_CONTROL(1).md` | 111 | `3096e98096ad48b3b3cfda07c6075ccffba8b44c1851a804d63f0ab103aef576` |
| B1 r3 | `FHS_MSC_B1_PIPD_LS_PKG_01_DOC_B1_PI(1).md` | 341 | `e1d8931c036a1e9dc97f79a3d0d00f151ea5a29dc81fb3d7aa488d5446d7b666` |
| B1 r3 | `FHS_MSC_B1_PIPD_LS_PKG_02_DOC_B1_PD(1).md` | 1289 | `8e15b92a69302bbb0f9a6352f80c9687fdfb3a217006703a87b3ba559f42eb2b` |
| B1 r3 | `FHS_MSC_B1_PIPD_LS_PKG_03_DOC_B1_OPS_ECP(1).md` | 756 | `54a17818473f2a4b7c4f0f8f504bc96e4e1450540facfd30cf38234fa89e8b8a` |
| B1 r3 | `FHS_MSC_B1_PIPD_LS_PKG_04_DOC_B1_DEV_ECP(1).md` | 101 | `7a1e44dfd91bd24011c019f3ff73446e6cebf4b7847d7220f7c78dc25927def5` |
| B1 r3 | `FHS_MSC_B1_PIPD_LS_PKG_05_DOC_B1_TQAEP(1).md` | 12056 | `1e09126f0c8e92fcd6e8531072a3f1f3033d82a671c2b4bb62c9916e675b7127` |
| B1 r3 | `FHS_MSC_B1_PIPD_LS_PKG_06_PRODUCT_COVERAGE_AND_R15(1).md` | 6919 | `f929d9cffd462d23bbdb52171f72a450e96e59c8333bc05ebd739a2d38338337` |
| B1 r3 | `FHS_MSC_B1_PIPD_LS_PKG_07_NATIVE_TOOLCHAIN_EXACT_USAGE(1).md` | 141 | `d1e0283200ad57cf1a3a1fc62bc09c6980ff118d4b7af4401d011ea87a009ea7` |
| B1 r3 | `FHS_MSC_B1_PIPD_LS_PKG_08_GOLDEN_WORKORDERS_E2E(1).md` | 70 | `bc12a5fca45e4f68c1b1a4772b00ca72e0c07be8293527bbaafceadc7347290f` |
| 施工／交接 | `FHS_MSC_B1_Task_Handoff_Report_v1_2026-10-27.md` | 734 | `aa006bc849c5bb6404265de6a28678e0a4ed8b75b13521b39d5dcf28fc07162d` |
| PIPD DOC | `PIPD_LS_DOC-00_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md` | 2292 | `be3a672ec20aa0e6b5e0e35097fc08de749bfe7f59f827d18e38aef67dd68ea4` |
| PIPD DOC | `PIPD_LS_DOC-01_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md` | 2592 | `b753f2e5cdd5598a818f8a113d57b7f815aeb3f1dfa061ce74c76bb3553ac8c7` |
| PIPD DOC | `PIPD_LS_DOC-02_2026-10-07_r2_HIGH_RETENTION_AUDIT_PATCHED_FULL_REPAIR_FULL_SUBSTANTIVE_BODY (1).md` | 18413 | `a021998dd3b63015e89af1dd40e0b413744a69b872da46c6bf5f4d92f7f23d0b` |
| PIPD DOC | `PIPD_LS_DOC-03_2026-10-07_r2_AUDIT_REPAIR_FULL_SUBSTANTIVE_BODY.md` | 1911 | `d89d82dcd2c8603ec6b86c5ec8c40845e4594bc181adf5272bd48a3de7c88f0f` |
| PIPD DOC | `PIPD_LS_DOC-04_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md` | 4052 | `fa64d84da3d747b183e4affff62f4d2fb86c80bb5075f5dd933c09b20caeddcf` |
| PIPD DOC | `PIPD_LS_DOC-05_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md` | 3946 | `7b40584540c162cda6debfd09a4c04321416706acdb03a7a3c2b41383dc585f4` |
| PIPD DOC | `PIPD_LS_DOC-06_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md` | 3790 | `20e44ea4dd8e53c9b0a076ce861136bbea86f52687019307f6e995cd9079d303` |
| PIPD DOC | `PIPD_LS_DOC-07_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md` | 12915 | `a68dae1c3670d07bcfa3476a1e37463c534594df5cd65d8dab0dca064b5a9fc1` |
| PIPD DOC | `PIPD_LS_DOC-08_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md` | 2501 | `e46caa7e440392a6cfa7a86421aead5bce8a2a229fec97b133429db6b6748e42` |
| PIPD DOC | `PIPD_LS_DOC-09_2026-10-07_r2_HIGH_RETENTION_AUDIT_PATCHED_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md` | 2451 | `eaf0aefe2b4711c140fc3274223d88fdc38ad4ec2b7184f756a0f2471f3b0b54` |
| SBL DOC | `SBL_PIPD-LS-PKG_DOC-00.md` | 1591 | `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01` |
| SBL DOC | `SBL_PIPD-LS-PKG_DOC-01.md` | 4938 | `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f` |
| SBL DOC | `SBL_PIPD-LS-PKG_DOC-02.md` | 11084 | `4ff0cda5ab00ba5f577151e5b004d2167d933e912e302c9e3529b237ccb9e035` |
| SBL DOC | `SBL_PIPD-LS-PKG_DOC-03.md` | 4851 | `ea69e1d3718ed86aecd74a3ebcc933960eacc30b586ab80fcb9f733037e33476` |
| SBL DOC | `SBL_PIPD-LS-PKG_DOC-04.md` | 3036 | `ee90cb1c86f6f7350c11c9c962233a89b035ca41ff82c8968f7968608fc6f6e0` |
| SBL DOC | `SBL_PIPD-LS-PKG_DOC-05.md` | 7888 | `3b47a0b6224b1984a4047cf53aac5ac50615c93a560fea46e1b43d079a5d9f27` |
| SBL DOC | `SBL_PIPD-LS-PKG_DOC-06.md` | 2858 | `64ea4977dab3093301f82dc7469413cc754998fc53946467842e06d83645102b` |
| SBL DOC | `SBL_PIPD-LS-PKG_DOC-07.md` | 3620 | `a366d3783c82089c5593ffabb0704d8507632cce45622684f7a0186f2ae310f8` |
| SBL DOC | `SBL_PIPD-LS-PKG_DOC-08.md` | 11139 | `c7029c1ff07abe3135d33d3abf858a5fecedd911b494cd69c16eb1ddb8158288` |
| SBL DOC | `SBL_PIPD-LS-PKG_DOC-09.md` | 3978 | `6450f7c15915ec8b304f4e5fd4093ea707434db8bae9d2bb6e66c30ab6eed2e1` |
| SBL DOC | `SBL_PIPD-LS-PKG_DOC-10.md` | 3888 | `a64aa21c977334dd74d660a86377ee10c4d329aa5fde0dae25ff81a3e69e8d8f` |
| SBL DOC | `SBL_PIPD-LS-PKG_DOC-11.md` | 5005 | `12f8705d780b76f264457c194a6ff359da8d74b5d6d8c83fa245b74d2a37508e` |
| SBL DOC | `SBL_PIPD-LS-PKG_DOC-12.md` | 7940 | `d1e470d82ca14319582cb8947aa52007927aa38e726249b1430804cfe8c8ca56` |
| SBL DOC | `SBL_PIPD-LS-PKG_DOC-13.md` | 3814 | `7cc0c8b17311130c875910b2548b93c28bd4e1c8ee04d300f85fc33d4c09beb1` |

---

## 附錄 C：本方案 RCA 與原始交叉核對定位簿

以下是人類／Codex 快速定位表；完整文內 RCA-01～48 的原始證據應由 Codex 以 `source_sha + exact line range + before/after clause` 重新產生，而不只引用這份摘要。

| 根因組 | 精確來源優先定位 | 主要修補文件 |
|---|---|---|
| RCA-01～06 | `B1施工狀況_總鑑定分析` L168–320、L954–975、L1259–1306；`FHS-MSC_藍圖_r2` §1.2／§7 | DOC-00/01/02/03/04/07 |
| RCA-07～11 | `B1施工狀況_總鑑定分析` L3941–4311、L4846–5185；Handoff KI-02 | DOC-00/03/04/05 |
| RCA-12～15 | `B1指揮施工_總紀錄` L6469–6555、L6577–6608；PIPD DOC-06/07、P4 Skill 需真版本 | DOC-01/02/03/05/07 |
| RCA-16～20 | `B1施工狀況_總鑑定分析` L1179–1306、`DOC-B1-00` §3、`DOC-B1-08` §2 | DOC-00/06/07/08 |
| RCA-21～23 | `B1指揮施工_總紀錄` L5950–6029、L6610–6654；DOC-B1-05/06 全量 | DOC-00/02/05/06 |
| RCA-24～32 | `B1指揮施工_總紀錄` L5774–5864、L6094–6152；Handoff KI-01 | DOC-00/02/04/08 |
| RCA-33～34 | `B1指揮施工_總紀錄` L5695–5766、L5912–5960；Handoff KI-03/04 | DOC-01/03/04/08 |
| RCA-35～37 | `B1指揮施工_總紀錄` L6469–6557、L6610–6690；Handoff KI-05/09 | DOC-03/04/05/07/08 |
| RCA-38～41 | `B1 r3 DOC-00` §4、DOC-03 Effect Journal／DOC-08 §1–5；Handoff §8 | DOC-00/03/05/08 |
| RCA-42～48 | `FHS-MSC_藍圖_r2` §0、§7–11；`B1指揮施工_總紀錄` L6161–6225；Handoff §§5–9 | DOC-00/04/05/06/07/08 |

### 來源追溯專項勘誤

- 早期 `PL-003 ×2 / PL-004 ×1` 是同一 Compiler Contract 的三個前置失敗，**不能**寫成三個已證實 Runtime 缺陷。
- 早期 `Knowledge Pack 00–19 R04 MUST NOT` 極性問題屬相關 Generator／Support 資料品質風險，不在本輪九冊文件內；不應靜默替這些 KP 改原件，應獨立開受影修復。
- r8/r9/r10 的證據可支持已有部分工作實作；**不可**據此推斷 r10 的 Fabric R3、Model R4 或真 Hermes Executor 已實際失敗，因報告主要標示 `NOT_RUN`。
- 上位 FHS r2 的 `SWOF PRE-W3 CONSUMPTION READY` 是 FHS 整體 MVP 候選 Exit，**不是** B1 Native G-B 的替代驗收，也不是 SWOF 真 `READY_W3`。
- Source Manifest 的 39 個 SHA 可證明本輪研究輸入位元存在，不表示原生 Domain Owner 批准、上游版本有效或 Host Loaded。
