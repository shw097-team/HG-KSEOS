# sbl-commander-sp_修補

**User:** Anonymous  
**Created:** 10/27/2026 20:45:07  
**Updated:** 10/27/2026 22:32:25  
**Exported:** 10/27/2026 22:50:43  
**Link:** [https://chatgpt.com/g/g-p-6acaeba0c56881919497d31c47756043-sbl-fhs-msc/c/6ae09cd2-46a8-83e8-89e0-632b4f588801](https://chatgpt.com/g/g-p-6acaeba0c56881919497d31c47756043-sbl-fhs-msc/c/6ae09cd2-46a8-83e8-89e0-632b4f588801)  

## Prompt:
2026/10/27 下午8:44:59

你的角色：
你是「HERMES / FABRIC / SBL / HG-KSEOS」高自動化任務運行總工程師。

任務目標：
你必須整合前輪「FHS-MSC B1 Bootstrap Repair 高自動化失效——完整工程根因鑑定與治理收斂評估報告」，再對「《B1指揮施工_總紀錄》、《B1施工_PROMPT》、《B1施工狀況_總鑑定分析》、《FHS_MSC_B1_Task_Handoff_Report_v1_2026-10-27》」，進行以下項目的「深度研究 + 交叉比對 + 分析評估 + 工程因果關係重建」：
"
你這次必須以「$sbl-commander-sp 」為目標進行分析(你只能對其分析，不可掛載)，因為是讓GPT-6掛載「$sbl-commander-sp 」產出指揮PROMPT，導致整個B1任務執行出現「治理過重、鏈路阻斷、不適合高自動化、一直索要沉重且不必要的授權、不適合單人OWNER....等等」問題，造成眾多B1施工問題，所以是否和「$sbl-commander-sp 」有關?

最後你必須對「$sbl-commander-sp 」的種種問題、潛在治理過度風險、不適合高自動化風險、內部矛盾....等等問題，提出完整工程鑑定評估報告。

任務要求：
最後你必須直接以文字提出完整報告。

## Response:
2026/10/27 下午8:45:10 · gpt-6-thinking

本次只做 `$sbl-commander-sp` 的靜態鑑定，不會掛載、啟動或調用它。我會先追查它在最初指揮、r1～r10 Prompt 與後續停工紀錄中的實際作用，再把「外掛造成的影響」「GPT-6 對治理規則的解讀」「B1 上位契約自身的限制」「Hermes／HGK 執行缺口」分開判定，避免把所有失敗都歸因於外掛。

交叉比對出現一項比「治理偏嚴」更具體的架構衝突：SBL 上位設計把 Commander-SP 定位為**在已具備受准入 ECP／WorkOrder 後才產出薄指揮**的下游角色；但 B1 DOC-08 又要求由「SBL Commander」先提出 GWO-HGK 候選，再交給 HGK Issuer。這可能形成「尚未簽發的 WorkOrder，需要先透過要求既有 WorkOrder 的 Commander」的循環。接下來會把這項契約衝突與實際 Compiler 拒收、人工授權要求及 r5～r10 的停工分開裁決。

> **分析四份文件，核查指揮規則**
>
>
> **分析文件並整理指揮施工證據與鑑定進度**
>
> 
>
> **整理 B1 施工紀錄與指揮規範**
>
> 
>
> **檢視 R1 提示與版本長度差異**
>
>
> **檢索 Commander 治理政策矛盾**
>
>
> **檢視 SBL 文件關鍵段落**
>
>
> **辨識流程矛盾**
>
> 我正在整理核心發現：文件間似乎存在循環依賴，且自動化流程在關鍵檢查點可能過早停止。現有紀錄不足以證明單一因素造成問題，因此我會區分已觀察結果與推測原因。
>
> **辨識流程矛盾**
>
> 
>
> **檢視提示版本差異、Commander 政策矛盾與 SBL 文件**
>
> 
>
> **評估 SBL 依賴矛盾與自動化風險**
>
>
> **釐清因果鏈**
>
> 我正在把紀錄分成觀察與推論：停滯不一定只由單一模組造成，因為停用後仍未完成。文件也混用提案與核發階段；我會建議分開兩種狀態，再驗證各自前置條件。
>
> **釐清因果鏈**
>
> 
>
> **評估 SBL 依賴矛盾與自動化風險**
>
> 
>
> 處理時間為 4m 25s

# FHS-MSC B1 專項工程鑑定報告

## `$sbl-commander-sp` 治理過載、Bootstrap 適配失效、授權阻斷與高自動化架構衝突

鑑定基準：2026 年 10 月 27 日｜分析對象：SBL Commander-SP｜範圍：指揮設計、施工 Prompt、跨系統治理、執行因果、適用性與改善方案

## 一、最終核心判定

**是。`$sbl-commander-sp` 與 B1 高自動化施工的反覆阻斷存在明確關聯，而且不只是偶然的時間關聯。**

但工程上必須作出更精確的區分：

**`$sbl-commander-sp` 是前期治理過重與 Bootstrap 流程錯置的重要促成因素；GPT-6 將其施工前置規則提升為整個 B1 Mission 的指揮規則，才是更直接的失效機制。**

現有證據尚不足以認定該外掛本身直接執行程式碼，造成 PIPD `PL-003`、`PL-004` 或 Hermes Runtime 故障。

專項鑑定結果

前期指揮治理不適配

## 高度確定

Bootstrap 適用性

## 不適合直接主控

直接造成 Compiler 失敗

## 未證實

作為高自動化總指揮

## 不建議

---

**工程處置裁決：** 維持本輪對 `$sbl-commander-sp` 的禁用，不將它作為 B1 Bootstrap、Hermes 自治施工、Native Issuer、Signer、Checker 或必要 Proposal 入口。後續若要恢復使用，必須先完成獨立的產品適配與治理資格化。

### 1.1 已有的直接證據

四份核心資料提供了相當完整的前後因果線索：

1. **2026 年 10 月 26 日 23:17**，最初 B1 指揮任務明確要求 GPT-6 掛載 `$sbl-commander-sp`，搭配 Knowledge Pack 00～19 及 `construction-acceptance-prompt-compiler`，為本地 Codex 規劃高自動化施工。
2. 當輪 GPT-6 隨後明確記錄已採用 Commander-SP 的主要約束，包括先取得 Frozen PI/PD、限定 Root/HEAD/WriteSet、可逆施工、原始證據，以及 Maker 不得自行驗收。
3. **10 月 26 日 23:44**，使用相同工具組合生成 Codex Master Mission Prompt；10 月 27 日凌晨第一輪執行即回報 `SOURCE_COMPILER_HOLD`，正式 Effectful Compiler 未通過。
4. **10 月 27 日 02:47**，OWNER 首次明確要求停止使用 Commander-SP、降低過度治理，且指出 Commander-SP 本身也是待開發／待修復的 SBL 部件。
5. r5～r10 已不再使用 Commander-SP，但仍持續存在 HGK Trust／Receiver、Native Issuer、Hermes 真 Executor、Fabric／模型驗收及續航問題。

這組事實支持兩個同時成立的結論：

**第一，Commander-SP 確實參與了最初產生阻斷型施工 Prompt 的指揮流程。第二，移除 Commander-SP 並沒有讓 B1 自動完成，因此它不是全部問題的唯一根因。**

尤其值得注意的是，既有《B1施工狀況\_總鑑定分析》已記錄前輪 GPT-6 的自我修正：過度強調原生簽章，未充分區分 OWNER 已授權施工與現役系統如何把授權轉換為可執行操作。該分析也明確指出 Commander-SP 假定 Frozen PI/PD 已存在，不適合擔任整個 Bootstrap Mission 的唯一入口。fileciteturn0file6L1105-L1132 fileciteturn0file6L1179-L1213

### 1.2 本次鑑定限制

遵照要求，**本次沒有掛載、啟動或調用 `$sbl-commander-sp`**。

分析依據是先前施工指揮紀錄中已保存的 Skill 描述、GPT-6 使用記錄、所產生的 Prompt、Codex／Hermes 回報，以及 SBL／PIPD／B1 的上位契約。

因此，本報告能判定其**已呈現的治理行為、接口設計風險及對 B1 的影響**；但不能把尚未取得的完整外掛原始碼、內部測試或未記錄的執行邏輯當成已直接審查的事實。

此處會明確區分「外掛規則本身的缺陷」、「GPT-6 的錯誤使用」與「上位系統另外造成的阻斷」。

---

## 二、`$sbl-commander-sp` 原始設計定位與 B1 實際使用方式

### 2.1 原始設計定位

對照 SBL DOC-01、DOC-03、DOC-04、DOC-07、DOC-10，可以確定 Commander-SP 在 SBL 產品架構中有明確的職責邊界。

其正常角色是：

**接受已形成、具來源和權限約束的施工契約，輸出有界施工指示或 WorkOrder 候選。**

它並不應成為：

- 所有專案工程的最高決策者；
- PIPD 的第二個 PI／PD／ECP 編譯器；
- HGK 的第二個 Issuer；
- Hermes 的 Durable Scheduler；
- 獨立 Checker；
- 人類 OWNER 的授權替代者；
- 整個 Bootstrap Mission 的啟動及停止控制器。

SBL DOC-03 特別明確：Commander-SP 只在已有受准入 ECP／WorkOrder 後編譯薄 Prompt，不負責修改 Repository。fileciteturn0file21L115-L128

SBL DOC-01 亦定義三個獨立 SP：

| SP | 正確責任 | 不能替代 |
|--------|--------|--------|
| TPM-SP | Goal、需求澄清、Spec、PI 候選 | PIPD Canonical Writer |
| Commander-SP | 受限 WorkOrder／施工指揮投影 | Hermes Executor／HGK Issuer |
| External Challenge-SP | 凍結主體的唯讀反證、驗收挑戰 | 真 Native Checker／Human Acceptance |

因此，原始三 SP 分工並不錯誤。

真正問題是 Commander-SP 的設計假設非常明確：**它通常消費已有的契約，而不是負責修復產生契約的基礎設施。**

### 2.2 B1 的工作性質完全不同

B1 Bootstrap Repair 需要修復的，正是以下上游能力：

- PIPD SourceFreeze、PI／PD／ECP；
- HGK Native Issuer、Trust、Receiver；
- Hermes Queue／Executor／自主續航；
- Fabric Policy Loaded；
- Checker 分權與驗收；
- SBL Proposal 真入口。

因此，B1 並非一項「所有前置條件已準備完成，等待 Commander 施工」的普通任務。

它是一項 **控制系統自舉修復任務（Control-Plane Bootstrap Repair）**。

這種任務必須允許合法的診斷、隔離修補、工程候選與回歸測試，先行建立尚不存在的控制能力。

若強制使用一般 Commander-SP 的 Frozen PI／PD 前置模式，就會出現以下矛盾：

### B1 Bootstrap 的循環依賴

B1 任務：修復 PI／PD／Issuer／Receiver

Commander-SP：必須先有符合條件的 PI／PD／ECP

前置系統尚待修復，正式施工卻被禁止開始

要求 OWNER 提供尚未建立的正式發行工件

再次回到相同阻斷

此圖是由文件前置條件重建的控制流程失效，不表示 Commander-SP 程式本身已被證明執行了該循環。

### 2.3 最重要的適用性裁決

| 任務類型 | Commander-SP 適用性 |
|--------|--------|
| 已凍結 PI／PD 的有界施工提示 | 適合其設計定位 |
| 已有合法 ECP 的 WorkOrder 施工投影 | 適合，但不得取代 Issuer |
| 一般需求或 Spec 草案 | 應優先由 TPM-SP 處理 |
| HGK Issuer 尚不存在時的 Bootstrap | 不適合作為唯一入口 |
| 大規模跨系統自行排錯與修補 | 不適合作為總調度器 |
| 跨程序持久續航與自動恢復 | 不具已證實的 Runtime 控制能力 |
| 正式 Independent Acceptance | 不能自行簽發 |
| 單人 OWNER 長期授權管理 | 需要外部有效政策／授權服務 |

**工程結論：Commander-SP 不是沒有價值，而是它原本的作用域比本次 GPT-6 指派給它的任務小得多。**

---

## 三、最初指揮 Prompt 如何放大 Commander-SP 的治理要求

### 3.1 第一個問題：輔助方法被提升為全域施工準則

最初 B1 指揮方案把 Commander-SP、Knowledge Pack 和 Prompt Compiler 列為輔助方法。

但實際 r1 Codex Master Mission Prompt 進一步要求：

- 全量來源掃描；
- C0～C9 指揮契約；
- Prompt Compiler 的 lint、activation、acceptance、compile；
- SourceFreeze、TaskKind、Oracle 的正式綁定；
- 完整 Native Gate；
- 全部 B1 驗收分母；
- 最終 G-A／GWO／G-B。

其中有些確實屬於正式交付的必要條件。

問題是，**最初指揮沒有足夠清楚地將這些要求分成「施工前必備」「施工中逐步建立」「最終驗收才需要」三種時間層級。**

SBL DOC-04 已明確指出 C0～C9 是 Contract Domains，並不是十個必須依序完成、才可開始一切施工的 Pipeline Stages。fileciteturn0file22L551-L589

這意味著真正的問題不只是 Commander-SP 本身嚴格。

還包括 GPT-6 將 Commander-SP、Prompt Compiler 與 B1 Native Acceptance 的約束組合後，產生了一份對 Bootstrap 不夠適用的施工契約。

### 3.2 第二個問題：未來產物被要求在啟動前存在

《B1施工狀況\_總鑑定分析》記錄了針對原始 `C0_C9_CONTRACT.json` 和 `compiler-report.json` 的直接檢查。

其中三個重要發現：

| 契約建模問題 | 真正後果 | 應負主要責任 |
|--------|--------|--------|
| 尚待建立的 Native Admission／TaskKind 被列為已存在的必要來源 | `PL-003 × 2` | Master Prompt／Contract Builder |
| Oracle 衝突被直接標成同階權威衝突 | `PL-004 × 1` | Authority Classification |
| 多個 Runtime 的 identify／discover 階段被標為 `BLOCKED_EXTERNAL` | 修復入口被提前關閉 | Dependency Scope |

更加嚴重的是，當輪產生的 Master Mission Prompt 自身曾被放進 `NORMATIVE` 來源集合。

這代表一份本應只作執行投影的指揮文件，被錯誤提升為規範性權威。

**這是可定位的指揮契約設計錯誤，而不是缺少人類 OWNER 再次同意。**

必須注意：目前較有力的直接證據指向 Contract Builder 和錯誤的前置條件分類，不是 Commander-SP 內部程式直接產生了三筆 Compiler 錯誤。fileciteturn0file6L1274-L1308

### 3.3 第三個問題：完整覆蓋義務被混入當輪排程

最初 Prompt 以 `27／31／120／124／38／949／192／81` 維護完整 B1 分母，這有避免遺漏的正面價值。

但如果把完整覆蓋清冊和可立即執行的工作清單當成同一種資料，就會導致：

- 尚未觸發的 Conditional 被當成必須執行；
- Deferred 身份被當成即時施工負擔；
- 設計驗收項目被當成已存在的 Runtime Runner；
- 正式驗收缺口被視為普通修補不可啟動的理由。

這不是 Commander-SP 單獨造成的。

不過，由於 Commander-SP 偏向以完整契約與驗收條件產生施工指揮，**當上位輸入沒有進行適用性分級時，容易放大這種治理負擔。**

### 3.4 第四個問題：Prompt 產生成功，卻沒有真正的自治續航機制

從歷次 Prompt 可看到一個值得關注的事實：

| 指揮版本 | 原始位元組大小 | 主體特徵 |
|--------|--------|--------|
| r1 | 42,507 | 完整 Master Mission |
| r2 | 36,017 | 完整續工及來源解鎖 |
| r3 | 36,096 | 連續續工及正式 Gate |
| r4 | 36,603 | Native Issuance 修復 |
| r5 | 12,679 | 降治理薄指揮 |
| r6 | 15,233 | Native 驗收薄指揮 |
| r7 | 13,147 | Hermes 自治施工 |
| r8 | 15,925 | 單一 OWNER |
| r9 | 16,960 | 自治結案 |
| r10 | 16,413 | User-scoped Native 自治 |

檔案變短確實代表指揮文字收斂，但不代表系統已具備完整高自動化能力。

r10 在要求持續施工的情況下，仍有 R3、R4 和真 Hermes Executor 未執行，並發生提前交付。

因此，即使完全不用 Commander-SP，只把大型 Prompt 換成薄 Prompt，也不足以形成真正的自治執行。

**這是對 Commander-SP 類型工具的功能上限判定：Prompt 編譯器不是 Durable Runtime Controller。**

---

## 四、Commander-SP 的內部設計矛盾與跨文件契約衝突

這是本次最重要的專項審查部分。

以下區分兩種情況：

- **已確認的跨文件衝突**：不同來源對 Commander 職責或入口提出不一致要求。
- **需要進一步驗證的內部風險**：現有描述呈現設計張力，但尚未直接取得當前完整外掛實作來證明程式級缺陷。

### 4.1 IC-01：Builder Principal 與 Read-only Commander 的角色矛盾

(P0｜高優先衝突)

既有 Commander-SP Skill 的歷史讀取紀錄使用了 `build principal` 的定位，要求它消費 Frozen PI／PD，產生施工成果或候選，並避免自我驗收。

但 SBL DOC-01／03／04／07 的產品設計，則把 Commander-SP 明確限制為只讀指揮與薄 Prompt 投影，不能直接修改 Repository。

這產生兩種不同角色語義：

| 角色模型 | 代表的權限 |
|--------|--------|
| Builder／Maker | 可能具有實際工程修補能力 |
| Commander／Prompt Planner | 只有指揮契約產生及工作提案能力 |

若同一外掛同時聲稱擁有這兩類職責，但沒有明確分離工作模式，使用者就很難知道它究竟是執行者、指揮者還是契約編譯器。

**裁決：這是實質的角色契約衝突。**

應以現行上位 SBL 設計為準，要求 Commander-SP 不具有直接 Repository Mutation 或 Native Effect 權限。

如果仍要保留 Builder 功能，必須作為另一個明確的受權 Worker 能力，而不是讓 Commander-SP 以文字角色自動升格。

### 4.2 IC-02：Commander 需要 ECP／WorkOrder，卻又被要求先提出 WorkOrder

(P0｜高優先衝突)

SBL DOC-03 規定 Commander-SP 在已有受准入 ECP／WorkOrder 後才產生薄 Prompt。

但 B1 DOC-08 的 GWO-HGK 設計要求：

1. SBL Commander 提出 WorkOrder 候選；
2. HGK Issuer 再正式簽發；
3. Hermes Queue 接受並執行。

兩者在「WorkOrder 產生前後」的入口要求不同。

若 DOC-08 的 SBL Commander 指的是同一個嚴格要求先有 ECP／WorkOrder 的外掛，就會發生循環。

必須特別指出：**目前不能僅因 DOC-08 寫了 `SBL Commander`，就證明 `plan.propose` 必然只能由 `$sbl-commander-sp` 這個外掛提供。**

可能存在獨立 SBL Proposal API，但現有交接資料尚未證明其實際可用。

所以需要區分：

- `Proposal Draft`：尚未簽發，只是合法提案；
- `Admitted WorkOrder`：已由 HGK Issuer 接納；
- `Execution Prompt`：消費正式工作卡後的執行投影。

**裁決：應明確拆分這三個 ABI，解除 GWO-HGK 的雞生蛋依賴。**

### 4.3 IC-03：`HOST_PENDING` 的工具卻被用作全域指揮依據

早期 GPT-6 紀錄稱 Commander-SP Skill 的 `claim_ceiling` 為 `HOST_PENDING`。

這本身不等於工具不可閱讀或不可參考。

但它代表沒有足夠證據將其直接升格為本地 Codex／Hermes 的已資格化 Runtime 控制能力。

最初指揮同時存在兩種行為：

- 正確宣稱 Commander-SP 只是輔助規範，不冒稱 Host Native 完成。
- 又將其規則及產生的施工契約套用到整個 B1 高自動化 Mission。

**風險在於：工具資格尚未完成，但其治理語義已經主導正式執行流程。**

這應被禁止。

未完成 Host Qualification 的工具可以提供設計參考，不得自動成為全域 Runtime Admission Gate。

### 4.4 IC-04：Commander／Prompt Compiler 權責可能重疊

SBL 原設計明確要求 PIPD 唯一 Canonical Writer，而 Commander 只產出薄指揮。

但歷史使用流程中，Commander-SP、Knowledge Pack 與 `construction-acceptance-prompt-compiler` 同時參與建立完整指揮契約。

如果兩者都可以各自解釋權威、來源、變更作用域及驗收要求，就容易形成兩套實際上的契約判斷：

- Commander 的自然語言判斷；
- Compiler 的機器規則與拒收。

這不代表二者必然有重複程式碼。

但如果沒有唯一 Machine Contract 作為 SSOT，就可能發生「自然語言認為可以繼續、正式 Compiler 卻因不同分類拒收」。

**裁決：Commander 只能消費既有 Canonical Contract，不應重新判定具有正式效力的 SourceFreeze、ECP 或 Native Admission。**

### 4.5 IC-05：C0～C9 與施工階段的語義混淆

SBL DOC-04 對 C0～C9 曾存在不同命名／映射，後續 r4 已對其進行更正。

該文件也明確把 Contract Domains 與 Pipeline Stages 分離。

這證明 SBL 設計體系曾經存在實質的契約映射漂移。

若 Commander-SP 消費舊映射，再要求 Codex 依其生成正式指揮，就可能把來源、權威或 Runtime Readiness 套錯欄位。

**這是版本與 Schema 漂移風險，不是目前已證實的外掛程式 Bug。**

必要修復是固定 Schema Version，禁止以同名欄位或舊 C2／C5／C6 意義進行靜默相容。

### 4.6 IC-06：獨立 Checker 被誤認為多位人類審批

歷史 Skill 描述要求 Challenge Principal，且提及人類參與正式接受決定。

這項分權要求本身有工程價值。

但若被解讀為：

- 每一張工程修補卡都需要人類批准；
- 每一輪隔離測試都需要第二位人類簽核；
- 單一 OWNER 無法擔任產品 Owner；
- 每次續工都需重新簽署整套文件；

就會造成不必要的高自動化阻斷。

**正確設計是單一人類 OWNER＋具備可驗證能力的不同機器 Principal。**

其中必須維持：

- Signer 的真實金鑰控制；
- Checker 的真實獨立性；
- 必要 Host 權限；
- 真正有風險時的 Human Veto。

不能把這四項一律轉成「再找另一個人類」。

### 4.7 IC-07：沒有證實具備真正的 Runtime 自治控制功能

現有 Commander-SP 的設計主要圍繞：

`Input Contract → WorkOrder／Thin Prompt → Bounded Execution Request → Evidence`

未找到其已實現以下全部功能的正式證據：

`Durable Queue、Lease CAS、Worker Restart、Autonomous Wakeup、Fair Scheduling、World Effect Reconciliation、Termination Controller`。

因此，不應將它視為 Hermes 的替代排程系統。

**若讓 GPT-6 依賴 Commander-SP 產生更多續工 Prompt，並期待它因此獲得跨 Session 自治能力，屬於工具能力分類錯誤。**

---

## 五、治理過度風險完整矩陣

以下嚴重度評估的是「在 B1 Bootstrap 作為全域指揮時的風險」，不是宣稱所有問題都存在於當前外掛原始碼。

| 編號 | 風險 | 造成的工程後果 | 等級 |
|--------|--------|--------|--------|
| CG-01 | Frozen PI／PD 全域前置 | 尚待修復的 Compiler 反而阻擋修復 | P0 |
| CG-02 | Bootstrap 與 Native Effect 不分層 | 合法診斷、隔離施工遭不當 HOLD | P0 |
| CG-03 | OWNER 任務授權未轉成操作能力 | 重複索要已表達的工程授權 | P0 |
| CG-04 | Commander 被提升為總控制器 | 權責越界、第二指揮權威風險 | P0 |
| CG-05 | Proposal 與 Issued WO 混淆 | GWO-HGK 啟動循環依賴 | P0 |
| CG-06 | Skill 缺少有效 Host Qualification | 設計候選冒充可用工具 | P1 |
| CG-07 | C0～C9 Schema 語義漂移 | Compiler Contract 拒收或誤路由 | P1 |
| CG-08 | Prompt 被當作 Normative 來源 | 自我授權、權威污染 | P0 |
| CG-09 | 全量來源與分母當輪重算 | Token、時間、上下文成本升高 | P1 |
| CG-10 | 全域 Fail-closed | 單一卡受阻造成獨立任務飢餓 | P0 |
| CG-11 | Checker 和 Human Approval 混用 | 假性多人簽核需求 | P1 |
| CG-12 | Design／Runtime／Acceptance 混用 | 候選修補被誤認無權開始 | P0 |
| CG-13 | 不具 Durable Scheduler | Session 結束後無法真正續行 | P0 |
| CG-14 | 多工具重複解析權威 | Commander／CAPC／PIPD 多重裁決 | P1 |
| CG-15 | 舊 Prompt 累積成隱含規範 | 已撤銷要求仍繼續影響施工 | P1 |
| CG-16 | 過度收斂為完整正式驗收 | 每次工作卡均背負最終 Gate | P1 |
| CG-17 | 角色名稱代替真實 Principal | Checker／Signer 安全保證錯誤 | P0 |
| CG-18 | 工具無法使用時缺替代入口 | 高自動化被單一產品依賴鎖死 | P0 |

### 5.1 最嚴重的不是規則數量，而是規則的作用域

即使治理只有十條，如果每條都被設為全部施工的硬前置條件，也可能造成嚴重阻斷。

反過來，即使系統有數百條驗收規則，只要能根據具體工作卡自動判斷適用性，也不一定妨礙高自動化。

因此，評估 Commander-SP 是否治理過重，不應只統計 Prompt 字數或驗收欄位數量。

應檢查：

**有多少規則被不必要地套用到沒有相應風險或依賴的工作。**

這才是真正的治理過載指標。

### 5.2 必須保留的治理原則

以下不應因 Commander-SP 存在適配問題而刪除：

- Root／HEAD／WriteSet 與真實操作作用域；
- Native Permit-before-effect；
- Maker／Checker 分權；
- Raw Evidence 和世界效果讀回；
- Effect At-most-once 與未知效果 Reconciliation；
- 不冒稱 Native PASS；
- 受影的 Rollback／Compensation；
- Security／Secret／User Data 防護。

這些原則符合 B1 上位契約。

真正需要刪除或改變的，是**不適用的前置綁定與重複人工批准流程**。

---

## 六、Commander-SP 是否不適合單人 OWNER？

### 6.1 工程裁決

**就原始 SBL 產品架構而言，不能判定 Commander-SP 天生不適合單人 OWNER。**

但就本次 Bootstrap 的實際使用方式而言，它確實展現出不利於單人 OWNER 高自動化施工的治理模式。

問題並不是只有一位人類。

問題是歷史指揮把不同種類的授權混合處理。

### 6.2 必須區分三層授權

| 層級 | 本次 B1 的正確處置 |
|--------|--------|
| Mission Authorization | OWNER 已明確授權本次有界修復任務，不應反覆重新詢問 |
| Operation Authorization | 按 Repo、OS、EffectClass、Policy、Token 取得實際可執行權限 |
| Acceptance Authority | 由具真正獨立能力的 Checker 和適用 Owner／Release Authority 決定 |

例如：

OWNER 已授權修補 HGK 的 Python 程式，且 Executor 具有該工作區的實際寫入權限，這不應因為尚未完成 G-A 而自動禁止普通修補。

但如果工作要求修改受保護 Windows 服務的 Trust Anchor，就仍然需要適用 OS 權限和合法信任程序。

同樣地，OWNER 授權自動驗收，不表示 Maker 可以自己簽署獨立 Checker Verdict。

### 6.3 適合單一 OWNER 的最小授權模型

建議保留一個由 OWNER 正式批准且具有版本、作用域、期限與撤銷機制的 Standing Policy，讓現役執行服務依其權限自動進行必要操作。

授權策略必須支持：

- 普通唯讀診斷自動進行；
- 已核准 Repo 的有界修補自動進行；
- 隔離測試與回歸自動進行；
- 真正受保護效果由已有權的 Native Issuer 簽發；
- 自動 Checker 在有效獨立信任邊界下執行；
- 超出原授權範圍、需要新使用者同意或高風險不可逆變更時才升級請求。

這樣仍只有一位人類 OWNER，不需要虛構第二個人類治理職位。

但機器權限不因此集中到單一不受限制的 AI Principal。

**Commander-SP 必須適應這種架構，而不是要求架構遷就其預設人工驗收流程。**

---

## 七、對 B1 全部失效的因果責任重新分配

### 7.1 不能使用「停工發生在掛載之後」作為充分證據

最初使用 Commander-SP 與後續發生停工，在時間順序上確實相連。

但不能因此直接宣稱：

> Commander-SP 程式造成所有 B1 故障。

較嚴謹的因果鏈是：

**A. 原始任務**：OWNER 要求高自動化 Bootstrap Repair

**B. 工具使用**：GPT-6 採用 Commander-SP／KP／CAPC

**C. 指揮建模**：完整 Frozen Contract／Formal Gate 被前置到 Mission

**D. 具體拒收**：C0–C9 Contract 將缺失的未來權威工件設成必要輸入

**E. 故障結果**：`PL-003／PL-004`、Effectful Compiler HOLD、反覆續工

在這條鏈中：

- A 是 OWNER 明確提出的任務。
- B 是已記錄的工具採用事實。
- C 是 Commander-SP 作用域錯置和 GPT-6 建模共同產生的結果。
- D 是實際可定位的契約建模錯誤。
- E 是 Compiler 真實拒收及任務未完成。

因此，**Commander-SP 參與了導致阻斷的指揮形成過程，但直接造成 Compiler 拒收的是其下游不正確的契約輸入。**

### 7.2 停用 Commander-SP 後，哪些問題仍然存在？

這是一項重要的反事實檢驗。

r5～r10 已明確禁止 Commander-SP，但 B1 沒有因此全部完成。

| 問題 | 停用 Commander-SP 後 | 代表的意義 |
|--------|--------|--------|
| 普通候選工程修補 | 持續產生部分成果 | 不依賴 Commander-SP 才能修補 |
| HGK User Trust | 出現局部實作與測試成果 | 原先全域前置有收斂空間 |
| Trust → Receiver | 仍未閉合 | 是 Native 整合缺口 |
| Hermes 真 Executor | 仍未取得正式閉環證據 | 屬 Runtime 問題 |
| Fabric R3 | r10 NOT\_RUN | 不可歸咎外掛直接造成測試失敗 |
| Model R4 | r10 NOT\_RUN | 仍需現役模型路由實測 |
| G-A／GWO／G-B | 未完成 | 涉及多個必要子系統 |
| 過早封存／結案 | r10 仍出現 | 缺少機械化 Terminal Controller |

這表明停用 Commander-SP 有利於解除不必要的指揮依賴，但無法代替工程實作。

### 7.3 根因歸屬裁決

| 失效領域 | Commander-SP 關聯程度 | 更直接的根因 |
|--------|--------|--------|
| 前期施工 Prompt 治理過重 | 高 | 工具作用域錯置、GPT-6 權威與階段建模 |
| `PL-003／PL-004` | 間接 | C0–C9 Contract 的來源與衝突分類 |
| 反覆索要普通工程授權 | 高風險促成因素 | Mission／Operation 授權未分離 |
| Bootstrap 循環依賴 | 高 | Frozen PI/PD 前置與待修系統互相依賴 |
| 單一 OWNER 適配困難 | 中至高 | 人類 OWNER 與機器 Principal 混淆 |
| Hermes 長期自動續工失敗 | 低至間接 | Durable Executor／Wakeup／Stop Controller 缺口 |
| HGK Native Receiver 未接線 | 無已證直接因果 | 實際 Trust／Receiver 整合 |
| Fabric／Model 未驗收 | 無已證直接因果 | 原生執行與證據尚未閉合 |
| GWO-HGK Proposal 入口 | 高 | SBL Commander 契約與 B1 DOC-08 前置衝突 |
| PIPD CI WriteSet 失敗 | 無已證直接因果 | Stage-C 具體變更集拒收 |

**這比將 B1 的全部施工問題歸咎於 Commander-SP，更符合目前可支持的工程證據。**

---

## 八、對 Commander-SP 本身應採取的完整修正方案

由於本輪明確禁止掛載，以下是後續產品修復所需的設計與驗收要求，不是本次已施作的修改。

### 8.1 改善產品責任邊界

Commander-SP 應只具備三類明確能力：

| 能力 | 輸入 | 輸出 | 權限 |
|--------|--------|--------|--------|
| `inspect` | Source／Contract／Capability | Scope／FirstFail／Gap Report | Read-only |
| `propose` | Goal／Source／Effect Intent | Candidate WorkOrder／Proposal | 不簽發 Permit |
| `render` | Admitted WO／ECP／Scope | Thin Execution Prompt | 不自行執行效果 |

這是建議的產品接口分層，不是聲稱現役外掛已具有這三個 API。

正式的 WorkOrder 發行與實際執行，應仍由 HGK／Hermes 負責。

### 8.2 新增 Bootstrap 適用性檢查，而不是直接放寬安全限制

Commander-SP 必須能判斷工作是否已準備進入正式有界施工。

若上游契約尚未存在，應返回具體的適用性結果：

`UPSTREAM_CONTRACT_NOT_READY`

並指出受影的缺失與可行的合法修復入口。

不應把缺少 Frozen PI／PD 自動解釋為「整個 Mission 不准診斷、不准修補、不准準備候選」。

這能保留 Commander-SP 的安全設計，同時避免它阻斷外部 Bootstrap Controller 的合法操作。

### 8.3 移除人類簽核與工程審查的錯誤耦合

需要將：

`Human Decision`、`Machine Authorization`、`Independent Verification`、`Product Release`

拆成不同權限事件。

其中低風險、既有授權、可逆的工作應由有效 Standing Policy 進行機器化准入。

Commander-SP 不應對每張工作卡要求新的人類簽署，除非目前有效的上位規則確實如此要求。

### 8.4 將治理規則編譯成適用性矩陣

建議以 EffectClass 和實際執行階段作為適用性輸入。

| 執行階段 | 來源核對 | Repo WriteSet | Native Issuer | Independent Checker |
|--------|--------|--------|--------|--------|
| 唯讀診斷 | 需要適用來源／範圍 | 不需要寫入權 | 不需要效果 Permit | 正式驗收時才需要 |
| 隔離工程修補 | 需要 | 需要 | 視實際效果，不一律需要 | 可先自動測試，正式驗收另行執行 |
| Host／Policy 效果 | 需要 | 視情況 | 必須有有效權限與准入 | 正式 Native 驗收需要 |
| User Data Effect | 需要 | 視情況 | 依 User Scope 和原生政策 | 必須依正式受影驗收 |
| 正式 Release | 需要正式版本 | 需要可追溯變更 | 適用的效果必須通過 | 必須完成必要獨立驗收 |

**讓工具先判斷規則是否適用，再決定是否拒收，而不是把全部規則預設套到全部任務。**

### 8.5 禁止 Prompt 自我升格為權威

Commander-SP 產出的所有工件必須固定：

`artifact_kind=INSTRUCTION_CANDIDATE`

或對應的正式非授權型別。

不得因 Markdown 標題含有 `MASTER`、`EXECUTABLE`、`FINAL`、`OWNER_APPROVED` 就把內容當成真正的 SourceFreeze、Permit 或原生授權。

正式 Source、Policy、Issuer、Compiler、Checker 權威必須保持各自原生來源。

### 8.6 不在 Commander-SP 內新增第二個 Scheduler

不應為了讓 Commander-SP 支援高自動化，而在其內部重新建立：

- 第二個 Durable WorkOrder State；
- 第二個 Hermes Scheduler；
- 第二個 HGK Issuer；
- 第二個 Policy Plane；
- 第二個 Claim Ledger 權威。

如果 Commander-SP 將來需要整合長任務，可以透過唯讀狀態及合法 Proposal 接口使用現有 HGK SharedSpine。

**它不應再擁有一份可獨立決定工作的平行狀態。**

---

## 九、Commander-SP 後續重新資格化的必要測試

建議在維持 B1 禁用的情況下，另行安排獨立的 Commander-SP 產品驗收。

| 測試 | 刺激條件 | 必須達成的結果 |
|--------|--------|--------|
| CS-01 | Frozen PI／PD 完整 | 產生有界薄指揮，不產生 Permit |
| CS-02 | Frozen PI／PD 缺失 | 返回受影缺口，不宣告整個 B1 Mission 禁止進行普通診斷 |
| CS-03 | 僅有 OWNER Mission Authorization | 正確認知工程任務已授權，但不冒稱已有 Host Permit |
| CS-04 | 低風險 Repo 工程已具有效授權 | 不額外要求無來源依據的人類重複批准 |
| CS-05 | 高風險 Native Effect 沒有有效准入 | 拒收受影效果，其他合法工作不被阻斷 |
| CS-06 | Maker 宣稱自己是 Checker | 拒收假獨立驗收 |
| CS-07 | 只有一位人類 OWNER | 支援不同機器 Principal，不強制要求第二位人類 |
| CS-08 | 尚未 Issued 的 Proposal | 可以作非授權候選，不假造已簽發 WorkOrder |
| CS-09 | C0～C9 舊版 Schema | 明確版本拒收或合法轉譯，不靜默改義 |
| CS-10 | Skill `HOST_PENDING` | 不自稱已具 Native Host Qualification |
| CS-11 | Commander 無法使用 | 不阻斷外部合法 Bootstrap 流程 |
| CS-12 | 產生大型 Prompt | 驗證其實質必要欄位，避免重複投影完整治理文本 |
| CS-13 | Wrong Root／HEAD／WriteSet | 確實拒收受影施工 |
| CS-14 | 不同 EffectClass | 正確套用不同前置與權限 |
| CS-15 | B1 DOC-08 GWO-HGK | Proposal 和 Issued WorkOrder 的依賴不形成循環 |
| CS-16 | 跨 Session 長任務 | 不宣稱 Prompt 本身提供 Durable Runtime |
| CS-17 | Host 安裝與卸載 | 真載入、正反例、不當工具拒收、卸載後不再觸發 |
| CS-18 | 政策版本及工具版本變更 | 正確受影失效，不重跑所有無關需求 |

驗收前應由獨立產品審查確認目前外掛的實際 Skill、版本、相依工具、Host API 與授權模型；本輪的歷史描述只能作為回歸依據之一。

### 9.1 建議的通過標準

Commander-SP 重新取得「可在 B1 相關流程中使用」的資格，至少需要：

- 不再把 Frozen PI／PD 缺失誤當作整體 Bootstrap 禁令；
- 明確區分 Proposal、Admitted WorkOrder 和 Thin Prompt；
- 不會要求單一 OWNER 反覆批准已授權的例行工作；
- 不把 Checker／Signer／Publisher 混成 Commander 本身；
- 不建立第二個 Scheduler／Issuer；
- Host 的實際載入、觸發、非觸發及卸載已驗證；
- 與現役 PIPD／HGK／Hermes 的 ABI 有真實可核對的整合測試。

在此之前，**不建議重新把 Commander-SP 放入 B1 的執行依賴圖**。

---

## 十、B1 應如何在不使用 Commander-SP 的情況下完成

本次工程判定不建議完全捨棄 SBL 三 SP 產品設計。

建議將兩種不同目標分離：

**目標 A：恢復 B1 自治修復及正式 Native 接管。**

**目標 B：在 SBL 產品開發週期中，重新修復與資格化 Commander-SP。**

兩者不應互為無條件前置。

### 10.1 B1 主線

| 順序 | 主執行系統 | 所需工作 |
|--------|--------|--------|
| 1 | Hermes／Codex | 依現有有界 OWNER 授權，完成真 Runtime／Repo 現況探查 |
| 2 | Hermes／HGK | 打通唯一 Durable Queue 與真 Executor／自動恢復 |
| 3 | HGK | 完成 Trust／Receiver／Issuer |
| 4 | PIPD | 修補受影 Oracle、Profile、TQAEP、CI ABI |
| 5 | Fabric | 真 Stage／Active／Loaded／Consumer |
| 6 | Hermes | 真模型 Required／Served，修補受影 Routing |
| 7 | SBL | 使用合法、經證實的非 Commander Proposal 入口 |
| 8 | HGK／Hermes | T2、R1～R4、G-A、三 GWO |
| 9 | HGK／Hermes／Checker | 外援撤銷、G-B、自主續行與獨立驗收 |
| 10 | SBL 產品工程 | Commander-SP 獨立修復、測試及資格化 |

這裡的順序是主要依賴次序；彼此獨立且已具合法條件的工作仍應並行，不需全部串成單一長鏈。

### 10.2 DOC-08 的修正方向

DOC-08 的 GWO-HGK 不應因 Commander-SP 禁用就刪除。

正確的最小修正是：

將「SBL Commander 先提出 WorkOrder 候選」釐清成經版本化核准的 **SBL Proposal Interface**，並證明它不依賴未修復的 Commander-SP 外掛。

如果該接口目前不存在，就需要實作最小受治理 Proposal Adapter。

該 Adapter 只能提出候選，不得自行發行 Native Permit。

HGK 仍是唯一 Issuer，Hermes 仍是 Executor。

這種處置既能解除 Commander-SP 的單點依賴，也保留 B1 原有 GWO-HGK 的正式責任。

### 10.3 不應把禁用擴張成否定所有 SBL Commander 需求

SBL 原有產品設計保留 TPM-SP、Commander-SP、External Challenge-SP 三個產品責任。

因此：

**暫時禁用一個未修復的外掛實作，不等於永久刪除 Commander-SP 這個產品功能。**

兩者應具有不同狀態：

| 對象 | 建議狀態 |
|--------|--------|
| B1 當前執行對 `$sbl-commander-sp` 的依賴 | `DISABLED / NOT_APPLICABLE` |
| SBL Commander-SP 原有產品需求 | `RETAINED` |
| 當前外掛是否符合其原始設計 | `REQUALIFICATION_REQUIRED` |
| 重新納入正式 Host 執行 | `HOLD_PENDING_INDEPENDENT_TEST` |

---

## 十一、最終根因排序

綜合前輪 B1 全域鑑定與本次 Commander-SP 專項審查，建議採以下優先順序。

| 優先序 | 根因 | 判定 |
|--------|--------|--------|
| 1 | 將 Commander-SP 的有界施工前置條件誤作全域 Bootstrap 前置 | **關鍵治理根因** |
| 2 | GPT-6／Contract Builder 將未來 Native 工件設定為已有必要來源 | **初期 Compiler 直接阻斷** |
| 3 | 未區分 Mission Authorization、Operation Authorization、Acceptance | **反覆授權問題的核心原因** |
| 4 | DOC-08 提案流程和 Commander 前置要求存在循環／接口衝突 | **關鍵跨文件根因** |
| 5 | C0～C9、B1 Gate、完整產品覆蓋被不恰當地耦合 | **治理放大因素** |
| 6 | 未形成按 EffectClass、適用性及真依賴分級的 Runtime 排程 | **高自動化結構性根因** |
| 7 | Hermes 未完成真 Executor／Wakeup／Termination 自治閉環 | **後續反覆停工的直接工程缺口** |
| 8 | HGK、Fabric、PIPD、SBL 各 Native 接口仍有獨立缺口 | **正式驗收未完成原因** |

需要強調，這是基於目前證據的**工程優先次序**，不是以實測工時或故障貢獻率計算的百分比排序。

若要確認 Commander-SP 的獨立因果影響，還需要在相同 B1 來源版本、相同 Codex／Hermes 模型與 Host、相同授權範圍下，比較「掛載／不掛載」兩種指揮所生成的 Contract 和 WorkOrder DAG。

本輪沒有進行這項受控 A/B 實驗，因此不能提供可信的量化歸因比例。

---

## 十二、正式工程鑑定結論

### 12.1 對 `$sbl-commander-sp` 的總體評價

| 評估面向 | 最終鑑定 |
|--------|--------|
| 原始有界施工概念 | 合理 |
| Source／Scope／Evidence 安全原則 | 應保留 |
| 在現有 Frozen Contract 下產出薄 Prompt | 符合設計定位 |
| 在尚未建立 PI／PD／Issuer 時主控 Bootstrap | 不適合 |
| 作為整個 Hermes 高自動化總指揮 | 不適合 |
| 當作 Native Issuer／Checker | 不允許 |
| 人類授權與機器權限分層 | 有待改善的使用與整合缺口 |
| GWO-HGK Proposal 入口 | 存在重要契約衝突 |
| 與 CAPC／PIPD 的權責隔離 | 需要嚴格重驗 |
| 是否已證實為 `PL-003／PL-004` 程式級根因 | 否 |
| 是否為初期治理過重的重要促成因素 | 是 |
| 是否為後續全部 Hermes 故障的唯一根因 | 否 |
| 是否適合立即恢復 B1 使用 | 不建議 |

### 12.2 對前輪 GPT-6 指揮設計的責任判定

**前輪 GPT-6 對 Commander-SP 的選用與治理規則的投影，存在可確認的工程適配錯誤。**

其核心不是正確採用了必要安全原則，而是沒有充分判斷 Commander-SP 的前置條件是否適用於 B1 Bootstrap。

具體而言：

- 把下游有界施工 Skill 用於上游控制系統自舉；
- 對尚未建立的正式工件要求過早完成；
- 沒有把 OWNER 既有工程授權有效轉換成不同工作類型的可執行條件；
- 未充分區分正式驗收 Gate 和日常修補工作的准入；
- 產生了過度耦合的 Contract，造成可定位的 Compiler 拒收；
- 過度倚賴新 Prompt 解決需要 Runtime 程式實作的自治問題。

這些都不應歸咎於 OWNER 沒有給予足夠口頭授權。

但它們也不意味著 AI 應當擁有無限制的 OS、加密簽章或私人資料存取權限。

### 12.3 對 SBL Commander-SP 產品的最終工程裁決

正式建議狀態

## `COMMANDER_SP_BOOTSTRAP_INCOMPATIBLE / REQUALIFICATION_REQUIRED`

此為本報告提出的工程鑑定標籤，並非已寫入 Native Registry 的實際狀態。

---

**裁決：維持禁用，保留產品義務，獨立修復，不作 B1 Bootstrap 前置。**

Commander-SP 可以保留為 SBL 之後的有界指揮產品，但必須釐清 Builder／Planner 角色、Proposal／Issued WorkOrder 生命週期、單人 OWNER 授權及 Host Qualification，才能考慮重新納入正式自動化鏈路。

### 12.4 最終總結

本次鑑定的關鍵結論可以歸納為三個層次。

**第一，Commander-SP 的確與 B1 前期高自動化不順利有關。**

其 Frozen PI／PD、受限施工和獨立驗收模式被 GPT-6 過度套用，對原本需要先修復控制系統的 Bootstrap 工程形成不合適的前置依賴。

**第二，Commander-SP 有需要正式修訂與重新資格化的產品契約問題。**

特別是 Builder 與 Read-only Commander 的角色差異、Proposal 與 Admitted WorkOrder 的流程衝突、與 CAPC／PIPD 的權責重疊風險，以及單人 OWNER 授權的操作適配。

這些問題需要產品級治理修復，而不是只把 Prompt 寫得更短。

**第三，停用 Commander-SP 是必要的風險隔離，但不是 B1 全部問題的修復。**

後續 Hermes／HGK／Fabric／SBL／PIPD 仍必須完成真實 Runtime 接線、正式准入、持久執行、效果讀回與獨立驗收。

因此，最適合 FHS-MSC 的架構不是「由更強的 Commander 代理接管所有治理」，而是：

> **單一人類 OWNER 提供有界常設授權；PIPD 負責唯一 Canonical Contract；HGK 負責唯一 Native Issuer 與 Work Authority；Hermes 負責真正持久自治執行；Fabric 管理有效政策；SBL 提供合法產品與 Proposal 入口；獨立 Checker 驗證真實結果。Commander-SP 僅在其契約已具備且通過資格化時，擔任有限的指揮投影角色。**

這能最大程度保留原有架構、降低不必要治理阻力，同時避免以放寬安全准入換取表面上的高自動化。

**最終報告法位：`SOURCE-BASED ENGINEERING REVIEW / CROSS-CONTRACT CAUSAL ASSESSMENT / NO COMMANDER-SP INVOCATION / NO NATIVE ACCEPTANCE CLAIM`。**

本次僅進行靜態研究、歷史證據交叉比對與工程評估；未掛載 Commander-SP、未修改其程式或 SBL/B1 契約，亦未產生新的 Windows Host 或獨立驗收結果。

## Prompt:
2026/10/27 下午9:52:29

任務目標：
你必須整合前述分析規劃，再進行以下項目的專業工程「研究分析 + 交叉比對 + 鑑定評估」：
"
1) 是否要完整重構SBL-Commander-SP的設計，使其完全降格，把「指揮」改成「引導自動化」，只負責協助用戶「比對設計原意、進行最佳裁決建議、自動化排錯、依上游控制包進行適當的代位授權」，並且對其採用極輕治理，甚至把SKILLS-PLUGIN進一步收斂成單純薄「SKILL」就好，避免再度重演治理過重、造成自動化阻斷的問題，

2)並將SBL-Commander和前項SBL-Commander-SKILL進行完整區隔，SBL-Commander將負責在HERMES / FABRIC / HGK中進行「高效語意理解、PIPD控制包讀取、任務拆解、PLAN、子代理指派、自動化裁決」，並且SBL-Commander將使用獨立車道，並可依用戶指令選擇不同模型(默認/主選：GPT 6.1 SOL-MEDIUM (OPEN AI OAuth))、備援1/可選：DEEPSEEK V4.1 FLASH (OPENCODE GO)、備援2/可選：MiMo-V2.6-Flash  (OPENCODE GO)。

3)第2項的要求和相關規劃，是否在「SBL_PIPD-LS-PKG」、《FHS-MSC_藍圖_r2》、《FHS-MSC_總討論》已經有相關規劃?
"

任務要求：
你必須針對任務目標，並對全部相關資料進行「研究分析+交叉比對」，再進行鑑定、評估、規劃，並提出完整報告。

## Response:
2026/10/27 下午9:52:45 · gpt-6-thinking

我會先從 SBL DOC-00～13、FHS-MSC 藍圖與總討論抽出 Commander-SP、Commander、模型車道、HGK／Hermes／Fabric 權責的原始規劃，再對照 B1 失效紀錄。模型名稱與 OpenAI OAuth／OpenCode Go 的實際支援狀態會另外核查，不把設計願望當作已可用的路由。最後會提出是否重構、如何分離薄 Skill 與 Runtime Commander，以及不破壞原架構的完整方案。

已確認兩個會直接影響最終設計的既有規範：PIPD DOC-08 明確採「Prompt／AGENTS → 薄 Skill → 只有具體工具整合需求才用完整 Plugin」，而且要求同條件 A/B 驗證；SBL DOC-04 則已將 Commander-SP 寫成 `NO_WORKORDER_ISSUE`、只產生薄 Prompt 與 Native Handoff 候選。這使「外部薄 Skill、內部強 PLAN」有充分上位依據，但若取消舊 Plugin 交付義務，仍必須正式修訂產品身份，不能靜默刪除。

> **檢查本地研究來源與藍圖檔案**
>
>
> **檢查研究檔案並整理FHS藍圖與SBL摘錄**
>
> 
>
> **已搜尋 5 個網站**
>
> 
>
> **檢索 Commander 架構證據與引用**
>
>
> **檢索 Commander 架構證據與引用**
>
> 
>
> **彙整SBL、FHS與模型路由證據**
>
> 
>
> **整理完整 Lane 架構與驗收規範**
>
>
> **列印文件成熟度與來源引用段落**
>
>
> **完成報告規劃**
>
> 我正在補齊架構報告，會明確說明外掛如何降級為輕量 Skill、保留必要相容性，並區分模型隔離、資源預算、驗證方式與治理界線。
>
> **完成報告規劃**
>
> 
>
> **整理 Lane 架構、驗收規範與來源引用成熟度**
>
> 
>
> **完成第7至10節與來源對照表**
>
> 
>
> 處理時間為 7m 7s

# SBL Commander 架構重構與高自動化整合工程鑑定報告

鑑定日期：2026 年 10 月 27 日｜範圍：SBL DOC-00～13、FHS-MSC 藍圖 r2、FHS-MSC 總討論、B1 Bootstrap Repair 歷史與現行模型供應路由

## 一、總體工程裁決

**建議採納「薄型 SBL Commander Skill」與「內部 SBL Commander／PLAN」徹底分權的重構方案。**

但不建議把整個 SBL Commander 產品功能一併降格，也不建議推翻既有 SBL、HG-KSEOS、Fabric、Hermes 或 PIPD 架構。

最符合上位設計原意的方案是：

- **外部 SBL Commander Skill：** 極輕治理、唯讀引導、設計原意比對、工程建議、故障診斷輔助、受限授權建議，以及輸出可交由內部系統處理的任務提案。
- **內部 SBL Commander／PLAN：** 真正負責高效率語意理解、PIPD 契約消費、任務拆解、Task DAG、角色分工、子代理指派規劃、治理約束內的自動裁決及持續重新規劃。
- **HG-KSEOS：** 保有唯一正式 WorkOrder、Native Issuer、授權、工作狀態及驗收控制權。
- **Hermes：** 負責可靠的持久排程、Worker 執行、Checkpoint、跨程序恢復及不中斷的合法工作推進。
- **Fabric：** 維持薄政策治理、Policy Activation 和現役 Consumer Readback。
- **PIPD-LS-SP：** 維持唯一 Canonical 契約及正式 ExecutionAdmission 語義，不被 Skill 或 Commander 取代。

### 三項任務的直接判定

| 使用者提出的方案 | 工程裁決 | 與既有設計關係 |
|--------|--------|--------|
| 1\. 將 Commander-SP 降為極薄引導 Skill | **建議採納** | 符合 Commander 不應擁有 Native 控制權的原則，但屬實質產品修訂 |
| 2\. 將內部 Commander 獨立承擔 PLAN／協調／子代理任務，使用指定三模型 | **建議採納，需修正「獨立車道」定義** | 三執行車道、Commander／PLAN 及指定模型順序已有明確規劃 |
| 3\. 確認 SBL、FHS-MSC 是否已規劃 | **有，而且規劃相當具體** | 尚未全面落實，部分契約存在需要解決的衝突 |

**最重要的架構勘誤：不需要再新增第四條物理模型車道。** 應讓 SBL Commander 擔任既有 `PLAN` 車道的專屬主要角色，擁有隔離的任務、容量、模型政策與操作身份，但繼續使用 HGK 原有三執行車道架構。

這能避免再造第二套 Scheduler、第二套模型路由權威或第二套 WorkOrder 控制平面。

---

## 二、既有規劃是否已包含使用者要求的能力？

### 2.1 《FHS-MSC\_總討論》：已有明確、接近完整的三車道規劃

原始討論在 2026 年 10 月 25 日已明確提出：

| 執行車道 | 主要角色 | 原規劃主選模型 |
|--------|--------|--------|
| `PLAN` | Commander | GPT-6.1 Sol Medium，OpenAI OAuth |
| `EXECUTE` | Codex Bounded Writer | DeepSeek V4.1 Flash，OpenCode Go |
| `VERIFY_SECURITY` | Acceptance Challenge、Independent Checker | GPT-6.1 Sol Medium，OpenAI OAuth |

各車道也已指定 DeepSeek、MiMo 和 OpenAI 模型的備援次序。

在該文件的長任務工程鑑定中，更明確提出：

`session_model ≠ lane_model ≠ served_model ≠ credential_identity`

也就是互動會話、執行車道、真正提供服務的模型，以及使用者憑證，必須是四個不同的控制與證據概念。

這正是避免過往「會話模型已切換，PLAN 車道卻沒有真正改變」的必要規則。

### 2.2 《FHS-MSC\_藍圖\_r2》：已有完整三車道與 Commander 權責表

其既有設計為：

| 車道 | 角色 | 核心輸出 |
|--------|--------|--------|
| `PLAN` | Commander、TPM、FAR Analyst、System Architect、PIPD Reader | Task DAG、Thin Prompt、Repair Cone |
| `EXECUTE` | Codex Writer、Backend、Frontend、DevOps、Test Builder | 受限 Patch、測試及執行 Raw |
| `VERIFY_SECURITY` | Independent Checker、AO、QA、Security | Findings、Oracle Verdict、正式驗收證據 |

而且明文要求：

- PLAN 只能 Proposal／Replan，不簽發正式 Native WorkOrder。
- EXECUTE 必須遵守精確 WriteSet，不得自行驗收。
- VERIFY\_SECURITY 的 Checker 不得修改自己正在驗收的候選成果。

原藍圖還要求修正 Commander-SP Manifest 中 `product.write` 的權限語義，把 GPT／外部 Commander 的提案權限與合法本地 Builder 寫入權限分離。

因此，**Commander-SP 和內部執行者需要權限隔離，不是本次才提出的全新架構方向；上位文件已經包含相同的基本主張。**

### 2.3 《SBL\_PIPD-LS-PKG》：已有產品角色，但尚未完全形成這次要求的雙產品邊界

SBL DOC-04 的核心架構是：

`One Shared Core + TPM-SP + Commander-SP + External Challenge-SP + Six Logical Modules`

SBL DOC-10 進一步確認，Commander-SP 只產生有限指揮／施工請求，不應取得正式 Canonical Writer、Native Issuer 或 Independent Checker 身分。

但是，**現有文件對「外部可攜 Commander-SP」與「HGK／Hermes 內部 Commander／PLAN」的分界仍不夠一致。**

部分文字把 Commander-SP 描述為有界施工指揮；另一些部分又要求它提出 WorkOrder、進行 Planning，或保留 Builder 權限。

這正是 B1 曾經出現指揮治理過重的其中一項背景。

所以本次的最佳方案不是否定舊設計，而是將舊設計尚未徹底分離的兩種能力，正式確立為兩個產品責任不同的組件。

---

## 三、Commander Skill 是否應完整重構並降格？

### 3.1 裁決：完整重構職責與接口，但不要全面重寫技術基礎

**應該重構，而且幅度應達到產品責任重新定義的程度。**

不過，「完整重構」應指完整修正角色、權限、輸入、輸出、上下游接口及測試契約，而不是刪掉既有能力後從零重寫所有程式。

建議正式區分兩個產品：

|  | 外部 SBL Commander Skill | 內部 SBL Commander |
|--------|--------|--------|
| 建議產品身份 | `SBL-COMMANDER-GUIDE` | `SBL-COMMANDER-PLAN` |
| 角色 | 工程引導與決策輔助 | 自治規劃及任務協調 |
| 核心能力 | 比對、診斷、建議、提案 | 理解、規劃、拆解、指派、重新規劃 |
| 是否需要獨立模型車道 | 不需要 | 使用 HGK `PLAN` 車道 |
| 是否保存正式 WorkOrder | 否 | 否；消費 HGK 工作狀態 |
| 是否能正式簽發 Permit | 否 | 否 |
| 是否直接寫 Repository | 否 | 否，交由 EXECUTE |
| 是否需要操作金鑰 | 不需要 | 不能持有 HGK Issuer 私鑰 |
| 是否可進行自動裁決 | 建議性裁決 | 有界工作規劃裁決 |
| 是否可自動排錯 | 診斷建議、修復方案 | 指派診斷及修補 Worker，追蹤回歸 |
| 是否取代 Hermes | 否 | 否 |
| 是否適合單一 OWNER | 是 | 是，配合 Standing Authorization |

這些識別名稱是本報告的**建議新接口名稱**，不是現有已發布的 Native ABI。

### 3.2 為何薄 Skill 比完整 Plugin 更適合第一項目標？

對於僅負責工程輔助的 Commander 引導能力，完整 Plugin 帶來的功能不一定足以抵銷額外治理與維護成本。

| 面向 | 薄 Skill | 完整 Plugin |
|--------|--------|--------|
| 安裝與維護 | 較簡單 | 可能涉及 Manifest、Adapter、工具權限與 Host 發布 |
| 權限 | 可設計為只讀、無效果權限 | 容易因連接工具而擴張效果面 |
| 跨 Host 攜帶 | 容易採用可攜說明與 Schema | 依實際 Host 及 Plugin API |
| 模型路由 | 消費宿主現有模型 | 可能額外引入工具或 Provider 接線 |
| PIPD 整合 | 讀取既有契約與有效摘要 | 可深度接線，但資格化成本較高 |
| 自動排錯 | 形成分析及建議 | 可調用工具，但需要授權及安全驗證 |
| B1 故障重演風險 | 較容易控制 | 若沿用舊設計，可能重新引入強制 Gate |

**建議外部 Commander 的主交付形態降為純薄 Skill，完整 Plugin 不再是此功能的必要前置。**

但這不等於 SBL 全產品都應停止提供 Plugin 形態。若其他合法 Host 或使用者需求確實需要可執行 Plugin，應保留其產品義務及相應發行資格化，而不將它綁為 B1 Bootstrap 必須先完成的條件。

這樣既能降低工程複雜度，也符合 SBL 上位文件對完整產品分母不能靜默縮減的規則。

### 3.3 薄 Skill 的六項職責

建議重構後的薄 Skill 僅提供以下六類能力：

1. **設計原意比對（Design Intent Reconciliation）**：核對使用者目標、原有藍圖、現行 PIPD 控制包與工作範圍，指出實質差異。
2. **最佳工程裁決建議（Engineering Decision Advisory）**：對既有方案進行風險、成本、相容性、可逆性、復用價值比較，提出建議及確信度。
3. **自動化排錯引導（Diagnostic Guidance）**：識別 FirstFail、分析 Root Cause、提供最小 Repair Cone 和正反例測試建議。
4. **授權適用性整理（Authorization Applicability）**：識別現有 OWNER 授權可涵蓋的範圍，提出合法權限補足建議。
5. **施工需求提案（Execution Proposal）**：產生無效果權限的 Typed Proposal，交由內部 Commander／HGK 判定。
6. **驗收結果解讀（Evidence Interpretation）**：比對 Raw、驗收條件及 Claim Ceiling，提出是否應繼續或修補的建議。

其中「依上游控制包代位授權」必須作一項關鍵勘誤。

**薄 Skill 可以代替使用者進行已有規則下的工程判斷、適用性分類及授權建議，但不能自行創造原本不存在的法律、OS、HGK 或使用者資料操作權限。**

若已有明確委派且符合有效政策，薄 Skill 可以準備供正式授權系統處理的請求；真正的生效授權仍由既有權威負責。

### 3.4 極輕治理的最低安全規則

建議只保留六條強制規則：

- 不擴張使用者授權範圍。
- 不自行簽發 Native Permit。
- 不自行更改受治理 Repository 或 Host。
- 不把建議、候選或模型判斷冒充正式驗收。
- 不重新編譯或覆寫 PIPD Canonical Truth。
- 不把無關的 Native HOLD 擴張成整體任務停止。

其他來源清冊、技術矩陣、驗收 Fixture、方法 Registry 應按需引用上游文件，而不是完整複製進 Skill 內部。

SBL Commander Skill 的治理應以**正確的作用域與禁止越權**為重點，而不是以累積更多繁複審批文字作為品質指標。

### 3.5 新 Skill 不應再具有的能力

應明確取消其作為「外部引導工具」時的以下職責：

`product.write`、`native.issuer`、`policy.activate`、`workorder.issue`、`checker.accept`、`session.scheduler`、`model.provider.override`。

這些是建議禁止的能力類別，並不是宣稱目前 Plugin 具有全部同名 API。

可以保留 `read`、`compare`、`diagnose`、`recommend`、`propose`、`explain`、`evidence-review` 等非效果功能。

---

## 四、內部 SBL Commander 的架構定位

### 4.1 不應降格的是真正的內部 PLAN 能力

內部 SBL Commander 與外部薄 Skill 不同。

它應是一個真正具備工具整合、上下文管理、任務規劃及協同控制能力的 **PLAN 專家角色／服務**。

但仍應避免將它提升成 HGK 之外的第二個主權控制平面。

建議內部流程為：

人類 OWNER／SBL 使用者入口

Mission、偏好、已存在的合法授權

SBL Commander／PLAN

語意理解 → PIPD Reader → DAG → 子代理角色規劃 → 有界裁決

HG-KSEOS 唯一正式控制平面

Policy／Admission／Issuer／WorkOrder／State

Hermes Durable Dispatcher

Lease／Worker／Checkpoint／Resume／Fair Queue

EXECUTE

Codex、工具、受限子代理

VERIFY\_SECURITY

獨立驗證、反證、安全檢查

Raw Evidence／HGK 狀態更新／PLAN Replan

建議邏輯架構。Fabric 提供政策來源與有效狀態，PIPD 提供契約權威；不建立新的平行控制平面。

### 4.2 內部 Commander 的正式責任

| 能力 | 具體工程行為 | 決策界線 |
|--------|--------|--------|
| Semantic Understanding | 解析用戶目標、隱含限制與跨系統依賴 | 不改寫原始需求 |
| PIPD Consumption | 讀取 Source／PI／PD／ECP／TQAEP、版本及適用性 | 不自編 Canonical |
| Task Decomposition | 建立 DAG、Repair Cone、驗收對應 | 不縮減有效 Required |
| Planning | 規劃順序、並行範圍、資源預算 | 不直接執行效果 |
| Sub-agent Assignment | 選 Worker 類型、工具、隔離範圍 | 正式派工由 HGK／Hermes 執行 |
| Automated Adjudication | 在既有政策內選擇方案、重試、局部 PARK | 不超越 OWNER Policy |
| Failure Recovery Planning | 依 FirstFail 重新規劃與轉派 | 不盲重播 UNKNOWN\_EFFECT |
| Optimization | 降低重複讀取、閒置、人工往返及資源衝突 | 不跳過必要驗收 |

**內部 Commander 應負責作出高品質的執行規劃，而 HGK／Hermes 負責保證那些規劃只有在合法且可執行時才真正發生。**

這樣能保留「指揮」的實際工程價值，同時避免它取得過大的直接權限。

---

## 五、獨立 Commander 車道與模型路由完整方案

### 5.1 「獨立車道」應如何定義？

使用者提出的 Commander 專屬車道應該成立，但要區分**邏輯隔離**與**新增物理控制平面**。

建議採用：

`HGK.PLAN.SBL_COMMANDER`

作為內部 Commander 的專屬角色／工作池識別。

它具有自己的工作型別、模型政策、併發配額、優先序、Token 預算和執行紀錄，但隸屬既有 `PLAN` 執行車道。

不增加新的 `COMMANDER` 第四車道。

| 機制 | 是否獨立 | 建議方式 |
|--------|--------|--------|
| Commander 工作任務 | 是 | 獨立 Role／Workload Class |
| 模型主選與備援 | 是 | 專用 Role Model Policy |
| Session 模型 | 是 | 不影響 Lane 綁定 |
| Worker 配額 | 是 | 預留 PLAN 容量或限制併發 |
| 工作狀態真值 | 否 | HGK 唯一 WorkOrder State |
| Durable Dispatcher | 否 | 復用 Hermes |
| Native Issuer | 否 | HGK 唯一 Issuer |
| Policy Activation | 否 | Fabric／HGK 現役政策 |
| 正式驗收權威 | 否 | Independent Checker／AO |

這也符合《FHS-MSC\_藍圖\_r2》明確提出的 **Three Execution Lanes × Multi-Role Profile Team × One Native Control Plane**。fileciteturn0file24L305-L339

### 5.2 Commander／PLAN 的指定模型政策

使用者希望採用的模型順序，與《FHS-MSC\_總討論》原先的明確規劃一致。

建議 Commander／PLAN 模型路由

**主選：GPT-6.1 Sol**

OpenAI｜ChatGPT/Codex 獲授權登入路徑｜Medium

Model ID：`gpt-6.1-sol`

(Primary)

---

**備援 1：DeepSeek V4.1 Flash**

OpenCode Go｜模型切換需符合授權策略

`opencode-go/deepseek-v4.1-flash`

---

**備援 2：MiMo-V2.6-Flash**

OpenCode Go｜模型切換需符合授權策略

`opencode-go/mimo-v2.6-flash`

已查核截至本次審查的公開供應商文件：

- OpenAI 官方列出 `gpt-6.1-sol`，支援 `medium` 推理強度，適用於複雜技術任務及工作協調，實際可用性仍取決於帳號、客戶端及工作區。\[[Models](https://learn.chatgpt.com/docs/models?utm_source=chatgpt.com); [GPT-6.1 Sol Model](https://developers.openai.com/api/docs/models/gpt-6.1-sol?utm_source=chatgpt.com)\]
- OpenCode Go 官方列出 DeepSeek V4.1 Flash 與 MiMo-V2.6-Flash，也列出其 API Model IDs。\[[Go](https://docs.opencode.ai/docs/go/?utm_source=chatgpt.com)\]

這證明三個**指定模型具有公開產品／API 支援依據**，但不證明它們目前都已通過使用者 Windows Host 的獨立路由驗收。

### 5.3 不能只檢查模型名稱

模型路由至少需要記錄下列互相獨立的資料：

| 欄位 | 真正意義 |
|--------|--------|
| `role_id` | 本次是否由 SBL Commander／PLAN 執行 |
| `lane_id` | 真實的 HGK PLAN 車道 |
| `requested_model_id` | 用戶或政策要求的模型 |
| `served_model_id` | Provider 實際提供的模型 |
| `provider_id` | OpenAI 或 OpenCode Go |
| `transport_id` | 原生 Codex／合法 Relay／其他已准入 Adapter |
| `credential_route` | 實際使用的驗證路徑 |
| `reasoning_effort` | 實際送出的 Medium 或其他推理強度 |
| `policy_epoch` | 有效路由政策版本 |
| `fallback_authorization` | 是否允許切換至哪一個備援 |
| `worker_identity` | 真正執行的 Worker／Principal |
| `request_id` | 可核對的實際呼叫身份 |

注意 OpenCode Go 使用自己的 API Key 與 Provider Endpoint，不應將其說成 OpenAI OAuth 的另一個名稱。

OpenAI 的 ChatGPT/Codex 登入路徑、OpenAI API Key 路徑及 OpenCode Go API Key 路徑也不應共用憑證或被視為等價的權限。

**模型可用，不等於該模型在指定憑證與傳輸路徑已驗收通過。**

### 5.4 自動備援應保留，但絕不允許靜默替換

建議採用兩種明確模式：

| 模式 | 路由行為 |
|--------|--------|
| `PINNED` | 用戶明確選 GPT-6.1 Sol／DeepSeek／MiMo；必須由指定模型服務，否則拒收或按用戶明確設定的備援政策處理 |
| `AUTO_ADMITTED` | 從已核准候選中按順位、健康、能力與預算選擇；每次實際選擇和切換均記錄 |

若使用者指定 GPT-6.1 Sol，而路由沒有經過合法備援裁決就使用 MiMo，不得宣稱原指定模型成功。

這不是理論風險。FHS-MSC 總討論引用的 R17 S2-17 紀錄已出現「要求 DeepSeek V4.1 Flash，實際服務 MiMo」的情形。fileciteturn0file24L212-L216

建議正式執行：

`Resolve Policy → Pre-spawn Admission → Invoke → Served Identity Readback → Accept / Reject / Re-admit Fallback`

備援必須額外檢查功能相容性，例如 Structured Output、Tool Calling、Context Capacity、Reasoning Effort、成本上限、資料流向與實際 Host ABI。

模型不能僅因名稱出現在供應商清單，就自動被視為與 GPT-6.1 Sol 在 PLAN 能力上完全等價。

### 5.5 同時保留 EXECUTE／VERIFY 的既有模型政策

內部 Commander 重構時，不應連帶覆蓋其他兩條車道。

| 車道 | 主選 | 備援 1 | 備援 2 |
|--------|--------|--------|--------|
| PLAN | GPT-6.1 Sol Medium | DeepSeek V4.1 Flash | MiMo-V2.6-Flash |
| EXECUTE | DeepSeek V4.1 Flash | MiMo-V2.6-Flash | GPT-6 Luna |
| VERIFY\_SECURITY | GPT-6.1 Sol Medium | DeepSeek V4.1 Flash | MiMo-V2.6-Flash |

這是《FHS-MSC\_總討論》既有的目標模型矩陣，而非要求本輪已經安裝這三條路由。

VERIFY 使用不同模型，並不自動代表擁有不同 Checker Principal。正式獨立驗收仍必須證明 OS／Service 身份、資料與修改權限、有效 Oracle 等控制真的獨立。

### 5.6 專屬 Commander 容量的必要性

《FHS-MSC\_總討論》既有 R17 分析指出，某些模型車道程序曾被誤算成 Active Worker，進而阻礙其他工作派發。

因此建議讓 PLAN Commander 具有獨立的容量分類及佇列配額。

具體要求：

- PLAN 的等待不得消耗全部 EXECUTE Worker Slot。
- 長時間執行的分析 Agent 不得讓合法 READ\_ONLY Probe 永久飢餓。
- `control_lane_worker` 與 `executor_worker` 的租約分類必須清楚。
- Commander 可規劃多子代理，但實際併發由 HGK／Hermes 的容量及 WriteSet 限制。
- 必須支持阻塞 A、獨立 B／C 繼續。
- Worker Crash 後由 Durable State 恢復，而不是讓 Commander 重寫一次整個計畫。

**所以需要的是真正的資源隔離與路由治理，而不是再增加一個名為 Commander 的物理車道。**

---

## 六、內部 Commander 的「自動化裁決」如何避免再度變成過度治理？

### 6.1 自動裁決可以很強，但不得擴張權威

建議將 Commander 自動裁決定義為三個層級。

| 層級 | 可自動處理的事項 | 權限上限 |
|--------|--------|--------|
| D0：工程判斷 | 第一根因、依賴排序、修補優先序、最小工具選擇 | 建議性裁決 |
| D1：授權內規劃 | 子代理分工、工作順序、重試／PARK／Replan | 有界執行計畫裁決 |
| D2：正式效果 | Repository Mutation、Host Policy、Issuer、User Data | 不由 Commander 自行放行，轉交有效 Native Admission |

例如 Hermes 施工遇到一個故障：

**情境 A：單元測試失敗。**

Commander 應能自動讀取錯誤、定位變更範圍、建立 Repair Cone、指派合法 EXECUTE Worker，然後要求回歸測試。

若原有效授權涵蓋這個操作，不應再次詢問 OWNER。

**情境 B：HGK Native Permit 無效。**

Commander 應標記受影 Host Effect 為 PARK，並檢查是否有其他獨立工作可繼續。

它不能自行簽發假 Permit。

**情境 C：需要改變上位設計原意或擴大授權。**

Commander 應提供具體衝突、替代方案、風險與所需正式決策，而不是自行宣告上位契約已變更。

### 6.2 最小治理不是零治理

建議在現有 HGK 中建立或復用版本化 Standing Mission Authorization，讓其支持合法自動派工及重試。

但需明確分離：

`Mission Authorization`、`Operation Admission`、`Effect Permit`、`Independent Acceptance`。

單一 OWNER 可批准任務的風險上限、Repo 範圍、時間和撤銷政策；日常工作在有效範圍內不必每次重新口頭核准。

具體修改受保護資源時，仍由已具有實際權限的服務完成准入與簽發。

不能因追求低阻力，就把模型本身變成無限制的 OS Administrator、Trust Anchor Owner 或 Checker。

### 6.3 需要改掉的高自動化失效模式

| 舊模式 | 新模式 |
|--------|--------|
| 一個 Native HOLD 阻斷整個 Mission | 只 PARK 真正受影的 WorkOrder |
| 每張卡重讀完整規範 | Source Ref＋版本化 Coverage Index＋按需讀取 |
| 重複要求 OWNER 已提供的授權 | 讀取現役 Standing Authorization |
| 多個代理各自管理進度 | 唯一 HGK Work State＋Hermes Runtime Projection |
| 封存報告就結束執行 | 由 Runtime Terminal Gate 判定 |
| Planner 自己推測模型已使用 | 真 Served Identity Readback |
| 同一模型／同一權限自我驗收 | 有效獨立 Checker |
| 故障時重新產生整份 Master Prompt | 針對失敗工作卡執行最小 Replan |

這些改動屬於內部 Commander／HGK／Hermes 的運作收斂，不應塞進外部薄 Skill。

---

## 七、與 SBL DOC-00～13 及 FHS-MSC 上位控制包的修訂對照

### 7.1 最重要的上位依據：PIPD 本來就不主張一律使用完整 Plugin

《PIPD\_LS\_DOC-08》已經明確設計 **Minimum-Sufficient Architecture**：

`Prompt／AGENTS → Thin Skill Candidate → A/B Evaluation → Promote Thin Skill`

只有真正存在工具整合、外部動作、共同驗證、Host 安裝生命週期或 UI 等需求時，才考慮 Full Plugin。

**Full Plugin 不是 Skill 成熟後必然要升級的下一階段。** fileciteturn0file33L826-L895

這對本次決策非常關鍵。

如果 SBL Commander 的外部職責已收斂為唯讀分析、工程建議及無效果提案，沒有充分理由繼續強制要求完整 Plugin。

但也不能因為 Skill 較薄，就略過實際觸發準確度、權限邊界、可攜性和效果驗證。

薄 Skill 應先與原生 Prompt／AGENTS 基準進行同條件測試，證明確實降低錯誤、延遲、重複詢問及上下文成本，才能正式升格。

### 7.2 跨文件需修改的範圍

| 文件 | 現有規劃 | 建議變更 | 優先度 |
|--------|--------|--------|--------|
| SBL DOC-00 | 全產品導航及權威入口 | 新增外部 GUIDE、內部 PLAN 兩類入口 | P1 |
| SBL DOC-01 | 產品需求、三 SP、旅程 | 明確雙產品責任；保留原三 SP 需求身份 | P0 |
| SBL DOC-02 | Source／Authority 轉換 | 區分 Guide 的唯讀比對與內部 PLAN 的正式契約消費 | P1 |
| SBL DOC-03 | Spec、PI Candidate、TaskSeed | 明確 Bootstrap 尚未 Frozen 時的合法 Proposal 模式 | P0 |
| SBL DOC-04 | Shared Core、Commander、Orchestration | 重新定義 ComponentCard、觸發、權限與雙角色接口 | P0 |
| SBL DOC-05 | RepoContext、PD、Construction Contract | Guide 不接受直接寫入；PLAN 只產生有界計畫 | P0 |
| SBL DOC-06 | Technology Admission／Donor | Skill 與 Runtime Adapter 各自按適用性資格化 | P1 |
| SBL DOC-07 | Security／Permission | 移除外部 Commander 的 Builder 權限，保留正式安全控制 | P0 |
| SBL DOC-08 | TQAEP／Oracle／Challenge | 加入雙產品的正反例與不重複驗收規則 | P1 |
| SBL DOC-09 | Evidence／CI／Release | 分開 Skill 發行證據與 PLAN Native 證據 | P1 |
| SBL DOC-10 | GENIEMAKER／Host／Skill | 明確輕量 Skill 與內部 Orchestrator 不是同一 Host 能力 | P0 |
| SBL DOC-11 | Gate／Mode／Host | 依產品類型維持不同准入及 NoFit | P1 |
| SBL DOC-12 | Packaging／Host Installation | 修改外部 Commander 的包裝身份及 Host 測試要求 | P0 |
| SBL DOC-13 | Dogfood／Evolution | 加入自動化效益、重複授權、過度治理回歸測量 | P1 |
| FHS-MSC 藍圖 r2 | 三車道、唯一 HGK Control | 保留架構，新增雙 Commander 身份及角色綁定 | P0 |
| FHS-MSC 總討論 | 模型／車道／協作規劃 | 保留歷史，附加正式新裁決及差異說明 | P1 |
| B1 DOC-00／08 | Governance、GWO Proposal | 明確禁用舊 Skill 下的合法非 Commander Proposal 入口 | P0 |

這是**受影修改規劃**，不是要求重新撰寫每份文件的所有章節。

SBL DOC-04 目前已明確規定 Commander-SP 的輸出為 `ThinPromptCandidate + NativeHandoffRequestCandidate`，權限為 `NO_WORKORDER_ISSUE`；新設計應沿用這項正確的不變量。fileciteturn0file22L368-L380

### 7.3 不能直接刪除既有 Commander-SP Plugin 產品義務

此處有一項必須處理的上位衝突。

《FHS-MSC\_藍圖\_r2》保留三個可攜式 SP，並將 Commander-SP 列為正式產品交付身份，其中包括 ZIP、`plan.propose` 及對應 Host 安裝、載入、調用、拒收和卸載要求。fileciteturn0file24L584-L600

如果現在決定 Commander 對外只保留薄 Skill，就不能靜默刪除上述產品要求。

建議採用版本化設計裁決：

**ADR-SBL-COMMANDER-SPLIT（建議新增）**

正式決定：

- 原有 Commander-SP 產品需求保留來源身份及歷史追溯。
- 其唯讀引導功能由新的 Thin Skill 承接。
- 原有任務規劃和自動化協調能力移交內部 SBL Commander／PLAN。
- 原有合法 Standalone Builder 寫入能力，若仍符合有效產品需求，則由獨立受權 Builder 承接。
- 舊 Commander-SP Plugin 不作 B1 Runtime 前置。
- 原有 Plugin 發布項目依 Owner 的版本化決策標為 Superseded、Conditional 或其他具體狀態。
- 任何正式 Mandatory Product Obligation 的取消或變更，都需要真正的上位 Owner Ratification。

不能讓同一舊 Plugin 和新的內部 Commander 同時聲稱擁有正式 `plan.propose` 權威。

### 7.4 最佳遷移方式：保留來源身份，切分功能，不重置架構

| 原有功能 | 新承接位置 |
|--------|--------|
| Source／Intent 比對 | 外部 Guide Skill |
| Engineering Decision Advisory | 外部 Guide Skill |
| 故障分析與最小 Repair Cone 建議 | Guide Skill；深度工程分析可交 FAR |
| 初步 Proposal | Guide Skill／合法 SBL Proposal Adapter |
| PIPD 控制包消費 | 內部 Commander PLAN |
| Task DAG／並行規劃 | 內部 Commander PLAN |
| Multi-Agent Assignment Planning | 內部 Commander PLAN |
| 真實派工及恢復 | HGK／Hermes |
| Repository 變更 | EXECUTE／Codex Worker |
| 正式 Native Permit | HGK Issuer |
| 正式驗收 | Independent Checker／AO |
| 原有合法 Standalone Builder 效果 | 專屬授權 Builder，而非 Guide Skill |

這是目前最能兼顧高自動化、產品原意和既有投資的分離方案。

---

## 八、建議的正式接口與資料契約

### 8.1 外部 Guide Skill：只輸出沒有執行效力的提案

推薦最小輸出：

```json
{
  "artifact_kind": "SBL_GUIDANCE_PROPOSAL",
  "schema_version": "1.0-proposed",
  "goal_ref": "...",
  "source_refs": [],
  "design_intent_delta": [],
  "findings": [],
  "recommended_decision": {},
  "repair_cone": {},
  "authorization_applicability": {},
  "requires_owner_escalation": false,
  "execution_authority": false,
  "native_permit": null
}
```

這是**新設計示意 Schema**，不是聲稱現有 SBL API 已實作該結構。

其中的 `authorization_applicability` 只能表達：

「已知哪些授權存在、此工作是否落在範圍內、還缺少什麼。」

不能寫入可被 HGK 當成有效 Permit 的自我批准結果。

### 8.2 內部 Commander PLAN：正式的規劃輸出

建議使用：

```json
{
  "artifact_kind": "SBL_PLAN_PROPOSAL",
  "schema_version": "1.0-proposed",
  "mission_id": "...",
  "source_subject_ref": "...",
  "pipd_contract_refs": [],
  "policy_epoch_ref": "...",
  "task_dag": [],
  "parallel_groups": [],
  "worker_role_requirements": [],
  "write_scope_proposals": [],
  "model_route_request": {},
  "dependency_gates": [],
  "recovery_policy": {},
  "acceptance_refs": [],
  "native_workorder_id": null,
  "execution_authority": false
}
```

它可以提出完整的任務拆解，甚至選擇最佳受限 Worker 類型，但只有經 HGK 接納後才產生真實的 Native WorkOrder 身份。

### 8.3 任務規劃與真實執行需有精確身份關聯

最少需要保持：

`mission_id → commander_invocation_id → plan_revision → task_id → HGK_workorder_id → Hermes_worker_id → operation_id → raw_receipt → checker_verdict`

這條身份鏈的目的不是增加治理表單，而是防止：

- 同一任務反覆派發；
- Planner 結束就讓工作消失；
- Worker 在錯誤作用域施工；
- 不同模型的回覆混為同一操作結果；
- 自動修補後驗收仍沿用舊 SHA；
- Reporter 把中間成果當作 Mission Complete。

### 8.4 Commander Replan 必須支援增量作業

重點是**不因單卡失敗就重新規劃整個產品**。

應由 Runtime 告知 Commander：

`Failed Task + FirstFail + Affected Dependencies + Available Workers + Existing Authorization`

Commander 只產生受影修改：

`PlanDelta + RepairCone + TaskReassignment`

然後由 HGK 檢查是否符合既有有效政策。

如果不相干工作已經完成，或其他 READY 工作仍可進行，就不應因一次 Replan 重新執行它們。

---

## 九、完整施工與遷移方案

### Phase 0：凍結現況及建立功能對照

不立即全面改寫 SBL。

先建立可核對的產品與實際介面清冊：

- 舊 Commander-SP 的 Manifest、Skill、入口、權限、工具能力。
- SBL 內部 Commander／PLAN 相關模組。
- HGK 現有三 Lane Model Registry。
- Hermes 真 Dispatcher／Worker 接口。
- PIPD Canonical Reader／Compiler。
- 既有 B1 禁用 Commander-SP 的有效限制。

**退出條件：** 每項原功能都有明確的新承接者或正式保留／暫停理由；沒有未說明的功能刪除。

### Phase 1：發布版本化架構修訂

制定前述雙產品 ADR。

同時修正 `product.write`、`build.route`、`evidence.read` 的權限邊界。

以有效的三車道分工為主，不修改 HGK 唯一 Issuer／Scheduler 的正式權威。

**退出條件：** Guide、PLAN、EXECUTE、Checker 四種不同權責不再出現雙重控制權。

### Phase 2：薄 Skill 最小原型與 A/B 驗證

建立小型 `SKILL.md`，只包含：

- 適用工作類型；
- 來源與授權讀取順序；
- 六項主要引導責任；
- 產物 Schema；
- 禁止越權的規則；
- 遇到真正缺少資料時的明確回報。

其他長篇規範按需要引用，不內嵌複製。

先以 Prompt／AGENTS 基準與薄 Skill 使用相同 Fixtures 比較，不因形式已是 Skill 就直接宣告成功。

**退出條件：** 有可量測的任務品質或效率收益，且沒有增加權限、驗收或來源漂移風險。

### Phase 3：內部 SBL Commander／PLAN 接線

完成：

- 真 PIPD Contract Reader；
- HGK Policy／WorkOrder Reader；
- Task DAG Generator；
- Worker Role／Capability Selector；
- Model Route Resolver；
- 增量 Replan；
- Handoff Adapter；
- Plan Version／Identity Ledger。

並且必須使它能使用既有 Hermes／HGK 的資料來源，不建立第二份 Canonical WorkOrder DB。

**退出條件：** 一項多工作卡 Mission 能產生合法 DAG，交給 HGK 接納，再由 Hermes 自主派工，不需要外部 Commander-SP 介入。

### Phase 4：三模型路由真實驗收

按照主選、備援 1、備援 2 分別驗證：

- 指定 Provider／Model；
- 實際 Served Identity；
- 真正 Credential Route；
- Reasoning Effort；
- Structured Output；
- Tool Invocation；
- Timeout／Rate Limit；
- 正反例 Fallback；
- 成本和資料使用範圍。

特別要求不同 Provider 間的來源資料傳輸必須符合既有資料保護政策。

不能因 OpenCode Go 模型支援 API，就自動將所有 SBL／HGK 私有 Source、金鑰、使用者資料提供給外部模型。

**退出條件：** 指定模型的實際服務可重播驗證，非授權替代必須拒收。

### Phase 5：Hermes／HGK 高自動化整合

以既有 SharedSpine／Hermes Runtime 為核心，完成：

`Plan → Native Admission → Dispatch → Execution → Readback → Verify → Replan／Complete`

必須進行 Crash／Restart、阻塞 A／繼續 B/C、Lease 過期、重複請求、效果未知和外援撤銷測試。

**退出條件：** 內部 Commander 的規劃結果能由真正的 Runtime 自主執行並恢復；產生報告不會導致合法待辦任務提前終止。

### Phase 6：SBL 全產品回歸與 B1 防復發驗收

最後驗證：

- SBL 原有 Guided Spec、Governed Build、Evidence-based Verify、Bounded Repair 均未退化。
- 三 SP 的產品身份保留並完成版本化調整。
- 外部 Guide Skill 不引入 Native Writer／Issuer。
- 內部 Commander／PLAN 不建立第二個 Runtime。
- B1 Bootstrap 可以在禁用舊 Commander-SP 的情況下合法推進。
- 不再出現由不適用的 Frozen PI／PD 前置條件引發的全域停工。
- 正式 Native Effect 依然需要真 Permit／Readback／Independent Checker。

**退出條件：** 不僅能證明新的架構可用，還能證明舊 B1 的失效機制不會重新發生。

---

## 十、關鍵回歸及驗收矩陣

| ID | 測試 | 正確結果 |
|--------|--------|--------|
| C01 | 外部 Skill 讀取已存在設計與目標 | 形成 Source-bound 建議 |
| C02 | 未具 Frozen PI／PD 的 Bootstrap | 可提出診斷與合法 Bootstrap 路徑，不以此阻斷全部工作 |
| C03 | Skill 被要求直接改 Repo | 不直接執行，返回合法工作建議 |
| C04 | OWNER 已有有效有界授權 | 不重複要求相同人工批准 |
| C05 | 要求超出授權的 Host Effect | 明確拒收或要求真正額外准入 |
| C06 | 內部 Commander 解析 PIPD 控制包 | 不產生第二份 Canonical PI／PD |
| C07 | 任務含三個可獨立工作卡 | 產生 DAG 與可並行工作建議 |
| C08 | Commander 指派多子代理 | 符合 Worker 能力、WriteSet、Lease 限制 |
| C09 | PLAN 指定 GPT-6.1 Sol Medium | 真 Served＝指定模型、推理強度與 Provider |
| C10 | 指定 DeepSeek V4.1 Flash | 不得靜默改用 MiMo |
| C11 | 主選不可用且備援已授權 | 合法切換並產生清楚的備援收據 |
| C12 | 主選不可用且禁止備援 | HOLD 指定呼叫，不冒充成功 |
| C13 | PLAN Worker 飽和 | 不使 EXECUTE／唯讀 Probe 無故飢餓 |
| C14 | Hermes Worker 被終止 | Durable Mission 依合法條件恢復 |
| C15 | 工作 A 阻塞，B/C 可執行 | B/C 繼續 |
| C16 | Maker 與 Checker 使用相同 Principal | 正式獨立驗收拒收 |
| C17 | 一個 Native Effect 缺 Permit | 只阻擋相依工作 |
| C18 | 產生中期報告時還有 READY 卡 | 不得結案 |
| C19 | 新 Skill 被停用 | 內部 Commander／Hermes 原生鏈路不受影響 |
| C20 | 舊 Commander-SP 嘗試進入 B1 | 依禁用規則拒收 |
| C21 | 新 Skill／Plugin 安裝及卸載 | 真 Host Readback、非預期觸發拒收、殘留檢查 |
| C22 | 使用者明確選模型 | 覆蓋預設但不得繞過有效 Provider／Model Admission |

這些測試應分為單元、整合、現役 Host 與獨立驗收四層；不得把相同的本機 Fixture 通過視為所有層級均已通過。

### 10.1 高自動化效益 KPI

建議將重構成效以以下資料衡量：

| KPI | 要改善的問題 |
|--------|--------|
| 重複 OWNER 授權詢問次數 | 減少無必要人工介入 |
| False Global HOLD 次數 | 防止不相干工作一起停止 |
| READY-to-Dispatch 延遲 | 提高真實派工效率 |
| Autonomous Continuation Rate | 確保跨 Session／Crash 能恢復 |
| Required＝Served 正確率 | 消除模型路由假成功 |
| 重複 Contract／Source 讀取成本 | 降低上下文與運算浪費 |
| Repair Cone 大小及重試次數 | 減少大範圍重工 |
| 未授權 Effect 次數 | 必須維持零 |
| Maker／Checker 身份衝突次數 | 正式驗收不得發生 |
| 產品功能回歸失敗率 | 防止精簡造成既有功能退化 |

不應在未量測現有基準前承諾固定百分比的效能提升。

---

## 十一、最重要的工程風險與防範

| 風險 | 若處理不當 | 防範 |
|--------|--------|--------|
| 將 Skill 降格理解為取消全部安全治理 | 越權施工 | 保留原生效果防線 |
| 把內部 Commander 升格為 HGK 控制器 | 第二主權平面 | PLAN 只產候選及合法 Replan |
| 為 Commander 再建一條完整新車道 | Scheduler／Model Registry 重複 | 使用現有 PLAN Role Pool |
| 把不同模型當成完全等價 | 語義與工具功能降級 | 能力、路由及 Served 驗證 |
| 將 OpenAI OAuth 與 OpenCode Go 混用 | 憑證、路由及服務身份錯誤 | 分離 Credential／Transport |
| 模型更換就認定 Checker 獨立 | 假 SoD | 真 Principal／權限隔離 |
| 外部 Skill 與內部 PLAN 同時派工 | 雙重 WorkOrder／重試 | 唯一 HGK Work Authority |
| 精簡後直接刪舊 Plugin | 違反 SBL 全產品覆蓋義務 | 正式 ADR／Supersession／Owner Ratification |
| 把舊 Prompt 當有效規範 | 治理阻斷反覆發生 | 舊指揮只作歷史來源 |
| PLAN 過度頻繁重新規劃 | Token、成本、競爭及飢餓 | Affected-only Replan／資源配額 |
| 自動備援將私有 Source 送至新 Provider | 資料邊界違反 | Provider Data Policy／有效授權 |
| B1 尚未完成就大規模重寫 Commander | 新重構阻斷 Bootstrap | B1 修復與 SBL 產品重構分線進行 |

最後一項尤其重要。

**目前不應要求 B1 先完成這次 Commander 重構，才能繼續原有 Bootstrap 修復。**

應讓 B1 以既有合法 HGK／Hermes／Codex 鏈路繼續，新的 Commander 產品修訂獨立推進；等內部 PLAN 取得真實資格化後再逐步接入。

---

## 十二、最終工程裁決

### 12.1 第一項：是否完整重構 SBL-Commander-SP 並降為薄 Skill？

**建議：採納。**

重構的是功能邊界、權限、接口及 Host 發布策略，而不是全面重建 SBL 技術基礎。

外部 Commander 應從「施工指揮及 Builder 候選」轉為：

**Design Intent Guidance + Engineering Advisory + Diagnostic Assistance + Authorization Applicability + Bounded Proposal。**

主交付選擇 Thin Skill；完整 Plugin 須有獨立可證明的工具整合必要性。

這不僅能降低治理阻力，還符合 PIPD DOC-08 對 Minimum-Sufficient Architecture 的正式原則。

### 12.2 第二項：內部 SBL Commander 是否應完整承擔 PLAN／多代理／模型路由？

**建議：採納，但只承擔 PLAN 責任，不接管 HGK／Hermes Native 控制權。**

保留：

- GPT-6.1 Sol Medium 作主選；
- DeepSeek V4.1 Flash 作備援 1；
- MiMo-V2.6-Flash 作備援 2；
- 使用者可在有效政策內明確選擇模型；
- 各 Provider 路由及真實服務結果須獨立驗證。

內部 Commander 的獨立性應體現在角色、工作池、模型政策、工具能力及資源配額，而不是再開一條平行物理車道。

### 12.3 第三項：是否已有相關規劃？

**已存在，且不只是概念級規劃。**

| 上位資料 | 規劃成熟程度 | 本次仍需補強 |
|--------|--------|--------|
| SBL DOC-00～13 | 有三 SP、Shared Core、Commander ComponentCard、Task DAG／Handoff、Host／Skill／Plugin 設計 | 外部 GUIDE 與內部 PLAN 的正式產品邊界 |
| FHS-MSC 藍圖 r2 | 有三車道、多角色、單一 HGK Control、模型與權限分離 | 統一的雙 Commander 身份與有效路由接線 |
| FHS-MSC 總討論 | 已明確指定三條模型車道、模型順序、子代理與長任務控制方案 | 從研究裁決落實成有版本的 Runtime Contract |
| B1 Bootstrap Package | 有正式 Native Gate、工作分類與 Golden WorkOrders | 避免 Commander-SP 前置循環，完成自治執行及獨立驗收 |

因此，這次規劃最適合採取 **High-Retention Architectural Refinement**，而不是 Architecture Reset。

### 12.4 最終建議採納的全域架構

### 建議定案架構

外部產品

`SBL Commander Guide Skill`

唯讀引導、設計比對、診斷與有界提案。

---

內部產品

`SBL Commander / PLAN`

PIPD 契約消費、語意理解、Task DAG、子代理協調、政策內裁決與增量 Replan。

---

執行基礎設施

`HG-KSEOS + Hermes + Fabric`

唯一 Native Work Authority、Issuer、政策、持久調度與世界效果讀回。

---

執行車道

`PLAN / EXECUTE / VERIFY_SECURITY`

三車道保留，Commander 使用 PLAN 的專屬 Role Pool。

---

正式效果與驗收

`Codex Worker + Native Admission + Independent Checker`

真施工、真證據、真獨立驗收，不由外部 Skill 自行代簽。

### 12.5 最終總結

本次最有工程價值的調整，不是單純將 Commander-SP 的 Prompt 縮短，而是**把外部引導能力與內部自治規劃能力從產品身份上分開**。

外部薄 Skill 應當極輕、容易安裝、容易停止、容易替換，不要求使用者為每一個工程建議進行繁重治理。

內部 SBL Commander 則應保留充分的語意理解與規劃能力，並由 HGK／Hermes 保證它提出的工作只有在符合真實授權、依賴、模型路由及資源條件時才執行。

這將同時避免兩種失敗：

**一是讓外部 Skill 對所有施工施加過度治理；二是為了降低治理，讓內部 Commander 取得無約束的執行及驗收權限。**

**最終工程裁決：採納「外部極薄 Skill＋內部專業 Commander／PLAN＋HGK 唯一 Native Control＋Hermes 持久執行＋既有三模型車道」的修訂架構；以版本化 ADR、按需接口收斂、實機測試及防回歸驗收落地，不進行全系統重建。**

本報告法位：SOURCE-BASED ARCHITECTURE REVIEW / CROSS-DOCUMENT RECONCILIATION / EXTERNAL MODEL DOCUMENTATION VERIFIED / DESIGN RECOMMENDATION。未掛載或調用 Commander-SP，未修改 Repository、模型設定、HGK Policy 或 Windows Host；現階段並不構成新架構已安裝或 Native Acceptance PASS。

## Prompt:
2026/10/27 下午10:24:16

任務目標：
你必須整合前述分析規劃，再進行以下項目的專業工程「研究分析 + 交叉比對 + 鑑定評估」：
"
1) 完整新版 SBL-Commander-Skill，是否適合先用HERMES/HGK先做第一版，然後在本地CODEX進行最終「掛載實跑檢測、治理/鏈路/高自動化實測、自修補、自迭代、自驗收、自交付」?或是全部直接在CODEX裡實作+檢測+驗收更高效率?

2) 目前對於完整新版 SBL-Commander-Skill的規劃，是否依然保有整合導入「OPENSPEC、MATT SKILLS、GSTACK、SPEC KIT、GSD....」等等現有可用的外界開源工具?避免重複自造/設計輪子?
"

任務要求：
你必須針對任務目標，並對 全部相關資料進行「研究分析+交叉比對+深度推理」，再進行鑑定、評估、規劃，並提出完整報告。

## Response:
2026/10/27 下午10:24:37 · gpt-6-thinking

我會以既有 SBL／FHS-MSC 控制包、B1 施工紀錄及前輪雙 Commander 分權方案為基準，分別評估「Hermes/HGK 先建、Codex 後驗」與「Codex 全程建置」的實際成本與控制風險。接著核對 OpenSpec、Matt Skills、gstack、Spec Kit、GSD 等工具在現有設計中的地位與最新可用接口，最後提出明確的施工分工、導入矩陣與驗收標準；不掛載舊 Commander-SP，也不修改本機工程。

交叉比對已確認：新版 Skill **不會失去開源工具整合規劃**。SBL DOC-06 已分別建立 OpenSpec（OS）、Spec Kit（SK）、Matt Pocock（MP）、gstack（GT）、GSD（GS）的方法槽位；但 PIPD DOC-08 對各工具的准入等級不同，並非要求全部安裝。另一項會影響建置順序的結論是：若新版主要是唯讀薄 Skill，直接在 Codex 的隔離工作樹完成第一版與快速回歸，通常比先啟動尚未完成 Native 驗收的 Hermes/HGK 全鏈路更省阻力；Hermes/HGK 應集中在真正需要原生派工、跨程序與 Host 效果的整合驗收。

> **檢查施工檔案與研究工作流**
>
>
> **檢查施工檔案與研究工作流**
>
> 
>
> **已搜尋 8 個網站**
>
> 
>
> **盤點GSD核心遷移相關文件**
>
>
> **整理實作建議**
>
> 我會先提出核心結論，再依序比較兩種工作流、工具角色、驗收方式與風險。重點是採用 Codex 優先、獨立驗證補強，避免不必要地引入完整工具鏈。
>
> **整理實作建議**
>
> 
>
> **盤點GSD核心遷移文件**
>
> 
>
> **已搜尋 1 個網站**
>
> 
>
> **整理本地來源與引用內容**
>
>
> **檢視外部工具採用狀態**
>
>
> **整理本地來源並檢視外部工具採用狀態**
>
> 
>
> **已搜尋 2 個網站**
>
> 
>
> 處理時間為 4m 45s

# 新版 SBL-Commander-Skill 建置策略與開源工具復用工程鑑定報告

鑑定基準：2026 年 10 月 27 日｜範圍：Hermes、HG-KSEOS、Codex、SBL DOC-00～13、PIPD DOC-00～09、FHS-MSC 藍圖與 B1 歷史施工資料

## 一、總體工程裁決

針對這次的兩個問題，結論如下。

**第一，新版 SBL-Commander-Skill 建議採取「Codex 優先建置＋Hermes/HGK 原生整合驗證＋Codex 修補回歸＋獨立資格化」的混合路線。**

如果只能在使用者提出的兩種方案中選擇：

- 「Hermes/HGK 先完成第一版，再交 Codex 最終檢測」；
- 「全部直接交 Codex 建置、測試及驗收」；

那麼**對新版唯讀、低權限、薄型 Commander Skill 而言，第二種方案在初始開發階段通常更有效率**。

但不建議將全部正式驗收都交由 Codex 自行完成。Codex 可以自動測試、自我診斷、自動修補與交付候選，卻不能因為自己測試成功，就取代 B1 要求的獨立驗收或 HGK Native Effect Acceptance。

**第二，SBL 現有設計已經保留 OpenSpec、Matt Pocock Skills、gstack、Spec Kit、GSD 等開源技術，而且定義了相當具體的導入槽位。**

不應因 Commander-SP 降為薄 Skill，就刪除原有開源工具整合規劃。應保留全部既有來源身份與功能義務，將需要的能力以薄型適配、原生工具調用或參考方法提供，不將五套完整框架全部複製進新版 Skill。

推薦的工程組合

新版 Skill 主建置

**Codex**

原生整合及持久自治

**Hermes／HGK**

自動修補／工程回歸

**Codex**

正式獨立驗收

**獨立 Checker／AO**

---

主要策略：**Reuse First、Thin Skill、Affected-only Repair、Single Native Control、Independent Acceptance**。

---

## 二、為什麼不建議先依賴 Hermes/HGK 完成整個新版 Skill？

### 2.1 新版 Skill 的性質已經改變

前輪正式規劃已將兩個產品分離：

| 產品 | 主要功能 | 需要的執行基礎 |
|--------|--------|--------|
| **SBL-Commander-Skill** | 比對設計原意、工程建議、排錯引導、授權適用性分析、無效果提案 | Skill 檔案、來源 Reader、Schema、隔離測試 |
| **內部 SBL Commander／PLAN** | PIPD 契約消費、Task DAG、子代理規劃、模型路由、增量 Replan | HGK／Hermes、正式 Model Lane、WorkOrder、持久執行 |

新版 Skill 並不需要自行管理 Queue、Lease、Issuer、Policy Activation 或 Worker Runtime。

這意味著若為了建立一個薄型 Skill，先要求完成整套 HGK Native Issuer、Hermes Autonomous Executor、G-A、G-B 等流程，就會重新引入 B1 已發生過的 Bootstrap 循環依賴。

**這正是此次重構應避免的問題。**

### 2.2 B1 目前的實際工程狀態不適合作為第一版必備依賴

《FHS\_MSC\_B1\_Task\_Handoff\_Report\_v1\_2026-10-27》記載：

- T1 持久派工基礎具備局部通過證據。
- R1／R2 仍為 PARTIAL。
- T2、R3、R4、G-A、三張 Golden WorkOrders、G-B 尚未取得正式 PASS。
- HGK User Trust 已有候選，但 Receiver 尚未接線。
- Hermes 真 Executor 在 r10 未完成驗證。

這代表現階段如果要求「新版 Skill 第一行程式碼必須由完整 HGK Native 流程派工」，就可能把一個原本可由普通 Codex 工作樹完成的軟體開發任務，變成依賴尚未完成的控制平面。

**應讓新版 Skill 的初期工程依賴最少的合法能力，避免把正式 Native Acceptance 重新變成普通開發前置條件。** fileciteturn0file7L9-L18

### 2.3 Hermes/HGK 應參與，但參與最能發揮優勢的階段

Hermes／HGK 的主要優勢是：

- 長任務持久狀態；
- 多工作卡依賴管理；
- 子代理協作；
- 自動派工及恢復；
- 模型車道與政策控制；
- 真實 Native Effect；
- 跨程序的原生執行與驗收鏈路。

這些都不是一份初版 `SKILL.md` 的必要功能。

但當新版 Skill 需要與內部 SBL Commander／PLAN、HGK WorkOrder Proposal、Hermes Role Pool 或不同 Host 整合時，Hermes／HGK 就應成為主要的整合測試環境。

所以推薦的是**按能力邊界分工，而不是將整個任務硬性分割為「Hermes 先做、Codex 後做」。**

---

## 三、兩種施工方案的專業比較

### 3.1 完整工程比較矩陣

| 評估項目 | Hermes/HGK 先做，Codex 後驗 | 全部 Codex 建置與檢測 | 建議混合方案 |
|--------|--------|--------|--------|
| 第一版生成速度 | 中等，取決於現役 Runtime | **通常較快** | **通常較快** |
| Skill 本體與 Schema 修改 | 增加跨 Agent 交接 | **直接修改最有效率** | Codex 負責 |
| 高速 Red→Green 迭代 | 需 Worker 接線 | **有利** | Codex 負責 |
| PIPD 上位設計比對 | 可利用 HGK PLAN | 可直接讀契約 | 兩端共用相同版本 |
| 多工作卡、長任務 | 有潛在優勢，依現役能力 | 依 Codex Session 能力 | Hermes/HGK 負責必要部分 |
| 真正跨程序恢復 | 必須由 Runtime 測試 | 無法僅靠 Skill 測試充分證明 | Hermes/HGK 負責 |
| Host Skill Discovery | 需目標 Host 實跑 | 目標為 Codex 時直接有效 | 各目標 Host 分別驗證 |
| 原生權限與 Native Effect | HGK 有正確權責 | 無法自行取代 HGK | HGK 負責 |
| 自動修補 | 可派工但有接線成本 | **有利** | Codex 修補，必要時 Hermes 派工 |
| 正式獨立驗收 | 仍需真 Checker | Codex 自驗不足 | 獨立 Checker |
| 重演 B1 Bootstrap HOLD 風險 | **較高**，若把未完成 Native Gate 當前置 | 較低，前提是符合普通工程授權 | **較低** |
| 後續內部 PLAN 擴展性 | 較好 | 需補整合 | **較好** |

這是根據任務適配性作出的定性工程判斷，不是已完成兩組實機 A/B 測試後的速度測量。

### 3.2 方案 A：Hermes/HGK 第一版，Codex 最終檢測

此方案適合的前提是：

- Hermes 真 Executor 已可穩定使用；
- HGK 工作授權與 Receiver 具備必要實際能力；
- 本次工作主要是內部 Commander／PLAN 與多代理協作，而不只是建立一份薄 Skill；
- 需要跨 Session 長時間施工；
- 已有多個可並行的工程修補項目。

但如果以上前提尚未具備，此方案就會重新引入待修控制系統作為開工依賴。

**對新版薄 Skill 的第一版而言，目前不建議採用它作為唯一施工主線。**

### 3.3 方案 B：全部在 Codex 建置、測試、修補

對下列工作，Codex 可以是一個有效率的單一工程工作環境：

- `SKILL.md` 的精簡重寫；
- Skill 觸發條件與禁止條件；
- PIPD Read Adapter；
- OpenSpec／Matt／Spec Kit 等方法選擇器；
- Tool Selection Registry；
- Typed Proposal Schema；
- 自動化測試 Fixture；
- 測試工具與 CI；
- 本地安裝、呼叫和卸載；
- 持續自動修補。

這些工作可以在隔離工作樹中以受限、可回復的方式執行。

但「全部由 Codex 自驗收」仍有一個不可消除的權責問題：

**同一個 Codex Maker 可以進行工程自測及回歸檢查，不能僅憑同一身份的自測結果宣稱已取得 Independent Acceptance。**

如果使用另一個真正隔離的 Checker 執行正式資格化，即使其也是由 Codex 工具啟動，仍必須證明 Maker／Checker 的身份與權限隔離，而不是只切換一個 Agent 名稱或模型。

### 3.4 最佳方案：Codex-first，Hermes/HGK-native qualification

建議流程：

**第一階段｜Codex**

現行來源對齊 → 薄 Skill → Schema → Donor Adapter → Red/Green → 局部回歸

**第二階段｜目標 Host 實跑**

Codex 實際掛載／觸發／非觸發／卸載；必要時 Hermes 實際載入

**第三階段｜Hermes/HGK**

原生 Proposal Handoff、權限負例、PLAN 接線、持久派工和跨程序驗證

**第四階段｜Codex 修補**

只針對失敗接口和 Regression Cone 做最小修補

**第五階段｜獨立 Checker／Owner**

核對最終版本、Host 真效果、負例、來源與安全邊界

**這個方案比先把 Hermes/HGK 全部修好再製作薄 Skill 更符合現階段 B1 的實際狀態；也比完全由同一個 Codex 自建、自測、自簽驗收更可靠。**

---

## 四、開源工具整合是否仍完整保留？

**是，而且不是僅以工具名稱保留。**

### 4.1 SBL DOC-06 已有六組 Donor 方法契約

《SBL\_PIPD-LS-PKG\_DOC-06》的 C32 已明確定義六組外部工具，各有四個能力槽位：

| Donor | 原有槽位 | 核心能力 |
|--------|--------|--------|
| OpenSpec | OS-01～04 | Explore、Spec Delta、Apply、Archive |
| GitHub Spec Kit | SK-01～04 | Constitution、Clarify、Task DAG、Workflow Composition |
| Matt Pocock Skills | MP-01～04 | Skill Routing、避免重問、Domain Model、Spec／Tickets |
| GSD | GS-01～04 | Long-loop Context、Milestone、Checkpoint／Resume、Release Readiness |
| gstack | GT-01～04 | Product Review、Engineering Review、QA、Ship Readiness |
| Superpowers | SP-01～04 | Design-first、TDD、Systematic Debugging、Verification |

合計 **24 個既有能力槽位**。

DOC-06 並未要求全部六套工具成為 SBL 的正式控制平面，反而明確要求區分原生復用、薄轉譯、零供應商運作模式及退出機制。fileciteturn0file10L126-L139

因此新版 Commander-Skill 的重構原則應是：

**24 個既有能力身份全部保留，但由適用性選擇器決定哪一項在當前任務中真正需要啟用。**

不能將「保留 24 個設計槽位」錯誤理解為「每次呼叫薄 Skill 就必須啟動 24 個方法」。

### 4.2 PIPD 已為各工具作出不同技術准入判定

《PIPD\_LS\_DOC-08》記載的設計准入如下：

| 工具 | PIPD 既有分類 | 本次建議 |
|--------|--------|--------|
| OpenSpec | `SELECTED_TRANSLATE` | 優先考慮實際 Spec Delta／Brownfield Adapter |
| Spec Kit | `SELECTED_WRAP` | 維持可選 Spec／Task 工作流，不作第二 Compiler |
| Matt Pocock Skills | `SELECTED_TRANSLATE` | 按需挑選單一 Skill，不強制整包安裝 |
| Superpowers | `SELECTED_TRANSLATE` | 選擇性復用 TDD、診斷、完成前驗證 |
| gstack | `REFERENCE` | 優先復用審查方法；整合執行需重新准入 |
| Open GSD／gsd-core | `REFERENCE` | 優先採用方法概念，不引入第二持久 Scheduler |
| 舊版 gsd-build | `REJECT`（Legacy） | 不作新的採用來源 |

這是截至 2026 年 10 月 7 日的設計基準，實際安裝時仍須重新確認版本、授權、工具支援及相依性。fileciteturn0file33L1228-L1243

另有一項重要差異：

SBL DOC-04 將 OpenSpec、Spec Kit、Superpowers 與 Matt 列為 `MANDATED_ASSESSED`，對 gstack 則存在 `QUARANTINE` 裁決。這表示相關能力必須被正面評估、保留設計對應及合法退出策略，**並不代表全部已批准安裝或已驗證生效**。fileciteturn0file22L901-L924

---

## 五、五套主要開源工具的實際導入策略

### 5.1 OpenSpec：新版 Skill 最值得優先復用的 Spec Delta 能力

[![OpenSpec/docs/commands.md at main · Fission-AI/OpenSpec · GitHub](https://images.openai.com/static-rsc-4/wf1AelIuaQ1tIOJ4rYq3DVBG6SJpcK2lyyI_mpQljYFNX18ia3uZTA7XTInESMGWPiXkZKmmX5NS59OgBWU2V_OsxdMUGsb4dLNi1K0frgadbmpju61S7QELhiATQvpVjZ1rM-Hk66blAoqKneRWJxJf1VrjSXSxi5CE99WnzwqRmjjPQzo53kfxNYfbHBzw?purpose=fullsize)](https://github.com/Fission-AI/OpenSpec/blob/main/docs/commands.md)

**OpenSpec**

建議地位：優先評估的可執行工具適配器

[官方 GitHub](https://github.com/Fission-AI/OpenSpec?utm_source=chatgpt.com)

OpenSpec 現在提供 `explore`、`propose`、`apply`、`verify` 及 `archive` 等工作流，並支援 Codex 與 Hermes Agent 的 Skill 安裝目標。Codex 使用 Skill 目錄；Hermes 的專案 Skill 則需要配置相應的外部目錄讀取。\[[GitHub - Fission-AI/OpenSpec: Spec-driven development (SDD) for AI coding assistants.](https://github.com/Fission-AI/openspec?utm_source=chatgpt.com); [OpenSpec/docs/supported-tools.md at main · Fission-AI/OpenSpec](https://github.com/Fission-AI/OpenSpec/blob/main/docs/supported-tools.md?utm_source=chatgpt.com)\]

對新版 Commander-Skill，最有價值的是：

- 對既有設計進行增量變更分析；
- 由使用者新的要求產生變更提案；
- 比較現有 Spec 與需求差異；
- 把變更分解成可施工項目；
- 於適當階段讀取驗證與封存結果。

**建議第一版優先使用 OpenSpec 的 Read／Explore／Diff／Proposal 能力，不自動啟動 Apply 或 Archive。**

尤其不能將 OpenSpec 產生的 Spec 視為 PIPD 正式 Canonical PI／PD，也不能因 OpenSpec 工具返回成功，就宣稱 Native TQAEP PASS。

這不是削弱 OpenSpec，而是讓它專注於其擅長的增量規格管理。

### 5.2 Matt Pocock Skills：最符合薄 Skill 思想的功能式復用來源

[![Matt Pocock Open-Source Bộ Skills AI Giúp Bạn Code Như Senior Engineer - devlog](https://images.openai.com/static-rsc-4/VSCCNIjMFVF1mcvg0y5K-ZExxmQd9tp4j6lQNrSa51iw5vhxpqyQd5tu0BKP-13HzE48uEARmm3fh1PgHvDDb_i9Q0yo2O9mUymRULmlv55V9PCinNUzuPSx8-o-UuD-ynxg09VsVE_PnydeKPiCdQ3UlSNVQXFpmrY9m6okqiqq6vkD7jXYB0qo1C5BRZ4k?purpose=fullsize)](https://www.donniechu.com/posts/skills-for-real-engineers-matt-pocock)

**Matt Pocock Skills**

建議地位：按任務挑選特定 Skill／方法

[官方 GitHub](https://github.com/mattpocock/skills?utm_source=chatgpt.com)

Matt Pocock 的現有工程技能包括 `diagnosing-bugs`、`tdd`、`domain-modeling`、`code-review`、`to-spec`、`to-tickets` 及 `grill-with-docs`。\[[skills/skills/engineering/README.md at main · mattpocock/skills](https://github.com/mattpocock/skills/blob/main/skills/engineering/README.md?utm_source=chatgpt.com); [mattpocock/skills](https://www.skills.sh/mattpocock/skills?utm_source=chatgpt.com)\]

建議的具體對應：

| 使用者需求 | 優先復用能力 |
|--------|--------|
| 已有具體 Bug | `diagnosing-bugs` |
| 需要 Red→Green | `tdd` |
| 架構和術語混亂 | `domain-modeling` |
| 對照設計需求生成規格 | `to-spec` |
| 已有 Spec，要拆分任務 | `to-tickets` |
| 現有文件仍有重要未知條件 | `grill-with-docs` |
| 程式碼品質及變更審查 | `code-review` |

但不能因需要一項功能，就要求安裝或執行整套 Skills。

特別是 `grill-with-docs` 一類互動方法，需要增加「已知答案不得重問」的 SBL 適用性判斷，避免重新產生前輪 B1 的反覆授權及詢問問題。

第一版建議先支援 `diagnosing-bugs`、`tdd`、`domain-modeling` 與 `to-spec` 的方法級能力，其他保持可發現、條件啟用。

### 5.3 gstack：適合工程審查，不適合承接正式驗收權威

[![GStack 2026 Review: AI, Skills, Claude Code, Codex, User Experience and FAQs - ICON](https://images.openai.com/static-rsc-4/Avtd7LTi095d1XqN71DcXIqBWItQDdxTksAXYUKXfqxg_yXAamLKlkbfobey84kgXAeshPuAiZ2ArPUxwNJB3Oj43o_C9E865KkuDszPHnVRQaZDmV8_qJwwY6SelpMJXJ5EJoyeW_-QFabxW4Ym2DnLj3WYxOSRtv59tJOFLBdnM9CWcvnYEm8QZNgfQIAg?purpose=fullsize)](https://iconpolls.com/blogs/gstack-2026-review-ai-skills-claude-code-codex-user-experience-and-faqs)

**gstack**

建議地位：選擇性 Review／QA 方法來源

[官方 GitHub](https://github.com/garrytan/gstack?utm_source=chatgpt.com)

gstack 提供多種具體工程方法，例如 `plan-eng-review`、`review`、`qa`、`investigate` 和 `devex-review`。目前官方文件將 Codex Host 支援列為 experimental，而非與 Claude Code 完全同級的正式資格化。\[[GitHub - garrytan/gstack: Use Garry Tan's exact Claude Code setup: 23 opinionated tools that serve as CEO, Designer, Eng Manager, Release Manager, Doc Engineer, and QA](https://github.com/garrytan/gstack?utm_source=chatgpt.com); [gstack/README.md at main · garrytan/gstack](https://github.com/garrytan/gstack/blob/main/README.md?utm_source=chatgpt.com)\]

建議先復用：

- 工程可行性與隱藏假設審查；
- 對既有 Diff 找出實際缺陷；
- 可重播 QA；
- 故障調查；
- 使用者／開發者體驗的實跑審查。

**不建議將 gstack 的完整 Sprint、Ship 或 Autopilot 流程強制整合進新版 Skill。**

尤其不應讓 gstack 的 `/ship` 自動升格為 SBL 的 Release Authority，也不能將 gstack `/review` 直接當作 PIPD Independent Checker 的正式簽章。

這也符合現有 SBL DOC-04 的 `QUARANTINE` 和 PIPD DOC-08 的 `REFERENCE` 定位。

### 5.4 Spec Kit：保留複雜規格工作流，不應成為普通排錯的強制流程

[![GitHub Spec-Kit: Transforming Agile Roles and Development Practices | by Adnane Arharbi, Eng | Medium](https://images.openai.com/static-rsc-4/t7GJSeNKHcEOw48m-qOGmpsakiMbabnzJq-TMiVJ8A86hqJBA2a-U1QAyAsr2VudlJ6MqzzeEbUhw2Pxc35nsU52Fk1vpg3n3MyIBNAWMmAt5C8cuU6bpr5IHtsS2qm8bkc_d7DjK_LZnub0IkGIH9tz2ziz1ltm1NJPV-_CFdSIRC2pMlRzkbQ8WJeBH_gz?purpose=fullsize)](https://medium.com/%40aa.adnane/github-spec-kit-transforming-agile-roles-and-development-practices-60b75647d4af)

**GitHub Spec Kit**

建議地位：大型需求／架構／任務規劃的條件式工具

[官方 GitHub](https://github.com/github/spec-kit?utm_source=chatgpt.com)

Spec Kit 不只是單一完整 SDD 流程，目前官方文件亦提供獨立的 Bug Fixing 及 Idea Assessment 入口，而非強制所有需求依序通過同一條長流程。\[[GitHub Spec Kit](https://github.github.com/spec-kit/?utm_source=chatgpt.com)\]

建議使用條件：

- 大規模新產品功能；
- 跨模組架構變更；
- 需求不明確且必須規格化；
- 多團隊／多階段 Task DAG；
- 需要正式對齊非功能需求及驗收條件。

不建議用它處理每個簡單程式錯誤或單一 Skill 文案修補。

對已有 PIPD 契約的任務，Spec Kit 只能輸出適用的規格或任務候選，不能另立一份與 PIPD 並行的 Canonical Constitution。

### 5.5 GSD：保留 Context Engineering，但不導入第二套持久排程器

[![GSD - Get Shit Done | AI Coding Framework](https://images.openai.com/static-rsc-4/uiKEQJ4usidj912j4EkwyxcgHlgjb5zfLoz-IyLHSxfe081f-d9xH9jNwFBxsjW1LtpmuKkQ4MpBdxrHy6BQzal4FFE3BSs_7SYH0u6ZomM5JMcQB3Y7vrbUWz5NIMynYJbIzAeMP9SIDa9m1ZLnRCD2icxRIm3AwOQ7z5C09Y3h9Qcdc_0zw38pTC66ASa2?purpose=fullsize)](https://gsd.build/)

**GSD Core**

建議地位：Context／Checkpoint／Milestone 方法參考

[現行官方 GitHub](https://github.com/open-gsd/gsd-core?utm_source=chatgpt.com)

目前 `gsd-build/get-shit-done` 已聲明不再是活躍開發主庫，現行程式碼與維護轉至 `open-gsd/gsd-core`。

GSD Core 提供階段式開發、獨立 Context 的子代理、Plan／Execute／Verify／Ship 與跨 Session 的狀態管理，也提供 Codex 等 Host 的安裝路線。\[[GitHub - gsd-build/get-shit-done: A light-weight and powerful meta-prompting, context engineering and spec-driven development system for Claude Code by TÂCHES.](https://github.com/gsd-build/get-shit-done?utm_source=chatgpt.com); [GitHub - open-gsd/gsd-core: Git. Ship. Done](https://github.com/open-gsd/gsd-core?utm_source=chatgpt.com)\]

它對本專案的主要價值在於：

- 長任務 Context 分片；
- 階段 Checkpoint；
- 防止 Context 壓縮後遺失已完成工作；
- 里程碑與驗收前置關聯；
- 可重現的 Resume Plan。

然而，HGK／Hermes 已擁有規劃中的持久 Queue、Lease、WorkOrder 和恢復控制能力。

因此，**不應把整套 GSD Runtime 安裝成 SBL 的第二個持久工作管理系統。**

正確做法是只吸收其 Context Engineering 及 Checkpoint 方法，並將必要的資料映射至既有 HGK／Hermes 的合法狀態。

舊版 GSD 的歷史文件可保留為方法來源，新的實際採用需針對 GSD Core 重新進行版本、Host、權限和相容性驗證。

### 5.6 Superpowers 亦應保留

雖然問題沒有逐名列出 Superpowers，但它是 SBL DOC-06 既有六 Donor 之一，不應在重構時遺漏。

建議優先吸收它的：

`Design-first → TDD → Systematic Debugging → Verification-before-completion`

這組方法尤其適合 Codex 第一版工程。

但若同一工作已有 Matt `tdd` 或 `diagnosing-bugs`，應由適用性路由選擇一套主要工作流，不要兩者同時對相同工作施加重複流程。

---

## 六、如何保留完整開源能力，又不重新造成治理過重？

### 6.1 建立單一 Donor Capability Registry

**不建議將所有開源工具的 Skill 正文直接複製到新版 Commander-Skill。**

應保留一個輕量、版本化的能力索引，最少包含：

| 欄位 | 作用 |
|--------|--------|
| `capability_id` | 例如 `OS-02`、`MP-03`、`GT-03` |
| `donor_source` | 官方來源 Repository |
| `source_version` | 版本、提交、必要雜湊 |
| `native_capability` | 真正要復用的原功能 |
| `task_trigger` | 何時適用 |
| `non_trigger` | 何時不應啟用 |
| `host_support` | Codex／Hermes 等實際支持程度 |
| `admission_state` | METHOD\_ONLY／ELIGIBLE／ENABLED／NO\_FIT 等 |
| `required_permission` | 真正需要的權限 |
| `input_output_schema` | Adapter 資料契約 |
| `fallback` | 無法使用時的最低功能 |
| `disable_uninstall` | 停用、撤銷、卸載和殘留檢查 |

此 Registry 是工具能力索引，不是第二個 HGK Policy Registry。

正式權限及 Native Effect 仍由現有 Owner 決定。

### 6.2 以能力適用性，而不是品牌名稱選工具

建議採用下列選擇規則：

| 任務情境 | 主選方法 | 不應強制啟用 |
|--------|--------|--------|
| 既有規格小範圍變更 | OpenSpec Delta | 完整 Spec Kit／GSD |
| Bug 重現及修復 | Matt Diagnosing Bugs／Superpowers Debugging | 大型需求重訪 |
| 領域模型模糊 | Matt Domain Modeling | Native Issuer |
| 大型新功能 | Spec Kit 或 OpenSpec，依適用性選一主流程 | 兩套重複 Spec Compiler |
| 需要產品／工程審查 | gstack Review 方法 | gstack 全部發行工具 |
| 跨 Session Context 退化 | GSD 方法＋Hermes 原生 Checkpoint | 第二套 GSD Queue |
| 普通 Read-only Guidance | SBL 原生 Guide Skill | 全部六 Donor |
| Native 工作卡已待執行 | Hermes／HGK／Codex | 外部 Commander-SP |

這種方式同時保留完整產品能力與高效率工作流。

### 6.3 三種實際復用層級

建議對每個 Donor 決定最小足夠的整合方式。

**L1 - 方法參考**

只使用原始方法概念、技術模式及判斷程序。

例如 gstack 審查原則、GSD Context 分片。

不安裝完整工具。

**L2 - 原生 Skill／CLI 調用**

當 Host 已具備合法安裝及調用能力時，直接調用外部工具，再將輸出轉為 SBL 的非授權型別資料。

例如 OpenSpec `propose`、Matt `diagnosing-bugs`。

**L3 - 薄型 Adapter**

只有當現有工具輸出不能直接與 SBL／PIPD 對應，且已有真實使用需求時，才建立最小相容 Adapter。

不能為每一種外部技術都自造第二份 Writer、Parser、Scheduler、Checker。

這符合 SBL 的 **Search-Before-Build → Reuse Native → Wrap Thin → Extend Governed → Build Minimum**。

### 6.4 工具沒有安裝，不得因此讓整個薄 Skill 停止

這一條應作為新版 Skill 的重要防阻斷不變量。

例如使用者要求比較需求與現有設計：

即使 OpenSpec CLI 不在本機，Skill 仍可以基於已讀的合法來源進行比對，產出有來源的差異建議。

但應標記：

`METHOD_ONLY / TOOL_NOT_INSTALLED / NO_NATIVE_EXECUTION`

不能聲稱已透過 OpenSpec 完成實際驗證。

反過來，如果任務明確要求執行 OpenSpec CLI，而該能力不存在，就需要只對受影執行項返回 `NO_FIT` 或具體 HOLD。

**工具缺失不應阻斷其實不依賴該工具的工作。**

### 6.5 防止 OpenSpec／Spec Kit／GSD 再次變成大型治理堆疊

《FHS-MSC\_總討論》已有明確的收斂裁決：

- OpenSpec：條件採用；
- gstack：選擇性復用 Review；
- Spec Kit／GSD：暫緩擴大；
- Hermes Kanban／Delegation：必要時直接復用；
- 不引入第二個持久流程框架或政策引擎。

這不是取消這些 Donor，而是避免目前 SBL／HGK 已有能力的重複實作。

因此新版 Skill 應**保留工具路由與可用性，不把所有 Donor 都變成 Mandatory Invocation**。

---

## 七、新版 Skill 的完整實作與驗收分期

| 階段 | 主責 | 工程內容 | 退出條件 |
|--------|--------|--------|--------|
| P0：Baseline | Codex | 固定現行 SBL／PIPD 來源、原 Skill 功能、技術槽位 | 保留項與變更項完整對照 |
| P1：Architecture | Codex | 外部 Guide／內部 PLAN 分權，權限和 ABI 定義 | 不存在雙重 Writer／Issuer |
| P2：Thin Skill | Codex | `SKILL.md`、Reader、Guidance Schema、NO\_EFFECT | 靜態及負例通過 |
| P3：Donor Integration | Codex | 24 Slot Registry、條件路由、最小 Adapter | 不強制安裝全套工具 |
| P4：Local Validation | Codex | 真掛載、觸發、非觸發、Source 與權限回歸 | 目標 Codex Host 有真實證據 |
| P5：Native Integration | Hermes／HGK | Proposal Handoff、PLAN Role、WorkOrder 接線及權限 | 真 Native 入口具備有效收據 |
| P6：Autonomous Recovery | Hermes／HGK | Lease、Resume、阻塞 A／B/C 續行、Restart | 跨程序合法自主恢復 |
| P7：Repair | Codex | 受影 Red→Patch→Green→Regression | 受影錯誤修復、無回歸 |
| P8：Qualification | 獨立 Checker | 同版本、正反例、Host 生效、權限分離 | 正式資格化收據 |
| P9：Delivery | 授權 Publisher／Owner | 版本、安裝／卸載、回復、來源與交付 | 發布權責及驗收條件通過 |

上述階段不表示每次都須依序完成 P0～P9 才能交付任何成果。

新版薄 Skill 可以先完成 P0～P4 的 **Codex Host 候選資格化**。P5～P6 是與 Hermes／HGK 的 Native 整合驗收，不應阻礙不依賴 Native 的合法初版功能。

P8～P9 則依實際交付類型判定需要的正式資格化。

### 7.1 「自修補、自迭代、自驗收、自交付」應如何定義？

| 自動化能力 | 可以自動化的範圍 | 不得冒稱的事項 |
|--------|--------|--------|
| 自建置 | 依受限 WorkSet 寫入候選 Skill／Adapter | 已經正式發布 |
| 自檢測 | 單元、整合、觸發、非觸發、Host 測試 | 不同 Principal 的獨立驗收 |
| 自修補 | 依 FirstFail 進行最小修改與回歸 | 無限制修改 Repo |
| 自迭代 | 依測試結果及成本約束修正候選 | 無條件無限重試 |
| 自驗證 | 自動收集 Raw、版本及測試收據 | Maker 自簽 Independent PASS |
| 自交付 | 產生版本化候選、Manifest、說明、回復資料 | 無權的正式 Release |

這種分離是提升高自動化可靠性，而不是新增不必要的人類審批。

### 7.2 建議必須實測的 20 個防回歸項目

| ID | 測試目標 | 必須達成 |
|--------|--------|--------|
| T01 | 無 Frozen PI／PD 的只讀 Bootstrap | 可以合法診斷，不全域停工 |
| T02 | OWNER 已有有效授權 | 不重複索要 |
| T03 | 新 Skill 唯讀行為 | 零未授權副作用 |
| T04 | Skill 觸發 | 正確匹配任務 |
| T05 | Skill 非觸發 | 無關工作不自動啟動 |
| T06 | 舊 Commander-SP | 不被意外載入或間接觸發 |
| T07 | OpenSpec Diff | 真 Root／非零受測集合／來源一致 |
| T08 | Matt Skill Routing | 不選錯、不重問已回答事項 |
| T09 | Spec Kit | 不覆寫 PIPD Canonical |
| T10 | gstack | Review 不冒充 Checker |
| T11 | GSD | 不建立第二 Durable Queue |
| T12 | Superpowers TDD | 真 RED→GREEN→回歸 |
| T13 | 缺少 Donor | 合法提供方法級 Fallback |
| T14 | Donor 安裝 | 真版本、權限及 Host Loaded |
| T15 | Donor 卸載 | 觸發消失、配置與敏感資料無不當殘留 |
| T16 | Guide→PLAN Proposal | 不自行簽發 WorkOrder |
| T17 | Hermes Worker 中斷 | Durable 工作可安全恢復 |
| T18 | Native Permit 失敗 | 只 PARK 受影工作 |
| T19 | Maker／Checker 隔離 | Self-Acceptance 被拒收 |
| T20 | 最終交付 | Candidate、Qualified、Released 狀態精確區分 |

其中 T07 必須額外注意《FHS-MSC\_總討論》記載的 OpenSpec 歷史假綠問題：錯誤 Root 或零受測項時，即使工具退出碼為零，也不能視為測試成功。

正確驗證至少應檢查真正 Root、實際測試項數量、受測主體及退出碼。fileciteturn0file23L288-L304

---

## 八、開源工具的安裝與供應鏈治理，不應被「極輕治理」取消

治理應輕量，但不能直接從任意網路來源安裝並執行具有本機操作能力的第三方工具。

建議最小准入程序：

`Official Source → Version/Commit Pin → License/Dependency Check → Isolated Install → Positive/Negative Test → Host Load → Disable/Uninstall Test`

尤其應避免：

- 將所有六 Donor 一次性全域安裝；
- 讓 Installer 任意覆蓋 `AGENTS.md`、Host Config、既有 Skills；
- 直接執行尚未審閱的安裝腳本；
- 將方法論 Donor 自動加入系統啟動流程；
- 在模型 Provider 切換時，無政策判斷地傳送私有來源；
- 將「工具在 GitHub 存在」誤當「本機已安裝且已調用」。

例如 OpenSpec 官方現在對 Codex 和 Hermes 提供不同的 Skill 載入配置，不能只把文件複製到任意目錄就宣稱兩個 Host 都已有效掛載。\[[OpenSpec/docs/supported-tools.md at main · Fission-AI/OpenSpec](https://github.com/Fission-AI/OpenSpec/blob/main/docs/supported-tools.md?utm_source=chatgpt.com); [Supported tools](https://openspec.dev/docs/supported-tools?utm_source=chatgpt.com)\]

同樣地，gstack 的 Codex 支援仍需按其實際宿主相容性驗證，不能用 Claude Code 的有效安裝證據替代 Codex 的 Host Readback。

**最低權限、版本釘選、真正觸發和可安全卸載，是必要的供應鏈控制，不屬於應刪除的過度治理。**

---

## 九、最後的工程推薦與決策

### 9.1 如果目前目標只限「新版薄 SBL-Commander-Skill v1」

**推薦：Codex 直接建置及迭代，較具工程效率。**

採用隔離 Worktree、最小 Skill、24 Slot 的按需方法索引及自動測試。

不需要先等待 Hermes／HGK 完整 Native Acceptance。

第一版應能實際完成：

- 設計原意比對；
- 工程裁決建議；
- FirstFail 診斷；
- 已有授權的適用性整理；
- OpenSpec／Matt／Spec Kit 等工具按需選用；
- 有界 Proposal；
- 真 Codex Skill 掛載與觸發；
- 回歸與自動修補。

**正式交付資格取決於相應的獨立與 Host 驗收，而不是 Codex 的自測聲明。**

### 9.2 如果目標還包括「內部 SBL Commander／PLAN 正式高自動化」

**推薦：Codex＋Hermes/HGK 分工，不適合 Codex 單獨完成。**

Codex 可以實作 Adapter、測試與程式碼修補。

但是：

- 真 Durable Queue；
- 多子代理原生派工；
- 模型車道；
- Native WorkOrder；
- Lease／Heartbeat；
- 自動恢復；
- 原生 Permit；
- 外援撤銷後自主接管；

仍應由真正的 HGK／Hermes Runtime 完成實測。

### 9.3 開源技術最終導入裁決

| 工具 | 新版 Skill 建議狀態 |
|--------|--------|
| OpenSpec | **優先評估整合** |
| Matt Pocock Skills | **按需精選整合** |
| Superpowers | **優先復用 TDD／診斷方法** |
| Spec Kit | **條件式規格／任務整合** |
| gstack | **先保留 Review 方法，整包安裝待准入** |
| GSD Core | **保留 Context／Checkpoint 方法，不導入第二 Scheduler** |
| PIPD-LS-SP | **維持唯一 Canonical 契約權威** |
| Hermes／HGK | **維持唯一正式 Native Work Authority 與持久協調** |
| Codex | **主要實作、修補及工程測試工具** |

### 9.4 最終結論

新版 SBL-Commander-Skill 的正確發展方向，是**先把它做成一個真正精簡、可測試、可攜、無不必要治理負擔的工程引導 Skill**。

第一版應讓 Codex 發揮直接讀取程式、修改 Skill、建立測試、快速 Red／Green 與局部修補的優勢。

Hermes／HGK 則應用在它真正不可替代的原生高自動化能力，而不是成為薄 Skill 第一版的沉重前置。

對外部開源工具，最重要的是**保留已規劃的全部 24 個能力身份，按需求復用原生功能，按真實價值建立薄 Adapter，並禁止重新創造重複的 Compiler、Scheduler、Issuer 和 Checker**。

如此才能同時達成：

**低治理阻力、高自動化、單一 OWNER 適配、充分復用成熟開源工具、保留正式安全權威，以及可被真正驗收的工程交付。**

本報告屬設計及工程策略鑑定，已交叉核對上傳的 SBL／PIPD／FHS-MSC 文件及開源專案公開資料；未操作本地 Codex、Hermes、HGK，未安裝 Donor 或掛載舊 Commander-SP，亦未執行新版本的 Host Acceptance。以上是建議施工與驗收契約，並非已完成工程的聲明。



---
Powered by [ChatGPT Exporter](https://www.chatgptexporter.com)