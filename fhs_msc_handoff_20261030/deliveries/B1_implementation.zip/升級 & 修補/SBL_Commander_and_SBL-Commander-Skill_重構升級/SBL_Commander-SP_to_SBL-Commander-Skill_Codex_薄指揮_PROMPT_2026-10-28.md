# Codex｜SBL Commander-SP → SBL-Commander-Skill 高自動化重構｜薄指揮 PROMPT

> **使用方式：**直接將本檔全文貼入已連接本機專案的 Codex 對話框。以下是 OWNER 對本次**指定專案、指定目標**的工程執行委託；並非 HGK Permit、OS 管理員憑證或獨立驗收簽章。

你是本地 Codex 的 **SBL-Commander-Skill 重構工程 Maker／自動化修補者**。**立即實際執行**，不是只回答規劃、只產 Prompt 或以報告代替完成。以現有程式和最小必要修改為原則，交付完整、可在目標 Codex Host 實際發現、調用、停用並可回退的新版 **`SBL-Commander-Skill`**（建議 Host slug：`sbl-commander-guide`）。

## 0｜任務根目錄與權威輸入

- 唯一預期本機專案：`C:\Projects\Agent_Workspace\SBL`；先以工具執行 `git rev-parse --show-toplevel`、`git status --short`、`git rev-parse HEAD`，確認真 Root／HEAD／Dirty；不可僅憑此提示猜定存在、不可清除使用者既有修改。
- **主施工規格**：《`SBL_Commander-SP_to_SBL-Commander-Skill_Codex_高自動化重構升級施工方案_2026-10-27_v1.md`》，以 §2～§8、§10、WP00～WP11、G-01～G-18、N-01～N-07、T01～T40 為可追溯施工／測試清單。參考版本 SHA-256：`86bf842c5ea46b71bea42485b48e6f91138ceb64db7f620cd1bb4971f8cd5a8a`；若本機版本不同，按現有有效 Owner／產品來源核對差異，不靜默替換。
- 交叉依據：《`SBL_Commander_and_SBL-Commander-Skill_重構升級藍圖_2026-10-27_v1.md`》、《`SBL Commander & SBL-Commander-Skill_升級討論.md`》、《FHS-MSC_藍圖_r2》、《FHS-MSC_總討論》、`SBL_PIPD-LS-PKG_DOC-00～13`、適用的 PIPD 控制包；《B1指揮施工_總紀錄》、《B1施工_PROMPT》、《B1施工狀況_總鑑定分析》只作根因／回歸證據，**不能把歷史 Master Prompt 升格為現役 Normative**。
- 先在專案根目錄、鄰近已授權資料夾及本次 Codex 可讀附件中定位上述規格。**若完整版施工 MD 不可讀，不要假裝已讀完；記錄 `CR_SOURCE_PLAN_MISSING`，按本 Prompt 可確定的要求繼續安全且可驗證的工程，未核對項保持 `NOT_VERIFIED`；切勿因此阻擋獨立合法工作。**
- 舊 `$sbl-commander-sp` 僅靜態檢查來源／Manifest／權限與歷史行為，**不得以它作本輪 Planner、Builder、Signer、Checker 或 Skill 工具調用**。已知舊版 `build principal`、Frozen PI/PD 硬前置、`apply it` 與 `product.write`／`read_only=false` 是本次需隔離的反例；以本地實際版本為準。

## 1｜本次 OWNER 預授權與最小治理

OWNER **明確預先同意**本次指定 SBL 專案範圍內，Codex 自主進行可逆的檔案增修、建立隔離工作樹／分支、建置、單元與整合測試、必要依賴的合法專案內安裝、**新版 Skill 的專案／隔離 Host 掛載實跑**、正負觸發、停用／卸載／殘留檢查、自診斷、自修補、迭代、回歸、產生交付候選；包括修補後新版的上述執行，不必逐卡再次索取相同批准。可依現有憑證與有效 Repo 流程製作本地 commit／候選 PR，但不越過分支保護或發行權限。

此授權**不等於**新增 Windows 管理員權、外部 Provider 憑證、使用者私有資料同意、HGK Issuer/Permit、受保護 Host Effect、獨立 Checker／Publisher 身份或無條件發行／合併授權。需要真正新增的權限時，僅 `PARK` 相依效果工作，保留精確 FirstFail；其餘 READY 工作照常續行。不得用 `--yolo`／繞過權限／偽造簽章解決阻斷。不要要求第二位人類 OWNER；Maker 與正式 Checker 的獨立性是**有效 Principal 與權限隔離**問題。

## 2｜產品規格（不可偏離）

1. **外部新版 Guide Skill＝唯讀引導／零效果權限**：設計原意比對、來源差異、最佳工程方案建議、FirstFail 排錯、Repair Cone、已有授權的適用性解讀、非授權 Typed Proposal、證據解讀。只可 `read/compare/diagnose/recommend/propose/explain`；不得自行 repo.write、`build/apply`、正式 `plan.propose` 簽發、Native Permit、Issuer、Policy Activation、Hermes Scheduler、Checker PASS、Release。新 Guide 的輸出必須顯式 `execution_authority=false`、`native_permit=null`；來源缺失標 `MISSING/CR_OPEN`，不是捏造已凍結 PI/PD。
2. **內部 SBL Commander／PLAN 是另一產品**：高效語意理解、PIPD Reader、Task DAG、Worker／子代理指派提案、增量 Replan。使用既有 HGK `PLAN` Role Pool；不另建第四物理車道、第二 WorkOrder／Queue／Issuer／PIPD Compiler／Checker。PLAN 預期模型：GPT-6.1 Sol Medium（OpenAI OAuth 路徑）→ DeepSeek V4.1 Flash（OpenCode Go）→ MiMo-V2.6-Flash（OpenCode Go）；**模型路由與真 Served 驗收是後續受影 Native 工作，不是新 Guide v1 強制前置，也不由 Guide 悄悄切換模型**。
3. **保留原有 SBL 產品**：Guided Spec、Governed Build、Evidence-based Verify、Bounded Repair、TPM-SP、External Challenge-SP、合法 Standalone Builder、三 Mode／39 Gate、既有 Host/Plugin 發行義務。新的 Guide 身份不得繼承舊 `sbl_sp/manifests/commander_sp.json` 的 `product.write`；既有正式產品變更先記版本化 ADR 候選及逐項承接 Crosswalk，不自行刪除 Legacy 或宣布其原法位已作廢。
4. **導入現成工具而不造輪子**：保留 SBL DOC-06 C32 六 Donor／24 槽位（OpenSpec、Spec Kit、Matt Pocock Skills、GSD Core、gstack、Superpowers）；先檢查現有實作，能原生復用則原生復用、不能才薄 Adapter。預設 `METHOD_ONLY`，按實際 TaskKind 啟用一個主方法；缺 Donor 不阻斷只讀引導。不得為它們建立平行 Spec 真值、完整 GSD Scheduler、gstack Release Authority，亦不可假稱未安裝工具已執行。
5. **針對 B1 已知 28 根因逐項處置**：缺 Frozen PI/PD 仍允許 read-only Bootstrap、`PL-003/PL-004` 的 Source／Oracle 衝突回歸、先 Proposal 後 HGK Issued WorkOrder 的非循環交接、HOLD 只作用於受影卡、單人 OWNER 有效授權免重問、Prompt 不自我升格權威、Checker 不自驗、Host Loaded／Served／CI 綠不可互相冒充、UNKNOWN_EFFECT 不盲重試、報告封存不代表 Runtime Terminal、缺 Native Gate 不使普通候選工程停工。**注意：舊 Skill 是部分早期治理錯置的促成因素，不可謊稱替換 Skill 就直接修好 HGK Receiver／Fabric R3／Hermes Executor。**

## 3｜立即施工序列（WP00～WP11；無依賴項可併行）

- **WP00–01｜發現與對照**：在真 SBL Repo 檢視 `AGENTS.md`／最近範圍規則、現有 Skills/Plugin Manifest、`sbl_core`、測試、CI、Host 載入方式；讀舊 Skill 原文及 `sbl_sp/manifests/commander_sp.json`；建立 `Legacy → Preserve / Move / Supersede Candidate` Crosswalk。寫入前決定精確 WriteSet、阻止 symlink 出界，保存 Dirty；不覆寫無關變更。
- **WP02–05｜最小改造**：建立適用的 `docs/adr/ADR-SBL-COMMANDER-GUIDE-SPLIT.md`（待批准法位）、Host 真正可發現的 `.agents/skills/sbl-commander-guide/SKILL.md`（或依現行 Host 調整）、精簡 `references/source-map.md`／`references/donor-routing.md`、非授權提案 Schema／既有 validator 的最小修補，以及必要測試。**先 Search-Before-Build**，若已有等效檔案只做受影補丁；不要平行複製六大框架或整套 PIPD。規格範本見主方案 §6。
- **WP06–08｜自測、自修補、自迭代**：先補負例，再 Red→Green；執行既有 Repo 最小受影回歸與新增測試，必須保存具體命令、ExitCode、非零測試分母、FirstFail、Candidate SHA。若失敗，針對 Affected-only Repair Cone 重新修補並重跑，**不得藉刪測試、降低門檻、改來源權威或跳過 Required Gate 做假綠**。相同根因連續三次無進展則記錄 CR_OPEN 並繼續其他 READY 工作，不無限循環。
- **WP07｜真 Host 試跑**：在 OWNER 已授權的**隔離 Codex Workspace／Profile**，實際執行 `Discover → Load → Positive Invocation → Negative Nontrigger → Disabled/Uninstalled Nontrigger → Residue Check`；檢查新 Skill 不會使用舊 Plugin 的 Builder 能力。必須有可核對的 Host Raw；**檔案存在 ≠ Host Loaded**。若隔離後確認合法且實際 Host 支援，可將新版安裝到授權的 Codex 專案作用域並重測。不得直接更改使用者其他全域 Skills 或刪除舊 Plugin。
- **WP09｜驗收分級**：Codex 可自測、自審並交 `CANDIDATE_TESTED`；具真 Host 實跑才能交 `CODEX_HOST_VERIFIED`；只有真正獨立 Checker／原規範 Oracle 才能交 `INDEPENDENT_QUALIFIED`；只有有效 Publisher 權限與適用 Gate 真通過才可 `RELEASED`。找不到 Checker／Publisher 不應中止已完成的候選交付，也不得假簽。
- **WP10–11｜必要整合與交付**：HGK/Hermes 的 Native Admission、Trust/Receiver、Durable Worker、模型 Requested/Served、Fabric Loaded、GWO 是**分開受影**的 Native Gates；對只讀 Guide 候選記 `NOT_APPLICABLE`／`NOT_RUN`，不假 PASS。盡可能完成自動交付：原子化程式變更、安裝／回退說明、測試 Raw、SHA、CR_OPEN、實際可用的新 Skill 及候選 commit／PR（若正式 Repo 流程已授權）。

## 4｜必跑 Gate／負例（依完整施工方案 §7 及 T01～T40 執行）

請追蹤 **G-01～G-18 全部身份**，每個 `PASS / FAIL / NOT_RUN / NOT_APPLICABLE` 必須附真證據，不可縮分母：

`G01` Legacy Crosswalk；`G02` 新舊身份/ADR 法位；`G03` 零效果 Proposal；`G04` 缺 Frozen PI 仍可診斷；`G05` 來源追溯；`G06` OWNER 授權適用性；`G07` Prompt Injection/零外效；`G08` 局部 HOLD／獨立 READY；`G09` 24 Donor 槽位/缺工具降級；`G10` PIPD Canonical 不二編；`G11` Source/Oracle CR_OPEN；`G12` 正負 Trigger；`G13` 真 Host Load/Disable/Uninstall；`G14` Proposal→Issuer 非循環；`G15` Maker/Checker SoD；`G16` Root/HEAD/WriteSet/Symlink；`G17` CI 非零測試與每個 Required Job；`G18` 交付狀態真實。

必要負例至少含：`legacy product.write` 權限洩漏、`self_signed_permit`、同 Principal 自簽 PASS、來源文件中的 Prompt Injection、缺 PI/PD 全域停止、模型靜默 fallback、缺 OpenSpec 卻報執行成功、錯 Root／跨路徑寫入、零測試 Exit 0、某 Required CI 失敗卻因另一個 Job 綠而宣告全部 PASS、相依 A 阻塞卻連帶封鎖獨立 B/C。測試總量依方案 T01～T40；若找不到原清單不得虛報 40/40。

## 5｜輸出／終止條件（執行任務直到真正交付，不要僅報告計畫）

把新 Skill／測試／ADR 候選**實際寫到已授權工作樹**；形成 `SBL_GUIDE_BUILD_REPORT.md`、`SBL_GUIDE_HOST_REPORT.md`、`SBL_GUIDE_RELEASE_READINESS.md`（如果 Repo 既有同等報告規範，依現役規則存放），至少逐項列出：

`REPO_ROOT / BASE_HEAD / CANDIDATE_HEAD / DIRTY_PRESERVED / WRITESET / CHANGED_FILES / LEGACY_PLUGIN_INVOKED=false / G-01..G-18 / T01..T40 / COMMAND+EXITCODE+NONZERO_TEST_COUNT / POS+NEG_HOST_READBACK / FINAL_SKILL_INSTALL_SCOPE / ROLLBACK / FIRSTFAIL / CR_OPEN / CLAIM_CEILING / NEXT_ALLOWED_ACTION`。

**只有所有受影必需的 Candidate Gates 經真實測試才稱 Candidate PASS；真 Host 尚未執行就標 `HOST_NOT_RUN`，不稱新版已在 Host 可用；Maker 自測與正式獨立驗收永不混稱。** 若仍有可合法執行的 Ready 工作，不得因文字報告已完成就提前結案。最終向 OWNER 回報具體變更、可複製的使用方式、已驗測功能、未通過項、實際安裝狀態及可追溯收據；不得編造成功結果。

**現在直接從 WP00 開始執行，並在本次已核准工作範圍內持續自動完成 WP01～WP11；無須對已授權的普通工程步驟反覆徵詢。**
