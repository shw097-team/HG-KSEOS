# SBL Commander & SBL-Commander-Skill｜重構升級藍圖

> **日期：**2026-10-27（Asia/Taipei）  
> **文件版本：**`v1.0-DESIGN-CANDIDATE`  
> **工程裁決：**`FAIL-CLOSED`（**正式釋出／Native Acceptance**）；`DESIGN_REPAIR_PROPOSAL_READY`（本藍圖可作下游候選施工輸入，**並未取得正式 SourceFreeze／Owner Ratification**）  
> **核心結論：**以 **Codex-first 薄 Guide Skill + 既有 HGK PLAN 車道之內部 Commander + Hermes 持久執行 + PIPD Canonical + Fabric Policy + 獨立 Checker**，替代舊 Commander-SP 全域主控；保存六 Donor／24 方法槽位，採最小足夠的按需原生復用，不另建第二個 Issuer、Queue、Compiler 或 Release Authority。  
> **禁止誤讀：**本次沒有操作 Windows Host、沒有安裝或掛載舊 `$sbl-commander-sp`、沒有修改 Repo、沒有取得 Native Receiver／Issuer／Checker 的新收據。本文件及範例代碼**不是**有效 Permit、Release 或已資格化系統。

## 0.0 讀者卡：立即裁決與實施界線

| 議題 | 推薦裁決 | 依據 | 現在可以做 | 不得宣稱 |
|---|---|---|---|---|
| 外部 Commander-SP 重構 | 拆分成只讀 `SBL-COMMANDER-GUIDE`；Skill 優先，Plugin 非必需 | `SBL DOC-04 C12.4.3`；`PIPD DOC-08 §9`；升級討論 §三、§七 | 有界候選、Schema、Fixture、隔離測試 | 舊 Plugin 產品義務已正式撤銷 |
| 內部 SBL Commander | `HGK.PLAN.SBL_COMMANDER` 角色池，不增第四物理 Lane | `FHS-MSC_藍圖_r2 §5.2`；總討論三車道決議 | PIPD Reader、Task DAG、Replan 的候選 Adapter | 取代 HGK Issuer／Hermes Scheduler |
| 初版施工 | Codex-first；Hermes/HGK 適用於原生整合及長任務 | 升級討論 §二、§三、§七；B1 handoff §0 | 在真授權的隔離 Worktree 製作候選 | Maker 自檢即正式 Acceptance |
| 模型 | PLAN 主選 GPT-6.1 Sol/Medium，備援 DeepSeek V4.1 Flash、MiMo-V2.6-Flash | `FHS-MSC_總討論` 模型矩陣；供應商官網 [W09][W10] | 配置「期望」路由、做 Served 實測 | OAuth 已有本地資格化或靜默降級合法 |
| 開源工具 | 六供體 24 方法身份保留，按適用性導入 | `SBL DOC-06 C32`；`PIPD DOC-08` 技術准入 | 盤點、版本鎖定、隔離檢測 | 六套全部已可用或都必須安裝 |
| B1 現況 | 與新 Commander 重構雙軌解耦 | B1 handoff §0、§1；B1 DOC-08 | 合法普通工程可持續、受影 Native HOLD 局部 PARK | T2/R3/R4/G-A/GWO/G-B 已 PASS |

> **判準語意：**`FAIL-CLOSED` 在本報告只阻斷 **發布、未經授權的 Native 效果與正式驗收聲明**；不阻斷已授權、無此依賴的只讀診斷及隔離候選施工。此分層用以消除 B1 已知的 Global-HOLD 反模式。[N:B1-00 §§1–6][N:B1-02 效果分類][N:PIPD-05 權限／Receiver]

## 1. Inputs Manifest、覆蓋方法與證據法位

### 1.1 本輪證據處理的實際界線

1. **直接可讀：**目前對話可見內容、單獨提供的《SBL Commander & SBL-Commander-Skill_升級討論》2650 行全文，以及 `/mnt/data` 中所列的 40 份歷史 SBL/PIPD/FHS/B1 Markdown 檔。已以嚴格 UTF-8 讀取、計算位元組 SHA-256、行數；詳見附錄 A 的**實際檔案清冊**。這是本環境讀取事實，不是 Windows Host SourceFreeze。[E:INV]
2. **舊 Plugin 靜態描述：**直接讀取安裝目錄中 `skills://plugins/sbl-commander-sp/commander-sp/skill.md` 的**說明文字**，未執行、未掛載、未呼叫它的建置流程。其 `build principal`、Frozen PI/PD、`apply it`、`HOST_PENDING` 均為可核內容。[E:PLUGIN-STATIC]
3. **間接資料：**B1 r1–r10 執行、宿主、CI 與 PR 歷史，多數是紀錄轉述；除具原始證據可重算外只視為 `REPORTED`。不能把文件多次引用計為多次獨立測試。[N:B1 handoff §0–§6]
4. **Web：**開源官方 Repo／產品文件、Agent Skills、GitHub Actions、OpenSSF、OWASP、SLSA、社群經驗；只提供 **SUPPORT**，不能取代本案 NORMATIVE。Web 文獻發表與擷取時間不同；需在真正安裝時重新固定提交。[W01–W20]
5. **未取得：**Windows 真 HGK Root/HEAD/Dirty、現役 Hermes Executor、Trust Registry、模型完整 Served Receipt、Verifier 分權原始證據；均進 CR_OPEN，正式 Release 仍 HOLD。[N:B1 handoff §0][E:CR]

### 1.2 權威堆疊

| 順位 | 來源／責任 | 使用方式 | 特殊處理 |
|---|---|---|---|
| A0 | 本次使用者明確任務／不掛載舊 Plugin、一次性交付 | 定義本報告目標、交付格式與禁用範圍 | 不等於 OS／HGK 服務端新簽署 Permit |
| A1 | 原有效 SBL／PIPD／FHS-MSC 的所屬 Owner SSOT（按各自法域） | 原設計意圖、Source、PI/PD/ECP/TQAEP、角色、技術不變量 | 多個法域不能以一個「最新日期」強行互蓋 |
| A2 | B1 DOC-00～08 已批准適用的施工控制與有效變更 | B1 受影 WorkOrder、Gate、GWO、停損 | r3 文件自標 `task_kind: DESIGN`、`formal_sourcefreeze: HOLD`，不得假裝已 Ratified |
| A3 | 2026-10-27 Owner 指揮紀錄及《升級討論》新方向 | 本輪提出的重構偏好、禁令與策略、後續 ADR 候選 | 歷史 AI 答覆不是 Canonical Writer／Policy |
| S1 | 舊 Commander-SP 靜態 Skill／B1 執行報告 | 歷史根因、反例與待替代產品身份 | `HOST_PENDING` 不具已生效法位 |
| S2 | Web、社群與專業研究 | 外部兼容性、最佳實務和候選工具 | 不得 override A1/A2；需本機另驗 |

**衝突處理：**先確認 Source 的**法域、Owner、版本、effect class 和 claim ceiling**；同一法域同一效力條款衝突時，不以自然語言猜測解決，登記 `CR_OPEN` 並阻斷**受影的** Release/Native Effect。普通無關工作繼續。[N:SBL DOC-04 R01][N:PIPD DOC-01 §Authority][N:B1-00]

### 1.3 主要來源定位表（Inputs Manifest 摘要）

| 檔名／來源 | 角色 | 精確定位／關鍵句 | 本輪狀態 |
|---|---|---|---|
| 本頁對話與歷次助理分析 | NORMATIVE（使用者指示）＋SUPPORT（AI 分析） | 四次角色／任務目標、Commander-SP 歸責、雙分工、Codex-first／開源復用 | FOUND；原始對話字節未獨立封存 |
| 《SBL Commander & SBL-Commander-Skill_升級討論》 | User decisions + historical SUPPORT | L16–23、L87–143、L1018–1043、L1154–1194、L1933–1941、L2000–2039、L2184–2225 | FOUND；2650 行 |
| `$sbl-commander-sp` 靜態 Skill | SUPPORT／實作意圖；非有效 Native | `# Commander-SP`／`You are the build principal`／Frozen PI/PD；`HOST_PENDING` | FOUND（只讀）／NOT_MOUNTED |
| SBL DOC-00～13 | NORMATIVE **設計候選**（按 Owner／版本） | DOC-04 C12.4.3、DOC-06 C32、DOC-07 權限、DOC-08 Checker、DOC-10/12 Host、DOC-13 回歸 | FOUND；14 冊；非 SourceFreeze |
| 《FHS-MSC_藍圖_r2》 | NORMATIVE 設計候選 | §5.2 三實體 Lane；SBL/TPM/Challenge 三 SP；唯一 HGK Plane | FOUND；未宣稱 Native Loaded |
| 《FHS-MSC_總討論》 | 決策脈絡／SUPPORT | Commander/PLAN 模型矩陣，`session_model != lane_model != served_model != credential_identity` | FOUND |
| B1 DOC-00～08 | NORMATIVE B1 設計控制包 | DOC-00 §§4/6、DOC-02 31 WO/OBS、DOC-05 120/124/38、DOC-06 949/192/81、DOC-08 3 GWO | FOUND；r3 DESIGN/正式 HOLD |
| 《B1指揮施工_總紀錄》 | 歷史執行證據 | 最初 2026-10-26 23:17 Commander 採用；r1～r10 決議；後續禁令 | FOUND／非驗收 |
| 《B1施工_PROMPT》 | 歷史指揮候選 | r1～r10 指揮文字、SourceFreeze/TaskKind/Oracle、Native Gate | FOUND／非執行證據 |
| 《B1施工狀況_總鑑定分析》 | 歷史 RCA／SUPPORT | `PL-003/PL-004`、全域 HOLD、自動恢復缺口、Maker/Checker | FOUND／含轉述 |
| 《FHS_MSC_B1_Task_Handoff_Report_v1_2026-10-27》 | 最近 B1 狀態紀錄 | §0：T1 PASS（r9）、R1/R2 PARTIAL、T2/R3/R4/G-A/GWO/G-B 未通過、Native PASS 0 | FOUND／實機未重驗 |
| PIPD DOC-00～09 | NORMATIVE PIPD 設計（本法域） | DOC-01 Authority、DOC-02 Contract Compiler、DOC-03 Binding、DOC-05 Admission、DOC-07 Oracle、DOC-08 Adapter、DOC-09 CI | FOUND／按受影適用 |
| 舊宿主真正 Repo／Host/Signer/Checker/Model Receipts | REQUIRED Live Evidence | 需 Root、SHA、Principal、Raw Readback 及對應 Checker；本次不可取得 | **MISSING → CR_OPEN** |

> 完整逐檔 Bytes／SHA-256／Lines Manifest 在附錄 A。以上「FOUND」代表本輪有檔案位元組，**不代表**該檔案的設計宣告具有正式 Ratification。來源全文很大；依索引、標題、定位句進行受影條款對照，未聲稱對每一來源條款完成新的語義 Coverage Ratification。[E:INV]

## 2. 現況鑑定與失效因果樹（RCA）

### 2.1 已知演進時間線

| 階段 | 事實或記錄結果 | 歸因法位 |
|---|---|---|
| 2026-10-26 23:17 | 最初 GPT-6 指揮以舊 Commander-SP + Knowledge Packs + CAPC 為方法 | 歷史指揮紀錄 [N:B1 CMD] |
| r1／r2／r3／r4 | Frozen Source／TaskKind／Oracle 等前置被搬入全域施工契約；`PL-003`、`PL-004`、`SOURCE_COMPILER_HOLD` | 編譯拒收由 Contract Mapping 直接造成；Skill 是促成、非證實唯一程式根因 [N:B1 Analysis] |
| 2026-10-27 02:47 之後 | OWNER 要求禁用舊 Commander-SP、改薄指揮；r5～r10 仍有 Native 端缺口 | 禁令與後續停滯的反事實證據 [N:B1 CMD/Prompt] |
| r7～r9 | 逐步實作 SharedSpine／部分 HGK/SBL 候選和 Windows Scheduler | 局部工具與測試；不等於 Hermes Native Executor [N:B1 handoff §0] |
| r10 | PIPD CE-2 修補、HGK User Trust 局部測試；Receiver 接線、R3/R4 真實執行、G-B 未驗 | `PARTIAL_WITH_EXPLICIT_HOLDS`／`native_artifact=false` [N:B1 handoff §0] |
| 2026-10-27 晚間 | 決定 Skill 降格 Guide，內部 Commander PLAN，Codex-first + HGK-native qualification，保留開源 24 Slot | **新設計方向**；待 Owner ADR 生效 [N:升級討論 L1018–2650] |

### 2.2 根因樹：症狀 → 機制 → 直接／間接證據

| RCA-ID | 症狀 | 直接機制／根因 | 證據定位 | 確信／處置 |
|---|---|---|---|---|
| R01 | Bootstrap 不開工 | Frozen PI/PD/Issuer 尚待修，卻成為它們自身的前置 Gate | 舊 Skill `frozen inputs`；B1 CMD r1；B1 Analysis `PL-003/4` | HIGH；改分階段 |
| R02 | PIPD 編譯拒收 | 未來要建立的 Admission/TaskKind 被誤標已有 Normative Input | B1 Analysis C0_C9/Compiler 報告；Prompt r1–r4 | HIGH；修 Authority/Applicability |
| R03 | Oracle Conflict | 相異法域/層級被標同權威；PIPD P4 Oracle ABI 未整合 | B1 Analysis `PL-004`；PIPD DOC-07；B1 DOC-07 | HIGH/OPEN；不假裁決 |
| R04 | 一個 HOLD 使全部停止 | EffectClass、依賴與 Gate 適用性未分離 | B1 DOC-02；B1 handoff；r1–r10 | HIGH；受影 PARK |
| R05 | 反覆索要 OWNER 授權 | Mission Authorization、OS Operation Permission、Native Permit、Acceptance 混為一談 | FHS 藍圖 §6.1；B1 Analysis；升級討論 | HIGH；Standing Delegation 不能自簽 |
| R06 | 不適合單人 OWNER | 人類數量與真機器 Principal 身份混淆 | 舊 Skill `challenge principal and a human`; SBL DOC-07 | HIGH；SoD 真權限分離 |
| R07 | 角色不明 | 舊 Skill 自稱 `build principal`+`apply it`；SBL DOC-04 卻 `NO_WORKORDER_ISSUE` | 舊 Skill 靜態；SBL DOC-04 C12.4.3 | DIRECT CONTRADICTION；雙產品拆分 |
| R08 | GWO-HGK 起始循環 | DOC-08 要 SBL Commander `plan.propose` 先提案；舊 Skill 要已有准入 WO | B1 DOC-08 §2；SBL DOC-03/04 | HIGH；分 proposal/admitted/render |
| R09 | Planner 當 Issuer | Natural language Prompt 或 Plugin 被誤升格 Source/Permit | B1 Analysis 將 Master Prompt 置 NORMATIVE；SBL DOC-04 | HIGH；型別與驗證器拒收 |
| R10 | Context / Session 後停工 | 無 Runtime READY/Lease/Wakeup/Stop Controller 閉環 | B1 handoff §0／r10 stop report | REPORTED/LIKELY；真 Process Test |
| R11 | 封存報告即停工 | Seal/report 與 Durable Mission Terminal State 耦合 | r10 handoff §0 | HIGH；分離 report、completion |
| R12 | Windows 管理員門檻 | Machine-scope Trust 方案被泛化為所有施工 | B1 Analysis／HGK Trust；r10 user trust | REPORTED；最小權限 |
| R13 | Trust 不生效 | `%LOCALAPPDATA%` User Trust 與 `%ProgramData%` Receiver Registry 未接線 | B1 handoff §0 | HIGH/UNVERIFIED LIVE；修 Resolver |
| R14 | Fabric SHA 視為 Loaded | Stage/Active/Loaded/Consumer 無真實讀回 | B1 DOC-08 GWO-Fabric；handoff R3 NOT_RUN | OPEN；真受影 Readback |
| R15 | 模型默默改變 | Required/Served/Credential 混淆；DeepSeek→MiMo | FHS 總討論 R17；handoff R4 NOT_RUN | HIGH/OPEN；真 served & pin |
| R16 | 虛假的獨立驗收 | Maker/Checker 名稱不同但同 SID/權限 | B1 handoff §0；SBL DOC-08 | P0；不同信任邊界 |
| R17 | CI 一綠就宣稱完成 | offline-gate PASS、Stage-C WriteSet FAIL 未區分 | B1 handoff §0；PR #20 歷史執行記錄 | REPORTED；雙 Job 收據 |
| R18 | 大幅放大治理成本 | R15 Required/Conditional/Deferred、TQAEP Fixtures 被當每輪任務 | B1 DOC-05/06；FHS 總討論 | HIGH；Coverage Index + Applicability |
| R19 | 開源輪子重造 | 每個 Donor 帶入新 Writer/Queue/Spec Truth | SBL DOC-06 C32；PIPD DOC-08 §9 | ARCH RISK；reuse first |
| R20 | 過早釋出 | Candidate/Accepted/Activated/Loaded/Release 混淆 | SBL DOC-09/12；B1 handoff | HIGH；typed lifecycle |
| R21 | Host 假成功 | Tool discovered≠installed≠enabled≠invoked；Skill 未實際觸發 | PIPD DOC-08；B1 DOC-07 | HIGH；雙向正反例 |
| R22 | 缺 PIPD/Profile ABI | Profile 12 axes vs Plugin 9 axes、TQAEP Design/Live 混淆 | B1 handoff §0；PIPD DOC-06/07 | CR_OPEN；逐軸 Adapter |
| R23 | 重複 Effect 或 UNKNOWN_EFFECT | 工程 repair iteration 與 Native at-most-once 混用 | B1 DOC-03 OPS-ECP；handoff | ARCH RISK；不同 attempt ledger |
| R24 | 依賴舊 Commander-SP 本身 | 其 `HOST_PENDING` 且 B1 後期明確禁用 | 靜態 Skill；B1 handoff §1 | HIGH；不作 B1 必經 |
| R25 | 新 Skill 自身 overtrigger | 對普通討論掛上全部治理與外部工具 | PIPD DOC-08 §9；Agent Skills [W01][W02] | ARCH RISK；trigger/non-trigger A/B |
| R26 | Donor 假成功 | OpenSpec zero tests exit 0、錯 Root；社群指出文檔膨脹 | FHS 總討論；社群 [W17] | HISTORICAL + SUPPORT；非零分母 |
| R27 | 補丁不被 Host 真正採用 | Repo candidate≠effective installed/loaded code | B1 handoff；SBL DOC-12 | OPEN；有效路徑驗收 |
| R28 | 憑證跨 Provider 泄漏 | OpenAI OAuth／OpenCode Go API Key、Lane、Session 混同 | FHS 總討論；MCP [W13]；OWASP [W12] | P0；provider-bound principal |

> **因果裁決：**舊 Skill 對早期治理錯置有明確促成作用，但 R13–R17、R21–R23、R27 等 Native 問題並不能被證明是它的直接程式錯誤；它禁用後仍未完成 r10，故不能誣稱「全部由 Skill 造成」。[N:升級討論 L89–141、L610–642]

### 2.3 問題閉環與不可再犯的 B1 反模式

1. `Frozen Missing → Global HOLD`：**改** `Bootstrap diagnostics` 可用、只有依賴 Native 的 effect 卡 PARK。
2. `Prompt Master → Normative`：**改** 所有 LLM 輸出預設 `PROPOSAL_ONLY`；Issuer/Writer/Checker 再次驗證來源。
3. `Owner said yes → all OS rights`：**改** Mission Grant 與 Per-effect Admission 兩層；沒有真正 OS 權限就 HOLD 受影效果。
4. `Config SHA → Host Loaded`：**改** Stage、Active、Loaded、Consumer 的不同真收據。
5. `Configured Model → Served Model`：**改** Request/Provider/Transport/Credential/Served 分離驗證。
6. `Maker says pass → AO PASS`：**改** 不同 Principal＋Frozen Subject＋Checker 原始結果。
7. `Report → mission closed`：**改** 由 Durable READY/RUNNING/PARKED/Native Gates 共同決定。
8. `One donor needed → install six frameworks`：**改** 24 Slot 保留，按需選一能力與一有效宿主。
9. `Skill build principal → native authority`：**改** Guide=Read/Recommend/Propose，PLAN=Plan/Replan，HGK=Admit/Issue，Hermes=Execute。
10. `Missing donor → stop all`：**改** `METHOD_ONLY` 或 `NO_FIT` 只影響依賴該工具的工作。

## 3. 2026 Web Research（SUPPORT，不得覆蓋 SSOT）

### 3.1 取證規則

- 每個涉及外部技術的建議至少以 **兩個不同維護主體**或官方標準加獨立安全／經驗來源相互對照；同一 GitHub 主庫的兩個頁面不算兩份獨立證據。
- 官方文件可確認功能和實際入口；第三方可以檢查安全、限制或實際使用成本，但社群口碑非正式能力驗收。
- 僅以 Star/下載量判斷人氣不可推出安全、成熟、Host 相容或對 FHS-MSC 效率必定提高。此輪未進行完整市場排名或端到端性能實測，量化 ROI 一律 `UNVERIFIED`。

| Web-ID | 2026 技術主張與支持範圍 | 第一來源 | 獨立交叉來源 | 工程裁決 |
|---|---|---|---|---|
| W01 | Agent Skill 由 `SKILL.md` YAML frontmatter + 可選 scripts/references/assets 組成，採漸進載入 | Agent Skills 規格 https://github.com/agentskills/agentskills/blob/main/docs/specification.mdx | GitHub Copilot Skills 說明 https://docs.github.com/en/copilot/how-tos/copilot-cli/customize-copilot/add-skills | 採薄 Skill＋on-demand references，不在主 Skill 複製全文件 |
| W02 | Codex/OpenSpec 為 Skill-only，Hermes Project-local 技能需顯式設定 external_dirs | OpenSpec https://github.com/Fission-AI/OpenSpec/blob/main/docs/supported-tools.md | Agent Skills format https://agentskills.io/ | Host Loaded 需兩端各自實測，不能只拷檔 |
| W03 | 規格工具可能增加流程摩擦，應採用同 Fixture A/B 而不是預設最複雜包裝 | PIPD DOC-08（NORMATIVE，見 §9） | 社群工作流比較 https://www.reddit.com/r/ClaudeAI/comments/1wdfrqs/four_specdriven_tools_one_identical_sentence_four/ | OpenSpec first; Spec Kit 大工作才准入；社群樣本不足以作硬保證 |
| W04 | 2026 GitHub Actions 應最小權限、固定 Action commit、避免不可信 PR 在高權限上下文執行 | GitHub https://docs.github.com/en/actions/reference/security/secure-use | OWASP https://cheatsheetseries.owasp.org/cheatsheets/GitHub_Actions_Security_Cheat_Sheet.html | PR 只讀 CI；發布另有審批，禁止 PR 寫 token |
| W05 | 供應鏈品質需看 Token Permissions、Dangerous Workflow、Pinned Dependencies，不只名氣 | OpenSSF Scorecard https://scorecard.dev/ | GitHub Actions Security https://docs.github.com/en/actions/reference/security/secure-use | 依 Repo 真證據評估；Unknown≠Pass |
| W06 | Provenance 有 L1/L2/L3 不同安全保證，存在 Manifest 不代表可信發行 | SLSA https://slsa.dev/how-to/get-started | SLSA Spec https://github.com/slsa-framework/slsa/blob/main/spec/build-provenance.md | 候選產出保留 SHA，正式發行需符合實際 provenance／簽章要求 |
| W07 | Prompt Injection 需把讀取內容當資料，工具端必須驗證權限與參數 | OWASP https://cheatsheetseries.owasp.org/cheatsheets/LLM_Prompt_Injection_Prevention_Cheat_Sheet.html | MCP Auth Security https://github.com/modelcontextprotocol/modelcontextprotocol/blob/main/docs/specification/2026-07-28/basic/authorization/security-considerations.mdx | Source/Donor 內容不得注入 Permit、模型憑證或 Script |
| W08 | MCP Access Token 要綁受眾，不能穿透轉發其他服務的 Token | MCP 2026 spec https://github.com/modelcontextprotocol/modelcontextprotocol/blob/main/docs/specification/2026-07-28/basic/authorization/security-considerations.mdx | OWASP LLM Tool Safety https://cheatsheetseries.owasp.org/cheatsheets/LLM_Prompt_Injection_Prevention_Cheat_Sheet.html | Provider / Tool / Operation Principal 綁定，不共享憑證 |
| W09 | OpenAI `gpt-6.1-sol` 支援 medium，但是否可用取決於客戶端與認證 | OpenAI Model https://developers.openai.com/api/docs/models/gpt-6.1-sol | OpenAI Work/Codex Models https://learn.chatgpt.com/docs/models | PLAN 主選模型 ID 為期望值，本地 OAuth 真路由另驗 |
| W10 | OpenCode Go 提供 `deepseek-v4.1-flash`、`mimo-v2.6-flash` 的獨立 Provider 模型目錄 | OpenCode Go https://docs.opencode.ai/docs/go/ | DeepSeek 官方 https://deepseek.com/en/news/deepseek-v4-1-flash/；Xiaomi 官方 https://mimo.mi.com/docs/en-US/updates/model | 兩家模型官方均確認產品，OpenCode Go 官方確認銷售模型 ID；本機 Served/Transport 仍 CR_OPEN |
| W11 | GSD Core 2026 活躍更新，有階段工作流及 Context 設計，但此處不可接管 Hermes Queue | GSD Core https://github.com/open-gsd/gsd-core | GSD 使用者比較 https://www.reddit.com/r/softwarearchitecture/comments/1vueeil/which_agentic_coding_setup_actually_works_without/ | 僅方法／可選工具，採 Native Hermes 持久化 |
| W12 | gstack 有 Review／QA 功能；Codex Host 經驗存在相容與上下文風險 | gstack https://github.com/garrytan/gstack | Codex 社群 https://www.reddit.com/r/codex/comments/1sjq2hg/gstack_in_codex/ | Review METHOD_ONLY，真 Host 先准入，不讓 `/ship` 發布 |
| W13 | Spec Kit 有成套 SDD 流程，但長流程可能增加文書工作量 | Spec Kit https://github.com/github/spec-kit | Spec Kit 實際心得 https://www.reddit.com/r/SpecDrivenDevelopment/comments/1tfkemy/tried_githubs_speckit_with_claude_code_for_2/ | 複雜多模組需求才啟用；不另建 Canonical Constitution |
| W14 | Matt Skills 提供獨立工程 skill，不應因名氣就全量安裝 | 主庫 https://github.com/mattpocock/skills | 獨立索引/體驗 https://www.skills.sh/mattpocock/skills | 只取診斷、TDD、Domain、Spec 等受影 Skill；實際版本需核 |
| W15 | Superpowers 具 TDD/診斷等方法；此處與 Matt 同用途只能擇一主流程 | 主庫 https://github.com/obra/superpowers | GSD/Superpowers 使用者比較 https://www.reddit.com/r/ClaudeCode/comments/1rhmnnl/best_framework_for_code_evolutions_gsd/ | 只挑符合用途之方法，避免雙重流程 |
| W16 | OpenSpec 比較適合現有系統的增量改動，Codex/OpenSpec 命令可從官方安裝矩陣辨識 | OpenSpec FAQ https://github.com/Fission-AI/OpenSpec/blob/main/docs/faq.md | Reddit 文書膨脹風險 https://www.reddit.com/r/ClaudeCode/comments/1uvrjy5/how_are_you_managing_specdriven_ai_workflows/ | 先 `explore/propose`，非授權不進 `apply/archive` |
| W17 | 2026 社群對重型 Agent Workflow 文書、Token、效果反應分歧 | 統計/討論 https://www.reddit.com/r/ClaudeCode/comments/1uvrjy5/how_are_you_managing_specdriven_ai_workflows/ | 另一社群 https://www.reddit.com/r/softwarearchitecture/comments/1vueeil/which_agentic_coding_setup_actually_works_without/ | 只作 A/B Fixture 設計，不直接宣稱某工具最優 |
| W18 | 技能的 Host 觸發與版本相容需要執行時驗證 | Agent Skills Spec https://github.com/agentskills/agentskills/blob/main/docs/specification.mdx | OpenSpec Host 安裝 https://github.com/Fission-AI/OpenSpec/blob/main/docs/supported-tools.md | `discovered / installed / loaded / invoked / verified` 五態 |
| W19 | GitHub action 發行/PR 安全需要明確權限隔離與真實版本 | GitHub Docs https://docs.github.com/en/actions/reference/security/secure-use | OpenSSF Scorecard https://github.com/ossf/scorecard | 附例 Workflow 僅設 PR READ，無任何發佈能力 |
| W20 | 局部開發安全／長任務排程評估應保留原生與方法層分離 | SBL DOC-06 C32（NORMATIVE） | GSD Core 官方設計 https://github.com/open-gsd/gsd-core | Donor 不變為第二 HGK Scheduler |

**社群交叉評價：**OpenSpec/Spec Kit/GSD/gstack/Matt 等在 2026 具公開 Repo 與使用討論，能作候選；但體驗意見互相矛盾，且平台／模型／工程規模不同。沒有同機同任務同模型 A/B 的工具不得被冠以「零磨合、無需任何測試」。人氣不等於合格，仍需 Host 正反例。[W03][W11–W17]

## 4. 整合方案：系統邊界、版本身份與最小改動

### 4.1 產品拆分（不得混淆功能）

| 產品身份（提案） | 工作內容 | 允許輸出 | 禁止效果 | 底層所有者 |
|---|---|---|---|---|
| `SBL-COMMANDER-GUIDE` | 設計原意比對、方案取捨、FirstFail、授權適用性整理、無效果 Proposal、證據解讀 | `SBL_GUIDANCE_PROPOSAL`、`Advice` | `repo.write`、Permit、Issuer、Checker、Release、Scheduler | SBL 產品 Owner／Portability Host |
| `SBL-COMMANDER-PLAN` | PIPD Reader、Task DAG、Worker Profile、模型路由 Proposal、受影 Replan | `SBL_PLAN_PROPOSAL`、`PlanDelta` | Native Issuer、直接 Repo Mutation、Checker | HGK `PLAN` Role + SBL 能力 |
| `EXECUTE_WRITER` | 有界代碼修補、測試、原始證據 | Patch、Diff、Raw | 自驗成正式 PASS、越 WriteSet | Codex/合法 Worker |
| `HGK_NATIVE_ISSUER` | 唯一 Permit/Admitted WorkOrder/Native State | 正式受權工單及 Admission | 不符合有效 OS/Policy 授權的效果 | HG-KSEOS |
| `HERMES_EXECUTOR` | 唯一持久 Dispatcher/Lease/Worker/恢復 | Executed/Readback/Checkpoint | 自簽 Issuer、錯 Lease 重播 | Hermes/HGK |
| `FABRIC_POLICY` | Stage/Activate/Loaded/Consumer ACK | 有效政策與 Consumer | 僅憑 SHA 冒稱 Loaded | Fabric |
| `INDEPENDENT_CHECKER` | 同 Subject Frozen RAW 的正式審查 | Checker Verdict/Negative | Maker 自驗、修改受測物 | 真不同 Principal |
| `PIPD_CANONICAL` | SourceFreeze、PI/PD/ECP/TQAEP、Oracle/Trace | Contract 與合法 Admission 設計 | Hermes Runtime Scheduler | PIPD |

**不可降級的設計意圖：**保留 SBL 原有 Guided Spec、Governed Build、Evidence-based Verify、Bounded Repair；TPM-SP、Commander-SP 歷史產品身份、External Challenge-SP 及 Standalone Builder 的適用義務。舊 Plugin 不可靜默刪除：需 Owner 批准 ADR-SBL-COMMANDER-SPLIT，釐清歷史滿足項與新歸屬。[N:SBL DOC-01/04/10/12][N:升級討論 L1510–1550]

### 4.2 唯一權威與執行鏈路

```text
HUMAN OWNER (single person; versioned Standing Delegation)
  |
  +--> External SBL Commander Guide Skill (READ/COMPARE/ADVISE/PROPOSE)
  |             |
  |             `-- SBL_GUIDANCE_PROPOSAL (NO EFFECT; NOT NORMATIVE)
  v
SBL Internal Commander on HGK.PLAN.SBL_COMMANDER
  |--> PIPD Canonical Reader (REF/SHA/currentness; NO second writer)
  |--> Donor Capability Selector (24 Slots; METHOD/ADMITTED; NO blind install)
  |--> Task DAG / Role Plan / Model Route Policy Proposal
  v
HG-KSEOS UNIQUE NATIVE ADMISSION + WorkOrder State + Issuer
  |                          ^
  |                          | FABRIC Stage/Active/Loaded/Consumer Policy
  v
Hermes UNIQUE Durable Dispatcher, Lease, Worker, Resume
  |--> EXECUTE Codex Bounded Writer (Scoped Patch/Raw)
  |--> HOST Effect via true Receiver/Permit (as applicable)
  v
World Readback + Independent Checker/AO
  |--> VERIFIED -> Release Gate if all applicable requirements pass
  `--> FirstFail -> AFFECTED-ONLY Replan -> other READY work continues
```

**最小修補原則：**以 SBL 既有 `sbl_core/modes.py`、`m01_intake`～`m06_repair`、`m04_bridge`、既有 `sbl_sp` manifests、`sbl-harness`／PIPD CLI、HGK SharedSpine、Hermes Worker Adapter 為優先檢查對象；本輪未取得現役 Repo 路徑，**下節新增路徑只是建議位置，不是已驗證存在**。所有真正修改需先檢查 Root/HEAD/WriteSet。[N:FHS 藍圖 §5.3][N:SBL DOC-04/10][CR-02]

### 4.3 分層准入：避免 B1 Global-HOLD 復發

| Class/階段 | 前置來源 | 效果權限 | 若缺少前置 | 允許的無影響工作 |
|---|---|---|---|---|
| L0 `READ_ONLY_PROBE` | 有效 Scope/必要來源 | READ | `SCOPE_MISSING` 局部 HOLD | 其他 Root 的唯讀工作 |
| L1 `REPOSITORY_WRITE` | Root/HEAD/WriteSet、適用 PIPD ExecutionAdmission、既有 OWNER Grant | 限範圍 Repository Write | `REPO_ADMISSION_MISSING` 局部 PARK | 獨立 OBS 與已准入的寫入卡 |
| L2 `HOST_OPERATIONS` | 正式 HGK Policy/Issuer/Receiver／受影 Permit | 原生 Host Effect | `NATIVE_PERMIT_MISSING` 局部 PARK | L0/L1 中不依賴此 Gate 的工作 |
| L3 `USER_DATA_EFFECT` | 明確 User Scope/Consent、受影 Policy/Permit | 有界使用者資料效果 | `USER_AUTH_MISSING` 局部 HOLD | 其他隔離測試及非資料效果 |
| V1 `INDEPENDENT_ACCEPTANCE` | Frozen Subject、Raw、真不同 Checker Principal | 驗證／正式判決 | `CHECKER_MISSING` 禁止正式 PASS | Maker 可保留 CANDIDATE 不封閉 |
| R1 `RELEASE` | 全部適用 Required 與觸發 Conditional 真通過 | 正式 Publisher | `CR_OPEN` 阻斷正式 Release | 保留已通過之非發布候選 |

### 4.4 工作狀態（**提案投影**，非現有 HGK Native Enum）

`DISCOVERED → READY → CLAIMED → EXECUTING → WORLD_READBACK → CHECKING → VERIFIED`

分支：`PARKED_EXTERNAL`、`REPAIR_REQUIRED`、`UNKNOWN_EFFECT`、`COMPENSATION_REQUIRED`、`NO_FIT`。只許在真正 Registry 定義對應 ABI 後進入生效；禁止將 Markdown Enum 直接當作 HGK 已支援。

**Mission terminal algorithm：**`READY>0 → cannot finish`；`RUNNING>0 → cannot finish`；若所有未完成卡均有可稽核 External Block，允許 `PARKED` 並保存 Wakeup Condition，但不宣稱 COMPLETE；只有必要 Gate、Checker、Release Authority 與所有適用卡通過，才可 `ELIGIBLE_FINAL`。[N:B1 handoff §0][N:升級討論 §四–§九]

### 4.5 事件矩陣（Event → decision → owner → evidence）

| Event | 規劃/路由行為 | 真正 Owner | 證據與處置 |
|---|---|---|---|
| `USER_GOAL_RECEIVED` | 解析需求、範圍及既存答案 | SBL Guide/PLAN | Source refs、無效果 Proposal |
| `SOURCE_MISSING` | 標 MISSING、只 HOLD 受影設計決議 | PIPD Owner | `CR_OPEN`; 不捏造 SSOT |
| `FROZEN_PI_MISSING` | Guide 可提供合法 Bootstrap 診斷 | PIPD/PLAN | 無正式 PI 不簽 Effect WO |
| `PLAN_REQUESTED` | 依 PIPD contract 建 DAG | SBL PLAN | Plan SHA／ReadSet |
| `MODEL_ROUTE_REQUESTED` | 檢查 Lane/Provider/Principal/Policy | HGK Route Owner | Requested/Admitted/Served 三聯 |
| `PROPOSAL_SUBMITTED` | Schema、ReadSet、SoD 驗證 | HGK Receiver | Accepted/NACK 原始資料 |
| `WORKORDER_ISSUED` | 真 Issuer 後才進 Queue | HGK Issuer | Native signature/permit/nonce |
| `WORKER_CLAIMED` | CAS、Lease、Heartbeat | Hermes | Worker PID/identity、Journal |
| `WORKER_CRASH` | 重新喚醒並核對 Effect | Hermes | 新 OS Process、Continuation |
| `NATIVE_HOLD` | 只 PARK 受影卡 | HGK/PLAN | FirstFail、Dependent Task IDs |
| `WRITESET_VIOLATION` | 效果前拒收 | Repo Admission | Negative Receipt、無 mutation |
| `MISSING_DONOR` | METHOD_ONLY 或受影 NO_FIT | Donor Resolver | tool identity absent, not fabricated |
| `POLICY_STAGED` | 仍不可視為 Active/Loaded | Fabric | Stage receipt |
| `POLICY_LOADED` | 同 Subject/Policy Epoch Consumer readback | Fabric | Loaded SHA + ACK |
| `REQUIRED_SERVED_MISMATCH` | REJECT 或有授權時重新 Admission fallback | HGK Model Router | Provider/Transport/Served raw |
| `CHECKER_MAKER_COLLISION` | 正式驗收 NACK | Independent AO | OS/Service Principal evidence |
| `UNKNOWN_EFFECT` | 先 Reconcile；禁止盲重試 | Hermes/HGK | Operation ID/World Readback |
| `REPORT_SEALED` | 不影響 READY Queue | Evidence Publisher | Snapshot SHA / Mission still active |
| `ALL_APPLICABLE_GATES_PASS` | 交正式 Release Owner | HGK/AO/Publisher | 封存、Signed Receipt、Owner ACK |
| `OWNER_REVOKES` | 停新效果、保留可驗結果 | Owner/Gate | Policy revoke epoch、DENY |

### 4.6 受限授權矩陣（Single OWNER ≠ Single Principal）

| Principal | Read source | Propose | Repo effect | Host effect | Issue Permit | Independent PASS | Release |
|---|---:|---:|---:|---:|---:|---:|---:|
| 外部 Guide Skill | Y（已授權內容） | Y | **N** | **N** | **N** | **N** | **N** |
| SBL PLAN | Y | Y | **N** | **N** | **N** | **N** | **N** |
| Codex Bounded Writer | Y | 回報候選 | Y（有效 Root/WriteSet） | 僅有有效 Native effect 時 | **N** | **N** | **N** |
| HGK Issuer | Policy 受影 | 審查 | 不作 Maker | 簽發受影操作 | Y | **N** | **N** |
| Hermes Executor | WorkOrder 受影 | 反饋 | 僅有效准入 | 僅有效 Permit | **N** | **N** | **N** |
| Independent Checker | Frozen A/Raw | Finding | **N** | 驗證所需限權 | **N** | Y（真獨立） | 視受權責任 |
| Owner/Publisher | 依身份 | Y | 視受權 | 視實際 OS | 不代替技術 Signer | Owner Acceptance（如需） | Y（另有 Release Gate） |

**「代位授權」正確意義：**Guide/PLAN 可比對已存在、可驗的 Standing Authorization 與操作影響，生成 `authorization_applicability` 建議及正式 Request；不得新增授權、偽造簽章、繞過受保護 OS 權限或混用 OAuth/Go Key。[N:SBL DOC-07][N:PIPD DOC-05][W07][W08]

### 4.7 失效降級矩陣（Degrade Matrix）

| Failure | Allowed degradation | Forbidden shortcut | State/Owner |
|---|---|---|---|
| 舊 Commander-SP `HOST_PENDING` | 不依賴舊 Skill；新 Guide 可讀資料 | 強迫啟用舊 Plugin | `DISABLED` / SBL |
| Frozen PI/PD 尚缺 | 只讀診斷、非效果提案 | 偽造正式 Frozen Contract | `PARKED` on dependent / PIPD |
| CAPC Compiler `PL-003/4` | 修受影 Authority/Oracle/TaskKind | 直接改為 PASS、移除 Gate | `CR_OPEN` / PIPD |
| Hermes 真 Executor 不可用 | Codex 獨立有界候選施工 | 冒稱 Durable Native Loop | `NATIVE_INTEGRATION_HOLD` |
| HGK Receiver 不可用 | L0/L1 合法工作繼續 | 自簽 Permit／重播 Effect | `NATIVE_HOLD` |
| Fabric Activator 未測 | 不依賴 Policy promotion 的工作 | SHA 當 Loaded | `R3_NOT_RUN` |
| PLAN 主選 Provider 不可用 | 如果 `AUTO_ADMITTED` 且有明示備援 Scope 才選下一個 | 靜默 DeepSeek↔MiMo | `MODEL_ROUTE_HOLD` |
| 使用者 `PINNED` 模型不可用 | 保留任務，回報 NoFit/HOLD | 隱式替換 | `PIN_HOLD` |
| 外部 Donor CLI 不可用 | `METHOD_ONLY` 可用來源閱讀 | 宣稱 CLI 已執行 | `TOOL_NOT_INSTALLED` |
| Donor 版本／授權不明 | 暫緩安裝，改原生等價工作方式 | `curl | bash` 不審核執行 | `ADOPTION_HOLD` |
| Checker 不是獨立 Principal | CANDIDATE 測試照做，正式 PASS HOLD | Maker 自驗正式 PASS | `CHECKER_HOLD` |
| PR CI WriteSet FAIL | 修實際 Diff 範圍 | 放寬 Allowlist 製造綠燈 | `CI_HOLD` |
| Seal 形成但 READY 仍非零 | 產中期快照，繼續派工 | 結束 Mission | `ACTIVE` |
| UNKNOWN_EFFECT / timeout | Readback／Reconcile | 無 Idempotency 重播 | `RECONCILE` |
| Source SHA 改變 | 只失效受影投影、重新檢查依賴 | 所有已完成工件一律重做或沿舊 SHA 釋出 | `AFFECTED_RECHECK` |
| Releases lacks Independent PASS | 留候選＋可驗工件 | 單一 Writer 自交付當 Release | `RELEASE_FAIL_CLOSED` |

### 4.8 三 Lane／模型需求與備援

| Lane | Role | Primary | Fallback 1 | Fallback 2 | 效果權限 |
|---|---|---|---|---|---|
| `PLAN` | `HGK.PLAN.SBL_COMMANDER` | OpenAI `gpt-6.1-sol`, `medium` | OpenCode Go `deepseek-v4.1-flash` | OpenCode Go `mimo-v2.6-flash` | proposal/replan only |
| `EXECUTE` | `Codex Bounded Writer` | OpenCode Go `deepseek-v4.1-flash` | OpenCode Go `mimo-v2.6-flash` | OpenAI `gpt-6-luna` | bounded writer subject to admission |
| `VERIFY_SECURITY` | `Checker/Challenge` | OpenAI `gpt-6.1-sol`, `medium` | OpenCode Go `deepseek-v4.1-flash` | OpenCode Go `mimo-v2.6-flash` | no maker write; formal verdict requires independent principal |

**供應商命名差異（重要）：**OpenCode Go 對 DeepSeek V4.1 Flash 的服務 ID 是 `deepseek-v4.1-flash`，DeepSeek 自營 API 官方則使用 `deepseek-flash`；兩者**不可靜默混用**。2026-10-17 DeepSeek 官方還記錄服務權重的模型版本更新，故必須保存 Provider/Endpoint/ServedRevision，不能只保存友善名稱。MiMo 的原廠 `mimo-v2.6-flash` 及 Go 入口亦須分別記錄。[W10][https://api-docs.deepseek.com/updates/][https://mimo.mi.com/docs/en-US/updates/model]

**精確分離：**`session_model != required_lane_model != served_model != credential_identity`；Model ID、Provider、Transport、OpenAI OAuth/Go API key、Scope、Policy Epoch、Request ID、Response readback 均為不同證據欄位；`configured` 與 `admitted` 不等於 `served`。[N:FHS 總討論 model matrix][N:FHS 藍圖 §5.2][W09][W10]

**效能隔離：**只設 `PLAN` 內部 `SBL_COMMANDER` 專屬 Role Pool、Budget、Concurrency；不創立第四實體 Lane／第二模型 Registry。PLAN 等待不得消耗全部 EXECUTE Worker 配額。[N:FHS 總討論 R17][N:升級討論 L1257–1399]

### 4.9 六 Donor／24 槽位：高保留、最小引入

| Donor | 既有 4 槽位 | 新版 GUIDE 允許使用 | 內部 PLAN／EXECUTE 使用 | 技術裁決 |
|---|---|---|---|---|
| OpenSpec | OS-01/02/03/04 | explore/spec-delta 提案 | apply/archive 僅交合法 EXECUTE | `SELECTED_TRANSLATE`，Codex skills 路徑需真確認 [N:SBL DOC-06 C32][W02][W16] |
| GitHub Spec Kit | SK-01/02/03/04 | 重大需求時 Constitution/Clarify 候選 | Task DAG 僅輸出候選 | `SELECTED_WRAP`，不得建立第二 PIPD Canonical [N:PIPD DOC-08][W13] |
| Matt Pocock Skills | MP-01/02/03/04 | diagnose/domain/to-spec | TDD/to-tickets 依受影施工 | `SELECTED_TRANSLATE`，不強制整包 [N:SBL DOC-06][W14] |
| GSD Core | GS-01/02/03/04 | 僅 Context/Milestone 方法 | 由 Hermes 持久化，禁第二 Scheduler | `REFERENCE`，新 gsd-core 版本須重新准入 [N:PIPD DOC-08][W11] |
| gstack | GT-01/02/03/04 | Review/QA 方法 | 僅有有效 Host 能力才 Native Review | `REFERENCE/QUARANTINE`；`/ship` 不取代 Release [N:SBL DOC-04][W12] |
| Superpowers | SP-01/02/03/04 | Design-first 提示 | TDD/Debug/Verify 方法 | `SELECTED_TRANSLATE`，和 Matt 同用途擇一主路徑 [N:PIPD DOC-08][W15] |

**不得捏造當前開源排名：**本輪 Web 搜尋顯示有活躍 Repo、官方文檔與社群經驗，但未核得每項的相同口徑 Maintainer Count、Release Freshness、Star 數、Security Score、Windows Host Compatibility。它們是「候選」，不是六套 `QUALIFIED`。[W01–W20][CR-07]

### 4.10 三種 Donor 接入等級

- `METHOD_ONLY`：僅參考受授權的公開方法與文檔；不安裝、不執行；最適合 gstack/GSD 初始。
- `NATIVE_SKILL_OR_CLI`：僅當已固定來源 Commit、License、Host、權限與正反例，直接使用 Donor 原生能力。
- `THIN_ADAPTER`：原生輸出和 SBL Proposal ABI 不合時才增加 Schema Adapter；永不新增第二 Source Writer／Queue／Release Checker。

所有 Donor 先做 `Search-Before-Build → Reuse Native → Wrap Thin → Build Minimum`，保留「找不到工具時仍能完成合法唯讀工作」的零 Donor fallback。[N:SBL DOC-06 C32][N:PIPD DOC-08 §9]

## 5. 工程可套用的參考實作（Code Blocks）

> **先決：**以下為候選文件與 Python 標準函式庫實作，可複製至**已由現役 Repo/Owner 確認**的合法專案根目錄；不依賴未知 HGK 私有 API，不讀或修改使用者 Registry／Key／Token。Windows PowerShell 和 GitHub Actions 的本機/雲端運行要分別依真授權驗證。此章提供可以運行的**無效果 Guide Core**，不冒充 Native PLAN/Issuer/Checker 已接線。[N:PIPD DOC-05/08][W01][W04]

### 5.1 建議最小目錄（新增路徑，非聲稱現有 Repo 已存在）

```text
<AUTHORIZED_SBL_REPO_ROOT>/
├─ .agents/skills/sbl-commander-guide/SKILL.md
├─ configs/sbl/commander-plan-policy.json
├─ schemas/sbl/guide-proposal.schema.json
├─ scripts/sbl/validate_guide.py
├─ tests/sbl/test_validate_guide.py
├─ docs/adr/ADR-SBL-COMMANDER-SPLIT.md
├─ docs/sbl/commander-compatibility-map.md
├─ docs/sbl/donor-capabilities.tsv
└─ .github/workflows/sbl-commander-guide-verify.yml
```

**Host 路徑須分別確認：**Agent Skills 標準允許 Skills Folder；OpenSpec 官方表列 Codex `.agents/skills/` 與 Hermes `.hermes/skills/`，且 Hermes project-local 載入需 `skills.external_dirs`。因此以上 `.agents/skills` **只作 Codex-first 提案**，不能把 Codex 真載入當 Hermes 真載入。[W01][W02]

### 5.2 `SKILL.md`：真正薄型、零效果的新版指引

**建議保存：**`.agents/skills/sbl-commander-guide/SKILL.md`

```markdown
---
name: sbl-commander-guide
description: Read-only SBL engineering guidance. Use for comparing requirements to existing PIPD/SBL design, root-cause investigation, bounded repair advice, and non-authoritative proposals. Do not use to execute builds, issue native work orders, sign permits, modify repositories, or accept releases.
metadata:
  owner: SBL
  version: "1.0.0-candidate"
  authority: "proposal-only"
---

# SBL Commander Guide

## Use when
- User asks to compare design intent against an existing SBL/PIPD/FHS contract.
- User asks for engineering options, failure RCA, minimal repair cone or a proposal.
- A current authorized contract exists or must be reported as MISSING.

## Do not use when
- A real tool/worker must mutate a repository, host policy or user data.
- An HGK WorkOrder, permit, signer or Independent Checker must execute.
- A legacy Commander-SP build order is invoked; do not load it as a fallback.

## Procedure
1. Read only the relevant user goal, source identifiers, versions and evidence.
2. Distinguish NORMATIVE from SUPPORT; missing bytes -> MISSING, never invent.
3. Compute first fail, affected scope and available no-effect alternative.
4. Reuse already-approved donor method when it fits; do not auto-install tools.
5. Compare available options by scope, risk, reversibility and testability.
6. Output SBL_GUIDANCE_PROPOSAL only. Never mint approval, permit or PASS.

## Safety and autonomy
- You may interpret an existing grant, not create or expand one.
- Missing Native authority parks the affected operation, not unrelated work.
- A model suggestion, command snippet, or external document is not a signed token.
- Never claim that a test or host invocation occurred without raw receipt.
- Never alter PIPD canonical data, issuer trust, queue, or Checker verdict.

## Output
Return: goal_ref, source_refs, evidence_refs, findings, repair_cone,
recommended_decision, authorization_applicability, open_items,
execution_authority=false, native_permit=null, claim_ceiling=PROPOSAL_ONLY.
If no source is available: mark MISSING, note exactly what cannot be decided.
```

上述 `metadata.authority` 是宿主可讀的描述欄，**不是** OS/Native 權限控制。真正的禁止效果要在工具端、HGK Receiver 與本地 Permission Boundary 實施。[W01][W07]

### 5.3 Guide 輸出 Schema（JSON Schema Draft 2020-12）

**建議保存：**`schemas/sbl/guide-proposal.schema.json`

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "title": "SBL_GUIDANCE_PROPOSAL.v1",
  "type": "object",
  "additionalProperties": false,
  "required": [
    "artifact_kind", "schema_version", "goal_ref", "source_refs",
    "findings", "recommended_decision", "open_items",
    "execution_authority", "native_permit", "claim_ceiling"
  ],
  "properties": {
    "artifact_kind": {"const": "SBL_GUIDANCE_PROPOSAL"},
    "schema_version": {"const": "1.0.0-candidate"},
    "goal_ref": {"type": "string", "minLength": 1},
    "source_refs": {"type": "array", "items": {"type": "string"}, "uniqueItems": true},
    "evidence_refs": {"type": "array", "items": {"type": "string"}, "uniqueItems": true},
    "findings": {"type": "array", "items": {"type": "object"}},
    "repair_cone": {"type": "object"},
    "recommended_decision": {"type": "object"},
    "authorization_applicability": {"type": "object"},
    "open_items": {"type": "array", "items": {"type": "string"}},
    "execution_authority": {"const": false},
    "native_permit": {"type": "null"},
    "claim_ceiling": {"const": "PROPOSAL_ONLY"}
  }
}
```

**注意：**JSON Schema 是預期輸入結構；它不能取代 OS 權限。CI 的最小零依賴驗證器如下，只覆蓋此固定 Schema 的核心屬性和高風險禁止欄位；若未來修改 Schema，需引入正式 JSON Schema Validator 和 Schema Conformance Test，不能假設手寫驗證器等同全面 Draft 2020-12 實作。

### 5.4 `validate_guide.py`：Python 標準庫 fail-closed 校驗器

**建議保存：**`scripts/sbl/validate_guide.py`

```python
#!/usr/bin/env python3
"""Validate a no-effect SBL guidance candidate; no network or host actions."""
import json
import sys
from pathlib import Path

REQUIRED = {
    "artifact_kind", "schema_version", "goal_ref", "source_refs",
    "findings", "recommended_decision", "open_items",
    "execution_authority", "native_permit", "claim_ceiling"
}
ALLOWED = REQUIRED | {"evidence_refs", "repair_cone", "authorization_applicability"}
FORBIDDEN_EFFECT_FIELDS = {
    "issued_workorder_id", "signed_permit", "native_signature",
    "release_verdict", "checker_pass", "issuer_private_key"
}


def check(obj):
    errors = []
    if not isinstance(obj, dict):
        return ["proposal must be an object"]
    missing = REQUIRED - set(obj)
    extra = set(obj) - ALLOWED
    if missing:
        errors.append("missing: " + ",".join(sorted(missing)))
    if extra:
        errors.append("unknown fields: " + ",".join(sorted(extra)))
    if set(obj) & FORBIDDEN_EFFECT_FIELDS:
        errors.append("forbidden effect fields")
    if obj.get("artifact_kind") != "SBL_GUIDANCE_PROPOSAL":
        errors.append("wrong kind")
    if obj.get("schema_version") != "1.0.0-candidate":
        errors.append("wrong schema_version")
    if not isinstance(obj.get("goal_ref"), str) or not obj.get("goal_ref"):
        errors.append("goal_ref required")
    if obj.get("execution_authority") is not False:
        errors.append("execution_authority must be false")
    if obj.get("native_permit", object()) is not None:
        errors.append("native_permit must be null")
    if obj.get("claim_ceiling") != "PROPOSAL_ONLY":
        errors.append("claim ceiling too high")
    for field in ("source_refs", "evidence_refs", "open_items"):
        if field in obj and (not isinstance(obj[field], list)
                             or not all(isinstance(x, str) for x in obj[field])):
            errors.append(f"{field} must be a list of strings")
    for field in ("findings",):
        if field in obj and (not isinstance(obj[field], list)
                             or not all(isinstance(x, dict) for x in obj[field])):
            errors.append(f"{field} must be a list of objects")
    for field in ("recommended_decision", "repair_cone", "authorization_applicability"):
        if field in obj and not isinstance(obj[field], dict):
            errors.append(f"{field} must be an object")
    return errors


def main():
    if len(sys.argv) != 2:
        print("usage: validate_guide.py <proposal.json>", file=sys.stderr)
        return 2
    try:
        obj = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
    except (OSError, UnicodeError, ValueError) as exc:
        print(f"FAIL-CLOSED: cannot read valid JSON: {type(exc).__name__}", file=sys.stderr)
        return 2
    errors = check(obj)
    if errors:
        for e in errors:
            print("FAIL-CLOSED: " + e, file=sys.stderr)
        return 1
    print("CANDIDATE-SCHEMA-PASS; NOT Native Admission or Acceptance")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
```

### 5.5 核心測試（離線，不要求 HGK Native Gate）

**建議保存：**`tests/sbl/test_validate_guide.py`

```python
import copy
import importlib.util
import pathlib
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[2]
VALIDATOR = ROOT / "scripts" / "sbl" / "validate_guide.py"
spec = importlib.util.spec_from_file_location("validate_guide", VALIDATOR)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

BASE = {
    "artifact_kind": "SBL_GUIDANCE_PROPOSAL",
    "schema_version": "1.0.0-candidate",
    "goal_ref": "goal-001",
    "source_refs": ["SBL-DOC04#C12.4.3"],
    "findings": [],
    "recommended_decision": {},
    "open_items": ["CR-01"],
    "execution_authority": False,
    "native_permit": None,
    "claim_ceiling": "PROPOSAL_ONLY"
}

class GuideContractTest(unittest.TestCase):
    def test_candidate_passes(self):
        self.assertEqual(module.check(BASE), [])

    def test_no_permit(self):
        d = copy.deepcopy(BASE)
        d["native_permit"] = "SELF_SIGNED"
        self.assertTrue(module.check(d))

    def test_no_native_effect(self):
        d = copy.deepcopy(BASE)
        d["execution_authority"] = True
        self.assertTrue(module.check(d))

    def test_no_issuer_fields(self):
        d = copy.deepcopy(BASE)
        d["issued_workorder_id"] = "fake"
        self.assertTrue(module.check(d))

    def test_no_release_claim(self):
        d = copy.deepcopy(BASE)
        d["claim_ceiling"] = "NATIVE_ACCEPTED"
        self.assertTrue(module.check(d))

    def test_unknown_version_fails(self):
        d = copy.deepcopy(BASE)
        d["schema_version"] = "2.0"
        self.assertTrue(module.check(d))

    def test_missing_source_is_not_invented(self):
        d = copy.deepcopy(BASE)
        d["source_refs"] = []
        d["open_items"] = ["MISSING: PIPD PI"]
        self.assertEqual(module.check(d), [])

    def test_invalid_type_fails(self):
        d = copy.deepcopy(BASE)
        d["findings"] = "PASS"
        self.assertTrue(module.check(d))

if __name__ == "__main__":
    unittest.main()
```

**本地執行（於授權 Repo 根目錄）：**

```powershell
python -m unittest discover -s tests/sbl -p 'test_*.py' -v
python scripts/sbl/validate_guide.py fixtures/sbl/valid-guidance.json
```

第二行需先建立符合上列 `BASE` 結構的 `fixtures/sbl/valid-guidance.json`；不存在時會明確 exit 2，不能將 `file missing` 視為 PASS。若 Python/Repo 實際 layout 不一致，先由 Owner／Worker 核對後調整**路徑適配**，不是放寬驗證規則。[N:SBL DOC-05 RepoContext][W01]

### 5.6 內部 PLAN 模型政策（**未生效期望配置**）

**建議保存：**`configs/sbl/commander-plan-policy.json`

```json
{
  "schema_version": "1.0.0-candidate",
  "role_id": "HGK.PLAN.SBL_COMMANDER",
  "lane_id": "PLAN",
  "state": "DESIGN_ONLY_NOT_LOADED",
  "default_selection": "AUTO_ADMITTED",
  "user_can_pin": true,
  "providers": [
    {
      "order": 0,
      "provider": "openai",
      "model_id": "gpt-6.1-sol",
      "reasoning_effort": "medium",
      "credential_route": "OPENAI_CODEX_SIGNIN_SUBJECT_TO_HOST_VERIFICATION"
    },
    {
      "order": 1,
      "provider": "opencode-go",
      "model_id": "deepseek-v4.1-flash",
      "credential_route": "OPENCODE_GO_SEPARATE_CREDENTIAL"
    },
    {
      "order": 2,
      "provider": "opencode-go",
      "model_id": "mimo-v2.6-flash",
      "credential_route": "OPENCODE_GO_SEPARATE_CREDENTIAL"
    }
  ],
  "auto_fallback_before_admission": false,
  "require_served_identity_receipt": true,
  "reject_unadmitted_provider": true,
  "data_export_default": "DENY_UNTIL_PROVIDER_POLICY_BOUND",
  "native_write_authority": false,
  "permit_issue_authority": false
}
```

`AUTO_ADMITTED` 表達候選策略，但 `auto_fallback_before_admission=false` 保證在本機來源／Provider／Data Policy／Credential 尚未資格化前，**不會因 YAML/JSON 宣告就自行換模型**。真正 Host Router Adapter 需繼承 HGK 已存在的合法配置；未知路由不得憑本範例新建 Proxy。[N:FHS 總討論][W09][W10][CR-06]

### 5.7 靜態模型 Served Receipt 拒收樣例（供現役 Adapter 重用）

```python
# This helper validates a *reported* receipt. It never contacts a model.
def validate_served_identity(request, receipt):
    fields = ("request_id", "provider_id", "model_id", "credential_route", "policy_epoch")
    if any(not request.get(k) or not receipt.get(k) for k in fields):
        return "HOLD_MISSING_IDENTITY"
    if request["request_id"] != receipt["request_id"]:
        return "FAIL_REQUEST_MISMATCH"
    if request["policy_epoch"] != receipt["policy_epoch"]:
        return "FAIL_POLICY_DRIFT"
    if request["provider_id"] != receipt["provider_id"]:
        return "FAIL_UNADMITTED_PROVIDER"
    if request["model_id"] != receipt["model_id"]:
        return "FAIL_UNADMITTED_MODEL_FALLBACK"
    if request["credential_route"] != receipt["credential_route"]:
        return "FAIL_CREDENTIAL_ROUTE_MISMATCH"
    return "IDENTITY_FIELDS_MATCHED_NOT_INDEPENDENTLY_VERIFIED"
```

此程式只能檢查「輸入欄位一致」，不能證明收據由供應商真實產生。正式模型 Gate 應使用 Provider/Transport 可信回應、有效模型 Registry 及 Raw Event；若 Provider 不揭露可信 `served_model_id`，應降為 `UNVERIFIED_SERVED`，不得假裝成功。[N:FHS 總討論 R17][N:B1 DOC-07]

### 5.8 GitHub Actions：只讀 PR 工程驗證（不自動發布）

**建議保存：**`.github/workflows/sbl-commander-guide-verify.yml`

```yaml
name: sbl-commander-guide-verify
on:
  pull_request:
    paths:
      - '.agents/skills/sbl-commander-guide/**'
      - 'schemas/sbl/**'
      - 'scripts/sbl/**'
      - 'tests/sbl/**'
      - '.github/workflows/sbl-commander-guide-verify.yml'
  workflow_dispatch:
permissions:
  contents: read
concurrency:
  group: sbl-guide-${{ github.workflow }}-${{ github.ref }}
  cancel-in-progress: true
jobs:
  guide-static-test:
    runs-on: ubuntu-latest
    timeout-minutes: 10
    steps:
      - name: Checkout least privilege
        uses: actions/checkout@11bd71901bbe5b1630ceea73d27597364c9af683 # v4.2.2; review pin before production
        with:
          persist-credentials: false
      - name: Set Python
        uses: actions/setup-python@a26af69be951a213d495a4c3e4e4022e16d87065 # v5.6.0; review pin before production
        with:
          python-version: '3.13'
      - name: Offline guide test
        run: python -m unittest discover -s tests/sbl -p 'test_*.py' -v
      - name: Assert no privileged artifact in skill
        shell: bash
        run: |
          python - <<'PY'
          from pathlib import Path
          p = Path('.agents/skills/sbl-commander-guide/SKILL.md')
          assert p.is_file(), 'SKILL.md missing'
          s = p.read_text(encoding='utf-8')
          assert s.startswith('---\n'), 'Skill frontmatter missing'
          for token in ('name: sbl-commander-guide', 'execution_authority=false', 'native_permit=null'):
              assert token in s, f'expected safety phrase missing: {token}'
          print('STATIC_GUARD_PASS_NOT_HOST_ACCEPTANCE')
          PY
```

**作用與限制：**CI 只讀、Pin Action Commit、不使用 `pull_request_target`、不傳任何 Host Secret、不產生 Release；在 `SKILL.md` 的上述文本存在且 8 個單元測試成功時可以產生候選測試 PASS，但絕不能代替現役 Host invoke、Permission negative test 或獨立 Checker。Action Pin 是歷史可追溯提交，不代表最新且無漏洞；真正 Repo Owner 仍須核對供應商來源及 Node Runtime 相容性。[W04][W05][W19]

### 5.9 Windows PowerShell 的安全檢測順序（不假定路徑）

```powershell
# Run in a repository that the OWNER has actually authorized.
$ErrorActionPreference = 'Stop'
$root = (git rev-parse --show-toplevel).Trim()
if ([string]::IsNullOrWhiteSpace($root)) { throw 'MISSING_REPO_ROOT' }
Set-Location $root
$head = (git rev-parse HEAD).Trim()
$dirty = git status --porcelain=v1
Write-Output "ROOT=$root"
Write-Output "HEAD=$head"
Write-Output "DIRTY_COUNT=$(@($dirty).Count)"
if (@($dirty).Count -gt 0) { throw 'DIRTY_WORKTREE_REQUIRES_OWNER_BOUND_SCOPE' }
python -m unittest discover -s tests/sbl -p 'test_*.py' -v
if ($LASTEXITCODE -ne 0) { throw 'FAIL_TESTS' }
Write-Output 'LOCAL_TEST_CANDIDATE_PASS_NOT_HOST_LOAD'
```

這段腳本僅在既有 Repo 執行唯讀 Git 查詢與 Python Test；測試程式本身由 Repo 來源提供，仍需 Source/WriteScope 審核。它**不進行** Git Commit/Push、Skill Install、HGK Permit、Windows 管理員提升。[N:SBL DOC-05][W04][W07]

### 5.10 Host Skill 生效驗證（**不得假作已有通用 CLI**）

- **Codex：**實際 Skill Discovery（獨立新 Session）、精確觸發、誤觸發反例、Guide Proposal Schema、卸載後非觸發，保存所用 Codex 版本、Skill SHA、Host Invocation ID。OpenSpec 官方給出 `.agents/skills`，但 SBL Guide 真宿主 ABI 仍需確認。[W01][W02]
- **Hermes：**若需要執行，先確認 `~/.hermes/config.yaml` 的 `skills.external_dirs` 和實際 Loader，禁止直接將 Codex 載入當成 Hermes 通過。[W02]
- **HGK：**只有非授權 Typed Proposal Handoff，可走合法現役 Adapter；B1 禁令仍禁止舊 `sbl-commander-sp` 被裝入或間接觸發。[N:B1 handoff §1]
- **Host install/enable/invoke/deny/uninstall/residue** 是六個獨立的證據事件。沒有真 Host，本輪該 Check 必填 `NOT_RUN`，不是 `PASS`。

## 6. 工程落地計畫、修改清單與阻斷依賴

### 6.1 工作包（WP）及施工順序

| WP | 主責 | 變更範圍 | 允許立即啟動的條件 | 必須取得的退出證據 | 不應依賴 |
|---|---|---|---|---|---|
| WP-00 | PIPD/SBL Architect | 實際 Root/HEAD/Dirty/現有功能/已知授權/ABI inventory | 只讀 Scope 有效 | Frozen inventory；法域/版本/證據差異 | G-B PASS |
| WP-01 | SBL Owner | `ADR-SBL-COMMANDER-SPLIT`、產品義務交叉表 | 候選文字起草 | Owner Ratification（正式生效須真簽核） | Windows Administrator |
| WP-02 | Codex | 薄 `SKILL.md`、輸出 Schema、Guide Validation | Repo 寫入有界授權、真 Worktree | Red→Patch→Green；前後 Diff/Raw | HGK Native Issuer 若本卡為普通 Repo Work |
| WP-03 | Codex | 24 Slot Donor Registry、無外效方法選擇 | Source/Tool version 可讀 | Search-before-build Ledger、License、NoFit | 六 Donor 全安裝 |
| WP-04 | Codex／Host | Codex Skill 掛載（僅**新** Guide）、觸發／非觸發／卸載 | 目標 Host/安裝位置已核實 | True Load + Call + Deny + Uninstall | 舊 Commander-SP |
| WP-05 | SBL/HGK PLAN | PIPD Reader、Role/Model Policy、Task DAG、PlanDelta | 現役 PIPD/HGK Read ABI 已發現 | PlanCandidate 的正反例與 Source join | 完整 G-A 如不需 Host Effect |
| WP-06 | HGK/PLAN | `plan.propose` 候選 Handoff Adapter | Owner 核定提案與 Issued WO 的區別 | Receiver 對候選回 ACK/NACK；無 Permit 自簽 | 舊 Commander-SP Plugin |
| WP-07 | Hermes/HGK | Durable Executor/Resume/READY stop rule | 真 Worker/Queue 已可合法操作 | Process A→B restore、B/C 繼續、Effect no-replay | 第二 Queue |
| WP-08 | Fabric/HGK | Active/Loaded/Consumer、Trust/Receiver、模型 Required/Served | 每一受影 Host Effect 有真准入 | 原始 Native Readback R2/R3/R4；否則 HOLD | 報告文字 |
| WP-09 | Codex | Affected-only Repair、Regression、CI WriteSet | 受影 WriteSet 已批准 | CI raw、Diff、測試分母非零 | 放寬保護規則 |
| WP-10 | Independent Checker | 安全負例、SoD、Host 真生效、功能歸屬 | Frozen Candidate SHA、Checker 真隔離 | Raw/Verifier Verdict，不是 Maker 自述 | 相同 SID 作假分權 |
| WP-11 | Owner/Publisher | 產品版本化 Release、卸載、可回退、來源封存 | 全部受影 REQUIRED Gate 過關 | 真 Publisher/Owner 受權收據 | Candidate-only CI 綠燈 |
| WP-12 | Product/RCA Owner | 成本/效能 A/B、B1 防復發與長期維運 | 相同機器／同樣 Fixture 設置 | 時間/Token/False Global HOLD/Autonomy 指標 | Star 數推定效率 |

**建議先開兩條獨立施工線：**

- **Track A — Thin Guide（優先，Codex-first）：**WP-00→01（可同步候選起草）→02→03→04→09→10→11。該 Skill 若不聲稱 HGK Native 效果，不必以 WP-07/08 為普通 Repo 修補的前置。
- **Track B — Internal PLAN（Native，HGK/Hermes）：**WP-00→01→05→06→07/08→09→10→11。B1 r10 未完的 HGK Receiver、Hermes Executor、R3/R4/GWO/G-B 等仍需各自驗收，不可把新 Skill 成功當作 B1 全部完成。

### 6.2 受影修改清單、路徑與變更型別

> 下列為**建議最小路徑**，若現役 Repo 不同，需由 WP-00 真實列出相對路徑並作 One-to-One Map；不存在的路徑 **不得**當成已存在或任意在錯 Repo 創建。[CR-02]

| 建議路徑 | 變更型別 | 理由與來源 | 風險／回退 |
|---|---|---|---|
| `.agents/skills/sbl-commander-guide/SKILL.md` | ADD | Guide-only、非效果；[N:SBL DOC-04][W01] | 誤觸發 → 刪除候選／禁用 |
| `schemas/sbl/guide-proposal.schema.json` | ADD | Typed No-Authority Output；[N:升級討論 §八] | Schema 漂移 → 版本鎖定／拒收 |
| `scripts/sbl/validate_guide.py` | ADD | 只讀/拒收候選越權；[N:PIPD DOC-05] | 校驗不足 → 加正式 Schema Validator |
| `tests/sbl/test_validate_guide.py` | ADD | RED/GREEN 正負例；[N:SBL DOC-08] | 零分母 → fail |
| `.github/workflows/sbl-commander-guide-verify.yml` | ADD | Read-only PR Gate；[W04][W05] | 第三方 Action → SHA pin／No Secrets |
| `configs/sbl/commander-plan-policy.json` | ADD CANDIDATE | 三車道／模型 Role Policy；[N:FHS 總討論] | 未核 ABI → DESIGN_ONLY |
| `docs/adr/ADR-SBL-COMMANDER-SPLIT.md` | ADD | 產品繼承與權責裁決；[N:SBL DOC-01/04/12] | 無 Owner Ratification → 不生效 |
| `docs/sbl/commander-compatibility-map.md` | ADD | 三 SP／六模組／原 24 Slot 零遺失 | 缺漏 → CR_OPEN |
| `docs/sbl/donor-capabilities.tsv` | ADD | Search-Before-Build／Donor 版本與 NoFit | 不得自動下載執行 |
| `sbl_sp/manifests/commander_sp.json` | AFFECTED MODIFY | 舊 `product.write` 與外部 Guide 分權；[N:FHS 藍圖 §5.3] | 舊 Standalone 功能不得意外失效 |
| `sbl_core/modes.py` | REVIEW THEN MINIMAL MODIFY | Standalone/Connected/Host Mode Gate 保留；[N:FHS 藍圖 §5.3] | 受影回歸 8 Kind/3 Mode |
| `m04_bridge` 等現役 Bridge | REVIEW THEN MINIMAL MODIFY | 非授權 Proposal→HGK Receiver 真接線 | 不能假造私有 SDK API |
| HGK/PLAN 真 Role/Registry 檔 | DISCOVER THEN MODIFY | `HGK.PLAN.SBL_COMMANDER` Role Pool；[N:FHS 藍圖 §5.2] | 不創第二 Registry |
| Hermes 真 Worker/Dispatcher 檔 | DISCOVER THEN MODIFY | 唯一 Runtime Lease/Resume | 不創第二 Queue |
| Fabric 真 Policy/Consumer 檔 | DISCOVER THEN MODIFY | POLICY Readback／Epoch | R3 先實測、後最小修 |
| PIPD 受影 Oracle/Profile ABI 檔 | DISCOVER THEN MODIFY | 12/9 軸/Oracle/Design-Live 修正 | 不重寫整套 PIPD |
| B1 DOC-08 GWO-HGK Proposal 字句 | VERSIONED AMENDMENT | 解開 Commander-SP 前置循環 | 原設計仍須保留 GWO 合約 |
| SBL DOC-00～13 受影段 | VERSIONED APPEND / TRACE | 更新雙身份＋原設計追溯 | 不偷刪任何 Required |

### 6.3 必須保留的原產品義務與不回歸斷言

1. SBL 原產品的 **Guided Spec / Governed Build / Evidence-based Verify / Bounded Repair** 不得刪除。[N:SBL DOC-01/04/13]
2. TPM-SP、Commander-SP（歷史產品身份）、External Challenge-SP、SBL Full Stack、HGK Harness Adapter 五工具及各自 Host/Installer 等義務保留至正式 Owner 版本化裁決；不因 Guide 改 Skill 而默默結案。[N:FHS 藍圖 r2 §6][N:SBL DOC-12]
3. SBL 六模組與現行 `sbl_core` 的能力語義可能不一一同名，先做 Capability Crosswalk 再修改。[N:FHS 藍圖 §5.3]
4. R15.1／B1 既有全產品身份分母仍是 Coverage Ledger，不被當成 v1 Skill 需要全部安裝的清單。[N:B1 DOC-06]
5. GWO-FABRIC/GWO-HGK/GWO-SBL 三個不同 Native 效果及 G-B 自主續行不因新版 Skill 完成而被宣告通過。[N:B1 DOC-08]
6. `SBL Guide`、`SBL PLAN`、`EXECUTE`、`HGK Issuer`、`Checker`、`Publisher` 的交付／身份與 Claim Ceiling 必須機械區分。

### 6.4 可執行驗收層級

| 驗收層 | 何者可以宣告 PASS | 何者不能宣告 PASS | 證據型別 |
|---|---|---|---|
| L0 Static/Schema | 檔案 Schema、文字、禁止權限 | Host 已掛載 | CLI stdout/stderr、exit、SHA |
| L1 Unit/Fixture | 原始功能正反例 | WorkOrder 真 Issuer | 非零計數＋環境＋SHA |
| L2 Codex Host | Codex 真 Discovery/Invocation/Nontrigger/Uninstall | Hermes／HGK Native Loop | Host Readback／Invocation ID |
| L3 Native PLAN Handoff | HGK 真 Proposal/Receiver ACK、Task Identity Join | GWO/G-B 自動通過 | 真 HGK Raw、Principal、Epoch |
| L4 Durable/Native Effects | Hermes 跨 Process Resume、合法 World Readback | 無 Checker 即正式放行 | Lease/CAS/世界觀察收據 |
| L5 Independent Acceptance | 不同 Principal Checker 的同 Subject 原始 Verdict | Maker 自我簽核 | Checker Signature、Raw Hash |
| L6 Release | 所有適用 REQUIRED、Owner/Publisher 授權後正式發布 | 只靠 CI Success | Release Artifact/Signature/Rollback |

### 6.5 必跑 Gate（精確 PASS/FAIL 規則）

| Gate ID | PASS 判準 | FAIL／HOLD 規則 | 層級／責任 |
|---|---|---|---|
| G01 Input Integrity | 所有**受影**檔案 UTF-8 可讀，SHA、Owner、Version、Scope 齊全 | 缺一 → `MISSING`，受影 HOLD | L0／Source Reader |
| G02 Role SoD | Guide/PLAN 無 repo.write/permit/accept；Builder/Checker 真隔離 | 權限或 Principal 碰撞 → FAIL | L0+L5／Security |
| G03 Guide Schema | 正例非零，越權字段/自簽 Permit/錯版本負例全部拒收 | 任一負例通過 → FAIL | L0/L1／Codex |
| G04 PIPD Canonical | Guide/PLAN 只引用唯一 PIPD source SHA，沒有第二 Writer | 修改真值/自編 Canonical → FAIL | L1/L3／PIPD |
| G05 A/B Skill Benefit | 同樣 Fixture 與任務，無安全退化且至少一項預定效益為正（先登記閾值） | 無穩定 baseline → HOLD | L1／SBL Product QA |
| G06 Donor 24 Slots | OS/SK/MP/GS/GT/SP 各 4 身份皆有版本和 disposition | 任一 silent drop → FAIL | L1／SBL Donor Owner |
| G07 Donor Admission | 真工具版本/授權/Host/負例滿足受影要求 | 沒裝 → METHOD_ONLY，不能假 PASS | L1/L2／Donor Adapter |
| G08 Codex Skill Host | 新 Session 真 Loaded＋invoked，無關情境 NOT invoked，卸載後消失 | 只見檔案而無 Host Readback → NOT_RUN | L2／Codex Host |
| G09 Old Skill Isolation | 新 B1 工作無舊 `$sbl-commander-sp` 載入/使用 | 任一舊依賴 → FAIL | L2/L3／Owner |
| G10 PLAN Task DAG | 無 cycle、依賴具名、READY 與 PARK 局部化 | 有 cycle/Global HOLD → FAIL | L3／SBL PLAN |
| G11 Model Identity | Required=Admitted=可信 Served/Provider/Transport，PINNED 無靜默 fallback | mismatch/receipt missing → FAIL/HOLD | L3／HGK Router |
| G12 Effect Class | 受影 Repo/Host/User 工作分別具合法真准入 | 未經授權實際效果 → FAIL | L3/L4／HGK |
| G13 Durable Continuation | 兩不同 OS Process 真恢復、A 阻塞不害 B/C、無重複 Effect | READY 有工作卻提前結束／double effect → FAIL | L4／Hermes |
| G14 Policy Effective | Stage→Active→Loaded→Consumer 同身份讀回 | 僅 PR SHA／Stage → HOLD | L4／Fabric |
| G15 Independent Checker | 不同可驗 Principal、Frozen Subject SHA、Raw、負例 | Maker 自評/同 SID 假分權 → FAIL | L5／AO |
| G16 CI Source/WriteSet | Raw CI 真 PASS、變更集均在有效範圍、測試分母非零 | CI Stage-C fail/越權 → FAIL | L1/L5／Repo Owner |
| G17 B1 Golden | 三 GWO 各自真世界效果、各自 Checker，G-B 撤外援後 Native Successor | 任一未跑→HOLD，不得整體 PASS | L4/L5／B1 Owners |
| G18 Release | 所有適用 Required/Triggered Conditional 已受影通過、CR 無 Release blocker、Publisher 真有權 | 任一 blocker/未簽署 → FAIL-CLOSED | L6／Release Owner |

### 6.5A 可下發的施工卡範本（非本次執行）

**Codex-first；只有現役 OWNER 受影 Repo Write 權限成立後可下發：**

```text
MISSION: SBL-COMMANDER-GUIDE.v1 CANDIDATE ONLY
READ: current authorized SBL root, PIPD DOC-01/02/05/08, SBL DOC-04/06/07/08/10/12,
      FHS-MSC blueprint and B1 anti-regression requirements.
VERIFY BEFORE WRITE: real git root/head/dirty, owner scope, exact WriteSet,
                     actual Repo ExecutionAdmission where applicable.
TASK: build the standalone read-only Guide SKILL.md, typed proposal schema,
      validator, donor 24-slot registry and offline positive/negative tests.
NO: legacy sbl-commander-sp invocation, HGK issuer/queue, provider secrets,
    false host readback, Maker self acceptance, broad repository rewrite.
TEST: run nonzero-denominator RED/GREEN; retain raw logs, candidate SHA, rollback.
RETURN: file diff, commands, exits, test count, raw sha, CR_OPEN, next affected task.
RELEASE: CANDIDATE_ONLY; independent Checker/Owner not automatically passed.
```

**Hermes/HGK Native integration；只能於真受權的 Native 流程中下發：**

```text
MISSION: SBL-COMMANDER-PLAN NATIVE INTEGRATION (scoped)
PREREQUISITES: real HGK issuer/receiver API, standing mission delegation,
               original SharedSpine/worker identity, source/subject/epoch readback.
TASK: consume SBL_PLAN_PROPOSAL; verify DAG, model requested/admitted/served,
      issue only by existing HGK authority; dispatch via existing Hermes runtime.
NEGATIVES: no permission, signer collision, model swap, stale lease, replay,
           blocked A with READY B/C, worker crash, report-with-READY termination.
NO: legacy Skill, second queue, second policy plane, forged signatures,
    skip Native admission or Checker.
RETURN: Native ACK/NACK, Raw/World Readback, operation IDs, Principal,
        actual served model, process-resume receipts, first fail, CR_OPEN.
RELEASE: HOLD until independent AO, GWO and affected formal Gates pass.
```

**這兩份文字是候選施工卡，不是本次已授權／已派送的 Host 命令。** 若現役接口名稱不同，以真 Receiver/Runner Discovery 與 Owner 決策為準，不自行假造 CLI。[N:B1 DOC-07][N:升級討論 §九]

### 6.6 Test Tracking List（TT-01～TT-40）

> 每個 Test 都需記錄 `test_id`, `source_ref`, `subject_sha`, `runner`, `principal`, `command`, `exit`, `observed_count`, `expected_count`, `raw_sha`, `result`, `timestamp`。`count=0` 的 PASS 無效，除非規範明確定義零分母是合法測試且有充分證據。[N:PIPD DOC-07][N:B1 DOC-05]

| Test | 情境／預期結果 | Gate |
|---|---|---|
| TT-01 | `SKILL.md` Frontmatter 有效、name lower-kebab、description 觸發明確 | G03 |
| TT-02 | 新 Skill 正確觸發於 design-intent 比對 | G08 |
| TT-03 | 無關閒聊／普通 Runtime 操作不觸發 Skill | G08 |
| TT-04 | 舊 Commander-SP 未被直接／間接裝載 | G09 |
| TT-05 | 無 PI/PD：標 MISSING，但能給合法 Read-only Bootstrap | G01/G03 |
| TT-06 | 缺 Source/Owner：不能自動宣稱已 Frozen | G01/G04 |
| TT-07 | Master Prompt 不會自行變 NORMATIVE | G04 |
| TT-08 | Guide 嘗試 Repo Mutation → 拒收 | G02/G03 |
| TT-09 | Guide 嘗試簽 Native Permit → 拒收 | G02/G03 |
| TT-10 | Guide 嘗試 Maker Self-Accept → 拒收 | G02/G15 |
| TT-11 | 單一 OWNER 原 Standing 授權有效時，普通工作不重問 | G02/G12 |
| TT-12 | 擴大授權 Scope → 具名局部 HOLD | G12 |
| TT-13 | 未註冊 TaskKind → HOLD 依賴卡，其他 READY 續行 | G10/G12 |
| TT-14 | Oracle 同階衝突 → PIPD CR_OPEN，不創新 Oracle | G04 |
| TT-15 | 受影 31 WO/OBS 依 EffectClass 正確分類 | G10/G12 |
| TT-16 | GUIDE→PLAN Candidate typed join、無 Native Issuer 冒名 | G10 |
| TT-17 | Task DAG 無環、Worker Role 不冒充 Principal | G10 |
| TT-18 | Job A PARK，不阻塞 B/C | G10/G13 |
| TT-19 | PLAN 專屬容量不耗盡 EXECUTE Quota | G13 |
| TT-20 | `PINNED gpt-6.1-sol` 真 Served/provider/effort | G11 |
| TT-21 | DeepSeek 被 MiMo 靜默替代 → FAIL | G11 |
| TT-22 | 有授權的備援重新 Admission 後可成功 | G11 |
| TT-23 | OpenAI OAuth 與 OpenCode Go Key 不交叉重用 | G11/G12 |
| TT-24 | Provider 不可信身份回報 → `UNVERIFIED_SERVED` | G11 |
| TT-25 | OpenSpec 錯 Root／0 Tests exit 0 → FAIL | G07/G16 |
| TT-26 | 24 Donor slots 保留、六類不遺失 | G06 |
| TT-27 | Donor 未安裝，合法唯讀方法仍可用 | G07 |
| TT-28 | Donor 實際安裝、載入、正觸發、誤觸發拒收 | G07/G08 |
| TT-29 | Donor 卸載後無殘留／無觸發 | G07/G08 |
| TT-30 | gstack `/ship` 不得觸發正式 Release | G02/G07 |
| TT-31 | GSD 不新增第二 Queue/Issuer | G06/G10 |
| TT-32 | Standalone Builder 功能未因 Guide 降權被刪 | G02/G16 |
| TT-33 | Windows User Trust profile 與 Receiver 實際鏈接 | G12/G17 |
| TT-34 | Host Effect 的 Nonce/TTL/Scope/Revoke 正反例 | G12 |
| TT-35 | Hermes Crash→新 OS Process 依狀態恢復 | G13 |
| TT-36 | UNKNOWN_EFFECT 先 Reconcile，不雙重 Effect | G13 |
| TT-37 | Fabric Active/Loaded/Consumer 同主體 Readback | G14 |
| TT-38 | Maker/Checker 同 SID 假隔離 → FAIL | G15 |
| TT-39 | 仍有 READY 卡時產報告不終止 Mission | G13 |
| TT-40 | 三 GWO＋G-B 按獨立身份，全部 Required 才正式 Release | G17/G18 |

**執行頻率：**G01–G07 每受影變更；G08/G09 每次 Host Pack/Version；G10–G13 每次 Runtime Adapter 變更及 Nightly 代表性 Fixtures；G14–G18 依實際 Native Effect、發行契約及 Owner Policy；不要用每次普通文字編輯強迫跑三 GWO。[N:PIPD DOC-08 §9]

### 6.7 並行、保留與停止條件

- `READ_ONLY` 和已有合法授權的其他 READY 卡可在受影 Native HOLD 時進行。
- 所有 Repo Mutation 必須先確認 Root/HEAD/WriteSet、符合現役 PIPD/HGK 適用 ExecutionAdmission；文件中提供的示範命令不代替真授權。
- 并行分派不可對同一受保護 Path 或相衝突的 Policy/Effect 產生雙重 Writer。
- 每張 Effect 操作採有效 Operation ID、Idempotency Key、World Readback；`UNKNOWN_EFFECT` 僅 reconciliation，不盲重播。
- `REPAIR_ITERATION`、`DIAGNOSTIC_ATTEMPT` 和 `NATIVE_EFFECT_ATTEMPT` 為不同計數器，不可用單一 Retry 上限全域停工。
- 提前 Seal、Context 壓縮、單一 Worker 退出，不是正式 Mission Termination 的充分條件。

## 7. 風險登記與 CR_OPEN（全部未知必須有處置）

### 7.1 風險登記表

| Risk | 等級 | 問題 | 影響 | 控制／降級 |
|---|---|---|---|---|
| RK-01 | P0 | 舊 Skill 引用進新版 Guide | B1 重新循環 | 靜態與 Host 反向觸發檢查 |
| RK-02 | P0 | SBL PLAN 自建第二 Issuer/Queue | 雙寫／效果重播 | HGK 唯一權威；Schema 不含 Permit |
| RK-03 | P0 | User Grant 解讀為全部 OS 權限 | 越權 | per-effect Native Admission、Trust Boundary |
| RK-04 | P0 | Checker 同 SID／Signer 私鑰可被 Maker 讀 | 虛假 SoD | 真 Principal 隔離、密鑰保護 |
| RK-05 | P0 | 模型 Provider 被靜默替代 | 指定模型失效 | Required/Served Raw，PINNED FAIL |
| RK-06 | P0 | 私有 Source/Key 傳向未核的外部模型 | 資料外洩 | deny-by-default Provider Data Policy |
| RK-07 | P1 | 24 Slot 未完整追溯 | 功能刪失 | Trace Matrix／差分驗證 |
| RK-08 | P1 | 過重 OpenSpec/Spec Kit/gstack/GSD 全啟用 | Token／使用摩擦 | Method-only、A/B、非必裝 |
| RK-09 | P1 | Host `discovered` 當 `invoked` | 假成功 | 動態觸發＋卸載反例 |
| RK-10 | P1 | 建議路徑與真 Repo 不同 | 錯寫其他 Repo | WP-00 真 ROOT／WriteSet |
| RK-11 | P1 | CI WriteSet 失敗被跳過 | 未授權變更進 Merge | 維持 Gate，修 Diff |
| RK-12 | P1 | SourceFreeze/Oracle 候選被冒稱有效 | 正式 Gate 錯放 | Claim Ceiling，CR_OPEN |
| RK-13 | P1 | 釋出工件缺可信來源與 provenance | 供應鏈風險 | SHA、SLSA 合法受影實作 |
| RK-14 | P1 | Windows Host 安裝不可回退 | 污染原宿主 | 受影 Worktree／Enable/Disable/Uninstall |
| RK-15 | P1 | Context Snapshot 引發工作狀態分岔 | 提早結案 | Snapshot ≠ queue; Resume Readback |
| RK-16 | P2 | 雙 Commander 命名混亂 | 誤調用舊外掛 | 清晰 ID/Name/Legacy mapping |
| RK-17 | P2 | 公開社群聲望快速變動 | 工具選型錯誤 | 版本／License／本機 A/B 而非 Star |
| RK-18 | P2 | User-scoped Key 安全保證不足 | Signer 與 Maker 不獨立 | Assurance Tier 明確降級、需實際隔離 |

### 7.2 CR_OPEN 清單（本輪現況，不得預設解決）

| CR | 必須確認的前提 | 本輪狀態 | 若缺失，封鎖什麼 | 合法降級與具名下一步 |
|---|---|---|---|---|
| CR-01 | Owner 對 ADR-SBL-COMMANDER-SPLIT 的正式 Ratification | **OPEN** | 舊正式產品義務修改／對外 Release | 提供 ADR 候選，不變更舊產品身份 |
| CR-02 | 真 SBL/HGK/Hermes/PIPD Repo Root、HEAD、Dirty、File ABI | **MISSING** | 受影 Repo Write/Patch | 只提供 path-proposed 工單；WP-00 read-only 探查 |
| CR-03 | 目標 Codex Host 版號、Skill Loader、Installed/Invoked 收據 | **MISSING** | Host Qualification | 靜態測試候選可用 |
| CR-04 | Hermes project-local Skill Loader 與實際配置 | **MISSING** | Hermes Host PASS | 不安裝、不宣稱相容 |
| CR-05 | HGK Native Receiver 現行 WorkOrder Proposal ABI | **MISSING** | 真 Proposal Admit/Issuer | 保留無權限 JSON Proposal |
| CR-06 | OpenAI OAuth／OpenCode Go 三模型現役 Routed/Served/Policy Epoch | **MISSING** | R4／正式 PLAN Model PASS | 路由只作 DESIGN_ONLY、PINNED Fail-safe |
| CR-07 | 六 Donor 真版本／License／Security Score／Host Supported | **MISSING** | 外部工具安裝與資格化 | METHOD_ONLY + Zero-donor fallback |
| CR-08 | HGK User Trust profile → Registry/Receiver 真連線 | **OPEN（r10 未閉合）** | Native Issuer/Receiver R1/T2 | 受影 Host Effect PARK |
| CR-09 | Hermes 真 Executor、Cross-Process Resume、Stop Controller | **OPEN** | R2/G-B 正式 PASS | Codex-first 無效應初版可行 |
| CR-10 | Fabric Activator→Consumer Loaded | **NOT_RUN in r10** | R3/G-A/GWO-Fabric | Stage 候選、隔離測試不冒稱 Loaded |
| CR-11 | 三模型 Required=Served 真調用與 fallback 負例 | **NOT_RUN in r10** | R4/G-A | 用已證現役模型進行普通非正式設計，正式模型 Gate HOLD |
| CR-12 | PIPD Oracle P4 與 Canonical DOC-07、12/9 axes Mapping | **OPEN** | 正式受影編譯／Ratification | Read-only Compare／Adapter Candidate |
| CR-13 | CI Stage-C ADR-0008/0009 WriteSet Fix 的最新狀態 | **REPORTED FAIL / LIVE NOT RECHECKED** | PIPD PR #20 受影 Merge/Release | 不放寬 Allowlist；核對真 Diff |
| CR-14 | GWO-HGK 的合法非 Commander-SP Proposal 入口 | **OPEN** | GWO-HGK 真 Effect | 新 SBL Proposal Adapter 候選 |
| CR-15 | 三 GWO／G-A／G-B 的 Checker Raw、真 OS Principal | **MISSING** | B1 Native Acceptance | 候選與可重算 Readback 分開 |
| CR-16 | 既有 Standalone Builder／六模組每項真路徑功能是否可用 | **MISSING** | 聲稱零回歸正式完成 | 凍結原測試，對受影項做 Compatibility Map |
| CR-17 | 新 Guide 與 Prompt/AGENTS 的同 Fixture A/B 效率收益 | **NOT_RUN** | 宣稱 Skill 優於 baseline | 先完成普通 Prompt；Skill 候選仍可試做 |
| CR-18 | 可用的 Native Independent Checker、Signing Keys、Trust Boundary | **MISSING** | 正式 Acceptance／Release | Maker 測試只能 CANDIDATE |
| CR-19 | SBL DOC-00～13 修訂後的跨版本 Trace Coverage | **NOT_RUN** | 全產品修訂正式版本宣稱 | 先出各章受影對應及 Supersession 候選 |
| CR-20 | 具體受影 OWNER Risk Ceiling／OS 及 User Data Consent | **MISSING FOR THIS SESSION** | Native Host/User Effect | 普通只讀、純文字規劃；不執行 OS 效果 |
| CR-21 | 可用 Repo GitHub Actions 主分支策略、Runner、SHA Pin Policy | **MISSING** | 正式 CI／Release Pipeline | 提供 read-only Workflow 候選 |
| CR-22 | 薄 Skill 的真 Host Negative Trigger、卸載殘留及安裝撤回 | **NOT_RUN** | `HOST_QUALIFIED` | 靜態 Skill 而非有效安裝 |
| CR-23 | `.md` 報告本身的正式歸檔位置、Owner、SourceFreeze | **OPEN** | 把本報告當正式 NORMATIVE | 本次僅 conversation-delivered design candidate |
| CR-24 | 是否已存在完整獨立外部 GPT Plugin 的既有效果型產品義務 | **OPEN** | 直接刪舊 Plugin Deliverable |保留 Legacy Obligation，經 Owner ADR 後處置 |

**封鎖範圍：**所有 `CR_OPEN` 都阻止**其受影的正式聲明／Release**，不把 24 個 CR 一律投影為任何普通 Read-only 工作不可開始；關鍵 Gate 缺證據即 FAIL-CLOSED 是 Release 語義，非任務永久停工。[N:B1 DOC-00][N:PIPD DOC-05]

## 8. 交付、Rollback、Runbook 及驗收交接

### 8.1 候選工件清單

- Versioned ADR、Product Identity Map、Guide Skill Bundle、Guide Proposal Schema、Validator/Tests、Donor Capability Registry；必要時 Internal PLAN Role Policy Candidate、Receiver Adapter、真 Native Raw、Host Test Receipt。
- 每個工件附：`source_ref`, `source_sha`, `subject_sha`, `schema_version`, `maker_principal`, `observed_exit`, `raw_log_sha`, `claim_ceiling`, `checker_ref`，其中不適用可具名 `N/A`，不可偽造。
- GitHub Actions 工件包含基於真 SHA 的 CI Check Runs；合併、正式 Tag、Release 由當前有效權限的 Publisher 執行。
- 不將 Agent 私有推理、密鑰、Owner Token、個資或無關工作日誌上傳公開 Repo。[N:SBL DOC-09/12][W04][W06][W07]

### 8.2 回退策略

| 問題 | 回退行為 |
|---|---|
| 新 Guide 觸發錯誤 | 停用／移除單一 Skill，不影響內部 PLAN | 
| JSON Schema 漂移 | 停新版本，保留相容的先前已驗候選及明確拒收 |
| Donor 安裝造成 Host 污染 | 使用原始 Installer/Uninstaller 的反向程序，核對殘留／配置；不可自行 `rm -rf` 未核路徑 |
| PLAN 模型路由錯配 | 停新 Role Binding，回復現役有效 Model Policy；未經准入不得 Fallback |
| 新 Adapter 未相容 HGK | 卸除 Adapter，恢復原有 HGK WorkOrder 單一權威 |
| HGK/Hermes Native Effect 未知 | 先查 World State，依正式 ECP Compensation，不盲重播 |
| 發行證據缺失 | 取消 Release Candidate 升格，保留其候選測試結果 |

### 8.3 最終 Release Decision Rule

**正式判準：**

```text
ALLOW_DESIGN_CANDIDATE = source-grounded AND no invented authority
ALLOW_LOCAL_BUILD = real_repo_grant AND root_head_writeset AND applicable_execution_admission
ALLOW_NATIVE_EFFECT = valid_per_effect_permit AND receiver_ack AND policy_loaded_if_required
ALLOW_HOST_QUALIFIED = installed AND loaded AND invoked_pos AND denied_neg AND clean_uninstall
ALLOW_INDEPENDENT_ACCEPTANCE = frozen_subject AND raw AND distinct_checker_principal AND oracle_pass
ALLOW_RELEASE = applicable_required_gates_pass AND zero_blocking_CR AND authorized_publisher_receipt
```

此為概念級條件表達，需由 Owner 將其映射至現役 HGK/PIPD Schema；本輪不能聲稱該布林運算已在 Windows 真執行。[N:SBL DOC-07–09][N:PIPD DOC-05–09][N:B1 DOC-08]

### 8.4 本輪正式總裁決

| 層級 | 裁決 | 依據 |
|---|---|---|
| 文件可以作「施工藍圖候選」 | `DESIGN_REPAIR_PROPOSAL_READY` | 受影規範與證據 locator、Code/Tests、CR_OPEN 已列出 |
| 正式 SBL Owner ADR | `HOLD` | CR-01／CR-24 |
| 新 Guide Skill 已在 Codex 真掛載 | `NOT_RUN` | CR-03／CR-22 |
| 新 Guide Skill 已具完整自動化 | `NOT_PROVEN` | WP-00～12 尚未在 Windows 執行 |
| 內部 PLAN 專用 Role 真接線 | `NOT_RUN` | CR-05／CR-06 |
| B1 Native Effect／G-B | `FAIL-CLOSED / HOLD` | r10 適用 Gate 未閉合；CR-08～15 |
| 正式 Release | **`FAIL-CLOSED`** | 真 Ratification、Host、Checker、Publisher 不足 |

**結語：**應修復的是角色適用性、合約流向和 Native 接線，而不是用更長 Prompt、全套外部 Agent Framework 或第二個管制平面取代現有原則。外部 Guide 的治理越薄，效果權限邊界越要精確；內部 PLAN 可以高自治但不得越過 HGK Issuer／Checker。優先 Codex-first 候選，再由 Hermes/HGK 真正完成長任務、模型及世界效果的 Native 驗收。[N:升級討論 L2000–2645][N:FHS 藍圖 §5.2][N:SBL DOC-04/06/12]


## 9. 自動化機器讀取區塊（內容內嵌；不能當作已部署檔）

### 9.1 `machine_summary.json`

```json
{
  "artifact": "SBL_COMMANDER_DUAL_PRODUCT_RESTRUCTURING_BLUEPRINT",
  "schema_version": "1.0.0-candidate",
  "date": "2026-10-27",
  "report_claim_ceiling": "DESIGN_REPAIR_PROPOSAL_READY",
  "formal_release": "FAIL_CLOSED",
  "independent_checker_receipt": null,
  "native_acceptance": null,
  "source_inventory": {
    "source_file_count": 40,
    "status": "LOCAL_FILES_UTF8_READ_AND_SHA256_ONLY_NOT_SOURCEFREEZE"
  },
  "recommended_architecture": {
    "external": "SBL-COMMANDER-GUIDE / no effect / thin skill",
    "internal": "HGK.PLAN.SBL_COMMANDER / plan-propose-replan",
    "canonical_contract": "PIPD-LS-SP unique Writer",
    "native_authority": "HG-KSEOS unique WorkOrder/Issuer/State",
    "runtime": "Hermes unique Durable Dispatcher",
    "policy": "Fabric Policy Loaded + Consumer ACK",
    "executor": "Codex bounded writer",
    "checker": "Independent principal AO",
    "physical_lanes": [
      "PLAN",
      "EXECUTE",
      "VERIFY_SECURITY"
    ],
    "no_extra_lane": true,
    "no_second_queue": true,
    "no_legacy_commander_dependency_for_B1": true
  },
  "build_strategy": {
    "guide": "CODEX_FIRST_ISOLATED_BUILD_TEST",
    "native_plan": "HERMES_HGK_INTEGRATION_AND_CHECK",
    "maker_can_formal_self_accept": false,
    "formal_release_requires_owner_and_checker": true
  },
  "plan_models": [
    {
      "priority": 0,
      "provider": "openai",
      "model": "gpt-6.1-sol",
      "effort": "medium",
      "state": "DESIGN_PENDING_HOST_READBACK"
    },
    {
      "priority": 1,
      "provider": "opencode-go",
      "model": "deepseek-v4.1-flash",
      "state": "DESIGN_PENDING_HOST_READBACK"
    },
    {
      "priority": 2,
      "provider": "opencode-go",
      "model": "mimo-v2.6-flash",
      "state": "DESIGN_PENDING_HOST_READBACK"
    }
  ],
  "donor_groups": {
    "OpenSpec": [
      "OS-01",
      "OS-02",
      "OS-03",
      "OS-04"
    ],
    "SpecKit": [
      "SK-01",
      "SK-02",
      "SK-03",
      "SK-04"
    ],
    "MattSkills": [
      "MP-01",
      "MP-02",
      "MP-03",
      "MP-04"
    ],
    "GSD": [
      "GS-01",
      "GS-02",
      "GS-03",
      "GS-04"
    ],
    "gstack": [
      "GT-01",
      "GT-02",
      "GT-03",
      "GT-04"
    ],
    "Superpowers": [
      "SP-01",
      "SP-02",
      "SP-03",
      "SP-04"
    ]
  },
  "required_gates": [
    {
      "id": "G01",
      "name": "Input Integrity",
      "responsible": "PIPD Source Reader",
      "current": "NOT_RUN_OR_UNVERIFIED"
    },
    {
      "id": "G02",
      "name": "Role SoD",
      "responsible": "SBL Security/HGK",
      "current": "NOT_RUN_OR_UNVERIFIED"
    },
    {
      "id": "G03",
      "name": "Guide Schema",
      "responsible": "Codex Maker",
      "current": "NOT_RUN_OR_UNVERIFIED"
    },
    {
      "id": "G04",
      "name": "PIPD Canonical",
      "responsible": "PIPD Owner",
      "current": "NOT_RUN_OR_UNVERIFIED"
    },
    {
      "id": "G05",
      "name": "Same Fixture A/B",
      "responsible": "SBL QA",
      "current": "NOT_RUN_OR_UNVERIFIED"
    },
    {
      "id": "G06",
      "name": "24 Donor Slots",
      "responsible": "SBL Donor Owner",
      "current": "NOT_RUN_OR_UNVERIFIED"
    },
    {
      "id": "G07",
      "name": "Donor Admission",
      "responsible": "SBL Tool Owner",
      "current": "NOT_RUN_OR_UNVERIFIED"
    },
    {
      "id": "G08",
      "name": "Codex Host Invoke",
      "responsible": "Codex Host QA",
      "current": "NOT_RUN_OR_UNVERIFIED"
    },
    {
      "id": "G09",
      "name": "Legacy Skill Isolation",
      "responsible": "SBL/HGK QA",
      "current": "NOT_RUN_OR_UNVERIFIED"
    },
    {
      "id": "G10",
      "name": "PLAN Task DAG",
      "responsible": "SBL PLAN",
      "current": "NOT_RUN_OR_UNVERIFIED"
    },
    {
      "id": "G11",
      "name": "Model Served Identity",
      "responsible": "HGK Model Router",
      "current": "NOT_RUN_OR_UNVERIFIED"
    },
    {
      "id": "G12",
      "name": "EffectClass Admission",
      "responsible": "HGK Issuer",
      "current": "NOT_RUN_OR_UNVERIFIED"
    },
    {
      "id": "G13",
      "name": "Durable Continuation",
      "responsible": "Hermes Runtime",
      "current": "NOT_RUN_OR_UNVERIFIED"
    },
    {
      "id": "G14",
      "name": "Fabric Effective Readback",
      "responsible": "Fabric Consumer Owner",
      "current": "NOT_RUN_OR_UNVERIFIED"
    },
    {
      "id": "G15",
      "name": "Independent Checker",
      "responsible": "AO/Checker",
      "current": "NOT_RUN_OR_UNVERIFIED"
    },
    {
      "id": "G16",
      "name": "CI WriteSet",
      "responsible": "Repo CI Owner",
      "current": "NOT_RUN_OR_UNVERIFIED"
    },
    {
      "id": "G17",
      "name": "GWO/G-B Native",
      "responsible": "B1 Native Owners",
      "current": "NOT_RUN_OR_UNVERIFIED"
    },
    {
      "id": "G18",
      "name": "Formal Release",
      "responsible": "Release Publisher",
      "current": "NOT_RUN_OR_UNVERIFIED"
    }
  ],
  "release_blockers": [
    "CR-01",
    "CR-02",
    "CR-03",
    "CR-04",
    "CR-05",
    "CR-06",
    "CR-07",
    "CR-08",
    "CR-09",
    "CR-10",
    "CR-11",
    "CR-12",
    "CR-13",
    "CR-14",
    "CR-15",
    "CR-16",
    "CR-17",
    "CR-18",
    "CR-19",
    "CR-20",
    "CR-21",
    "CR-22",
    "CR-23",
    "CR-24"
  ],
  "statuses": {
    "proposed_paths": "NOT_CONFIRMED_IN_REAL_REPO",
    "sourcefreeze": "HOLD",
    "owner_adr_ratification": "HOLD",
    "host_load": "NOT_RUN",
    "native_effect": "NOT_RUN",
    "release": "FAIL_CLOSED"
  },
  "normative_scope": "USER + OWNER VALID SBL/PIPD/FHS/B1 DESIGN, SUBJECT TO RATIFICATION",
  "support": "WEB TECH SOURCES W01-W20, NO AUTHORITY OVER SSOT"
}
```

### 9.2 `change_plan.tsv`

```tsv
path	change_type	reason	priority	source_locator
.agents/skills/sbl-commander-guide/SKILL.md	ADD	Candidate guide no effect	P1	SBL DOC-04 C12.4.3
schemas/sbl/guide-proposal.schema.json	ADD	Typed no-authority candidate	P1	SBL DOC-04; PIPD DOC-05
scripts/sbl/validate_guide.py	ADD	Fail-closed proposal guard	P1	PIPD DOC-05/08
tests/sbl/test_validate_guide.py	ADD	Positive negative fixture	P1	SBL DOC-08
.github/workflows/sbl-commander-guide-verify.yml	ADD	Read-only pinned CI	P1	GitHub Actions Secure Use
configs/sbl/commander-plan-policy.json	ADD-CANDIDATE	PLAN role three model desired config	P1	FHS-MSC total discussion
docs/adr/ADR-SBL-COMMANDER-SPLIT.md	ADD	Owner ratified dual product boundary	P0	SBL DOC-01/04/12
docs/sbl/commander-compatibility-map.md	ADD	Preserve all original obligations	P0	FHS-MSC blueprint §5.3
docs/sbl/donor-capabilities.tsv	ADD	Six donor 24 slots	P1	SBL DOC-06 C32
sbl_sp/manifests/commander_sp.json	REVIEW-THEN-MODIFY	Move product.write off external skill	P0	FHS-MSC blueprint §5.3
sbl_core/modes.py	REVIEW-THEN-MODIFY	Keep Standalone/Connected modes	P1	FHS-MSC blueprint §5.3
<DISCOVERED_SBL_BRIDGE_PATH>	DISCOVER-THEN-MODIFY	Legal proposal not issued WO	P0	B1 DOC-08
<DISCOVERED_HGK_PLAN_ROLE_PATH>	DISCOVER-THEN-MODIFY	Use existing PLAN role pool	P0	FHS-MSC blueprint §5.2
<DISCOVERED_HERMES_EXECUTOR_PATH>	DISCOVER-THEN-MODIFY	Durable recovery no second queue	P0	B1 handoff §0
<DISCOVERED_HGK_RECEIVER_PATH>	DISCOVER-THEN-MODIFY	Trust/profile true receiver wiring	P0	B1 handoff §0
<DISCOVERED_FABRIC_ACTIVATOR_PATH>	REVIEW-ONLY-BEFORE-PATCH	Stage active loaded consumer receipt	P1	B1 DOC-08
<DISCOVERED_PIPD_ABI_PATH>	REVIEW-ONLY-BEFORE-PATCH	Oracle/profile axes/live split	P1	PIPD DOC-06/07
FHS_MSC_B1_PIPD_LS_PKG_08_GOLDEN_WORKORDERS_E2E.md	VERSIONED-AMENDMENT	Clarify plan.propose candidate nonlegacy	P0	B1 DOC-08 §2
SBL_PIPD-LS-PKG_DOC-00..13.md	AFFECTED-VERSIONED-ADDENDUM	Dual role and no silent loss	P1	SBL DOC-00..13
```

### 9.3 `checkrun_contract.tsv`

```tsv
check_id	required_check	responsible	degrade_on_failure	source_locator
G01	Input Integrity	PIPD Source Reader	MISSING→affected-only HOLD	PIPD DOC-01/03
G02	Role SoD	SBL Security/HGK	permission violation→FAIL	SBL DOC-07
G03	Guide Schema	Codex Maker	no native claim; negative failures→FAIL	SBL DOC-04; Agent Skills spec
G04	PIPD Canonical	PIPD Owner	read only candidate	PIPD DOC-02/04
G05	Same Fixture A/B	SBL QA	baseline missing→HOLD	PIPD DOC-08 §9
G06	24 Donor Slots	SBL Donor Owner	missing slot→FAIL	SBL DOC-06 C32
G07	Donor Admission	SBL Tool Owner	absent tool→METHOD_ONLY or NO_FIT	PIPD DOC-08 §9
G08	Codex Host Invoke	Codex Host QA	not loaded→NOT_RUN	Agent Skills; OpenSpec supported-tools
G09	Legacy Skill Isolation	SBL/HGK QA	legacy invoked→FAIL	B1 handoff §1
G10	PLAN Task DAG	SBL PLAN	cycle/global HOLD→FAIL	FHS-MSC blueprint §5.2
G11	Model Served Identity	HGK Model Router	unverified/mismatch→HOLD	FHS-MSC discussion R17
G12	EffectClass Admission	HGK Issuer	no permit→PARK affected	B1 DOC-02/03
G13	Durable Continuation	Hermes Runtime	no true worker→HOLD	B1 handoff §0
G14	Fabric Effective Readback	Fabric Consumer Owner	R3 NOT_RUN→HOLD	B1 DOC-08
G15	Independent Checker	AO/Checker	same principal→FAIL	SBL DOC-08; B1 DOC-05
G16	CI WriteSet	Repo CI Owner	stage-C failure→FAIL	B1 handoff PR20
G17	GWO/G-B Native	B1 Native Owners	any receipt missing→HOLD	B1 DOC-08
G18	Formal Release	Release Publisher	any required failing/CR blocker→FAIL-CLOSED	SBL DOC-09/12; PIPD DOC-09
```

> **機器區塊使用限制：**本節內 `current=NOT_RUN_OR_UNVERIFIED` 為設計交付當下狀態，不是腳本回報；需由真 Runner 替換為有 Raw/SHA/Principal 的實測結果。所有 `<DISCOVERED_...>`、`version=candidate`、`state=DESIGN_ONLY` 必須在真 Repo 盤點後綁定，否則禁止正式 Release。[N:PIPD DOC-03/05/07]

## 附錄 A｜本輪所有直接讀取附件的位元組清冊（Inputs Manifest Full）

> **注意：**SHA-256 為本執行環境所列附件的原始檔位元組；不能替代各 Repository 工作樹的 HEAD、Owner SourceFreeze 簽章或 Runtime Loaded SHA。MD 文字為嚴格 UTF-8 解碼；`Lines` 依 Python `splitlines()`。

| ID | Family | Exact local source filename | Bytes | Lines | SHA-256 | Status |
|---|---|---|---:|---:|---|---|
| SRC-001 | B1 Historical | `B1指揮施工_總紀錄.md` | 365435 | 6855 | `5e83ec59cf226d666146f0d73436cd87b30e35d30918657c6762f04ee576208c` | FOUND/UTF8_READ |
| SRC-002 | B1 Historical | `B1施工_PROMPT.md` | 248187 | 1643 | `6f24b2aac28dd8b3aa4823250dc6c18115580f743f141d2db2fb3011e8804409` | FOUND/UTF8_READ |
| SRC-003 | B1 Historical | `B1施工狀況_總鑑定分析.md` | 355565 | 6658 | `a7b17816b46d8f4ff38a3b62b336b7d36895d9730e82e6b8f892141f013f4936` | FOUND/UTF8_READ |
| SRC-004 | FHS-MSC | `FHS-MSC_總討論(1).md` | 283613 | 4930 | `9ecd1f6f1d9c854206eee4a12519b08e6caf61951a3735502654272416ae0597` | FOUND/UTF8_READ |
| SRC-005 | FHS-MSC | `FHS-MSC_藍圖_r2(2).md` | 1320878 | 4191 | `a80b3b4d7cc93e52a297a3e5176e27f207b36b8cd81a3d5440c70b4a80290ff9` | FOUND/UTF8_READ |
| SRC-006 | B1 Design Control | `FHS_MSC_B1_PIPD_LS_PKG_00_GOVERNANCE_AND_CONTROL(1).md` | 10324 | 111 | `3096e98096ad48b3b3cfda07c6075ccffba8b44c1851a804d63f0ab103aef576` | FOUND/UTF8_READ |
| SRC-007 | B1 Design Control | `FHS_MSC_B1_PIPD_LS_PKG_01_DOC_B1_PI(1).md` | 53244 | 341 | `e1d8931c036a1e9dc97f79a3d0d00f151ea5a29dc81fb3d7aa488d5446d7b666` | FOUND/UTF8_READ |
| SRC-008 | B1 Design Control | `FHS_MSC_B1_PIPD_LS_PKG_02_DOC_B1_PD(1).md` | 62807 | 1289 | `8e15b92a69302bbb0f9a6352f80c9687fdfb3a217006703a87b3ba559f42eb2b` | FOUND/UTF8_READ |
| SRC-009 | B1 Design Control | `FHS_MSC_B1_PIPD_LS_PKG_03_DOC_B1_OPS_ECP(1).md` | 24829 | 756 | `54a17818473f2a4b7c4f0f8f504bc96e4e1450540facfd30cf38234fa89e8b8a` | FOUND/UTF8_READ |
| SRC-010 | B1 Design Control | `FHS_MSC_B1_PIPD_LS_PKG_04_DOC_B1_DEV_ECP(1).md` | 9287 | 101 | `7a1e44dfd91bd24011c019f3ff73446e6cebf4b7847d7220f7c78dc25927def5` | FOUND/UTF8_READ |
| SRC-011 | B1 Design Control | `FHS_MSC_B1_PIPD_LS_PKG_05_DOC_B1_TQAEP(1).md` | 455090 | 12056 | `1e09126f0c8e92fcd6e8531072a3f1f3033d82a671c2b4bb62c9916e675b7127` | FOUND/UTF8_READ |
| SRC-012 | B1 Design Control | `FHS_MSC_B1_PIPD_LS_PKG_06_PRODUCT_COVERAGE_AND_R15(1).md` | 859287 | 6919 | `f929d9cffd462d23bbdb52171f72a450e96e59c8333bc05ebd739a2d38338337` | FOUND/UTF8_READ |
| SRC-013 | B1 Design Control | `FHS_MSC_B1_PIPD_LS_PKG_07_NATIVE_TOOLCHAIN_EXACT_USAGE(1).md` | 19392 | 141 | `d1e0283200ad57cf1a3a1fc62bc09c6980ff118d4b7af4401d011ea87a009ea7` | FOUND/UTF8_READ |
| SRC-014 | B1 Design Control | `FHS_MSC_B1_PIPD_LS_PKG_08_GOLDEN_WORKORDERS_E2E(1).md` | 6741 | 70 | `bc12a5fca45e4f68c1b1a4772b00ca72e0c07be8293527bbaafceadc7347290f` | FOUND/UTF8_READ |
| SRC-015 | FHS-MSC | `FHS_MSC_B1_Task_Handoff_Report_v1_2026-10-27.md` | 80850 | 734 | `aa006bc849c5bb6404265de6a28678e0a4ed8b75b13521b39d5dcf28fc07162d` | FOUND/UTF8_READ |
| SRC-016 | PIPD-LS | `PIPD_LS_DOC-00_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md` | 251982 | 2292 | `be3a672ec20aa0e6b5e0e35097fc08de749bfe7f59f827d18e38aef67dd68ea4` | FOUND/UTF8_READ |
| SRC-017 | PIPD-LS | `PIPD_LS_DOC-01_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md` | 177451 | 2592 | `b753f2e5cdd5598a818f8a113d57b7f815aeb3f1dfa061ce74c76bb3553ac8c7` | FOUND/UTF8_READ |
| SRC-018 | PIPD-LS | `PIPD_LS_DOC-02_2026-10-07_r2_HIGH_RETENTION_AUDIT_PATCHED_FULL_REPAIR_FULL_SUBSTANTIVE_BODY (1).md` | 1306240 | 18413 | `a021998dd3b63015e89af1dd40e0b413744a69b872da46c6bf5f4d92f7f23d0b` | FOUND/UTF8_READ |
| SRC-019 | PIPD-LS | `PIPD_LS_DOC-03_2026-10-07_r2_AUDIT_REPAIR_FULL_SUBSTANTIVE_BODY.md` | 454167 | 1911 | `d89d82dcd2c8603ec6b86c5ec8c40845e4594bc181adf5272bd48a3de7c88f0f` | FOUND/UTF8_READ |
| SRC-020 | PIPD-LS | `PIPD_LS_DOC-04_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md` | 181988 | 4052 | `fa64d84da3d747b183e4affff62f4d2fb86c80bb5075f5dd933c09b20caeddcf` | FOUND/UTF8_READ |
| SRC-021 | PIPD-LS | `PIPD_LS_DOC-05_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md` | 227894 | 3946 | `7b40584540c162cda6debfd09a4c04321416706acdb03a7a3c2b41383dc585f4` | FOUND/UTF8_READ |
| SRC-022 | PIPD-LS | `PIPD_LS_DOC-06_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md` | 405028 | 3790 | `20e44ea4dd8e53c9b0a076ce861136bbea86f52687019307f6e995cd9079d303` | FOUND/UTF8_READ |
| SRC-023 | PIPD-LS | `PIPD_LS_DOC-07_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md` | 689563 | 12915 | `a68dae1c3670d07bcfa3476a1e37463c534594df5cd65d8dab0dca064b5a9fc1` | FOUND/UTF8_READ |
| SRC-024 | PIPD-LS | `PIPD_LS_DOC-08_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md` | 197972 | 2501 | `e46caa7e440392a6cfa7a86421aead5bce8a2a229fec97b133429db6b6748e42` | FOUND/UTF8_READ |
| SRC-025 | PIPD-LS | `PIPD_LS_DOC-09_2026-10-07_r2_HIGH_RETENTION_AUDIT_PATCHED_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md` | 144948 | 2451 | `eaf0aefe2b4711c140fc3274223d88fdc38ad4ec2b7184f756a0f2471f3b0b54` | FOUND/UTF8_READ |
| SRC-026 | Commander Upgrade Transcript | `SBL Commander & SBL-Commander-Skill_升級討論.md` | 126454 | 2650 | `61c16f2d9a8100c0e60265666ccf238c05d3eda87f0123ec7730b1064bec5c8e` | FOUND/UTF8_READ |
| SRC-027 | SBL_PIPD-LS-PKG | `SBL_PIPD-LS-PKG_DOC-00.md` | 465363 | 1591 | `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01` | FOUND/UTF8_READ |
| SRC-028 | SBL_PIPD-LS-PKG | `SBL_PIPD-LS-PKG_DOC-01.md` | 1041962 | 4938 | `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f` | FOUND/UTF8_READ |
| SRC-029 | SBL_PIPD-LS-PKG | `SBL_PIPD-LS-PKG_DOC-02.md` | 1148207 | 11084 | `4ff0cda5ab00ba5f577151e5b004d2167d933e912e302c9e3529b237ccb9e035` | FOUND/UTF8_READ |
| SRC-030 | SBL_PIPD-LS-PKG | `SBL_PIPD-LS-PKG_DOC-03.md` | 1704253 | 4851 | `ea69e1d3718ed86aecd74a3ebcc933960eacc30b586ab80fcb9f733037e33476` | FOUND/UTF8_READ |
| SRC-031 | SBL_PIPD-LS-PKG | `SBL_PIPD-LS-PKG_DOC-04.md` | 618110 | 3036 | `ee90cb1c86f6f7350c11c9c962233a89b035ca41ff82c8968f7968608fc6f6e0` | FOUND/UTF8_READ |
| SRC-032 | SBL_PIPD-LS-PKG | `SBL_PIPD-LS-PKG_DOC-05.md` | 2382349 | 7888 | `3b47a0b6224b1984a4047cf53aac5ac50615c93a560fea46e1b43d079a5d9f27` | FOUND/UTF8_READ |
| SRC-033 | SBL_PIPD-LS-PKG | `SBL_PIPD-LS-PKG_DOC-06.md` | 1554880 | 2858 | `64ea4977dab3093301f82dc7469413cc754998fc53946467842e06d83645102b` | FOUND/UTF8_READ |
| SRC-034 | SBL_PIPD-LS-PKG | `SBL_PIPD-LS-PKG_DOC-07.md` | 1265128 | 3620 | `a366d3783c82089c5593ffabb0704d8507632cce45622684f7a0186f2ae310f8` | FOUND/UTF8_READ |
| SRC-035 | SBL_PIPD-LS-PKG | `SBL_PIPD-LS-PKG_DOC-08.md` | 925526 | 11139 | `c7029c1ff07abe3135d33d3abf858a5fecedd911b494cd69c16eb1ddb8158288` | FOUND/UTF8_READ |
| SRC-036 | SBL_PIPD-LS-PKG | `SBL_PIPD-LS-PKG_DOC-09.md` | 904598 | 3978 | `6450f7c15915ec8b304f4e5fd4093ea707434db8bae9d2bb6e66c30ab6eed2e1` | FOUND/UTF8_READ |
| SRC-037 | SBL_PIPD-LS-PKG | `SBL_PIPD-LS-PKG_DOC-10.md` | 1397936 | 3888 | `a64aa21c977334dd74d660a86377ee10c4d329aa5fde0dae25ff81a3e69e8d8f` | FOUND/UTF8_READ |
| SRC-038 | SBL_PIPD-LS-PKG | `SBL_PIPD-LS-PKG_DOC-11.md` | 1831131 | 5005 | `12f8705d780b76f264457c194a6ff359da8d74b5d6d8c83fa245b74d2a37508e` | FOUND/UTF8_READ |
| SRC-039 | SBL_PIPD-LS-PKG | `SBL_PIPD-LS-PKG_DOC-12.md` | 982931 | 7940 | `d1e470d82ca14319582cb8947aa52007927aa38e726249b1430804cfe8c8ca56` | FOUND/UTF8_READ |
| SRC-040 | SBL_PIPD-LS-PKG | `SBL_PIPD-LS-PKG_DOC-13.md` | 1251068 | 3814 | `7cc0c8b17311130c875910b2548b93c28bd4e1c8ee04d300f85fc33d4c09beb1` | FOUND/UTF8_READ |

**其他非檔案來源：**`CURRENT_CONVERSATION`（本頁訊息，User 指令與 AI 答覆分法位）、`PLUGIN_STATIC_SKILL_URI`（靜態已讀／`HOST_PENDING`，非載入／不啟動）、`WEB_W01..W20`（公開 SUPPORT）。如需具正式 SourceFreeze 的完整來源包，仍屬 `CR-01/02/23`。

## 附錄 B｜高優先設計衝突與修復歸屬 Trace

| Conflict | 舊狀態 A | 舊狀態 B | 本次提案裁決 | 所需正式權威 |
|---|---|---|---|---|
| IC-01 | Plugin Skill `build principal` / `apply it` | SBL DOC-04 `NO_WORKORDER_ISSUE` | Guide/PLAN/Builder 分責 | SBL Product Owner |
| IC-02 | SBL DOC-03 先有受准入 ECP/WO 才薄指揮 | B1 DOC-08 要 Commander 先提出候選 WO | Proposal 與 Issued WO 分 ABI | SBL＋HGK Owners |
| IC-03 | 舊 Skill `HOST_PENDING` | 早期 GPT-6 當成全局施工控制 | Skill 僅 SUPPORT；不能作 Native Gate | Host/SBL Owner |
| IC-04 | CAPC C0-C9 Contract Domains | C0-C9 被用成十階 Pipeline | Domain/Stage 嚴格分離 | PIPD/CAPC Owner |
| IC-05 | Owner 已給 Mission Grant | Agent 要求每張低風險卡重簽 | Standing Authorization + effect-specific admission | Owner/HGK |
| IC-06 | PIPD Canonical Writer | Guide/Commander 自造 Second Source Truth | Guide/PLAN 僅 Read/Propose | PIPD Owner |
| IC-07 | HGK WorkOrder State | GSD/Hermes/Commander 可能各有 Queue | 僅 HGK/Hermes Single Durable State | HGK/Hermes |
| IC-08 | SBL v0.1 `product.write` | 外部 Commander 需唯讀 | StandAlone Builder 另 Profile 承接 | SBL Owner |
| IC-09 | 完全 Plugin/ZIP 既有 SBL 產品身份 | 薄 Skill Minimum-Sufficient Architecture | 正式 Supersession ADR；產品義務不靜默刪 | SBL/PIPD Owners |
| IC-10 | 模型設定/Session Pin | 實際 Served Model/Principal | 先 Native readback，再接納/合法備援 | HGK Model Owner |
| IC-11 | Stage/Active Repo SHA | Host Loaded／Consumer readback | 四種異效證據分開 | Fabric Owner |
| IC-12 | 同 SID 多 Agent | 需真 Maker/Checker SoD | 不同 OS/Service 權限及有效 Oracle | AO/Owner |
| IC-13 | TQAEP Design Fixture | TQAEP Live Receipt | 標 PLANNED/EXECUTED/INDEPENDENT_VERIFIED | PIPD Oracle Owner |
| IC-14 | PIPD CI offline-gate success | public-plugin-verify Stage-C WriteSet fail | 雙受影 CI gate 真修補 | PIPD Repo Owner |
| IC-15 | 報告封存 DONE | Durable Work READY > 0 | Report≠Mission Terminal | Hermes Runtime Owner |

## 附錄 C｜明確未達成的實機證據與下游讀者免誤用宣告

**下列事項全部未於本輪執行：**Codex 真 Host 安裝與互動回讀、新 Skill 正反例觸發、Hermes/HGK 本地 Executor、HGK Native Receiver、Fabric Activator Loaded、三模型 Served Receipt、跨 OS Process Resume、GWO×3、G-B、Maker/Checker OS 身份隔離、SourceFreeze Ratification、Owner 發布。僅交付藍圖及內嵌候選代碼；後續按 `WP-00..12` 與 `G01..G18` 進行實測，不能只把本文件的 `machine_summary.json` 送回 Checker 當作 Raw。

**檔案完整性聲明：**本單一 MD 已含：封面、Inputs Manifest、Authority、28 RCA、Web Support、產品分離、事件／權限／降級、實例程式、Workflow、分階段計畫、Gate、40 Tests、18 Risks、24 CR_OPEN、三機器區塊及逐檔 SHA 清冊；不代表已取得原生運行或正式釋出。
