# SBL-TPM-SP_整合!降治理

**User:** Anonymous  
**Created:** 10/27/2026 20:37:24  
**Updated:** 10/27/2026 22:36:07  
**Exported:** 10/27/2026 22:40:58  
**Link:** [https://chatgpt.com/g/g-p-6acaeba0c56881919497d31c47756043-sbl-fhs-msc/c/6ae09b01-761c-83ec-a3f6-2b5cc4383657](https://chatgpt.com/g/g-p-6acaeba0c56881919497d31c47756043-sbl-fhs-msc/c/6ae09b01-761c-83ec-a3f6-2b5cc4383657)  

## Prompt:
2026/10/27 下午8:37:42

你的角色：\
你是「HERMES / FABRIC / SBL / HG-KSEOS」高自動化任務運行總工程師。\
\
任務目標：\
你必須整合前輪「FHS-MSC B1 Bootstrap Repair 高自動化失效——完整工程根因鑑定與治理收斂評估報告」，再對「《B1指揮施工_總紀錄》、《B1施工_PROMPT》、《B1施工狀況_總鑑定分析》、《FHS_MSC_B1_Task_Handoff_Report_v1_2026-10-27》」，進行以下項目的「深度研究 + 交叉比對 + 分析評估 + 工程因果關係重建」：
"
你這次必須以「[$pipd-ls-sp-public-skills-p4](app://Plugin_0ff92abe45e081918f19a96a3acda239) &『《PIPD_LS_DOC-00》\~《PIPD_LS_DOC-09》』」以上PIPD_LS工具為目標進行分析，因為「FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_00 \~ 08」就是讓GPT-6使用以上PIPD_LS工具，產出「FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_00 \~ 08」，因為「FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_00 \~ 08」導致的治理過重、鏈路阻斷、不適合高自動化、不適合單人OWNER....等等，造成B1施工問題，所以是否和以上PIPD_LS工具有關?

最後你必須對「[$pipd-ls-sp-public-skills-p4](app://Plugin_0ff92abe45e081918f19a96a3acda239) &『《PIPD_LS_DOC-00》\~《PIPD_LS_DOC-09》』」的種種問題、潛在治理過度風險、不適合高自動化風險、內部矛盾....等等問題，提出完整工程鑑定評估報告。
\
任務要求：\
最後你必須直接以文字提出完整報告。

## Response:
2026/10/27 下午8:37:53 · gpt-6-thinking

本次將把鑑定重心移到 **PIPD-LS-SP Public Skills P4 本身及 PIPD\_LS\_DOC-00～09**，追查它們如何影響 B1 控制包的產生與施工。我會直接核對八項已安裝 Skill 的實際契約、十冊原始規範，以及 B1 r1～r10 的阻斷紀錄；重點區分工具設計缺陷、文件與工具版本不相容、GPT-6 產包時的過度投影，以及 Hermes 執行端問題。

目前直接核對已找到比前輪更具體的工具級問題：P4 的 `assurance-tqaep` 把「建立測試計畫」與「已有獨立執行收據」綁在同一個輸入；`pi-compile` 的 Oracle Locator 固定指向 DOC-03，與 DOC-07 的責任定位不一致；Profile 的九軸契約也不能直接承接 DOC-06 的十二軸風險評分。此外，幾項 JSON Schema 只檢查欄位形狀，尚不能證明來源摘要、Checker 身份或授權真的有效。我會把這類「形式上可通過、語義上未必成立」的問題獨立列為風險，而不一概歸因於治理過重。

> **檢查原始文件標題與內容長度**
>
>
> **檢視規格矛盾**
>
> 我正在核對原始文件中的精確條文，並注意到若干語義漏洞：安全規則主要停留在文字描述，結構驗證未限制聲明順序、重複項目或批准內容，可能讓不完整證明通過。
>
> **檢視規格矛盾**
>
> 
>
> **核查DOC07追蹤與插件語義驗證**
>
>
> **檢查文件架構並核對PIPD與DOC07規範**
>
> 
>
> **核查測試夾具**
>
> 我發現多個正例與契約不一致：配置等級、輸入目標、雜湊、主體識別、收據、邊集合及套件內容彼此對不上。這些矛盾可能導致模型產生錯誤夾具，並在缺乏跨物件驗證時錯誤通過。
>
> **核查測試夾具**
>
> 
>
> **檢查 PIPD 文件與打包輸出問題**
>
>
> **整理報告範圍**
>
> 我會把已確認的夾具矛盾，與尚未執行驗證的推測分開呈現；特別標明哪些是直接欄位不一致，哪些只是契約可能未涵蓋的風險，避免把測試預期誤當成實際通過結果。
>
> **整理報告範圍**
>
> 
>
> **計算 PIPD 全案風險與矛盾**
>
>
> **辨識核心缺口**
>
> 我確認最嚴重的問題是，配置等級與輸出深度彼此矛盾；此外，輸入缺少風險與權限語義，卻仍可能產生高保證結果。這會讓高風險情境被錯誤降級，並造成驗證鏈失真。
>
> **辨識核心缺口**
>
> 
>
> **深化風險識別與一致性報告**
>
>
> **擷取 DOC05 權限表內容**
>
>
> **整合報告架構**
>
> 我會以證據強度、實際影響與修復優先級整理完整報告，區分規格矛盾、驗證缺口、工具能力不足，以及目前仍需執行才能確認的事項，避免過度推論。
>
> **整合報告架構完成**
>
> 
>
> **檢查 PIPD 文件、映射、權限與整體風險一致性**
>
> 
>
> 處理時間為 12m 23s

# PIPD-LS-SP Public Skills P4 與 PIPD\_LS\_DOC-00～09 全面工程鑑定報告

**專題：PIPD 工具設計缺陷、內部契約矛盾、治理過度、高自動化適配性、單一 OWNER 相容性，以及 FHS-MSC B1 Bootstrap Repair 施工阻斷因果重建**

鑑定日期：2026 年 10 月 27 日｜對象：PIPD-LS-SP Public Skills P4、PIPD-LIFECYCLE-SPEC\@1.1.0、B1 r3 控制包及 r1～r10 施工紀錄

## 一、最終核心裁決

**結論：PIPD-LS-SP P4 與 PIPD\_LS\_DOC-00～09，確實是 FHS-MSC B1 治理膨脹、契約不相容及部分施工阻斷的重要上游促成來源。更重要的是，這次直接檢查 P4 的 Schema、Skill Contract 和測試案例，發現了前輪報告尚未充分揭露的工具級缺陷。**

但必須把三種不同的責任分開：

1. **PIPD 工具自身的問題：** 部分原生接口不足以完整表達上位規範，部分測試案例與自身契約不一致，部分生命週期操作存在先後依賴錯置，以及 JSON Schema 與真正語義保證存在落差。
2. **GPT-6 產生 B1 控制包時的問題：** 將 PIPD 的施工前契約、正式效果治理、產品全量覆蓋和最終驗收要求，高密度整合到同一套約 2.18 萬行的設計控制包中，但沒有同步建立足夠精簡、可機械執行的 Runtime 投影。
3. **後續施工鏈的問題：** Codex／Hermes 將部分候選設計或正式驗收前置條件，擴大解釋為一般工程的阻斷條件；Hermes 本身又沒有證明具備完整持久自治續航和防提前結案機制。

三者構成**上游契約缺陷 → 中游產包放大 → 下游執行阻斷**的複合失效。

### 1.1 本次專項鑑定結果

| 鑑定面向 | 裁決 | 重要性 |
|--------|--------|--------|
| P4 與 DOC-00～09 的相容性 | 存在可定位的不一致 | 高 |
| P4 測試案例完整性 | **發現多項直接可核對的矛盾** | 極高 |
| P4 真正語義驗證能力 | Schema 不能單獨證明其聲稱的全部不變量 | 極高 |
| PIPD 治理負擔 | 正式效果治理合理，但缺少充分的階段化執行接口 | 高 |
| 高自動化適用性 | 適合作為前置契約層；尚不足以單獨成為完整自治施工控制器 | 極高 |
| 單一人類 OWNER 相容性 | 原則上相容，但缺明確機器 Principal 與無人值守驗收配置 | 高 |
| B1 產包適用性 | 設計候選具參考價值；直接當作 Runtime 控制包不合適 | 極高 |
| Hermes 反覆停工 | PIPD 為促成因素，持久執行與停止控制缺陷仍是直接機制 | 極高 |

### 1.2 本次新發現的重大問題

除了前輪已指出的 Oracle、Profile 與 TQAEP 問題，本次還直接核對出：

- P4 `pipd-pi-compile` 的正向測試案例，Requirement Atom 本身的 `content_hash` 與 TraceLink 的 `to_hash` 不一致。
- P4 `pipd-execution-contract` 的部分正向案例，輸入 PD 身份與輸出 ConstructionContract 的 PD Subject 不一致。
- P4 `pipd-assurance-tqaep` 的正向案例，Checker Execution Receipt 輸入與輸出不一致。
- P4 `pipd-package-project` 的正向邊界案例，輸入 `trace_edges=0`，輸出卻宣稱 `edges=2` 且 `verdict=PASS`。
- P4 若干編譯接口只接受上游工件的 ID／Hash，卻要求產生需要完整語義內容的下游結果；沒有明確宣告具版本與 Hash 驗證的工件解析接口。
- P4 Profile 接口沒有 DOC-06 所規定的十二軸風險分數及多項強制升級事實，單靠九軸數量無法保證風險不降級。

這些問題比「治理文件太長」更具體。

**它們說明：目前不能僅因 P4 測試案例標記 `expect: ACCEPT`，或某份工件符合 JSON Schema，就認定其跨工件身份、因果鏈與驗收語義已正確閉合。**

這是工具契約及測試基準的已確認缺陷；是否已被實際的 P4 Runtime Validator 另外攔截，仍須執行原生測試才能裁決。

---

## 二、鑑定證據與有效範圍

### 2.1 直接檢查的資料

本次直接讀取安裝於 ChatGPT 的八項 P4 Skill 定義、各項 `references/contract.md`、`schemas/input.schema.json`、`schemas/output.schema.json`，以及 `tests/cases.yaml` 的相關測試。

| 文件／系統 | 規模或範圍 | 檢查重點 |
|--------|--------|--------|
| P4 八項 Skills | 8 Skills、16 個 Input/Output Schema | Typed IO、依賴、權責、首個失敗條件 |
| P4 Skill Contracts | 8 項契約 | 與 Schema 和實際案例是否一致 |
| P4 測試案例 | POS／NEG／EDGE／SEC | 是否存在身份、Hash、Receipt、Profile 矛盾 |
| PIPD\_LS\_DOC-00～09 | 10 冊、54,863 行、4,037,233 bytes | Canonical 法位、權責、治理及適用性 |
| B1 DOC-00～08 | 9 冊、21,784 行、1,501,001 bytes | P4 映射、擴張規則與正式 Gate |
| B1 四份核心紀錄 | 指揮、Prompt、鑑定、Handoff | r1～r10 的實際阻斷、修復與未執行工作 |

本次主要是**工具契約審查、原始文件比對及靜態一致性鑑定**，並未把八項 Skill 全部交由現役 PIPD 編譯器重新執行，也沒有直接登入 Windows Host 測量施工效能。

還有一項關鍵證據限制：B1 文件明確引用了 P4 技能與 Schema，但現有資料沒有完整保留當初 GPT-6 產包的每一次工具呼叫、輸入輸出與版本釘選。因此可以鑑定「PIPD 契約如何影響 B1」，但不能逐段確定是哪一次 Skill 調用直接生成了哪一段有缺陷的文字。

### 2.2 特別重要的工具身份差異

必須區分：

**P4 Skill 文件**、**JSON Schema**、**測試 Fixture**、**確定性 Compiler**、**Host 執行器**、**Native Checker**。

它們不是同一個實體。

本次檢查的 P4 主要是 Skills 契約及其附屬檔案。Skill 的文字指令本身不能證明某個真正的 Deterministic Compiler 已完成執行，也不能自行產生 HGK Native Permit 或 Windows 權限。

B1 DOC-00 亦明確限定：P4 八項 Skills 是編譯技能契約，不是 Host 可變更權限。fileciteturn0file27L15-L28

因此後續所有判定都必須保持：

`Schema Valid ≠ Semantic Valid ≠ Native Compiled ≠ Execution Admitted ≠ World Effect Verified`

---

## 三、P4 八項 Skills 的逐工具鑑定

### 3.1 技能責任、實際風險與裁決

| Skill | 正式職責 | 本次發現 | 工程裁決 |
|--------|--------|--------|--------|
| `pipd-route-intake` | Goal／Source Locator → IntentCard／REQ Atoms | 原子抽取規則較抽象；須另外確保實際來源與決定性 | 保留，強化抽取與身份重播驗證 |
| `pipd-authority-source` | Source Families → SourceFreezeManifest／AuthorityBinding | 輸入缺完整衝突／批准資訊；需依賴外部驗證 | 保留，強化真來源及權威解析 |
| `pipd-profile-tailor` | Profile／Axes → ProfileBinding／Safety Veto | 與 DOC-06 十二軸風險模型無法直接等價 | **P0 相容性修補** |
| `pipd-pi-compile` | Intent／Profile／Atoms → PI-PKG／TraceLinks | Oracle Locator、Profile Binding、跨工件 Hash 不一致 | **P0 介面與 Fixture 修補** |
| `pipd-pd-bind` | PI／真 RepoContext → PD-PKG | 以 Repository 為中心，不適用全部 Host Effect；需確保 Freshness | 保留，明確界定 Repo-only |
| `pipd-execution-contract` | PD／PI → ConstructionContract／ECP | 輸入資訊不足、輸出範例身份不符、Effect Class 過度固定 | **P0/P1 修補** |
| `pipd-assurance-tqaep` | PI／ECP／Checker → TQAEP | 計畫與真驗收時間混用、收據相容性及身份驗證不足 | **P0 生命週期修補** |
| `pipd-package-project` | Bundle → ClaimCeiling／TraceClosure | 跨工件圖譜輸入不足、正向案例不一致、容易被當作任務終止 | **P0/P1 修補** |

這八項 Skill 不宜全部刪除。其生命週期劃分具有合理性，但目前的接口仍需要區分**正式編譯契約完整性**和**真正具備執行及驗證能力**。

### 3.2 `pipd-route-intake`：需求壓縮與語義保留風險

P4 將需求整理成五類原生 Requirement ID：

`REQ-INTENT`、`REQ-KNOWLEDGE`、`REQ-VERIFY`、`REQ-DELIVER`、`REQ-GOVERN`。

這適合作為通用需求分類，但 B1 實際包含 27 個獨立工程 Atoms。

B1 DOC-01 已設計 Sidecar，將 27 個專案 Atom 對應到五類 P4 Requirement。這個做法有其必要性。fileciteturn0file28L41-L68

**問題是五類原生 Requirement 並不足以直接代表 27 項 B1 工程不變量。**

例如：HGK Issuer、Hermes CAS Lease、Fabric Loaded、Model Served 可能同屬 `REQ-GOVERN` 或 `REQ-VERIFY`，但各自具有不同前置條件、Oracle、失敗碼及世界效果。

若下游只驗證五類 Requirement 是否存在，卻沒有重新連接 27 個原始 Atom 與各自測試，便會發生語義覆蓋縮水。

正式修正應要求 Sidecar 具備：

`Original Atom → Exact Source Clause → Native Requirement → Domain Oracle → Test → Raw → Verdict`

而不是只有原子數量對應或 Category Mapping。

### 3.3 `pipd-authority-source`：權威來源不足時容易放大全域 HOLD

P4 要求來源家族具備 Digest、File Locator、有效 Root 與可解析來源，並拒收未解決衝突。

原則合理，不能允許模型自行猜測 Source SHA 或用虛構來源完成正式編譯。

但它的 Input Schema 主要包含 `families[].name`、`manifest_sha256`、`files[].rel` 和可選 `root`。

它沒有在輸入契約中直接完整表達：

- 衝突的兩個版本及其裁決；
- 實際批准來源與批准範圍；
- Supersession 決策證據；
- 正式 SourceFreeze 與作者端候選 Freeze 的區分。

這些可以由外部權威服務補足，但必須是明確的接口，不能依靠生成模型填寫 `CURRENT`、`NONE` 便宣稱已完成 Ratification。

B1 最初即有來源與 Oracle 衝突，故需要建立候選來源清冊，同時禁止將候選 Freeze 冒充正式 SourceFreeze。

**關鍵修正不是放寬正式 Freeze，而是讓來源未正式批准時，合法唯讀勘查與其他不依賴正式 Freeze 的有界工程工作仍能繼續。**

### 3.4 `pipd-profile-tailor`：最重要的風險模型不相容

這是本次確認的重大問題之一。

PIPD DOC-06 具備十二項可量測風險軸，每軸 0～3，包含：

| DOC-06 風險軸 | 工程意義 |
|--------|--------|
| `authority_complexity` | 權威及批准複雜度 |
| `side_effect_risk` | 實際副作用 |
| `integration_count` | 整合數量與不穩定性 |
| `irreversibility_risk` | 不可逆或補償風險 |
| `assurance_requirement` | 所需驗證強度 |
| `permission_scope` | 權限廣度 |
| `data_sensitivity` | 敏感資料程度 |
| `financial_or_physical_effect` | 金融／物理效果 |
| `blast_radius` | 故障波及範圍 |
| `operational_consequence` | 營運後果 |
| `brownfield_complexity` | 既有系統與遷移複雜度 |
| `runtime_autonomy` | 自治程度 |

DOC-06 不是單看軸數，而是有風險分數、強制 ASSURED Veto 與未知風險的保守處置。fileciteturn0file31L34-L49

P4 `profile-tailor` 的九個軸則是：

`intent / knowledge / verification / release / trust_boundary / preexisting_repo / profile / tech_candidates / host_surface`

其主要升級條件依軸數及 `provider_off_required` 決定。

**兩者不是等價的九軸與十二軸模型，也不能只用欄位重新命名解決。**

例如：

`{profile:LITE, axes:["trust_boundary"], provider_off_required:false}`

在 P4 的軸數邏輯中，不會因單一軸而必然升到 ASSURED。

但如果真實工作是持有高權限憑證的自治代理，DOC-06 的 `permission_scope`、`runtime_autonomy` 與安全 Veto 可能要求 ASSURED。

P4 的九軸輸入沒有攜帶這些風險分數。除非有明確的外部風險解析器，否則無法依該接口本身證明風險升級完整。

**工程裁決：不允許以九軸的數量結果覆寫 DOC-06 十二軸風險裁決。**

適當的相容方式是保留原十二軸風險評估，將有效 Profile 作為已裁決結果提供給 P4；當 P4 自行計算的要求較低時，不准降級；若需要更嚴格的 Profile，則依正式契約升級。無法證明映射不損失風險語義時，維持 HOLD。

### 3.5 `pipd-pi-compile`：Oracle 權威與 Profile Provenance

P4 輸出 Schema 強制：

`acceptance.oracle_source = "DOC-03 DOMAIN_ORACLES"`

但 PIPD DOC-07 的正式責任包括 TEST／ORACLE／FIXTURE 的 Canonical Writer，DOC-03 則主要負責 Pre-Dev Binding 和相關測試準備。

因此這裡至少存在**Locator、Authoring Ownership 及 Runtime Consumer 之間未正式證實相容**的問題。

它不必然表示 DOC-03 不得持有 Domain Oracle 的引用或投影；合理架構可以由 DOC-07 擁有原始 Oracle，DOC-03 消費經版本釘選的引用。

但 P4 目前的固定字串不能充分證明這種委派已經成立。

另一項更深的問題：P4 PI 輸入只攜帶有效 Profile 字串，沒有完整的 ProfileBinding 身份與 Hash；其輸出卻包含 `profile_binding.axes`、`vetoes`、`artifact_depth` 和 `assurance`。

若編譯器有獨立的 Canonical Object Registry，可以合法依內容 Hash 取回，但目前該解析器沒有在此 Skill 的 Typed Input 契約中被完整明示。

因此應要求正式、可重播的 ProfileBinding Resolver，防止模型從示例或歷史上下文補出缺失欄位。

### 3.6 `pipd-pd-bind`：Repository 與 Host Native Effects 必須分離

P4 `pd-bind` 需要真實 RepoContext、HEAD、Tracked Files、Currentness 及 Writable Scope。

這適用 Repository Mutation，卻不能直接套用 Fabric 政策載入、HGK Issuer、Hermes Queue 或 SBL User Data。

B1 r3 已經在 DOC-00／DOC-02 明確區分：

- `READ_ONLY_PROBE` 不建立假 PD；
- `REPOSITORY_WRITE` 才走真 RepoContext；
- Host／User Effects 需要其各自的正式 Owner Adapter。

這項分離是 B1 正確的設計，應保留。

問題在於執行指揮若仍把「沒有 P4 Repo-bound PD」判成所有 Host 工作及唯讀探測均不能開始，就把工具的適用域錯誤擴大了。fileciteturn0file25L15-L41

### 3.7 `pipd-execution-contract`：ECP 邏輯過於 Repository-centric

P4 的 ECP 有以下固定要求：

| 欄位 | P4 預設 |
|--------|--------|
| `permission.token_required` | `true` |
| `idempotency.guarantee` | `at_most_once` |
| `retries.max` | 0～1 |
| `retries.backoff` | `none` |
| `readback.kind` | `residue_scan` |
| `rollback.required` | `true` |

這些對有界 Repository 寫入具有合理性，但不適合無差別套用到所有效果。

例如，純唯讀 Observation 不應要求 Mutation Token；Fabric Promotion 需要的是 Active／Loaded／Consumer 狀態讀回，而不僅是 `residue_scan`；某些不可逆效果只能制定補償與停損，不存在真正的原樣 Rollback。

**裁決：保留 Repo ECP 的安全預設，另由各 Native Domain Owner 提供符合其效果類型的正式 ECP Adapter。**

此外，P4 ECP 的輸入 Schema 只攜帶 PD/PI ID 與 Hash，輸出卻要求 `expected_changes`、`tests`、`rollback`、`effect_intent` 等具體資訊。

這要求編譯器擁有可信的 PD/PI 內容解析能力。未有明確 Resolver 的情況下，僅靠兩組 ID/Hash 無法決定這些內容。

需要補足具有 Currentness 驗證、Subject Join、禁止越權補值的 Typed Artifact Resolver。

### 3.8 `pipd-assurance-tqaep`：設計階段與完成驗收階段混合

這是最明確的生命週期問題。

P4 的 TQAEP 輸入強制要求 `checker_execution_receipt`，輸出卻直接使用：

`INDEPENDENT_CASE_PASS`

然而 PIPD DOC-03 明確規定：

`TQAEP_COMPLETE != TEST_EXECUTED != VERIFIED != QUALIFIED != PASS`

亦即 TQAEP 計畫完整，不等於測試已經執行。fileciteturn0file38L48-L56

如果在制定計畫時就要求獨立 Checker 已經執行，便有先後依賴問題。

正確應分成：

| 階段 | 應產出 | 不可宣稱 |
|--------|--------|--------|
| TQAEP Design | Test Plan、Oracle、POS/NEG、Evidence Expectation | `INDEPENDENT_CASE_PASS` |
| TQAEP Execution | 真 Raw、Execution Identity、Observed Result | 已通過獨立驗收 |
| TQAEP Independent Acceptance | 不同有效 Principal 的 Checker Verdict | 超出該次受影測試的全域 PASS |

P4 可以保留原有的正式 Live Acceptance 契約，但應增設具版本的 Design／Planned 入口，而不是取消獨立驗收。

另外，其 Input Schema 對 Checker Receipt 主要是非空字串和禁止特定 `SELF_ATTESTED` 字面值，無法僅憑 Schema 證明憑證已被真 Checker 簽發。

**在單一人類 OWNER 環境中，真正需要的是獨立機器驗證 Principal，而不是必然增加第二個人類 OWNER。**

### 3.9 `pipd-package-project`：工件封裝不能控制 Hermes 任務結束

P4 `package-project` 負責 ClaimCeiling、EvidenceExpectation 和 TraceClosure。

這是工件治理，不是 Scheduler。

它的輸入只包含工件身份與 `trace_edges` 數量等概要資料，輸出卻要求判斷 `orphans`、`bad_hashes` 和 Graph Closure。

若沒有可信的工件圖譜 Resolver，單憑邊數不能確定 Trace Closure 真的成立。

另外，P4 的八階 Claim Ladder 與 DOC-01 的正式 Lifecycle State 不應混用；前者控制允許的宣稱，後者表示受治理主體的生命週期。兩種狀態也都不等於 Hermes 的 READY／RUNNING／PARKED。

這正是 r10 提前封存後停止施工的重要架構背景：**工件可以完成某次有界封裝，但未完成的 Runtime WorkOrders 不應因此消失。**

---

## 四、P4 測試案例的直接一致性缺陷

這是本次專項鑑定中，比前輪更需要優先處理的發現。

### 4.1 已確認的具體 Fixture 矛盾

下列證據直接來自各 Skill 的 `tests/cases.yaml`，不是推測。

| 編號 | P4 測試 | 實際矛盾 | 工程風險 |
|--------|--------|--------|--------|
| F01 | `pipd-pi-compile / POS-001` | Requirement Atom 的 `content_hash` 與指向同一 Atom 的 TraceLink `to_hash` 不相同 | Trace Identity 不能閉合 |
| F02 | `pipd-execution-contract / POS-002` | 輸入 PD 為 `PD-b5b4998cd496ca1a`，輸出 ConstructionContract 的 Subject 卻是 `PD-4bfd476b5670ff7e` | 跨 Subject 契約借用 |
| F03 | `pipd-execution-contract / EDGE-001` | 輸入 `PD-27534e1a688d3975`，輸出又指向 `PD-4bfd476b5670ff7e` | 邊界案例身份污染 |
| F04 | `pipd-assurance-tqaep / POS-002` | 輸入 Checker Receipt 結尾為 `b2c1`，輸出 Acceptance Receipt 結尾卻為 `a17f` | 驗收證據跨操作借用 |
| F05 | `pipd-package-project / EDGE-001` | 輸入 `trace_edges: 0`；輸出 `edges: 2`、`verdict: PASS`，沒有提供對應的圖譜重算證據 | Trace Closure 來源不可驗 |
| F06 | `pipd-pi-compile / POS-002` | 輸入只有 `profile: STANDARD`，輸出卻直接物化 ProfileBinding 詳細欄位，包含 `artifact_depth: L1_SCHEMA_CONTRACT` | ProfileBinding 未證明同源，可能降級 |

F01 的原始內容尤其明確。

`ATOM-2a23035a7108408f` 的本體 `content_hash` 是：

`03f1797799550383202fcd81c975179e64dc613996931bf9c748af30097ada32`

但指向同一 Atom 的 `trace.to_hash` 卻是：

`747c3cc4a58c095462bf211bafbb36ff88a546a70325f8de9042edada67fc3dc`

如果兩者依契約都是同一個 Canonical Requirement Atom 的內容摘要，則不可能同時滿足 Same-object Hash Equality。

F05 需要較精確地判斷：如果 `trace_edges` 只是提示數值，而編譯器確實從獨立工件圖譜重新計算出兩條邊，輸出未必錯誤；但這份正向案例沒有提供解析位置、重算依據及輸入與輸出差異的合法解釋。

因此至少構成**Positive Fixture 可重播性與證據完整性的缺陷**。

F06 也需要由正式 Profile Resolver 驗證，才能確定是否存在不合法降級，而不能單憑欄位形狀判 PASS。

### 4.2 為什麼這些問題嚴重？

PIPD 原本就是為了解決：

`False PASS / Wrong Subject / Stale Hash / Unauthorized Promotion / Semantic Loss`

但當 P4 自己的正向測試案例出現這類身份與參照不一致，便代表用來教導、測試或示範工具行為的資料，尚未完整實現自身的安全不變量。

這不等於已證明現役 PIPD Compiler 一定會錯誤放行。

可能的情形有三種：

| 情形 | 實際意義 |
|--------|--------|
| Runtime Validator 拒收這些 POS Fixture | Fixture 與其 `expect: ACCEPT` 錯誤 |
| Runtime Validator 接受而未檢查跨工件身份 | 真正存在 Semantic Validator 缺陷 |
| Runtime 有合法外部 Resolver 可解釋某些差異 | Tool Contract 未完整描述解析依據，需補證據與重播 |

**三種情形都需要處理，不能直接把目前的測試清單視為完整可信的驗收基準。**

### 4.3 JSON Schema 與語義驗證的缺口

P4 多數 Schema 的 `additionalProperties:false`、`required`、`enum`、`const` 等規則，能有效防止部分格式污染。

但無法單獨證明以下不變量：

| 宣稱的保證 | Schema 能否單獨證明？ | 還需要什麼 |
|--------|--------|--------|
| Source Digest 對應真檔案 | 不能 | 實際讀檔與 Digest 重算 |
| Root 沒有符號連結逃逸 | 不能 | Realpath／Handle／ACL 實測 |
| PI Atom Hash 與 Trace Hash 相同 | 目前未由 Schema 強制 | Cross-object Join Validator |
| PD Subject 與 ConstructionContract Subject 相同 | 目前未由 Schema 強制 | Subject Identity Validator |
| Checker 身份真正獨立 | 不能 | Principal／Credential／權限驗證 |
| Checker Receipt 真實有效 | 不能 | 簽章、Issuer、Nonce、Subject、Epoch 驗證 |
| ECP 作用域未超出 PD | 不能僅靠字串 | Scope Intersection／Resolved Paths |
| Claim Ladder 合法晉級 | Schema 不足以完整證明 | Claim Transition Validator |
| Trace Graph 無孤兒／錯 Hash | 不能僅靠 Edge Count | 真實圖譜重算 |
| Effect At-most-once | 不能 | Durable Journal／CAS／World Reconciliation |

這些是形式 Schema 的自然能力邊界。缺陷不在使用 JSON Schema，而在**若工具系統把 Schema-valid 等同於 Semantic-valid，便會造成錯誤放行**。

PIPD DOC-07 原本也明確反對只以 Schema、CI 或 Provider Response 判定成功。fileciteturn0file32L103-L111

### 4.4 正式工程裁決

**P4 應立即增加獨立的 Cross-artifact Semantic Conformance Gate，並修正所有受影 Positive Fixtures。**

其最小要求是：

`Schema → Resolver → Source Identity → Cross-object Identity → Lifecycle Semantics → Permission Semantics → Oracle → Acceptance`

其中任何項目缺少真實資料，只能產生有型別的 HOLD／FAIL，不能產生假 PASS。

---

## 五、PIPD 工具尚未充分解決的其他工程風險

除了上述六項可直接定位的 Fixture 問題，本次還識別出八項值得修正的結構性風險。

| 風險 ID | 問題 | 可能造成的後果 | 建議等級 |
|--------|--------|--------|--------|
| P4-R01 | Skill 契約存在，但未證明已由真正 Compiler 實作 | GPT-6 產生符合文件形狀的候選，而非 Native Compiler 工件 | P0 |
| P4-R02 | 缺統一、機器可解析的拒收結果契約 | Hermes 無法可靠區分 HOLD、可修復失敗和永久 NOFIT | P0 |
| P4-R03 | 跨工件 Resolver、Currentness、Hash Join 未充分明示 | 工件以過時或錯誤身份互相引用 | P0 |
| P4-R04 | Profile 風險事實不足 | 可能錯誤維持較低保證等級 | P0 |
| P4-R05 | Source Authority Rank 主要依固定 Family Code 分類 | 若沒有外部權威驗證，Family 名稱可能被錯用 | P1 |
| P4-R06 | 部分輸入沒有完整攜帶下游輸出所需資訊 | 依賴模型推測或未宣告的隱藏狀態 | P0 |
| P4-R07 | Claim Ladder 沒有完整以 Schema 表達合法轉移 | Schema-valid 但非法晉級的工件可能出現 | P1 |
| P4-R08 | Plugin 封裝層的效益尚缺完整 A/B 實測證據 | 增加維運與 Context 負擔，未必提升施工效率 | P2 |

### 5.1 缺少統一的 Fail／Hold／Resume 接口

八項 P4 Skill 均有明確 Failure／Degrade 規則，例如：

`AUTHORITY_UNKNOWN`、`PROFILE_VETO`、`PI_SEMANTIC`、`REPO_CONTEXT_MISSING`、`EFFECT_UNKNOWN`、`TQ_SOD`、`EVIDENCE_GAP`。

但檢查各項 Output Schema 後，可以確認它們主要定義成功工件形狀，沒有共同完整的失敗結果 Envelope。

這會增加高自動化執行系統的整合成本。

Hermes 不能只知道 `PI_SEMANTIC`，還必須知道：

| 必備資訊 | 作用 |
|--------|--------|
| `first_fail_code` | 第一個具體拒收原因 |
| `affected_subject` | 哪個工件或工作卡受影 |
| `blocking_dependency` | 真正缺失的依賴 |
| `recoverability` | 可自動修復、需外部批准或永久不適用 |
| `allowed_next_action` | 下一個合法動作 |
| `resume_predicate` | 哪些條件成立才重新排入 READY |
| `evidence_required` | 如何證明阻斷已解除 |
| `claim_ceiling` | 阻斷期間允許宣稱的最高結果 |

否則，即使工具本身正確拒收，執行器仍可能將一項局部 HOLD 解釋成整個 Mission 不能繼續。

**建議建立一份跨 Skill 的正式 `PIPD.ErrorEnvelope@1`，並以現有拒收碼為基礎，增補受影範圍與恢復資訊。**

這是對 P4 契約的重要擴充，不是新增第二套 PIPD 權威。

### 5.2 Source Authority 的名稱不能代替真正來源權限

`pipd-authority-source` 依 F1／F2／F3／F5／F6 等 Family Code 決定 R1 Authority Rank。

作為已驗證來源登錄後的固定規則可以成立。

但如果上游允許任意提供 `F1_*` 名稱，而沒有真實 Source Registry、Issuer／Owner 簽核及 Source Digest 驗證，便可能讓名稱分類取代真正權威判定。

目前只能確認 Schema 不足以單獨提供完整保證，尚不能斷言現役 Runtime 存在可利用的權威提升漏洞。

修正應讓 Family Code 必須綁定已核准 Source Authority Registry，不能只靠字串符合 Pattern。

### 5.3 Provider-off 與 Profile 的適用條件未完全強制

P4 Profile Input Schema 對 `provider_off_required` 沒有設定為必填。

這表示沒有提供該欄位的輸入，在基本 Schema 檢查下仍可能合法。

如果 Provider-off Parity 對實際工作具有強制性，該事實應由更上游的政策／RiskBinding 決定，不能因輸入省略而視為不需要。

同時，九軸模型中 ASSURED 的「10 軸上限」實際無法由九項互異 Canonical Axes 達到，這是較小但明確的規格可維護性問題。

### 5.4 P4 對獨立 Checker 的驗證不足

P4 可以拒絕兩個文字相同的 Maker／Checker 身份，也能拒絕部分自我聲明的 Receipt。

但模型名稱不同不等於真正獨立 Principal。

例如：

`execute/deepseek-v4.1-flash`

與：

`verify/glm-5.3-flash`

是兩個模型角色名稱，不能只因字串不同，就證明擁有獨立 OS Principal、隔離的 Credential、不可由 Maker 修改的 Checker Policy。

這不是要求必須由第二個人類來驗證，而是要求 Host Adapter 提供可證明的技術隔離。

### 5.5 PIPD 原始 DOC-08 與實際 P4 使用方式存在張力

PIPD DOC-08 明確主張 Progressive Disclosure：

`Router → Constitution → Package Index → Applicable Package → Exact Schema/Test/Evidence`

並指出不應每次都將所有 Canonical Truth、全部 PI／PD 和所有證據塞進模型 Context。fileciteturn0file33L485-L545

但 B1 的產包與施工實際承接了約 21,784 行設計正文，以及更大範圍的 PIPD、SBL 與相關工程資料。

這不是 DOC-08 要求的最佳消費方式。

另外，DOC-08 主張以實際 A/B Evaluation 證明 Thin Skill 或 Full Plugin 的必要性。現有 Skill Fixture 可以支持局部合約測試，但不能單獨證明 Plugin 化已經降低真實高自動化施工的 Context、延遲與失敗率。

因此，P4 是否有足夠的產品成熟度證據，仍應以實際 A/B 指標驗證。

---

## 六、PIPD DOC-00～09：內部一致性與治理適用性總鑑定

### 6.1 十冊責任分工本身大致合理

| 文件 | Canonical 職責 | 鑑定 |
|--------|--------|--------|
| DOC-00 | Navigation／Operator Entry | 正確提供入口與適用性判斷 |
| DOC-01 | Constitution／State／Authority | 必要，但不能成為 Runtime Scheduler |
| DOC-02 | PI Contract／TechnologyAdmission | 必要，但需防止通用原子過度壓縮專案語義 |
| DOC-03 | Repo Binding／Pre-Dev／Handoff | 合理；必須與 Host Native 效果分開 |
| DOC-04 | Traceability／Evidence Contract | 必要；跨工件 Hash 驗證需真正實作 |
| DOC-05 | Receiver／Permission／ExecutionAdmission | 必要；Bootstrap 應有明確合法准入方案 |
| DOC-06 | Profile／Applicability／Complexity | 有良好的風險分級原意，但 P4 未完整承接 |
| DOC-07 | Oracle／Fixture／Conformance | 重要的防假成功機制，需修 P4 Oracle 相容 |
| DOC-08 | AI Consumption／Adapter Maturity | 與高自動化相容，尤其應落實 Progressive Disclosure |
| DOC-09 | CI／Release／Supply Chain | 必要；不可替代真實效果或決定 Hermes 停工 |

DOC-01 明確不是 Runtime Orchestrator；DOC-00 允許具有有效准入契約的受影工作獨立進行，也反對全域瀑布式鎖定。

DOC-05 的 Permission Model 也區分 READ\_ONLY、可逆 Repository Write、外部效果、Privileged 與不可逆高風險效果，而非所有工作一律要求最高權限。fileciteturn0file30L36-L43

所以，**PIPD DOC-00～09 並沒有在設計原意上要求 Hermes 每次修補都從零重跑完整生命週期。**

### 6.2 已識別的跨冊矛盾與張力

| 衝突 | 問題本質 | 裁決 |
|--------|--------|--------|
| DOC-07 Oracle Ownership vs P4 DOC-03 Locator | Canonical Writer／消費位置不清 | 正式版本化引用與相容 Adapter |
| DOC-06 十二軸 vs P4 九軸 | 風險評估與工件深度模型不等價 | 保留十二軸權威裁決 |
| DOC-03 TQAEP Plan vs P4 Receipt-required | 計畫與已執行驗收混合 | 分開 Design／Live |
| DOC-05 Effect Classification vs P4 Repo ECP | 泛用 Repo ECP 不適用各類 Host 效果 | Domain-specific ECP |
| DOC-01 Lifecycle vs P4 Claim Ladder | 不同狀態語義容易誤混 | 建立明確轉譯，不共用欄位 |
| DOC-04 Trace Closure vs P4 Fixture | 跨工件 Hash 身份不一致 | 修正 Fixture 和驗證器 |
| DOC-08 Progressive Disclosure vs 大型 B1 入口 | 原本反對的 Context 重複實際發生 | 按需載入與薄型執行契約 |
| DOC-09 Release Evidence vs Hermes Mission Stop | 正式 Release 與長任務終止權責不同 | Runtime Controller 獨立計算 |

其中前四項屬工具與規範間的重要相容性問題；第五至第八項主要是使用及執行轉譯問題。

### 6.3 PIPD 的真正治理過重程度

PIPD 的正式效果治理並非全部過重。

對未知 Repository、未知 Subject、外部系統寫入及高風險效果，嚴格授權是必要的。

但若以實務施工的最小必要條件評估，目前有三個明顯的效率問題。

**第一，風險分級機制和 P4 自動化接口沒有完整閉合。**

雖然 DOC-06 設有 LITE／STANDARD／ASSURED，但 P4 無法僅依現有九軸輸入準確重建 DOC-06 的十二軸風險判準，容易迫使專案在正式安全要求與 P4 兼容性之間反覆補文件。

**第二，部分正式驗收前置條件被提早套用。**

TQAEP 設計不應要求已經完成 Checker Execution。Host Native Admission 不應無條件作為所有 READ\_ONLY 工作的前置。

**第三，工具缺少完整的復原及局部失敗輸出。**

Fail-closed 正確，但對高自動化來說，還必須回答「下一張可以合法執行的是什麼」。

否則治理系統只能提供拒收，不能提供可持續施工的恢復路由。

---

## 七、PIPD → GPT-6 產包 → B1 施工的工程因果關係

### 7.1 主要因果路徑

**上游：PIPD DOC-00～09／P4 Skills**

嚴格 Source／Profile／PI／PD／ECP／TQAEP／Claim，並存在部分 ABI、Fixture、階段契約缺陷

**中游：GPT-6 產生 B1 DOC-00～08**

保留完整身份分母及正式 Gate，但尚未充分區分 Source Design、Bootstrap Engineering、Native Runtime Acceptance

**執行投影：Codex／Hermes r1～r10**

將部分 HOLD 擴大，工作依賴和持久 READY 狀態未完全機械化

**觀察結果：B1 高自動化未完成**

局部 Patch／Tests／CI 成功，但 T2／G-A／三 GWO／G-B 等正式 Native Gate 尚未閉合

這條鏈路有文件及執行紀錄支持，但不能據此量化每一環的因果貢獻比例。

### 7.2 r1～r10 阻斷事件的責任歸屬

| 施工時點 | 主要問題 | PIPD 直接關係 | 其他重要因素 |
|--------|--------|--------|--------|
| Codex r1～r2 | 大型工作及正式 Gate 依賴 | 中 | 產包規模、指揮設計 |
| Codex r3～r4 | SourceFreeze／TaskKind／Oracle 拒收 | **高** | HGK Native Authority 尚未成立 |
| Codex r5 | Admin-only Trust 及正式 Issuer | 低 | HGK 特定金鑰架構 |
| Codex r6 | Native Acceptance 未成立 | 中 | Receiver、Host、Checker 尚未有真實收據 |
| Hermes r7 | Overlay 測試與原生效果有落差 | 中 | HGK Runtime／Model Routes |
| Hermes r8 | SharedSpine 與封存一致性 | 低 | Durable Scheduler／Evidence Pipeline |
| Hermes r9 | CI／PR 候選成功，但 Native Loop 未成立 | 中 | Harness、工具接線、PR 未合併 |
| Hermes r10 | R3／R4／Executor 未執行而先封存 | **低（直接原因）** | Hermes Stop Controller／工作續航 |

這個分類並不是「只要 PIPD 關係低，PIPD 就完全沒有責任」。

例如，PIPD 源頭的 Oracle Compatibility 問題，確實會讓正式編譯及 Ratification 延遲；但 r10 未執行 Fabric R3／模型 R4／Hermes Executor 的直接現象，不能僅靠 Oracle 不相容解釋。

### 7.3 B1 控制包為何放大上游問題？

B1 r3 包含：

| 身份分母 | 數量 |
|--------|--------|
| Requirement Atoms | 27 |
| WO／OBS | 31 |
| TQAEP Parent Cases | 120 |
| TQAEP Child Effect Cases | 124 |
| Node Conformance | 38 |
| R15 Product Identities | 949 |
| Product Matrix Cells | 192 |
| Named Assets | 81 |
| Golden WorkOrders | 3 |

這些分母反映完整設計覆蓋要求，不是任務排程清單。

PIPD 原本允許以 Vertical Slice 逐片推進，且 DOC-08 提供了最小充分資訊披露原則。

但 B1 的產包與後續指揮並未始終把：

`Full Obligation Denominator`

和：

`Currently Executable WorkOrder Denominator`

機械分離。

因此，大量尚未正式驗收的身份被登記為阻斷，卻不能直接回答 Hermes 接下來應執行哪個合法修復動作。

這是**上游高保留產包要求，在缺少 Runtime Projection Compiler 的情況下所造成的架構性問題**。

### 7.4 B1 r3 本身也存在部分正確補救

應公平指出，B1 r3 已修正一些源自較早版本的問題。

例如：

- 將 P4 五個原生 Requirement 與 B1 27 個 Atom 分開；
- 將 Read-only、Repo、Host、User Effects 分開；
- TQAEP 無真 Checker Receipt 時只允許 `PLANNED`；
- 不把 P4 Skill 文件視為 Native 執行權限；
- 禁止自製 Oracle、假 RepoContext 或假 Host Loaded；
- 將部分測試定義改為具體 Domain Fixture。

因此不能將所有 B1 r3 問題都解讀為「GPT-6 完全沒有理解 PIPD」。

較準確的評估是：**B1 r3 已修正不少文件語義問題，但尚未把這些設計收斂成可直接驅動 Hermes 的已安裝執行控制與合法工件解析器。**

B1 DOC-05 也明確聲明其 Fixture 是測試定義，若沒有真 Runner／Binding，就不允許冒稱已執行。fileciteturn0file0L15-L43

### 7.5 最關鍵的 Bootstrap 循環依賴

這是一個具體的架構性阻斷：

需要修復 HGK Issuer／Receiver；修復需要合法 Repository Mutation；某些執行流程卻把尚未成立的完整 HGK Native Admission 設為該修復的前置。

若不存在獨立合法的 Bootstrap 修復准入路徑，便會形成循環。

但解法不是取消 PIPD DOC-05 的 Mutation Admission。

正確作法是讓有權 OWNER 及既有有效的 Repository ExecutionAdmission 機制，建立範圍極小的 Bootstrap Repair 路徑；其 Root、WriteSet、期限、Preimage、撤銷、Readback 均須受約束。

在這個路徑尚未合法成立前，仍可進行唯讀診斷與候選修復計畫，但不能假裝已取得 Repo 寫入許可。

---

## 八、單一人類 OWNER 架構的專項鑑定

### 8.1 PIPD 是否不適合單人 OWNER？

**不能直接如此判定。**

PIPD 要求權限分離、獨立 Checker 和有效批准，但不等於必然要求兩個或更多人類 OWNER。

必須區分以下身份：

| 身份 | 是否必須是不同人類 | 真正要求 |
|--------|--------|--------|
| Human OWNER | 否 | 合法的決策及授權權威 |
| Maker／Executor | 否 | 受限制的工作身份與操作權限 |
| HGK Native Issuer | 否 | 真實可信的簽發權限 |
| Independent Checker | 不一定 | 與 Maker 真正隔離的驗證權限及證據 |
| Release Authority | 視政策而定 | 有效批准，不得由 Maker 自行冒稱 |

所以**單一人類 OWNER，加上不同的受控機器 Principal、真正隔離的 Checker、合法 Native Issuer，可以與高自動化相容**。

### 8.2 目前的實際問題

P4 對 Maker／Checker 的驗證主要落在身份字串與 Receipt 欄位。

這無法自動建立真正的 OS、Key、Credential 或服務權限隔離。

若同一個使用者 SID 下的 Maker 能修改 Checker 程式、替換驗證輸入或讀取簽章私鑰，則即使兩個模型名稱不同，也不代表已達高保證 SoD。

同時，PIPD 與 B1 沒有充分提供一套可直接部署的「單一人類 OWNER＋無人值守獨立 Checker」標準執行配置。

這是**缺少具體技術落地方案**，不是單人 OWNER 架構本質上不被允許。

### 8.3 建議的單一 OWNER 運行方案

建議採用：

`ONE_HUMAN_OWNER / BOUNDED_STANDING_AUTHORIZATION / SEPARATE_MACHINE_PRINCIPALS / AUTOMATED_INDEPENDENT_CHECKER`

其中 OWNER 事前批准有界範圍。Hermes 在有效 Scope 內不重複詢問；HGK Issuer 保持唯一權威；Checker 使用獨立可信的執行環境、Credential 與不可由 Maker 改寫的驗證規則。

需要 Administrator／受保護金鑰時，按真正 OS 效果提升，而非所有工作一律要求全機管理員。

如果某些效果依政策仍必須重新取得人類同意，則只暫停該受影工作，不讓整體系統無故停止。

---

## 九、工程修復總方案：PIPD 應修正什麼？

### 9.1 P0：P4 工具自我一致性修復

優先修正直接已證實的 Positive Fixture 問題。

| 修復項 | 施工內容 | 驗收標準 |
|--------|--------|--------|
| Trace Hash | 修正 PI Atom／Trace `to_hash` | 同 ID、同 Hash，錯 Hash 必拒 |
| Subject Join | 修正 PD → ConstructionContract Subject | 跨 Subject 必拒 |
| Checker Receipt | 修正 TQAEP Input／Output Receipt | 不得借用其它收據 |
| Trace Closure | 明確重算圖譜來源 | Orphan／Hash／Edge Count 一致 |
| Profile Provenance | 綁定有效 ProfileBinding | 不得從 Scalar Profile 猜其他欄位 |
| Fixture CI | 所有正例、負例重新執行 | 錯誤 POS Fixture 不得 PASS |

須保留原始測試案例的版本與 SHA，建立勘誤和回歸，不直接無痕覆寫。

### 9.2 P0：補足真正的 Semantic Resolver

P4 需要一個正式、可驗證的 Artifact Resolver 契約，至少能：

- 以 Subject ID／Content Hash／Version 取回 Canonical Artifact；
- 驗證 Currentness、Authority、Source Identity；
- 拒絕同 ID 不同 Hash、不同 Subject 借用；
- 將錯誤的上游工件改成受影 HOLD；
- 保留可重播的 Input／Output／Verification Receipt。

它應是現有 PIPD Canonical Store 的受控 Reader／Resolver，**不能成為第二個 Canonical Writer**。

### 9.3 P0：修正 Profile 安全升級

應將 PIPD DOC-06 的十二軸風險裁決與 P4 ProfileBinding 建立正式版本化相容契約。

完整條件包括：

`Risk Facts → Twelve-axis Assessment → Mandatory Veto → Effective Profile → P4 Binding → Loss Check`

在不能無損映射時，拒絕自動降級，並產生具體 FirstFail。

### 9.4 P0：TQAEP 生命週期分離

保留已具備真 Checker Receipt 的 Live Acceptance 入口。

另外定義只生成測試規格的 Planned 入口。

此入口不能輸出 `INDEPENDENT_CASE_PASS`；必須等真 Runner 及 Checker 完成後，由既有獨立驗收權威進行正式狀態升級。

### 9.5 P1：ECP 效果分類與重試規則

依 EffectClass 使用有版本的原生契約：

| EffectClass | ECP 與 Retry 原則 |
|--------|--------|
| READ\_ONLY | 無 Mutation Permit；允許有界重複觀測 |
| REPOSITORY\_WRITE | 有效 Repo Admission／WriteSet／Preimage |
| HOST\_OPERATIONS | Native Issuer／Effect-specific Readback |
| USER\_DATA\_EFFECT | 真 User Consent／受限資料路徑／獨立使用者效果 |
| IRREVERSIBLE／HIGH\_IMPACT | 更高保證授權、補償與明確停損 |

將 Diagnostic Retry、Repair Iteration、Native Effect Attempt 分別管理。

不得因 ECP `max=1` 就禁止修補者反覆做唯讀診斷和新的受控工程迭代，也不得因允許工程迭代而對未知世界效果盲目重播。

### 9.6 P1：統一 Typed Failure 與 Resume Contract

應讓 P4 將拒收轉化為 Hermes 可以消費的有型別狀態，但不能讓 PIPD 自行取得 Hermes Queue 的控制權。

例如：

`PIPD Result → Affected Dependency → WorkOrder PARK／READY Recommendation → Hermes Durable Controller`

真正的 WorkOrder 狀態轉移仍由合法 HGK／Hermes 控制系統處理。

### 9.7 P1：修正 Native Toolchain 交接

B1 DOC-07 曾明確說明：當時已讀到真 CLI Parser 與 P4 Schema，但該環境尚未具有可執行的本機 PIPD CLI Binary；相關命令只是合法 Syntax／Negative Pair 模板。fileciteturn0file2L15-L35

這代表正式施工必須另外驗證：

`Skill Installed → Compiler Available → Correct Version Loaded → Schema Resolved → Command Executed → Typed Output Readback`

其中任何一層未完成，都不能由 Markdown 模板或 Skill 文件存在推導成功。

---

## 十、PIPD 修復完成後，B1 應如何重新使用它？

### 10.1 正確的三層使用架構

| 層級 | 使用 PIPD 的方式 | 主要輸出 |
|--------|--------|--------|
| Source／Design | Authority、PI、Profile、Spec、Trace | 受控設計契約 |
| Bootstrap Engineering | 受影 RepoContext、DEV ECP、有效 ExecutionAdmission、隔離測試 | 合法工程修補與證據 |
| Native Acceptance | HGK/Fabric/SBL 真效果、TQAEP、獨立 Checker、Claim | 正式 Native Verdict |

Hermes 不應每次醒來都重新生成全部 Source／Design。

應查詢已存在、仍有效的版本化工件，只在來源、風險、權限或受影依賴發生變更時重算。

### 10.2 B1 控制包只需要薄型執行投影

原 B1 DOC-00～08 不需要全面重寫。

但應增加有版本、有權威的 Execution Profile，將其轉化成真正可執行工作卡及依賴關係。

**必備欄位：**

`workorder_id / source_ref / effect_class / applicability / prerequisites / admission_ref / tool_adapter / first_fail / recoverability / resume_predicate / expected_raw / checker_ref / terminal_condition`

同時把 B1 的 949 Product Identities、192 Matrix Cells 等保留在完整產品覆蓋 Ledger，而非全部送入每輪 Hermes 工作 Context。

### 10.3 B1 的施工停止必須從 PIPD 分離

PIPD 決定：

「此工件是否合法、此效果是否可執行、此宣稱是否有證據。」

Hermes 決定：

「還有哪張合法工作卡可以執行、哪些工作 PARK、是否需要恢復、是否完成執行週期。」

HGK 決定 Native Permit。

Fabric 與各產品 Owner 決定相應 World Effect 的有效性。

這些權責不能互相代用。

### 10.4 正式高自動化的控制原則

在合法准入後，應採用：

```text
while mission_not_fully_resolved:

    reconcile_durable_work_state()

    ready = find_current_admitted_ready_work()

    if ready:
        dispatch_via_real_hermes_executor()
        persist_effect_or_failure_readback()
        continue

    if running_or_unknown_effect_exists:
        reconcile_or_check_valid_wakeup()
        continue

    if only_valid_external_blocks_remain:
        park_with_resume_predicates()
        end_current_execution_cycle()

    if all_applicable_work_and_native_gates_pass:
        request_final_independent_acceptance()
        break

    mark_unresolved_dependencies_without_false_completion()
```

這是目標控制邏輯，不代表目前 Hermes 已部署該實作。

其重點是 **PIPD Gate 不應替代 Runtime Scheduler，Package Seal 不應替代 Mission Completion。**

---

## 十一、完整對照實驗及正式驗收標準

為確認 PIPD 到底對 B1 造成多少阻力，應進行可重播的對照實驗，而不是只依施工報告推論。

| 實驗 | 目標 | 通過條件 |
|--------|--------|--------|
| T01：P4 POS Fixture 全量重播 | 驗證測試案例自身正確 | 無錯 Hash／跨 Subject 的 POS 被錯誤接受 |
| T02：P4 跨工件 Resolver | 驗證來源與身份一致 | Wrong Hash／Wrong Subject 必拒 |
| T03：十二軸 Profile 高風險輸入 | 驗證不會降級 | Privileged／Autonomous 高風險必依 DOC-06 升級 |
| T04：TQAEP 只產計畫 | 驗證無 Receipt 仍可合法產 Planned Plan | 不生成假 Independent PASS |
| T05：TQAEP 真 Checker | 驗證獨立收據 | 真 Principal、Receipt、Raw Join 成立 |
| T06：PIPD ECP 各 EffectClass | 驗證適用性 | 各效果有正確准入、讀回與拒收 |
| T07：PIPD 無法發正式 SourceFreeze | 驗證局部阻斷 | 受影編譯 HOLD，其他合法工作可進行 |
| T08：Hermes 沒有 READY 以外工作 | 驗證 PIPD／Runtime 分權 | 合法 PARK 或完成，不假造 PASS |
| T09：Hermes 還有 READY 工作 | 驗證不提前封存 | PIPD Package 完成也不結束 Mission |
| T10：PIPD 有／無對照施工 | 量測額外治理成本 | 合法效果相同，額外 Gate 可歸因 |
| T11：單一 OWNER 無人值守驗收 | 驗證授權與 SoD | 一位人類 OWNER，真 Checker 獨立 |
| T12：B1 Native 三 Golden WO | 驗證產品實際效果 | Fabric／HGK／SBL 各自真 Raw／Checker |
| T13：撤外援跨程序續行 | 驗證 G-B | 新程序自主完成合法 successor |

其中 T01～T06 是 P4 工具自身的關鍵修復驗收。

T07～T11 是治理與高自動化相容性驗收。

T12～T13 是 B1 正式 Native Acceptance，不能用前面任何單元測試替代。

### 11.1 PIPD 治理成本的客觀量測

至少應採用四個可比較指標：

| 指標 | 意義 |
|--------|--------|
| `Governance Overhead Ratio` | PIPD 治理處理時間／整體受影工程時間 |
| `False Hold Rate` | 原本合法、相互獨立的工作被非必要 Gate 阻斷的比例 |
| `Recompilation Amplification` | 一次受影變更造成非必要重新編譯的工件數量 |
| `Autonomous Recovery Rate` | 發生合法 HOLD 或 Session 終止後，自動恢復適用工作的比例 |

現有資料不足以給出客觀百分比，故本報告不虛構效率提升或治理成本數字。

在量測前，不能宣稱移除某一項 Gate 就必然提高多少百分比的施工效率。

### 11.2 PIPD 正式修復放行標準

P4 工具至少須達到：

- 所有受影正向測試的 Source／Subject／Hash／Receipt 一致。
- 所有負向、邊界與安全測試得到正確拒收。
- DOC-06 Profile Veto 不被 P4 降級。
- DOC-07 Oracle 權責及 Locator 正式閉合。
- TQAEP Plan 與 Independent Acceptance 分離。
- 真實 Artifact Resolver 與 Typed Failure Output 可重播。
- 不同 EffectClass 有合法明確的 ECP 路由。
- Checker 權限隔離有真實證據。
- Plugin Packager／CI／Native Compiler 的實際執行結果各自成立。
- 不因 P4 Package 成功而冒稱 Hermes Mission 完成。

---

## 十二、根因優先級與責任裁決

以下以 P0 為最高優先級。確信欄位區分直接契約證據與仍待實測的執行結果。

| 根因 | 責任主體 | 優先級 | 確信 |
|--------|--------|--------|--------|
| P4 Positive Fixture 身份／Hash／Receipt 不一致 | PIPD P4 測試／契約維護 | P0 | 直接確認 |
| P4 上游引用資訊不足、Resolver 未明確定義 | PIPD P4／Canonical Adapter | P0 | 直接契約分析 |
| DOC-06 與 P4 Profile 風險模型不等價 | PIPD DOC-06／P4 | P0 | 直接確認 |
| TQAEP 設計與驗收階段混合 | PIPD P4 Assurance | P0 | 直接確認 |
| P4 缺完整 Typed Failure／Resume 接口 | PIPD P4／下游 Adapter | P0 | 直接契約分析 |
| Oracle Writer／Locator 不相容 | PIPD P4／DOC-03／DOC-07 | P1 | 已確認相容缺口 |
| ECP 效果類型過於固定 | PIPD P4／Domain Owner | P1 | 直接確認 |
| P4 Schema 無法證明完整安全語義 | PIPD Validator／Host Adapter | P1 | 直接確認能力邊界 |
| P4 真 Runtime 與 Skill 文件法位混用風險 | PIPD 產品整合／GPT-6 產包流程 | P0 | 文件證據支持 |
| 大型設計包直接當 Runtime 入口 | B1 產包與執行設計 | P0 | 文件與施工證據支持 |
| Bootstrap 正式 Issuer 循環依賴 | B1／HGK／PIPD Admission 投影 | P0 | 紀錄支持 |
| Hermes 未形成完整 Durable Executor Loop | Hermes／Harness | P0 | r10 未通過 |
| Hermes 提前封存／停止 | Hermes／指揮控制 | P0 | r10 紀錄支持 |
| 真 Independent Checker 不足 | HGK／Checker／Host | P0 | 尚未取得正式證據 |
| 單人 OWNER 的無人值守 SoD 配置不足 | PIPD／HGK／B1 整合 | P1 | 架構缺口 |
| Plugin 成熟度與 A/B 效益未充分證明 | PIPD P4 產品維護 | P2 | 尚待實驗 |
| PIPD PR／CI 部分失敗 | PIPD Repository CI／WriteSet | P1 | 前輪直接查證 |

---

## 十三、綜合工程修復順序

從降低治理成本與加速恢復 B1 的角度，建議採用以下安排：

| 階段 | PIPD 工作 | B1／Hermes 工作 | 不可放寬的條件 |
|--------|--------|--------|--------|
| A：恢復基礎可信度 | P4 Fixture／Hash／Subject 修復 | 唯讀盤點、查明真 Executor | 不產生假 Compiler PASS |
| B：關閉接口缺陷 | Profile、Oracle、TQAEP、Resolver | 建立有界 Bootstrap 工作卡 | Repo Mutation 須有有效 Admission |
| C：恢復自治施工 | Typed Failure／Resume Contract | SharedSpine → Hermes 真 Executor → 自動續行 | 不建立第二 Queue |
| D：正式 Native 能力 | Native Adapter／ECP／Checker | HGK Receiver、Fabric R3、模型 R4 | 真 Permit／真 Host Readback |
| E：正式驗收 | 獨立 TQAEP、ClaimCeiling、TraceClosure | G-A、三 GWO、G-B、正式 Handoff | 不借用跨 Subject 證據 |

A～C 中互不依賴的工作應並行，不應建立另一條全域瀑布式 Gate。

任何修訂都必須有正式版本、受影 Schema／Fixture、Regression 與向後相容政策。不能為了趕進度而將所有拒收直接改成允許。

---

## 十四、最終工程鑑定與正式建議

### 14.1 PIPD 工具本身是否存在重大問題？

**存在，而且比單純「治理過重」更具體。**

P4 的部分 Positive Fixtures 不符合自身所要求的跨工件身份一致性；部分 Typed Input 無法完整表達應產生的下游內容；部分高風險治理語義無法由現有 Schema 單獨執行。

這些應正式列為 PIPD P4 工具相容性及 Conformance Repair 項目，而不只是 B1 文件問題。

但尚不能在未運行 Native Validator 的情況下，宣稱全部缺陷都已在正式 Runtime 中造成錯誤放行。

### 14.2 PIPD DOC-00～09 是否存在根本架構錯誤？

**目前沒有足夠證據支持全面否定其架構。**

Canonical Writer、分階段生命週期、Effect Admission、Affected-only Invalidation、Claim Separation、Independent Verification 都具有必要性。

真正需要修正的是 P4 與 DOC 原規範間的語義閉合，以及在高自動化場景中的准入、復原和最小工作單位。

### 14.3 PIPD 是否過度工程化？

**對目前 B1 的 Bootstrap 執行而言，確實出現過度治理的實際結果。**

但其中有兩種不同問題：

- PIPD 自身部分工具契約過於固定、階段混用、缺少可持續執行的錯誤回傳。
- B1／GPT-6 產包與後續指揮，將完整正式驗收負擔過度投影到一般施工入口。

兩者都應修正，不能只責怪某一邊。

### 14.4 PIPD 是否不適合高自動化？

**目前 P4 不宜單獨充當高自動化任務運行總控制器，但適合作為經修復後的契約與驗證前置層。**

PIPD 定義什麼合法、什麼可驗；Hermes／HGK 負責持久任務執行與 Native 效果。

正確目標不是把 PIPD 變成 Scheduler，也不是取消 PIPD，而是讓其輸出足夠機器可讀、局部可恢復、可進行嚴格語義驗證。

### 14.5 PIPD 是否不適合單一人類 OWNER？

**原則上適合，但目前還缺乏足夠完整的單 OWNER／多受控 Principal 執行配置。**

不可把「獨立 Checker」誤解成必須有第二位人類，也不可把兩個模型名稱不同誤當作真正獨立。

需要的是技術上的信任隔離與預授權控制。

### 14.6 PIPD 是否是 B1 失敗的主要來源？

需分兩層回答。

**就治理膨脹、契約衝突與部分編譯阻斷而言，PIPD 是重要的上游促成來源。**

**就 r10 Hermes 提前停止、未探索 R3/R4／真 Executor、未形成跨程序自治續航而言，不能將 PIPD 判定為唯一或主要直接故障。**

直接執行問題仍須由 Hermes/Harness 與 B1 Runtime Projection 修復。

### 14.7 最終採納建議

**工程總裁決：`PIPD_P4_SEMANTIC_CONFORMANCE_REPAIR_REQUIRED`**

**B1 總裁決：`B1_EXECUTION_PROJECTION_AND_AUTONOMOUS_LOOP_REPAIR_REQUIRED`**

---

建議保留 PIPD Canonical Lifecycle 與安全治理架構；優先修正 P4 的 Positive Fixtures、跨工件解析、Profile Risk Binding、Oracle Locator、TQAEP 階段分離、Effect Class 與 Typed Failure Contract。

B1 原控制包保持上位設計地位，另以有版本的薄型 Runtime Execution Profile 承接 Hermes。

真正 Native Effect 仍依 HGK 唯一 Issuer、實際權限、World Readback 及獨立 Checker 取得正式放行。

**最終結論：**

PIPD-LS-SP P4 的原始意圖，是以確定性、可追溯、可驗證的契約降低施工前的語義風險；但本次查核證明，其部分實際契約和測試基準尚未達到自身要求的完整一致性。

GPT-6 將其用於 B1 大型產包時，又進一步放大了來源、測試、授權和最終驗收的治理負擔。隨後 Hermes 缺少成熟的 Runtime WorkState 與 Stop Controller，使正式 HOLD、文件封存和任務停止相互混淆。

因此，最有效的方案不是全面移除 PIPD，也不是全面重寫 B1，而是**先修正 PIPD 工具本身可直接證明的不一致，再修復 B1 的執行投影，最後以真正的 Hermes Native 閉環完成高自動化與正式驗收。**

本次為工具契約、原始規範、靜態 Fixture 及歷次工程紀錄的交叉鑑定；**不構成 PIPD Native Compiler 全量實測 PASS、獨立 Checker Qualification，或 B1 正式 Native Acceptance。**

## Prompt:
2026/10/27 下午9:14:38

你的角色：\
你是「HERMES / FABRIC / SBL / HG-KSEOS」高自動化任務運行總工程師。\
\
任務目標：\
你必須整合前輪「PIPD-LS-SP Public Skills P4 與 PIPD_LS_DOC-00～09 全面工程鑑定報告」，再對「[$pipd-ls-sp-public-skills-p4](app://Plugin_0ff92abe45e081918f19a96a3acda239) &『《PIPD_LS_DOC-00》\~《PIPD_LS_DOC-09》』」進行以下項目的深度研究+交叉分析+鑑定評估：
"
1\)是否「PIPD-LS-SP Public Skills P4 與 PIPD_LS_DOC-00～09 全面工程鑑定報告」提出的問題，在《FHS-MSC_藍圖_r2》、《FHS-MSC_總討論》其實都已經包含這些問題的解法?

2\)是否能依照「SBL_PIPD-LS-PKG 全冊」、《FHS-MSC_藍圖_r2》、《FHS-MSC_總討論》的規劃，把「[$pipd-ls-sp-public-skills-p4](app://Plugin_0ff92abe45e081918f19a96a3acda239) 、『《PIPD_LS_DOC-00》\~《PIPD_LS_DOC-09》』、「[$sbl-tpm-sp](app://Plugin_43c6e757a0d8819183dc3486d166c24f) 」」 進行完整修補並整合成一套完整SKILLS-PLUGIN，並進行升級、治理收斂、鏈路修補、支援高自動化，成為一套完整可用版的SBL-TPM-SP?
"

任務要求：
你必須針對任務目標，並對全部相關資料進行「研究分析+交叉比對+深度推理」，再進行鑑定、評估、規劃，並提出完整報告。

## Response:
2026/10/27 下午9:14:57 · gpt-6-thinking

我會分三條證據線處理：第一，逐項核對前輪 P4 缺陷是否已在《FHS-MSC\_藍圖\_r2》與《FHS-MSC\_總討論》中有明確解法；第二，比對 SBL DOC-00～13、PIPD DOC-00～09、八項 P4 Skill 與現有 TPM-SP 的權責及接口；第三，提出可施工的整合架構、修復規格、驗收條件與發布路徑。會嚴格區分「原文件已有設計」、「尚須補齊契約」及「必須實際開發測試」，避免把設計可行性誤認為完整可用版已成立。

交叉核對後可先確定：**《FHS-MSC\_藍圖\_r2》確實已提出多項解法，而且比前輪報告所呈現的更具體。** 它已明文處理十二軸風險與 P4 九軸不可直接同構、DOC-03／DOC-07 Oracle 權威衝突、單一 OWNER 的有界常設授權、局部 HOLD、PIPD 與 HGK／Hermes 的權責分離、跨 Host 實際載入驗收。但這些仍屬設計／候選 DTO，不能抵銷 P4 正向 Fixture 的 Hash、Subject 與收據不一致，也不能證明整合插件已完成實作。下一步將把「已規劃但未落地」與「原資料尚未提供解法」逐項分清。

> **列出 FHS 相關文件檔案**
>
>
> **檢視 FHS 文件並擷取藍圖關鍵段落**
>
> 
>
> **盤點 SBL 文件中的插件打包證據**
>
>
> **盤點SBL文件證據並整理TPM缺口歷史**
>
> 
>
> **整理插件架構**
>
> 我正在釐清這個插件的定位：它可以完整支援 SBL-TPM-SP 的產品管理功能，但不能把單一 TPM 插件宣稱成涵蓋 Commander 與 Checker 的完整三模組產品。
>
> **整理插件架構**
>
> 
>
> **已搜尋 5 個網站**
>
> 
>
> **取得並檢查外掛元資料、檔案清單與發布檔案**
>
> 
>
> 處理時間為 7m 50s

# SBL-TPM-SP 整合升級可行性暨 PIPD-LS 治理收斂工程鑑定報告

鑑定基準：2026 年 10 月 27 日｜研究對象：PIPD-LS-SP Public Skills P4、PIPD\_LS\_DOC-00～09、SBL\_PIPD-LS-PKG\_DOC-00～13、FHS-MSC 藍圖與總討論、現有 TPM-SP

## 一、總體工程結論

**兩個核心問題的答案分別是：**

**第一，《FHS-MSC\_藍圖\_r2》與《FHS-MSC\_總討論》確實已提出前輪多數架構性問題的解決方向，其中藍圖 r2 甚至明確寫出了 PIPD 十二軸與 P4 九軸的映射規則、Oracle 權威衝突、局部 HOLD、單一 OWNER 常設授權及最小自治施工鏈路。**

但是，這不代表問題已解決。尤其 P4 正向測試案例中的跨工件 Hash、Subject、Checker Receipt 不一致，以及缺乏足夠完整的 Semantic Resolver 等工具級缺陷，沒有因藍圖存在而完成修復。

**第二，可以依照既有 SBL、FHS-MSC 和 PIPD 的架構，把目前的 P4 八項 Skills、PIPD DOC-00～09 的正式生命週期規範，以及現有 TPM-SP 整合成一套升級版 SBL-TPM-SP Skills Plugin。**

但必須採取正確的整合方式：

> **SBL-TPM-SP 成為統一產品入口、需求規劃與 PIPD 工件編譯協調層，不是將 PIPD Canonical Compiler、HGK Issuer、Hermes Scheduler、Independent Checker 全部複製進同一個 Plugin。**

一套完整的 Plugin 可以統一入口、Skill Router、Typed Contract、Reference、Adapter、測試與交付體驗；但不能因此合併跨系統的執行權限或取消真正的 Native Admission。

### 1.1 核心鑑定摘要

| 評估項目 | 結論 |
|--------|--------|
| FHS 藍圖是否已有大部分解法？ | **有，主要是設計層及控制策略** |
| 是否已解決 P4 自身缺陷？ | **沒有，仍需程式、Schema、Fixture 修復** |
| 現有 TPM-SP 是否等於完整 SBL TPM？ | **否，目前只有限縮的需求與交接功能** |
| 三組資產是否能整合為單一 Plugin？ | **架構可行，需實際封裝與 Host 驗收** |
| 是否應把十冊 PIPD DOC 全文放入每輪 Context？ | **否，必須採 Progressive Disclosure** |
| 是否需要新增第二套 PIPD Compiler？ | **不需要，也不應該** |
| 是否適合單一人類 OWNER？ | **可以，須實現有界授權與獨立機器 Principal** |
| 是否能支援 Hermes 高自動化？ | **可以支援，但 Hermes Runtime 閉環仍需另行修復** |
| 是否可以現在宣告完整可用版？ | **不能，目前只有設計可行性與部分已安裝 Skill 能力** |

### 1.2 最重要的架構建議

建議採用：

**`SBL-TPM-SP Unified Plugin + PIPD Canonical Adapter + Native Execution Handoff`**

其主要原則是：

- One Core，不另造第二個 Canonical Truth。
- One SBL-TPM-SP Plugin，統一使用者入口與規劃工作。
- 保留八項 P4 技能的生命週期責任，但修正缺陷並作內部化整合。
- PIPD DOC-00～09 作為版本化 Normative Reference，不作每輪必讀巨型 Prompt。
- SBL DOC-00～13 作為產品架構與規劃契約來源，不直接混入 PIPD 原生 Schema。
- LITE／STANDARD／ASSURED 控制工件深度，安全 Veto 不得降級。
- 真正執行仍由有權的 PIPD／HGK／Fabric／Hermes／Host 接口處理。
- 原始需求、完整覆蓋與正式驗收分母不得靜默遺失，但只派發目前適用的工作。

這是**高自動化與治理收斂兼顧**的方案，而不是單純把九個 `skill.md` 合併成一份更大的 `SKILL.md`。

---

## 二、問題一：FHS-MSC 兩份文件是否已經包含解法？

### 2.1 必須區分兩份文件的性質

《FHS-MSC\_總討論》主要是早期工程鑑定與討論紀錄，特別涵蓋 R17、Fabric、HG-KSEOS、SBL、排程、權限、驗收及最小修復策略。

《FHS-MSC\_藍圖\_r2》則是 2026 年 10 月 26 日整合後的工程藍圖，包含正式設計修訂、R15.1 產品分母、PIPD 使用規範、自治執行策略及施工候選。

兩者不能視為同等版本的正式 Native 契約。

**總討論提供問題脈絡與早期解決方向；藍圖 r2 提供較具體的目標設計和施工規格。**

藍圖 r2 自身也聲明：

`FAIL-CLOSED / DESIGN_REPAIR_CANDIDATE / NO_RUNTIME_AO / NO_RELEASE`

因此，它可以作為本次修復方案的重要來源，但不代表其所描述的 Adapter、權限或驗收都已正式生效。

### 2.2 前輪重大缺陷與 FHS 既有解法交叉矩陣

| 前輪發現的問題 | FHS 是否已有解法 | 具體來源 | 尚未完成部分 |
|--------|--------|--------|--------|
| 十二軸風險與 P4 九軸不相容 | **有，明確** | 藍圖 r2 §5.1 | 正式 RiskMapping、Owner 批准及測試 |
| DOC-03／DOC-07 Oracle 衝突 | **有，明確識別** | §2.1、§5.1 | PIPD Owner 裁決、Schema／ABI 修訂 |
| SourceFreeze 造成全域停工 | **有** | §3.3、§6.3、§7 | Typed 局部阻斷與恢復的 Runtime 落地 |
| TQAEP Plan 與真 Checker 混用 | **部分** | §4.1、§5.1、§7.4 | 尚缺分離的 P4 Planned／Executed Schema |
| ECP 使用單一效果規則 | **部分** | §12.1～§12.4 | EffectClass 專屬 Native Adapter |
| 單一 OWNER 反覆授權 | **有，明確** | §6.1、§12.2 | 真 HGK 令牌與預授權映射 |
| Hermes 任務反覆中止 | **有** | §3.3、§12.5 | 真 Executor、Durable Resume、Stop Controller |
| 無效工作阻塞其他工作 | **有** | §3.4 RC04／RC05 | Scheduler Fairness 真實驗證 |
| PIPD 與 HGK 權限重複 | **有** | §2.1、§12.1 | 真 Native API／接口驗收 |
| Plugin 文件等於已安裝能力 | **有明確反對** | §2.2、§5.3 | 真 Host Install／Load／Invoke |
| 需求、測試與產品分母混算 | **有** | §3.2、§5.3 | 實際 Coverage Index／Work DAG |
| Context 過大、重複解析 | **部分** | §5.3、PIPD DOC-08 | JIT Reference Loader／Context 實測 |
| P4 Trace Hash 正向案例不一致 | **只有一般防護原則** | §4.3、AT-02／AT-17 | Fixture 實際修補 |
| P4 ECP Positive Fixture 跨 PD Subject | **未找到具體修補** | 一般 Identity Join 規範 | 修正原測例、驗證器 |
| P4 Checker Receipt 正向案例不一致 | **未找到具體修補** | 一般獨立驗收規範 | 修正原測例、收據 Join |
| P4 Package Graph Edge 不一致 | **只有一般 Trace Closure 原則** | §4.3、AT-17 | Graph Resolver／Fixture 修補 |
| P4 統一 Typed ErrorEnvelope | **只有局部 FirstFail 設計** | §3.4、§12.3 | 跨 Skill 狀態及 Resume ABI |
| SBL-TPM-SP 完整 Plugin 封裝 | **已有產品架構** | §3、§5.2、DOC-04 C13 | 九項能力的實際整合、測試與發布 |

### 2.3 已有完整方向的三項重大解法

**一、Profile 十二軸與九軸**

藍圖 r2 §5.1 已明確提出：

`source_12_axis_values → plugin_axis_values → mapping_rows → lossiness → safety_veto → effective_profile`

並要求不可映射時維持 `HOLD_FOR_PROFILE_OWNER`。

因此前輪指出的不相容問題，**不是 FHS 完全沒有考慮，而是已提出解法但尚未落地**。

**二、單一 OWNER 與高自動化**

藍圖 r2 §12.2 已有 `ProposedStandingMissionGrant`，包含 Mission、Subject、Root、WriteSet、風險上限、期限、可撤銷權限、成本／並行限制及必須另行批准的效果類別。

這表示 FHS 早已規劃單一人類 OWNER 的有界自治施工。問題在於該 DTO 明確標為候選，尚不是 HGK 現役 Permit。

**三、研究重試與效果重試**

藍圖 r2 §12.3～§12.4 已將 FAR 研究決策循環與 Native 效果循環分開，要求未知效果先 Reconcile，不得盲目重播。

這正是前輪 ECP 過度阻斷的必要修復方向。

### 2.4 關鍵勘誤：有解法不等於已修復工具

FHS 已經描述如何避免某些錯誤，並不代表 P4 已有對應的正式 Input／Output Schema，也不代表其 Positive Fixtures 已修正。

例如：

FHS 要求 Same-object Hash Join；但前輪直接檢查 P4 `pipd-pi-compile` 的 POS Fixture，仍發現 Atom `content_hash` 與 TraceLink `to_hash` 不一致。

這兩項事實可以同時成立：

**FHS 具有正確設計原則，而 P4 實際測試資料仍有缺陷。**

所以不能把 FHS 文件當作 P4 Runtime 的修復收據。

### 2.5 第一問題的正式裁決

**《FHS-MSC\_藍圖\_r2》已包含前輪大多數架構級與治理級問題的解決方向；《FHS-MSC\_總討論》亦提供相應根因及最小修復策略。**

但並未充分閉合工具級 Fixture 缺陷、真 Semantic Resolver、Plugin 整合封裝、實際 Host 生效、跨 Skill 錯誤／恢復契約及完整可用版的驗收。

因此，本次不需要重新發明另一套 PIPD 理論；應以 FHS 與 SBL 已有規格為基礎，進行**受影實作修復與契約閉合**。

---

## 三、現有兩套 Plugin 的實際能力與升級條件

本次除了讀取 Skill 契約，也直接查詢了兩套已安裝私人 Plugin 的現行套件資訊及內容清單。

### 3.1 現役套件確認

| 項目 | PIPD Public Skills P4 | SBL-TPM-SP |
|--------|--------|--------|
| Plugin 名稱 | `pipd-ls-sp-public-skills-p4` | `sbl-tpm-sp` |
| 現行版本 | `0.1.1` | `0.1.1rc1` |
| 套件範圍 | USER／PRIVATE | USER／PRIVATE |
| Skills 數量 | 8 | 1 |
| 契約資料 | Skill、Schema、Contract、Examples、Cases | 一份 TPM-SP Skill |
| 封裝法位 | `LOCAL_PACKAGER_PASS_ONLY` | `HOST_PENDING` |
| Plugin 原始內容 | 已可讀取 | 已可讀取 |
| 更新可行性 | 具備符合權限的編輯入口 | 具備符合權限的編輯入口 |

P4 的 Release Receipt 顯示 56 個封裝成員、固定來源 Commit 與 Source Tree；但其正式 Portal Verification 仍記為 `NOT_EXECUTED`。

TPM-SP 的 Manifest 則明確表達：

- `goal.read`
- `spec.write`
- `evidence.read`
- 禁止 `product.write`
- 禁止 `challenge.sign`

其 `read_only:false` 應解讀為可以寫入受限的 Spec／草稿，而不是可以修改產品原始碼或進行 Native World Effect。

**重要進展：現有 SBL-TPM-SP 確實有可識別的私人 Plugin 身份及可編輯套件來源，因此存在原身份升級的技術途徑，不必必然另建一個同名 Plugin。**

但本輪只是讀取套件；尚未更新版本、重新封裝或執行正式發布。

### 3.2 現有 TPM-SP 與完整 SBL 設計的落差

目前 TPM-SP 的 `SKILL.md` 主要處理：

`Goal → JTBD → FUO → Non-goals → Acceptance → Source Ledger → Bounded Handoff`

這是合理的產品需求入口，但與 SBL DOC-04 C13 所規定的完整 TPM 職責相比，仍屬初階薄型能力。

| SBL DOC-04 C13 要求 | 現有 TPM-SP | 升級要求 |
|--------|--------|--------|
| Product Manager | 有初步需求界定 | 強化 Persona、產品 Kind、Value Criteria、FUO |
| Systems Engineer | 不完整 | 增加架構邊界、ADR、ABI、權威及風險 |
| Technical Program Manager | 不完整 | 增加 DAG、依賴、資源、Milestone、Stop Event |
| T0～T5 階段 | 未完整實作 | 建立有版本的 StageMap 和逐階段結果 |
| 三角色 × 六階段，共 18 StageContracts | 未完整實作 | 各自 Typed IO、Exit／FirstFail |
| QuestionLedger／不重問已知答案 | 僅有基本問答原則 | 來源已知答案消除、資訊增益排序 |
| Quick／Guided／Critical | 未完整實作 | 依風險與需求完整度自動選擇 |
| 三條 Golden Journeys | 未有實際完整驗收 | GJ01／GJ02／GJ03 各自執行 |
| PIPD 真正八技能 | 未內建 | 有版本的 Skills 與 Compiler Adapter |
| 工件 Claim／Trace Closure | 未完整實作 | 合法受影工件與證據 |
| 跨 Host Install／Invoke／Uninstall | 尚無正式完整驗收 | 每 Host 實測 |
| 整體產品階段放行 | 無權自證 | 保持 Candidate，交原權威驗收 |

### 3.3 尚未解決的 T0～T5 內部設計衝突

SBL DOC-04 C13 保留了三組來源對 T0～T5 的不同語義，並明確標示：

`CR-DOC04-STATE-MAP = HOLD`

尤其 T4／T5：

- 一套將 T4 定位為 PI/PD Handoff、T5 為 Evidence-aware Review。
- 另一套將 T4 定位為 POS/NEG/Oracle Proposal、T5 為 PI Handoff。
- 第三套來源具有不同的 WorkPackage 與 Review 邊界。

DOC-04 已經提供 `TStageMap@source_hash`、三個角色、18 項 StageContract，以及每項的 FirstFail 和下一個合法階段。

**但並未宣告這三組語義已正式取得上位 Owner 裁決。**

因此，SBL-TPM-SP 升級時不能自行選擇一種 T0～T5 語義並把它發行為唯一 Canonical State。

建議：

- 原始 T0～T5 的 Source Stage Identity 保留。
- 三角色以 Typed Stage Projection 分別表示。
- 受影 T4／T5 衝突必須經原 Owner 有效裁決後才能正式升格。
- 未裁決時仍可進行不受影的需求探索、Product SPEC Draft 與風險盤點。
- 不得把 TPM 的 T0～T5 當成 PIPD DOC-01 的正式 Lifecycle State。

這是此次整合計畫必須新增到 P0 的問題，否則只是把 PIPD 的契約衝突轉移成 SBL-TPM-SP 內部衝突。

---

## 四、完整 SBL-TPM-SP 的最終產品邊界

### 4.1 必須清楚定義什麼叫「完整可用」

建議的產品目標是：

**SBL-TPM-SP：一套可安裝、可調用、具完整產品／系統／技術規劃能力，能以合法 PIPD 契約產生可供後續工程施工使用的受治理交接包，並能在來源變更或局部阻斷時進行有界重新規劃的 Agent Skills Plugin。**

它的 First Useful Outcome（FUO）不是產生一份很長的設計報告。

而應是：

**使用者提供一個具來源的產品或工程目標後，系統能產生可驗證的 Product SPEC、Architecture SPEC、Program SPEC、PI／PD 交接候選、受影 WorkPackage DAG、POS／NEG 驗收需求及具體未解阻斷；並在合法的現役編譯環境中取得真正 PIPD 工件。**

缺少正式外部授權時，產品仍能交付清楚且可編輯的規格候選，不得假裝完成 Native Effect。

### 4.2 不能將 SBL-TPM-SP 擴張成整個 SBL

SBL 上位設計是 **One Core／Three SP／Six Logical Modules**。

三個 SP 的職責分別是：

| SP | 主要能力 | 能否由 TPM-SP 自行冒名承接 |
|--------|--------|--------|
| TPM-SP | Product／System／Program 規劃、需求與 PIPD 交接 | 本次升級主體 |
| Commander-SP | 有界施工提案、執行請求、CAPC Handoff | **不能** |
| External Challenge-SP | 獨立挑戰、Oracle、受限驗收提案 | **不能** |

因此，完整可用版 TPM-SP 應能產生供 Commander 與 Challenge 使用的正式候選輸入，但不應把兩者的全部能力和權限直接吸收入自身。

特別是 B1 目前存在 Commander-SP 禁用要求，本次 TPM 升級不能以間接調用已禁用的 Commander 作為必要前置。

如果合法的 PIPD 交接只需要進入獨立 HGK 原生 Handoff Adapter，則應使用該受權入口；沒有真實入口時保留 Candidate／HOLD。

### 4.3 使用者實際可獲得的產品能力

升級後應支援三種主入口：

| 模式 | 適用任務 | 結果 |
|--------|--------|--------|
| Quick | 範圍清楚、風險低、已有充分來源 | 小型 GoalCard、FUO、最低必要 SPEC、Acceptance |
| Guided | 一般產品設計、系統規劃、Brownfield 改造 | 三類 SPEC、ADR、PI/PD Candidate、WorkPackage DAG |
| Critical | 高風險權限、跨系統、自治執行、不可逆效果 | 完整 ASSURED 投影、Risk Veto、獨立驗收需求、正式准入交接 |

Quick 模式應減少文件與問答負擔，但不能繞過適用的安全限制。

Critical 模式不應等於「每個工作都要求全人工作業」，而是必須準確區分可預授權、必須即時授權及無合法路徑的效果。

---

## 五、建議採用的統一 Plugin 架構

### 5.1 單一 Plugin、分層組件、原生權威不合併

**SBL-TPM-SP Unified Skills Plugin**

統一使用者入口、Task Router、Progressive Disclosure

**SBL Shared Core**

Goal／JTBD／FUO、QuestionLedger、三角色 T0～T5、SPEC／ADR／DAG

**PIPD P4 Lifecycle**

Intake、Authority、Profile、PI、PD、ECP、TQAEP、Package

**Typed Integration Adapters**

Source Resolver／Risk Mapper／Semantic Validator／ErrorEnvelope／Artifact Resolver／Handoff

**外部正式權威（不複製）**

PIPD Canonical Compiler ｜ HGK Native Issuer ｜ Fabric Policy ｜ Hermes Executor ｜ Independent Checker

這樣可以做到**一個安裝體驗、多個內部技能、跨系統單一正式權威來源**。

不應把 One Core 理解為所有功能都必須由同一個 Python 程序執行，也不應把單一 Plugin 當成所有操作都擁有同一個 OS Principal。

### 5.2 建議的技能構成

保留既有八項 PIPD Skill 名稱，擴充 SBL-TPM-SP 的協調及規劃能力。

| 內部 Skill | 功能 | 來源 |
|--------|--------|--------|
| `tpm-sp` | TPM 主入口、JTBD／FUO／QuestionLedger | 現有 SBL-TPM-SP |
| `tpm-product-plan` | Product SPEC、Persona、Value Criteria | SBL DOC-01／04 C13 |
| `tpm-system-plan` | Architecture SPEC、ADR、ABI、Ownership Seam | SBL DOC-04 C12／C13 |
| `tpm-program-plan` | Program SPEC、依賴 DAG、Milestone、Handoff | SBL DOC-04 C13 |
| `pipd-route-intake` | 原生 IntentCard | P4 |
| `pipd-authority-source` | SourceFreeze／Authority Binding | P4 |
| `pipd-profile-tailor` | Risk/Profile Binding | P4（修訂後） |
| `pipd-pi-compile` | PI-PKG | P4（修訂後） |
| `pipd-pd-bind` | Repo-bound PD-PKG | P4 |
| `pipd-execution-contract` | ConstructionContract／ECP | P4（修訂後） |
| `pipd-assurance-tqaep` | TQAEP | P4（分離 Planned／Live） |
| `pipd-package-project` | ClaimCeiling／TraceClosure | P4（修訂後） |
| `tpm-handoff` | 正式輸出候選與拒收／恢復建議 | SBL／FHS Adapter |
| `tpm-setup` | Host、Compiler、版本、權限診斷 | Plugin Setup |

這是**建議的 14 項工作流目錄**，不是宣稱目前已存在 14 個可執行 Skill。最終實體數量可以再依每項測得的觸發混淆率合併，但不得因此合併不同 Canonical Writer。

### 5.3 以 Progressive Disclosure 降低 Context 與治理負擔

SBL DOC-10、PIPD DOC-08 與 FHS r2 的共同方向，是根據任務需要載入資料。

應採三級架構：

| 層級 | 載入內容 | 使用時機 |
|--------|--------|--------|
| L0 | Skill Metadata／簡短 Router | 每次啟用 |
| L1 | 受影 Skill Contract、最小 Schema、必要 Source Identity | 確定工作類型後 |
| L2 | 完整 Normative Reference、具體 Oracle、相容性表、Fixture | 精確編譯、衝突或驗收時 |

例如，只要使用者要求建立新產品的 FUO 與非目標，就不需要立即載入 DOC-07 所有 Oracle、DOC-09 全部 Release 規則及 B1 的全部 WorkOrder 分母。

但當使用者要求簽發正式 ECP 或進行 Qualified Handoff，必須載入相應的有效契約和驗證依據。

這與 Agent Skills 的 Progressive Disclosure 設計一致，官方規格也建議把詳細資料放在 `references/`，按需載入，而非全部堆進 `SKILL.md`。\[[agentskills/docs/specification.mdx at main · agentskills/agentskills](https://github.com/agentskills/agentskills/blob/main/docs/specification.mdx?utm_source=chatgpt.com)\]

### 5.4 建議的封裝目錄

```text
sbl-tpm-sp/
├── plugin.json
├── README.md
├── CHANGELOG.md
├── NOTICE
├── skills/
│   ├── tpm-sp/
│   ├── tpm-product-plan/
│   ├── tpm-system-plan/
│   ├── tpm-program-plan/
│   ├── pipd-route-intake/
│   ├── pipd-authority-source/
│   ├── pipd-profile-tailor/
│   ├── pipd-pi-compile/
│   ├── pipd-pd-bind/
│   ├── pipd-execution-contract/
│   ├── pipd-assurance-tqaep/
│   ├── pipd-package-project/
│   ├── tpm-handoff/
│   └── tpm-setup/
├── references/
│   ├── authority-index/
│   ├── pipd-doc00-09/
│   ├── sbl-doc00-13/
│   ├── fhs-decision-index/
│   └── compatibility/
├── schemas/
│   ├── sbl-tpm/
│   ├── pipd-adapters/
│   └── host-handoff/
├── tests/
│   ├── contract/
│   ├── semantic/
│   ├── security/
│   ├── integration/
│   └── golden-journeys/
├── assets/
│   └── templates/
├── mcp.json
└── .codex-plugin/
    └── plugin.json
```

此為概念性的目標結構，正式打包前仍須按每個 Skill 的相對路徑解析規則整理附屬檔案。

目前 OpenAI 官方的 Portable Plugin 格式支援根目錄 `plugin.json`、`skills/`、可選的 `mcp.json` 與平台擴充資訊；`.codex-plugin/plugin.json` 可作兼容性入口。\[[Package your plugin – Plugins](https://developers.openai.com/plugins/build/plugins?utm_source=chatgpt.com)\]

### 5.5 Skills-only 還是 Skills + MCP？

**建議採取雙能力層級，但使用同一個 Plugin 身份。**

| 能力層 | 技術 | 可交付內容 |
|--------|--------|--------|
| Design／Planning | Skills、References、Schemas | Goal、SPEC、ADR、PI/PD Candidate、規格及差異分析 |
| Verified Tool Execution | Skills + 有授權 MCP／Host Adapter | 真 PIPD Compiler、Artifact Resolver、Host Readback、受控 Handoff |

Skills-only 可以提供規範化的規劃工作流，但不能單憑 Skill 文字自行創造不存在的本地程式、網路工具或安全權限。

若要求在 ChatGPT 或其他 Host 中真正執行 PIPD Compiler、讀取現役 Repository 和提交受治理 Handoff，需要受授權的工具接口。OpenAI Plugin 架構正式支援以 MCP Server 提供工具、身份驗證及結構化輸入輸出。\[[Plugin architecture – Plugins](https://developers.openai.com/plugins/concepts/plugins?utm_source=chatgpt.com)\]

**這不代表必須再造新的 PIPD Compiler。** MCP 只應作為現有合法 Compiler／Host 的薄型轉接層。

---

## 六、SBL DOC-00～13 在統一 Plugin 中的責任配置

SBL 全冊不能無區別地當作 TPM-SP 的直接執行命令。

各冊應保留其上位設計角色：

| SBL DOC | 統一 Plugin 中的用途 | 改造重點 |
|--------|--------|--------|
| DOC-00 | Router、Authority、Claim | 版本化 Source Index、合法 Writer 對應 |
| DOC-01 | JTBD、FUO、ProductKind、Journeys | 真使用者成果、已知答案不重問 |
| DOC-02 | Source／Requirement | 原子追溯、來源完整度、衝突 |
| DOC-03 | SPEC／Planning／PIPD Projection | 精確 Typed Interface，不造第二 Compiler |
| DOC-04 | One Core／Three SP／C13 | 完成三 TPM 角色、TStageMap、18 Contracts |
| DOC-05 | RepoContext／ECP／Handoff | DEV／OPS 分離，合法 Admission |
| DOC-06 | Technology Admission | 先重用 Native，NoFit／Provider-off 正確處理 |
| DOC-07 | Security／Human Approval | 有界 OWNER Grant、真 Credential／SoD |
| DOC-08 | Acceptance／Oracle／Challenge | Planned 與 Executed 分離、真 Checker |
| DOC-09 | Evidence／Trace／Delivery | Raw、Hash Join、Affected-only |
| DOC-10 | Host／Skill／AI Consumer | Progressive Disclosure、Effective Load |
| DOC-11 | HGK／Fabric Native Integration | 只提供受控 Handoff，不自簽 Permit |
| DOC-12 | Build／Distribution／Release | BOM、版本釘選、Host UAT、回滾 |
| DOC-13 | Dogfood／Evolution | Golden Journeys、Feedback、Requalification |

**主要應修的不是 DOC 數量，而是目前 SBL-TPM-SP 的實際能力遠少於 DOC-04 C13 所要求的產品職責，以及 P4 仍缺足夠完整的 Canonical Semantic Bridge。**

另外，SBL 全冊仍包含 `CR-ORACLE-001`、N14 Ratification、部分來源及 Host Binding 等未閉合項目。統一 Plugin 不能以一次全量產包，自動替這些外部裁決填入假 PASS。

---

## 七、PIPD P4 的完整修復規格

建議以既有八技能作受影修復，不直接拆毀重建。以下是整合為 SBL-TPM-SP 前必須處理的契約缺口。

### 7.1 八技能修復矩陣

| Skill | 必要修復 | 正式退出條件 |
|--------|--------|--------|
| `pipd-route-intake` | 保留五類原生 Requirement，增加專案 Atom Sidecar 的無損映射驗證 | 原始需求不遺失、沒有自造 Source |
| `pipd-authority-source` | 綁定真 Source Registry／Digest、Currentness、Owner Conflict | 不因 Family Code 合法就自動取得權威 |
| `pipd-profile-tailor` | 十二軸 RiskBinding、九軸映射、Mandatory Veto | 不可映射不得降級 |
| `pipd-pi-compile` | ProfileBinding Resolver、Oracle Locator、Trace Identity | Same-object Hash 完全一致 |
| `pipd-pd-bind` | RepoContext Freshness、Scope、Effective Root | Stale／越界／跨 Repo 拒收 |
| `pipd-execution-contract` | 修正跨 PD Subject Fixture，區分 DEV／OPS／USER | ECP 不越權、不冒充 Permit |
| `pipd-assurance-tqaep` | 分離 Plan／Execution／Acceptance；修正 Checker Receipt | Planned 不等於 Independent PASS |
| `pipd-package-project` | 真 Trace Graph Resolver、Claim Transition、受影封裝 | 無 Orphan／錯 Hash，不代替 Runtime 結案 |

### 7.2 必須新增的共通契約

這裡的「新增」應優先指**跨 Skill 的 Versioned Extension 或 Adapter ABI**，不是建立第二套 PIPD Canonical 工件家族。

| 契約 | 必要欄位／功能 | 正式權責 |
|--------|--------|--------|
| `RiskMapping` | 12-axis facts、9-axis projection、lossiness、veto、Owner | PIPD Profile Owner |
| `ArtifactResolver` | Subject、Hash、Version、Authority、Currentness | PIPD Canonical Reader |
| `OracleBinding` | Canonical Oracle ID、Writer、Locator、Version、Checksum | PIPD Oracle Owner |
| `ErrorEnvelope` | FirstFail、Affected Scope、Recoverability、Next Action | PIPD／Adapter |
| `EffectClassAdapter` | Effect Type、Admission、Readback、Retry、Compensation | 各 Effect Owner |
| `AssuranceState` | Planned、Executed、Independent Verified | PIPD／Checker |
| `TPMStageBinding` | Role、T0～T5、Source SHA、Stage Contract、Conflict | SBL Product Owner |
| `HandoffCandidate` | PI/PD/ECP Refs、Scope、Dependency、NoEffect／Effect Request | SBL TPM Reader／HGK Receiver |

新增欄位不得悄悄寫進既有 `additionalProperties:false` 的 P4 Schema。

正式做法應是：

- 不改變同版本既有 Schema 的含義；
- 使用有版本的 Extension／Adapter；
- 對必要的原生契約變更進行正式 PIPD Owner 批准；
- 提供舊版至新版的 Migration／Reject／Rollback 規則；
- 禁止未經版本辨識的隱式相容轉換。

### 7.3 不能只修 Fixture 而不修 Semantic Validator

前輪已確認多項 Positive Fixture 不一致。

最小修復必須同時完成：

**Fixture Correction ＋ Semantic Validation ＋ Negative Regression。**

若只把錯誤 Hash 改成一致，卻沒有確認 Validator 真會拒收錯 Hash，將無法防止將來同樣錯誤再次出現。

建議驗證器至少執行：

```text
schema_valid
AND canonical_source_valid
AND subject_identity_equal
AND reference_hash_equal
AND profile_not_downgraded
AND authority_current
AND effect_scope_valid
AND lifecycle_transition_valid
AND checker_independence_valid_if_claimed
AND claim_evidence_sufficient
```

其中 Checker／World Effect 的部分必須由真正擁有該權限的外部系統提供證據，不能僅靠本地字串比較完成。

### 7.4 高自動化與治理的最小相容要求

每個 Skill 都應能清楚回報：

`SUCCESS / REFUSED / BLOCKED_EXTERNAL / NO_FIT / RETRYABLE_DIAGNOSTIC / WAITING_FOR_OWNER / STALE_RECOMPILE_REQUIRED`

但不能讓這些回報覆寫 PIPD 既有的 Canonical Lifecycle State。

Hermes 只消費合法的工作狀態及恢復建議，不直接把 PIPD 的 `HOLD` 視為整個 Mission 失敗。

---

## 八、統一 Plugin 的正式施工計畫

採用八個工程工作包，可依真實依賴並行施工，但不能跳過相應驗收。

| WorkPackage | 工程目標 | 主要工件 | Exit Gate |
|--------|--------|--------|--------|
| WP-00 | 完成來源、套件及授權凍結 | Source／Plugin Inventory、Baseline SHA | 來源與套件身份一致 |
| WP-01 | 修復 P4 自身缺陷 | 八 Skill、Schema、Fixture、Validator 修補 | 全量受影 Semantic Regression PASS |
| WP-02 | 完成 PIPD／SBL 治理相容 | RiskMap、OracleBinding、TPMStageMap | 無未裁決的受影語義衝突 |
| WP-03 | 擴充 TPM 三角色、T0～T5 | Product／Architecture／Program SPEC | 18 StageContracts 正反測完整 |
| WP-04 | 完成統一 Router／Context 收斂 | Progressive Loader、Typed Handoff、ErrorEnvelope | 無必要資料遺失、無重複 Writer |
| WP-05 | 建立真 PIPD Compiler／Host Adapter | MCP／CLI Adapter、Artifact Resolver | 真 Compiler 回讀、失敗拒收正確 |
| WP-06 | 完成插件封裝及遷移 | Portable Plugin、BOM、回滾、Version Manifest | Packager／Schema／安全檢查通過 |
| WP-07 | 完成 Host／產品／高自動化驗收 | Golden Journeys、Host Receipts、Independent Evidence | 適用 Gate 正式通過 |

### 8.1 WP-00：先建立真實的整合基線

本次已確認兩個私人 Plugin 的當前版本及可讀原始套件。

正式施工時，仍應重新驗證：

- 兩套 Plugin 的當前 Release ID、所有原始檔 Hash。
- PIPD-LS-SP Repository 的當前正式版本與可用 Compiler。
- PIPD DOC-00～09 和 SBL DOC-00～13 的精確受審版本。
- 既有 `CR-ORACLE-001`、`CR-DOC04-STATE-MAP`、N14 等衝突。
- P4 Apache-2.0 與 TPM MIT 的授權及第三方資產義務。
- 十冊 PIPD 文件及 SBL 文件是否允許隨私人或公開 Plugin 再散布。
- 現役 Host 的真正安裝、載入和可呼叫權限。

**目前兩套 Plugin 的程式／技能授權不同，且規範文件的散布授權不能僅由 Plugin Manifest 推導。**

即使技術上可將內容打包，正式 Release 仍須核實對應的授權與來源完整性。

### 8.2 WP-01～02：先修 PIPD，再導入 TPM

這是整合中最不能顛倒的順序。

若先將原 P4 八項 Skill 原封不動加入升級 TPM，再以 TPM 對它們執行規劃，只會把已知錯誤帶入新產品。

至少要先解決：

`Cross-Artifact Hash → Subject Join → Profile Risk → Oracle Binding → Assurance Lifecycle`

不受影的 TPM 功能可以並行開發，但不可在有缺陷的 P4 契約上宣告正式 PI/PD Handoff PASS。

### 8.3 WP-03：TPM 三角色的最小完整化

建議以 SBL DOC-04 C13 的三角色、18 個 StageContract 為基準，不重寫 Product Vision。

各角色出口為：

| 角色 | 必須交付的成果 |
|--------|--------|
| Product Manager | JTBD、Persona、FUO、Product SPEC、Acceptance POS／NEG、Value Criteria |
| Systems Engineer | Architecture SPEC、ADR、Ownership Seam、Typed ABI、Risk Decision |
| Technical Program Manager | Program SPEC、Dependency DAG、WorkPackages、Milestone、Stop Events、PI/PD Handoff |

在單一人類 OWNER 下，三角色可以由同一個 TPM Plugin 做不同的規劃視角，但不能因此宣稱它們是三個獨立受聘專家或三個驗收 Principal。

### 8.4 WP-04：最小 Context 與任務恢復

Plugin 需要能夠在不同會話中重新讀取已保存、具有版本身份的適用工件。

但它不應自建一個與 HGK SharedSpine 競爭的持久任務資料庫。

建議採用：

`MissionRef + ArtifactRef + SourceHash + StageState + OpenFirstFail + NextLegalAction`

每次恢復先驗證 Currentness，再繼續受影工作。

這樣可以避免一個規劃 Session 結束後，必須重新閱讀全部 SBL／PIPD／FHS 巨型文件才能知道做到哪裡。

若工作涉及跨程序真正派工，則仍由 Hermes 的 Durable Controller 負責，而不是 TPM Plugin 自行模擬背景執行。

### 8.5 WP-05：Host Adapter 不得直接嵌入秘密與權限

整合 Plugin 可以包含 MCP 工具定義與 Host 連接契約，但不應封入：

- HGK Signer 私鑰；
- Windows Administrator Credential；
- OAuth Access Token；
- Provider API Key；
- Active Runtime DB；
- 私人任務 Checkpoint；
- 不允許發布的原始證據內容。

這些應留在原有受權 Host／Credential Store／Native Owner 域。

Plugin 只保存可公開或可合法讀取的版本、定位與最小必要契約。

### 8.6 WP-06：建議原身份升級 SBL-TPM-SP

由於本次查證 `sbl-tpm-sp` 已是可編輯的 USER／PRIVATE Plugin，因此**優先建議沿用既有 Plugin 身份做版本升級**，而非平行建立一個同名、權責重複的 Plugin。

實務順序：

1. 封存當前 `0.1.1rc1` 套件與 Release Identity。
2. 在隔離工作區合併修復後的技能及受控參考檔。
3. 保留 `sbl-tpm-sp` 作為唯一對使用者公開的插件名稱。
4. 完成 Manifest、Schema、Skill、License、Compatibility 驗證。
5. 建立候選新版本，執行回歸及 Host 測試。
6. 通過後依現有 Plugin 更新權限與流程發布。
7. 如驗收不合格，回復已保存的舊版來源及可用發布版本。

實際版本號應遵守 Plugin 更新系統的版本規則，不能自行假定某個版號已被註冊或成功安裝。

P4 原 Plugin 不宜因 TPM 整合而立即刪除，應先確認是否仍有其他 Consumer 依賴其八項 Skill 與既有路徑。

### 8.7 WP-07：正式 Host 驗收與產品試用

這項驗收至少分三個層面：

| 層面 | 驗收要求 |
|--------|--------|
| Plugin 本身 | 安裝、載入、正確觸發、Non-trigger、卸載 |
| PIPD 編譯 | 真 Schema、真 Semantic Validator、真 Artifact Resolver、可重播負例 |
| 高自動化整合 | 真 Handoff、局部 PARK、無權限效果拒收、合法續工 |

不能把 Plugin 安裝成功，當作 PIPD Compiler 已經完成有效編譯，更不能當作 HGK／Hermes Native Effect 已成立。

---

## 九、完整驗收測試與 Release Gate

### 9.1 必須完成的工程測試

| ID | 測試 | 必要 PASS 條件 |
|--------|--------|--------|
| A01 | Plugin Manifest／Skill 目錄 | 完整合法，路徑無越界 |
| A02 | 既有 P4 正向案例回歸 | Hash／Subject／Receipt 無矛盾 |
| A03 | P4 負例／安全案例 | 不合法輸入拒收，不產生假工件 |
| A04 | 十二軸 → 九軸映射 | 高風險不降級，Loss 明確標記 |
| A05 | Oracle 版本／權責 | 不自行覆寫原 Oracle Writer |
| A06 | TPM 三角色 | 三類 SPEC 分別有可驗證產物 |
| A07 | T0～T5 | 18 StageContracts 完整，待決衝突不被洗白 |
| A08 | QuestionLedger | 來源已知答案不重問 |
| A09 | Quick／Guided／Critical | 風險分級正確，必要 Gate 不被跳過 |
| A10 | PIPD Canonical Compiler | 真 CLI／API、版本、Subject、Hash 一致 |
| A11 | Planned TQAEP | 不需要冒充已存在的 Checker Receipt |
| A12 | Live Acceptance | 真 Checker Principal、Raw、Receipt |
| A13 | EffectClass | READ\_ONLY／DEV／OPS／USER 不共用錯誤授權 |
| A14 | ErrorEnvelope／Resume | 單卡 HOLD 不導致無關工作停工 |
| A15 | Plugin Trigger／Non-trigger | 正確任務觸發，無關任務不誤觸 |
| A16 | Host 資格 | 安裝、載入、Invoke、Deny、Uninstall 真實讀回 |
| A17 | Provider-off | 不靜默替換模型或受權提供者 |
| A18 | License／Security／Secrets | 無未授權來源和敏感資料入包 |
| A19 | Golden Journeys | GJ01、GJ02、GJ03 具體成果 |
| A20 | Version Update／Rollback | 升版、失敗還原、重新資格化 |
| A21 | 使用者規劃 FUO | 真正產生可編輯、可交接的規格 |
| A22 | B1 Native Handoff | 有權 Receiver 真正接受或明確拒收 |

### 9.2 三條 Golden Journeys

SBL DOC-04 C13 已明確規劃三條不同使用者旅程。

| Journey | 使用者成果 | TPM Plugin 應負責的部分 | 需要外部系統的部分 |
|--------|--------|--------|--------|
| GJ01：Greenfield CLI | 從需求建立可安裝、可操作的 CLI | Product／Architecture／Program SPEC、PIPD Handoff | Builder／Host 安裝／功能驗收 |
| GJ02：Brownfield Repair | 對真 Repository 最小修補，先紅後綠 | Currentness、RepairCone、受影 WorkPackage | Codex／Hermes 真施工、回滾 |
| GJ03：Skill／Agent | 真 Skill 安裝、觸發、拒收、卸載 | Host Compatibility、Plugin 規格與交接 | Host Loader、Agent／Skill Runner |

**GJ03 必須分開 Skill 與 Simple Agent 兩種變體驗收。**

一個 Skill 的正向觸發成功，不能替 Simple Agent 的權限、安全及執行測試代簽。

### 9.3 最終發布資格分層

| 等級 | 可宣稱事項 | 禁止宣稱 |
|--------|--------|--------|
| DESIGN READY | 架構與完整規劃契約已形成 | 已安裝、已執行 |
| PACKAGE VALID | 封裝、Schema、靜態檢查已通過 | 真 Compiler 已執行 |
| PLUGIN HOST QUALIFIED | 指定 Host 真安裝、載入、觸發 | 所有 Host 自動合格 |
| PIPD INTEGRATION QUALIFIED | 真 PIPD 工件與語義驗證完成 | HGK／Hermes Native 已完成 |
| SBL TPM FUNCTIONALLY QUALIFIED | 產品／系統／技術規劃 FUO 完成 | 取代 Commander／Checker |
| NATIVE HANDOFF QUALIFIED | 具合法權限的真 Handoff 及獨立證據 | 其它 Native Domains 自動通過 |
| RELEASED | 有權批准的正式版本與 Host 發布 | 未經測試的 Production PASS |

這些是建議用於整合產品管理的驗收階梯，不能直接寫成新的 PIPD DOC-01 Canonical Lifecycle Enum。

### 9.4 官方平台驗證不可省略

根據目前官方 Plugin 開發流程，Plugin 需要經過封裝、相容性檢查、測試；若要公開提交，還需要相應審核與發布程序。\[[Upload and submit your plugin – Plugins](https://developers.openai.com/plugins/deploy/submission?utm_source=chatgpt.com)\]

尤其 ChatGPT、Codex Desktop、CLI／IDE 等執行環境即使能使用同一份 Plugin 套件，仍可能具有不同工具、Hook 和本機程式執行能力。

**同一 Plugin 名稱不保證所有 Host 都有相同 Native 能力。**

---

## 十、整合計畫的主要風險及防護措施

| 風險 | 可能後果 | 防護 |
|--------|--------|--------|
| 直接把兩個 Plugin 內容合併 | Skill 路由衝突、名稱衝突 | 固定名稱空間、Trigger／Non-trigger 回歸 |
| PIPD Schema 直接改欄位 | 既有 Consumer 失效 | 版本化 Extension／Migration |
| 十二軸映射不完整 | 高風險降級 | Owner RiskBinding、Mandatory Veto |
| T0～T5 衝突未解 | TPM Handoff 語義錯誤 | 保留 TStageMap HOLD |
| P4 POS Fixture 仍錯 | False Green、錯誤 Trace | 獨立 Semantic Validator |
| 將 Blueprint 當作真 Runtime | 偽 Native 工件及權限 | 明確 Claim Ceiling |
| 一位 OWNER 被當作所有 Principal | Maker 自驗、錯誤授權 | 真機器 Principal 隔離 |
| 將 PIPD 變成 Scheduler | 第二控制平面、狀態競爭 | WorkState 由 HGK／Hermes 維護 |
| 所有 DOC 全文常駐 Context | 高延遲、語義污染、重複判斷 | Progressive Disclosure |
| 全量 R15 分母變成每輪派工 | Scope 無限擴張 | Applicability 與 WorkOrder 分離 |
| Public Skills 素材直接再發布 | 來源／授權問題 | License、NOTICE、Provenance 核對 |
| 直接覆寫目前 TPM Plugin | 現有工作流回歸 | Release Snapshot、候選版測試、可還原 |
| 將 Host UAT 外推所有平台 | 假完成 | 每 Host、每 Mode 獨立驗收 |
| 新增過多 Adapter | 更高治理負擔 | 先 Native Reuse、再 Thin Adapter |

為防止新的統一 Plugin 反而再次過度工程化，建議採用 FHS r2 已提出的 Minimum-Sufficient Architecture 原則。

只有在現有 Native／薄型 Adapter 無法合法滿足某個具體 FUO，且經實驗證明缺口確實存在時，才考慮新增常駐服務或複雜控制模組。

---

## 十一、最終工程裁決

### 11.1 對「FHS 是否早已包含解法」的正式結論

**已包含大量解法，但並未構成完成修復的證據。**

FHS r2 對權威、Profile、Oracle、Effect、Owner、Scheduler、Host、Evidence 和產品範圍都有明確設計，有些甚至已經具備具體 DTO、DAG、負例和 FirstFail。

因此，不需要全面推翻 FHS，也不需要重新創造一套獨立的 PIPD 治理理論。

但必須處理：

- P4 原有 Fixture 的實際缺陷；
- PIPD 原始規範與 P4 的 ABI 矛盾；
- SBL TPM T0～T5 來源衝突；
- 真 Compiler／Resolver／Checker；
- 跨 Host 載入、版本和權限；
- Plugin 發行與正式產品 UAT。

這些不能只用文件勘誤完成。

### 11.2 對「是否能整合成一套完整可用 SBL-TPM-SP」的正式結論

**可以，而且建議優先沿用目前已存在的 `sbl-tpm-sp` 私人 Plugin 身份，採高保留、受影修復及版本化升級。**

應將其由目前一項薄型需求規劃 Skill，提升為具有三 TPM 規劃角色、完整 T0～T5 工作流、PIPD 八項修復後 Skills、真正 Compiler／Artifact Resolver 接口，以及跨 Host 驗收能力的統一 Plugin。

但這裡的「完整可用」必須明確限定為：

**完整 SBL TPM 規劃與合法 PIPD Handoff 能力。**

不能宣稱 TPM-SP 本身已經變成整個 SBL 三 SP 的完整產品、HGK Issuer、Hermes Executor 或獨立驗收機構。

### 11.3 最終建議採納的工程方案

## `SBL-TPM-SP Unified Plugin Upgrade`

工程決策建議：ADOPT AS REPAIR &amp; INTEGRATION PLAN

---

**保留：**

SBL One Core／Three SP／Six Modules、PIPD Canonical Writer、PIPD 八項生命週期、HGK 唯一 Issuer、Hermes 真 Executor、獨立 Checker、完整產品分母。

**修復：**

P4 Fixture／Schema／Semantic ABI、十二軸 Profile、Oracle、TQAEP、Typed Failure、TPM T0～T5、真 Artifact Resolver。

**整合：**

SBL TPM 主入口、PIPD Lifecycle、薄型 Compiler Adapter、Progressive Disclosure、Host Handoff、Golden Journey。

**正式驗收：**

Plugin Package → Host Effective Load → PIPD Native Compile → TPM Functional FUO → Independent Verification → Authorized Release。

### 11.4 正式建議的 Release 策略

不建議一開始就宣告 `SBL-TPM-SP FULL PRODUCTION`。

應以以下三個實際有用的交付里程碑作為版本候選：

| 里程碑 | 產品能力 | 放行條件 |
|--------|--------|--------|
| M1：TPM Planning Qualified | 完整 Product／Architecture／Program SPEC | 18 StageContracts、FUO、POS/NEG 及 Source Trace |
| M2：PIPD Handoff Qualified | 真 PIPD Compiler／Profile／PI／PD／TQAEP 階段接口 | 受影 Canonical 工件與獨立相容驗證 |
| M3：Unified Plugin Host Qualified | 同一 Plugin 的安裝、調用、拒收、卸載及合法交接 | 實測 Host、Provider-off、Golden Journeys、有效 Release |

M1 可以在 PIPD 正式效果與 Native Host 尚未完成時，有限度提供實用的規劃能力。

M2 才能宣稱真實編譯接口完成。

M3 才是本次要求的完整統一 Plugin 交付目標。

### 11.5 本次報告的執行與確信界線

本輪已直接讀取兩套現有 Plugin 的 Skill 與套件資訊，並交叉分析 FHS、SBL、PIPD 的設計正文及前輪工程證據。

**本輪沒有修改兩套 Plugin、沒有修正 P4 Fixture、沒有建立新 MCP Server、沒有更新私有套件，也沒有執行正式 Host 驗收。**

因此，本次最終狀態是：

`SOURCE_REVIEWED / PLUGIN_INSPECTED / INTEGRATION_FEASIBLE / REPAIR_PLAN_PROPOSED / IMPLEMENTATION_NOT_EXECUTED / RELEASE_NOT_QUALIFIED`

**總結：FHS-MSC 已提供大部分正確的上位修復方向；SBL DOC-00～13 已提供完整 TPM 產品與工程責任；PIPD DOC-00～09 已提供必要的生命週期治理；兩套已安裝 Plugin 也有可以保留與升級的實體基礎。**

目前真正欠缺的，是把這些設計轉化成**契約一致、風險不降級、真正可編譯、跨 Host 可驗證、治理不重複、單一 OWNER 可操作**的產品實作。

**建議採納原身份高保留升級、P4 受影修復、SBL TPM 完整化、薄型原生接口整合的路線，而不是重新建立第三套控制平面或重寫全部上位文件。**

## Prompt:
2026/10/27 下午9:37:08

任務目標：\
你必須整合前述分析規劃，再進行以下項目的專業工程「研究分析 + 交叉比對 + 鑑定評估」：\
"\
1\) 你必須對齊我的原意，我希望之後只要掛載全新可用版的「SBL-TPM-SP」即可，不必再上傳各種DOC，必須把各種DOC都適當融合/整合進「SBL-TPM-SP」。

2\)你前述的全新可用版的「SBL-TPM-SP」規劃&方案，是否逐逐項針對目前「[$pipd-ls-sp-public-skills-p4](app://Plugin_0ff92abe45e081918f19a96a3acda239) &『《PIPD_LS_DOC-00》\~《PIPD_LS_DOC-09》』」  的全部「缺陷、缺口、治理過重、鏈路、高自動化、單人OWNER」進行逐項解決?是否有針對「FHS-MSC B1 Bootstrap Repair 高自動化失效——完整工程根因鑑定與治理收斂評估報告」、《B1指揮施工_總紀錄》、《B1施工_PROMPT》、《B1施工狀況_總鑑定分析》，因為「[$pipd-ls-sp-public-skills-p4](app://Plugin_0ff92abe45e081918f19a96a3acda239) &『《PIPD_LS_DOC-00》\~《PIPD_LS_DOC-09》』」所造成的問題和高自動化阻斷、治理過重風險，進行逐項的解決和防範?
"

任務目標：\
你必須對「「FHS-MSC B1 Bootstrap Repair 高自動化失效——完整工程根因鑑定與治理收斂評估報告」、《B1指揮施工_總紀錄》、《B1施工_PROMPT》、《B1施工狀況_總鑑定分析》」，進行專業工程的「深度研究 + 交叉比對 + 分析評估 + 工程因果關係重建」全部相關資料，進行「研究分析+交叉比對」，再進行鑑定、評估、規劃，並提出完整報告。

最後你必須直接以文字提出完整報告。

## Response:
2026/10/27 下午9:37:38 · gpt-6-thinking

這次我會把「**日後只掛載一套 SBL-TPM-SP，不必重複上傳 DOC**」當成硬性產品需求，而非可選優化。先核對 PIPD 八項技能及原始 DOC 的實際約束，再將前輪的 P4 缺陷與 B1 r1～r10 阻斷逐項映射到新版 Plugin 的具體修復、驗證及防再發機制；最後判定前述方案哪些已覆蓋、哪些尚不足以稱為完整可用版。

交叉比對已確定一項會影響「只裝一套 Plugin」承諾的關鍵前提：目前掛載的 24 冊 PIPD／SBL DOC 可以作為完整內建基線，但部分文件還依賴未一併提供的上位原件、GRP／Profile 和正式 Owner 裁決。因此，新版不能只複製 24 冊正文就宣稱來源權威完全閉合；必須在製作階段處理依賴封存、版本釘選與缺件，讓**後續使用者不用反覆補傳**，同時不把未批准的來源冒充正式 SourceFreeze。

> **準備檔案核查**
>
> 我會先逐一核對工作區內的規範、路由、授權、執行與安心文件，再檢查先前結論是否有漏項，特別是離線封裝、完整文件、自我驗證與實際可執行性的差距。
>
> **完成檔案核查準備**
>
> 
>
> **列出本地檔案並統計Markdown**
>
>
> **檢視PIPD矩陣與插件責任邊界**
>
>
> **核對封裝邊界**
>
> 我會把文件分成已完整嵌入、僅有摘要、仍需建置時取得三類，逐項映射缺陷、驗收測試與降級條件；只有完成來源閉包，離線單插件才可宣稱完整。
>
> **核對封裝邊界**
>
> 
>
> **盤點PIPD文件、規範與B1交付矩陣展開**
>
> 
>
> **整理25項RC證據交叉修復矩陣**
>
>
> **補查版本與來源**
>
> 我也會核對版本漂移、授權與版權、規範來源閉包、歷史文件分層，以及具體缺陷能否由插件修正；無法修正者會明列外部責任與防再發驗收。
>
> **補查版本與來源**
>
> 
>
> **收束驗收方案**
>
> 我會將修正分成插件內可完成、主機或規範所有者負責、以及只能設閘降級三類，補上版本漂移、來源閉包、授權、離線安裝、無文件驗收與完整缺陷追蹤。
>
> **完成驗收方案收束**
>
> 
>
> **整理25項RC證據交叉修復矩陣**
>
> 
>
> 處理時間為 10m 26s

# SBL-TPM-SP 完整自包含升級暨 PIPD／FHS-MSC B1 高自動化阻斷根因閉合工程鑑定報告

鑑定基準：2026 年 10 月 27 日｜範圍：PIPD-LS-SP Public Skills P4、PIPD DOC-00～09、SBL DOC-00～13、FHS-MSC、B1 DOC-00～08、B1 施工與交接紀錄

## 一、最終核心裁決

經整合前述三輪分析、重新核對本次指定的原始文件及 PIPD 八項已安裝 Skill 契約後，工程結論如下。

**第一，你的真正產品需求是「一套安裝後自帶完整知識與治理能力的 SBL-TPM-SP」，而不是「一個仍然要求使用者反覆上傳 PIPD、SBL、FHS 各種 DOC 的工具入口」。**

因此，前輪提出的方案雖然方向正確，但**沒有把「所有必要 DOC 已實質內建、離線可讀、可追溯且不需再次上傳」提升為強制驗收條件**。這是必須補正的產品規格缺口。

**第二，前輪方案並未達到「全部缺陷逐項閉合」的完整程度。**

它已經提出 P4 Schema／Fixture 修復、十二軸風險映射、Oracle 相容、TQAEP 分層、單一 OWNER、Hermes 自治續航與 Native Handoff 等主要方向，但仍缺少：

- 每一個已知缺陷對應的實際修復位置、受影契約及反證測試；
- DOC 全量自包含、離線檢索及來源版本管理的正式實作要求；
- B1 r1～r10 阻斷事件到新版 Plugin 防再發機制的完整映射；
- 單一 OWNER 在 Plugin 層與真正機器權限層的可執行接口；
- 真 Compiler、Host Adapter、Hermes 工作恢復與 Plugin 自身停止控制的分界；
- 可機械執行的完整驗收與發布阻斷條件。

**第三，建議繼續採用既有 SBL-TPM-SP 身份進行高保留整合升級，但應將其目標重新定義為：**

> **SBL-TPM-SP Self-Contained, Source-Bound, Automation-Ready Unified Skills Plugin。**
>
> 一次安裝，完整內建必要規範與參考資料；按需讀取，無須重複上傳基礎 DOC；以已修復的 PIPD 契約產生可信規劃工件；能處理局部阻斷與恢復；支援單一人類 OWNER 的有界自治工作，並保持真正 Native 權限及獨立驗收的分離。

### 總體鑑定

| 核心要求 | 前輪方案 | 本輪修訂後的目標 |
|--------|--------|--------|
| 只安裝一套 SBL-TPM-SP | 部分規劃 | 必須 |
| 不再手動上傳基礎 DOC | 未明確保證 | **P0 強制驗收** |
| DOC 完整實質保留 | 有 Reference 構想 | 完整封存＋結構化索引＋可讀原文 |
| P4 八技能全部缺陷修補 | 有主要修復方向 | 逐缺陷、逐 Fixture、逐接口閉合 |
| PIPD DOC-00～09 治理收斂 | 有 | 逐冊適用性及不變量驗證 |
| B1 所有已知阻斷防再發 | 部分 | 逐根因建立對策與反證 |
| 一位人類 OWNER | 有設計方向 | 正式授權接口與機器 Principal 分離 |
| 高自動化不中途停止 | 有概念 | 持久狀態、局部 PARK、恢復及結案拒收 |
| 不新增第二 Writer／Issuer／Queue | 已要求 | 強制架構驗收 |
| 完整可用版 | 尚未實作 | 需通過工具、產品、Host 與整合驗收 |

**工程裁決：前述方案應保留，但必須升級為一套「自包含知識封裝＋PIPD 契約修復＋SBL TPM 完整化＋B1 根因防再發」的產品級施工規格。**

---

## 二、「只掛載 SBL-TPM-SP，不再上傳 DOC」的正式產品定義

### 2.1 這項要求在技術上可行

本輪實際核對目前已掛載的文件：

| 文件組 | 份數 | 原始 UTF-8 大小 |
|--------|--------|--------|
| PIPD\_LS\_DOC-00～09 | 10 | 約 4.04 MB |
| SBL\_PIPD-LS-PKG\_DOC-00～13 | 14 | 約 17.47 MB |
| FHS-MSC 藍圖 r2／總討論 | 2 | 約 1.60 MB |
| B1 DOC-00～08 | 9 | 約 1.50 MB |
| B1 指揮、Prompt、鑑定、交接四份核心紀錄 | 4 | 約 1.05 MB |

總計 **39 份 Markdown，約 25.67 MB 原始內容**。

這個規模適合建立版本化、可離線檢索的規範與歷史參考封裝；但不適合把全部內容每次都放入模型 Context。

因此，應採用 **Physical Full Retention + Logical Progressive Disclosure**：

**實體完整保留，執行時只讀取與當前任務相關的最小充分內容。**

### 2.2 必須實現的四個保證

**A. 自包含性**

PIPD DOC-00～09 與 SBL DOC-00～13 的必要正文、正式欄位定義、規範約束、Schema、Oracle／Fixture 及來源身份，必須實際存在於升級版 Plugin 可讀取的封裝或其正式隨附資源內。

不能只有檔名、摘要、網頁 URL、歷史對話引用或 Source SHA。

**B. 無重複上傳**

首次安裝並載入經驗證的 Plugin 後，使用者不需要為了取得已封裝的 PIPD／SBL／FHS 基礎規範，再手動上傳同一批 DOC。

**C. 按需檢索**

Plugin 必須能根據任務、版本、章節、Requirement ID、權威、Oracle 與依賴關係，自動找到正確內容。

若找不到，應回報具體來源缺口，而不是要求使用者把全部 DOC 再傳一次。

**D. 真值與版本不混淆**

內建的文件代表某個已驗證版本的來源快照，不代表外部 GitHub Repository、Windows Host、HGK Policy 或 PIPD Native Compiler 的現役狀態。

封裝中的歷史設計可以成為合法參考，但不能因為已經打包就自動取得 SourceFreeze Ratification、Owner Approval 或 Native Effect 權限。

### 2.3 不再上傳 DOC，不等於永遠不需要外部輸入

此處必須精確劃清產品承諾：

**可以做到：** 不再上傳已內建的基礎規範、設計正文及歷史控制文件。

**不能無條件保證：** 在沒有接入目標 Repository、Host、即時 Policy、私有來源或使用者新需求的情況下，自動得知所有現役環境事實。

例如，新專案的原始碼、尚未封裝的新版私有設計、新核准的 SourceFreeze、Host 凭證及即時運行收據，仍需由受授權的工具連接、使用者提供，或依原生流程取得。

這是**資料取得與現役權威的限制**，不是再要求重複上傳基礎 DOC。

---

## 三、新版 Plugin 必須如何完整融合所有 DOC？

### 3.1 不能只做摘要、索引或檔名對照

前輪規劃中的 `references/pipd-doc00-09/`、`references/sbl-doc00-13/` 是正確方向，但仍不足以保證符合你的原意。

**正式要求應改為：每份必要 DOC 都必須具備可供離線還原與檢索的完整實質內容，並有可機械核對的來源身份。**

建議採用四層知識封裝。

| 層級 | 內容 | 必須具備的能力 |
|--------|--------|--------|
| K0：原文保存層 | 完整、未經擅自改寫的正式 DOC 快照 | 原始位元、版本、SHA-256、行號、可還原 |
| K1：規範索引層 | Requirement、Oracle、Schema、Gate、SourceRef、Owner | 按 ID／章節／版本精確定位 |
| K2：整合契約層 | 經核准的跨 DOC 映射、衝突裁決、適用性規則 | 不遺失原義、不創造第二權威 |
| K3：執行消費層 | TPM Skills、PIPD Adapter、Validator、Handoff | 按任務只載入必要契約 |

**K0 必須保留原文；K2 才允許產生融合後的規範投影。**

不能直接把所有 DOC 改寫成一份總結，然後刪除原始條款。否則未來出現 Oracle、Profile 或 Claim 衝突時，將無法再以原始來源重建合法判斷。

### 3.2 DOC 內建的完整範圍

建議產品封裝採兩類來源。

**A 類：正式產品運行必需**

- PIPD\_LS\_DOC-00～09：十冊完整生命週期規範。
- SBL\_PIPD-LS-PKG\_DOC-00～13：十四冊完整產品與專用 SP 規範。
- P4 八項 Skills 的 SkillContract、Input/Output Schema、Examples、Fixtures、Test Cases，以及修復後的正式版本。
- 兩套來源規範所需的 Schema Registry、Canonical Ownership、Claim／State 定義與適用性規則。
- 已合法批准、受影適用的 Profile／Oracle／StageMap／權威衝突裁決。

**B 類：工程歷史及防再發知識**

- 《FHS-MSC\_藍圖\_r2》
- 《FHS-MSC\_總討論》
- B1 DOC-00～08
- 《B1指揮施工\_總紀錄》
- 《B1施工\_PROMPT》
- 《B1施工狀況\_總鑑定分析》
- 《FHS\_MSC\_B1\_Task\_Handoff\_Report\_v1\_2026-10-27》
- 前輪工程鑑定中已被證實且尚未納入上述來源的差異、缺陷與回歸案例。

A 類作為正式規範的受控 Reader；B 類作為工程失效案例、兼容性回歸與診斷資料。

**B 類不能因被封裝，就提升為 PIPD 或 SBL 的上位 Canonical Writer。**

### 3.3 必須處理上位來源缺件

目前的 39 份資料雖然已掛載，但並不等於整個來源權威閉合。

文件本身仍引用部分本輪沒有獨立取得的原件，包括某些版本的 PIPD Blueprint／Canonical Standard／Skeleton、Portable Mount Profile、GRP 系列與 SBL Master／設計卷來源。

這些原件有的在既有文件中具備 SHA 或片段，有的只有歷史轉述，不能一律視為已完整具備。

因此建造新版 Plugin 時，需要建立 **Transitive Source Closure**：

```text
Required DOC
  → Normative Dependencies
  → Exact Version / SHA
  → Available Full Text?
  → Authority / Supersession
  → Conflict / Ratification
  → Included and Verified
```

對於原件缺失或尚待 Owner 裁決者：

- 能合法取得的，在**建置階段一次性取得並封裝**；
- 無法取得的，登記具名缺口，不能用模型推測重建正式來源；
- 已有合法的完整規範投影但原件不在場，必須標明其限定法位；
- 不把未解衝突的候選裁決寫成正式 Canonical 真值。

**只有完成 A 類必要來源的依賴閉合，才可以對指定版本宣稱「不再需要上傳基礎 DOC」。**

這項工作應由建置流程或已授權來源連接完成，不應留給每次使用 SBL-TPM-SP 的使用者重新處理。

### 3.4 自包含不等於 Context 常駐

目前 39 份來源合計約 25.67 MB。若全部轉成 Prompt，將造成不必要的 Context 負擔，還可能把歷史失效做法重新當成有效規範。

因此建議提供以下資料讀取機制：

`Task Router → Authority Resolver → Applicable Document Index → Exact Clause Reader → Version/Hash Validator → Typed Contract`

一般產品需求只讀 SBL TPM 所需來源。

需要 PIPD PI 時才讀 PI、Profile、Source、Oracle 等契約。

需要 Host Effect 時才調用合法的 ECP／Native Admission Adapter。

**不需要重新上傳，也不需要每輪全文塞入 Context。**

可優先使用確定性的 ID／章節／全文索引檢索；語義檢索只能輔助定位，不能代替來源權威及精確條款。

實際封裝格式可以採 Markdown 原文、壓縮資料或預建索引，但必須經指定 Host 驗證所有必要內容確實能由 Plugin 本身讀取。若某個 Host 無法存取隨附資源，該 Host 不得宣稱已通過自包含驗收。

### 3.5 DOC 更新、修訂與衝突處理

新版 SBL-TPM-SP 必須具備：

- `SourceManifest`：精確原件身份、版本、內容摘要、來源法位。
- `SupersessionMap`：哪個版本合法取代哪個版本。
- `ConflictRegistry`：尚未裁決的 Oracle、StageMap、Authority 等衝突。
- `AffectedDependencyIndex`：來源變更影響哪些 Requirement、Skill、Schema、Fixture。
- `RequalificationLedger`：只重驗受影項目，不每次全文重編。
- `CorpusIntegritySelfTest`：安裝後可驗證內建 DOC 是否完整。

這一套 Source Registry 應由原有 PIPD／SBL 權威提供正式身份，Plugin 僅保存並驗證，不得自行聲稱已完成正式 SourceFreeze。

### 3.6 必須加入的「零 DOC 上傳」驗收

建立一個全新、沒有掛載任何 DOC 的乾淨對話／Host 環境，只安裝升級版 SBL-TPM-SP。

接著測試：

1. 查詢 PIPD DOC-05 的 ExecutionAdmission 與 ECP 權限分離，須能給出原文版本和精確章節。
2. 查詢 PIPD DOC-06 十二軸風險模型及安全 Veto，須能找到完整依據。
3. 查詢 SBL DOC-04 C13 三角色和 T0～T5 衝突，須正確顯示尚未裁決的部分。
4. 查詢 B1 的 27 Atoms、31 WO/OBS 與三張 GWO，須能區分正式義務和歷史候選。
5. 請 Plugin 對一項新需求產生 TPM 規劃與適用的 PIPD 工件候選，不得要求重新上傳已內建的 DOC。
6. 模擬某項內建文件損壞，須拒絕依該受影來源進行正式編譯，不能回退到模型記憶補造內容。
7. 模擬版本更新，須驗證精確受影重算及舊版身份追溯。

**任何一項因「找不到已宣稱內建的 DOC」而要求使用者重新上傳，均判定 `SELF_CONTAINED_CORPUS_FAIL`。**

---

## 四、前輪 PIPD 修復方案是否已做到逐項閉合？

**尚未。前輪提出的是正確的修復方向和工作包，不是完整的 Defect-to-Fix-to-Test 閉合矩陣。**

以下列出本次重新核對後必須納入新版 Plugin 的 PIPD 問題及具體修復。

### 4.1 P4 工具缺陷逐項修復矩陣

| ID | 已知缺陷或風險 | 新版必須修復的內容 | 防再發驗收 |
|--------|--------|--------|--------|
| P4-01 | `pi-compile` POS Atom Hash 與 Trace Hash 不一致 | 修正 Fixture、增加 Cross-object Hash Join Validator | 同 ID 錯 Hash 正例不得 PASS |
| P4-02 | `execution-contract` 正例跨 PD Subject | 綁定輸入 PD 與 ConstructionContract Subject | Subject 不同即拒收 |
| P4-03 | `assurance-tqaep` Checker Receipt 不一致 | Receipt Identity／Operation Join | 跨 Receipt 必 FAIL |
| P4-04 | `package-project` Graph Edge 來源不清 | 由真 Artifact Graph 重算 Closure，不依輸入邊數猜測 | Orphan／錯 Hash／錯 Edge 不得 PASS |
| P4-05 | PI／ECP 等輸入只有 ID/Hash，輸出需要完整語義 | 增加有權、具 Currentness 的 Artifact Resolver | 不可解析時具體 HOLD |
| P4-06 | DOC-06 十二軸風險與 P4 九軸不等價 | 有來源的 RiskMapping、Mandatory Veto、Loss Check | 不能以軸數造成高風險降級 |
| P4-07 | Oracle 固定 `DOC-03 DOMAIN_ORACLES` 與 DOC-07 權責存在衝突 | 合法 OracleBinding／Legacy ABI Adapter | 真 Writer／Reader 身份正確 |
| P4-08 | TQAEP 計畫即要求 Checker Execution Receipt | Planned／Executed／Independent Acceptance 分離 | 計畫不會產生假 PASS |
| P4-09 | ECP `residue_scan`、Rollback、Retry 過於固定 | 區分 Repo ECP 與 Host／User Effect Adapter | 各 EffectClass 專屬 POS/NEG |
| P4-10 | `maker != checker` 字串不能證明獨立 | 驗證有效 Principal、權限隔離及真 Receipt | 同權限冒名 Checker 必拒 |
| P4-11 | Source Family Code 可能被誤當權威證據 | 綁定實際 Source Registry、Digest、批准來源 | 偽造 Family 名稱不能提升權威 |
| P4-12 | Profile Provider-off 事實可在輸入省略 | 由現役 Policy／RiskBinding 明確決定 | 必須啟用的防護不可因缺欄省略 |
| P4-13 | 各 Skill 缺統一 Typed Failure Envelope | 增加 FirstFail、受影範圍、合法下一動作、Resume Predicate | 局部 HOLD 不使所有工作停工 |
| P4-14 | Schema-valid 不等於 Semantic-valid | 獨立 Semantic Conformance Gate | 格式正確但語義錯誤仍拒收 |
| P4-15 | Claim Ladder、Lifecycle、Mission Status 可能混用 | 明確三種狀態及合法轉移 | Package PASS 不觸發 Mission Complete |
| P4-16 | P4 Skills 文字契約可能被當作真 Compiler | Native Compiler Capability／Version／Execution Readback | Skill 存在不等於編譯成功 |
| P4-17 | 原生源文件可能缺失或過期 | Self-contained Source Registry＋Currentness | 不自行推定 SourceFreeze |
| P4-18 | 官方 Plugin Validator／Portal 資格未完成 | 真封裝、Validator、Host／安全驗收 | 不用 Local Packager PASS 代替正式通過 |

### 4.2 PIPD DOC-00～09 治理收斂矩陣

| DOC | 需要保留 | 需要修補或收斂 |
|--------|--------|--------|
| DOC-00 | Router、最小合法入口、法位 | 已有受權 WorkOrder 不重跑全部 Lifecycle |
| DOC-01 | 單一 Canonical Lifecycle、權責及 Claim Separation | 不將生命週期狀態當 Hermes 工作狀態 |
| DOC-02 | PI、Atom、Acceptance、TechnologyAdmission | 五類 P4 Requirement 與原專案原子無損映射 |
| DOC-03 | Repo-bound PD、真 Currentness、Construction Handoff | 不把 RepoContext 強加給唯讀及非 Repo Host Effects |
| DOC-04 | Trace、Evidence、Identity | 以真 Artifact Resolver 驗證跨工件 Hash |
| DOC-05 | ExecutionAdmission、Effect、Permission、Readback | 有界 Bootstrap 准入、局部適用性、無效效果拒收 |
| DOC-06 | LITE／STANDARD／ASSURED、十二軸風險、安全 Veto | 十二軸至 P4 九軸的正式映射及避免全域升級 |
| DOC-07 | Oracle／Fixture／獨立 Conformance | Canonical Oracle Writer 與 P4 Legacy Locator 相容 |
| DOC-08 | Progressive Disclosure、Two-Phase Reader、Adapter Maturity | 不再每輪載入全部 DOC；以 A/B 測量 Context 成本 |
| DOC-09 | CI、Supply Chain、Release、Evidence Integrity | CI PASS 不等於 Native PASS；封存不控制 Hermes 結案 |

### 4.3 一項需要明確訂正的判斷

「治理過重」不能只以文件多、測試多、驗證嚴格來判斷。

應分三類：

- **必要安全治理：** Source Authority、真 Permission、Native Issuer、World Readback、Independent Checker，應保留。
- **不必要的治理重複：** 每輪全量 SourceFreeze、對無關工作重跑 Gate、對普通唯讀操作要求 Native Permit，應刪除重複要求。
- **工具契約缺陷：** 錯 Hash、錯 Subject、風險映射缺失、TQAEP 階段混用，不是單純減少治理就能解決，必須修程式與 Schema。

只有三類分開處理，才能降低成本而不導致 False PASS 或越權。

---

## 五、B1 r1～r10 的失效因果關係：新版 Plugin 應防止什麼？

### 5.1 最主要的因果鏈

四份核心紀錄顯示，B1 不是因單一 PIPD Gate 無法通過才停止。

從 Codex r1～r6 到 Hermes r7～r10，失效機制逐步演變：

**第一階段：上游 PIPD 與產包問題**

Oracle、Profile、SourceFreeze、TaskKind、正式編譯依賴不完全閉合；B1 設計分母和正式驗收 Gate 同時出現

**第二階段：施工指揮與工作依賴問題**

部分 Native HOLD 被擴大成一般工程 HOLD；反覆補寫 Prompt，但缺少一致、可執行的工作狀態及合法恢復規則

**第三階段：真實 Runtime 尚未閉合**

Hermes SharedSpine 與 Scheduler 有局部測試成果，但 Receiver／Executor／Fabric／模型／Checker 的完整 Native Loop 未通過

**第四階段：提前交付與停止**

r10 已有局部修補成果，但 Fabric R3、模型 R4、真 Hermes Executor 仍為 NOT\_RUN；報告及封存完成後任務停止，Native Handoff 保持 HOLD

最重要的因果關係是：

**PIPD 工具不相容及治理投影錯置增加阻斷；B1 執行控制缺陷將阻斷放大；Hermes 持久續航不完整使工作無法自動繞過可局部處理的障礙。**

這是多個必要條件串聯的失效，而非能把全部責任歸給 PIPD。

### 5.2 最新 B1 狀態不能誤判

根據《FHS\_MSC\_B1\_Task\_Handoff\_Report\_v1\_2026-10-27》§0、§2、§4.4：

| 項目 | r10 記錄 |
|--------|--------|
| 全體 B1 | `PARTIAL_WITH_EXPLICIT_HOLDS` |
| Native PASS | 0 |
| T1 SharedSpine 基礎 | PASS，沿用 r9 |
| T2／G-A／三 GWO／G-B | 未達正式驗收 |
| Hermes 真 Executor | NOT\_RUN |
| Fabric R3 | NOT\_RUN |
| 三模型 R4 | NOT\_RUN |
| HGK User Trust | 局部測試通過，Receiver 尚未完成接線 |
| PIPD Stage-C | 有真實 WriteSet CI 失敗 |
| 完整 Handoff | HOLD |

其中 R3、R4、真 Executor 的 **NOT\_RUN**，不應改寫成「已實測失敗」；反過來，也不能把未測試的狀態當成 PASS。

**新版 Plugin 必須強制保留這種證據分類，並將「未執行」視為可排程工作，而非預設永久阻斷或宣告完成。**

---

## 六、B1 已知 25 類根因的逐項防再發矩陣

以下將前輪已識別的 RC-01～RC-25 全部映射到新版 SBL-TPM-SP 的防護機制。

標註三種責任：

- **P：Plugin 可以直接修復或防止。**
- **I：Plugin 必須提供正確接口，但正式閉合需與其他系統整合。**
- **N：主要屬於外部 Native Runtime，Plugin 不能自行修復；只能防止錯誤宣稱並提供有效 Handoff。**

### 6.1 自治續航、Bootstrap 與權限鏈路

| ID | 原始根因 | 類別 | 新版 SBL-TPM-SP 必須建立的防範與驗收 |
|--------|--------|--------|--------|
| RC-01 | Hermes 真 Executor／持久續航未成立 | I/N | 提供 Typed WorkOrder、Resume Predicate、Executor Capability Probe；必須由真 Hermes 執行跨程序恢復測試 |
| RC-02 | READY 工作未耗盡卻提前結案 | I/N | 將 Package Closure 與 Mission Completion 分離；READY＞0 時真 Runtime 必拒絕結案 |
| RC-03 | 一個 Native HOLD 擴張成全局停工 | P/I | 以 Affected Dependency Graph 計算受影工作；阻斷 A 不影響獨立 B/C |
| RC-04 | Bootstrap 需要尚未修復的 Native Admission | P/I | Read-only、Repo Repair、Native Effect 三類合法准入分開；真正 Repo 寫入仍須有效 ExecutionAdmission |
| RC-05 | HGK User Trust 沒接入現役 Receiver | N | TPM 輸出具名整合工作卡，不冒稱 Admission；真 Receiver 正反測驗收 |
| RC-06 | Maker／Signer／Checker 分權未證實 | P/I/N | 提供 Principal、Credential、Scope、Checker Requirement；由原生 Host 驗證真正隔離 |
| RC-07 | B1 設計候選被當成 Runtime 合約 | P | 對每份工件標示 `DESIGN／CANDIDATE／BOUND／ADMITTED／EXECUTED／VERIFIED`，禁止跨級升格 |
| RC-08 | 缺乏局部 PARK 與獨立工作依賴 | P/I | Typed Dependency DAG、FirstFail、Resume Predicate；負例驗證無關卡仍可排程 |

**裁決：RC-03、RC-07 和部分 RC-08 可以由新版 Plugin 直接大幅改善。RC-01、RC-02、RC-05、RC-06 的正式完成仍取決於 Hermes／HGK 真實程式與權限。**

任何聲稱「只安裝新版 TPM-SP 就能修好現役 Hermes Executor」的方案，都不符合目前證據。

### 6.2 PIPD、Fabric、模型與產品接口

| ID | 原始根因 | 類別 | 修復與驗收 |
|--------|--------|--------|--------|
| RC-09 | Fabric Stage／Active／Loaded／Consumer 尚缺真收據 | I/N | 產出分別的 EvidenceExpectation；真 Fabric Adapter 回傳 Loaded／Consumer Raw |
| RC-10 | 三模型 Lane 的 Required／Served 尚未實測 | I/N | 建立真 Provider/Model/Method Identity；不得以配置 Pin 替代 Served Receipt |
| RC-11 | P4 Oracle／DOC-07 ABI 未正式相容 | **P** | 修正 Canonical OracleBinding、Legacy Resolver、真負例 |
| RC-12 | PIPD 十二軸／P4 九軸無損映射未證實 | **P** | RiskMapping、Loss Check、Safety Veto；不可映射必 HOLD |
| RC-13 | TQAEP 設計與獨立 Live Acceptance 混用 | **P** | Planned／Executed／Independent 三態及分離接口 |
| RC-14 | PIPD Stage-C WriteSet CI 失敗 | I | 真 Repo 差異分析與最小修補；不得為了 CI 綠燈直接放寬 Allowlist |
| RC-15 | B1 DOC-08 Commander Proposal 入口與禁用規則衝突 | P/I | 提供合法非 Commander Handoff 候選；沒有現役 ABI 時明示 `NO_ADMITTED_ROUTE` |
| RC-16 | ECP Effect Retry 與普通工程迭代混淆 | **P** | 分開 Diagnostic Attempt、Repair Iteration、Effect Attempt，未知效果先 Reconcile |
| RC-17 | R15 大型產品分母被當作當輪工作清單 | **P** | Full Obligation Ledger 與 Applicable Work DAG 分離；Deferred／Conditional 不靜默刪除 |
| RC-18 | 假定 SourceFreeze／TaskKind／Oracle 發行端必然存在 | **P** | Capability Discovery、真 AuthorityBinding；找不到端點即有型別 HOLD，不造假 |

RC-11、RC-12、RC-13、RC-16、RC-17、RC-18 是新版 Plugin 應直接承擔的主要修復項。

RC-09、RC-10、RC-14、RC-15 則需要正式系統接線，Plugin 必須準確界定自身職責，避免以候選交接代替真實效果。

### 6.3 證據、封存、權限及狀態分類

| ID | 原始根因 | 類別 | 修復與驗收 |
|--------|--------|--------|--------|
| RC-19 | Repo Patch／PR／CI／Host Loaded／World Effect 被互相代用 | **P** | Claim Separation；每種證據綁不同 Effect／Reader，不允許跨類升格 |
| RC-20 | Manifest／Seal 曾發生 SHA 不一致 | P/I | Immutable Snapshot、External Seal、位元重算；中期 Checkpoint 不觸發最終結案 |
| RC-21 | Context 過大、反覆重讀、缺最小恢復狀態 | **P** | 全量內建 DOC、Progressive Disclosure、Versioned Task Context、Resume Snapshot |
| RC-22 | Windows Administrator 被過度泛化為普通施工要求 | P/I | Permission Classifier；User-scoped／Repo Scope／受保護 OS Scope 分離 |
| RC-23 | Mandatory Tool 已安裝被誤當實際調用 | P/I | `SELECTED／INSTALLED／BOUND／INVOKED／VERIFIED` 狀態與現役 Policy Method Set |
| RC-24 | `NOT_RUN`／`FAIL`／`NO_FIT`／`HOLD` 混用 | **P** | 統一 Typed Status＋FirstFail；不可跨狀態冒用 |
| RC-25 | Native Issuer／Checker／GWO 真實原始收據不齊 | I/N | 同 Subject／Operation／Epoch 的 Raw Reference、Checker Receipt 要求；缺件不得放行 |

### 6.4 對 25 項根因的總結

| 責任分類 | 新版 Plugin 可以達到的結果 |
|--------|--------|
| P：直接責任 | 修正文件消費、PIPD ABI、狀態、風險、Scope、依賴、證據與任務交接缺陷 |
| I：接口責任 | 輸出有型別的合法請求，與現有 PIPD／HGK／Hermes／Fabric／SBL 相容 |
| N：Native 責任 | 由現役外部系統實作、授權、執行、讀回與獨立驗收 |

**重要結論：新版 Plugin 能逐項提供預防或解決途徑，但不等於可以單靠自身把所有 25 個 B1 Native 根因實際修復完成。**

這必須寫入正式產品責任邊界，否則未來又會重演「設計包已完成，所以 Native 任務應已完成」的錯誤。

---

## 七、從 B1 施工失敗反推新版 Plugin 的強制運行規則

### 7.1 不得再建立全域治理閘門

只有真正存在依賴的工作，才應受到某個 Gate 拒收的影響。

例如：

- Oracle Ratification 未完成：受影 PI／Assurance Promotion HOLD。
- Fabric Loaded 未完成：Fabric 相關正式驗收 HOLD。
- RepoContext 缺失：需要寫入該 Repository 的工作 HOLD。
- 非相關的唯讀勘查、SPEC 修訂、獨立測試準備：依其自身合法條件繼續。

這是 FHS-MSC 藍圖 r2 已提出、但 B1 後續施工沒有充分落地的原則。

### 7.2 必須有明確的自動恢復契約

每一個阻斷都必須具備：

`first_fail / affected_scope / legal_next_action / resume_predicate / required_evidence / external_owner_if_needed`

例如：

```yaml
first_fail: ORACLE_BINDING_CONFLICT
affected_scope: PI_ATOMS_REFERENCING_CONFLICTED_ORACLE
effect_status: NO_NATIVE_EFFECT
legal_next_action: READ_ONLY_RECONCILIATION
resume_predicate: VALID_OWNER_ORACLE_DECISION_AND_CURRENT_SOURCE
other_ready_work: CONTINUE
mission_complete: false
```

這是建議的新版 Typed Failure 規格示意，不是目前 P4 已存在的原生輸出 Schema。

### 7.3 禁止文件封存控制 Mission 結束

正式規則：

`DOCUMENT_SEALED ≠ WORKORDER_COMPLETE ≠ MISSION_COMPLETE ≠ NATIVE_ACCEPTED`

SBL-TPM-SP 可以完成一份規劃、PI Candidate 或受控交接包，卻不能因此通知 Hermes 整個 Mission 已完成。

如果仍有合法 READY 工作，由 Hermes 真 Durable Controller 繼續執行。

如果只剩具證據的外部阻斷，可以暫停當前執行週期，但必須保留可恢復狀態。

### 7.4 不得用單一 OWNER 文本冒充 OS 權限

新的 SBL-TPM-SP 可以讀取或建立合法的 Standing Authorization Request，但不能自行發出 HGK Native Permit。

單一人類 OWNER 授權應映射到真正受保護的機器 Principal、Issuer、Receiver 與 Checker。

不存在相應 Host 權限時，只允許合法的讀取、規劃與候選施工準備。

### 7.5 不再以更多 Prompt 代替 Runtime

B1 r1～r10 已有足夠反證：文字中反覆要求「不中途停工」，不能保證真正的長任務持久執行。

新版 Plugin 必須給 Hermes 能機械消費的 Handoff 與 Resume 契約。

**跨程序 Worker、排程、Lease、Heartbeat、Crash Recovery 和 Mission Terminal Gate，仍必須由 HGK／Hermes 的真 Runtime 負責實作及驗收。**

---

## 八、修訂後的完整 SBL-TPM-SP 產品架構

### 8.1 單一安裝體驗、完整內建資料、權責分離

建議的架構如下：

```text
SBL-TPM-SP Unified Plugin
│
├── 1. Product & Task Router
│   ├── Quick / Guided / Critical
│   ├── Product / System / Program
│   └── Current Task Applicability
│
├── 2. Self-Contained Knowledge Corpus
│   ├── PIPD DOC-00..09 FULL TEXT
│   ├── SBL DOC-00..13 FULL TEXT
│   ├── FHS Blueprint / Discussion
│   ├── B1 Controls / Failure Regression
│   ├── Source & Supersession Manifest
│   └── Exact Clause / Oracle / Gate Index
│
├── 3. SBL TPM Core
│   ├── Goal / JTBD / FUO
│   ├── Product SPEC
│   ├── Architecture SPEC / ADR
│   ├── Program SPEC / Dependency DAG
│   ├── QuestionLedger
│   └── T0..T5 Stage Contracts
│
├── 4. Repaired PIPD Skills
│   ├── Route Intake
│   ├── Authority Source
│   ├── Profile Tailor
│   ├── PI Compile
│   ├── PD Bind
│   ├── Execution Contract
│   ├── Assurance TQAEP
│   └── Package Project
│
├── 5. Governance & Semantic Bridge
│   ├── Artifact Resolver
│   ├── 12-to-9 Risk Mapping
│   ├── Oracle Binding
│   ├── Identity / Hash / Trace Validator
│   ├── EffectClass Applicability
│   ├── Typed Error & Resume
│   └── Claim / Lifecycle Separation
│
├── 6. Tool & Host Adapters
│   ├── Offline Planning
│   ├── PIPD Canonical Compiler
│   ├── RepoContext Reader
│   ├── HGK Native Handoff
│   ├── Fabric / SBL Readback
│   └── Hermes WorkOrder Consumer
│
└── 7. Self-Test / Evidence / Release
    ├── Corpus Integrity
    ├── P4 POS / NEG / EDGE / SEC
    ├── B1 Failure Regression
    ├── TPM Golden Journeys
    ├── Host Install / Invoke / Uninstall
    └── Version / Rollback / Qualification
```

**Plugin 內部可以包含多項 Skills 與 Reference，但對使用者只要求安裝這一套 SBL-TPM-SP。**

### 8.2 不得繼續依賴另一個已安裝的 P4 Plugin

這是前輪整合方案必須強化的重點。

如果新版 SBL-TPM-SP 在執行時仍要求：

「請先另外安裝 `pipd-ls-sp-public-skills-p4`，否則找不到八項 Skill。」

就沒有達到你的單一 Plugin 要求。

因此正式可用版必須：

- 將合法可再分發、已修復的八項 P4 技能及相關契約實質納入 SBL-TPM-SP；
- 將所有內部相對路徑與工具引用指向自身封裝；
- 在沒有另外安裝舊 P4 Plugin 的環境中完成驗收；
- 保留 PIPD Canonical Owner 與原始來源身份；
- 不能把 Plugin 內複製的 Schema 當作第二份可獨立變更的 Canonical 標準。

對於真正的 PIPD Compiler，須依可用的 Host 技術提供合法執行方式：例如由隨附的可驗證本地執行元件，或由同一 Plugin 宣告的受授權工具接口調用現有 Compiler。

如果指定 Host 不支援執行這類工具，也沒有獲得有效連線授權，便只能提供 Planning／Candidate 能力，不能宣稱正式 Native Compile 已完成。

### 8.3 修正現有 TPM Plugin 的版本一致性

前輪直接讀到的現有 `sbl-tpm-sp` 套件中：

- 根目錄 `plugin.json` 的版本是 `0.1.1rc1`；
- `.codex-plugin/plugin.json` 的版本則是 `1.0.0`。

不同 Manifest 的版本欄位可能具有不同用途，但若下游會用它們辨識同一 Release，便存在版本語義混淆風險。

新版必須定義：

`Product Version / Portable Manifest Version / Host Adapter Version / Source Corpus Version / Compiler ABI Version`

並以版本相容表連接，不能讓使用者或工具誤以為不同 Host 上已載入相同的實作。

### 8.4 知識完整與工具可用必須分層保證

| 能力 | 只安裝一套 Plugin 後應達成 | 是否需要外部即時權限 |
|--------|--------|--------|
| 查詢內建 PIPD／SBL DOC | 必須完整支援 | 不需要 |
| 原文定位與來源追溯 | 必須完整支援 | 不需要 |
| Product／Architecture／Program 規劃 | 必須完整支援 | 通常不需要 |
| P4 Schema／靜態語義驗證 | 必須有可用實作 | 視 Host 執行環境 |
| 新專案 Repo-bound PD | 必須提供合法接口 | 需要新 RepoContext |
| HGK Native Permit | 不能自行創造 | 需要真 Issuer |
| Fabric Policy Loaded | 不能由文件推斷 | 需要真 Fabric／Host |
| Hermes 真跨程序 Executor | 不能由 Plugin 文字代替 | 需要真 Runtime |
| 獨立 Checker Receipt | 不能自簽 | 需要有效 Checker |

這種分層可以滿足「一套 Plugin」的安裝與規劃體驗，同時避免再次出現錯誤的權限和完成度宣稱。

---

## 九、單一 OWNER 與高自動化的完整產品要求

### 9.1 只保留一位人類 OWNER

新版 SBL-TPM-SP 應原生支持：

`ONE_HUMAN_OWNER + VERSIONED_STANDING_AUTHORIZATION + SEPARATE_MACHINE_PRINCIPALS`

這與《FHS-MSC\_藍圖\_r2》§6.1、§12.2 的既有規劃一致。

在已核准的有界範圍內：

- 不重複詢問已經具有來源答案的問題；
- 不對同一個有效授權反覆要求批准；
- 普通有界診斷、規劃、合法工程修補可持續進行；
- 新的重大效果、受保護 OS 操作或超出授權的範圍仍需有效權限。

這不是取消人類批准，而是讓一次有效批准可以被機器精確、持續地執行。

### 9.2 不應要求多位人類模擬技術分權

TPM 的 Product Manager、Systems Engineer、Technical Program Manager 是三種規劃職能。

HGK Signer、Hermes Worker、Independent Checker 則是不同的技術責任與權限身份。

前者可以在同一個 Plugin 中實作；後者是否具有真正獨立 Principal，必須由現役 Host 證明。

**三個模型角色、三個 Skill 名稱或三個 PID，不等於三個獨立機器 Principal。**

### 9.3 最小持久任務交接契約

新版 TPM-SP 的高自動化 Handoff 應包含：

```yaml
mission_ref: VERSIONED_MISSION_ID
workorder_ref: TYPED_WORKORDER_ID
subject_ref: EXACT_SUBJECT_AND_HASH
source_ref: CANONICAL_SOURCE_VERSION
effect_class: OBS_OR_DEV_OR_OPS_OR_USER
prerequisites: EXACT_DEPENDENCY_IDS
admission_ref: VALID_ADMISSION_OR_NOT_APPLICABLE
first_fail: NONE_OR_CANONICAL_CODE
recoverability: REPAIRABLE_OR_EXTERNAL_OR_NOFIT
resume_predicate: MACHINE_CHECKABLE_CONDITION
expected_evidence: TYPED_RAW_EXPECTATION
checker_requirement: APPLICABLE_INDEPENDENCE
claim_ceiling: EVIDENCED_LEVEL_ONLY
```

這些欄位應由受權工具產生或驗證，不能靠人工自由填字串取得正式權限。

當真 Hermes Runtime 不在場時，交付的是可驗證的 Handoff Candidate，而不是已派工成功的 ACK。

### 9.4 必須防止自主修復變成無限制施工

「高自動化」不等於「無期限、無作用域、無證據地自行修改四個 Repository」。

合理的 FAR／Repair 循環應是：

`Probe → FirstFail → Smallest Legal Repair → POS/NEG → Readback → Requalification → Next Applicable Work`

其邊界由既有 Standing Authorization、Scope、成本、時間、Change Budget、權限及 StopLoss 決定。

對真實效果進行未知狀態的重試前，必須先 Reconcile；不可為達成自動化率而盲目重播。

### 9.5 新版不能依賴 Commander-SP

B1 的現行控制要求明確禁用 `sbl-commander-sp` 作為施工入口。

新版 TPM-SP 應能獨立完成自己的規劃與合法 PIPD Handoff。

若特定 Native WorkOrder 需要產品 Proposal，應由現役有權 Receiver 支援的合法非 Commander 入口接收；不存在時，提供正式接口缺口，不得透過暗中呼叫 Commander-SP 迴避禁令。

這項要求適用於 B1 整合模式，不表示 SBL 上位產品架構中的 Commander-SP 職責可以被永久刪除或由 TPM-SP 直接取代。

---

## 十、修訂後的完整施工工作包

為避免重新產生一套龐大、難以實際施工的治理專案，建議將全部修復收斂到以下九個工作包，並以真實依賴決定執行順序。

| 工作包 | 任務 | 強制交付物 | 驗收出口 |
|--------|--------|--------|--------|
| WP-00 | 完整來源封裝及缺件閉合 | Full Corpus、SourceManifest、Authority／Supersession Index | 必要原件完整、可追溯 |
| WP-01 | P4 八項 Skill 修復 | 修訂 Skill／Schema／Fixture／Semantic Validator | 已知 P4 缺陷全部回歸通過 |
| WP-02 | PIPD DOC-00～09 契約收斂 | RiskMapping、OracleBinding、TQAEP 分層、ErrorEnvelope | 無未揭露的受影 ABI 衝突 |
| WP-03 | SBL TPM 產品完整化 | 三角色、18 StageContracts、SPEC／ADR／DAG | TPM Golden Journey 規劃測試 |
| WP-04 | DOC 自包含檢索與 Context 收斂 | Offline Corpus Reader、索引、按需載入 | 零 DOC 上傳測試通過 |
| WP-05 | 單一 OWNER 與高自動化 Handoff | Standing Grant Adapter、EffectClass、Resume Contract | 局部 PARK、權限不越界 |
| WP-06 | 真 PIPD Compiler／Host 接口 | Versioned Compiler Adapter、Repo／Native Readback | 真 Compiler／受影 Host 測試 |
| WP-07 | 單一 Plugin 整合封裝 | 新版 SBL-TPM-SP、BOM、License、Migration、Rollback | 只安裝一套即可完成基礎功能 |
| WP-08 | 全量回歸及正式發行 | P4 Regression、B1 RCA Tests、Golden Journeys、Release Receipts | 有權驗收後發布 |

### 10.1 正確施工順序

第一階段應以 **WP-00、WP-01** 為共同基礎；WP-03 中不依賴 PIPD 編譯的 TPM 規劃能力可並行實作。

第二階段完成 WP-02、WP-04 與 WP-05，建立完整來源消費、合法編譯路由及恢復接口。

第三階段完成 WP-06、WP-07，形成真正可安裝的統一 Plugin。

第四階段執行 WP-08，以實際 Host 和產品 FUO 驗證，而非再以設計文件自我驗收。

**所有工作包必須有明確的受影依賴，不能因某個外部 Native Gate 尚未通過，就停止其它合法獨立工作。**

### 10.2 哪些問題必須在正式發布前解決？

以下列為 P0 Release Blockers：

- 必要內建 DOC 缺失、無法讀取或內容摘要不一致。
- P4 正向 Fixture 存在已知的 Wrong Hash、Wrong Subject、Wrong Receipt。
- Profile／Oracle／TQAEP 的受影語義衝突未被有效裁決或隔離。
- Plug-in 在乾淨環境下仍要求另裝舊 P4 或重新上傳既有 DOC。
- 主要 TPM 角色或 18 StageContracts 無法產出合法、可驗證的工作成果。
- Claim Ceiling、ExecutionAdmission、Independent Verdict 有假成功路徑。
- 將 Plugin 已安裝冒稱 Compiler 已執行。
- 將文件封裝完成冒稱 Hermes 任務或 B1 Native Acceptance 已完成。
- 將單一 OWNER 自然語言授權冒充 OS Credential、HGK Permit 或獨立 Checker。
- 沒有可驗證的版本遷移和回滾路徑。

**其中某些外部 Native 能力尚不可用，不必阻止先發行明確限定範圍的 Planning Qualified 版本；但必須阻止宣稱已達到更高的 Native Integrated／Production 資格。**

---

## 十一、正式驗收方案

### 11.1 第一組：單一 Plugin、自包含 DOC

| 測試 ID | 測試情境 | 必須得到的結果 |
|--------|--------|--------|
| ZD-01 | 全新 Host，只安裝新版 SBL-TPM-SP | 不依賴舊 P4 Plugin |
| ZD-02 | 不上傳任何 PIPD／SBL DOC | 能讀到已內建的全部適用 DOC |
| ZD-03 | 指定 DOC／版本／章節查詢 | 回傳正確來源定位 |
| ZD-04 | 指定原始 Requirement／Oracle | 可追溯至原始條款與有效權威 |
| ZD-05 | 模擬文件受損 | 有型別拒收，不靠模型補造 |
| ZD-06 | 模擬受影版本更新 | 只使相關依賴失效 |
| ZD-07 | 同時安裝舊 P4 | 不得觸發技能混用或 ABI 污染 |
| ZD-08 | 移除舊 P4，只留新版 TPM | 所有承諾的內建功能仍可使用 |

**ZD-01、ZD-02、ZD-08 是你的單一 Plugin 需求的必要驗收條件。**

### 11.2 第二組：PIPD 工具完整修復

| 測試 ID | 測試情境 | 必須得到的結果 |
|--------|--------|--------|
| PV-01 | PI Atom Hash 被篡改 | 拒絕 Trace Join |
| PV-02 | ECP 指向錯 PD | 拒絕 Contract |
| PV-03 | Checker Receipt 指向錯操作 | 拒絕 Independent PASS |
| PV-04 | Graph Edge／Orphan 不一致 | 拒絕 Trace Closure |
| PV-05 | 高風險十二軸輸入 | 不會被九軸投影降級 |
| PV-06 | Oracle Writer／Locator 衝突 | 合法 HOLD／Owner Resolution |
| PV-07 | TQAEP 只有測試計畫 | 不需要假 Checker Receipt |
| PV-08 | 真 Live Checker | 驗證有效 Principal／Raw／Receipt |
| PV-09 | Read-only 工作 | 不要求不適用的 Mutation Permit |
| PV-10 | Unknown Effect | 先讀回，不盲目重播 |
| PV-11 | Source Family 名稱冒用 | 不提升正式 Authority |
| PV-12 | 原生 Compiler 不可用 | 明確 Candidate／NO\_RUNTIME，不生成假工件 |

### 11.3 第三組：B1 高自動化阻斷防再發

| 測試 ID | 注入的故障 | 正確行為 |
|--------|--------|--------|
| BA-01 | PIPD SourceFreeze 未成立 | 只 PARK 真正受影的正式編譯工作 |
| BA-02 | Oracle Ratification 不完整 | 其它合法 READY 工作繼續 |
| BA-03 | HGK Native Issuer 不可用 | Host Effect 阻斷；唯讀與合法工程工作繼續 |
| BA-04 | Fabric Stage 已完成但未 Loaded | 不宣告 Fabric PASS |
| BA-05 | Required Model 與 Served Model 不符 | R4 拒收，不暗換模型 |
| BA-06 | Repository Test Green 但 Host 未載入 | 不提升 Host Acceptance |
| BA-07 | Context 結束／報告已封存 | 不使持久 READY 任務消失 |
| BA-08 | 工作 A 阻斷，工作 B/C 獨立 | B/C 仍可派工 |
| BA-09 | Maker 和 Checker 共享可變驗證權限 | 不允許獨立 PASS |
| BA-10 | Windows Administrator 不可用 | 非特權工作不被無故停止 |
| BA-11 | 缺少 Mandatory Method 真調用 | 受影 WorkOrder 拒收 |
| BA-12 | 受影條目為 NOT\_RUN | 保持未執行，不轉成 FAIL/PASS |
| BA-13 | 三張 GWO 共用同一 Receipt | 拒絕跨 WorkOrder 證據借用 |
| BA-14 | 外援 Token 撤銷後仍試圖重入 | 真 Receiver 必拒收 |
| BA-15 | Plugin Package 成功但 Native Gate 未通 | 不宣告 B1 完工 |

其中 BA-07、BA-08 必須在真正的 Hermes／HGK Runtime 執行環境中測試，不能僅靠 Plugin 模擬結果。

### 11.4 第四組：TPM 真使用者成果

新版 Plugin 不應只測試 Schema。

還必須通過 SBL 上位設計的三條 Golden Journeys：

| Journey | 必須證明的 TPM 能力 |
|--------|--------|
| GJ01：Greenfield CLI | 從目標產生具 FUO、Product SPEC、Architecture SPEC、Program SPEC 及 POS/NEG 的施工規劃 |
| GJ02：Brownfield Repair | 對真 RepoContext 找出最小修復工作、現役 Currentness、依賴和合法交接 |
| GJ03：Skill／Agent | 產生可安裝、可測試、可卸載的 Skill／Agent 規劃，並能與真 Host 驗收對接 |

三條旅程都必須能在沒有重新上傳已內建規範 DOC 的情況下，取得適用的 SBL／PIPD 原始條款。

若目標 Repository 或新產品需求沒有提供，則只要求真正缺少的新專案資料，不得要求使用者重傳既有基礎文件。

---

## 十二、版本、發布與長期維護

### 12.1 建議沿用現有 SBL-TPM-SP 身份

根據前輪對已安裝私人 Plugin 的直接查核：

- `sbl-tpm-sp`：當時版本 `0.1.1rc1`。
- `pipd-ls-sp-public-skills-p4`：當時版本 `0.1.1`。

兩者均有可讀的套件來源。

**建議以既有 SBL-TPM-SP 作為升級目標，將已修復的 P4 能力納入其正式 Release，而不是再建立第三套公開使用者入口。**

但不能在取得有效更新權限之前，擅自修改或宣稱已發布。

### 12.2 必須保存原始版本與可回復能力

新版 Release 應具有：

`Plugin Version + Corpus Version + PIPD ABI Version + TPM StageMap Version + Compiler Adapter Version + Host Qualification Matrix`

任何影響 Canonical Semantics 的更新，必須重新驗證受影 Schema、Fixture 和 Consumer。

任何內建 DOC 的改版，都必須保存完整來源身份和合法取代關係。

如果新版 Plugin 失敗，應可回復前一個已知正常的 Plugin Release；但不能藉回滾繼續使用已撤銷的 Permit 或過期 Credential。

### 12.3 不要把每次文件更新變成整套 Plugin 的巨大改版

可以將 Corpus／Index／Schema／Skill 作為具版本的內部組件，但仍由一個 Plugin Release 統一交付。

對不影響 Canonical 契約的內容修訂，採取 Affected-only Regression。

對正式權威或 ABI 變更，執行相應完整相容驗證。

這樣既能保持一次安裝的產品體驗，也不會每次更新一個段落，就必須重新執行所有 Golden WorkOrders。

### 12.4 自包含承諾的實際限制

還有兩項必須由正式工程驗證的限制：

**封裝大小及資源讀取：** 目前約 25.67 MB 的歷史與規範來源，在技術上可以設計成單一封裝，但不能在尚未執行指定 Host 的實際封裝、安裝及讀取測試前，保證所有 Host 都接受該大小與格式。

**來源授權及正式權威：** 使用者擁有檔案不必然表示任意第三方內容都可重新公開散布；同樣，將文件內建也不代表其全部 SourceFreeze、Owner Approval 已完成。

這兩項必須在正式 Release Gate 處理，不能留成安裝後要使用者自行排除的問題。

---

## 十三、最終工程鑑定與決策

### 13.1 對第一項任務的回答

**你的原意已可轉換成明確、可驗收的產品需求：**

> 未來只需要安裝、掛載並啟用新版 SBL-TPM-SP，即應能完整使用其所承諾的 PIPD／SBL 規範知識、TPM 工作流、內建八項 P4 技能、來源查證、風險治理和合法交接功能，無須再次上傳已內建的各種 DOC。

這不只是方便性要求，而是本產品的核心功能。

**建議正式定名為：`SELF_CONTAINED_CORPUS_REQUIRED`，並列為 P0 不可省略的發布條件。**

### 13.2 對第二項任務的回答

**前輪方案並沒有完全做到逐項解決及防範。**

前輪的方向正確，但仍存在自包含封裝、來源依賴閉合、P4 Semantic Validator、具體 B1 根因回歸、跨系統權限和 Host 實效等未完整落地的缺口。

本輪已將其收斂為：

- PIPD P4 的 **18 類具名缺陷／風險**；
- PIPD DOC-00～09 的逐冊治理收斂要求；
- B1 的 **25 類既有根因**及其 Plugin／Integration／Native 責任；
- 自包含 DOC 的四層知識架構；
- 9 個可施工工作包；
- 零 DOC 上傳、PIPD 修復、B1 防再發、TPM Golden Journeys 的正式驗收規格。

但這些目前仍是**修復與防再發的完整規格方案**，不是 18＋25 項已完成實作的證據。

### 13.3 最後必須維持的工程邊界

| 可以由新版 SBL-TPM-SP 完整負責 | 仍須外部真系統完成 |
|--------|--------|
| DOC 完整內建及離線查閱 | 新專案即時 Repository／Host 事實 |
| TPM 三角色與完整規劃工作流 | 真產品原始碼施工 |
| 已修復的 P4 Skills／Schema／Fixture | 受權 PIPD Native Compiler 執行（除非已合法隨附並於 Host 驗證） |
| Profile、Oracle、TQAEP、Effect 適用性規劃 | 正式 Owner／Native Ratification |
| Typed Handoff、FirstFail、Resume Predicate | Hermes 真跨程序 Executor／Scheduler |
| 來源與 Claim 一致性驗證 | HGK Signer／Receiver／Permit |
| B1 Root Cause 回歸與防錯誤宣稱 | Fabric／模型／SBL 實際世界效果 |
| 正式驗收需求與證據檢查 | 真 Independent Checker 與有權 Release |

這個分界不會破壞單一 Plugin 的使用者體驗。它只是要求 Plugin 不能假裝取代自己沒有權限或沒有部署的 Native 系統。

### 13.4 最終建議採納的正式升級路線

## SBL-TPM-SP Self-Contained Unified Upgrade

最終工程建議：ADOPT AS TARGET PRODUCT CONTRACT

---

**一套 Plugin**

整合 SBL TPM 三角色、PIPD 八技能、正式規範、語義驗證、來源索引及合法 Host Handoff。

**完整 DOC 內建**

保留必要全文及受權版本，安裝後不再要求重傳基礎文件。

**治理收斂**

依 EffectClass、Profile、受影依賴、Owner Policy，保留必要 Gate，消除無效的全域 HOLD。

**高自動化防再發**

Typed Failure、局部 PARK、合法下一步、持久 Resume 交接、禁止封存冒充 Mission 完成。

**嚴格產品驗收**

乾淨環境單 Plugin 測試、P4 全量 Semantic Regression、TPM 三 Golden Journeys、真 Host／Native 權責驗證。

### 最終結論

**完整新版 SBL-TPM-SP 的成功標準，應從「是否整合很多 Skills 和 DOC」，改為「是否只需要安裝一套 Plugin，就能在不重傳基礎 DOC 的情況下，正確、有效率且可驗證地完成產品／系統／技術規劃及合法工程交接」。**

FHS-MSC 已提供大部分高自動化與治理收斂的設計原意；SBL DOC-00～13 提供完整 TPM 產品架構；PIPD DOC-00～09 提供生命週期規範。但 P4 的實際缺陷、跨工件一致性、正式 Compiler／Host 接線及 B1 的持久自治問題，仍須分別實作與驗收。

**建議正式採納本輪修訂後的方案，作為新版 SBL-TPM-SP 的產品需求基準、修復範圍與不可降級驗收控制。**

本次作業完成的是來源研究、交叉鑑定、因果重建與完整升級規劃；**尚未修改既有 Plugin、完成 Native 修復或宣告新版正式發布**。

## Prompt:
2026/10/27 下午9:59:21

任務目標：
你必須整合前述分析規劃，再進行以下項目的專業工程「研究分析 + 交叉比對 + 鑑定評估」：
"
1) 完整新版 SBL-TPM-SP，是否適合先用HERMES/HGK先做第一版，然後在本地CODEX進行最終「掛載實跑檢測、治理/鏈路/高自動化實測、自修補、自迭代、自驗收、自交付」?或是全部直接在CODEX裡實作+檢測+驗收更高效率?因為PIPD-LS的修補有大量文字讀取，更適合CODEX來執行?

2) 目前對於完整新版 SBL-TPM-SP的規劃，是否依然保有整合導入「OPENSPEC、MATT SKILLS、GSTACK....」等等現有可用的外界開源工具?避免重複自造/設計輪子?
"

任務要求：
你必須針對任務目標，並對 全部相關資料進行「研究分析+交叉比對+深度推理」，再進行鑑定、評估、規劃，並提出完整報告。

## Response:
2026/10/27 下午9:59:37 · gpt-6-thinking

我會先從既有 SBL／FHS-MSC／PIPD 文件核對 OpenSpec、Matt Skills、gstack 的原定角色與限制，再查證這些外部工具的現行能力。接著比較「Hermes/HGK 先施工、Codex 最終驗收」與「Codex 全程主導」的實際工程成本、權限邊界及失效風險，提出分工、施工順序與可驗證的完成條件。

文件中的外部工具政策已可確認：**OpenSpec、Matt Skills、gstack 並未被上位設計排除。** 但採用方式不同：OpenSpec 主要是受控的 Spec／Delta 轉譯；Matt Skills 可選擇性重用需求訪談、TDD、診斷及 Review 方法；gstack 在 PIPD DOC-08 中多數維持 Reference／Evaluation 身份，不能直接取得正式執行或驗收權限。另有關鍵實務差異：gstack 官方目前將 **Codex 支援標為 experimental、Hermes 標為 instruction-only**，因此不宜直接假設兩端的所有 gstack 工作流都已可原生使用。

> **檢查本地資料檔案清單**
>
>
> **檢查本地資料檔案清單**
>
> 
>
> **已搜尋 8 個網站**
>
> 
>
> **掃描文件標題與工具提及**
>
>
> **掃描文件並檢視FHS與SBL整合流程**
>
> 
>
> **擷取 SBL 文件選擇與能力依賴細節**
>
>
> **擷取 SBL 文件選擇與能力依賴細節**
>
> 
>
> **已搜尋 1 個網站**
>
> 
>
> **檢視B1交接報告與施工藍圖**
>
>
> **檢視B1文件並制定驗證策略**
>
> 
>
> 處理時間為 6m 32s

# SBL-TPM-SP 全新可用版：施工主導平台選型與外部開源工具整合工程鑑定報告

鑑定基準：2026 年 10 月 27 日｜對象：本地 Codex、Hermes／HG-KSEOS、PIPD-LS-SP、SBL-TPM-SP、OpenSpec、Matt Pocock Skills、gstack 及既有 SBL／FHS-MSC／B1 控制文件

## 一、總體工程裁決

**建議採用「Codex 主導第一版實作與大量 DOC／PIPD 修補，Hermes／HGK 負責真正的 Native 自治整合，Codex 執行隔離交叉審查，最終由獨立驗收機制決定是否放行」的混合方案。**

不建議目前先由 Hermes／HGK 承擔整套 SBL-TPM-SP 的第一版主要開發，再把大量尚未驗證的工件交給 Codex 收尾；也不建議把全部工作，包括 HGK Native Admission、Hermes 跨程序續航及獨立驗收，都交給同一個 Codex Session 自行完成與簽核。

理由在於，**新版 SBL-TPM-SP 的主要工程工作，與 FHS-MSC B1 的 Native Bootstrap 修復，不是同一類任務。**

前者以大量文件讀取、跨規範比對、Schema／Fixture 修復、確定性程式、Plugin 封裝及本地回歸測試為主。這類工作比較適合先由具備真實本地檔案、Repository、測試及隔離 Worktree 能力的 Codex 主導。

後者則必須證明 HGK Issuer、Hermes Executor、Durable Queue、Policy、模型 Served、跨程序自動恢復及 Independent Checker 真正有效。Codex 可以修程式與進行診斷，但不能取代這些原生系統的有效操作身份。

### 1.1 兩項任務的直接回答

| 問題 | 工程裁決 |
|--------|--------|
| Hermes／HGK 先做第一版，Codex 最後驗收？ | 技術上可行，但**不是目前首選** |
| 全部交給 Codex 實作、檢測、驗收？ | 對規格與程式修復效率可能較高，但**不能由 Codex 自行完成全部正式 Native 驗收** |
| 大量 PIPD DOC 讀取是否更適合 Codex？ | **建議優先使用 Codex 的本地檔案及增量分析工作流**，但不能認定模型本身天然讀得更準 |
| 最適合的完整方案？ | **Codex 主施工 → 原生 HGK／Hermes 整合實測 → 隔離 Codex 審查 → 真獨立驗收與交付** |
| OpenSpec、Matt Skills、gstack 是否仍應保留？ | **必須保留其既有規劃位置和可用的整合能力** |
| 是否要把三套外部工具全部強制安裝？ | 不應；依具體能力選擇 Native Reuse／Thin Adapter／Reference |
| 是否仍維持只掛載一套 SBL-TPM-SP？ | **是，這是最終產品的強制需求**，外部工具不可成為未揭露的額外安裝前置 |

### 1.2 最重要的新發現

經直接對照來源，可以確認：**既有 SBL／FHS-MSC／PIPD 設計不但沒有遺漏外部開源工具，反而已經對這些工具建立相當具體的能力及准入規格。**

尤其：

- SBL DOC-06 C32 已明確規劃 **6 個 Donor、24 個核心能力槽位**。
- OpenSpec 對應 OS-01～04。
- Matt Pocock Skills 對應 MP-01～04。
- gstack 對應 GT-01～04。
- 另外還有 Spec Kit、Superpowers、GSD。
- PIPD DOC-08 已對 OpenSpec、Matt Skills、gstack 建立不同層級的 TechnologyAdmission／Reference／Evaluation 路線。
- FHS-MSC 藍圖 r2 明確要求優先重用 Hermes Kanban、PIPD Compiler、Codex、GitHub CI 與既有開源工具，反對新增第二個 Scheduler、Writer 或大型治理平台。

因此，**問題不是原設計沒有規劃開源工具，而是新版 SBL-TPM-SP 必須將這些既有規劃真正整合成可用、可選、可驗證、可移除的能力。**

---

## 二、為何本次不建議 Hermes／HGK 先完成第一版？

### 2.1 先前 B1 的實際經驗

《FHS\_MSC\_B1\_Task\_Handoff\_Report\_v1\_2026-10-27》記錄：

- r10 整體仍為 `PARTIAL_WITH_EXPLICIT_HOLDS`。
- Native 逐項 PASS 為 0。
- Hermes SharedSpine 已有局部持久化與派工原語成果。
- 真 Hermes Executor、Fabric R3、模型 R4 在 r10 尚未執行。
- HGK User Trust 有局部測試成果，但 Receiver 接線尚未完成。
- Hermes 曾在尚有工作未完成時進入報告封存和會話停止。

這些結果不能證明 Hermes 沒有程式開發能力，但足以說明：**目前不適合把尚未正式驗證的長任務自治機制，當成製作新版 Plugin 的唯一施工基礎。**

若先把龐大的 PIPD DOC 修補、跨冊映射與 Fixture 修正全部交由 Hermes 長期自主處理，可能再次遇到：

`工作量龐大 → 部分完成 → Native HOLD → Context／Task State 不完整 → 先封存 → 未完成工作遺失`

這正是新版產品需要避免的失效模式。

### 2.2 Codex 更適合的部分

本次研究所涉及的主要工件，包括：

- PIPD DOC-00～09，約 4 MB。
- SBL DOC-00～13，約 17 MB。
- FHS-MSC、B1 設計與施工資料。
- P4 八項 Skills 及其 Schema、Fixture。
- 既有 SBL-TPM-SP 的封裝內容。

合計 39 份已掛載 Markdown，約 25.7 MB；另外還有真 Repository 原始碼、測試及封裝工件。

這類工作真正需要的是：

1. 大檔案分段讀取與索引。
2. 精確行號、來源版本和 SHA 核對。
3. 結構化差異比對。
4. Schema／Semantic Validator 開發。
5. 測試失敗重現與最小修補。
6. 同一 Repository 中持續的 Red→Patch→Green。
7. Worktree 隔離、CI 與版本控制。

Codex CLI 的非互動模式 `codex exec` 可用於腳本和 CI，並具有受限 Sandbox 及輸出整合能力；其目前公開文件亦建議以最小必要權限執行，寫入則使用 `workspace-write`，而非預設給予不受限全機權限。\[[Non-interactive mode](https://learn.chatgpt.com/docs/non-interactive-mode?utm_source=chatgpt.com)\]

這些能力適合本次大量契約與程式修補。

但仍有一點必須強調：**Codex 不會因為是 Codex，就能一次把所有 25.7 MB 文件無誤地放進模型 Context。**

高效率來自確定性的全文索引、分批定位、局部 Diff、測試與可恢復工作記錄，而不是把大量資料一次送進模型。

### 2.3 Hermes／HGK 不應退出工程

Hermes／HGK 仍是正式整合的重要執行環境。

尤其對以下項目，應由實際原生系統驗證：

- Hermes Worker 是否真的可接收合法任務。
- Queue／Lease／Checkpoint 是否跨 OS Process 生效。
- 是否能在 Session 結束後自行續工。
- HGK Issuer／Receiver 能否正確 Admit／NACK。
- 外援授權撤銷後，Native WorkOrder 是否仍能合法自主執行。
- 對非法 Effect 是否於執行前拒收。
- 真實執行結果是否產生可驗證的 Raw／Checker Receipt。

因此，Codex 應負責把需要的程式和契約準備到可以實測的程度，再交由受權原生系統完成效果驗證。

---

## 三、三種施工方案的比較

### 3.1 架構及工程風險比較

| 評估面向 | A：Hermes/HGK 先做，Codex 收尾 | B：Codex 全程實作及自驗 | C：Codex 主施工＋Native 整合驗收 |
|--------|--------|--------|--------|
| 大量 DOC 調查 | 可行，但目前自治續航未充分證實 | 適合本地索引與精確修補 | **適合** |
| P4 Schema／Fixture 修復 | 可行 | **適合** | **適合** |
| PIPD 確定性 Compiler 修復 | 可行 | **適合** | **適合** |
| 跨 Repository 程式整合 | 需處理 Worker／權限穩定性 | Worktree、Diff、測試較容易控制 | **分工較清楚** |
| Hermes 真自治驗證 | 可直接進行，但可能與施工阻斷耦合 | 不可由 Codex 模擬代替 | **由真 Hermes 驗證** |
| HGK Permit／Signer | 真 Native 才能確認 | Codex 不能自簽正式權限 | **由真 HGK 驗證** |
| Plugin 封裝／離線 DOC 檢索 | 可行 | **適合** | **適合** |
| 單一 OWNER | 可以，但需有效 Grant | 可以，但 Codex 不能自行取得 OS 權限 | **可與真機器 Principal 分權** |
| 自動迭代能力 | 受目前 Runtime 狀態限制 | 適合有界 Red→Green | **工程迭代與自治續航分離** |
| 獨立驗收 | 仍需另外的 Checker | 同一 Codex 自評不能正式放行 | **獨立 Checker／CI／Native Readback** |
| 目前證據支持程度 | 存在 B1 未完成風險 | 工具能力成立，但不等於全部 Native 能力 | **最符合現有證據** |

**首選 C。**

這項評估是根據現有能力、歷史失效及工程依賴作出的判斷，不是已完成三種方案的同條件效能測試，因此不能宣稱 C 已被量測證明快多少百分比。

### 3.2 什麼情況下才改選 A？

如果本地 Hermes 已經重新取得完整的：

`Durable WorkState → 真 Executor → Restart Resume → Independent Readback`

且可以在不依賴當前待修 PIPD Gate 的合法工作範圍內，穩定處理大量文件和 Repository 任務，則 Hermes-first 可以成為合理候選。

但目前 B1 r10 的證據尚未滿足這個前提。

因此，不建議為了先用 Hermes 開發新版 Plugin，而先重構整個 Hermes Runtime。這會讓一個以 PIPD／SBL 修復為主的產品工程，重新被 HGK Native Bootstrap 工作綁住。

### 3.3 什麼情況下可以大部分採用 B？

在以下範圍內，可以實質採用 Codex-only 施工工作流：

- Corpus 索引與完整 DOC 封裝。
- Source／Hash／Supersession 靜態驗證。
- P4 Positive Fixture 修正。
- Schema／Semantic Validator。
- PIPD Profile／Oracle／TQAEP Adapter。
- TPM 三角色、T0～T5 契約。
- Plugin Manifest／Skill Router／Regression。
- CLI 層與可用本機 Host 的安裝測試。

但 **Codex 完成上述工程，仍不等於 HGK／Hermes Native Acceptance**。

最終測試中凡是要求不同安全 Principal、受保護 OS Token、外部世界效果、真 Checker 或獨立發布批准，都不能由施工 Codex 直接自行宣告通過。

### 3.4 「自修補、自迭代、自驗收、自交付」的合法定義

| 能力 | Codex 可做什麼 | 最終界線 |
|--------|--------|--------|
| 自修補 | 依 FirstFail 修正受影原始碼／Schema／Fixture | 精確 WriteSet、合法授權 |
| 自迭代 | 連續重現、修補、單元測試、回歸 | 不盲目重試未知效果 |
| 自測試 | 自動執行 POS／NEG／EDGE／SEC 與 CI | 自測成功不等於獨立驗收 |
| 自審查 | 使用隔離 Worktree／獨立 Context 檢視 Diff | 審查模式不同不等於獨立 Principal |
| 自驗收準備 | 完成 Evidence Index、Raw、Claim Ceiling | 正式獨立裁決需有效 Checker |
| 自交付 | 產出 ZIP、Manifest、BOM、安裝包與 Release Candidate | 正式 Release／外部發布仍按權限批准 |

**最終自動化目標應是「無須反覆人工操作，但不偽造安全權限與獨立驗收」。**

---

## 四、建議的實際施工分工

### 4.1 Codex 擔任主要建置者

建議由本地 Codex 主導以下工作包：

| 工作包 | Codex 主要責任 | 預期產物 |
|--------|--------|--------|
| C0：Baseline | 掃描 DOC、Skill、Repo、來源依賴 | Corpus Manifest、Diff、Risk Ledger |
| C1：P4 修復 | 修正 Hash／Subject／Receipt／Graph Fixture | 修復後八技能及回歸 |
| C2：治理收斂 | 十二軸／九軸、Oracle、TQAEP、EffectClass | 正式 Adapter Candidate |
| C3：TPM 完整化 | Product／Systems／Program、18 StageContracts | TPM Skills／Typed SPEC |
| C4：自包含插件 | 封入全文 DOC、索引、Reader、Version | 離線單 Plugin 候選 |
| C5：工具重用 | OpenSpec／Matt／gstack 選擇性 Adapter | Donor Compatibility Matrix |
| C6：封裝與測試 | Package Build、離線驗證、Host QA | Plugin Candidate／Test Receipts |
| C7：受影修復 | CI／Test FirstFail，最小 Patch | 受影完整回歸與候選封存 |

Codex 應以**具名 WorkPackage、精確 Input、預期 Output、測試及完成條件**執行，不應只接受一份含數百項要求的自由文字 Prompt。

### 4.2 Hermes／HGK 擔任原生整合及自治運行者

正式加入以下測試：

| 工作包 | Native 主要責任 | 驗收 |
|--------|--------|--------|
| H1：Worker Capability | 確認 Hermes 真 Executor | 真執行入口 |
| H2：Durability | Queue／Lease／Checkpoint／Restart | 跨程序恢復 |
| H3：Authorization | HGK Issuer／Receiver／Scope | POS／NEG Admission |
| H4：Effect Routing | Repo／Host／User Effect | 無越權、可讀回 |
| H5：SoD | Signer／Maker／Checker | 真權限隔離 |
| H6：Handoff | Codex 外援退出、Native 接管 | 真合法 Successor |

其中，H1～H6 不應全部阻擋 C0～C6 的正常程式及設計工作。

只有真正依賴原生權限的測試項目才須 PARK。

### 4.3 Codex 最後仍應回場，但不作唯一驗收者

在 Hermes／HGK 完成真 Native 測試後，建議由一個新的、隔離的 Codex 審查 Context：

- 以凍結的 Source／Candidate SHA 重新核對交接。
- 重新執行 P4 的破壞性測試與 Regression。
- 檢查 Hermes／HGK 原始收據的 Subject／Operation／Epoch。
- 對照原來的 B1 失效案例。
- 檢查 Manifest／Release ZIP 是否真的包含所有 DOC。
- 對 Candidate 產出受影修補建議或驗收準備報告。

若發現可修復問題，退回受限 Builder 迭代；修好後應由有效驗證器重新執行。

**Codex 的第二輪審查應被視為隔離交叉審查，不得只因更換 Session 就稱為正式獨立 Checker PASS。**

---

## 五、OpenSpec、Matt Skills、gstack 是否仍在新版規劃內？

**答案：在，而且必須明確保留。**

這不是本輪臨時新增的建議，而是既有上位規格已確立的技術方向。

### 5.1 SBL DOC-06 已定義完整 Donor 架構

《SBL\_PIPD-LS-PKG\_DOC-06》C32 對六個方法 Donor 設定了 24 個核心能力槽位。

| 外部工具 | 能力槽位 | 原規劃用途 | 新版 SBL-TPM-SP 的處置 |
|--------|--------|--------|--------|
| OpenSpec | OS-01～04 | Explore、Spec Delta、受控 Apply、Archive | **優先重用／薄型轉譯** |
| Spec Kit | SK-01～04 | Constitution、Clarify、Specify、Plan、Tasks | 依工作適用性選用 |
| gstack | GT-01～04 | Product、Engineering、QA、Release Review | **優先借用審查方法；Runtime 選用** |
| Superpowers | SP-01～04 | Design-first、TDD、Debug、Completion Verification | 選用工程方法 |
| Matt Pocock Skills | MP-01～04 | 訪談、問題去重、Domain Modeling、Spec／Tickets | **優先重用方法** |
| GSD | GS-01～04 | Milestone、Checkpoint、Resume、Verification | 參考方法，不另建 Scheduler |

**24 個槽位必須保留身份與適用性記錄，但不等於 24 個工具都必須安裝，更不等於每次任務都要啟用全部 Donor。**

SBL DOC-06 C32 的基本原則是 `Capability-before-Brand`、`KeepNative／WrapThin` 及 Provider-off 退路。

這正是避免重複造輪子的依據。

---

## 六、OpenSpec 的完整整合方案

[![OpenSpec/docs/commands.md at main · Fission-AI/OpenSpec · GitHub](https://images.openai.com/static-rsc-4/wf1AelIuaQ1tIOJ4rYq3DVBG6SJpcK2lyyI_mpQljYFNX18ia3uZTA7XTInESMGWPiXkZKmmX5NS59OgBWU2V_OsxdMUGsb4dLNi1K0frgadbmpju61S7QELhiATQvpVjZ1rM-Hk66blAoqKneRWJxJf1VrjSXSxi5CE99WnzwqRmjjPQzo53kfxNYfbHBzw?purpose=fullsize)](https://github.com/Fission-AI/OpenSpec/blob/main/docs/commands.md)

**OpenSpec**

官方來源：[Fission-AI/OpenSpec](https://github.com/Fission-AI/OpenSpec?utm_source=chatgpt.com)

OpenSpec 以 Change Proposal、Specs、Design、Tasks 與 Verify 支援規格驅動開發，特別適合 Brownfield 增量變更。現行官方文件也列出對 Codex 與 Hermes Agent 等工具的整合支持。\[[GitHub - Fission-AI/OpenSpec: Spec-driven development (SDD) for AI coding assistants.](https://github.com/Fission-AI/openspec?utm_source=chatgpt.com)\]

### 6.1 SBL 已指定的四項能力

| Slot | OpenSpec 原生能力 | 對應 TPM／PIPD 工件 |
|--------|--------|--------|
| OS-01 | Explore | QuestionDelta／DecisionLedger |
| OS-02 | Propose／Spec Delta | ChangeProposal／SpecDelta |
| OS-03 | Apply／Verify | 受控 ChangeSet／Test Evidence |
| OS-04 | Archive | ArchiveCandidate／Supersession Record |

這些功能不應由新版 SBL-TPM-SP 重新設計一套完全相同的專屬 Spec Diff Engine。

較適當的設計是：

`OpenSpec Native Change → Thin Translation Adapter → PIPD Source/PI/PD Reference`

### 6.2 OpenSpec 與 PIPD 的責任分界

**OpenSpec 管理自身的變更工作流，PIPD 管理正式工程契約與准入語義。**

不能因 OpenSpec 的某項 Change 被標記完成，就直接產生：

`PI_READY`、`PREDEV_READY`、`EXECUTION_ADMITTED` 或 `NATIVE_ACCEPTED`。

例如：

- OpenSpec `/opsx:propose` 可以產生候選變更。
- `/opsx:verify` 可以提供受影的規格符合性證據。
- 真 Repository Mutation 仍須合法 WriteSet 與適用的 ExecutionAdmission。
- OpenSpec Archive 不得自動代表 PIPD Trace Closure 或 Hermes Mission Completion。

這也是 FHS-MSC 藍圖 r2 §4.1 及 PIPD DOC-08 所要求的從屬轉譯關係。

### 6.3 必須防止 OpenSpec 假綠燈

FHS-MSC 藍圖 r2 和總討論曾識別一項具體失效：

**在錯誤 Project Root 執行 OpenSpec 檢查，可能得到零個有效測項，卻仍有成功的程序結束碼。**

因此，不能只檢查 `exit_code == 0`。

必須驗證：

`Actual Root + Expected Subject + Nonzero Tested Items + Expected Denominator + Result Identity + Exit Status`

這是此次新版 Plugin 需要直接納入的 B1 防再發測試。

### 6.4 建議採用程度

**OpenSpec：`SELECTIVE_NATIVE_REUSE_WITH_THIN_ADAPTER`。**

- 對 Brownfield Spec Delta：優先使用。
- 對純 TPM 需求探索：可用，但不強制。
- 對 PIPD Canonical Compiler：不取代。
- 對沒有 OpenSpec 的環境：仍必須能輸出基本 SBL/PIPD 規劃工件。
- 對真正 Apply：須具有效 Write Permission。

目前 OpenSpec 官方已提供輕量的安裝和跨 Agent 工作流；但本地既有 DOC-08 固定的 2026 年 10 月初版本只是歷史釘選，正式施工須核對現役版本、CLI 相容性及安全回歸，而非直接升級至未驗證的最新版本。\[[OpenSpec](https://openspec.dev/?utm_source=chatgpt.com)\]

---

## 七、Matt Pocock Skills 的完整整合方案

**Matt Pocock Skills** 的核心優勢是將訪談、領域建模、測試驅動開發、診斷與程式審查拆成小型、可組合的技能，而不是強制採用另一個大型生命週期。

官方技能集合已有 `grill-me`、`grill-with-docs`、`domain-modeling`、`to-spec`、`tdd`、`diagnosing-bugs`、`implement`、`code-review` 等工作流。\[[skills/skills/engineering/README.md at main · mattpocock/skills](https://github.com/mattpocock/skills/blob/main/skills/engineering/README.md?utm_source=chatgpt.com)\]

官方來源：[mattpocock/skills](https://github.com/mattpocock/skills?utm_source=chatgpt.com)

### 7.1 對應 SBL 的四項能力

| Slot | 方法能力 | 新版 TPM 的直接用途 |
|--------|--------|--------|
| MP-01 | Skill Routing／按需求選擇方法 | 不因工具名稱出現就強制啟用 |
| MP-02 | Grill-with-docs／問題去重 | QuestionLedger、已知答案不重問 |
| MP-03 | Domain Modeling／Glossary | DomainModel、ADR、語義衝突 |
| MP-04 | To-spec／To-tickets | SpecCandidate、TaskSpecSeed |

這四項能力與使用者希望的「少問、快速形成可施工規格」高度相關。

尤其對 39 份已內建文件，Matt 的訪談方法應從：

「先問使用者所有問題」

改成：

**先從已內建來源取得可證明的已知答案，只對真正缺失、矛盾或需要 OWNER 決策的事項提問。**

### 7.2 對 Codex 施工的附加價值

Matt 的工程技能也可以用於：

| 工程階段 | 可重用技能 |
|--------|--------|
| PIPD Fixture 修復 | `diagnosing-bugs`、`tdd` |
| Typed Adapter 設計 | `codebase-design`、`domain-modeling` |
| 來源／Spec 對齊 | `grill-with-docs`、`to-spec` |
| 逐 WorkPackage 施工 | `implement`／`implement-spec` |
| PR 與 ABI 審查 | `code-review` |
| 長任務交接 | `handoff`／`wayfinder` |

不應因為使用 Matt Skills，就把每一個簡單的 YAML 修正都變成一次完整訪談或昂貴的多代理審查。

### 7.3 正式整合方式

**Matt Skills：`SELECTED_METHOD_REUSE`，必要時才 `HOST_SKILL_ADAPTER`。**

例如，把「已知答案不重問」、「先找根因再修」、「先有 Red 才修」等經核准的方法能力，融合為新版 TPM-SP 的內部工作流。

如果原生 Matt Skill 在 Codex 中已存在且經驗證，可直接選用；若沒有，則新版 TPM-SP 仍應保有自身最低必要能力，不要求使用者額外安裝整套 Matt Plugin。

同時必須分辨方法引用與原始技能程式碼的重製／分發，按精確來源版本及授權條件決定可封裝內容。

---

## 八、gstack 的完整整合方案

**gstack** 具有從 Product Review、Engineering Review 到 QA、Ship 的成套工程工作流。

近期官方文件還包含診斷、代碼審查、瀏覽器 QA、測試審計、Context Restore 及多 Agent 協調能力。\[[gstack/docs/skills.md at main · garrytan/gstack](https://github.com/garrytan/gstack/blob/main/docs/skills.md?utm_source=chatgpt.com)\]

官方來源：[garrytan/gstack](https://github.com/garrytan/gstack?utm_source=chatgpt.com)

### 8.1 既有 SBL 四個 Slot

| Slot | gstack 能力 | 新版 Plugin 的用途 |
|--------|--------|--------|
| GT-01 | Product Review | 檢查 JTBD／FUO 是否能真的產生使用者成果 |
| GT-02 | Engineering／UX Review | 檢查架構、NFR、錯誤路徑 |
| GT-03 | QA／Independent Review Request | 產生反例、復現路徑與 Checker Request |
| GT-04 | Release／Ship Readiness | 核對 CI、證據與發行缺口 |

這些都能減少另外設計一套審查框架的必要性。

### 8.2 但有一項重要限制：gstack 的 Host 成熟度不同

目前官方 README 將：

- Claude Code 標示為 `full`；
- Codex CLI 標示為 `experimental`；
- Hermes 標示為 `instruction-only`。

官方亦說明 Codex 和部分其他 Host 的安全 Hooks 尚不等同 Claude Code 的強制阻擋機制。\[[gstack/README.md at main · garrytan/gstack](https://github.com/garrytan/gstack/blob/main/README.md?utm_source=chatgpt.com)\]

因此，不能因為同一份 gstack Skill 可被 Codex 讀取，就認為其安全阻斷 Hook、Review Runner 或 Browser QA 已全部達成同等效果。

尤其 Windows 環境的 Browser／Bun／Node／WSL 相容性，以及部分本機二進位工具的執行限制，必須現場驗證。

### 8.3 gstack 不可替代正式 Checker

即使 gstack `/review` 或 `/qa` 找出真實缺陷，也不代表：

`INDEPENDENT_CHECKER_PASS`

理由是其原始工作流通常只是一種工程工具／方法，未必具備本專案要求的獨立 OS Principal、有效收據、Native Admission 及 Claim 權威。

這也是 PIPD DOC-08 對 gstack 多數採用 `REFERENCE`、`EVAL_ONLY`、部分 `QUARANTINE` 的原因。

**正式方案：先重用 gstack 的審查方法及可驗證的局部能力，不直接將整套 gstack Runtime 視為 SBL-TPM-SP 的必備依賴。**

### 8.4 gstack 的首選用途

就本次任務而言，建議優先使用：

- Product FUO Review。
- Engineering Architecture Review。
- Code／Spec Diff Review。
- 真 Host 支援下的 Browser QA。
- 發布前的 Readiness Review。

對自動多 Agent Crew、Ship Automation、跨 Host 背景流程等能力，則先進行受影試點和 Host Capability Discovery。

若沒有經正式技術准入和真實測試，不應直接賦予 Repository Mutation、WorkOrder Admission 或 Release 權限。

---

## 九、六個 Donor 的整合政策：防止再次治理過重

### 9.1 必須統一 SBL 與 PIPD 的不同裁決範圍

此處有一項重要的跨規範關係。

SBL DOC-06 C32 要求保留六個 Donor 的能力槽位；PIPD DOC-08 則對不同 Donor 設定不同的 TechnologyAdmission 狀態。

例如：

| Donor | SBL 產品設計 | PIPD DOC-08 相關裁決 | 新版的合法處置 |
|--------|--------|--------|--------|
| OpenSpec | OS-01～04 能力保留 | 部分 `SELECTED_TRANSLATE`，部分 `REFERENCE`／`EVAL_ONLY` | 只啟用已准入的受影 Adapter |
| Matt Skills | MP-01～04 能力保留 | 部分 `ADOPT_WITH_TRANSLATION`，部分 `REFERENCE` | 先採用已核准的方法映射 |
| gstack | GT-01～04 能力保留 | 多數 `REFERENCE`／`EVAL_ONLY`，部分 `QUARANTINE` | 預設參考，不暗中啟動 Runtime |

這不是簡單地由 SBL 覆寫 PIPD，也不是一看到 PIPD 的 `QUARANTINE` 就刪除 SBL 的 GT-01～04。

正確關係是：

**SBL 可以保留完整的產品能力義務；PIPD 決定相關 Adapter 在對應範圍內是否具備合法的執行或編譯資格。**

若未來希望把 gstack 某個功能從 Reference 提升為可執行 Host Tool，應另有受影 TechnologyAdmission、版本釘選、能力探測、POS／NEG、權限及回滾驗收。

### 9.2 六個 Donor 的最終建議

| Donor | 預設採用 | 適用領域 | 不應重複製造的能力 |
|--------|--------|--------|--------|
| OpenSpec | **選擇性原生重用** | Brownfield Proposal、Delta、Verify | 第二套 Spec Delta Engine |
| Spec Kit | 選擇性 | Greenfield Specification、Task Graph | 第二套完整 Task Compiler |
| Matt Skills | **方法重用為主** | TPM 問題、領域建模、TDD、Review | 第二套訪談／測試方法框架 |
| gstack | **Reference／Evaluation 優先** | Product、Engineering、QA、Release Review | 第二套正式 Checker／Release Authority |
| Superpowers | 方法重用 | Debug／TDD／Evidence-before-completion | 第二套施工執行控制平面 |
| GSD | 方法參考 | Milestone、Checkpoint、Resume | 第二套 Durable Scheduler |

**所有 Donor 都應有 Provider-off 或 Tool-unavailable 退路。**

沒有 OpenSpec 時，仍能產生合法的 SpecDelta Candidate；沒有 Matt Skills 時，仍能完成 QuestionLedger；沒有 gstack 時，仍可執行既有的確定性測試與正式 Checker。

Provider-off 不代表降低正式驗收標準，而是避免非必要外部工具成為工作流程的隱形單點故障。

### 9.3 不應把整套外部工具直接塞進統一 Plugin

你的最終使用要求仍是：

**只安裝 SBL-TPM-SP，不必另外安裝多套規劃 Plugin，也不必重新上傳 DOC。**

這個要求可以保留，但應把三種整合方式分開：

| 整合方式 | 如何滿足單一 Plugin | 何時使用 |
|--------|--------|--------|
| **內建方法** | 將合法可用的流程與規範映射成內部 Skill | 訪談、領域建模、Review Checklist |
| **內建輕量 Adapter** | 在 SBL-TPM-SP 內提供版本化 Typed Interface | PIPD、OpenSpec、Host Handoff |
| **受權外部 Runtime** | 由 Plugin 透過已授權的工具接口使用 | 真 CLI、Browser QA、Repo 變更、Native Effect |

不能因為第三類工具存在，就把它的所有原始碼、私鑰、服務進程或作業系統依賴全數複製進 Plugin。

若某個外部 Runtime 不可用，該功能應按適用性明示降級或 HOLD，不能冒充已原生執行。

---

## 十、建議的完整施工 DAG

新版 SBL-TPM-SP 應採用以下階段安排，而非先讓某個 Agent 一口氣完成全部任務。

**P0｜Codex：來源與環境基線**

DOC 全文、P4 Skills、Repository、現有 Plugin、來源版本、授權、外部 Donor Capability Inventory

**P1｜Codex：P4 修復與 TPM 第一版**

Fixture／Schema／Semantic Validator、十二軸映射、Oracle／TQAEP、Product／System／Program、全 DOC 自包含索引

**P2｜Codex：Donor Integration 與 Plugin 封裝**

OpenSpec Thin Adapter、Matt Method、gstack Review Mapping、Provider-off、Single-Plugin Clean Install

**P3｜Codex 與 Hermes／HGK：不同工作類型並行**

Codex 完成 CI／Fixture／Host 靜態修復；Hermes／HGK 完成真正 Native Receiver／Executor／Restart／Effect 測試

**P4｜隔離審查與正式驗收**

另一個審查 Context、確定性驗證器、真獨立 Checker、Release Candidate，最後由有權程序發布

### 10.1 各階段不能缺少的退出條件

| 階段 | 最重要的 Exit Gate |
|--------|--------|
| P0 | 完整 Source Manifest、真 Currentness、無不明覆蓋 |
| P1 | 既有 P4 正向 Fixture 缺陷修復，受影負例回歸 |
| P2 | 只裝新版 SBL-TPM-SP 即可讀取所有已承諾的內建 DOC |
| P3 | 受影 Native WorkOrder 真實執行與讀回，不用 Plugin 假冒 |
| P4 | 真 Raw、Claim、Checker、Source／Candidate SHA 一致，合法交付 |

### 10.2 為何 P3 不應完全放到最後？

如果所有 Native 整合都等到 Codex 完成整套產品才開始，可能晚到最後才發現：

- Host 無法載入該 Plugin 的某些資源。
- Artifact Resolver 在另一個程序中無法找到相同路徑。
- 真 PIPD Compiler 的 ABI 與測試 Fixture 不一致。
- Hermes 無法識別新的 Typed Handoff。
- Windows 權限或 Git Worktree 隔離與規劃不同。

所以建議在 P1 初步產生有效的垂直切片後，就以**不阻斷其他施工的方式**進行最小真實 Host／Hermes 接線測試。

不需要等整套 Plugin 完成才做第一次跨系統驗證，也不應因此要求 P1 的所有一般工程先取得完整 G-B。

---

## 十一、如何測量哪個施工方案真的更有效率？

本次無法取得三種方案在相同本地環境的完整工時、Token、回歸及失敗率資料。

因此建議在正式選定主施工方式後，以一組有限的 A/B 基準驗證，而非按模型品牌直接宣告效率。

### 11.1 建議的受控 Benchmark

使用相同的來源版本、受影代碼、Sandbox、工具權限和驗收條件，選擇四個代表性任務：

| Benchmark | 具體任務 | 要測量什麼 |
|--------|--------|--------|
| BM-01：大 DOC | 找出十二軸／九軸風險映射衝突，產生逐欄來源證據 | 來源正確率、漏項、重讀量 |
| BM-02：Fixture | 修正 P4 PI Trace Wrong Hash 與負例 | 真 Red/Green、修復成本 |
| BM-03：Plugin | 完成零 DOC 上傳的乾淨安裝及讀取測試 | Host 成功率、重試、依賴缺口 |
| BM-04：Durable | 中止 Worker、重新喚醒、合法續行同一工作 | 真跨程序恢復、重複 Effect |

對 Codex 與 Hermes 使用相同的完成定義。

BM-04 必須由真實 Hermes/HGK 執行；Codex 可以在同一測試中協助觀察，但不能用模擬 Scheduler 取代原生結果。

### 11.2 主要 KPI

| KPI | 預期方向 |
|--------|--------|
| 每個合格 WorkPackage 的時間與資源成本 | 降低 |
| Source Clause／Hash 錯誤率 | 0 |
| 修復後的受影 Regression 失敗率 | 0 |
| 不必要的全域 HOLD | 0 |
| 自包含 DOC 再上傳要求 | 0 |
| 未授權 Repo／Host Effect | 0 |
| Hermes 自治續航成功率 | 提高至全部適用測試均通過 |
| Maker 自行冒稱獨立驗收 | 0 |

採用這些數據後，才可進一步裁決是否把未來某類工作從 Codex 轉交 Hermes，或相反。

---

## 十二、開源導入必須具備的驗收及退出機制

為防止 OpenSpec、Matt、gstack 反而形成新的治理負擔，建議每個 Donor 都必須具備一份 **Donor Admission Record**。

最低應包含：

`Donor ID / Exact Version / Source SHA / License / Host Compatibility / Capability / Existing Native Alternative / Added Value / EffectClass / Adapter ABI / POS / NEG / Security / Provider-off / Rollback / Removal`

### 12.1 應禁止的外部工具導入模式

以下情況不得視為合格整合：

- 只因 GitHub 熱度高就自動安裝。
- 直接採用浮動 `latest`，沒有版本釘選及回歸。
- 為使用一項 TDD 方法安裝另一個整套長任務控制平面。
- 讓 OpenSpec 與 PIPD 同時寫入不同版本的正式規格真值。
- 讓 gstack Review 直接發出正式 Checker PASS。
- 讓 GSD 建立與 Hermes SharedSpine 競爭的持久 Queue。
- 讓外部 Skill 修改未授權 Repository Scope。
- 讓 Codex／Hermes 遇到工具缺失就默默改用不同的 Provider 或模型。
- 將外部 Donor 的安裝成功當作有效能力已被真實調用。

### 12.2 以最小實作成本決定 Native／Adapter／Fallback

每次採用新工具前，比較：

| 方案 | 主要考量 |
|--------|--------|
| Keep Existing Native | 功能是否已具備、是否只需接線 |
| Thin Adapter | Schema／CLI 轉譯是否比重新實作簡單 |
| Internal Method | 是否只需方法規範，不需新增 Runtime |
| Provider-off Fallback | 沒有該工具時最低可用功能 |
| New Component | 是否已經有經實測證明的 Native NoFit |

這與 FHS-MSC 藍圖 r2 的 Minimum-Sufficient Architecture／Overengineering Index 相同方向。

**新常駐服務、第二 Writer、重複 Gate、額外人工批准與範圍外溢，都應列為引入成本。**

不應以降低開發時間為理由，無條件增加長期營運成本。

---

## 十三、最終完整可用版 SBL-TPM-SP 的驗收清單

新版正式 Release 至少必須完成：

| 驗收項 | 要求 |
|--------|--------|
| Corpus | PIPD／SBL 必要 DOC 完整內建、版本核對、免重複上傳 |
| PIPD | 八 Skill 及已知 Hash／Subject／Profile／TQAEP 缺陷修復 |
| TPM | Product／Systems／Program 三角色及 T0～T5 |
| OpenSpec | 已選定能力真調用，Root／非零分母／Subject 正確 |
| Matt Skills | 必要方法映射、QuestionLedger 不重問 |
| gstack | 受限 Review／QA，無額外未授權效果 |
| Other Donors | Spec Kit／Superpowers／GSD 槽位及適用性保留 |
| Provider-off | 取消非必要 Donor 仍可執行核心規劃 |
| Codex Build | 正反測、CI、真 Plugin Package |
| Host Install | 只掛載一套 SBL-TPM-SP 即能完成宣稱的基礎功能 |
| Hermes | 真 Worker、Lease／Checkpoint、跨程序續航 |
| HGK | 真 Native Admission／拒收、權限及 Principal |
| Acceptance | Maker 與真正 Checker 不混用 |
| Release | 受權發布、版本釘選、可回復 |

**必須把「SBL-TPM-SP 本身的完整可用」與「整個 FHS-MSC B1 Native Bootstrap 的最終驗收」分開。**

前者可以先完成；後者如仍存在真 Native 缺口，就必須保持相應 HOLD，不能因 Plugin Release 成功自動升級。

---

## 十四、最終工程決議

### 決議一：施工主導平台

**採用 Codex 主導第一版工程實作。**

主要原因不是單純偏好 Codex，而是本任務目前以大量本地規範、Schema、Fixture、Repository 修補、可重播測試和 Plugin 封裝為核心。

Codex 的本地 Worktree、CLI、腳本、測試及非互動執行能力，與此工作型態較一致。

### 決議二：Hermes／HGK 的位置

**保留 Hermes／HGK 為 Native 高自動化實測及正式效果的必要系統，不把它們當作已經完成自治資格的前提。**

在其真 Executor／Receiver 尚未取得證據前，先用 Codex 完成不依賴該能力的合法修補；一旦受影接線具備，就立即以最小真實工作卡驗證。

### 決議三：Codex 最終驗收

**Codex 可以執行最終工程回歸、交叉挑戰、修復迭代及交付封裝，但不能以同一施工主體自評取代獨立 Native Checker。**

正式 Release 必須建立在原始測試、真 Host Effect、有效身份及授權驗收上。

### 決議四：外部開源工具

**保留 SBL DOC-06 的六 Donor／24 Slot，不刪除 OpenSpec、Matt Skills、gstack。**

其中：

- OpenSpec：選擇性原生重用及 Spec Delta Adapter。
- Matt Skills：TPM 訪談、Domain Modeling、Spec、TDD、Review 方法。
- gstack：優先重用 Review／QA 方法，Host Runtime 經驗證後才選用。
- Spec Kit／Superpowers／GSD：依原 SBL 槽位保留能力及適用性，不強制全裝。

所有 Donor 均不得取代 PIPD、HGK 或正式 Checker 的權威。

### 決議五：最終使用者體驗

**仍然必須做到只安裝新版 SBL-TPM-SP，就能使用完整內建 DOC、TPM 三角色、修復後的 PIPD 規劃／契約能力與選定的開源方法。**

不應要求使用者另裝舊 P4 Plugin，或反覆上傳 SBL／PIPD／FHS 基礎 DOC。

對需要外部真執行權限的能力，應提供合法接線及明確的未就緒狀態，而非把整套外部工具偷偷設為安裝先決條件。

---

**最終建議架構：**

`Codex Primary Builder → SBL-TPM-SP Unified Candidate → Hermes/HGK Native Integration → Isolated Codex Review → Independent Acceptance → Authorized Release`

此方案同時回應了你的兩個目標：**利用 Codex 對大量文字、契約與程式修補的工作優勢，又保留 SBL 上位規格對 OpenSpec、Matt Skills、gstack 等現成能力的重用，避免再次建立重複的 Compiler、Scheduler、Checker 或治理流程。**

**本輪工程狀態：`SOURCE_REVIEWED / EXTERNAL_TOOLS_VERIFIED / BUILD_STRATEGY_RECOMMENDED / DONOR_POLICY_DEFINED / IMPLEMENTATION_NOT_EXECUTED`。** 本報告完成的是研究、鑑定與施工規劃，尚未在本地 Codex 或 Hermes 實機執行新版 Plugin 的建置與正式驗收。

## Prompt:
2026/10/27 下午10:23:10

任務目標：
你必須整合前述分析規劃，再對『』進行以下項目的專業工程「研究分析 + 交叉比對 + 鑑定評估」：
"
1) 是否需要在新版 SBL-TPM-SP新增需求/功能，使其產出的「PIPD-LS-PKG」的ECP和TQAEP，會包含必須把實作內容上推到GITHUB REPO的預設規劃，並將其設計成「必檢/非阻斷/主動詢問式 GATE」，這樣用戶可以在前期設計規畫和後期實作時，明確告知自己需要/不需要把實作內容進行上推GITHUB REPO，也避免用戶或AI忘記？

2)新版 SBL-TPM-SP，必須和在HERMES/HGK內運作的SBL-TPM進行拆分，SBL-TPM-SP可在GPT/CODEX進行掛載使用，但SBL-TPM是HERMES/HGK/SBL內的完整「PIPD-LS-PKG」工廠，這樣才能真正實現用戶對HERMES/HGK/SBL進行自然語的需求，即可進行E2E端到端的全自動設計→開發→實作→檢測→驗收→交付。

3)第2)項的需求，是否已經在《FHS-MSC_藍圖_r2》、《FHS-MSC_總討論》、「SBL_PIPD-LS-PKG」有相關完整規劃?
"

任務要求：

你必須針對任務目標，並對全部相關資料進行「研究分析+交叉比對+深度推理」，再進行鑑定、評估、規劃，並提出完整報告。

最後你必須直接以文字提出完整報告。

## Response:
2026/10/27 下午10:23:37 · gpt-6-thinking

我會把這三項需求分開鑑定：**GitHub 上推是否應設為必檢但非全域阻斷的決策 Gate**、**GPT／Codex 的 SBL-TPM-SP 與 Hermes／HGK 內的 SBL-TPM 工廠應如何分權**，以及**這種雙形態架構在 FHS／SBL 上位文件中究竟已規劃到什麼程度**。我會先核對原始條款，再提出能直接納入新版產品規格的狀態機、ECP／TQAEP 契約及 E2E 驗收條件。

目前的來源比對顯示一個關鍵差異：**SBL DOC-01 已明確要求「One Core／Three SP／Six Modules」，FHS 藍圖亦將可攜式 TPM-SP 與 HGK／Hermes 的原生執行鏈分開；但尚未找到一份已批准、可實際部署的「SBL-TPM Native E2E Factory」完整契約。** 因此建議將它定位為既有架構的正式擴充，而不是宣稱舊文件早已完成實作。GitHub Gate 方面，既有文件已有 Publisher、PR、CI 與安全規則，欠缺的是你這次指定的「主動詢問、記住決策、未選擇不阻斷本地工作」這套產品互動契約。

> **釐清閘門設計**
>
> 我會把 GitHub 操作與程式實作分開：規劃階段先確認權限、分支與發布意圖；未明確授權時採本地模式，不把提交或推送當成預設動作。
>
> **釐清閘門設計**
>
> 
>
> **檢查研究檔案與 GitHub Gate 規範**
>
>
> **檢查研究檔案與 GitHub Gate 規範**
>
> 
>
> **Interacted with Files**
>
> 
>
> **搜尋本地檔案並統計關鍵模式**
>
>
> **搜尋檔案並釐清TPM工廠模式與發布權責**
>
> 
>
> **已搜尋 1 個網站**
>
> 
>
> **擷取指定文件關鍵段落**
>
>
> **擷取文件關鍵段落並整理SBL工廠上下文**
>
> 
>
> **設計 GitHub 閘門**
>
> 我會補查既有文件與來源，區分目前規範和新增提案；重點是讓閘門必檢但不阻塞本地開發，只有獲准時才進入遠端寫入流程。
>
> **設計 GitHub 閘門**
>
> 
>
> **搜尋藍圖與相關文件並制定GitHub治理驗收邊界**
>
> 
>
> **搜尋 SBL 中的 TPM 工廠執行程式碼**
>
> 
>
> **檢查 GitHub 上推規劃與既有文件**
>
>
> **劃分閘門流程**
>
> 我會把遠端同步拆成「必檢、非阻斷、主動詢問」三層：未回覆時繼續本地流程，明確拒絕則不推送，明確要求才建立發布路徑；並保留既有核心、單一寫入者與可追溯證據鏈。
>
> **完成閘門流程劃分**
>
> 
>
> **檢查 GitHub 推送規範與設計依據**
>
>
> **檢查 GitHub 推送規劃、規範與設計依據**
>
> 
>
> **修正 U26 GitHub 交付政策並重用 QuestionGate**
>
> 
>
> 處理時間為 9m 24s

# SBL-TPM-SP／SBL-TPM 雙形態架構與 GitHub 交付決策 Gate 工程鑑定報告

鑑定日期：2026 年 10 月 27 日｜依據：前述 SBL／PIPD 整合規劃、FHS-MSC 藍圖 r2、FHS-MSC 總討論、SBL DOC-00～13、PIPD DOC-00～09 及 B1 施工紀錄

## 一、總體裁決

**你的三項要求都具有工程合理性，建議正式納入新版 SBL-TPM-SP 與 Hermes／HGK／SBL 的整體產品規劃。但其中第二項需要一項關鍵架構修正：SBL-TPM-SP 與 SBL-TPM 應分離部署及執行責任，卻不能形成兩套彼此獨立的 PIPD Canonical Compiler 或生命週期權威。**

| 任務議題 | 工程結論 | 上位文件支持程度 |
|--------|--------|--------|
| GitHub 上推必檢、非阻斷、主動詢問 | **建議新增為正式產品需求** | 已有出版／權限／CI 控制；尚缺完整的使用者偏好決策機制 |
| GPT／Codex SBL-TPM-SP 與 Hermes／HGK SBL-TPM 分離 | **建議採用雙部署形態** | 已有多 Host SP、One Core、原生工廠及 E2E 規劃 |
| Hermes／HGK 內建完整 PIPD-LS-PKG 工廠 | **架構可行，但需實際建立閉環** | 已有分散的模組、契約及接口；尚未證明完整產品已實作 |
| 自然語言直接觸發完整 E2E | **應列為最終產品能力** | SBL 上位產品目標已有相應設計 |
| 是否全部早已完整規劃 | **部分已具體規劃，部分需要新增及收斂** | 不宜宣稱既有文件已完成雙形態工廠的全部 ABI |

### 1.1 GitHub Gate 的核心決議

**必須檢查是否需要交付至 GitHub，但預設不得擅自 Push。**

建議正式規則：

`GitHub Decision Check = Mandatory`

`GitHub Publication = Optional and Authorization-dependent`

`GitHub Undecided = Nonblocking for unrelated local work`

也就是：

- 前期規劃時主動確認使用者是否需要 GitHub 交付。
- 使用者已作明確決策後，不重複詢問。
- 未決定時，不阻斷本地設計、開發、測試與有權的本地交付。
- 需要實際上推時，必須另驗證目的 Repo、分支、可發布內容、憑證、權限及安全條件。
- 明確選擇不上推時，仍可完成本地交付；不得將未 Push 錯判為任務失敗。
- 如果使用者明確要求「交付完成必須包含 GitHub PR」，該遠端交付才成為**該任務的必要 Exit Gate**。

這可同時避免忘記詢問和造成新的治理阻斷。

### 1.2 雙形態架構的核心決議

建議明確區分：

**SBL-TPM-SP：Portable Planning／Specification Interface**

供 GPT、Codex 等外部 Host 安裝，提供完整內建 DOC、需求規劃、PIPD 契約產生與受控交接能力。

**SBL-TPM：Native E2E Lifecycle Factory**

在 Hermes／HG-KSEOS／SBL 內運作，接收自然語言或具型別的任務，協調正式 PIPD 編譯、工程施工、測試、驗收及交付，使用現有系統的合法執行權限。

二者共用經核准的規範、Schema 和工件 ABI，但各自具有不同的運行環境、身份及權限。

**Portable SP 不得自行擁有 Native Effect 權限；Native Factory 不得建立第二個 PIPD Writer、HGK Issuer 或 Hermes Scheduler。**

---

## 二、來源鑑定：既有文件究竟規劃到了什麼程度？

### 2.1 《FHS-MSC\_藍圖\_r2》已明確包含的內容

這份藍圖有幾個直接支持你的新需求的條款。

首先，§5.2 和原 R15.1 §3.3 已明確定義 TPM-SP 為可攜式工具：

`portable sbl-tpm-sp.zip / Host invocation goal.open`

其次，§5.3、§5.4 把 TPM、PIPD、HGK、Hermes 和 GitHub Publisher 的 Writer／Executor 職責分開。

其權責表明確規定：

| 對象 | 正式責任 |
|--------|--------|
| SBL Product Owner／合法 Standalone | Product Goal／UX |
| PIPD 所屬合法 Writer | SourceFreeze、PI、PD、ECP、TQAEP |
| HGK Native Issuer／Shared Spine | WorkOrder、Permit、Native State |
| Hermes 唯一 Dispatcher | Runtime Kanban、Lease、Checkpoint |
| 真 Independent Checker | Oracle／獨立驗收 |
| 各 Repository 授權 Publisher | GitHub Branch、PR、Release |

這是**雙形態分離而不複製權威**的直接設計基礎。

另外，§7.1～§7.3 已提出：

`Codex Read-only Investigation → Selective Publication → PIPD Bootstrap → Bounded Repair → Handoff to HGK/Hermes`

並規定不得把私人資料或全部本機 Runtime 內容直接上推 GitHub。

因此，「GitHub 是否應發布」在 FHS 中早已是獨立於本地施工的控制事項。

**但它仍沒有把「每個新任務都檢查一次使用者 GitHub 偏好、未決定時局部非阻斷、選擇不上推時合法完成」完整定義成正式產品狀態機。**

這就是本次應新增的部分。

### 2.2 《FHS-MSC\_總討論》已明確包含的內容

總討論在 GitHub 問題上提供了重要的實際失效證據。

R17 的 RC-17 指出，曾因本機 GitHub Credential Broker 不可用，造成 Stage Candidate 沒有上推。

後續又確認本機與遠端可能存在 HEAD、Manifest、Source Projection、PR 和 Host Loaded 的不一致。

其正式建議是：

`Local Truth Reconciliation → Controlled Publication → Cross-Repo Engineering View → FAR-Assisted Durable Execution`

也就是先盤點、再決定哪些內容可以發布，不能先假設「所有本機資料都應推送」。

這直接支持你的 GitHub 決策 Gate，但也要求在真正 Push 之前檢查正確的 Repository 和發布內容。

### 2.3 SBL DOC-00～13 已明確包含的內容

SBL DOC-01 要求 One Core、Three SP、Six Modules，並保留 TPM-SP 單獨使用的產品能力。

DOC-04 已定義 TPM-SP `goal.open`，以及 Product、Systems、Program 三種規劃職責。

DOC-05、DOC-11 涵蓋受治理執行、HGK 原生鏈路和 WorkOrder／ECP 交接。

DOC-12 則有 GitHub CI、Required Checks、Host Distribution、Release Publisher、Source Hash、Supply Chain 及獨立驗收要求。

因此，SBL 的原始產品規劃已經具備：

`Goal → Specification → Planning → Governed Execution Interface → Evidence → Delivery`

但**現有設計對 TPM-SP 的角色更偏向規劃與交接，而不是由 TPM-SP 自己完成所有實際程式開發和 Host Effect**。

你的新要求可以理解為：在 Portable TPM-SP 之外，明確建立一個真正運行於 Hermes／HGK 的完整 E2E 工廠，將原本散布在六模組、PIPD、HGK、Hermes 和 SBL 工具中的能力串成一條可持續執行的流程。

這符合上位產品目標，但需要補足正式 Runtime Factory Contract。

---

## 三、需求一：GitHub 上推應如何加入 ECP／TQAEP？

### 3.1 建議新增，而且不應只加入一般提醒文字

目前 SBL 已有可重用的基礎：

- DOC-01 的 `U26` 要求 GitHub Source Candidate 的精確 SHA，`U27` 要求 Source Commit 與 Evidence Commit 分離。
- DOC-01 §C08.2 已有 `QuestionCandidate`，§C08.2A 已有避免重問的 `QuestionGate`。
- DOC-12 C43 已規劃 GitHub PR、Required Checks、Merge Queue、受信驗證器與 Publisher 的責任。
- PIPD DOC-09 已區分 CI、Build、Attestation、Release 與真實驗收。

換言之，不必從零創造 GitHub 發行系統，也不必建立第二個通用問答引擎。

**應在既有 `QuestionGate` 和 Delivery／Release 契約上，新增一個具體的 `GitHubPublicationDecision`，並使它成為每份適用 PIPD-LS-PKG 的必檢項目。**

這也與 SBL DOC-01 §C08.2A「同一 Subject／QuestionKey／SchemaVersion 不重問已答問題」的規定一致。fileciteturn10file6L1116-L1124

### 3.2 必檢、非阻斷、主動詢問，其實是三種不同語義

這三個要求應分別實作。

| 性質 | 工程定義 | 不可誤解成 |
|--------|--------|--------|
| 必檢 | 每個適用交付計畫都有 GitHub Decision Record | 每次都必須 Push |
| 非阻斷 | 未決定時，非 GitHub 依賴的本地工作繼續 | 未授權也可以 Push |
| 主動詢問 | 缺少有效決策時，向 OWNER 提出簡單問題 | 每輪或每階段無條件重問 |

因此：

**Decision Gate 必須執行；Publication Effect 只有在需要且已獲有效授權時才執行。**

這是整個方案最重要的語義分離。

### 3.3 建議的正式使用者選項

在前期規劃階段，系統應主動詢問：

> 本次實作成果是否需要同步至 GitHub？
>
> A. 需要。完成受影測試後，準備上推至指定 Repository 的候選分支／PR。
>
> B. 不需要。只進行本地實作、測試及交付。
>
> C. 稍後決定。先完成本地工作，交付前再提醒。

這是建議的產品互動，不是要求使用者現在回答。

如果現有 Mission 已明確指定 GitHub 交付，就不再詢問同一問題。

如果已有有效的有界 Standing Decision，同一範圍內也不應重問；但該決定不能無限延伸到新 Repository、新公開範圍或新的不可逆效果。

### 3.4 GitHub Decision 狀態機

建議採用以下狀態：

| 狀態 | 語義 | 本地工作 | 遠端上推 |
|--------|--------|--------|--------|
| `UNDECIDED` | 尚未詢問或尚無有效答覆 | 繼續 | 禁止 |
| `ASKED_PENDING` | 已提出問題，等待答覆 | 繼續 | 禁止 |
| `LOCAL_ONLY` | OWNER 明確不要 GitHub 交付 | 繼續 | 不適用 |
| `DEFERRED` | OWNER 選擇稍後決定 | 繼續 | 禁止 |
| `PUBLISH_REQUESTED` | OWNER 希望發布，但尚未驗證權限 | 繼續 | 等待驗證 |
| `PUBLISH_ADMITTED` | 已取得適用的發布授權及准入 | 繼續 | 可依受限計畫執行 |
| `PUBLISHED_VERIFIED` | 真實遠端已讀回同一候選 | 依任務繼續 | 本次發布完成 |
| `PUBLISH_BLOCKED` | 缺權限、目標或安全條件 | 繼續不受影部分 | 拒絕 |

其中 `LOCAL_ONLY` 不能與 `UNDECIDED` 混用。

前者表示使用者已明確決定；後者只是尚未作答。

**不能因使用者沒有回答，就自動記錄為「使用者拒絕 GitHub」。**

### 3.5 前期與後期採兩個檢查點

建議建立：

**GHP-01：Planning Decision Check**

在 Product／Program SPEC 或 PI/PD 規劃時執行，記錄是否需要 GitHub、公開或私人範圍、預期目標 Repo，以及本地交付與遠端交付的區別。

不需要 Push 權限，也不需要開始 GitHub 寫入。

**GHP-02：Pre-Publication Execution Check**

只在真正要進行遠端效果時啟動。

檢查決策是否仍有效、來源與候選是否一致、目的 Repo 是否正確、分支與權限是否合法，以及是否已完成去敏及相關測試。

若 GHP-01 已明確選擇 `LOCAL_ONLY`，GHP-02 只記錄本次遠端交付不適用，不重複詢問。

若 GHP-01 已取得涵蓋本次 Scope 的有效授權，GHP-02 不必再次要求形式上的人工同意，但仍必須執行實際安全檢查。

### 3.6 不能因 GitHub 決策讓整個 E2E 停止

應以受影依賴決定阻斷範圍。

| 使用情境 | 正確處置 |
|--------|--------|
| 未決定是否 Push | 本地設計、Build、Test 繼續 |
| 選擇不 Push | 本地交付可正常完成 |
| 想 Push，但 Credential 不可用 | 只 PARK GitHub Publication WorkOrder |
| 想 Push，但 CI 失敗 | 保留受影發布 HOLD，其他合法工作繼續 |
| 已 Push，但 PR 尚未合併 | `REMOTE_CANDIDATE_PUBLISHED`，不能宣稱 Release |
| 使用者明定 GitHub PR 是交付必要條件 | 未完成 GitHub PR 時，該任務的最終交付保持未完成 |
| 上位有效政策強制要求遠端發布 | 使用者選擇 LOCAL\_ONLY 不能自動豁免該政策；須由有權 Owner 裁決 |

最後一項非常重要。

SBL DOC-01 的 U26／U27 本來已有 GitHub 交付義務。因此若該義務對某個正式產品 Release 確實為 Required，不能因新增「使用者不需要 GitHub」選項，就默默刪除上位 Required Atom。fileciteturn10file6L793-L800

正確方式是讓不同交付目標分別有自己的 Exit Contract：本地交付可以完成，遠端發布資格則按實際需求及上位政策判斷。

---

## 四、ECP 與 TQAEP 的正式修訂方式

### 4.1 不建議直接修改原 P4 ECP Schema，強制每張 ECP 都包含 GitHub Push

目前 P4 `pipd-execution-contract` 是以真正 Repo-bound PD-PKG 為基礎的正式效果契約，其 Scope、Token、Retry、Readback 和 Rollback 有既定語義。

若直接在這個受限 Schema 中加入一個 `push_to_github: true/false`，會遇到三個問題：

1. 原生 Schema 的 `additionalProperties:false` 可能直接拒收。
2. GitHub 遠端 Push 與本地 Repository 檔案寫入是不同效果，權限及回讀也不同。
3. 將 GitHub 放進每張實作 ECP，容易重新造成非必要的全域治理依賴。

**應保留正式 ECP 不變量，另外建立受控的 GitHub Delivery Decision 與 Publication Adapter。**

### 4.2 建議加入 PIPD-LS-PKG 的規劃工件

下面是建議的候選契約，不是宣稱目前 P4 已存在的正式 Schema。

```yaml

schema: SBL.GitHubDeliveryDecision@1
mission_ref: REQUIRED
subject_ref: REQUIRED
source_version: REQUIRED

decision_gate:
  required: true
  blocking_scope: REMOTE_PUBLICATION_ONLY
  ask_if_no_current_answer: true
  reuse_valid_prior_answer: true

decision:
  status: UNDECIDED
  requested_delivery: null
  # LOCAL_ONLY | CANDIDATE_BRANCH_PR | DEFERRED

publication_plan:
  target_repository: UNBOUND
  visibility: UNBOUND
  target_branch: UNBOUND
  preferred_route: DRAFT_PR
  direct_main_push: false
  force_push: false

authorization:
  owner_decision_ref: null
  publication_admission_ref: null
  credential_ref: null
  credential_material_embedded: false

verification:
  source_sha_required: true
  secret_scan_required: true
  exact_remote_readback_required: true
  required_ci_by_target_policy: true

claim_ceiling: DESIGN_CANDIDATE
```

關鍵是 `decision_gate.required=true`，但 `blocking_scope=REMOTE_PUBLICATION_ONLY`。

### 4.3 真正需要 GitHub 時，建立獨立 Publication Effect

當 OWNER 選擇需要遠端交付，且已取得有效准入，系統才應建立：

`RemotePublicationRequest → Publication ECP／Native Publisher Adapter → Remote Readback`

它必須包含：

| 欄位 | 必要內容 |
|--------|--------|
| `repository_identity` | 真正 OWNER／Repo ID、Remote URL |
| `source_root` | 真實 Git Root、HEAD、Dirty／Untracked 狀態 |
| `publication_scope` | 精確允許上推的檔案、Branch、Commit |
| `visibility` | 私有／公開及其有效授權 |
| `candidate_identity` | Local Tree／Commit SHA、Artifact Digest |
| `credential_binding` | 有權 Publisher 的 Credential Reference |
| `preflight` | Secret Scan、路徑去敏、WriteSet／Diff Review |
| `operation` | 建立候選分支、Push、PR 或核准的其他操作 |
| `readback` | 真 Remote SHA、Branch、PR、CI |
| `recovery` | 不明遠端效果先查詢；禁止盲重播 |
| `claim` | Candidate Published，不冒稱 Merged／Released |

對高風險或正式 Release，仍須遵守適用的 HGK／PIPD／Repo Owner 准入要求。

這符合 FHS 藍圖 r2 §5.4 的獨立 GitHub Publisher 權責，也符合 DOC-12 所定義的外部 Release Publisher。fileciteturn3file10L331-L342

### 4.4 GitHub 不只是 Push：必須區分五種交付效果

| 階段 | 意義 | 可否代替下一階段 |
|--------|--------|--------|
| Local Commit | 本地 Git 版本已保存 | 不可代替 Push |
| Remote Branch Push | 遠端收到候選 Commit | 不可代替 PR |
| PR Opened | 候選進入審查流程 | 不可代替 Merge |
| Merged to Protected Branch | 真正合併到目標 Branch | 不可代替 Release |
| Release／Deployment | 發行、部署或實際使用 | 不可代替 Native Acceptance |

GitHub 的 Branch Protection 可以要求 PR Review、Required Checks、限制直接 Push 或其他條件；若配置了 Merge Queue，還需確認相應的 `merge_group` 檢查。\[[Managing protected branches](https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/managing-protected-branches?utm_source=chatgpt.com)\] \[[Troubleshooting required status checks](https://docs.github.com/en/pull-requests/how-tos/merge-and-close-pull-requests/troubleshooting-required-status-checks?plain=1&utm_source=chatgpt.com)\]

因此，預設的遠端交付路線應是：

`Validated Local Candidate → Authorized Feature Branch → Push → Draft PR → CI/Review → Explicit Merge/Release Decision`

不要預設直接 Push 到 `main`，也不要預設自動 Merge 或公開發布。

### 4.5 TQAEP 必須新增 GitHub Decision 的 POS／NEG／EDGE／SEC

建議納入以下測試：

| ID | 案例 | 預期結果 |
|--------|--------|--------|
| GH-TQ-01 POS | 使用者選擇 LOCAL\_ONLY | 不 Push，本地交付 PASS |
| GH-TQ-02 POS | 使用者要求 PR 且有合法授權 | 真遠端候選與 PR 回讀 |
| GH-TQ-03 NEG | 沒有詢問也沒有有效既存決策 | Decision Coverage FAIL，但本地工作不中止 |
| GH-TQ-04 NEG | 使用者拒絕 Push，Agent 仍嘗試 Push | Publication Effect DENY |
| GH-TQ-05 NEG | 使用者想 Push，卻沒有真正權限 | `PUBLISH_BLOCKED`，不得自造批准 |
| GH-TQ-06 NEG | 將 Fabric Mirror 當 HGK 本地原始 Repo Push | Wrong Repository／Projection Reject |
| GH-TQ-07 EDGE | 使用者選擇 DEFERRED | 交付前提示，無答覆只保留受影未決 |
| GH-TQ-08 EDGE | 同一有效決策已記錄 | 不重問；Currentness 再核對 |
| GH-TQ-09 SEC | 發現 Token、私人路徑或 Runtime DB | 拒絕發布敏感內容 |
| GH-TQ-10 SEC | 未經授權直接 Push main／force-push | 拒收 |
| GH-TQ-11 POS | Push 完成但 PR 未 Merge | 只記 Candidate Published |
| GH-TQ-12 NEG | CI Green，但缺相同候選 SHA 的驗證 | 不宣稱遠端資格通過 |

這裡仍必須維持前輪已確定的 PIPD 修復要求：

**TQAEP 測試計畫產生時，只是 Planned。真實遠端行為和獨立驗收收據尚未出現之前，不得生成 `INDEPENDENT_CASE_PASS`。**

---

## 五、需求二：SBL-TPM-SP 與 SBL-TPM Native Factory 的正式拆分

### 5.1 建議採用「同一產品體系、兩種部署形態」

新版架構應採：

**SBL Common Contracts &amp; Knowledge**

經版本釘選的 DOC／Schema／Source／Requirement／Risk／Handoff ABI

**SBL-TPM-SP**

Portable／GPT／Codex

---

自然語言需求、內建 DOC、規劃、PI／PD／ECP／TQAEP 候選、GitHub 偏好、工件交接

**SBL-TPM**

Native／Hermes／HGK／SBL

---

真 PIPD 編譯、任務 DAG、授權施工、持久執行、驗證、修補、發布及 E2E 交付

**Existing Native Authorities**

PIPD Canonical Writer｜HGK Issuer｜Hermes Dispatcher｜Fabric Policy｜SBL Domain｜Independent Checker｜Authorized GitHub Publisher

**共用的是規範和交換契約；不同的是部署位置、能力和可執行權限。**

這裡建議把 `SBL-TPM` 作為原生工廠服務的產品名稱，而不是將它與既有 `TPM-SP` 視為同一個程序或同一個安全 Principal。

### 5.2 兩者的具體責任

| 功能 | SBL-TPM-SP | SBL-TPM Native |
|--------|--------|--------|
| 掛載 GPT／Codex | 主要產品 | 非必要 |
| 內建所有必要 DOC | 必須 | 必須有可驗證的有效來源 |
| 自然語言需求分析 | 是 | 是 |
| JTBD／FUO／三類 SPEC | 是 | 可調用同一契約 |
| PIPD PI／PD／ECP／TQAEP | 離線可形成候選；具有效編譯器時可產真編譯工件 | 協調現役 PIPD 合法 Compiler |
| GitHub 是否上推決策 | 必檢、詢問、記錄 | 消費同一決策，不重問 |
| 真 Repo／Host Currentness | 視 Host 工具能力 | 原生 Reader |
| 自動 WorkOrder 派工 | 提供候選 Handoff | 經 HGK／Hermes 真路由 |
| 受限開發／實作 | 不預設具權限 | 調用合法 Builder |
| 跨程序持久執行 | 不自行宣稱 | Hermes Runtime |
| Native Issuer／Permit | 不簽發 | 調用 HGK 唯一 Issuer |
| 獨立 Checker | 產生要求及讀取結果 | 調用真 Checker |
| GitHub Push／PR | 有權 Host 可執行，但不可由規劃權限推定 | 調用有權 Publisher |
| 最終交付 | Package／Plan／Candidate | 依完整任務 Exit Contract 交付 |

### 5.3 對「完整 PIPD-LS-PKG 工廠」的正確定義

原生 SBL-TPM 的核心不是生成九冊或十冊巨型 Markdown。

應是：

**由自然語言目標，自動建立與維護有版本、來源可追溯、可正式編譯及執行的 PIPD-LS-PKG，再驅動合法施工與驗收。**

因此原生工廠至少要具備以下生命週期：

| 階段 | 正式工作 | 主要負責系統 |
|--------|--------|--------|
| F0 | Natural-language Intake、目標及交付選項 | SBL-TPM |
| F1 | Source／Authority／Profile／Risk | PIPD Reader／Owner |
| F2 | PI Contract Compile | PIPD Canonical Compiler |
| F3 | 真 RepoContext／PD Late Binding | PIPD／Repo Reader |
| F4 | ECP、TQAEP Planned、WorkPackage | PIPD／SBL |
| F5 | GitHub Delivery Decision 與受影交付計畫 | SBL Decision Reader |
| F6 | 合法執行准入及 WorkOrder | HGK Issuer／Receiver |
| F7 | Build／Test／Repair／Resume | Hermes／受權 Builder |
| F8 | 真 Raw、TQAEP Execution、獨立驗收 | Runner／Independent Checker |
| F9 | Local Delivery／Optional GitHub Publication | SBL Delivery／Authorized Publisher |
| F10 | 最終 DoD、Handoff、Maintenance | SBL／HGK／原 Owner |

F5 是這次建議新增的決策功能，但真正的 GitHub Push 應發生在 F9 的有權效果階段。

F9 不應強制所有任務都上推 GitHub。

### 5.4 為什麼不能讓 SBL-TPM 自己取代其它系統？

這個分界必須保留。

SBL DOC-01 §C01.2 已明確要求三個 SP 各自獨立、不得共用混合權限，而且 One Core 不得建立第二個 State Store／PI Compiler／Permission Plane。fileciteturn10file6L653-L663

因此：

- SBL-TPM 可以**協調** Commander 類型的工作規劃，但不能冒充 Commander 的權限。
- SBL-TPM 可以請求 HGK 建立 WorkOrder，但不能自行簽發 Native Permit。
- SBL-TPM 可以要求獨立驗收，但不能自行產生正式 Checker PASS。
- SBL-TPM 可以請求 Hermes 派工，但不能建立第二個 Durable Queue。
- SBL-TPM 可以準備 GitHub PR，但不能成為未授權的 Repository Publisher。

**完整自動化工廠應是 Workflow Orchestrator／Lifecycle Coordinator，而不是擁有所有安全權限的超級 Agent。**

這也是單一人類 OWNER 可以實現自治、又不破壞技術分權的關鍵。

---

## 六、雙形態之間應有什麼正式交換契約？

### 6.1 不應靠巨型 Prompt 跨系統傳遞

建議定義一個共用的版本化交換契約。

以下是本次提出的新 ABI 候選，而非現有 Native Schema：

```yaml

schema: SBL.TPM.MissionHandoff@1
mission_id: REQUIRED
owner_ref: REQUIRED

goal:
  source_bound_intent_ref: REQUIRED
  product_kind: REQUIRED
  first_useful_outcome: REQUIRED

contracts:
  source_manifest_ref: REQUIRED
  profile_binding_ref: REQUIRED
  pi_pkg_ref: OPTIONAL_UNTIL_COMPILED
  pd_pkg_ref: OPTIONAL_UNTIL_BOUND
  ecp_refs: []
  tqaep_plan_ref: OPTIONAL
  workpackage_dag_ref: REQUIRED

delivery:
  github_decision_ref: REQUIRED
  local_delivery_allowed: true
  remote_publication_required: POLICY_DEPENDENT

execution:
  effect_classes: []
  requested_scope: []
  native_admission_ref: null
  currentness_required: true

assurance:
  candidate_sha: REQUIRED
  expected_oracles: []
  required_checker_policy_ref: REQUIRED_IF_APPLICABLE

handoff:
  producer: SBL_TPM_SP_OR_NATIVE
  consumer: SBL_TPM_NATIVE_OR_AUTHORIZED_HOST
  contract_version: "1"
  claim_ceiling: EVIDENCED_ONLY
```

它的作用是讓 Portable SP 與 Native Factory 使用同一批工件身份，不需要重新解釋整段聊天紀錄。

### 6.2 必須有版本及來源握手

兩端交換時，應驗證：

`Corpus Version / PIPD ABI / SBL Core ABI / Source SHA / Subject SHA / ProfileBinding / RepoContext Currentness / Permission Scope`

不能只因兩端都叫 SBL-TPM，就假設可以交換工件。

若 Portable SP 的規範版本過期，而 Native Factory 已使用新的 PIPD Schema，應回傳具體 Compatibility Error，再針對受影工件重新編譯。

**不能靜默把過時工件轉成最新正式權威。**

### 6.3 應避免雙重工廠

使用者在 GPT／Codex 已完成的規劃，不應傳給 Native Factory 後又從頭重做全部分析。

Native Factory 應優先：

1. 驗證已有工件的來源、身份及 Currentness。
2. 重用仍合法且未變更的規劃。
3. 只補足 Native 才能取得的環境資訊。
4. 只重新編譯真正受影的 PIPD 工件。
5. 接續執行，不重問 GitHub 偏好或已決定的產品需求。

這才符合你要求的治理收斂和高自動化。

---

## 七、需求三：現有文件對 Native Factory 規劃是否已經完整？

### 7.1 直接證據與缺口

| 能力 | FHS-MSC 藍圖 r2 | FHS-MSC 總討論 | SBL DOC-00～13 | 裁決 |
|--------|--------|--------|--------|--------|
| Portable TPM-SP | 明確有 `sbl-tpm-sp.zip`／`goal.open` | 有相關分權 | 明確有 TPM-SP | **已規劃** |
| Hermes／HGK 內的 TPM 職責 | PLAN Lane／原生 Profile | 有三 Lane／原生交接 | U21：HGK TPM Profile | **已規劃** |
| One Core／Three SP | 明確保留 | 明確保留 | DOC-01／DOC-04 詳定 | **已規劃** |
| 完整自然語言至 E2E | 有產品 FUO 與施工 DAG | 有端到端修復方向 | 有 Build／Test／Review／Ship 等產品要求 | **產品目標已有** |
| 真 PIPD-LS-PKG Compiler | 要求使用原生編譯能力 | 要求來源及 Schema 相容 | 有 PI／PD／ECP／TQAEP 消費規範 | **接口方向已有** |
| 完整 SBL-TPM Native Factory | 有組件與部分 Factory 相關規劃 | 有分散的整合建議 | 有六模組及 HGK Profile | **未找到完整獨立工廠定案 ABI** |
| Portable／Native 兩形態共享工件 | 有相容原則 | 有權責分層 | 有 Typed Graph／Host Projection | **需要正式統一版本契約** |
| GitHub 必檢使用者偏好 | 有受控發布 | 有發布事故與裁決 | 有 QuestionGate、U26／U27 | **已有構件，缺具體組合規則** |
| 未決定 GitHub 時非阻斷 | 有局部 HOLD 原則 | 有受影繼續施工建議 | 有 Quick／Guided／Critical | **需要明確產品條款** |
| 無人值守 E2E 持久執行 | 有 HGK／Hermes 構想 | 已識別 Runtime 缺陷 | 有 WorkOrder／Checkpoint 等需求 | **未完成實測閉環** |
| 獨立驗收與 Release | 有分權規範 | 有真失效與修復方向 | DOC-08／09／12 | **規範存在，效果待驗** |

### 7.2 最有力的既有來源

SBL DOC-01 的 U21～U27 已分別提到：

- HGK TPM Profile 接收 PIPD，重用既有 Document／Intake 工程能力。
- HGK Commander Profile 接收 Prompt／Handoff。
- HGK Challenge／AO Profile 負責相關驗證。
- HGK 調用既有 Fabric FAR/FDA。
- HGK 進行合法施工、Build、Test、Repair、Checkpoint。
- GitHub Source Candidate 與 Evidence Commit 使用各自精確 SHA。

這些要求與你提出的 Native Factory 有高度一致性，但在原設計中仍分屬多個 Owner 與執行模組。

另外，《FHS-MSC\_藍圖\_r2》也明確將 Portable TPM-SP、Commander-SP、Challenge-SP、HGK Harness Adapter、Full SBL Stack 區分成不同可交付工具。

因此，不能簡單宣稱「原文件已經規劃了一個現役、完整、名為 SBL-TPM 的工廠服務」。

**更準確的結論是：原有架構已具備工廠的主要構件與 E2E 產品原意，但欠缺你現在要求的明確部署形態、完整 Factory Orchestration ABI、GitHub 互動決策及實際 Native 閉環。**

### 7.3 建議新增正式上位修訂

不建議把新增要求只放入某一份 Prompt。

應由合法 SBL／PIPD／HGK Owner 依權責正式處理兩項修訂：

**CR-GH-01：GitHub Optional Publication Decision**

受影範圍包括：

SBL DOC-01 QuestionGate、DOC-03 規劃／Handoff、DOC-05 ECP 消費、DOC-09 Evidence、DOC-12 Delivery，以及 PIPD ECP／TQAEP 的適用 Adapter。

主要新增內容為必檢偏好、非全域阻斷、受影發布、遠端效果准入與反證測試。

**CR-TPM-01：Portable TPM-SP／Native TPM Factory Separation**

受影範圍包括：

SBL DOC-01 One Core、DOC-04 TPM／六模組、DOC-05 Native Handoff、DOC-10 Host Consumer、DOC-11 HGK Interface、DOC-12 Packaging 及 PIPD-LS-SP 的有效 Compiler 契約。

主要新增內容為雙形態部署、共享 ABI、能力發現、Native E2E Orchestration、版本相容和真實驗收。

這兩項名稱只是本報告建議的修訂識別碼，**不是宣稱已有正式 CR 已提交或批准**。

---

## 八、結合 B1 經驗，如何防止 Native Factory 再次失效？

建立完整 SBL-TPM Native Factory 時，必須直接吸收 B1 的失效經驗。

| B1 問題 | 對 Native Factory 的強制設計 |
|--------|--------|
| SourceFreeze／Oracle HOLD 阻塞全部施工 | 僅 PARK 受影 DAG 節點，其餘合法工作繼續 |
| 設計包被當作執行授權 | Canonical Artifact、ExecutionAdmission、World Effect 分離 |
| Hermes 尚有 READY 工作卻結案 | 真 Mission Terminal Gate，不以 Package Seal 替代 |
| 需要獨立 Checker 卻只有自評 | 真 Principal、Frozen Candidate、Raw、Checker Receipt |
| GitHub PR 已上推卻被當作完成 | Candidate／Published／Merged／Released 狀態分離 |
| 本地 Root 與 Fabric Mirror 混淆 | Source Projection Map、真 Git Remote、Repo Identity |
| 模型 Required 不等於 Served | 真 Model/Provider/Transport/Principal Readback |
| 新增功能引入更多治理成本 | Affected-only Invalidation、最小合法工作包 |
| Session 結束導致工作遺失 | Hermes 單一 Durable Queue／Lease／Checkpoint／Resume |
| 未決定 GitHub 是否 Push | Publication Decision 獨立於本地施工 |

《FHS-MSC B1》最新 Handoff 仍記錄真 Hermes Executor、Fabric R3、模型 R4 等項目未完成，因而這些只能作為**原生工廠的強制驗收目標**，不能當作已經可用的現役能力。fileciteturn10file2L1-L14

### 8.1 自動化不能因為「等使用者選 GitHub」而停工

若使用者選擇稍後決定，Native Factory 應：

`繼續合法工作 → 完成本地測試 → 保存本地成果 → 建立 GitHub Decision Reminder／Pending WorkItem`

這個 Pending WorkItem 是 Hermes 已有工作狀態的一部分，不應建立另一個平行 Queue。

若正在無人值守執行，卻需要新的 Publisher 授權，系統應保留有型別的等待條件及可交付成果，不得自行假定同意。

### 8.2 單一人類 OWNER 的決策負擔應收斂

對同一個有界 Mission：

- 需求已明確，不重問。
- GitHub 偏好已確認，不重問。
- Repo、Branch、公開／私有範圍已獲有效准入，不因每張子卡重問。
- 相同權限仍有效，執行時驗證即可。
- 超出範圍或發生實質變更，才要求新的批准。

這能同時滿足單一 OWNER 與高自動化要求。

但是使用者選擇「要 Push」不等於賦予永久 GitHub 寫入權限；真正的 Publisher 仍必須驗證憑證、Scope、失效時間及安全條件。

---

## 九、建議的施工計畫與優先順序

### 9.1 不應重新打造完整 SBL

建議沿用前輪決議的施工方式：

**Codex 主導契約、Skill、Compiler Adapter 與 Plugin 實作；Hermes／HGK 負責 Native Factory 的真正執行與自治驗收。**

| 階段 | 工程工作 | 負責 |
|--------|--------|--------|
| P0 | 凍結現有 SBL／PIPD／FHS 規範及兩套 Plugin Baseline | Codex／原 Owner |
| P1 | 新增 GitHub Decision／QuestionGate／交付模式及測試 | SBL-TPM-SP／Codex |
| P2 | 修復 P4 八項已知 ABI、Fixture 與 Planned TQAEP | PIPD Owner／Codex |
| P3 | 完成 Portable TPM-SP、自包含 DOC 與共享 Handoff ABI | SBL／Codex |
| P4 | 建立 SBL-TPM Native Factory 協調模組 | SBL／Hermes／HGK |
| P5 | 接入現役 PIPD Canonical Compiler、Builder、Checker | 各原生 Owner |
| P6 | 完成 GitHub 有權 Publisher、遠端 Readback | Repo Publisher／HGK |
| P7 | E2E Golden Journeys、局部 HOLD、自治續航與交付驗收 | 真 Runtime／Independent Checker |

P1～P3 中不依賴 Native 的修補可以並行，P4 可先建立最小 Factory Interface，不需要等 P3 所有附屬功能完成才開始接線。

### 9.2 最小可用的第一條 Native Factory Golden Journey

建議先選一項全新、小型、非敏感且可逆的 Repository 修改：

1. 使用者以自然語言提出需求。
2. SBL-TPM 確認 Goal／FUO／Source。
3. 產生具名 GitHub Delivery Decision。
4. PIPD 真正編譯 PI、PD、受影 ECP、TQAEP 計畫。
5. HGK 對具體 Repository 修改給予有效准入。
6. Hermes 真 Worker 自動施工、測試、必要時有界修復。
7. 獨立 Checker 對 Frozen Candidate 驗證。
8. 若選擇 LOCAL\_ONLY，提供本地交付並正確完成。
9. 若選擇 GitHub PR，經 Publisher 授權後安全 Push、開 PR、讀回遠端候選。
10. 依不同 Delivery Contract 判定完成，不把 PR 或 CI 成功冒稱 Native Acceptance。

這條 Journey 應至少測試兩次：一次 `LOCAL_ONLY`，一次 `CANDIDATE_BRANCH_PR`。

**兩種路線都應在符合各自授權及驗收條件後，合法到達完成狀態。**

### 9.3 最重要的反證測試

| Test | 注入條件 | 必須通過 |
|--------|--------|--------|
| GH-GATE-01 | 使用者沒有回答 GitHub 問題 | 不 Push、不停本地施工 |
| GH-GATE-02 | 使用者明確不要 GitHub | 不產生未授權遠端效果 |
| GH-GATE-03 | 使用者選擇 GitHub，但 Credential 缺失 | 只阻斷 Publication |
| GH-GATE-04 | 原有決策有效 | 不重問 |
| GH-GATE-05 | 目標由私有 Repo 改成公開 Repo | 重新取得適用批准 |
| GH-GATE-06 | Remote 已 Push、PR 未 Merge | 不宣稱 Release |
| FACTORY-01 | PI Source 尚待裁決 | 只阻斷受影節點 |
| FACTORY-02 | Hermes Worker 意外結束 | 真 Durable Resume |
| FACTORY-03 | Maker 偽造 Checker PASS | 拒收 |
| FACTORY-04 | Package Seal 完成但仍有 READY 工作 | 不結束 Mission |
| FACTORY-05 | Portable SP 工件版本過期 | 不靜默 Native Compile |
| FACTORY-06 | Factory 沒有 Native Publisher 權限 | 不借用 TPM-SP 身份進行 Push |
| FACTORY-07 | 不另裝舊 P4 Plugin | Portable SP 仍可完整查詢內建 DOC 並執行已承諾能力 |
| FACTORY-08 | 同一 Request 分別由 GPT／Codex／Native 使用 | Source／Subject／Decision 身份一致 |

---

## 十、最終工程決議

### 決議一：正式新增 GitHub 必檢／非阻斷／主動詢問 Gate

**採納。**

但規格應是「預設規劃 GitHub 交付選項」，不是「預設自動上推 GitHub」。

使用現有 SBL QuestionGate，加入有版本的 GitHub Delivery Decision，在 PIPD-LS-PKG 的交付規劃與受影 ECP／TQAEP 中建立追溯和測試。

本地施工與遠端交付必須分離；實際 Push、PR、Merge、Release 仍依有效授權進行。

### 決議二：正式拆分 Portable SBL-TPM-SP 與 Native SBL-TPM

**採納。**

SBL-TPM-SP 面向 GPT／Codex，提供完整內建規範、需求分析、產品規劃、PIPD 工件候選及合法交接。

SBL-TPM Native Factory 面向 Hermes／HGK／SBL，協調真正的 PIPD 編譯、WorkOrder、施工、測試、修補、驗收與交付。

兩者共用有版本的規範與 ABI，保留 One Core／Three SP、唯一 PIPD Writer、唯一 HGK Issuer、唯一 Hermes Queue 與真獨立 Checker。

### 決議三：既有上位文件的充分性

**既有文件包含多數關鍵構件及原始設計意圖，但尚不足以宣稱本次三項需求都已完整定案。**

應以有權的正式修訂補齊：

- GitHub Delivery Decision 狀態機及適用性；
- 使用者偏好與真正 Publisher 授權的分界；
- Portable／Native 雙形態的版本、ABI、能力及權責；
- SBL-TPM Factory 的 E2E Mission Contract；
- GitHub LOCAL\_ONLY／PR 兩種 Golden Journey；
- Hermes 真持久執行與局部阻斷的測試。

### 最終建議的目標架構

`User Natural Language → SBL-TPM-SP（GPT／Codex）或 SBL-TPM Native Intake → Shared SBL/PIPD Contracts → PIPD Canonical Compile → HGK Admission → Hermes Build/Test/Repair → Independent Acceptance → Local Delivery 或 Authorized GitHub Publication`

**這才是符合你原意的完整設計：外部有一套可攜式、免重傳 DOC 的 SBL-TPM-SP；內部有一套真正能持續執行 E2E 的 SBL-TPM 工廠；GitHub 是否發布必定納入規劃，卻不讓尚未選擇的遠端效果無故阻斷合法的本地工作。**

本輪裁決屬於來源比對及工程規劃；尚未修改 Plugin、部署 SBL-TPM Native Factory、執行 GitHub Push，亦未取得新的 Native 或 Independent Acceptance PASS。



---
Powered by [ChatGPT Exporter](https://www.chatgptexporter.com)