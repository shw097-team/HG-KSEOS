# SBL-TPM-SP｜Codex 高自動化升級、PIPD-P4 修補與單一 Plugin 正式施工方案

> **Document ID:** `SBL-TPM-SP-CODEX-UPGRADE-20261027-R1`  
> **日期／時區：** 2026-10-27／Asia-Taipei  
> **版本：** r1 — Codex-executable **DESIGN / WORKPACKAGE / TEST CONTRACT**  
> **裁決：** `PLAN_READY_CANDIDATE`；`PLUGIN_PRODUCTION_RELEASE=FAIL-CLOSED`；`NATIVE_SBL_TPM_ACCEPTANCE=NOT_EXECUTED`  
> **一句話：** 保留 SBL One Core 與 PIPD 唯一正式編譯權威，讓 Codex 以受限 Worktree 對既有 `sbl-tpm-sp` **原身份**進行 P4 八技能缺陷修復、自包含全文 DOC、三角色 TPM、GitHub 主動決策 Gate 與無外掛依賴之 Host 驗證；Native SBL-TPM 另以薄型 ABI 交接，絕不以 Plugin 自評冒充 HGK/Hermes 真效果。

**讀者與範圍：** 本檔是給本地 Windows Codex 執行的完整工作規格，**不是**已執行的變更、Owner Ratification、Native Admission、Independent Checker 或正式 Release。推薦使用具本地 Repository 存取能力的 Codex CLI／Desktop，先在**隔離、經授權的工作樹**執行。所有示例路徑必須由真實 `git rev-parse`、Plugin Export、Host 探測綁定；不可假定 `C:\repo` 或任何未驗證的二進位已存在。

**證據語義**：`[N:PIPD-xx:§...]`／`[N:SBL-xx:§...]` = 本輪可讀上位設計規範，生效／Ratification 仍須查核；`[N:FHS-R2:§...]` = FHS r2 上位設計候選；`[H:B1:...]` = 已保存的歷史執行證據；`[P:skill]` = 當前安裝 Skill 文字契約；`[D:UPGRADE]` = 本方案新增待核准的工程提案；`[U:CR-xx]` = MISSING/UNVERIFIED，不能生成正式 PASS。

**不可降低的不變量：** `ONE_CORE_NOT_ONE_PRINCIPAL`、`NO_SECOND_CANONICAL_WRITER`、`NO_SECOND_HERMES_QUEUE`、`NO_SECOND_HGK_ISSUER`、`NO_FAKE_CHECKER`、`NO_SOURCE_NO_NORM`、`SOURCE_HASH_EXACT`、`AFFECTED_ONLY_HOLD`、`NO_BASE_DOC_REUPLOAD`、`GITHUB_DECISION_MANDATORY_PUBLICATION_OPTIONAL`、`NO_AUTO_PUSH`、`PACKAGE_SEAL_NOT_MISSION_COMPLETE`、`B1_FULL_DENOMINATOR_PRESERVED`。[N:SBL-01:C01.2,C08.2A; N:FHS-R2:§5.4,§7.1; N:PIPD-05:ExecutionAdmission; N:PIPD-09:CI/Claim Separation]

---

# 0｜最終工程定位與交付範圍

| 問題／決策 | 本次正式採用 | 施工／發布邊界 | 來源 |
|---|---|---|---|
| 原身份升級 | 使用既有私人 `sbl-tpm-sp` 作產品升級目標；保留原件備份 | 不另建並行同名控制平面；實際 Plugin 更新另需 Owner 授權 | [H:DIALOGUE:§現役 Plugin 0.1.1rc1／P4 0.1.1] |
| 只掛一套 Plugin | 將適用 P4 8 skills、必要 DOC 全文、Schema／Fixture、Reader／Router 打入一個可攜套件 | 不要求每輪重新上傳基礎 DOC，也不要求另裝舊 P4 | [H:DIALOGUE:§單一插件][N:PIPD-08:Progressive Disclosure] |
| 修 P4 不洗白 | Fixture 改動＋語義負例 Validator＋可重播 Diff | 不能將 `expect: ACCEPT` 或 Schema 合法當 Native Compiler PASS | [P:8 skills][N:PIPD-07:Oracle/Fixture] |
| TPM 完整化 | Product／Systems／Technical Program 三角色×T0..T5 共 18 Contracts | `CR-DOC04-STATE-MAP` 未裁決處維持受影 HOLD；不可創造第 4 套 T0–T5 Canonical Enum | [N:SBL-04:C13] |
| GitHub | GHP-01 必檢、主動詢問／QuestionLedger，不決定不阻本地；真 Push 另走 Publisher Admission | 不允許 `LOCAL_ONLY` 自動上推、不預設 Push main；CI≠Release | [N:SBL-01:C08.2A,U26/U27][N:SBL-12:C43] |
| 單人 OWNER | 有效 bounded delegation，不重問來源已知答案 | 獨立技術 Principal、真 Publisher／Issuer／Checker 不因一個人而豁免 | [N:FHS-R2:§6.1,§12.2][N:PIPD-05] |
| 高自動化 | Codex 可連續 Red→Patch→Green、Checkpoint／Resume；Typed Error 只阻受影工作 | Codex 不自行代表 Hermes 真 Durable Executor | [H:B1:RC-01..25] |
| Native Factory 拆分 | `SBL-TPM-SP`=GPT/Codex planning／handoff；`SBL-TPM`=HGK/Hermes 內 Native E2E factory | 本次不把 Native Factory 程式施工列為 Portable Plugin 的 P0 | [N:SBL-01:C01.2,U21–U27][N:FHS-R2:§5.4] |
| 外部工具 | 六 Donor/24 Slot 保留；能重用則重用，不能則禁用／降級 | 不增加必裝依賴；不允許第二 Compiler、第二 Scheduler、第二正式 Checker | [N:SBL-06:C32][N:PIPD-08] |

**完成產品的兩個合格範圍：** `M1 PORTABLE_TPM_QUALIFIED`（單插件無 DOC 重傳／規劃與 PIPD Candidate 正確）、`M2 PIPD_INTEGRATION_QUALIFIED`（真 Compiler／Artifact Reader 有同 SHA 執行證據）。`M3 HOST_QUALIFIED` 是指定 Host 的安裝、生效、觸發、拒收、卸載，不能替其它 Host 簽 PASS。`M4 NATIVE_SBL_TPM_E2E` 為外部產品，非本輪 Portable Plugin 的 Release 先決條件；如果對外承諾 M4 才變為該產品自有硬 Gate。[N:SBL-12:Distribution/Release; H:B1-HANDOFF]

---

# 1｜Authority Stack、Inputs Inventory 與使用規則

**上位裁決排序**：① 原始合法 PIPD Canonical Owner 的 SourceFreeze／Schema／正式 Oracle／Effect Admission；② SBL 上位設計和正式 Owner Ratification；③ FHS r2 設計整合與 B1 受影契約（其自身 Claim Ceiling 不升格）；④ 歷史 r1–r10、對話與既有藍圖的 SUPPORT／Issue Ledger；⑤ GitHub／OpenSSF／外部工具文件的候選 SUPPORT。當來源不一致，建立 `CR_OPEN` 並保留兩條原始版本；不以「較新」「比較合理」冒充原 Owner 裁決。[N:PIPD-00:Authority Router][N:PIPD-01:Canonical State][N:SBL-00:C02][N:FHS-R2:§2.1]

**以下清冊為本輪容器可讀來源的本地位元摘要**，不是 SourceFreeze 亦非 Plugin 已內建；源資料移入本地 Codex 時必須重新計算，與本列 SHA 對照。來源 `SBL-TPM-SP & Native SBL-TPM_升級討論.md` 是前輪 4,706 行歷史決策；`SBL-TPM-SP_Native-SBL-TPM_升級藍圖_r1_2026-10-27.md` 是已交付的上位整合藍圖，兩者不可冒稱 Native Ratification。[D:UPGRADE; H:DIALOGUE]

| Group | 本地來源檔名 | Bytes | Lines | SHA-256 (physical) | 可用性 |
|---|---|---:|---:|---|---|
| HISTORY | `B1指揮施工_總紀錄.md` | 365,435 | 6,855 | `5e83ec59cf226d666146f0d73436cd87b30e35d30918657c6762f04ee576208c` | `FOUND_LOCAL / RATIFICATION_UNVERIFIED` |
| HISTORY | `B1施工_PROMPT.md` | 248,187 | 1,643 | `6f24b2aac28dd8b3aa4823250dc6c18115580f743f141d2db2fb3011e8804409` | `FOUND_LOCAL / RATIFICATION_UNVERIFIED` |
| HISTORY | `B1施工狀況_總鑑定分析.md` | 355,565 | 6,658 | `a7b17816b46d8f4ff38a3b62b336b7d36895d9730e82e6b8f892141f013f4936` | `FOUND_LOCAL / RATIFICATION_UNVERIFIED` |
| FHS | `FHS-MSC_總討論(1).md` | 283,613 | 4,930 | `9ecd1f6f1d9c854206eee4a12519b08e6caf61951a3735502654272416ae0597` | `FOUND_LOCAL / RATIFICATION_UNVERIFIED` |
| FHS | `FHS-MSC_藍圖_r2(2).md` | 1,320,878 | 4,191 | `a80b3b4d7cc93e52a297a3e5176e27f207b36b8cd81a3d5440c70b4a80290ff9` | `FOUND_LOCAL / RATIFICATION_UNVERIFIED` |
| B1 | `FHS_MSC_B1_PIPD_LS_PKG_00_GOVERNANCE_AND_CONTROL(1).md` | 10,324 | 111 | `3096e98096ad48b3b3cfda07c6075ccffba8b44c1851a804d63f0ab103aef576` | `FOUND_LOCAL / RATIFICATION_UNVERIFIED` |
| B1 | `FHS_MSC_B1_PIPD_LS_PKG_01_DOC_B1_PI(1).md` | 53,244 | 341 | `e1d8931c036a1e9dc97f79a3d0d00f151ea5a29dc81fb3d7aa488d5446d7b666` | `FOUND_LOCAL / RATIFICATION_UNVERIFIED` |
| B1 | `FHS_MSC_B1_PIPD_LS_PKG_02_DOC_B1_PD(1).md` | 62,807 | 1,289 | `8e15b92a69302bbb0f9a6352f80c9687fdfb3a217006703a87b3ba559f42eb2b` | `FOUND_LOCAL / RATIFICATION_UNVERIFIED` |
| B1 | `FHS_MSC_B1_PIPD_LS_PKG_03_DOC_B1_OPS_ECP(1).md` | 24,829 | 756 | `54a17818473f2a4b7c4f0f8f504bc96e4e1450540facfd30cf38234fa89e8b8a` | `FOUND_LOCAL / RATIFICATION_UNVERIFIED` |
| B1 | `FHS_MSC_B1_PIPD_LS_PKG_04_DOC_B1_DEV_ECP(1).md` | 9,287 | 101 | `7a1e44dfd91bd24011c019f3ff73446e6cebf4b7847d7220f7c78dc25927def5` | `FOUND_LOCAL / RATIFICATION_UNVERIFIED` |
| B1 | `FHS_MSC_B1_PIPD_LS_PKG_05_DOC_B1_TQAEP(1).md` | 455,090 | 12,056 | `1e09126f0c8e92fcd6e8531072a3f1f3033d82a671c2b4bb62c9916e675b7127` | `FOUND_LOCAL / RATIFICATION_UNVERIFIED` |
| B1 | `FHS_MSC_B1_PIPD_LS_PKG_06_PRODUCT_COVERAGE_AND_R15(1).md` | 859,287 | 6,919 | `f929d9cffd462d23bbdb52171f72a450e96e59c8333bc05ebd739a2d38338337` | `FOUND_LOCAL / RATIFICATION_UNVERIFIED` |
| B1 | `FHS_MSC_B1_PIPD_LS_PKG_07_NATIVE_TOOLCHAIN_EXACT_USAGE(1).md` | 19,392 | 141 | `d1e0283200ad57cf1a3a1fc62bc09c6980ff118d4b7af4401d011ea87a009ea7` | `FOUND_LOCAL / RATIFICATION_UNVERIFIED` |
| B1 | `FHS_MSC_B1_PIPD_LS_PKG_08_GOLDEN_WORKORDERS_E2E(1).md` | 6,741 | 70 | `bc12a5fca45e4f68c1b1a4772b00ca72e0c07be8293527bbaafceadc7347290f` | `FOUND_LOCAL / RATIFICATION_UNVERIFIED` |
| HISTORY | `FHS_MSC_B1_Task_Handoff_Report_v1_2026-10-27.md` | 80,850 | 734 | `aa006bc849c5bb6404265de6a28678e0a4ed8b75b13521b39d5dcf28fc07162d` | `FOUND_LOCAL / RATIFICATION_UNVERIFIED` |
| PIPD | `PIPD_LS_DOC-00_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md` | 251,982 | 2,292 | `be3a672ec20aa0e6b5e0e35097fc08de749bfe7f59f827d18e38aef67dd68ea4` | `FOUND_LOCAL / RATIFICATION_UNVERIFIED` |
| PIPD | `PIPD_LS_DOC-01_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md` | 177,451 | 2,592 | `b753f2e5cdd5598a818f8a113d57b7f815aeb3f1dfa061ce74c76bb3553ac8c7` | `FOUND_LOCAL / RATIFICATION_UNVERIFIED` |
| PIPD | `PIPD_LS_DOC-02_2026-10-07_r2_HIGH_RETENTION_AUDIT_PATCHED_FULL_REPAIR_FULL_SUBSTANTIVE_BODY (1).md` | 1,306,240 | 18,413 | `a021998dd3b63015e89af1dd40e0b413744a69b872da46c6bf5f4d92f7f23d0b` | `FOUND_LOCAL / RATIFICATION_UNVERIFIED` |
| PIPD | `PIPD_LS_DOC-03_2026-10-07_r2_AUDIT_REPAIR_FULL_SUBSTANTIVE_BODY.md` | 454,167 | 1,911 | `d89d82dcd2c8603ec6b86c5ec8c40845e4594bc181adf5272bd48a3de7c88f0f` | `FOUND_LOCAL / RATIFICATION_UNVERIFIED` |
| PIPD | `PIPD_LS_DOC-04_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md` | 181,988 | 4,052 | `fa64d84da3d747b183e4affff62f4d2fb86c80bb5075f5dd933c09b20caeddcf` | `FOUND_LOCAL / RATIFICATION_UNVERIFIED` |
| PIPD | `PIPD_LS_DOC-05_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md` | 227,894 | 3,946 | `7b40584540c162cda6debfd09a4c04321416706acdb03a7a3c2b41383dc585f4` | `FOUND_LOCAL / RATIFICATION_UNVERIFIED` |
| PIPD | `PIPD_LS_DOC-06_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md` | 405,028 | 3,790 | `20e44ea4dd8e53c9b0a076ce861136bbea86f52687019307f6e995cd9079d303` | `FOUND_LOCAL / RATIFICATION_UNVERIFIED` |
| PIPD | `PIPD_LS_DOC-07_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md` | 689,563 | 12,915 | `a68dae1c3670d07bcfa3476a1e37463c534594df5cd65d8dab0dca064b5a9fc1` | `FOUND_LOCAL / RATIFICATION_UNVERIFIED` |
| PIPD | `PIPD_LS_DOC-08_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md` | 197,972 | 2,501 | `e46caa7e440392a6cfa7a86421aead5bce8a2a229fec97b133429db6b6748e42` | `FOUND_LOCAL / RATIFICATION_UNVERIFIED` |
| PIPD | `PIPD_LS_DOC-09_2026-10-07_r2_HIGH_RETENTION_AUDIT_PATCHED_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md` | 144,948 | 2,451 | `eaf0aefe2b4711c140fc3274223d88fdc38ad4ec2b7184f756a0f2471f3b0b54` | `FOUND_LOCAL / RATIFICATION_UNVERIFIED` |
| HISTORY | `SBL-TPM-SP & Native SBL-TPM_升級討論.md` | 241,225 | 4,706 | `92305bce348b0dc4af27f9cf56432ba195b2ad5def3150440f0a61450c0b15c4` | `FOUND_LOCAL / RATIFICATION_UNVERIFIED` |
| BLUEPRINT | `SBL-TPM-SP_Native-SBL-TPM_升級藍圖_r1_2026-10-27.md` | 108,939 | 1,303 | `76277ebeba22bd20a1a2204ca8c5d3893938e4fb3e3d410d08a7a9ff9b2412a7` | `FOUND_LOCAL / RATIFICATION_UNVERIFIED` |
| SBL | `SBL_PIPD-LS-PKG_DOC-00.md` | 465,363 | 1,591 | `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01` | `FOUND_LOCAL / RATIFICATION_UNVERIFIED` |
| SBL | `SBL_PIPD-LS-PKG_DOC-01.md` | 1,041,962 | 4,938 | `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f` | `FOUND_LOCAL / RATIFICATION_UNVERIFIED` |
| SBL | `SBL_PIPD-LS-PKG_DOC-02.md` | 1,148,207 | 11,084 | `4ff0cda5ab00ba5f577151e5b004d2167d933e912e302c9e3529b237ccb9e035` | `FOUND_LOCAL / RATIFICATION_UNVERIFIED` |
| SBL | `SBL_PIPD-LS-PKG_DOC-03.md` | 1,704,253 | 4,851 | `ea69e1d3718ed86aecd74a3ebcc933960eacc30b586ab80fcb9f733037e33476` | `FOUND_LOCAL / RATIFICATION_UNVERIFIED` |
| SBL | `SBL_PIPD-LS-PKG_DOC-04.md` | 618,110 | 3,036 | `ee90cb1c86f6f7350c11c9c962233a89b035ca41ff82c8968f7968608fc6f6e0` | `FOUND_LOCAL / RATIFICATION_UNVERIFIED` |
| SBL | `SBL_PIPD-LS-PKG_DOC-05.md` | 2,382,349 | 7,888 | `3b47a0b6224b1984a4047cf53aac5ac50615c93a560fea46e1b43d079a5d9f27` | `FOUND_LOCAL / RATIFICATION_UNVERIFIED` |
| SBL | `SBL_PIPD-LS-PKG_DOC-06.md` | 1,554,880 | 2,858 | `64ea4977dab3093301f82dc7469413cc754998fc53946467842e06d83645102b` | `FOUND_LOCAL / RATIFICATION_UNVERIFIED` |
| SBL | `SBL_PIPD-LS-PKG_DOC-07.md` | 1,265,128 | 3,620 | `a366d3783c82089c5593ffabb0704d8507632cce45622684f7a0186f2ae310f8` | `FOUND_LOCAL / RATIFICATION_UNVERIFIED` |
| SBL | `SBL_PIPD-LS-PKG_DOC-08.md` | 925,526 | 11,139 | `c7029c1ff07abe3135d33d3abf858a5fecedd911b494cd69c16eb1ddb8158288` | `FOUND_LOCAL / RATIFICATION_UNVERIFIED` |
| SBL | `SBL_PIPD-LS-PKG_DOC-09.md` | 904,598 | 3,978 | `6450f7c15915ec8b304f4e5fd4093ea707434db8bae9d2bb6e66c30ab6eed2e1` | `FOUND_LOCAL / RATIFICATION_UNVERIFIED` |
| SBL | `SBL_PIPD-LS-PKG_DOC-10.md` | 1,397,936 | 3,888 | `a64aa21c977334dd74d660a86377ee10c4d329aa5fde0dae25ff81a3e69e8d8f` | `FOUND_LOCAL / RATIFICATION_UNVERIFIED` |
| SBL | `SBL_PIPD-LS-PKG_DOC-11.md` | 1,831,131 | 5,005 | `12f8705d780b76f264457c194a6ff359da8d74b5d6d8c83fa245b74d2a37508e` | `FOUND_LOCAL / RATIFICATION_UNVERIFIED` |
| SBL | `SBL_PIPD-LS-PKG_DOC-12.md` | 982,931 | 7,940 | `d1e470d82ca14319582cb8947aa52007927aa38e726249b1430804cfe8c8ca56` | `FOUND_LOCAL / RATIFICATION_UNVERIFIED` |
| SBL | `SBL_PIPD-LS-PKG_DOC-13.md` | 1,251,068 | 3,814 | `7cc0c8b17311130c875910b2548b93c28bd4e1c8ee04d300f85fc33d4c09beb1` | `FOUND_LOCAL / RATIFICATION_UNVERIFIED` |

**安裝 P4 skills 源契約**（本輪已直接重讀）：`skills://plugins/pipd-ls-sp-public-skills-p4/{pipd-route-intake,pipd-authority-source,pipd-profile-tailor,pipd-pi-compile,pipd-pd-bind,pipd-execution-contract,pipd-assurance-tqaep,pipd-package-project}/skill.md`；其中各 `references/contract.md`、`schemas/{input,output}.schema.json`、`tests/cases.yaml` 為施工必需 Source。現役 SBL Thin Skill：`skills://plugins/sbl-tpm-sp/tpm-sp/skill.md`，目前只定義 JTBD/FUO/MVP/Non-goals/Source Ledger/Bounded Handoff，`claim_ceiling: HOST_PENDING`。[P:8 skills][P:tpm-sp]

**完整來源閉包**：Core 24 冊（PIPD 10＋SBL 14）必須於 Release 全文打包；其適用的上位 GRP、Portable Mount Profile、Schema/Oracle Ratification 若本輪缺原件，登記 `CR-SOURCE-TRANSITIVE`，不要用零上傳要求反推其存在。FHS／B1／對話／本藍圖應分為 `HISTORY_SUPPORT`，可封存作 RCA 測試，但不能作新的正式 Writer。若因封裝平台容量或法規授權不可全內建，則**不得宣稱** `ZERO_BASE_DOC_REUPLOAD_PASS`；改為內含必要 Core＋受權隨附離線資料包的**單安裝物**，同樣須實際 Host 測試。[N:PIPD-08][N:SBL-10; H:UPGRADE-BLUEPRINT:§1]

**SBL 的三 SP 正式分離：** Portable TPM 不具 `product.write`、`challenge.sign`、HGK `permit.issue`；產品／系統／Program 三角色是職能視角，不代表不同 OS Principal。B1 `sbl-commander-sp` 禁用規則不得經 `tpm-handoff` 偷用它。[N:SBL-01:C01.2][N:SBL-04:C12/C13][H:B1-08]

---

# 2｜B1＋P4 的整體 RCA 與隔離修復策略

## 2.1 可重播根因樹

```text
症狀：B1 r1–r10 有部分 Patch、PR、Unit Test，仍無 Native E2E 完工
 ├─ 上游 P4：正向 Fixtures Hash/Subject/Receipt 漂移；12↔9 Profile 失真
 │   ├─ Planned TQAEP 在輸入即索取真 Checker Receipt（時序衝突）
 │   ├─ DOC-03 Oracle Locator／DOC-07 Writer 未正式同構
 │   └─ 只用 JSON Schema，沒有顯式 Trusted Artifact Resolver
 ├─ 中游 B1：完整大分母→每輪 Runtime 錯誤投影
 │   ├─ 27 Atoms、31 WO/OBS、120+124 TQAEP、949 IDs 不等於 949 READY 工作卡
 │   ├─ READ_ONLY / DEV Repo / OPS Host 混入相同 Gate
 │   └─ Oracle/HGK Native HOLD 被錯誤擴大成全域停工
 └─ 下游 HGK/Hermes：真 Receiver／Executor／Scheduler Stop Controller 未閉合
     ├─ Seed/Package Seal/Report 被當 Mission 完成
     ├─ SharedSpine 有局部耐久測試，真 Executor/Revocation/3 GWO 未驗
     └─ R3 Fabric Loaded、R4 Model Served、G-B 外援撤銷後續行仍缺真 Raw
```

**因果強度**：Fixture 欄位矛盾是直接可重播的**靜態事實**；無法在未跑真正 Validator 前推定 Runtime 已誤放行。r10 `NOT_RUN` 非「實測失敗」；PIPD 為治理過重的上游促因，不是 r10 Hermes 提前結案的唯一直接根因。[H:DIALOGUE:§P4 Fixture/因果 §4/§7][H:B1-HANDOFF:§0,§2]

## 2.2 分母及有效法位必保留

| 資產 | 來源分母／狀態 | 新版 Plugin 必須如何使用 |
|---|---|---|
| P4 Native Req | 5 大類（INTENT、KNOWLEDGE、VERIFY、DELIVER、GOVERN） | 保留原有 5 類；Sidecar 另保留各專案完整 Atoms |
| B1 r3 | 27 Atoms、31 WO/OBS、120 parent、124 child、38 nodes、949 IDs、192 Cells、81 Assets、3 GWOs | 存 `ObligationLedger`，不可全部轉成 Runnable Queue |
| B1 r10 | 1,565 IDs（Required 625、Conditional 285、Deferred 655） | 只有適用 Required＋已觸發 Conditional 可成 WorkOrder；Deferred 不消失 |
| B1 r10 觀察 | `PARTIAL_WITH_EXPLICIT_HOLDS`；0 per-ID Native PASS；T1 inherited PASS；T2/R3/R4/G-A/G-B NOT_RUN 或 HOLD | 保留狀態，不由本次 Plugin 施工自動改寫 |

[N:B1-00/01/05/06/08][H:B1-HANDOFF:§0,§2,§4][H:UPGRADE-BLUEPRINT:§3.3]

## 2.3 Codex 修復 vs 外部 Native 拆分

- **可直接修的 Portable Plugin 缺陷：** Corpus、Skills/Fixtures、cross-object validator、Profile/Oracle compatibility request、TQAEP Plan、Quick/Guided/Critical、18 Stage Contracts（未決部分保留 CR）、QuestionGate、GitHub DeliveryDecision、Typed Failure、Plugin packaging、Host smoke。
- **Plugin 只能防止假成功／輸出合法請求：** 真 PIPD Compiler、Native RepoContext、HGK Signer／Receiver、Hermes READY/Lease、Fabric Loaded、模型 Served、Remote GitHub Publisher、獨立 Checker。這些在 Portable 測試中應 `NO_CAPABILITY`／`NOT_RUN`，不可預填 PASS。[N:SBL-01:C01.2][N:FHS-R2:§5.4][H:B1]
- **修復治理過度的原則：** 將 `FULL_OBLIGATIONS`、`CURRENT_APPLICABLE_WORK`、`FORMAL_ACCEPTANCE_EVIDENCE` 分開；保持必需安全 Gate，不以全面關閉 Validator 達成低阻力。每個 Fail 提供精確 `affected_scope`、`allowed_next_action`、`resume_predicate`。[N:PIPD-00:No global waterfall][N:PIPD-05:Effect][N:PIPD-08]

---

# 3｜PIPD 八技能與 DOC-00～09：逐缺陷修補合同

## 3.1 八技能的合法輸入、修補方式、交付驗證

| 原 Skill | 原本保留的權威能力 | Codex 必須修補／增加的 Adapter | 效果邊界／Test |
|---|---|---|---|
| `pipd-route-intake` | 帶來源的 Goal → content-addressed IntentCard | 保留五種 Native Req，`OriginalAtomSidecar@1` 對專案完整原子、來源、ACC+NEG 作無損投影 | 零 Source 或越界 Locator 必拒；不得從沒有來源的散文直接正式 PI [P:route-intake;N:PIPD-02] |
| `pipd-authority-source` | 真 Digest、Locator、SourceFreezeManifest | `AuthorityResolver` 必驗 Provenance、Owner、SourceRank、Currentness、Supersession；Family Code 不是權限 | 偽稱 F1/R1 或 Source SHA 不一致拒收，正式 SourceFreeze 需原生 Writer [P:authority-source;N:PIPD-01/04] |
| `pipd-profile-tailor` | 三 Profile、九 Context Axes、不可降級 Veto | 新 `RiskMapping@1` 承接 DOC-06 十二分數軸及 Mandatory ASSURED Veto；明示 lossy projection | Privileged/Autonomous 高風險不能被 9 軸低計數降級；未知風險 `HOLD_FOR_PROFILE_OWNER` [N:PIPD-06:12-axis;P:profile-tailor] |
| `pipd-pi-compile` | Intent＋Profile→PI/Atoms/Trace | 信任 `ProfileBindingRef` Resolver、Same-Atom SHA Join、合法 DOC-07 OracleBinding/legacy DOC-03 Locator | 原 `POS-001` WrongHash 必被拒；PI 不靠文本猜 Profile [P:pi-compile;N:PIPD-07] |
| `pipd-pd-bind` | 真 RepoContext 的 PI→PD late bind | Root/HEAD/TrackedFiles/WriteScope Freshness，拒絕 symlink/junction escape，保留 Repo-only | Host READ_ONLY/OPS 不假造 RepoPD；Stale 不洗白 [P:pd-bind;N:PIPD-03/05] |
| `pipd-execution-contract` | 受治理 Repo Build ECP，token、at-most-once、rollback | 修 Fixture Subject；依原 Owner 的 `EffectAdapter` 分離 Repo/Host/User/Remote；不改同版 P4 Schema | `POS-002` 和 `EDGE-001` 跨 PD Subject 負例；Native permission 非文字符號 [P:execution-contract;N:PIPD-05] |
| `pipd-assurance-tqaep` | 真 Checker 後的 Live Assurance | 建立獨立 `PlannedTQAEP@1` 不需要執行收據、不輸出 PASS；原 Live Reader 必真 receipt／principal | `POS-002` receipt mismatch 拒收；兩個模型名稱≠SoD [P:assurance-tqaep;N:PIPD-03/07] |
| `pipd-package-project` | ClaimCeiling、EvidenceExpectation、TraceClosure | 真 `ArtifactGraphResolver`、跨 Hash Join、引用數與實際 Edge 同源、合法 Claim Transition | `EDGE-001` 0→2 Edge 須 resolver 證據，否則 FAIL/HOLD；Package≠MissionComplete [P:package-project;N:PIPD-04/09] |

**關鍵工具現況：** P4 八個 `skill.md` 是 *tool contract*，不是本輪已證明可供 Codex 使用的本地編譯 Binary。本地 Codex 的第一項工作是探測 **真 source tree / parser / CLI / binary / package path / runtime version**；不能根據 P4 的示例憑空建立「Native PI-PKG」或假 `checker_execution_receipt`。本地 CLI 缺席時允許 Repair Candidate、Schema Regression、失敗收斂，正式 Compiler Gate 保留 HOLD。[P:8 skills;H:B1-07;N:PIPD-09]

## 3.2 P4-01～P4-18：Defect → 修復面 → POS/NEG 閉合

| Defect | 可定位的問題 | 最小變更面（候選） | 正向 Exit／負向拒收 | 來源 |
|---|---|---|---|---|
| P4-01 | PI POS-001 Atom Hash 與 Trace `to_hash` 不同 | `skills/pipd-pi-compile/tests/cases.yaml`; `scripts/semantic_validate.py` | 同 Subject Hash 閉合；Mutant mismatched Ref FAIL | [P:pi-compile/cases.yaml;H:DIALOGUE:§P4-F01] |
| P4-02 | ECP POS-002 輸入 PD `PD-b5b...`，輸出 `PD-4bfd...` | `skills/pipd-execution-contract/tests/cases.yaml` + Subject Join | 跨 PD Subject FAIL | [P:execution-contract/cases.yaml;H:DIALOGUE:F02] |
| P4-03 | TQAEP POS-002 receipt `b2c1` vs `a17f` | `skills/pipd-assurance-tqaep/tests/cases.yaml` + Receipt Ref Validator | receipt 跨操作、Epoch/Subject 不同 FAIL | [P:assurance-tqaep/cases.yaml;H:DIALOGUE:F04] |
| P4-04 | Package EDGE-001 `trace_edges=0` 卻輸出 2／PASS，缺 graph provenance | `ArtifactGraphResolver`; Cases 的 graph fixtures | 若 resolver 另算出 2，須有合法版本綁定；否則 HOLD | [P:package-project/cases.yaml;H:DIALOGUE:F05] |
| P4-05 | PI／ECP Scalar Refs 無法自行推得完整內容 | `ArtifactResolver@1`（Reader） | ID/SHA lookup、Currentness、Exact Subject；無外部 Registry ⇒ HOLD | [P:pi-compile/execution-contract;N:PIPD-04] |
| P4-06 | DOC-06 12 風險軸與 P4 9 context 軸非等價 | `RiskMapping@1`＋lossiness＋veto | 12-axis high-risk ≥ ASSURED；資料不足 ⇒ HOLD | [N:PIPD-06;P:profile-tailor] |
| P4-07 | DOC-03 `DOMAIN_ORACLES` 與 DOC-07 Oracle Writer 權責歧義 | `OracleBinding@1`、legacy locator bridge | 無正式 CR-ORACLE-001 Ratification ⇒ affected PI/HOLD | [N:PIPD-03/07;N:FHS-R2:§5.1] |
| P4-08 | Planned TQAEP 先要求 Checker Receipt | `PlannedTQAEP@1` new adapter only | `PLANNED != VERIFIED`；無 Receipt 仍可作 Plan，不得 PASS | [N:PIPD-03:§TQAEP;P:assurance-tqaep] |
| P4-09 | Repo ECP `residue_scan`、固定 Rollback 不適用所有效果 | `EffectClassRouter@1` | Repo ECP 留在 Repo；Host User Remote 各找原有合法 Adapter | [N:PIPD-05;P:execution-contract] |
| P4-10 | `maker!=checker` 字串不足 SoD | Checker Principal／Protected Verifier Reader | Maker 可修改 Checker Evidence ⇒ 拒 Independent PASS | [N:PIPD-07;H:B1-RCA] |
| P4-11 | F1/R1 Family Code 可能被冒用 | `AuthorityRegistryAdapter` | Family 僅分類，無 Owner Hash 即拒 Authority | [P:authority-source;N:PIPD-01] |
| P4-12 | `provider_off_required` 可省略 | RiskInput/PolicyTruth `required` 投影 | 應 Required 卻 missing 時不得當 false | [P:profile-tailor/input.schema;N:PIPD-06] |
| P4-13 | 八 Skill 缺統一 typed ErrorEnvelope | `PIPD.ErrorEnvelope@1` | `first_fail`+`affected`+`resume_predicate`，B 工作不被 A HOLD | [P:8 output schemas;N:FHS-R2:§12] |
| P4-14 | JSON Schema 不保證 cross-object 語義 | 獨立、可測 `semantic_validate.py` | Schema Valid＋Wrong Hash ⇒ FAIL | [N:PIPD-07;H:DIALOGUE:§Schema] |
| P4-15 | Claim/Lifecycle/Hermes State 混同 | `ClaimStateCrosswalk` 只讀投影 | Package Seal 絕不設 Hermes Mission Complete | [N:PIPD-01/09;H:B1-HANDOFF] |
| P4-16 | Skills 存在被冒稱 Compiler Loaded | Tool Capability Probe／Runtime Receipt | 探測／Invoke／Readback 五段缺任一不 PASS | [P:8 skills;H:B1-07] |
| P4-17 | Source Snapshot 被當正式 SourceFreeze | `SourceStatus`／OwnerApproval Reader | `FOUND_LOCAL != RATIFIED`（不推定） | [N:PIPD-01;N:FHS-R2:§2] |
| P4-18 | Local Packager 被當正式 Host Portal | `HostQualificationMatrix` | 真 install/load/invoke/deny/uninstall 逐 Host；無收據不可 Release | [P:tpm-sp;H:DIALOGUE:§Plugins] |

**欄位矛盾須保留 Errata 來源版本**：不要直接把原錯 POS Fixtures 刪掉，應把原檔固定到基線、導入改正的 POS，並加入從原錯案例衍生的 NEG Mutant，記錄 Input SHA、Output SHA、Verifier/Compiler Version、first_fail。P4-04 的 0→2 是缺乏 resolver 證據的**疑點**，不可在未解析 graph provenance 前斷定 Runtime 必然違規。P4-06 `STANDARD→L1` 亦需完整 Profile Resolver 才能裁決。[H:DIALOGUE:§P4-F05/F06]

## 3.3 PIPD DOC-00～09 的保留與收斂（不可抽掉必要安全 Gate）

| DOC | 必須保留的 Canonical 職責 | Portable Plugin 消費與減負方式 | 實際高風險拒收 |
|---|---|---|---|
| DOC-00 | Router、Operator Entry、受影最小合法切片 | 按任務選最小入口，不重跑未受影生命周期 | Second Route／Unbounded Work |
| DOC-01 | Lifecycle State、Authority、Claim | PIPD Lifecycle 只由 Reader 映射 | Wrong State Promotion |
| DOC-02 | PI、REQ、TechnologyAdmission | 5 Native Category＋原專案 Sidecar，原子不掉失 | Missing Atom／No Source |
| DOC-03 | Repo-Bound PD／Construction/PreDev | 只對真 Repo Write 綁 PD | Faked RepoContext／Stale HEAD |
| DOC-04 | Trace/Evidence/Identity | Cross-object Hash/Subject/Graph Validator | Wrong Hash/Subject |
| DOC-05 | Effect Permission/ExecutionAdmission | READ_ONLY vs REPO vs HOST vs USER vs REMOTE，依真 Owner Adapter | Unauthorized Mutation／Unknown Effect Retry |
| DOC-06 | LITE/STANDARD/ASSURED、12-axis/Veto | 風險事實與有效 Profile 先判定；Small Work 不全域升 ASSURED | Demotion／Missing Risk Fact |
| DOC-07 | TEST/ORACLE/FIXTURE Writer | 正式 OracleBinding、POS/NEG/Security Fixture | Fake Oracle／Self-signed Receipt |
| DOC-08 | Skills/Host Progressive Disclosure | L0 Router→L1 Relevant Ref→L2 Exact Clause；不載全部 24+ | Unbounded Context／Source Drift |
| DOC-09 | CI/Release/SupplyChain/Claim | Package、CI、Host、Native Acceptance 不共用 PASS | PR/CI→Native Claim Inflation |

[N:PIPD-00..09;H:UPGRADE-BLUEPRINT:§12.4]

## 3.4 SBL DOC-00～13 的逐冊責任收束

| DOC | 本輪 Plugin 工作內容（絕不變成第二 Canonical Writer） | 驗收責任 |
|---|---|---|
| 00 | Authority Router、Source Manifest、正式 Claim 限制 | SBL Source Reader |
| 01 | JTBD、FUO、QuestionLedger、One Core/Three SP、U01–U27、GH Decision | TPM Product Role |
| 02 | Source Clause、Risk/Requirement、Original Atom Trace | Source+PI Adapter |
| 03 | SPEC、PI/PD 投影、Ticket/WorkPackage 候選 | TPM Systems/Program |
| 04 | C12/C13；Product/System/Program×T0–T5 18 Contracts；StageMap Conflict | SBL Product Owner |
| 05 | PIPD Effect、Repo/Host Handoff、Dev/Ops 分離 | Domain Owner |
| 06 | Technology Admission、6 Donor 24 Slot、NoFit/Provider-off | System Engineer |
| 07 | Security、Standing Owner Delegation、真正 Machine SoD | Security Owner |
| 08 | POS/NEG、Independent Checker Request | Assurance Reader |
| 09 | Raw Evidence、Trace、Claim、Repair Cone | Evidence Index |
| 10 | Host、Skills、JIT Context、Plugin Trigger、Uninstall | Host Loader |
| 11 | HGK/Fabric/SBL Typed Native Handoff，不簽 Permit | Native Receiver |
| 12 | License、BOM、CI／Trusted Verifier、Release、Rollback | Authorized Publisher |
| 13 | GJ01/02/03、Dogfood、受影回歸與演化 | Product Acceptance |

[N:SBL-00..13; N:SBL-04:C12/C13; N:SBL-06:C32; N:SBL-12:C43]

---
# 4｜B1 RC-01～RC-25 全因果閉合：避免 PIPD 再度造成高自動化卡點

本表沿用前輪分析定義的 25 個 **分析用 RC 索引**，不冒稱它們已由 B1 Native Issue Tracker 正式編號。`P`=Plugin 直接修復，`I`=Plugin 產生正確接口但外部需實測，`N`=Native 端 Owner 真修復；**只有 P 類可列本輪 Codex Plugin 的 Release Blocking 修補**，I/N 的正式 Native PASS 另歸外部產品驗收。[H:B1-RCA;H:UPGRADE-BLUEPRINT:§3.2]

| RC | B1 症狀／根因 | 本輪具體補救、Codex 更動 | 屬性 | 反證測試 | 原始定位 |
|---|---|---|---|---|---|
| 01 | Hermes 真 Executor、跨 Session 續航未證 | `MissionHandoff@1` 帶 `resume_predicate`；不得自行建立 Worker | I/N | `B1-REC-01`：無 Executor 仍 Claim Native PASS 必拒 | [H:B1-HANDOFF:§0,§2] |
| 02 | READY 未耗盡卻 Report/Seal 結案 | `PackageStatus!=MissionStatus` 靜態 crosswalk | I/N | `B1-REC-02`：READY>0 拒 `MISSION_COMPLETE` | [H:B1-RCA:r10停止] |
| 03 | 某 Native HOLD 變成全域 HOLD | 有向 DAG `affected_subjects`／局部 PARK | P/I | `B1-REC-03`：A HOLD 不影響 B/C | [N:FHS-R2:§3.3;H:B1-LOG] |
| 04 | Bootstrap 修 Issuer 卻要求完整 Issuer Permit，形成依賴循環 | `READ_ONLY/DEV_REPO/OPS_HOST` 分層；明確 Bootstrap External Admission | P/I | `B1-REC-04`：無 Repo Permit 禁寫，但唯讀照行 | [N:PIPD-05;N:FHS-R2:§7] |
| 05 | HGK User Trust 尚未接 Receiver | `NativeCapabilityProbe`, `NO_ADMITTED_ROUTE`，不虛報有效 | N | `B1-REC-05`：只看到 Trust 文件不可簽发 Admission | [H:B1-HANDOFF:§2] |
| 06 | Maker/Signer/Checker 可能同 SID／同 Key | `PrincipalSeparationRequirement` 只輸出期望 | I/N | `B1-REC-06`：名稱不同、同權限拒 Independent PASS | [H:B1-RCA;N:SBL-07] |
| 07 | B1 DESIGN Candidate 被當成 Native 交付 | Claim Ceiling 強類型，`DESIGN≠ADMITTED` | P | `B1-REC-07`：Candidate 轉 Native PASS 拒收 | [N:B1-00:task_kind/claim_ceiling] |
| 08 | 缺被阻斷工作與可續工作的獨立依賴 | `AffectedWorkGraph`, FirstFail→NextLegalAction | P/I | `B1-REC-08`：局部恢復不全量重編 | [H:B1-LOG;N:FHS-R2:§12] |
| 09 | Fabric Stage/Active/Loaded/Consumer 混用 | EvidenceExpectation 逐 World Effect 分開 | I/N | `B1-REC-09`：只 Stage 不准 Loaded | [H:B1-HANDOFF:R3] |
| 10 | Required Model Pin 不等於實際 Served | Model/Provider/Transport/Method Identity 型別 | I/N | `B1-REC-10`：配置 Pin 不當 R4 PASS | [H:B1-HANDOFF:R4] |
| 11 | Oracle DOC03/DOC07 ABI 不一致 | `OracleBinding@1`、Legacy Bridge＋CR | P | `B1-REC-11`：錯 Writer Locator HOLD | [N:PIPD-03/07;N:FHS-R2:§5.1] |
| 12 | DOC06 12 risk axes→P4 9 axes 語義遺失 | `RiskMapping@1` 不降級、loss report | P | `B1-REC-12`：高權限自動化必 ASSURED/HOLD | [N:PIPD-06;P:profile-tailor] |
| 13 | Planned TQAEP 被當 Live Checker PASS | `PlannedTQAEP@1` 與獨立 Live | P | `B1-REC-13`：無 Receipt 只能 PLANNED | [N:PIPD-03;P:assurance-tqaep] |
| 14 | PIPD Stage-C WriteSet CI 修改受保護 ADR | 嚴格 `git diff --name-only`、Allowlist，不放寬 Check | I | `B1-REC-14`：ADR0008/0009 越界必 FAIL | [H:B1-RCA:Stage-C;N:PIPD-09] |
| 15 | B1 DOC08 GWO 與 Commander 禁用矛盾 | `HandoffCandidate` 只導向批准的非 Commander ABI | P/I | `B1-REC-15`：找不到合法 Receiver，回 NO_ROUTE | [N:B1-08;H:B1-HANDOFF] |
| 16 | ECP effect retry 與普通 Red/Green 修補迭代混淆 | Diagnostic／Repair Iteration／World Effect Attempt 三帳 | P | `B1-REC-16`：UNKNOWN_EFFECT 先 reconcile，不盲重試 | [P:execution-contract;N:PIPD-05] |
| 17 | 949 / 1565 完整分母誤派為當輪工作 | `ObligationLedger` vs `RunnableDAG` | P | `B1-REC-17`：Deferred 保留，不進 READY | [N:B1-06;H:B1-HANDOFF:§0] |
| 18 | SourceFreeze／TaskKind／Oracle 端點假定可用 | `CapabilityDiscovery` 的 MISSING／NO_FIT | P | `B1-REC-18`：無 Compiler 只 Candidate | [N:FHS-R2:§5;H:B1-07] |
| 19 | Patch/PR/CI/Host Loaded/World Effect 證據混用 | `EvidenceType` + exact SHA/Subject | P | `B1-REC-19`：CI PASS 不准 Native PASS | [N:PIPD-09;H:B1-RCA] |
| 20 | Manifest/Seal SHA 漂移、封存誤止 | 不可變 Candidate Snapshot／bitwise digest／Owner Final Gate | P/I | `B1-REC-20`：中期 Seal 不達 Done | [H:B1-LOG:r8/r9;N:PIPD-04] |
| 21 | 全 DOC 常駐 Context，壓縮後無續工 | K0 全文＋K1 Index＋K2 ABI＋K3 JIT；StepState | P | `B1-REC-21`：無 DOC 重傳、只局部載入 | [N:PIPD-08;H:DIALOGUE] |
| 22 | 不需 Admin 的修補也被判需要全權 | Effect→Permission Classifier；非特權按最小權限 | P/I | `B1-REC-22`：普通 Repo/Read 不索要 Administrator | [N:PIPD-05;N:SBL-07] |
| 23 | Tool Installed 當 True Invoked | `SELECTED/INSTALLED/BOUND/INVOKED/VERIFIED` 分層 | P/I | `B1-REC-23`：無真 receipt 不標 VERIFIED | [N:PIPD-09;H:B1-HANDOFF] |
| 24 | NOT_RUN、FAIL、HOLD、NO_FIT 混淆 | `TypedFailure@1`，原始狀態不摺疊 | P | `B1-REC-24`：NOT_RUN 不被渲染成 FAIL/PASS | [H:B1-HANDOFF:§2;N:FHS-R2] |
| 25 | Issuer/Checker/Golden WO Raw 不完整 | `EvidenceExpectation` 分主體、Operation、Epoch | I/N | `B1-REC-25`：跨 GWO Receipt 借用拒收 | [N:B1-08;H:B1-HANDOFF] |

**Codex 退出邊界**：對 RC-01/02/05/06/09/10/14/25，只承諾本輪可以把 **防假成功、正確 Handoff、受影測試規格** 落在 Portable Plugin；不能將 `B1 NATIVE PASS 0→N` 寫入報告。對 RC-03/07/08/11/12/13/16/17/18/19/20/21/22/23/24 必須在 Plugin 自己的 Regression 真跑出結果，才可勾選其相應靜態 Gate 通過。外部失效保留獨立 `CR_OPEN_NATIVE`。[H:B1-HANDOFF;N:SBL-11]

---

# 5｜最終 Portable Plugin 架構及可攜 Host 條件

## 5.1 核心元件圖（proposal，不等於現有部署）

```text
GPT / Codex / compatible Agent Host
       │ ONE install: sbl-tpm-sp
       v
   tpm-sp / goal.open (SOURCE-BOUND entrypoint)
       │
       ├── Intent / Product / Systems / Program (18 StageContracts)
       ├── QuestionLedger (known answers; GitHub GHP-01)
       ├── SourceBound K0 full raw / K1 exact clause / K2 norm mapping / K3 JIT
       ├── 8 repaired P4 Skill Contracts (Source→PI→PD→ECP→TQAEP→Package)
       ├── Semantic/Oracle/Risk/ErrorEnvelope independent local checks
       ├── Donor Capability Router (6 donor / 24 slots / Provider-off)
       └── MissionHandoff@1 (CANDIDATE unless real compiler/readback)
                  │  Typed ABI, SHA+Version handshake, NO credentials
                  v
      External Native SBL-TPM Factory (Hermes / HG-KSEOS / SBL)
                  │
        Existing PIPD canonical writer │ HGK issuer │ Hermes queue
        Independent checker │ Native Host readers │ Publisher
```

**Portable 主體依原 SBL DOC-04 C13 提供 PM、Systems、TPM 三角色**，不是把 `Commander-SP`、`External Challenge-SP` 併成同一 Prompt／身份。不能因為只有一位 OWNER 就合併 PIPD/HGK/Checker 技術 Principal。Portable 有權輸出 `spec.write` 的受限 Draft，不自稱具 `product.write`、`challenge.sign` 或 `github.push` 能力。[N:SBL-01:C01.2;N:SBL-04:C13;P:tpm-sp]

## 5.2 最小物理檔案布局（路徑在 Worktree 探測後綁定）

```text
<sbl-tpm-sp-repo-root>/
  plugin.json                         # only if current packaging target uses it
  .codex-plugin/plugin.json          # host-specific pointer; version mapping required
  README.md CHANGELOG.md LICENSE NOTICE
  skills/
    tpm-sp/SKILL.md                   # preserve host's existing casing/convention
    tpm-product-plan/SKILL.md
    tpm-system-plan/SKILL.md
    tpm-program-plan/SKILL.md
    tpm-handoff/SKILL.md
    tpm-setup/SKILL.md
    pipd-route-intake/...             # 8 repaired P4 skills, with schemas/tests
    pipd-authority-source/...
    pipd-profile-tailor/...
    pipd-pi-compile/...
    pipd-pd-bind/...
    pipd-execution-contract/...
    pipd-assurance-tqaep/...
    pipd-package-project/...
  references/
    corpus/pipd/                      # full original PIPD DOC-00..09
    corpus/sbl/                       # full original SBL DOC-00..13
    corpus/history/                   # FHS/B1/chat/support, subset or full approved
    corpus/SourceManifest.json        # exact bytes, role, group, hash, origin
    index/clause-index.jsonl
    index/authority-registry.json     # only authority-verified refs
    index/supersession.json
    index/conflicts.json
    compatibility/abi-matrix.json
    compatibility/tstage-source-map.json
    compatibility/donor-admission.json
  schemas/
    sbl-tpm/GitHubDeliveryDecision.schema.json
    sbl-tpm/MissionHandoff.schema.json
    sbl-tpm/ErrorEnvelope.schema.json
    pipd-adapters/                    # extensions; do NOT silently alter P4 v0 schemas
  scripts/
    verify_corpus.py
    check_semantics.py
    github_decision.py
    package_preflight.py
  tests/
    test_corpus.py
    test_semantics.py
    test_github_decision.py
    test_p4_fixtures.py
    test_role_stage.py
    test_b1_regressions.py
  evidence/                             # generated locally; exclude secrets from plugin
  .github/workflows/sbl-tpm-candidate.yml
```

**實作順序要讓 Codex 探測現有實際套件 Manifest，不得把上方 proposal 路徑當成已存在檔案。** 每個 P4 Skill 原始附屬 Contract/Schema/Fixture 應保持相對路徑、命名和原型，避免 merge 後 Handler 無法尋找 `references/contract.md`。若原始 private plugin 要求的是 `skill.md` 小寫，必須按已安裝 Host 接口確認，不得一律假設 `SKILL.md`。[P:8 skills][N:SBL-10]

## 5.3 K0–K3：來源自包含而不塞爆 Prompt

- **K0 Raw Retention**：原始全位元、原路徑名、SHA-256；保持 `NORMATIVE-DESIGN` 與 `HISTORY_SUPPORT` 分離。不得自行改寫 DOC 並覆蓋 K0。
- **K1 Exact Index**：`source_id,hash,heading,line_from,line_to,clause_id,canonical_owner,authority_state`；精確讀行，必要時只讀受影切片。Index 本身不能替代 Raw。
- **K2 Approved Normalization**：`12→9 profile mapping`、`OracleBinding`、`TStageMap`、`SourceRank`、ConflictRegistry；未 Ratify 的項目只能 `PROPOSED/HOLD`。
- **K3 JIT Task Projection**：Codex 問題涉及 JTBD 就只載 Goal/Persona/FUO；涉及 Host ECP 才載 DOC-05/07 及真 Scope；涉及 GitHub Publication 才載 C43/Publisher Policy。避免全部規範全文常駐。[N:PIPD-08:Progressive Disclosure;N:SBL-10]

## 5.4 TPM 18 StageContracts 的最小輸出（不改 Canonical T0–T5 原義）

| Role | T0 | T1 | T2 | T3 | T4 | T5 |
|---|---|---|---|---|---|---|
| PM | SourceBound Goal | Persona/JTBD／去重問 | FUO／Value Criteria | Product SPEC | POS/NEG 候選 | 有 Raw 則 Review，否則 Hold |
| SE | Source/Trust Seam | Writer/Reader Ownership | ADR／Risk | Architecture SPEC/ABI | Security/Effect NEG | Verified Arch Handoff |
| TPM | Milestone Inputs | Capability/Repo/Host Discovery | Dependency DAG | Program SPEC＋WorkPackage | PI/PD Handoff Candidate | Review/Continuity＋Acceptance Request |

**T4/T5 的三種來源語義必須以不同 `TStageMap@source_hash` 同時保留，`CR-DOC04-STATE-MAP=HOLD` 不能由 Codex 擅自裁決。** 上表只是本方案的「可測 Orchestration View」，不能發行為 PIPD Lifecycle State。各 18 個 Contract 實作至少含 `entry_guard/typed_input/typed_output/exit_guard/first_fail/next_legal_action/owner/consumer/source_ref`；任何缺正式 T4/T5 裁決的正式交接應維持 Candidate，受影外的一般 SPEC 設計可繼續。[N:SBL-04:C13.1–C13.3]

## 5.5 External Donor：六 Donor／24 Slot 非必裝依賴

| Donor | Slot | 建議預設 | 實作 | Provider-off／NOFIT |
|---|---|---|---|---|
| OpenSpec | OS-01..04 | Selected thin adapter | `explore/spec-delta/apply/archive` 只由真 Root/CLI 授權 | 無 OpenSpec 用規範 Draft，不冒稱外部 Verify |
| Spec Kit | SK-01..04 | Selective | Constitution/Clarify/Specify/Plan/Tasks 的產品語義 | 不建立第二 PI Compiler |
| Matt Skills | MP-01..04 | Method-first | `grill-with-docs`、domain model、to-spec、TDD | 只內建合法方法，無外掛仍可問少量缺失問題 |
| gstack | GT-01..04 | Reference/Eval | Product/Engineering/QA/Ship review | Codex/Hermes 原生 Hooks 需 Host 驗證，不當 Trusted Checker |
| Superpowers | SP-01..04 | Method selective | Red→Green、Debug、Verify-before-completion | 不建立第二執行平面 |
| GSD | GS-01..04 | Reference; archived old donor must not pin latest | Milestone/Checkpoint 方法 | 不建立第二 Hermes Queue |

`DonorAdmission@1` 包含 `repo_url,version/full_sha,license,host,capability,scope,method_vs_runtime,positive,negative,offline_fallback,rollback,admission_owner`。外部工具未正式選用時 `SELECTED=false`；不得因星數多而忽略 PIPD TechnologyAdmission。參考來源：SBL DOC-06 C32、PIPD DOC-08，藍圖 r1 §5.3；官方/社群 Currentness 在實際建置日重查，不能只靠本輪歷史版本記錄。[N:SBL-06:C32;N:PIPD-08;H:UPGRADE-BLUEPRINT:§5]

---
# 6｜GitHub 必檢但非阻斷 Decision Gate：ECP/TQAEP 低治理實作

GitHub 需求是「**每個適用 Mission 都應確認遠端交付偏好**」，不是預設 Push。決策屬 SBL `QuestionGate`／`DeliveryDecision`；真正外部效果屬 Remote Publisher、專屬 ECP／Native Adapter。不能將 `push_to_github: true` 偷增到 P4 原有 `additionalProperties:false` Schema。[N:SBL-01:C08.2A,U26/U27;N:SBL-12:C43;N:PIPD-05/09;D:UPGRADE]

## 6.1 兩個 Gate 不同作用域

| Gate | 觸發 | 確認事項 | 阻斷範圍 |
|---|---|---|---|
| `GHP-01 PLANNING_CHECK` | 新 Mission 的 Spec/TQAEP 規劃；或既存決策失效 | `LOCAL_ONLY`／`CANDIDATE_BRANCH_PR`／`DEFERRED`、Owner、Source、QuestionKey | 缺決策不阻本地設計／測試；只建立 Pending |
| `GHP-02 PRE_PUBLICATION` | **實際** Remote Branch／PR／Release 之前 | Repo ID/Visibility、Publisher Scope、Exact SHA、SecretScan、Protected Ruleset、有效 Owner Grant | 缺任一，禁止遠端效果；不阻無關本地工作 |

若本次任務明定「PR 是最終交付 Required」，未完成真 PR 時此任務 **remote delivery exit** 仍 HOLD；不能因 GHP-01 非阻斷把適用 Required 發布義務刪掉。若使用者已選 LOCAL_ONLY，**不得 Push**；先前經核准的同 Subject 同 Scope 決策仍有效時，不重問。使用者單句「要同步」也不能替代 Credential／Publisher Admission。[N:SBL-01:U26/U27][N:SBL-12:C43]

## 6.2 狀態機（Proposal）

```text
UNDECIDED ──ask──> ASKED_PENDING ──owner-local──> LOCAL_ONLY
                                   ├─owner-defer──> DEFERRED
                                   └─owner-publish──> PUBLISH_REQUESTED
PUBLISH_REQUESTED ──valid publisher authorization──> PUBLISH_ADMITTED
PUBLISH_ADMITTED ──remote exact readback──> PUBLISHED_VERIFIED
any remote route ──missing permission/secret exposure/wrong repo──> PUBLISH_BLOCKED
```

`ASKED_PENDING`/`DEFERRED` 不表示拒絕；`PUBLISHED_VERIFIED` 只表示所聲稱的 Remote Candidate 已讀回，**不表示** PR 已 Merge、Release 已發布或 Native Accepted。`LOCAL_ONLY` 若滿足 Local Delivery Contract 可以合法完成。對於沒有 Native Publisher 的 Portable Host，一律允許 Output `RemotePublicationRequest Candidate`，不允許寫入 GitHub。[N:PIPD-09;N:SBL-12:C43]

## 6.3 TQAEP 測試最小分母（GHP 必檢）

| ID | POS/NEG/EDGE/SEC | 實際判定 |
|---|---|---|
| GH-01 | `UNDECIDED` | 本地 PLAN 可繼續；必提示／記錄問項；REMOTE 禁止 |
| GH-02 | `LOCAL_ONLY` + 合法決策 | 本地交付可達受限 PASS；REMOTE DENY |
| GH-03 | `DEFERRED` | 不重複問；交付前提醒；不自 Push |
| GH-04 | `PUBLISH_REQUESTED` 無真 Publisher | 只 Remote HOLD；本地不受影工作 READY |
| GH-05 | `PUBLISH_ADMITTED` 只是 AI 字串 | Fake Permit DENY |
| GH-06 | Remote Repo/Branch/Visibility Wrong | Remote DENY |
| GH-07 | Secret/Token/Private Runtime DB 進候選 | DENY Publication，開具受影 RepairCone |
| GH-08 | Wrong Commit/PR head SHA | DENY PUBLISHED_VERIFIED |
| GH-09 | Push 成功 PR 未建 | 不可宣稱 PR_DELIVERED |
| GH-10 | PR CI Green，Trusted Verifier 缺席 | `CANDIDATE_GATES_OBSERVED`，不得 Release |
| GH-11 | 既存同 Scope 有效 Decision | 不重問；依 currentness/expiry 驗證 |
| GH-12 | 新公開範圍或新的 Repo | 重取有效 Owner/Publisher 批准 |

**Stage A 與 Stage B 分層：** Candidate PR 自身代碼可修改 Stage A workflow，不能以其 Green 假裝非 PR 可修改的 Trusted Verifier。正式 Stage B 的 `expected_app_id/ruleset_id/repository_id/head_sha/merge_group_sha/protected_workflow_sha/oidc_claims` 必須由受保護的有權來源提供；缺時 `CR-TRUSTED-CHECKER`，不以自製假 `sbl-independent` check 名稱充數。[N:SBL-12:C43.PATCH;N:PIPD-09]

---

# 7｜可讓 Codex 直接施工的 WorkPackage DAG

**執行模型：** 每張卡完整帶 `goal/source_inputs/affected_paths/preflight/allowed_write_scope/commands/exit_pos_neg/evidence/next_legal_action/claim_ceiling`；Codex 可在一個有權 Worktree 反覆診斷和修補，但不得偷偷延伸 WriteSet。所有狀態落在**本地工程 Checkpoint**（非新 Hermes Queue），每次重新啟動先復查 Git HEAD、source SHA、Diff、open failing tests。[N:FHS-R2:§7/§12;N:PIPD-05;D:UPGRADE]

| WP | 依賴 | Codex 施工內容 | 主要候選路徑 | POS／NEG 退出 | 缺件降級 |
|---|---|---|---|---|---|
| `C00` Baseline | NONE | Clone/Export 兩原 Plugin、四 Repo read-only inspect、原件完整 SHA／License／Host Capability、既存差異保存 | `evidence/baseline/*`, `references/corpus/SourceManifest.json` | Exact source SHA、實際 Repo Root/HEAD；禁止未授權寫入 | Source MISSING ⇒ 只產 Inventory／CR，不猜 Repo |
| `C01` P4 Fixtures | C00 | 快照原 8 Skill／cases；修 F01–F06，將錯正例變負例 | `skills/pipd-*/tests/cases.yaml`, `tests/test_p4_fixtures.py` | P4-01～04 的真 POS/NEG；原件可追溯 | P4 source 無權複製 ⇒ 產 Patch Candidate／授權 CR |
| `C02` P4 Semantic | C00,C01 | Artifact/Graph Resolver、Hash/Subject/Receipt Join、12→9 Profile、Oracle Binding、TQAEP Plan／Live | `scripts/check_semantics.py`, `schemas/pipd-adapters/*` | P4-05～15、17：錯誤 Mutant DENY | Oracle/StageMap CR 僅受影正式項 HOLD |
| `C03` TPM Core | C00 | PM/SE/TPM、18 StageContracts、QuestionLedger、Quick/Guided/Critical、Product SPEC | `skills/tpm-*/`, `schemas/sbl-tpm/*` | 18/18 Design Contract；T4/T5 Conflict 保留 | StageMap Owner 未決 ⇒ 不升格 PI_READY |
| `C04` Corpus | C00 | 10+14 全文 K0，Manifest、Index、Integrity Reader、History 分層 | `references/corpus/*`, `scripts/verify_corpus.py` | ZD01..ZD08；SHA mismatch FAIL | 未授權再散布 ⇒ 僅 User-private candidate，不公開 Release |
| `C05` GitHub Decision | C03 | GHP-01/GHP-02、QuestionKey、DeliveryDecision、Truthful Remote/Local Claim | `scripts/github_decision.py`, `tests/test_github_decision.py` | GH-01..GH-12；未授權遠端零效果 | 沒 Publisher ⇒ Local Planning 繼續，Remote HOLD |
| `C06` External Donors | C03 | 6 Donor 24 Slot registry、Native reuse 方法、Provider-off | `references/compatibility/donor-admission.json` | Each selected/off positive/negative；不多裝服務 | NoFit 不阻 TPM Core |
| `C07` Handoff ABI | C02,C03 | Portable/Native Version Handshake、Claim/Effect Types、ErrorEnvelope／Resume | `schemas/sbl-tpm/MissionHandoff.schema.json`, `references/compatibility/abi-matrix.json` | Wrong version/SHA/Subject 拒；真 Receiver 未就緒正確 HOLD | 沒 Native ⇒ Candidate only |
| `C08` Package | C01..C07 | 以原私人 Plugin ID 生成 Candidate、版本同步、License/NOTICE、SBOM、改版/回滾 | `plugin.json`, `.codex-plugin/plugin.json`, `CHANGELOG.md` | 區分 Package Valid vs Host Effective | Host 未裝 ⇒ PACKAGE_CANDIDATE |
| `C09` Clean Host | C08 | 全新 Host 僅裝本 Plugin，零 DOC 重傳、舊 P4 缺席、Trigger/Nontrigger/Uninstall | `evidence/host-uat/*`, `tests/test_host_*` | ZD01..ZD08／GJ03 真 Readback | Host 受限 ⇒ 標 `HOST_UNQUALIFIED` |
| `C10` Golden Journeys | C09 | GJ01 Greenfield CLI、GJ02 Brownfield Repair、GJ03 Skill/Agent 兩變體；TQAEP | `tests/golden_journeys/*` | 有真 FUO/正負測；外部 Native 只引用真收據 | Builder 無權 ⇒ Candidate not World PASS |
| `C11` Audit/Delivery | C09,C10 | 檢查受影 P0、3 類 Claim、Manifest/ReleaseCandidate/PR 交付計畫 | `evidence/final/*`, `reports/*` | Check Matrix 真結果、無 CR 假閉合 | Native/Checker 不全 ⇒ 受限交付不假 Production |

**並行與最小阻斷：** `C03/C04/C05/C06` 可視受影依賴並行；`C07` 可先用 Stub 作 ABI Negative，不必等 Hermes 完工；`C09` 以指定 Host 真載入為條件，不用其它 Host 的 HOLD 阻塞已合格 Host。`C11` 不因 `M4 Native E2E` 未通而阻止有權的 **Portable Planning Candidate** 交付，卻必須阻止對外宣稱 `NATIVE_ACCEPTED`。[N:PIPD-00;N:SBL-12;H:B1-HANDOFF]

## 7.1 WorkPackage 的標準實作記錄

```yaml
schema: SBL.CodexWorkPackage@1 # DESIGN_PROPOSED
wp_id: C02
mission_subject: <exact_source_bound_subject>
input_refs: [<source_manifest_sha>, <p4_source_sha>, <test_baseline_sha>]
affected_paths: ["scripts/check_semantics.py", "schemas/pipd-adapters/"]
allowed_effect_class: LOCAL_REVERSIBLE_WRITE
admission_ref: <real_owner_repo_admission_or_EXTERNAL_HOLD>
preimage_ref: <git_HEAD_and_tree_sha>
first_fail: <observed_test_name_or_NONE>
repair_iteration_limit: <approved_limit>
positive_tests: [P4-SEM-01, P4-SEM-06]
negative_tests: [WRONG_HASH, HIGH_RISK_DOWNGRADE]
checkpoint_path: evidence/checkpoints/C02.json
claim_ceiling: AUTHOR_SIDE_REPAIR_CANDIDATE
```

`<...>` 全部必須在 C00 由真環境取得並提供給 Validator。它們不是 Codex 可自行填入任意假值的權限欄。`admission_ref` 需在 Repository 寫入前由適用的既有實際機制決定；若沒有，允許只讀審計、候選 Patch 文字及受影 HOLD，但不允許越權變更 Repo。[N:PIPD-05;N:FHS-R2:§6.1]

## 7.2 正確的自動化修復迴路

```text
FOR each READY authorized Codex WorkPackage:
  verify current Repo Root/HEAD/preimage + source manifest + real write permission
  reproduce first failure (RED) without widening scope
  repair smallest affected code/schema/fixture delta
  run target POS/NEG/EDGE/SEC + adjacent regression
  if failed and still within authorized repair iteration budget:
      record FirstFail → minimal revision → rerun (do not restart full Mission)
  else if external Native/Owner/Oracle/Host unavailable:
      PARK this affected WP with resume_predicate; continue unrelated READY WP
  else if succeeded:
      record exact diff/HEAD/runner/subject/candidate SHA; advance dependency DAG
  else:
      STOP only this WP; report precise immutable blockers
NEVER:
  git push/merge/tag/release by default
  forge PIPD Compiler/Checker/HGK receipts
  erase original normative text, overwrite unrelated files, make a second PIPD writer
  translate NOT_RUN to PASS/FAIL without execution
  terminate Mission because Document Packaged
```

Codex **不能承諾在 ChatGPT 對話結束後自行背景執行**。在真正本地 Codex 機制下，每次透過確定性的 `evidence/checkpoints/*.json`、Worktree/HEAD 和選定任務卡恢復；若需要真 Durable Scheduler，另由 Hermes 現役機制提供。不可假裝 `todo_list` 本身等於跨程序 Worker。[H:B1-RCA:Stop Controller;N:FHS-R2:§12]

---
# 8｜Codex Windows 施工啟動與具體指令

## 8.1 第一次啟動：只讀先探測，不預設本機路徑

以下 PowerShell 為讀取／檢查指令；**不要**從有管理員權限的終端直接執行未知 Repository 程式。先以普通使用者、隔離 Worktree 及真實已取得的 Repository Clone 執行。

```powershell
$ErrorActionPreference = 'Stop'
Get-Command git,python,py,codex -ErrorAction SilentlyContinue |
  Select-Object Name,Source
# 在候選已合法克隆的 Repository 內執行，不在未知路徑自動寫入
& git rev-parse --show-toplevel
& git rev-parse HEAD
& git remote -v
& git status --porcelain=v1 --untracked-files=all
& git branch --show-current
& git log -1 --format='%H %ct %an %s'
# 如果上述任一命令失敗，記錄工具/路徑 FirstFail；不要自行猜測新 Clone 位置
```

在有權 Repository root 內，先由 Owner／既有合法機制確認本輪可寫範圍，才能執行 `git worktree add`。**不得直接在當前髒 Working Tree 覆寫 source。** 建議先 `git diff --binary > <secure-evidence-path>` 保存前像，並由 Codex 顯示 Diff Summary；匯出證據不得被自動收集進公開 Plugin。對 P4 原 Repo 是否具有修改權限，必須按實際權限驗證；僅將 P4 八項 Skills 複製到 Plugin 前，先核對程式碼 License、原文件授權和來源 SHA。[N:PIPD-05;N:SBL-07/12]

## 8.2 建置用自包含資料包的供應路徑

「只需安裝新版 SBL-TPM-SP」不等於「在**製作**新版時可以不取得來源」。Codex C00 必須由本地來源集或有權 Source Connector 取得 PIPD 10 冊、SBL 14 冊及八 Skills 全附屬原檔，並以本檔 §1 的原件 SHA 為比較基線；原件若與基線不同，必須另產 Version Drift 報告並取得有權決策，不能盲拷。

**SourceLock 輸入格式（建置時由有權來源管理者審閱、非腳本自核准）：**

```json
{
  "schema": "SBL.SourceLock@1",
  "authority_state": "BASELINE_CANDIDATE_NOT_RATIFIED",
  "files": [
    {
      "group": "pipd",
      "filename": "PIPD_LS_DOC-00_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md",
      "sha256": "be3a672ec20aa0e6b5e0e35097fc08de749bfe7f59f827d18e38aef67dd68ea4"
    }
  ]
}
```

以上只有**一份示例記錄**，不能假稱完整 Corpus，執行時必須由 C00 形成**精確 10+14** 記錄、可選 HISTORY，全部來源經正式權限及版本核對。資料包含附帶 SourceLock 與必需 License/NOTICE 文件；原始 SHA 可驗但**不證明**正式 Authority Ratification。[N:PIPD-01;N:SBL-12]

## 8.3 `scripts/import_corpus.py`：只按受控鎖定清單匯入

以下候選腳本不訪網、不修改原來源；只將 Locked 內容複製至一個**尚不存在的暫存封裝目錄**。同一 Origin File 必須精確對上受控 SHA，硬連結或 junction 穿出來源根目錄時拒收。`SourceLock` 本身是否經有權來源管理者批准是外部 Gate，腳本不簽發任何 SourceFreeze。

```python
#!/usr/bin/env python3
"""Copy a pinned set of UTF-8 DOCs into a new staging directory; never ratifies them."""
import argparse
import hashlib
import json
from pathlib import Path


def stage(source: Path, destination: Path, lock: Path) -> dict:
    source = source.resolve(strict=True)
    data = json.loads(lock.read_text(encoding="utf-8"))
    if data.get("schema") != "SBL.SourceLock@1":
        raise ValueError("SOURCE_LOCK_SCHEMA")
    records = data.get("files")
    if not isinstance(records, list) or not records:
        raise ValueError("EMPTY_SOURCE_LOCK")
    observed = {"pipd": 0, "sbl": 0}
    staged = []
    seen = set()
    for record in records:
        group = record.get("group")
        name = record.get("filename")
        sha = record.get("sha256")
        if group not in observed or not isinstance(name, str):
            raise ValueError("INVALID_GROUP_OR_FILENAME")
        if (Path(name).name != name or name in seen or
                name.startswith(".") or "/" in name or "\\" in name or
                ":" in name or not name.endswith(".md")):
            raise ValueError("TRAVERSAL_OR_DUPLICATE")
        seen.add(name)
        if not isinstance(sha, str) or len(sha) != 64 or any(c not in "0123456789abcdef" for c in sha):
            raise ValueError("BAD_PIN")
        candidate = source / name
        if candidate.is_symlink():
            raise ValueError("SYMLINK_SOURCE_FORBIDDEN")
        item = candidate.resolve(strict=True)
        item.relative_to(source)
        if not item.is_file():
            raise ValueError("BAD_INPUT")
        raw = item.read_bytes()
        raw.decode("utf-8", "strict")
        if hashlib.sha256(raw).hexdigest() != sha:
            raise ValueError(f"SOURCE_DRIFT:{name}")
        staged.append((group, name, raw, sha))
        observed[group] += 1
    if observed != {"pipd": 10, "sbl": 14}:
        raise ValueError(f"DENOMINATOR:{observed}")
    if destination.exists():
        raise ValueError("DESTINATION_MUST_NOT_EXIST")
    # Local reversible write. Caller must have authorized parent scope.
    destination.mkdir(parents=True)
    manifest = []
    for group, name, raw, sha in staged:
        target = destination / group / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(raw)
        manifest.append({"path": f"references/corpus/{group}/{name}", "group": group,
                         "sha256": sha, "required": True})
    return {"schema": "SBL.CorpusManifest@1",
            "required_group_counts": {"pipd": 10, "sbl": 14},
            "files": manifest,
            "authority_state": "PHYSICAL_COPY_VERIFIED_ONLY"}


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--source", type=Path, required=True)
    ap.add_argument("--staging", type=Path, required=True)
    ap.add_argument("--lock", type=Path, required=True)
    a = ap.parse_args()
    manifest = stage(a.source, a.staging, a.lock)
    print(json.dumps(manifest, ensure_ascii=False, indent=2))
    # Review print output; write SourceManifest only into authorized repo staging path.
```

**重要修正點（須由 Codex 落地）**：上述腳本完整驗證來源檔的位元 SHA，但實體檔案分組路徑本身在不同 Windows/NTFS、junction、reparse-point、硬連結及併發替換條件下仍需安全測試；正式發版應採用 staging 暫存根目錄、拒絕存在的目標、資料讀取前後 Identity 對照、原子 Materialize，並由受保護 Runner 確定性回讀。這段是起點而非對抗性檔案系統的完整安全證明。[N:PIPD-05;N:SBL-07]

## 8.4 直接驗證與迭代指令

```powershell
# 請先 cd 至經驗證的 <PLUGIN_WORKTREE_ROOT>；此處不自動設定路徑
& git status --short
& git diff --name-only
& python -V
# Codex 在 C04 建立 Corpus Manifest / scripts 後執行：
& python scripts/verify_corpus.py .
& python -m compileall -q scripts
& python -m unittest discover -s tests -v
& git diff --check
& git status --porcelain=v1 --untracked-files=all
# 只在安全、受限的候選分支；不得直接 git push, merge, release
```

**低阻力 Checkpoint 格式**：每次 WorkPackage 結束，Codex 產出 `evidence/checkpoints/<WP>.json`，至少包括 `worktree_root,head_before,head_after,source_hash,modified_paths,tests_invoked,exit_code,first_fail,evidence_paths,blocked_external,allowed_next_action`。此 JSON 是工程恢復資訊，不是 HGK SharedSpine 的第二真值；進入新 Session 時先重新讀真 Worktree 和 Checkpoint，不重問原文已有答案。[H:B1-RCA:Session stop;N:PIPD-08]

---

# 9｜可直接複製到 Codex Worktree 的離線檢查、GitHub 決策範例

**以下代碼來自已交付的雙形態藍圖 r1 §9.2～§9.7，作為 Portable Plugin 施工候選。** 原範例於前輪完成了局部 Python 語法／決策負例測試，**本輪仍需重新執行**；更不代表經 PIPD Native Compiler 或 Host UAT。檔案 `gate.py` 僅作本地限制，不持有 GitHub Token，不會 Push。Codex 應將其封裝為有版本、可重播的 `scripts/` 和 `tests/`，再按本檔之受影要求改進。

## 9.1 `verify_corpus.py`

```python
#!/usr/bin/env python3
"""Offline corpus integrity / count gate. No network, no side effects."""
import hashlib
import json
import re
import sys
from collections import Counter
from pathlib import Path


def verify(root: Path) -> list[str]:
    errors = []
    root = root.resolve(strict=True)
    mf = root / 'references/corpus/SourceManifest.json'
    if not mf.is_file():
        return ['MISSING_MANIFEST']
    obj = json.loads(mf.read_text(encoding='utf-8'))
    if obj.get('schema') != 'SBL.CorpusManifest@1':
        errors.append('SCHEMA_MISMATCH')
    records = obj.get('files')
    if not isinstance(records, list) or not records:
        return errors + ['EMPTY_FILE_DENOMINATOR']
    seen, counts = set(), Counter()
    for i, row in enumerate(records):
        if not isinstance(row, dict):
            errors.append(f'FILE_{i}_INVALID_RECORD')
            continue
        rel, digest, group = row.get('path'), row.get('sha256'), row.get('group')
        if not isinstance(rel, str) or not rel or rel in seen:
            errors.append(f'FILE_{i}_PATH_OR_DUPLICATE')
            continue
        seen.add(rel)
        if not isinstance(digest, str) or not re.fullmatch(r'[0-9a-f]{64}', digest):
            errors.append(f'FILE_{i}_BAD_SHA256')
            continue
        path = root / rel
        try:
            actual = path.resolve(strict=True)
            actual.relative_to(root)  # forbids ../ and symlink escape
            if not actual.is_file():
                raise ValueError('NOT_A_FILE')
            data = actual.read_bytes()
            data.decode('utf-8', 'strict')
        except (OSError, ValueError, UnicodeError):
            errors.append(f'FILE_{i}_UNAVAILABLE_OR_ESCAPED')
            continue
        if hashlib.sha256(data).hexdigest() != digest:
            errors.append(f'FILE_{i}_HASH_MISMATCH')
        if row.get('required') is not True:
            errors.append(f'FILE_{i}_NOT_REQUIRED')
        if group not in ('pipd', 'sbl', 'historical'):
            errors.append(f'FILE_{i}_UNKNOWN_GROUP')
        else:
            counts[group] += 1
    expected = obj.get('required_group_counts', {})
    for group in ('pipd', 'sbl'):
        if counts[group] != expected.get(group) or expected.get(group) != {'pipd': 10, 'sbl': 14}[group]:
            errors.append(f'{group.upper()}_DENOMINATOR_MISMATCH')
    return errors

if __name__ == '__main__':
    target = Path(sys.argv[1] if len(sys.argv) > 1 else '.')
    failures = verify(target)
    print(json.dumps({'verdict': 'FAIL' if failures else 'PASS', 'errors': failures}, ensure_ascii=False))
    raise SystemExit(1 if failures else 0)
```

**必須額外驗證：** 同一 Subject/Source SHA、錯 Repo、錯角色、缺 Owner Decision、跨版本、Prompt 注入、Scope 越界及 Forbidden Remote Effect；任何 `PASS_CANDIDATE_ONLY` 只表示本地候選，並非正式 Authority 或 Native PASS。[N:SBL-12:C43;N:PIPD-09;D:UPGRADE]

## 9.2 `GitHubDeliveryDecision.schema.json`

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "https://example.invalid/sbl/GitHubDeliveryDecision.schema.json",
  "title": "SBL.GitHubDeliveryDecision@1",
  "type": "object",
  "additionalProperties": false,
  "required": ["schema", "subject_sha256", "question_key", "state", "owner_decision_ref"],
  "properties": {
    "schema": {"const": "SBL.GitHubDeliveryDecision@1"},
    "subject_sha256": {"type": "string", "pattern": "^[a-f0-9]{64}$"},
    "question_key": {"const": "github_publication_for_mission"},
    "state": {"enum": ["UNDECIDED", "ASKED_PENDING", "DEFERRED", "LOCAL_ONLY", "PUBLISH_REQUESTED", "PUBLISH_ADMITTED", "PUBLISHED_VERIFIED", "PUBLISH_BLOCKED"]},
    "owner_decision_ref": {"type": ["string", "null"]},
    "repository_id": {"type": ["string", "null"]},
    "branch": {"type": ["string", "null"]},
    "remote_sha256": {"type": ["string", "null"]}
  }
}
```

**必須額外驗證：** 同一 Subject/Source SHA、錯 Repo、錯角色、缺 Owner Decision、跨版本、Prompt 注入、Scope 越界及 Forbidden Remote Effect；任何 `PASS_CANDIDATE_ONLY` 只表示本地候選，並非正式 Authority 或 Native PASS。[N:SBL-12:C43;N:PIPD-09;D:UPGRADE]

## 9.3 `gate.py`

```python
#!/usr/bin/env python3
"""Non-mutating planning/publication gate; authorization verified elsewhere."""
import json
import re
import sys
from pathlib import Path

STATES = {
    'UNDECIDED', 'ASKED_PENDING', 'DEFERRED', 'LOCAL_ONLY',
    'PUBLISH_REQUESTED', 'PUBLISH_ADMITTED',
    'PUBLISHED_VERIFIED', 'PUBLISH_BLOCKED',
}


def decision_gate(data, requested_operation='PLAN'):
    if not isinstance(data, dict) or data.get('schema') != 'SBL.GitHubDeliveryDecision@1':
        return ('FAIL', 'SCHEMA')
    if not re.fullmatch(r'[0-9a-f]{64}', str(data.get('subject_sha256', ''))):
        return ('FAIL', 'SUBJECT_SHA')
    if data.get('question_key') != 'github_publication_for_mission':
        return ('FAIL', 'QUESTION_ID')
    state = data.get('state')
    if state not in STATES:
        return ('FAIL', 'STATE')
    if requested_operation == 'PLAN':
        return ('PASS', 'QUESTION_REQUIRED') if state == 'UNDECIDED' else ('PASS', 'RECORDED')
    if requested_operation == 'LOCAL_DELIVERY':
        if state != 'LOCAL_ONLY':
            return ('HOLD', 'DELIVERY_CONTRACT_REVIEW')
        ref = data.get('owner_decision_ref')
        if not isinstance(ref, str) or not ref.strip():
            return ('HOLD', 'OWNER_DECISION_RECORD_MISSING')
        # Candidate only: this string does not prove an authorized OWNER signer.
        return ('PASS_CANDIDATE_ONLY', 'OWNER_RECORD_NEEDS_TRUSTED_READER')
    if requested_operation == 'REMOTE_PUBLICATION':
        if state != 'PUBLISH_ADMITTED':
            return ('HOLD', 'REMOTE_NOT_ADMITTED')
        # One boolean or an AI-written receipt is never sufficient proof of a real permit.
        return ('HOLD', 'EXTERNAL_PUBLISHER_ADMISSION_AND_READBACK_REQUIRED')
    return ('FAIL', 'UNKNOWN_OPERATION')

if __name__ == '__main__':
    if len(sys.argv) not in (2, 3):
        raise SystemExit('usage: gate.py <decision.json> [PLAN|LOCAL_DELIVERY|REMOTE_PUBLICATION]')
    data = json.loads(Path(sys.argv[1]).read_text(encoding='utf-8'))
    result, reason = decision_gate(data, sys.argv[2] if len(sys.argv) == 3 else 'PLAN')
    print(json.dumps({'gate': result, 'reason': reason}, ensure_ascii=False))
    raise SystemExit(0 if result in ('PASS', 'PASS_CANDIDATE_ONLY') else 2)
```

**必須額外驗證：** 同一 Subject/Source SHA、錯 Repo、錯角色、缺 Owner Decision、跨版本、Prompt 注入、Scope 越界及 Forbidden Remote Effect；任何 `PASS_CANDIDATE_ONLY` 只表示本地候選，並非正式 Authority 或 Native PASS。[N:SBL-12:C43;N:PIPD-09;D:UPGRADE]

## 9.4 `prepublish_probe.py`

```python
#!/usr/bin/env python3
"""Read-only git preflight. Never calls push/merge or accepts a credential."""
import subprocess
import sys


def git(*args):
    return subprocess.check_output(['git', *args], text=True, stderr=subprocess.STDOUT).strip()


def probe(expected_remote_url, expected_branch):
    try:
        root = git('rev-parse', '--show-toplevel')
        remote = git('remote', 'get-url', 'origin')
        head = git('rev-parse', 'HEAD')
        branch = git('symbolic-ref', '--short', 'HEAD')
        dirty = git('status', '--porcelain', '--untracked-files=all')
    except (subprocess.CalledProcessError, OSError) as exc:
        return ('FAIL', f'GIT_UNAVAILABLE:{str(exc)[:80]}')
    if remote != expected_remote_url or branch != expected_branch:
        return ('FAIL', f'REMOTE_OR_BRANCH_MISMATCH:{remote}:{branch}')
    if dirty:
        return ('HOLD', 'DIRTY_OR_UNTRACKED_WORKTREE')
    if len(head) not in (40, 64):
        return ('FAIL', 'INVALID_HEAD')
    return ('PASS_CANDIDATE_ONLY', f'root={root} head={head}')

if __name__ == '__main__':
    if len(sys.argv) != 3:
        raise SystemExit('usage: prepublish_probe.py <exact-origin-url> <expected-feature-branch>')
    outcome = probe(sys.argv[1], sys.argv[2])
    print(*outcome, sep='	')
    raise SystemExit(0 if outcome[0] == 'PASS_CANDIDATE_ONLY' else 2)
```

**必須額外驗證：** 同一 Subject/Source SHA、錯 Repo、錯角色、缺 Owner Decision、跨版本、Prompt 注入、Scope 越界及 Forbidden Remote Effect；任何 `PASS_CANDIDATE_ONLY` 只表示本地候選，並非正式 Authority 或 Native PASS。[N:SBL-12:C43;N:PIPD-09;D:UPGRADE]

## 9.5 `sbl-candidate.yml`

```yaml
name: sbl-candidate
on:
  pull_request:
  merge_group:
  workflow_dispatch:
permissions:
  contents: read
jobs:
  sbl-candidate:
    name: sbl-candidate
    runs-on: ubuntu-latest
    timeout-minutes: 15
    steps:
      - name: Checkout candidate
        # This full SHA is an illustrative existing checkout v4 baseline,
        # NOT a claim of current 2026 admission. Re-pin from the real upstream.
        uses: actions/checkout@11bd71901bbe5b1630ceea73d27597364c9af683
        with:
          persist-credentials: false
      - name: Confirm Python environment
        run: python3 --version
      - name: Corpus integrity
        run: python3 scripts/verify_corpus.py .
      - name: Python syntax
        run: python3 -m compileall -q scripts
      - name: Repository candidate tests
        run: python3 -m unittest discover -s tests -v
      - name: Candidate only claim
        run: echo 'CANDIDATE_GATES_OBSERVED; NO RELEASE/AO/NATIVE CLAIM'
```

**必須額外驗證：** 同一 Subject/Source SHA、錯 Repo、錯角色、缺 Owner Decision、跨版本、Prompt 注入、Scope 越界及 Forbidden Remote Effect；任何 `PASS_CANDIDATE_ONLY` 只表示本地候選，並非正式 Authority 或 Native PASS。[N:SBL-12:C43;N:PIPD-09;D:UPGRADE]

## 9.6 `test_delivery_gate.py`

```python
import unittest
from scripts.gate import decision_gate

BASE = {
    'schema': 'SBL.GitHubDeliveryDecision@1',
    'subject_sha256': 'a' * 64,
    'question_key': 'github_publication_for_mission',
    'owner_decision_ref': None,
}

class DeliveryGateTest(unittest.TestCase):
    def test_undecided_asks_and_does_not_publish(self):
        d = dict(BASE, state='UNDECIDED')
        self.assertEqual(decision_gate(d, 'PLAN'), ('PASS', 'QUESTION_REQUIRED'))
        self.assertEqual(decision_gate(d, 'REMOTE_PUBLICATION')[0], 'HOLD')

    def test_local_only_can_complete_locally(self):
        d = dict(BASE, state='LOCAL_ONLY', owner_decision_ref='candidate-owner-record')
        self.assertEqual(decision_gate(d, 'LOCAL_DELIVERY')[0], 'PASS_CANDIDATE_ONLY')
        self.assertEqual(decision_gate(d, 'REMOTE_PUBLICATION')[0], 'HOLD')

    def test_local_only_without_owner_record_is_hold(self):
        d = dict(BASE, state='LOCAL_ONLY')
        self.assertEqual(decision_gate(d, 'LOCAL_DELIVERY')[0], 'HOLD')

    def test_even_admitted_string_is_not_a_true_remote_permit(self):
        d = dict(BASE, state='PUBLISH_ADMITTED', owner_decision_ref='fake')
        self.assertEqual(decision_gate(d, 'REMOTE_PUBLICATION')[0], 'HOLD')

    def test_wrong_subject_never_passes(self):
        d = dict(BASE, state='LOCAL_ONLY', subject_sha256='wrong')
        self.assertEqual(decision_gate(d, 'LOCAL_DELIVERY')[0], 'FAIL')

if __name__ == '__main__':
    unittest.main()
```

**必須額外驗證：** 同一 Subject/Source SHA、錯 Repo、錯角色、缺 Owner Decision、跨版本、Prompt 注入、Scope 越界及 Forbidden Remote Effect；任何 `PASS_CANDIDATE_ONLY` 只表示本地候選，並非正式 Authority 或 Native PASS。[N:SBL-12:C43;N:PIPD-09;D:UPGRADE]

# 10｜可機械裁決的 Gates／Test Tracking／Host Qualification

## 10.1 正式測試層級，不得互相冒用

| Gate ID | Input／Runner／原始證據 | 明確 PASS | FAIL/HOLD/Claim Ceiling |
|---|---|---|---|
| `G0-SOURCE` | 24 Core Docs bit SHA、受影 AuthorityBinding、License | 位元全部一致；有權來源 Ratification 依適用工件成立 | `SOURCE_MISSING`／`CR-SOURCE-TRANSITIVE` 阻正式 SourceFreeze；允許候選 |
| `G1-P4-FIXTURES` | 原 8 Skill tests/cases.yaml、POS/NEG/EDGE/SEC runner | F01～F06 具名 Errata 修正，所有負例確實拒收 | 錯 POS／Fixture 未執行 ⇒ FAIL/NOT_RUN |
| `G2-P4-SEMANTIC` | Artifact Resolver、Trace/Subject/Receipt／Profile/Oracle | Exact identity、12-axis veto 不降級、Oracle 確認 | 同 Hash 不同 Object、缺 Resolver ⇒ HOLD |
| `G3-TPM-ROLES` | 3×6 StageContract、每 Role 的 POS/NEG | 18/18 Draft Contract + TStage conflict 仍忠實保留 | 受影 T4/T5 Owner 未決不升 PI_READY |
| `G4-SELF-CONTAINED` | Clean Host 新 Session，只掛一 Plugin，無 Base DOC | 10+14 原文/精確來源索引可按需讀、舊 P4 不在場 | 任一要求重傳已內建 DOC ⇒ FAIL |
| `G5-GITHUB-QUESTION` | QuestionLedger、GHP01/GHP02 候選模型 | `LOCAL_ONLY` 無 Push；UNDECIDED 本地可繼續 | 資料無效或未查決策不發 Remote Effect |
| `G6-HOST` | Plugin install/load/trigger/nontrigger/uninstall Raw | 每宣稱合格 Host 必留真 Loader Receipt | Package Valid ≠ Host Qualified |
| `G7-PIPD-CLI` | 真 Compiler Path/Version/Schema/Invoked/Output | Native PI/PD/ECP 具現役 tool receipt/Hash | 找不到 CLI/權限/Oracle ⇒ NOT_RUN/HOLD；Portable 規劃不受影可繼續 |
| `G8-B1-REGRESSIONS` | 25 RC 的 POS/NEG 及 Owner Trace | 直接 Plugin 子集可重播；Native 子集正確保持未實測 | `NOT_RUN` 不算失敗或通過，非本輪 Release Scope 需明示 |
| `G9-GOLDEN` | GJ01 CLI／GJ02 Brownfield／GJ03 Skill+Agent | 各 FUO 有 Runner 與原始使用者效果（Host 適用時） | 欠 Builder/Host 時停留 Candidate，不冒充 E2E |
| `G10-SECURITY` | Secret/License/Symlink/Scope/Principal/Dependency | 無未授權內容、無權限冒充、精確 WriteSet | Secret/Scope Escape 必 FAIL |
| `G11-PORTABLE-RELEASE` | Plugin BOM、Signed/authorized Owner Review、Host Qualification、Rollback | 對應範圍全部 Required Gates PASS，當前 CR 不受影 | Critical CR 開放 → FAIL-CLOSED；可輸出 Candidate Report |

**GitHub Remote Publisher、Hermes Native E2E、HGK/Issuer/Independent Checker** 的各自正式 Gate 由原生 Owner 控制，不因本輪 G0–G11 綠燈而自動通過。Stage A Candidate CI 若 PR 作者可修改測試，只能說 `CANDIDATE_GATES_OBSERVED`；Stage B 經受保護 Trusted Verifier 並具 Raw/Principal 才可能放行相應高階 Claim。[N:SBL-12:C43.PATCH;N:PIPD-09]

## 10.2 最小 Regression 追蹤清單（精確分母）

| Test Group | 子測試／分母 | Required Runner | 初始狀態 | 當輪 Exit |
|---|---|---|---|---|
| `ZD-01..08` | Clean Host 8：無 DOC／無原 P4／錯 SHA／Version Drift／Lookups／Trigger／Uninstall | 真 Portable Host + corpus reader | `NOT_RUN` | 8/8 POS/NEG 正確 |
| `P4-SEM-01..18` | 已知 18 類缺陷，各至少 POS + NEG，且真受影編譯另測 | local semantic runner/real PIPD when available | `NOT_RUN` | 18/18 有正負或具名外部 HOLD |
| `TPM-STAGE-01..18` | 三角色×六階段各 1、TStage Conflict | Local Python/Test Runner + Spec QA | `NOT_RUN` | 18/18 Draft Contract 合法，受影正式 CR 保留 |
| `GH-01..12` | GitHub Question 12 | `scripts/gate.py` + trusted Publisher（Effect 要求時） | `NOT_RUN` | 無意外 Push，語義正確 |
| `DONOR-01..24` | 六 Donor/24 Slot 適用性、版本、Provider-off | Local Compatibility Tests | `NOT_RUN` | 每 Slot SELECTED/OFF/EVAL/NOFIT 有證據 |
| `B1-REC-01..25` | B1 25 RC 故障注入 | Portable subset + Native外部各自 Runner | `NOT_RUN` | Plugin 子集 TRUE；Native 子集不冒稱 PASS |
| `GJ01` | Greenfield CLI 的 FUO/POS/NEG | 具可操作 CLI／Host | `NOT_RUN` | 真用戶功能 |
| `GJ02` | Brownfield Red→Patch→Green＋rollback | 真 RepoContext＋Authorizer | `NOT_RUN` | scope 正確、回退測過 |
| `GJ03-SKILL` | Plugin trigger／nontrigger／uninstall | GPT/Codex 對應真 Host | `NOT_RUN` | Host 真 receipt |
| `GJ03-AGENT` | Simple Agent 權限／失敗 | Agent Runner | `NOT_RUN` | 不偷借 SKILL 變體 PASS |
| `RELEASE-01..08` | License／SBOM／Signatures／Secret／Migration／Rollback／Manifest／Repro | trusted CI／Host Reviewer | `NOT_RUN` | Release Scope 受影全部 PASS |

## 10.3 Host Clean-Room 操作規格

在已合法安裝的指定 GPT／Codex Host，執行以下順序；不能以只檢 Markdown 存在代替真正 Host 行為：

1. 將歷史會話中的 DOC 與舊 P4 Plugin **完全不掛載**於乾淨測試環境，只裝新候選 SBL-TPM-SP。
2. 真正 `discover→install→effective_load→invoke`；查 PIPD DOC-05 `ExecutionAdmission`、DOC-06 12-axis、SBL DOC-04 C13 TStageMap（必標 Conflict）。
3. 問新產品 `JTBD/FUO`，產出 Product、Systems、Program 三類成果；要求並驗證 Source Clause、版本與 SHA，而不是模型記憶口述。
4. 新增 GH LOCAL_ONLY 需求，驗證 QuestionGate 記錄後不再問、不使用任何遠端寫入工具。
5. 故意破壞一份封裝 DOC SHA：Reader FAIL，不從模型補造正式條款。
6. 用無源 Goal、Wrong Subject、Self Checker、Unknown Effect、過期 Profile 測試拒收。
7. `nontrigger` 對不相關請求不應觸發 TPM；卸載後不得殘留有效 Trigger／可用 Credential。
8. 產出真 Host Receipt：版本、Host、Workflow、Plugin digest、啟用時間、正反輸入、結果、錯誤與卸載狀態。

**對沒法驗收的 Host：** 記 `NO_HOST_CAPABILITY`，不可替換為另一 Host 的證據。對 CLI 請求 Builder 工程效果時，應區分 Portable 規劃的 `HOST_PENDING` 與 Codex 本地 Worktree 有權的施工能力。[N:SBL-10;N:SBL-12]

---

# 11｜風險、CR_OPEN 與 Fail-Closed Degrade Matrix

| CR | 問題／未證資訊 | 缺陷是否直接阻 Portable 本地 Design? | 阻斷的正式 Claim／解除責任 | 降級 |
|---|---|---|---|---|
| `CR-001-SOURCE` | PIPD/SBL 原上位 Blueprint/GRP/Portable Mount Profile 真原件、Owner Ratification 尚未全部在本輪實驗取得 | 否，可源標注 Draft | 阻 affected Canonical SourceFreeze／正式 Release；原 Owner 提出版本 SHA | `DESIGN_CANDIDATE` |
| `CR-002-P4-ORACLE` | `CR-ORACLE-001` DOC03 Locator vs DOC07 Writer 合法裁決 | 否 | 阻受影 PI/Assurance Owner Claim；PIPD Canonical Owner | 其它 Skill QA 可續 |
| `CR-003-STAGEMAP` | `CR-DOC04-STATE-MAP` T4/T5 跨來源歧義 | 否 | 阻正式 T0–T5 交接自稱 Canonical；SBL／PIPD Owner | 用 source-bound 三 Map Draft |
| `CR-004-P4-CLI` | 本地真 PIPD Native Compiler、Version、CLI/Artifact Resolver、Policy 是否可用 | 否 | 阻 `NATIVE_COMPILED`；PIPD Tool Owner | Skills＋Semantic Candidate |
| `CR-005-P4-FIX` | POS-F01/F02/F03/F04/F05/F06 尚未在真 Compiler 重播 | 否 | 阻 `P4_SEMANTIC_QUALIFIED`；PIPD Maintainer | 先修靜態測例 |
| `CR-006-OWNER-REPO` | 真 `sbl-tpm-sp` 原 Plugin Repo/包 Export、allowed WriteSet、Owner 權限 | 對寫 Repo 是 | 阻 Mutation；現役 Repo/Plugin Owner | Source report/patch Candidate |
| `CR-007-LICENSE` | PIPD P4、TPM、第三方 Donor及 DOC 全文再散布範圍 | 對純內部個人候選視實際權利 | 阻公開/共享 Release；Legal/Content Owner | 私人靜態 Candidate、避免未授權複製 |
| `CR-008-HOST` | GPT/Codex Portable Plugin 是否可載 24+全文，版本一致與免重新上傳 | 否，可靜態打包 | 阻 `HOST_QUALIFIED`；Host Owner | PACKAGE_CANDIDATE |
| `CR-009-ABI` | Portable／Native SBL-TPM 現役 `MissionHandoff` Receiver ABI 缺真 binding | 否 | 阻 NATIVE_HANDOFF；HGK/SBL Owner | Typed Request Candidate |
| `CR-010-GITHUB` | 有效 Publisher、Repo ID/Ruleset/Branch/visibility、有效 Owner 決策 | 否，本地可工作 | 阻 Remote Effect；Repo Publisher | `LOCAL_ONLY`／`DEFERRED` 分開 |
| `CR-011-CHECKER` | 真獨立 OS Principal／Protected Validator／Signed Receipt 不足 | 否 | 阻 INDEPENDENT_VERIFIED/RELEASE；Checker Owner | POS/NEG Planned 不自驗收 |
| `CR-012-NATIVE` | r10 T2/R3/R4/G-A/三 GWO/G-B、Hermes 真 Executor | 否 | 阻 `NATIVE_SBL_TPM_E2E_QUALIFIED`；HGK/Hermes/Fabric | Portable Candidate 不遺失工作 |
| `CR-013-PROVENANCE` | 受保護 CI Workflow SHA/Check App/Action pin/Attestation 依 Host 和 Repo 不同 | 否 | 阻 Trusted Release；SBL DOC-12 Publisher | Candidate CI only |
| `CR-014-DONOR` | OpenSpec/Matt/gstack 等實際版本/授權/Host 及 GSD 活躍 Repo 綁定 | 否 | 只有選定必需 Donor 受影；Technology Admission Owner | Provider-off 本地 Core |
| `CR-015-MANIFEST` | 不同 host plugin.json/`.codex-plugin/plugin.json` 的版本語義與 Source Package 可用性 | 否 | 阻對應 Host Release；Plugin Maintainer | VERSIONED_CANDIDATE |
| `CR-016-B1-CI` | PIPD public-plugin-verify Stage-C WriteSet（歷史 ADR-0008/0009 受影） | 否 | 阻當次有要求的 CI/Repo PR；PIPD Maintainer | 不放寬 allowlist |

**Degrade Rules 不變量**：單一外部 `CR_OPEN` 不得阻全部互不依賴的合法本地 Draft；同時任何 `CR_OPEN` 都不能因跳過測試而被改標 `CLOSED`。`NOT_RUN`、`FAILED`、`NO_FIT`、`BLOCKED_EXTERNAL`、`OWNER_DECISION_PENDING` 分開留痕。對正式 Release 若某項仍為受影 Required，輸出 `FAIL-CLOSED` 而不是 `PARTIAL_PASS`。[N:PIPD-05/09;N:FHS-R2:§12]

---
# 12｜本地 Codex 可直接使用的 MASTER ENGINEERING PROMPT

> **使用方法**：在已授權的本地 Codex、具 Repository Worktree 存取的 Session，將以下區塊整段作為主任務指令，並讓 Codex 直接讀取本 MD 與已合法取得的原始 Source/Plugin Export。若已知的 DOC 已包含答案不得重問；若關鍵權限或來源缺失，對**受影操作** Fail-Closed，不要以重問掩蓋來源缺口，也不要停掉其它有權的工作。
>
> **此 Prompt 不會自行賦予 OS、GitHub、Plugin 編輯或 HGK Issuer 權限**。所有 Repository Mutation 必須符合現有 Scope 和允許的執行環境。不要先執行 `git push`、PR Merge、Release、HGK Native Effect 或受保護金鑰操作。

```text
[ROLE]
你是本地 CODEX，擔任 SBL-TPM-SP Portable Plugin 首席 Builder、PIPD P4 修復工程師、
Test-Driven Regression Engineer。你必須遵守原 Owner 的 Canonical Writer/Effect/Checker 權責。
這份文件《SBL-TPM-SP_Codex_高自動化升級修補執行方案_r1_2026-10-27.md》
是本輪 DESIGN/EXECUTION PLAN，不是 Native Permit，也不是 SourceFreeze Ratification。

[MISSION]
以本地已存在且被授權的 sbl-tpm-sp 原 Plugin 作為升級身份，修復、整合
pipd-ls-sp-public-skills-p4 八個 Skill＋正式附件、PIPD DOC-00..09、SBL DOC-00..13，
完成 ONLY ONE PORTABLE PLUGIN，能在 GPT/Codex Host 掛載，使用者不再重傳內建基本 DOC。
增加 Product/System/Technical Program 三角色×T0..T5、QuestionGate、GitHub 必檢但非全域
阻斷決策、Typed Error/Resume、PIPD Profile/Oracle/TQAEP/Semantic Fix，完成真 Host Test。
Native SBL-TPM/HGK/Hermes 是不同產品，僅交接 ABI/候選，不納入本輪 Plugin 的強制全域施工。

[SOURCE-FIRST]
1. 首先讀本方案§0..§15及其 Source Inventory；逐一核對真實工作區內文件原文及 SHA。
2. 探測真 local worktree / HEAD / dirty/untracked / writable scope / P4 Source / CLI / Host。
3. 缺資料先從現有 Project/Repo/Plugin Export 找；不能自行編造已不存在的路徑、Binary、Receipt。
4. 保留所有原 P4 Schema/Fixture/Source 的 PREIMAGE 和合法 Errata。
5. `CR-ORACLE-001` / `CR-DOC04-STATE-MAP` / TRANSITIVE SOURCE 若未 Ratified，
   只對相應正式 Artifact 自動轉 HOLD；其它 READ_ONLY/Design/合法 Build 繼續。

[NON-NEGOTIABLE]
- 一位 HUMAN OWNER；Owner 已有效授權同一受影 Scope 就不要反覆問。
- PIPD Canonical Writer/HGK Issuer/Hermes Queue/Independent Checker 各唯一，絕不仿造。
- 不新增第二個 PIPD Compiler/Scheduler/Permission Plane。
- 不將 P4 JSON Schema Valid 當 Semantic Valid；不將 POS Fixture 期待值當成功證據。
- 不以三個模型名稱不同聲稱 SoD；不以新 Codex Session 自簽 Independent PASS。
- 不以 TaskReport、Markdown 包裝、Plugin 安裝、CI/PR 成功視為 Native Acceptance。
- 保留 R15 原始義務分母與適用 Work DAG 分離；不把 949/1565 identity 直接派工。
- 不要出於治理簡化移除真正安全 Gate；需要精確 EffectClass + AffectedOnly。
- 不把 SBL-TPM-SP 升級改成 Native SBL-TPM Factory 全面重構。
- GitHub Decision 必查，LOCAL_ONLY/DEFERRED 不 Push，未決時本地工作繼續；
  遠端發布只能由真有權 Publisher 經 GHP-02 真准入操作。禁止 push main、force push。

[WORK DAG]
執行 C00→(C01,C03,C04)→C02/C05/C06→C07→C08→C09→C10→C11；
必要時在合法 Scope 內並行非受影工作。C00 須先具備真 Repo/Plugin Source，
才可開始相應寫入；無完整權限時，繼續可做的 READ_ONLY/CANDIDATE 子任務。
每個 WorkPackage 都記錄 FirstFail、affected_scope、resume_predicate、tests、
changed_paths、source_hash、candidate_head、next_legal_action、claim_ceiling。

[IMPLEMENT]
C00: 快照原 plugin manifest/skills、取得兩 Plugin 的確切 Release/Source；建立 baseline。
C01: 重現 P4 WrongHash/WrongPDSubject/WrongCheckerReceipt/Graph Edge provenance；
     原 Positive 不可直接重標通過；修 Fixture，生成 Mutation Negative。
C02: 實作 typed ArtifactResolver/GraphResolver/RiskMapping/OracleBinding/TQAEP Planned；
     保持 P4 原 ABI 相容，未 Ratified 的必要欄位走版本化 Adapter。
C03: 實作 TPM 三角色與 18 StageContracts，T4/T5 保留 3 SourceMaps + CR。
C04: 建 K0 full DOC、K1 clause index、K2 approved crosswalk、K3 progressive router；
     乾淨 Host 無原 P4 也可查 10+14 全文；保留外部原始來源／Ratification 邊界。
C05: GitHub GHP01/02 決策、重問抑制、LOCAL_ONLY/DEFERRED、Published claim gating。
C06: OpenSpec/Matt/gstack/SpecKit/Superpowers/GSD 6 Donor 24 Slot 視准入選用，
     不裝全套，也不把方法工具變成新的安全 Checker/Task Queue。
C07: 整理 Portable→Native Handoff Candidate、Source+ABI+Subject SHA、Typed Error；
     若真 Receiver 不在場，保留 no-native-effect Candidate，不偽造 ACK。
C08: 原 Plugin ID 生成可回滾包、Licence/Notice、BOM、版本與 Host 相容矩陣。
C09: 真 Host Clean-Room install/load/trigger/nontrigger/uninstall，零基本 DOC 重傳。
C10: GJ01 Greenfield、GJ02 Brownfield、GJ03 Skill/Agent 兩個 Variant；Red→Green。
C11: 生成 Candidate Snapshot、diff、Raw test logs、CR_OPEN、Release Decision Request。

[REPAIR LOOP]
- 每一個失敗先重現 RED，識別 FirstFail，寫最小 Patch，跑 POS/NEG/EDGE/SEC，
  並且維持 Change Scope；不為 CI 過關直接修改受保護的 ADR/Allowlist/Policy。
- 非受影 READY 工作必須繼續；不要因只剩 Native/HGK/Checker 外部缺口，就提前
  宣稱這些項目完成。PARK 有明確 resume predicate；完成的合法 Plugin WorkPackage
  保留真 Runtime Evidence。
- 若本輪長任務 Session 被中斷，從真 Git HEAD、Source SHA 與 Checkpoint 恢復，
  不憑「上次說做完了」推定現況。更新本地 task board，不創造 Hermes 第二 Queue。

[DELIVERABLES]
1. 修訂的 sbl-tpm-sp 源樹或受權 Patch/PR Candidate；保持原 ID，禁止冒充已發版。
2. SourceManifest／24 原文全文／Indexed Clause／Conflict Registry／License/BOM。
3. 修復 P4 八 Skill/semantic tests、TQAEP Planned/Live、12→9 Risk、Oracle Binding。
4. Product/Systems/Technical Program 18 Contracts、QuestionLedger、GitHub Gate。
5. 六 Donor/24 Slot 選用紀錄和 Provider-off。
6. Clean Host UAT Raw（如 Host 不可得，標 `NOT_RUN`）；GJ01/02/03 Raw。
7. 每個 WP 的 PREIMAGE、git diff、tests、FirstFail、CLAIM CEILING、下一步。
8. Final Report 分 `CANDIDATE_PASS` / `HOST_QUALIFIED` / `NATIVE_NOT_RUN` / `RELEASE_FAIL_CLOSED`；
   不要把工作報告的完成當 World Effect 成功。

[STOP CONDITIONS]
立即停止**受影寫入或發布效果**：Root/HEAD/WriteSet 無效、來源 hash 不符、
GitHub Publisher 授權不明、Checker 主體與 Maker 沒有真隔離、Schema/Oracle
矛盾被嘗試強制洗白、外部效應 unknown、Secret/Private Source 可能外洩。
不要因此停止無關的唯讀、文件索引、差異分析、合法 Regression。
禁止自動提高 OS/Admin 權限、禁止暗中改 Host Settings/Secrets。

[FINAL REPORT FORMAT]
RunID; WorktreeRoot; Baseline/FinalHEAD; changed_paths/WriteSet; TestRunIDs/ExitCode;
CorpusSHA; P4-01..18; B1-RC-01..25 responsibility; TPM-STAGE 18; GH-01..12;
GJ01/02/03; HostUAT; NativeCapabilities; CR_OPEN; next_legal_action;
package_manifest_SHA; release_status; rollback_instructions.
未獲證據的項目寫 MISSING/NOT_RUN/UNVERIFIED，不得補假資料。
```

**Codex 指揮 Prompt 的 Claim Ceiling**：它能授權「按照已存在的合法 Permission 施工」，不能自己創造新的 Permission；`[MISSION]` 描述期望結果，不是允許對四個 Repo 隨意 Write 的全權憑證。**交付完整性必以真測試及實際 Diff 判定**，不可憑本 Prompt 承諾一次全自動成功。[N:PIPD-05;N:SBL-07/12;H:B1-RCA]

---

# 13｜Release 戰略、版本相容與最小可用節點

## 13.1 分層發行，不把 Native Factory 阻斷變成本地 Plugin 瀑布

| Milestone | 可對使用者宣稱 | 必須完成 | 不可宣稱 |
|---|---|---|---|
| `R0 SOURCE_BOUND_CANDIDATE` | 真來源目錄、P4 Patch、還未發版 | C00、必要文件 SHA | Plugin 已安裝 |
| `R1 PORTABLE_PLANNING_CANDIDATE` | TPM 18 Stage Design、GitHub Gate、自包含位元的候選 | C01～C05 Static POS/NEG | Source Ratification、Native Compiler 已真執行 |
| `R2 PLUGIN_HOST_QUALIFIED` | 指定 GPT/Codex Host 真掛載一套 Plugin，查詢基本 DOC 不需上傳 | C08/C09 真 Host UAT | 其它 Host 自動 PASS |
| `R3 PIPD_INTEGRATION_QUALIFIED` | 真 PIPD Native Compiler Reader／Subject Hash 一致 | G7、Oracle/StageMap 受影 Owner 決策及實測 | HGK/Hermes Native E2E 完工 |
| `R4 AUTHORIZED_PLUGIN_RELEASE` | 經合法 Publisher 發行的受限能力 | G0–G11 適用合取＋有權 Release | Checker 及 Native 可能未受影的所有功能均自動有權 |
| `R5 NATIVE_SBL_TPM_E2E` | 另一條 Native Factory 產品 | HGK/Hermes/Fabric/G-A/G-B/GWOs 真實收據 | 不能用 R4 代替 |

## 13.2 版本規則與授權

- 各版本須明確保留：`plugin_product_version / portable_manifest_version / codex_manifest_version / P4_skill_contract_version / PIPD_ABI_version / SBL_StageMap_version / corpus_manifest_sha / host_qualification_scope`。
- 先快照目前已觀察的私有 `sbl-tpm-sp` 版本 `0.1.1rc1` 與 P4 `0.1.1`，但正式施工以**現役 Plugin Export** 重算版本；不能假設本輪仍是這兩版。[H:DIALOGUE:§Plugin inspected]
- 根目錄 Manifest 與 `.codex-plugin/plugin.json` 如有各自版本，必須寫 `CompatibilityMap`，不可直接稱它們必然相同；原前輪觀察一份根版 `0.1.1rc1`、另一版 `1.0.0` 需綁定說明。[H:DIALOGUE:§Manifest]
- 自動更新只針對可回滾的候選；需要有 Owner 權限的 Plugin Release／Public Publish 不會因本地 `git commit` 自動完成。
- P4 Apache-2.0／TPM MIT、各 DOC、外部 Donor 授權的精確適用條件須在 C00 核實；無法確認可再散布權時，**不得將其打成公開 Plugin**。可先在合法的私人隔離環境建立 Design Candidate。[N:SBL-12]
- 未取得真 PIPD Compiler 時可以交付經測試的 Portable Planning Candidate，但不得宣稱正式 Native PI/PD Compiled；這個降級是明示的能力等級，不是「高自動化」失敗後的假綠燈。

## 13.3 文件交付與回滾

交付必附 `SourceManifest`、`Patch Set`、`Test Tracking`、`Plugin BOM`、`CompatibilityMap`、`License/NOTICE`、`ReleaseCandidateDigest`、`CR_OPEN`、Rollback Plan、Host UAT Raw。若 Codex 發現舊 Plugin 使用者依賴舊八 Skill 路徑，先建立 Legacy Invocation Resolver/Deprecation Notice，再在已測 Host 內發行新路由，勿直接刪原 P4 Plugin。回滾只回舊 Source+Package 版本，**不能回滾已撤銷的 Permit**。[N:SBL-12;N:PIPD-09]

---

# 14｜Machine-Readable 附錄（可直接從本 Markdown 擷取）

**所有狀態初始為 `NOT_RUN/FAIL_CLOSED`，不預填成功。** `<PLUGIN_ROOT>`、`<EVIDENCE_ROOT>` 是必須在 C00 真綁定的**相對工作樹候選路徑**，不是已存在 Windows 路徑。表格可以生成 WorkPackage/Diff/Test Board，但絕不可自行簽發 HGK/Checker/Publisher 權限。[D:UPGRADE;N:SBL-12]

## 14.1 `machine_summary.json`

```json
{
  "schema": "SBL.PortableTPMUpgradePlan@1",
  "document_id": "SBL-TPM-SP-CODEX-UPGRADE-20261027-R1",
  "date": "2026-10-27",
  "source_blueprint": "SBL-TPM-DUAL-20261027-R1",
  "mission": "upgrade existing sbl-tpm-sp as sole portable plugin, independently from native SBL-TPM factory",
  "status": {
    "plan": "DESIGN_CANDIDATE",
    "runtime_implementation": "NOT_EXECUTED",
    "host_qualification": "NOT_RUN",
    "native_e2e": "NOT_RUN",
    "release": "FAIL_CLOSED"
  },
  "product_criteria": {
    "only_one_portable_plugin": true,
    "base_document_reupload": false,
    "pipd_core_docs": 10,
    "sbl_core_docs": 14,
    "p4_lifecycle_skills": 8,
    "tpm_roles": 3,
    "stage_contracts": 18,
    "donor_count": 6,
    "donor_slots": 24,
    "github_decision_gate": "MANDATORY_NON_GLOBAL_BLOCKING",
    "remote_push_default": false
  },
  "authority": {
    "canonical_writer": "PIPD_EXISTING_OWNER",
    "native_issuer": "HGK_EXISTING_OWNER",
    "dispatcher": "HERMES_EXISTING_SINGLE_SPINE",
    "independent_checker": "SEPARATE_REAL_PRINCIPAL",
    "release_publisher": "AUTHORIZED_REPO_OWNER",
    "portable_plugin": "SBL_TPM_SP_PRODUCT_OWNER"
  },
  "implementation": {
    "primary_builder": "LOCAL_CODEX",
    "workpackages": [
      "C00",
      "C01",
      "C02",
      "C03",
      "C04",
      "C05",
      "C06",
      "C07",
      "C08",
      "C09",
      "C10",
      "C11"
    ],
    "max_scope": "AUTHORIZED_PLUGIN_WORKTREE_ONLY",
    "default_effect": "READ_ONLY_DISCOVERY",
    "no_auto_push": true,
    "no_second_queue": true,
    "no_second_compiler": true
  },
  "named_regression_sets": {
    "pipd_defects": 18,
    "b1_rc": 25,
    "github": 12,
    "self_contained": 8,
    "stage_contracts": 18,
    "donor_slots": 24,
    "golden_journeys": [
      "GJ01",
      "GJ02",
      "GJ03_SKILL",
      "GJ03_AGENT"
    ]
  },
  "mandatory_gates": [
    "G0-SOURCE",
    "G1-P4-FIXTURES",
    "G2-P4-SEMANTIC",
    "G3-TPM-ROLES",
    "G4-SELF-CONTAINED",
    "G5-GITHUB-QUESTION",
    "G6-HOST",
    "G8-B1-REGRESSIONS",
    "G9-GOLDEN",
    "G10-SECURITY",
    "G11-PORTABLE-RELEASE"
  ],
  "conditional_gates": [
    "G7-PIPD-CLI",
    "GHP-02-PUBLISHER",
    "NATIVE_SBL_TPM_E2E"
  ],
  "open_conflicts": [
    "CR-001-SOURCE",
    "CR-002-P4-ORACLE",
    "CR-003-STAGEMAP",
    "CR-004-P4-CLI",
    "CR-005-P4-FIX",
    "CR-006-OWNER-REPO",
    "CR-007-LICENSE",
    "CR-008-HOST",
    "CR-009-ABI",
    "CR-010-GITHUB",
    "CR-011-CHECKER",
    "CR-012-NATIVE",
    "CR-013-PROVENANCE",
    "CR-014-DONOR",
    "CR-015-MANIFEST",
    "CR-016-B1-CI"
  ],
  "release_rule": "All applicable required gates need real raw receipts + valid independent authorization; absence is FAIL_CLOSED; explicitly scoped draft milestone can be delivered as candidate without claiming release.",
  "key_source_locators": [
    "SBL DOC-01 C01.2/C08.2A/U21-U27",
    "SBL DOC-04 C12/C13",
    "SBL DOC-06 C32",
    "SBL DOC-12 C43",
    "PIPD DOC-03 TQAEP",
    "PIPD DOC-05 ExecutionAdmission",
    "PIPD DOC-06 12 risk axes",
    "PIPD DOC-07 Oracle Writer",
    "PIPD DOC-08 Progressive Disclosure",
    "PIPD DOC-09 CI/Claim",
    "FHS r2 §5.4 §6 §7 §12",
    "B1 Handoff §0/§2/§4"
  ]
}
```

## 14.2 `change_plan.tsv`

```tsv
workpackage	path_candidate	change_kind	purpose	risk	gate	initial_status
C00	<PLUGIN_ROOT>/plugin.json	READ_AUDIT	discover installed manifest/version; do not overwrite without snapshot	MEDIUM	baseline plugin export SHA	NOT_RUN
C00	<PLUGIN_ROOT>/.codex-plugin/plugin.json	READ_AUDIT	record version semantics and compatibility	MEDIUM	host manifest reader	NOT_RUN
C00	<PLUGIN_ROOT>/skills/tpm-sp/SKILL.md	BACKUP_READ	preserve JTBD/FUO/goal.open original contract	LOW	source SHA	NOT_RUN
C01	<PLUGIN_ROOT>/skills/pipd-pi-compile/tests/cases.yaml	PATCH	correct POS hash and retain NEG mutant	HIGH	P4-SEM-01	NOT_RUN
C01	<PLUGIN_ROOT>/skills/pipd-execution-contract/tests/cases.yaml	PATCH	correct POS/EDGE wrong PD subject	HIGH	P4-SEM-02	NOT_RUN
C01	<PLUGIN_ROOT>/skills/pipd-assurance-tqaep/tests/cases.yaml	PATCH	same operation checker receipt	HIGH	P4-SEM-03	NOT_RUN
C01	<PLUGIN_ROOT>/skills/pipd-package-project/tests/cases.yaml	PATCH	graph resolver provenance for edge count	HIGH	P4-SEM-04	NOT_RUN
C02	<PLUGIN_ROOT>/scripts/check_semantics.py	ADD	cross-object hash/subject/receipt/graph semantic validator	HIGH	G2-P4-SEMANTIC	NOT_RUN
C02	<PLUGIN_ROOT>/schemas/pipd-adapters/RiskMapping.schema.json	ADD	12-risk-axis to 9-context-axis versioned projection/veto	HIGH	P4-SEM-06	NOT_RUN
C02	<PLUGIN_ROOT>/schemas/pipd-adapters/OracleBinding.schema.json	ADD	owner/source/versioned oracle legacy bridge	HIGH	P4-SEM-07	NOT_RUN
C02	<PLUGIN_ROOT>/schemas/pipd-adapters/PlannedTQAEP.schema.json	ADD	planning without checker receipt or fabricated live PASS	HIGH	P4-SEM-08	NOT_RUN
C02	<PLUGIN_ROOT>/schemas/pipd-adapters/ErrorEnvelope.schema.json	ADD	affected-only first-fail and resume contract	MEDIUM	P4-SEM-13	NOT_RUN
C03	<PLUGIN_ROOT>/skills/tpm-product-plan/SKILL.md	ADD	PM role JTBD/Persona/FUO/source-bound product spec	MEDIUM	TPM-STAGE-01..06	NOT_RUN
C03	<PLUGIN_ROOT>/skills/tpm-system-plan/SKILL.md	ADD	SE trust seams/ADR/ABI/profile risks	MEDIUM	TPM-STAGE-07..12	NOT_RUN
C03	<PLUGIN_ROOT>/skills/tpm-program-plan/SKILL.md	ADD	dependency DAG, program spec, handoff	MEDIUM	TPM-STAGE-13..18	NOT_RUN
C03	<PLUGIN_ROOT>/references/compatibility/tstage-source-map.json	ADD	preserve 3 TStageMap sources and CR state	HIGH	CR-003-STAGEMAP	NOT_RUN
C04	<PLUGIN_ROOT>/references/corpus/pipd/	ADD	K0 full ten original docs pinned by SHA	HIGH	ZD-01..08	NOT_RUN
C04	<PLUGIN_ROOT>/references/corpus/sbl/	ADD	K0 full fourteen original docs pinned by SHA	HIGH	ZD-01..08	NOT_RUN
C04	<PLUGIN_ROOT>/references/corpus/SourceManifest.json	ADD	exact full text byte manifest and authority state	HIGH	G0-SOURCE	NOT_RUN
C04	<PLUGIN_ROOT>/references/index/clause-index.jsonl	ADD	K1 deterministic locators with authority and source SHA	MEDIUM	ZD-02	NOT_RUN
C04	<PLUGIN_ROOT>/scripts/verify_corpus.py	ADD	UTF8/SHA/root/count offline gate	HIGH	G4-SELF-CONTAINED	NOT_RUN
C05	<PLUGIN_ROOT>/schemas/sbl-tpm/GitHubDeliveryDecision.schema.json	ADD	GHP-01/GHP-02 delivery decision shape	MEDIUM	GH-01..12	NOT_RUN
C05	<PLUGIN_ROOT>/scripts/gate.py	ADD	remote effect deny by default, local planning gate	HIGH	GH-01..12	NOT_RUN
C06	<PLUGIN_ROOT>/references/compatibility/donor-admission.json	ADD	6 donor 24 slot, provider-off, license/host, no 2nd scheduler	MEDIUM	DONOR-01..24	NOT_RUN
C07	<PLUGIN_ROOT>/schemas/sbl-tpm/MissionHandoff.schema.json	ADD	portable/native ref-only typed ABI	HIGH	G7-PIPD-CLI	NOT_RUN
C08	<PLUGIN_ROOT>/CHANGELOG.md	MODIFY	versioned migration and security errata	LOW	RELEASE-01	NOT_RUN
C08	<PLUGIN_ROOT>/NOTICE	MODIFY_IF_AUTHORIZED	source attribution and legal obligations	HIGH	CR-007-LICENSE	NOT_RUN
C08	<PLUGIN_ROOT>/.github/workflows/sbl-tpm-candidate.yml	ADD	candidate CI only: read-only, no trusted check self-sign	HIGH	G10-SECURITY	NOT_RUN
C09	<EVIDENCE_ROOT>/host-uat/	GENERATE	real install/effective-load/trigger/nontrigger/uninstall receipts	HIGH	G6-HOST	NOT_RUN
C10	<PLUGIN_ROOT>/tests/golden_journeys/	ADD	GJ01/GJ02/GJ03 Skill+Agent	MEDIUM	G9-GOLDEN	NOT_RUN
C11	<EVIDENCE_ROOT>/final/	GENERATE	diff, test run raw, CR and release candidate not inflated	HIGH	G11-PORTABLE-RELEASE	NOT_RUN
```

## 14.3 `checkrun_contract.tsv`

```tsv
required_check	reporting_principal	gate	when_unavailable	initial_status
sbl-source-integrity	trusted build/candidate	G0-SOURCE	deny official source claim	NOT_RUN
sbl-p4-fixtures	CI candidate and tested runner	G1-P4-FIXTURES	abort semantic qualification	NOT_RUN
sbl-p4-semantic	CI candidate + PIPD owner	G2-P4-SEMANTIC	affected canonical hold	NOT_RUN
sbl-tpm-stage-18	CI candidate	G3-TPM-ROLES	stage candidate only; owner conflict hold	NOT_RUN
sbl-corpus-clean-host	Host QA	G4-SELF-CONTAINED	deny host-qualified claim	NOT_RUN
sbl-github-delivery-decision	CI candidate	G5-GITHUB-QUESTION	hold remote only	NOT_RUN
sbl-host-effective-load	Host QA	G6-HOST	package candidate only	NOT_RUN
sbl-pipd-native-compile	PIPD canonical runner	G7-PIPD-CLI	candidate only, not native compiled	NOT_RUN
sbl-b1-rac-regression	CI candidate + native owner if applicable	G8-B1-REGRESSIONS	native tests remain NOT_RUN	NOT_RUN
sbl-golden-journeys	Product QA + actual host	G9-GOLDEN	limited design candidate	NOT_RUN
sbl-security-scope	Security Owner + candidate tests	G10-SECURITY	no release, stop affected writes	NOT_RUN
sbl-package-candidate	PR-controlled CI	G11-PORTABLE-RELEASE	not a trusted independent check	NOT_RUN
sbl-independent-verified	separate protected verifier (not PR mutable)	external actual receipt	MISSING=release fail closed	NOT_RUN
sbl-plugin-release	authorized plugin publisher	G11 release authority	hold release when critical CR open	NOT_RUN
sbl-remote-publication	authorized GitHub Publisher	GHP-02	do not push	NOT_RUN
sbl-native-sbl-tpm-e2e	Hermes/HGK/Checker Native	external M4	do not claim native accepted	NOT_RUN
```

## 14.4 對 `Required Checks` 的實際配置禁令

上表的 `required_check` 是本產品的**候選命名契約**；不是聲稱現在 GitHub Repo Ruleset 已存在同名 Context。只有各 Repo 的有權 Admin，在核實實際 App ID、Protected Workflow Immutable SHA、Ruleset ID、`pull_request`／`merge_group` 觸發及 CheckRun Publisher Principal 後，才能將對應可信檢查設定成 Required。若保護來源不存在，維持 `CHECKER_UNAVAILABLE/FAIL-CLOSED`，不得由 PR Mutable Workflow 自行發布同名 `sbl-independent-verified` 取得假綠燈。[N:SBL-12:C43;N:PIPD-09]

---

# 15｜2026 工具參考證據（SUPPORT，不可覆蓋本專案 NORMATIVE）

| 工具／機制 | 支援資料 | 本案只承接的能力 | 需驗證的當前條件 |
|---|---|---|---|
| Agent Skills 規範 | https://agentskills.io/specification ; https://github.com/agentskills/agentskills | Progressive Disclosure，Skill Metadata/Reference | 各 Host 的實際 Loader 路徑/Case |
| OpenAI Portable Plugin | https://developers.openai.com/plugins/build/plugins ; https://developers.openai.com/plugins/concepts/plugins | Portable manifest／MCP tool boundary | 本地已安裝產品的真 Package Schema 和權限 |
| Codex CLI | https://developers.openai.com/codex/cli ; https://developers.openai.com/codex/non-interactive | Worktree/CLI/Script/Bounded Automation | Windows 現役 Codex 可用 CLI 與 sandbox |
| GitHub Actions Security | https://docs.github.com/en/actions/security-for-github-actions/security-guides/security-hardening-for-github-actions | least privileges, PR threat models | Trusted workflow/App/Action full SHA |
| GitHub Rulesets／Merge Queue | https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/managing-rulesets/about-rulesets ; https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/configuring-pull-request-merges/managing-a-merge-queue | exact check/app/sha/merge_group | 現役 Repo ruleset、分支和 App |
| OpenSSF Scorecard／SLSA | https://github.com/ossf/scorecard ; https://slsa.dev/spec/v1.2/ | supply-chain guidance/method candidate | License/attestation availability per repo/plan |
| OpenSpec | https://github.com/Fission-AI/OpenSpec | SpecDelta／Brownfield exploration，Thin Adapter | pin exact release/tool Host + true root |
| Spec Kit | https://github.com/github/spec-kit | Constitution/Specify/Plan/Tasks | 不取代 PIPD PI Canonical Compiler |
| Matt Skills | https://github.com/mattpocock/skills | grill-with-docs/domain-model/to-spec/TDD methods | License、exact task and Host routing |
| gstack | https://github.com/garrytan/gstack | Review/QA 方法為主 | Codex/Hermes Host support != full trusted hooks |
| Superpowers | https://github.com/obra/superpowers | TDD/debug/verification methods | Not a second governance authority |
| GSD | https://github.com/gsd-build/get-shit-done ; https://github.com/open-gsd/gsd-core | checkpoint planning, reference only | 舊 repo 封存；不要 pin floating latest/second queue |

**證據限度**：本表沿用已交付《SBL-TPM-SP & Native SBL-TPM 升級藍圖》r1 §5 的外部工具研究結論和官方 URL；仍需於 C00 真實施工當日再次確認所選版本／License／平台支援，因外部資料是 SUPPORT，不可覆寫 PIPD/SBL 正式上位 Source，也不能從 GitHub Stars 推斷安全／速度必然更好。[H:UPGRADE-BLUEPRINT:§5;N:SBL-06:C32]

---

# 16｜最後工程裁決

**正式建議：採「Codex 在單一受限 Plugin Worktree 主施工，原 P4 八技能受影修補→全文 Corpus 自包含→TPM 18 Contracts→GitHub 決策 Gate→單 Plugin Host Test→分層交付」。** 此方案保留 SBL One Core、PIPD Canonical、HGK/Hermes 既有權威，**不以重構 Native Factory 作為 Portable Plugin 的全域前置**；Native SBL-TPM 仍是另一產品／執行域，其未完成工作由有權 Owner 的獨立計畫交接。[N:SBL-01:C01.2;N:FHS-R2:§5.4;H:B1-HANDOFF]

**目前狀態：** `CODEX_IMPLEMENTATION_NOT_EXECUTED / SOURCE_AUTHORITIES_PARTIALLY_OPEN / P4_SEMANTIC_TEST_NOT_RUN / HOST_UAT_NOT_RUN / NATIVE_E2E_NOT_RUN / RELEASE_FAIL_CLOSED`。本文件提供逐項可施工變更、實作樣本、Master Prompt、測試／風險／回滾與完整來源 Locator，但**不構成**本地 CODEX 的原始碼修改、PIPD Compiler PASS、Plugin 更新或 GitHub/Native Effect 的實際收據。
