# CODEX 薄指揮 PROMPT｜SBL-TPM-SP／PIPD P4 整合修補升級

你是本地 **Codex 首席 Builder／回歸測試工程師**。**立即開始實際施工，不要只產出另一份計畫或詢問已知資訊。**以本機《SBL-TPM-SP_Codex_高自動化升級修補執行方案_r1_2026-10-27.md》（下稱「r1 方案」）作為 **C00～C11、G0～G11、逐項缺陷、測試及交付規格的詳細施工基線**；本 Prompt 是薄型執行入口，不能取代或降低 r1 方案的要求。

## 1｜指定來源與發現順序

以下 Windows 絕對路徑已由唯一人類 OWNER 指定；**先驗證存在、真實路徑、讀寫權限、Git Root、HEAD、Dirty/Untracked、工具與來源版本**，不得猜測其下的具體檔名、Repository 或 Plugin 套件位置：

- **PIPD DOC 原始來源（預設唯讀）**：`C:\Projects\Agent_Workspace\知識庫\實作相關DOC\Fabric vNext\Semantic World OS Fabric\PIPD\PIPD_LS`
- **PIPD-LS-SP 相關實作來源**：`C:\Projects\Agent_Workspace\PIPD`
- **SBL／既有 sbl-tpm-sp 相關實作來源**：`C:\Projects\Agent_Workspace\SBL`
- **r1 方案**：先在以上已知位置及 `C:\Projects\Agent_Workspace` 的受限文件搜尋中按確切檔名尋找；不要對整台電腦無界搜尋。

需要的 `SBL_PIPD-LS-PKG_DOC-00～13`、PIPD DOC-00～09、P4 八 Skill 的 `SKILL.md / contract / schemas / cases`、原 `sbl-tpm-sp` Manifest／Plugin 來源，依 r1 方案 §1、§8 在上述來源或已授權本地 Repository／匯出包定位。**ChatGPT 的 `app://Plugin_...` 是產品引用，不是 Windows 原始碼路徑；不可假裝本地能直接解參照。**缺某項來源先記 `MISSING/CR_OPEN`、繼續無關合法工作；不得杜撰原始正文、Oracle、二進位、Host Receipt 或版本 SHA。找到 r1 方案後先讀全檔 §0～§16，依其 `change_plan.tsv` 與 `checkrun_contract.tsv` 建工作追蹤。

## 2｜目標產品與不可降級的 SPEC

**唯一目標：完成可在 GPT／Codex 掛載的新版 Portable `SBL-TPM-SP`，優先沿用現有 Plugin 身份，並交付可回滾的安裝候選及真實測試紀錄。**

1. **只裝一套 Plugin／零 DOC 重傳**：把 PIPD DOC-00～09、SBL DOC-00～13 的適用全文與已修復 P4 八項 Skills、Schema、契約／Fixture 實質整合到同一候選 Plugin；K0 原文及 SHA、K1 條款索引、K2 經批准相容映射、K3 Progressive Disclosure。舊 P4 Plugin **不是**使用者的額外安裝前提。保留歷史 FHS／B1 資料的 SUPPORT 法位；未取得原件或散布權不可假稱來源閉合。
2. **保留 PIPD 唯一權威**：修復錯 Atom／Trace Hash、錯 PD Subject、Checker Receipt 錯配、Graph Edge／Profile Provenance 可重播性；建立可信的跨工件 Resolver／Semantic Validator、DOC-06 十二風險軸與 P4 九 Context Axes 版本化映射、安全 Veto、DOC-03／DOC-07 Oracle Binding、Planned TQAEP 與 Live Independent Acceptance 分離。保留原 Fixture 前像，錯正例須另生成 NEG Mutant，不以修改期望值掩蓋錯誤。
3. **TPM 產品完整化**：Product Manager／Systems Engineer／Technical Program Manager × T0～T5，共 **18 StageContracts**；JTBD、FUO、QuestionLedger、Quick／Guided／Critical、Product／Architecture／Program SPEC、ADR、Dependency DAG、POS／NEG。`CR-DOC04-STATE-MAP` 或 `CR-ORACLE-001` 未正式裁決時，只限制受影正式工件，保留各來源投影，不自創 Canonical 裁決。
4. **GitHub Decision Gate**：GHP-01 前期必檢、主動詢問一次且重用有效答案；`LOCAL_ONLY`／`DEFERRED`／`UNDECIDED` 不阻合法本地施工，但**不得 Push**。只有具有效 Publisher 權限、正確 Remote／Branch／Scope、GHP-02 預發布檢查及明確 Remote Delivery Decision 才可執行遠端效果；Push／PR／Merge／Release 必分開宣稱。
5. **單一 OWNER＋高自動化**：已回答的問題不重問；採 `READ_ONLY／REPO_WRITE／HOST／USER／REMOTE` 效果分類、受影 HOLD、`first_fail／affected_scope／allowed_next_action／resume_predicate`、有界 Red→Patch→Green，自動續做其它 READY 工作；不要為每次迭代重跑整套 SourceFreeze。
6. **Portable 與 Native 分離**：本次只施工 `SBL-TPM-SP`；對在 Hermes／HGK 運作的 **Native SBL-TPM E2E Factory** 僅交付版本化 `MissionHandoff`／ErrorEnvelope／ABI／證據候選。不得建立第二個 PIPD Canonical Writer、HGK Issuer、Hermes Durable Queue、Checker 或 Permission Plane；不得繞過 B1 對 Commander-SP 的禁用規則。
7. **不造輪子**：依 SBL DOC-06 六 Donor／24 能力槽位，盤點 OpenSpec／Spec Kit／Matt Skills／gstack／Superpowers／GSD，採 `KeepNative > ThinAdapter > MethodReuse > ProviderOff`；只納入有版本、授權與 Host 證據的功能，不把外部 Donor 安裝列為核心 TPM 的隱性依賴。

## 3｜唯一 OWNER 的本輪預先授權

**我作為唯一人類 OWNER，預先同意你在上述已核實、合法可寫的工程範圍內，對新版修補候選自主執行：隔離 Worktree／分支建立、必要最小程式修改、來源複本建置、依賴安裝（可信且可重播）、測試、候選 Plugin 打包、乾淨測試環境安裝／載入／卸載、故障注入、回歸、自修補、自迭代與可逆的本地交付。**授權已覆蓋同一 Subject、WriteSet 與合理測試循環，不要對相同操作逐次要求我確認。

此同意**不會自行產生** OS Administrator 權限、PIPD 正式 ExecutionAdmission、HGK Permit、Checker 獨立身份、GitHub Publisher Credential 或 Plugin 平台實際發布權限。**禁止**修改非受權 Root、破壞現有工作樹、提升系統權限、讀取或封裝秘密、對公開／遠端 Repo 無決策 Push、Merge、Tag、Release、直接覆寫現役正式 Plugin，或偽造測試／驗收收據。若指定範圍的真正寫入准入機制不存在，對受影寫入 Fail-Closed，保留候選 Patch；其它只讀及獨立合法工作繼續。

## 4｜按 r1 方案實際執行 C00～C11

- **C00**：盤點三根目錄及 r1 方案；來源完整性／授權／Plugin 真 Export／Compiler／Host 能力探測；備份原件、記錄 SHA／HEAD／Dirty；在隔離工作樹施工。
- **C01**：重現並修正 P4 八技能已知不一致的正向 Fixture；保留原錯例作負例。
- **C02**：實作 Artifact／Graph Resolver、Cross-object Semantic Gate、Risk 12→9、Oracle Binding、Planned TQAEP、Effect Adapter、Typed Error；不擅改現行 P4 同版限制 Schema。
- **C03**：完成 TPM 三角色 18 StageContracts、QuestionLedger、三種任務模式、Golden Journey 契約。
- **C04**：完整內建 10+14 DOC、Manifest、SHA、離線索引／Reader；缺原文、版本或散布權時精確 CR。
- **C05**：GitHub GHP-01/GHP-02 狀態機，實作 LOCAL_ONLY／DEFERRED／錯權限負例。
- **C06**：六 Donor／24 Slot 以可用工具重用為主，Provider-off 須不破壞核心能力。
- **C07**：Portable→Native `MissionHandoff`、版本／Subject／Hash 握手、局部阻斷與 Resume 契約。
- **C08**：單 Plugin 封裝、正確 Manifest／版本、BOM／License／NOTICE、候選安裝包及回滾。
- **C09**：**真乾淨 Host** 只掛新版 Plugin，無舊 P4／無 DOC 重傳：Install→Load→Trigger／Nontrigger→Invoke→Uninstall。
- **C10**：GJ01 Greenfield CLI、GJ02 Brownfield Repair、GJ03 Skill／Agent 兩變體，真 FUO＋POS／NEG。
- **C11**：覆核受影 Gate、整理原始證據／Diff／CR_OPEN／Release Decision、封存可回滾候選。

執行依賴遵循 r1 §7：`C00 → (C01,C03,C04) → (C02,C05,C06) → C07 → C08 → C09 → C10 → C11`；依實際依賴允許無關任務並行。每完成一張 WorkPackage 就落實 `evidence/checkpoints/<WP>.json`：Source SHA、Baseline/Current HEAD、Changed Paths、Tests/Exit Codes、FirstFail、Next Legal Action、Claim Ceiling；長任務重啟**從現役檔案、Git 與 Checkpoint 重建**，不可憑上一輪回話猜測完成。

## 5｜必須執行的 GATE／回歸與判定

完整依 r1 §10 的 **G0～G11** 和 `checkrun_contract.tsv`；至少覆蓋：

- **P4 18 類缺陷**逐項 POS＋NEG（包含 WrongHash／WrongSubject／WrongReceipt／Graph Provenance／Profile Veto／Oracle／TQAEP）；Schema-valid 不得代替 Semantic-valid。
- **B1 25 類根因**逐項對應 `PLUGIN_FIX／INTEGRATION_INTERFACE／NATIVE_EXTERNAL`，測試是否杜絕全域 HOLD、權限冒充、Package Seal 冒充 Mission Complete；Native 未跑必記 `NOT_RUN`。
- **24 冊 DOC** SHA／原文／索引與來源定位；乾淨環境只裝一套、零重傳；缺件或 SHA 改變必拒受影的正式 Source Claim。
- **18／18 TPM StageContract** 正反測、三類 SPEC 及適用 FUO；T4/T5 未決不可假 Ratify。
- **GH-01～12**：LOCAL_ONLY 不 Push、DEFERRED 本地可續、沒權限遠端拒收、Remote SHA／PR／CI 不混成 Release。
- **六 Donor／24 Slot** 有准入與 Provider-off 記錄；GJ01／GJ02／GJ03-SKILL／GJ03-AGENT 真 Runner／Host 證據。
- **Security／Host**：真 Root/HEAD/WriteSet、Symlink/Junction 越界、Secret Scan、錯版本、錯 Subject、Maker/Checker SoD、Install／Effective Load／Invoke／Uninstall、可回滾測試。

**遇測試失敗**：先保存 RED 原始紀錄→定位 FirstFail→最小 Patch→重跑該 POS/NEG/EDGE/SEC＋鄰近回歸；不得為刷綠放寬 Protected CI、Source、Oracle、Allowlist 或權限。受影外部缺口才 PARK，繼續其它 READY。`NOT_RUN ≠ FAIL ≠ PASS`。自己執行的 CI／測試不能冒充真正 Independent Checker。

## 6｜最終交付（禁止僅交報告）

交付 **實際已修改的可重播源樹／候選 Plugin 安裝包（或現有權限允許的原身份升級）**、原件 SHA／Diff、24 DOC 內建 Manifest 與檢索測試、P4 修補／語義回歸、TPM 18 合約、GitHub Decision、Donor Registry、Host 真收據、GJ 原始測試、回滾指令、`CR_OPEN` 及符合當前證據的 Release 判定。能合法更新並有效驗證私人 Plugin 時自動進行；平台操作權限缺失則輸出**可直接安裝的候選包及精確剩餘操作**，不虛稱已更新。

最後報告逐項列出 `C00..C11`、`G0..G11`、`P4-01..18`、`B1-RC-01..25` 的 `PASS／FAIL／NOT_RUN／BLOCKED`、實測命令與退出碼、產物路徑、Git SHA、受影缺口及下一合法步驟。**只有指定 Host 真載入且必要 Gate 全部有效通過，才宣告該 Host 的 Portable Plugin Qualified；Native SBL-TPM 的 E2E／正式獨立 Checker 未驗收，不得宣稱 Native Accepted 或 Production Released。**

**現在執行 C00，並直接持續推進所有具合法來源與權限的工作包。不要把首次盤點或文件封存當成任務完成。**
