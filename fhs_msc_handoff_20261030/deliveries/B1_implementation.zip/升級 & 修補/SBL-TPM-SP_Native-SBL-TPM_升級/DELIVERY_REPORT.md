# SBL-TPM-SP P4 整合升級：實測交付

已交付可重播私人候選，以及經明確批准的六檔公開 Adapter 候選分支；尚未完成 Portable Qualification／正式發布。

本地 Git：`8de6f43e398b4bf6c1d77bb9c052827f7359a5ce`；Baseline：`0109f34c0811cb2cf1573d837ff495c61139b483`。
安裝候選：`sbl-tpm-sp-0.2.0rc1-private.zip`（4,987,096 bytes），SHA-256：`7cc15a09dafee9f724306d802374c3161a7f5d0c964fd32f4287618e3b5f8c25`。兩次獨立打包逐位元相同。

24/24 Core DOC 與 r1 SHA 一致；r1 文字說 40 檔，但實際表格有 41 列，本輪保留並核對 41/41，不刪減分母。3,308 條索引；14 Skills；18 StageContract Draft；16 原 P4 Schema 逐位元未改。

107 個本地測試 PASS；原 Repo Runner 56/56 PASS；跨物件 Fixture/Mutant 63 PASS + 原 graph EDGE-001 BLOCKED。沒有將後者改期望值。真 CLI Profile/Intake/PI/PD/ECP 退出 0；缺 Checker Receipt 的 TQAEP 正確退出 2。

乾淨 Codex CLI 0.164.0 安裝成功，App Server skills/list 真載入 14 Skills，且卸載後 installed=[]。最終載入快照與候選逐檔相同。觸發／非觸發／模型 Invoke／GPT Portal／GJ03 Agent 未驗收，不能宣稱 HOST_QUALIFIED。

GJ01：真 wheel 建置、乾淨 venv 安裝、add/list/delete、負例與卸載；GJ02：真 Repo Red→Patch→Green、精確 src/api.py WriteSet、Git revert 回滾及再次恢復通過。兩者是本地 FUO，不冒充 Plugin/Native E2E。

## WorkPackages

| ID | 狀態 | 實際 Scope／剩餘條件 |
|---|---|---|
| C00 | PASS | Actual roots/dirty/HEAD, observed installed exports and all 41 pinned table entries inventoried |
| C01 | BLOCKED | 7 bad fixture joins repaired; 8 original mutants retained; native pack 56/56; original graph EDGE-001 unresolved |
| C02 | BLOCKED | Local semantic/risk/Oracle/plan adapters implemented; formal Owner Oracle/Profile mapping remains open |
| C03 | PASS | 18/18 source-bound stage drafts; three source views retained without ratification |
| C04 | PASS | 24/24 full Core DOCs and 17 SUPPORT rows exact SHA; 3308 clause index entries |
| C05 | PASS | GH-01..12 controls passed; exact six-file public candidate branch delivered and read back |
| C06 | PASS | 6 donors / 24 explicit Provider-off slots; core fallback passes; no donor runtime installed |
| C07 | PASS | Versioned handoff candidate, error/resume contract; native receiver deliberately UNBOUND |
| C08 | PASS | Private source/package/BOM/NOTICE and deterministic archive; prior identity retained as source name |
| C09 | BLOCKED | Actual clean CLI install, app-server 14-skill load and uninstall passed; model trigger/invoke NOT_RUN |
| C10 | BLOCKED | Real GJ01 wheel FUO and GJ02 Git repair+rollback passed; GJ03 variants NOT_RUN |
| C11 | PASS | Candidate, raw evidence, diff, Git bundle, checkpoints and truthful release decision delivered |

## Gates

| ID | 狀態 | 實際證據／受影缺口 |
|---|---|---|
| G0 | BLOCKED | 41 physical SHA matches; Source ratification/transitive originals/distribution grants remain open |
| G1 | BLOCKED | Native pack checker 56/56 PASS; semantic replay 63 PASS / original EDGE-001 BLOCKED |
| G2 | BLOCKED | Local semantic controls PASS; formal Oracle/Profile/source authority not ratified |
| G3 | PASS | 18 stage draft POS/NEG PASS; formal stage transitions remain HOLD |
| G4 | BLOCKED | Self-contained physical corpus and loader PASS; full clean model-session Reader acceptance NOT_RUN |
| G5 | PASS | 12 GitHub decision controls PASS; no unauthorized remote effect |
| G6 | BLOCKED | CLI install/load14/uninstall PASS; trigger/nontrigger/invoke NOT_RUN; GPT portal NOT_RUN |
| G7 | BLOCKED | Actual Profile/Intake/PI/PD/ECP exit 0; missing-receipt TQAEP correctly exit 2; P4/current CLI ABI Owner review open |
| G8 | BLOCKED | 25 local prevention controls tested; external Native root causes remain NOT_RUN |
| G9 | BLOCKED | GJ01 and GJ02 local scope PASS; GJ03-SKILL and GJ03-AGENT NOT_RUN |
| G10 | BLOCKED | Local secret/reparse/hardlink/scope controls PASS; public full-corpus license and trusted checker unavailable |
| G11 | BLOCKED | PORTABLE_RELEASE_FAIL_CLOSED; no independent/Owner release receipt and incomplete Host acceptance |

## P4 逐項

| ID | 狀態 | 判定 |
|---|---|---|
| P4-01 | PASS | Atom/trace hashes and parent joins fixed; original mutants refuse |
| P4-02 | PASS | PD Subject join corrected, including EDGE-001 |
| P4-03 | PASS | Historic receipt joins corrected; no live receipt claimed |
| P4-04 | BLOCKED | Actual native graph POS/NEG passed with 5 edges; original 0→2 case still blocked |
| P4-05 | PASS | Pinned catalog verifies file/body/Subject/version/currentness and graph endpoints |
| P4-06 | BLOCKED | All 12 facts retained; conservative veto; Owner mapping still proposed |
| P4-07 | BLOCKED | DOC07 Writer + DOC03 legacy bridge preserved; CR-ORACLE-001 open |
| P4-08 | PASS | Receipt-free PlannedTQAEP cannot report Live PASS |
| P4-09 | PASS | Effect classes separate; non-read effects require existing admission |
| P4-10 | BLOCKED | Self/mutable principal evidence rejected; protected checker absent |
| P4-11 | PASS | Family code never grants authority |
| P4-12 | PASS | Missing provider_off_required refuses in additive adapter |
| P4-13 | PASS | ErrorEnvelope and affected DAG preserve unrelated READY |
| P4-14 | PASS | Schema-valid WrongHash refuses semantic gate |
| P4-15 | PASS | Package seal cannot produce Mission Complete |
| P4-16 | PASS | Actual CLI invocation and Host skill load recorded separately |
| P4-17 | BLOCKED | Snapshots kept unratified; original Authority Owner not synthesized |
| P4-18 | BLOCKED | Actual install/load/uninstall passed; model invocation still missing |

## B1 逐項

每項 local prevention control 皆有作者側實測；Native 子集仍 NOT_RUN。

| ID | 責任 | 狀態 | Native |
|---|---|---|---|
| B1-RC-01 | NATIVE_EXTERNAL | NOT_RUN | NOT_RUN |
| B1-RC-02 | NATIVE_EXTERNAL | NOT_RUN | NOT_RUN |
| B1-RC-03 | PLUGIN_FIX | PASS | NOT_RUN |
| B1-RC-04 | PLUGIN_FIX | PASS | NOT_RUN |
| B1-RC-05 | NATIVE_EXTERNAL | NOT_RUN | NOT_RUN |
| B1-RC-06 | NATIVE_EXTERNAL | NOT_RUN | NOT_RUN |
| B1-RC-07 | PLUGIN_FIX | PASS | NOT_RUN |
| B1-RC-08 | PLUGIN_FIX | PASS | NOT_RUN |
| B1-RC-09 | NATIVE_EXTERNAL | NOT_RUN | NOT_RUN |
| B1-RC-10 | NATIVE_EXTERNAL | NOT_RUN | NOT_RUN |
| B1-RC-11 | PLUGIN_FIX | BLOCKED | NOT_RUN |
| B1-RC-12 | PLUGIN_FIX | BLOCKED | NOT_RUN |
| B1-RC-13 | PLUGIN_FIX | PASS | NOT_RUN |
| B1-RC-14 | INTEGRATION_INTERFACE | BLOCKED | NOT_RUN |
| B1-RC-15 | PLUGIN_FIX | PASS | NOT_RUN |
| B1-RC-16 | PLUGIN_FIX | PASS | NOT_RUN |
| B1-RC-17 | PLUGIN_FIX | PASS | NOT_RUN |
| B1-RC-18 | PLUGIN_FIX | PASS | NOT_RUN |
| B1-RC-19 | PLUGIN_FIX | PASS | NOT_RUN |
| B1-RC-20 | PLUGIN_FIX | PASS | NOT_RUN |
| B1-RC-21 | PLUGIN_FIX | PASS | NOT_RUN |
| B1-RC-22 | PLUGIN_FIX | PASS | NOT_RUN |
| B1-RC-23 | PLUGIN_FIX | PASS | NOT_RUN |
| B1-RC-24 | PLUGIN_FIX | PASS | NOT_RUN |
| B1-RC-25 | NATIVE_EXTERNAL | NOT_RUN | NOT_RUN |

## 實測命令及退出碼

| Run | 命令 | Exit |
|---|---|---:|
| controls-final | `C:\Users\user\AppData\Local\Programs\Python\Python311\python.exe -X utf8 -m unittest discover -s tests -v` | 1 |
| controls-final-normal-user | `C:\Users\user\AppData\Local\Programs\Python\Python311\python.exe -X utf8 -m unittest discover -s tests -v` | 0 |
| controls-green | `C:\Users\user\AppData\Local\Programs\Python\Python311\python.exe -X utf8 -m unittest discover -s tests -v` | 0 |
| controls-red | `C:\Users\user\AppData\Local\Programs\Python\Python311\python.exe -X utf8 -m unittest discover -s tests -v` | 1 |
| controls-release-candidate | `C:\Users\user\AppData\Local\Programs\Python\Python311\python.exe -X utf8 -m unittest discover -s tests -v` | 0 |
| corpus-green | `C:\Users\user\AppData\Local\Programs\Python\Python311\python.exe -X utf8 scripts/verify_corpus.py .` | 0 |
| package-1 | `C:\Users\user\AppData\Local\Programs\Python\Python311\python.exe -X utf8 scripts/package_preflight.py . ../../sbl-tpm-sp-0.2.0rc1-private.zip` | 0 |
| package-2 | `C:\Users\user\AppData\Local\Programs\Python\Python311\python.exe -X utf8 scripts/package_preflight.py . ../../sbl-tpm-sp-0.2.0rc1-repro.zip` | 0 |
| package-final-1 | `C:\Users\user\AppData\Local\Programs\Python\Python311\python.exe -X utf8 scripts/package_preflight.py . ../../sbl-tpm-sp-0.2.0rc1-private.zip` | 0 |
| package-final-2 | `C:\Users\user\AppData\Local\Programs\Python\Python311\python.exe -X utf8 scripts/package_preflight.py . ../../sbl-tpm-sp-0.2.0rc1-repro.zip` | 0 |
| package-sealed-1 | `C:\Users\user\AppData\Local\Programs\Python\Python311\python.exe -X utf8 scripts/package_preflight.py . ../../sbl-tpm-sp-0.2.0rc1-private.zip` | 0 |
| package-sealed-2 | `C:\Users\user\AppData\Local\Programs\Python\Python311\python.exe -X utf8 scripts/package_preflight.py . ../../sbl-tpm-sp-0.2.0rc1-repro.zip` | 0 |
| semantics | `C:\Users\user\AppData\Local\Programs\Python\Python311\python.exe -X utf8 scripts/check_semantics.py` | 2 |
| semantics-after-native-reseal | `C:\Users\user\AppData\Local\Programs\Python\Python311\python.exe -X utf8 scripts/check_semantics.py` | 2 |
| syntax | `C:\Users\user\AppData\Local\Programs\Python\Python311\python.exe -X utf8 -m compileall -q scripts` | 0 |
| native/profile | `C:\Users\user\AppData\Local\Programs\Python\Python311\python.exe -X utf8 -B -m pipd_ls_sp.cli --root C:\Users\user\Documents\Codex\2026-10-28\new-chat\work\native-probe profile --profile LITE --axis intent` | 0 |
| native/intake | `C:\Users\user\AppData\Local\Programs\Python\Python311\python.exe -X utf8 -B -m pipd_ls_sp.cli --root C:\Users\user\Documents\Codex\2026-10-28\new-chat\work\native-probe intake --goal Implement a todo CLI with source-bound acceptance and negative tests --source C:\Users\user\Documents\Codex\2026-10-28\new-chat\work\native-probe\source.md` | 0 |
| native/compile-pi | `C:\Users\user\AppData\Local\Programs\Python\Python311\python.exe -X utf8 -B -m pipd_ls_sp.cli --root C:\Users\user\Documents\Codex\2026-10-28\new-chat\work\native-probe compile-pi --intent C:\Users\user\Documents\Codex\2026-10-28\new-chat\work\native-probe\intent.json --profile LITE --replay` | 0 |
| native/bind-pd | `C:\Users\user\AppData\Local\Programs\Python\Python311\python.exe -X utf8 -B -m pipd_ls_sp.cli --root C:\Users\user\Documents\Codex\2026-10-28\new-chat\work\native-probe bind-pd --pi C:\Users\user\Documents\Codex\2026-10-28\new-chat\work\native-probe\pi.json --repo-root C:\Users\user\Documents\Codex\2026-10-28\new-chat\work\golden\GJ02` | 0 |
| native/compile-ecp | `C:\Users\user\AppData\Local\Programs\Python\Python311\python.exe -X utf8 -B -m pipd_ls_sp.cli --root C:\Users\user\Documents\Codex\2026-10-28\new-chat\work\native-probe compile-ecp --pd C:\Users\user\Documents\Codex\2026-10-28\new-chat\work\native-probe\pd.json --pi C:\Users\user\Documents\Codex\2026-10-28\new-chat\work\native-probe\pi.json` | 0 |
| native/compile-tqaep-no-live-receipt | `C:\Users\user\AppData\Local\Programs\Python\Python311\python.exe -X utf8 -B -m pipd_ls_sp.cli --root C:\Users\user\Documents\Codex\2026-10-28\new-chat\work\native-probe compile-tqaep --pi C:\Users\user\Documents\Codex\2026-10-28\new-chat\work\native-probe\pi.json --ecp C:\Users\user\Documents\Codex\2026-10-28\new-chat\work\native-probe\ecp.json` | 2 |

原 Repo Fixture Runner：`python -X utf8 -B <PIPD>/tools/skill_pack_check.py --all --skills-root <isolated-8-packs>`，Exit 0（修補前 Frontmatter 失敗 Exit 1 保留於 native-fixture-runner）。
Host 原始步驟及退出碼見 `evidence/host-uat-canonical/summary.json`、`loader-summary.json`；Golden 29 個命令見 `evidence/golden/summary.json`。

## CR_OPEN 與下一合法動作

公開交付：使用者明確批准確切六檔後，以指定憑證經 GitHub Git Data API 建立候選分支並逐檔讀回。Commit：`39517466009fb41226d66593f9be9dd52b02015a`；[候選分支](https://github.com/shw097-team/SBL/tree/codex/sbl-tpm-p4-upgrade-20261028)。main 未更動；PR 未建立、Merge／Tag／Release 未執行。先前自動審查拒絕及後續批准皆保留，不把來源候選說成完整 Plugin 已公開。

正式 Owner 仍須處理 CR-ORACLE-001、CR-DOC04-STATE-MAP、Source/GRP/Mount Profile、P4/current CLI ABI 相容性及 DOC/P4 再散布權。三份 StageMap 上位原件尚未逐份取得，只保留 DOC-04 報告的 SHA 與投影，沒有假稱原件已驗證。

原 Plugin Backend ID、平台更新能力及獨立受保護 Checker 不在本輪工具能力內；現役正式 Plugin 未被覆寫。Native Receiver/HGK/Hermes/Fabric/Model Served/G-A/G-B/GWO 未實跑，維持 NOT_RUN。

回滾：見候選 INSTALL.md；真隔離 Host 卸載已測過。`sbl-tpm-sp-private-history.bundle` 保存原件快照與候選提交；原件也在 evidence/baseline。回滾不復活已撤銷 Permit。

全部 checkpoint 在 evidence/checkpoints/C00.json～C11.json，原始 Diff 在 evidence/final/changes.patch，機讀總表在 evidence/final/status.json。

Release 判定：`PRIVATE_PORTABLE_REPAIR_AND_PLANNING_CANDIDATE / HOST_UNQUALIFIED / NATIVE_NOT_RUN / RELEASE_FAIL_CLOSED`。
