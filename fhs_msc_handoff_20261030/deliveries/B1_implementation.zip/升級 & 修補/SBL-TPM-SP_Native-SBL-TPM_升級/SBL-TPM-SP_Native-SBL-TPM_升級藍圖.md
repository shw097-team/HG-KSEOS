# SBL-TPM-SP & Native SBL-TPM｜2026 完整升級、整合與高自動化 E2E 工程藍圖

> **Blueprint ID** `SBL-TPM-DUAL-20261027-R1`  
> **日期** 2026-10-27（Asia/Taipei）  
> **版本** r1／DESIGN–IMPLEMENTATION BLUEPRINT  
> **最終裁決** **FAIL-CLOSED（Production Release）**；**PASS（形成可施工設計候選）**  
> **一句話結論**：以 Codex 主建置、Hermes/HG-KSEOS 真實 Native 驗收的雙形態架構，高保留修復 PIPD P4 與 SBL-TPM-SP，將內建 DOC、可恢復的工作 DAG、GitHub 必檢但非全域阻斷決策及開源 Donor 薄型重用整合成一條合法 E2E 鏈；**所有未有真實授權、Checker、Host Receipt 的效果維持 HOLD，不宣稱 Production PASS**。

**讀法與證據分類**：`[N:<source_id>:locator]` = 上位文件提供的規範/設計義務（不表示已 Ratified）；`[H:...]` = 歷史執行觀察；`[SUP-Wxx]` = 2026 Web SUPPORT；`[DESIGN]` = 本報告新增方案，須適用 Owner 批准；`[UNVERIFIED]` = 缺實機/原件；`[CR-xx]` = 外部待決。本文為**單一完整藍圖及範例程式碼**，不是修改既有 Plugin、修改四 Repo 或真 Native Acceptance 的證明。

**硬性不變量**：`NO_SOURCE_NO_NORM`／`NO_FAKE_PASS`／`ONE_CORE_NOT_ONE_PRINCIPAL`／`NO_SECOND_CANONICAL_WRITER`／`NO_SECOND_HERMES_QUEUE`／`NO_SECOND_HGK_ISSUER`／`CLAIM_CEILING_BY_EVIDENCE`／`AFFECTED_ONLY_HOLD`／`ZERO_BASE_DOC_REUPLOAD`／`GITHUB_ASK_ALWAYS_WHEN_UNDECIDED_NO_AUTO_PUSH`／`UNVERIFIED_RELEASE_BLOCKED`。[N:FHS-R2:§5.4,§6.1; N:SBL-01:C01.2; N:PIPD-05:ExecutionAdmission; N:PIPD-09:CI vs Acceptance]

---

# 0｜裁決總覽與可交付範圍

| 問題 | 結論 | Evidence／邊界 |
|---|---|---|
| 「只掛載一套新版 SBL-TPM-SP、不再上傳基礎 DOC」 | **P0 必需** | A 類全原文內建、SHA、按需檢索、乾淨 Host 無 DOC 測試。[H:DIALOGUE:L2124–2350] |
| TPM-SP 和 Hermes/HGK Native SBL-TPM 拆分 | **採納、同源不同部署** | 兩者消費同一 PIPD Canonical Reader／ABI；Native 由 HGK/Hermes 掌權。[N:SBL-01:C01.2; N:FHS-R2:§5.4] |
| GitHub 是否 Push 必檢/非全域阻斷/主動問 | **採納** | Planning Decision 必檢，Remote Effect 需獨立 Permit；`LOCAL_ONLY` 可以本地完成。[N:SBL-01:U26/U27,C08.2A; DESIGN] |
| Codex 或 Hermes 優先建造 | **Codex Builder → Hermes/HGK Native Integration → 隔離審查** | r10 真 Executor 未驗收；純 Doc/Schema/Fixture 修補不宜先綁未修 Native Loop。[H:B1-HANDOFF:§0] |
| PIPD P4 八技能原樣內建 | **不行，先修 Fixture/ABI** | Profile 12↔9、TQAEP Planned/Live、Trace Hash、Subject、Checker Receipt、Resolver。[H:DIALOGUE:L133–144,L399–483] |
| OpenSpec/Matt/gstack/Spec Kit/Superpowers/GSD | **保留 6 Donor/24 Slot，按能力授權、薄型重用** | gstack Codex experimental、Hermes instruction-only；Provider-off 不可冒稱等價。[N:SBL-06:C32; SUP-W09/W10] |
| 已可正式宣稱 FULL PRODUCTION | **不可，FAIL-CLOSED** | Native Compiler/Host/Checker/Corpus 權威來源、CI/WriteSet/StageMap 等未充分證成。[N:PIPD-09; H:B1-HANDOFF:§0] |

本報告的 **PASS** 僅指「所有已列入的可施工要求、證據不足與阻斷出口均有明確位置」，**不是**正式來源 Ratification、Plugin Portal 認證、SBL StageMap 裁決、B1 G-A/G-B 或任何 World Effect 的 PASS。

# 1｜Inputs Manifest：上位資料、聊天決策與 P4 工具清點

## 1.1 本輪真實可讀檔案

本輪透過本地容器**逐檔嚴格 UTF-8 讀取與 SHA-256 位元計算**；清點為 40 個 Markdown（不包含本次新報告）。`FOUND_LOCAL` 代表位元在目前本輪環境可讀，**不代表**文件已成為 Native Ratified 或已正式打包進 Plugin。以下 `SHA-256` 是**本輪物理檔案**摘要，不可假定等於文件內描述的上游原始 Source SHA。

| Source ID | 檔名 | 法位 | 文件定位 | Bytes | Lines | 物理 SHA-256 | 狀態 |
|---|---|---|---|---:|---:|---|---|
| `B1-LOG` | `B1指揮施工_總紀錄.md` | SUPPORT／HISTORY／DECISION | r1–r10 history and push 章節依內文 | 365,435 | 6,855 | `5e83ec59cf226d666146f0d73436cd87b30e35d30918657c6762f04ee576208c` | FOUND_LOCAL |
| `B1-PROMPT` | `B1施工_PROMPT.md` | SUPPORT／HISTORY／DECISION | r1–r10 directives 章節依內文 | 248,187 | 1,643 | `6f24b2aac28dd8b3aa4823250dc6c18115580f743f141d2db2fb3011e8804409` | FOUND_LOCAL |
| `B1-RCA` | `B1施工狀況_總鑑定分析.md` | SUPPORT／HISTORY／DECISION | B1 root cause and early stop 章節依內文 | 355,565 | 6,658 | `a7b17816b46d8f4ff38a3b62b336b7d36895d9730e82e6b8f892141f013f4936` | FOUND_LOCAL |
| `FHS-DISC` | `FHS-MSC_總討論(1).md` | SUPPORT／HISTORY／DECISION | RC-14; RC-17; FHS execution sequence L298–302, L2106+ | 283,613 | 4,930 | `9ecd1f6f1d9c854206eee4a12519b08e6caf61951a3735502654272416ae0597` | FOUND_LOCAL |
| `FHS-R2` | `FHS-MSC_藍圖_r2(2).md` | NORMATIVE-DESIGN-CANDIDATE | §5.4 Writer/Publisher; §7.1 DAG; R15.1 §3.3 L331–342, L419–436, L590–603 | 1,320,878 | 4,191 | `a80b3b4d7cc93e52a297a3e5176e27f207b36b8cd81a3d5440c70b4a80290ff9` | FOUND_LOCAL |
| `B1-00` | `FHS_MSC_B1_PIPD_LS_PKG_00_GOVERNANCE_AND_CONTROL(1).md` | NORMATIVE-B1-DESIGN-CANDIDATE | B1 design authority and claim 全文 | 10,324 | 111 | `3096e98096ad48b3b3cfda07c6075ccffba8b44c1851a804d63f0ab103aef576` | FOUND_LOCAL |
| `B1-01` | `FHS_MSC_B1_PIPD_LS_PKG_01_DOC_B1_PI(1).md` | NORMATIVE-B1-DESIGN-CANDIDATE | 27 atoms 全文 | 53,244 | 341 | `e1d8931c036a1e9dc97f79a3d0d00f151ea5a29dc81fb3d7aa488d5446d7b666` | FOUND_LOCAL |
| `B1-02` | `FHS_MSC_B1_PIPD_LS_PKG_02_DOC_B1_PD(1).md` | NORMATIVE-B1-DESIGN-CANDIDATE | 全文結構索引 定位為全檔；精確句須重查 | 62,807 | 1,289 | `8e15b92a69302bbb0f9a6352f80c9687fdfb3a217006703a87b3ba559f42eb2b` | FOUND_LOCAL |
| `B1-03` | `FHS_MSC_B1_PIPD_LS_PKG_03_DOC_B1_OPS_ECP(1).md` | NORMATIVE-B1-DESIGN-CANDIDATE | 全文結構索引 定位為全檔；精確句須重查 | 24,829 | 756 | `54a17818473f2a4b7c4f0f8f504bc96e4e1450540facfd30cf38234fa89e8b8a` | FOUND_LOCAL |
| `B1-04` | `FHS_MSC_B1_PIPD_LS_PKG_04_DOC_B1_DEV_ECP(1).md` | NORMATIVE-B1-DESIGN-CANDIDATE | 全文結構索引 定位為全檔；精確句須重查 | 9,287 | 101 | `7a1e44dfd91bd24011c019f3ff73446e6cebf4b7847d7220f7c78dc25927def5` | FOUND_LOCAL |
| `B1-05` | `FHS_MSC_B1_PIPD_LS_PKG_05_DOC_B1_TQAEP(1).md` | NORMATIVE-B1-DESIGN-CANDIDATE | TQAEP parent/child plans 全文 | 455,090 | 12,056 | `1e09126f0c8e92fcd6e8531072a3f1f3033d82a671c2b4bb62c9916e675b7127` | FOUND_LOCAL |
| `B1-06` | `FHS_MSC_B1_PIPD_LS_PKG_06_PRODUCT_COVERAGE_AND_R15(1).md` | NORMATIVE-B1-DESIGN-CANDIDATE | product identity obligation denominators 全文 | 859,287 | 6,919 | `f929d9cffd462d23bbdb52171f72a450e96e59c8333bc05ebd739a2d38338337` | FOUND_LOCAL |
| `B1-07` | `FHS_MSC_B1_PIPD_LS_PKG_07_NATIVE_TOOLCHAIN_EXACT_USAGE(1).md` | NORMATIVE-B1-DESIGN-CANDIDATE | 全文結構索引 定位為全檔；精確句須重查 | 19,392 | 141 | `d1e0283200ad57cf1a3a1fc62bc09c6980ff118d4b7af4401d011ea87a009ea7` | FOUND_LOCAL |
| `B1-08` | `FHS_MSC_B1_PIPD_LS_PKG_08_GOLDEN_WORKORDERS_E2E(1).md` | NORMATIVE-B1-DESIGN-CANDIDATE | three Golden WO 全文 | 6,741 | 70 | `bc12a5fca45e4f68c1b1a4772b00ca72e0c07be8293527bbaafceadc7347290f` | FOUND_LOCAL |
| `B1-HANDOFF` | `FHS_MSC_B1_Task_Handoff_Report_v1_2026-10-27.md` | SUPPORT／HISTORY／DECISION | r10 status and gates L9–70 | 80,850 | 734 | `aa006bc849c5bb6404265de6a28678e0a4ed8b75b13521b39d5dcf28fc07162d` | FOUND_LOCAL |
| `PIPD-00` | `PIPD_LS_DOC-00_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md` | NORMATIVE-DESIGN（生效/批准需核對） | 全文結構索引 定位為全檔；精確句須重查 | 251,982 | 2,292 | `be3a672ec20aa0e6b5e0e35097fc08de749bfe7f59f827d18e38aef67dd68ea4` | FOUND_LOCAL |
| `PIPD-01` | `PIPD_LS_DOC-01_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md` | NORMATIVE-DESIGN（生效/批准需核對） | 全文結構索引 定位為全檔；精確句須重查 | 177,451 | 2,592 | `b753f2e5cdd5598a818f8a113d57b7f815aeb3f1dfa061ce74c76bb3553ac8c7` | FOUND_LOCAL |
| `PIPD-02` | `PIPD_LS_DOC-02_2026-10-07_r2_HIGH_RETENTION_AUDIT_PATCHED_FULL_REPAIR_FULL_SUBSTANTIVE_BODY (1).md` | NORMATIVE-DESIGN（生效/批准需核對） | 全文結構索引 定位為全檔；精確句須重查 | 1,306,240 | 18,413 | `a021998dd3b63015e89af1dd40e0b413744a69b872da46c6bf5f4d92f7f23d0b` | FOUND_LOCAL |
| `PIPD-03` | `PIPD_LS_DOC-03_2026-10-07_r2_AUDIT_REPAIR_FULL_SUBSTANTIVE_BODY.md` | NORMATIVE-DESIGN（生效/批准需核對） | 全文結構索引 定位為全檔；精確句須重查 | 454,167 | 1,911 | `d89d82dcd2c8603ec6b86c5ec8c40845e4594bc181adf5272bd48a3de7c88f0f` | FOUND_LOCAL |
| `PIPD-04` | `PIPD_LS_DOC-04_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md` | NORMATIVE-DESIGN（生效/批准需核對） | 全文結構索引 定位為全檔；精確句須重查 | 181,988 | 4,052 | `fa64d84da3d747b183e4affff62f4d2fb86c80bb5075f5dd933c09b20caeddcf` | FOUND_LOCAL |
| `PIPD-05` | `PIPD_LS_DOC-05_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md` | NORMATIVE-DESIGN（生效/批准需核對） | 全文結構索引 定位為全檔；精確句須重查 | 227,894 | 3,946 | `7b40584540c162cda6debfd09a4c04321416706acdb03a7a3c2b41383dc585f4` | FOUND_LOCAL |
| `PIPD-06` | `PIPD_LS_DOC-06_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md` | NORMATIVE-DESIGN（生效/批准需核對） | risk 12 axes L195–279 | 405,028 | 3,790 | `20e44ea4dd8e53c9b0a076ce861136bbea86f52687019307f6e995cd9079d303` | FOUND_LOCAL |
| `PIPD-07` | `PIPD_LS_DOC-07_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md` | NORMATIVE-DESIGN（生效/批准需核對） | 全文結構索引 定位為全檔；精確句須重查 | 689,563 | 12,915 | `a68dae1c3670d07bcfa3476a1e37463c534594df5cd65d8dab0dca064b5a9fc1` | FOUND_LOCAL |
| `PIPD-08` | `PIPD_LS_DOC-08_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md` | NORMATIVE-DESIGN（生效/批准需核對） | progressive disclosure / adapter surface §4–7 | 197,972 | 2,501 | `e46caa7e440392a6cfa7a86421aead5bce8a2a229fec97b133429db6b6748e42` | FOUND_LOCAL |
| `PIPD-09` | `PIPD_LS_DOC-09_2026-10-07_r2_HIGH_RETENTION_AUDIT_PATCHED_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md` | NORMATIVE-DESIGN（生效/批准需核對） | claim separation and CI L45–71, L266–273 | 144,948 | 2,451 | `eaf0aefe2b4711c140fc3274223d88fdc38ad4ec2b7184f756a0f2471f3b0b54` | FOUND_LOCAL |
| `DIALOGUE` | `SBL-TPM-SP & Native SBL-TPM_升級討論.md` | SUPPORT／HISTORY／DECISION | prior 6 rounds and decisions L100–1149, L1210–2040, L2116–3049, L3060–4706 | 241,225 | 4,706 | `92305bce348b0dc4af27f9cf56432ba195b2ad5def3150440f0a61450c0b15c4` | FOUND_LOCAL |
| `SBL-00` | `SBL_PIPD-LS-PKG_DOC-00.md` | NORMATIVE-DESIGN（生效/批准需核對） | Router/Authority/Claim 全文；章節依有效索引 | 465,363 | 1,591 | `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01` | FOUND_LOCAL |
| `SBL-01` | `SBL_PIPD-LS-PKG_DOC-01.md` | NORMATIVE-DESIGN（生效/批准需核對） | C01.2; C08.2A; U21–U27 L653–664, L794–800, L1124–1159 | 1,041,962 | 4,938 | `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f` | FOUND_LOCAL |
| `SBL-02` | `SBL_PIPD-LS-PKG_DOC-02.md` | NORMATIVE-DESIGN（生效/批准需核對） | 全文結構索引 定位為全檔；精確句須重查 | 1,148,207 | 11,084 | `4ff0cda5ab00ba5f577151e5b004d2167d933e912e302c9e3529b237ccb9e035` | FOUND_LOCAL |
| `SBL-03` | `SBL_PIPD-LS-PKG_DOC-03.md` | NORMATIVE-DESIGN（生效/批准需核對） | 全文結構索引 定位為全檔；精確句須重查 | 1,704,253 | 4,851 | `ea69e1d3718ed86aecd74a3ebcc933960eacc30b586ab80fcb9f733037e33476` | FOUND_LOCAL |
| `SBL-04` | `SBL_PIPD-LS-PKG_DOC-04.md` | NORMATIVE-DESIGN（生效/批准需核對） | C12/C13; TStageMap conflict L468–506 | 618,110 | 3,036 | `ee90cb1c86f6f7350c11c9c962233a89b035ca41ff82c8968f7968608fc6f6e0` | FOUND_LOCAL |
| `SBL-05` | `SBL_PIPD-LS-PKG_DOC-05.md` | NORMATIVE-DESIGN（生效/批准需核對） | 全文結構索引 定位為全檔；精確句須重查 | 2,382,349 | 7,888 | `3b47a0b6224b1984a4047cf53aac5ac50615c93a560fea46e1b43d079a5d9f27` | FOUND_LOCAL |
| `SBL-06` | `SBL_PIPD-LS-PKG_DOC-06.md` | NORMATIVE-DESIGN（生效/批准需核對） | C32 six donors /24 slots L126–149 | 1,554,880 | 2,858 | `64ea4977dab3093301f82dc7469413cc754998fc53946467842e06d83645102b` | FOUND_LOCAL |
| `SBL-07` | `SBL_PIPD-LS-PKG_DOC-07.md` | NORMATIVE-DESIGN（生效/批准需核對） | 全文結構索引 定位為全檔；精確句須重查 | 1,265,128 | 3,620 | `a366d3783c82089c5593ffabb0704d8507632cce45622684f7a0186f2ae310f8` | FOUND_LOCAL |
| `SBL-08` | `SBL_PIPD-LS-PKG_DOC-08.md` | NORMATIVE-DESIGN（生效/批准需核對） | 全文結構索引 定位為全檔；精確句須重查 | 925,526 | 11,139 | `c7029c1ff07abe3135d33d3abf858a5fecedd911b494cd69c16eb1ddb8158288` | FOUND_LOCAL |
| `SBL-09` | `SBL_PIPD-LS-PKG_DOC-09.md` | NORMATIVE-DESIGN（生效/批准需核對） | 全文結構索引 定位為全檔；精確句須重查 | 904,598 | 3,978 | `6450f7c15915ec8b304f4e5fd4093ea707434db8bae9d2bb6e66c30ab6eed2e1` | FOUND_LOCAL |
| `SBL-10` | `SBL_PIPD-LS-PKG_DOC-10.md` | NORMATIVE-DESIGN（生效/批准需核對） | 全文結構索引 定位為全檔；精確句須重查 | 1,397,936 | 3,888 | `a64aa21c977334dd74d660a86377ee10c4d329aa5fde0dae25ff81a3e69e8d8f` | FOUND_LOCAL |
| `SBL-11` | `SBL_PIPD-LS-PKG_DOC-11.md` | NORMATIVE-DESIGN（生效/批准需核對） | 全文結構索引 定位為全檔；精確句須重查 | 1,831,131 | 5,005 | `12f8705d780b76f264457c194a6ff359da8d74b5d6d8c83fa245b74d2a37508e` | FOUND_LOCAL |
| `SBL-12` | `SBL_PIPD-LS-PKG_DOC-12.md` | NORMATIVE-DESIGN（生效/批准需核對） | C43 trusted verifier, Publisher L149–151, L1228–1241 | 982,931 | 7,940 | `d1e470d82ca14319582cb8947aa52007927aa38e726249b1430804cfe8c8ca56` | FOUND_LOCAL |
| `SBL-13` | `SBL_PIPD-LS-PKG_DOC-13.md` | NORMATIVE-DESIGN（生效/批准需核對） | 全文結構索引 定位為全檔；精確句須重查 | 1,251,068 | 3,814 | `7cc0c8b17311130c875910b2548b93c28bd4e1c8ee04d300f85fc33d4c09beb1` | FOUND_LOCAL |

## 1.2 P4 八項已安裝 Skill 實際讀取證明

本輪已按安裝技能 URI **直接重讀**八份 `skill.md`：

| URI 後段 | 真 Skill 約束（短摘） | 判斷 |
|---|---|---|
| `pipd-route-intake` | 有效 goal 與 source locators、五類 atoms、typed IntentCard | 保留，補 Source/Atom Sidecar |
| `pipd-authority-source` | family manifest SHA、R1/R2 分類、衝突即拒 | 需要有效 Registry，不依任意 Family 字串 |
| `pipd-profile-tailor` | LITE/STANDARD/ASSURED、九軸及升級 | 必須以 DOC-06 十二軸 Safety Veto 先行 [N:PIPD-06:§5] |
| `pipd-pi-compile` | frozen Intent、Profile、非空 atoms，固定 DOC-03 Oracle locator | Oracle ABI/Hash/Resolver 未閉合 |
| `pipd-pd-bind` | 真 RepoContext root/head/tracked/currentness/writable_scope | Repo-only，不擴張 Host Read-only |
| `pipd-execution-contract` | Repo PD、Token-required、at-most-once、residue scan、rollback | 效果分型，遠端 Push 獨立 Adapter |
| `pipd-assurance-tqaep` | 必須 maker≠checker＋checker_execution_receipt、直接獨立 CASE PASS | Planned 與 Live 強制分離 |
| `pipd-package-project` | ClaimCeiling、TraceClosure、Checker/Approval | Package Seal 不控制 Hermes Mission 結案 |

**重要範圍不足**：直接讀取 Skill 首頁不等於本輪重新取回全部 `references/contract.md`、`tests/cases.yaml` 和原生 Runtime Validator；先前會話之 P4 Fixture 具名問題屬**已記錄的靜態契約鑑定**，正式修補仍需從當前 Repository 再重播與對照。[H:DIALOGUE:L399–452; CR-04]

## 1.3 缺失與二手引用

| 來源/能力 | 本輪身份 | 狀態 | 阻斷範圍／可採降級 |
|---|---|---|---|
| 上位 PIPD Blueprint／Canonical Standard／Portable Mount Profile／GRP 原始完整檔 | 某些 DOC 引用有 SHA/片段，未全部另行附全原文 | **MISSING_FULL_OR_RATIFICATION** | 受影 SourceFreeze/正式 Release HOLD；可索引現有投影，但不能冒充原件 |
| SBL Master／原始設計卷的完整獨立原件及 N14 裁決 | SBL DOC 中有來源定位或投影；本輪無法逐一獨立取得全部原檔 | **MISSING_FULL_OR_OWNER_DECISION** | 受影歧義 Gate HOLD；保留三份 StageMap |
| 現役 `sbl-tpm-sp` 私人 Plugin 完整原始 Zip、當前 Validator 收據 | 前輪有查核，今次未把目前發行工件複製入容器 | **NOT_REVERIFIED_CURRENT_RELEASE** | 不宣稱能直接 Patch 此路徑；先 capability/source export |
| P4 `cases.yaml`、當前 Canonical Compiler Binary、Repo 僅有部分前輪報告的直接結果 | 本輪讀已安裝八 Skill 首頁；未完整重跑其 Runner | **PARTIAL_DIRECT** | 保留已知缺陷；當前版本 P4 POS/NEG 全量 PASS 不可宣稱 |
| 真 Windows HGK/Hermes/Fabric Loaded／Model Served／Checker | 本輪無遠端 OS 執行/權限 | **NOT_RUN** | Native Qualification／Production Release HOLD |
| 「本頁」未由本次匯出包含的其它歷史對話/附件 | 本輪以可見目前對話、完整 4706 行匯出與本地 40 檔為界 | **COVERAGE_BOUNDARY** | 不得宣稱看到未提供的其它私密聊天或任務 |

## 1.4 前輪決策覆蓋（可追溯至本次完整匯出）

| 歷次決策／失敗／需求 | 本報告章節 | 規範／歷史定位 |
|---|---|---|
| PIPD P4 上游治理失配、正例 Fixture 六缺陷 | §3、§6、§9 | [H:DIALOGUE:L133–146,L399–483] |
| FHS 舊規格已有方向但不是完成實作 | §2、§7、§12 | [H:DIALOGUE:L1283–1349] |
| TPM-SP 只是一個薄 Skill，三角色與 18 StageContracts 缺口 | §4、§7 | [H:DIALOGUE:L1387–1434; N:SBL-04:C13] |
| 一套安裝、基礎 DOC 不重傳、K0–K3 完整封裝 | §4、§8、§11 | [H:DIALOGUE:L2124–2350] |
| B1 r1～r10 25 根因與真 Native 未完成 | §3、§10 | [H:DIALOGUE:L2412–2532; H:B1-HANDOFF:§0] |
| Codex 主 Builder、HGK/Hermes 真整合、隔離 Checker | §7、§9 | [H:DIALOGUE:L3060–4000] |
| OpenSpec、Spec Kit、Matt、gstack、Superpowers、GSD | §5 | [N:SBL-06:C32; H:DIALOGUE:L3500+] |
| GitHub 必檢／非阻斷／主動問及 Local-only | §6、§8、§11 | [H:DIALOGUE:L4020–4706; N:SBL-01:C08.2A,U26,U27] |
| TPM-SP（GPT/Codex） vs Native SBL-TPM（Hermes/HGK） | §4、§7 | [H:DIALOGUE:L4300–4706; N:FHS-R2:§5.4] |
| 單一 OWNER＋分離機器 Principal／No second Queue | §4、§7、§10 | [N:FHS-R2:§6.1; N:SBL-01:C01.2] |

---
# 2｜Authority Stack：誰能定義規範、誰不能

## 2.1 來源優先序與投影約束

1. **生效的現役 Canonical Owner／授權 Policy／有版本原生 Schema**：PIPD 的 Source/PI/PD/ECP/TQAEP、HGK Admission/Permit、Hermes SharedSpine WorkState、各 Repo Publisher Ruleset、正式 Checker；**只有合法工具讀回其狀態時才能宣稱現役**。[N:FHS-R2:§5.4; N:SBL-01:C01.2]
2. **已獲批准且精確受影的 SBL/PIPD Normative DOC**：以原始版本、有效 SHA、AuthorityBinding、Supersession 判定。`NORMATIVE-DESIGN` 只是本次閱讀角色，不是 Owner 的簽章。[N:PIPD-00:Router; N:PIPD-01:Authority; N:SBL-00:source-index]
3. **FHS 藍圖 r2、SBL r2 候選、B1 r3 候選**：作為設計/控制目標；未 ratify 項目不得覆蓋第一層。[N:FHS-R2:§5.4; H:B1-00:design claim]
4. **《FHS 總討論》、B1 指揮/RCA/交接、此次 4706 行升級討論**：歷史 RCA 與已記錄決策的 SUPPORT，**不因詳細就成為原生系統真實性證明**。[H:DIALOGUE:L100–4706]
5. **2026 Web／GitHub 官方／社群**：SUPPORT／Donor 候選／技術相容資訊；不得覆寫任何來源家族的 Canonical Owner。[SUP-W01–W22]
6. **本報告的新 Contract／範例／路徑**：`DESIGN_PROPOSED`，只可進隔離測試；外部 Owner 批准、Host 綁定以前不具有 Native Effect 權限。

**排序不是文字篇幅的排序**。衝突：保存雙方原文、Source SHA、適用範圍及 CR_OPEN；範圍外的工作可照常繼續，受影正式效果不得默默自選「最新」或「看似合理」。[N:PIPD-05; N:PIPD-06; N:SBL-04:C13]

## 2.2 五個互不等價的成果狀態

`DESIGN_CANDIDATE ≠ SCHEMA_VALID ≠ SEMANTIC_VALID ≠ COMPILER_EXECUTED ≠ NATIVE_ACCEPTED ≠ RELEASED`。另行分離：`WORK_STATE{READY,RUNNING,PARKED,DONE}`、`LIFECYCLE_STATE`、`CLAIM_CEILING`、`DELIVERY_STATE{LOCAL,PUSHED,PR,MERGED,RELEASED}`；任何不能被真工具驗證的跨狀態提升均 `FAIL-CLOSED`。[N:PIPD-09:L45–71; N:SBL-12:C43; H:B1-RCA]

---
# 3｜RCA：故障樹、證據與最小修補點

## 3.1 核心症狀 → 根因 → 證據 → 修復

| 症狀 | 核心根因 | 直接定位或證據 | 最小修補（誰做） |
|---|---|---|---|
| B1 r10 提前停止，仍有 READY/NOT_RUN | 真 Hermes Executor/Stop Controller 未證成；文件 Seal 與 Mission Complete 混用 | [H:B1-HANDOFF:L9–70; H:B1-RCA:early-stop] | `MissionTerminalGate` 和 Durable Resume 由 Hermes 實作，TPM 只輸出 Typed WorkGraph |
| PIPD 源頭正式 Gate 造成跨域 HOLD | 源碼/Oracle/TaskKind 未閉合＋相依 DAG 太粗 | [H:DIALOGUE:L675–755; N:PIPD-00; N:PIPD-05] | Affected-only Dependency Resolver；唯讀/Repo/Host/User 分類 |
| 尚無 Native Issuer 又要求修 Native Issuer | Bootstrap Permission 循環 | [H:DIALOGUE:L745–757; N:FHS-R2:§7.1] | 由既有合法 Repo Admission＋最小 WriteSet/有效 Owner 授權破環；不能自造通道 |
| P4 POS 夾具跨 Hash／Subject／Receipt／Graph 不一致 | 形式 Schema 與語義驗證分離缺失；上下游 Resolver 不明 | [H:DIALOGUE:L405–475] | 修正原 Fixture＋CrossArtifact Semantic Validator＋受影 NEG，PIPD Owner |
| 十二軸安全風險不能由九軸 P4 原樣承接 | Profile 軸用途不同；缺 SafetyVeto 無損映射 | [N:PIPD-06:§5; H:DIALOGUE:L247–290] | Native RiskBinding 投影只增不減；缺 source `HOLD_FOR_PROFILE_OWNER` |
| TQAEP Plan 需要真 Checker Receipt | 時序混用：規劃和 Live Acceptance 重疊 | [N:PIPD-03:TQAEP distinctions; H:DIALOGUE:L353–381] | 分 `PLANNED/EXECUTED/INDEPENDENT_ACCEPTED`；新 ABI 需批准 |
| Oracles：DOC-03 Domain Oracle vs DOC-07 Writer | Legacy Locator／正式 Writer 身份不明 | [N:PIPD-07:Oracle Writer; H:DIALOGUE:L292–311] | Versioned OracleBinding＋原 Owner CR，而非改字串就強制 PASS |
| HGK User Trust 有測試但 Receiver 未接線 | Host 政策、Token、Receiver 路徑不同 | [H:B1-HANDOFF:§4; H:B1-RCA] | `native_admission.REGISTRY` 真受權 Receiver 綁定/負測 |
| Fabric R3／模型 R4 未測 | Stage/Active/Loaded、required/served 缺真收據 | [H:B1-HANDOFF:L9–70] | Native LiveProbe 與獨立 Checker；`NOT_RUN` 不能改 `FAIL` |
| PIPD Stage-C CI 曾 WriteSet fail | 實際寫入超出固定 allowlist | [H:B1-RCA:PIPD Stage-C] | 最小合法 Patch/CI 差異；禁止放寬 allowlist 以洗綠 |
| GitHub Candidate 未 Push、或 PR/CI 被當 Native PASS | Publisher/credential 有限；成果階段混用 | [H:FHS-DISC:L301; N:SBL-01:U26/U27; N:SBL-12:C43] | Decision GHP-01/02；真 Repo、SHA、Readback；獨立 Check App |
| 單 OWNER 反覆被問、又恐自簽 | 人類決策與機器 SoD 混淆 | [N:FHS-R2:§6.1; N:SBL-01:C01.2] | Standing Grant 受限授權＋不同真 Principal，不以模型名區分 |
| 使用者反覆上傳 DOC、Context 過大 | Plugin 沒內建全文、索引/版控缺乏 | [H:DIALOGUE:L2116–2350; N:PIPD-08:§4–7] | K0–K3 全原文＋檢索/完整性，自包含 UAT |
| 大產品 949 身份/625 Required 與工作卡混淆 | 義務分母和當輪可派工分母混用，另兩種 namespace | [H:DIALOGUE:L694–724; H:B1-HANDOFF] | ObligationLedger/Applicability/RuntimeWorkDAG 三層隔離 |
| SBL-TPM-SP 和 Native SBL-TPM 混為一物 | Portable Planning vs Native Execution 身份混淆 | [N:SBL-01:C01.2; N:FHS-R2:L590–603; H:DIALOGUE:L4300+] | Common ABI＋兩獨立部署，原 PIPD Writer 不變 |

## 3.2 B1 25 根因可施工閉合索引（依前輪 RC-01～25，並非本輪新增原始診斷結果）

| RC | Root Cause | 解法／工作包 | 責任 | 回歸測試 |
|---|---|---|---|---|
| 01 | Hermes 真 Executor／持久續航不足 | Durable Executor Adapter／OS Process Reboot | Native | B1-REC-01 |
| 02 | READY 未耗盡提前結案 | MissionTerminalGate 實時計算 | Native | B1-REC-02 |
| 03 | 局部 Native HOLD 擴全局 | Affected-only dependency graph | Plugin+Native | B1-REC-03 |
| 04 | Bootstrap Authorization 循環 | 既有合法 Repo ExecutionAdmission Minimal Cone | PIPD/HGK | B1-REC-04 |
| 05 | User Trust Receiver 接線不足 | native_admission REGISTRY readback | HGK | B1-REC-05 |
| 06 | Maker/Signer/Checker 隔離不足 | 真 Principal／Credential／不可變 Checker | HGK/Checker | B1-REC-06 |
| 07 | Design 候選被當 Runtime | 法位分離及 claim guards | Plugin | B1-REC-07 |
| 08 | PARK 和依賴局部性不足 | Typed ErrorEnvelope/Resume | Plugin+Hermes | B1-REC-08 |
| 09 | Fabric Stage≠Active≠Loaded≠Consumer | 四層 live evidence | Fabric | B1-REC-09 |
| 10 | required model≠served model | Provider/Model/Method/Transport readback | Native/Fabric | B1-REC-10 |
| 11 | Oracle DOC03/DOC07 ABI | Canonical OracleBinding／Legacy adapter | PIPD | B1-REC-11 |
| 12 | P4 risk 9 vs DOC06 12 | lossless RiskMapping safety veto | PIPD | B1-REC-12 |
| 13 | Planned TQAEP 混 Live receipt | 3-stage AssuranceState | PIPD/Checker | B1-REC-13 |
| 14 | Stage-C WriteSet fail | 不變更 allowlist 的合法 Patch | PIPD Repo | B1-REC-14 |
| 15 | Commander-SP 禁用與 Proposal 入口矛盾 | Non-Commander authorized receiver | SBL/HGK | B1-REC-15 |
| 16 | Diagnostic Retry 混 Native Effect Retry | Attempt Type＋UNKNOWN_EFFECT Reconcile | Plugin/HGK | B1-REC-16 |
| 17 | R15 全量分母當當輪工作 | obligation/applicability/DAG | Plugin | B1-REC-17 |
| 18 | SourceFreeze/Oracle 發行端假設存在 | capability probe + typed HOLD | PIPD | B1-REC-18 |
| 19 | PR/CI/Loaded/WorldEffect 互相借用 | evidence claim separation | Plugin/Checker | B1-REC-19 |
| 20 | Seal SHA 不一致 | 外部位元重算＋immutable snapshot | CI/Publisher | B1-REC-20 |
| 21 | Context 擁擠／缺 ResumeSnapshot | Progressive Disclosure/Versioned Snapshot | Plugin/Hermes | B1-REC-21 |
| 22 | Admin 權限被全域泛化 | EffectClass scope + least privilege | HGK | B1-REC-22 |
| 23 | Tool installed≠invoked | 5階 Tool Truth、真正 Invoke Receipt | Native/Plugin | B1-REC-23 |
| 24 | NOT_RUN/FAIL/HOLD/NO_FIT 混用 | TypedStatus/FirstFail | Plugin/Hermes | B1-REC-24 |
| 25 | 缺真 Issuer/Checker/3 GWO Receipt | subject/epoch/operation raw joins | Native/Checker | B1-REC-25 |

**驗收邏輯**：每項 RC 同時有「修復 Commit/變更」及「真受影 POS/NEG」才可標 `FIX_VERIFIED`；純文字方案為 `FIX_PLANNED`，外部 Native 未實際執行為 `NOT_RUN`。r10 已記錄 `0 new Native per-ID PASS`、`0/3 Golden WorkOrders`，本輪沒有新增 Native 收據。[H:B1-HANDOFF:L9–70]

## 3.3 分母不可互相轉換

B1 r3 控制包的 **27 Requirement Atoms、31 WO/OBS、120 Parent TQAEP、124 Child Cases、38 Conformance Nodes、949 Product Identities（66 Required/254 Conditional/629 Deferred）、192 Matrix Cells、81 Assets、3 Golden WOs**，是其固定文件分母。r10 Ledger 的 **1,565 identities（625 Required/285 Conditional/655 Deferred）** 屬另一個受影 ledger 命名空間；不能以 625 取代 66、不能把 949 個全部當 READY 工單，也不能因 Deferred 便刪掉 Requirement。[H:DIALOGUE:L694–724; H:B1-HANDOFF:L9–70]

---
# 4｜雙形態目標架構、權限與 E2E 事件流

## 4.1 雙產品、同一契約、原有權威

```text
                         ┌───────────────────────────────┐
                         │ Human OWNER (one person)      │
                         │ standing bounded grant       │
                         └────────────┬──────────────────┘
                                      │ Natural Language
              ┌───────────────────────┴───────────────────────┐
              ▼                                               ▼
  GPT/Codex/ChatGPT Host                              Hermes/HGK/SBL Host
  [Portable SBL-TPM-SP]                               [Native SBL-TPM]
  - one installed plugin                               - E2E factory coordinator
  - K0 full corpus/K1 index                            - durable Mission/WorkGraph
  - Product/System/Program                             - capability probe
  - repaired 8 PIPD skills                             - authorized adapters
  - Spec/PI/PD/ECP/TQAEP candidate                     - live build/test/repair
  - GHP GitHub Decision                                - local or remote delivery
              │                                               │
              └──────────┬─ Common versioned ABI ─────────────┘
                         ▼
                 PIPD Canonical Reader/Compiler  (NO SECOND WRITER)
                         │                         │
                 HGK Native Issuer/Receiver       Domain Evidence
                         │                         │
                 Hermes SharedSpine/Executor ── Fabric/SBL/Model Readback
                         │
                 Independent Checker ─ Authorized Publisher
```

兩者具有 **不同安裝包／不同可用工具／不同安全 Principal**，只共用經批准的 Source、Schema、Type、Oracles、Effect/Claim 對應。Portable Plugin 不是 Native Permit；Native Factory 不是第二個 PIPD Compiler。對於 B1，Commander-SP 原有禁用要求仍適用於 B1 這個產品路由，不擴張為全面廢除 SBL 上位三 SP。[N:SBL-01:C01.2; N:FHS-R2:§5.4; H:B1-HANDOFF:§0]

## 4.2 對外 API／ABI 建議（DESIGN_PROPOSED）

| 入口 | 消費者 | 輸入 | 合法輸出 | Effect class |
|---|---|---|---|---|
| `goal.open` | portable/Native | goal + source refs | SourceBound ProductBrief + QuestionLedger | READ_ONLY/PLAN |
| `tpm.plan` | TPM | Product/Architecture/Program specs | 18 typed stage projections + WorkDAG | DESIGN |
| `pipd.compile.request` | Canonical Compiler | frozen source+Profile+Intent refs | true PI/PD/ECP/TQAEP refs **only when executed** | COMPILER_EXACT |
| `mission.handoff` | HGK Receiver | Versioned Handoff + grant ref | ACCEPT/NACK + Native Mission Ref | AUTHORIZATION |
| `mission.run` | Hermes Executor | admitted WorkOrder refs | RAW + idempotency journal | REPO/HOST/USER |
| `mission.verify` | independent checker | frozen candidate + Oracles + RAW | scoped verified verdict | READ_ONLY in isolated principal |
| `github.decide` | QuestionGate | subject/version/current answer | GitHubDeliveryDecision@1 | READ_ONLY/PLAN |
| `github.publish` | authorized repo publisher | decision+permit+source/remote | branch/PR/remote SHA readback | REMOTE_WRITE |
| `mission.status` | read-only consumer | mission id | separate delivery/verification/mission status | READ_ONLY |

所有表格中的 API 名稱是目標 Adapter，非已證明當前 GitHub/Hermes 的真命令；Host Capability Probe 必須先取得真版本與簽入的路由，不能對假設命令進行世界效果。[DESIGN; CR-08]

## 4.3 F0–F10 E2E 流與事件矩陣

| Step/Event | 觸發 | 真 Owner／執行者 | 最小輸出 | 對未就緒的合法降級 |
|---|---|---|---|---|
| F0 `GOAL_RECEIVED` | User Natural Language | TPM | GoalCard、FUO | 缺新任務關鍵目標→QuestionLedger |
| F1 `SOURCE_CHECKED` | Goal 解讀 | PIPD Source Reader | SourceManifest/ConflictRegistry | 非受影 OBS 繼續，受影 Freeze HOLD |
| F2 `PROFILE_BOUND` | 真 risk facts | PIPD Profile Owner | 12-axis effective Profile | 不可映射→受影 ASSURED/HOLD，不降級 |
| F3 `SPEC_PREPARED` | Goal+source | TPM 3 roles | Product/Architecture/Program SPEC | StageMap conflict 視受影範圍 HOLD |
| F4 `PI_PD_COMPILE` | frozen+RepoContext | 真 PIPD Compiler | content-addressed refs | Compiler unavailable→Candidate Only |
| F5 `TQAEP_PLANNED` | PI/ECP | PIPD Assurance | test plan+oracle/evidence expectation | 無 Checker→PLANNED，非 FAIL |
| GHP1 `GITHUB_DECISION` | planning | SBL QuestionGate | LOCAL_ONLY/PENDING/REQUESTED | 不 Push，本地工作繼續 |
| F6 `ADMISSION_CHECK` | effect proposed | HGK Issuer/Receiver | admitted WorkOrder or NACK | 未授權只有 OBS/準備合法繼續 |
| F7 `BUILD_TEST_REPAIR` | ready/admitted | Hermes/Builder | commits/raw/errors/checkpoints | 只 PARK 受影並保留 resume predicate |
| F8 `INDEPENDENT_VERIFY` | frozen effect/readback | Checker | subject-bound verdict | checker missing→ASSURANCE_HOLD |
| GHP2 `PUBLISH_PREFLIGHT` | decision=yes+authorization | Repo Publisher | preflight/remote branch/PR | credential/policy fail→remote only PARK |
| F9 `DELIVERED` | contracted delivery met | SBL Delivery Owner | Local package or verified remote refs | Remote mandatory missing→delivery not done |
| F10 `MISSION_TERMINAL` | all applicable tasks resolved | Hermes terminal controller + qualified approver | native completed/blocked with evidence | READY>0 不得 final; park with wakeup |

**禁止**使用 package Seal、TQAEP Plan 或 GitHub CI Success 作 F10 的唯一停工訊號；真正 Native Approval 另有原生權限和聲明。[N:PIPD-09:L50; H:B1-RCA:early-stop]

## 4.4 單一 OWNER 的最小 Principal 配置

| Principal/角色 | 應擁有 | 不得擁有 | 驗證點 |
|---|---|---|---|
| Human Owner | Scope/Impact/Repo/Public visibility 授權決策 | 不必為每一 Worker 人工審核 | signed bound grant/ref/expiry |
| Codex Builder／Hermes Worker | 限定工作樹和受影 WriteSet | Signer key、Checker policy 修改、直接主分支寫入 | FS ACL/Repo permissions |
| PIPD Canonical Writer | PI/PD/ECP/TQAEP canonical write | HGK permit signing | canonical source identity |
| HGK Issuer／Receiver | 真 Native Admission、NACK、Revoke | 替 Maker 生成事後假 Raw | verified principal/nonce/epoch |
| Hermes Dispatcher | single queue/lease/checkpoint/terminal | 新增 PIPD canonical state | CAS epoch + recovery test |
| Independent Checker | Read frozen source/evidence、獨立 verdict | 修改 maker candidate 或共享可寫 policy | OS principal＋credential isolation |
| Repo Publisher | 受權精確 Repo/branch/PR | 未授權 Force push、秘密/任意公開 | ruleset and Remote SHA readback |

若 Maker 和 Checker 同一 Windows SID 且 Maker 可修改 checker 的規則、憑證或輸入，**不得以「兩個模型名不同」宣稱獨立 SoD PASS**。[H:DIALOGUE:L761–804; N:FHS-R2:§6.1]

---
# 5｜Web Research 2026：SUPPORT Evidence 與 Donor 選型

**方法**：本輪搜尋官方 GitHub/Docs、OpenSSF、SLSA、Sigstore、Agent Skills 及獨立專欄、2026 論文；官方規格作工具能力來源，獨立組織資料提供交叉或相反限制。對「產品自稱」而沒有第二個獨立技術驗證的具體 Host 成熟度，一律只記 `VENDOR_CLAIM / NATIVE_UAT_REQUIRED`，不虛構實測口碑、評分或效率提升。所有 Web 資料均屬 **SUPPORT**；下面推薦只在本報告作 `DESIGN`，不覆寫 NORMATIVE。

## 5.1 來源庫（URL、組織與驗證語義）

| ID | 官方或獨立來源 | URL | 用途／界線 |
|---|---|---|---|
| SUP-W01 | OpenAI Plugins：Portable Bundle（官方） | https://developers.openai.com/plugins/build/plugins | root plugin.json、skills、mcp.json、Codex compatibility；不同 Host 必 UAT |
| SUP-W02 | Agent Skills spec（標準維護者） | https://github.com/agentskills/agentskills/blob/main/docs/specification.mdx | SKILL.md、scripts/references、按需展開及 frontmatter |
| SUP-W03 | OpenAI Agents Plugins Guide（另一官方產品面） | https://developers.openai.com/api/docs/guides/agents-api/tools/plugins | ZIP/skills/MCP 的環境限制，產品接口可能不同 |
| SUP-W04 | GitHub Actions Secure Use（官方） | https://docs.github.com/en/actions/reference/security/secure-use | full commit SHA pin、least privilege |
| SUP-W05 | OpenSSF Scorecard（獨立基金會） | https://scorecard.dev/ | Dangerous Workflow、Token Permission、Pinned Dependencies |
| SUP-W06 | GitHub Repo Rulesets（官方） | https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/managing-rulesets/available-rules-for-rulesets | Required checks、expected GitHub App 身份、Merge Rule |
| SUP-W07 | GitHub Merge Queue（官方） | https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/configuring-pull-request-merges/managing-a-merge-queue | `merge_group` 必覆蓋；計畫適用時才啟用 |
| SUP-W08 | GitHub OIDC（官方） | https://docs.github.com/en/actions/how-tos/secure-your-work/security-harden-deployments/oidc-in-cloud-providers | 短期身份、無需長存雲端密鑰；不是直接的 GitHub Repo Permission |
| SUP-W09 | OpenSpec（Fission-AI 官方） | https://github.com/Fission-AI/OpenSpec | Explore/Propose/Apply/Verify/Archive，選用薄型變更轉譯 |
| SUP-W10 | OpenSpec Supported Tools（官方具體 Host 面） | https://github.com/Fission-AI/OpenSpec/blob/main/docs/supported-tools.md | Codex skills-only；路徑不當成通用所有 Host ABI |
| SUP-W11 | 2026 第三方 OpenSpec vs Spec Kit 實測分析（獨立部落格） | https://ypyl.github.io/programming/2026/06/03/openspec-vs-spec-kit-sdd.html | 小樣本經驗，無法代表本專案性能 |
| SUP-W12 | GitHub Spec Kit（官方） | https://github.com/github/spec-kit | Spec→Plan→Tasks/Implement；需量測相對治理成本 |
| SUP-W13 | Spec Kit 文件（同專案文件，不算獨立佐證） | https://github.github.com/spec-kit/ | 拆模組和 opt-in 的產品表面 |
| SUP-W14 | Matt Pocock Skills（官方 Repo） | https://github.com/mattpocock/skills | 訪談、domain-modeling、TDD、review，方法重用 |
| SUP-W15 | Matt TDD 文件（同供應方） | https://github.com/mattpocock/skills/blob/main/docs/engineering/tdd.md | 2026 當前 TDD 不一定包含獨立 Refactor；依真版本釘選 |
| SUP-W16 | Superpowers（獨立工具供應方） | https://github.com/obra/superpowers | 另一套 TDD、診斷、review，證明可以重用一般工程方法 |
| SUP-W17 | Superpowers 2026-10-21 Release Notes | https://github.com/obra/superpowers/blob/main/RELEASE-NOTES.md | Context-first 減少重問；供版本遷移評估 |
| SUP-W18 | gstack 官方 README | https://github.com/garrytan/gstack/blob/main/README.md | Codex experimental、Hermes instruction-only，非跨 Host Live PASS |
| SUP-W19 | gstack Adding Host（同供應方） | https://github.com/garrytan/gstack/blob/main/docs/ADDING_A_HOST.md | Hermes 需另行 cert，來源不是獨立驗收 |
| SUP-W20 | 舊 GSD Repo 已封存 | https://github.com/gsd-build/get-shit-done | **2026-06-26 archived**，不得視為活躍上游 |
| SUP-W21 | GSD Core 新 Repo（不同活躍維護位置） | https://github.com/open-gsd/gsd-core | 候選方法源，不能變第二 Hermes Scheduler |
| SUP-W22 | SLSA Provenance v1（標準方） | https://github.com/slsa-framework/slsa/blob/main/spec/build-provenance.md | subject/buildDefinition/builder.id/resolvedDependencies |
| SUP-W23 | GitHub Artifact Attestations（實作官方） | https://docs.github.com/en/actions/how-tos/secure-your-work/use-artifact-attestations/use-artifact-attestations | 建立及驗證工件溯源；私有 Repo 方案限制 |
| SUP-W24 | Sigstore Cosign（獨立開源方案） | https://docs.sigstore.dev/cosign/verifying/verify/ | 身份／OIDC Issuer 精確驗證候選 |
| SUP-W25 | GitHub fork PR 安全指南 | https://docs.github.com/en/actions/reference/security/securely-using-pull_request_target | 不得用高權限跑不信任 PR 原始碼 |
| SUP-W26 | 2026 安全掃描比較研究（學術 Support） | https://arxiv.org/abs/2601.14455 | 掃描器偵測範圍不同，不能單靠掃描綠燈 |
| SUP-W27 | 2026 SDD 深度分析（學術 Support） | https://arxiv.org/abs/2602.00180 | spec-first 的適用層級與簡化成本，不是本案效能實測 |
| SUP-W28 | OpenSSF Scorecard 維護評分研究（學術 Support） | https://arxiv.org/abs/2601.18344 | 評分不能預測專案未來維護品質，避免只看 Star |

## 5.2 雙獨立來源交叉驗證矩陣

| 技術主張 | 不同組織來源 ≥2 | 可採用結論 | 確信 |
|---|---|---|---|
| Agent Skills 應採 Progressive Disclosure 並封裝 references | OpenAI [SUP-W01]＋ Agent Skills 規範維護者 [SUP-W02] | 自包含但 Context 只按需載入 | CROSS-SUPPORTED |
| PR CI 不可執行帶 Secret 的不可信程式，Actions 用最小權限/完整 pin | GitHub [SUP-W04/W25]＋OpenSSF [SUP-W05]＋學術研究 [SUP-W26] | candidate CI 權限只讀；獨立可信 verifier 另開 | CROSS-SUPPORTED |
| 溯源 attestation 必須驗 subject 和 builder，CI 綠燈不等於 Release | SLSA [SUP-W22]＋GitHub [SUP-W23]＋Sigstore [SUP-W24] | 先驗 Artifact SHA/Signer/Policy，再宣稱受影資格 | CROSS-SUPPORTED |
| SDD 可用現成 Spec 工具但 Workflow 成本需選型 | OpenSpec [SUP-W09]＋GitHub Spec Kit [SUP-W12]＋獨立實測 [SUP-W11] | Brownfield 薄型首選 OpenSpec；高結構 Greenfield 可評估 Spec Kit | CROSS-SUPPORTED(方案比較); 本案效率 UNVERIFIED |
| 程式開發方法可借用而非另造 | Matt [SUP-W14/W15]＋Superpowers [SUP-W16/W17] | 重用 TDD/diagnosing/domain/model/review 方法，路由避免雙重啟用 | CROSS-SUPPORTED |
| gstack 真 Codex/Hermes Host 成熟度 | gstack 自身 [SUP-W18/W19]；**沒有獨立本案 UAT** | 暫定 `EVAL_ONLY`; 不以 README 等同成功部署 | **UNVERIFIED_HOST** |
| GSD 當前活躍來源已變動 | 舊 Repo archival notice [SUP-W20]＋新維護 Repo [SUP-W21] | 改採 `open-gsd/gsd-core` 作評估候選，舊 Repo 不再 Current | CROSS-SUPPORTED identity only |
| GitHub Artifact Attestation 適用於所有私有 Repo | 官方 GitHub 明示 Free/Pro/Team 私有 Repo 不通用 [SUP-W23]＋獨立 Sigstore [SUP-W24] 提供其它驗證方法 | **不能**全局 mandatory；Capability-by-Plan，無法使用時切換受權替代形式 | CROSS-SUPPORTED capability constraints |

**口碑/熱門度欄位誠實性**：本輪 Google/Web/GitHub 原始頁顯示部分 Star/Fork，卻沒有在同一日、同一 Host、同一基準測得 6 Donor 的 FUO/POS/NEG、安全與配置成本；不可憑 Star 直接宣稱「不用摸索試錯」。必須以真 Host Install/Trigger/Uninstall＋CI＋不執行敏感效果測試評估。對開源 Repo 作者自稱的功能，至少一個**獨立實跑**才可提升本案 Qualification。[SUP-W28]

## 5.3 六 Donor / 24 Slot 正式選型（對齊 SBL DOC-06 C32）

| Donor／槽位 | 2026 實際可用性 | 受控整合 | 最小要求／退出 | 風險 |
|---|---|---|---|---|
| **OpenSpec OS01–04** | CLI + Explore/Propose/Apply/Archive，Codex skills-only [SUP-W09/W10] | `SELECTIVE_NATIVE_REUSE` + thin SpecDelta adapter | 根目錄/Change ID/非零 test denominator/readback；缺則本地 SpecDelta Candidate | 不能取代 PIPD Writer；Root=錯 CI 可能假綠 [H:FHS-DISC:L298] |
| **Spec Kit SK01–04** | spec→plan→tasks／可選路線 [SUP-W12/W13] | `OPTIONAL_GREENFIELD`，不強制所有場景 | 輸出映射相同 SBL Spec/Task；反向卸載 | 避免第二 Spec Authority/重 Gate |
| **Matt Skills MP01–04** | grill-with-docs、domain model、to-spec、TDD/diagnosing [SUP-W14/W15] | `METHOD_REUSE` | 內建抽象方法/合法 License；已知答案不問 | 不因方法整合就要求再裝 Matt 全套 |
| **gstack GT01–04** | Codex experimental、Hermes instruction-only [SUP-W18/W19] | `REFERENCE/EVAL_ONLY` 到 host UAT | Product/Eng/QA/Release Review 規範；無資歷不得當 Checker | 同作者兩頁≠獨立能力驗證 |
| **Superpowers SP01–04** | TDD/debug/verification/worktrees [SUP-W16/W17] | `METHOD_REUSE` | Red→Green、最小 Change、completion truth | 完整工作流不能搶 Hermes Dispatcher |
| **GSD GS01–04** | 舊 `gsd-build` **archived 2026-06-26**；新 `open-gsd/gsd-core` [SUP-W20/W21] | `REFERENCE_ONLY`／新 Repo Evaluation | 只借 checkpoint/phase/Resume 方法；Provider-off | 新增第二持久 Scheduler 嚴禁 |

**不造輪子政策**：先 `KeepNative` → `ThinAdapter` → `ReusableMethod` → `ProviderOff`，只有經真 `NO_FIT` 與成本量測才准新增服務。`License/NOTICE/SBOM` 必經建置時核對；概念引用不等於有權再分發全部原始碼。[N:SBL-06:C32; SUP-W05]

## 5.4 開源/安全版本鎖定

不允許 `latest`、浮動 tag 或未經驗證的下載腳本直接進 Production 建置。`DonorAdmissionRecord@1` 固定 `{repo_url, immutable_sha, release_id, license, transitive_deps, host, start_command, rights, readback, POS/NEG, provider_off, rollback}`；OS/Windows、Codex/Desktop 和 Hermes 為不同 Host 資格，不互相借用。[N:SBL-06:C32; N:PIPD-02:TechnologyAdmission; SUP-W04/W05]

**2026 特殊提醒**：gstack 「Codex Experimental / Hermes Instruction-only」來自作者官方，不是本案 Host UAT。GSD 的歷史基礎文件若仍指向 `gsd-build/get-shit-done` 必改成「歷史來源」；新 `open-gsd/gsd-core` 的安裝操作、授權、API 與 Context 優勢仍須獨立在目標環境試測，不能套用舊 Repo Fixture。[SUP-W18/W20/W21]

---
# 6｜GitHub 必檢／非阻斷／主動詢問的 ECP＋TQAEP 修訂

## 6.1 決策 Gate 與 Remote Effect 必須分離

**規則 GHP-01**：對每個有可交付實作的 Mission，產生具版本 `GitHubDeliveryDecision@1`；同 Subject+QuestionKey+SchemaVersion 的有效 OWNER 決策只問一次，不因每張 ECP 重問；`UNDECIDED`→主動詢問三選一 `LOCAL_ONLY／CANDIDATE_BRANCH_PR／DEFERRED`。[N:SBL-01:C08.2A,L1124–1159; N:SBL-01:U26/U27; DESIGN]

**規則 GHP-02**：真正遠端寫入前，由 Repo Publisher 對 Repo ID/Branch/Visibility/SourceSHA/Secret Scan/Token Scope/Ruleset 和真授權重新核對。受影遠端 Publish 可 HOLD，本地獨立工作繼續；禁止預設自動 Push、Merge、Force Push 或把 PRIVATE 改 PUBLIC。[N:FHS-R2:§5.4,§7.1; N:SBL-12:C43; SUP-W04/W05]

`Decision必檢 != Push必做`。只有 Owner 明確指定 GitHub 遠端為交付 DoD，或有當前有效上位 Policy 要求該範圍的遠端交付時，Remote Gate 才成為該交付任務的必要 Exit；不得用 `LOCAL_ONLY` 規避生效的 U26/U27 Required Atom，應拆分 `LOCAL_DELIVERY_DONE` 與 `REMOTE_RELEASE_HOLD`。[N:SBL-01:U26/U27; DESIGN]

## 6.2 GitHub Decision 狀態機與事件

| 狀態 | 使用者已授權內容 | 允許的下一步 | 必須禁止 |
|---|---|---|---|
| `UNDECIDED` | 無 | ASK (一次)／合法本地工作 | Push |
| `ASKED_PENDING` | 已問，未答 | 其它獨立 WorkOrders | Push／擅自當拒絕 |
| `DEFERRED` | 明示稍後決定 | checkpoint＋提醒；繼續本地 | Push |
| `LOCAL_ONLY` | 明示不上傳 | Local QA＋Delivery | GitHub remote mutation |
| `PUBLISH_REQUESTED` | 希望 PR/remote，但未有有效發行許可 | Publish Preflight | Push/Permit 自製 |
| `PUBLISH_ADMITTED` | 真 Publisher 有 bound scope/token | 受限 feature branch Push、PR | 主分支直推、Secret、越界 |
| `PUBLISHED_VERIFIED` | 遠端 exact SHA readback | Candidate delivery | 自動聲稱 Merged/Released |
| `PUBLISH_BLOCKED` | remote 作用域不合法或缺資料 | PARK Remote only＋resume | 假 PR/CI PASS |

`PUBLISH_REQUESTED` 只表示產品偏好，**不是**原生權限。GitHub PR／Merge／Release／Host Loaded／Native Pass 各有獨立效果與 Receipt。[N:PIPD-09:L45–71; N:SBL-12:C43]

## 6.3 新 Extension 不得偷偷改 P4 `additionalProperties:false`

原 P4 `pipd-execution-contract` 是 Repo-bound PD 到單一 ECP 的既定 Schema；新增 `publish_to_github` 到同版輸入可能被 Schema 拒，亦混淆本地 Repo Write 與遠端 GitHub Effect。應以 **`SBL.GitHubDeliveryDecision@1` 和獨立 `PublicationEffectRequest@1`** 作旁路契約；相容層由適用 PIPD/Repo Owner 批准。[H:DIALOGUE:L328–351; N:PIPD-05:Effect; DESIGN]

**ECP 規則**：只有遠端發布確實適用，才生成獨立 EffectClass=`REMOTE_PUBLICATION`，包含 `{source_commit_sha,repo_id,expected_branch,write_scope,preflight_refs,admission,readback,unknown_effect_reconcile}`。沒有選擇 GitHub 的任務不應每張 ECP 重複添加無效的 GitHub Token Gate。

**TQAEP 規則**：PLANNED 包含 POS/NEG/EDGE/SEC 且不需真 Checker Receipt；Live Published 需真 remote SHA/PR/CI、不同有效 Principal Checker；其證據僅覆蓋精確 Subject，不轉換成 Native World Effect PASS。[N:PIPD-03:TQAEP distinctions; N:PIPD-09]

## 6.4 GitHub 交付效果真實性

`LOCAL_COMMIT → REMOTE_BRANCH → OPEN_PR → REQUIRED_CI → MERGED → RELEASED` 每一步需要各自 readback；Merge Queue 啟用時以 `merge_group.head_sha` 及有權 Check App 驗證 [SUP-W06/W07]。`push` 只可由已授權 Repo Publisher 執行；不可因 `gh auth status` 是綠燈就認定正確 Repo/Scope/Principal。[N:SBL-12:C43; SUP-W06]

**必跑 GH 測試**：`LOCAL_ONLY` 無 Push、`ASKED_PENDING` 無全域停工、同 Question 不重問、無憑證 Remote HOLD、不信任 PR 無 secrets、Wrong Repo/Branch Reject、Push succeeded 但 Remote SHA mismatch Reject、PR Open 不當作 Merged、Required Check 同名但不同 App Reject、無合適私有 Attestation 計畫需受權替代。[N:SBL-01:C08.2A; N:SBL-12:C43; SUP-W04/W05/W06/W23]

---
# 7｜治理收斂、自治運行與專案施工分工

## 7.1 三種不同的准入等級

| Layer | 操作類別 | 合法前置 | 不應追加的前置 | Claim |
|---|---|---|---|---|
| L0 | Read-only Inspection/Spec/Design | Source Reader、Read Scope、資料敏感性 | 無關的完整 HGK Native Permit、ECP Mutation Token | OBS/DESIGN |
| L1 | Bounded Repo Engineering / Red→Green | 真 RepoContext、精確 WriteSet、Repo ExecutionAdmission／Owner scope | 未受影的 Fabric Loaded/G-B | DEV CANDIDATE/TESTED |
| L2 | Host/User/Remote/Privileged/Irreversible Effect | 真 Native Issuer 或各正式 Effect Owner、有權 Credential、Readback、Checker | 不合法的超全域 Gate | EFFECT/BY-RECEIPT |

`L0/L1/L2` 是本藍圖施工分類，不是新增 PIPD 正式 State Enum；不可用 L1 文字代替有效 Permission，也不可因某項未生效的 L2 驗收 Gate 暫停所有 L0 工作。[N:PIPD-05; N:FHS-R2:§6/§7; H:B1-RCA]

## 7.2 故障包統一 ErrorEnvelope@1（建議 Adapter）

```yaml
schema: SBL.PIPD.ErrorEnvelope@1
subject_ref: '<EXACT_SUBJECT_REF>'
first_fail_code: ORACLE_BINDING_CONFLICT
blocking_dependency: 'OracleBinding@exact-sha'
affected_work_ids: ['PI-17']
recoverability: OWNER_DECISION_REQUIRED
allowed_next_action: READ_ONLY_SOURCE_RECONCILIATION
resume_predicate: VALID_OWNER_RATIFICATION_AND_CURRENTNESS
expected_evidence: ['oracle_authority_receipt', 'source_sha_join']
claim_ceiling: DESIGN_CANDIDATE
other_admitted_ready_work: CONTINUE
```

`ErrorEnvelope` 不擁有 Hermes Queue State；Receiver 只消費它來 `PARK` 受影項目，SharedSpine 同一個 Queue 仍是唯一 WorkState。非法 `HOLD`→`SUCCESS` 轉換需重新執行真 Gate，不得由 GPT/Codex 語言改欄。[H:DIALOGUE:L504–531; N:SBL-01:C01.2]

## 7.3 Hermes/HGK 真續航（以現役 SharedSpine Adapter 實作，禁止第二 Queue）

```python
# DESIGN_PSEUDOCODE — not a deployed Hermes API.
# Replace spine.* names only after capability discovery of the REAL SharedSpine ABI.
def run_once(spine, native_executor, checker):
    spine.reconcile_unknown_effects()   # must read actual effect journal first
    ready = spine.list_admitted_ready()   # current scope/epoch/permit re-check
    for work in ready:
        lease = spine.compare_and_swap_lease(work.id, work.version)
        if not lease:
            continue
        try:
            result = native_executor.execute_admitted(work, lease)
            spine.store_raw_and_update(work.id, lease, result)
        except Exception as exc:
            spine.record_typed_first_fail(work.id, lease, exc)
    snap = spine.authoritative_snapshot()  # includes READY/RUNNING/PARKED
    if snap.ready or snap.running or snap.unknown_effects:
        return 'CONTINUE_OR_RECONCILE'
    if snap.parked:
        spine.ensure_external_wakeup_for_all(snap.parked)
        return 'CYCLE_PARKED_NOT_MISSION_COMPLETE'
    if checker.validated_mission_claim(snap):
        return 'REQUEST_NATIVE_TERMINAL_APPROVAL'
    return 'EVIDENCE_HOLD'
```

需要 OS Process Restart、新 Job 續行、CAS lease、Token Revoke、Unknown Effect Reconciliation、Ready>0 NoStop、三個 GWO 獨立收據及 G-B 撤銷外援後續行實測。上面**只是演算法範例，不代表已發現 `spine.list_admitted_ready` 真方法**。[N:FHS-R2:§7; H:B1-HANDOFF:§0,§4; DESIGN]

## 7.4 Codex vs Hermes 施工責任

| 工作類型 | 首選建造者 | 必需的獨立證據 | 原因 |
|---|---|---|---|
| 40 DOC 索引、P4 Fixture/Schema、Plugin 打包/回歸 | Codex（真本地 Worktree） | stable SHA、Red→Green、Package check | 不受未修 Hermes Runtime 綁住 [H:B1-HANDOFF:§0] |
| SBL 3 角色 × T0–T5、QuestionGate、Donor Compatibility | Codex/SBL TPM Owner | Golden Journey＋StateMap Ratification | 規劃工作不需先 Host Native Permit |
| HGK Issuer/Receiver、Fabric Loaded、Model Served、OS restart | Hermes/HGK 各真 Owner | Native Raw／SEC NEG／不同 Principal | Codex 模擬不得代用 |
| PIPD Canonical Writer/Oracle/Risk/Schema 版本 | PIPD Owner/合法 Compiler | 真 Compiler/Source Join | 不得另造 Authority |
| GitHub Push/PR/CI/Release | Repo Publisher / trusted CI App | SourceSHA/RemoteSHA/Ruleset/App ID | Owner 偏好非 Credential |
| 終驗 | isolated Codex review ＋ **真獨立 Checker** | new context for challenge; actual isolated principal for formal verdict | 同一施工主體自評≠SoD |

**先行順序**：Codex 的 source/fixture/schema/Corpus 修補可以與 Hermes HGK 的 Receiver/Executor 最小探測**並行**；不將所有 Native Gate 放在全部文檔修補前面，也不等整套 Plugin 都完成才第一次 Host Smoke Test。[H:DIALOGUE:L3060–4040; N:FHS-R2:§7.1]

## 7.5 最小可運作切片（按 FUO 验收，不重造全 SBL）

`FUO-1`：乾淨 Codex/GPT Host，單一 Plugin 啟用後不再上傳基礎 DOC，能生成 Product/Architecture/Program SPEC＋GitHub Local-only Decision；`FUO-2`：真 RepoContext → PIPD 正式 Compiler → Red/Green Candidate；`FUO-3`：Native small WorkOrder 在 HGK Admission 後由 Hermes 新 OS Process 完成並經 Checker；`FUO-4`：有授權時真 PR Publish Readback。這四條路徑分別資格化，不能一條 UAT 代替全部。[N:SBL-04:C13; N:FHS-R2:§7.1]

---
# 8｜自包含 Plugin、Native Factory 及跨 Host 目標檔案布局

**路徑是建議相對路徑**；對未讀現役 Repository 完整 Tree 的路徑一律標 `NEW_PROPOSED` 或 `PATCH_AFTER_DISCOVERY`，不得照本藍圖盲寫現役 Repo。禁止在舊 P4 或私有 TPM 插件上原地修改而無備份。[N:SBL-12:Distribution; SUP-W01]

```text
sbl-tpm-sp/                       # ONE portable distribution identity
  plugin.json                     # portable manifest; actual schema via host UAT
  .codex-plugin/plugin.json       # optional Codex compatibility, versions coherent
  skills/
    tpm-sp/SKILL.md
    tpm-product-plan/SKILL.md
    tpm-system-plan/SKILL.md
    tpm-program-plan/SKILL.md
    tpm-handoff/SKILL.md
    tpm-setup/SKILL.md
    pipd-route-intake/SKILL.md
    pipd-authority-source/SKILL.md
    pipd-profile-tailor/SKILL.md
    pipd-pi-compile/SKILL.md
    pipd-pd-bind/SKILL.md
    pipd-execution-contract/SKILL.md
    pipd-assurance-tqaep/SKILL.md
    pipd-package-project/SKILL.md
  references/
    corpus/raw/pipd-doc00-09/*.md  # K0 FULL, exact file identities
    corpus/raw/sbl-doc00-13/*.md
    corpus/raw/fhs-and-b1/*.md
    corpus/SourceManifest.json     # K1 version/hash/authority
    corpus/ClauseIndex.json       # K1 exact clause locator, query layer
    corpus/Supersession.json      # K2 only ratified replacements
    corpus/ConflictRegistry.json  # K2 unresolved not overwritten
  schemas/sbl-tpm/*.schema.json   # design extensions, P4 schema versioned
  adapters/                     # Thin CLI/MCP, not a second compiler
  scripts/verify_corpus.py
  scripts/gate.py
  tests/{fixtures,semantic,security,golden,hosts}/
  sbom/ NOTICE LICENSES README.md CHANGELOG.md

native-sbl-tpm/                   # separate deployment; **NOT portable plugin payload**
  adapters/pipd_reader.py
  adapters/hgk_receiver.py
  adapters/hermes_spine.py
  adapters/fabric_readback.py
  adapters/repo_publisher.py
  contracts/MissionHandoff.schema.json
  config/allowed-capabilities.json
  tests/{native,soD,restart,e2e}/
```

**A 類完整內建文件**：PIPD 10＋SBL 14 的原文、版本、Oracle／Schema/Fixture 有效部分（若具散布授權）；**B 類**：FHS/B1/施工/對話失效案例作受限 Reference。K0 完全保留位元，K1 標引定位，K2 僅作已批准映射，K3 按需消費；絕不把所有 25+ MB 每次全塞 Context。[H:DIALOGUE:L2164–2350; N:PIPD-08; SUP-W01/W02]

**重要產品界線**：即使 40 份本地文件均 `FOUND_LOCAL`，缺上位原件及未批准 N14/Oracle/StageMap 不代表 Self-contained Normalized Normative Bundle 已閉合。可先達 `CORPUS_SNAPSHOT_COMPLETE_FOR_LISTED_40`，再於 Owner 批准及依賴 closure 後宣稱 `SELF_CONTAINED_NORMATIVE_READY`；兩者不同。[N:SBL-00; CR-01/02]

**Version Matrix**：`{portable_plugin_version, native_factory_version, corpus_version, canonical_pipd_abi, tpm_stage_map_version, host_adapter_version, donor_lock_version}`。任何 source SHA drift 只 invalidate 真受影依賴並保留以前候選；Currentness 絕不由模型記憶推定。[N:PIPD-03:Late Binding; N:PIPD-08:Progressive Disclosure; SUP-W02]

---
# 9｜程式碼落地規格：受限、可重播、預設拒收

所有程式碼是**目標工作樹內可複製的初版 Candidate**，不是對現有私有 Repo 實際路徑的承諾。`<...>` 表示建置期確定性注入參數，不得帶佔位符宣稱 Gate PASS；所列測試要在真 Tool/Host 綁定後重播。[DESIGN; N:SBL-12:C43; SUP-W01/W04]

## 9.1 `references/corpus/SourceManifest.json`（結構樣本，不能當真 Manifest）

```json
{
  "schema": "SBL.CorpusManifest@1",
  "authority_state": "DESIGN_SNAPSHOT_NOT_RATIFIED",
  "required_group_counts": {"pipd": 10, "sbl": 14},
  "files": [
    {
      "path": "references/corpus/raw/pipd-doc00-09/PIPD_DOC-00.md",
      "group": "pipd",
      "sha256": "REPLACE_WITH_ACTUAL_64_HEX_SHA256",
      "source_role": "NORMATIVE_CANDIDATE",
      "required": true
    },
    {
      "path": "references/corpus/raw/sbl-doc00-13/SBL_DOC-00.md",
      "group": "sbl",
      "sha256": "REPLACE_WITH_ACTUAL_64_HEX_SHA256",
      "source_role": "NORMATIVE_CANDIDATE",
      "required": true
    }
  ]
}
```

**本示例必 FAIL**：僅 2 項但 required 24；含非 SHA 佔位符。真建置流程要由本輪 Inputs Manifest 中的 SHA 和實際物理封裝位置自動生成 24+ 筆，不允許手寫 `required=false` 躲 Gate。其餘上位原件若被有效 Owner 宣告為必需，必須也進 required manifest。[N:PIPD-00:Source; H:DIALOGUE:L2272–2301]

## 9.2 `scripts/verify_corpus.py`：可直接複製的 Python 3.11+ 離線驗證器

```python
#!/usr/bin/env python3
"""Offline corpus integrity / count gate. No network, no side effects."""
import hashlib
import json
import re
import sys
from collections import Counter
from pathlib import Path


def verify(root: Path) -> list[str]:
    errors = []
    root = root.resolve(strict=True)
    mf = root / 'references/corpus/SourceManifest.json'
    if not mf.is_file():
        return ['MISSING_MANIFEST']
    obj = json.loads(mf.read_text(encoding='utf-8'))
    if obj.get('schema') != 'SBL.CorpusManifest@1':
        errors.append('SCHEMA_MISMATCH')
    records = obj.get('files')
    if not isinstance(records, list) or not records:
        return errors + ['EMPTY_FILE_DENOMINATOR']
    seen, counts = set(), Counter()
    for i, row in enumerate(records):
        if not isinstance(row, dict):
            errors.append(f'FILE_{i}_INVALID_RECORD')
            continue
        rel, digest, group = row.get('path'), row.get('sha256'), row.get('group')
        if not isinstance(rel, str) or not rel or rel in seen:
            errors.append(f'FILE_{i}_PATH_OR_DUPLICATE')
            continue
        seen.add(rel)
        if not isinstance(digest, str) or not re.fullmatch(r'[0-9a-f]{64}', digest):
            errors.append(f'FILE_{i}_BAD_SHA256')
            continue
        path = root / rel
        try:
            actual = path.resolve(strict=True)
            actual.relative_to(root)  # forbids ../ and symlink escape
            if not actual.is_file():
                raise ValueError('NOT_A_FILE')
            data = actual.read_bytes()
            data.decode('utf-8', 'strict')
        except (OSError, ValueError, UnicodeError):
            errors.append(f'FILE_{i}_UNAVAILABLE_OR_ESCAPED')
            continue
        if hashlib.sha256(data).hexdigest() != digest:
            errors.append(f'FILE_{i}_HASH_MISMATCH')
        if row.get('required') is not True:
            errors.append(f'FILE_{i}_NOT_REQUIRED')
        if group not in ('pipd', 'sbl', 'historical'):
            errors.append(f'FILE_{i}_UNKNOWN_GROUP')
        else:
            counts[group] += 1
    expected = obj.get('required_group_counts', {})
    for group in ('pipd', 'sbl'):
        if counts[group] != expected.get(group) or expected.get(group) != {'pipd': 10, 'sbl': 14}[group]:
            errors.append(f'{group.upper()}_DENOMINATOR_MISMATCH')
    return errors

if __name__ == '__main__':
    target = Path(sys.argv[1] if len(sys.argv) > 1 else '.')
    failures = verify(target)
    print(json.dumps({'verdict': 'FAIL' if failures else 'PASS', 'errors': failures}, ensure_ascii=False))
    raise SystemExit(1 if failures else 0)
```

**局限與必需擴充**：此腳本證明 SHA／路徑／24 份分母與 UTF-8 位元完整，**沒有證明** DOC 的上位 AuthorityBinding、第三方 License、Supersession 或內容語義；另需合法 Source Resolver 和 Ratification。[N:PIPD-01; N:PIPD-04; SUP-W02]

## 9.3 `schemas/sbl-tpm/GitHubDeliveryDecision.schema.json`（嚴格形狀）

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "https://example.invalid/sbl/GitHubDeliveryDecision.schema.json",
  "title": "SBL.GitHubDeliveryDecision@1",
  "type": "object",
  "additionalProperties": false,
  "required": ["schema", "subject_sha256", "question_key", "state", "owner_decision_ref"],
  "properties": {
    "schema": {"const": "SBL.GitHubDeliveryDecision@1"},
    "subject_sha256": {"type": "string", "pattern": "^[a-f0-9]{64}$"},
    "question_key": {"const": "github_publication_for_mission"},
    "state": {"enum": ["UNDECIDED", "ASKED_PENDING", "DEFERRED", "LOCAL_ONLY", "PUBLISH_REQUESTED", "PUBLISH_ADMITTED", "PUBLISHED_VERIFIED", "PUBLISH_BLOCKED"]},
    "owner_decision_ref": {"type": ["string", "null"]},
    "repository_id": {"type": ["string", "null"]},
    "branch": {"type": ["string", "null"]},
    "remote_sha256": {"type": ["string", "null"]}
  }
}
```

`example.invalid` 只代表 **本地 Schema ID 佔位**，不能視為可解析權威 URL。此 JSON Schema **沒有**自行判斷授權，需下列 Semantic Gate 和真 Receiver；建置者應於有權批准後綁定正式 URI。[DESIGN]

## 9.4 `scripts/gate.py`：本地 Decision＋遠端操作拒收（不執行 Push）

```python
#!/usr/bin/env python3
"""Non-mutating planning/publication gate; authorization verified elsewhere."""
import json
import re
import sys
from pathlib import Path

STATES = {
    'UNDECIDED', 'ASKED_PENDING', 'DEFERRED', 'LOCAL_ONLY',
    'PUBLISH_REQUESTED', 'PUBLISH_ADMITTED',
    'PUBLISHED_VERIFIED', 'PUBLISH_BLOCKED',
}


def decision_gate(data, requested_operation='PLAN'):
    if not isinstance(data, dict) or data.get('schema') != 'SBL.GitHubDeliveryDecision@1':
        return ('FAIL', 'SCHEMA')
    if not re.fullmatch(r'[0-9a-f]{64}', str(data.get('subject_sha256', ''))):
        return ('FAIL', 'SUBJECT_SHA')
    if data.get('question_key') != 'github_publication_for_mission':
        return ('FAIL', 'QUESTION_ID')
    state = data.get('state')
    if state not in STATES:
        return ('FAIL', 'STATE')
    if requested_operation == 'PLAN':
        return ('PASS', 'QUESTION_REQUIRED') if state == 'UNDECIDED' else ('PASS', 'RECORDED')
    if requested_operation == 'LOCAL_DELIVERY':
        if state != 'LOCAL_ONLY':
            return ('HOLD', 'DELIVERY_CONTRACT_REVIEW')
        ref = data.get('owner_decision_ref')
        if not isinstance(ref, str) or not ref.strip():
            return ('HOLD', 'OWNER_DECISION_RECORD_MISSING')
        # Candidate only: this string does not prove an authorized OWNER signer.
        return ('PASS_CANDIDATE_ONLY', 'OWNER_RECORD_NEEDS_TRUSTED_READER')
    if requested_operation == 'REMOTE_PUBLICATION':
        if state != 'PUBLISH_ADMITTED':
            return ('HOLD', 'REMOTE_NOT_ADMITTED')
        # One boolean or an AI-written receipt is never sufficient proof of a real permit.
        return ('HOLD', 'EXTERNAL_PUBLISHER_ADMISSION_AND_READBACK_REQUIRED')
    return ('FAIL', 'UNKNOWN_OPERATION')

if __name__ == '__main__':
    if len(sys.argv) not in (2, 3):
        raise SystemExit('usage: gate.py <decision.json> [PLAN|LOCAL_DELIVERY|REMOTE_PUBLICATION]')
    data = json.loads(Path(sys.argv[1]).read_text(encoding='utf-8'))
    result, reason = decision_gate(data, sys.argv[2] if len(sys.argv) == 3 else 'PLAN')
    print(json.dumps({'gate': result, 'reason': reason}, ensure_ascii=False))
    raise SystemExit(0 if result in ('PASS', 'PASS_CANDIDATE_ONLY') else 2)
```

**本 Gate 對遠端一律 HOLD** 是刻意設計：真 Push 的 Permission 和世界效果必交 **Native Publisher Adapter**。若直接把這段 Python 當成遠端 Publisher，就是嚴重責任外溢。它只完成「本地 Planning Decision Gate」及「不存在誤推送」。[N:SBL-12:C43; DESIGN]

## 9.5 `scripts/prepublish_probe.py`：Repository Identity／Dirty Tree 初步拒收

```python
#!/usr/bin/env python3
"""Read-only git preflight. Never calls push/merge or accepts a credential."""
import subprocess
import sys


def git(*args):
    return subprocess.check_output(['git', *args], text=True, stderr=subprocess.STDOUT).strip()


def probe(expected_remote_url, expected_branch):
    try:
        root = git('rev-parse', '--show-toplevel')
        remote = git('remote', 'get-url', 'origin')
        head = git('rev-parse', 'HEAD')
        branch = git('symbolic-ref', '--short', 'HEAD')
        dirty = git('status', '--porcelain', '--untracked-files=all')
    except (subprocess.CalledProcessError, OSError) as exc:
        return ('FAIL', f'GIT_UNAVAILABLE:{str(exc)[:80]}')
    if remote != expected_remote_url or branch != expected_branch:
        return ('FAIL', f'REMOTE_OR_BRANCH_MISMATCH:{remote}:{branch}')
    if dirty:
        return ('HOLD', 'DIRTY_OR_UNTRACKED_WORKTREE')
    if len(head) not in (40, 64):
        return ('FAIL', 'INVALID_HEAD')
    return ('PASS_CANDIDATE_ONLY', f'root={root} head={head}')

if __name__ == '__main__':
    if len(sys.argv) != 3:
        raise SystemExit('usage: prepublish_probe.py <exact-origin-url> <expected-feature-branch>')
    outcome = probe(sys.argv[1], sys.argv[2])
    print(*outcome, sep='	')
    raise SystemExit(0 if outcome[0] == 'PASS_CANDIDATE_ONLY' else 2)
```

此腳本只用 `remote URL` 與 `branch` 作 **初步辨識**；正式 GitHub Reader 還須解析 repo_id、effective API permissions、protected ruleset、visibility、PR head/base、簽名、Credential，不能由此腳本直接升格 `PUBLISH_ADMITTED`。[N:SBL-12:C43; SUP-W06]

## 9.6 `.github/workflows/sbl-candidate.yml`：無 Secret、只讀、PR／Merge Group 候選測試

```yaml
name: sbl-candidate
on:
  pull_request:
  merge_group:
  workflow_dispatch:
permissions:
  contents: read
jobs:
  sbl-candidate:
    name: sbl-candidate
    runs-on: ubuntu-latest
    timeout-minutes: 15
    steps:
      - name: Checkout candidate
        # This full SHA is an illustrative existing checkout v4 baseline,
        # NOT a claim of current 2026 admission. Re-pin from the real upstream.
        uses: actions/checkout@11bd71901bbe5b1630ceea73d27597364c9af683
        with:
          persist-credentials: false
      - name: Confirm Python environment
        run: python3 --version
      - name: Corpus integrity
        run: python3 scripts/verify_corpus.py .
      - name: Python syntax
        run: python3 -m compileall -q scripts
      - name: Repository candidate tests
        run: python3 -m unittest discover -s tests -v
      - name: Candidate only claim
        run: echo 'CANDIDATE_GATES_OBSERVED; NO RELEASE/AO/NATIVE CLAIM'
```

**注意**：`actions/checkout@11bd...` 是已知的歷史完整版 Commit SHA 範例，2026 Release 時**仍必須由 GitHub upstream 核對真正版本／來源／SHA，再由 Source Lock 受權釘選**；`ubuntu-latest` 是漂移環境，正式再現性資格需 pin runner/runtime。Workflow 的 `on` 在某些 YAML 1.1 parser 被視為布林鍵，應以 GitHub 真 Actions Parser 驗收。這個 Candidate Job 只由 PR 原始碼控制，**絕不輸出正式 Independent PASS**；受信 verifier 必須位於非 PR Mutable 的獨立受保護 Environment/Workflow/Repo/App 中。[N:SBL-12:C43,L1228–1241; SUP-W04/W05/W06/W07/W25]

**Trusted Check 契約**：`expected_app_id / ruleset_id / repository_id / exact_head_or_merge_group_sha / protected_workflow_sha / evidence_digest / required_check_context / verifier_principal` 都必須由受保護來源綁定。沒有該 App/RuleSet/Principal 者**不得**將 `sbl-independent` 設成 Required Green；應維持 `CHECKER_UNAVAILABLE` 的 fail-closed 行為；不得令 PR 工作流自己回報 trusted check。[N:SBL-12:C43; SUP-W06]

## 9.7 最小 Python 負例單元測試 `tests/test_delivery_gate.py`

```python
import unittest
from scripts.gate import decision_gate

BASE = {
    'schema': 'SBL.GitHubDeliveryDecision@1',
    'subject_sha256': 'a' * 64,
    'question_key': 'github_publication_for_mission',
    'owner_decision_ref': None,
}

class DeliveryGateTest(unittest.TestCase):
    def test_undecided_asks_and_does_not_publish(self):
        d = dict(BASE, state='UNDECIDED')
        self.assertEqual(decision_gate(d, 'PLAN'), ('PASS', 'QUESTION_REQUIRED'))
        self.assertEqual(decision_gate(d, 'REMOTE_PUBLICATION')[0], 'HOLD')

    def test_local_only_can_complete_locally(self):
        d = dict(BASE, state='LOCAL_ONLY', owner_decision_ref='candidate-owner-record')
        self.assertEqual(decision_gate(d, 'LOCAL_DELIVERY')[0], 'PASS_CANDIDATE_ONLY')
        self.assertEqual(decision_gate(d, 'REMOTE_PUBLICATION')[0], 'HOLD')

    def test_local_only_without_owner_record_is_hold(self):
        d = dict(BASE, state='LOCAL_ONLY')
        self.assertEqual(decision_gate(d, 'LOCAL_DELIVERY')[0], 'HOLD')

    def test_even_admitted_string_is_not_a_true_remote_permit(self):
        d = dict(BASE, state='PUBLISH_ADMITTED', owner_decision_ref='fake')
        self.assertEqual(decision_gate(d, 'REMOTE_PUBLICATION')[0], 'HOLD')

    def test_wrong_subject_never_passes(self):
        d = dict(BASE, state='LOCAL_ONLY', subject_sha256='wrong')
        self.assertEqual(decision_gate(d, 'LOCAL_DELIVERY')[0], 'FAIL')

if __name__ == '__main__':
    unittest.main()
```

`gate.py` 的 `PASS_CANDIDATE_ONLY` 僅表示存在一份 Owner Decision Reference 候選，**不是**真 OWNER 已批准；正式本地交付仍須由受權 QuestionLedger/Decision Reader 校驗；其狀態語義僅為最低本地拒收，不具有 Digital Signature、Currentness、Original Owner Decision Replay Detection；這些需真 Native Adapter 與正式 Signature Policy。測試成功的 Claim Ceiling 為 `LOCAL_STATIC_GATE_PASS`。[DESIGN; N:PIPD-09]

---
# 10｜完整施工 WorkPackages、變更、追溯與 Test Tracking

## 10.1 工作包依賴、責任及 Exit

| WP | 根據 | 實作範圍 | 主要責任 | Exit（缺證據則 HOLD） |
|---|---|---|---|---|
| WP00 | [N:PIPD-00/01; N:SBL-00] | 40 檔 Source/Host/Repo/Plugin Inventory、Full SHA、原上位依賴閉合、授權 | Codex+原 Owner | SourceManifest/RepoHEAD/License/CR 都可定位 |
| WP01 | [H:DIALOGUE:L399–483; N:PIPD-04/07] | P4 8 skills POS Fixture、Semantic Validator、Cross-object Hash Join | PIPD Owner+Codex | 受影原 POS/NEG/SEC 全量綠且錯 ID 實際被拒 |
| WP02 | [N:PIPD-03/05/06/07] | 12↔9 Risk、Oracle Binding、Plan/Live TQAEP、EffectClass、Resolver | PIPD+各 Domain Owner | 無受影未裁決語義假 PASS |
| WP03 | [N:SBL-01/04] | TPM 三角色、T0～T5 18 StageContract、QuestionGate、Quick/Guided/Critical | SBL+Codex | 18/18 合法且 CR StageMap 衝突可重現 |
| WP04 | [H:DIALOGUE:L2116–2350] | Portable Plugin K0–K3、原文 24+、Corpus Index/Version/Integrity、免 DOC 上傳 | Codex | ZD-01～08 clean host PASS；權威缺口不被封裝洗白 |
| WP05 | [N:SBL-06:C32; SUP-W09–21] | 6 Donor/24 Slot 的選用 Adapter、Provider-off、pin | Codex | 真相容表、效果受限、無第二 Scheduler |
| WP06 | [N:SBL-01:C08.2A; N:SBL-12:C43] | GitHub GHP-01/GHP-02、決策持久化、受權 Publisher 介面 | Codex/SBL/Publisher | LOCAL_ONLY 與 PR POS/NEG；拒絕錯 Repo/Secret |
| WP07 | [N:SBL-01:C01.2; N:FHS-R2:§5.4] | Portable/Native Handoff ABI、PIPD Canonical Compiler Bridge | PIPD/SBL/HGK | 真 Compiler Ref、不同 Host 精確版本握手 |
| WP08 | [H:B1-HANDOFF; N:FHS-R2:§7] | Hermes 真 durable executor、Receiver/HGK Admission、Fabric R3、Model R4 | Hermes/HGK/Fabric | Restart/Revocation/Loaded/Served 真收據 |
| WP09 | [N:PIPD-07/09; N:SBL-12:C43] | TQAEP Live／Independent Checker、CI Stage A/B、Attestation capability | Checker/RepoAdmin | Checker Principal+Raw+candidate SHA 狀態一致 |
| WP10 | [N:SBL-04:C13; N:SBL-13] | GJ01 CLI、GJ02 Brownfield、GJ03 Skill＋Agent、B1 three GWO | SBL/Hermes/Checker | 每種 FUO 真 Host Positive/Negative |
| WP11 | [N:SBL-12; SUP-W01] | Release Candidate／Portal/Host UAT、SBOM、License、Rollback | authorized Publisher | 受影 Host 正式 PASS 且 CR Gate 全部閉合 |

**關鍵路徑**：`WP00 → WP01/02 → WP03/04/05/06 → WP07 → WP08/09 → WP10 → WP11`；不受影工作可並行。`WP08` 的 Native Discovery 可在 WP00 後以 READ_ONLY Probe 並行，避免末端才發現 ABI NO_FIT；`WP08` 未 Pass 不阻擋宣稱為「僅 Planning Qualified」的受限版本，但阻擋 `E2E_Native_Qualified`。[N:FHS-R2:§7.1; H:B1-RCA]

## 10.2 P4 十八類缺陷修復清單（承接前輪 ID，不等於原生 Repo 已修）

| ID | 需變更的 Adapter / Fixture | Gate |
|---|---|---|
| P4-01 | PI Atom/Trace hash equal | P4-SEM-01 |
| P4-02 | ECP ConstructionContract PD Subject equal | P4-SEM-02 |
| P4-03 | TQAEP Checker Receipt exact same operation | P4-SEM-03 |
| P4-04 | Package true TraceGraph closure, 0 edge no unproved 2 | P4-SEM-04 |
| P4-05 | PI/PD/ECP typed Full Artifact Resolver | P4-SEM-05 |
| P4-06 | DOC-06 12-axis + P4 9-axis risk, veto non-lowering | P4-SEM-06 |
| P4-07 | DOC-03 legacy oracle locator vs DOC-07 Writer | P4-SEM-07 |
| P4-08 | Planned TQAEP no Checker Receipt; Live only after proof | P4-SEM-08 |
| P4-09 | Repo ECP vs Host/User/Remote Effect-specific classes | P4-SEM-09 |
| P4-10 | Maker/Signer/Checker Principal isolation, not names | P4-SEC-10 |
| P4-11 | Family Authority lookup not arbitrary name | P4-SEM-11 |
| P4-12 | Provider-off required from risk/policy not optional omission | P4-SEM-12 |
| P4-13 | FirstFail/AffectedWork/Resume typed error | P4-SEM-13 |
| P4-14 | Schema-valid but semantic-invalid fail | P4-SEM-14 |
| P4-15 | Claim/Lifecycle/Mission status noninterchangeable | P4-SEM-15 |
| P4-16 | Skill installed vs Compiler loaded/invoked truth | P4-HOST-16 |
| P4-17 | Source Snapshot vs valid SourceFreeze Currentness | P4-SEM-17 |
| P4-18 | Local Packager PASS vs Host Portal/Release | P4-HOST-18 |

[H:DIALOGUE:L2354–2381; N:PIPD-00..09]。不能只修 Positive Fixture 字段而跳過 Semantic Negative Validator；正式離線 ZIP 通過不等於 PIPD 原生 Compiler Pass。

## 10.3 Gate 定義、每項 PASS／FAIL 機制

| Gate ID | 所需原始證據 | PASS 條件 | 典型 FAIL/HOLD |
|---|---|---|---|
| G0-SOURCE | SHA Manifest＋Owner authority refs | required 24+ full raw、exact digest、transitive authority closure | SHA mismatch／缺上位來源、缺 Ratification |
| G1-P4-SEM | 8 Skills fixtures、真 Resolver、POS/NEG/EDGE/SEC | 原 POS 正確、wrong hash/subject/receipt 皆拒 | Semantic mismatch |
| G2-SBL-STAGE | DOC-04 3 Role×6 Stage、Owner StageMap | 18 typed IO 與當前合法語義；衝突未混用 | CR-DOC04-STATE-MAP unresolved for affected |
| G3-PLUGIN-HOST | Host install/load/invoke/deny/uninstall receipts | 單 Plugin、零 base DOC 上傳、同版、無重裝 P4 | Host unsupported/missing corpus |
| G4-PIPD-COMPILER | 真 Compiler/RepoContext/SourceSHA | 同 subject same digest Canonical artifact | Candidate-only/Schema-only |
| G5-GITHUB-DECISION | QuestionLedger＋DeliveryDecision | decision checked；Pending 不 Push；LOCAL_ONLY 可本地完成 | 未問、重問、User no→Push |
| G6-REMOTE | Repo ID、Publisher Permit、Push/PR/CI readback | 精確 SHA/Branch/PR＋授權和 SecretScan | credential/scope/visibility mismatch |
| G7-NATIVE | HGK Issuer/Receiver、Fabric Loaded、Model Served、Hermes Resume | POS/NEG/Revocation／三 WO／G-B 真 Raw | R3/R4/T2 NOT_RUN |
| G8-ASSURANCE | Maker Raw＋Frozen Subject＋獨立 Checker Receipt | 真隔離、同 Operation/Hash/epoch 且驗證器有權 | maker self-attest／different source |
| G9-RELEASE | Relevant checks from trusted App/ruleset、Host qualification、Owner release approval | 所有受影 G0–G8 required 合取，signed release | CR_OPEN、candidate CI alone |

**非全域阻斷但不假 PASS**：`G5-UNDECIDED` 只保留 Remote Pending；`G7-NOT_RUN` 阻 Native Qualification，不阻 L0 適用設計輸出；`G0-MISSING` 阻正式來源編譯及發布但容許非受影唯讀盤點。必須在 Gate 之間實作 `dependency_scope` 和 `resume_predicate`。[N:PIPD-05; N:SBL-01:C08.2; H:B1-RCA]

## 10.4 Test Tracking List（初始全部 NOT_RUN，不能預填 PASS）

| 測試組 | 需跑的 POS/NEG | 必須留存 | 本次狀態 |
|---|---|---|---|
| CORPUS ZD-01..08 | 新 Host 無 DOC／舊 P4 缺席／壞 SHA／version drift | host_install, exact file list, SHA readback | NOT_RUN |
| P4-SEM-01..18 | 18 缺陷逐條 POS/NEG，安全隔離 | exact fixture commit, diff, runner logs | NOT_RUN |
| TPM-ROLE-01..18 | 三角色×六階段、T4/T5 CR 衝突 | StageContract raw and negative rejection | NOT_RUN |
| GH-TQ-01..12 | LOCAL_ONLY／DEFER／PERMIT／Wrong Repo／PR÷Merge | QuestionGate ledger、Remote ID、SecretScan | NOT_RUN |
| DONOR-01..24 | 每 Slot selected/off/nontrigger/rollback | donor SHA/license/host capability | NOT_RUN |
| B1-REC-01..25 | 前輪 25 RC 逐條故障注入 | current Native or static raw per scope | NOT_RUN |
| B1-T1/T2/R1..R4/G-A/G-B | 真 native, reboot, revoke, 3 Golden WO | HGK raw, Fabric Loaded, Model Served, checker | NOT_RUN_THIS_TURN |
| GJ01 | Greenfield CLI installed/usage/negative | CLI binary, POS/NEG, receipt | NOT_RUN |
| GJ02 | Brownfield Red→Patch→Green + rollback | repo preimage/diff/checks | NOT_RUN |
| GJ03-SKILL | Host install/trigger/nontrigger/uninstall | loader raw and uninstall residue | NOT_RUN |
| GJ03-AGENT | Simple Agent distinct principal/permission | runner/denied effects/negative | NOT_RUN |
| RELEASE-01..08 | Secret/License/SBOM/Provenance/Updater/Rollback | protected verifier, artifact sha, rollback | NOT_RUN |

### 10.5 可重播本地命令（在已克隆、已備份且合法的隔離工作樹）

```bash
# IMPORTANT: <WORKTREE> needs an actual authorized clone; no global privileged flag.
cd '<WORKTREE>'
python3 --version
python3 scripts/verify_corpus.py .
python3 -m compileall -q scripts
python3 -m unittest discover -s tests -v
# No git push/merge in this smoke test.
git status --short
git rev-parse HEAD
```

`<WORKTREE>` 必須在施工前由工具證明存在；此處沒有試圖執行這些命令，也不把語法可讀視為 Linux/Windows/Actions UAT。由 Codex 執行時，在 Project Root 使用最小可寫 Sandbox 和有界 Worktree，不允許在本輪聊天的 /mnt/data 上無意修改使用者真 Repo。[DESIGN; SUP-W01; N:FHS-R2:§7]

## 10.6 成本與高自動化量測 KPI（需 A/B 實測，不捏造）

`GovernanceOverheadRatio = applicable governance time / applicable total work time`；`FalseHoldRate = wrongly blocked independent READY work / otherwise admitted READY work`；`RecompilationAmplification = nonaffected rebuilds / source change`；`AutonomousRecoveryRate = qualified recovered work / applicable interrupted work`；`UserRepeatQuestionRate`、`CorpusReuploadRate`（目標 0）、`WorldEffectFalsePositiveRate`（目標 0）、`NoValidCheckerPassCount`（目標 0）。量測須在同工作集/同 Host/同授權、Codex-only vs hybrid vs Hermes-first 建立可重播報告，**本輪不宣稱任何百分比改善**。[H:DIALOGUE:L997–1010; N:PIPD-08:A/B]

---
# 11｜Risk Register／CR_OPEN：Fail-Closed 與降級矩陣

## 11.1 CR_OPEN（沒有實際裁決就不升格）

| CR | 缺失證據 / 分歧 | 受影範圍 | FirstFail/降級 | Closure owner／必須有的證據 |
|---|---|---|---|---|
| CR-01 | 部分上位 PIPD Blueprint/Canonical Standard/Portable Mount/GRP 全原件未獨立取回 | Normative SourceFreeze | `MISSING_UPSTREAM_NORM`; Design Snapshot only | PIPD Source Owner 提供完整原件/版本/SHA/批准 |
| CR-02 | SBL Master/原始設計卷/N14 等來源批准狀態不完整 | TPM Canonical product release | `SBL_SOURCE_RATIFICATION_HOLD` | SBL Owner 的明確 scope/supersession/ref |
| CR-03 | `CR-ORACLE-001` DOC-03 Domain Locator vs DOC-07 Writer | PIPD PI/TQAEP 正式 Oracle | `ORACLE_AUTHORITY_CONFLICT`；受影 HOLD | PIPD Oracle Writer／Reader 對照與 Ratification |
| CR-04 | P4 原始 full `cases.yaml`／Compiler 本輪未完整重跑 | P4 受影 Typed IO 正式編譯 | `P4_SEMANTIC_TEST_NOT_RUN` | 當前 Repo+完整 Fixture/POS/NEG/Runner raw |
| CR-05 | `CR-DOC04-STATE-MAP` T0–T5 T4/T5 來源衝突 | TPM 18 Contract 受影 stage | `STAGE_MAP_CONFLICT`；可繼續無關 T0–T3 | SBL Doc04 原 Owner+source SHA+批准映射 |
| CR-06 | 本輪現役私人 `sbl-tpm-sp` 及 P4 Plugin Release 全量檔案未重新物理封存 | 升級分支 Patch target | `LIVE_PLUGIN_BASELINE_MISSING` | Plugin Owner Export tree + manifest + version + rollback |
| CR-07 | 將 24 DOC+上位原件隨 Plugin 再分發授權未逐一確定 | Unified Plugin License/Release | `LICENSE_REVIEW_HOLD` | 每份來源 License / redistribution and privacy approval |
| CR-08 | 真 PIPD Canonical Compiler CLI/API/ABI/權限未現役證明 | Native Compile qualification | `COMPILER_CAPABILITY_UNBOUND` | PIPD Owner 可執行工具與 typed raw roundtrip |
| CR-09 | Windows HGK User Trust 的 Signer/Receiver/REGISTRY 與權限獨立未真 Readback | L2 admission | `ISSUER_OR_RECEIVER_UNBOUND` | HGK Native POS/SEC NEG、epoch/nonce/revoke |
| CR-10 | Hermes OS process Executor/SharedSpine Durable Replay 未真通過 | Native long-horizon E2E | `EXECUTOR_NOT_RUN` | 真 restart/CAS/lease/Ready>0 NoStop/G-B |
| CR-11 | Fabric Stage/Active/Loaded/Consumer 與 Served Model 未驗 | Fabric R3/Model R4 | `HOST_OR_MODEL_NOT_RUN` | 對 exact candidate 的四層/三模型 Live readback |
| CR-12 | 真 Checker 的獨立 OS Principal、Credential/Policy immutable 未驗 | Formal TQAEP Acceptance | `CHECKER_SOD_UNVERIFIED` | 正反權限測試與真 receipt |
| CR-13 | 當前 Repo Ruleset/App ID/Trusted Workflow SHA、Publish 權限未讀回 | GitHub PR/Release | `PUBLISHER_RULESET_UNBOUND` | RepoAdmin+App+remote ref/Protected Verifier |
| CR-14 | 本地新數據庫/Repo 是否允許 GitHub Public Visibility 未定 | Remote publication | `VISIBILITY_UNDECIDED` | GHP-01 Owner decision；本地不中斷 |
| CR-15 | PIPD Stage-C 實際 WriteSet CI 修補尚無新版 Green | Stage-C/affected PIPD | `WRITESET_TEST_FAIL_OR_STALE` | 最小合法差異與不可削弱 allowlist 的新 CI |
| CR-16 | OpenSpec/Matt/gstack/GSD 特定 Windows+Codex+Hermes Host UAT 未執行 | optional Donor Adapter | `DONOR_HOST_EVAL_ONLY` | pin/installation/negative/provider-off/uninstall |
| CR-17 | GitHub private Repo Artifact Attestation 可用性視方案限制 | supply chain qualified | `ATTESTATION_PROVIDER_UNAVAILABLE` | per-plan capability；Sigstore/受權替代憑證 |
| CR-18 | SBL-TPM Native 新 Factory API 尚未由 Host 批准 | native orchestration | `NATIVE_TPM_ABI_UNRATIFIED` | SBL/HGK/Hermes Owner 批准 Versioned ABI |
| CR-19 | B1 r10 Required 625/Conditional 285 ledger 及三 GWO 尚未新驗收 | B1 Native Acceptance | `B1_NATIVE_HOLD` | per-ID new receipts，0/3→3/3 真 GWO |
| CR-20 | Plugin Portal/Host 2026 產品資格、Version Compat 未實測 | Public Release | `HOST_QUALIFICATION_MISSING` | 真 Install/Mount/Invoke/Deny/Uninstall＋Validator |
| CR-21 | 真環境模型路由 Required/Served Policy/Transport/Principal | L2 Model R4 | `MODEL_SERVE_IDENTITY_UNVERIFIED` | live probe, per-lane negative |
| CR-22 | 目前 Shell/Windows/git credential 的最小權限/主分支實際權利 | bounded builder and publisher | `PRINCIPAL_SCOPE_UNVERIFIED` | protected ACL/Repo Permission/deny tests |

**CR 狀態不等於所有工作停下**：對真 Native/正式 Release，任一 **受影 P0 CR_OPEN** 都 `FAIL-CLOSED`；對 L0 Read-only 規劃可有 `CANDIDATE_WITH_EXPLICIT_HOLD`；對已經合法完成的本地交付不得因未選 GitHub 而任意降級。[N:PIPD-05:Permission; N:SBL-01:C08.2A; H:B1-RCA]

## 11.2 Degrade Matrix

| 錯誤事件 | 不阻斷哪些動作 | 必須阻斷哪些效果 | 恢復條件 |
|---|---|---|---|
| `SOURCE_UNRATIFIED` | 歷史盤點、規格候選 | 真受影 SourceFreeze/PI Promotion | 經 Owner 批准的 Source/Hash |
| `CORPUS_HASH_FAIL` | 非受影 source 的合法查閱 | 受損 DOC 的正式工件與 Release | 重建位元+hash/版本 |
| `P4_COMPILER_UNAVAILABLE` | Goal/SPEC/QuestionLedger | 宣稱 Native PI/PD/ECP 真編譯 | Compiler version/IO/readback |
| `ORACLE_CONFLICT` | 來源雙方對照和無關工件 | 受影 TQAEP Live/Claim | Oracle Owner Ratified |
| `REPO_CONTEXT_STALE` | Read-only/Proposal | 該 Repo 寫入 | fresh root/HEAD/currentness |
| `PUBLISH_DECISION_PENDING` | 本地開發、測試、合法本地交付 | Push/PR/Merge | 有效 OWNER 決策＋有權 Publisher |
| `PUBLISHER_CREDENTIAL_MISSING` | Local build/docs/evidence | GitHub Remote Mutation | Scope-bound publisher credential |
| `GITHUB_PRIVATE_ATTEST_UNAVAILABLE` | Candidate CI/Local Evidence | 必須該 Attestation 的受影 Release | 實際企業權利或合規替代政策 |
| `CHECKER_UNAVAILABLE` | Design/Test Raw/Recovery | Independent Accepted／Release | 真 Checker Readback |
| `HERMES_EXECUTOR_DOWN` | 靜態修補與授權外觀測 | 宣稱無人值守真 E2E | OS process restart pass |
| `FABRIC_LOADED_MISSING` | 非 Fabric work | Fabric Native Acceptance | Active/Loaded/Consumer readback |
| `MODEL_REQUIRED_NOT_SERVED` | 不受影工作和合法診斷 | 該 Lane 正式 PASS | exact served policy+principal+transport |
| `UNAUTHORIZED_EFFECT` | Read-only 的不受影任務 | 全部受影 Mutation | 真 ECP/Permit, not free-text |
| `STAGE_MAP_CONFLICT` | 已清楚合法 T0–T3 受限設計 | 含衝突 T4/T5 的正式 Stage Promotion | SBL Owner ratification |
| `GSD_OLD_REPO_ARCHIVED` | SBL 自有合法 Task DAG | 用歷史 GSD 版本宣稱活躍兼容 | 新 Repo source pin+independent host qualification |

## 11.3 Release 關卡分層（禁止全域假完成）

| Claim 等級 | 必要 Gate | 不可宣稱 |
|---|---|---|
| `DESIGN_BLUEPRINT_READY` | 40 檔 Inventory／RCA／CR 定位（本輪） | 正式來源批准 |
| `LOCAL_CANDIDATE_CODE_READY` | Candidate scripts local POS/NEG | Host plugin installed |
| `CORPUS_SNAPSHOT_VERIFIED` | 24+ 文件 hash/count pass | Transitive normative ratified |
| `PORTABLE_PLUGIN_HOST_QUALIFIED(host/version)` | ZD＋TPM 18＋trigger/nontrigger/uninstall | 另一 Host 同等有效 |
| `PIPD_COMPILER_QUALIFIED(subject/version)` | 真 source/RepoContext/compiler/semantic readback | HGK Native Accepted |
| `NATIVE_FACTORY_QUALIFIED(scope)` | Hermes resume/HGK/Fabric/Model live and Checker | 未受影其它 Domain PASS |
| `GITHUB_CANDIDATE_PUBLISHED(repo,sha)` | authorized remote readback | Merged/Release/Deployment |
| `RELEASED(exact_product_version)` | trusted verifier+Owner release+app/host proof | 全域 Production 無條件保證 |

**本輪可宣稱最高等級**：`DESIGN_BLUEPRINT_READY / SOURCE_MANIFEST_40_LOCAL / WEB_SUPPORT_REVIEWED`。對 `RELEASED` 的裁決 **FAIL-CLOSED**；所有 `NOT_RUN` 必須有具體 Resume Gate。[N:PIPD-09:L50–71; H:B1-HANDOFF]

---
# 12｜Release Handoff、操作指南與不可違反的設計預算

## 12.1 預設最小施工順序

**步驟 1**：在 4 個 Repo 與當前私有 Plugin 的已授權工作區建立只讀 Baseline，存檔案/commit/runner/OS identity；`CR-01/02/06/13` 對現役權威做明確鑑定。[N:FHS-R2:§7.1; N:SBL-12:C43]

**步驟 2**：在本地 Codex 的隔離 Worktree 修 P4 細節（Wrong Hash、Subject、Checker Receipt、Graph Edge、Profile、Oracle、TQAEP、Full Resolver），先紅後綠、每次限修一個受影錯誤，不動未被授權的路徑。[H:DIALOGUE:L399–483; N:PIPD-07]

**步驟 3**：同步建構 K0 24 DOC 全原文、非 DOC 歷史資料、SourceManifest+ClauseIndex；**僅使用一套 TPM-SP 即達成零再上傳**；但在 CR-01/02 未閉合前僅宣稱 Snapshot，正式來源不冒認。[H:DIALOGUE:L2164–2350]

**步驟 4**：完成 SBL TPM 三角色×18 StageContract，從已核對的 SourceKnown Answer 產 QuestionLedger；StageMap CR 明列但不阻 T0–T3 受限設計。加入 GHP-01 decision/GHP-02 remote adapter。[N:SBL-01:C08.2A; N:SBL-04:C13]

**步驟 5**：基於 `KEEP_NATIVE` 融入 OpenSpec 等 Donor，逐個執行可移除/Provider-off/拒收，絕不將 gstack instruction-only 假冒 Native Checker。[N:SBL-06:C32; SUP-W09/W14/W18]

**步驟 6**：建立真正的 Native TPM thin orchestrator，只調用真 PIPD Writer、HGK Issuer、Hermes SharedSpine、Domain readback、Checker；把 Step/State 持久化至**現有** Queue/ledger。[N:FHS-R2:§5.4,§7; N:SBL-01:C01.2]

**步驟 7**：執行 L0/L1/Native 垂直切片、整體對照工作量和失效注入；每次只修最小受影 Patch；Mission 尚有 READY 工作時禁止 Terminal。[H:B1-RCA:early-stop]

**步驟 8**：產出 Release Candidate、受信 CI/Checker 的分離證據、權限與 License 清冊。對 GitHub `LOCAL_ONLY` 產 Local Package，對 `PUBLISH_REQUESTED` 等 Remote 取得真 Publisher Authorization 後才發布候選 PR。沒有真 Checker/Host/Portal receipt 不升格。[N:SBL-12:C43; SUP-W04/W06]

## 12.2 技術債及過度工程警報（決策預算）

如任一新設計增加**第二 Canonical Writer、第二 Native Issuer、第二 Durable Queue、無精確成本與 Consumer 的常駐 Agent、每次全量重編、每張 ECP 都重問 GitHub、一個 Local Hold 阻斷全部工程、永久 Admin 萬能授權、Schema-valid 代替 Semantic**，需先提交 `ARCHITECTURE_NOFIT_AND_COST`，經有權 Owner 批准才可繼續。能保留原 Native/Thin Adapter 的情況，禁止升格為全新控制平面。[N:SBL-01:C01.2; N:SBL-06:C32; N:FHS-R2:§6/§7]

## 12.3 來源存證與交付日的確信界線

- **真的做了**：本輪 40 份本地 Markdown 的 UTF-8/bytes/SHA 盤點、8 項 P4 Skill 首頁直接讀取、2026 Web 官方/第三方來源查核、4 個私有 Repo 在 GitHub Connector 可讀到基本身份/main branch、產生本藍圖與機器化資料。
- **未做**：未獲任一 Windows HGK/Hermes OS Process 的真權限；未重放 P4 所有 `cases.yaml`；未修改/重建任何私有 Plugin；未在四 Repo Push/PR/Merge；未執行真 SBL-TPM E2E；未取得獨立 Checker 與正式 Release Receipt。
- **不可推論**：「GitHub Repo 存在」≠可 Publish；「Skills 已安裝」≠正式 Compiler 生效；「本文流程與程式碼可讀」≠安全授權；「40 DOC 找到」≠正式 SourceFreeze；「本輪取得外部文章」≠開源 Donor 已被本案 Host 驗證。

**最終 Release Gate**：`RELEASE = SOURCE_RATIFIED && CORPUS_VERIFIED && SEMANTIC_VERIFIED && HOST_QUALIFIED && (NATIVE_REQUIRED ? NATIVE_ACCEPTED : PLANNING_ONLY_CLAIM) && CHECKER_AS_APPLICABLE && AUTHORIZED_PUBLISHER && NO_APPLICABLE_CR_OPEN`。任何缺失保持 `FAIL-CLOSED`，只依合法最小 Claim 交付。[N:PIPD-09; N:SBL-12; DESIGN]

## 12.4 全冊受影覆蓋矩陣（每冊 → Reader／WorkPackage／拒收）

| 文件 ID | 主要契約／用途 | 工程落點 | 必須防止的越權與回歸 |
|---|---|---|---|
| PIPD-00 | Router／入口及 Source Family | WP00/WP07 | 不因 Skill 存在冒稱 Native Compilation |
| PIPD-01 | Constitution／Lifecycle／Canonical Owner | WP00/WP02 | Claim/WorkState 狀態不混用 |
| PIPD-02 | PI/Atom/TechnologyAdmission | WP01/WP05 | Requirement Sidecar 不壓縮原子 |
| PIPD-03 | PD／Repo Currentness/PreDev | WP02/WP07 | 不套用到 Host/OBS、Stale 不當 Fresh |
| PIPD-04 | Trace/Evidence/Identity | WP01/WP09 | Wrong Subject/Hash 禁假綠 |
| PIPD-05 | Permission/ECP/Native Receiver | WP02/WP08 | 不取代真 HGK Issuer；EffectClass 分型 |
| PIPD-06 | 十二軸風險/Profile/Veto | WP02 | 九軸映射不能降低風險 |
| PIPD-07 | Oracle/Fixture/Checker/Conformance | WP01/WP09 | Planned 不等於 Live PASS |
| PIPD-08 | Progressive Disclosure/Adapter Admission | WP04/WP05 | 不灌滿 Context、不用浮動 Provider |
| PIPD-09 | CI/Release/Provenance/Claim | WP09/WP11 | CI ≠ Production/Release |
| SBL-00 | Source Router/Authority/Claim | WP00 | Source 投影不升格 Writer |
| SBL-01 | One Core/3 SP/QuestionGate/U21–U27 | WP03/WP06 | 不擅改 Commander/Challenge 權限 |
| SBL-02 | Requirement/Source Ledger | WP00/WP03 | 不縮小義務分母 |
| SBL-03 | SPEC/Planning/PIPD Projection | WP03/WP07 | 只投影不寫第二 Compiler |
| SBL-04 | C12/C13 三角色×T0–T5 | WP03/WP10 | StageMap 衝突保留 HOLD |
| SBL-05 | Governed ECP/Handoff | WP02/WP08 | Bootstrap 範圍適用性 |
| SBL-06 | C32 6 Donor/24 Slot／TechnologyAdmission | WP05 | Provider-off、KeepNative、No Second Scheduler |
| SBL-07 | Security/Risk/Human Approval | WP06/WP08 | One OWNER ≠ 一個 Principal 擁所有權限 |
| SBL-08 | Acceptance/Oracles/Challenge | WP09/WP10 | Maker 不能自簽 Checker |
| SBL-09 | Evidence/Trace/Delivery | WP09/WP11 | GitHub PR ≠ Host World Effect |
| SBL-10 | Host/Skill/AI Consumer | WP04/WP11 | Install ≠ Loaded ≠ Invoke |
| SBL-11 | HGK/Fabric Native Interface | WP07/WP08 | 真 Receiver/admission/readback |
| SBL-12 | C43 GitHub/CI/Release | WP06/WP09/WP11 | Check App/SHA/Ruleset、untrusted PR |
| SBL-13 | Dogfood/Feedback/Evolution | WP10/WP11 | GJ01/02/03、受影 Requalification |
| B1-00 | r3 authority/claim | WP08/WP10 | DESIGN/Native 分離 |
| B1-01 | 27 Atomic requirements/PI | WP01/WP10 | 5 Native REQ class 不遺失 27 original |
| B1-02 | PD/RepoSource binding | WP07/WP10 | Repo/Host Currentness |
| B1-03 | Host OPS ECP | WP08 | Fabric/HGK world readback 不通用 residue |
| B1-04 | DEV ECP | WP01/WP08 | Bootstrap Repo WriteSet/Admission |
| B1-05 | TQAEP 120+124 | WP09/WP10 | Planned vs Independent Executor |
| B1-06 | 949/192/81 coverage | WP10 | 全量義務 ≠ 當輪 WorkDAG |
| B1-07 | Native toolchain exact usage | WP07/WP08 | 無二進位不可冒稱 run |
| B1-08 | Three Golden E2E WO | WP10 | Fabric/HGK/SBL per-operation receipt |

定位：依 1.1 的完整檔名和物理 SHA；主要依 `PIPD DOC-00..09` 相應正式章節、`SBL DOC-01:C01.2,C08.2A`、`DOC-04:C13`、`DOC-06:C32`、`DOC-12:C43`，以及 B1 r3 `DOC-00..08` 各檔原文。此矩陣是施工消費視圖，**不是**逐段合法 Authority Ratification 的替代證據。[N:PIPD-00..09; N:SBL-00..13; H:B1-00..08]

---
# 13｜自動化機器讀取區塊（直接自本單一 MD 擷取）

**規格**：下列為範例內容（`DESIGN_PROPOSED`），欄位足以驅動建置任務/驗收工作卡，但**不是**原 HGK/PIPD Native Schema。機器只可當作輸入候選；需先校驗由本文前面章節指定的正式 Native Versioned Adapter 和 Owner。[N:SBL-01:C01.2; N:PIPD-05]

## 13.1 `machine_summary.json`（有效 JSON；Release 一律 FAIL-CLOSED）

```json
{
  "schema": "SBL.TPM.UpgradeBlueprintSummary@1",
  "blueprint_id": "SBL-TPM-DUAL-20261027-R1",
  "date": "2026-10-27",
  "timezone": "Asia/Taipei",
  "status": {
    "design": "DESIGN_BLUEPRINT_READY",
    "production_release": "FAIL_CLOSED",
    "native_execution": "NOT_RUN_THIS_TURN",
    "independent_acceptance": "NOT_RUN_THIS_TURN"
  },
  "claims": {
    "portable_plugin_installed": false,
    "native_factory_deployed": false,
    "p4_fixtures_repaired": false,
    "github_published": false,
    "world_effect_verified": false
  },
  "architecture": {
    "portable": "SBL-TPM-SP: one install, embedded full docs, candidate planning, typed handoff",
    "native": "SBL-TPM: orchestrator consuming canonical PIPD/HGK/Hermes/Checker/Publisher",
    "canonical_truth": "PIPD, SBL, HGK, Hermes, Fabric original domain owners; no new duplicate writer/issuer/queue"
  },
  "build_lead": "Codex isolated authorized worktree",
  "integration_lead": "Hermes/HGK real native host",
  "release_authority": "Original legitimate release owner + qualified independent checker",
  "corpus": {
    "files_read_local": 40,
    "pipd_doc_count": 10,
    "sbl_doc_count": 14,
    "full_text_packaging_required": true,
    "zero_repeat_upload": true,
    "transitive_authority_closed": false
  },
  "github": {
    "planning_gate": "MANDATORY_ASK_ONCE_IF_UNDECIDED",
    "remote_push_default": "DENY",
    "local_only_allowed": true,
    "remote_publication_gate": "AUTHORIZED_PUBLISHER_AND_TRUE_READBACK",
    "unknown_decision": "CONTINUE_LOCAL_PARK_REMOTE"
  },
  "p4": {
    "skill_count": 8,
    "known_defect_count": 18,
    "semantic_negative_regression_required": true,
    "tooltext_is_not_compiler": true
  },
  "b1": {
    "root_cause_count": 25,
    "last_confirmed_native_pass_count": 0,
    "golden_workorders_passed": "0/3 at last r10 handoff",
    "new_native_acceptance_this_turn": false
  },
  "donors": [
    {
      "id": "OpenSpec",
      "mode": "SELECTIVE_NATIVE_REUSE"
    },
    {
      "id": "Spec Kit",
      "mode": "OPTIONAL"
    },
    {
      "id": "Matt Skills",
      "mode": "METHOD_REUSE"
    },
    {
      "id": "gstack",
      "mode": "EVAL_ONLY"
    },
    {
      "id": "Superpowers",
      "mode": "METHOD_REUSE"
    },
    {
      "id": "GSD",
      "mode": "REFERENCE_ONLY_NEW_OPEN_GSD_CANDIDATE"
    }
  ],
  "must_run_gates": [
    "G0-SOURCE",
    "G1-P4-SEM",
    "G2-SBL-STAGE",
    "G3-PLUGIN-HOST",
    "G4-PIPD-COMPILER",
    "G5-GITHUB-DECISION",
    "G6-REMOTE_IF_APPLICABLE",
    "G7-NATIVE_IF_CLAIMED",
    "G8-ASSURANCE_IF_APPLICABLE",
    "G9-RELEASE"
  ],
  "workpackages": [
    "WP00",
    "WP01",
    "WP02",
    "WP03",
    "WP04",
    "WP05",
    "WP06",
    "WP07",
    "WP08",
    "WP09",
    "WP10",
    "WP11"
  ],
  "open_cr": [
    "CR-01",
    "CR-02",
    "CR-03",
    "CR-04",
    "CR-05",
    "CR-06",
    "CR-07",
    "CR-08",
    "CR-09",
    "CR-10",
    "CR-11",
    "CR-12",
    "CR-13",
    "CR-14",
    "CR-15",
    "CR-16",
    "CR-17",
    "CR-18",
    "CR-19",
    "CR-20",
    "CR-21",
    "CR-22"
  ],
  "evidence_boundary": "Local 40 markdown physical SHA, 8 P4 skill.md, 2026 Web SUPPORT, GitHub repo metadata only; no Native test or release",
  "paths": {
    "portable_plugin": "sbl-tpm-sp/",
    "native_factory": "native-sbl-tpm/"
  },
  "security": {
    "default_effect_permission": "DENY",
    "false_pass_policy": "FAIL_CLOSED",
    "retry_unknown_world_effect": "RECONCILE_FIRST",
    "single_human_owner": true,
    "machine_principal_separation": true
  }
}
```

## 13.2 `change_plan.tsv`（精確 TSV，路徑需先 Repository Tree Discovery）

```tsv
path	change_type	reason	workpackage	gate
sbl-tpm-sp/plugin.json	PATCH_AFTER_DISCOVERY	Portable manifest／version consistent with host	WP11	G3-PLUGIN-HOST
sbl-tpm-sp/.codex-plugin/plugin.json	PATCH_AFTER_DISCOVERY	Codex fallback version aligned	WP11	G3-PLUGIN-HOST
sbl-tpm-sp/skills/tpm-sp/SKILL.md	PATCH	Single entrypoint, not native execution	WP03	G2-SBL-STAGE
sbl-tpm-sp/skills/tpm-product-plan/SKILL.md	NEW_PROPOSED	Product JTBD/FUO/spec, T0-T5	WP03	G2-SBL-STAGE
sbl-tpm-sp/skills/tpm-system-plan/SKILL.md	NEW_PROPOSED	Architecture/ABI/ADR, T0-T5	WP03	G2-SBL-STAGE
sbl-tpm-sp/skills/tpm-program-plan/SKILL.md	NEW_PROPOSED	Program DAG/Stop/Resume, T0-T5	WP03	G2-SBL-STAGE
sbl-tpm-sp/skills/tpm-handoff/SKILL.md	NEW_PROPOSED	Versioned handoff, no new issuer	WP07	G4-PIPD-COMPILER
sbl-tpm-sp/skills/tpm-setup/SKILL.md	NEW_PROPOSED	Host capability probe and denial	WP07	G3-PLUGIN-HOST
sbl-tpm-sp/skills/pipd-*/SKILL.md	COPY_AND_PATCH_VERSIONED	Eight repaired skills, no old plugin install dep	WP01	G1-P4-SEM
sbl-tpm-sp/references/corpus/raw/pipd-doc00-09/	NEW_PROPOSED	All 10 full raw, digest retained	WP04	G0-SOURCE
sbl-tpm-sp/references/corpus/raw/sbl-doc00-13/	NEW_PROPOSED	All 14 full raw, digest retained	WP04	G0-SOURCE
sbl-tpm-sp/references/corpus/raw/fhs-and-b1/	NEW_PROPOSED	History/reference only, separate authority	WP04	G0-SOURCE
sbl-tpm-sp/references/corpus/SourceManifest.json	NEW_PROPOSED	Hashes/source/authority/required counts	WP00	G0-SOURCE
sbl-tpm-sp/references/corpus/ClauseIndex.json	NEW_PROPOSED	JIT exact clause source lookup	WP04	G0-SOURCE
sbl-tpm-sp/references/corpus/ConflictRegistry.json	NEW_PROPOSED	Keep Oracle/StageMap CR unratified	WP02	G1-P4-SEM
sbl-tpm-sp/references/corpus/Supersession.json	NEW_PROPOSED	Approved supersession only	WP00	G0-SOURCE
sbl-tpm-sp/schemas/sbl-tpm/GitHubDeliveryDecision.schema.json	NEW_PROPOSED	Typed GHP-01 decision	WP06	G5-GITHUB-DECISION
sbl-tpm-sp/schemas/sbl-tpm/ErrorEnvelope.schema.json	NEW_PROPOSED	FirstFail, scope, resume predicate	WP02	G1-P4-SEM
sbl-tpm-sp/schemas/sbl-tpm/RiskMapping.schema.json	NEW_PROPOSED	DOC06 12-axis non-downgrade	WP02	G1-P4-SEM
sbl-tpm-sp/scripts/verify_corpus.py	NEW_PROPOSED	Full SHA/count/escape verification	WP04	G0-SOURCE
sbl-tpm-sp/scripts/gate.py	NEW_PROPOSED	Local decision gate deny-by-default	WP06	G5-GITHUB-DECISION
sbl-tpm-sp/scripts/prepublish_probe.py	NEW_PROPOSED	Read-only local Git identity preflight	WP06	G6-REMOTE_IF_APPLICABLE
sbl-tpm-sp/tests/test_delivery_gate.py	NEW_PROPOSED	Decision NEG and LOCAL_ONLY POS	WP06	G5-GITHUB-DECISION
sbl-tpm-sp/.github/workflows/sbl-candidate.yml	NEW_PROPOSED	Readonly PR/merge_group candidate gates	WP09	G9-RELEASE
sbl-tpm-sp/adapters/pipd_compiler.*	NEW_AFTER_CAPABILITY_DISCOVERY	Thin Reader/Compiler, canonical owner preserved	WP07	G4-PIPD-COMPILER
native-sbl-tpm/contracts/MissionHandoff.schema.json	NEW_PROPOSED	Versioned SP→Native exchange	WP07	G4-PIPD-COMPILER
native-sbl-tpm/adapters/hgk_receiver.*	PATCH_AFTER_DISCOVERY	Real permit receiver and audit	WP08	G7-NATIVE_IF_CLAIMED
native-sbl-tpm/adapters/hermes_spine.*	PATCH_AFTER_DISCOVERY	One real durable queue/mission terminal	WP08	G7-NATIVE_IF_CLAIMED
native-sbl-tpm/adapters/fabric_readback.*	NEW_AFTER_CAPABILITY_DISCOVERY	Stage/Active/Loaded/Consumer raw	WP08	G7-NATIVE_IF_CLAIMED
native-sbl-tpm/adapters/repo_publisher.*	NEW_AFTER_CAPABILITY_DISCOVERY	Authorized remote publication not auto-push	WP06	G6-REMOTE_IF_APPLICABLE
native-sbl-tpm/tests/restart/	NEW_PROPOSED	OS process restart, lease CAS, stop controller	WP08	G7-NATIVE_IF_CLAIMED
native-sbl-tpm/tests/e2e/	NEW_PROPOSED	LocalOnly+PR golden, three B1 WO	WP10	G7-NATIVE_IF_CLAIMED
sbl-tpm-sp/sbom/	NEW_PROPOSED	SPDX/CycloneDX or admitted equivalent	WP11	G9-RELEASE
sbl-tpm-sp/NOTICE	NEW_PROPOSED	License and third-party attribution	WP11	G9-RELEASE
```

## 13.3 `checkrun_contract.tsv`（不把候選 Workflow 冒充 Trusted Verifier）

```tsv
required_check	reporting_authority	oracle	missing_or_failure_degrade
sbl-corpus-integrity	sbl-candidate GitHub Actions / required when plugin changes	hash,count,source paths	FAIL / required not waived
sbl-p4-semantic	PIPD approved compiler or authorized runner	POS NEG EDGE SEC hash/subject/receipt	HOLD PIPD Qualification
sbl-risk-profile	PIPD Profile Owner	12 to 9 lossless-veto fixtures	HOLD effective Profile
sbl-oracle-bind	PIPD Oracle owner/trusted verifier	canonical Oracle sha + legacy locator	HOLD affected TQAEP
sbl-tpm-stage	SBL TPM Owner	18 stage contracts, 3 source map conflict	HOLD affected stage
sbl-portable-host	Authorized Host UAT	clean install load trigger nontrigger uninstall	HOLD plugin host qualification
sbl-github-decision	SBL QuestionGate test runner	ask once/local_only/deferred POS NEG	HOLD publication decision only
sbl-publisher-preflight	Authorized Repo Publisher	repo id/visibility/branch/preimage/credential/scan	HOLD remote write only
sbl-remote-readback	Authorized Publisher/trusted checker	remote branch/PR SHA and status	HOLD remote delivery
sbl-hgk-admission	HGK Issuer/Receiver	permit scope/nonce/epoch/revoke POS NEG	HOLD native admission
sbl-hermes-restart	Hermes Durable Controller	lease CAS/restart/ready-no-stop	HOLD native continuity
sbl-fabric-loaded	Fabric Native Reader	stage/active/loaded/consumer	HOLD fabric qualification
sbl-model-served	Model Host Reader	provider/model/method/transport actual served	HOLD model qualification
sbl-independent	Protected, non-PR-mutable trusted Checker App	exact candidate sha/subject/Raw/Checker	FAIL CLOSED; never candidate CI auto-green
sbl-provenance	Protected Publisher if feature available	subject builder digest signature	HOLD if required; admitted equivalent route
sbl-golden-journeys	SBL Product UAT Owner	GJ01/02/03-Skill/03-Agent	HOLD product qualification
sbl-b1-native-e2e	B1 independent checker	3 Golden WOs + G-A/G-B new process	HOLD B1 native qualification
sbl-release	Authorized Release Authority	all applicable checks+ratification+remote hash	FAIL CLOSED
```

### 13.4 正確配置 Repo Required Checks 的前置

`checkrun_contract.tsv` 的 `required_check` 是**建議命名**，不是已在各 Repo Ruleset 內設定成功。需先核對 `{OWNER,REPO,BASE,REPO_ID,RULESET_ID,CHECK_APP_ID,BRANCH,WORKFLOW_FULL_SHA,MERGE_GROUP_POLICY}`。只有已部署且有可信 App/工作流的 Check 才能成為真正的 Required Check；不可設一個永遠不存在的 Required Context 造成永久死鎖，也不可用 PR 作者可改的 Workflow 報出 `sbl-independent=success`。分母按各 Repo 所需 Gate 選取，`NOT_APPLICABLE` 必有 Owner-approved proof。[N:SBL-12:C43; SUP-W06/W07/W25]

---
# 14｜獨立審查交付清單與最終裁決

**審查者首先驗證**：物理 40 檔 Manifest SHA→基礎 DOC Source Authority→現役 PIPD/TPM Plugin 發行身份→P4 Fixture 真編譯→Github Publisher/Host/SoD Currentness；再將已生效的 R15 義務逐項映射到 `Applicable WorkDAG`。若資料不存在，回答 `MISSING` 而非修補臆測。[N:PIPD-01/04/07; N:SBL-12]

**工程可採納裁決**：`ADOPT_DUAL_FORM_FACTOR_AS_DESIGN`、`ADOPT_GITHUB_DECISION_GATE`、`ADOPT_CODEX_BUILDER_NATIVE_INTEGRATION`、`ADOPT_SIX_DONORS_WITHOUT_SECOND_SCHEDULER`、`ADOPT_FULL_CORPUS_PROGRESSIVE_LOADING`、`PRODUCTION_RELEASE_FAIL_CLOSED`。

**最後一次風險界線**：這份 Markdown 已具可施工的來源矩陣、事件、ABI 候選、權責、狀態機、Python 驗證、CI 候選、WorkPackages、測試和 machine blocks；**沒有**任何新的 PIPD SourceFreeze、HGK Permit、Hermes Durable Successor、Fabric Loaded、Model Served、Checker Verdict、GitHub Push 或 Authorized Release。相應缺口保留 CR_OPEN，絕不由「藍圖完整」推導「產品已可正式發布」。

