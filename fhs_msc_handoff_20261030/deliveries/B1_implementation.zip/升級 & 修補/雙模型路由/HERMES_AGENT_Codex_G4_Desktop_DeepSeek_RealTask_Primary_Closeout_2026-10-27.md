# HERMES AGENT 執行總指揮令 G4｜原生桌面 Codex × DeepSeek 真實小任務驗收、OpenCodex 2.92.0 主選升格與結案

- **命令 ID**：`OWNER-G4-DESKTOP-DEEPSEEK-REAL-TASK-PRIMARY-CLOSEOUT-20261027`
- **日期／時區**：2026-10-27，Asia/Taipei
- **OWNER**：全系統唯一 OWNER；本令直接授權本機 Hermes Agent 進行下述全部有界調查、**一次桌面 Codex／DeepSeek 小型真實程式施工測試**、最小必要自修復、機械自驗、主選升格、回滾點及結案。**不需為已列明行動再次請示**。
- **執行模型**：本地 Hermes Agent 使用 **OpenCode Go · DeepSeek V4.1 Flash**；被測主體是 **Windows 原生 Codex Desktop 內透過 Picker 選到的 DeepSeek**，不是 Hermes 自己使用 DeepSeek 回答，也不是僅用 `curl` 或 Codex CLI 模擬。
- **工作模式**：`AUTONOMOUS_EXECUTE → OBSERVE → ONE_BOUNDED_REPAIR_IF_NEEDED → RETEST → PROMOTE_OR_ROLLBACK → CLOSE`。
- **Scope**：僅本機 Codex 雙供應商 Gateway／原生 GUI 可觀測能力／隔離小測試 Repo。不觸碰 FHS-MSC r5 的 HG-KSEOS、PIPD、Fabric、SBL 等產品 Repo、PR、Native Gate、使用者私人檔案或有效憑證。

## 0. OWNER 最終預先裁決：先驗真實桌面任務，再升格主選，不無限擱置

1. **接受 G3 的已完成升級**，`@bitkyc08/opencodex@2.92.0`、原正式埠 `127.0.0.1:10102`、原 `desktop_router`、原廠 OAuth 和 Go 雙路由基線均已由 Hermes 回報成功；**不重裝、不再升級、不重新跑 G1/G2 原取證**，除非當場身分比對顯示漂移。
2. **G3 尚未驗證的關鍵缺口**是：在升級後的**原生 Windows Codex Desktop**，透過 **GUI Picker** 真正選定 `OpenCode Go · DeepSeek V4.1 Flash`，完成帶有檔案 Diff 與自動化測試的任務，同時檢查是否發生新的 `compacted`、重讀／重建情境、無進度重試。**本令批准且要求執行一次小型真實測試**。不能用先前 `curl`、G3 協定冒煙或 Hermes 自己的 DeepSeek 工作結果代替。
3. **驗收主張上限**：短測試 PASS 僅證明「新版 Gateway＋桌面 Picker＋DeepSeek 在此有界實際工作負載中可以完成任務，且未觀察到異常壓縮循環」，**不能證明**「未來所有 121,600 Context、數小時長任務皆不會再壓縮」，也不等於 `COMPACTION_LOOP_FIX=CONFIRMED`。原歷史長任務的修復狀態一律保持 `NOT_CONFIRMED`，除非另有同等壓力的受控實驗。
4. **升格規則**：當 G3 的已驗證基線仍一致、原生桌面小任務 PASS、回滾點可用，即批准並**自動寫入**：`PRIMARY_GATEWAY=desktop_router / opencodex@2.92.0`、`GATEWAY_OPERATIONS_CLOSED=YES`、`DESKTOP_DEEPSEEK_BOUNDED_TASK=PASS`、`COMPACTION_LOOP_FIX=NOT_CONFIRMED`、`CROSS_FAMILY_SAME_THREAD=KNOWN_FAIL_UNTIL_NEW_PASS`。本機 `config.toml` 若已設 `desktop_router`，**不要為升格再更動程式配置或預設模型**。
5. GUI 無法操作／驗證時，必須標 `DESKTOP_GUI_TASK=NOT_EXECUTED/NOT_OBSERVED`；可保留 G3 `UPGRADED_2_92_0_OPERATIONAL_PASS`，但**不得**謊稱已實測桌面 DeepSeek 工作。不得將 CLI-only PASS 升級成 GUI PASS。若存在真實功能回歸，做最多一次有根因指向的隔離小修與一次重測；不能修好則依責任邊界恢復舊版或 `HOLD_VERIFIABLE_BLOCKER`，詳見第 6 節。
6. **不再以無專職 Independent Checker 阻擋本機工具維護**；Hermes 的原始 GUI 觀測、Rollout 事件、Git Diff、Python `unittest` 的退出碼、程序與 SHA 收據就是本機營運機械驗收。仍**不得**宣稱 FHS-MSC Native／Independent Acceptance 已通過。

## 1. 既有資料交叉鑑定（只讀；以當場讀回為真）

### 1.1 來源與證據等級

| 已有事實／結論 | 證據 | 判讀 |
|---|---|---|
| G3 已將 2.11.0 → 固定 vendor 2.92.0；PID 曾為 6284；loopback 10102 健康 | `02_upgrade_diff_and_integrity.md`、G3 回報 | **升級已完成**，當前 PID 要重新讀取，不能固定 6284 |
| `router.ts` 只有兩行 Import 變更 | before `0c8ff56a…` / after `3ecb99ed…` | 沒有新建 Gateway；核心由原生 `@bitkyc08/opencodex` 執行 |
| `config.json` 明確 `claudeCode.enabled=false` | after SHA `57752556…` | 防止新版自行啟動 10204/10205、Claude intercept、建立 CA；本輪重新確認 |
| `catalog.json` / Codex `config.toml` 未改 | `c908b53a…` / `a2e1b3ae…` | 不能為完成這輪而更改模型 Slug、Provider、Context Window 或 root model |
| G3 原廠 OAuth、DeepSeek、MiMo、工具與 SSE、compact v1/v2 | Hermes G3 協定與受限工作收據；完整 JSON 請從本地 G3 檔讀回 | **協定驗收 PASS；不等於新版原生桌面程式施工實測** |
| G3 原生 Picker 10 項 | 未 GUI 觀察；僅 `/v1/models` 11 entries/9 visible 加預設作推算 | **GUI_NOT_OBSERVED**，本輪須實測 |
| DeepSeek 歷史 T1 353 次 Compaction | G2/G3 取證：其中 352 次在同一 `turn_id` | **嚴重循環已成立；升級後是否改善未知** |
| G1 模型名稱差異致每回合壓縮 | G2 逐筆推翻 | **REFUTED_AS_REPEATED_TRIGGER**，禁止為此任意刪 `opencode-go/` |
| G2 79M lifetime tokens 直接驅動壓縮 | G3 更正，`last_token_usage` 與 `total_token_usage` 分離 | **RETRACTED**；活動上下文與 historical reasoning 估算尚有未知 |
| Go 有效窗口 121,600，T1 last usage median 65,998/p90 104,364，工具輸出峰值 1,435,475 B | `01_g2_counter_correction.md` | 大歷史與工具輸出是合理放大因素，**非已證實唯一原因** |

### 1.2 固定版本身分與既有回滾點

```text
Expected gateway: vendor\opencodex-2.92.0 (MIT; gitHead 9f0d40a25f8b842c33ab233d466d0bd991d86052)
Expected wrapper SHA256: 3ecb99ed8c519e3f3ab2a0e8ab0bef557d3476ee20f76eec6ff49b7d291b1dc5
Expected config.json SHA256: 57752556f4c7f2292aba34f580bca9149f1f61e7812a904c92fef7d6058463c8
Expected catalog.json SHA256: c908b53a3fbe24e50670979f8193a137bc991e6f0c79e9d22579fd625248bbb5
Expected config.toml SHA256: a2e1b3ae34c7a5428884fb091a4c891d6b8e591b67a2237c9d7e036d076696df
Tarball SHA256: ac71cdb2a4e03f546caeb5521886ad67d744a2769e05c6de008cb061d8e18d75
Rollback preimage: C:\Users\user\.codex\desktop-model-router\g3_backup_20261027T111944\
Old 2.11.0: C:\Users\user\AppData\Roaming\npm\node_modules\@bitkyc08\opencodex
```

上述皆為 **G3 報告值，不是本輪現場已證明的值**。逐項 `Get-FileHash` 對照，若使用者合法調整導致不同，先比對來源與動機，**不得盲目覆蓋**。備份與舊版留存，禁止為結案做破壞性清理。

### 1.3 2026 年 10 月已查證外部技術資料

- OpenCodex 2.92.0（2026-10-24）正式 Release／npm 來源：<https://github.com/lidge-jun/opencodex/releases>；有 Hermes session correlation 與 SSE carry 修補，但**沒有官方宣稱能保證消除本案長任務循環**。
- 2.90.0 同 Releases：Responses opaque state 恢復 `#7388`、DeepSeek／MiMo／OpenCode Go Adapter `#7394`。
- OpenCodex 關閉 Claude routing 的既有設定：<https://github.com/lidge-jun/opencodex/blob/main/docs-site/src/content/docs/guides/claude-code.md>；`claudeCode.enabled=false` 有官方文件依據。
- OpenCode Go 模型清單：<https://docs.opencode.ai/docs/go/>；包含 DeepSeek V4.1 Flash、MiMo-V2.6-Flash。
- Codex 2026-10-21 #55928：<https://github.com/openai/codex/issues/55928>；保留 encrypted reasoning 被重複估算，可能使 Compaction 早於 UI 顯示的窗口比例，不可只憑 `last_token_usage` 反推精確 Trigger。
- Codex 2026-10-11 #53204：<https://github.com/openai/codex/issues/53204>；Windows Desktop 壓縮頻率異常回報，為觀察而非同負載控制實驗。
- Codex 2026-10-26 #57006：<https://github.com/openai/codex/issues/57006>；即使原廠模型的長任務亦有壓縮後反覆讀檔、無程式進展案例。**不能把短程成功等同永久修復**。

## 2. 工作預算、安全及停止規則——避免本次驗收本身再陷入循環

1. 首次完整閱讀本指令**一次**，立即落地 `G4_CHECKPOINT.json`（最多 6 KiB），之後只取 Checkpoint、所需檔案片段；禁止重新讀取此指令 N 次。單筆工具輸出 ≤ **64 KiB**；超過則落磁碟、僅回傳摘要／定位行。
2. **只允許一個新的真實 GUI DeepSeek 小任務**及其必要的短續談／一次可選手動壓縮檢驗；若前置 GUI 障礙存在，最多一個現場小型修補與一次重測，不可開 5 個幾乎相同的 Threads 假裝多組獨立驗證。
3. **預算**：新增 Go 上游請求最多 **12 次**（真實 Codex 工具迴圈可能需數次 API 請求）；本輪原則**0 次**額外官方付費請求，只有正式官方 OAuth 基線不一致時最多 **1 次**必要確認。整個 GUI 小任務最長執行 **10 分鐘**，最多 **18 次工具呼叫**。超限直接 `STOP_BUDGET`，不是繼續等待、反覆壓縮或重跑全套。
4. 連續兩次 Compaction 且沒有新的檔案變更、測試收據或可核驗進展，或同一工具動作無差異重複三次、或連續八次工具呼叫都沒新結果：**立即停止該 Desktop 任務／寫 Checkpoint**；不得對既有大型 r5 Thread 開新一輪測試。小任務內出現兩次以上非人工觸發 Compaction，應標 `EARLY_COMPACTION_ANOMALY` 並提前停止。
5. 不重建／更新 Gateway，不增加 Port、不動 Windows CA／Credential Manager／系統 Proxy／防火牆、不輸出 OAuth/Go Key/原始 Authorization、不執行 `ocx start/sync/init` 接管正式配置、不更改預設模型／模型名稱／auto compact 閾值。**不可為方便測試關閉 Compaction 功能、偽造 response 或縮減 Catalog 窗口。**
6. 只在人工／UI 可核證的安全窗口使用桌面：若使用者正在操作、Composer 有未送出的草稿或已有進行中的 Codex 任務，不能強殺／遮蓋；本令對**新建隔離測試 Repo**已明確授權，但不授權破壞使用者當前工作。若 GUI 自動操作權限缺失，記實際阻擋；CLI 替代可作診斷，**不得冒充原生 GUI 測試**。
7. 任務允許自主修復，但限於已發現且可復現的小型 Local Gateway／Wrapper／模型選單故障：先快照、同一原因僅修一次、重測一次。服務級關鍵回歸與本次變更有因果關係時回滾，**不得因模型答錯一個小型測試就直接回滾已通過安全與路由的 Gateway**；先區分模型行為、測試環境及路由缺陷。

## 3. Gate A｜當場一次確認正式桌面運行實體（快速唯讀）

- `curl.exe -sS --fail http://127.0.0.1:10102/router/health`；確認 `ready`。
- `Get-NetTCPConnection -LocalPort 10102 -State Listen` 與 `Get-CimInstance Win32_Process` 核對目前 Listener 只在 loopback、當前 PID／CommandLine、Import 真正 vendor 2.92.0。SSE `response.in_progress` 僅為輔助行為指紋，**不是單獨版本證據**。
- 對 `router.ts`、`config.json`、`catalog.json`、`.codex/config.toml` 算 SHA，確認現場或記錄實際差異；核實 `claudeCode.enabled=false`、10204/10205 未由本服務監聽、新 CA 未產生、原廠/Go upstream 目的地與 G3 相同。
- 確認排程 `Codex Desktop OpenAI and DeepSeek Router` 與舊 2.11.0 回滾原件存在；**只做備份一致性／PowerShell 語法靜態確認，不為驗證回滾而真降版**。
- **必須觀察原生 Desktop GUI**：目前登入態、工作區、右下 Picker 原廠/DeepSeek/MiMo 可見性；先不切換既有使用者的任務。原 GUI 10 項歷史收據可當預期，**不能把 `/v1/models` 的 11 entries 當成實際 GUI PASS**。

## 4. Gate B｜OWNER 明確授權的「一次桌面 Codex + DeepSeek 小型真實程式任務」

### B1. 建立完全隔離的測試 Repo（Hermes 執行，不使用產品 Repository）

新目錄：

`C:\Projects\Agent_Workspace\GPT_Dual_Routing_Audit\Compaction_Regression_20261027_G4\synthetic_repo\`

先確認路徑不含原有使用者工作樹、敏感檔案及其他任務；若不存在才建立，不覆寫現存內容。使用 Windows 已有 `python` 與 `git`；如果無 Python，用現有最簡單可測語言／測試器替換，但明確記錄不使用 `pip install` 外部套件或網路下載。

初始 `tag_normalizer.py`（**故意未完工**）：

```python
"""A tiny, synthetic exercise for Codex Desktop provider testing."""

def normalize_tag(value: str) -> str:
    return value
```

初始 `test_tag_normalizer.py`：

```python
import unittest
from tag_normalizer import normalize_tag

class TagNormalizerTests(unittest.TestCase):
    def test_trim_and_words(self):
        self.assertEqual(normalize_tag("  RED   APPLE "), "red-apple")

    def test_punctuation(self):
        self.assertEqual(normalize_tag("MiXeD__Case"), "mixed-case")
        self.assertEqual(normalize_tag("  a---b  "), "a-b")

    def test_edges(self):
        self.assertEqual(normalize_tag("X"), "x")
        self.assertEqual(normalize_tag("   "), "")

if __name__ == "__main__":
    unittest.main()
```

執行 `python -m unittest -q`，確認**施工前失敗**且原因是未完成函式，而不是缺套件。`git init`、加兩份檔並 commit baseline（若 Git 使用者設定未準備好，允許只在本測試 repo 指定合成作者，不能改全域 Git 身分）。記錄 baseline `git status --short`／檔案 SHA、Git HEAD、Python 版本、基線測試退出碼；此測試 Repo 不 push／不發 PR。

### B2. **一定要使用原生 Codex Desktop GUI** 下達的小任務

1. 啟動／使用**現有正式 Windows Codex Desktop**，工作區選 `synthetic_repo`；**開一個全新 Thread**，絕不重用 T1 的 r5 長 Thread。
2. 在**GUI 模型選單**實際選擇 **`OpenCode Go · DeepSeek V4.1 Flash`**（後端 slug 依現場 `opencode-go/deepseek-v4.1-flash`）；確認不是 GPT／MiMo、不是僅更改 CLI profile 或 Hermes Agent 自身模型。記錄去敏的 Picker 顯示、選項/模型 ID 和桌面版本，可用局部 UI 截圖，不包含個人對話／Key。
3. 將下列**唯一施工任務**直接送至該 Desktop Thread（測試 ID 可由 Hermes 於外層日誌登錄，不必增加 Prompt 長度）：

> 只處理目前小型測試工作區的 `tag_normalizer.py`。請實作 `normalize_tag(value: str) -> str`：先將字串轉成小寫，把連續的非 ASCII 英文字母與數字字元換成一個 `-`，移除字串開頭／結尾的 `-`。不要修改 `test_tag_normalizer.py`；不要讀取任何其他 Repo 或使用者目錄；不要安裝依賴。完成後執行 `python -m unittest -q`，核對退出碼及測試案例，再回覆修改與測試結論，**完成即停止**，不要展開新規劃。

4. 允許被測 Codex 在**該合成 Repo**透過正常 Workspace 授權修改檔案、執行 Python、讀必要片段；**不允許**用 `--dangerously-bypass-approvals-and-sandbox`，不能將 Sandbox 全域改成不受限。若 Windows Sandbox 禁止合成 Repo 寫入，優先用正常 Workspace trust/permissions，不能單純為了取得 PASS 繞過安全機制。
5. 桌面模型執行完畢後由 Hermes **獨立執行**：`python -m unittest -q`、`git diff -- tag_normalizer.py`、`git status --short`、必要時 `python -m compileall -q tag_normalizer.py`。以 Exit 0、至少預設案例 3 個測試方法 PASS、實際檔案修改、**測試檔 SHA 不變**、變更僅在 `tag_normalizer.py` 為合格。**不能把模型口頭「我已完成」當作修改收據。**
6. 可做**一次同一 Thread 的短續談**（純驗證，不新增第二個施工任務）：

> 請只說明剛才變動的是哪個檔案、`python -m unittest -q` 是否通過、以及 `normalize_tag("  BLUE__BIRD  ")` 的預期結果。不要重新讀整個專案，也不要改檔。

Hermes 從實際 Repo 自行運算期望值為 `blue-bird`；觀察續談是否接得上前項工作而不是重新開始規劃。若上一施工 Thread 已於首次回合產生異常壓縮，立即停止，**不執行續談**。

### B3. Compaction／重建情境取證（不能偷換成「無壓縮保證」）

- 以 GUI 執行時段、工作區路徑、此新 Thread ID／Rollout 檔關聯，讀取**該測試 Thread** 的 `turn_context`、`compacted`、Token `last_token_usage`、工具呼叫及完成事件；只抽取去敏的模型、時間、事件、計數與檔案路徑 Hash。**不要讀回或傾印整段 Chat、工具 stdout、OAuth 或其他 Thread**。
- 必填：`desktop_app_version`、`selected_picker_label`、`effective_model_provider`、`requested_model_id`、`response_model`（有才記）、`router_pid/version`、`thread_id`（可雜湊）、`turn_id_count`、`compacted_event_count`、`automatic_compaction_count`（可辨才填）、`repeated_identical_read_count`、`tool_call_count`、`first_and_last_tool_action`、`actual_git_diff_paths`、`test_exit_code`、`elapsed_seconds`、`usage_available_or_unknown`。
- 小任務**理應**在遠低於 121,600 有效窗口時完成，若本案竟出現連續 2 次自動壓縮／重建相同背景、重複相同檔案讀取 3 次且沒有變更或測試進展，直接 `DESKTOP_DEEPSEEK_COMPACTION_LOOP_REPRODUCED`、停止、保留原始事件位置；不再讓它無限燒 Token。
- `compacted_event_count=0` 且實作 PASS：標記 `NO_ABNORMAL_COMPACTION_OBSERVED_IN_BOUNDED_TEST`。**不能**標記 `COMPACTION_LOOP_PERMANENTLY_FIXED`；短工作沒有達到壓縮門檻，本來就不應自動壓縮。
- **可選、單次、無壓力的恢復檢查**：僅在 Desktop 明確支援手動 `/compact` 且小任務已完整 PASS、並確認沒有進行中的工具呼叫時，允許用**原同一 Thread**手動壓縮一次，然後只問 `normalize_tag("  BLUE__BIRD  ")` 的預期結果和已修改檔案；觀察能否保留狀態。若 UI 不支援／任務太短無效則 `MANUAL_COMPACT=NOT_APPLICABLE`，**不**為觸發壓縮而大量灌入合成文字或重播 r5。手動恢復 PASS 仍不等於多次自動 Compaction PASS。

### B4. 何謂已實測？

| 觀察 | 可宣稱 | 不可宣稱 |
|---|---|---|
| G3 協定／SSE 200 | `GATEWAY_PROTOCOL_PASS` | `DESKTOP_REAL_TASK_PASS` |
| 原生 GUI Picker 選定 DeepSeek＋真檔案修改＋Python Exit 0 | `DESKTOP_DEEPSEEK_SMALL_TASK_PASS` | `LONG_CONTEXT_STABILITY_CONFIRMED` |
| 新小任務 Rollout 自動壓縮 0 次／無重讀循環 | `NO_ABNORMAL_COMPACTION_OBSERVED_IN_BOUNDED_TEST` | `353_COMPACTIONS_ROOT_CAUSE_FIXED` |
| 一次手動 Compact 並正確續談 | `SINGLE_MANUAL_COMPACT_RECOVERY_PASS` | `REPEATED_AUTOCOMPACT_RECOVERY_PASS` |
| GUI 無法控制，只有 CLI PASS | `CLI_FALLBACK_PASS` | `DESKTOP_GUI_PASS` |

## 5. Gate C｜直接升格主選與分層結案

### C1. 必須達成的實際條件

- 目前運行的 Gateway 是**被 PID／loaded vendor 路徑確認的** 2.92.0；與 G3 SHA/config 邊界相容，health ready；Claude intercept 已停、loopback／官方與 Go 目的地隔離未回歸。
- 正式 Codex Desktop **GUI Picker 可選 DeepSeek**；**Gate B 小程式任務真正 PASS**（修改源檔／測試 exit 0／無跨 Repo 寫入），Rollout 與 GUI / Router request 可對應，且沒有本輪重複壓縮／無進度回圈。
- G3 官方 OAuth、MiMo、SSE 工具等**相同配置**實測收據可引用，不為結案重打無意義付費請求；若本輪 SHA 或 Provider 變了，只重測受影響路徑。
- 舊版 2.11.0、`g3_backup_20261027T111944`、`router.ts.pre-g3`、`config.json.pre-g3` 經 SHA 靜態驗證可供回滾。

### C2. 三種分層結果（不允許模糊的 FULL_SUCCESS）

**結果 A｜通過、升格、結案**

```text
GATEWAY_RUNNING = OpenCodex 2.92.0 / 127.0.0.1:10102
GATEWAY_PRIMARY = PROMOTED_OPERATIONAL_PRIMARY
DESKTOP_GUI_PICKER = PASS
DESKTOP_DEEPSEEK_SMALL_TASK = PASS
BOUNDED_TEST_COMPACTION_LOOP = NOT_OBSERVED
COMPACTION_LOOP_FIX = NOT_CONFIRMED_LONG_HORIZON
CROSS_FAMILY_SAME_THREAD = KNOWN_FAIL_UNTIL_NEW_PASS
GATEWAY_MAINTENANCE_CLOSEOUT = CLOSED
FHS_MSC_R5_NATIVE = CANDIDATE_ONLY_UNCHANGED
OWNER_ACTION_REQUIRED = NONE
```

**結果 B｜Gateway 健康，但 GUI 真任務無法完成／無法觀察**

`GATEWAY_RUNNING_2_92_0=PASS`；`PRIMARY_GATEWAY=PROVISIONAL_OPERATIONAL`；`DESKTOP_DEEPSEEK_SMALL_TASK=FAIL | NOT_EXECUTED | NOT_OBSERVED`；`CLOSEOUT=PARTIAL_PENDING_DESKTOP_EVIDENCE`。只要沒有證據指向 Gateway 引起的安全或路由回歸，**不要為了 GUI 不可操作而盲目回滾健康 Gateway**。標出真正 blocker 並交付所有已驗證結果；不得造出 GUI PASS。

**結果 C｜確有新版引入關鍵 Gateway 回歸**

先對本次正式服務/設定做最小 preimage，最多一次有根因指向的修補＋一次重測。若官方 OAuth、Go 路由、工具、安全或 Claude intercept 重大回歸不能解決，使用 G3 已驗的精確備份回到 2.11.0，驗證服務恢復，輸出 `ROLLED_BACK_2_11_0_REGRESSION`，**不得繼續升格**。

**特別注意**：「升格主選」指 **Gateway 核心**，不是把 Codex 預設模型改成 DeepSeek。正常 `config.toml` 預設如為 GPT，保持不變；官方 ↔ Go 家族切換仍一律開新 Thread。

## 6. Gate D｜低負擔工件、回滾點與自動結案

Case 路徑：`C:\Projects\Agent_Workspace\GPT_Dual_Routing_Audit\Compaction_Regression_20261027_G4\`。新的正文最多 **4 份＋1 manifest**，Git 測試 Repo 作為其中的原始證據，不新增監控服務／第二套 Proxy／額外治理專案。

| 工件 | 最小必要內容 |
|---|---|
| `00_G4_DESKTOP_TASK_RECEIPT.json` | Desktop 版號、GUI 模型選擇、Go 路由、真實小任務、前後 SHA、Git Diff 路徑、unittest exit、Rollout 事件與 Compaction 數、停止規則、LIMITS，JSON 可解析 |
| `01_G4_PRIMARY_GATEWAY_AND_CLOSEOUT.md` | 升格／有限制／回滾正式裁決，G3 功能收據關聯，GUI 欠證界線，G1/G2 根因更正，`COMPACTION_LOOP_FIX` 判決，操作者日常守則 |
| `02_G4_ROLLBACK_AND_CHECKPOINT.md` | 當場 2.92 前像、舊 2.11.0／精確 G3 備份與 SHA、排程與程序確認、**不預先執行**的回滾命令、安全窗口與恢復後驗證；`MODEL_HANDOFF.json` 交接示例 |
| `03_G4_TEST_DIFF_AND_EVENTS.md` | 測試前 RED、測試後 GREEN；`git diff` 摘要、`unittest` 案例數與 Exit；GUI 與 Rollout 對應方法；Token/Compaction/重複工具統計的 source location（去敏） |
| `04_G4_SHA256_MANIFEST.txt` | 前四份 SHA256，重新驗證 4/4，manifest 不自雜湊 |

安全：交付內不含任何 OAuth/Go Key、Bearer header、整條 Session 內容、個人 Home 全文、無關 Repo／產品資料。只用必要的 SHA/小段工具結果；原始私密備份保持 ACL 限制，所有 JSON 寫完再 `ConvertFrom-Json` 驗證。**不打開 FHS-MSC 產品驗收**。

### 實際回滾操作（僅在必要時，不為證明而執行）

1. 驗證 `g3_backup_20261027T111944` 中 `router.ts.pre-g3`、`config.json.pre-g3` 的 SHA、舊版 2.11.0 套件版本，核實 Scheduler Action。
2. 核實當前 `10102` 監聽 PID **確實是本 Router**，且沒有使用者正在執行 Codex 任務；先保存當前 2.92.0 wrapper/config 的最終 SHA。
3. 恢復兩個有完整性驗證的 Pre-G3 檔，安全停止**僅本 Router**，由原排程啟動；如真的需要 `Stop-Process`，先按 PID/CommandLine 強驗，不能盲目殺埠。
4. 健康檢查與一個必要 Go/官方冒煙，確認舊核心路徑恢復；只於成功時聲明 `ROLLBACK_COMPLETED`。回滾失敗則 `HOLD_ROLLBACK_FAILED` 並停止高風險寫入。

### 最終 Hermes 回報格式（填實際值，禁止全填 PASS）

```text
CASE_ID: Compaction_Regression_20261027_G4
OWNER_AUTH: ONE_DESKTOP_DEEPSEEK_REAL_TASK_PLUS_PRIMARY_PROMOTION
EXECUTOR: Local Hermes Agent / OpenCode Go DeepSeek V4.1 Flash
DESKTOP_APP_VERSION: <readback>
REAL_GUI_TEST_EXECUTED: YES | NO
GUI_PICKER_DEEPSEEK: PASS | FAIL | NOT_OBSERVED
GATEWAY_RUNNING_PID_AND_VERSION: <PID / loaded path / 2.92.0 or actual>
GATEWAY_ROUTE_AND_KEY_BOUNDARY: PASS_FROM_G3_AND_CURRENT_MATCH | FAIL | UNKNOWN
DESKTOP_DEEPSEEK_TASK: PASS | FAIL | NOT_EXECUTED
TEST_RED_BEFORE: <exit + assertion>
TEST_GREEN_AFTER: <exit + test_count>
ACTUAL_EDITED_FILES: <diff paths>
TEST_ROLLOUT_ID: <hashed ID / source path>
COMPACTED_EVENT_COUNT: <integer or UNKNOWN>
AUTOMATIC_COMPACT_COUNT: <integer or UNKNOWN>
REPEATED_CONTEXT_REBUILD: OBSERVED | NOT_OBSERVED | UNKNOWN
FOLLOWUP_CONTEXT_CONTINUITY: PASS | FAIL | NOT_RUN
MANUAL_COMPACT_RECOVERY: PASS | FAIL | NOT_APPLICABLE
COMPACTION_LOOP_FIX_LONG_HORIZON: NOT_CONFIRMED
GATEWAY_PRIMARY: PROMOTED_OPERATIONAL_PRIMARY | PROVISIONAL_OPERATIONAL | NOT_PROMOTED
CROSS_FAMILY_SAME_THREAD: KNOWN_FAIL_UNTIL_NEW_PASS
FHS_MSC_R5_NATIVE: CANDIDATE_ONLY_UNCHANGED
ROLLBACK_POINT: <verified path and hashes / verification status>
GATEWAY_MAINTENANCE_CLOSEOUT: CLOSED | PARTIAL_PENDING_DESKTOP_EVIDENCE | ROLLED_BACK
PRODUCTION_CHANGES_G4: NONE | <exact change list>
ARTIFACT_MANIFEST: 4/4 VERIFIED | <real issue>
FIRST_FAIL: NONE | <first verified failure>
OWNER_ACTION_REQUIRED: NONE | <one actual external blocker>
```

**終止指令**：正常 PASS 並結案、已成功回滾、或存在客觀不可操作 GUI／不可修的實體 blocker 後，**立即停止**。不得以「要證明絕不再壓縮」為理由，繼續無限讀文件、重演 4.9 小時 r5 或建立 G5 研究專案。這一次只要求**有證據的真桌面工作完成＋誠實的有限能力聲明**。
