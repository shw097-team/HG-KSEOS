# HERMES AGENT 工程指揮 PROMPT｜Codex Desktop × OpenAI × OpenCode Go：Compaction 循環取證、現成 OpenCodex 對照及最小充分修復

**版本**：`2026-10-27 / ROUTER-COMPACTION-R1 / zh-TW`  
**交付對象**：本機 Hermes Agent  
**執行模型**：`OpenCode Go · DeepSeek V4.1 Flash`（精確模型 ID：`deepseek-v4.1-flash`；本機工作端實際模型名稱若不同，以已驗證的 Hermes 模型設定為準）  
**OWNER 授權**：全系統唯一 OWNER 已明確授予此案的有界代位裁決與執行權。**依下列範圍直接執行；不就已列明的安全檢查、隔離 POC 及合格後受控導入重複請示。**  
**工程原則**：`SEARCH_BEFORE_BUILD / REUSE_BEFORE_REWRITE / MINIMUM_SUFFICIENT_ARCHITECTURE / PRESERVE_WORKING_BASELINE / EVIDENCE_FIRST / FAIL_CLOSED / SoD / BOUNDED_AGENT_EXECUTION`。  
**重要**：本文件本身不是本機事實的替代品。所有版本、來源、雜湊、設定與功能狀態均須以即時機械讀回為準。不得在缺少證據時宣布 Router 有 bug、OpenCodex 可修復，或 DeepSeek 模型品質不足。

---

## 0. 即刻任務：一段話版

你是本機 Hermes Agent 的**工程 Maker／執行者**，使用 `deepseek-v4.1-flash`，**不是重新建造第二套 Router 的架構師**。先唯讀調查 2026-10-27 的 GPT→DeepSeek→GPT 長 Thread 異常：DeepSeek 段報告 353 次 Compaction、837 次工具呼叫、沒有可辨識的產品程式碼 patch。比對「原本 OpenCode Go 直連」、「既有 `desktop_router`」、「獨立的完整 OpenCodex 固定版本」的 Compaction／工具／模型切換行為。先使用已存在的 OpenCodex／Codex 技術；若現況已可靠，**只補新 Thread＋Checkpoint 的操作約束，不更換 Gateway**。若完整 OpenCodex 在**隔離環境**可機械證明消除目前 Gateway 的真缺陷，且能保持官方 OAuth、Go Key、Picker、安全與回滾相容，才允許依 Gate D 做**一對一受控替換**。不能讓另一個 Agent 再消耗上百次 Compaction、反覆讀文件或長時間沒有 WriteSet 進展。

任務執行完畢立即提供帶真實證據的終局判決：`KEEP_CURRENT_ROUTER`／`REPLACE_WITH_PINNED_OPENCODEX`／`HOLD_INSUFFICIENT_EVIDENCE`／`ROLLBACK_COMPLETE`；不可只有長篇規劃而沒有實際取證、測試與判定。

## 1. OWNER 已生效的工程裁決與權限邊界

### 1.1 既有成果：不可破壞

已驗收的基線（皆為**過去 Hermes 報告的觀察，不可等同今日即時狀態**）：

- Windows Desktop `OpenAI.Codex 26.1021.3705.0`；Codex 引擎 `codex-cli 0.164.0-alpha.11.1`。
- `C:\Users\user\.codex\config.toml` 的有效 root Provider 為 `desktop_router`；自訂 Provider `wire_api="responses"`、`base_url="http://127.0.0.1:10102/v1"`、`requires_openai_auth=true`、`supports_websockets=false`。
- Windows 本機 `bun.exe` 執行獨立 `C:\Users\user\.codex\desktop-model-router\router.ts`，僅監聽 `127.0.0.1:10102`，排程 `Codex Desktop OpenAI and DeepSeek Router` 負責登入啟動。
- Picker 有 7 官方模型＋預設組合＋2 Go 模型＝**10 個可見項目**（router catalog 11 個 slug；**切勿混淆顯示項目與 catalog entries**）。
- 官方模型通過真 OAuth→Router→`chatgpt.com` 200；DeepSeek `deepseek-v4.1-flash`、MiMo `mimo-v2.6-flash` 經 Router→`opencode.ai` 200、實際工具呼叫與短期多輪測試均已通過。
- 之前 `T12R=FAIL`：同一 Thread 跨官方／Go 會發生 `400 array_above_max_length`；`T13R=NOT_TESTED_SAFE`、`T14R=PARTIAL`、`T16R=PARTIAL`；Router 停止可造成兩供應商一起中斷。
- 已有回滾腳本 `C:\Projects\Agent_Workspace\GPT_Dual_Routing_Audit\switch_route_official.cmd` 及其他已驗證私密備份；**保留**原 Go／官方切換工具，禁止刪除。
- 既有 npm 套件版本報告為 `@bitkyc08/opencodex@2.11.0`，但**實際供應請求的是另一個 73 行上下的 `router.ts`**；不得以 npm 套件存在即認定完整 OpenCodex Compaction 已啟用。

已通過的單一 Picker／OAuth 不因新案件而改判失敗；本次須處理的是**未驗證的跨模型長 Thread、Compaction、長任務進度恢復**。

### 1.2 本次經 OWNER 授權可直接執行

1. 讀取本機設定與安全不變量（必要欄位，不外洩憑證）；唯讀取證 rollout、日誌、Router 程式及相依套件；SHA-256 封存。
2. 建立新的**隔離** `CODEX_HOME`／實驗目錄／本機 loopback Port／只包含合成資料的 Git 測試 Repo；**不覆寫正式 `.codex`、不碰正式產品 Worktree**。
3. 在隔離目錄從官方 GitHub/npm 取得經來源、Release Tag、Commit、package integrity 驗證的**固定** OpenCodex 版本；本輪起始候選為截至 2026-10-27 公開的 `@bitkyc08/opencodex@2.92.0`，精確採納版本由相容測試決定。允許讀取官方原始碼、執行隔離單元／相容測試，不允許更新正式 2.11.0。
4. 設計並實際執行低 Token 成本的 A/B／交叉模型合成測試，根據**功能收據**而不是模型口述成功判定。
5. **在 Gate A–C 真實通過，且獨立技術驗收已成立的條件下**，允許執行本文件限制的**單一 Gateway 原子受控切換、GUI 小規模驗收與回滾預演**；不必再索取相同範圍的 OWNER 批准。驗收缺失立即回滾。
6. 新增本次調查與操作交接工件至新的稽核目錄；不改寫舊 r2 取證報告，不重寫 FHS-MSC r5 候選、不合併 PR。

### 1.3 禁止事項（任何「全部權限」都不抵銷技術證據與信任邊界）

- **不得**在正式 `CODEX_HOME` 執行 `ocx start/sync/init/link` 或安裝腳本；這些行為可能自動覆寫 `openai_base_url` 與 model catalog。隔離環境亦必須先以唯讀方式查明命令的副作用，才可在明確隔離的 Home 運行。
- **不得**修改原廠 EXE/MSIX、ASAR、DLL、系統 TLS、系統 Proxy、全域環境變數、Windows 安全機制、瀏覽器 OAuth 儲存、`auth.json`；不得把官方 OAuth 金鑰移交至新增的服務／帳戶或讀取、複製、匯出 Token。
- **不得**讓 Go Key 送往官方 OpenAI，也不得讓 OpenAI OAuth 轉往 `opencode.ai`、其他自訂第三方或新增的遙測／日誌主機；任何未知目的地都要 fail closed。
- **不得**同時串接兩個 Gateway（`Codex→Router A→OpenCodex B` 禁止）；不能將候選外網 bind `0.0.0.0`；不能停掉正式 Router 只為測試。
- **不得**調大 `model_context_window` 來掩飾 400、停用 Compaction 來掩飾循環、手工篡改 session JSONL／SQLite 來偽造續談成功。
- **不得**為了重演故障重新送 45M+ Tokens、重跑 FHS-MSC r5 的全部四 Repo 工作、重做全部 Maker／Checker／Native Gates 或建立新記憶服務／向量 DB。
- **不得**把 Maker 自測、AI 第二次閱讀報告、GitHub Issue／README 宣稱，寫成真正 Independent Checker PASS。

---

## 2. 本案事實、證據優先順序與重要未知數

**證據來源優先序**：本機 rollout 原始位元（若可讀）／程式和 Git 真實 Diff／Router 請求級匿名收據／Model Catalog 實際 JSON／當前 Windows App 回歸結果 ＞ Hermes 既有取證報告 ＞ 使用者操作紀錄 ＞ 社群 Issue／一般文件 ＞ 工程假說。

### 2.1 已有事故證據（不可重述成「DeepSeek 本身有 bug」）

從 `B1_R5_CROSS_MODEL_ENGINEERING_PROVENANCE_AUDIT.md`、`B1_R5_T0_T1_T2_FILE_DELTA.tsv`、完整對話匯出整理：

| lane | 時段（Taipei） | 工具呼叫 | Patch | 估列輸入 Tokens* | 輸出 Tokens | Compaction |
|---|---|---:|---:|---:|---:|---:|
| T0 GPT | 10/26 23:58–10/27 03:07 | 137 | 54 | 31,847,239 | 208,315 | 1 |
| T1 DeepSeek | 10/27 03:08–07:59 | 837 | 0 | 45,479,969 | 1,439,980 | **353** |
| T2 GPT | 10/27 08:01–08:41 | 89 | 40 | 17,171,726 | 75,381 | 0 |

*輸入含 Cached Token，**不是**花費或唯一 context 長度；所有數值為既有報告的 rollout 統計，不替代原始事件重新稽核。T1 實際曾產生證據檔案、Repository 傾印及一次 27 passed 測試，但在受審產品檔案未發現有效程式碼增量。

**關鍵時間關係**：使用者在**同一已累積 GPT 工作歷史的 Thread** 切入 DeepSeek，立即開始頻繁壓縮，切回 GPT 後又可接續舊候選。這支持「跨 Provider 歷史／Compaction／目錄」為高優先假說，但沒有 Provider Request ID 便不能認定 353 次都由哪個真實上游模型服務。

**供應鏈與證據限定**：本輪上傳的取證 MD 副本 SHA-256 曾與報告給定值不符（可能是版本不同）；TSV 副本在結構／階段欄位上有歧義。若本機兩者仍不一致，**必須登錄**而不是覆寫、悄悄修正。可依可靠的原始 JSONL 重建摘要。不得把 `turn_context.model` 標籤寫成 Provider 所回傳的模型簽章。

### 2.2 必須明確分離的 4 個假說

- `H-CROSS-THREAD`：Codex 同 Thread GPT→Go 的 Previous-model PreTurn Compaction、`comp_hash` 或 Model Downshift 造成重壓縮；本案 T12R 已知同家族之外歷史曾不相容。
- `H-CATALOG`：合併 `model_catalog_json` 的 DeepSeek 上下文上限／壓縮支援／`model_auto_compact_token_limit[_scope]` 與先前直連 Go 配置不同。
- `H-ADAPTER`：現行 `router.ts` 未涵蓋 Codex Compaction v1 `/v1/responses/compact`、v2 `compaction_trigger`、完整 Responses SSE、reasoning/tool replay；或匯入的適配器版本不足。
- `H-HARNESS`：Codex/Agent 任務壓縮後遺失 checkpoint、反覆讀同一份 r5／技能文件而不產生新的 WriteSet。**一樣可能在原廠 GPT 發生**；不應用切換 Gateway 取代任務進度治理。

另將 `H-UPSTREAM-CACHE` 視為**不同類型**：Go Cache Miss 可能令費用／耗時上升，但**不能直接當作 353 次 Compaction 原因**。OpenCode Issue #58175 的維護者後續討論亦指出部分高 Cache Miss 可由專案插件或 Prompt Prefix 改變造成；沒有對應 request_id 時不得下結論。

---

## 3. 本輪已核對的外部公開來源（截至 2026-10-27）

工程分析優先官方文件／實際上游程式碼與版本發行；GitHub Issues 為個案，不等於已對本機重現。**2026-10-01 後的材料**：

1. **OpenCodex Releases**，`2.87.0` 10/16、`2.88.0` 10/17、`2.89.0` 10/19、`2.90.0` 10/21、`2.91.0` 10/22、`2.92.0` 10/24：https://github.com/lidge-jun/opencodex/releases 。10/21 `#7388` opaque Responses 狀態還原及 `#7394` MiMo、DeepSeek、opencode-go adapter 修補；10/24 `#7542` Hermes Session correlation、`#7541` SSE chunk 處理改進。**這些是候選修補，而非對本次事故的實機驗收。**
2. **Codex #54423**（2026-10-15，Custom provider / failed previous-model compaction）：https://github.com/openai/codex/issues/54423 。`previous_turn_settings.model`、`comp_hash`、Model Downshift、PreTurn compact fallback 是關鍵診斷線索；該 Issue 是特殊前模型拒絕造成的失敗，**不是本機 353 次成功提示的同一個證明**。
3. **Codex #54881**（2026-10-17，Windows model_catalog_url vs model_catalog_json）：https://github.com/openai/codex/issues/54881 。指出本機 JSON 模型清單在 Windows Picker 可能較可靠，但顯示成功不等於請求成功。
4. **Codex #57006**（2026-10-26，自動 Compaction 後重讀檔案／不產生施工進展）：https://github.com/openai/codex/issues/57006 。說明官方模型也可能有循環；須分離 Harness 與 Go 轉接因素。
5. **OpenCode Go 官方文件**：https://docs.opencode.ai/docs/go/ 。`deepseek-v4.1-flash`、`mimo-v2.6-flash` 目前列用 `https://opencode.ai/zen/go/v1/chat/completions`；要求穩定 `x-opencode-session`、自訂 User-Agent；各類端點／版本與本機成功日誌必須實測後固定。
6. **Codex Config Reference**：https://learn.chatgpt.com/docs/config-file/config-reference 。有 `model_provider`、`model_catalog_json`、`model_context_window`、`model_auto_compact_token_limit`、`model_auto_compact_token_limit_scope`、`requires_openai_auth`；讀有效值，不在正式配置盲目改動。
7. **OpenCodex How It Works**：https://github.com/lidge-jun/opencodex/blob/main/docs-site/src/content/docs/getting-started/how-it-works.mdx 。區分 `POST /v1/responses/compact` 與 Responses `compaction_trigger`；上游走 Compaction 摘要或 passthrough，SSE 需正確終止、工具/推理要保留。
8. **OpenCodex Codex Integration**：https://github.com/lidge-jun/opencodex/blob/main/docs-site/src/content/docs/guides/codex-integration.md 。`ocx init/start/sync` 預設修改 Codex config/catalog；`codexClientCompaction`、`compactionRouting`、`compactionRecovery` 是不同開關，預設和修改後果不同，**不要同時任意啟用**。
9. **OpenCode #58175**（2026-10-22，DeepSeek V4.1 的特定 Prompt Cache Miss 回報及維護者反證）：https://github.com/anomalyco/opencode/issues/58175 。不能把 Cache Miss 當 Compaction 次數。
10. **2026-10-01 arXiv / HF AutoCompact**：https://arxiv.org/abs/2610.02163 ，https://huggingface.co/papers/2610.02163 。工作狀態保存與何時壓縮同樣重要；這是設計依據，不是本機修復證據。
11. **2026-10-01 arXiv Beyond Memory**：https://arxiv.org/abs/2610.01415 。研究對反覆沒有進展的 Agent 狀態監控；據此採**既有 Git Checkpoint** 而非自建大型 Memory System。

**歷史背景（非 10/01 後）**：OpenCodex #2723（8/27，已記錄 Previous-model Compaction 被前模型配額阻擋）https://github.com/lidge-jun/opencodex/issues/2723 ；OpenCodex #1090（8/6，`ocx start/sync` 修改正式 Codex config）https://github.com/lidge-jun/opencodex/issues/1090 。僅作背景及防回歸，用於制定隔離和備份規則。若最新上游文件／版本已有差異，在工件標記擷取時間、版本與來源，不自行套用過期建議。

---

## 4. 必須先遵守的自我防循環協定（本任務最高優先）

這次由 `deepseek-v4.1-flash` 擔任 Hermes Maker，**不得在調查其他人的循環時自己又陷入循環**。

### 4.1 每次回合只能做新的工作

- 第一輪建立小型 `investigation_checkpoint.json`，記錄：Phase、唯一 `next_action`、已讀來源的 `path+size+mtime+sha256`、現有 HEAD／dirty、工具呼叫計數、已取得的測試證據、目前 `first_fail`。**每一 Phase 僅建立一次基線；後續只追加新證據，不重寫大段 Handoff。**
- 同檔同雜湊**禁止第二次全文讀取**；只讀目標行段或從 manifest 的已讀索引引用。相同命令若輸出無變化，禁止連續執行第三次。
- 每一工具呼叫前明確回答：「此呼叫要分辨哪一個未解假說／產生哪一個新驗收證據？」若不能回答，略過並推進下一步或停止。
- **兩次連續 Compaction 但無新證據／沒有進展**：立即輸出 `HOLD_COMPACTION_LOOP` 並停止當前 Session。單 Session 每小時超過 **10 次** Compaction 也停止；這是本案保守管理閾值，不是官方 Codex 限制。
- 連續 12 次工具呼叫仍沒有新的證據、判定或 WriteSet 收據：停止 `HOLD_NO_PROGRESS`。單一試驗組最多 20 個模型請求；任何超出須停止並提出可量化理由，**不可自行不斷擴大**。
- 各 Phase 的掃描上限：Phase A 最多 35 次非模型工具呼叫、Phase B 最多 45 次、Phase C 最多 65 次；若耗盡，列出已得到的結果，**停止而非無界續讀**。
- 任一單檔工具輸出預設上限 256 KiB；原始 Repo 傾印**禁止**。單一原始證據複製上限 5 MiB（較大的原始 rollout 可只讀／抽取摘要與 Hash，不複製整包）。這是**讀入上下文及額外重製檔**限制，不是禁止給既有檔案算 SHA。
- 不在聊天全文貼出 Prompt、所有 AGENTS.md、整個 config、整個 rollout 或 OAuth／Go Key。工件僅存結構化摘要、相對路徑與 Hash；絕對路徑僅限必要本機交接文件。

### 4.2 明確停止點

任一發生立即停下、保留原正式 Router：`UNKNOWN_CREDENTIAL_DESTINATION`、`UNEXPECTED_EXTERNAL_LISTENER`、`PRODUCTION_CONFIG_DRIFT`、`SOURCE_INTEGRITY_FAIL`、`COMPACTION_LOOP`、`NEW_PROVIDER_REQUEST_TO_OPENAI_FROM_GO`、`UNAPPROVED_AUTH_MUTATION`、`TOOL_CALL_SEMANTIC_REGRESSION`、`INDEPENDENT_CHECK_UNAVAILABLE_FOR_DEPLOY`。

禁止使用「再重讀完整 r5 一次」或「重新研究整份四 Repo 專案」作為恢復策略。停止時產生 1 頁明確 `first_fail + evidence + next_safe_action` 即可，不要耗 Token 再寫長計畫。

---

## 5. Gate A｜唯讀、可再現的現況與原始事故取證

### A1. 環境與基線

1. 確認實際登入使用者、`CODEX_HOME`、正式 `config.toml`、`model_catalog_json`、精確 App/Engine 版本。記錄 SHA-256 與設定中**必要但非秘密** root key；不可自動修復 drift。
2. 唯讀記錄 router PID、確切執行路徑、Package 版本、lockfile、`router.ts` SHA、監聽位址與排程實際 Action；確認 **port 10102 僅由已核准 Router 使用**。
3. 唯讀檢查已存在的 `switch_route_official.cmd`、Go 一鍵腳本、備份、`06_rollback_runbook.md`，但**禁止先執行回滾／重啟正式程序**。
4. 抽查目前 `GET /router/health` 及 `GET /v1/models`（如果是只讀且不需傳送 Token）；確認 10 個 Picker 可見邏輯不被變更；不要先重做所有 GUI 測試。
5. 優先定位原始 T0→T1 切換前後的 rollout JSONL（UTC 事件／本地檔名）。先讀索引和時間窗口，**不是整包 Dump**。以 10/27 03:05–03:15 首次壓縮為主窗口，再抽 1 組典型重複的中期回合。可核對現有 Hermes 取證但不依賴其抽取程式碼無誤。

### A2. 第一次壓縮的判別表（最重要）

對首次 1–3 次 Compaction 記：

| 欄位 | 需查證的值 |
|---|---|
| before／after model | `turn_context` 標籤，標注其不是服務端簽章 |
| previous model state | `previous_turn_settings.model`、如可觀察的 `comp_hash`、downshift |
| event type | `PreTurn`／`MidTurn`／`manual`／unknown |
| request API | `/v1/responses`／`/v1/responses/compact`／`compaction_trigger`／unknown |
| upstream route | 官方／Go／unknown（需 request ID、Router log 或 network receipts 支持） |
| response outcome | HTTP 類型、SSE terminal、是否有有效摘要、錯誤／重試 |
| effective context before/after | 觀察到的實值，未觀察到填 `null` |
| next turn action | 新 Patch、新 Test、又重讀同檔，具體證據 |
| session linkage | 去識別化 Hash／Stable Session，不能外洩 conversation ID 原文 |

**不要以曾顯示「上下文已自動精簡」推定 Remote `/compact` 已成功**，也不要以 200 推定語意正確；要檢查下一回合是否真的能繼續並保留工具回覆與工作狀態。

### A3. Catalog／Adapter 現成能力比對

- 讀舊 Go Provider 與目前 Router Catalog 的 DeepSeek、MiMo entry：精確 ID、`context_window`、`model_auto_compact_token_limit`、`model_auto_compact_token_limit_scope`、`comp_hash` 或等效能力、supports reasoning、tool calling、visibility；標記哪些欄位是 Codex 真正在**當前 Engine**解析的，哪些只是文檔欄位。**不得發明缺失值。**
- 靜態審查 `router.ts` 與其 `import` 指向的函式：
  1. Go `chat/completions` ↔ Codex `responses` 的映射；
  2. Compaction v1 與 v2 是否**有實際路由支援**；
  3. 非預期輸入錯誤時 fail-closed 還是 silent fallback；
  4. Responses SSE `response.completed`、reasoning、tool events；
  5. `x-opencode-session` 如何從同 Thread 生成且不串線；
  6. 官方 OAuth 是否真正 pass-through、Go Key 是否只在 Go request 加入；
  7. 是否有限制 retry 及處理 quota、408/429/5xx/EOF。
- 必須記錄精確結論，例如 `CURRENT_ROUTER_HAS_COMPACTION_V1=YES/NO/UNKNOWN`、`V2=...`、`ACTUAL_HANDLER_PATH=...`；**不得從 router.ts 行數推斷功能缺失**。

**Gate A 退出條件**：完成基線、前三次異常窗口、Router Import/Handler 事證與模型目錄對照；無法取得 request 級證據時標註 `ROOT_CAUSE_UNCONFIRMED`，但仍可進行小成本隔離 A/B，無須無界挖原始日誌。

---

## 6. Gate B｜現成開源輪子選型及安全隔離

### B1. 候選分級（不得平行部署全部）

- `Candidate 0`：**不換 Router**，保持官方/Go 選單＋跨家族新 Thread＋精確 Git Checkpoint。這是最低 OI 的立即安全模式。
- `Candidate 1`：**完整 OpenCodex** 官方發行版（首選探索 `@bitkyc08/opencodex@2.92.0`，若兼容證據顯示 2.90/2.91 更穩，允許在隔離環境選固定版本）；**一對一替換**現有 Router 的候選，不得串接。確認 `compactionRouting`、`compactionRecovery`、`codexClientCompaction` 的差異與各自所需信任邊界。**一次只測一項可解決假說的變數**，起始皆保持預設關閉。
- `Candidate 2`：LiteLLM／CLIProxyAPI／其他開源 Router 僅在 Candidate 1 存在明確阻斷、而 Candidate 2 又可證明處理該阻斷時，列為紙面備選；**不啟動第四個服務**。`LiteLLM` 一般 Responses↔Chat bridge 本身不等於特殊 Compaction v2 完全相容。

**最低充分評分 OI（內部決策指標、非業界公認分數）**：新增常駐服務、額外 Provider Auth 邊界、正式 Config 變更、自製協定程式碼、回滾步驟，各項 0–1 分；全案 OI 目標 `≤2`。優先 `維持現況＋明確新 Thread`，除非 POC 證明存在可避免的真缺陷，才批准 OI 2 的一對一替換。

### B2. 供應鏈與隔離

1. 對候選 OpenCodex 的 Tag、commit、npm 包名與 dist integrity、License、Windows/Bun 支援、相關 Release Notes、已知副作用作短表；必要時比對 git source 與 npm pack，**不得使用未固定的 `latest` 作實驗依賴**。
2. 只在新的 `%TEMP%\codex-router-compaction-poc-<case_id>` 或受控私有實驗根目錄建立 `CODEX_HOME` 與 candidate Config。固定工作路徑和權限，避免 symlink/junction 導向正式 `%USERPROFILE%\.codex`。
3. 候選另占 `127.0.0.1:10104`（若已占用，選一個未使用的 loopback 高位 Port 並紀錄）；正式 `10102` 不動、不重啟、不旁路其安全規則。
4. 先唯讀閱讀候選的 CLI startup option／injector 範圍；若 `ocx start/sync/init` 無法保證只作用於隔離 `CODEX_HOME`，**改用受支援的獨立服務啟動方式**；若兩者都不可安全隔離，標記 `HOLD_CANDIDATE_SIDE_EFFECT`，不強行試。
5. 隔離 Go 認證只允許透過本機現有受保護 runtime 方法取得最少權限的 Key；**不複製金鑰檔到 POC、不可寫入 config、不可 dump 環境變數**。初期用無憑證 Mock Adapter/Fixture 驗證協定。
6. 隔離的 OpenAI 官方 OAuth 測試必須先用無真 Token 的假 upstream/401 分流測試；不得在 POC 複製 `auth.json`。**只有在準備受控正式 GUI pilot、且已通過供應鏈／路由信任／回滾 Gate 時，才允許使用現有登入狀態驗證真 OAuth。**
7. 本案不採用憑證池輪替、共享帳戶、簽名中介、加密會話轉寫外送、遠端 SaaS 中轉等多餘能力；關閉不需要的 Gateway Dashboard／Analytics，僅 Loopback 機械測試。

---

## 7. Gate C｜有界 A/B/C 測試（真實成功條件，避免再燒 Tokens）

### C1. 對照組與控制變因

| 組別 | 路徑 | 目的 |
|---|---|---|
| A：Direct-Go | 隔離 Codex Profile → 舊 `opencode_go`（已驗證合法的端點／wire_api） | 判斷原本直連 Go 的壓縮與工具行為 |
| B：Current-Thin-Router | 隔離 Codex Profile → 既有 `127.0.0.1:10102` → Go | 對照現有薄 Router，勿打斷正式服務 |
| C：Full-OpenCodex | 隔離 Codex Profile → 隔離 `127.0.0.1:10104` → Go | 確認現成完整適配器改善何種真缺陷 |
| D：Official GPT | 獨立新 GPT Thread → 官方模型，不跨家族繼承 | 辨別 Codex Harness 與任務設計的共同問題 |

如果 A/B/C 無法使用**完全同一份合成 fixture** 或有效模型、Catalog、Engine 版本不同，標注不可比較的差異。不得因方便把「舊的短聊天」拿來和「新 r5 幾十萬 Token」比較並判定因果。D 中不對測試 Repo 產生外部副作用；官方請求須按現有登入／安全路由執行。

### C2. 固定測試 fixture（不用用戶實際四 Repo）

建立一個離線合成 Git Repo（README、1 個 Python/JS 函式、1 個明確失敗測試、1 個小輸入、1 份摘要），測試依序：

- `P01` 普通 DeepSeek 單輪與精確 Model ID，Go Key 不串供應商。
- `P02` 真實工具：寫合成檔 → 測試前 RED／修改後 GREEN → 記錄 Git diff／sha；**模型說「完成」不算 PASS**。
- `P03` 兩輪續談，前一工具結果可正確引用；SSE 有 `response.completed` 或與實際協定相應的完整終止事件。
- `P04` 可控手動 Compaction，以及下一回合**繼續同一工作**；若 Harness 不支援強制觸發，改驗證 mock／unit fixture，不能宣稱 live PASS。
- `P05` 若支援且安全，利用適當的測試 context threshold 觸發 1–2 次自動 Compaction，確認壓縮後有效 context 下降／任務進度維持。**不能把任意縮小 context 造成的人工錯誤當成本機自然成因；此組只證明協定。**
- `P06` 模型切換：GPT → Go、Go → GPT，使用合成歷史，對照 `comp_hash`/window 值、Previous-model PreTurn compact 的模型。已知跨家族歷史風險，**與 P01–P05 的單家族 pass 分開評級**。
- `P07` Go Session ID：同 Thread 穩定、不同 Thread 不同；檢查傳給 Go 的 `x-opencode-session`、UA、cache key（若有）；不得輸出原始 Conversation ID。
- `P08` 未知 routed slug → 400 fail closed；保留官方 model ID 不可被 Go 路由接管；`400/401/403/429/5xx/EOF` 錯誤需正確分類（未自然出現者 Mock 覆蓋）。
- `P09` Compaction v1 `/responses/compact` 與 v2 `compaction_trigger`：依 Engine 實際支援分別驗證；不支援的路徑標 `NOT_APPLICABLE`，不可填 PASS。
- `P10` 反無限循環：當摘要無法產生、上下文不降、工具重複、前模型拒絕時，停止及明確錯誤，不得 silently retry 多百次。

**成本硬限制（本案專用）：**每組最多 20 個付費模型請求；正式 Go/API 額度消耗依最新供應商政策保守控制；單組最多 2 次受控 Auto Compaction；禁止完整 r5 任務與長 Repo dump。模型呼叫超出限額，`HOLD_BUDGET` 並根據 Mock、靜態與已有實測判定，**不能自行加碼**。

### C3. 有效性判準（不能只看 HTTP 200）

每組建立機器可核對 receipt：`model_id`、`route`、`request_kind`、`http_status`、`terminal_event`、`tool_call↔tool_result`、`git diff`、`test_exit`、`before/after context`（如可觀測）、`compaction_count`、`progress_delta`、`credential_destination_allowlist`。

- 單回合完整回覆、有正確工具事件及 Git 寫集進展才算對應項目 PASS。
- Compaction **結束且下一回合仍能引用正確工作狀態**才算 Compaction PASS；`200` 或 UI「已精簡」不足以證明。
- 同 Thread 跨家族 P06 如果仍是 400 或多次無用 Compaction，判 `FAIL`、保持跨家族新 Thread 規則；**不可因此把已驗收的新 Thread Go 能力改判失敗**。
- 若 A、B、C 都同樣陷入無進展，則優先標 `HARNESS_OR_TASK_DESIGN_UNRESOLVED`，**不能因 C 是新版本就部署**。

### C4. Go／快取與 Compaction 嚴格分離

對 T1 的 45.48M 輸入含快取統計，不依報告的 token 數推算費用。各組若有 `cache.read`／`cached_tokens`，只比較同一 Session 同一 fixture 的 Prefix 穩定性；避免將 `H-UPSTREAM-CACHE` 與 `H-COMPACTION` 混為同一指標。可紀錄 cached ratio，但**不能以它單獨判定工作是否成功**。

---

## 8. Gate C2｜最小 SoD 與證據審核

**Maker（Hermes）**：執行環境唯讀調查、固定版本 POC、Mock/Live 有界測試、提供原始可重現收據、給出建議。Hermes 不得把自己重讀報告一次當 Independent Checker。

**Independent Checker**：須使用與 Maker 不同的測試入口、固定 fixture／雜湊、原始 Router 請求或 Git Diff 的非摘要收據，復驗 `P01–P10`、供應商憑證邊界、官方回歸、回滾。Checker 必須是有效被授權的獨立程序／身份；若當前環境無此能力，輸出 `PENDING_INDEPENDENT_VERIFICATION`，**不自行偽造 PASS**。可先使用機械固定斷言作為 `DETERMINISTIC_SELF_CHECK`，但必須明列不等於組織或原生獨立 Checker。

**Owner/Acceptor**：OWNER 已授權有界變更，但授權並不創造技術證據，也不等於獨立檢查收據。證據 Gate 不成立 → 不進正式切換。

本案是 Windows 個人桌面 Router 整合，不重開 FHS-MSC Native Issuer、Registry、Golden WorkOrder 或產品驗收 Gate；這些在 r5 原有專案狀態依然保持未簽／HOLD。**別把本次 Router 驗收證書混入 FHS-MSC 產品 Native Acceptance。**

---

## 9. Gate D｜保留還是替換：已授權的條件式代位裁決

### D1. 決策矩陣（不得跳過）

| 證據結果 | 裁決 | 允許的下一步 |
|---|---|---|
| B 的新 Thread 長任務正常，C 不明顯更好 | `KEEP_CURRENT_ROUTER` | 不部署、不升級；只加入 Checkpoint 與新 Thread 規則 |
| A 正常、B 異常、C 正常；C 有有效 Compaction＋工具回歸證據 | `CANDIDATE_OPEN_CODEX_REPLACEMENT` | 經安全＋Checker Gate 才導入；否則保留現況 |
| A/B/C 均正常、只有同 Thread GPT→Go 失敗 | `CROSS_FAMILY_THREAD_UNSUPPORTED` | 維持新 Thread；追蹤 Codex upstream，不為此改 Gateway |
| A/B/C 均相似失敗 | `HARNESS_OR_UPSTREAM_UNRESOLVED` | 保留正式 Router；記錄 first fail，別重複移植 |
| C 出現 OAuth 路由改變、泄漏、工具遺失或未知上游 | `REJECT_CANDIDATE_SECURITY_OR_COMPATIBILITY` | 立即停止候選，絕不導入 |
| 證據不齊／Checker 不存在 | `HOLD_INSUFFICIENT_EVIDENCE` | 保留現況，交付精確缺口，停止作業 |

**OI 量化**：保持單 Gateway，新的常駐 daemon 數量=0（若替換，停舊換新，不串接）；正式新增配置只准必要的 `model_provider`、`model_catalog_json`、新增 Provider 的相應最小表格；不改 OpenAI OAuth 的原生儲存與 Windows 全域網路。以 0–5 相對 OI 評分，不能用大量新程式碼換小改進。

### D2. 只有以下全通過才批准正式一對一替換

- `SUPPLY_CHAIN_VERIFIED=PASS`：固定版本、官方來源、完整性與授權；套件若更改，逐項證明必要。
- `ISOLATED_COMPACTION_GO_PASS=PASS`：不只 200，壓縮後能正確繼續工具與狀態。
- `ISOLATED_ROUTING_SECURITY_PASS=PASS`：Loopback only、目的地允許清單、No secret log。
- `OPENAI_OAUTH_ROUTE_PLAN_VERIFIED=PASS`：新的官方 pass-through 與 `requires_openai_auth=true` 有明確測試設計；不碰 `auth.json`。
- `TOOL_PROTOCOL_PARITY=PASS`：SSE、function_call、exec/apply_patch 及測試回合無新增失敗。
- `DESKTOP_CATALOG_PLAN=PASS`：能以版本相容的本機 `model_catalog_json` 顯示 10 項 Picker，隱藏模型保持隱藏，不從 UI 可見推導 routing 成功。
- `ROLLBACK_VERIFIED=PASS`：完整 SHA 備份、原子更新及有效一鍵官方 fallback；受控 piloto 失敗後立即可以恢復。
- `INDEPENDENT_CHECKER_PASS=PASS` 或已有正式有效的獨立驗收收據。**只有 Maker 自測不得部署永久正式版。**

### D3. 如全通過：最小、安全正式 Pilot（不用重做整套施工）

1. 建立本輪專用原子完整備份與當前設定 SHA；CAS 檢查不曾被其他程序修改；所有正式改動有 diff 與回滾收據。
2. 若現有 Router 10102 的服務／排程還健康，**不得雙重監聽 10102**。先以不干擾正式的另一 Loopback Port 驗證新 Gateway；完成風險審核後按核准的維護步驟一次完成進程／Provider 切換，保留原服務可回退設定。**禁止改寫正式 OAuth 記錄。**
3. 正式設定僅做最小必要修改並由 parser 讀回。不得在正式 config 執行自動 injector；若 OpenCodex 只有自動 injector 方案，先在隔離 Home 產生變更再人工對照 CAS 後最小引用。候選系統不能自動恢復或覆蓋 root provider。
4. App 只在**必要的受控 Pilot 切換時**重啟一次，不承諾零重啟部署；部署成功後的使用體驗仍必須符合 **選擇模型不需每次重啟**。
5. GUI 確認 7 官方＋預設＋2 Go，共 10 項；官方真 OAuth→原官方 host 200；Go DS/MiMo 200，真正工具結果；新 Thread 長任務精簡進度不循環；路由錯誤 fail-closed。
6. 任何 `401/403`、官方功能回歸、Go model/slugs 漏項、SSE 假成功、Router 10061、憑證轉往未知主機、Compaction 循環，立刻**回滾**；即使成功也保留舊一鍵切換器及備份。
7. `T12R` 已知跨家族同 Thread 失敗只能在**新合成證據全部通過**後才改判；否則操作規則永遠是**切換 Provider 家族，建立新對話**。

**若無獨立 Checker 或無法在不讀寫 OAuth 憑證的前提下試驗新正式路由，不能藉 OWNER「全權授權」跳過安全 Gate；最終 `KEEP_CURRENT_ROUTER`／`HOLD` 亦是合法完成。**

---

## 10. Gate E｜最小運維對策：即使不換 Router 也須落地

只需完成以下低成本文件，不在正式系統新增背景監控／自動化服務：

1. **跨家族新對話規則**：官方↔Go 的中大型施工任務，一律建立新 Thread。Go→Go 可依原驗收使用，但也須在長任務壓縮風險下保存 checkpoint。禁止把這條禁令誤認為 Picker 功能失敗。
2. **小型機械 Checkpoint**：每次切換模型／切換 Session 前，在既有專案 outputs 製作 1 個不含密鑰的 `MODEL_HANDOFF.json`，建議欄位：`case_id`、`repo`、`git_head`、`branch`、`dirty_path_hashes`、`completed_changes`、`tests_verified`、`tests_not_run`、`ci_unknown`、`first_fail`、`next_action`、`stop_conditions`、`recorded_at`。新 Session 僅讀此 Checkpoint + 需修檔案片段，不重讀整段聊天或整份 r5 指揮書。
3. **循環停止規則**：連續兩次 Compaction 無新證據／施工進展、或 10 次／小時，標示 `HOLD_COMPACTION_LOOP`；不讓自動任務耗盡額度。此為保守運維閾值，可按穩定實測調整。
4. **大型輸出控制**：預設單次交給模型的檔案內容≤256 KiB；大 Repo 改 `rg --files`／`rg -n`／特定行段讀取；不要再建造幾百 MB repo dump，也不能把純檔案大小等同 Token context。
5. **問題與產品驗收分離**：把 `B1_R5_LONG_TASK_COMPACTION_LOOP` 登錄為獨立 Router/Harness 相容性問題；FHS-MSC r5 仍是 `FUNCTIONAL_CANDIDATE_ADVANCED`，PIPD #20 CI 紅、HGK PR／Checker／Native 仍未達成，不得因 Gateway 修補改判 `NATIVE_ACCEPTED`。

---

## 11. 最小交付物（不做 12 份重複報告）

在現有合法使用者的 `GPT_Dual_Routing_Audit` 下建立**新的**例證目錄，如 `Compaction_Regression_20261027_<short_case_id>\`，僅產出必要文件與機器收據：

| 檔名 | 必要內容 |
|---|---|
| `00_case_manifest.json` | `case_id`、時間、OWNER 授權範圍、現況、版本、工作模式、已知未知、SHA |
| `01_baseline_and_source_audit.md` | 正式 Config 必要鍵、Router/Imports、舊新 Catalog 差異、GitHub 來源版本表；秘密遮罩 |
| `02_compaction_first_event.json` | T0→T1 首 1–3 次 Compaction 的逐事件對照、Model/Provider/Request Path、unknown 欄位不得猜 |
| `03_opencodex_adoption_review.md` | 2.11 對比所選固定版本、相關上游修補與信任邊界、OI 評估 |
| `04_ab_protocol_receipts.json` | A/B/C/D P01–P10 真實執行 status、sha、工具配對、SSE、after-compact progress |
| `05_independent_check_and_security.md` | Maker 與獨立檢查分界、實際收據、有無 OAuth／Go Key 洩漏、原廠回歸 |
| `06_decision_and_rollback.md` | `KEEP`／`REPLACE`／`HOLD`／`ROLLBACK`、最小 diff、Gate 判決、first_fail／後續操作 |
| `07_owner_operations_handoff.md` | 跨家族新 Thread、Checkpoint 格式、停止循環、健康檢查、官方回滾快速步驟 |
| `08_sha256_manifest.txt` | 工件 SHA-256（不包含真實金鑰、OAuth、完整會話原文） |

任何 Phase 尚未達成時，只能產出上述已完成部分及 `HOLD` 收據，不要填造空的 PASS。**原始曾上傳的 forensic MD、TSV 及對話檔要保留版本身分，不直接覆寫舊報告。**

### 11.1 最終回報格式（繁體中文，不超過必要長度）

```
CASE_ID:
FINAL_VERDICT: KEEP_CURRENT_ROUTER | REPLACE_WITH_PINNED_OPENCODEX | HOLD_INSUFFICIENT_EVIDENCE | ROLLBACK_COMPLETE
CURRENT_DESKTOP_STATE: HEALTHY | DEGRADED | UNKNOWN
CURRENT_PROVIDER:
CURRENT_ROUTER_VERSION_AND_SHA:
CANDIDATE_VERSION_AND_INTEGRITY:
FIRST_COMPACTION_CAUSE: [evidence or UNCONFIRMED]
HYPOTHESES: H-CROSS-THREAD / H-CATALOG / H-ADAPTER / H-HARNESS / H-UPSTREAM-CACHE 逐項 PASS/FAIL/UNKNOWN
AB_RESULTS: A/B/C/D 逐項已測、未測、差異及禁止比較事項
OPENAI_AUTH_NO_REGRESSION: PASS/FAIL/NOT_TESTED
GO_DEEPSEEK_MIMO_NO_REGRESSION: PASS/FAIL/NOT_TESTED
INDEPENDENT_CHECKER: PASS/PENDING/NOT_AVAILABLE
PRODUCTION_CHANGES: NONE | exact bounded diff
ROLLBACK_RECEIPT: exact proof or NOT_APPLICABLE
KNOWN_LIMITS: T12R and other still-open limitations
EVIDENCE_PATH:
FIRST_FAIL:
NEXT_SAFE_ACTION:
```

報告中的 `REPLACE_WITH_PINNED_OPENCODEX` 只有在 Gate D 正式完成後才能使用；**若只是 POC 證明適合而未正式替換，裁決 `KEEP_CURRENT_ROUTER` 並列 `CANDIDATE_VALIDATED_NOT_DEPLOYED`**。

---

## 12. 成功／失敗與立即開始指令

**本輪最小成功**不是讓全部舊對話跨家族完全相容，而是：

- 找到前次壓縮循環最小可信證據及現有 Router 的真實 Compaction 能力；
- 完成一次有限成本、可比較的現成方案 A/B（不足時誠實 HOLD）；
- 選擇「保留」或符合安全／Checker 閘門的「一對一替換」，並保障已正常的官方／Go Picker 不回歸；
- 讓今後的 DeepSeek 長任務有新 Thread／Checkpoint 與循環 Stop-Rule，不再無界重讀和重試；
- 不虛構 Native Acceptance、Provider 證據或修復成果。

**現在開始 Gate A，按 A→B→C→D→E 的順序一次推進。禁止把本指令重新全文讀取超過一次；任何人為或系統性的 Compaction 重啟都必須由 Checkpoint 接續、遵守前述停止閘門。若新證據不足，即時交付已取得的鑑定與 `HOLD`，不可用大量空泛敘述充當工程成果。**
