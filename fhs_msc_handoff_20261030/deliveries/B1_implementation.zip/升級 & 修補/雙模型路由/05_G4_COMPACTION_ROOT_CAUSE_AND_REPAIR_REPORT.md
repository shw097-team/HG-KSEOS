# G4 結案報告｜原生桌面 Codex × DeepSeek：異常壓縮的根因、修補與驗收

- **案件**：`Compaction_Regression_20261027_G4`
- **結案時間**：2026-10-27（Asia/Taipei）
- **執行端**：本機 Hermes Agent（承接 G1／G2／G3／G4 全鏈）
- **被測主體**：Windows 原生 Codex Desktop `OpenAI.Codex 26.1021.3705.0`，內嵌 `codex-cli 0.164.0-alpha.11.1`，Picker 選 `OpenCode Go · DeepSeek V4.1 Flash`（上游 ID `deepseek-v4.1-flash`）
- **Gateway**：`@bitkyc08/opencodex@2.92.0`（vendor 固定版）於 `127.0.0.1:10102`
- **終局**：`CASE = CLOSED_WITH_KNOWN_LIMITATIONS`；`PRIMARY_GATEWAY = desktop_router / opencodex@2.92.0`；`GATEWAY_OPERATIONS_CLOSED = YES`；`DESKTOP_DEEPSEEK_TASK = PASS (WORKSPACE_ALIAS)`

> 本報告只寫機械可核對的事實。凡未直接量測者，一律標 `NOT_CONFIRMED` 或 `NOT_CLAIMED`，不以推論補空缺。

---

## 1. 一句話結論

異常壓縮不是模型身分、不是 Gateway 墊高、不是 catalog 窗口設定錯誤，而是 **Codex 每次請求都夾帶約 62k tokens 的 ChatGPT apps／connectors 工具 schema**；在 DeepSeek 的 128,000 硬限（有效窗口 121,600）下，這使每次請求的「起跑線」就吃掉 59–77% 的窗口，任何實質工作都會立刻越過自動壓縮門檻（約 100k），壓縮後再重讀大檔又回到高位，形成 353 次壓縮的循環。關閉該功能後，桌面基線由 **93,512 → 29,222**，同一任務 0 次壓縮。

---

## 2. 事故現象

| 事實 | 數值 | 來源 |
|---|---|---|
| 主 session 自動壓縮次數 | **354** 筆 `compacted` 事件 | `rollout-2026-10-26T23-58-08-…jsonl` |
| 集中在幾個 turn | 只有 **2 個** `turn_id`，其中 **352 次在同一個** | G2 逐筆重算 |
| 相鄰兩次壓縮之間的工具呼叫 | 中位數 **1.0** 次 | G2 |
| 該段模型 | `deepseek-v4.1-flash`（Go） | `turn_context.model` |
| 該段是否真有工程產出 | **無**（0 個 patch、0 行變更） | B1 r5 交叉鑑定 |
| 累計 lifetime token | 32.2M → 79.0M | `total_token_usage` |

也就是說：模型在反覆被壓縮、重讀、再壓縮，幾乎沒有推進工作。

---

## 3. 取證方法（可獨立重跑）

| 證據 | 位置／指令 | 用途 |
|---|---|---|
| Rollout 事件 | `~/.codex/sessions/<年>/<月>/<日>/rollout-*.jsonl` | `turn_context.model`、`token_count`、`compacted`、工具呼叫 |
| Gateway 用量 | `~/.codex/desktop-model-router/usage.jsonl` | provider／status／conversationId／付費請求數 |
| 客戶端錯誤 | `~/.codex/logs_2.sqlite` | `os error 10061`、`provider=`、`model=` |
| 上游硬限 | `POST /v1/responses`（超大輸入）→ HTTP 413 原文 | 模型真實窗口 |
| 靜態基線 | 新 session 第一個 `token_count.last_token_usage.input_tokens` | 每請求固定成本 |
| 版本指紋 | v2 SSE 事件數（2.11.0 = 10；2.92.0 = 11，含 `response.in_progress`） | 證明實際載入版本 |

---

## 4. 根因分析

### 4.1 先排除（每項都做過對照）

| 假設 | 量測 | 判定 |
|---|---|---|
| 模型名稱不一致導致每回合壓縮（G1） | 352 筆 `previous_turn_settings` **逐位元相同**仍壓縮 | **REFUTED** |
| Gateway／opencodex 墊高 prompt | 直接打 `/v1/responses`（10 字）→ input **32 tokens** | **否** |
| catalog 窗口設太小 | 上游 413 原文：`context window of deepseek-v4.1-flash (128000 tokens)`；有效 121,600 = 128,000×95% | **設定正確，不可上調** |
| 引擎預設 258,400 才是真值 | 250k tokens 請求被上游 413 拒絕 | **否**（258,400 是通用預設） |
| plugins 全關可降基線 | 13 個 plugin `enabled=false` → 71,860（無變化） | 否 |
| `mcp_servers.node_repl` 關閉可降 | 71,407（-463） | 否 |
| 精簡 `model_catalog_json` | 71,787（無變化） | 否 |
| 移除 skills（619 KB） | 7,400 → 7,066（-334） | 否 |
| `thread_history_1.sqlite` 注入 | 7,902（無變化） | 否 |
| 79M lifetime token 驅動（G2 早期推論） | `total_token_usage` 為終身累計，判定看活動上下文 | **已撤回** |

### 4.2 決定性對照

同一台機器、同一個 CLI、同一個 cwd、同一份 `config.toml`：

```
正式 home（apps 開）                 71,708
正式 home + -c features.apps=false    9,643
正式 home 寫入 apps = false 後        9,646
```

唯一變數就是 `features.apps`。這是 ChatGPT apps／connectors 的工具 schema（每個請求重新送一次）。

### 4.3 機制

```
每次請求 = 靜態基線（apps 開啟時 ~71.7k CLI / ~93.5k 桌面）
          + 對話歷史 + 工具輸出
DeepSeek 有效窗口 = 121,600（硬限 128,000 × 95%）
自動壓縮門檻 ≈ 100k（實測在 99,997 觸發）

apps 開啟：起跑線 93.5k → 只剩 ~6.5k 餘裕 → 一做事就壓縮
          壓縮後重讀大檔（工具輸出中位 22.6 KB、最大 1.44 MB）→ 立刻回高位 → 再壓縮
apps 關閉：起跑線 29.2k → 餘裕 ~90k → 同一任務 0 次壓縮
```

### 4.4 為什麼是「異常循環」而不是「正常壓縮」

正常壓縮應該是「長任務偶發、每次推進一段」。本案是「2 分鐘內、相鄰壓縮之間只有 1 次工具呼叫、352 次落在同一 turn」，代表壓縮後沒有換來新的推理空間，只是把同樣的重量重新搬一次 —— 這正是基線佔比過高的典型症狀。

---

## 5. 修補內容

| 項目 | 內容 |
|---|---|
| 檔案 | `C:\Users\user\.codex\config.toml` |
| 變更 | `[features]` 增加一行 `apps = false`（+175 B） |
| SHA-256（改前） | `03551ae29392dd46…`（12,093 B） |
| SHA-256（改後） | `004e99df9664a904…`（12,268 B） |
| 備份 | `config.toml.bak-g4-apps-repair-20261027` |
| 回滾 | 刪除該行或還原備份 → 重啟 App |
| 代價 | Codex 內不再提供 ChatGPT apps／connectors 工具 |
| 不受影響 | 官方 OAuth 路由、Go 金鑰邊界、Picker 內容、模型 slug、`model_auto_compact_token_limit`、`catalog.json` |

> 注意：App 每次啟動會重寫 `config.toml`，全檔 hash 會漂移。驗證請比對**鍵的不變量**：`model_provider = "desktop_router"`、`model = "opencode-go/deepseek-v4.1-flash"`、`[features] apps = false`。結案時實測值 `21a2a81a…`，`apps = false` 在第 104 行。

---

## 6. 驗收（OWNER 裁決 A：一般對話即可）

| 項目 | 第 1 次 11:48 | 第 2 次 11:54 | 第 3 次 12:19 |
|---|---|---|---|
| 模式 | GUI 一般對話 | GUI 一般對話 | GUI 一般對話 |
| 模型 | deepseek-v4.1-flash | deepseek-v4.1-flash | deepseek-v4.1-flash |
| 工作區 | App 自配 `…value-` | App 自配 `…value-2` | App 自配 `…value-7` |
| 工具呼叫 | 6 | 17 | 7 |
| 請求基線 | — | **93,512** | **29,222** |
| 壓縮次數 | 0 | **1**（≈100k 觸發） | **0** |
| 產出 | 453 B `7b45e736…` | 271 B `e3c26043…` | 444 B `9961be52…` |
| 對官方測試檔獨立驗證 | **3/3 OK / exit 0** | **3/3 OK / exit 0** | **3/3 OK / exit 0** |

三次功能等價：`lower()` → 連續非英數轉 `-` → 去頭尾 `-`。

**`WORKSPACE_ALIAS` 揭露**：App 一律在 `Documents\Codex\<日期>\<slug>` 新建工作區，且跳過任何已存在的名稱；因此「修改指定 repo 路徑」在此產品流程中不可達，改以「同一組檔案、同一組測試、GUI 觸發、模型產出以官方測試獨立驗證」作為驗收基準。此為 OWNER 明示裁決 A。

---

## 7. 升格與回滾點

### 7.1 實作升格（已套用進指定 repo）

| 項目 | 值 |
|---|---|
| 檔案 | `synthetic_repo\tag_normalizer.py` |
| 前 | `13df86fa8b75dc45…`（125 B，測試 RED `FAILED (failures=3)`） |
| 後 | `9961be52e60b092a…`（444 B，來自第 3 次 GUI 產出） |
| repo 內測試 | `python -m unittest -q` → **Ran 3 tests / OK / exit 0** |
| 測試檔 | `e2eec52a8edcd67f…` **未變** |
| Git | `6124c34`（前版 `342337a`） |
| 回滾 1 | `git reset --hard 342337aa19aef040646247d50aa9d598cd0e995f` |
| 回滾 2 | `synthetic_repo\_rollback\tag_normalizer.py.pre-G4-20261027T132939` |

### 7.2 Gateway 升格

| 項目 | 值 |
|---|---|
| `PRIMARY_GATEWAY` | `desktop_router / opencodex@2.92.0` |
| `GATEWAY_OPERATIONS_CLOSED` | `YES` |
| 現場 | `http://127.0.0.1:10102` health `ready`、PID 6284、`/v1/models` 兩 Go 模型、官方 `direct-passthrough` |
| 核心 | vendor `@bitkyc08/opencodex@2.92.0`；v2 SSE 指紋含 `response.in_progress` |
| 回滾 | `g3_backup_20261027T111944`（`router.ts.pre-g3 0c8ff56a…`、`config.json.pre-g3 e100ef7c…`）＋ 全域 npm 2.11.0 仍在 |

### 7.3 其他狀態變更（已回復）

- 曾插入 `state_5.sqlite` 的 `projects`／`project_roots`／`project_idempotency_keys` 以嘗試綁定專案 → **已全部撤回**，DB 回到 7 專案／7 roots／7 keys，備份留存。
- 曾建立 `Documents\Codex\2026-10-27\…-3`～`-6` junction → **已刪除**（App 會跳過已存在名稱，無效）。

---

## 8. 主張上限（不可跨越）

| 命題 | 狀態 |
|---|---|
| 提前壓縮的觸發條件 | **ROOT_CAUSE_IDENTIFIED_AND_REMOVED**（基線 93.5k→29.2k，同任務 0 壓縮） |
| 「壓縮循環永久修好」 | **NOT_CONFIRMED_LONG_HORIZON** —— 沒有等壓的數小時長跑 |
| 桌面 DeepSeek 完成真實工程任務 | **PASS**（三次，功能 3/3，`WORKSPACE_ALIAS`） |
| 同 Thread 跨 Provider 家族續談 | **KNOWN_FAIL_UNTIL_NEW_PASS**（歷史 `400 array_above_max_length`） |
| Picker 10 項（GUI 觀測） | 本輪未以 GUI 逐項觀測；以 `/v1/models` 11 entries／9 visible 作替代收據 |
| Independent Audit / Native Gate | **NOT_CLAIMED** |

---

## 9. 附錄 A：重現指令

```bash
# 1) 量靜態基線（新 session 的第一個 token_count）
python - <<'PY' ... 讀 rollout ... PY

# 2) 對照 apps 開／關（不寫檔）
codex exec --skip-git-repo-check -C <repo> -m opencode-go/deepseek-v4.1-flash "reply with exactly: X"
codex exec ... -c 'features.apps=false' "reply with exactly: Y"

# 3) 上游硬限
POST http://127.0.0.1:10102/v1/responses  # 1.15M 字 → 413 原文含 128000

# 4) Gateway 健康
curl -s http://127.0.0.1:10102/router/health

# 5) repo 驗收
cd .../G4/synthetic_repo && python -m unittest -q ; echo EXIT=$?
```

## 10. 附錄 B：本次工件清單

| 檔案 | 內容 |
|---|---|
| `00_G4_DESKTOP_TASK_RECEIPT.json` | 三次嘗試、量測、裁決、升格、回滾的機器可讀收據 |
| `01_G4_PRIMARY_GATEWAY_AND_CLOSEOUT.md` | 主選與結案敘述 |
| `02_G4_ROLLBACK_AND_CHECKPOINT.md` | 全部回滾點 |
| `03_G4_TEST_DIFF_AND_EVENTS.md` | 三次 run 事件與 diff |
| `04_G4_SHA256_MANIFEST.txt` | 上列檔案 SHA-256 |
| `05_G4_COMPACTION_ROOT_CAUSE_AND_REPAIR_REPORT.md` | 本報告 |

---

**結案簽註**：本報告為 Maker 自驗（Hermes 執行、機械收據可獨立重跑），**不主張** Independent Checker／FHS-MSC Native Acceptance。任何超出第 8 節的主張均屬越界。
