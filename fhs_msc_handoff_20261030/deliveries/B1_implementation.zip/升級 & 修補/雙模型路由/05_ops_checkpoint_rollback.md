# 05 運維、檢查點與一步回滾

## 1. 健康檢查（唯讀）

```powershell
curl.exe -s http://127.0.0.1:10102/router/health
Get-NetTCPConnection -LocalPort 10102 -State Listen | Select-Object LocalAddress,OwningProcess
Get-ScheduledTask -TaskName 'Codex Desktop OpenAI and DeepSeek Router' | Select-Object State
Get-ChildItem 'C:\Users\user\.codex\desktop-model-router\vendor\opencodex-2.92.0\package.json' | ForEach-Object { (Get-Content $_ | ConvertFrom-Json).version }
```

預期：`ready:true`、`127.0.0.1:10102`、`Running`、`2.92.0`。

## 2. 一步回滾（回 2.11.0）

```powershell
$bk='C:\Users\user\.codex\desktop-model-router\g3_backup_20261027T111944'
Copy-Item "$bk\router.ts.pre-g3"    'C:\Users\user\.codex\desktop-model-router\router.ts'    -Force
Copy-Item "$bk\config.json.pre-g3"  'C:\Users\user\.codex\desktop-model-router\config.json'  -Force
$p=(Get-NetTCPConnection -LocalPort 10102 -State Listen).OwningProcess; Stop-Process -Id $p -Force
Start-Sleep 3; Start-ScheduledTask -TaskName 'Codex Desktop OpenAI and DeepSeek Router'
```

回滾後驗證：`/router/health` ready；`/v1/models` 11 entries；v2 SSE **不含** `response.in_progress`（2.11.0 指紋）。
vendor 目錄可保留（不載入即無作用）或整目錄刪除。

## 3. `MODEL_HANDOFF.json` 範例

```json
{
  "case_id": "…", "repo": "C:/path", "git_head": "…", "branch": "…",
  "dirty_path_hashes": {"src/…": "sha256:…"},
  "tests_verified": ["Ran 27 tests OK"],
  "tests_not_run": ["…"], "ci_unknown": ["…"],
  "first_fail": "…", "next_action": "…",
  "context_budget_note": "本 Thread 已用 Xk tokens；effective window 121,600（Go）",
  "recorded_at": "2026-10-27 11:23:40 +0800"
}
```

## 4. 循環停止規則（依本輪量化結果調整）

| 規則 | 閾值 |
|---|---|
| 同 turn 連續 2 次壓縮無新證據 | 停 turn、落 Checkpoint、開新 Thread |
| 單輪 `last_token_usage.total_tokens` | 維持 < 80,000（Go 有效窗口 121,600 的 ~66%） |
| 單筆工具輸出 | ≤ 256 KiB（T1 曾出現單筆 1.4 MB） |
| 每小時壓縮次數 | > 10 即 HOLD |
| 跨供應商家族 | 一律新 Thread |

## 5. 版本固定

- 核心：`vendor\opencodex-2.92.0`（勿原地 `npm update`）
- wrapper：`3ecb99ed8c519e3f3ab2a0e8ab0bef557d3476ee20f76eec6ff49b7d291b1dc5`
- `config.json`：`57752556f4c7f2292aba34f580bca9149f1f61e7812a904c92fef7d6058463c8`（含 `claudeCode.enabled=false`，避免 10204/10205 與本地 CA）
- 排程／`bun.exe`：未變
