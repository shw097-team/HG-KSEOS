# HERMES AGENT｜Codex × OpenAI × OpenCode Go — Compaction G2 歸因核證、最小修補裁決與受控候選升格總指揮令

**版本**：`2026-10-27 / COMPACTION-G2 / OWNER-LIMITED-AUTHORITY / zh-TW`  
**執行者**：本機 Hermes Agent；主要執行模型 `OpenCode Go · DeepSeek V4.1 Flash`（上游模型 ID：`deepseek-v4.1-flash`）  
**案件承接**：`Compaction_Regression_20261027_G1`；雙路由施工 r2；B1 r5 GPT→DeepSeek→GPT 跨模型長任務事故。  
**執行定位**：工程 Maker／調查及隔離驗證，不得自稱 Independent Checker 或 Native Acceptor。  
**OWNER 裁決**：准予本指令列出的唯讀鑑定、低耗用隔離試驗、可驗證的最小候選修補與獨立驗收交接；**不必就這些範圍反覆請示**。正式系統的修改僅在本文全部部署閘門成立時條件式授權；否則 KEEP 並結案 G2。

> **你首先要做的決定，不是「如何立刻修改」。而是驗證 G1 宣稱的模型 ID 不一致是否真會觸發 Codex 每回合的 PreTurn Compaction。現有事件反而顯示第 3、4 次壓縮的 before/after 模型一致；這是必須反證的證據矛盾。不能在未排除它之前改正式 catalog 或 Router。**

---

## 0. 任務摘要與不可偏離的成功標準

在**不損壞已經正常提供 10 項 Picker 選項的 Windows Codex 正式桌面配置**的前提下：

1. 重新核實 G1 的 `SERVED_MODEL_IDENTITY_MISMATCH` 假說：區分 `requested model ID`、Gateway `response.model`、`turn_context.model`、`previous_turn_settings.model`、`comp_hash`、`compaction reason` 及 `window_number`。**證明因果，而不是只有時間共現**。
2. 重新核實 G1 已得出的反證：本機 `router.ts` 是薄外殼、真正運行 `@bitkyc08/opencodex@2.11.0`，Compaction v1/v2 已通過基本協定測試；不能回到「Router 沒有 Compaction」的舊假說。
3. 在隔離 `CODEX_HOME`、合成 Repo、獨立 loopback Port 做最少、可比較的差異測試。先驗證模型身分及 Compaction 原因；只在相關假說成立時分別測 **M1**（身份對齊）與 **M2**（閾值／scope），而不是同時改兩者。候選 **M3**（2.92.0）維持「已審源碼、未實跑、未部署」，除非有新可治缺陷才升級隔離研究。
4. 以 **M0 KEEP_CURRENT_ROUTER** 作為預設終局。只有合成復現的失敗被**單一**候選明確改善，且獨立驗證、官方 OAuth、Go 路由、Picker、憑證邊界、回滾都通過，才可升格一個最小候選。沒有 Checker 或可靠真 OAuth 驗收就不得改正式配置。
5. 最後出具一次精確報告；如果不能證明「每回合壓縮」的可修原因，明確說 `ROOT_CAUSE_UNPROVEN`，保留新 Thread + `MODEL_HANDOFF.json`。不為了交報告而作多餘施工。

**兩個相互獨立的成功標準**：
- `G2_CAUSAL_VERDICT`：證據是否足以確定可治的觸發條件？
- `G2_OPERATIONAL_VERDICT`：是否保留或改變已成功的正式雙路由？

本輪不對 FHS-MSC B1 r5 的產品程式碼、PR、Native Admission、Independent Acceptance、Live Gate 動手。

---

## 1. OWNER 即刻生效的代位裁決

### 1.1 已准許（直接執行，不再詢問）

- 唯讀檢查正式 `config.toml`、`catalog.json`、`router.ts`、所匯入 `@bitkyc08/opencodex` 的實際版本與來源、鎖檔、排程、服務健康、Gateway 日誌及相關 `rollout` JSONL。必要時將敏感識別遮罩並只保存有限證據片段。
- 建立 `Compaction_Regression_20261027_G2/<UTC-或-Taipei-時間戳>/` 隔離證據根；檔名與 Manifest 固定，所有原始 G1 工件唯讀保存、不得原地覆寫。
- 建立**合成** Git Repo、隔離 CLI `CODEX_HOME`、固定引擎、獨立 Port／Fixture；使用本機已授權的 Go Key 經既有安全機制讀入，**不得列印或匯出 Key**。
- 在隔離副本修改一次僅一個假說的 `catalog.json`、隔離 Router wrapper，或使用 Codex 官方支援的臨時 `-c` 覆寫進行 M2 測試；均先備份並記錄 SHA-256。
- 源碼核對 Codex 既有 `previous_turn_settings`／`comp_hash`／`ModelDownshift` 的真實判定，並與該 Windows Desktop 實際安裝引擎版次比較；不得把 GitHub `main` 的行為直接當成本機二進位的行為。
- 若隔離測試確有可復現差異，製作**一個**可逆、最小的候選 Patch 與自動化測試，交付獨立檢查入口。
- 以本文條件對合格候選進行有限正式部署：**必須先有真正獨立 Checker PASS、官方 OAuth 與 Go 安全回歸、可立即回滾收據，且所有 Gate 通過**。未達者只做候選，不碰正式。

### 1.2 嚴格禁止

- 不得在正式 `CODEX_HOME` 運行 `ocx start/sync/init/link`；不得升級目前正式 `@bitkyc08/opencodex@2.11.0`，也不得新增串接中的第二 Gateway。
- 不得修改 Codex App MSIX、EXE、DLL、Codex Engine 檔案、全域 TLS／Proxy／防火牆、Windows 身分管理、`auth.json`、Key 檔案本體或系統憑證。
- 不得直接對正式 `catalog.json` 去 `opencode-go/` namespace；不明白 route 白名單的情況下，這樣可能把 Go 模型請求送到官方 `chatgpt.com`，連同錯誤的 OAuth Header 造成嚴重安全與功能回歸。
- 不得直接將 `model_auto_compact_token_limit = 96000` 寫進 Catalog 的模型 entry，除非已核對**本機有效 JSON schema 與 parser**確實支援；Codex 官方參考首先將其列為 config 層設定，不能假設逐模型 entry 可用。
- 不得篡改 `rollout` JSONL、Compaction Snapshot、SQLite 或 `previous_turn_settings` 來取得假陽性；不得把伺服器回的 `response.model` 改名當成已證明能改變 Codex 的 Compaction 決策。
- 不得讀取／輸出 OAuth Token、Go API Key、Authorization、Cookie、Prompt 全文或敏感檔案；日誌用 HMAC／前綴 SHA、碼化 request IDs，而不是原始秘密。
- 不得把 Legacy 成功的短回合 A/B 當成 353 次壓縮循環已修復；不准在使用者真實四 Repo 上重跑事故以「驗證」。
- 不得使用 `--dangerously-bypass-approvals-and-sandbox` 於正式產品樹。若隔離合成 Repo 的沙箱不可寫，優先以外部明確允許的安全可寫目錄或唯讀協定 Stub 測試；任何隔離 bypass 必須證明工作目錄、權限、連線與輸入皆只落合成環境，並清楚標示特殊風險。當無法建立安全隔離時停止測試。
- 不得將 Maker 撰寫的測試交給同一 Maker 重跑後稱為 Independent Checker。若沒有可用獨立檢查者／既有獨立檢查工具，標記 `PENDING_INDEPENDENT_VERIFICATION`，**不得用 OWNER 的全面授權替代不存在的技術證據**。

---

## 2. G1 新證據：先接受事實，後反證機制

### 2.1 G1 現況與重要數字

以下是 Hermes 的 G1 報告，**請以本機原始位元再次核對，不得把本 Prompt 當成 G2 現況**：

- 正式 Codex：前輪 Windows Desktop `OpenAI.Codex 26.1021.3705.0`、Engine `codex-cli 0.164.0-alpha.11.1`；現況以系統讀回為準。
- 正式 root：`desktop_router` → `127.0.0.1:10102`；`requires_openai_auth=true`、`supports_websockets=false`；已驗收 Picker 10 項（7 官方＋預設＋DeepSeek＋MiMo）。
- `router.ts` **約 4,115 B 的外殼**，實際 `import startServer from '@bitkyc08/opencodex/src/server/index.ts'`；上游本體 `@bitkyc08/opencodex@2.11.0`。過去曾錯以為它只是 73 行獨立 Proxy，現以 G1 新證據為準。
- G1 合成 A（舊 Go 直連）與 B（當前 Router）均完成真實 1 行修改＋ `pytest 1 passed`，代表**短任務基本功能**一致，**不是壓縮循環對照實驗**。
- G1 協定探測顯示 v1 `/v1/responses/compact` 200；v2 `compaction_trigger` 產生指定 SSE 事件並 `response.completed`；50 KB 可縮至 0.53，證明功能存在，未證明跨模型 PreTurn 狀態完全正確。
- G1 2.92.0 已做來源及 npm SHA512 審查，**沒有啟動候選 C，也沒有正式安裝**。不得以其新模組存在就宣稱解決模型身分問題。
- G1 354 筆 `compacted`：T0 GPT 1、T1 DeepSeek 353；新窗口 window 1→354；`input_tokens` 中位 24,220；替代歷史中位 65,600 B、retained 約 20,456 B。T2 GPT 0 compaction。
- 請求宣告 `opencode-go/deepseek-v4.1-flash`，部分回應宣告 `deepseek-v4.1-flash`。此為**模型識別差異事實**，而非已證明 Codex 一定使用回應 `model` 欄位更新 `previous_turn_settings`。
- G1 `config.toml` 該次前後雜湊一致（`a2e1b3ae...`），但與 r2 結案快照 `ad570aed...` 有漂移，增加了 root `model = "gpt-6.1-sol"`；不得擅自回寫「修正」或認定它必然造成問題。

### 2.2 G1 宣稱根因存在邏輯缺口——必須作為本輪首要攻關

附件 `02_compaction_first_event.json` **不是全部 354 筆原始紀錄**，只是取出 6 個代表事件及 aggregate；必須從本機原始 rollout 重新審核 354 筆才有逐事件完整證明。尤其：

- `seq=2 / 03:08:54`：`before_model = gpt-6.1-sol` → `after_model = opencode-go/deepseek-v4.1-flash`；切換當回合 PreTurn Compaction。符合 `CompHashChanged`／`ModelDownshift` 可能性。
- `seq=3 / 03:09:31`：**before = after = `opencode-go/deepseek-v4.1-flash`**；卻仍發生 PreTurn Compaction。
- `seq=4 / 03:10:11`：**before = after = `opencode-go/deepseek-v4.1-flash`**；再次 PreTurn Compaction。
- G1 推測模型回應去除 namespace 造成每回合 `previous model ≠ current model`；但是目前 JSON 內 `before_model`／`after_model` 的可見值相同，且 `request_api` 均 UNKNOWN。**不能把「model response 不同」與「Codex 真實 PreTurn 比較不同」混為一談**。
- `window_number` 每次變動只證明每回合有 Compaction，不等同 `comp_hash` 或某個 ID 比較失敗的原因；窗口未達 128K 亦不等同能排除 `body_after_prefix`、不同模型的實際壓縮閾值、PreTurn 模型切換、PostTurn/Async Compact 等其他原因。

**G2 因果檢查的目標**：找出程式路徑上的具體 Trigger Reason、比較的兩個模型設定／`comp_hash`、選定的 Provider、前一回合快照的實際來源，以及是否成功採用壓縮結果。沒有這些，不准宣告 M1 必然修復。

---

## 3. 2026-10-01 後外部技術交叉資料與檢證方法

不要只看 README，核對版本固定 Commit 與原始碼。

1. **Codex Issue #54423**（2026-10-15）`Custom provider: failed previous-model compaction pins the thread`：https://github.com/openai/codex/issues/54423 。它說明 `maybe_run_previous_model_inline_compact` 會在 `CompHashChanged` 或 `ModelDownshift` 時引用 `previous_turn_settings.model`；該 Issue 的現象是**前模型壓縮失敗且 fallback 不成立**，不是本案每回合摘要成功的同一錯誤。
2. **Codex Issue #54226**（Oct 2026）`Remote compaction stuck on retired GPT-5.5`：https://github.com/openai/codex/issues/54226 。展示 `previous_turn_settings` 持久化／恢復與繼續模型不同的風險；它的人工改 JSONL 方法不可採用於正式系統。
3. **Codex source**（比較現有安裝引擎版次，不可只看 main）：https://github.com/openai/codex/blob/main/codex-rs/core/src/session/turn.rs 、https://github.com/openai/codex/blob/main/codex-rs/core/src/session/mod.rs 、https://github.com/openai/codex/blob/main/codex-rs/core/src/session/context_window.rs 。Codex 的模型來源與 Session settings 必須從內部狀態而非只看上游 `response.model`。
4. **Codex Config Reference（現行）**：https://learn.chatgpt.com/docs/config-file/config-reference ，其中 `model_auto_compact_token_limit`、`model_auto_compact_token_limit_scope` 是配置層設定；務必證明本地 Engine 是否支援逐 Catalog Entry 設值，不能假設。
5. **OpenCodex Releases**（2.90.0 10/21、2.92.0 10/24）：https://github.com/lidge-jun/opencodex/releases 。2.90.0 含 #7388 opaque Responses replay、#7394 Go／DeepSeek／MiMo；2.92.0 含 SSE 與 Hermes session 關聯。這些不是對本次 G1 first_fail 的確切修補證明。
6. **OpenCodex Codex Integration**：https://github.com/lidge-jun/opencodex/blob/main/docs-site/src/content/docs/guides/codex-integration.md 。`codexClientCompaction`、`compactionRouting`、`compactionRecovery` 分別是不同開關，切換可能變更 Codex Provider 形式、跨上游發送摘要及影響歷史可攜性。此回合不盲目打開。
7. **OpenCode Go 官方模型端點**：https://docs.opencode.ai/docs/go/ 。目前 DeepSeek／MiMo 的上游 Chat Completions 路徑為 `opencode.ai/zen/go/v1/chat/completions`。維持 `x-opencode-session`、User-Agent 與 Key 目的地界線，不靠靜態文件取代實測。
8. **OpenCodex Issue #2723**（**2026-08-27，時間較早，只作技術背景**）：https://github.com/lidge-jun/opencodex/issues/2723 ，同 Thread GPT→DeepSeek 前模型 Compaction 被 quota 阻斷，修復需追蹤 Session Lane；不是對本案例 353 次的直接證據。

在調查表記錄 `SOURCE_DATE`、`REPO_COMMIT`、`APPLIES_TO_INSTALLED_BUILD=YES/NO/UNKNOWN`、可重現行為及版本差異；不得把搜尋命中、來源摘錄當成已實測。

---

## 4. Gate A — 僅唯讀歸因核證（最高優先）

### A0｜小型健康／漂移快照

- 只讀 `C:\Users\user\.codex\config.toml` 的**必要且去秘密化**欄位：root `model`、`model_provider`、`model_catalog_json`、Provider `base_url`、`wire_api`、`requires_openai_auth`、`supports_websockets`、`model_auto_compact_token_limit`、scope；保留完整原始檔的**雜湊／大小**而不複製秘密內容。
- 只讀現有 `catalog.json` 的 10 個 Picker 選項／11 個 Catalog 模型映射、DeepSeek／MiMo 模型精確 ID、上下文欄位、能力欄位、原廠保留模型 ID；SHA-256、schema parser 認證。
- 只讀 `router.ts` SHA-256、imports、`goModels`、官方／Go 的分流規則；檢查是否對任何未知模型 fail closed；不允許 Go namespace 被簡化後錯送官方。
- 只讀 Router 健康、PID、loopback 綁定、排程、package lock SHA；與 G1 `router.ts` hash `0c8ff56a73dc125d...`、程序 PID 19852、當前 config `a2e1b3ae...` 差異記錄。若漂移非預期，`HOLD_CONFIG_DRIFT`，不進行實作測試。
- G1 報告稱 10/26 結案 SHA `ad570aed...` 其後漂移至 `a2e1b3ae...`，差異可能是使用者所選預設模型；**只記錄，不自作主張回復**。

### A1｜原始 354 次 Compaction 重新抽取（有限資訊，禁止全文傾印）

來源候選：`C:\Users\user\.codex\sessions\2026\10\26\rollout-2026-10-26T23-58-08-01a178ee-...jsonl`。實際路徑以存在性與原檔 UUID 確認。

- 僅迭代原始 JSONL 一次，產生 354 筆**結構化小型 CSV／JSON**（禁止保存聊天全文、Prompt／Tool stdout）；若實測數不符則記差異。
- 每筆至少：`seq`、`timestamp`、`window_number`、`turn_id`（雜湊）、`turn_context.model`、`previous_turn_settings.model`（如有）、`compaction_event.reason`／`phase`（存在才填）、`input_tokens`、`replacement_history_bytes`、`retained_context_bytes`、`response.model`（存在才填）、`last_token_usage`、`provider route`（僅有可靠來源才填）、`source_line_offset` 或 byte-offset。
- **不可**把 `before_model=after_model` 硬轉成不一致，不可用回應 `model` 欄位推測 Codex 的 previous model；缺資料即 `UNKNOWN`。
- 驗證 `window_number` 是否真的一回合一次（需要 `turn_id` 可用或 `turn_context` 發生序列；若無 turn IDs，只能說一事件一新 window，不能證明一回合一事件）。
- 記錄從 T0→T1 切換首回合 seq2、T1 第 2、3 個回合 seq3/seq4，以及 T2 第一回合的 `previous_turn_settings`；集中判讀是不是 `CompHashChanged`、`ModelDownshift`、token 閾值、PostTurn、Async Compact 或其他。
- 確認是否實際能觀測 Prompt／summary 成功被採用；`response.completed` 或 `compacted` 出現不能單獨證明狀態收斂。
- 假如沒有請求級日誌，明確標示 `UPSTREAM_MODEL_ATTRIBUTION_NOT_PROVEN`。**不得將 Compaction 與 Prompt Cache Miss 混為一談。**

### A2｜執行引擎版本對照（不重新編譯產品）

1. 取得本機 Codex Engine 可執行版次／build SHA 或 installer package version；核對當時事故是否同 build。
2. 抽取對應 tag／版本（或最接近可確認的 source）與 `main` 的以下概念實際程式路徑：`maybe_run_previous_model_inline_compact`、`CompHashChanged`、`ModelDownshift`、`previous_turn_settings` 設定／恢復、`comp_hash` 的計算輸入、`run_pre_sampling_compact`、`response.model` 是否參與上一回合身份判定。
3. 明確寫入機械判定：`REQUEST_MODEL_SLUG`、`RESPONSE_MODEL_FIELD`、`PREVIOUS_TURN_SETTINGS_MODEL` **究竟誰寫入誰**。如果 `response.model` 根本不更新 `previous_turn_settings`，則 G1 名稱不一致是共現，不可判為觸發根因。
4. 若本機二進位缺調試可見性，使用隔離的 mock Responses HTTP Stub 搭配一個最小模型測試，僅令 Stub `response.model` 在名稱有／無前綴間改變，並**保持 prompt、選定 slug、context window、`comp_hash`、工具與 Provider 相同**；觀察是否改變 PreTurn 觸發。

**Gate A 判定**：
- `A_CAUSAL_CONFIRMED`：有**機械比較條件**、可復現輸入與輸出差異，且替代假說排除。
- `A_CAUSAL_REFUTED`：例如 `response.model` 不參與 previous settings，比較結果不變；須更正 G1。
- `A_CAUSAL_INCONCLUSIVE`：缺必要日誌／可用測試；**不能進正式變更**。

---

## 5. Gate B — M1／M2 分離的受控差異實驗

### B0｜最小測試設計與共通約束

- 固定相同 Codex CLI Engine、隔離 `CODEX_HOME`、合成 Git Repo（只能是隨機測試字串，絕無 FHS-MSC 工作檔）、相同工具清單與輸出大小、相同請求預算；每組完全獨立的 Session／測試 Port／Catalog hash。
- 可先用本地匿名 Stub 完成模型身份及窗口觸發的**零付費對照**，再使用少量真正 OpenCode Go 請求確認上游相容。不要為了壓縮而重新讀入 80 KB 以上大 Prompt；用 fixture 和符合協定的最小上下文即可。
- 每組測試必須記錄：`pre/post slug`、`response.model`、`comp_hash`、`previous_turn_settings`、Compaction 原因／次數、SSE 完成、工具結果及下回合對前一工具輸出的可辨識回想；缺值標 `UNKNOWN`。
- 成功要求是：可驗證的修補消除相同原因的**不必要**重複壓縮，且正常達閾值時 Compaction 仍可執行、摘要後確實維持上下文／工具安全。
- 只測新 Thread A/B 的短任務為**必要但不足**；要加一個可控且不包含私人內容的「先 GPT 後 DeepSeek」合成歷史轉換試例。不能用真實 353 次 Thread 作測試素材或修改它。

### B1｜M1：模型身份對齊（只在 A 顯示身份真的觸發時測）

選擇**最小可驗證修法**，不是先固定刪 Namespace：

- **M1a（候選）**：在隔離路由 Adapter 回傳合法的 `response.model` 欄位／事件時保留 Codex 選定的公開 slug，且內部轉送 `opencode.ai` 仍使用精確上游 `deepseek-v4.1-flash`。前提是必須證明 Codex 用此欄位決定 Compaction 前模型；否則淘汰。
- **M1b（候選）**：Catalog slug 若改為無前綴 `deepseek-v4.1-flash`／`mimo-v2.6-flash`，**同步**變更 Router 的精確 Go allowlist、拒絕規則、模型命名衝突檢查、session mapping、Picker label、官方 reserved slug；不得只改 Catalog 而不改 Router。**不能有任何 Go Model 路由到官方上游、不能讓官方 OAuth 被發到 Go、不能讓 Go Key 被發到 ChatGPT。**
- 使用**不含憑證的 mock 請求**對所有 11 個 catalog entries／未知 ID 做決策表，驗證 upstream destination、期望 Credential Class、Provider Route、deny 行為；任何 Unknown 必須 fail closed 而非預設送官方。
- M1a 或 M1b 最多各測一個，先以最小風險且能被機械證明有效者為優先；若只能解決 display 而不能抑制不必要的 PreTurn Compaction，**拒絕升格**。

### B2｜M2：Compaction 閾值／scope（不能當 M1 的替代證明）

- 先核對本機 Codex 版本是否把 `model_auto_compact_token_limit` 與 `model_auto_compact_token_limit_scope` 作為 **root config** 或 **ModelInfo/catalog entry** 解析；**不能因名稱看起來相似就把欄位寫進 JSON 模型 entry**。
- 如只支援 root／CLI `-c`，只在隔離 `CODEX_HOME` 透過 `-c model_auto_compact_token_limit=<安全小值>` 和 `-c model_auto_compact_token_limit_scope=body_after_prefix`（依 parser 可用選項）測試**正常閾值行為**；任何 `96000` 都是示例，不是已獲證明的最佳值。高值不能繞過真 context hard cap，也不能解決 CompHashChanged。
- 分別測由 threshold 正常觸發和由模型切換 `CompHashChanged` 觸發；若 M2 只把異常壓縮拖延到後面、仍在相同切換條件下觸發，不能宣稱修復。
- 正式單一 root 若會套用到官方與 Go 兩家模型，且無法逐模型隔離，將 M2 正式配置評為 `REJECT_GLOBAL_SIDE_EFFECT`，避免破壞 GPT 原廠 Context／Compaction。

### B3｜保留正常能力測試（獨立合成）

最少測 6 類，不需重新跑先前全部 22 項矩陣：

1. 目前 B0 合成短回合 DeepSeek／MiMo 基線 PASS；兩輪工具／SSE 結束。
2. `POST /v1/responses/compact` 仍能正確回覆；v2 `compaction_trigger` 若由此 build 支援仍正確終止。
3. 恰當的同模型多輪使用後，不出現每回合非必要 Compaction；保留正常超限時確實會壓縮。
4. 合成 GPT→Go 切換；若上一模型的正常 Compaction 被觸發，需能辨別 `PreTurn` 真原因與正確的 after-state。
5. 模型路由全白名單與 Unknown 400；Go 只往 `opencode.ai`，官方只往 `chatgpt.com`；絕無跨憑證目的地。
6. 原樣展示 Parser 能讀取的新 Catalog（含 Picker 可見模型），不要求在正式桌面 App 反覆切換作 POC。

### B4｜預算及停止閘門

- 單個假說實驗不得超過 12 次付費請求；整個 G2 的 OpenCode Go 新付費請求預設上限 24 次，超出先停止並提交有界結論，不靠加大用量硬試。
- 連續 2 次 Compaction 且沒有**新可驗證**證據／狀態變更，立刻 `HOLD_COMPACTION_LOOP`，停止該 Session，不能在它裏面重新讀全文指揮令。
- 連續 12 次工具呼叫沒有新增差異證據、1 小時超過 10 次 Compaction、單檔全文讀取超過 256 KiB、同 hash 的指揮令被重讀第 3 次，立刻停止本輪分支。
- 每個階段寫**短 Checkpoint**（≤16 KiB），只包含 Gate、已有證據位置、hash、下一具體動作與停止理由；不要在模型上下文裏複製全部主報告、所有 rollout 或多 Repo Dump。
- 若 DeepSeek 本身再次壓縮循環，保持 G2 產物與主正式環境不變，`HOLD_AGENT_LOOP`；不隱形切模型／不停追查數小時。

---

## 6. Gate C — 候選價值與升格裁決（M0 預設）

### 6.1 允許的裁決類型

`KEEP_CURRENT_ROUTER`：現有 Compaction 功能足夠，未能機械證明 M1/M2 具有真改善；採用新 Thread＋Checkpoint。**這是預設且完全有效的結案。**

`M1_ISOLATED_CANDIDATE`：確定身份／CompHash 比對是觸發根因，M1 隔離修補讓不必要 Compaction 明顯減少，且 Route／安全負向測試 PASS；**若無 Checker，仍不得部署。**

`M2_ISOLATED_CANDIDATE`：只有閾值／scope 方案明確改善本機可復現問題，且沒有全域副作用；依 parser 支援範圍給出最低改動。

`ROOT_CAUSE_UNPROVEN`：有 Compaction Loop 事實，但既有 request/model 比較鏈不夠；不採用 M1/M2、保留 M0。

`BLOCKED_SECURITY_OR_CHECKER`：有候選可治，但官方 OAuth 分流、憑證或獨立驗收無法證實，禁止正式部署。

`PRODUCTION_CHANGE_ACCEPTED`：**唯一一個**可證明最小修補通過所有以下 D Gate 且完成受控部署。

`ROLLED_BACK`：正式變更引起任何阻斷即自動回復至原有效基線。

### 6.2 OI（Minimum-Sufficient Architecture）

- M0：0；不修改已運行系統，結案允許。
- M1：候選 1–2（視需要改變 Route allowlist 與模型目錄範圍；無確證則回到 0）。
- M2：候選 1–3（若只是隔離 `-c` 是 1；若改 root 影響全部官方模型，可能達 3 而拒絕）。
- M3：單一 Gateway 2.92.0 **一對一替換**，不是增加第二 daemon；實際 OI 需按真實工作流、資安信任與服務啟動變更衡量，不得直接照搬 G1 宣稱「一定多一個 daemon」而把它固定評分 4；但未有可修缺陷時仍**不採納**。
- 不發明 Proxy v3、不新增 SQLite Store 或特別記憶服務，不修改 Codex Rust 核心，優先既有 OpenCodex 2.11.0 的現成能力。

### 6.3 Independent Checker 及正式部署 D Gates

以下全部 PASS 才准許正式變更；**OWNER 在此預授權合格的最小變更，不必再重複問批准**，但不得把授權當成 PASS：

| Gate | 必要收據 | 失敗行為 |
|---|---|---|
| D01 CAUSE | 本機對應 Build 的決策路徑＋隔離復現＋單因素反證 | KEEP/HOLD |
| D02 EFFECT | M1 或 M2 相較 baseline 可測且重現的 Compaction 收斂改善 | KEEP/HOLD |
| D03 ROUTE | 全模型 allowlist、Unknown Fail-closed、目的地主機分類 PASS | HOLD |
| D04 SEC | OAuth 僅往官方、Go Key 僅往 Go、loopback／日誌無秘密 | HOLD |
| D05 CORE | DeepSeek、MiMo SSE／tool／多輪正常，官方不回歸 | HOLD |
| D06 AUTH | **真官方 OAuth 經現行 Provider／候選 Route 200**，僅用已授權既有憑證管理，無 token 複製 | HOLD |
| D07 GUI | 正式 Picker 原有 10 選項正常、Slug/Label 正確、重啟前後一致 | ROLLBACK |
| D08 ROLLBACK | 正式 config/catalog/wrapper/hash 備份、原子寫、CAS、可逆腳本 | ROLLBACK |
| D09 CHECKER | 不同執行主體／可信既存外部 Checker 使用原始收據獨立驗證 | HOLD |
| D10 OPS | Router 不增加額外 daemon、Port／排程穩定、窗口故障有明確復原 | ROLLBACK |

**獨立驗證界線**：由 Maker 自己生成的 deterministic script 是好證據，但不是單憑執行便足以稱為 Independent Checker；第二個對話或模型重看結論也不構成獨立驗收。找不到真正不同主體／可信既存 Checker 時，應完成 Maker 候選、給出可重跑測試輸入、期望結果及遮罩報告，終局 `PENDING_INDEPENDENT_VERIFICATION`。不為了硬湊 Checker 新建一套大型驗收平台。

### 6.4 條件式正式小變更（只有 D01–D10 完整 PASS 才可執行）

1. 讀回正式檔案完整 SHA 與 PID／排程狀態；與 Gate A 快照一致方可更新。若使用者於此期間改過選定模型或 config：CAS 失敗則 `HOLD_CONFIG_DRIFT`，不重寫。
2. 修改範圍只能是**一個候選的確定最小檔案集合**；不得把 M1+M2 混合成單次不可歸因的大 Patch。不得修改 `auth.json` 或 Credential Store。若修改 M1b 白名單，所有 Go ID 和 Reserved ID 目的地負向測試先通過。
3. 正式使用前列印**遮罩後** Config Diff、Verified Before SHA、通過的獨立測試證據；只一次受控 App 重啟（需要才做）；留存 AFTER SHA 與回滾包。
4. 以 10 項 Picker、不重啟切換、Go／MiMo 工具及官方真 OAuth 200 實驗驗收，並且運行最小可驗證的安全 Compaction 回歸；若官方 OAuth 401、Unknown 路由錯、10061、App 無法正常啟動或無預期的重複壓縮，**立即用經驗證的正式回滾流程恢復**。
5. 正式回滾腳本：`C:\Projects\Agent_Workspace\GPT_Dual_Routing_Audit\switch_route_official.cmd` 是**退回官方模式**的最後保險；本次若修改 Catalog/Router，還必須準備新的「恢復本次改動前 `desktop_router`」專用 rollback snapshot，避免只回官方而遺失雙路由。
6. 記錄經驗證事實，**絕不宣稱修復了原始 353 次真實 Thread**；僅能聲明合成復現與指定 GUI 測試範圍通過。

---

## 7. Gate E — 立即能用的操作止血與 B1 r5 隔離

不論 G2 是否找到可治修法，先保留並公布以下操作規則，不需正式程式碼修改：

- OpenAI ↔ Go **跨供應商家族**的大型工作一律**新 Thread**，不能把已累積數百萬 Tokens 的原 GPT Thread 直接切到 Go 繼續施工；此為 T12R 已有 400 證據的已知限制。
- 切換前以 `MODEL_HANDOFF.json` 保存 Git HEAD、Branch、Dirty path hash、已過測試、已知阻斷、下一步最小可執行動作，僅由新 Thread 讀 Checkpoint 和必要片段；不全文重餵數 MB r5 命令、Repo Dumps。
- 同一內容 SHA 重複讀取超過 2 次、2 次連續 Compaction 無新實質進度、每小時 >10 次即停止；不得無界長任務。
- FHS-MSC r5 **仍是 CANDIDATE**：PIPD PR #20 CI 曾 failure、HGK 無 Native Acceptance、SIGNED Owner Plan 不存在。不能因這次 Gateway G2 結案而把 FHS-MSC 的 Maker 修補自動升格。
- Go Key 缺失、429 或完整 Windows OS reboot 舊有缺口按運維觸發記錄；不為此案重跑故障注入。

Checkpoint 只做狀態與風險交接，不必另外建置 RAG、向量資料庫或高權限 Agent memory daemon。

---

## 8. 必須交付的工件（只需 7+1 份，不重造 G1 報告）

在 G2 新證據目錄，交付：

1. `00_g2_case_and_source_manifest.json` — G1 精確引用、App／Codex／Router 版本、配置雜湊、當前健康、檔案與來源版本；敏感值不寫入。
2. `01_compaction_event_discrepancy.md` — G1 6 個抽樣事件 vs 原始 354 筆重算、seq3/4 before=after 矛盾、可得的 actual reason、`previous_turn_settings` 與 `comp_hash`。
3. `02_source_mechanism_crosswalk.md` — Codex 本地對應版與 #54423 原始碼、response model 寫回路徑、模型目錄 schema、M1/M2 是否實際可用。
4. `03_isolated_experiment_receipts.json` — 對照分支、合成 Fixture、模型身份與 compact 計數、工具 exit、SSE、路由／安全負向測試、請求與 Token 預算；所有缺失 `NOT_RUN`。
5. `04_minimum_patch_or_keep_decision.md` — M0/M1a/M1b/M2/M3 逐方案採納理由、OI、可測效益、風險、是否具備部署條件。
6. `05_independent_checker_and_security_status.md` — 實際 Checker 身分與受測 artifact hash；無 Checker 則 PENDING，不可偽造。
7. `06_owner_verdict_ops_and_rollback.md` — 最終裁決、是否修改正式、現行雙路由保持狀態、Checkpoint 操作及兩級回滾說明。
8. `07_sha256_manifest.txt` — 前 7 份工件的 SHA-256（不自包含），機械重算校驗，列出真正確認的完整路徑。

所有數字和 PASS 必須附可重建的執行條件、非秘密來源與實際狀態；GitHub／Source issues 是**參照**而非機械成功證據。

### 完成時在對話顯示的終局回報格式

```text
CASE_ID: Compaction_Regression_20261027_G2
FINAL_VERDICT: KEEP_CURRENT_ROUTER | M1_ISOLATED_CANDIDATE | M2_ISOLATED_CANDIDATE | ROOT_CAUSE_UNPROVEN | BLOCKED_SECURITY_OR_CHECKER | PRODUCTION_CHANGE_ACCEPTED | ROLLED_BACK
CAUSAL_VERDICT: CONFIRMED | REFUTED | INCONCLUSIVE
IDENTITY_MISMATCH: observed_request_slug=...; observed_response_model=...; previous_turn_settings_source=...; causal=...
SEQ3_SEQ4_EXPLANATION: ... (no guessing)
COMPACTION_REASON_PROVENANCE: ... (actual instrumentation or UNKNOWN)
CATALOG_THRESHOLD_SCOPE: supported_at=...; parser_evidence=...
BASELINE_ROUTER: @bitkyc08/opencodex@2.11.0 / wrapper SHA=... / health=...
CANDIDATE_2_92_0: SOURCE_AUDITED_NOT_DEPLOYED (unless separately evidenced)
ISOLATED_AB: ...
SECURITY_GO_UPSTREAM: ...
SECURITY_OFFICIAL_OAUTH: NOT_RETESTED | PASS_WITH_EVIDENCE | FAIL
INDEPENDENT_CHECKER: PASS_WITH_ID | PENDING_INDEPENDENT_VERIFICATION
PRODUCTION_CHANGES: NONE | [exact files + before/after SHA]
ROLLBACK: NOT_APPLICABLE | DESKTOP_ROUTER_RESTORED | OFFICIAL_ONLY_RESTORED
COST_AND_STOP_RULES: go_requests=...; compactions=...; repeats=...
FHS_MSC_R5_STATUS: CANDIDATE_ONLY; NOT_NATIVE_ACCEPTED
EVIDENCE_PATH: C:\...\Compaction_Regression_20261027_G2\<timestamp>\
FIRST_FAIL: ...
NEXT_SAFE_ACTION: ...
```

若沒有真正原因，不得重複前輪 `FIRST_FAIL=SERVED_MODEL_IDENTITY_MISMATCH` 的 A 級宣稱；使用 `FIRST_FAIL=UNPROVEN_CAUSAL_LINK` 或最精確可證的第一阻斷。

---

## 9. 执行停止與最終判定條款

- **本指令不是要求無條件修補**；它是要求「以可靠證據裁決修或不修」。如果 B0 事實已說明身份差異不是壓縮原因，停止 M1，直接檢查 CompHashChanged 或其他觸發，完成可證的最小鑑定，不為交差硬造 Patch。
- 如缺少 request-level logging 或目前 Engine 無可用 Instrumentation，不得為了證據去修改正式程式；可以用 Stub／原始 rollouts 與代碼路徑形成有界結論。
- `KEEP_CURRENT_ROUTER` 不是失敗，而是現在最符合已驗證短回合正常、v1/v2 Compaction 功能存在、沒有獨立 Checker 的審慎工程裁決。
- 若檢查後真有最小候選，優先提供隔離 Patch／測試給獨立 Checker；沒有檢查者就不要碰正式設定，使用新 Thread＋Checkpoint 保持營運。
- **不接受無邊界長文、反覆讀技能、空轉宣告或 100+ 次無實際進度的工具呼叫。** 實際完成上述工件、真實機械數據及一次終局判定後即停止。

**本輪 OWNER 裁決生效：立即執行 G2 有界取證與隔離核證；正式雙路由保持原狀。只有具備實證改善及全部獨立 Gate 的最小變更才獲預先授權升格。**
