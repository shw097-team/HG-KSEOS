# 02 來源機制對照（本機 build vs 上游 main）

## 1. 本機安裝引擎

| 項目 | 值 | 可對照性 |
|---|---|---|
| Engine | `codex-cli 0.164.0-alpha.11.1`（`app\resources\codex.exe`） | 二進位，無 debug 符號 |
| Build SHA | 未取得（installer package version `26.1021.3705.0`） | `APPLIES_TO_INSTALLED_BUILD=UNKNOWN` |
| 可觀測物 | rollout 的 `turn_context.comp_hash`、`resume_metadata.previous_turn_settings`、`compacted.latest_token_usage_record` | 皆為引擎自寫 |

## 2. 上游 main 的實際程式路徑（S2）

`codex-rs/core/src/session/context_window.rs`：

```rust
let active_context_tokens = sess.get_total_token_usage().await;
let (auto_compact_scope_tokens, auto_compact_scope_limit, _) =
  match config.model_auto_compact_token_limit_scope {
    AutoCompactTokenLimitScope::Total => (active_context_tokens, model_info.auto_compact_token_limit(), None),
    AutoCompactTokenLimitScope::BodyAfterPrefix => { … active_context_tokens.saturating_sub(baseline) … },
  };
…
let token_limit_reached = buffered_auto_compact_limit
    .is_some_and(|limit| auto_compact_scope_tokens >= limit)
    || full_context_window_limit_reached;
```

`codex-rs/protocol/src/config_types.rs`：

```rust
#[derive(Default)] pub enum AutoCompactTokenLimitScope {
    #[default] Total,        // 預設：以累計 session token 計算
    BodyAfterPrefix,
}
```

`codex-rs/core/src/compact.rs:431`：`compaction_model_hash: turn_context.model_info().comp_hash.clone()` → **comp_hash 只是被寫入壓縮記錄的標籤，不是壓縮閘門的比較輸入**。

## 3. 誰寫入誰（機械判定）

| 欄位 | 寫入者 | 是否參與壓縮判定 |
|---|---|---|
| `response.model`（上游回應） | Gateway（opencodex／官方） | **否**（本機無任何 rollout 欄位顯示回寫） |
| `turn_context.model` | 引擎（使用者選定 slug） | 作為設定來源 |
| `resume_metadata.previous_turn_settings.model/comp_hash` | 引擎 | **僅作標籤**；seq3→seq354 完全相同仍持續壓縮 |
| `active_context_tokens = sess.get_total_token_usage()` | 引擎 | **是（Total scope 的唯一輸入）** |

→ `SERVED_MODEL_IDENTITY_MISMATCH` 與壓縮的關係：**共現，非因果**。

## 4. `model_auto_compact_token_limit` 在哪一層？

- 上游：`config.model_auto_compact_token_limit`（root 設定）與 `model_info.auto_compact_token_limit()`（**ModelInfo／catalog 層**，main 已有此方法）。
- 本機 catalog（38 欄）**不含**該欄位；本機 config **未設** root 值。
- 因此本機是否解析 catalog entry 的該欄位 → `UNKNOWN`（需 2.92.0 之外的 engine 版本證據；本輪不做）。
- 即使可設，因 scope=Total 且累計已 79M，任何合理上限都會持續超標 → 只能延後，不解除。

## 5. Issue 交叉參照（僅背景，非機械證據）

| 來源 | 日期 | 與本案關係 |
|---|---|---|
| #54423 previous-model compaction pins thread | 2026-10-15 | 描述 `CompHashChanged`／`ModelDownshift` 路徑；本案 352 次 prev 完全相同 → **不同觸發** |
| #54226 remote compaction stuck on retired model | 2026-10 | 與 previous_turn_settings 持久化相關；本案未見 |
| #2723 quota 阻斷前模型壓縮 | 2026-08-27 | 背景 |
