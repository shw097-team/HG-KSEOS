# 01 G1 抽樣 vs 原始 354 筆重算

產出：2026-10-27 10:58:44 +0800｜來源 S1（單次迭代，未保存任何 prompt／tool stdout 全文）

## 1. 重算結果（機械）

| 指標 | G1 宣稱 | G2 重算（原始 354 筆） |
|---|---|---|
| 事件數 | 354（1 T0 + 353 T1） | **354**（1 + 353）✔ |
| window_number | 1→354 | **1→354** ✔ |
| 「每回合一次」 | 推論成立 | **不成立**：T1 353 次壓縮只落在 **2 個 turn_id**；其中 **352 次同屬單一 turn_id** |
| before/after model | seq3/4 皆 `opencode-go/deepseek-v4.1-flash` | 相符；且 **352 次的 `previous_turn_settings` 完全逐位元相同** |
| comp_hash | 未取得 | `turn_context.comp_hash` 僅 7 筆有值（**全為 gpt-6.1-sol = `3000`**）；Go 的 353 筆皆 **null** |
| previous_turn_settings 來源 | UNKNOWN | **已取得**：`payload.resume_metadata.previous_turn_settings` |

## 2. seq2 / seq3 / seq4 實際值

| seq | 時間 | window | turn_id(sha12) | turn_context.model | previous_turn_settings | input_tokens | thread_total |
|---|---|---|---|---|---|---|---|
| 2 | 03:08:54 | 2 | `7a46aa6237b2` | gpt-6.1-sol | `{model: gpt-6.1-sol, comp_hash: "3000"}` | 188,418 | 32,247,939 |
| 3 | 03:09:31 | 3 | `8475f574dfb6` | opencode-go/deepseek-v4.1-flash | `{model: opencode-go/…, comp_hash: null}` | 27,423 | 32,383,664 |
| 4 | 03:10:11 | 4 | `8475f574dfb6` | 同上 | **與 seq3 完全相同** | 26,196 | 32,517,338 |
| 353 | 06:12:30 | 353 | 同上 | 同上 | **仍完全相同** | 20,081 | 78,847,732 |
| 354 | 07:59:34 | 354 | 同上 | 同上 | **仍完全相同** | 21,073 | 78,975,503 |

→ seq3 與 seq4 **不是兩個回合**，是**同一 turn 內**的兩次相鄰壓縮。G1 把它們讀成「每回合一次」是取樣 artifact。

## 3. 觸發節奏（新事實）

相鄰壓縮之間的工具呼叫數：**中位數 1.0**（n=352；1 次=186、2 次=5、3 次=44、4 次=95、5 次=13、6 次=6、最大 11）。

即：**幾乎每一次「回應＋工具」之後就壓縮一次**；與回合數無關，與模型身分變更無關。

## 4. 可直接排除的觸發

- **模型／comp_hash 變更**：352 次的 `previous_turn_settings` 完全相同（Go, comp_hash=null）→ 沒有任何一次是「前後不同」。
- **Served model 名稱不一致**：seq3→seq4 model 與 previous 都相同仍壓縮 → G1 的宣稱在證據上被**反證**（詳見 02）。
- **窗口耗盡**：每輪 `input_tokens` 20–35k，遠低於 catalog 128k。
- **PostTurn/Async 壓縮**：`world_state` 與 `event_msg` 無此類事件型別；壓縮以 `compacted` 記錄出現且 window 遞增。

## 5. 尚未可證

- 精確的 request-level 觸發 reason 字串（rollout 未記錄 `reason`／`phase`）→ `COMPACTION_REASON_PROVENANCE = UNKNOWN（無 request-level instrumentation）`。
- `sess.get_total_token_usage()` 在 window 推進後是否重置的實際行為（原始碼可見，執行期未 instrument）→ 列為 residual unknown。
