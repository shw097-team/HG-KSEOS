# B1 R5 跨模型施工來源鑑定（GPT-6.1 Sol → DeepSeek V4.1 Flash → GPT-6.1 Sol）

- 案件：FHS-MSC B1 r5｜跨模型施工進度、工程量跳躍與成果歸因
- 性質：`FORENSIC_INVESTIGATION_ONLY`（未重新施工、未寫入任何產品檔案、未 push／merge）
- 執行者：本機 Hermes Agent；執行時間 2026-10-27 09:11–09:5x（Asia/Taipei）
- 證據等級：A＝直接可驗（原始 rollout 事件／Git Diff／檔案雜湊／測試收據）；B＝多源互證；C＝架構推論；D＝無證據；E＝有反證

---

## 1. 執行摘要與最終鑑定

**核心問題的回答：不存在必須由 DeepSeek 在中間完成的大量實質工程。**

> 從 03:08:54 到 07:59:34（4 小時 51 分）的 DeepSeek 階段，**產品工作樹的檔案變更為 0 行**：0 個 `apply_patch`、0 新增／刪除行、10 個受審產品檔的 mtime 全部落在 03:07 之前或 08:01 之後（A）。DeepSeek 的可歸因產出是 2 個 evidence 目錄（含 587 MB repo 傾印）、1 次 `27 passed` 測試執行，以及對既有候選的大量重複核對。第二次 GPT 回覆是**接續自己切換前已存在的候選**（T0 已有 54 個 patch／+2,910 行），不是依賴 DeepSeek 的新增成果（A：T2 對 `resume-r5-cont-*` 引用 0 次）。

| 階段 | 時間（Taipei） | 模型（lane 標籤） | 工具呼叫 | 檔案 patch | 新增行 | 刪除行 | 模型回應 | 輸入 token | 輸出 token | compaction |
|---|---|---|---|---|---|---|---|---|---|---|
| **T0** | 23:58:09–03:07 | gpt-6.1-sol | 137 | **54** | **+2,910** | −49 | 142 | 31,847,239 | 208,315 | 1 |
| **T1** | 03:08:54–07:59:34 | deepseek-v4.1-flash | 837 | **0** | **0** | **0** | 705 | 45,479,969 | 1,439,980 | **353** |
| **T2** | 08:01:35–08:41:20 | gpt-6.1-sol | 89 | **40** | **+1,126** | −90 | 90 | 17,171,726 | 75,381 | 0 |

> Token 數字取自 rollout 內 937 筆 `token_usage_record`（`usage.input_tokens` 含 cached），非估算。
> T1 用掉 45.5M 輸入／1.44M 輸出 token，換得 **0 行程式碼**。

---

## 2. 調查範圍與來源清單

| 來源 | 內容 | 等級 |
|---|---|---|
| `C:\Users\user\.codex\sessions\2026\10\26\rollout-2026-10-26T23-58-08-01a178ee-….jsonl` | 主 session 原始事件：10,640 行、1,063 工具呼叫、360 `turn_context`（含 `payload.model`）、937 token 記錄、354 `compacted` | A（原始遙測） |
| 同目錄 12 個 session（00:01–09:13） | 10 個為 `codex-auto-review`／guardian 子代理（0 工具呼叫）；1 個 02:53–03:03 為另一 GPT 短 session（38 呼叫） | A |
| `work\r5-hgk-20261026T185545Z` | `HEAD 086a940`、branch `codex/b1-r5-native-admission-20261026t185545z`、`M×4 + ??×6` | A |
| 10 個產品檔 SHA-256／大小／mtime | 見第 5 節 | A |
| `outputs\resume-r5-cont-20261027T043849Z`、`…T211601Z` | DeepSeek 期 evidence（preimage 4,063 B；scope 851 B；搜尋 210 B；repo 傾印 587 MB） | A |
| GitHub REST API | PIPD-LS-SP #20、Fabric #18、SBL #13、HG-KSEOS branch/PRs、check-runs | A |
| 對話 Markdown《從 GPT-6.1 Sol 變更為 DeepSeek V4.1 Flash.md》 | **本機檔案系統未找到此檔**（`Documents\Codex` 全樹搜尋無結果） | D（以 rollout 取代） |

**限制**：`served_model_if_verified` 僅為 `turn_context.model`（lane 標籤），非 Provider 回應簽章；無 Provider Request ID。CLI Codex 未保存逐請求路由決策，故「為何切換」不可證（U1）。

---

## 3. T0／T1／T2 三時點對照

| 維度 | T0（03:07 前） | T1（08:01 前） | T2（現況） |
|---|---|---|---|
| Repo root | 同一 worktree | 同一 worktree | 同一 worktree |
| HEAD／branch | `086a940`／`codex/b1-r5-…185545z` | **相同**（T1 全程 `git status` 快照一致） | **相同** |
| Dirty manifest | `M` lifecycle/schema/spine/test_spine；`??` native_admission.py、test_native_admission.py、native-canonical.js、native-trust-maintenance.ps1、HGK policy | 同上 + `?? test_native_boundaries.py` **不存在** | 同上 + `?? tests/test_native_boundaries.py`（第 10 項） |
| 產品 patch 總量 | +2,910／−49（41 檔，含 work/ 腳本） | **+0／−0** | +1,126／−90（21 檔） |
| 測試狀態 | 03:02:14 `Ran 27 tests FAILED (failures=1)` → 03:04:26 `Ran 27 tests OK` | `pytest -q tests/test_native_admission.py` → `27 passed, 14 subtests` | 9→18 個新邊界測試；多輪 OK（見 §9） |
| Native Gate／Issuer／Registry | 未發行（僅程式與 route 探查） | 未發行 | 未發行（`OWNER_ENABLE_PLAN.UNSIGNED.json` 仍 unsigned） |

**T1 完整快照不可得**：無歷史檔案位元，`HISTORICAL_STATE_NOT_RECOVERABLE`。但「有無變更」可由三條獨立證據確證（patch ledger／mtime／T1 期間 `git status` 重複快照），屬 A 級。

---

## 4. 完整工程時間線（只列狀態改變點）

| 時間 | 模型 | 事件 | 證據 |
|---|---|---|---|
| 02:55:45 | gpt | worktree/branch 建立（`r5-hgk-20261026T185545Z`＝18:55:45Z） | 目錄名 + `git rev-parse` |
| 02:57:13 | gpt | **Add `native_admission.py` +242** | apply_patch |
| 02:57:53 | gpt | schema.sql +12（native admission v1 DDL 註解與表） | mtime + T1 `git diff` 顯示 |
| 02:59:58 | gpt | `native_admission.py` +162；`native-trust-maintenance.ps1` +84 | apply_patch |
| 03:00:03 | gpt | `HGK/HGK_TASK_TOPOLOGY_POLICY.proposed.yaml` 建立（+?） | mtime |
| 03:01:51 | gpt | **Add `test_native_admission.py` +171（27 個測試）** | apply_patch |
| 03:02:14 | gpt | `Ran 27 tests FAILED (failures=1)` | 呼叫輸出 |
| 03:04:06 | gpt | `native-canonical.js` 建立 | mtime |
| 03:04:26 | gpt | `Ran 27 tests OK`（T0 收綠） | 呼叫輸出 |
| 03:04:59 | gpt | `lifecycle.py` admission 掛鉤；`native_admission.py` +14/−4 | apply_patch（同一呼叫三檔） |
| **03:08:54** | **deepseek** | **模型切換（turn_context 由 gpt-6.1-sol → deepseek-v4.1-flash）** | turn_context |
| 03:09–06:11 | deepseek | 837 次工具呼叫，**0 檔案寫入**；47×／29×／26× 同檔重讀；13× `git status --short --branch` | call ledger |
| 04:38:49 | deepseek | 寫 `00_repo_preimage.json`（4,063 B） | mtime + exec |
| 05:16:01 | deepseek | 寫 repo 傾印：SBL 486,803,893 B／PIPD 82,762,001 B／Fabric 16,796,074 B／HGK 1,840,980 B（合計 587 MB） | `ls -l` |
| 06:05:33 | deepseek | `pytest -q tests/test_native_admission.py` → `27 passed, 14 subtests` | 呼叫輸出 |
| 06:10–06:12 | deepseek | **7 份 Handoff 長文 + 7 次「我會…」重啟宣言（2 分 11 秒內）** | assistant messages |
| 07:00–08:00 | deepseek | 幾乎無工具呼叫（全期 837 次中僅 0 次），session 空轉至切回 | call ledger 分桶 |
| **08:01:35** | **gpt** | **模型切回 gpt-6.1-sol** | turn_context |
| 08:03:53 | gpt | **Add `test_native_boundaries.py` +132（首批 9 個邊界測試）** | apply_patch + `Ran 9 tests OK` |
| 08:04:27 | gpt | `native_admission.py` +55/−19（相對路徑不得升級為 cwd） | apply_patch |
| 08:05:34 | gpt | `native_admission.py` +49/−18；boundaries +70 | apply_patch |
| 08:11:50 | gpt | `Ran 41 tests OK` | 呼叫輸出 |
| 08:17:11／08:22:26 | gpt | PIPD commit `bfd0b9684b`／`cddd68228c`（PR #20 建立 08:20:00） | GitHub API |
| 08:21:12 | gpt | `native_admission.py` +42/−2；trust-maintenance 定稿 | apply_patch（mtime 08:21:16） |
| 08:31:06／08:31:13 | gpt | Fabric `142add1378`；SBL `a97b1bf886` | GitHub API |
| 08:35:54／08:36:05 | gpt | boundaries +11（至 18 個）；`lifecycle.py` +4/−4 並推 HG-KSEOS 分支 `33b5b9fac5` | apply_patch + GitHub API |

---

## 5. 逐檔 Diff／SHA／作者階段歸因

| 檔案 | T0 存在 | T1 存在 | T0→T1 | T1→T2 | 現況 SHA-256(16) | bytes | mtime | 歸因 |
|---|---|---|---|---|---|---|---|---|
| `src/hg_kseos/native_admission.py` | 是（02:57 +418 行） | 是（未變） | **無** | +146／−39 | `3699e9cff9e098eb` | 21,050 | 08:21:16 | T0 建立（242+162+14）／T2 三次邊界修補 |
| `src/hg_kseos/spine.py` | 是（HEAD 既有+mod） | 是 | 無 | 有 | `62c75ba4e181d02d` | 32,855 | 08:04:30 | 既有檔；T2 微調 |
| `src/hg_kseos/schema.sql` | 是 | 是 | 無 | 無 | `235c38a903f49ace` | 11,161 | **02:57:53** | **純 T0**（T2 未再動） |
| `src/hg_kseos/lifecycle.py` | 是 | 是 | 無 | +4／−4 | `8e2a9697123911c5` | 38,448 | 08:36:04 | T0 掛鉤 → T2 invariant 傳遞修正 |
| `tests/test_native_admission.py` | 是（03:01 +171） | 是 | 無 | 無 | `0eef8b46e40a9df3` | 13,388 | **03:05:02** | **純 T0**（27 測試） |
| `tests/test_native_boundaries.py` | **否** | **否** | — | 建立 +213 | `efb056cb4bb5853f` | 12,105 | 08:35:59 | **純 T2**（18 測試） |
| `tests/test_spine.py` | 是 | 是 | 無 | 有 | `75f14516024165d2` | 3,951 | 08:12:57 | 既有；T2 修改 |
| `scripts/native-canonical.js` | 是 | 是 | 無 | 無 | `a998c1310dac6841` | 921 | **03:04:06** | **純 T0** |
| `scripts/native-trust-maintenance.ps1` | 是（+84） | 是 | 無 | +104 | `3568f79da076c595` | 18,256 | 08:21:16 | T0 建立 → T2 擴充 |
| `HGK/HGK_TASK_TOPOLOGY_POLICY.proposed.yaml` | 是 | 是 | 無 | 無 | `0d1cd40c6a9c5aa0` | 1,150 | **03:00:03** | **純 T0** |

**無法歸因**：T0／T1 的逐檔位元（已不可重建）；每次 patch 的 pre/post SHA（rollout 未記錄，只能取現況）；`spine.py`／`test_spine.py` 的 T2 具體 hunk 未逐一列出（patch 內容在 `patches/*.patch` 可回溯）。

**行為改變 vs 註解**：T2 的三次 `native_admission.py` 修補均落在函式體（`refuse`／root 驗證／`@` 交易區塊），不是註解；`lifecycle.py +4/−4` 改的是 `admit_workorders` 例外傳播（commit message：「Propagate lifecycle invariant failures instead of reporting admission…」）。`schema.sql` 的 +12 是 DDL 註解＋表定義，屬行為面（新表）。

---

## 6. SharedSpine Admission 工程依賴分析

| # | 節點 | 狀態 | 證據 |
|---|---|---|---|
| 1 | Requirement Freeze vs 真正 Native SourceFreeze | `PROPOSED_ONLY`（未簽發） | `OWNER_ENABLE_PLAN.UNSIGNED.json`；無 Issuer 簽章 |
| 2 | `create_taskspec/create_workorder` 的 Admission 接收端 | **IMPLEMENTED_BEFORE_SWITCH** | `native_admission.py` 02:57–03:04（T0 +418 行）；`lifecycle.py` 03:04:59 掛鉤 |
| 3 | Native Issuer／Verifier／Registry | `PROPOSED_ONLY` + 讀取端已實作 | registry reader pin 測試在 T2（`test_registry_reader_keeps_same_file_pinned`） |
| 4 | Nonce 原子消耗與重播拒收 | **IMPLEMENTED_BEFORE_SWITCH** | T0 patch 已含 nonce 消耗於同一交易（`@` 交易區塊）；T2 補「post-insert policy drift rolls back」 |
| 5 | Lease Generation／CAS | **IMPLEMENTED_BEFORE_SWITCH**（schema + 邏輯） | `schema.sql` 02:57 加 `leases.generation`；T2 只加測試 |
| 6 | SQLite 原子交易與 rollback | **IMPLEMENTED_BEFORE_SWITCH**；T2 補 BaseException 路徑 | T2 `test_baseexception_rolls_back_before_guard_release` |
| 7 | Canonical Event／Outbox 一致性 | **IMPLEMENTED_BEFORE_SWITCH**（T0 `native-canonical.js`） | 03:04:06 |
| 8 | Root 絕對路徑驗證、Path／Junction | **IMPLEMENTED_AFTER_SWITCH** | T2 08:04:27 +55/−19、08:05:34 +49/−18；測試 `test_relative_or_missing_roots_are_not_promoted_to_cwd` |
| 9 | Protected File Handle／TOCTOU | 部分 T0、部分 T2 | T2 `test_exact_bytes_and_replacement_denied_until_release`、`test_pinned_artifact_held_until_commit` |
| 10 | Commit／Rollback／Cleanup／Close 例外安全 | **IMPLEMENTED_AFTER_SWITCH** | T2 `test_guard_cleanup_failure_still_closes_connection`、`lifecycle.py +4/−4` |
| 11 | Lifecycle Controller 的 Admission Bundle 傳遞 | T0 掛鉤、T2 修正 | 03:04:59 patch + 08:35:54 |
| 12 | WorkOrder 建立失敗是否誤報成功 | **IMPLEMENTED_AFTER_SWITCH** | T2 `test_late_requirement_does_not_turn_invariant_failure_into_success`、`test_workorder_failure_restores_draft_and_all_admission_rows` |

**核心鑑定（§6 末段問題）**：第二次 GPT 發現的「相對路徑風險」與「交易清理異常」，是 **T0 Admission／Nonce／Lease 原子修補的自然後續邊界檢查**（A），不是依賴 DeepSeek 新增的程式——因為 DeepSeek 未新增任何程式（§5）。呼叫圖上，T2 的 3 次 `native_admission.py` 修補全部落在 T0 建立的 `refuse()`／交易裝飾器／root 驗證函式；`lifecycle.py` 的例外傳播也只改 T0 掛鉤的同一個 `admit_workorders`。唯一「新」的是測試檔 `test_native_boundaries.py`（T2 自建）。

---

## 7. DeepSeek 有效工作／重複工作分類

| 指標 | T0（gpt） | T1（deepseek） | T2（gpt） |
|---|---|---|---|
| 工具呼叫 | 137 | 837 | 89 |
| 檔案 patch | 54 | **0** | 40 |
| 讀取類（Get-Content/rg…） | 61 | 541 | 19 |
| Git 查詢類 | 0 | **111**（status 113 次字串命中／rev-parse 75／diff 93） | 9 |
| 重複（相同命令雜湊） | 17 | **298** | 3 |
| 長文（>3K 字）助理訊息 | 1 | **352** | 0 |
| 「我會…」重啟宣言 | 5 | **325** | 3 |
| compaction | 1 | **353** | 0 |
| 輸出 token | 208,315 | **1,439,980** | 75,381 |

**PRODUCTIVE_WORK（可歸因 DeepSeek，全部非程式碼）**
1. `outputs\resume-r5-cont-20261027T043849Z\00_repo_preimage.json`（4,063 B，04:38:49）
2. `outputs\resume-r5-cont-20261026T211601Z\`：`00_scope.json` 851 B、`01_search_hits.tsv` 210 B、4 份 repo 傾印（587 MB，05:16–05:17）
3. 一次完整測試執行：`pytest -q tests/test_native_admission.py` → `27 passed, 14 subtests`（06:05:33）
4. 對候選狀態的確認（多次 `git status`／`git diff` 快照，內容與 T0 相同）——**零新資訊**

**REPEATED_OVERHEAD（無新工程事實）**
- 同一份 SBL/FHS-MSC 指令文件被完整重讀 **47×／29×／26×**（03:09–06:11）
- 同一批 skills cache 檔案 24×／22×／15×／14×／14×
- `git status --short --branch` 13×（同一個 HEAD、同一份 dirty 清單）
- 06:10–06:12 內 7 份 Handoff 長文 + 7 次重啟宣言；全期 352 份長文／325 次宣言
- 587 MB repo 傾印（單一 SBL 檔 486 MB）——對判定無貢獻，且必然擠爆 context

**無法歸因**：三類成因無法以遙測分離（無 Provider Request ID／無 context telemetry）。可觀測事實是：`compacted` 事件 353 次 ≈ 每回合一次，且每次 compaction 後模型立即重寫一份 Handoff 並宣告「我會…」，此為 Harness 行為與模型行為耦合的可見迴圈（B）。

---

## 8. GPT 恢復後成果的真正來源

| T2 成果 | 來源 | 是否依賴 DeepSeek 產物 |
|---|---|---|
| 9→18 個邊界測試（`test_native_boundaries.py`） | T2 新建 | **否** |
| 相對路徑／cwd 提升防護 | T2 修改 T0 的 `native_admission.py` | 否 |
| BaseException 回滾、guard 清理關閉連線 | T2 修改 T0 交易裝飾器 | 否 |
| WorkOrder 失敗回滾 draft + admission rows | T2 修改 T0 邏輯 + 新測試 | 否 |
| `lifecycle.py` invariant 例外傳播 | T2（08:35:54） | 否 |
| PIPD #20／Fabric #18／SBL #13／HGK 分支 | T2 08:17–08:36 | 否 |

**T2 對 DeepSeek 產物的引用次數：0**（89 次呼叫中無任何 `resume-r5-cont` 路徑）。T2 開場的「工作樹與既有 HEAD 一致，先前候選仍在」與機械事實相符（HEAD 086a940 未動、dirty 清單一致）。

---

## 9. GitHub Repo／PR／CI 交叉驗證（即時讀回 2026-10-27 09:4x）

| 目標 | 狀態 | 時間（Taipei） | 內容 | CI |
|---|---|---|---|---|
| PIPD-LS-SP **#20** | open / **draft** / unmerged | PR 建立 08:20:00；commits 08:17:11、08:22:26 | +200/−0，3 檔（`oracle_compat.py` 新 +68、`pipeline.py` +18、`test_oracle_compat.py` +114） | **`verify` = failure**；`offline-gate` success ×2；mergeable_state=`unstable` |
| Fabric **#18** | open / draft | 建立 08:33:05；commit 08:31:06 | +93/−5，2 檔 | **0 個 check-run**（未配置 CI） |
| SBL **#13** | open / draft | 建立 08:33:19；commit 08:31:13 | +64/−3，2 檔 | `test (ubuntu-latest, py3.11)` ✅、`test (windows-latest, py3.11)` ✅ |
| HG-KSEOS 分支 `codex/b1-r5-native-admission-20261027` | 已推、**無 PR** | commit 08:36:05 | `lifecycle.py +4/−4`、`test_native_boundaries.py +11` | check-runs 403（token 權限）＝**UNKNOWN** |
| HG-KSEOS PR #1 | closed, draft（**非 r5**） | 10-09 20:28 | `r4-candidate` | — |

**歸因結論**：所有遠端元件首次出現時間都在 **08:17–08:36（T2）**，`03:07–08:01` 期間沒有 commit／PR／push（A）。但「commit 時間」不等於「首次撰寫時間」——本地 T0 已有 `native_admission.py` 418 行與 27 個測試，因此 PIPD／Fabric／SBL 的 T2 內容屬「新檔」，而 HGK 的 T2 內容是「在 T0 候選上補邊界」。

**測試集合重疊（不得相加）**：實測序列為 9 → 23 → 41 → 14 → 55 → 47 → 647（全套）→ 13 → 5 → 58 等，皆為**重複覆蓋的套件執行**，`test_native_boundaries.py` 最終僅 18 個方法、`test_native_admission.py` 27 個。使用者所述「9／41／14／23」對應 08:04:34（首批 9）、08:11:50（41）、08:13:11（14）、08:11:27／08:14:27（23），**不可加為獨立新增測試數**（A）。

---

## 10. 無法確認的事項與證據限制

| ID | 事項 | 限制 |
|---|---|---|
| U1 | 模型切換的觸發原因（配額／手動／路由） | rollout 無 provider 路由決策事件；`config.toml` 現況為 `desktop_router`，但 03:07 當時的選擇理由無紀錄 |
| U2 | 41／14／23 各套件的 Case ID 聯集 | 需在隔離副本 `--collect-only` 才能逐 ID 對齊；本次不做（避免 `__pycache__` 污染產品樹） |
| U3 | HG-KSEOS r5 分支 CI | API check-runs 403（token 無 checks 讀取權） |
| U4 | T0／T1 逐檔精確 SHA | `HISTORICAL_STATE_NOT_RECOVERABLE`：無歷史快照 |
| U5 | 對話 MD《從 GPT-6.1 Sol 變更為 DeepSeek V4.1 Flash.md》 | 本機找不到此檔；已用原始 rollout 取代（更強來源） |
| U6 | 587 MB 傾印是否真的進入模型 context | 無 context 內容遙測；僅能說「檔案存在且極大」 |

---

## 11. 工程品質、模型效率與 Harness 風險

- **工程品質（T0/T2 皆為 gpt）**：測試先行、RED→GREEN 有據（03:02 red → 03:04 green；08:03 red → 08:04 green），邊界檢查具體（路徑提升、TOCTOU、BaseException、guard 清理），無「自證成功」痕跡。T2 的 `lifecycle.py` 修正直接對應「失敗卻回報 admission 成功」的嚴重語意缺陷。品質屬良好，但仍屬 **Maker 自測**。
- **模型效率（T1）**：45.5M in／1.44M out 換 0 行程式；298 次重複命令、352 份長文、353 次 compaction。以「工程狀態變化」計，T1 的邊際產出為 3 個非程式碼檔案 + 1 次測試執行。
- **Harness 風險**：`compacted` 幾乎每回合觸發（353/353），且每次重注入 Handoff → 模型重寫計畫 → 再 compaction，形成自我維持迴圈。這是「重複」最可能的放大器，且與模型無關的部分（context 管理、任務範圍）佔比不小。
- **任務設計風險**：r5 單一 session 同時要求四 repo、GitHub、Native 路由、測試與證據封包，且無「完成即停」的檢查點，導致無界重規劃。

---

## 12. 可執行的後續改進規劃

1. **切換前置閘門**：任何模型切換前，先落地 `checkpoint.json`（HEAD、dirty 清單、已完成 patch 數、綠燈測試名），切回後**只讀 checkpoint**，不重讀全文（預計可省 90% 重複讀取）。
2. **禁止 handoff 重寫**：以「固定 handoff 檔 + append diff」取代每回合重生成（352 份 → 1 份）。
3. **compaction 上限與告警**：單 session 每小時 compaction > 10 次即中止並要求切片（本次 353 次/4.9h）。
4. **禁止巨量傾印**：repo 傾印上限 5 MB／檔（本次 486 MB 單檔），改以 `rg` 命中摘要 + 檔案清單。
5. **任務切片**：r5 拆為 (a) HG-KSEOS admission、(b) PIPD oracle、(c) Fabric consumer、(d) SBL todo，各自獨立 session 與驗收，避免無界重規劃。
6. **切換即證據**：每次模型切換自動寫 `MODEL_HANDOFF.json`（本鑑定的 ledger 格式可直接沿用）。
7. **CI 前置**：PIPD #20 的 `verify` 目前 failure，維持 draft；未取得 Hosted CI 綠燈前不得升格為交付候選。

---

## 13. 最終裁決（逐題、無模糊語言）

1. **兩段 GPT 回覆是否自然連續？** → **是（A）**。同一 worktree、同一 HEAD `086a940`、dirty 清單一致；T2 第一個 patch（08:03:53）直接在 T0 的 `native_admission.py` 上補邊界並新建測試檔。
2. **03:07–08:01 是否完成大量不可忽略的新增程式修補？** → **否（A）**。0 patch、0 行、產品檔 mtime 無一落在該區間。
3. **DeepSeek 真正可歸因的工程增量？** → **3 個非程式碼 evidence 檔 + 587 MB 傾印 + 1 次 27 passed 測試（A）**；程式碼增量為 **0**。
4. **首次 GPT 是否低估切換前已存在的實作候選？** → **是（A）**。03:07 的敘述以未來式描述「修補會把 nonce／lease／實體／事件放進同一交易」，但該實作在 02:57–03:04 已落地 +418／+171 行且 03:04:26 已全綠。
5. **GPT 恢復後的成功是否依賴 DeepSeek 的特定中間產物？** → **否（A）**。T2 對 `resume-r5-cont` 引用 0 次；所有 T2 patch 落在 T0 檔案或 T2 新檔。
6. **是否存在明顯重複與浪費？** → **是（A）**。見 §7 表格：298 次重複命令、352 份長文、325 次重啟宣言、353 次 compaction、1.44M 輸出 token 換 0 行程式。
7. **主因是模型、Harness 或任務設計？** → **三者皆有，主因判定為 Harness＋任務設計（B）**：每回合 compaction 觸發 handoff 重寫（Harness），加上 r5 無界範圍（任務設計）使模型無收斂點；模型層面（DeepSeek）在「不寫檔、只重複驗證」的模式上放大了浪費，但無證據顯示其拒絕執行或幻覺成功（C）。
8. **現有 r5 修補可否直接保留續用？** → **可保留為 CANDIDATE，不可宣告完成（A/B）**。本地 4 modified + 6 untracked 完整、T2 測試多輪綠燈；但 PIPD #20 `verify` failure、Fabric 無 CI、HGK 分支無 PR、CI 未讀（403），且 **無 Native Acceptance／Independent Checker**。

### claim ceiling
- 可宣稱：`FUNCTIONAL_CANDIDATE_ADVANCED`、`NO_HIDDEN_ENGINEERING_VOLUME`、`DEEPSEEK_CODE_CONTRIBUTION_ZERO`。
- 不可宣稱：`NATIVE_ACCEPTED`、`INDEPENDENTLY_VERIFIED`、`ALL_CI_GREEN`、`COMPLETE_B1_R5`，或把 lane 標籤當成 Provider 實際服務證明。

---

## 附錄：本次產出的證據檔（同目錄）

| 檔案 | 用途 |
|---|---|
| `B1_R5_MODEL_HANDOFF_EVIDENCE_LEDGER.json` | 1,078 筆事件（15 KEY + 1,063 工具呼叫），欄位依規格，無資料者為 `null` |
| `B1_R5_T0_T1_T2_FILE_DELTA.tsv` | 10 個受審檔案三時點狀態、SHA、變更類別、歸因限制 |
| `B1_R5_INVESTIGATION_CHECKPOINT.json` | 已排除假說、未解 Unknown、證據上限、停止理由 |
| `call_ledger.tsv` / `edit_ledger.json` / `patches/*.patch` | 原始抽取（1,063 呼叫、94 個檔案層級編輯、55 份 patch 原文） |
| `sessions_summary.json` / `assistant_messages.json` | 13 個 session 清單、753 則助理訊息 |

**本次未執行**：任何產品檔寫入、任何 push／merge、任何測試重跑、任何 Native 簽發／Registry 啟用、任何憑證讀取。
