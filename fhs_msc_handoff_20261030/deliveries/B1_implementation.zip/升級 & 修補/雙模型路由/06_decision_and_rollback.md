# 06 裁決與回滾

## 1. 裁決

```text
FINAL_VERDICT = KEEP_CURRENT_ROUTER
外加標記      = CANDIDATE_SOURCE_AUDITED_NOT_POC / NOT_DEPLOYED
```

理由（依 Gate D1 決策矩陣）：A（直連 Go）與 B（現行 Router）在合成 fixture 上**行為一致**且都成功（1 行 diff、pytest green、SSE 完成）；現行 compaction v1/v2 **功能存在**（v1 在 50 KB 可縮至 0.53）；未發現「非換版不可」的真缺陷；且 Independent Checker 不存在 → 依 D2 不得替換。

## 2. 真正的 first_fail（本輪新證據）

`SERVED_MODEL_IDENTITY_MISMATCH` → 每回合一個 compaction window。

- 事實（A）：354 個 window，`window_number` 1→354，一回合一個；壓縮時 `input_tokens` 中位數 **24,220**（遠低於 128k 窗口）；GPT 階段（T2）0 次。
- 事實（A）：`model=opencode-go/deepseek-v4.1-flash` 的請求，回應 `model` = `deepseek-v4.1-flash`。
- 機制（B）：Codex 以「上一回合 model ≠ 當前 model」判定需 PreTurn 壓縮（#54423 同族機制）；名稱每回合不一致 → 每回合壓縮。
- 分類：`B1_R5_LONG_TASK_COMPACTION_LOOP`（Router/Harness 相容性問題），**與 FHS-MSC 產品驗收無關**。

## 3. 回滾收據

`NOT_APPLICABLE`（本輪零正式變更）。既有回滾路徑保持可用：
- `C:\Projects\Agent_Workspace\GPT_Dual_Routing_Audit\switch_route_official.cmd`（關 App → 備份 → 移除 root provider/catalog → 驗證 → 重啟）
- 私密備份：`...\NativePicker_POC\20261026-174517-OWNER-APPROVED\backup\config.toml.pre-desktop-router`（11,417 B）

## 4. 未採用但已備妥的最小修法（待 OWNER 決定，未執行）

| 方案 | 變更面 | 預期效果 | OI |
|---|---|---|---|
| M1 對齊 model id（catalog slug 去 namespace + `goModels` 白名單同步） | catalog.json + router.ts 4 KB 外殼 | 消除每回合 previous-model 判定差異 | 1 |
| M2 為 Go entries 設 `model_auto_compact_token_limit`（如 96,000）＋scope | catalog.json | 壓縮改由窗口比例驅動 | 1 |
| M3 換 2.92.0 | 換 gateway + 排程 + 回滾 | 新 compaction history/budget 模組，未驗證 | 4 |
| M0 不改程式（本案採用） | 0 | 靠新 Thread＋Checkpoint 治理 | 0 |

M1/M2 皆需 Gate D 全項與獨立驗收；目前 **HOLD 於 Checker**。
