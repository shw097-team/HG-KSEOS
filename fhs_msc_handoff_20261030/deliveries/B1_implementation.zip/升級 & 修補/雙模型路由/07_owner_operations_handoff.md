# 07 OWNER 操作交接

## 1. 日常規則（立即可用）

1. **跨 Provider 家族一律新對話**：官方 ↔ OpenCode Go 的中大型施工，先開新 Thread。
2. **切換前落 Checkpoint**（見 §2），新 Session 只讀 Checkpoint + 需修改片段，不重讀整份指揮書或整段聊天。
3. **循環停止規則**：連續 2 次 compaction 無新證據、或 1 小時 > 10 次，標 `HOLD_COMPACTION_LOOP` 並停 Session。
4. **禁止巨量讀入**：單次餵入檔案 ≤ 256 KiB；1.3–5.9 MB 文件改用 `rg -n` 取片段（本案 T1 的 47× 重讀即為反例）。
5. **模型說完成不算完成**：一律看 `git diff` + 測試 exit code。

## 2. `MODEL_HANDOFF.json` 範本

```json
{
  "case_id": "…", "repo": "C:/path", "git_head": "086a940…", "branch": "codex/…",
  "dirty_path_hashes": {"src/…": "sha256:…"},
  "completed_changes": ["…"], "tests_verified": ["Ran 27 tests OK @03:04:26"],
  "tests_not_run": ["native acceptance"], "ci_unknown": ["HG-KSEOS checks 403"],
  "first_fail": "SERVED_MODEL_IDENTITY_MISMATCH", "next_action": "…",
  "stop_conditions": ["COMPACTION_LOOP", "PRODUCTION_CONFIG_DRIFT"],
  "recorded_at": "2026-10-27 10:39:27 +0800"
}
```

## 3. 健康檢查（唯讀）

```powershell
curl.exe -s http://127.0.0.1:10102/router/health
Get-NetTCPConnection -LocalPort 10102 -State Listen | Select-Object LocalAddress,OwningProcess
Get-ScheduledTask -TaskName 'Codex Desktop OpenAI and DeepSeek Router' | Select-Object State
```

## 4. 官方回滾（需要時）

`C:\Projects\Agent_Workspace\GPT_Dual_Routing_Audit\switch_route_official.cmd`
⚠️ 會重啟 App，未送出草稿可能遺失；執行前確認輸入框已清空。

## 5. 版本凍結

`@bitkyc08/opencodex@2.11.0`（勿升級）、現行 catalog／config hash、排程定義、`router.ts` `0c8ff56a73dc125d73a7c289230b33b6683763181aa9e72b09796e36d985633c`。

## 6. 觸發重新審查

- 出現第二次「單一 Thread 每回合壓縮」→ 執行 M1/M2（需 Checker）；
- 官方模型出現 401/回歸；
- Router 停止或 10061；
- 任何 compaction 後無法引用先前工具結果。
