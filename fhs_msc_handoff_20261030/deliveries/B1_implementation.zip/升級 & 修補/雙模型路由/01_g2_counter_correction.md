# 01 G2 計數更正：`thread_token_usage` ≠ 壓縮判定計數

產出：2026-10-27 11:23:40 +0800｜來源：原始 rollout（單次迭代）＋ 上游 `history.rs`／`context_window.rs`

## 1. OWNER 指出的錯誤，已機械證實

G2 曾以 `thread_token_usage.total_tokens`（32.2M→79.0M）推論「累計恆超限」。**該欄位不是壓縮判定輸入**。

原始 rollout 的 `event_msg.token_count.info` 實際欄位為：

```
info.keys = ['last_token_usage', 'model_context_window', 'total_token_usage']
```

即引擎自己就分開輸出：單次用法（`last_token_usage`）、窗口大小（`model_context_window`）、終身累計（`total_token_usage`）。壓縮判定用的是**活動上下文估值**（`last_token_usage` ＋ 未回報的本地尾巴 ＋ 視旗標而定的歷史 reasoning 估量），不是 79M 的 lifetime 累計。

→ 更正分類：`CUMULATIVE_THREAD_USAGE_NOT_AUTOCOMPACT_COUNTER`（G2 的 79M 主張**撤回**）。

## 2. 真正可量測的差距：窗口大小隨模型而變

| 階段 | `model_context_window` | 樣本數 |
|---|---|---|
| T0（gpt-6.1-sol） | **475,000** | 146 |
| T1（deepseek-v4.1-flash） | **121,600** | 1,410 |
| T1 首筆（切換邊界） | 475,000 | 1 |
| T2（gpt-6.1-sol） | 475,000 | 97 |

`121,600 = 128,000 × 0.95`（catalog `context_window` × `effective_context_window_percent`）。

## 3. T1 每輪實際用量 vs 窗口

| 指標 | 值 |
|---|---|
| `last_token_usage.total_tokens` 中位數 | **65,998** |
| p90 | **104,364** |
| 最大 | 192,385（切換當回合殘留 475k 窗口語境） |
| 有效窗口 | 121,600 |

→ T1 的常態用量已逼近窗口（p90 達 104k／121.6k ≈ 86%），**每輪都可能跨過壓縮門檻**；壓縮後模型重讀大檔（T1 曾同一指令重讀 47×），用量立刻回到高位 → 下一次壓縮。這才是「同一 turn 內 352 次」的可量測機制。

## 4. 工具輸出量（放大器）

相鄰兩次 T1 壓縮之間的工具輸出位元組：中位數 **22,602 B**、最大 **1,435,475 B**（單筆 1.4 MB 輸出）。

## 5. 未解 unknown（誠實標示）

| 項目 | 狀態 |
|---|---|
| `local tail`（本地未送出工具內容）估值 | 未 instrument → UNKNOWN |
| `server_reasoning_included` / `x-reasoning-included` 在 0.164.0-alpha.11.1 的實際旗標 | rollout 無此欄位 → UNKNOWN |
| 每次壓縮的 `reason` 字串 | 無 request-level 記錄 → UNKNOWN |
| `APPLIES_TO_INSTALLED_BUILD` | 上游 main 對照 → **UNKNOWN**（二進位無符號） |

## 6. 結論

- G1 的「served model 名稱不一致」維持 `REFUTED_AS_REPEATED_TRIGGER`。
- G2 的「79M 累計」**撤回**，改為「121,600 有效窗口 ＋ 每輪 66k–104k 用量 ＋ 大工具輸出」。
- 這也直接說明為什麼換 Gateway 版本不會自動修好：這是**模型窗口與工作負載大小**的關係，不是 gateway 缺陷。
