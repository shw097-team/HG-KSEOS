# HERMES AGENT 總指揮令｜Windows Codex 雙路由 G3：OpenCodex 2.92.0 自主升級、Compaction 真因核證、修復迭代與正式營運交付

**文件代號**：`OWNER-G3-CODEX-OCX-UPGRADE-COMPACTION-20261027`  
**發布日**：2026-10-27（Asia/Taipei）  
**OWNER**：單一全系統 OWNER，本次已授權本指令指定之本機工具維護、隔離施工、受控正式替換、機械驗收與必要回滾。  
**執行端**：本地 Hermes Agent；主模型 OpenCode Go `deepseek-v4.1-flash`（使用者也稱 V4.1 FALSH）。  
**範圍**：Windows GPT/Codex Desktop、官方 OpenAI/ChatGPT OAuth 原廠模型路由、OpenCode Go DeepSeek/MiMo、`desktop_router` 與 `@bitkyc08/opencodex` Gateway；**不**進入 FHS-MSC/HGK/PIPD/Fabric/SBL Native Acceptance 或 Live 資料施工。  
**工作模式**：`AUTONOMOUS_EXECUTE_WITH_BOUNDED_GATES`。這不是新一輪無限研究；一旦驗證版本來源及升級前檢查無阻擋，**直接完成 2.92.0 升級、實測、必要修復及交接**，不得反覆請求 OWNER 再次核准。

---

## 0. OWNER 立即裁決——優先於舊 G1/G2 對 M3 的不採納

1. **直接核准升級**現有運行核心 `@bitkyc08/opencodex@2.11.0` → **固定正式版 `@bitkyc08/opencodex@2.92.0`**。發布源以 npm 正式發行與 GitHub `v2.92.0` 核對；截至 2026-10-27，2.92.0 為最新標註 `latest` 的正式版；若執行當下來源不同，先證明差異，仍以 2.92.0 為本輪固定候選，不追逐 Preview/HEAD。此核准**不以是否已證明修好 353 次 Compaction 作前提**：依賴維護與故障根因是兩個不同命題。
2. **核准同一 Gateway 的受控替換**，保持唯一正式服務埠 `127.0.0.1:10102`、`desktop_router`、10 項 Picker 及官方 OAuth/Go Key 目的地邊界。只替換現有 Gateway 核心，必要時作最小 wrapper 相容修補；**不得**在正式鏈路上堆第二 Gateway、改寫 Codex 應用程式/引擎、建立全域 TLS Proxy。
3. **撤銷 G1 假說**：`SERVED_MODEL_IDENTITY_MISMATCH` 不是已證明導致 353 次壓縮的觸發原因；不得為此直接移除 `opencode-go/` namespace 或改 allowlist。
4. **G2 的 Total-scope「79M 因此恆超限」也不得作為已證明根因**。`thread_token_usage.total_tokens` 是累計線索，不等於 `sess.get_total_token_usage()` 所讀的**活動上下文估值**。必須按安裝引擎版次驗證 `last_token_usage`、retained encrypted reasoning、未回報的本地工具內容、header/inclusion 標記與有效壓縮閾值，才能定位觸發；上游 `main` 只能作參考。
5. **不再設專案外獨立 Checker 作為本機 Gateway 版本升級的必備前置條件**。Hermes 可以用既有自動化、固定收據及自己執行的回歸矩陣完成 `OPERATIONAL_PASS`；不得因此自稱 `INDEPENDENT_CHECKER_PASS`，也不得替 FHS-MSC 產品簽 Native Gate。若既有獨立檢查工具可用可用之，但不為此另建治理平台。
6. **明確反對盲目 M1/M2**：模型名稱、全域 `model_auto_compact_token_limit`、scope、Context Window 不能和版本升級一起任意修改。只有在升級後仍有**可重現、可定位的真缺陷**，才允許在隔離副本一次只改一個變項進行最小修補；通過對照後可在本次 OWNER 授權內部署，不需再次請示。
7. **失敗即回滾**。若新版無法啟動、官方 OAuth 回歸、Go 模型失效、憑證目的地錯誤、模型選單遺失、未預期 config 改寫或重要長任務功能退化，立即在同一工作輪次恢復舊 Gateway。不得硬撐、不得將部分 PASS 寫成全部完成。
8. **以結果結案**：可接受的終局只有 `UPGRADED_2_92_0_OPERATIONAL_PASS`、`UPGRADED_2_92_0_PASS_WITH_KNOWN_CROSS_THREAD_LIMIT`、`ROLLED_BACK_2_11_0_REGRESSION`、`HOLD_VERIFIABLE_BLOCKER`；每一項均必須附客觀收據。不要把「研究完成」冒充「施工完成」。

### 權限界線（低阻力，不等於無安全界線）
- 允許：本地唯讀盤點、短期隔離 `CODEX_HOME`、合成 repo、隔離端口與 npm cache、受控依賴替換、一次必要服務重啟、路由及工具測試、版本一致性核驗、回滾、交接文件與雜湊。
- 不允許：讀出或打印 OAuth/Go Key/原始 Authorization；將官方憑證送 Go 或 Go Key 送官方；修改 Windows Credential Manager、`auth.json`、防火牆、全域 Proxy、Codex EXE/MSIX；`ocx init/sync/start` 在**正式** `CODEX_HOME` 自動接管配置；在產品 repo 使用 sandbox bypass；對 FHS-MSC 產品 PR、Native 票據、效果 Gate 做未授權寫入。
- 合成 repo 的受限 bypass 只在隔離環境、固定 allowlist、路徑與權限確認後才可用，並須披露，優先使用正常 workspace-write。

---

## 1. 不可覆蓋的既有成果與新證據（判讀優先序）

### 1.1 已驗收正式基線（2026-10-26 r2）
- Codex Desktop `OpenAI.Codex 26.1021.3705.0`，內嵌 CLI `0.164.0-alpha.11.1`（本輪以機器當場讀回為準）。
- `C:\Users\user\.codex\config.toml` 使用 `model_provider="desktop_router"`；唯一 loopback `127.0.0.1:10102`；原廠 OAuth 通往 `chatgpt.com`，OpenCode Go 通往 `opencode.ai`；Picker：7 個官方＋1 default＋DeepSeek＋MiMo 共 10 項。
- Router `router.ts` 約 4,115 B，只是 wrapper，真正 `import startServer from '@bitkyc08/opencodex/src/server/index.ts'`；核心 `@bitkyc08/opencodex@2.11.0`。G1 已驗證 Compaction v1 `/v1/responses/compact`、v2 `compaction_trigger` 會回應；不可再說 2.11.0 根本沒有 Compaction。
- 2026-10-26 r2 T12R：**同一 Thread Go→官方發生 400**；Go→Go 可續談。跨家族長任務先維持「新 Thread＋checkpoint」，**升級後若未額外通過這項測試，限制不可取消**。
- 既有健康檢查、Windows 排程及回滾；勿以舊 PID/hash 作強制要求——服務重啟後 PID 必然改變。當前 config G1/G2 `a2e1b3ae…` 與 10/26 結案 `ad570aed…` 有已知基線漂移（root `model` 預設變更），先紀錄實際 diff，**不要自動改回過期快照**。

### 1.2 B1 r5 事故與 G1/G2 證據上限
- T0 GPT：54 patch；T1 DeepSeek：837 工具呼叫、353 `compacted`、0 可歸因產品 patch；T2 GPT：40 patch、0 `compacted`。FHS-MSC r5 產品仍 `CANDIDATE_ONLY`、Native/Independent Acceptance 未核准。
- G1 將 354 個 window 誤判為「每回合一次」及 `response.model` 無前綴而造成 previous-model mismatch；G2 按 **原始 354 筆**重算後，T1 353 次僅在 **2 個 `turn_id`**，其中 **352 次同一 `turn_id`**，且該 turn `previous_turn_settings` 位元相同。**G1 因果撤銷**；`response.model` 的不同仍可記錄為非因果共現。
- G2 對上游 `context_window.rs` 見 `AutoCompactTokenLimitScope::Total`，但稱 `thread_token_usage.total_tokens` 32.2M→79M 等於 `get_total_token_usage()`；**這是待糾正的欄位混用**。當前上游 `history.rs` 的 `get_total_token_usage()` 基於 `last_token_usage.total_tokens` ＋ 未反映於最近回應的工具/訊息估量 ＋（如未聲明 server 已計入）歷史 encrypted reasoning 估量；**並非直接引用整條 Thread 累積花費**。新版本/已安裝二進位是否採同邏輯須核對。
- G2 仍沒有每次 `reason`／`phase` 的請求級證據，未直接 instrument 實際 0.164.0-alpha.11.1 Binary；不得宣稱已證實造成 352 次 MidTurn 壓縮的唯一機制。
- G1 A（直連 Go）與 B（現有 Router）僅合成短任務 PASS，對多次壓縮的長任務**鑑別力不足**。G2 未做新版 2.92.0 實跑；本輪需實際測試，不以原先 `SOURCE_AUDITED_NOT_DEPLOYED` 取代。

### 1.3 本輪必讀的 G2 附件（只讀）
1. `01_compaction_event_discrepancy.md`：354 次重算、turn ID、前後模型／Token 欄位。
2. `02_source_mechanism_crosswalk.md`：上游實作對照與**安裝 Build 不可證**的限制。
3. `04_minimum_patch_or_keep_decision.md`：G2 M0/M1/M2/M3 既有結論；**本次 OWNER 對 M3 已修正為核准維護升級**。
4. G1 `02_compaction_first_event.json`、`06_decision_and_rollback.md`、`07_owner_operations_handoff.md`；r2 `07_live_test_matrix_r2.md`、`11_final_verdict_r2.md`；B1 r5 原取證檔，只有需要核對時才讀必要片段。
5. 以本機路徑是否存在核實來源；**不能把本指令引述或 G2 結論當作當下已驗證狀態**。

---

## 2. 2026-10-01 後的外部技術基礎——可用輪子，禁止臆測

以下為本輪已查驗的公開資料。須保存來源 URL、發布時間、修補版本、適用範圍及與本機 build 的可比性；讀不到則註記，不能捏造。

1. OpenCodex 發行：https://github.com/lidge-jun/opencodex/releases 。**v2.92.0 於 2026-10-24 發布**，npm `@bitkyc08/opencodex@2.92.0`、release commit `9f0d40a`；2.90.0 已整合 Responses 狀態還原（#7388）、Go/DeepSeek/MiMo 適配（#7394）；2.92.0 有 Hermes session 關聯及 SSE 改善。**沒有**發布說明直接保證解決本機 352 次同一 turn 壓縮。
2. npm 套件：https://www.npmjs.com/package/%40bitkyc08/opencodex 。只使用來源與 integrity 可確認的正式固定版本，不用不明 Fork 或 preview；不複製用戶 API Key 作驗證。
3. Codex `context_window.rs`：https://github.com/openai/codex/blob/main/codex-rs/core/src/session/context_window.rs 。`Total` 範圍呼叫 `sess.get_total_token_usage()`；並有 effective full-window guard；**不是** `thread_token_usage.total_tokens` 本身。
4. Codex `history.rs`：https://github.com/openai/codex/blob/main/codex-rs/core/src/context_manager/history.rs 。`get_total_token_usage()` 使用 `last_token_usage.total_tokens`、附加的 local tail，以及視 `server_reasoning_included` 而定的加計項；與 UI/rollout 的 lifetime 累計計數必須區分。
5. Codex Issue #54825（2026-10-17）：https://github.com/openai/codex/issues/54825 。真實報告在 638,856 伺服器回報 Tokens 時，Compaction 計數可能因歷史推理內容估量而達 917,130；並提供明確計數拆解。此是機制參考，**不是**本案 24k 的直接證明。
6. Codex Issue #53913（2026-10-14）：https://github.com/openai/codex/issues/53913 。缺少 `x-reasoning-included` 時可能估入已被服務端計算的舊 reasoning；跨 resume/fork 也可能影響決策。不同傳輸路徑、旗標必須實測。
7. Codex Issue #57006（2026-10-26）：https://github.com/openai/codex/issues/57006 。即使原廠模型亦可能在 Compaction 後重複讀檔與不推進任務，故 Harness/任務收斂不得全歸咎 Go。
8. OpenCodex Issue #1090：https://github.com/lidge-jun/opencodex/issues/1090 。歷史 `ocx start/sync` 改寫 Codex 配置；本次正式環境不使用自動接管指令。
9. OpenCode Go 官方：https://docs.opencode.ai/docs/go/ 。`deepseek-v4.1-flash`／`mimo-v2.6-flash` 皆通向 `https://opencode.ai/zen/go/v1/chat/completions`，現存 `opencode-go/` 是 Codex Picker 識別前綴，不可直接移除。

**研究上限**：這些資料說明已知機制與升級效益，不證明現行安裝引擎與上游 `main` 位元一致。必要時比對已發行 Tag；若無法得到 Source/Build SHA，寫 `INSTALLED_BUILD_MECHANISM_UNVERIFIED`，仍可用黑箱行為測試決定工具升級。

---

## 3. 執行原則：一次自主完成，節制工具與 Tokens

**重點**：Hermes 不得重演 T1 的「讀全文 → 我會… → Compact → 重讀全文」。

- 首次讀取本令**一次**，製作最多 **8 KiB** 的 `G3_CHECKPOINT.json`（目標、現況 SHA、下一個單一動作、測試收據、阻斷、已用預算）；其後只讀 checkpoint 與必要 256 KiB 以內的片段。禁止全文傾印 Source Tree、Chat Histories、Skills 與 `AGENTS.md`；僅在作用範圍改變或 SHA 改變時增量讀取。
- 只建立**一個** case 根目錄；最多 6 份交付文件＋manifest，存於 `C:\Projects\Agent_Workspace\GPT_Dual_Routing_Audit\Compaction_Regression_20261027_G3\`；不同執行嘗試採 append-only 事件及版本子目錄，禁止重寫 G1/G2。
- 不開無限子代理，最多一次必要的工具專項對照；優先使用 PowerShell、`npm`、固定路由工具、Git diff、現有 Windows Scheduled Task，不建立新記憶系統、監控服務或新的常駐 Proxy。
- **單一 turn 連續兩次 Compaction 沒有新增可驗證狀態／證據：立即停止該 turn、寫 checkpoint、在新 DeepSeek Thread 續作**。一小時 >10 次、同命令無新狀態連續 3 次、或 12 次工具呼叫沒有新測試／Diff／檔案收據，同樣停止。本指令**不授權**在循環中無上限重試。
- 安裝/執行迭代：**最多 3 個有限施工循環**（首裝＋最多 2 次局部相容修補），每次改動前有快照、改動後直接測試；如果仍失敗即回滾結案。不要把三個修補循環等同允許三次覆寫正式服務；正式服務替換以一次受控窗口為原則。
- 外部付費測試上限：**24 次 Go、最多 6 次官方 OAuth**；單輪合成測試避免無限制大 Prompt。若已由 mock/真實一次收據充分證明，提前停止。每個回合先清楚定義可驗證完成條件，完成即返回，不讓模型無界延續。
- 「繼續直到全部完成」的解釋：**完成已授權的有限驗證、升級或回滾、交接**；無法克服的可證 blocker 必須在同一輪交付 `HOLD_VERIFIABLE_BLOCKER`，不允許造假 PASS 或無限待命。

---

## 4. Gate A｜唯讀基線與 G2 計數更正（不可省略，但必須有界）

### A1. 現況一次讀回

核對 Windows 正式桌面版本與 engine、正式 root Provider、10 項 Picker 名單、Router wrapper 與 Imports、`@bitkyc08/opencodex` 真正被載入的版號和絕對安裝路徑、Listening `127.0.0.1:10102`、PID、Scheduled Task、舊 2.11.0 精確版本/完整性、現有 config/catalog 的 SHA、大小、實際生效路由、Go 白名單及原廠保留模型 ID。讀取秘密時**只判斷存在性/用途，不打印內容**。保留已知 root 預設 model 漂移，不擅自還原舊雜湊。

只讀命令示例（以實際路徑為準，勿盲抄）：

```powershell
Get-FileHash -Algorithm SHA256 -LiteralPath 'C:\Users\user\.codex\config.toml'
curl.exe --fail --silent http://127.0.0.1:10102/router/health
Get-NetTCPConnection -LocalPort 10102 -State Listen | Select-Object LocalAddress,OwningProcess
Get-ScheduledTask -TaskName 'Codex Desktop OpenAI and DeepSeek Router' | Select-Object TaskName,State
```

### A2. G2 Token 會計糾錯（限一次原始事件抽樣＋一次 Source 比對）

在原始 rollout JSONL 上，只抽**小型、去敏且具 offset 的數字/枚舉證據**：

- `thread_token_usage.total_tokens`（全程累計）；`turn_token_usage`（當回合累計）；`usage.total_tokens`（單請求）；`latest_token_usage_record`；`last_token_usage.total_tokens`（如有）；`retained/replacement_history` 的大小；模型 `turn_context`、`turn_id`、`window_number`。
- **最重要**：壓縮判斷中的 `active_context_tokens`／`auto_compact_scope_tokens`／`auto_compact_scope_limit`／`full_context_window_limit`／`server_reasoning_included`、retained encrypted reasoning estimate 與 local tail estimate。**記錄不到就填 UNKNOWN，不把 79M 填進 active counter。**
- 先聚焦 T1 第 3、第 4、第 5 次壓縮和末端各一筆，不重算原已核過的 354 筆聊天全文；若數據足以否定或支持假說，立即停止調查。
- 解析 `compacted` 後 last snapshot 是否改變、`last_token_usage` 與 `thread_token_usage` 差異；如果只有上游 `main` 靜態原始碼，`APPLIES_TO_INSTALLED_BUILD=UNKNOWN`。
- 將 G2 的 `79M` 重新歸類為 `CUMULATIVE_THREAD_USAGE_NOT_AUTOCOMPACT_COUNTER`（除非實際 runtime counter 另有相反證據）。G1「served model mismatch」依 G2 反證仍維持 `REFUTED_AS_REPEATED_TRIGGER`。
- 不能把 **input_tokens 約 24k** 直接當作目前活動上下文總大小或排除加計的 retained reasoning/tool tails；更不能因此把每次壓縮歸因為必然的 ModelID mismatch。

**A2 是根因進度，不是阻擋既有 2.92.0 依賴升級的藉口。** 根因可以 `PARTIAL/UNKNOWN`，仍繼續 Gate B，只要來源、安全、配置和啟動條件滿足。

---

## 5. Gate B｜固定來源 2.92.0 及隔離預演（已正式授權）

1. 核對 GitHub Release `v2.92.0`、npm 正式版 `@bitkyc08/opencodex@2.92.0`、Release commit、npm integrity；重用 G1 已驗的 SHA512 收據時必須比對**這次實際用的封包**。不使用 `npm install -g` 直接在正式運行目錄熱覆蓋。G1 候選解包屬 `SOURCE_AUDITED_NOT_POC`，不能冒充已執行 POC。
2. 在獨立、可刪除路徑安裝固定版及必要 Bun 依賴；記錄 package.json、Lockfile、Integrity、實際入口檔及 runtime 版號。檢查目前 wrapper 的 `@bitkyc08/opencodex/src/server/index.ts` 匯入路徑、`startServer` 的 export 與啟動參數是否相容。若不相容，優先使用**新版官方支持的可配置啟動入口**，而非自行維護一個新 Gateway；只修改必要 wrapper 小範圍。
3. 隔離 CLI `CODEX_HOME`、port（例 `127.0.0.1:10104`，須確認空閒）、合成 repo、單獨 temp/cache/log。**隔離環境不得指向正式 `config.toml`、正式排程或正式 Port**；不得借用正式 OAuth Token 做任意轉送／鏡像。必須能明確確認沒有 config side effect。
4. 功能測試：健康／API 模型表、Go DeepSeek 和 MiMo 的最小 SSE＋tool/result、Go 模型白名單與未知 slug 400、`/v1/responses/compact`、v2 `compaction_trigger` 合法完成；官方 OAuth 只使用現有授權機制且不打印 Token。協定 mock 可替代所有秘密邊界測試，但最後真實官方 OAuth 200 必須在正式前後至少一次核證（如測不了，正式替換暫停或回滾）。
5. 合成上下文測試：同一 DeepSeek Thread 做 **最多三個有界 tool-follow-up**，其間模擬或真觸發一次 Compaction，觀察 replacement history 是否收斂與能否參照上一個工具結果；接續再做新 Thread 成功測試。另以合成 GPT→Go 的切換試例確認仍有無 T12R 400；若跨家族仍失敗，**不能用這一項單獨否決版本維護升級**，但明確保留 known limitation。
6. 如替換版本在 mock/Go 真請求表現不如 2.11.0，最多 **兩次**針對性最小 wrapper 相容調整（無全域配置改寫），每次固定 SHA、diff 和測試。仍失敗則**不部署正式**，回報 `HOLD_VERIFIABLE_BLOCKER`。不得為改善結果而提高限制或重新寫一層協定處理器。

**Gate B 合格**：`PINNED_SOURCE_PASS`、`WRAPPER_START_PASS`、`GO_DEEPSEEK_MIMO_PASS`、`COMPACTION_V1_V2_PASS`、`ROUTE_AUTH_BOUNDARY_PASS`、`NO_CONFIG_SIDE_EFFECT_PASS`、`ROLLBACK_PACKAGE_READY`。個別隔離 GUI／官方 OAuth 真路徑若受限，需在正式切換窗口補做並立即回滾，不能以 mock PASS 偷換成實證。

---

## 6. Gate C｜受控正式原位替換（不要再等二次 OWNER 簽核）

**進入條件**：Gate B 全部可做的檢查通過；舊 2.11.0 可於同一工具窗口重啟回復；健康及憑證分流基線已記錄；沒有任何使用者未儲存的 Composer 草稿或不可中斷任務。若無法客觀確認安全窗口，記 `HOLD_ACTIVE_DESKTOP_SESSION`，不強殺正在執行的 Codex 任務。

實作次序：

1. **Preimage**：以檔案層備份（不列印秘密）固定 `config.toml`、catalog、wrapper、排程 XML/Action、package lock 與正在運行的 2.11.0 package/相關 dependencies，記 SHA-256、大小及可回滾路徑；只存本機受限 ACL 私有目錄，不上傳包含秘密的整份設定。預先準備服務啟動/停止/回滾命令與判斷式。
2. **版本路徑原子切換**：停止**僅**既有 10102 Gateway；不重裝/殺掉整套 GPT 桌面 App（除非產品重連機制客觀要求）。把排程/啟動鏈中實際使用的依賴根切到隔離已驗證 `2.92.0`，沿用同一 Port、同一服務身分與現有憑證安全存取方式。不要新增新的生產常駐程序、Global npm hook 或 `ocx sync/init`。
3. **啟動驗證**：從**實際 PID**與 package resolve 結果確認 running core == `2.92.0`，不只看 npm CLI `--version`。Healthy、loopback only、原廠／Go upstream 目的地判斷不變，沒有在不知情下寫入 root config。
4. **最小真實冒煙（固定成本）**：官方真 OAuth 一次正常答覆，DeepSeek 和 MiMo 各一次含工具／SSE 完成；10 項 Picker（GUI 可驗則實測，否則以實際載入 Catalog 與官方/Go 選單清單提供替代收據並標 `GUI_NOT_OBSERVED`）；Go Unknown model `400`；v1/v2 Compaction；同 DeepSeek Thread 有界續談、路由錯誤時如實報錯。原廠/Go 凭證不得跨 upstream，實際來源只記憑證類別與目的地。
5. **部署後收斂**：若本次無新的產品修復，標 `UPGRADED_2_92_0_PASS_WITH_KNOWN_CROSS_THREAD_LIMIT`；保留 T12R 跨家族新 Thread 規則。不要求為了升級 PASS 重跑原 r5 4.9 小時施工或 353 次 Compaction。
6. **任何 fail**：停止 2.92.0 → 將完全相同的舊版本 package/Wrapper/排程來源恢復 → 啟動 2.11.0 → 確認原廠/Go 核心健康 → 出具 `ROLLED_BACK_2_11_0_REGRESSION` 與第一個失敗收據；**不得在失敗的正式環境連續堆 patch**。已知 config 漂移若未受本輪改動，應原樣保留。

本 Gate **不要求專設 Independent Checker**。現有可靠的機械收據、Test Exit Code、API 結果、上下游路由與 SHA 對照即構成本機工具維護驗收；但如 `GUI_NOT_OBSERVED` 或全局重開機未測，按限制標示，不得宣稱全部測完。

---

## 7. Gate D｜必要時最小修復，否則到此停止

版本升級後若仍有同 turn 重複 Compaction，**先確認活動 Token 計數**，再選擇現成輪子、不要亂修：

### D1. 精準比較（一次隔離 A/B，不在正式環境反覆重現）
- 同 Codex Engine、同合成工作負載及 Go 模型：2.11.0 vs 已部署/隔離 2.92.0（若已經是 2.92 正式，舊版僅在測試 Port 隔離啟動）；記 `turn_id`、Compaction 次數、有效 active count、`last_token_usage`、local tail、historical reasoning、`x-reasoning-included` 可觀測值、上下文恢復、工具可驗進展。
- 如無執行期細計數，僅以離線歷史重建作**候選說明**，不得稱 `ROOT_CAUSE_CONFIRMED`。不得把 `thread_token_usage.total_tokens = 79M` 填入 `active_context_tokens`。
- 區分「Compaction 成功但模型不繼續施工」、「Compaction 重複觸發」、「上游 400」、「SSE 不完整」、「回應推理缺口」這五個不同故障；只針對實際重現的缺陷做最小修法。

### D2. 候選修法（只改一項，測後決定）
- 若有 OpenCodex 已修的 history/replay/budget 舊缺陷：優先使用新版**既有設定/已發布代碼**，不要另造 Gateway。
- 若證實與 `server_reasoning_included`／`x-reasoning-included` 有關：僅測試已支持的 header/保留狀態及現成修補，在隔離环境證實有效且不會偽稱上游已計入 reasoning。**不可隨意偽造 header** 以壓低計數。
- 若確定是 CLI Engine 本身的錯誤，而新版 Gateway 不能治：**維持 2.92.0 工具升級結果**（若其他功能都 PASS），追蹤 Codex 官方版修補，並用有界回合＋Checkpoint 做營運降級；不要 patch 原廠 EXE。
- **M1**：只有有請求級證據且隔離實驗證實模型 ID 影響本案時才考慮；G2 已否定它作為 352 次重複壓縮的解釋，原則不做。
- **M2**：只有 Parser 支援且能逐模型隔離，並確定不影響官方 OAuth/模型硬性 Context Window 時才可能升格；根 config 的全域閾值改寫原則不做。

### D3. 修復/停止閘門
- 最多兩次隔離修補迭代，**每次必須有新測試收據**；同樣失敗連續兩次則停。成功修補需能在同一 fixture 下確切消除重複壓縮、工具結果保持正確、Go/官方路由安全不退化，才能部署；否則 `KNOWN_COMPAT_LIMITATION` 並以短 Thread 運行。
- 不把「此次未重演 353 次」當成「原始事故永久修復」。驗收分類 `GATEWAY_UPGRADE_PASS` 與 `COMPACTION_LOOP_FIX_CONFIRMED` 必須分開記錄。

---

## 8. Gate E｜低負擔交付、運維與回滾

只交付下列 **6 個正文工件＋1 manifest**；禁止 30 份重複報告。存於本機 `Compaction_Regression_20261027_G3` 專屬目錄：

| 工件 | 最少內容 |
|---|---|
| `00_execution_receipt.json` | 案件/機器版次、執行的 Gates、起迄狀態、source integrity、Go/官方請求計數、暫停原因、版本結論 |
| `01_g2_counter_correction.md` | `thread_total` 與 `last_token_usage/active_context` 的證據界線、上游與安裝引擎適用性、未解 unknown |
| `02_upgrade_diff_and_integrity.md` | 新舊版本、wrapper/package lock/排程/config/catalog 精確前後雜湊與路徑、變動說明、未改部份 |
| `03_smoke_and_compaction_receipts.json` | 官方/DeepSeek/MiMo/SSE/tools/v1/v2/Picker/loopback/route、合成重現、失敗收據，PASS/FAIL/UNKNOWN |
| `04_final_owner_operational_verdict.md` | 最終部署或回滾裁決、實際 PID/version、known limits、是否真正修復 Compaction、產品 Native 保持不變 |
| `05_ops_checkpoint_rollback.md` | 短 Thread、`MODEL_HANDOFF.json` 示例、循環停止規則、健康檢查、版本固定與一步回滾 |
| `06_sha256_manifest.txt` | 以上 6 份檔案 SHA-256，manifest 不自雜湊 |

正本保持原始檔不篡改；必要的完整 config/credential 只保存在本機私密受限備份，對外摘要不得外洩路徑中秘密或權杖。所有 JSON 必須可剖析、`PASS` 必須附 test/assertion、時間、執行路徑及 SHA；雜湊 manifest 必須重新算而非複製報告中的預期值。

### 終局宣告格式（必填）

```text
CASE_ID: Compaction_Regression_20261027_G3
EXECUTOR: Hermes Agent / OpenCode Go deepseek-v4.1-flash
OWNER_AUTH: PREAUTHORIZED_LOCAL_GATEWAY_UPGRADE_AND_ROLLBACK
BEFORE_GATEWAY: 2.11.0 / <real hash and path>
AFTER_GATEWAY: 2.92.0 | 2.11.0 ROLLED BACK | UNCHANGED
ACTUAL_RUNNING_PID_AND_VERSION: <evidence>
FINAL_VERDICT: UPGRADED_2_92_0_OPERATIONAL_PASS |
               UPGRADED_2_92_0_PASS_WITH_KNOWN_CROSS_THREAD_LIMIT |
               ROLLED_BACK_2_11_0_REGRESSION |
               HOLD_VERIFIABLE_BLOCKER
G1_IDENTITY_ROOT_CAUSE: REFUTED_AS_REPEATED_TRIGGER
G2_79M_LIFETIME_EQUALS_ACTIVE_COUNTER: NOT_ESTABLISHED (or grounded correction)
COMPACTION_LOOP_FIX: CONFIRMED_BY_BOUNDED_REPRO | NOT_CONFIRMED | NOT_TESTED
OFFICIAL_OAUTH: PASS | FAIL | NOT_TESTED
DEEPSEEK_MIMO: PASS | FAIL | NOT_TESTED
SSE_AND_TOOLS: PASS | FAIL | NOT_TESTED
COMPACTION_V1_V2: PASS | FAIL | NOT_TESTED
PICKER_10: PASS | FAIL | NOT_OBSERVED
PROVIDER_KEY_ISOLATION: PASS | FAIL | UNKNOWN
CONFIG_DRIFT_THIS_ROUND: NONE | DOCUMENTED_DIFF | UNEXPECTED
CROSS_FAMILY_SAME_THREAD: KNOWN_FAIL_UNTIL_NEW_PASS
FHS_MSC_R5_NATIVE_STATUS: CANDIDATE_ONLY_UNCHANGED
PRODUCTION_CHANGES: <exact list>
ROLLBACK: NOT_NEEDED | COMPLETED | NOT_POSSIBLE_AND_ESCALATED
FIRST_FAIL: <None or exact failed invariant>
EVIDENCE_PATH: <real directory>
OWNER_ACTION_REQUIRED: NONE | <one true external blocker>
```

**停止並交付**：終局為 PASS、PASS_WITH_LIMIT、成功回滾或客觀 blocker 之一後，不繼續「再看看」、「再重讀指令」、「再查另一個候選」，不留下無界工作。所有正常可完成部分必須在本次工作輪次完成，而不是只交調查計畫。

---

## 9. 本令意圖與核准門檻總結

- **以升級為預設行動**（2.92.0 固定官方正式版），而不是把 `KEEP_CURRENT_ROUTER` 變成對改版的永久禁令。
- **以可回滾的最低必要操作控制風險**，不是依靠新的審核團隊阻止工程。
- **不再混淆 G1、G2 的互相矛盾假說**；`thread_token_usage` 累計 79M 不能直接替代活動上下文判定計數。
- **用新版現有代碼，不自己再造 Compaction Adapter/Proxy**；任何補丁需小、可驗證、可回滾。
- **升級通過≠原始事故完整修復**；跨官方／Go 同 Thread，未另有實證前繼續新 Thread＋Checkpoint。
- **FHS-MSC B1 r5 候選、Native、Independent Checker 及 Live 效果全部保持原治理身分**；工具維護驗收不等於產品驗收。

## 10. 上游參考 URL（2026-10-01 後優先）

- https://github.com/lidge-jun/opencodex/releases
- https://www.npmjs.com/package/%40bitkyc08/opencodex
- https://github.com/openai/codex/blob/main/codex-rs/core/src/session/context_window.rs
- https://github.com/openai/codex/blob/main/codex-rs/core/src/context_manager/history.rs
- https://github.com/openai/codex/issues/54825
- https://github.com/openai/codex/issues/53913
- https://github.com/openai/codex/issues/57006
- https://github.com/lidge-jun/opencodex/issues/1090
- https://docs.opencode.ai/docs/go/
