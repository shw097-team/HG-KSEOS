# 04 方案裁決（M0 / M1a / M1b / M2 / M3）

## 裁決表

| 方案 | 內容 | 可治本案？ | OI | 裁決 |
|---|---|---|---|---|
| **M0** | 不改程式；新 Thread＋`MODEL_HANDOFF.json`＋有界回合 | ✔ 直接對症（唯一在資料上成立的解法） | 0 | **ADOPT（預設終局）** |
| M1a | Adapter 回寫 requested slug 為 `response.model` | ✘ 352 次壓縮中 previous 完全相同，名稱非閘門輸入 | 1 | **REJECT（無效）** |
| M1b | catalog slug 去 `opencode-go/` 並同步 allowlist | ✘ 同上；且改動正式 route 白名單屬高風險 | 2 | **REJECT（無效＋風險）** |
| M2 | `model_auto_compact_token_limit`（root 或 catalog） | △ 僅延後；Total scope 累計 79M 恆超限；root 設定波及官方模型 | 3 | **REJECT_GLOBAL_SIDE_EFFECT** |
| M3 | 換 `@bitkyc08/opencodex@2.92.0` | ？ 無對症證據（新模組針對 history/budget） | 4 | **NOT_ADOPTED（SOURCE_AUDITED_NOT_DEPLOYED）** |

## 為什麼 M0 是正確答案而不是「沒修」

1. 反證已成立：352 次壓縮的 `previous_turn_settings` 逐位元相同、`comp_hash=null` 恆定、工具間距中位數 1 → 觸發是**每輪 token 預算判定**，非身分比對。
2. 判定式為 `get_total_token_usage() >= auto_compact_token_limit`（scope=Total，預設）；本案該值達 **79.0M**。任何 catalog／root 上限都無法「調高到夠」，只能暫時延後。
3. 因此真正的可操作槓桿是**讓單一 turn 不要無界累積**：把長工作切成有界回合（新 Thread 或中斷再開），使 `get_total_token_usage()` 不進入持續超限區。
4. OI：M0=0；M2=3（全域副作用）；M3=4（換 gateway＋信任邊界）。

## 具體操作（Gate E，立即生效）

- 單一 turn 內若連續 2 次壓縮而無新可驗證進度 → 停止該 turn，落 Checkpoint，開新 turn／Thread 續作。
- 跨供應商家族一律新 Thread（T12R 400 已證）。
- 單次餵入 ≤ 256 KiB；1.3–5.9 MB 文件改 `rg -n` 取片段。
- 每小時 >10 次壓縮即 `HOLD_COMPACTION_LOOP`。

## 未被採納但已備妥的候選（若日後 engine 支援逐模型閾值）

`model_auto_compact_token_limit_scope = "body_after_prefix"` 搭配 root 上限，理論上可讓「只計算前綴之後的增量」以貼近實際視窗；但本機 parser 支援未證，且會改變全部模型的壓縮行為 → 留待 engine 升級後的獨立驗證。
