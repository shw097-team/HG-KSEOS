# 02 升級差異與完整性

## 1. 版本與來源

| 項目 | 值 |
|---|---|
| before | `@bitkyc08/opencodex@2.11.0`，實體路徑 `C:\Users\user\AppData\Roaming\npm\node_modules\@bitkyc08\opencodex`（**未刪、未改**，保留為回滾源） |
| after | `@bitkyc08/opencodex@2.92.0`，`C:\Users\user\.codex\desktop-model-router\vendor\opencodex-2.92.0` |
| license | MIT |
| gitHead | `9f0d40a25f8b842c33ab233d466d0bd991d86052` |
| npm integrity | `sha512-4of4Ab/wJ3gCNQ8+SM/dQlCE3vsFuPW7BUpj2VYOyYgfphVAOJyzkx2VNZK/Xwwr3AoFuB0nfm1K3nk03zA+/w==`（本輪重算相符） |
| tarball SHA-256 | `ac71cdb2a4e03f546caeb5521886ad67d744a2769e05c6de008cb061d8e18d75`（`bitkyc08-opencodex-2.92.0.tgz`, 14,869,383 B） |
| deps | `@bufbuild/protobuf`、`@modelcontextprotocol/sdk`、`@napi-rs/keyring@1.3.0`、`zod@4.6.6`、`bun@1.4.4`（宣告） |
| runtime | bun **1.3.14**（既有，未變更；vendor 內的 bun binary 下載失敗，已改用既有 runtime，屬「執行期不變」） |

## 2. 檔案級前後雜湊

| 檔案 | before SHA-256 | after SHA-256 | 大小 |
|---|---|---|---|
| `router.ts` | `0c8ff56a73dc125d73a7c289230b33b6683763181aa9e72b09796e36d985633c`（4,115 B） | `3ecb99ed8c519e3f3ab2a0e8ab0bef557d3476ee20f76eec6ff49b7d291b1dc5` | 4,145 B |
| `config.json` | `e100ef7cc3b2d0c9cb004a395e9eb9ee0477db6e65e7760c6ccca995f3a1f49d` | `57752556f4c7f2292aba34f580bca9149f1f61e7812a904c92fef7d6058463c8` | 7,474 B |
| `catalog.json` | `c908b53a3fbe24e50670979f8193a137bc991e6f0c79e9d22579fd625248bbb5` | **未變** `c908b53a3fbe24e50670979f8193a137bc991e6f0c79e9d22579fd625248bbb5` | 403,597 B |
| `config.toml` | `a2e1b3ae34c7a5428884fb091a4c891d6b8e591b67a2237c9d7e036d076696df` | **未變** `a2e1b3ae34c7a5428884fb091a4c891d6b8e591b67a2237c9d7e036d076696df` | 12,073 B |
| 排程 Action | `wscript.exe → candidates\router-windowless-host.vbs` | **未變** | — |

## 3. 變更內容（僅兩處）

1. **router.ts**：兩個 import 由全域 2.11.0 絕對路徑改為 vendor 2.92.0 絕對路徑，其餘 71 行邏輯（Go session 注入、thinking 開關、官方直通、未知 slug 400、`startServer` 呼叫）**一字未改**。
2. **config.json**：新增 `"claudeCode": { "enabled": false }`。原因：2.92.0 出廠預設會啟動 Claude intercept（CONNECT proxy `127.0.0.1:10204`、picker proxy 10205、本地 CA 目錄 `claude-intercept/`）。首次隔離啟動已實測出現該日誌與副作用；關閉後重啟，日誌與監聽皆消失、亦未產生 CA 目錄。

## 4. 未變更（明確）

`config.toml`、`catalog.json`、`auth.json`、Go Key 檔、Credential Manager、防火牆、全域 Proxy/TLS、Codex EXE/MSIX/ASAR/DLL、排程定義、`bun.exe`、全域 2.11.0 套件。

## 5. 回滾包

`C:\Users\user\.codex\desktop-model-router\g3_backup_20261027T111944\`
- `router.ts.pre-g3`（`0c8ff56a73dc125d73a7c289230b33b6683763181aa9e72b09796e36d985633c`）
- `config.json.pre-g3`（`e100ef7cc3b2d0c9cb004a395e9eb9ee0477db6e65e7760c6ccca995f3a1f49d`）
- `catalog.json.pre-g3`（`c908b53a3fbe24e50670979f8193a137bc991e6f0c79e9d22579fd625248bbb5`）

回滾＝複製回原位 → 停止 10102 程序 → `Start-ScheduledTask`（步驟見 05）。
