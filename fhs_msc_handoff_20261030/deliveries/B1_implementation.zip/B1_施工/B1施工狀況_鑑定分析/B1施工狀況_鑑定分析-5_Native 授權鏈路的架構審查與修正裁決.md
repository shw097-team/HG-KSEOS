# you asked

message time: 2026-10-27 12:13:56

任務目標：\
你必須整合前述分析規劃，再對『』進行以下項目的專業工程「研究分析 + 交叉比對 + 鑑定評估」：\
"\
那HERMES提出的「剩下的都卡在同一個東西上：沒有 OS 授權的簽發 principal（`Enable` 需要管理員 + 機器金鑰）。」要怎解決?你前輪有對此提出嗎?

而且為啥需要WINDOES的管理授權?HG-KSEOS就只是一般CODING工廠，需要 OS 授權反而很奇怪且不正常吧，根本不需要阿，這是否是你之前的PROMPT設計錯誤/治理過度?或是「FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG」的設計問題?

任務要求：
你必須針對以上項目，進行網路搜索"2026年10月1日"以後的最新資料，搜索相關主題的「技術社群論壇(例如：GitHub 、ARXIV、HuggingFac)、網站、專欄、部落格、專業研究」，並對「搜索資料」和「本篇對話上傳的全部相關資料」進行「研究分析+交叉比對+深度推理」，再對任務目標進行符合「專業工程實務思維、技術社群成熟技術者共識」的工程評估 / 鑑定 / 規劃，並且不過度工程化。
最後你必須直接以文字提出完整報告。

---

# chatgpt response

我會先核對 HGK 現有 `Enable` 腳本究竟把 Windows 管理員權限用在哪些操作，再比對 B1 DOC-00～08 是否真的要求「OS 管理員＋機器憑證」，以及這是安全必要條件還是 r5～r9 修補時自行加入的實作選擇。接著查閱 2026 年 10 月 1 日以後的技術資料，提出不要求日常管理員權限、也不增加人類簽核者的最小修正方案。

交叉比對後又找到更關鍵的實作矛盾：目前 `Enable/Sign` 不只要求管理員，還把 Registry 的 `owner_os_sid` 綁死在執行程序的 SID，並將 Trust 目錄寫入權限限制為 Administrators／SYSTEM。這使前輪提議的「換一個普通 HGK Signer Service 自動簽發」**不能直接接上現有程式**；必須先修改這組身分與 ACL 契約。

因此解法應是**移除「系統管理員」作為一般 Native 簽發的固定前置**，而不是再要求你安裝一個管理員常駐服務來配合錯誤前提。真正需較高權限的 Host 安裝操作另行隔離。

# FHS-MSC B1｜HG-KSEOS 為何要求 Windows 管理員？Native 授權鏈路的架構審查與修正裁決

研究基準：2026 年 10 月 27 日｜比對範圍：B1 DOC-00～08、Bootstrap 藍圖、r5～r9 指揮與執行紀錄、HGK GitHub 原始碼，以及 2026 年 10 月 1 日後的技術資料

## 一、核心結論：你的質疑成立，而且找到了具體的過度治理來源

**HG-KSEOS 作為一般本地 Coding Factory，並不需要 Windows Administrator 才能正常執行程式碼施工、Git 操作、測試、WorkOrder 排程、持久佇列或一般驗收。**

真正需要區分的是：

- **應用程式層授權**：誰能核准某張 WorkOrder、哪個 Repository 可修改、哪些效果可執行。這些可以由 HGK 的 Policy、憑證、權限檢查及可追溯收據處理，不需要 Windows 管理員。
- **作業系統層授權**：誰能修改受 Windows 保護的系統資源，例如特定全機憑證儲存區、系統保護的信任目錄或需要提權安裝的服務。只有操作這類資源，才可能需要對應的 OS 權限。

這兩種權限在目前 HGK 候選實作中被過度綁定。

### 最重要的原始碼發現

我直接檢查了 HGK 最新 PR \#2 所包含的 `scripts/native-trust-maintenance.ps1`。它在 `Inspect` 及 `SelfTest` 以外的操作入口使用：

```powershell
if($Mode -ne 'SelfTest' -and -not $isAdmin){
    throw 'ERR_OWNER_ELEVATED_OS_PRINCIPAL_REQUIRED'
}
```

同時，`Enable` 只能接受位於：

`Cert:\LocalMachine\My\`

的既有、不可匯出、機器層級 CNG RSA 私鑰，並要建立 `%ProgramData%\HG-KSEOS\native-admission\registry.json`，設定管理員／SYSTEM 控制的 ACL。

這不是 Windows 對一般 Coding Factory 的要求，而是 **HGK r5 修補所選擇的特定信任儲存及部署模式**。

更重要的是，原始 B1 DOC-00 明確要求 HGK 唯一 Native Issuer、Owner 權限、簽發主體與獨立 Checker，卻沒有明文規定：

- HGK Issuer 必須以 Windows Administrator 執行；
- 必須使用 `LocalMachine\My`；
- 必須使用 RSA-3072 CNG Machine Certificate；
- 每次 `Sign` 必須以提升權限的 PowerShell 執行。

**因此，我的初步工程鑑定是：目前的 Windows 管理員阻斷，主要源於 r5～r9 採用的 HGK Native Trust 實作選型，而不是 B1 業務及 Native 驗收契約不可避免的要求。**

這也表示，前輪只不斷要求你建立管理員 Broker，卻沒有先質疑「為何 Coding Factory 的日常簽發必須依賴管理員」，確實存在工程判斷過度保守的問題。

## 二、到底是哪一層設計出了問題？

我把問題拆成三層，避免繼續把所有阻斷都叫做 `NATIVE_TRUST_BOOTSTRAP_REQUIRED`。

| 層級 | 原始設計／實作 | 鑑定 |
|--------|--------|--------|
| B1 DOC-00～08 | 要求唯一 Issuer、有效 Owner Policy、作用域、簽章與獨立驗收 | **有工程理由，但應按效果風險適用** |
| HGK r5 Native Admission 修補 | 強制全機 Trust Registry、管理員 SID、Machine CNG RSA Key | **實作選型過重，並非 B1 明文指定** |
| Hermes r7～r9 指揮 | 持續要求啟用管理員 Signer Broker，沒有先重新評估權限需求 | **我先前的指揮規劃確實需要修正** |

### 2.1 B1 文件真正要求什麼？

交叉讀取九份 B1 文件後，最直接的權威條款是：

**DOC-00** 規定 HGK 唯一 Native Issuer、Hermes Queue／Lease、Fabric Active Policy、PIPD Compiler，以及正式 SourceFreeze、Maker／Checker 真正隔離、同主體 Raw Evidence。其 G-A 還要求 Issuer、Queue、Fabric、Model Lanes、Methods 與 Checker 六項合取成立。

**DOC-02／03** 將簽發契約表述為帶有 `subject`、`policy_epoch`、`principal`、`nonce`、`scope`、`ttl` 的 Token，要求 Issuer 先驗證再允許效果。

**DOC-04** 強調必須量測真正的現役載入路徑，而非只測原始碼。

**DOC-05／07／08** 要求真實效果、拒收負例、獨立 Checker 與 GWO 原生續工。

以上是 B1 自己的設計契約。

**沒有看到必須以 Windows Administrator 進行所有 Native Sign 的要求。**

這是「文件未規定」的結論；並不等於我已證明所有未上傳的其他系統規則也完全沒有額外限制。

### 2.2 HGK r5 修補究竟增加了什麼？

目前 HGK 程式多加了四項特定實作前提：

| 具體實作 | 實際後果 | 是否為一般 Coding Factory 的必要條件？ |
|--------|--------|--------|
| `IsInRole(Administrator)` | `Enable／Sign／Revoke` 普遍要求管理員 | **否** |
| `Cert:\LocalMachine\My` | 只能取用全機憑證存放區 | **否** |
| `RSACng.IsMachineKey`＋不可匯出 RSA-3072 | 排除現有使用者層金鑰選項 | **否** |
| `%ProgramData%`＋Administrators／SYSTEM ACL | 把信任註冊設計成全機保護資源 | **否，除非確實要建立全機信任服務** |

其中 ACL 檢查還存在一個容易忽略的後果：

**即使建立普通權限的 HGK Signer Service，也不能直接套用現有程式。**

因為現有註冊機制把簽發者身份等同 `owner_os_sid`，並把 Registry 的修改權限限制給 Administrators／SYSTEM。不同機器服務身份沒有被納入完整授權語義。

這解釋了為什麼前輪的「另外部署 Signer Broker」不一定真正打得通。

它可能只是把原本的過度管理員要求，包裝成另一個常駐服務。

### 2.3 為什麼這不是密碼學本身的限制？

有一個非常具體的程式證據：

HGK `native_admission.py` 的 `verify_signature()` **已經支援 `Ed25519` 公開金鑰驗證**，也支援 RSA。

也就是說，Verifier 的設計並未要求每個簽章都必須來自 `LocalMachine\My` 的 CNG RSA Machine Certificate。

**現有 Receiver 具備較一般化的公開金鑰驗證能力，Maintenance 工具卻把簽章來源限制為特定 Windows 全機憑證。**

這是明顯的實作不對稱。

修正它，無須放棄數位簽章或唯一 Issuer。

---

## 三、前輪是否曾經提出解法？

**有提出，但沒有真正解決你現在指出的根因。**

前輪「單一 OWNER 全自動授權與 Native 驗收鏈路修復方案」提出：

- Single Human Owner。
- Standing Authorization。
- HGK Protected Signing Broker。
- 獨立 Machine Checker。
- 如果沒有既有有權執行端，先完成一次 Windows UAC 初始化。

r8／r9 隨後延續這個設計，要求 Hermes 呼叫 `native-trust-maintenance.ps1 -Mode Enable`。

這個方案在「確實要建立全機受保護服務」時可以成立。

**但它把全機受保護服務當成了預設必要架構。**

我先前沒有優先提出另一個更簡單的問題：

> 能不能在標準 Windows 使用者權限內，直接完成 HGK 所需要的密碼學簽發、授權驗證與原生工作管理？

答案是：**一般情況可以。**

所以前輪的缺失不是沒有提供任何解法，而是**沒有先進行最小權限的必要性驗證，就接受 r5 寫死的管理員要求**。

本輪應正式修正此決策。

---

## 四、2026 年 10 月最新技術研究與社群交叉比對

我依照你的要求，檢索了 2026 年 10 月 1 日以後的 GitHub、arXiv、Microsoft 與技術社群資料。以下僅以發布或明確事件日期落在指定期間的資料作為近期研究證據。

| 日期 | 來源 | 研究或技術結果 | 對 HGK 的直接啟示 |
|--------|--------|--------|--------|
| 10 月 6 日 | [A Case Study in Assuring AI-Written Software](https://arxiv.org/abs/2610.08651) | 多代理施工、審查與監測可能產生代理指標及假成功 | 應保留真實效果讀回，不靠額外服務數量建立可信度  [arxiv.org](https://arxiv.org/abs/2610.08651?utm_source=chatgpt.com) |
| 10 月 7 日 | [Microsoft Execution Containers](https://blogs.windows.com/windowsdeveloper/2026/10/07/microsoft-execution-containers-policy-driven-containment-for-ai-agents/) | Windows 以受控執行環境限制 Agent 的檔案、網路與能力 | 自治能力應在受限環境內提供，不是提高整個 Agent 的權限  [Windows Developer Blog](https://blogs.windows.com/windowsdeveloper/2026/10/07/microsoft-execution-containers-policy-driven-containment-for-ai-agents/?utm_source=chatgpt.com) |
| 10 月 7 日 | [GitHub Copilot Local Sandboxing](https://github.blog/changelog/2026-10-07-local-sandboxing-for-github-copilot-now-generally-available/) | 原生 Sandbox 可約束 Agent 的檔案、憑證及工具存取 | 支持普通權限執行＋能力邊界的模式  [GitHub Changelog](https://github.blog/changelog/2026-10-07-local-sandboxing-for-github-copilot-now-generally-available/?utm_source=chatgpt.com) |
| 10 月 13 日 | [Codex GitHub Issue #53665](https://github.com/openai/codex/issues/53665) | 社群回報將權限申請錯誤綁定「必須有寫入行為」，反而阻擋合法唯讀診斷 | 不能把人工提權做成不合理的工具前置；此為使用者回報，不是經確認的 HGK 同源故障  [GitHub](https://github.com/openai/codex/issues/53665?utm_source=chatgpt.com) |
| 10 月 16 日 | [From Approval to Abuse](https://arxiv.org/abs/2610.22987) | 實驗顯示過寬且可重用的 Agent Allow Rules 可能被惡意情境誘導 | 常設授權要限定 WorkOrder 範圍，而不是整個管理員權限  [arxiv.org](https://arxiv.org/abs/2610.22987?utm_source=chatgpt.com) |
| 10 月 19 日 | [Microsoft Agent Dynamic Permissions](https://www.microsoft.com/en-us/security/blog/2026/10/19/agents-are-your-newest-insiders-security-must-move-at-their-speed/) | 主張 Agent 權限依任務、時間與作用域動態授予，不直接繼承人類全部權限 | 唯一 OWNER 可常設委派政策，但每張卡只取得所需能力  [Microsoft Security Blog](https://www.microsoft.com/en-us/security/blog/2026/10/19/agents-are-your-newest-insiders-security-must-move-at-their-speed/?utm_source=chatgpt.com) |

另外，2026 年 10 月 13 日的 [Beyond Maliciousness](https://arxiv.org/abs/2610.19264) 研究指出，Agent Skill 的聲明權限和實際執行能力可能有顯著差異。這支持在工具執行層真正限制能力，而不只在 Prompt 寫「禁止越權」。 [arxiv.org](https://arxiv.org/abs/2610.19264?utm_source=chatgpt.com)

### 技術社群資料支持哪個方向？

上述資料不能代表所有工程師一致同意某個唯一架構，但跨不同來源可以觀察到相當一致的工程方向：

**Agent 高自動化與高系統權限，不應畫上等號。**

讓 Agent 能連續自行開發、測試與提交，較成熟的做法是提供明確的工作空間、可用工具、作用域、受限憑證、持久狀態及真實驗證，而不是預設要求 Administrator。

這也不是主張關閉安全保護。相反地，近期研究特別提醒：以一條極寬的永久批准規則來消除提示，可能帶來新的風險。

### Windows 本身已經有使用者層密碼學能力

這裡另以 Microsoft 的既有技術規格佐證，與上表的 2026 年 10 月近期研究分開看待。

Windows 本來就區分 `CurrentUser` 與 `LocalMachine` 憑證存放區；CNG 的 `NCRYPT_MACHINE_KEY_FLAG` 是選擇全機金鑰的旗標，不使用該旗標時，金鑰可屬於目前使用者。 [Microsoft Learn](https://learn.microsoft.com/en-us/windows-server/identity/ad-cs/inspect-certificates-manage-certificate-stores?utm_source=chatgpt.com) [Microsoft Learn](https://learn.microsoft.com/windows/win32/api/ncrypt/nf-ncrypt-ncryptcreatepersistedkey?utm_source=chatgpt.com) [Microsoft Learn](https://learn.microsoft.com/en-us/windows-hardware/drivers/install/local-machine-and-current-user-certificate-stores?utm_source=chatgpt.com)

因此：

**Windows 有現成的使用者層簽發機制。HGK 沒有技術上的必要，強迫所有正式簽章都由全機 Machine Key 發出。**

---

## 五、建議採用的最小修正架構

### 正式裁決：不要再把 Administrator 當作 B1 預設准入條件

我建議把現有 HGK Trust 改為**兩種執行權限配置，而不是建立兩套 Issuer**。

| 配置 | 適用任務 | Windows 管理員 |
|--------|--------|--------|
| **USER-SCOPED NATIVE**（預設） | Repo 修補、測試、Git、PIPD 編譯、使用者目錄內的 Fabric Policy、Hermes Queue、隔離 SBL 工作 | **不需要** |
| **OS-PROTECTED HOST**（例外） | 修改受保護的全機憑證、受限系統目錄、安裝真正需要提權的系統服務等 | **僅在操作本身確實需要時** |

兩種配置共用：

- 同一個 HGK Issuer。
- 同一個 WorkOrder／TaskSpec 契約。
- 同一套 Nonce／TTL／Scope 驗證。
- 同一套 SharedSpine。
- 同一個 B1 Completion Ledger。

**不同的是 OS 存取範圍，不是是否需要工作授權。**

**唯一 OWNER 的 B1 Standing Policy**

明確批准來源、工作目錄、Repo、EffectClass、期限及回復

**HGK 使用者層 Signer／Admission**

CurrentUser Key／受限簽發入口／公鑰驗證

**Hermes 普通使用者 Worker＋SharedSpine**

自施工、自排錯、自測試、Checkpoint、Restart

**獨立 Checker 執行受影測試及真實 Readback**

功能驗證與簽發身份分離；按實際隔離程度聲明保證等級

### 5.1 Signer 不需要 Administrator，但也不能變成普通的可編輯 Python 函式

最簡單且較安全的方案是：

HGK 在首次合法 OWNER 啟用時，建立一組使用者範圍的簽章金鑰，將公鑰及信任身份固定於版本化設定，由受限 Signer 執行簽發。

Hermes 提交精確 WorkOrder 後，Signer 先驗證：

`Owner Policy → Root → Subject SHA → EffectClass → WriteSet → Epoch → TTL → Nonce`

符合才簽發。HGK Receiver 再驗證公鑰簽章與實際工作效果權限。

**模型本身不持有私鑰，也不能任意修改 Signer 的授權政策。**

這樣既不需要 Windows Administrator，也保留 B1 所要求的 Native 授權語義。

但這裡必須避免另一種反向錯誤：若 Hermes／Maker 與 Signer 在同一 Windows 帳戶下執行，且 Maker 能直接修改使用者層信任檔案或存取私鑰，那麼單靠不同程序名稱就不能證明真正的安全隔離。

因此還需要實際的 Sandbox／能力限制，或經驗證的獨立服務／遠端身份；不能只把同一個程式拆成三個 PID，就宣稱符合最高強度的獨立 Principal 要求。

### 5.2 不必保留所有 r5 的特定實作限制

以下是我建議的最小修補範圍：

| 元件 | 修補方向 |
|--------|--------|
| `native-trust-maintenance.ps1` | 把 `elevated_admin` 要求限制在真正操作全機保護資源的模式 |
| `native_admission.py` | 增加經 OWNER 固定的使用者層 Trust Profile；不允許 WorkOrder 任意指定信任根 |
| CNG／Signing | 支援使用者層金鑰；沿用既有公鑰驗證，不強制全機 RSA |
| Registry | 使用者層 Registry 必須有可信任的 Root Pin、受限寫入與防替換驗證 |
| `owner_os_sid` | 區分 OWNER 授權來源與實際 Signer 角色 |
| Maker／Checker | 用真正不同的執行能力與簽章身份，並依實際 OS 隔離程度判定可信度 |

**不要用直接刪除全部 `PRINCIPAL_SEPARATION` 檢查來解決。**

應改成可由測試明確證明的職責隔離；如果只有邏輯角色不同、沒有有效的權限隔離，就必須降低該項獨立性聲明，而不是假裝已通過高保證驗收。

### 5.3 B1 文件是否也應修正？

**應修正，但只要極小範圍，不應重新設計整套 DOC-00～08。**

建議形成一份正式的 OWNER 架構修訂，明確規定：

1. `Native Issuer ≠ Windows Administrator`。
2. Owner Approval 可以採用版本化、具有效範圍的常設授權。
3. 使用者層 WorkOrder 預設不需要系統管理員。
4. OS 管理員只在實際受保護 Host 操作的權限需求成立時出現。
5. Checker 的獨立性應依可觀察的身份、憑證、執行環境與權限隔離判定，不能只比較角色名稱。
6. 既有 SourceFreeze、Oracle、Nonce、TTL、Readback、G-A、G-B 及全部驗收分母保留。

對正式 Source 契約而言，這涉及 DOC-00 的授權解釋、DOC-02／03 的 Effect／Permission 綁定，以及 DOC-05 的獨立驗收負例。應由唯一 OWNER 的版本化決議正式變更，不能讓 Hermes 默默忽略原有條款。

這是**修正不合理的權限前置**，不是把原生效果的真實性要求取消。

---

## 六、Hermes 應該如何驗證新方案真的解決問題？

我建議先完成一個不需要管理員、使用隔離測試工作區的最小端到端實驗。

| 測試 | 必須觀察到的結果 |
|--------|--------|
| 普通權限啟用 | 非 Elevated 程序建立合法的使用者層 Trust Profile |
| 正向簽發 | HGK 成功簽發符合 Standing Policy 的精確工作卡 |
| 無授權拒收 | 未簽發 Bundle 仍回 `ERR_NATIVE_BUNDLE_REQUIRED` |
| 簽章負例 | 錯 Subject、錯 Key、過期 TTL、重播 Nonce 全部拒收 |
| 跨角色隔離 | Maker 無法直接取得簽發私鑰或竄改 Checker Verdict |
| 工作效果 | Hermes 真正完成一張可逆 Repository Write 工作卡 |
| Readback | 實際工作樹、效果 SHA 與 Journal 一致 |
| 獨立驗證 | Checker 重新讀取原始效果並輸出可驗證 Verdict |
| OS 權限負例 | 工作卡試圖寫入未授權系統資源時正確拒收 |
| 重啟續工 | 不同程序從 Durable Checkpoint 接手下一卡 |

其中 **「跨角色隔離」是新方案最重要的安全測試**。如果使用者層信任檔案可以被同一 Maker 隨意覆寫，或 Maker 可以呼叫 Signer 為任意資料簽章，方案就不合格，不能因為免管理員而宣稱成功。

如果這條鏈路成功，即可證明：

**HGK 的一般 Native Coding WorkOrder 不需要 Windows Administrator，也能有真實簽章、准入、執行和驗證。**

但它仍只代表該測試主體的成功；尚不等於 G-A、三個 GWO 及 G-B 全部通過。

---

## 七、目前 r9 的阻斷應如何重新分類？

r9 把：

`NATIVE_TRUST_BOOTSTRAP_REQUIRED`

列為多個正式 Gate 的共同阻斷。

這個診斷指出 Trust 缺失是正確的，但過度把**信任尚未建立**與**必須取得管理員權限**視為同一件事。

應拆成：

| 原先 FirstFail | 更精確的新分類 | 處置 |
|--------|--------|--------|
| `NATIVE_TRUST_BOOTSTRAP_REQUIRED` | `USER_SCOPE_TRUST_NOT_ENROLLED` | 普通使用者權限即可施工與嘗試啟用 |
| `ERR_OWNER_ELEVATED_OS_PRINCIPAL_REQUIRED` | `UNNECESSARY_ADMIN_PRECONDITION`（對 User Scope） | 修改實作與相關測試 |
| 缺 Maker／Checker SID | `ROLE_ISOLATION_UNPROVEN` | 以實際身份／憑證／Sandbox 驗證隔離 |
| 全機保護資源確需修改 | `HOST_OS_PRIVILEGE_REQUIRED` | 只阻斷該 Host 效果工作 |
| Fabric 沒有 Loaded | `FABRIC_ACTIVATION_NOT_EVIDENCED` | 獨立修 R3 |
| 模型沒有 Served 收據 | `MODEL_SERVING_NOT_EVIDENCED` | 獨立修 R4 |

這樣做有兩個好處。

一是 Hermes 不會因為沒有 Administrator，就放棄本來在普通使用者權限下可完成的正式開發及簽發測試。

二是真正必須動用管理員的操作仍會被正確辨識，不會為了降低治理而越過 OS 權限邊界。

### 對 r9 現況的具體處置

r9 目前的 SharedSpine、跨 PID Dispatcher 與每五分鐘排程觸發器，已經證明可以在普通使用者層完成相當多工作。fileciteturn137file4L23-L35

因此沒有理由先將 `HGK-B1-R9-Dispatch` 改成管理員 Windows Service 才能繼續。

我建議優先次序調整為：

1. **先修 HGK 的 User-scoped Native Trust Profile**，用普通權限證明完整正向簽發。
2. 並行處理 PIPD 最新 CI 回歸、Fabric R3 真實活化和 R4 模型車道 Served。
3. 將既有 SharedSpine Dispatcher 接到真正 Hermes 執行入口，保持普通權限與可復原性。
4. 在具備實際簽發、讀回及 Checker 後，進入 T2、R1～R4、G-A、三 GWO、G-B。
5. 只有某張特定 Host WorkOrder 真的涉及 Windows 保護資源，才為那一張工作卡啟用正常的較高 OS 權限流程。

---

## 八、工程責任與治理收斂的正式裁決

| 鑑定問題 | 最終答案 |
|--------|--------|
| HG-KSEOS 作為 Coding Factory，需要 Windows Administrator 嗎？ | **一般不需要** |
| Native WorkOrder 簽發一定要 Administrator 嗎？ | **不需要，可以採使用者層簽章與受限授權** |
| 現有 HGK 為何硬性要求 Administrator？ | **r5 的 Trust Maintenance 實作選擇了全機憑證／ACL 架構** |
| 這是 Windows 本身的限制嗎？ | **不是一般限制；只對特定受保護 OS 操作成立** |
| 是 B1 DOC-00～08 明文規定的嗎？ | **沒有發現全機管理員簽發的明文要求** |
| B1 是否也有治理過重的可能？ | **有；若把正式 Native Gate 無差別套用於全部一般 Coding 操作，就屬過度套用** |
| 之前的 Prompt 是否有設計錯誤？ | **有；過早接受 r5 的 Admin-only 前提，未先驗證 User Scope 可行性** |
| 應否取消全部簽章和 Checker？ | **不應；應保留有效、可測量的應用層控制** |
| 是否可以取消一般工作的人類重複簽核？ | **可以，改為單一 OWNER Standing Policy** |
| 現在能否直接 Native PASS？ | **尚不能；必須先完成新配置的正向驗證與正式 Gate** |

### 我的最終建議

**停止把 Windows Administrator 視為 HG-KSEOS 一般 Native Coding Factory 的必要條件。**

應直接修正 r5 所引入的 **Admin-only Trust Implementation**，建立具有明確使用者層作用域的 HGK Native Signer／Verifier，使單一 OWNER 的常設授權能在普通使用者權限下自動轉化為真正的短期 WorkOrder Permit。

同時保留可驗證的簽章、Nonce、TTL、Root／WriteSet 限制、實際效果讀回及獨立驗收。若 Maker 與 Checker 仍共享不受限制的同一 OS 身份，則須補上真正的隔離機制，或者明確將其標示為較低保證等級，不能冒充高保證的獨立 OS Principal。

對真正需要安裝全機服務或修改 Windows 受保護資源的特定 Host 工作，再按其實際權限處理；**不應讓少數 Host 操作的提權需求，變成整個 B1 所有 WorkOrder 的共同前置。**

因此本輪的正式工程裁決為：

`REMOVE_UNNECESSARY_WINDOWS_ADMIN_DEPENDENCY`

`ADOPT_USER_SCOPED_NATIVE_TRUST_AS_DEFAULT`

`KEEP_SINGLE_HGK_ISSUER_AND_SCOPED_SIGNATURE_VERIFICATION`

`REQUIRE_PROVEN_CHECKER_ISOLATION_FOR_FORMAL_ACCEPTANCE`

`OS_ELEVATION_ONLY_FOR_ACTUAL_PROTECTED_HOST_EFFECTS`

`CONTINUE_B1_NATIVE_ACCEPTANCE_AFTER_REAL_POSITIVE_CHAIN`

**這比繼續新增管理員 Broker／常駐服務，更符合你要求的專業工程實務：先移除不必要的技術前置，再以最小、可測試、可回復的方式保留真正需要的控制。**

---
Powered by [AI Exporter](https://saveai.net)