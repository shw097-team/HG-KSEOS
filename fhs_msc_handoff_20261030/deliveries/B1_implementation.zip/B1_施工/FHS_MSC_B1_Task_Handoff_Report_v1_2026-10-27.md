# 任務交接報告（Task Handoff Report）

- **交接版本：** v1
- **產出時間：** 2026-10-27 14:10 +08:00
- **適用範圍：** 本篇對話的 FHS-MSC B1 Bootstrap/Repair／PIPD-LS-PKG、Hermes r7–r10、前序 Codex r3–r6、HG-KSEOS／Fabric／SBL／PIPD-LS-SP、PIPD P4 Skills 與 DOC-00～09 之分析、修補、證據、GitHub 候選及正式 Native 驗收。
- **交接對象：** 新對話 GPT（接手執行）。
- **資料與確信慣例：** `OBSERVED`＝本交接輪有實際工件位元或已讀 GitHub 回應；`REPORTED`＝Hermes 報告稱已在其 Windows Host 執行，但本交接環境無法重現；`DECIDED`＝對話中的工程裁決，不等於工具已施作；`MISSING`＝缺必要工件／定位；`UNVERIFIED`＝定位已知但未能獨立核實。**GitHub 狀態僅以本對話 2026-10-27 的末次查核為準，不保證新對話時仍相同。** [定位：本對話〈FHS-MSC B1 r10｜高自動化停工根因…鑑定報告〉§2–§10；`B1_HERMES_R10_EXECUTION_AND_NATIVE_ACCEPTANCE_REPORT.md` L1–17、L57–87；本交接輪所列 GitHub PR URL。]

## 0) TL;DR（30 秒接手）

1. **DoD：** 在唯一人類 OWNER 的有界 Standing Authorization 下，使 Hermes 自動執行與恢復受限施工；完成 B1 **適用 Required＋已觸發 Conditional**，T2、R1～R4、G-A 六項合取、GWO-FABRIC／HGK／SBL、G-B（撤銷外援後由新 OS Process 自主續行）且有真正 Issuer、Policy Loaded、模型 Served、效果 Readback、獨立 Checker、可驗算封存。`Commander-SP` 全程禁用。[定位：`FHS_MSC_B1_Hermes_UserScoped_Native_Autonomous_Thin_Command_2026-10-27_r10.md` §0、§4–§6；`FHS_MSC_B1_PIPD_LS_PKG_00_GOVERNANCE_AND_CONTROL.md` §4；`FHS_MSC_B1_PIPD_LS_PKG_08_GOLDEN_WORKORDERS_E2E.md` §1–§4。]
2. **最新正式結果：** r10 `PARTIAL_WITH_EXPLICIT_HOLDS`、`native_artifact=false`；Gate T1 PASS（沿用 r9），R1/R2 PARTIAL，T2/R3/R4/G-A/三 GWO/G-B BLOCKED；逐 ID Native PASS **0**；`handoff_status=HOLD`、`signed_receipt=null`。**未完成 B1。** [定位：`B1_HERMES_R10_EXECUTION_AND_NATIVE_ACCEPTANCE_REPORT.md` L3–5、L57–81；`B1_HERMES_R10_HANDOFF_RECEIPT.json` `handoff_status/signed_receipt`。]
3. **實作進度：** r10 修好 PIPD CE-2 共用欄位定義，PR #20 HEAD `abeae2512e5f…`，遠端 `offline-gate` success；HGK 本地 `user_trust.py` commit `de37c48`，使用者層 DPAPI/Ed25519 七測通過但**尚未接 Receiver／未推送到 #2**。[定位：`B1_HERMES_R10_EXECUTION_AND_NATIVE_ACCEPTANCE_REPORT.md` §2–§4；[PIPD PR #20](https://github.com/shw097-team/PIPD-LS-SP/pull/20)；[CI Run 40450463928](https://github.com/shw097-team/PIPD-LS-SP/actions/runs/40450463928)；[HGK PR #2](https://github.com/shw097-team/HG-KSEOS/pull/2)。]
4. **目前最短技術線：** 將 HGK `user_trust` 的 *可信 Profile 選擇* 接到 `native_admission.REGISTRY` 與現役 Receiver，以已簽 Bundle 做正反例與 Readback；原 Candidate 的 Receiver 仍讀 `%ProgramData%`，未有端到端 Admission PASS。[定位：`B1_HERMES_R10_EXECUTION_AND_NATIVE_ACCEPTANCE_REPORT.md` §4；`B1_HERMES_R10_RESUME_CHECKPOINT.json` `next_in_order[0]`；GitHub HGK PR #2 `src/hg_kseos/native_admission.py`。]
5. **不能只修簽發：** Fabric Activator R3、三車道真調用 R4、Hermes Executor 入口在 r10 **NOT_RUN**，不是已證實不可用；SharedSpine 18/18 與 r9 OS Scheduled Task 證明的是派工原語／獨立觸發，**不是 Hermes Native Loop**。[定位：`B1_HERMES_R10_EXECUTION_AND_NATIVE_ACCEPTANCE_REPORT.md` L73–81；`B1_HERMES_R9_EXECUTION_AND_NATIVE_ACCEPTANCE_REPORT.md` §2、§6。]
6. **自治的直接失效：** Hermes 自述未用 `todo_list`／沒有可恢復的實際工作卡，Context 壓縮、`Native HOLD→停工`、交付 Seal 被誤當結束訊號；r10 先封存而 R3/R4/Executor 未跑。其因果推論為 `LIKELY`，具體 `NOT_RUN` 是可驗事實。[定位：`B1_SESSION_STOP_ROOT_CAUSE_REPORT.md` RC-1～RC-7；`B1_HERMES_R10_任務回報.md` L51–123；r10 report §1、§6。]
7. **唯一 Queue 與禁令：** SharedSpine 是唯一持久權威；`WORK_QUEUE.json` 若產出只能為可重建的視圖，**不得另建第二個 Queue/Issuer**；`sbl-commander-sp` 禁止安裝／載入／呼叫／依賴，DOC-08 `plan.propose` 的合法替代 ABI 還需查證／必要時修補。[定位：`FHS_MSC_B1_PIPD_LS_PKG_00_GOVERNANCE_AND_CONTROL.md` §6；`FHS_MSC_B1_PIPD_LS_PKG_08_GOLDEN_WORKORDERS_E2E.md` L17、L31；r10 command §0、§4；本對話〈r10 根因鑑定〉§4、§8。]
8. **PIPD 尚有兩個不同問題：** PR #20 offline CI 綠，`public-plugin-verify` **仍 FAIL**；原始 Run 日誌拒絕 ADR-0008/0009 超出 Stage-C WriteSet，**不是**僅 `resolved-deps.txt` 的上傳警告。P4 Skill 的 Oracle `DOC-03 DOMAIN_ORACLES` 與 DOC-07 Canonical、DOC-06 12 軸對 Plugin 9 軸、TQAEP 設計／Live Receipt 混用屬已識別相容性風險。[定位：[Run 40450464119](https://github.com/shw097-team/PIPD-LS-SP/actions/runs/40450464119)／Job `122011714859`；`pipd-pi-compile/skill.md`；`pipd-profile-tailor/skill.md`；`pipd-assurance-tqaep/skill.md`；本對話〈PIPD-LS-SP 與 B1 高自動化失效〉§4–§5。]
9. **最高風險／防線：** 不可把 User-scoped 軟體金鑰與同一 Windows SID 的三個 PID 當作獨立 Principal；不能用 CI 綠、配置 SHA、Scheduler 訊號代替 Signed Admission／Host Loaded／Served／World Effect／Checker。不能用文字代簽數位簽章。一般工程可持續，真正缺 Permit 的受影 Host 效果 PARK。[定位：r10 report §3–§6；`FHS_MSC_B1_PIPD_LS_PKG_00_GOVERNANCE_AND_CONTROL.md` §4；本對話〈單一 OWNER 全自動授權方案〉§3–§6。]
10. **接手決策：** 優先新、精簡的 Hermes Session，先做 SharedSpine READY/Lease→Hermes 真 Executor→重啟續工的最小閉環，同步 HGK Receiver 接線／R3/R4 與 PIPD Stage-C；Codex **只作有界補丁 Worker**，不全面退回；B1 DOC-00～08 只做有版本的**薄執行投影收斂**，不重寫整包、不移除正當驗收 Gate。[定位：本對話〈r10 高自動化停工根因…鑑定報告〉§6–§11；〈PIPD-LS-SP 與 B1 高自動化失效〉§8–§10。]

## 1) 任務背景與範疇鎖定（Scope Lock）

### In-Scope

- 對本地 `HG-KSEOS`、`Fabric`、`SBL`、`PIPD-LS-SP` 與 Hermes 自治續航進行現況復核、修補、隔離／現役測試、必要 PR 合併審查及實際 Host Readback；讀既有 r10 checkpoint，不從 r1 重啟。[定位：r10 command §1–§4；`B1_HERMES_R10_RESUME_CHECKPOINT.json`。]
- B1 DOC-00～08 的適用 Required 與已觸發 Conditional：SourceFreeze、TaskKind、Oracle Ratification、PIPD Effectful Compiler、HGK Issuer／Receiver、Hermes Fair Durable Queue／Executor、Fabric Stage→Active→Loaded、三模型 Lane、實際 Mandatory Methods、獨立 Checker、G-A、三 GWO、G-B。[定位：B1 DOC-00 §4；DOC-07 §1–§3；DOC-08 §1–§4；r10 command §4–§5。]
- 一位人類 OWNER 的常設有界授權：普通 Repo／測試／隔離合成資料工作免重複 HITL；Issuer、Checker 各須真實能力／適用權限；Host 全機提升權限**僅**對真正受保護 OS 效果使用。[定位：本對話〈單一 OWNER 全自動授權與 Native 驗收鏈路修復方案〉；〈HGK 為何要求 Windows 管理員？〉§5–§7；r10 command §0。]
- PIPD P4 八 Skills、PIPD DOC-00～09 的**受影介面**驗證（Oracle ABI、Profile Axes、TQAEP Design vs Live、ECP Retry vs Engineering Iteration），以及 B1 Package 的有版本薄型執行契約收斂。[定位：本對話〈PIPD-LS-SP 與 FHS-MSC B1 高自動化失效〉§3–§9；P4 `pipd-*` SkillContracts。]

### Out-of-Scope

- **完全禁用** `sbl-commander-sp`／Commander-SP：不安裝、不載入、不作 Proposal／Signer／Checker／工作入口；替代 ABI 必須找到或合法修補，不能偽稱存在。[定位：r10 command §0、§4；B1 DOC-08 L17、L31。]
- 不增加第二個 HGK Issuer、第二套 Queue、第二個 Canonical Source Writer；不全面重寫 PIPD DOC-00～09 或 B1 DOC-00～08；不全面回退 Codex，也不預設安裝 Administrator Service。[定位：B1 DOC-00 §6；本對話〈r10 根因鑑定〉§6–§8、〈PIPD 與 B1 失效〉§8。]
- 不造假 OS Token、簽名、USER 同意、不同 Principal、Host Loaded、模型 Served、驗收 PASS；不對既有私人資料作未限定的修改；不將 Deferred 當成 B1 必裝清單。[定位：r10 command §0、§4–§5；B1 DOC-08 §3；r10 ledger `class_totals_*`。]

### DoD／Acceptance（必須逐項有實體定位）

1. 新 Session 可從**唯一 SharedSpine** READY 卡與合法喚醒入口讀回依賴、Claim Lease、真 Hermes 執行、Checkpoint、跨 Process 恢復；若 Runner 過早封存而 READY>0，測試必拒絕 `MISSION_COMPLETE`。[定位：r9 report §2；r10 report R2；本對話〈r10 根因鑑定〉§8–§9。]
2. HGK User Trust 的最小適用 Profile 被**實際 Receiver**採用；正向 Bundle Admission＋篡改／Nonce／TTL／Revoke／Policy／Principal 負例；不得把 `USER_SCOPED_SOFTWARE_KEY` 冒充高保證 SoD。[定位：r10 report §3–§4；r10 checkpoint `next_in_order[0]`。]
3. Fabric 真 Stage、Active、Loaded、Consumer 同一 Policy SHA／Epoch，各自 RAW；三 Lane (`PLAN`/`EXECUTE`/`VERIFY_SECURITY`) required=served；PIPD Oracle／Stage-C 權威與 CI 受影負例閉合。[定位：B1 DOC-00 §4；DOC-08 §1；r10 report §6；PIPD Run 40450464119。]
4. G-A 六項合取，GWO-FABRIC/HGK/SBL 三域各自獨立效果；G-B 先 Revoke 外援，後在**另一 OS Process／Session**由 Native 自主觸發、舊 Token 重入拒收、零殘留。[定位：B1 DOC-00 §4；DOC-08 §1–§4。]
5. 四庫實際 Host Import/Loaded、受影 CI、HEAD／PR currentness 與 RAW 對齊，r10 原始 1,565 身份分母保存：Required 625、Conditional 285、Deferred 655；只把符合條件的身份關閉。[定位：r10 ledger `denominators/axis_totals`；r10 command §5。]
6. 最終可重算 Manifest＋外部 Seal＋真 Signed Receipt／AO Verdict＋Handoff；**若缺任一 DoD，`NATIVE_ACCEPTED` 不成立**，但不妨礙無關 READY 卡施工。[定位：r10 report §7；r10 handoff `signed_receipt:null`；B1 DOC-00 §4。]

## 2) 現況總覽（Current State Dashboard）

> 此表的 `PASS` 僅表示欄內明示的最小測試通過，**不能跨欄升格正式 Native Gate**。時間上限：本對話 r10 工件觀測 `2026-10-27 12:38:10 +08:00`，GitHub 遠端查核為本篇對話 2026-10-27 的最後一次觀測。[定位：r10 report L3–5；本篇先前 GitHub 檢查對話。]

| 項目 | 當前狀態 | 直接證據（locator） | 影響 | 備註 |
|---|---|---|---|---|
| 全 B1 Native Acceptance／G-B | **FAIL** | r10 report L3–5、L57–71；handoff `HOLD` | 不得交接 | 0 Native PASS |
| r10 主要四檔 SHA、Seal | **PASS** | `B1_HERMES_R10_RAW_EVIDENCE_MANIFEST.json` entries 1–4；`...MANIFEST_SHA256.txt` | 交接可採信其位元 | Manifest 共 9，其他 5 原始位元 MISSING |
| T1 SharedSpine 基礎耐久 | **PASS** | r8 report §1–§2；r9 report §2；r10 report L61 | 可復用技術成果 | r10 沿用非重測 |
| R2 Hermes 真 Native Loop | **FAIL** | r10 report L64、L73–80 | 持續自治缺口 | 排程觸發 ≠ 真 Hermes Executor |
| r9 測試 Scheduled Task 保留 | **UNVERIFIED** | r10 task report §3、`TRIGGER_REMOVAL_RECEIPT.json` 於 Manifest 路徑 | 喚醒能力須重新查 | Hermes 稱已刪，該原始收據未上傳 |
| HGK User Trust 隔離鏈 | **PASS** | r10 report L35–49／ledger `HGK_USER_TRUST` | 技術候選可用 | 同 SID 私鑰隔離未證明 |
| HGK Receiver 正向 Admission | **FAIL** | r10 report L51–55、L62–63 | T2/R1 阻斷 | `REGISTRY` 仍 ProgramData 常數 |
| HGK User Trust 遠端 PR 整合 | **UNVERIFIED** | HGK PR #2 HEAD `70147a5…`；`user_trust.py` 遠端 404（先前查核） | 本機 commit 不等於 PR 已有 | Local `de37c48` 仍需真樹核對 |
| Fabric PR #18 程式碼修補 | **PASS** | r9 report §4；[Fabric PR #18](https://github.com/shw097-team/Fabric/pull/18) HEAD `a65231c…` | 進 R3 前置 | 表示候選分支修補非 Host Loaded |
| R3 Stage→Active→Loaded | **FAIL** | r10 report L65、L78；B1 DOC-08 §1 | G-A、GWO-Fabric 無法過 | r10 `NOT_RUN` |
| R4 三車道實調 | **FAIL** | r10 report L66、L79；r8 report §3 | G-A 不成立 | Config pin ≠ Served |
| SBL PR #13 Atomic Save | **PASS** | [SBL PR #13](https://github.com/shw097-team/SBL/pull/13)；[Run 40427153912](https://github.com/shw097-team/SBL/actions/runs/40427153912) | 程式候選可用 | GWO-SBL 未做 USER 效果 |
| PIPD PR #20 CE-2 offline-gate | **PASS** | [Run 40450463928](https://github.com/shw097-team/PIPD-LS-SP/actions/runs/40450463928)；r10 report §2 | 回歸已修 | 另有 Stage-C 失敗 |
| PIPD public-plugin-verify | **FAIL** | [Run 40450464119](https://github.com/shw097-team/PIPD-LS-SP/actions/runs/40450464119) Job `122011714859` | 不可發布級升格 | ADR-0008/0009 WriteSet |
| T2／G-A／三 GWO／G-B | **FAIL** | r10 report L62、L67–71；DOC-00 §4 | 正式 Native 未達 | 真 Raw／Checker 不齊 |
| PIPD P4 Oracle ABI | **TEMP_CLOSED** | `pipd-pi-compile/skill.md`、PIPD DOC-07；PR #20 Oracle Adapter | 正式 Ratification 未達 | 已有相容候選但未簽發 |
| PIPD 12 軸→9 軸 Profile | **UNVERIFIED** | PIPD DOC-06 §5；`pipd-profile-tailor/skill.md` | 無映射可能拒收或降風險 | 尚無本輪正式 Mapping 測試證據 |
| DOC-08 非 Commander Proposal | **MISSING** | B1 DOC-08 L17、L31；r10 command §4 | GWO-HGK 入口未證 | 不得用 Commander-SP |
| 625 Required 工程軸 | **FAIL** | r10 ledger `axis_totals.engineering.BLOCKED_HELD=625` | 掩蓋已驗修補進度 | 應只針對有映射的身份更新 |
| 任務停止／持久 READY 控制 | **FAIL** | `B1_SESSION_STOP_ROOT_CAUSE_REPORT.md` RC-1～RC-4；r10 `NOT_RUN` | 每輪過早交付 | 是直接續航問題 |

## 3) 時間線（Timeline）

> 對話缺少具體時間者**不得創造 HH:MM**；一律寫「時間 MISSING」。外部 GitHub `updated_at` 是 PR 更新時間，**不是** Host 測試發生時間。r9 的 `04:10Z` 有固定 Emission 時鐘背景，不能充作全部事件真實發生時刻。[定位：r9 report §7；本對話 r9 SHA 封存分析。]

- **2026-10-07，時間 MISSING（+08:00）** — PIPD DOC-00～09 r2 文件日期；定義 Canonical Writer、Admission、Profile、Oracle、TQAEP、Release Claims；對 B1 是前置契約，不是 Hermes Runner。[定位：`PIPD_LS_DOC-00_2026-10-07_r2_...md`～`PIPD_LS_DOC-09_2026-10-07_r2_...md` 的檔名／Metadata；DOC-01 §2、DOC-05 Admission、DOC-08 §1。]
- **2026-10-26，時間 MISSING（+08:00）** — B1 DOC-00～08 r3 Source 設計版本與三 Golden WO 契約保留；`task_kind: DESIGN / claim_ceiling: AUTHOR_SIDE_REPAIR_CANDIDATE / formal_sourcefreeze: HOLD`。[定位：B1 DOC-00 L1–15；DOC-08 L1–17；`FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_藍圖(1).md`。]
- **2026-10-27 08:33:19 +08:00** — SBL PR #13 GitHub `updated_at`，Atomic Save 修補候選，稍後 CI Run 40427153912 success。[定位：[SBL #13](https://github.com/shw097-team/SBL/pull/13)、[Run 40427153912](https://github.com/shw097-team/SBL/actions/runs/40427153912)。]
- **2026-10-27 08:37:23 +08:00** — HGK PR #1 GitHub `updated_at`，Native Admission/Trust candidate；PR #2 以 #1 為 Base，存在堆疊相依。[定位：[HGK #1](https://github.com/shw097-team/HG-KSEOS/pull/1)、[HGK #2](https://github.com/shw097-team/HG-KSEOS/pull/2)。]
- **2026-10-27 09:45:13 +08:00** — r6 Codex Native Acceptance 報告 `PARTIAL_WITH_EXPLICIT_HOLDS`，Issuer／Oracle／Policy Loaded／三車道／AO 未閉合，五個 PR 候選。[定位：`B1_NATIVE_FINAL_ACCEPTANCE_REPORT.md` L1–4、§四庫／修補候選、§現役讀回、§Required Gate。]
- **2026-10-27 10:35:42 +08:00** — r7 Hermes `PARTIAL`；HGK Overlay 63 測試、路由 `ROUTE_SOURCE_PIN_STALE` 修補候選，但 T1 Durable ACK 尚無正式證據，T2～G-B BLOCKED。[定位：`B1_R7_00_INDEX_AND_SUMMARY.md` L1–8；`B1_R7_01_FULL_TASK_REPORT.md` §5–§9。]
- **2026-10-27 11:30:01 +08:00** — r8 SharedSpine 18/18 跨進程、HGK 11 檔 commit `0d3622e` 63 PASS、SBL 3 PASS、Route Pin rev35/epoch34；Fabric／PIPD 本地 32／44 行差異未合。[定位：`B1_HERMES_R8_EXECUTION_AND_NATIVE_ACCEPTANCE_REPORT.md` §1–§4、§5。]
- **2026-10-27 11:54:00 +08:00** — Fabric #18 更新至 `a65231cd…`（遠端 `updated_at`），PR Draft 未合併；Hermes 回報三方合併與 5 tests。[定位：[Fabric #18](https://github.com/shw097-team/Fabric/pull/18)；r9 report §4。]
- **2026-10-27 11:54:32 +08:00** — HGK #2 更新至 `70147a5e…`（遠端 `updated_at`），修 CP950 Thread 讀取候選；尚無遠端 CI。[定位：[HGK #2](https://github.com/shw097-team/HG-KSEOS/pull/2)；r9 report §4。]
- **2026-10-27 12:10:00 +08:00（固定報告時間，不等同完整事件的獨立真實時刻）** — r9 Fabric/PIPD/SBL/HGK 候選整合、PR 快進；HGK Trust `Inspect` registry false、`SelfTest` 5/5；兩 PID durable dispatcher + per-user Task Scheduler 自動觸發；r8 Manifest Errata 修正（65 entries、外部 Seal）；R2 PARTIAL。[定位：`B1_HERMES_R9_EXECUTION_AND_NATIVE_ACCEPTANCE_REPORT.md` §1–§8；`B1_HERMES_R9_MANIFEST_SHA256.txt`。]
- **2026-10-27 12:34:16 +08:00** — PIPD #20 更新到 `abeae251…`（PR `updated_at`），修復 r9 合併導致 `NON_RECORD_SIDECARS` 消失之 CE-2 回歸。[定位：[PIPD #20](https://github.com/shw097-team/PIPD-LS-SP/pull/20)；r10 report §2。]
- **2026-10-27 12:34:19 +08:00** — PIPD 新 HEAD 離線 CI success，但 public-plugin-verify Failure；實際 WriteSet 與 ADR-0008/0009 有衝突。[定位：[CI 40450463928](https://github.com/shw097-team/PIPD-LS-SP/actions/runs/40450463928)、[Verify 40450464119](https://github.com/shw097-team/PIPD-LS-SP/actions/runs/40450464119)，Job `122011714859`。]
- **2026-10-27 12:38:10 +08:00** — r10 觀測：PIPD CE-2 FIXED、HGK User Trust 7 tests（本地 `de37c48`）；R3/R4/Executor NOT_RUN；撤除 r9 測試 Trigger（只據 Hermes 報告）；Native/Handoff 仍 HOLD；r10 Manifest 9 entries、外部 Seal。[定位：r10 report L1–87；handoff；resume；`B1_HERMES_R10_RAW_EVIDENCE_MANIFEST.json`。]
- **2026-10-27，時間 MISSING（+08:00）** — 後續對話技術裁決：PIPD P4 介面差異、B1 Design/Runtime 投影、過早交付與 SharedSpine READY 停工規則；**這是分析／決策，非已在 Windows 執行**。[定位：本對話〈r10 高自動化停工根因…鑑定報告〉§4–§11；〈PIPD-LS-SP 與 B1 高自動化失效〉§3–§10。]

## 4) 已完成工作（What’s Done）

> `REPORTED` 的 Host 測試不可憑文字報告升為本交接環境的獨立 `OBSERVED`。每項均保留未證明的邊界。

### 4.1 r6／r7：原始設計分母與 HGK／路由缺陷定位

- **做了什麼：** r6 建立正式 Native Gate／工作身份追溯、識別 HGK Trust、Fabric Source Pin、PIPD Oracle 與 PIPD CLI 缺口；r7 HGK PR1+PR2 先 RED 後補齊而 63/63，發現 `ROUTE_SOURCE_PIN_STALE`。[產出：`B1_NATIVE_FINAL_ACCEPTANCE_REPORT.md`、`B1_NATIVE_COMPLETION_LEDGER.json`、`B1_R7_01_FULL_TASK_REPORT.md`、`B1_R7_02_CONSTRUCTION_EVIDENCE.md`；驗證：隔離測試／文件；Native Acceptance NO；定位：r6 report §§完成與驗證／Required Gate，r7 report §§5–8。]
- **Do not repeat：** 不再把 r6 的 `HKLM` 探測當唯一 Registry 真相；後續候選實際指定 `%ProgramData%`，r10 User Trust 則指定 `%LOCALAPPDATA%`，須以現役 Profile 解析為權威。[定位：r8 report §7；r10 report §3–§4；[HGK #2](https://github.com/shw097-team/HG-KSEOS/pull/2) `native_admission.py`。]

### 4.2 r8：來源已落地但不等於 Host Loaded

- HGK PR1+PR2 本地 commit `0d3622e`，11 檔 `+1190/-20`、`63 passed/28 subtests/0 warnings`；SBL Atomic Save 3 tests；SharedSpine 18/18 與跨進程 ACK；Route Pin rev35/epoch34 正負／回復測試。[產出：r8 Report／Ledger／Checkpoint；定位：`B1_HERMES_R8_EXECUTION_AND_NATIVE_ACCEPTANCE_REPORT.md` §1–§4。]
- Fabric `FABRIC/fabric/consumers/hgk_policy_consumer.py` 32 行、PIPD `src/pipd_ls_sp/pipeline.py` 44 行 Base/Local 差異，r8 因精確前像不同而回退，非 Native Gate 實際拒收。[定位：r8 report §1、§9。]

### 4.3 r9：三庫 PR 快進、派工驗證與封存修復

- Fabric 本地 `fffcb98` → PR #18 `a65231cd…`，三方 `_fabric_root` 保留 REC07 fail-closed，5 tests；PIPD 本地 `513e81e` → #20 `e716ed6…`，12 tests（其後被 r10 修復 CE-2）；SBL 本地 `826ca06` → PR #13 已相同（不造假推送）；HGK #2 → `70147a5…` 編碼修補 63 tests。均報告 fast-forward/no-force。[定位：r9 report §4；PR URLs 見 §7.1。]
- `hgk_dispatch.py` typed Adapter 共用 SharedSpine，不建第二 Queue；兩 PID 接手、停阻 A 而 B/C 續行、Task Scheduler 觸發 `WO-REQ-TASK` VERIFIED；**這是 Durable Dispatcher 測試，未證 Hermes Native Executor**。[產出：`var/B1-HERMES-R9/dispatch/` 與日誌/ACK（原始檔在本交接附件中 MISSING）；定位：r9 report §2、r10 handoff `durable_queue_ack`。]
- r8 Manifest 先封存後修改造成四筆 SHA 差異；r9 Errata 保留舊位元、修正先寫報告再 Manifest、外部 Seal；r9 Manifest 65 entries（非全部位元上傳）。[定位：r9 report §7、`B1_HERMES_R9_RAW_EVIDENCE_MANIFEST.json`／Seal。]

### 4.4 r10：兩項實作、一項清理、三項未執行

- PIPD CE-2：恢復 `from .validate import HASH_EXCLUDED_FIELDS, NON_RECORD_SIDECARS`；受影 9 tests，Windows 本地完整套 `634 passed/32 skipped/1 failed`（Foreign CWD 失敗據報在原 HEAD 也重現）；遠端 `offline-gate` success，PR #20 HEAD `abeae251…`；**Public Plugin Verify 仍 FAIL**。[定位：r10 report L19–33；[PR #20](https://github.com/shw097-team/PIPD-LS-SP/pull/20)、[Run 40450463928](https://github.com/shw097-team/PIPD-LS-SP/actions/runs/40450463928)、[Run 40450464119](https://github.com/shw097-team/PIPD-LS-SP/actions/runs/40450464119)。]
- HGK User Trust：`src/hg_kseos/user_trust.py` 本地 commit `de37c48`；`%LOCALAPPDATA%\HG-KSEOS\native-admission` Ed25519 + DPAPI CurrentUser、七項正反鏈；`assurance_level=USER_SCOPED_SOFTWARE_KEY`，非高保證 Principal 隔離；**遠端 PR #2 不含此檔**。[定位：r10 report L35–55；`B1_HERMES_R10_HANDOFF_RECEIPT.json` `side_effects`；[HGK #2](https://github.com/shw097-team/HG-KSEOS/pull/2)。]
- r9 Scheduled Task `HGK-B1-R9-Dispatch` 據報已刪，避免持續修改 Frozen Evidence；`TRIGGER_REMOVAL_RECEIPT.json` 已在 Manifest 列名，但**未上傳實體位元，Host 現況 UNVERIFIED**。[定位：`B1_HERMES_R10_任務回報.md` §3；r10 Manifest `TRIGGER_REMOVAL_RECEIPT.json`。]
- r10 `FABRIC_R3`、`R4_LANES`、`HERMES_EXECUTOR`＝`NOT_RUN`；**不准描述為「已試過而遭 OS 拒絕」**。[定位：r10 report L9–17、L76–81；r10 ledger `work_items`。]
- 封存自驗：r10 Manifest 共九筆、其中上傳四筆位元／長度／SHA 均一致；外部 Seal 摘要 `820f3d9eedf0431f88fc1c146731e8509b486d3a6aa6d688ea4ad4cc2a3f211b` 與 Manifest 相符。剩餘五筆原始檔未同時上傳；**九筆全量獨立重算 MISSING**。[定位：`B1_HERMES_R10_RAW_EVIDENCE_MANIFEST.json`、`B1_HERMES_R10_MANIFEST_SHA256.txt`；本交接環境對上傳檔的 SHA 比對。]

## 5) 已知問題與根因假說（Known Issues & Root-Cause Hypotheses）

### KI-01｜Hermes 中途停工／缺自治 Runtime

- **現象／影響：** r7～r10 每輪 `PARTIAL`＋交付；r10 Fabric R3／R4／Executor 未測試；r9 有 OS 觸發，r10 移除測試 Task，未證有正式替代喚醒。[定位：r9 report §2；r10 report §§1、6；`B1_SESSION_STOP_ROOT_CAUSE_REPORT.md` RC-1～RC-4。]
- **假說（按可信度）：** (高) 計畫只在 Context、沒用 `todo_list`／持久 READY；(高) 把 Native HOLD 當停止、Seal 當完工；(中) Context Compaction 歷史 HOLD 加強行為；(中) 指揮篇幅與 B1 大表增加 Context 壓力；(中) 尚缺 Hermes 真 Executor／外部喚醒結構。[定位：`B1_SESSION_STOP_ROOT_CAUSE_REPORT.md` RC-1～RC-7；本對話〈r10 根因鑑定〉§4–§5。]
- **反證／待驗：** 若新 Session 同 Subject 的持久 READY→Hermes 入口→Crash/Restart→自動下一卡測試 PASS，則「無續航能力」已解除；若具備 READY＋Watcher 而仍提前封存，則模型停止決策仍為主要因素。**狀態：`CONFIRMED`（提前停工／缺入口證據），`LIKELY`（原因組合）。**[定位：r10 report L76–81；`B1_SESSION_STOP_ROOT_CAUSE_REPORT.md` §8。]

### KI-02｜HGK User Trust 已通，但 Receiver／Trust SoD 未通

- **現象／影響：** Profile 是 `%LOCALAPPDATA%`，Receiver `REGISTRY` 常數仍 ProgramData；T2/R1 FAIL/PARTIAL；同 Windows SID 下 DPAPI 不能證明 Checker 獨立。[定位：r10 report §§3–5；GitHub HGK #2 `native_admission.py`。]
- **根因：** (高) 正向 Profile→Registry Resolver 尚未接線；(高) User-scope key 的保證級別不足以自證獨立 Principal；(中) 原 r5 的 Admin-only 全機簽發配置被過度當通用需求。[定位：r10 report L35–55；本對話〈HGK 為何要求 Windows 管理員？〉§1–§5。]
- **反證／待驗：** Signed Bundle 經現役 Receiver Admit 且篡改／Revoke／Nonce/TTL 拒收、Maker 無法換 Trust Anchor／解保護 Signer 私鑰且 Checker 身分可獨立驗證。**狀態：`CONFIRMED`（未接線），`UNVERIFIED`（合格隔離方案）。**

### KI-03｜Fabric R3 無真 Activator／Loaded/Consumer ACK

- **現象／影響：** PR #18 是 Consumer Inspect 語義，不等於 Stage→Active→Loaded；r10 `NOT_RUN`。GWO-Fabric/G-A 不成立。[定位：r9 report §4；r10 report L65、L78；B1 DOC-08 §1。]
- **假說：** (高) 未展開受影探索；(未知) 現役 Activator 是否可調／有效 Permit 是否存在。反證為同 SHA/Epoch `RAW-FAB-STAGE/LOADED/CONSUMER`；**狀態：`CONFIRMED`（未做），`UNVERIFIED`（系統能力）。**

### KI-04｜R4 Required/Served 未實測

- **現象／影響：** Route Pin rev35/epoch34 已據報修復，但 `PLAN/EXECUTE/VERIFY_SECURITY` 真 Served 無收據；r10 `NOT_RUN`。[定位：r8 report §3、r10 report L66、L79。]
- **假說：** (高) 尚未呼叫；(未知) 現役路由／帳權／模型供應接口是否符合。反證為三 Lane 的 Provider/Model/Policy Epoch/RAW readback。**狀態：`CONFIRMED`（未做），`UNVERIFIED`（提供者可用性）。**

### KI-05｜PIPD Stage-C WriteSet 仍 Fail

- **現象／影響：** PR #20 `offline-gate` 綠，`public-plugin-verify` 失敗；Log 首個主要 failure 是 `UPGRADE_WROTE_OUTSIDE_ALLOWED_SET` 指向 ADR-0008/0009，不是只有 artifact 收集缺失。[定位：Run 40450463928、40450464119；Job `122011714859`，步驟 `Prove the upgrade wrote only inside its allowed set`。]
- **假說：** (高) 比對基線含前階段 ADR 變更，或套用的 Stage-C 授權範圍不一致；**不是**應直接放寬 Allowlist 的證據。反證為逐 path 的 Git Base/Head Diff、Stage-C 期望 ChangeSet 與 Receiver WriteSet 同主體核對。**狀態：`CONFIRMED`（CI fail），`LIKELY`（基線歸屬）。**

### KI-06｜PIPD Plugin／DOC 原生 ABI 差異

- **現象／影響：** `pipd-pi-compile` 仍指定 `DOC-03 DOMAIN_ORACLES`，DOC-07 是 Canonical Oracle；DOC-06 採十二風險軸，`pipd-profile-tailor` 限九軸；`pipd-assurance-tqaep` 單階段要求 Checker Execution Receipt，與先設計測試計畫的生命週期衝突。[定位：P4 Skills `pipd-pi-compile/skill.md`、`pipd-profile-tailor/skill.md`、`pipd-assurance-tqaep/skill.md`；PIPD DOC-06 §5、DOC-07；本對話〈PIPD 與 B1 高自動化失效〉§4。]
- **假說：** (高) 版本與責任邊界不同；(中) B1 執行投影沒完整 mapping。反證為 Owner 正式批准的 Oracle 相容、12→9 軸零語義損失測試與 Design/Live 分段證據。**狀態：`CONFIRMED`（字面接口不一致），`UNVERIFIED`（正式修正已生效）。**

### KI-07｜B1 Source Design 被當 Runtime Gate／Bootstrap 循環

- **現象／影響：** B1 DOC-00 明列 `task_kind: DESIGN`、`formal_sourcefreeze: HOLD`；有些工作被全域 `SOURCE_COMPILER_HOLD` 覆蓋；要求尚未修好的 Issuer 批准修 Issuer 的普通工程會循環。[定位：B1 DOC-00 L1–25；r10 ledger `axis_totals`；本對話〈r10 根因鑑定〉§6。]
- **假說：** (高) B1 產包執行投影過度耦合 Design/Engineering/Effect/Acceptance；(中) r7～r10 長 Prompt 放大。反證為有界 Bootstrap Engineering Boundary、逐 WorkOrder 依賴圖與在 Issuer 未啟用時照常修 Repository 的對照測試。**狀態：`LIKELY`（因果），`CONFIRMED`（文件狀態與施工實例）。**

### KI-08｜DOC-08 `SBL Commander` 入口與禁用矛盾

- **現象／影響：** DOC-08 L17 要 `plan.propose`；L31 用 `SBL Commander` 提案；本輪明令 `sbl-commander-sp` 未修復，禁止使用。[定位：B1 DOC-08 L17、L29–31；r10 command §0。]
- **假說：** (高) 原設計入口未和本輪可用工具集合一致化；(未知) SBL 是否已有獨立非 Commander `plan.propose`。反證為真合法替代入口與版本化契約批准，**不能直接口頭視同**。**狀態：`CONFIRMED`（條款衝突），`MISSING`（替代 ABI 證據）。**

### KI-09｜r10 Raw Evidence 仍缺五筆本體

- **現象／影響：** Manifest 有 9 Entries，交接環境僅有其中 4 個實體；外部 Seal 與 4 個檔的 Hash 可信，但無法全驗 `USER_TRUST_RECEIPT.json`、`TRIGGER_REMOVAL_RECEIPT.json`、PIPD 局部 logs。[定位：r10 Manifest entries `emit_r10.py/PIPD_CE2_RECEIPT.json/pipd_full.txt/TRIGGER_REMOVAL_RECEIPT.json/USER_TRUST_RECEIPT.json`。]
- **假說：** (高) 上傳集合為精選檔而非完整 Raw Bundle；反證為從 Windows Host 的原始 Evidence Root 提供未變位元並全量 SHA 重算。**狀態：`MISSING`（本對話原始檔）。**

## 6) 重要決策與裁決理由（Decisions & Rationale）

| 決策（已在對話中確立，`DECIDED ≠ APPLIED`） | 理由 | 代價／副作用 | locator |
|---|---|---|---|
| 唯一人類 OWNER、Standing Authorization；不每卡重問 HITL | 避免多重人類審批假前置 | 仍須真 OS 權限／簽章／USER 資料作用域 | 本對話〈單一 OWNER 全自動授權方案〉§1–§6；r10 command §0 |
| HGK 唯一 Issuer；Hermes 唯一持久派工、PIPD Compiler、Fabric Policy Canonical、SBL 真入口 | 防止第二權威平面 | 原生線尚未整合，正式 Gate HOLD | B1 DOC-00 §4、§6；r10 command §§3–4 |
| 一般 Coding WorkOrder 不預設 Windows Administrator | r5 `LocalMachine`/ProgramData 是 Host Profile 選型非一般業務必然 | User-scope 必須另驗真私鑰隔離，不能直接稱高保證 | 本對話〈HGK 為何要求 Windows 管理員？〉§1–§7；r10 report §3 |
| Native Effect 必須合法 Permit；Formal PASS 必須同主體 Raw、Checker | 真 World Effect 不可由配置／CI 推估 | 受影效果會 PARK，但無關工程續做 | B1 DOC-00 §4；r10 command §4–§5 |
| r9 Fabric/HGK/SBL 主選**候選**保留；PIPD CE-2 可用，Stage-C 未過不得完整發布 | 隔離與遠端 CI 分級，不假 Host Loaded | GitHub PR 均未合併 | r9/r10 Reports；五 PR；PIPD Runs |
| Hermes 新乾淨 Session、少量 Context＋持久工作狀態；Codex 只作補丁 Worker | r10 提前交付／未展開困難卡；Codex 不解 Host 自治 | 新 Session 不能代替 Runtime Watcher | 本對話〈r10 根因鑑定〉§7–§11 |
| SharedSpine 唯一 Queue，`WORK_QUEUE.json` 僅作可再生視圖；READY>0 不得以 Seal 停工 | 避免第二 Scheduler／權威漂移 | 需真 Hermes Executor 入口、外部喚醒及退出判斷 | B1 DOC-00 §6；本對話〈r10 根因鑑定〉§4、§8 |
| B1 DOC-00～08 做**薄執行投影**收斂、不全面重寫；PIPD DOC-00～09 與 P4 做相容性受影修補 | Design 契約≠Runtime Runner；Oracle／Profile／TQAEP 不一致 | 必須有正式版本化差異，不能假定已生效 | 本對話〈PIPD 與 B1 高自動化失效〉§3–§10 |
| Commander-SP 全面禁用；找非 Commander 入口或有界修補 SBL Proposal | 該部件尚待開發修復 | DOC-08 Proposal ABI 仍待合法閉合 | r10 command §0、§4；B1 DOC-08 L17、L31 |
| `PIPD public-plugin-verify` 禁止用擴大 allowlist 洗綠 | Stage-C 精確 WriteSet 屬真限制 | 必須逐 path 釐清 Base/Stage 層 | Run 40450464119 Job 122011714859 |

## 7) 證據與資訊索引（Evidence & Index）

### 7.1 連結索引

**PRs（2026-10-27 最後一次 GitHub 檢查；新對話時務必重查）**：

- [HGK #1](https://github.com/shw097-team/HG-KSEOS/pull/1) — HEAD `33b5b9fac5ea418b42f467b457393a5b9402d45a`，Draft/Open，#2 的 Base；Native Admission/Trust 候選。[locator：PR `/pull/1`，r9 report §4。]
- [HGK #2](https://github.com/shw097-team/HG-KSEOS/pull/2) — HEAD `70147a5e6452e39bd62f7d40a0fbf716fce863d6`，Draft/Open，r9 CP950 修補；**r10 `de37c48` User Trust 尚無遠端上傳證明**。[locator：PR `/pull/2`，r10 report §3–§4。]
- [Fabric #18](https://github.com/shw097-team/Fabric/pull/18) — HEAD `a65231cd9ca79e8f2fe6419c539a84edcb7d6866`，Draft/Open；Consumer Inspect／REC07 整合。[locator：PR `/pull/18`；r9 report §4。]
- [SBL #13](https://github.com/shw097-team/SBL/pull/13) — HEAD `a97b1bf886b4668588980682d36016781ee9a6a9`，Draft/Open；Atomic Save。[locator：PR `/pull/13`。]
- [PIPD #20](https://github.com/shw097-team/PIPD-LS-SP/pull/20) — HEAD `abeae2512e5f1826173154bc48f68d0121126028`，Draft/Open；CE-2 共用定義已修，Stage-C 仍 Fail。[locator：PR `/pull/20`；r10 report §2。]

**`main` HEAD（僅本篇 2026-10-27 最後一次查核的快照）：** HGK `a2389c138cf51641c95494c3fa551c249a6c0058`；Fabric `bcd91043b89b69c9d2f08309e46e31898ac87d89`；SBL `dc5428f23d15f0ec56cbc3d25b22f5381fce8771`；PIPD `e95942abcb6aa07e69304607ab8afc22a74fc67d`。這不是最新 Host Import Readback，新 Session 必須重查。[定位：四庫 `/branches/main` GitHub 查核；r9/r10 Reports §四庫。]

**Runs／Checks**：

- [SBL CI 40427153912](https://github.com/shw097-team/SBL/actions/runs/40427153912) — success（Ubuntu／Windows）。[locator：PR #13 Checks；本對話 r9/r10 GitHub 查核。]
- [PIPD offline-gate 40450463928](https://github.com/shw097-team/PIPD-LS-SP/actions/runs/40450463928) — success（HEAD `abeae251…`），Job `122011714667`。[locator：Run Actions。]
- [PIPD public-plugin-verify 40450464119](https://github.com/shw097-team/PIPD-LS-SP/actions/runs/40450464119) — failure，Job `122011714859`、`UPGRADE_WROTE_OUTSIDE_ALLOWED_SET` ADR-0008/0009；`resolved-deps.txt` 只是另外的 Warning。[locator：該 Job `Prove the upgrade wrote only inside its allowed set` 原始日誌。]
- 歷史 Run：[PIPD 40446714172](https://github.com/shw097-team/PIPD-LS-SP/actions/runs/40446714172)（r9 CE-2 回歸）；[PIPD 40446714124](https://github.com/shw097-team/PIPD-LS-SP/actions/runs/40446714124)（r9 public-plugin-verify）；[PIPD 40426026162](https://github.com/shw097-team/PIPD-LS-SP/actions/runs/40426026162)（r8 public-plugin-verify）。**最新主張以前述 r10 HEAD 的兩個 Run 為準。**

**相關文件／章節（可在新對話搜尋同名 Markdown）：**

- `FHS_MSC_B1_PIPD_LS_PKG_00_GOVERNANCE_AND_CONTROL.md`：Metadata、§1 Late Binding、§2 Failure Registry、§3 Methods、§4 G-A/G-B、§6 SSOT。
- `FHS_MSC_B1_PIPD_LS_PKG_01_DOC_B1_PI.md`（27 Atoms）；`02_DOC_B1_PD.md`（31 WO/OBS）；`03_DOC_B1_OPS_ECP.md`（Host Effect）；`04_DOC_B1_DEV_ECP.md`（Repo）；`05_DOC_B1_TQAEP.md`（120/124/38）；`06_PRODUCT_COVERAGE_AND_R15.md`（949/192）；`07_NATIVE_TOOLCHAIN_EXACT_USAGE.md`（13 CLI／19 Contracts／25 Methods／24 Donors）；`08_GOLDEN_WORKORDERS_E2E.md`（GWO×3/G-B）。[locator：各文件同名章節；DOC-08 §1–§4。]
- `PIPD_LS_DOC-00…09_2026-10-07_r2_*.md`：DOC-01 §2 非 Runtime Orchestrator；DOC-05 Permission/Admission；DOC-06 §5 12 軸；DOC-07 Canonical Oracle；DOC-08 AI Projection；DOC-09 CI/Release 非 World Effect。**精確檔名有 r2/audit 補丁差異，新對話依索引搜尋 `PIPD_LS_DOC-0x`。**[locator：十份上傳 Markdown。]
- Installed P4 Skills：`skills://plugins/pipd-ls-sp-public-skills-p4/{pipd-route-intake,pipd-authority-source,pipd-profile-tailor,pipd-pi-compile,pipd-pd-bind,pipd-execution-contract,pipd-assurance-tqaep,pipd-package-project}/skill.md`；此為 Skill URI，不是 Windows Host Executor。[locator：本對話〈PIPD 與 B1 高自動化失效〉，逐技能讀取。]

### 7.2 檔案／工件索引

> `OK`＝**此對話有該名稱上傳工件的可讀位元**，不表示其內容聲稱的 Windows 效果已獨立驗證；`UNVERIFIED`＝可見位置但未獨立讀回；`MISSING`＝本對話未附相關實體檔。路徑的 Windows 本機目錄只可由新對話的有權 Host 查詢，**不能把 `/mnt/data` 當成 Windows 現役 Repo**。[定位：r10 report L3、r10 Manifest entries；本篇上傳附件清單。]

| artifact | path | 生成方式（若已知） | 內容摘要 | 狀態 | locator |
|---|---|---|---|---|---|
| r10 Execution Report | `C:\Projects\Agent_Workspace\HG-KSEOS\var\B1-HERMES-R10\B1_HERMES_R10_EXECUTION_AND_NATIVE_ACCEPTANCE_REPORT.md` | `emit_r10.py`（Hermes 報告） | 7 工作卡、11 Gates、FirstFail | **OK** | r10 Manifest Entry `...REPORT.md`；檔 §1–§7 |
| r10 Completion Ledger | 同根 `B1_HERMES_R10_COMPLETION_LEDGER.json` | `emit_r10.py`（報告） | 1,565 身份、625/285/655 | **OK** | r10 Manifest Entry `...LEDGER.json`；ledger `denominators/axis_totals` |
| r10 Raw Manifest | 同根 `B1_HERMES_R10_RAW_EVIDENCE_MANIFEST.json` | 工件落地後生成 | 9 Entries、自我排除 | **OK** | Manifest `entries/count/excluded_by_rule` |
| r10 Manifest Seal | 同根 `B1_HERMES_R10_MANIFEST_SHA256.txt` | Manifest 最後外部重算 | SHA `820f3d9e…` | **OK** | Seal `manifest_sha256`；本輪重算 |
| r10 Handoff Receipt | 同根 `B1_HERMES_R10_HANDOFF_RECEIPT.json` | `emit_r10.py`（報告） | `HOLD/signed_receipt:null` | **OK** | Handoff `handoff_status/signed_receipt` |
| r10 Resume Checkpoint | 同根 `B1_HERMES_R10_RESUME_CHECKPOINT.json` | `emit_r10.py`（報告） | Next order／repro 命令 | **OK** | checkpoint `next_in_order/rerun` |
| r10 停工根因報告 | `B1_SESSION_STOP_ROOT_CAUSE_REPORT.md`（r10 封存根**外**；Windows 絕對路徑 MISSING） | Hermes 事後分析 | RC-1～RC-7 與處置 | **OK** | 該檔 §0–§9 |
| r10 任務回報／問答 | `B1_HERMES_R10_任務回報.md`（Windows 絕對路徑 MISSING） | Hermes 文字輸出 | 自修補及提前停工自述 | **OK** | 該檔 §1–§5、後續問答 |
| r10 emitter | r10 Evidence Root `emit_r10.py` | Hermes 自建 | 封存產生器 | **MISSING** | r10 Manifest Entry `emit_r10.py` |
| r10 CE2 Raw Receipt | r10 Evidence Root `PIPD_CE2_RECEIPT.json` | PIPD test | CE-2 局部收據 | **MISSING** | r10 Manifest Entry 同名 |
| r10 Full Test Log | r10 Evidence Root `pipd_full.txt` | 本地 pytest | 634 PASS/1 FAIL 原始 log | **MISSING** | r10 Manifest Entry 同名 |
| r10 Trust Raw Receipt | r10 Evidence Root `USER_TRUST_RECEIPT.json` | `user_trust` SelfTest | Ed25519 DPAPI/7 tests | **MISSING** | r10 Manifest Entry 同名 |
| r10 Trigger Removal Raw | r10 Evidence Root `TRIGGER_REMOVAL_RECEIPT.json` | Windows task delete/readback | Trigger 撤除 | **MISSING** | r10 Manifest Entry 同名 |
| HGK User Trust source | Windows HGK Repo `src/hg_kseos/user_trust.py`（local commit `de37c48`） | Hermes 新增 | User-scoped signing | **UNVERIFIED** | r10 report §3；HGK PR #2 無該遠端檔 |
| HGK Receiver | Windows HGK Repo `src/hg_kseos/native_admission.py`；遠端 #2 同名 | HGK r5 PR | ProgramData Registry、Admit | **UNVERIFIED**（Host）；**OK**（PR 可讀） | HGK PR #2；r10 report §4 |
| r9 Dispatcher Code/ACK | `C:\Projects\Agent_Workspace\HG-KSEOS\var\B1-HERMES-R9\dispatch\`；`T1_ACK.json`／`DISPATCHER_ACK.json` | r9 測試 | 兩 PID、OS trigger、journal | **MISSING**（raw） | r9 report §2；r10 Handoff `durable_queue_ack` |
| r9 Report/Ledger/Manifest/Seal/Handoff/Checkpoint | `var\B1-HERMES-R9\B1_HERMES_R9_*` | r9 emit | 三線整合、65 Entries | **OK**（本對話上傳集合） | r9 同名六檔、r9 report §1–§9 |
| r8 Report/Ledger/Manifest/Handoff/Checkpoint | `var\B1-HERMES-R8\B1_HERMES_R8_*` | r8 emit | 18/18、HGK、Route Pin；原封存四檔 Errata | **OK**（原檔存在但部分舊 SHA 失效） | r8 同名五檔、r9 report §7 |
| r7 Index/Report/Evidence/Per-ID Ledger | `B1_R7_00_INDEX_AND_SUMMARY.md` 等四檔（Windows 絕對根見 r7 report §10） | Hermes r7 | 來源／FirstFail／1,565 行 | **OK** | r7 index、r7 report §10 |
| r6 Native report／ledger／manifest／checkpoint | `B1_NATIVE_FINAL_ACCEPTANCE_REPORT.md` 等四檔 | Codex r6 | 原生 gate/身份起點 | **OK** | r6 report §交付與限制 |
| B1 Source 00～08 | `FHS_MSC_B1_PIPD_LS_PKG_00_...md` 至 `_08_...md`（本對話十足九檔） | PIPD Design 產包 | 正式需求／驗收規格 | **OK**（設計檔） | DOC-00 metadata、DOC-08 §1–§4 |
| PIPD DOC-00～09 | `/mnt/data/PIPD_LS_DOC-00_...md` 至 `DOC-09_...md` | PIPD 規格 r2 | Canonical/CLI/TQAEP/Release | **OK**（設計檔） | DOC-01/05/06/07/08/09 |
| Hermes r7～r10 薄指揮 MD | `FHS_MSC_B1_Hermes_*_2026-10-27_r7…r10.md` | 本篇 GPT 先前生成 | OWNER、續行與 Gate 指令 | **OK** | r7、r8、r9、r10 同名檔 |
| r6 Native Owner／HITL actions | `HITL_ACTION_PACKET.json`、`NATIVE_OWNER_ACTION_PACKET.json` | r6/先前流程 | 原始簽發／AO／USER 待動作 | **OK**（附件） | r6 report §唯一合併後 HITL 行動 |
| Host 真 Signed Receipt／Checker Raw | `MISSING`（尚無可信來源路徑） | 尚未正式產生 | Formal Native PASS 證據 | **MISSING** | r10 handoff `signed_receipt:null`；r10 report §5 |

### 7.3 記憶碼／錨點／ID

- **使命／版本：** `FHS-MSC-B1`、`FHS_MSC_B1_PIPD_LS_PKG_00～08`、`B1-HERMES-R7-20261027`、`B1-HERMES-R8`、`B1-HERMES-R9`、`B1-HERMES-R10`、`PARTIAL_WITH_EXPLICIT_HOLDS`、`FHS_MSC_B1_NATIVE_ACCEPTED`。[定位：r7/r8/r9/r10 Reports；r10 command §5。]
- **Gates：** `T1/T2/R1/R2/R3/R4/G_A/G_B`、`GWO-FABRIC/GWO-HGK/GWO-SBL`、`SL-ISSUER/SL-QUEUE/SL-LOAD/SL-USER/SL-METHOD/SL-CHECKER/SL-EFFECT`。[定位：r10 ledger `gates`；B1 DOC-00 §4；DOC-08 §1–§4。]
- **原始身份：** `27 PI Atoms`、`31 WO/OBS`（10 READ_ONLY_PROBE／5 REPOSITORY_WRITE／14 HOST_OPERATIONS／2 USER_DATA_EFFECT）、`120 Parent`、`124 Child`、`38 Nodes`、`949 R15=66/254/629`、`192 Cells`、`81 Assets=24/31/26`、`3 GWO`；整本 Ledger **1,565 rows=625 Required＋285 Conditional＋655 Deferred**。[定位：r10 ledger `denominators/axis_totals/class_totals_*`；B1 DOC-02；DOC-06。]
- **r10 Work IDs：** `PIPD_CE2`、`HGK_USER_TRUST`、`T1_CORE`、`T1_SCHEDULER`、`FABRIC_R3`、`R4_LANES`、`HERMES_EXECUTOR`。[定位：r10 ledger `work_items`。]
- **重要 FirstFails：** `NATIVE_ISSUER_NOT_WIRED_INTO_RECEIVER`、`USER_TRUST_CHAIN_NOT_ROUTED_TO_ADMISSION`、`HERMES_NATIVE_LOOP_ABSENT`、`NO_ACTIVATOR_EXECUTION_THIS_ROUND`、`NO_SERVED_LANE_EVIDENCE`、`NO_STAGE_ACTIVE_LOADED`、`USER_DATA_SCOPE_NOT_OPENED`、`ERR_NATIVE_BUNDLE_REQUIRED`、`SOURCE_COMPILER_HOLD`、`CR_ORACLE_001_OPEN`、`ROUTE_SOURCE_PIN_STALE`、`UPGRADE_WROTE_OUTSIDE_ALLOWED_SET`、`METHOD_REQUIRED_NOT_INVOKED`、`POLICY_UNBOUND`。[定位：r10 report §5；r7 report §6；PIPD Run 40450464119；B1 DOC-00 §2–§4。]
- **環境／路徑／變數：** `%ProgramData%\HG-KSEOS\native-admission\registry.json`、`%LOCALAPPDATA%\HG-KSEOS\native-admission`、`HGK_TRUST_PROFILE`（**r10 checkpoint 提議採用，是否已在 Host 正式實作 UNVERIFIED**）、`B1_R9_NOW`（固定 Emit Clock 歷史語境，正式時間須採真 `observed_at`）、`FABRIC_ROOT`、`PYTHONPATH`、`.venv\Scripts\python.exe`、`C:\Projects\Agent_Workspace\HG-KSEOS\var\B1-HERMES-R9\`、`...R10\`。[定位：r10 report §§3–4、§7；r10 checkpoint `next_in_order/rerun`；r9 report §4、§7。]
- **SBL CLI：** `python -m sbl_cli.sbl_todo --data-dir <APPROVED_DIR> init|add|list --json|remove --id <ACTUAL_ID>|uninstall --yes`，`--data-dir` 在子命令前。[定位：B1 DOC-08 L38–55；r10 command §4。]
- **原生方法：** `KANBAN`、`SWARM`、`GSTACK`、`OPENSPEC`、`CODEX`；是否 Mandatory **以有效 Owner Policy Epoch 的 `mandatory_set` 判定，不憑文件自行推測**。[定位：B1 DOC-00 §3；r10 command §4。]
- **PIPD P4 Skill IDs：** `pipd-route-intake`、`pipd-authority-source`、`pipd-profile-tailor`、`pipd-pi-compile`、`pipd-pd-bind`、`pipd-execution-contract`、`pipd-assurance-tqaep`、`pipd-package-project`。[定位：上述 Skill URI；本對話 PIPD 專項鑑定。]
- **獨立對話外記憶碼：** `MISSING`；本對話沒有提供一枚可授權跨對話讀取私有資料的通用 Token。**新對話僅能依此報告與實際可存取附件重新載入，不得假裝有秘密記憶。**

### 7.4 最小最終證據集（Minimum Final Evidence Set；正式結案不可缺）

> **本表是交接時的證據要求索引，不表示工件已存在。** 只有同一 Subject/Policy Epoch、真 Host Effect、真正有權簽發及獨立 Checker 可支持 `NATIVE_ACCEPTED`。已存在的 r10 報告／Ledger／Seal 只能證明當輪 PARTIAL 狀態。 [定位：B1 DOC-00 §4；DOC-05 TQAEP；DOC-08 §§1–4；r10 Handoff `signed_receipt:null`。]

| ID | 最小最終工件／Readback | 本輪狀態 | 核驗方式／定位 |
|---|---|---|---|
| `MF-01` | 正式 SourceFreeze／TaskKind／Oracle Ratification（Subject/Version/SHA/Authority） | **MISSING** | 不採候選替代簽發；r10 Report §4；PIPD DOC-07；B1 DOC-00 §1 |
| `MF-02` | 有效 OWNER Standing Policy／HGK 原生 Issuer Bundle，含 Purpose、Scope、TTL、Nonce、Epoch、Revocation | **MISSING** | 現役 Receiver 驗簽＋篡改負例；r10 Report §3–§5；B1 DOC-00 §4 |
| `MF-03` | PIPD Effectful Compile 合格且 Source/Oracle/RepoContext 同主體 | **MISSING** | 真 Compiler 命令與 stdout、Artifact Hash；B1 DOC-07 §1；r10 Report `T2` |
| `MF-04` | Hermes 真 Executor 的 HGK 入列／公平 Lease／CAS/ACK/重啟／原生續行 | **MISSING**（原語測試 PASS） | 不能用 r9 Fixture/OS Trigger 取代；r9 Report §2；r10 Report R2 |
| `MF-05` | Fabric `RAW-FAB-STAGE`＋`RAW-FAB-LOADED`＋`RAW-FAB-CONSUMER` | **MISSING** | 逐個 SHA/Policy Epoch/Reader ACK；B1 DOC-08 §1 |
| `MF-06` | 三 Lane `PLAN/EXECUTE/VERIFY_SECURITY` Required＝Served、現役 Mandatory Methods 的同 Epoch `REAL_INVOKE` | **MISSING** | 來源 Policy 及真 Provider Receipt；B1 DOC-00 §3–§4；r10 Report R4 |
| `MF-07` | 真 HGK Effect 的 Exec/World Readback 與獨立 Checker | **MISSING** | `RAW-HGK-ISSUER/QUEUE/EFFECT` 異源且同主體；B1 DOC-08 §2 |
| `MF-08` | SBL 真 Host Install＋USER Data `ADD/LIST1/REMOVE/LIST2/UNINSTALL` 六類 Receipt | **MISSING** | 只用全新隔離合成 DataDir；B1 DOC-08 §3 |
| `MF-09` | G-A 六項合取＋三個獨立 Domain GWO PASS | **MISSING** | 每張不同 Operation/Receipt，不能借帳；B1 DOC-00 §4／DOC-08 §5 |
| `MF-10` | G-B 外援先 Revoke、下一 OS Process 自動續行、舊 token 失效與零殘留 | **MISSING** | 真 Native Successor、不依賴外援再次手動驅動；B1 DOC-08 §4 |
| `MF-11` | 針對同主體 Raw 的**真正獨立 Checker** Verdict 與身份/ACL/私鑰隔離證據 | **MISSING** | 同 SID 三 PID 不足；r10 Report §3；B1 DOC-00 §4 |
| `MF-12` | 完整 Required/Conditional/Deferred Ledger、可重算 Raw Manifest、外部 Seal、正式 Signed Handoff | **TEMP_CLOSED**（僅 r10 PARTIAL 舊證據），**最終 MISSING** | r10 Ledger/Manifest/Seal 可驗，Handoff HOLD；r10 Report §7／Handoff |

### 7.5 補強技術證據集（Reinforcement Technical Evidence Set；隔離／回歸／負例）

| 索引 | 需要保留的技術證據 | 本輪可見結果與缺口 | locator |
|---|---|---|---|
| `TE-01` | HGK PR1→PR2 RED/GREEN、63/63、Windows Relative Path/CP950 解碼負例 | **REPORTED PASS**，需 RAW 受影日誌／HEAD 重現 | r7 Report §5.1；r8 Report §4；r9 Report §4 |
| `TE-02` | User Trust 七項正反鏈、隔離金鑰與同 SID 權限測試 | **REPORTED PASS**；Checker SoD **UNVERIFIED** | r10 Report §3；`USER_TRUST_RECEIPT.json` MISSING |
| `TE-03` | 無 Bundle／錯 Purpose/Nonce/TTL/Root/Key/Revocation 負例 | 未 Bundle 拒收已 REPORTED，其餘現役 Receiver 端到端 **MISSING** | r9 Report §3；r10 Report §4 |
| `TE-04` | SharedSpine Enqueue/Lease/CAS/Fairness/Restart/Replay/Park 與兩 PID／Trigger | r8 18/18、r9 Dispatcher **REPORTED PASS**；Hermes 真 Loop **MISSING** | r8 Report §2；r9 Report §2 |
| `TE-05` | Route Pin SHA/Epoch 正向與壞 SHA、壞 Epoch、Rollback | rev35/epoch34 **REPORTED PASS**；真 Served **MISSING** | r8 Report §3；r10 Report §6 |
| `TE-06` | Fabric `_fabric_root` 三方差異、5 tests、fail-closed `INSPECTED_NOT_APPLIED` | **REPORTED PASS**；Activator Live **MISSING** | r9 Report §4；Fabric PR #18 |
| `TE-07` | SBL Atomic Save 3 tests／Ubuntu+Windows CI、Duplicate/Empty/Foreign Data 負例 | 程式層 **PASS**，真 Host USER Effect **MISSING** | SBL PR #13，Run 40427153912；B1 DOC-08 §3 |
| `TE-08` | PIPD CE-2 shared identity/trace negative、局部 9 tests、全套 634 pass/1 fail | Remote offline CI **PASS**；本地 full log **MISSING** | PIPD PR #20，Run 40450463928；r10 Report §2 |
| `TE-09` | PIPD Stage-C ADR-0008/0009 非法路徑、Traversal/self-test | Job 真 FAIL，修正方案尚需同 Base 的負例 | Run 40450464119 Job 122011714859 |
| `TE-10` | Manifest Emitter ordering、SHA Errata、Self-inclusion/Snapshot Freeze | r9 65 Entry 與 r10 9 Entry 報告，r10 四筆上傳 SHA **OBSERVED PASS** | r9 Report §7；r10 Manifest/Seal |
| `TE-11` | 異步工作未盡仍生成 Seal 的反例／READY>0 拒絕完工 | **MISSING**（下一輪新測） | `B1_SESSION_STOP_ROOT_CAUSE_REPORT.md` RC-2/RC-3；本對話 r10 根因鑑定 §8–§9 |
| `TE-12` | P4 Oracle/12→9 Profile/TQAEP Design→Live 相容正反例 | **MISSING/UNVERIFIED**，只確認接口字面落差 | P4 SkillContracts；PIPD DOC-06 §5；DOC-07；本對話 PIPD 專項鑑定 §4–§5 |

## 8) 下一步（最短路徑）＋逐步驗證點（Verification Checkpoints）

> **操作前共同規則：** (a) 在新 Hermes Session 先核對真 Host 實際 Root/HEAD/Dirty/ACL；(b) 命令逐條執行並保存 Exit Code；(c) 先唯讀／隔離，效果操作必具有效權限；(d) 報告不等於測試；(e) **禁止 Commander-SP**。以下 Windows 命令是用既有來源提供的 Repo/Path 形成的**待執行操作**，**不是已執行結果**。[定位：r10 command §§0–§5；r10 checkpoint。]

### Step 1：先核對最新位元與唯一權威工作狀態

- **操作：** 使用新 Hermes Session 讀取 `B1_HERMES_R10_RESUME_CHECKPOINT.json`、`B1_HERMES_R10_COMPLETION_LEDGER.json`、`B1_SESSION_STOP_ROOT_CAUSE_REPORT.md`；在本機對 HGK、Fabric、SBL、PIPD 各跑一次 `git status --short; git rev-parse HEAD; git branch --show-current`；以 PR #1/#2/#18/#13/#20 URL 重新確認遠端 Head、CI、Reviewer。讀 `var/B1-HERMES-R9/dispatch` 的真正 Source/Journal 並查 `schtasks /query /tn HGK-B1-R9-Dispatch /v /fo LIST`（**僅查，不重建**）。
- **成功判據：** 四庫 HEAD/Dirty 快照、Queue 所屬 SharedSpine DB/Lease、測試 Trigger 存亡都獲得真 readback；有具 `READY/RUNNING/PARKED/DONE` 語義的受影卡。[定位：r10 checkpoint `next_in_order`、r10 report §6；r9 report §2。]
- **若失敗：** `MISSING` 指定 DB/入口/路徑，搜索現有 Hermes 已安裝 CLI/SessionDB/SharedSpine 文檔與工具；**不要創建另一 Queue**。保存具名探索卡並繼續其它 READY。[定位：B1 DOC-00 §6；本對話〈r10 根因鑑定〉§8。]

### Step 2：先證明 Hermes 真持久續航，而非再寫一份 Prompt

- **操作：** 以現有 `hgk_dispatch.py`／SharedSpine 為唯一 Queue 來源，定位已安裝 Hermes 的真正 Executor 入口；建立最小合法測試卡，記 `id/subject/effect_scope/first_fail/next_repro/state/lease` 到 SharedSpine；`todo_list` 及 `WORK_QUEUE.json` 只能作**可再生視圖**；跑 Claim→Execute→Readback→Checkpoint；殺 Worker，再由**已驗證**外部喚醒流程起新 PID 讀回續行。另測「封存時 READY>0 應拒絕最終 Handoff」。[定位：r9 report §2；r10 report R2；`B1_SESSION_STOP_ROOT_CAUSE_REPORT.md` RC-1～RC-3。]
- **成功判據：** 新 PID 真執行卡、同 Subject ACK、Lease/Fairness/At-most-once 成立；`HERMES_NATIVE_LOOP_ABSENT` 有對應消除的 RAW。**無權限 Native Effect 不能拿 Fixture 代替**。[定位：B1 DOC-00 §4；r10 command §4。]
- **若失敗：** 將缺失定位至「Hermes 執行入口／Host 喚醒／SharedSpine Claim／簽發前置」之一；只對真修補接口派給 Codex Worker，不整套 Codex 回退。[定位：本對話〈r10 根因鑑定〉§7、§8。]

### Step 3：接 HGK User Trust → Receiver（優先實際可行的 User Scope）

- **操作：** 比對本地 `de37c48` 的 `src/hg_kseos/user_trust.py`、相應 `tests/test_user_trust.py` 與 HGK #1/#2 `native_admission.py`。先以 r10 Checkpoint 的已記錄命令做隔離測試：

  ```powershell
  # 在已核准的本地 HG-KSEOS Repo Root 內；先核對 .venv 的真實存在
  $env:PYTHONPATH = 'src'
  .\.venv\Scripts\python.exe -B -m pytest tests/test_user_trust.py -q
  ```

  補最小、版本化 Trust Profile Resolver；`HGK_TRUST_PROFILE=user` 是**提議的選擇器，尚未證明已實作**，不可在已安裝 Receiver 不支援時僅設 Env 就聲稱生效。對相同 Subject 用真 Signer Bundle 執行 Taskspec/WorkOrder Admission，並做錯 Key/過期/Nonce 重播/Revoke/SID/Root/Scope 負例；把不同 Principal 保證級別與實測分開記錄。[定位：r10 report §3–§4；r10 checkpoint `rerun.user_trust`/`next_in_order[0]`。]
- **成功判據：** 真 Receiver `ADMIT`＋拒收負例＋有效 Issue/Verify/Readback；Maker 不得自行替換 Trust Anchor。若 SoD 未成立，只關閉 User-scope 技術測試，不標高保證 R1/G-A PASS。[定位：r10 report L47–55；B1 DOC-00 §4。]
- **若失敗：** 若 `ProgramData` 常數仍硬綁，修 Resolver 不關 Gate；若 UserScope 密鑰可被 Maker 同權限操作，`ROLE_ISOLATION_UNPROVEN`，繼續可做工程，僅 PARK 受影正式 Native 效果。不得靠虛構 OS SID 或弱化檢查。[定位：本對話〈HGK Windows Admin〉§5–§7。]

### Step 4：Fabric R3 實測（不以 PR Inspect 冒充 Active）

- **操作：** 從 Fabric Repo 尋找現役 `stage`／`activate`／`active_pointer`／`loaded`／`consumer` 的 CLI/API；先唯讀取得實際 Source Revision、Active/Loaded SHA、Epoch、前像及有權 Issuer。合法可逆環境中才發 Stage/Activate，讀 `RAW-FAB-STAGE/RAW-FAB-LOADED/RAW-FAB-CONSUMER`；並做錯 SHA／Epoch 負例與可回復檢查。[定位：B1 DOC-08 §1；r9 report §4；r10 report §6。]
- **成功判據：** 同一 Subject/Epoch 真 Stage→Active→Loaded，Consumer ACK；不是 `INSPECTED_NOT_APPLIED`。若缺合法 Permit，Stage DryRun 與查詢可完成但 `R3` 保持 HOLD。[定位：B1 DOC-00 §4；B1 DOC-08 L19–27。]
- **若失敗：** `NO_ACTIVATOR_EXECUTION` 與 `ACTIVATOR_UNAVAILABLE` 分開；前者不能直接 PARK 為外部 HARD Blocker。[定位：r10 report L78。]

### Step 5：R4 模型車道 Required／Served 真量測

- **操作：** 在**已授權**的 Hermes／Fabric 現役 Routing 介面讀 `route rev35/epoch34`、Provider/Model、Policy SHA，逐一對 `PLAN`、`EXECUTE`、`VERIFY_SECURITY` 發受限真調用並記 Request ID、實際 Served、Epoch、錯配負例；對 `KANBAN/SWARM/GSTACK/OPENSPEC/CODEX` 先讀現役簽名 `mandatory_set`，只對 Required 作真正 Invocation。[定位：r8 report §3、r10 command §2.C、B1 DOC-00 §3。]
- **成功判據：** 三 Lane 每項 `required=served` 且真 raw；方法 Same Epoch 按需有 `REAL_INVOKE`。**不能改換 OWNER 選用 Provider 來假造綠燈。**[定位：B1 DOC-00 §3–§4。]
- **若失敗：** `MISSING` 認證／Provider／真呼叫入口，先做合法 read-only Diagnosis；只 PARK 受影 Lane，保留其他 READY。[定位：r10 report L79；r10 command §2.C。]

### Step 6：PIPD CI、Oracle、Profile/TQAEP 受影收斂

- **操作：** 先讀 [PR #20](https://github.com/shw097-team/PIPD-LS-SP/pull/20) 最新 HEAD 與兩 GitHub Runs；定位 Job 122011714859 的 ADR-0008/0009 比較範圍、Stage-C allowed WriteSet，不擴大放行條件；Oracle 依 DOC-07 Canonical＋P4 Legacy Adapter，Profile 12→9 軸需有覆蓋矩陣，TQAEP 明確區分 Design Planned 和 Live Checker Verdict。若本地 Repo 存在且測試依賴已配置，先用 `python -m pytest` 跑受影測試，避免沿用 r10 Checkpoint 已移除的 `var/.../wt-pipd` worktree 路徑。[定位：r10 report §2；r10 Handoff `side_effects`；PIPD Plugin 八 SkillContracts；PIPD DOC-06/07；Run 40450464119。]
- **成功判據：** 新 PR HEAD 的 `offline-gate` 與 `public-plugin-verify` 都 success，違反 WriteSet 的負例仍 FAIL；Oracle/Axis/TQAEP 正式版本化差異具有效驗證。[定位：PIPD Run 40450463928/40450464119；本對話〈PIPD 專項鑑定〉§4–§5。]
- **若失敗：** 保留 `CR_ORACLE_001_OPEN` 或對應精確 Gate，隔離其他不受影工作續行；禁止以 `resolved-deps.txt` warning 掩蓋 Stage-C 真失敗。[定位：PIPD Job 122011714859。]

### Step 7：非 Commander SBL Proposal 與三個 Golden WorkOrders

- **操作：** 查已安裝 SBL／Repo 的 `plan.propose` 真 ABI；若依賴 `sbl-commander-sp` 才存在，**不要安裝或調用**，提最小合法 SBL Proposal 修補與版本化 DOC-08 入口差異。對三個 GWO 用不同 Issuer／Lease／Raw/Checker；SBL 僅在全新已授權合成 DataDir 中按 DOC-08 §3 的 `init/add/list/remove/uninstall` 執行，不使用既有真實私人資料。[定位：B1 DOC-08 §1–§4；r10 command §4。]
- **成功判據：** GWO-FABRIC/HGK/SBL 各有不同 Operation ID、同主體 RAW、獨立 Checker；SBL 6 類效果 Receipt 均存在；不能以安裝替代 USER Data Add。[定位：B1 DOC-08 L40–68。]
- **若失敗：** 哪個 Proposal、USER Issuer、Host Install 真缺就 PARK 對應卡；不縮原始驗收身份，不啟用 Commander-SP。[定位：B1 DOC-08 L17、L31、L40–42。]

### Step 8：完成 G-A／G-B＋最終封存與交接

- **操作：** 以 B1 DOC-00 §4 驗證 G-A 六項同 SHA／Epoch 合取；三 GWO 皆 PASS 後撤外援暫時授權，在**另一 OS Process／Session**由 Native 持久流程自主觸發下一張卡；讀舊 token Revoke 拒收與 World Effect/Residue；**只在 READY/RUNNING 已耗盡**且 Gate 真閉合後生成最終 Report→Ledger→Manifest→外部 Seal→Handoff（先固定靜態位元、不收進行中的 stdout/WAL）。[定位：B1 DOC-00 §4；DOC-08 §4；r10 report §7；`B1_SESSION_STOP_ROOT_CAUSE_REPORT.md` RC-3。]
- **成功判據：** `native_accepted=true` 有可驗 Signed Receipt＋不同 Checker，`G_B=PASS` 新 Process 自主續行，1,565 身份不縮減，封存全量 SHA MATCH，舊外援 Token 無效。[定位：r10 command §5–§6；B1 DOC-08 §4。]
- **若失敗：** `NATIVE_ACCEPTANCE_HOLD` 並保存**可機器喚醒**的 PARK 原因／下一次有效條件；**不得**在仍有 READY 卡時把 `PARTIAL` 視為任務完成，也不得無限空轉。[定位：本對話〈r10 根因鑑定〉§8–§9。]

## 9) 風險清單與防線（Risks & Guardrails）

1. **Maker/Signer/Checker 同 SID，DPAPI CurrentUser 不是高保證隔離** → 只稱 `USER_SCOPED_SOFTWARE_KEY`，正式 G-A/AO 不過；需真 Principal／權限區隔 readback。[定位：r10 report §3；本對話〈HGK Admin〉§5。]
2. **再度錯把 PARTIAL/HOLD 當停止** → Gate 狀態、工程狀態、Runner READY 分離；READY>0 拒絕最終 Handoff。[定位：`B1_SESSION_STOP_ROOT_CAUSE_REPORT.md` RC-2/RC-3；r10 report L15–17。]
3. **第二 Queue／工作卡重複執行** → 只信 SharedSpine CAS/Lease/Nonce/Checkpoint；`WORK_QUEUE.json` 不獨立成為寫入權威。[定位：B1 DOC-00 §6；r9 report §2。]
4. **r9 Scheduled Task 再次污染封存** → 先查是否存在；Live Journal 與 Frozen Snapshot 分離；無需預設系統管理員 Service。[定位：r9 report §2、§7；r10 任務回報 §3。]
5. **Stage SHA／PR CI 被借作 Loaded/World Effect** → 必須分別 RAW-FAB-STAGE/LOADED/CONSUMER，真三 Lane Served、SBL User Data Readback。[定位：B1 DOC-08 §§1–3；r10 report L76–81。]
6. **PIPD 為了綠 CI 放寬 Stage-C Allowlist** → 查準比對 Base、受影 ChangeSet，保留 ADR-0008/0009 NEG 拒收。[定位：PIPD Run 40450464119、Job 122011714859。]
7. **r10 本地 User Trust 尚未推遠端或目前工作樹已變** → 先核對 `git log/status`／檔案 SHA；禁止把 `de37c48` 當已合併 `main`。[定位：r10 Handoff `side_effects`；HGK #2。]
8. **原始 B1 Design 被誤當 Native Permission** → Bootstrap 有界 Repo 修補／隔離測試在 Standing Scope 內推進，正式 Host Effect 仍 Permit-Gated；不改寫原始身份。[定位：B1 DOC-00 `task_kind:DESIGN`；本對話〈PIPD 與 B1 失效〉§3、§6。]
9. **Commander-SP 被間接啟用** → 所有 Tool Routing／依賴搜尋排除 `sbl-commander-sp`，對 DOC-08 `plan.propose` 留 MISSING 直到有真非 Commander ABI。[定位：r10 command §0；B1 DOC-08 L17、L31。]
10. **r10 Manifest 檢查被誤稱全部 Raw 獨立驗證** → 僅四個 Entries 位元已上傳重算，未提供的五份標 MISSING；需要 Host 直接 SHA 讀回。[定位：r10 Manifest 9 Entries、外部 Seal。]
11. **未知效果盲目 Retry，重複操作或資料遺失** → 若 `UNKNOWN_EFFECT`，先 World State Reconcile，再獨立補償；不把一般修補迭代的重試次數套用到 Effect 原語。[定位：B1 DOC-00 §4/StopLoss；DOC-08 GWO-HGK §2；P4 `pipd-execution-contract/skill.md`。]
12. **過長 Context 的迭代惡化** → 新 Session 先讀本 Handoff、r10 Resume、兩個 Gate 文件與當前 Host 狀態，依問題點逐步展開其他附件，不一次重灌全部 r1～r10 的長 Prompt。[定位：`B1_SESSION_STOP_ROOT_CAUSE_REPORT.md` RC-5/RC-7；PIPD DOC-08 相關 AI 投影原則。]

## 10) 待決項（CR_OPEN / MISSING / Questions-for-Next-Operator）

### CR_OPEN（已知但可繼續）

- `CR_ORACLE_001_OPEN`：DOC-07 Canonical vs P4 `DOC-03 DOMAIN_ORACLES` ABI／正式 Ratification 尚未生效；只封鎖受影 Native Compiler／Claim。[定位：r7 report §5.3；PIPD DOC-07；P4 `pipd-pi-compile`。]
- `CR_OPEN-STAGE-C`：PIPD public-plugin-verify ADR-0008/0009 Stage-C ChangeSet/Allowlist 比對。[定位：PIPD Run 40450464119 Job 122011714859。]
- `CR_OPEN-USER-TRUST-RECEIVER`：`user_trust` Profile→`native_admission.REGISTRY` 尚未接線。[定位：r10 report §4。]
- `CR_OPEN-R2-RUNTIME`：Hermes 真 Executor／合法外部喚醒未驗。[定位：r10 report R2、§6；r10 任務回報 §3。]
- `CR_OPEN-R3-R4`：Activator/Loaded/Consumer 與三 Lane Served 均 NOT_RUN。[定位：r10 report §6。]
- `CR_OPEN-DOC08-SBL`：非 Commander Proposal ABI/正式差異裁決未閉合。[定位：B1 DOC-08 L17、L31；r10 command §4。]
- `CR_OPEN-PIPD-PROFILE-TQAEP`：DOC-06 12 軸到 P4 9 軸映射、TQAEP Design/Live Receipt 分離未正式驗測。[定位：PIPD DOC-06 §5；P4 Skills；本對話 PIPD 專項 §4。]

### MISSING／UNVERIFIED（直接阻礙可信結案）

- `MISSING-R10-RAW-5`：`emit_r10.py`、`PIPD_CE2_RECEIPT.json`、`pipd_full.txt`、`TRIGGER_REMOVAL_RECEIPT.json`、`USER_TRUST_RECEIPT.json` 的原始未修改位元。[定位：r10 Manifest entries 5–9。]
- `UNVERIFIED-LOCAL-HEAD`：四個 Windows Repo 當前 HEAD/Dirty/Live Import、`de37c48` 是否仍在本地；路由 rev35/epoch34 配置是否仍生效。[定位：r10 Handoff/Resume；r8 report §3；GitHub PR refs。]
- `MISSING-ISSUER-AO`：正式 HGK Signed Bundle、獨立 Checker Principal、Machine-scope Trust 或可驗的 User-scope 隔離設計／收據。[定位：r10 Handoff `signed_receipt:null`；r10 report §3–§5。]
- `MISSING-FABRIC-R4`：真 Activator／Loaded Consumer、真 Provider/Model Lane Served RAW。[定位：r10 report §6；B1 DOC-08 §1。]
- `MISSING-HERMES-EXECUTOR`：已安裝 Hermes 本體真正的 Executor Hook／Wake-up API 及跨 Process 真 Native successor 證據。[定位：r10 report §6；r9 report §2。]
- `UNVERIFIED-SOURCE-CURRENTNESS`：新 Session 取得本報告後所有 PR/CI/Tool Provider 版本是否已變更；不能依舊 SHA 假設仍為 HEAD。[定位：本篇 PR URLs；r10 report 2026-10-27 觀測。]
- `MISSING-PIPD-INVOKE-TRACE`：當初 B1 包產出的 P4 Skill 工具呼叫逐步軌跡未提供；因此「PIPD 造成全部停工」僅為未證因果。[定位：本對話〈PIPD 與 B1 高自動化失效〉§2、§7。]

### Questions-for-Next-Operator（自己查，不回問使用者）

1. Hermes 真 Executor 在已安裝 v0.21.5 Host 的 CLI／App 路徑何處？可否讓 SharedSpine Lease 真喚醒？[定位：r7 report §2；r10 report R2。]
2. `de37c48` 本地樹／測試檔與 HGK PR #2 差異是什麼？能否以最小 Resolver 讓簽名 Bundle 正向 Admission？[定位：r10 Handoff／Report。]
3. Fabric 真 Activator 和現役 Policy Pointer／Loaded Reader 位置何在？[定位：B1 DOC-08 §1；r10 report R3。]
4. 三 Lane `PLAN/EXECUTE/VERIFY_SECURITY` 的真 provider/model request/served event 在哪？[定位：r10 report R4。]
5. PIPD Stage-C 違反 WriteSet 的 ADR-0008/0009 屬哪一個受治理階段的變更？[定位：Run 40450464119。]
6. SBL 除 Commander-SP 外是否已有可用 `plan.propose`？若沒有最小相容層寫在哪？[定位：B1 DOC-08 L17、L31。]
7. 有效政策的 Mandatory Methods、`Owner Signature`、Checker SoD 在哪個現役 Policy Epoch？[定位：B1 DOC-00 §3。]

## 11) Self-Check（交付前自檢）

- [x] 每個「已完成／已失敗／已產出」均給出附件名稱、章節/欄位、PR 或 Run 定位；`REPORTED` 未冒稱獨立 Host 驗證。
- [x] 不確定事項均標示 `MISSING`／`UNVERIFIED`，收錄於 §2、§5、§7、§10。
- [x] 已提供 Step 1～8 的目的、操作、成功觀察、失敗分支與來源。
- [x] 未輸出 token、密碼、私鑰，未複製 Askpass 或憑證材料；若新附件包含秘密應替換為 `[REDACTED]`。
- [x] 已知精確事件時間全部換算為 `Asia/Taipei (+08:00)`；只有日期無時分者明示 `時間 MISSING`；r9 固定 Emission 時鐘保留限制。
- [x] 保留 B1 `task_kind: DESIGN`、Formal Native Gate、Commander-SP 禁令及 1,565 身份，不將工程測試偷換成 Native PASS。
- [x] 本交接文件已包含固定 schema 的 §12 JSON Summary；其 `null` 表示未知而非猜測。

## 12) Machine Summary（JSON，供自動化／快速掃描）

```json
{
  "handoff_version": "v1",
  "generated_at": "2026-10-27T14:10:12+08:00",
  "task_name": "FHS-MSC B1 Bootstrap/Repair PIPD-LS-PKG／Hermes r7–r10 自治施工與 Native 驗收交接",
  "definition_of_done": [
    "在唯一人類 OWNER 有界 Standing Policy 下可自動派工、除錯、修補、重啟續行；不使用 sbl-commander-sp",
    "B1 Required＋已觸發 Conditional 正式閉合，保留 1565 身份追溯",
    "T2、R1–R4、G-A 六項合取、GWO-FABRIC/HGK/SBL、G-B 全部真實 PASS",
    "具真 HGK Issuer/Permit、Fabric Active+Loaded 同 SHA、PLAN/EXECUTE/VERIFY_SECURITY required=served、實際效果 Raw＋獨立 Checker",
    "外援撤銷後由另一個 OS Process/Session 由 Native Scheduler 自主續行，完成可重算 Manifest/Seal 與 Signed Handoff"
  ],
  "current_blockers": [
    {
      "item": "B1 Native Admission not completed",
      "status": "FAIL",
      "locator": "r10 Report §5 gates T2/R1, §4; r10 Handoff signed_receipt=null"
    },
    {
      "item": "Hermes actual native executor and autonomous wakeup",
      "status": "FAIL",
      "locator": "r10 Report §1/§6, R2=PARTIAL; r9 Report §2"
    },
    {
      "item": "Fabric Stage Active Loaded Consumer",
      "status": "FAIL",
      "locator": "r10 Report §6 FABRIC_R3=NOT_RUN; B1 DOC-08 §1"
    },
    {
      "item": "Three model lanes required=served",
      "status": "FAIL",
      "locator": "r10 Report §6 R4_LANES=NOT_RUN"
    },
    {
      "item": "PIPD public-plugin-verify Stage-C WriteSet",
      "status": "FAIL",
      "locator": "GitHub Run 40450464119 Job 122011714859 ADR-0008/0009"
    },
    {
      "item": "Independent Checker Principal and true Native Signed Receipt",
      "status": "MISSING",
      "locator": "r10 Report §3 assurance=USER_SCOPED_SOFTWARE_KEY; r10 Handoff signed_receipt=null"
    },
    {
      "item": "Non-Commander SBL proposal ABI",
      "status": "MISSING",
      "locator": "B1 DOC-08 L17/L31; r10 command §4"
    },
    {
      "item": "Five r10 Manifest raw artifacts not uploaded",
      "status": "MISSING",
      "locator": "r10 Manifest entries 5..9"
    },
    {
      "item": "Current Windows HEAD/dirty/host-loaded after handoff",
      "status": "UNVERIFIED",
      "locator": "r10 Resume; GitHub PR HEAD as of 2026-10-27"
    }
  ],
  "artifacts": [
    {
      "name": "B1_HERMES_R10_EXECUTION_AND_NATIVE_ACCEPTANCE_REPORT.md",
      "path": "C:\\Projects\\Agent_Workspace\\HG-KSEOS\\var\\B1-HERMES-R10\\B1_HERMES_R10_EXECUTION_AND_NATIVE_ACCEPTANCE_REPORT.md",
      "status": "OK",
      "locator": "r10 Manifest entry report; r10 Report §§1–7"
    },
    {
      "name": "B1_HERMES_R10_COMPLETION_LEDGER.json",
      "path": "C:\\Projects\\Agent_Workspace\\HG-KSEOS\\var\\B1-HERMES-R10\\B1_HERMES_R10_COMPLETION_LEDGER.json",
      "status": "OK",
      "locator": "r10 Manifest entry ledger; ledger denominators/axis_totals/gates"
    },
    {
      "name": "B1_HERMES_R10_RAW_EVIDENCE_MANIFEST.json",
      "path": "C:\\Projects\\Agent_Workspace\\HG-KSEOS\\var\\B1-HERMES-R10\\B1_HERMES_R10_RAW_EVIDENCE_MANIFEST.json",
      "status": "OK",
      "locator": "r10 Manifest count=9"
    },
    {
      "name": "B1_HERMES_R10_MANIFEST_SHA256.txt",
      "path": "C:\\Projects\\Agent_Workspace\\HG-KSEOS\\var\\B1-HERMES-R10\\B1_HERMES_R10_MANIFEST_SHA256.txt",
      "status": "OK",
      "locator": "r10 Seal manifest_sha256=820f3d9..."
    },
    {
      "name": "B1_HERMES_R10_HANDOFF_RECEIPT.json",
      "path": "C:\\Projects\\Agent_Workspace\\HG-KSEOS\\var\\B1-HERMES-R10\\B1_HERMES_R10_HANDOFF_RECEIPT.json",
      "status": "OK",
      "locator": "r10 Handoff handoff_status=HOLD signed_receipt=null"
    },
    {
      "name": "B1_HERMES_R10_RESUME_CHECKPOINT.json",
      "path": "C:\\Projects\\Agent_Workspace\\HG-KSEOS\\var\\B1-HERMES-R10\\B1_HERMES_R10_RESUME_CHECKPOINT.json",
      "status": "OK",
      "locator": "r10 Resume next_in_order/rerun"
    },
    {
      "name": "B1_SESSION_STOP_ROOT_CAUSE_REPORT.md",
      "path": null,
      "status": "OK",
      "locator": "attached B1_SESSION_STOP_ROOT_CAUSE_REPORT.md RC-1..RC-7; precise Host path MISSING"
    },
    {
      "name": "B1_HERMES_R10_任務回報.md",
      "path": null,
      "status": "OK",
      "locator": "attached B1_HERMES_R10_任務回報.md §§1–5"
    },
    {
      "name": "src/hg_kseos/user_trust.py",
      "path": "C:\\Projects\\Agent_Workspace\\HG-KSEOS\\src\\hg_kseos\\user_trust.py",
      "status": "UNVERIFIED",
      "locator": "r10 Report §3, local commit de37c48; remote HGK PR#2 lacks file"
    },
    {
      "name": "PIPD_CE2_RECEIPT.json",
      "path": "C:\\Projects\\Agent_Workspace\\HG-KSEOS\\var\\B1-HERMES-R10\\PIPD_CE2_RECEIPT.json",
      "status": "MISSING",
      "locator": "r10 Manifest entry PIPD_CE2_RECEIPT.json"
    },
    {
      "name": "pipd_full.txt",
      "path": "C:\\Projects\\Agent_Workspace\\HG-KSEOS\\var\\B1-HERMES-R10\\pipd_full.txt",
      "status": "MISSING",
      "locator": "r10 Manifest entry pipd_full.txt"
    },
    {
      "name": "USER_TRUST_RECEIPT.json",
      "path": "C:\\Projects\\Agent_Workspace\\HG-KSEOS\\var\\B1-HERMES-R10\\USER_TRUST_RECEIPT.json",
      "status": "MISSING",
      "locator": "r10 Manifest entry USER_TRUST_RECEIPT.json"
    },
    {
      "name": "TRIGGER_REMOVAL_RECEIPT.json",
      "path": "C:\\Projects\\Agent_Workspace\\HG-KSEOS\\var\\B1-HERMES-R10\\TRIGGER_REMOVAL_RECEIPT.json",
      "status": "MISSING",
      "locator": "r10 Manifest entry TRIGGER_REMOVAL_RECEIPT.json"
    },
    {
      "name": "emit_r10.py",
      "path": "C:\\Projects\\Agent_Workspace\\HG-KSEOS\\var\\B1-HERMES-R10\\emit_r10.py",
      "status": "MISSING",
      "locator": "r10 Manifest entry emit_r10.py"
    },
    {
      "name": "r9 dispatcher ACK",
      "path": "C:\\Projects\\Agent_Workspace\\HG-KSEOS\\var\\B1-HERMES-R9\\dispatch\\DISPATCHER_ACK.json",
      "status": "MISSING",
      "locator": "r9 report §2; r10 Handoff durable_queue_ack"
    }
  ],
  "links": {
    "prs": [
      "https://github.com/shw097-team/HG-KSEOS/pull/1",
      "https://github.com/shw097-team/HG-KSEOS/pull/2",
      "https://github.com/shw097-team/Fabric/pull/18",
      "https://github.com/shw097-team/SBL/pull/13",
      "https://github.com/shw097-team/PIPD-LS-SP/pull/20"
    ],
    "runs": [
      "https://github.com/shw097-team/SBL/actions/runs/40427153912",
      "https://github.com/shw097-team/PIPD-LS-SP/actions/runs/40450463928",
      "https://github.com/shw097-team/PIPD-LS-SP/actions/runs/40450464119",
      "https://github.com/shw097-team/PIPD-LS-SP/actions/runs/40446714172",
      "https://github.com/shw097-team/PIPD-LS-SP/actions/runs/40446714124",
      "https://github.com/shw097-team/PIPD-LS-SP/actions/runs/40426026162"
    ],
    "docs": [
      "FHS_MSC_B1_PIPD_LS_PKG_00_GOVERNANCE_AND_CONTROL.md §4/§6",
      "FHS_MSC_B1_PIPD_LS_PKG_01_DOC_B1_PI.md",
      "FHS_MSC_B1_PIPD_LS_PKG_02_DOC_B1_PD.md",
      "FHS_MSC_B1_PIPD_LS_PKG_03_DOC_B1_OPS_ECP.md",
      "FHS_MSC_B1_PIPD_LS_PKG_04_DOC_B1_DEV_ECP.md",
      "FHS_MSC_B1_PIPD_LS_PKG_05_DOC_B1_TQAEP.md",
      "FHS_MSC_B1_PIPD_LS_PKG_06_PRODUCT_COVERAGE_AND_R15.md",
      "FHS_MSC_B1_PIPD_LS_PKG_07_NATIVE_TOOLCHAIN_EXACT_USAGE.md",
      "FHS_MSC_B1_PIPD_LS_PKG_08_GOLDEN_WORKORDERS_E2E.md §1–§4",
      "PIPD_LS_DOC-00…09_2026-10-07_r2_*.md",
      "B1_HERMES_R10_EXECUTION_AND_NATIVE_ACCEPTANCE_REPORT.md",
      "B1_HERMES_R10_RESUME_CHECKPOINT.json",
      "B1_SESSION_STOP_ROOT_CAUSE_REPORT.md"
    ]
  },
  "next_steps": [
    {
      "step": 1,
      "action": "讀取 r10 Checkpoint + 四庫 HEAD/Dirty + SharedSpine/Task Scheduler 唯讀現況",
      "success_criteria": "確定實際 Root/HEAD/READY/Trigger 不依賴舊 Context",
      "if_fail_then": "缺任一來源→MISSING 有界探索卡，繼續其它 READY",
      "locator": "r10 Resume next_in_order; r10 Report §6"
    },
    {
      "step": 2,
      "action": "修 Hermes 真 Executor→SharedSpine/Lease/Checkpoint/重啟與 READY 出口檢查",
      "success_criteria": "新 PID 真續行且 READY>0 不可 Final Handoff",
      "if_fail_then": "真 Executor 接口缺失→派 Codex 最小 Harness 接線卡",
      "locator": "r9 Report §2; r10 Report R2; stop-root-cause RC-1..3"
    },
    {
      "step": 3,
      "action": "把 HGK user_trust 可信 Profile 與 native_admission Receiver 真接線",
      "success_criteria": "真 Signed Bundle 正向 Admit＋Nonce/TTL/Revoke/Key 篡改負例",
      "if_fail_then": "SoD 未證→僅低保證技術通過，正式 Gate HOLD",
      "locator": "r10 Report §§3–4; r10 Resume item 1"
    },
    {
      "step": 4,
      "action": "真實探測 Fabric Activator 與受限 Stage→Active→Loaded Consumer",
      "success_criteria": "同 Subject/Policy Epoch 三種不同 RAW/ACK",
      "if_fail_then": "無有效 Host Permit→只停受影 Activator，保存 preflight",
      "locator": "B1 DOC-08 §1; r10 Report §6"
    },
    {
      "step": 5,
      "action": "真調用 PLAN/EXECUTE/VERIFY_SECURITY 與 Mandatory Methods",
      "success_criteria": "三 Lane required=served，same Epoch REAL_INVOKE",
      "if_fail_then": "Provider 或 Policy 不可用→MISSING/UNVERIFIED 不猜測",
      "locator": "B1 DOC-00 §§3–4; r10 Report §6"
    },
    {
      "step": 6,
      "action": "修 PIPD Stage-C WriteSet 並確認 Oracle/Profile/TQAEP 介面",
      "success_criteria": "最新 HEAD offline-gate + public-plugin-verify 綠，拒收負例仍紅",
      "if_fail_then": "不得擴允許集合；記 CR_ORACLE_001_OPEN",
      "locator": "PIPD Runs 40450463928/40450464119; P4 skills"
    },
    {
      "step": 7,
      "action": "查證非 Commander SBL plan.propose 並執行 GWO×3",
      "success_criteria": "真 Proposal + HGK Issuer + 3 domains 分離 RAW/Checker",
      "if_fail_then": "無 ABI→最小正式修補；禁 Commander-SP",
      "locator": "B1 DOC-08 L17 L31 §§1–3"
    },
    {
      "step": 8,
      "action": "G-A/G-B 真合取與 Final seal/handoff",
      "success_criteria": "Issuer/Queue/Loaded/Served/Checker PASS + revocation successor；seal重算",
      "if_fail_then": "Gate 未過維持 HOLD、保留可重入卡而非假 PASS",
      "locator": "B1 DOC-00 §4; B1 DOC-08 §4; r10 Handoff"
    }
  ],
  "open_items": [
    {
      "id": "CR_ORACLE_001_OPEN",
      "type": "CR_OPEN",
      "desc": "PIPD DOC-07 Canonical 與 Legacy DOC-03 DOMAIN_ORACLES 的正式 Ratification 未閉合",
      "locator": "r7 report §5.3; P4 pipd-pi-compile; PIPD PR#20"
    },
    {
      "id": "CR_OPEN-STAGE-C",
      "type": "CR_OPEN",
      "desc": "PIPD public-plugin-verify ADR-0008/0009 WriteSet 首失敗",
      "locator": "Run 40450464119 Job 122011714859"
    },
    {
      "id": "CR_OPEN-USER-TRUST-RECEIVER",
      "type": "CR_OPEN",
      "desc": "user_trust Profile 未接 native_admission.REGISTRY",
      "locator": "r10 Report §4"
    },
    {
      "id": "CR_OPEN-R2-RUNTIME",
      "type": "CR_OPEN",
      "desc": "Hermes 真 Executor/可用喚醒未證",
      "locator": "r10 Report R2; r9 Report §2"
    },
    {
      "id": "CR_OPEN-R3-R4",
      "type": "CR_OPEN",
      "desc": "Fabric Stage Active Loaded 與三車道 Served 未執行",
      "locator": "r10 Report §6"
    },
    {
      "id": "CR_OPEN-DOC08-SBL",
      "type": "CR_OPEN",
      "desc": "Commander-SP 禁用下合法非 Commander Proposal ABI 尚未證",
      "locator": "B1 DOC-08 L17/L31; r10 command §4"
    },
    {
      "id": "CR_OPEN-PIPD-PROFILE-TQAEP",
      "type": "CR_OPEN",
      "desc": "12→9 風險軸投影與 TQAEP Design/Live 分離未閉合",
      "locator": "PIPD DOC-06 §5; P4 Skills"
    },
    {
      "id": "MISSING-R10-RAW-5",
      "type": "MISSING",
      "desc": "r10 Manifest 中五個未上傳原始證據位元",
      "locator": "r10 Manifest entries emit_r10.py/PIPD_CE2_RECEIPT.json/pipd_full.txt/TRIGGER_REMOVAL_RECEIPT.json/USER_TRUST_RECEIPT.json"
    },
    {
      "id": "UNVERIFIED-LOCAL-HEAD",
      "type": "UNVERIFIED",
      "desc": "Windows 四庫 HEAD/Dirty/Host Imported/r10 commit 等須現場重新讀回",
      "locator": "r10 Handoff/Resume; PR refs"
    },
    {
      "id": "MISSING-ISSUER-AO",
      "type": "MISSING",
      "desc": "真正高保證 Signer/Checker 身份與正式 Native Signed Receipt",
      "locator": "r10 Handoff signed_receipt=null"
    },
    {
      "id": "MISSING-HERMES-EXECUTOR",
      "type": "MISSING",
      "desc": "Hermes 真 Executor Hook、可自主喚醒並續行的 Runtime RAW",
      "locator": "r10 Report R2; stop-root-cause RC-1"
    },
    {
      "id": "MISSING-FABRIC-R4",
      "type": "MISSING",
      "desc": "Fabric Activator/Loaded Consumer 與三 Lane Served 的現役 RAW",
      "locator": "r10 Report §6"
    },
    {
      "id": "MISSING-PIPD-INVOKE-TRACE",
      "type": "MISSING",
      "desc": "初次 B1 包的 P4 Skill 真工具調用軌跡不在本對話中",
      "locator": "PIPD 與 B1 失效鑑定 §2/§7"
    }
  ]
}
```
