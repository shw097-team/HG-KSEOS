# FHS-MSC B1｜Codex 高自動化降治理續工薄指揮令 r5

> **本指令直接交給 Windows 本地 GPT Desktop／Codex 執行。** Mission 保持 `FHS-MSC-B1-CODEX-CONTINUOUS-REPAIR-20261026-R1`；ChangeSet：`CONTINUATION / B1_BOOTSTRAP_REPAIR`。本指令**完全取代此前 r1～r4 的執行 Prompt 與衍生長流程**；過去的執行報告、Checkpoint、Evidence、B1 正式設計文件仍是事實與規格來源，不能丟失。
>
> **嚴禁載入、調用、依賴 `sbl-commander-sp`／Commander-SP 外掛、Skill、代理或其指揮流程。** Commander-SP 是待修復的 SBL 產品部件，不能作為本次 Codex 施工者或驗收者。直接使用 Codex 原生程式編輯、終端機、測試、Git 和合法 Windows／HGK／Hermes API；既有系統的原生權限驗證仍須生效。

## 1. 唯一目標及常設工程授權

OWNER 一次性委派：**自主查核 → 最小修復 → 測試 → 排錯 → 再修 → 受控整合 → 生效讀回 → 獨立驗收 → 下一個受影任務**。不需為日常原始碼修改、隔離 Worktree、測試、候選版控、合理設計選擇或合法且可逆的工作反覆詢問；任何可由既有實體來源判定的工程細節直接裁決、紀錄並執行。**不要停在規劃、候選、文件或例行詢問。**

本次僅修好 HERMES／HG-KSEOS／Fabric／SBL 的 **B1 最小原生施工能力**，包括 R1～R4、G-A、三個 Golden WorkOrders、G-B、外援撤銷與原生接管。後續完整 `SBL_PIPD-LS-PKG_DOC-00～13`／FHS-MSC 產品工程由恢復後的 HGK／Hermes 接管，Codex 不藉本任務自行展開完整產品或 SWOF W3。

**硬界線只有四項：** ① 不偽造 OWNER／Native 簽章、Token、Issuer 或有效 Permit；② 不用 Maker 自驗取代實際獨立 Checker；③ 不覆寫使用者既有 dirty/untracked、私鑰、資料或其他 Repo；④ 不繞過真正生效的 Policy／Compiler 阻斷進行未獲准的 Live／UserData Effect。若缺少上述外部條件，只停住受影效果，**繼續所有可授權的修復與驗證**，將待 OWNER 在本機完成的動作壓到最小且只提出一次。密鑰一律不進對話、日誌、提交與 PR。

## 2. 從 R4 現況立即續行，不重啟調查

工作位置為 `C:\Projects\Agent_Workspace`；B1/FHS/SBL 規格位於其知識庫 `...\Fabric vNext\Semantic World OS Fabric\SBL_PIPD`。以**實際本機文件**的 `FHS-MSC_藍圖_r2`、`SBL_PIPD-LS-PKG_DOC-00～13`、`FHS_MSC_B1_PIPD_LS_PKG_00～08` r3 為上位規格；只查當輪受影條款，不複製大量正文。

直接接續以下 R4 實體附件與其 ZIP 內來源：`R4_EXECUTION_REPORT.md`、`NATIVE_OWNER_ACTION_PACKET.json`、`B1_R4_Evidence.zip`；既有 R4 Evidence 子目錄 `01_source/`、`02_contract/`、`03_native_recovery_candidate/`、`05_check/`、`07_handoff/`、`08_final/`。對 ZIP 只讀、安全解包**選定的程式及資料**到隔離位置；禁止執行壓縮包內來源未經檢視的腳本。

已證實可直接復用：read-only child Compiler 4/4 PASS；Admission 候選 **53/53 Maker tests PASS**，SHA `0cd01331f380ca714a08b6e3125e0e17c0770a9e965674cb575418ba229ed634`；Oracle 候選 **16/16 Maker tests PASS**；Source Subject Manifest SHA `cba81646ba88955499b899518292e1ed54354157f6dcf687e0567f30842f0581`。目前 **Live B1 Native PASS=0**；effectful Compiler `PL-003×2 + PL-004×1`；原始身份 `27／31／120／124／38／949／192／81` 不減少。上述是起點，**不是原生已驗收**。

四個原 root 的 Git HEAD 與 dirty 清單以 `08_final/B1_R4_CHECKPOINT.json`／`01_source/ROOT_CURRENTNESS.json` 為基準，開始前只做**快速新鮮度核對**；大量 untracked 不重複全盤分析。必要修改採獨立 worktree 或原有合法工作區；先 pin Root/HEAD/目標檔案/寫入範圍及 preimage。禁止 `git reset --hard`、清除 shared files、強制推送。未被影響的前輪 PASS 不重跑。

## 3. 最高優先：把 Native Trust 缺口修成可正式啟用的功能

這是**真正第一修復工作**，不要再長時間搜尋已證明不可發現的發行端點。依 `NATIVE_OWNER_ACTION_PACKET.json`、`TASK_KIND_PROVENANCE_GRID.json` 與隔離 `admission_components.py`，在 HG-KSEOS **現有唯一控制平面**內做最小整合：

1. **Topology／TaskKind：** 現役 Stack Manifest 引用 `HGK/HGK_TASK_TOPOLOGY_POLICY.yaml`，但該檔自首次 tracked commit 就缺失，已有界歷史與 projection 搜尋無可恢復的核准版本。先從現存 HGK 使用點、既有規格與 Registry 形狀推導**最小新版本候選**，標明它是新補訂而非歷史批准檔；提出清晰 Kind 名稱／語意／Owner／相容性／拒收測試。若需正式註冊，走真正 HGK Owner 在 Host 的受保護登記路徑，不能把未核准 YAML 直接載入成 authority。
2. **Signer／Verifier／Trust：** 復用既有 HGK Shared Spine `create_taskspec`／`create_workorder` 所屬的 Receiver／Canonical State，不另建 Issuer、Scheduler 或 DB。整合先前的 admission preflight，補齊受保護 Owner 公鑰／purpose／policy／revocation reader、真正的驗簽、nonce/lease 原子 consume/CAS 與 effect-time Root/HEAD/handle 驗證；密碼學 canonicalization 須有確切版本和跨語言測試，不把 RFC 公開測試金鑰註冊為 Native trust root。**不得由 Codex Maker 自行簽自己的准入或控制本機私鑰。**
3. **最低阻力的首次信任啟用：** 優先使用**已存在且有權限隔離**的 HGK/Fabric 管理員與 OS 保護金鑰機制。若真的尚無受保護簽發基礎，先完成最小維修／註冊程式與 RED/GREEN 測試，再產生**單一可直接操作的本機 Owner 啟用步驟**：實際 UI/CLI、批准的精確目標 SHA、Root/HEAD/WriteSet、信任根來源、回讀結果和撤銷方法。只有由**真實有權管理員身分**啟用後才能當作生效；沒有該身分或操作環境時不要假造成功，也不要再要求模糊的「請提供端點」。
4. **Oracle：** 正式採用 DOC-07 Oracle/Fixture authoring 與 P4 legacy `DOC-03 DOMAIN_ORACLES` serialized ABI 並存的相容處置；Canonical DOC-03 Environment-Binding 是另一 namespace。整合隔離候選的 duplicate-key、schema pin、TraceLink hash/foreign-source 拒收與 legacy roundtrip；保留已安裝 P4 byte/schema，正式 Ratification 和獨立 same-subject regression 另由有效 Owner/Checker 流程完成。不要改原生 REQ enum。
5. **真正整合，而非再留一份孤立候選：** 在合法、精確許可的最小產品 WriteSet 實際落入修補與測試，完成受影 negative/rollback；若現役 Policy 限制目前只能隔離開發，就完成**可直接套用的受限 patch/branch＋本機 Owner 一次性啟用作業**。不要靠刪 `PL-003/PL-004`、修改 Compiler 程式、偽造 source 欄位或自簽票據求 PASS。

`RECOVERY_READONLY` 的 Compiler PASS 不等於 `B1_EFFECTFUL` PASS。**只有 Native Trust／正式 SourceFreeze／Oracle Ratification 與 TaskKind 真正閉合後，才針對已更新的受影 Subject 重跑一次 effectful 四階段 Compiler；若內容再次改變才重編。** 無進展時禁止無限重試同一個 `PL-003/PL-004`。

## 4. 由 Codex 自動連續執行的施工 DAG

在第一項合法准入閉合前，先進行所有不需 Live Permit 的：隔離程式整合、單元與安全反例、Host 真載入路徑只讀查核、各 Repo 適用性差異比對、Owner 啟用工具測試、Checker 配置與獨立測試環境準備。

准入成立後**立刻、不再徵詢普通工程同意**，用現役 HGK 發行的真實 Permit/ECP 依序完成：

- **R1 Issuer／Grant：** subject／issuer／nonce／TTL／epoch／scope 的正負例；過期、未簽、重播、錯 scope → 零非法 Spawn。
- **R2 Hermes Queue／Lease：** 真實 active import path、A blocked 時 B/C 仍公平前進，CAS lease_generation、durable cursor、restart/reconcile、UNKNOWN_EFFECT 不盲重播。
- **R3 Fabric：** 真實 `Stage → Active → Loaded → Consumer ACK` 同一 epoch/SHA；Stage-only、錯版、反向 projection NACK；測 rollback。
- **R4 Model Lanes：** 找真實簽核 policy epoch 和 served arm；修 registry 的 PLAN/VERIFY_SECURITY 宣告與 OpenCode transport／epoch 漂移；實測 required=served、不同權限 principal 及最小 restart。不要再重跑已證明 `changes=0` 的純 resync 當修復。
- **G-A：** 將上述真實效果、必需 method invoke、Provider/Host 和分離 checker 的同 Subject 收據做合取 Gate，缺一不能宣稱 PASS。
- **三個 GWO：** `GWO-FABRIC` 真 activate/load/consumer ACK；`GWO-HGK` 真 permit/lease/可逆 native effect；`GWO-SBL` 真 Host install 與**分離、經同意的 USER issuer**執行 TODO `init → add → new-process list → remove --id → list → uninstall`。三者不同 operation_id/resource/Raw，真 POS/NEG/EDGE/SEC；不可用 Maker 模擬取代。
- **G-B：** 撤銷有綁定的 Codex 外援 grant（若不存在須驗證，而非假造 revoke）；關閉外援 session 後，由 HGK/Hermes 真 durable scheduler **自行**簽發／領取／完成下一張工作；舊 token 被拒、沒有外援觸發的 next-session raw。
- **接管：** 將原 22-node 後續 Full Product DAG 保留正式責任與未完成依賴，交給 HGK/Hermes 合法 admission/queue，取得真 ACK；本任務不代做完整產品。

## 5. 每輪自排錯／自測／自修與最小停損

一輪只做：**讀最新 HEAD/Policy → 最小 patch → RED/GREEN 與受影回歸 → 真載入／回讀 → 若合法則獨立 Checker → Checkpoint → 下一 WO**。對同一失敗根因兩次無效修補後更換診斷假設，不無限重跑。只 PARK 受影 branch；其他獨立工作持續。涉及不可逆資料、真簽章管理員權限、獨立檢查員或使用者資料同意時，建立精確單次 Handoff，不以一般聊天授權冒充這些實際能力。

每張 B1 WO/OBS 仍以 r3 DOC-02 原始 EffectClass 區分 READ_ONLY／REPOSITORY_WRITE／HOST_OPERATIONS／USER_DATA_EFFECT；READ_ONLY 不造 ECP；DEV/OPS/USER 分離。只運行目前 **實際適用且有有效 Runner/Owner** 的測試；PASS 必有受影實測及可信證據，其餘如實標記 HOLD/NOT_RUN/N_A及來源原因。保持原始：27 Atoms、31 WO/OBS、120 Parent、124 Child、38 Nodes、949 R15（66 Required／254 Conditional／629 Deferred）、192 cells、81 assets。**身份覆蓋不代表真效果通過，也不等於安裝全部供應技術。**

Code Review、Unit tests、negative security tests、Host readback 可以由 Codex 做自測；**獨立驗收須另一個真實、隔離的 Checker principal**，不能把同一工作者換名為「自驗收」。如果無 checker，完成所有前置測試並只 HOLD 最後 Acceptance。

## 6. GitHub、輸出與唯一完成定義

對屬於已確認 owner repository 的正式修補，測試通過後推送**最小、去敏、可回滾**的候選分支／PR：`shw097-team/SBL`、`shw097-team/Fabric`、`shw097-team/PIPD-LS-SP`。各自先驗證本地 origin；HG-KSEOS 目前無合法 remote，**不自動當成 Fabric 可公開來源**。如需憑證，本機 `C:\Projects\Agent_Workspace\API KEY\GITHUB-REPO_SHW097-4.txt` 只經不輸出 Token 的 OS credential helper／隔離 Git 認證使用，不讀給對話，不放 Git remote、命令列、log、source、PR。推送後 readback 真遠端 SHA/CI；未合併候選不是 Native Loaded。

僅需一份簡明滾動狀態和小型機器可讀 checkpoint：`phase,first_fail,changed_repo/path,HEAD,policy/epoch,tests,real_effect,Gate,independent_checker,PR,rollback,next_action`。復用舊 31/120/124 等 Ledger，不每輪重新產生巨量平行文件。每次切換真正外部需求才回報 Owner，寫出**一個具體操作及實際阻擋**。不要把視窗停掉、最後一句話或 Prompt Compiler PASS 當任務完成。

**可宣告 `FHS_MSC_B1_PIPD_LS_PKG_COMPLETE` 的必要條件：** 所有 B1 必需身份與受影測試合法結案；正式 Native Admission、生效 Trust/TaskKind/Oracle、R1～R4、G-A、三 GWO、G-B 全有同主體 Raw+實際 Reader ACK、獨立驗收與 rollback；外援撤銷且 HGK/Hermes 新 session 自主續工；後續 22-node Native 接管真 ACK。缺項則繼續合法工作或呈現**具名真實外部不可替代阻斷**，不得用漂亮總結冒充完成。

**現在開始：從 R4 Checkpoint／已完成候選直接進入「最小可信 Native Trust/TaskKind/Oracle 修復」；不要讀取或執行任何舊 r1～r4 指揮 Prompt，也不要調用 Commander-SP。沿著以上 DAG 自主連續推進。**
