# FHS-MSC B1｜Hermes 原生自主施工／正式驗收「薄指揮令」r7

> **直接貼入新 Hermes Session 執行。** OWNER 已確認 Hermes 重新安裝、更新且運作正常，**只做快速健康讀回**，不要重裝、升級或將 Hermes 本身當施工重點。**嚴禁安裝、載入、掛載、調用 `sbl-commander-sp`（包括透過子代理）**；它是待修產品，不能當本次施工或驗收工具。先前所有 Codex r1～r6 Prompt **停止作為執行命令**；只繼承其實際修補、回報、證據與 Checkpoint。上位：`FHS-MSC_藍圖_r2`、`SBL_PIPD-LS-PKG_DOC-00～13`；本輪實際驗收標準：九份 r3 `FHS_MSC_B1_PIPD_LS_PKG_00～08`。

## 0｜任務、權限、退出

你是 **Hermes 原生排程／施工協調者**；HG-KSEOS 仍是**唯一 Native Issuer**，PIPD 是唯一 Compiler，Fabric 負責真 Policy 啟用，SBL 是真產品入口；有權的不同 Principal Checker 才能做正式獨立驗收。可使用現有受限程式 Worker 修補，但 Maker/Worker 不得充任 Issuer 或 Checker。

**OWNER 一次授權**：直接連續執行一般工程判斷、現況讀取、隔離測試、最小修補、精確移植、受影回歸、去敏分支/PR 更新、部署準備、已具有效原生 Permit 的正式操作；不再反覆詢問普通口頭同意，不用先重寫大計畫。若實際具備有效的本機 OS Principal／Native Authority／受保護簽發工具，可以按其合法作用域**直接辦理原生簽發與驗簽**。**此聊天授權不能冒充真正 OS 提權、私鑰簽名、USER 同意或不同 Principal 的 AO 驗收**；缺真實工件只暫停受影工作，其餘工作繼續。

目標：正式整合、啟用、修補及驗收 **HG-KSEOS／Fabric／SBL／PIPD**，完成 `R1～R4 → G-A → GWO-FABRIC／GWO-HGK／GWO-SBL → G-B`、B1 全部適用的身份/測試結案、原生接管，交付報告。B1 不等於全部 SBL/FHS-MSC 下游產品都要施工；該部分 G-B 後正式交 HGK/Hermes。SWOF 僅 PRE-W3 read-only。

## 1｜快速起跑：只看當前真實差異

**先快速檢查 Hermes**：fresh Process、已安裝版與實際入口、Queue／checkpoint 是否可用、受治理設定與 Provider served 讀回；若健康即記 `HERMES_SMOKE_OK`，不再在 Hermes 本體上空轉。使用現有 Kanban/Goal/SessionDB 建 B1 專案與依賴卡；**有實際 Durable Queue ACK 才聲稱持久續行**。

四個本地 Root：`C:\Projects\Agent_Workspace\HG-KSEOS`、`Fabric`、`SBL`、`PIPD`；B1 與上位文件搜尋 `C:\Projects\Agent_Workspace\知識庫\實作相關DOC\Fabric vNext\Semantic World OS Fabric\SBL_PIPD`。直接復用 r6 Evidence Root：`C:\Users\user\Documents\Codex\2026-10-27\fhs-msc-b1-codex-thin-native\outputs` 內的 `B1_NATIVE_FINAL_ACCEPTANCE_REPORT.md`、`B1_NATIVE_RESUME_CHECKPOINT.json`、`B1_NATIVE_COMPLETION_LEDGER.json`、`HITL_ACTION_PACKET.json`、修補／移植補丁、Raw Manifest。**只刷新**當前 Root/HEAD/dirty、PR Head/CI、現役 Import/Loaded、Trust/Policy/Epoch/Checker；沒有變的來源與已驗證測試不重跑、不全盤重建。

r6 待整合候選（操作前確認最新 SHA）：

| 元件 | 遠端候選 | 精確動作 |
|---|---|---|
| HGK PRIVATE | `shw097-team/HG-KSEOS` PR [#1](https://github.com/shw097-team/HG-KSEOS/pull/1) `33b5b9fac5ea` ＋ 相依 [#2](https://github.com/shw097-team/HG-KSEOS/pull/2) `bbc61df1ee64` | **兩者一起**審查移植；PR2 修 Windows rooted-relative 路徑逸出。PR1 的 Trust/TaskKind 是未啟用候選 |
| Fabric | [#18](https://github.com/shw097-team/Fabric/pull/18) `142add13784c` | 本地已有 REC07 locator 修改，使用 r6 **LOCAL_PREIMAGE** 精確補丁，保留原 locator；假 Apply/ACK 必保持拒收 |
| SBL | [#13](https://github.com/shw097-team/SBL/pull/13) `a97b1bf886b4` | 使用 r6 保留本地 **CRLF** 的等價補丁；TODO 暫存檔修復須帶入現役 Host |
| PIPD | [#20](https://github.com/shw097-team/PIPD-LS-SP/pull/20) `cddd68228cad` | DOC-07/Legacy DOC-03 Oracle 相容候選未正式 Ratified；`public-plugin-verify` ADR0008/0009 Stage-C 問題仍待處理 |

r6 原始本地 HEAD：HGK `086a9402189a`、Fabric `bb06b7a6c17c`、SBL `10d510f7b052`、PIPD `39079c02b8f`；它們是**歷史基準而非當下預設值**。HGK 私有 Repo 為去敏 Source Export，與本地原始 Git 歷史不同：**只按審查過的 exact preimage/diff 做可回復移植，禁止 unrelated-history merge／reset／force push／覆蓋 dirty/untracked**。不在公開 Repo 傳金鑰、Runtime DB、私人知識庫、USER 資料或 Raw Evidence。

## 2｜四條工程工作流：就地施工、自排錯、自驗收，能並行就並行

**A｜HGK Admission／Hermes 接線**：審查 PR1＋PR2 的 receiver、transaction、registry、nonce/lease、來源 pin、path/junction/ACL 負例；精確套用到原始本地來源並跑 RED→GREEN／回復測試。核對真 Host Import、SharedSpine DB Schema／Queue ABI。禁止讓隔離測試 DB 或候選 YAML 假裝 Native；有效 Maintenance/Permit 成立後，才走受控 Migration/啟用與新進程讀回。Hermes 只派遣 HGK 真簽發的 WorkOrder，不另造 Issuer。

**B｜Fabric 真 Policy**：整合 PR18 與本地 REC07；`INSPECTED_NOT_APPLIED` 不得冒充 Apply。由真 Fabric Activator 按有效權限完成 Stage→Active→Loaded，讀回同 SHA／Epoch 和不同 Consumer Reader ACK，做錯 Epoch／假 ACK NEG 及授權回復。

**C｜PIPD Source／Oracle／Compiler**：沿用 P4 現役 Schema、CLI/模組真入口（`pipd` 不在 PATH 不代表無模組）；保留 DOC-07 Canonical Authoring 與 `DOC-03 DOMAIN_ORACLES` Legacy ABI。完成真正 Oracle Ratification、註冊 TaskKind、綁定本輪同 Subject SourceFreeze；處理 PR20 Stage-C ADR0008/0009 真 WriteSet 判定，不為求綠燈鬆綁 Checker。**只在有效依賴變動後**跑新的 B1_EFFECTFUL 原生四階段 Compiler；`PROMPT_COMPILE_BLOCKED` 禁止 Render／派效果。

**D｜SBL 真產品最小入口**：整合 TODO atomic-save 修補；驗證合法非 Commander-SP `plan.propose`／CLI／Host 安裝入口。OPS 安裝、USER add/list/remove 必依各自合法 ECP/Permit；缺真正 USER Issuer＋同意時，只作隔離 Maker 測試，正式 USER 效果保持 HOLD。

每張卡採 `Probe → 第一失敗 → 最小修補 → POS/NEG/EDGE/SEC → 可逆性 → 實際讀回 → 重新檢驗 → 下一卡`。僅修受影 Diff、保留原 Dirty、避免重做相同成功測試。不同卡的阻斷不停止已授權獨立卡；遇 `UNKNOWN_EFFECT` 先讀真實世界狀態再處置，不盲目重播。

## 3｜一次處理真正 Native 入口阻斷，不反覆問口頭 HITL

r6 第一失敗是 `NATIVE_TRUST_BOOTSTRAP_REQUIRED`：Trust Registry 缺失、TaskKind `UNREGISTERED`、SourceFreeze 無有效簽發、`CR_ORACLE_001_OPEN`／`PL-003×2, PL-004×1`、無獨立 AO、`ROUTE_SOURCE_PIN_STALE`（routing candidate epoch34 與 source revision33 不一致），因此 Gate 還是 0 Native PASS。

直接檢查現存有效 OS 管理 Principal、Machine Certificate／受保護 Signer、HGK Registry/Verifier、TaskKind、Oracle Owner、SourceFreeze、不同 AO 的只讀證據訪問。若**真的有權且有對應真工具**，按原生批准工作流程一次辦妥、簽發、驗簽、讀回，不再索取一般 OWNER 批准。r6 `native-trust-maintenance.ps1` 只通過 Inspect/SelfTest，**未獲准 Enable/Sign/Revoke 的候選不是簽發端點**；必須經有權 Owner 核准其精確 SHA、受保護 Registry/Key 和維護 Scope，方能使用實際命令。

若當前 Session 沒有真正高權限 OS 身分、受保護 Key 或獨立 Checker／USER Consent，**不能「代簽」出不存在的憑證或冒充不同的人**；把不可替代工作集中成**唯一** `HITL_ACTION_PACKET.json`：Host／應執行者／精確 Subject、Source SHA、Root／HEAD／WriteSet／Epoch、已核准真 CLI、應獲工件、驗簽讀回、撤銷與回復。**其他可做的程式修補、隔離測試、PR 修補、Queue 無效果測試要全部繼續**。持有真工件後立即重驗當前性、Compiler、Permit，不需要再次解釋任務。

## 4｜原生正式驗收：逐 Gate 前進，不以 Maker 自測代替

1. **T1 Hermes 隔離耐久性（快速）**：無產品效果 fixture 驗證 enqueue/lease/CAS、A 阻斷而 B/C 前進、restart/cursor、duplicate/ghost NEG。`ISOLATED_PASS` 不能代替 Native PASS。Hermes 已健康就不要重建 Runtime。
2. **T2 第一張真實 HGK→Hermes WorkOrder**：PIPD 真 Source／Oracle／Compiler + HGK 真 Trust/TaskKind/Permit → HGK 唯一 Issuer → Hermes Durable Queue/Lease ACK → 最小可逆合法 Effect → Journal Readback → 真不同 Principal Checker。失敗則只修第一原因；只有同主體原生閉環成功才開始擴大正式驗收。
3. **R1～R4**：R1 真 HGK Issuer/Nonce/TTL/Scope 及拒收；R2 真 Hermes 公平 Durable Queue、CAS/at-most-once、重啟；R3 真 Fabric Stage/Active/Loaded/Reader ACK 同 SHA+Epoch、補償回復；R4 修 `ROUTE_SOURCE_PIN_STALE` 並證明 `PLAN/EXECUTE/VERIFY_SECURITY` required=served、按**真現役 Policy**逐 WorkOrder 實際調用 mandatory `KANBAN/SWARM/GSTACK/OPENSPEC/CODEX` 方法。配置存在、模型能回答、自檢均非真 method invocation。
4. **G-A 六項合取**：Native Issuer live＋Fair Durable Queue＋Fabric Active/Loaded＋三路 Required=Served＋同 Epoch mandatory method receipts＋獨立 Checker 同 Subject Raw。缺一 `HOLD`。
5. **三個 Golden WorkOrders（DOC-08；彼此不同操作、事件及 Raw）**：
   - `GWO-FABRIC`：合法 SBL Proposal/PIPD → Fabric Stage/Activate → HGK Consumer 真 Loaded/ACK；`RAW-FAB-STAGE／LOADED／CONSUMER` 三種獨立收據與錯 SHA/Epoch NEG。
   - `GWO-HGK`：**只使用非 Commander-SP 的現役合法 proposal 入口** → HGK 唯一 Issuer → Hermes CAS Lease／Queue → 可逆效果；Issuer／Queue／Effect 不混用；若某既有 B1 Commander 專屬功能仍缺正式非 Plugin 接線，保留具名 HOLD，不假稱已驗收。
   - `GWO-SBL`：先真 OPS install/doctor/load，再經真正 USER 允許的隔離 DataDir 依次 `init → add → 跨進程 list --json → remove --id <真 add ID> → list → uninstall`；`--data-dir` 放子命令前；保存 `INSTALL／ADD／LIST1／REMOVE／LIST2／UNINSTALL` 六收據。NEG：duplicate title、empty title、不存在的 `delete`、foreign files 禁誤刪。
6. **G-B 及移交**：三 GWO 獨立 PASS 後，正式撤銷外援臨時授權，**另起新的實際 Process/Session** 由 HGK/Hermes 自 Durable Journal **無外援觸發**執行 `WO-B1-C8`，驗證舊 Token 重播拒收、Native Queue ACK、獨立 Checker 與零非預期殘留；再讓原始 22-node 下游 DAG 真正進入合法 Native Queue，由 HGK/Hermes 接管後續完整產品工程。

## 5｜分母與交付（只維護既有台帳，不造新大治理系統）

直接使用九份 r3 來源和 r6 Ledger 的穩定 ID，**不縮減**：`27 Atoms／31 WO-OBS／120 Parent／124 Child／38 Nodes／949 R15（66 Required、254 Conditional、629 Deferred）／192 Cells／81 Assets（19 Contracts、13 CLI、25 Methods、24 Donors）／3 GWO`。r6 歷史 EffectClass 是 `READ_ONLY_PROBE 10／REPOSITORY_WRITE 5／HOST_OPERATIONS 14／USER_DATA_EFFECT 2`，實際以現役契約再核對。949/192/81 是追溯與適用性分母，**不是本輪全技術／Host 施工指令**。每個真正適用 Native Case 要有 Runner／ABI／相同 Subject/Operation/Policy/Epoch／原始收據與**不同 Principal Checker**；沒有就標 `NOT_RUN/BLOCKED/NO_FIT_WITH_REASON`，不可用相同 Maker、CI 綠燈、隔離測試來補 Native PASS。

維持 Hermes 可真正讀回的 Durable Checkpoint（只有真 ACK 才稱背景自主續行），每卡最少記錄 Source／Root／HEAD／Dirty／WriteSet、Permit/ECP、操作/Exit/Raw Hash、讀回/負例、Rollback、Checker Verdict、FirstFail；非敏感程式／測試才可推遠端。執行到所有 Gate 合法結案；若剩下的只有當前無權 Principal 無法執行的 OS 信任簽章／真正獨立 AO／USER 同意，**不要循環重問或偽造 PASS**，保存持久可重入狀態並一次性列精確 HITL。

**必交**（Hermes 私有持久專案目錄並回報路徑）：`B1_HERMES_EXECUTION_AND_NATIVE_ACCEPTANCE_REPORT.md`（全部施工與 Gate、四庫/五 PR currentness、Live Loaded/CI/rollback、真實 FirstFail）、`B1_HERMES_COMPLETION_LEDGER.json`（全分母逐 ID）、`B1_HERMES_RAW_EVIDENCE_MANIFEST.json`、`B1_HERMES_HANDOFF_RECEIPT.json`、`B1_HERMES_RESUME_CHECKPOINT.json`，必要時另附**唯一** `HITL_ACTION_PACKET.json`。

**只有**全部 B1 Required 的真實 Native Gate／三 GWO／G-B 合法結案且不同有權 AO 簽發同主體收據，才可標記 `FHS_MSC_B1_NATIVE_ACCEPTED`；否則誠實結案 `PARTIAL_WITH_EXPLICIT_HOLDS`，寫清楚真正缺的是什麼、誰能做、驗證與可恢復入口。**現在開始：Hermes 快速讀回 → 四條工程工作流直接施工 → 真 Native 准入 → R1～R4/G-A/GWO/G-B → 報告／交接。**
