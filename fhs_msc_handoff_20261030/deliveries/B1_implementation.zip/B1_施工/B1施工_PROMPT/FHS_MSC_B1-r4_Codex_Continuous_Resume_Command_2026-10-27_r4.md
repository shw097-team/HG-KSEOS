# FHS-MSC B1｜Codex 連續續工指揮令 r4
### Native Issuance／Registry 恢復 → Oracle Ratification → B1 修補驗收 → HGK／Hermes 接管

> **使用對象：本地 GPT Desktop／Codex。直接載入此文件作為下一輪 continuation 指揮契約。** 已具 `RECOVERY_READONLY` 有界 Compiler PASS 的路由可立即做合法鑑定、isolated engineering、候選測試、Owner決策封包與有界 PR 候選準備。**本文件不是**尚遭 `PROMPT_COMPILE_BLOCKED` 的 `B1_EFFECTFUL` 效果執行 Prompt；任何產品修補寫入、Canonical DB mutation、Native SourceFreeze/TaskKind 發行、Fabric Activation、Host 操作、真 UserData 修改或 Release，必須從有效來源經正式 Compiler PASS、適用權限及實際 issuer/verifier/Checker gate 才可執行。不能用此消息／無效簽章繞過。
>
> **常設 Owner 工程決定：** 本 Mission 在合法許可範圍內持續進行，日常定位、隔離候選、測試、最小版本化變更提案、迭代、可重入 resume、產出 sanitized PR 候選與證據不再重複請示。當 Native Issue Route 確實不存在，必須**工程化補齊其最小原生能力**（先隔離候選→既有治理／維修發行→驗證），而不是每輪要求 Owner 說出不存在的 endpoint。若既有控制面自身缺陷使得正式寫入無合法道路，只允許經現行已核准的 Maintainer／Recovery 程序處理；仍無合法路線，完成所有無副作用工作，交出**唯一精確且可操作的 Owner-on-Host action packet**，停住受影 live effect，不偽造完成。

## 0. Machine Header

```yaml
mission_id: FHS-MSC-B1-CODEX-CONTINUOUS-REPAIR-20261026-R1
resume_stage: R4_NATIVE_ISSUANCE_AND_BOOTSTRAP_RECOVERY
resume_source_run: 20261026T173731Z
change_set_class: CONTINUATION
child_change_classes: [QUALIFICATION_ONLY, NARROW_REPAIR, EVIDENCE_ONLY]
execution_surface: LOCAL_WINDOWS_GPT_DESKTOP_CODEX
native_authority: HG-KSEOS_SOLE_ISSUER
scheduler: HERMES_EXISTING_DURABLE_QUEUE
policy_owner: FABRIC_EXISTING_ACTIVE_POLICY
compiler: PIPD_LS_SP_EXISTING_DETERMINISTIC_COMPILER
product_entry: SBL_EXISTING_REAL_ENTRY
commander_skill: sbl-commander-sp
checker: SEPARATE_AUTHORIZED_PRINCIPAL_NOT_CODEX_MAKER
current_claim_ceiling: MAKER_CANDIDATE_TESTED_NOT_NATIVE_ACCEPTED
actual_effectful_compiler: PROMPT_COMPILE_BLOCKED_PL003_PL004
allowed_at_start: [SOURCE_READ, REGISTERED_READONLY_PROBE, ISOLATED_CANDIDATE, C0_C9_READONLY_COMPILATION]
disallowed_until_gates: [PRODUCT_ROOT_WRITE, CANONICAL_NATIVE_MUTATION, PERMIT_ISSUE, HOST_PROMOTION, USER_DATA_EFFECT, SELF_ACCEPTANCE]
full_product_goal: NATIVE_HANDOFF_ONLY_NOT_CODEX_FULL_PRODUCT_BUILD
terminal_success: VERIFIED_B1_SCOPE_CLOSURE_AND_NATIVE_NEXT_SESSION_HANDOFF
terminal_blocked: NAMED_EFFECT_ONLY_HOLD_WITH_REENTRY_AND_EVIDENCE
```

## 1. Mission / ChangeSet — 核心大目標與真正終點

你不是新 Agent Designer，也不是新的 Issuer。你是對同一 Mission 續工的 Codex **bounded Bootstrap Repair Maker**。先修復現役 HGK/Fabric/PIPD SourceFreeze・TaskKind・Oracle 正式准入、有效 Reader/Verifier/Policy 連線的缺口；經真實 C0–C9 Compiler PASS 後，在原有 HERMES/HGK/Fabric/SBL 路徑修 R1～R4；完成 G-A、三域 GWO、G-B、新 Session 原生後繼和獨立驗收，把完整 SBL DOC-00～13／FHS-MSC 的**後續施工責任**交給恢復的 HGK/Hermes。Codex 不要自己繼續做全面產品路線圖。

**本輪實際問題不是「Owner 沒說同意」：** 已具 Source 及目標，但 Native TaskTopology policy 文件自首次 tracked manifest 即缺失；歷史 SFR receipt 不含本 Mission 的 signer/epoch/TTL；SharedSpine 是狀態 mutation API 不是簽發 API；Oracle DOC-07 authoring vs legacy `DOC-03 DOMAIN_ORACLES` ABI 沒有 Ratification；Compiler 精確卡在 PL-003×2 + PL-004×1。**解決策略是修復元件與發行流程本身，而不是修改 Compiler 驗證器讓紅燈變綠。**

**原始聲明分開紀錄：** `READONLY_COMPILER_PASS` = 唯讀 child 可執行；`ISOLATED_16_PLUS_12_MAKER_PASS` = 候選具有局部品質證據；`B1_EFFECTFUL_COMPILER_BLOCKED` = 真正 B1 live effect 不可執行；所有 R1～R4 live/GWO/G-A/G-B native cases=NOT_RUN；這些狀態禁止跨欄位升格。

最終交付：`R4_ISSUANCE_RECOVERY_ROOTCAUSE_AND_DECISION`, `R4_NATIVE_ADMISSION_IMPLEMENTATION_CANDIDATE`, `ORACLE_VERSIONED_RATIFICATION_PROPOSAL`, `COMPILER_AND_EFFECT_BOUND_RECEIPTS`, `B1_COMPLETION_LEDGER`, `NATIVE_G_A_G_B_GWO_RECEIPTS`, `INDEPENDENT_ACCEPTANCE_VERDICT`, `R4_GITHUB_READBACK`, `NATIVE_22_NODE_HANDOFF_AND_QUEUE_ACK`, `B1_R4_CHECKPOINT`, `R4_EXECUTION_REPORT`, sanitized evidence archive。若仍有不可繞過的 Gate，清楚產出唯一 pending authorized action、其真正 Owner、具體最短辦法，而非反覆提出模糊提問。

## 2. Authority / Files-first order

依序讀取真實本地文件（所有實體 SHA、line locator、version 均須 readback）：

1. `C:\Projects\Agent_Workspace\知識庫\實作相關DOC\Fabric vNext\Semantic World OS Fabric\SBL_PIPD` 下的 `FHS-MSC_藍圖_r2`, `SBL_PIPD-LS-PKG_DOC-00..13`, `FHS_MSC_B1_PIPD_LS_PKG_00..08` **r3**；如文件搬家，以原 sha+真正路徑追查，勿以「檔名不同」宣告遺失。
2. 當前 R3 四附件：`B1_Resume_R3_Execution_Report.md`, `B1_Resume_R3_Checkpoint.json`, `B1_R3_Evidence.zip`, `MINIMAL_NATIVE_ISSUANCE_REGISTRY_REPAIR_PROPOSAL.json`，尤其 ZIP 裡 `01_routes/*`, `02_candidate/*`, `03_verify/*`, `04_handoff/*`, `COMPILER_STAGE_RECEIPTS/*`, `B1_COMPLIANCE_MATRIX.json`, `NATIVE_FULL_PRODUCT_HANDOFF/*`。使用已保存的上一輪 `B1_Resume_Evidence` 和其更前歷史，只取尚需補證的邊。ZIP 是不受信任輸入，先 zip-slip/symlink/CRC/size/file-signature 檢查，再只讀解析；不可執行 ZIP 內的腳本。
3. 前輪 `FHS_MSC_B1_Codex_Continuous_Resume_Command_2026-10-27_r3.md` 作歷史 Mission 方向，及《FHS-MSC B1 工程範圍與 Codex→HGK/Hermes 交接鑑定》。**本 r4 取代 R3 當輪續工路由；不回寫舊記錄。**
4. `sbl-commander-sp` Skill；《00_KNOW_INDEX》～《19_KP_INDEX_CROSSWALK》；正式 `construction-acceptance-prompt-compiler_SKILL.md` + 實際 `references/*`, `prompt-contract.schema.json`, `scripts/prompt_contract_compiler.py`。用 Skill 所列實際 lint/activation/acceptance/compile；沒有 render 即不跑針對 render 的 duplication。
5. `Fabric使用說明文檔`, `HG-KSEOS使用說明文檔`, `fabric-autonomous-research_使用說明手冊_v2026.08.13-r1`，真正安裝的 HGK/Fabric/PIPD registry/authority policy/schema/import map；手冊及公開 GitHub 不是 Native signature。

**權威順序：** 目前已簽 Native Policy/Owner-approved scope→已批准的原生 SourceFreeze/TaskKind/Oracle Ratification→正式 PIPD Owner source→FHS-MSC r2 + SBL DOC-00..13 + B1 r3 適用設計→現役程式/Host Readback（事實非授權）→操作指南／知識包。等級相同的衝突先隔離其相關 live effect；不能以日期或 chat 投票決定。

**具體已觀測來源 pins：** Source Manifest `e35a4b60e1644f65b3eb46e1c36891f311a0db4a1c25a5443630b3f865a88cf1`；R3 Oracle candidate `fb8cde37693ebb0462a350a68ddd7cf12a107a004bdbeaf7ccddf4aa32ce1e60`；Receiver Preflight candidate `429aafae5330a120f227dab8c2c022db10da2cf53a9f8e761130cb6d2f2e7cd3`；原 `B1_EFFECTFUL` contract `080ef6394737f1257718364e046193fe749a6b6629bca0b8f94c7da24c98f5ba`；Read-only child `832d8fc1048d53ef6b5d5d1f69f4d7b3eb042a65fa08c4d1134972e8660a23a9`。它們是舊 Subject 參照，不得覆蓋新 candidate 的 SHA。每次使用前重新確認。

## 3. Intent / Non-goals / Claim ceiling / Owner standing decisions

**OWNER-A01：** 已確定 `DOC-07` 是 Canonical Oracle／Fixture **authoring** source；現役 P4 JSON ABI `DOC-03 DOMAIN_ORACLES` 保留為 legacy *serialization symbol*，Canonical DOC-03 Environment Binding 不可混淆。**准許以此作 engineering decision 與最小相容測試候選**，但**不冒充**正式具版本、簽署與驗證者的 Oracle Ratification；批准文件與已安裝 Plugin Schema 分開。

**OWNER-A02：** 已准許「在既有 HGK 唯一控制平面，補齊最小 SourceFreeze 签發／驗證＋TaskTopology Registry 的缺口」的**設計、隔離驗證、精確有界變更提案**。不得因此建立第二 Issuer、第二 Scheduler、第二 PIPD Compiler、使用 Caller 自宣稱 `verified=true`、偽造 Owner trust-anchor 或補簽歷史 SFR。

**OWNER-A03：** 假設已批准且現役的 maintenance/recovery authorization workflow 存在時可用它啟動受限修復；必須有原生 owner reference、作用域、時限、兩人/分離權責（如規範要求）、負例、Restore/Revocation/Readback。不存在此路線就不要擅創 bypass。可另生成一個經治理供 Owner 導入的 bootstrap *proposal*，但它仍不能授予自身當前 live mutation。

**OWNER-A04：** 自行決定工程優先順序、兩輪最小修復嘗試、代碼候選、負例、密碼學 library 比較、真註冊 ABI 對齊、被授權的 repo PR 候選；不再要一次普通的聊天同意。**保留不可替代的人類/原生 Gate**：生效信任根、Key 用途、簽章簽發、Policy/TaskKind 原始批准、正式 Ratification、可識別的獨立 AO、真 UserData consent、不可逆操作及 Production/Release。這些不可因「唯一 OWNER」在 Chat 自動成為有效簽章。

**OWNER-A05：** 僅修 B1 Bootstrap，於 G-B 交回 HGK／Hermes；後續 SBL/全產品 FHS-MSC 的 22 node Candidate DAG 要做可被合法 Native Scheduler 接受的 Handoff，不讓 Codex 完整施工。

**禁止：** 修改 prompt compiler/lint 去消除 `PL-003/PL-004`；修改已安裝 P4 Plugin Cache Schema；在未授權的產品 root 自行寫入；直接修改 canonical SQL；從 GitHub credential 充當 HGK trust-anchor；讀出/打印私鑰／token；改寫 global `C:\Users\...\.codex`；無有效鏈就直接 Host activate／USER add-remove；把任何 28 個 Maker tests 或 30 個預備 Runner Route 轉成正式 Native PASS；發布未去敏 evidence；在共享 dirty worktree 執行 reset/clean/force push。

## 4. Active / Deferred / Forbidden scope — 不可縮減分母

必須讀取當前 `B1_COMPLETION_LEDGER.json` 與 B1 00～08 做機械逐ID守恆：

| 身分全集 | 基準 | 本輪已證明 | 續工要求 |
|---|---:|---|---|
| PI atoms | 27 | Native 0 PASS／27 NOT_RUN | B1 current subject→source/owner→WO→runner/oracle→Checker |
| WO/OBS | 31 | Native 0 PASS／31 NOT_RUN | 分 effect class；OBS 不造 ECP；DEV/OPS/USER 不混用 |
| Parent TQAEP | 120 | Native 0 PASS／120 NOT_RUN | POS/NEG/EDGE/SEC 每筆真 runner+raw |
| Child TQAEP | 124 | Native 0 PASS／124 NOT_RUN | 31×4；不得借 sibling/GWO receipt |
| Conformance Nodes | 38 | Native 0 PASS／38 NOT_RUN | 每節點自身 schema/owner/oracle |
| R15 identities | 949 | 66 Required／254 Conditional／629 Deferred | 18 family 全身份保留；延期不等於全部安裝 |
| Kind×Mode×Host×Provider-off | 192 | 本次 0 Native PASS | 8×3×4×2，Canonical 4 Hosts；不全量強制裝 Host |
| Named assets | 81 | 19 contract+13 CLI+25 METHOD+24 Donor Slot | Trigger/NO-FIT＋runtime method receipt，選擇性安裝 |

30 個 `OWNER_REGISTERED::*` Runner **文字 route** 已發現，但實際 signed executable/ABI/same-subject 繫結為 0。**未簽 Runner 不可 PASS**，也不可把 30 種 Runner 試圖實作成新的第二 Harness。

對 31 個 Slot 的完整表見文件末尾 **附錄 A**。本次 R0～R3 內容只處理外援修復+必要 SBL 接線和 GWO，其他 Full Product 經一個 native handoff 移交。

## 5. Baseline / Reuse / Do-not-redo

R3 ZIP 已驗證 188 members、CRC PASS、byte size 1,723,048，SHA256 `c32f5eeee30d32bc75742f6112fe373f3367dcb3798491e8461064e4b15cc79c`。R3 當輪四產品 `HEAD` 均 untouched，沒有產品寫入／真 issuer／native runner／外部背後監控。接續開始重驗本輪 currentness，**不是**把過期 HEAD 當可寫入凍結點。已完成來源數據和獨立候選可復用但不得升格。

| Root | R3 observed local HEAD | remote reference & handling |
|---|---|---|
| SBL | `10d510f7b052e6139fd4eb536f970c0245002e17` | `shw097-team/SBL`，與 `main` 不同，先辨本地分支既有 dirty/untracked |
| PIPD | `39079c02b8f2a3a3e63d3f2a2d5537805d3a3594` | `shw097-team/PIPD-LS-SP`，守住 Legacy P4 ABI |
| Fabric | `bb06b7a6c17c45c777a636e9dae3196e21eb77b9` | `shw097-team/Fabric`，Public mirror ≠ signed live policy |
| HG-KSEOS | `086a9402189a2bb0ac3b198a7a9805b3dcbe38d8` | origin absent，**不可**自動推到 Fabric 作 Canonical |

本次指揮驗證遠端 `main` 仍為 SBL `dc5428f23d15f0ec56cbc3d25b22f5381fce8771`，Fabric `bcd91043b89b69c9d2f08309e46e31898ac87d89`，PIPD `e95942abcb6aa07e69304607ab8afc22a74fc67d`；重新查 remote 才能決定當輪 branch/base。HGK 四 root 實際路徑前進須 check file-ID、Junction/Reparse、HEAD/dirty manifest、現役 Host Import 和 Loaded SHA。**勿在有數萬 untracked 的 SBL／PIPD root 清理、stage all 或 reset**。

**Reuse:** 100個原始 sources + R2/R3 各特定 source pins；Oracle 16/16 Maker offline tests；receiver preflight 12/12；R3 README/CI root cause、TaskTopology bounded absence、6份上游SHA、materializer scope、no native route conclusion、22-node handoff DAG。只有條件變動再重開相應 Test。修復的關鍵是獲得新權威能力而非重新跑無效的 `lane_assignment_resync.py` 0-change。

## 6. Implementation and qualification gates — 任務 DAG 與精確出口

### R4-0 — 有界 resume／證據 readback（現在即可執行）

- [ ] 讀取上輪 checkpoint、ZIP hash/manifest/CRC/unsafe members、安全地解析 JSON。確認原 31 Slots、120/124/38、949/192/81 身分與上一輪 `NOT_RUN` 不漂移；檢驗 16＋12 tests 原始收據但不充作 native。
- [ ] 重驗四 Root 的 `git rev-parse`、NUL-safe `git status`、跟蹤文件、reparse/file-ID/ACL、現役 PID/loaded/import/epoch、真 GitHub 3 remote。保留舊 dirty。確定 evidence run 根、private ACL 和完整 SHA。
- [ ] 遵守 R3 `RECOVERY_READONLY` compilation 已成立，但產生新 per-run `C0..C9` 的 READONLY/ISOLATED child；真的 lint/activation/acceptance/compile PASS 才依產物執行。若其自己的 Compiler BLOCKED，只能準備來源候選，不得 render 被擋子指令。
- [ ] 不再次廣搜不存在的 endpoint；已有 `NATIVE_ISSUANCE_ROUTE_NOT_IMPLEMENTED_OR_NOT_DISCOVERABLE`，僅在來源/remote/head 變更或有新路線時限定增量查證。

### R4-1 — SourceFreeze／TaskTopology／Issuer 的「最小原生修復」候選（目前真正的首要工作）

**輸入：** `01_routes/TASK_KIND_PROVENANCE_GRID.json`, `MATERIALIZER_SCOPE_READBACK`, `NATIVE_ISSUANCE_SOURCE_AUDIT`, `ISSUER_VERIFIER_ROUTE_FINDINGS`, `MINIMAL_NATIVE_ISSUANCE_REGISTRY_REPAIR_PROPOSAL`, `ONE_TIME_OWNER_ISSUANCE_PACKET`, 與真實 HGK `src/hg_kseos/spine.py` 和 TaskTopology manifest。Source manifest `e35a4b...` 只可綁相同主體。

- [ ] **根因確認：** `HGK/HGK_STACK_MANIFEST.yaml` 的 manifest 版本既有引用 `HGK/HGK_TASK_TOPOLOGY_POLICY.yaml`，但 local refs/tags/五個投影/420-entry release manifest、六個歷史 A4 上游均無可恢復授權版。視為真缺口，不要再以「Owner 提供原路徑」兜圈。先確認現役來源是否可改以有正式 Schema/Owner 的其他**既有** topology；若真的無替代，從已驗證相關 HGK 契約**產生新受控 TaskTopology Source proposal**，留原 namespace/unknown TaskKind 為 `UNREGISTERED`，版本號及疑點具名列出。這是新候選，不是已批准 registry，不得自稱已恢復。
- [ ] **Bounded native issuance implementation proposal：** 不另建 DB/second issuer/scheduler。以真正存在的 SharedSpine `create_taskspec`/`create_workorder` 之*前*插 typed reference verification seam。保留既有 API/ABI、正反例、canonical transaction shape 與 rollback。以 `receiver_preflight_candidate.py` 作有界 unit test seed，但補齊其沒有實作的**Owner-bound signer/verifier trust anchor、TaskKind resolver、issued SourceFreeze subject binding、issuer revocation/epoch/TTL/nonce、policy snapshot**；只能透過 Owner-approved protected native registry/credential mechanism 插入，不得依 Caller 自帶 `verified`、fake key 或 unsigned JSON。
- [ ] **分層發行契約：** (a) PIPD deterministic `freeze_authority` / source digest，不自帶批准；(b) Owner-approved SourceFreeze signed mission/source subject/epoch/TTL/scope；(c) approved TaskKind Registry 原始來源與 resolver，同 epoch；(d) HGK 唯一 Issuer 的 ECP/Permit/WO；(e) Hermes real queue/lease/effect journal；(f) distinct checker。若已存在受保護發行 backend，復用它；若確無 backend，產生最小 versioned issuer/verifier **設計與候選實作**，不可冒充已獲 root 信任。批准簽署後在現有維修路由整合；若無該路由，將受影程式補丁保持 isolated + 最小 diff/PR 候選，進入 R4-1.HITL 區而非 live self-authorization。
- [ ] **精確負例：** missing SourceFreeze、foreign mission/source SHA、unknown/unregistered Kind、wrong epoch/scope/subject、expired/revoked nonce、caller-asserted verifier、replayed lease、symlink WriteSet escape、invalid authority signature 全部 **zero canonical mutation / zero Spawn**。形狀正確但缺 Issuer → `SHAPE_VALID_ONLY`／HOLD；Maker 不能產 Native Positive。
- [ ] **出口：** 受控 Candidate Diff＋source/ABI/Owner／Trust anchors＋10組以上具身份的拒收測試＋rollback＋legal approval route 或唯一 Owner-on-Host action packet。若尚無真 signer/registry，**僅** `R4_ISSUANCE_REPAIR_CANDIDATE_READY`，不可填 `PL003_RESOLVED`。

### R4-1.HITL — 只有真正簽發入口不存在時的唯一外部動作

不再次請 Owner「說同意」，不要求提供不存在的 endpoint。產生**一份** `NATIVE_OWNER_ACTION_PACKET`，以實際可執行的 Host 主控管理程序（若存在）及具名 Owner/Policy 說明：候選 Source SHA、Issuer/Verifier/TaskKind 授權範圍、信任根來源、Issuer 主體、需要哪些本機 UI 或 CLI 人類操作、最小 Repo/Effect WriteSet、expiry/revoke、post-issuance `verify`、RAW readback、分離 Checker、失敗安全處置。**若連簽章信任根/正式批准程序都不存在，這是 `NATIVE_TRUST_BOOTSTRAP_REQUIRED` 的阻斷工件，不能以自製腳本在同一 Maker 帳號自行採納或產生真密鑰來取代**。其他合法獨立工作繼續。

### R4-2 — Oracle CR_ORACLE_001_OPEN 的最小相容裁決

- [ ] 讀取 DOC-02、DOC-07、Canonical DOC-03 與實際 `P4 0.1.1` schema。保留 `DOC-07` 為 authoring authority、`DOC-03 DOMAIN_ORACLES` 為 legacy serialized ABI，`DOC-03 Environment Binding` 嚴格不同 namespace；絕不「全文 search/replace DOC-03」。
- [ ] 重用 **新** SHA `fb8cde...` 的 `oracle_namespace_candidate.py`；16個 Maker tests 已涵蓋 duplicate keys/schema substitution/source digest invalid + legacy 正負例。對當輪 Subject 重新檢查 duplicate JSON、schema canonical byte/semantic pin、TraceLink atom hash/cardinality、foreign source/subject/owner、舊 Consumer roundtrip、失敗 rollback。必要時補最小可逆 diff。**同一 Maker 的16 PASS≠ Ratification/Independent AO。**
- [ ] 生成 versioned `ORACLE_NAMESPACE_COMPATIBILITY_RATIFICATION_REQUEST`，用真 PIPD Owner Signer+現役驗證/獨立 Checker 取得 same-subject ratification／raw；Ratification signer route 不存在就保持 `PL-004`，不得透過修改 P4 const 或規避 `/authority/conflicts/0` 使 compiler 假 PASS。
- [ ] **出口：** `CR_ORACLE_001_RESOLVED` 僅在 Ratification＋Current Subject Checker 皆證實，否則 `CANDIDATE_READY/HOLD`；不要求另一個普通聊天同意。

### R4-3 — Compiler source/admission 才能轉入效果階段

- [ ] 新的 Owner SourceFreeze、registered TaskKind source/resolver、Oracle Ratification 分別先由原生 issuer/verifier 驗證 **subject SHA、Owner、epoch、TTL、scope、revocation、policy/load**。請真受控 `SourceFreezeApproval`／`TaskKindBinding` 作為 C0/Authority reviewed sources；兩個 `PL-003` 不能靠刪 `missing_sources`、改 `required_sources`、補 dummy path 過關。
- [ ] 保留原 103 required/101 reviewed + two external dynamic bindings，並將本 r4 續工新的來源增量登記而非少算。對真正的 B1_EFFECTFUL JSON Contract 重新執行 `lint`, `activation`, `acceptance`, `compile`。完整 PASS 且產生 executable effectful child prompt 才放行下個階段，讀取 contract/render hash。Blocked 時只隔離該 effects；不只因 compile 失敗就把 READONLY 也停掉。
- [ ] 對 each effect 重驗 Root/HEAD/Dirty、ECP 一卡一 EffectClass、Token/Issuer Scope、live signed epoch、required/served、Tool/METHOD applicability、original 31 slots/runner 同主體。禁止 Root 及 policy 漂移；具名重新 prepare。

### R4-4 — R1/R2/R3/R4 最小現役修補與自排錯（只有 R4-3 真 PASS 後）

**四個 Cone 都必須是已綁原生合法 WO；每一次 patch 採 Red → minimal diff → Green → Negative/Edge/Security → independent readback → exact rollback proof。**

| Cone | 必做 | 禁止 proxy PASS |
|---|---|---|
| R1 HGK Issuer/Receiver | Permit 身份、nonce、TTL、scope、epoch、live receiver、unknown effect 拒絕，零非法 Spawn | shape test／舊 HGK receipt |
| R2 Hermes Fair Durable Queue | A Blocked/Parked 時 B/C forward progress、lease CAS generation、crash/restart/reconcile `UNKNOWN_EFFECT`、at-most-once | SQLite schema 存在／schedule Ready |
| R3 Fabric Stage→Active→Loaded | verified approved SHA＝Active SHA＝Loaded SHA、genuine policy consumer ACK、rollback同 generation | file digest/active pointer 等同載入 |
| R4 PLAN/EXECUTE/VERIFY_SECURITY | 三車道 required/served live、transport/credential principal 同 epoch、wrong lane fail-closed、外援 revocation 試驗 | 只有 registry YAML/assignment 格式變更 |

R2 不憑猜測修 `mission_runner.py`，先測現役 Import Path（歷史證據候選 `runner.py → advance.py`）。R4 的 `lane_assignment_resync.py` 既已三次零改動，不再當修復途徑；找真正 signed registry/launcher/config source revision mismatch 再產最小 patch。若 repair red 缺明確同範圍 fixture，Maker 先加可靠 regression，不直接改有風險 Hotpath。FAR 可做附屬 RCA，不成第二 issuer 或 scheduler。

### R4-5 — G-A → 三域 GWO → G-B 真原生交接

- [ ] G-A 僅當 native Issuer live+authorized、Hermes fair durable queue+effect journal、Fabric stage/active/loaded一致、三 lanes required=served、每個 required METHOD 真 invoke、distinct Checker 同 Subject RAW **全部合取**才 PASS。
- [ ] **GWO-FABRIC**：原有 `plan.propose`→分開 DEV/OPS→真 Approved Stage、`OP-FAB-ACTIVATE`、Active Loaded Consumer 同 epoch ACK；RAW-STAGE/LOADED/CONSUMER 分離，錯 epoch/reverse projection 全 NACK。
- [ ] **GWO-HGK**：SBL Proposal→HGK唯一Issuer→Hermes CAS/durable A/B/C→小型可逆 Native Effect→RAW-ISSUER/QUEUE/EFFECT + Checker，舊nonce/ghost/duplicate拒收。
- [ ] **GWO-SBL**：只有合法分離的 OPS install 授權 + 使用者實際 consent/USER issuer 才執行隔離 TODO `--data-dir` 前置命令 `init`, `add --title`, 跨進程 `list --json`, 依實得ID `remove --id`, `list --json`, `uninstall --yes`。6份 RAW distinct；`delete` 未知、空標題、重複、foreign file 拒收；無 consent/issuer 即 NOFIT/HOLD，不拿 OPS token 假替。
- [ ] G-B：驗證 temporary Codex grant 是否**確實存在**並由合法 issuer撤銷；若不存在需真全域受限 scope readback 而非虛構 REVOKE event。新 Process/Session 的 HGK/Hermes Durable Queue 自身發 `WO-B1-C8`，真 Issuer/Lease/Effect/Checker，外部舊憑證 0 Spawn。`B1_Resume_R3_Checkpoint` 或 Cron 存在 ≠ native successor。
- [ ] 由有獨立 Principal、只讀Frozen Candidate的 Checker 重算120 Parent＋124 Child＋38 Node、必要192 cell/81資產與949 source dispositions（適用性參照B1 05/06/07）。Reader須備 Owner-signed executable/ABI/policy/same subject；目前30 logical route但0 registered signed runner，必逐條照需求現役註冊，不能拿 runner 名稱代理結果。
- [ ] Native 22-node full-product DAG 僅在合法 HGK Kind/Admission/Queue ACK 後變成正式 WorkOrders；發交接前只保持 `planning_only=true`。SWOF僅 `PREW3_SHADOW` / W2 readset、不准 W3 mutation。由HGK/Hermes主控後續完整 SBL/FHS-MSC，Codex 外援權限結束，Codex 只可被日後受治理地當 Worker 調用。

### R4-6 — GitHub 候選發佈與遠端讀回（每一步須由獨立 publisher/有效 repo 權限准許）

- [ ] 查 real root+origin+branch+HEAD+dirty，分 SBL、Fabric、PIPD-LS-SP 原有 owner，HGK 無 remote 不臆造 mirror/projection 路由。零產品變更就 `NO_CHANGE_WITH_EVIDENCE`；真改才用受限 branch、精確 file staging、PR、CI、SHA readback，不自動 merge `main`。
- [ ] Owner GitHub Token 本地位置 `C:\Projects\Agent_Workspace\API KEY\GITHUB-REPO_SHW097-4.txt`：僅真 publisher credential broker 安全取用，**絕不可回顯內容**到 stdout、chat、Git URL、diff、文件、PR 或 evidence；repo owner/scope 先驗，清除暫時受限憑證痕跡；Token **不能**為 Native HGK Issuer 签章。
- [ ] PIPD PR #19 verify 先前在 stage-c guard 拒絕兩個 ADR 文件，**僅**本輪現役發佈鏈依賴該 PR 時以正當 scope 受影修復，同 head 重測；不得改 guard/scope 來硬闖，不因另一 CI 綠燈 waiver。
- [ ] sanitized PR 可依 repo writer 有效 owner scope提交，但它仍是候選且不構成 live SourceFreeze/Loaded/Native PASS。遠端 head/blob/tree readback 以 real GitHub 得到的 URL 顯示。

## 7. Failure / HITL / Repair / Resume — 切斷重複停工

**真 FirstFail 次序：** `Source/Authority → Root/HEAD/TaskKind → Signed Issuer/Revocation/Policy → EffectClass/ECP → Selected Methods → Actual Execute/Unknown Effect → Loaded Reader → Independent Checker → G-A/G-B`；最新目前 `PL-003`（two dynamic source families）+ `PL-004/CR_ORACLE_001_OPEN`，其它全未運行。只要適用就保留 B1 00 canonical FirstFail，不產生替代名字冒稱不同 PASS。

- [ ] **一次可重入 Resume：** 同一 Mission ID、新 run_id，保存 immutable checkpoint，檢查 source/HEAD/dirty/epoch/loaded/previous WO effect journal；不重用 token/nonce/lease/candidate-same-subject acceptance。
- [ ] **每塊可自行迭代：** 凍結最小 diff；負例先證明當前缺陷；最多兩次同根因修補；失敗先縮小 fixture/ABI，再 FAR source-bound RCA；修補不碰其他工作樹；對非受影分支繼續。
- [ ] **不得要求額外口頭授權：** 清楚記錄 `ordinary_engineering_reapproval_needed=false`。若真唯一缺口是信任根／原生 signer／受治理來源批准，輸出一份 precise `NATIVE_OWNER_ACTION_PACKET` 與可選的 Owner on-host UI 指令/變更 PR，**只要求能實際完成的控制行為**，不要再詢問不存在的端點。
- [ ] **合法的外部效果停損：** 既有 Owner approval workflow 不存在時，候選可以完成/測試，但不得擅自整合/激活讓失效的程序替自己簽 Permit。做完候選和其餘獨立任務後記 `BLOCKED_BY_REQUIRED_NATIVE_OWNER_ACTION`，留下下一次可自動 Resume 的受影 Restart Hook；不承諾無排程仍在背景運行。
- [ ] Canonical `UNKNOWN_EFFECT` 一律 read-world-state/reconcile，不能因兩次 repair budget 還有一次而 blind replay；任何不可回復副作用/密鑰/資料超出已核准範圍 → park 該 lane。按 file owner 路徑排除 symlink/junction escape。

## 8. Evidence / Independent acceptance / Candidate binding

**本輪私有 evidence run**（從實際受控工作目錄產生新目錄，不覆蓋舊 ZIP／前輪）至少保留：

```text
00_previous/{ZIP_MANIFEST,PRIOR_SHA_READBACK,UNTOUCHED_PREIMAGE}
01_source/{R4_SOURCE_CROSSWALK,TASKKIND_ROOTCAUSE,ISSUER_VERIFIER_CURRENTNESS}
02_contract/{C0_C9_READONLY,COMPILER_READONLY_RECEIPTS,B1_EFFECTFUL_RECHECK}
03_native_recovery_candidate/{TOPOLOGY_CANDIDATE,SOURCEFREEZE_ISSUER_VERIFIER_CANDIDATE,ORACLE_CANDIDATE,NEGATIVE_TESTS,ROLLBACK}
04_effect/{BOUNDED_BUILD_ORDER,RAW_POS_NEG_EDGE_SEC,R1_R4,G_A,THREE_GWO,G_B}
05_check/{INDEPENDENT_PRINCIPAL,FROZEN_SHA,TQ_120_124_38,R15_949,MATRIX_192,METHOD_RECEIPTS}
06_publish/{SECRET_SCAN,REPO_BRANCH_PR,REMOTE_HEAD_BLOB_READBACK}
07_handoff/{NATIVE_OWNER_ACTION_PACKET,NEXT_NATIVE_22_NODE_DAG,QUEUE_ACK,REVOKE,NATIVE_SUCCESSOR}
08_final/{B1_LEDGER,OPEN_TT,ROLLBACK,RESUME_CHECKPOINT,EXECUTION_REPORT}
```

對每項 Commander-SP 使用 `build_order{root,head,writeset}`, `steps[]{command,exit,stdout_sha256,stderr_sha256,denominator}`, `candidate_sha`, `raw_receipt`, `policy_epoch`, `oracle_binding`, `checker_principal`（真有才填）、`rollback`, `open_items`。`R4_...` 候選可追本輪 SHA；不跨 sibling WO/EffectClass/epoch 借 RAW。Maker 16/12 local tests不作 AO；Checker 必另一個真的權限隔離 principal，讀真 frozen subject 重跑負例＋loaded readback。

**安全證據約束：** ZIP raw 內可能含本機私人路徑／狀態資料；Public GH 只送 sanitized hashes/IDs、必要受影代碼與去敏報告。不要公開原始 ZIP、checkpoint 中的 user path、GitHub Token、runtime DB、完整 private inventory。

## 9. Termination / Final output / Native handoff

### 可以宣稱 B1 真正完成的合取出口

1. 真 versioned Signed SourceFreeze/Native Admission/registered TaskKind/Oracle Ratification 綁**當前** subject/Owner/epoch/TTL，原 Contract C0～C9 真的 `PROMPT_COMPILE_PASS`，適用 per-effect ECP/Permit 由真正 Issuer 發行；
2. 27/31/120/124/38 完整 Case Identity 和有真 Raw Oracle/Runner/Independent Checker的適用欄位，949 的 66/254/629 disposition、192/81 團隊範圍無 shrink、必要 method 真 invocation；
3. 四個 RepairCone 和 live Stage/Loaded/Native worker 真的修復，G-A 全部合取、GWO-FABRIC/HGK/SBL 各 domain真效果與三種 distinct RAW、G-B 撤銷外援並在新 Process 真 Native successor；
4. 完成受控 GitHub remote readback（對當輪有變更的合法來源）、Rollback/readback、不留 UnknownEffect、不自簽 Checker；
5. 22-node 後續 Native Mission DAG 經真 TaskKind/Issuer/Queue ACK 接手，Codex 停止 bootstrap 代理，HGK/Hermes 接下完整 SBL/FHS-MSC，SWOF 只做 PRE-W3 Shadow；
6. **由非 Maker 的合法 AO 實際出具同 Subject 獨立 PASS**，本輪不自稱 Signed Release/Production。

### 如果真正 Native Gate 仍不可合法通過

輸出 `PARTIAL_WITH_EXPLICIT_HOLDS`，附**唯一最小被阻斷 Owner 行動**、改動候選 SHA、真 FirstFail、舊觀測/reentry、安全確認與後續非受影完成工件。**不可**把 session 結束等同 B1 完成；**亦不可**重複同一不存在端點查找，把 `PROMPT_COMPILE_BLOCKED` 靜默更改為 PASS 或強制清空 `missing_sources`。

### 回報格式

在每個 Gate checkpoint 與最終報告以繁體中文輸出：已實際完成、Maker候選、未執行、真 signed receipt/Checker、case計數、真 HEAD/dirty/policy/loaded、GitHub candidate PR、剩餘 TT、Owner action packet（如有）、下一個被允許的修復／正式 Native WorkOrder。每個數字以真收據為準，不填估算百分比。

**立刻開始 R4-0，完成 C0–C9 有界 child、R4-1 Native Issuance/Registry 候選與 R4-2 Oracle 相容候選。只要原生 gate 真正解除，立刻順 DAG 連續向 R4-3..R4-6 前進；遇到不可替代的 trust-root/authorization 只停受影 live effects，其他工作不中止。**


## 附錄 A｜31 張原始 B1 WO/OBS 逐張路由檢查表（來源 B1 DOC-02／R3 Ledger）

本表只保留 ID 與 EffectClass，不重寫原始 PD 的參數／正負例。每張卡必回讀精確 Source Locator／EffectKey／ECP／Runner／Policy／Oracle；所有列都要出現在機器 Completion Ledger，且不得自選 new kind。

| # | 原始 WO/OBS ID | EffectClass | ECP 條件 |
|---:|---|---|---|
| 1 | `OBS-B1-A1` | `READ_ONLY_PROBE` | `NO_EFFECT`；只讀 |
| 2 | `WO-B1-A2` | `HOST_OPERATIONS` | OPS/Native typed ECP + signed Permit |
| 3 | `WO-B1-A3` | `HOST_OPERATIONS` | OPS/Native typed ECP + signed Permit |
| 4 | `WO-B1-A4` | `HOST_OPERATIONS` | OPS/Native typed ECP + signed Permit |
| 5 | `OBS-B1-A5` | `READ_ONLY_PROBE` | `NO_EFFECT`；只讀 |
| 6 | `WO-B1-A6` | `HOST_OPERATIONS` | OPS/Native typed ECP + signed Permit |
| 7 | `OBS-B1-A7` | `READ_ONLY_PROBE` | `NO_EFFECT`；只讀 |
| 8 | `WO-B1-A8` | `REPOSITORY_WRITE` | DEV typed ECP only after admission |
| 9 | `WO-B1-A9` | `HOST_OPERATIONS` | OPS/Native typed ECP + signed Permit |
| 10 | `OBS-B1-B1` | `READ_ONLY_PROBE` | `NO_EFFECT`；只讀 |
| 11 | `OBS-B1-B2` | `READ_ONLY_PROBE` | `NO_EFFECT`；只讀 |
| 12 | `WO-B1-B3-DEV` | `REPOSITORY_WRITE` | DEV typed ECP only after admission |
| 13 | `WO-B1-B3-OPS` | `HOST_OPERATIONS` | OPS/Native typed ECP + signed Permit |
| 14 | `WO-B1-B4-DEV` | `REPOSITORY_WRITE` | DEV typed ECP only after admission |
| 15 | `WO-B1-B4-OPS` | `HOST_OPERATIONS` | OPS/Native typed ECP + signed Permit |
| 16 | `WO-B1-B5-DEV` | `REPOSITORY_WRITE` | DEV typed ECP only after admission |
| 17 | `WO-B1-B5-OPS` | `HOST_OPERATIONS` | OPS/Native typed ECP + signed Permit |
| 18 | `WO-B1-B6-USER` | `USER_DATA_EFFECT` | USER consent + UserData issuer |
| 19 | `OBS-B1-B7` | `READ_ONLY_PROBE` | `NO_EFFECT`；只讀 |
| 20 | `OBS-B1-B8` | `READ_ONLY_PROBE` | `NO_EFFECT`；只讀 |
| 21 | `OBS-B1-B9` | `READ_ONLY_PROBE` | `NO_EFFECT`；只讀 |
| 22 | `WO-B1-C1` | `HOST_OPERATIONS` | OPS/Native typed ECP + signed Permit |
| 23 | `WO-B1-C2` | `HOST_OPERATIONS` | OPS/Native typed ECP + signed Permit |
| 24 | `WO-B1-C3-OPS` | `HOST_OPERATIONS` | OPS/Native typed ECP + signed Permit |
| 25 | `WO-B1-C3-USER` | `USER_DATA_EFFECT` | USER consent + UserData issuer |
| 26 | `WO-B1-C4` | `HOST_OPERATIONS` | OPS/Native typed ECP + signed Permit |
| 27 | `WO-B1-C5` | `REPOSITORY_WRITE` | DEV typed ECP only after admission |
| 28 | `WO-B1-C6` | `HOST_OPERATIONS` | OPS/Native typed ECP + signed Permit |
| 29 | `OBS-B1-C7` | `READ_ONLY_PROBE` | `NO_EFFECT`；只讀 |
| 30 | `WO-B1-C8` | `HOST_OPERATIONS` | OPS/Native typed ECP + signed Permit |
| 31 | `OBS-B1-C9` | `READ_ONLY_PROBE` | `NO_EFFECT`；只讀 |

**31/31 機械關聯：** 逐 Atom 以原 Ledger 對應 Slot/Parent，Parent 覆蓋每 Atom × POS/NEG/EDGE/SEC + 每個 GWO ×4，Child 為 31 ×4。未具 Owner-registered Runner／same-subject RAW 僅能 `NOT_RUN`/合法 HOLD，禁止複製另一卡的成功輸出。

### 附錄 B｜此次修復問題的正式決策對照

| 問題／證據 | 本輪最短解法 | 目前 Claim Ceiling |
|---|---|---|
| `PL-003` SourceFreeze | 以既有簽發／維修治理修復 current mission bound approver+signature verifier；歷史 SFR 不替代 | `HOLD` |
| `PL-003` TaskKind | 修復 missing TaskTopology source/projection 或由原 owner批准新合法 Source；Resolver 不收自造 kind | `HOLD` |
| `PL-004` Oracle | DOC-07 authoring + legacy DOC-03 ABI versioned compatibility + independent ratification | `QUARANTINE` |
| `RECEIVER PREFLIGHT` | 保留 12/12 maker tests、補真 signer/verifier/registry 後才測 positive native | `MAKER_CANDIDATE` |
| `R4 Model Lanes` | 查 registry root version33/34、真正 launcher served、繫結 signed policy epoch，不再零差異 resync | `OBSERVED_DRIFT` |
| `G-A/G-B` | 合法 Native live repair+three GWOs+separate checker+new-session successor | `NOT_RUN` |
| `PIPD PR #19` | 只有本輪發佈依賴才處理 stage-c two ADR write-set guard，必真重跑 required CI | `OPEN_OBSERVATION` |
| `Checker/Runner/USER` | Owner-signed current runner ABI、獨立 principal 與 USER issuer/consent，不用 maker 自簽 | `UNBOUND` |
| `HGK Git Remote` | 沒有驗證 source projection owner 就保持本地，不任意指向 Fabric | `NO_VERIFIED_REMOTE` |
| `Full SBL/FHS` | 22-node planning-only DAG 待 Native queue ACK 後移交，不由 Codex 全產品施工 | `CANDIDATE_ONLY` |

**本文件僅有工程指揮效力，不是 Native Owner 的已發行信任工件。**
