# FHS-MSC B1｜Codex 新 Session 原生正式驗收薄指揮令 r6

> **給本地 GPT Desktop Codex（執行模型：OpenCode Go / DeepSeek V4.1 Flash）直接執行。** 本文件取代 r1～r5 的「執行命令」；舊報告／Checkpoint／修補 PR 只作已完成證據和來源參照，勿重新按舊 Prompt 逐輪執行。**嚴禁載入、安裝、引用為執行代理或調用 SBL Commander-SP**；它目前是待修／待驗收的產品部件，不能自己當施工／驗收前置。可直接使用 Codex 本身的程式編輯／Shell／Git、現存 HGK／Hermes／Fabric/PIPD 原生介面，以及實際獲授權的獨立 Checker。Commander-SP 對應的待驗收產品義務仍保留，但不能靠調用它自證 PASS。

## 0｜任務與自主權（一次授權）

你現在是 **B1 正式驗收推進的 Maker／施工執行者，不是 Native Issuer、獨立 Acceptance Officer 或簽章 Root**。OWNER 對本輪授權：直接做讀取／調查、隔離測試、最小必要補丁、修復 PR、合法分支發布、正式驗收準備、追查並修復真阻斷；不必為這些常規工程步驟反覆詢問。若本機已有有效、可驗證且範圍吻合的 Native Maintenance/Permit，可直接按其條款執行；**不能把聊天授權、候選 YAML、離線測試、臨時模型回覆變成正式簽章／UserData issuer／AO verdict**。

**真正目標：** 連續把現有 B1 r5 候選推進到正式 Native Admission→現役受控整合／Loaded→R1–R4→G-A→GWO-FABRIC/GWO-HGK/GWO-SBL→G-B→原生 HGK/Hermes 續行交接，完成全部 B1 適用性裁決與獨立驗收，提交完整報告。不是完成整套 SBL/FHS-MSC 下游產品；該工程在 B1 後移交 HGK/Hermes 執行。SWOF 限 PRE-W3 read-only shadow。

**降治理規則：** 不重建制度、不創第二 Issuer／Scheduler／PIPD Compiler；不全量重讀既有檔案或重跑已證實仍有效的測試；每個實際效果只需「準確 Source／Root/HEAD/WriteSet／Permit → 受影操作 → Raw Readback／回復 → 不同主體的 Checker」。借用原生已註冊工作流，不產製與原生工件平行的巨大治理文件。單項阻斷只停受影 DAG 節點，其他合法節點立即續作。任何 Session／Context 中斷均先 checkpoint，恢復後依實際狀態續行，**不宣告已在背景運作，除非 Hermes 真的註冊 Durable Job 並有 Queue ACK**。

## 1｜權威來源與現有進度（只做增量 currentness）

- 上位藍圖：本機 `FHS-MSC_藍圖_r2*`、`SBL_PIPD-LS-PKG_DOC-00*`…`DOC-13*`；**本輪 Native 驗收的直接判準是 `FHS_MSC_B1_PIPD_LS_PKG_00*`…`_08*` r3 九檔**。所有文件先到 `C:\Projects\Agent_Workspace\知識庫\實作相關DOC\Fabric vNext\Semantic World OS Fabric\SBL_PIPD` 定位，引用現存的 SHA／行錨，必要時才展開相關段落。`Fabric使用說明文檔`／`HG-KSEOS使用說明文檔`／FAR 使用手冊為運作說明，不取代現役 Native Policy。
- R5 起點（2026-10-27，**全部重新確認實際 HEAD/PR/dirty/Host 有效身分後才用**）：

  | 候選 | GitHub PR | R5 candidate HEAD | R5 已知測試／狀態 |
  |---|---|---|---|
  | HG-KSEOS（PRIVATE） | https://github.com/shw097-team/HG-KSEOS/pull/1 | `33b5b9fac5ea418b42f467b457393a5b9402d45a` | 58 Maker 基準＋3 受影；Trust 沒有 Enable/Sign/驗收 |
  | Fabric | https://github.com/shw097-team/Fabric/pull/18 | `142add13784c6d5f9b9cdbfb2c9b24216c5c9ce0` | 5 Maker；`INSPECTED_NOT_APPLIED` |
  | SBL | https://github.com/shw097-team/SBL/pull/13 | `a97b1bf886b4668588980682d36016781ee9a6a9` | 14 Maker；CI success；USER effect 未做 |
  | PIPD-LS-SP | https://github.com/shw097-team/PIPD-LS-SP/pull/20 | `cddd68228cad4d1ebe08119428dfe7026399338b` | 23 Maker；一般 CI PASS、`public-plugin-verify` FAIL；Oracle 未 Ratified |

- 先讀 `B1_R5_CHECKPOINT.json`、`R5_EXECUTION_REPORT.md`、上輪 `NATIVE_OWNER_ACTION_PACKET.json`、四個 PR Diff／Checks、R5 精確補丁／Rollback Manifest；就地找最近的真 Evidence Root。老的 Source pin／54 等測試結果若候選與環境未變可**證據繼承**，不可升格成 Native PASS。私有 HGK 遠端是經篩選的獨立 export，**不能**把它與舊本機 HGK 歷史 `git merge --allow-unrelated-histories`；以 preimage+精確 diff 受控移植。不得改原本 dirty/untracked、洩漏 Key／Raw Evidence，也不做 force push。
- 首輪僅刷新四 Repo exact PR head/base、查各 PR Review/Actions、現役 HGK/Hermes Loaded Import、Active policy、signed epoch、PIPD installed P4 schema、Checker principal、Trust registry。看不到的寫 `UNKNOWN/NOT_RUN`，不可把 GitHub commit 說成 Loaded。

## 2｜五步連續正式驗收（不先空轉）

**A. 四庫獨立候選審查，立即開始。** 對 PR #1/#18/#13/#20 的確切 diff 執行必要的靜態／依賴／Secret／負向／受影迴歸及 Rollback 檢查。召用**確實不同的授權獨立 Checker**、唯讀候選及可追溯的檢查器／來源版本；DeepSeek 這個 Maker 自查、相同 Principal 的新對話或模型名稱變更均非正式 AO。先取得「Candidate Code Review Verdict」，不能直接稱 Native Acceptance。Checker 尚不存在時，立即準備完整唯讀檢查包並只發出**一次**具名 AO 身分／可讀證據存取請求，不無限重做 Maker 測試。缺 PR CI 的 HGK/Fabric 執行可重現本機受影測試；PIPD `public-plugin-verify` 的 ADR-0008/0009 Stage-C 歷史 WriteSet 差異，按受影層級修正真錯誤或明示独立 Gate HOLD，禁止弱化檢查器以求綠燈。將獨立核可的變更依真 Source／Owner 的發布政策受控合併／套用與必要部署；**單純合併 PR 不算正式啟用**。

**B. 一次性 HGK Native Trust/TaskKind/Oracle 解鎖。** 第一個真阻斷仍為 `NATIVE_TRUST_BOOTSTRAP_REQUIRED`，另有 `PL-003 ×2`、`PL-004/CR_ORACLE_001_OPEN`。先用 R5 已交付的 `scripts/native-trust-maintenance.ps1` **Inspect/SelfTest**、現役 HGK Owner／OS Principal、真受保護 Registry／Schema／信任根與 Source Manifest 審視；該工具來自 PR #1 的**未啟用候選**，不得假設它已裝入 Host 或被授權。確認批准後且由真正有權的 OS/Authority Owner 執行一次性的 **Trust Enable、TaskTopology 正式定版與註冊、Oracle DOC-07 正式 Ratification**：綁定真 Principal、信任公鑰／鍵用途、簽章 canonical profile、Root/HEAD/WriteSet、policy epoch、TTL、revocation、kind resolver、獨立 Checker。`HGK_TASK_TOPOLOGY_POLICY.proposed.yaml` 是 `UNREGISTERED`，不能改檔名偽作批准；PIPD  `native_use_allowed=false` 的兼容候選要保留原 P4 ABI，須由真 Owner ratify。**若需要高權限管理員、私鑰／OS protected trust 或獨立 AO 而 Session 無該實際權限，不要自行提權／產生信任根／改 compiler 規則**：交付唯一可操作請求（被核准工件、精確 CLI 参数／環境、作用 SHA、需誰執行、Readback、撤銷）並繼續 A、D 的不受影工作，後續有真收據立即銜接，勿再要求普通口頭授權。

**C. 同主體正式准入和生效。** 驗證真簽章 SourceFreeze/Owner Registry、registered TaskKind、Oracle Ratification＋獨立 same-subject regression。只在這些實際依賴改變時，對**更新的** B1_EFFECTFUL contract 跑原生四階段 Compiler；`PROMPT_COMPILE_BLOCKED` 時不 render／執行效果 prompt，保留第一失敗與可重入點。真 `PROMPT_COMPILE_PASS` 後，按 WorkOrder 一種 EffectClass 一個對應 ECP/Permit；REPOSITORY_WRITE 用真 root/head/dirty/writeset 的 PD，HOST_OPERATIONS 與 USER_DATA_EFFECT 使用原有合法 Host/User issuer，不跨借；READ_ONLY 不偽造 PD/Permit。逐作用元件讀回 `Approved SHA = Active SHA = Loaded SHA`、Hermes 真工作進程／import、Fabric consumer ACK、真正 required=served 和 policy method applicability。正式 Host 啟用只走現有授權 promotion／maintenance 路由，按確切 preimage 做可逆切換，不能直接執行隔離測試版 DB 遷移。

**D. 完成全部 B1 現役案例，修一次驗一次，持續續工。**

- **R1**：HGK Issuer/Permit/Effect —— 有效同主體正例、無權／錯 Subject／Epoch／TTL／Nonce／Unknown Effect 負例皆於 Spawn 前拒收，零非法效果。
- **R2**：Hermes Queue／Lease／Journal —— 阻斷 A 不妨礙無衝突 B/C、CAS lease generation、process restart/durable cursor、at-most-once；UNKNOWN_EFFECT 先 observe/reconcile，不盲重播。只修實際載入的 runner/advance 熱路徑。
- **R3**：Fabric Stage→Active→Loaded→Consumer ACK 同 SHA/Epoch；Stage-only、假 applied、舊 Loaded、倒寫投影皆拒收；受影 rollback 與 readback 必須真實。
- **R4**：PLAN/EXECUTE/VERIFY_SECURITY 各自 required=served 的真模型、Principal、Provider/Host、resume；禁止無證據備援、同一 Maker 自驗。DeepSeek V4.1 Flash 是**本 Codex 的執行模型**，不是其他三條 Native 模型車道已生效的證據。
- **G-A**：六項合取：Native issuer；公平持久 Queue；Fabric Active/Loaded；三路模型 required=served；同 Epoch 的每卡 mandatory method **真正調用**；獨立 Checker same-subject Raw。缺一 HOLD，測試摘要不能補。
- **GWO-FABRIC**：`RAW-FAB-STAGE / RAW-FAB-LOADED / RAW-FAB-CONSUMER` 三種不同 Event，真 Activator／Reader ACK、錯 SHA/Epoch NEG。
- **GWO-HGK**：SBL 有效非 Commander-SP 的現存合法 proposal entry → HGK 唯一 Issuer → Hermes Queue/CAS Lease → 可逆原生效果，Issuer/Queue/Effect 三種 Raw＋ghost/replay NEG。**若正式驗收契約某一項硬性依賴 Commander-SP，維持該項具名 HOLD，先用原生合法 bridge 驗證其餘能力，不以替代入口冒充 Commander-SP 合格。**
- **GWO-SBL**：合法 OPS Host install/doctor/load 與另行合法 USER consent/issuer；隔離專用 DataDir 執行跨進程 `init → add → list --json → remove --id <實際ID> → list → uninstall`，保留 INSTALL/ADD/LIST1/REMOVE/LIST2/UNINSTALL 六收據及 duplicate-title/empty-title/unsupported-delete/foreign-files NEG。`--data-dir` 在子命令前；沒有 User issuer 不做真 USER 效果。
- **G-B**：三個 GWO 同源對齊但不同 `operation_id/resource/raw`；撤銷外援臨時 grant 後，再由**另一個進程／Session** 的 HGK/Hermes 原生 Durable Journal 自己派合法 `WO-B1-C8`，檢查舊 token 重播拒收／無非法 Spawn、真正 native successor、零非預期殘留；有效 Durable Queue ACK 才可聲稱有背景續行。

若有缺陷：定位唯一 `first_fail`，在授權的最小影響 cone 執行 RED→最小 patch→POS/NEG/EDGE/SEC→Rollback→重新獨立驗收；同根因兩輪未修復時只暫停該節點，交付精確依賴/行動，其他合法節點續行。禁止循環重讀指揮稿、重編未變且已知必然 BLOCKED 的同一 contract，或無限重跑相同測試。

**E. B1 全量項目驗收／移交。** 從原 DOC-01/02/05/06/07 直接機械載入穩定 ID，而不是重寫千行 Prompt：**27 Atoms、31 WO/OBS、120 Parent、124 Child、38 Nodes、949 原始 R15 身份（66 Required／254 Conditional／629 Deferred）、192 Kind×Mode×Host×provider-off Cells、81 Assets（19 Contracts＋13 CLI＋25 Methods＋24 Donors），以及 3 GWO**。每個具適用性的原生測試都要有實際註冊 Runner／ABI/Owner Signature、Subject/operation/candidate/epoch 真 Raw、領域特定 POS/NEG/EDGE/SEC 與不同 Checker；沒有真正 Runner 就 `BLOCKED_MISSING_RUNNER`，不得假 PASS。949/192/81 為完整追溯與 disposition 分母，**不是要求一次安裝所有技術或部署所有 Host**；Conditionals/Deferred 逐 ID 保留原始理由、Owner、reentry，不能縮分母。最後把未完成的完整 SBL/FHS-MSC 產品 WorkOrders 及原 22-node planning DAG 交給已恢復的 HGK/Hermes **合法**排程、實際 Queue ACK，Codex 外援退場。SWOF 僅 PRE-W3 唯讀相容，不執行 W3。

## 3｜證據、連續續行與唯一必要的人工作業

每次實際變更只保存最低可重現證據：`Source/Root/HEAD/Dirty/WriteSet + candidate SHA + policy epoch + Permit/ECP + command/exit/raw log hash + domain readback + negative + rollback + independent checker verdict + updated Gate`。證據存本機 Owner 指定**私有**目錄；公開 Repo 只能放去敏工件與精確 PR/commit，絕不讀取／輸出 Token 或 private keys。PR 從 draft 改為 ready／merge 要符合當前 Repo Owner 與 Native admission 實際規則，不因聊天指令強制越權合併。所有檢測需比對真正生效 Host 路徑，不用 PR 頭部或離線 fixture 代替。

每輪可短報 `DONE／NEXT／FIRST_FAIL／GATE／EVIDENCE／CHECKPOINT`。執行到完成，或遇到**唯一不能由 Codex 合法執行**的 Owner-OS 信任啟用、簽章、真正獨立 Checker 身分、UserData consent 時，僅列出一個合併後的 **HITL_ACTION_PACKET**（誰、在哪個 Host、使用哪個現存真 CLI、需批准什麼確切 SHA/Policy/Scope、如何驗證成功／回復），把其他可做事項做到止，然後停受影節點等待真工件；**不要停下來要求一般工程口頭同意，也不要聲稱能跨 Session 自己在背景等待執行**。若原生 Scheduler 已可用，受有效 Permit 才能註冊後續 Durable WorkOrder/ACK。

## 4｜驗收出口與完整報告（必交）

在當前可用 Host 完成每一項後，生成 `B1_NATIVE_FINAL_ACCEPTANCE_REPORT.md`、`B1_NATIVE_COMPLETION_LEDGER.json`、`B1_NATIVE_RAW_EVIDENCE_MANIFEST.json`、`B1_NATIVE_HANDOFF_RECEIPT.json`、`B1_NATIVE_RESUME_CHECKPOINT.json`；對四個 Repo 提供 **實際** PR/Commit URL、Source-Export／正式現役 SHA 對照、CI＋獨立審查、Native Installed/Loaded 狀態、Rollback 和所有第一失敗。報告必須呈現以下逐項狀態與數量：

1. `Trust/TaskKind/Oracle/Compiler/SourceFreeze`：真 Native 票據或具名 HOLD。
2. `R1,R2,R3,R4,G-A,GWO-FABRIC,GWO-HGK,GWO-SBL,G-B`：各自 `PASS/FAIL/BLOCKED/NOT_RUN` 及 raw/獨立 verdict。
3. `27/31/120/124/38/949/192/81`：每個原 ID 的 PASS/FAIL/HOLD/NOT_RUN/N_A＋理由、版本、證據，沒有數量縮減。
4. `External revoke → new-session native successor → 22-node handoff`：真 Queue ACK／重啟驗證。
5. R5 既有 PR #1/#18/#13/#20 和所有新實際修補對應的驗證、Current HEAD、條件、阻斷及永久殘留。

只有在有權的獨立 Acceptance Officer **真實簽發**同一凍結候選的驗收票據，且上述 B1 每個 Required Gate/Case 依原生狀態合法結案後，才標記 `FHS_MSC_B1_NATIVE_ACCEPTED`。否則輸出 `PARTIAL_WITH_EXPLICIT_HOLDS`，詳細說明剩下精確的原因和一次性需要的真實行動，**絕對不要用 Maker 自測、模型切換、CI 綠燈或 OWNER 聊天授權偽造正式 PASS**。B1 可通過但不等於完整產品 Release／Production。

**立即開始：讀 R5 Checkpoint 和四個 Draft PR 最新狀態，執行候選獨立審查／Native Trust 一次性啟用準備；一路推進當前合法且可實測的工作，確實跨 Gate 後自動銜接，不要改寫本 Prompt 或返回只含規劃的報告。**
