# FHS-MSC B1｜Hermes 單一 OWNER 常設授權、原生自動施工與驗收「薄指揮令」r8

> **交給當前／新開的本機 Hermes Session 直接執行。** 本指揮令**取代先前 r1～r7 的執行程序與反覆 HITL 等待慣例**；歷史證據、實際合約及驗收要求不被取代。唯一人類 OWNER 已就**本輪明確 B1 範圍**授予持續工程裁決與受限自動化委派。**禁止安裝、載入、掛載、調用 `sbl-commander-sp`／Commander-SP，包括子代理間接調用**；可修補其原始碼，但本輪不把該 Plugin 當成執行工具。Hermes 已更新且基本正常，**快速讀回即可，勿重裝**。

## 0｜唯一 OWNER 決議：停止「等第二個人類」的死循環

- **只有一個人類 OWNER／Administrator：本次下令的使用者。** 不要求第二位人類 Issuer、Oracle Owner 或 Acceptance Officer。將原 `TB-1／AO-1／CR-1` 改為**受託機器職責配置與驗證工作**，不是新的人工審批票。OWNER 已核准本輪**一般工程修改、隔離測試、受控 Git 寫入／Commit／去敏 PR、在既有合法 Host 權限下部署、受限簽發及適用性技術裁決**；無須每卡再問使用者。
- **單一權威、分離機器身分**：HG-KSEOS 是唯一 Native Issuer；Hermes 是 Scheduler／Executor 協調；PIPD 是 deterministic Compiler／Oracle 契約；Fabric 是 Policy Activator／Reader；SBL 是產品／USER 效果入口；Checker 必須是與 Maker **不同的實際 OS／服務 Principal**，可由相同人類 OWNER 管理，不需另一個人類。保留真密鑰隔離、nonce／lease／scope、Readback；不接受 Maker 自評充作 AO。
- **此輪 OWNER 工程裁決直接生效**：Oracle 採 `PIPD DOC-07` Canonical Authoring，**保留已裝 P4 `DOC-03 DOMAIN_ORACLES` Legacy Serialized ABI**，用最小 Adapter；批准修復 `ROUTE_SOURCE_PIN_STALE`；批准受控整合 HGK PR1+PR2、Fabric PR18、SBL PR13、PIPD PR20；批准隔離合成 DataDir 的 SBL add/remove 測試；批准在合法機器授權內自動執行 B1 Gate。把上述決議版本化為 **OWNER Standing Delegation Policy**，令 HGK 真實受保護 Verifier 能消費，而非反覆索取文字批准。
- **權限界線只有三條**：① 不可用對話文字冒充 OS 提權／真私鑰簽章；② 不可用同 Maker／無效 Principal 偽造 AO／USER 世界效果；③ 不得擅自擴大到 B1 以外、既有私人資料、未核准敏感發布或不可逆破壞。**不是要求再有人類簽字**。有效 Policy 條件滿足時，自動 Issue → Verify → Execute → Check → Next；條件不滿足時修實作或環境，而非要求重複口頭 HITL。

## 1｜立即起跑，不重建計畫

**先執行 T1**：對已安裝 Hermes 做 1 次版本／Process／state DB／實際模型路由讀回，**立即在隔離 Durable Queue** 跑 enqueue → lease/CAS → A blocked 時 B/C 公平前進 → restart／cursor → nonce/replay/ghost NEG → 可重算 ACK；**T1 不等待 HGK Trust**。若實際 Hermes Queue API 無法提供此操作，定點修接線並重驗；不得因沒有 ACK 就僅讀 DB 後停止，亦不得虛報背景自主續行。

真實本地 Roots（操作前 `git rev-parse --show-toplevel`，不以舊 HEAD 冒充現在）：
`C:\Projects\Agent_Workspace\HG-KSEOS`、`C:\Projects\Agent_Workspace\Fabric`、`C:\Projects\Agent_Workspace\SBL`、`C:\Projects\Agent_Workspace\PIPD`。復用 `C:\Projects\Agent_Workspace\HG-KSEOS\var\B1-HERMES-R7-20261027\` 的四份 r7 MD、`B1_HERMES_*` JSON、`HITL_ACTION_PACKET.json`、`candidate/`、`b1_check_route_pin.py`、78 筆 Evidence Manifest；上位九份 `FHS_MSC_B1_PIPD_LS_PKG_00～08` 與 `FHS-MSC_藍圖_r2`。僅校驗必要來源 SHA／Root／HEAD／Dirty／真 Live Import／Host／PR HEAD；不全量重新盤點、不重跑位元相同的成功測試。嚴禁 reset、stash、clean、`git add -A`、force push、私有資料進公開 Repo。SBL 既有大量 untracked 是歷史 Workspace 噪音，不作新的本輪 diff。

**目前可直接接手的證據**：r7 `HERMES_SMOKE_OK`、T1=`NOT_RUN`、HGK PR1＋PR2 隔離 63/63（另有 thread/Unicode warning 待定位）、Route Pin 三項 RED／修補候選 GREEN、Fabric/SBL 原 preimage 未變、Native PASS 0；以現況變動更新，不把歷史值定死。遠端：HGK 私有 [#1](https://github.com/shw097-team/HG-KSEOS/pull/1) + 疊加 [#2](https://github.com/shw097-team/HG-KSEOS/pull/2)、Fabric [#18](https://github.com/shw097-team/Fabric/pull/18)、SBL [#13](https://github.com/shw097-team/SBL/pull/13)、PIPD [#20](https://github.com/shw097-team/PIPD-LS-SP/pull/20)。**PR2 base 是 PR1 分支，必須一併整合**。所有遠端 SHA／CI 現場重驗。

## 2｜第一波：能合法寫程式碼的工作直接施工，不等待 Native Trust

並行、按受影 WriteSet 完成真實可測的 **受控來源整合**（不把 Repo 修改等同 Host 啟用）：

1. **HGK**：從 PR1＋PR2 最終位元對本地原始 Root 做精確移植；完成 `native_admission.py`／SharedSpine／Schema／測試／`native-canonical.js`／Maintenance，補正 `cryptography` 正式依賴；修復隔離 63/63 的 background-thread `UnicodeDecodeError` warning，執行完整受影 POS／NEG／EDGE／SEC、DB migration 升降級與 rollback；保存 preimage、提交受控分支／PR，不合併無關 Git 歷史、不覆蓋現有 Dirty。
2. **Route pin**：用 r7 `b1_check_route_pin.py` 在新 Preimage 上驗證；只修改 `assignment.registry_epoch`、必要 revision、對應 `source_of_routes.sha256`，從**新的 Assignment bytes** 重算 digest；保留真 OWNER 指定三條 lane 與歷史來源，不借修 pin 暗改 provider；正向、壞 SHA、壞 Epoch、rollback 都過再套用受控 config，另取得實際 `required=served`（純 config 一致不算 R4 PASS）。
3. **Fabric**：按當前 SHA／本地 REC07 locator 等價移植 PR18，留下 `INSPECTED_NOT_APPLIED` 的真實界線；修既有 Activator/Reader 必要接線，在正式受權後才啟用 Stage→Active→Loaded；不新建第二 Policy Plane。
4. **SBL**：精確移植 PR13 atomic-save，保留本地 CRLF 與產品入口；修既有非 Commander-SP 的 `plan.propose`／CLI／Host Adapter，整合並測試最小 TODO 生命週期。合成 DataDir 可立即實驗；既有 USER 資料不在此輪委派範圍。
5. **PIPD**：受控整合 PR20 Canonical DOC-07＋Legacy P4 ABI Adapter，不改動已裝 Legacy Schema 以求過關；以唯一 OWNER 本輪裁決建立可機讀 Ratification Decision、同 Subject 回歸；Stage-C ADR-0008／0009 `public-plugin-verify` 的實際 WriteSet 故障受影修復；不放寬 Checker／Compiler。

每張工作卡使用 **Probe → FirstFail → smallest patch → unit/NEG/security → real readback → rollback check → next**；失敗只重跑受影依賴。工程狀態另記 `TESTED/INTEGRATED/LOADED`，獨立於 `native_acceptance_status`，避免全台帳一律 HOLD 掩蓋進度。普通程式碼審查、Commit、去敏 PR 更新**已取得本輪 OWNER 常設許可**，不再寫一張新的 HITL。

## 3｜第二波：補齊一次性 Machine Authority，讓後續簽章不再找人

**不要找三個人。要落地三個機器職責：** 已授權 Owner Host/Signer Broker、非管理員 Hermes Maker Worker、另一個受限唯讀 Checker Service Principal。先讀現役**正確**信任路徑 `%ProgramData%\HG-KSEOS\native-admission\registry.json`（非只查 `HKLM\SOFTWARE\...`），及當前 ProgramData ACL、Machine Cert Store、受保護不可匯出 CNG key、現有具管理權的 Service／Task／維護接口。**不要假定有，也不要假定沒有**。

**最短自動啟用路由（順序）**：

A. 若已有經核准、實際有權的 Host Broker／註冊排程任務／維護服務，Hermes 提交**精確、校驗位元的 B1 Enable Plan**，由既有有權執行端自動 `Inspect/SelfTest → Enable → Verifier Readback`，不需要再問人。禁止任意命令轉送／通用管理員 Shell。

B. 若只有候選 `scripts/native-trust-maintenance.ps1`，先按 PR1+PR2 修成可驗證正式工具；它原來 `Enable/Sign` 要求 Elevated OS SID、Existing Nonexportable Machine Certificate。做**最小相容施工**：把 `human_owner_sid`（唯一決策者）與 `delegated_issuer_service_sid`（真正簽發程序）分開綁定；註冊 Maker/Checker 不同 OS SID；有憑證就使用合法既有憑證，沒有就於有權的受保護 Host 執行端依 Windows CNG／Cert Store 正式建立不可匯出 Machine Key／憑證；秘密永不落 Prompt、JSON、Repo、一般 Worker 日誌。保留現有 SharedSpine／Verifier，**不建第二 Issuer／DB／Scheduler**。如現有 schema 要求 `owner_os_sid == executing_sid`，只能以受控、版本化、經 NEG 測試的委派相容修補實現，**不能把 SID 全改一樣／刪除 PRINCIPAL_SEPARATION**。

C. 若本機**沒有**任何具備所需 Windows 權限的有權程序，Hermes 應**自動準備校驗 SHA、列明固定參數的狹義 Host Bootstrap**，並透過 Windows **正常**提升權限流程啟動一次（例如標準 UAC 的有權執行途徑）。如 OS 要求本機使用者確認，該**一次性 OS 驗證無法由文字授權代替**；不可繞過 UAC、偷取 Token、永久開放 Administrator、停用 ACL／簽章檢查。若系統未能取得真 OS 授權，僅受影 `HOST_BOOTSTRAP_PENDING_OS_AUTH`，其他修補、T1、隔離 Checker 實驗及證據交付**繼續**，不反覆要求聊天口頭批准。

**Broker 的最小固定 API（需實作／驗證，非假稱既有）**：`inspect`、`enroll`、`issue`、`verify`、`revoke`。Broker 以受保護 IPC／ACL 接收 typed request，使用 OWNER 有版本的 **Standing B1 Policy** 評估 `mission/subject_sha/root_identity/HEAD/write_set/effect_class/policy_epoch/nonce/TTL/rollback`；符合即自動用其 Machine Key `Sign`，交由 HGK Receiver 再 `Verify`；拒收即回 `typed FirstFail`。Machine Key 不可交予 Hermes 模型、外掛或 Maker，亦不准 Broker 作任意命令執行端。每次 Issuance 自帶 Scope、短 TTL、可撤銷與真 Raw；OWNER Policy 的**作用域擴大**不允許 Worker 自行修改。

**自動化 Ratification/Acceptance**：將本次已採納的 Oracle 語義轉成真正的版本化 Owner Decision／Source Manifest，由 PIPD 執行合法 Compiler、Same-Subject 回歸後走 HGK Broker 簽發 `source_freeze`／`task_kind`／`oracle_ratification`；須證明真 Verifier 驗簽、Registry `REGISTERED` 與有效 Subject／Epoch。獨立 Checker 使用**不同實際 Service SID**、不同驗收憑證／權限、唯讀原始證據重新跑驗證；同一人類可以管理兩個服務，但**同一 Maker 自評或改名副程序不能充當獨立 AO**。正確配置服務身分，而非刪掉這個拒收。

**CR-1 裁決**：唯一 OWNER 已核准本輪新的、明確綁定的**隔離合成 DataDir** 的 SBL `init/add/list/remove/uninstall` 測試，Broker 可在此 scope 依 Policy 自動簽 USER 效果；此授權不涵蓋既有私人資料或他人資料。無須第二位人類 User-Issuer。

## 4｜正式 Native 驗收：第一張真工作卡後自動連跑

A. **T1** 必須先取得真 Hermes Durable Queue/Lease/Restart/Replay 的隔離 ACK；這是可立即執行項，別再標 `NOT_RUN` 而不實測。

B. **T2 真 HGK→Hermes 最小 WorkOrder**：本輪 Source/Oracle/PIPD Compiler 真 `PASS` → HGK Protected Registry/Registered TaskKind/三種真簽章有效 → 真 `ADMIT`／WorkOrder → Hermes Durable Queue CAS/Lease ACK → 最小可逆實際效果 → Journal/Host Readback → 異 Principal Checker 重新驗證並出具同 `subject/operation/policy/epoch` Verdict。**T2 通過後，無須再問 OWNER，轉向下一個 Required Gate。**

C. **R1～R4 → G-A**：R1 真 Issuer／Scope／Nonce／Revoke；R2 真公平 Queue、重啟、At-most-once；R3 真 Fabric Stage→Active→Loaded、Consumer ACK 同 SHA／Epoch／Rollback；R4 `PLAN／EXECUTE／VERIFY_SECURITY required=served` 與現役 mandatory Methods 真實每卡調用收據。**G-A 六項 AND**：Issuer、Fair Durable Queue、Fabric Loaded、三路 served、同 Policy Epoch Methods、獨立 Checker。配置、模型回答、CI 綠燈或 Maker 自測不得替代。

D. **三個互不代用 GWO**：`GWO-FABRIC` 真 Stage/Loaded/Consumer；`GWO-HGK` 經合法**非 Commander-SP Plugin** Proposal 入口 → 唯一 HGK Issuer → Hermes Queue/Lease → 可逆 Effect；`GWO-SBL` 真 OPS Install/Load 與隔離 USER DataDir 的 `init → add → cross-process list --json → remove --id <實得 ID> → list → uninstall`，分別留六類效果收據及 NEG（包含不能刪 foreign files）。**非 Commander-SP 入口若功能未實作，應修其既有受治理 ABI，不刪 GWO-HGK 需求**。

E. **G-B**：三 GWO 各自獨立 PASS 後，真正 Revoke 外援臨時授權／Key/Nonce Scope；另啟**新 OS Process/Session**，由 HGK/Hermes Durable Journal **沒有外援再次觸發**地執行 `WO-B1-C8`，驗證舊 Token 重放在效果前拒收、新 Native Successor／Checker 真 ACK、零非預期殘留；再以 Native Queue Handoff 原 22-node 下游 DAG。SWOF 僅 PRE-W3 唯讀，不擴張產品施工。

**不准繞過正式 Compiler 的 `PROMPT_COMPILE_BLOCKED`**；但隔離測試、受控來源寫入及不依賴該 Effectful Subject 的工作**不受這個阻斷拖住**。對未知效果先讀真世界狀態，不盲重播。

## 5｜真正連續自治的排程規則、完成出口與交付

- **建立本輪 Durable Project／Checkpoint**：每張工作卡 `PENDING/READY/RUNNING/REPAIR/VERIFIED/BLOCKED_FIRSTFAIL`，A 卡等待授權時 B/C 已獲權的卡照跑；最多兩次等價補救後改走第一失敗根因，不作無限相同重試。**實際 Queue ACK 才宣稱自動背景續行**。只存一套真 Ledger／Raw Manifest，不每輪寫新冗長治理封包。
- **工程與正式驗收分開計量**：每 ID 保存 `engineering_execution_status` 與 `native_acceptance_status`，兼存 `subject_sha/policy_epoch/operation/effect_class/permit/issuer/worker/checker/raw_hash/rollback/first_fail`。原分母**逐一保留**：27 Atoms、31 WO/OBS、120 Parent、124 Child、38 Nodes、949 R15（66 Required＋254 Conditional＋629 Full Product Deferred）、192 Matrix、81 Assets（19 Contracts＋13 CLI＋25 Methods＋24 Donors）、3 GWO。949 的 Deferred/Conditional 是保留身份及適用性，**不虛構全都在 B1 施工**。不得把 CANDIDATE/CI 綠燈自動轉 Native PASS。
- **交付可讀回成果**：`B1_HERMES_R8_EXECUTION_AND_NATIVE_ACCEPTANCE_REPORT.md`、`B1_HERMES_R8_COMPLETION_LEDGER.json`、`B1_HERMES_R8_RAW_EVIDENCE_MANIFEST.json`、`B1_HERMES_R8_HANDOFF_RECEIPT.json`、`B1_HERMES_R8_RESUME_CHECKPOINT.json`。報告按 T1/T2、HGK/Fabric/SBL/PIPD 現役 HEAD/Loaded/CI、Trust/Signer/Checker/Oracle、R1～R4/G-A/GWO/G-B、工程對 Native 二軸、Readback/NEG/Rollback、剩餘 FirstFail 逐項作成；Private Runtime／Key/Token/USER Data 不推公開 Repo。
- **完成前不因例行 OWNER 決策停工**。真 OS 提權或不可得 Service Principal 只能阻斷其受影 effect cone；同時繼續修補其他範圍，並保留一次性 OS 權限狀態與本機標準提升程序（不再問同一口頭批准）。若實際依賴全數成功則產出 `FHS_MSC_B1_NATIVE_ACCEPTED` 及獨立機器 Checker Verdict；若缺不可替代權限／世界效果則產出 `PARTIAL_WITH_EXPLICIT_HOLDS` 與**確定的自動恢復入口**，不得偽造 PASS／假裝背景仍會繼續。

**現在立即開工，不先重擬計畫：T1 隔離佇列真測 → 四庫受控原始碼施工／Route Pin 修復 → 既有有權 Broker 探測與最小機器身分補齊／正式 Trust → 真 PIPD Ratification＋Compiler → T2 → R1～R4 → G-A → 三 GWO → G-B → 全量交付。**
