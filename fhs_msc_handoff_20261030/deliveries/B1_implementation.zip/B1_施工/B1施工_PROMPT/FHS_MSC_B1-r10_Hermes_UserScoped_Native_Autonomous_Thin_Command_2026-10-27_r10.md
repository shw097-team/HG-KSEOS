# FHS-MSC B1｜Hermes 使用者層 Native 授權鏈修正與自治完工薄指揮令 r10

> **交給新開 Hermes Session 全文執行。** 目的：直接接續 r9，在本地 HG-KSEOS／Fabric／SBL／PIPD-LS-SP 上自施工、自排錯、自測試、自修補、自迭代、自驗收、自交付，直到 `FHS_MSC_B1_PIPD_LS_PKG_00～08` 的 **B1 適用 Required／已觸發 Conditional** 義務全部真實結案、G-B 原生交接成功。此令取代 r1～r9 的**操作指揮**，但不取代 B1 Source／PI／PD／ECP／TQAEP／授權和真實驗收契約。禁止安裝、載入、呼叫、間接調度 `sbl-commander-sp`／Commander-SP；不得將該未修復部件用作執行、簽發、驗收或阻斷其他可執行工作。

## 0｜OWNER 一次性常設工程裁決（不再就普通工程逐項請示）

全系統只有**一位人類 OWNER**。OWNER 已就**本 B1 邊界內**的 Repo 檢測、最小修改、三方合併、測試、修回、Commit／PR 快進更新、正常 CI 修復、隔離合成資料、Durable Queue、模型車道探測、受限 Host 測試、適用性判定、版本化 Policy／TaskKind／Oracle 提案及合格驗收工作，授權 Hermes 連續自行完成，無需反覆詢問人類同意。Codex 僅可作可替換的受控 Worker，不作第二 Owner、第二 Issuer 或永久調度器。

**最終工程裁決：HGK 是一般 Coding Factory；Windows Administrator 不是普通 Repo WorkOrder、User-scope Issuer 或日常 `Sign` 的必要條件。** r5 的 `native-trust-maintenance.ps1` 強制 `Administrator + LocalMachine/My + RSA-CNG machine key + ProgramData ACL` 是**特定候選實作選型**，不可再視為 DOC-00～08 必然要求。授權 Hermes 實作經版本化核定的 **User-scoped Native Trust Profile（預設）**，只在實際修改 Windows 受保護 Host 資源時才使用 OS 所要求的較高權限；不得關閉 UAC、繞過 ACL 或偽造 OS Token。

**一人類 OWNER ≠ 單一機器執行身份。** HGK 仍是**唯一** Native Issuer；Hermes 是 Maker／Scheduler；Checker 必須有可證明的有效獨立執行與驗證能力。OWNER 的文字授權可以設定政策，**不能代替真實簽章、私鑰保護、USER 資料作用域或驗收結果**。不可讓 Maker 直接讀取／置換 Signer 私鑰、Trust Anchor 或 Checker 判決；同 Windows SID 的三個程序／PID 並非天然獨立。若高保證獨立性暫不可成立，先完成可行工程與隔離驗證，Native 判決保持 HOLD，留下單一精確技術缺口而非新的人類簽核問題。

通用 Fail-closed：不偽造簽章、Permit、Policy Loaded、模型 Served、Checker、OS 權限、USER 同意或 PASS；不自動擴權至未知個資、不相關目錄、公開機密、不可逆破壞、主分支強制推送或未批准的資源。所需額外 Host 權限由真正有權的現有執行端處理；不存在時只 PARK 該受影 Host 卡，**其他 READY 工作持續**。勿建立第二個 Issuer、第二個 Queue、第二個權威 DB 或通用 Administrator 命令代理。

## 1｜從 r9 真實 Checkpoint 接續，勿從頭規劃

先一次性確認本機四個 Repository 的 HEAD／Dirty／權限、現役 Import／Service／Routing、r9 Evidence Root，並讀 `B1_HERMES_R9_RESUME_CHECKPOINT.json`、Execution Report、Completion Ledger、Manifest 及外部 Seal；對照本機九份 `FHS_MSC_B1_PIPD_LS_PKG_00～08` 實際 SHA。保留原 Evidence，不就同一測試重造 PASS。Hermes 本體已重裝且正常，**只快速讀回**，不重裝、不重構。遠端 PR 在任何更新前重新讀回真實 HEAD／CI／Review，不以這裡的 SHA 假設仍是最新。

r9 已有：HGK PR #1→#2 的安全／Admission 疊加（#2 `70147a5e6452`，本地 HGK 63 PASS／0 warning）；Fabric PR #18 `a65231cd9ca7`（5 受影 PASS）；SBL PR #13 `a97b1bf886b4`（本地 3 PASS、Ubuntu／Windows CI PASS）；PIPD PR #20 `e716ed6f8994`（本地 12 受影 PASS，但**遠端完整 CI 失敗**）。SharedSpine 原語 18/18、Dispatcher 10/10、雙 PID 續跑、per-user Scheduled Task `HGK-B1-R9-Dispatch` 真 OS 觸發已證明；**非 Hermes Native Loop**。Trust `Inspect: registry_exists=false, elevated_admin=false`、隔離 `SelfTest 5/5`、正式 Native Sign/Issuer/Checker 皆未成立。r9 封存 65 entries／外部 SHA Seal、r8 勘誤已完成；只核對受影變更。四庫遠端仍是 Draft PR，不等於 `main`／Host 已啟用。

## 2｜四條可並行、先有結果再進下一卡的施工線

**A. 優先修 PIPD 最新 CI 真實回歸，不要相信局部 12 PASS。** PR #20 最新 `offline-gate` 647 tests 出 1 ERROR：`test_ce_repair_regression.CE2CompilerStdoutTests.test_sidecar_list_has_one_definition`，`pipeline.NON_RECORD_SIDECARS` 消失；r9 merge 將 `from .validate import HASH_EXCLUDED_FIELDS, NON_RECORD_SIDECARS` 移除，`_seal` 又硬編碼排除欄位。用最小補丁恢復 **validate 的單一定義與同一物件 identity**，維持 Schema 的 `trace` 拒收負例；先跑 CE-2，再跑全部 unittest 與 CI；對 `public-plugin-verify` 的 Stage-C ADR-0008／0009 WriteSet 問題，檢查正確歷史 base 和受治理 WriteSet，勿任意擴大 allowlist、改 Checker 規則或刪 ADR。使用隔離 worktree、精確最小 Commit、正常 fast-forward 推送；讀回最新 CI 全綠才准程式碼升格為可發布候選，失敗立即自修補。PIPD 的 DOC-07 Canonical Oracle、既有 P4 DOC-03 Legacy ABI 均保留。

**B. 修 HGK User-scoped Native Trust 的不合理 Administrator 綁定。** 先畫出現役 Receiver／Maintenance 的實際依賴：`IsInRole(Administrator)`、`Cert:/LocalMachine/My`、`RSACng.IsMachineKey`、`%ProgramData%/HG-KSEOS/native-admission/registry.json`、`owner_os_sid == caller SID`、`maker/checker` 與 ACL。以 DOC-00～08 的**原生效果契約**對照，而非把 r5 候選當權威 Source。採**最小版本化相容修補**：將「Owner 授權來源」與「實際 Signer 主體」分開，新增非管理員可用的 `USER_SCOPED` Trust Profile／受限簽發接口；可使用 Windows CurrentUser CNG／既有已受保護金鑰能力或原有 Receiver 已支援的 Ed25519 公鑰驗證路徑，選擇**可由測試證明私鑰及 Trust Anchor 不受 Maker 篡改**的最低成本方案。不得用普通可編輯 Repo JSON 假裝受保護 Root，不得直接把同一 OS SID 的不同 PID 當成獨立 Checker。若不同身份／Sandbox／現有受託服務可實證隔離，沿用；否則記錄保證級別及最小缺口，不偽稱正式高保證 PASS。讓 `Enable/Sign/Revoke` 的 Admin-only 前置只適用**確需受保護 OS 寫入的明示 Host Profile**；保留原 Machine Profile 相容、Canonical Signature、nonce、TTL、replay、root/write-set、Purpose、Revoke 和負例；不要刪除拒收保護。先 RED→GREEN 隔離測試，再測普通非 Elevated Process 的 `enroll → sign → verifier readback → revoke` 正反鏈。若既有 Source 硬定義所有 Native Trust 必須 OS Protected，先由唯一 OWNER 本次決議形成**極小、版本化、可驗證的適用 Profile 修訂／差異表**，由原始合法權責路由核准；不可在未生效時用較低保證替代正式 Gate。確需 Windows 管理員的單一全機效果另外處理，不得綁死全部 B1。

**C. 完成 R3／R4 現役測量，不等待 B 線才做合法準備。** Fabric #18 已三方合併，不重做；使用**實際** Fabric Activator、Policy SHA／Epoch 與 Consumer，先唯讀檢查，再對經許可的受限 Policy 做 `Stage→Active→Loaded→Consumer Readback`、失敗回滾、真相同 SHA／Epoch；`INSPECTED_NOT_APPLIED ≠ R3 PASS`。對 Routing rev35／epoch34 先讀回目前現役配置，逐一真正調用 `PLAN`、`EXECUTE`、`VERIFY_SECURITY`，取得 required/served provider／model 與運行收據；不能靠 Registry 綠燈代替 Served，也不能未經授權更改 OWNER 選用的 Model Provider。R4 適用方法依**現役 Policy Epoch**，`KANBAN/SWARM/GSTACK/OPENSPEC/CODEX` 等實際 Required 才須提供真調用收據。

**D. 讓 Hermes 真正消費合法 HGK Queue。** 保留現有 SharedSpine 唯一佇列、CAS、Lease、Fairness、Checkpoint 及 r9 受限排程觸發，**不因想要形式上「常駐」就新建 Windows Service**。將 `hgk_dispatch.py` 最小接到 Hermes 的真可調用 Worker 執行入口／生命週期（已安裝環境實際接口為準），用新 OS Process 實證 HGK 已准入卡：`Admit→Queue ACK→Claim→execute→readback→Checker→verified→restart successor`。此前 r9 直插 Fixture 僅算測試，不計 Native；沒有真 Hermes Executor 身份與負例不得 R2 PASS。現有 `HGK-B1-R9-Dispatch` 每 5 分鐘觸發器僅准使用隔離測試 Scope；核對是否仍在運作，避免持續改寫已封存證據與重複效果；合法任務完工後撤除測試觸發器或轉移至正式受控部署，保留解除記錄。

每條線完成最小修復立即測試、取 Raw、更新受控 Commit／PR、再次讀回 CI／Host 真相。碰到 local drift 採三方語義合併而非永久 HOLD；不可 force-push、不可將 HGK private／原始本地歷史和去敏 Export 強行合併或外洩。

## 3｜一次 OWNER Standing Policy → 正式 Native 准入，不反覆 HITL

按單一 OWNER 已核准的 B1 作用域形成短小且版本化的 Standing Authorization：Mission／Subject／Repo Root／Scope／EffectClass／WriteSet／TaskKind／Policy SHA+Epoch／TTL／Nonce／Revoke／回復／Checker 職責。生效前以真正的 Owner Trust Anchor 和程式驗證，不將聊天文字當數位簽章。

依現役 DOC-07 Canonical 與 Legacy ABI 相容結果，完成正式 Oracle Ratification；TaskKind 從 `UNREGISTERED` 轉真 `REGISTERED`，簽發 SourceFreeze，重新執行更新後 subject 的 PIPD effectful `lint→activation→acceptance→compile`，先修 `PL-003/PL-004` 所依賴的真 FirstFail，絕不把設計期 TQAEP 當 Runner PASS。HGK 承擔唯一 Issuer，Signer 私鑰不交給 Hermes／模型；原生 Receiver 對每張短 TTL WorkOrder 重新驗簽。Checker 以**實際隔離的驗證權限／身份**從 Raw 與現役效果獨立重算；自動 PASS/FAIL 取決於測試結果，不由 Standing Policy 直接決定。

**真正需要 OS 高權限時**：先檢查已存在、合法、有界的 Host 執行路由並自動使用；若完全沒有且操作本身是全機 OS 保護資源，僅將該效果卡標 `HOST_OS_PRIVILEGE_REQUIRED`，提供可一次完成的最小 OS 提權程序；不要新增第二人類 Owner、不反覆索取聊天同意、不把該卡的前置傳染給其他一般 Coding 卡。禁止繞過 UAC／伺服器 ACL、放寬 Issuer Signature Gate、偽造不同 Principal。

## 4｜正式 Native Gate，自動修受影失敗直至結案

完成非管理員可信 Signer／Verifier（或合法例外 Host Profile）、Oracle、TaskKind、SourceFreeze、真 Checker 後，**先 T2 正向最小可逆 Native WorkOrder**：PIPD 真 Contract／編譯 → HGK 唯一 Sign／Admit → Hermes 真 Queue／Lease → 可逆 Effect → 現役 Readback → Checker 獨立 PASS。錯簽、錯 Epoch／Subject、過期 TTL、重播 Nonce、拒絕的 Root／WriteSet、stale Lease 須於第一效果前拒收且無殘留。

接續 **R1～R4 → G-A → 三 GWO → G-B**。R1 Issuer／Permit；R2 Hermes 真 Fair Durable Loop／跨程序續行；R3 Fabric 真 Stage→Active→Loaded 與 Consumer；R4 三 Lane required=served 及現役強制 Methods。**G-A 必須六項同主體合取**：Issuer、Queue、Fabric、Lanes、Methods、獨立 Checker。**GWO-FABRIC** 真 Policy Activate／Loaded Readback；**GWO-HGK** 使用已存在合法 SBL `plan.propose` 入口（不使用 Commander-SP），HGK 簽發→Hermes 可逆 Effect；如果只有未修復 Plugin 能提供此 ABI，就對合法 Proposal 入口做最小修復或正式版本化規格差異裁決，**不得憑空宣稱已完成原規格**。**GWO-SBL** 在唯一本次 OWNER 明示核准的全新隔離合成 DataDir，真 Host install/load，使用 `python -m sbl_cli.sbl_todo --data-dir <APPROVED_DIR> <subcommand>`（`--data-dir` 在 subcommand 前），再 `init→add→另一程序 list --json→remove --id <實際 ID>→list→uninstall`，真實既有私人資料不在作用域；Install 不代替 UserData Consent。每張 GWO 不同 operation、Raw、Checker，不能共享偽收據。

**G-B**：三 GWO 均真 PASS 後，先撤銷外援臨時權限，從**另一個真正 OS Process／Session**由持久原生 Scheduler **自主觸發** Native Successor（不是同一 Hermes Chat／外援手動代跑）；舊 Token 再入必拒收、無多餘 Effect、Rollback/readback 無殘留，再交接 22-node 後續 DAG 與可讀回 ACK。

## 5｜持續執行規則及唯一有效停止條件

Hermes 建立／沿用同一已驗證的持久工作路徑，不把對話當 Queue。每卡至少留 `id,scope,dependencies,subject_sha,source_head,policy_epoch,status,first_fail,raw,checker_verdict,restart_condition`；`READY→CLAIM→EXECUTE→READBACK→CHECK→VERIFIED`；失敗 `REPAIR→受影重測`。單卡待權限或外部依賴只 `PARK` 受影卡，其他 READY 卡繼續；避免無效輪詢，同樣 FirstFail 兩次等價重試後換根因處置，保留可重入觸發。每次新程序自動恢復，不能用「Session 還開著」冒充離線持續運作。已經完成的測試以同 HEAD／同 Source SHA 的有效 Raw 繼承；依賴改變只重驗受影卡。

逐 ID 保留 DOC-00～08 的 **27 Atoms／31 WO-OBS／120 Parent／124 Child／38 Nodes／949 R15／192 Cells／81 Assets／3 GWO**，R15 **66 Required＋254 Conditional＋629 Deferred**；Assets **24 Required＋31 Conditional＋26 Deferred**；Conditional 必須記觸發條件及未觸發理由、Deferred 記後續里程碑，**不把 949／1,565 身份錯當全部必做的 B1 效果工作卡**。分開記 `engineering_status` 與 `native_acceptance_status`，不縮分母、不用 Maker Unit／CI／Repo Commit／Task Scheduler 單項成果冒充 Native PASS。

**唯一正式成功停止條件**：適用 Required 及已觸發 Conditional 的正式證據與現役效果均 CLOSED，R1～R4、G-A、GWO×3、G-B 全部真 PASS，真正 Native successor 接管，四庫合格來源與真 Host Loaded／CI／Repo currentness 對齊、Verifier／Checker 簽章及可重算封存均成立，才輸出 `FHS_MSC_B1_NATIVE_ACCEPTED`。不得以阻斷改寫成 PASS 或刪除驗收項。若所有合法可行工作已耗盡、且尚缺**真實外部 OS 權限、受保護隔離／Issuer 或合法 USER 作用域**，不可無限執行；先將能交付的完整修補、獨立證據與待權限卡固化到可自動恢復的 Queue，誠實輸出 `PARTIAL_WITH_EXPLICIT_HOLDS` 及唯一可執行解阻動作，**不要再要另一位人類簽核，也不要在每張卡回頭問 OWNER**。

## 6｜固定最終交付（先凍結，再 Seal）

在新的 `B1-HERMES-R10` Evidence Root（真實路徑自行發現）交付：
- `B1_HERMES_R10_EXECUTION_AND_NATIVE_ACCEPTANCE_REPORT.md`：四庫各 HEAD/PR/CI/Host Imported、User-scope Trust 的 RED/GREEN 與私鑰隔離結果、PIPD 647-test/Stage-C 受影結果、T1/T2/R1～R4/G-A/GWO/G-B、真 FirstFail、自動續行證據、已完成／未完成、回復與後續路由。
- `B1_HERMES_R10_COMPLETION_LEDGER.json`：全部原始身份、適用性、工程／Native 雙軸、Raw／Checker／原因。
- `B1_HERMES_R10_HANDOFF_RECEIPT.json` 與 `B1_HERMES_R10_RESUME_CHECKPOINT.json`：真控制權／未完成 Ready/Parked 工作及下一次喚醒；若未過 G-B 不得聲稱已交接。
- `B1_HERMES_R10_RAW_EVIDENCE_MANIFEST.json` ＋ `B1_HERMES_R10_MANIFEST_SHA256.txt`：先封存靜態工件，Manifest 排除自身、外部 Seal 不列入自身 Entries，不收錄仍在寫的活躍 stdout/WAL；另一個驗證程序重算同一版本，標出真正測量時間（不可用固定 emit 時間冒充）。

**現在就開工**：核對 r9 checkpoint/current PR → PIPD CE-2 CI 回歸修復、HGK User-scoped Trust Profile 與隔離負例、Fabric R3／模型 R4 真實測量、Hermes 真 Executor 接線四線並行；完成合法 Native Issuer 正向鏈後即不停頓推進 T2、R1～R4、G-A、三 GWO、G-B。禁止 Commander-SP，禁止以缺 Windows Administrator 作為普通 HGK Coding WorkOrder 的停止理由。
