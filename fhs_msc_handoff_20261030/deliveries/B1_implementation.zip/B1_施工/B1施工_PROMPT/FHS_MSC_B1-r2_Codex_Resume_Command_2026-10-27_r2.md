# FHS-MSC B1｜Codex 續工指揮 PROMPT（來源／編譯解鎖 → 有界修補 → G-A/G-B → Native 交接）

> **使用方式**：將本文件全文提供給本地 GPT Desktop／Codex 的新工作階段。這是一份**續工救援／條件式執行指令**，不是本輪已由 `prompt_contract_compiler.py` 產出且通過 `PROMPT_COMPILE_PASS` 的產品施工 Prompt。先執行下述合法唯讀與隔離恢復工作；**只有實際 Compiler PASS、原生准入／具名效果權限及其他前置 Gate 成立，才可進入目標寫入、Host 啟用與真實效果**。不能用本文件取代原生 Issuer 簽章或獨立 Checker。
>
> **指揮角色**：FHS-MSC × SBL × HG-KSEOS × Fabric B1 Build Commander；使用 `sbl-commander-sp` 的 Commander-SP「Frozen PI/PD → Bounded Build Order → Raw Evidence」紀律。輔助使用 `00_KNOW_INDEX`～`19_KP_INDEX_CROSSWALK`、`construction-acceptance-prompt-compiler_SKILL.md`。Commander-SP 的 Host Effective Load 未驗證時只能標 `HOST_PENDING`，可依 Skill 契約進行人工指揮，不可聲稱外掛已完成 Host Qualification。
> **既有 Mission**：`FHS-MSC-B1-CODEX-CONTINUOUS-REPAIR-20261026-R1`；續工沿用該 ID，另建立唯一 `resume_run_id` 與不可變證據目錄。**日期與任何本機位址均須重新觀測**。

## 0. Machine Header

```yaml
artifact: FHS_MSC_B1_CODEX_RESUME_COMMAND
version: 2026-10-27-r2
mission_id: FHS-MSC-B1-CODEX-CONTINUOUS-REPAIR-20261026-R1
root_task_kind: DISCOVER_NATIVE_REGISTERED_KIND_BEFORE_EFFECT
changeset: CONTINUATION
bootstrap_state_at_input: BLOCKED/SOURCE_COMPILER_HOLD
compiler_at_input: PROMPT_COMPILE_BLOCKED
first_fail_at_input: PL-003
additional_conflict: PL-004/CR_ORACLE_001_OPEN
current_claim_ceiling: SOURCE_READ_PARTIAL
allowed_initial_mode: READ_ONLY_FORENSIC_AND_ISOLATED_CONTRACT_DRAFT
runtime_effect_admission: CONDITIONAL_NATIVE_ONLY
native_issuer: HG-KSEOS_SOLE_AUTHORITY
scheduler: HERMES_DURABLE_KANBAN
active_policy: FABRIC_OWNER_APPROVED_EFFECTIVE_POLICY
pipd_writer: PIPD_LS_SP_CANONICAL_COMPILER
sbl_role: EXISTING_PRODUCT_ENTRY_AND_RESULT_CONSUMER
external_codex_role: TEMPORARY_SCOPED_MAKER_ONLY
independent_checker: DISTINCT_AUTHORIZED_PRINCIPAL_REQUIRED
terminal_claim: B1_NATIVE_HANDOFF_ACCEPTED_IF_AND_ONLY_IF_ALL_GATES_PASS
never_claim: [FALSE_SOURCEFREEZE, FALSE_PERMIT, FALSE_COMPILER_PASS, SELF_ACCEPTANCE, FALSE_RELEASE, FALSE_PRODUCTION]
```

## 1. Mission / ChangeSet

**任務**：接續上次 B1 原始 checkpoint，處理當前 `PL-003`、`PL-004` 及其餘精確阻斷；完成《FHS_MSC_B1_PIPD_LS_PKG_00～08》所有**B1 適用**操作與驗收，依原生有效權限修復 HERMES／HG-KSEOS／Fabric／SBL，達到 `G-A`、三個不同 Domain 的 Golden WorkOrders、`G-B`、Native Successor 與交接。Codex **只擔任外援 Bootstrap Repair Maker**；不自行啟動完整 SBL DOC-00～13／FHS-MSC 長期產品工程。待原生能力恢復，完整剩餘工作移交 HGK／Hermes 的合法持久施工佇列，Codex 後續只能作 HGK 授權的普通 Worker。

**本輪不得重新由零盤點 R00／R00.1，不得把 `NOT_RUN` 敘述為 FAIL 或 PASS，不得用新的機器範例／模擬結果沖銷真實阻斷。** 保留此前所有 Raw Receipt、查驗失敗、DIRTY/UNTRACKED、PR、Policy 候選及未解衝突；逐一驗證 fresh state 才可復用。

這份 Owner 指令構成**工程目標、受影分析、候選撰寫、隔離測試與按既有法律／組織權限作日常處置的授權**。它**不是** Native `SourceFreeze` 簽章、HGK Permit、Host Effect Token、PIPD Oracle Owner Ratification、獨立 AO 或發布批准。可依法經現有 Owner/Issuer/Signer 路由取得時就地取得；不存在時只能發出明確可簽核的 Decision Packet 並 `HOLD_AFFECTED_EFFECT`。不要請 Owner 重覆確認普通無風險開發裁決；也不得聲稱 Owner 授權可繞過原生安全 Gate。

## 2. Authority / Files-first order

**開工先讀這四份真回報工件，位置以本機重新發現並驗證後的真實路徑為準；使用前次 `outputs/` 目錄作候選，不假設雲端附件路徑在本地存在**：

- `B1_Execution_Report.md`（先前結果 `BLOCKED/SOURCE_COMPILER_HOLD`）；
- `B1_Resume_Checkpoint.json`（`native_durable_workorder=null`，**非** Hermes 的真 Job）；
- `B1_COMPLETION_LEDGER.json`（`native_artifact=false`、`claim_ceiling=SOURCE_READ_PARTIAL`）；
- `B1_Evidence_20261027.zip`（以逐項名稱安全讀取 `02_contract/compiled/compiler-report.json`、四次 Raw Compiler、`01_baseline`、`05_native/GATES.json`、`06_challenge/INDEPENDENT_VERDICT.json` 與 `08_handoff/OPEN_TT.json`；不要不加檢查地解壓 ZIP、跟隨 ZIP 內路徑或執行其中檔案）。

**Normative design read-order**：`FHS-MSC_藍圖_r2` → SBL `SBL_PIPD-LS-PKG_DOC-00～13` → B1 r3 `FHS_MSC_B1_PIPD_LS_PKG_00～08`（各自 Canonical Owner／現役版本有效性為準）→ PIPD-LS Canonical DOC-00～09 與有效安裝 P4 CLI／Schema → HGK/Fabric 真 Effective Policy/Issuer/Repository AGENTS → R17、R00.1、GitHub 各 Repo／PR／CI（作現況證據，**非**自動授權）→ `00_KNOW_INDEX`～`19_KP_INDEX_CROSSWALK`、Commander-SP、Prompt Compiler（方法與導航輔助）。如有跨 Owner 平級衝突，留下 exact clause、SHA、Owner、affected scope，請原 Owner route 判決，不得自行以檔名新舊選勝者。

**當前紀錄之 source pin（必重新計 SHA；僅作比對基準）**：

```text
FHS-MSC_藍圖_r2.md = a80b3b4d7cc93e52a297a3e5176e27f207b36b8cd81a3d5440c70b4a80290ff9
B1_00_GOVERNANCE_AND_CONTROL = 3096e98096ad48b3b3cfda07c6075ccffba8b44c1851a804d63f0ab103aef576
B1_01_DOC_B1_PI = e1d8931c036a1e9dc97f79a3d0d00f151ea5a29dc81fb3d7aa488d5446d7b666
B1_02_DOC_B1_PD = 8e15b92a69302bbb0f9a6352f80c9687fdfb3a217006703a87b3ba559f42eb2b
B1_03_DOC_B1_OPS_ECP = 54a17818473f2a4b7c4f0f8f504bc96e4e1450540facfd30cf38234fa89e8b8a
B1_04_DOC_B1_DEV_ECP = 7a1e44dfd91bd24011c019f3ff73446e6cebf4b7847d7220f7c78dc25927def5
B1_05_DOC_B1_TQAEP = 1e09126f0c8e92fcd6e8531072a3f1f3033d82a671c2b4bb62c9916e675b7127
B1_06_PRODUCT_COVERAGE_AND_R15 = f929d9cffd462d23bbdb52171f72a450e96e59c8333bc05ebd739a2d38338337
B1_07_NATIVE_TOOLCHAIN_EXACT_USAGE = d1e0283200ad57cf1a3a1fc62bc09c6980ff118d4b7af4401d011ea87a009ea7
B1_08_GOLDEN_WORKORDERS_E2E = bc12a5fca45e4f68c1b1a4772b00ca72e0c07be8293527bbaafceadc7347290f
```

**既有 Windows 候選 Roots**（不可先驗視為已獲可寫入資格）：`C:\Projects\Agent_Workspace\SBL`、`C:\Projects\Agent_Workspace\PIPD`、`C:\Projects\Agent_Workspace\Fabric`、`C:\Projects\Agent_Workspace\HG-KSEOS`。前次 HEAD 分別為 `10d510f7b052e6139fd4eb536f970c0245002e17`、`39079c02b8f2a3a3e63d3f2a2d5537805d3a3594`、`bb06b7a6c17c45c777a636e9dae3196e21eb77b9`、`086a9402189a2bb0ac3b198a7a9805b3dcbe38d8`；前次 Dirty/Untracked 有重大存量，**不得** `git clean`、`reset --hard`、`stash`、`add -A`、覆蓋 ignored/private 內容，亦不能將 74 個 Worktree 記錄中失效路徑當作有效施工 Workspace。

SBL／Fabric／PIPD-LS-SP remote HEAD 只作當前差異基準；HGK 上次 `origin` 空白，**不可擅加遠端**。先定位真 Loaded Runtime／Hermes venv／canonical home／kanban.db、reparse/junction、實際 git top-level、ACL、effective import，而不是從配置欄位判定已生效。密鑰只通過合規 Secret Store/Broker 使用，不讀值、不輸出。

## 3. Intent / Non-goals / Claim ceiling

**真實交付**：補完 27 原子、31 WO/OBS 及 B1 可適用的 TQAEP；依各身份及條件保留 120 parent、124 child、38 nodes、949 R15、192 matrix、81 named assets，並用原始 denominator、原 ID、Source/Owner/Disposition、TestClass、Raw Receipt/Claim 建立 closure matrix；完成 G-A、三 GWO、G-B、外援撤銷及新 Session Native Successor；再交付 Full SBL/FHS-MSC 剩餘工程的 Native Handoff Packet。

**不屬 Codex 外援本次完工條件**：全面施工八種 ProductKind×三 Mode×全部 Host、實裝 386 技術候選、交付所有 SP/Host 全產品正式 Release、SWOF W3 Mutation、未選用 Donor/Method 的全量安裝、重建 Issuer／Scheduler／Policy DB／PIPD Compiler、把四個 Repo 合併、繞過 Gate 強推 GitHub PR。所有 Full-Product 延期項保留原 ID、原因與重入條件，不移除或誤標 PASS。

**Claims 分層**：Source Identity PASS ≠ SourceFreeze；Prompt Compiler PASS ≠ Native Admission；CI PASS ≠ Live Loaded SHA；Maker POS PASS ≠ Independent AO；G-A ≠ G-B；FHS-MSC MVP ≠ Full SBL Release／SWOF W3。任何未實測的 domain case 標 `NOT_RUN`，受影 Gate `HOLD`；任何真負例未達預期才標 `FAIL`，不能用 NOT_RUN 裝作已測。

## 4. Active / Deferred / Forbidden scope

- `ACTIVE_RECOVERY_READONLY`：前輪證據快照再驗、`PL-003/PL-004` 根因定位、Source/Credential/Owner Registry 的**存在性及驗簽**、真 Task Kind 查詢、Tool/Host ABI 探測、Oracle ABI Crosswalk、Compiler Contract 受影修正（在本 Mission 專用隔離 outputs；不改 Compiler/Policy 來放寬拒收）。
- `ACTIVE_AFTER_COMPILER_PASS_AND_NATIVE_PERMIT`：R1 grant/effect fail-closed；R2 Hermes Queue/Lease/Fairness；R3 Fabric Stage→Active→Loaded；R4 Hermes/Codex/Checker/model lanes；只對受影現役 HotPath 實施最小 patch、正式 activation、回讀與 requalification。
- `ACTIVE_NATIVE_B1_E2E`：SBL 最小 proposal-to-native handoff；GWO-FABRIC、GWO-HGK、GWO-SBL；有條件 T2/T3/T4、撤銷／新 session Native successor、PRE-W3 shadow read-only compatibility。
- `CONDITIONAL`：PIPD-LS-SP PR #19 CI 缺陷只有經定位證明會阻斷 B1 的合法 PIPD 編譯、插件資格或已選 Host 才在其 own Repo/Owner WriteSet 中修；gstack、OpenSpec、SWARM 等依 Effective Method Policy `mandatory/selected` 才執行真路由與收據。
- `FULL_PRODUCT_DEFERRED`：949 中的 629 類及任何經合法條件裁定的非 B1 技術，不提前施工；254 Conditional 均應逐項分配條件判斷及 re-entry，66 B1 Required 不可改稱 N_A。
- `FORBIDDEN`：自行製造 token/簽章/Issuer；改 Compiler 的 fail-closed hard constraints 來讓它變綠；將 `CR_ORACLE_001_OPEN` 清空、改名或自動 ratify；把 Policy registry epoch 改成較新數字代替 Active/Loaded 證據；自簽 Checker；繞過 `USER_DATA_EFFECT` 的獨立權限；使用 `--yolo` 或 unrestricted privileges 迴避 Sandbox；對受影以外共享根目錄清理／重寫；公開 Secret 或未准入來源。

## 5. Baseline / Reuse / Do-not-redo

**前輪已確定，除 source/currentness 失效不得重算整份**：B1 9/9 SHA pin；`27/31/120/124/38/949/192/81` 身份保留；949 分配 `66 REQUIRED +254 CONDITIONAL +629 DEFERRED`；Compiler 四次 exit 2；四個產品 Root HEAD／Dirty 前後一致、產品寫入 `0`；G-A/G-B、三 GWO、Maker/Checker 真執行皆未開始；`native_durable_workorder=null`。此 checkpoint 不是可由 Scheduler 自動恢復的 Native WO。

**需要重新確認的精確差異**：

1. `PL-003`：`C0_C9_CONTRACT.json` 的 `source_scan.required_source_families=102`，`reviewed=100`，`missing=2`；這兩個缺失是 `CURRENT_NATIVE_ADMISSION_AND_SOURCEFREEZE_APPROVAL` 與 `CURRENT_REGISTERED_TASK_KIND_BINDING`。**不是全部 100 個來源消失**。維持 `authority.missing_sources` 真值，不可只刪除 required/missing 以求 PASS。
2. `PL-004`：DOC-07 canonical Oracle Writer 與 installed P4 `pipd-pi-compile/schemas/output.schema.json` 的 `oracle_source: DOC-03 DOMAIN_ORACLES` 存在權威／ABI 衝突；原生 Schema 現版不可由 Codex 直接修改為 DOC-07。需要 DOC-02／DOC-07／P4 Schema Owners 的有效 Erratum、namespace compatibility 決定、版本範圍與獨立相同主體 regression。
3. HGK Model lanes：`AGENTS.md` epoch33、lane registry epoch34/source pin revision33、model assignment revision34/registry_epoch33；PLAN/VERIFY 的 assigned OpenAI 模型與 declared transport DeepSeek 不一致。數字/文字不等於 signed effective epoch；必測 Required vs Served + Credential Principal，不可靜默換模型。
4. Hermes binding 指向 AppData venv、home、DB 僅是 config；上次沒有 matching live PID/import/loaded digest 證據。計畫任務 `HGK-OpenCodex-Sealed-10101` 的存在**不代表** Native successor。
5. 先前 `B1_COMPLETION_LEDGER.json` 與 ZIP 內 `08_handoff/B1_COMPLETION_LEDGER.json` 具有相同 ID／結果／基本契約；單獨 JSON 是緊縮投影，ZIP 內附帶 `source_text`、部分 `source_requirements`；不要因位元組不同就判錯誤，也**不可**拿緊縮版代替必要的原文 reread/Oracle。
6. PIPD PR19 當時 failing check 為 `public-plugin-verify`；一項 offline-gate success 不代替 exact-head required verify PASS。重新 fetch 現行相同 HEAD 的 job 和 annotations 才能合法裁斷。

所有上次 SHA／HEAD／PR/CI 資料只是 checkpoint。每次真正施工以前必檢查 `SourceSHA + Root FileId/Reparse + HEAD + Dirty Manifest + PolicyEpoch + Host Loaded SHA + Issuer + Principal`，任一 changed 就只重新綁定受影節點；不要清空既有全域台帳。

## 6. Implementation and qualification gates

### Phase R0 — 恢復環境、隔離資料與原始收據

1. 發現並驗證上次四工件：JSON parse、ZIP CRC、zip-slip/過大展開風險、raw 相同主體與 SHA；生成 `RESUME_EVIDENCE_RECONCILIATION.json`。**唯讀開源檔，輸出到本 Mission 專用隔離 `outputs/resume-<run-id>/`**。保留原 bytes，零寫四個產品根。
2. 重讀 `00_KNOW_INDEX`～`19_KP_INDEX_CROSSWALK`、Commander-SP、Compiler Skill；紀錄路徑、SHA、role、Host Loaded 狀態；禁止只列存在就宣稱技能已調用。
3. 使用安全的只讀 `git -C <root> rev-parse --show-toplevel`、`rev-parse HEAD`、`status --porcelain=v1 -z -uall`、`worktree list --porcelain`、`git ls-files`、`Get-FileHash -Algorithm SHA256`、Process/Module/Host config 查詢。採用 NUL-safe bytes，不因 PowerShell 新行編碼而產生假 Dirty 差異；同時紀錄命令 exit/stdout/stderr SHA。
4. 先釐清 zip 內 `BUILD_ORDER.json` 是上次 `CANDIDATE_ONLY` 還是有真正 Native Issue；確認 `05_native/GATES.json` 與 `06_challenge/INDEPENDENT_VERDICT.json` 仍未有有效 Raw。絕不可重用 expired Nonce、Lease、Token 或先前 WorkOrder 當新授權。

**R0 Gate**：生成 fresh `REPO_CONTEXT_DIFF`、`EVIDENCE_MANIFEST`、`SOURCE_AUTHORITY_GAPS`、`KNOWN_SAFE_READONLY_TASKS`；若來源不在，本輪僅保存 truthful Missing；不可用猜測路徑。

### Phase R1 — 不跳 Gate、精確解除 PL-003 的原生身份缺口

**第一件事：找可驗的真實原生路由，而不是修改 Compiler。** 對現役 HGK／Fabric／PIPD 的 README/AGENTS/schema/registry/control/requirements/source-freeze/admission/issuer/read-only CLI 逐條限定搜尋：

- 目前合法 Host Task Kind registry 與 permitted ChangeSet 的差別；查真 exact kind、name、scope、version、active epoch、Owner、currentness。`CONTINUATION` 是 Compiler ChangeSet，不得冒充 Native 任務型別。不要創造 `B1_RECOVERY` 等新類型，只因名稱看似合理。
- SourceFreeze 及 Approval 的真 Issuer／Owner、有效驗簽公鑰或核對介面、Source Subject SHA/Owner/Scope、Expiry/Revocation、Policy Epoch、簽章/Native 事件。允許搜尋與驗證*存在性*；不得讀出或打印私鑰、Secret、Bearer token。
- 若資料存在但未與本 Mission 綁定：依現役 documented API 向正確 Issuer 申請/綁定；保存具名原生 ACK/NACK。若不存在：建立 `OWNER_DECISION_PACKET_PL003.json`，列 `issuer_owner, sourcefreeze_subject, missing_fields, evidence, legal_issue_route, requested_action, impact, TTL, precise scope, effective_gate`；送現有治理 Owner/Issuer 流程，不製造偽紀錄。
- **Bootstrap paradox**（Issuer 本身損壞）：優先判定是否存在**已批准的**一次性 emergency/maintenance/recovery procedure；僅當該原有程序完整具備身份、受影 Writeset、時限、操作單、前/後世界讀回、受獨立觀察、撤銷及 rollback 時使用。不存在合法 Recovery Path 時 `HOLD_LIVE_EFFECT`，仍可完成離線負例與受影候選 patch；不得偽簽 HGK Token。
- 再生成兩份不同 scope 的 Compiler Contract：`RECOVERY_READONLY` 只描述合法唯讀來源與 Authority Resolution，可選 `EVIDENCE_ONLY`／`CONTINUATION`，但僅當原 schema、Host Task Kind 與資料真實適用；`B1_EFFECTFUL` 完整保留所有正常 Native Admission/SourceFreeze 要求。**不以 read-only 的 PASS 充當 effectful PASS**。

**R1 Gate**：兩個 Required Source Family 必須有原生簽核/註冊身份與有效 locator，或明確保持阻擋。任何 missing 不准改為 `reviewed` 以取得綠燈。若能完成合法只讀契約，其 PASS 僅授權該只讀範圍。

### Phase R2 — 原生 Owner 解決 CR_ORACLE_001_OPEN / PL-004

在不改安裝中 Plugin Cache、也不破壞前向相容的前提下，逐項比對：

1. PIPD DOC-02（PI compiler owner）、DOC-03（Environment-Binding）、DOC-07（Verification/Oracle Writer）、P4 `pipd-pi-compile` 實際生效 Schema `$id`/version/`oracle_source` const、PIPD CLI 生成結果與已接受消費者。
2. 製作唯一 `CR_ORACLE_001_OWNER_DECISION_PACKET`：列「canonical authoring Oracle 屬 DOC-07」與「installed runtime field/enum 尚宣告 DOC-03」兩個不同維度；對每個讀寫端點標 `semantic_owner`, `serialized_legacy_symbol`, `migration_reader`, `backward_compat`, `subject/version`, `negative_fixture`。
3. **優先最小相容方案**：Canonical Oracle/Fixture 由 DOC-07 Owner 決定；現有 P4 schema/ABI 在未經正式 Erratum 前維持 byte-for-byte，必要時於合法受影 Adapter 建立受審核的 namespace 映射，不設第二 Oracle Writer。若正式 Owner 選擇 Schema Migration，必先有 versioned Erratum、impact, compatibility, tests/rollback、獨立 Checker，禁止直接把 const 改成 DOC-07 來消滅 PL-004。
4. 唯有取得真正 DOC-02/DOC-07/P4 Schema Owner 的合法 Ratification（同一 source subject、版本、scope），且獨立執行至少「legacy accepted＋new canonical trace＋conflicting oracle negative＋foreign owner negative＋rollback」回歸後，才把 `CR_ORACLE_001_OPEN` 轉為正式 `RESOLVED`；若只有兼容設計候選則維持 QUARANTINE，但不阻擋其他不涉及此 Oracle 的合法 read-only 工作。

**R2 Gate**：原生有效的 Owner Decision、兼容結論與獨立 Raw；絕不把作者或 Codex 的自述當正式裁決。

### Phase R3 — 重新執行真正 Prompt Compiler C0～C9

1. 保留上輪 `C0_C9_CONTRACT.json` 的各來源、27 affected atoms、Activation Bridge、4 Journeys、64 acceptance edges、先前 Claim/Dispositions；只修真實證據已允許的 fields。逐源核對 `required_source_families`、`reviewed`、`missing`、`authority.sources/conflicts`，不得單純降低 required 數量或把 conflict 欄刪除。
2. 給 `root_task_kind` 綁**已存在且真正被 Native Registry 接受**的型別；`changeset=CONTINUATION` 作 Compiler ChangeSet。若原生 kind 無法表達本次混合任務，依既有 native rules 分成合法 `EVIDENCE_ONLY` 與受影 `NARROW_REPAIR` 子契約，而不是自創 schema/kind。
3. 先用 `python <SKILL_ROOT>\scripts\prompt_contract_compiler.py --help` 或實際已安裝 CLI 的 help 驗證命令參數，確認 CLI/Schema/Host 可用；在真實 Syntax 下依序執行 `lint`、`activation`、`acceptance`、`compile --out-dir <ISOLATED_OUTPUT_DIR>`；每個 stdout/stderr、exit、contract_sha、compiler report 保留。若 `PROMPT_COMPILE_BLOCKED`，**停止 render effectful executable prompt**，只產針對新的 `first_fail` 的 resolution packet、合法 read-only retry/受影 checkpoint。
4. Compile PASS 後，對實際生成的 Prompt/本續工指令與 canonical control 執行適用的 `duplication`、issuer/second-control-plane lint。**PASS 不等於已核准 Native Effect**；仍要向 HGK/Fabric/PIPD 取得 exact ECP/Permit、真 Actor/Principal、Independent Checker Binding。

**R3 Gate**：`PROMPT_COMPILE_PASS`（對 effectful 契約）＋最新 Contract/Rendered Prompt SHA＋有效 registered kind＋無受影 Oracle authority conflict；未通過絕不開始 R4 Live Effects。

### Phase R4 — 受影施工四 RepairCone，與 G-A

對下列四個 Cone：先找真正 live import/hotpath，最小 Red Repro→Frozen Preimage→有界 Candidate Patch→Green/NEG→Owner-approved stage/activation→Loaded readback→獨立驗收；每一步用原生單卡 ECP、Subject SHA、Scope、Nonce/TTL、At-most-once Journal 與有效 Permit。**對 CODEX/MAKER 始終維持指定 WriteSet**；不把程式測試成功冒充 Hot Reload 成功。

| Cone | 受影目標 | 主要強制負例／讀回 |
|---|---|---|
| R1 | HGK Issuer/Grant/Effect fail-closed | wrong subject/nonce、missing or unclassified effect 必 DENY；合法 Issuer 原生事件可驗簽 |
| R2 | Hermes Durable Queue/Lease/Fairness/Worker Busy | A blocked 時獨立 B/C 前進，同 WriteSet 不競寫；Lease CAS generation/heartbeat/expiry；未知效果 reconciliation first |
| R3 | Fabric Stage→Active→Loaded/Consumer | Stage PASS but old Loaded SHA、wrong policy epoch、reversed projection 必拒收；Approved/Active/Loaded/Consumer 同 subject |
| R4 | Hermes/Codex/Checker/模型車道 + Native Continuation | Required!=Served、wrong credential principal、self-checker 必 HOLD；Fresh Process/Session、T2/T3/T4 持久續行依現役策略生效 |

**特別處理模型路由**：對 `AGENTS.md epoch33`、`lane-routing-registry.yaml epoch34`、`model-lane-assignment.json revision34/registry_epoch33` 建精確 Drift Matrix。取真正已簽章 Active Policy/Config；模型名、provider、transport、credential principal、实际 Served arm 四者獨立讀回。PLAN/VERIFY 的 declared GPT route 不可靜默走 DeepSeek Transport；EXECUTE 的 declared DeepSeek route 也不可用其他模型假 PASS。僅經現役合法替代路由可 fallback；尚未實測不得宣稱 `gpt-6.1-sol`、`deepseek-v4.1-flash` 可用。

**G-A 是六項聯合 Gate**：`valid issuer` ∧ `fair durable queue` ∧ `Fabric Active/Loaded same SHA` ∧ `three lanes Required=Served with principal` ∧ `selected/mandatory method true invocation receipts` ∧ `independent checker on exact subject`。任一不成立 `G-A=HOLD`，保留各 Cone 成功項，不重設整個 Mission。

### Phase R5 — SBL 最小接線、31 Slots、三域 Golden WorkOrders

由恢復後 HGK/Hermes 控制施工編排，SBL 只能以現有 `plan.propose`／Commander/Bridge 送 Proposal；PIPD 保持唯一 Compiler；**SBL 永遠不能自發 Issuer Permit**。按照 Ledger 31 Slots、B1 00～08 的每卡 Domain readback/effect classifier 運行；只需改 B1 受影缺陷，不由 Codex 外援擴展至 Full Product。

- **GWO-FABRIC**：三份相互獨立 `STAGE`、`LOADED`、`CONSUMER` Readback；合法 Stage→Activation 與 HGK Consumer ACK，反證 wrong SHA/epoch；回退為獨立 Owner-approved compensation。
- **GWO-HGK**：SBL proposal→HGK Native WO/Permit→Hermes Queue/Lease→可逆小 Effect→Raw Id/Checker；負例 ghost worker、stale nonce/lease、unknown-effect replay；不得以 Builder stdout 代替 Native event。
- **GWO-SBL**：`CLI_TOOL × STANDALONE` 安裝／Doctor／Help 先走 Host OPS，UserData 另經合法 USER Owner/consent/issuer。隔離資料目錄執行真 `init → add → list --json（跨 Process） → remove --id <actual-id> → list --json → uninstall --yes`，在 `python -m sbl_cli.sbl_todo` 實際 CLI 中 `--data-dir` 位於 subcommand 前；不使用不存在的 `delete` 指令。分別保留 Install/Add/List1/Remove/List2/Uninstall 真收據。沒有 User Issuer 則 `NOFIT_USER_ISSUER_UNBOUND`，不能借 OPS Token。
- **三個 SBL Product Journeys**：與 B1 交接必要的 CLI/Greenfield、Brownfield Red→Green、不觸發負例的 Skill/Agent 只在已選 Host/有效真路由中驗收；非必要額外 Host/Mode 轉交後續 Native Full Product Task。

**31 Slot 完整性**：保留原 Ledger 全部 31 Id（本文附錄列出），逐 Slot 僅能標 `PASS/FAIL/HOLD/NOT_RUN/N_A` 的正確 domain status；`N_A` 僅在真適用性裁決時可用，否則保留 HOLD/NOT_RUN。Parent 120／Child 124 必須與原 Slot 按 same-subject join，不可跨 Slot 重用原始效果收據。Fabric、HGK、SBL 三個 GWO 要不同 operation_id/subject/policy epoch/ECP/readback/checker identity；不得互借。

### Phase R6 — G-B、外援撤銷、新 Session Native Successor

由現有正式 Owner 撤銷 temporary Codex external helper principal/scope/nonce；保存可驗證 `RAW-REVOKE`。結束原 External Session，在另一 Process／Session 驗證 Hermes Durable Journal/Dispatcher **自行**觸發新的 Native WorkOrder：HGK Issuer、Hermes Lease、same-subject Maker/Checker、journal/readback 均屬 Native path；External Codex 不可再作觸發主體。拿已撤銷的舊 Token 嘗試受限 NEG，必在 Spawn 前拒收且 `zero unauthorized delta`。出現 stale/unknown effect 時先 reconcile 世界狀態，禁止 blind retry。

**G-B 聯合條件**：三 GWO 真效果 + 三組 distinct Raw + revoke before successor + successor no external trigger + rejected reentry + no unapproved residue + independent Checker + rollback readiness。未全部成立絕不宣稱 Native Autonomous PASS。

### Phase R7 — 獨立驗收與 Native 長期工程交接

核驗同一 source/policy/HEAD/Loaded Subject、當輪 Receipt、Maker/Checker Principal 分離、required method invocation、positive/negative/edge/security、restarts/rollback、no data/secret leakage；獨立 Checker 只讀被測主體，不能修改 Candidate 或重寫 Oracle/ExpectedResult。Native Gate PASS 需真簽章/ACK；若 Checker 不可用，Maker 只輸出完整 Candidate/Evidence 和 `HOLD_INDEPENDENT_AO`。

建立 **`B1_NATIVE_HANDOFF_PACKET`**：

- `SOURCE_AUTHORITY_MAP`：FHS r2/SBL DOC-00～13/B1 00～08 的 exact SHA/Owner/生效邊界及衝突 disposition。
- `B1_COMPLETION_LEDGER`：保持 `27/31/120/124/38/949/192/81` 的原始 IDs＋逐項 Raw/結果＋66/254/629 各適用性；不把延後項刪除。
- `NEXT_NATIVE_MISSION_DAG`：完整 SBL DOC-00～13、R15 M1～M4、FHS-MSC 後續 Full Product/PRE-W3 事項的合法分期與依賴，絕不要求 Codex 外援完成全部。
- `NATIVE_ADMISSION_AND_QUEUE_ACK`：使用 HGK 真 Registered TaskKind、已生效 PI/PD/ECP/Permit 及 Hermes Durable Queue 中**至少一個可檢驗接管的下一任務**；若尚未允許建立 effectful job，提交候選 DAG 和 `HOLD_NATIVE_QUEUE_ADMISSION`，不得假稱已掛排程。
- `RAW_EVIDENCE_MANIFEST`、`INDEPENDENT_VERDICT`、`G-A/G-B`、`THREE_GWO_RESULTS`、`REVOKE/REENTRY_NEG`、`LOADED_SHA`、`ROLLBACK_READBACK`、`OPEN_TT` 與可續行位置。

SWOF 接軌只做 PRE-W3 shadow/read-only consumer compatibility；不能以本次 B1 自行宣稱正式 `READY_W3` 或觸發 W3 Mutation。

## 7. Failure / HITL / Repair / Resume

**對上輪八個具名阻擋與操作處置**：

| 阻擋 | 先採取的合法自動處置 | 不可替代的真正解鎖證據 |
|---|---|---|
| `CR_ORACLE_001_OPEN` | DOC02/03/07/P4 schema ABI crosswalk；最小兼容 Erratum 候選；舊 Schema 保留 | Canonical Owners 正式 Ratification + same-subject independent regression |
| `B1-NATIVE-ADMISSION-UNBOUND` | 擴大**受界定**的 native registry/issuer/approval 唯讀查詢；準備 OwnerDecision Packet | signed effective SourceFreeze/Admission + registered TaskKind，驗證 issuer、scope、subject |
| `B1-RUNTIME-POLICY-UNBOUND` | 現役 Policy/Config/Loader/Issuer/Broker ABI 讀回；EffectClass 配對 | Current signed policy snapshot、exact ECP/Permit、Native ACK + Loaded/Effect readback |
| `B1-LANE-DECLARATION-DRIFT` | epoch33/34 差異及 transport 變更 proposal；列各 Lane model/prov/cred | actual required==served、effective signed epoch、正負路由測試 |
| `B1-CHECKER-UNBOUND` | 查現有獨立 Checker Registry/Principal、設計只讀驗收委派 | distinct Authorized Checker principal / immutable same-subject Raw verdict |
| `B1-USER-ISSUER-UNBOUND` | 在隔離 fixture 準備 UserData effect/consent/negative cases | 合法 UserData Owner + separate USER permission/consent/issuer；無則 NOFIT |
| `B1-PIPD-PR19-CI-FAIL` | 精確讀 failing job/annotations，定位受影真阻擋 | 同一已准入 HEAD required CI 變綠，或具名合法非適用 Owner Decision（不可默免） |
| `B1-P0-READINESS-INCOMPLETE` | 真 Root/Reparse/ACL/Loaded/Source clause 受影重驗；FAR manual 缺失記 TT | Source Owner 與 Host 原生 Reader 有效證據，未找到者具名 Missing 不造假 |

**停受影、不中止其它獨立分支**。對每個 first_fail：`Classify → Minimal Repro → Bounded Repair Proposal → (Legal Gate) Execute → Readback → Independent Verify → Resume`。最多在有新可檢驗根因或合法授權後按已註冊 retry budget 重試；同一 failed permission/token 不得自動永無止境 retry。世界狀態不明 (`UNKNOWN_EFFECT`) 時先 reconcile，不復送原 operation_id。Missing Owner/Issuer、非法 scope、外洩 Secret、使用者資料不同意、Checker Maker collision、安全 NEG 失敗，一律即刻 `HOLD_AFFECTED_EFFECT` 並產詳細 Decision Packet。

**合理授權選擇**：本次 Owner 已指定以最小 B1 修復為重心；對不影響權限、契約及產品行為的普通隔離診斷、測試與候選方案，按既有權限自行進行。需要簽章、Host effect、公開推送、跨 Owner 合併、User Data 真異動或生產切換時仍須取得真 Native Owner/Issuer/Checker/Pipeline 工件。**不要用一段宣稱「Owner 代位完全同意」的 JSON 或臨時自創 Permit 代替原生簽章。**

## 8. Evidence / Independent acceptance / Candidate binding

**每一步輸出 `build_order`**：`root, HEAD, exact WriteSet, source_sha, active_policy_epoch, workorder_id, registered_task_kind, effect_class, ECP_ref, permission/token_ref_nonsecret, actor_principal, checker_principal, required_method_map, expected_raw, rollback_ref, stoploss`；`steps[]` 各有 `command`, `exit`, `stdout_sha256`, `stderr_sha256`, `effect_op_id`, `pre/post SHA`；最後有 `candidate_sha`, `loaded_sha`, `evidence_locators[]`, `raw_receipts[]`, `first_fail`, `open_items[]`, `resume_checkpoint`。

唯讀 Observation Slot 使用 `NO_EFFECT`，不產假 ECP/Permit；Repo-bound `REPOSITORY_WRITE` 才按真 `RepoContext` 調 PIPD PD Binder；`HOST_OPERATIONS` 與 `USER_DATA_EFFECT` 使用合法 Owner-bound typed adapter 與不同 Issuer，不借 Repository ECP 產 Host effect。不同 WorkOrder、operation_id、resource、Candidate SHA、PolicyEpoch 之間，Receipt 不得共用。Maker 測試可附作證據，但 `INDEPENDENT_PASS` 必有真正不同 Principal 的 Checker Execution Receipt。

交付 `B1_Resume_Execution_Report.md`、`B1_Resume_Checkpoint.json`、`B1_Completion_Ledger.json`、`B1_Raw_Evidence_Manifest.json`、`B1_Compiler_Receipts.json`、`B1_Open_TT_and_Owner_Decision_Packets/`、`B1_Native_Handoff_Packet/`；Raw 可另壓縮 ZIP 並有完整 SHA 清單；與上次檔案採不覆寫版本化輸出。若 Mission 分會話繼續，確認 Hermes 真 queue/job 存在才可標 `NATIVE_DURABLE_RESUMABLE`；否則必標 `READONLY_CHECKPOINT_NOT_NATIVE_JOB`。

## 9. Termination / Final output

**唯一可宣稱 B1 完成的條件**：

1. 來源及 Native Registered Kind／Owner Oracle Conflicts 已按適用性合法閉合，受影 Effectful Compiler 真 PASS；
2. 四 RepairCone R1～R4 的必要現役故障得到可核 Live Readback，`G-A=PASS`；
3. 27/31 的 B1 受影事實與 120/124/38 的適用 Case 已執行或以**原生規則**合法 disposition，949/192/81 原身份與 66/254/629 權責完整；
4. `GWO-FABRIC`、`GWO-HGK`、`GWO-SBL` 各自有 Native/World Effect 和不互借的 Raw/Checker；
5. 外援權限已撤銷，在真正另一 Session/Process 有原生排程的後續 WO、撤銷重入必拒收、`G-B=PASS`；
6. 原生持久接管後續 SBL/FHS-MSC 工程的 Handoff ACK 可驗，SWOF PRE-W3 只在合法 Shadow 層接軌；
7. 獨立 Checker 對 exact frozen subject 覆核、Rollback/Residue 無非預期殘留，所有 Open TT 有正式處置。

若任一必要前置仍未解：不要輸出空泛「已完成」或無限重試；輸出本輪**最深合法進度**與最小 `FIRST_FAIL`、完整 Evidence/OwnerDecision 欄位、再進入條件和不可變 checkpoint。對無關卡保持合法繼續；不得以為拿到本文件就可繞過 Compiler 或永續控制完整 SBL 產品。

**本次給最終使用者的回報格式**：`Mission State`、`Source/Native Binding Verdict`、`Oracle Decision`、`Compiler Verdict`、`R1..R4`、`G-A`、三 `GWO`、`G-B`、`Codex External Revoke`、`Native Successor`、`Native Full-Product Handoff`、分母結果、Git/Host Effects、獨立 Checker、FirstFail/Next Owner、可驗下載或本機實體輸出路徑。所有結論必標明 `observed`／`candidate`／`not_run`。

---

## Appendix A｜31 WorkOrder／Observation 原始身份索引（原 Ledger，禁止重新編號）

| 原始 Slot ID | EffectClass | Domain EffectKey |
|---|---|---|
| `OBS-B1-A1` | `READ_ONLY_PROBE` | `ROOT_RAW` |
| `WO-B1-A2` | `HOST_OPERATIONS` | `ISSUER_SUBJECT` |
| `WO-B1-A3` | `HOST_OPERATIONS` | `QUEUE_WO` |
| `WO-B1-A4` | `HOST_OPERATIONS` | `RECEIVER_ABI` |
| `OBS-B1-A5` | `READ_ONLY_PROBE` | `MODEL_LANES` |
| `WO-B1-A6` | `HOST_OPERATIONS` | `EFFECT_JOURNAL` |
| `OBS-B1-A7` | `READ_ONLY_PROBE` | `RAW_EVIDENCE` |
| `WO-B1-A8` | `REPOSITORY_WRITE` | `NATIVE_HOTPATH` |
| `WO-B1-A9` | `HOST_OPERATIONS` | `NATIVE_CONTINUATION` |
| `OBS-B1-B1` | `READ_ONLY_PROBE` | `SOURCE_ATOMS` |
| `OBS-B1-B2` | `READ_ONLY_PROBE` | `REPO_CONTEXT` |
| `WO-B1-B3-DEV` | `REPOSITORY_WRITE` | `SBL_TO_NATIVE__DEV` |
| `WO-B1-B3-OPS` | `HOST_OPERATIONS` | `SBL_TO_NATIVE__OPS` |
| `WO-B1-B4-DEV` | `REPOSITORY_WRITE` | `ECP_SELECTOR__DEV` |
| `WO-B1-B4-OPS` | `HOST_OPERATIONS` | `ECP_SELECTOR__OPS` |
| `WO-B1-B5-DEV` | `REPOSITORY_WRITE` | `THREE_SP__DEV` |
| `WO-B1-B5-OPS` | `HOST_OPERATIONS` | `THREE_SP__OPS` |
| `WO-B1-B6-USER` | `USER_DATA_EFFECT` | `TODO_PERSISTENCE` |
| `OBS-B1-B7` | `READ_ONLY_PROBE` | `NOFIT_ROUTE` |
| `OBS-B1-B8` | `READ_ONLY_PROBE` | `TRACE_GRAPH` |
| `OBS-B1-B9` | `READ_ONLY_PROBE` | `R15_COVERAGE` |
| `WO-B1-C1` | `HOST_OPERATIONS` | `FABRIC_PROMOTION` |
| `WO-B1-C2` | `HOST_OPERATIONS` | `HGK_GWO` |
| `WO-B1-C3-OPS` | `HOST_OPERATIONS` | `SBL_GWO__INSTALL` |
| `WO-B1-C3-USER` | `USER_DATA_EFFECT` | `SBL_GWO__USER` |
| `WO-B1-C4` | `HOST_OPERATIONS` | `EXTERNAL_GRANT` |
| `WO-B1-C5` | `REPOSITORY_WRITE` | `CODEX_MINPATCH` |
| `WO-B1-C6` | `HOST_OPERATIONS` | `REVOKE_RACE` |
| `OBS-B1-C7` | `READ_ONLY_PROBE` | `FOUR_LAYER_ID` |
| `WO-B1-C8` | `HOST_OPERATIONS` | `NATIVE_SUCCESSOR` |
| `OBS-B1-C9` | `READ_ONLY_PROBE` | `TRIPLE_GWO` |

## Appendix B｜本輪已查驗的原始證據界線

- ZIP 證據包 `02_contract/compiled/compiler-report.json`：`PL-003×2`、`PL-004×1`；`PROMPT_COMPILE_BLOCKED`。來源紀錄數 100，兩個 Required Source Families 缺少有效 Native 綁定。
- ZIP 證據包 `05_native/GATES.json`：`G-A=HOLD`、`G-B=HOLD`、三個 GWO `NOT_RUN`，沒有 Native Durable WorkOrder。
- ZIP 證據包 `06_challenge/INDEPENDENT_VERDICT.json`：`NOT_RUN`、`checker_principal=null`。
- 上傳的 JSON Completion Ledger 與 ZIP 完整 Ledger 的結構化任務值相同；ZIP 額外保留 source body，所以本文不主張它們 byte-identical。
- **本文件只是本輪可交付的指揮與恢復方案，不是已在 Windows 環境成功取得 SourceFreeze、Native ECP/Permit 或 Compiler PASS 的結果。**
