# FHS-MSC B1｜Hermes 真正自治施工、排錯與 Native 驗收「薄指揮令」r9

> **執行對象：**本地 Hermes（已正常安裝）；**任務：**接續 r8，不從零規劃，直到 `FHS_MSC_B1_PIPD_LS_PKG_00～08` 的 **B1 適用 Required 義務**均有真實獨立驗收與可重算證據，完成 G-B 與原生續工交接。**本指令取代 r1～r8 舊 Prompt 的操作流程**；舊版 Source／PI／PD／ECP／TQAEP／Gate 義務及有效證據仍有約束力。**嚴禁安裝、載入、呼叫或經子代理間接使用 `sbl-commander-sp`／Commander-SP**；其程式可在受限工作卡上修補，但它不是本輪工具。不要重裝、重構 Hermes，健康讀回僅一次。

## 0. 唯一 OWNER 常設授權：真正放行一般施工，不冒充真憑證

本輪唯一人類 OWNER 已授權 Hermes 在下述 B1 邊界內**無須重問**：查證本地／遠端、故障定位、受控 Repo 修改／三方合併／測試／Commit／Push／PR 更新、隔離合成資料、建立及執行 Durable 工作卡、精確回滾、模型車道真實探測、Host 準備與依現有合法授權自動部署、配置簽發／Checker／Oracle 服務、合約適用性工程裁決與正式驗收程序的連續執行。遇一般差異或工作失敗，**先施工，不提交新的 OWNER 問題**。

**只有一個人類 OWNER，不需要第二個人類 AO／Issuer／Oracle Owner。** 使用已由 OWNER 授權的受保護 HGK Signer Service、Hermes 非管理員 Maker Worker、不同 OS／Service SID 的 Checker Worker，各司其職。有效 Standing Policy 下允許自動 `evaluate → issue → verify → execute → readback → independent-check → next`；但是聊天文字**不是** Windows 高權限 Token、私鑰簽章、Oracle Ratification 收據、USER 真實世界效果或 AO Verdict。不可由 Maker 自簽、自驗收、偽造 ACK／PASS；不可關閉 UAC、ACL、簽章／Compiler 的拒收，或擴至 OWNER 未指明的私人資料／不可逆破壞。若沒有已授權的提權 Broker，使用 Windows 正常的首次提升權限流程；若 OS 真正要求一次確認，保留唯一具體 Host 啟用步驟，**不要以再次聊天口頭同意作為替代**，並繼續所有不受影的工作。

**原生職責不變**：HG-KSEOS 唯一 Issuer／SharedSpine；Hermes 排程與 Executor 協調；Fabric Policy 活化及 Consumer；PIPD Canonical 契約、Oracle、Compiler；SBL Host／產品／USER 操作；不同實際 Principal 的 Checker 作獨立 Raw 驗證。只使用既有 Authority／DB／Policy Plane，**不造第二 Issuer、第二 Queue、第二權威資料庫**。

## 1. 直接接續 r8 實測結果（先校驗變化，不重做已過項）

本地原始 Root：

- `C:\Projects\Agent_Workspace\HG-KSEOS`
- `C:\Projects\Agent_Workspace\Fabric`
- `C:\Projects\Agent_Workspace\SBL`
- `C:\Projects\Agent_Workspace\PIPD`

**起點：**`C:\Projects\Agent_Workspace\HG-KSEOS\var\B1-HERMES-R8\`，優先讀取 `B1_HERMES_R8_RESUME_CHECKPOINT.json`、`B1_HERMES_R8_EXECUTION_AND_NATIVE_ACCEPTANCE_REPORT.md`、`B1_HERMES_R8_COMPLETION_LEDGER.json` 以及 `hgk/`、`remote/`、`route_pin/`、`t1/` 的原始收據。九份 `FHS_MSC_B1_PIPD_LS_PKG_00～08` 是驗收合約。採用**現在**的 root/HEAD/Dirty/import、SHA 與實際命令輸出，不讓歷史 SHA 冒充現況；只重測受影依賴。

r8 已有可信的**工程候選**：`SharedSpine T1 18/18`、跨程序 digest；Route Pin rev35／epoch34 已寫入且負例及回復通過；HGK PR #1＋疊加 #2 的 11 檔已落地本地分支 commit `0d3622e`、63 PASS／28 subtests／0 warning、DB schema 遷移已測；SBL Atomic Save 本地落地、3 PASS。**不要再做相同的 T1 原語 harness、重套已存在的 HGK 位元、重跑 Route Pin 修補或重裝 Hermes**。上述不等於真 Hermes Scheduler、Host Loaded 或 Native AO PASS。Fabric PR #18、PIPD PR #20 因本地分歧撤回而未落地；Trust 未啟動；所有 T2、R1～R4、G-A、三 GWO、G-B 原生 Gate 尚未通過。

遠端候選（每次真施工前讀回最新 HEAD／CI／Review）：私有 `shw097-team/HG-KSEOS` PR [#1](https://github.com/shw097-team/HG-KSEOS/pull/1)＋[#2](https://github.com/shw097-team/HG-KSEOS/pull/2)，`shw097-team/Fabric` [#18](https://github.com/shw097-team/Fabric/pull/18)，`shw097-team/SBL` [#13](https://github.com/shw097-team/SBL/pull/13)，`shw097-team/PIPD-LS-SP` [#20](https://github.com/shw097-team/PIPD-LS-SP/pull/20)。r8 截點各 PR 仍為 Draft／未合併，未 Push 本輪本地提交。HGK PR2 的 base 是 PR1，**不得獨立於 PR1 使用**。

**保護現有工作樹**：先記錄 HEAD、tracked dirty、untracked 摘要、真正 Root，按檔案精確 WriteSet；禁止 `reset --hard`、`clean`、`stash`、`git add -A`、force push、不相關檔案覆寫、秘密／UserData 上傳公開 Repo。HGK 私有 Source 不可原封不動推成 Fabric 公開投影；先做去敏及 Secret Scan。

## 2. 現在立即跑的三條並行施工線（不要互相等待）

**A｜四庫消除具名 FirstFail 並整合成主選。**

- **Fabric #18**：`FABRIC/fabric/consumers/hgk_policy_consumer.py` 本地相對 PR base 有約 **32 行**語義分歧。先比對 `base → PR` 與 `base → current local`，保留本地新功能，手工／工具做最小**三方語義合併**，把 Consumer＋測試**成對落地**；POS／NEG／Rollback、舊行為與 PR 需求皆綠後 Commit／去敏 Push／更新 PR。保留 `INSPECTED_NOT_APPLIED` 真實語義；另外接上既有真 Activator／Loader／Consumer Readback，**原始碼合併不可冒稱 Stage→Active→Loaded**。
- **PIPD #20**：`src/pipd_ls_sp/pipeline.py` 相對 PR base 約 **44 行**本地差異；採同一三方策略，把 `pipeline.py`＋`oracle_compat.py`＋`tests/test_oracle_compat.py` 成套合併、回歸、Commit／更新 PR。OWNER 已裁決 **DOC-07 Canonical Oracle／Fixture Authoring，保留現役 P4 `DOC-03 DOMAIN_ORACLES` Serialized Legacy ABI**；不改寫已裝 Schema 欺騙相容。針對 `public-plugin-verify` 的 Stage-C ADR-0008／0009 WriteSet 基準另做最小受影修補；不得放寬 CI／Checker。
- **HGK**：沿用本地 commit `0d3622e`，確認真 Import Path／依賴 `cryptography>=42`／Schema 路徑／11 檔 hash、測試 warning 0；受控 Commit 差異、去敏推到正確私有 HGK Repo 的分支／PR，獨立檢查後再合併，確保 PR #2 安全修補不丟失。**不得直接推入 Fabric 的 `HG-KSEOS/` 公開鏡像**。
- **SBL**：沿用本地 Atomic Save（3 PASS）；受控 Commit、推送／更新 PR，檢查 Ubuntu／Windows CI、CLI 相容及隔離合成 DataDir 的 `init/add/list/remove`；保持不調用 Commander-SP Plugin。供 `GWO-HGK` 使用的既有非 Commander-SP Proposal ABI 若欠缺，以最小功能修補補齊，不刪驗收義務。
- **Route／R4**：保存 rev35／epoch34 已生效 Source Pin；**真實觸發** PLAN、EXECUTE、VERIFY_SECURITY 三 Lane 的 provider／model 調用，記錄 `required`、實際 `served`、runtime epoch 與 transport receipt。若 registry 的 provider/model 声明矛盾，修主 Registry 再重投影；不為通過檢查暗換 OWNER 指定 Provider。`source pin GREEN ≠ R4 PASS`。

**B｜完成真正的 Hermes 自治接線（r8 T1 原語不算完成）。** 定位實際 Hermes CLI／Service／Worker 從何處接收任務；連到**同一套 HGK SharedSpine 持久 WorkOrder／Lease／Journal**，做最小 typed Adapter，不新建 Queue、不重構 Hermes。真實驗證 `enqueue → poll READY → CAS claim → heartbeat/lease → checkpoint → park blocked A & process B/C fairly → effect/result journal → restart new OS process → resume successor`。先用隔離 DB／合成資料跑正負例（雙 worker、ghost、stale CAS、重播、程序被殺），**必須量到 Hermes 本人調用該 Adapter 和新程序自動恢復，不可只執行 `t1_harness.py`**。若 Hermes 沒有背景常駐入口，使用其可支持的已授權 Windows Service／Task／Watcher 建立真 Durable Dispatcher 並驗證重啟；沒有真 Host 續工觸發器就明記 `HERMES_SCHEDULER_NOT_CONNECTED`，絕不宣稱背景自治。

**C｜修復 r8 Evidence／Ledger 兩項小缺陷。** 上傳的 r8 Ledger SHA 與 Manifest 一致，但 Report、Handoff、Checkpoint、Manifest 自身四項 SHA 不一致。讀本地 Evidence Root 的原位位元，保留舊版本，建立簡短 `R8_EVIDENCE_ERRATA.json`：`source_manifest_claim_sha/bytes`、`actual_sha/bytes`、變動原因（證據不足則 `UNKNOWN`）、受影範圍；只失效受影證據，**不重跑已證明同位元的成功測試**。最終 **先固定所有工件，再生成不自含自身摘要的 Manifest；外部 checksum/Seal 記錄 Manifest SHA**，由不同驗證程序重算。Ledger 保留 949 身份的 **66 REQUIRED＋254 CONDITIONAL_UNTRIGGERED＋629 DEFERRED**，81 Named Assets 的 **24 REQUIRED＋31 CONDITIONAL_UNTRIGGERED＋26 DEFERRED**；禁止把 285 個 Conditional 改成永久 `NO_FIT`。原始 ID 不刪不重排，工程與 Native 驗收二軸分列。

## 3. 同步處理 HGK 自動簽發的唯一真正權限障礙

r8 現況：`%ProgramData%\HG-KSEOS\native-admission\registry.json` **ABSENT**，執行身份 `NOT_ELEVATED`，沒有已證明可用的有權 Service／Scheduled Task；`scripts/native-trust-maintenance.ps1`（`Inspect/SelfTest/Enable/Sign/Revoke`）已移入本地樹但 r8 **尚未實際呼叫**。

**立即做**：先用現有身份呼叫 `Inspect`，隔離空間執行 `SelfTest`（按實際工具參數；不猜 CLI；未提權可執行的部分先做）。檢查 Windows Cert Store、CNG 不可匯出金鑰、ProgramData ACL、現役 Registry、合法既有維護 Broker／Task／Service。**若已有合法有權 Broker，直接走它的受限 typed 接口**；若沒有，實作**單一 HGK Authority 下的最小受保護 Signer Broker／Checker Service 布署**，先在隔離模式驗證，再走標準 Windows 提權進行首次初始化。OS 要求 UAC 時用真正有權身份完成；不得繞過、竊取權杖或用文字偽造。此時只將受影 Host Bootstrap 工作列為 `PENDING_OS_AUTH`，**A/B/C 施工繼續**。

**OWNER Standing Policy 是一次性人類決策、可由機器反覆執行的版本化規則**，受限於 B1 Mission、Root、Repo HEAD、精確 Subject SHA、EffectClass、WriteSet、Host、Epoch、TTL、Nonce、Rollback、Revoke；只由有權 HGK Service 簽發，Maker 不持私鑰。採 `human_owner_sid`／`delegated_issuer_service_sid`／`maker_sid`／`checker_sid` 真實分離（若 schema 必須擴充，做最小版本相容 migration＋NEG，不直接刪 SID 分離驗證）。HGK `issue` 回給真 Receiver 再驗簽；不同 SID 的 Checker 從唯讀原始收據自行重算，不得由 Maker 寫 PASS。**同一人類 OWNER 可以管理全部 Service，不需要額外人類 AO。**

完成 `TaskKind REGISTERED`、本輪簽發有效 SourceFreeze、Oracle Ratification（同 Subject／已採 DOC-07 決議／Legacy ABI 回歸）、有效 Policy Epoch、可撤銷簽章／Nonce／Lease；重新編譯**更新後的 effectful subject**：`lint → activation → acceptance → compile`。`PROMPT_COMPILE_BLOCKED` 時**不輸出／不執行 effectful executable prompt**，但不影響合法隔離測試與普通 Repo 施工。真正 `PASS` 後，用固定短 TTL Permit 執行第一張可逆原生卡，Verifier 再讀回。

## 4. 真實 Native 驗收和自動下一卡：T2 → R1～R4 → G-A → 三 GWO → G-B

- **T2（最小正向鏈路）**：PIPD 真 Contract＋Compiler PASS → HGK SourceFreeze/TaskKind/Oracle 正式簽章 → Receiver Admit → Hermes **真正** Durable Queue ACK／Lease → 可逆效果 → 同 Operation/Subject/Epoch 的世界 Readback → 不同 Principal Checker Raw 重驗 PASS；錯簽、過期 TTL、Replay Nonce、錯 WriteSet、stale Lease 均須拒收且無效果。T2 未通過不許認證原生接管。
- **R1**：唯一 Native Issuer、權限作用域、Nonce／TTL／Revoke／拒收。**R2**：Hermes 原生持久、CAS Claim、Blocked A 不妨礙 B/C、Crash／Restart、真 ACK。**R3**：Fabric 真 Stage→Active→Loaded、Active／Loaded SHA、Policy Epoch 與 Consumer ACK 相等，Rollback 真讀回。**R4**：三 Lane `required=served` 及真 Mandatory Method Invocation；不能以配置／Provider 表面回覆冒充。
- **G-A**：同一現役 Subject 下六項 AND＝有效 HGK Issuer、Fair Durable Queue、Fabric Loaded＋Consumer、三 Lane served、有效 Policy Epoch Mandatory Methods、獨立 Checker Verdict。
- **GWO-FABRIC**：真 Policy 活化、Host Loaded／Consumer。**GWO-HGK**：非 Commander-SP Plugin 的受治理 Proposal 入口 → HGK Issuer → Hermes Durable WorkOrder → 可逆 Effect。**GWO-SBL**：合法 Host Install／Load，加上 OWNER 授權的**隔離合成 DataDir** `init → add → 新程序 list --json → remove --id <實際輸出的 ID> → list → uninstall`，包含殘留與 foreign-files 不得刪 NEG；真實既有 USER 私人資料不在授權範圍。三 GWO 是三個不同效果，不能互代。
- **G-B**：三 GWO 分別通過獨立驗收後，真正撤銷外援暫時許可；新 OS Process／Session 由持久原生 Queue **自行**執行 Native Successor，重播舊 Token 被拒收、確認沒有外援密鑰繼續有效，再移交 22-node 下游工作 DAG 予 HGK／Hermes，附真 Queue ACK；不是讓 Codex 永久主控。

**分母不縮水**：27 Atoms／31 WO-OBS／120 Parent／124 Child／38 Nodes／949 R15／192 Matrix／81 Named Assets／3 GWO，逐 ID 使用 `PASS/FAIL/BLOCKED/CONDITIONAL_UNTRIGGERED/DEFERRED` 的真實適用性及原證據。DOC-00（Authority/Gates）、01（PI）、02（PD）、03（OPS ECP）、04（DEV ECP）、05（TQAEP）、06（Coverage）、07（Toolchain）、08（GWO）逐文件閉環；不把 949 Deferred/Conditional 身份全塞進 B1 現役 Required。Maker tests、CI、Commit、簽發、執行或 ACK **任一單項皆非獨立 Native PASS**。

## 5. 真正連續的工作迴圈與停止條件

把本輪任務註冊到**已驗證可執行的**持久 HGK／Hermes 工作路徑，為每卡保存 `id / dependencies / scope / status / first_fail / operation_id / subject_sha / source_head / policy_epoch / permit / raw_sha / checker_verdict / next_wake_condition`。工作狀態 `READY → CLAIMED → EXECUTING → EVIDENCE → INDEPENDENT_CHECK → VERIFIED`；有缺陷自動 `REPAIR → affected-only RETEST`；只有受影卡可 `PARK_BLOCKED`，其他 READY 卡繼續。相同 FirstFail 最多兩次等價重試，第三次改切根因／替代合法路徑，不無限空跑。每次 Process 終止前先落持久 Checkpoint，確認由**另一個新 OS Process**能恢復與觸發下一張；**沒有真 Watcher/Service 時不得宣稱離線自動續行**。

**完成的唯一出口**：適用 B1 Required 全部有正確准入／Raw／世界 Readback／獨立 Checker PASS，R1～R4＋G-A＋三 GWO＋G-B PASS、真 Native Successor 成功、Repo 最終 HEAD／CI／Host Loaded 身份匹配、Ledger 與封存可重算，才標 `FHS_MSC_B1_NATIVE_ACCEPTED`。如確實缺 Windows OS 權限、外部服務或不可替代憑證：不得假簽／假 PASS，也不得以沒有第二位人類 Owner 為由停止普通工程；受影項保留具精確 `first_fail` 與可執行重入觸發的 Durable WorkOrder，其他工作直到耗盡合法可執行卡才可交付 `PARTIAL_WITH_EXPLICIT_HOLDS`。**聊天 Session 不能代替已安裝的常駐工作服務。**

## 6. 最小完整交付（只一套台帳，不複製大型治理包）

最終／每次持久 Checkpoint 更新：

1. `B1_HERMES_R9_EXECUTION_AND_NATIVE_ACCEPTANCE_REPORT.md` — 已做／未做、四庫主選／遠端 PR／Live Import、T1-Core／Scheduler 分離、Trust／Oracle／Compiler、R1～R4/G-A/GWO/G-B、真實 FirstFail、回復與下一卡。
2. `B1_HERMES_R9_COMPLETION_LEDGER.json` — 1,565 原 ID 不刪，二軸＋Required/Conditional/Deferred 明確保留，逐 Gate／Effect／Checker 原始引用。
3. `B1_HERMES_R9_RAW_EVIDENCE_MANIFEST.json` ＋**獨立** `B1_HERMES_R9_MANIFEST_SHA256.txt` — 原始位元 SHA、Exit、UTC、主體身份；不循環自摘要、無金鑰秘密、由另一驗證程序重算。
4. `B1_HERMES_R9_HANDOFF_RECEIPT.json` ＋ `B1_HERMES_R9_RESUME_CHECKPOINT.json` — 真 Signed Receipt／Durable Queue ACK，或準確標 HOLD，不杜撰。
5. `R8_EVIDENCE_ERRATA.json` — 僅 4 個 SHA 差異及受影查明；不改寫 r8 舊 Evidence。

**立即從 Fabric 32 行／PIPD 44 行三方整合、Hermes 真 Scheduler 接線、HGK Maintenance `Inspect/SelfTest` 三線開工**；修完即自動更新遠端候選及受影驗證，再進 T2、R1～R4、G-A、三 GWO、G-B。除 OS 真要求本機一次性特權建立外，**不要把任何一般工程決策當成新 HITL 來問唯一 OWNER**。禁止使用 Commander-SP。 
