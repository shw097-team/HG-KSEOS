# FHS-MSC B1｜Codex 連續續工指揮令 r3
## 來源／原生准入解鎖 → 最小修復 → G-A → 三域 GWO → G-B → HGK／Hermes 原生接管

> **交付對象：本地 GPT Desktop／Codex 的續工作業。** 本文件是一份可立即用來執行「已合格唯讀恢復、確定性工程診斷、合法隔離候選及有界 Owner 路由查找」的**恢復指揮令**。它不是 `B1_EFFECTFUL` 在 `PROMPT_COMPILE_BLOCKED` 狀態下的可執行效果 Prompt。任何產品 Root 寫入、正式原生效果、Policy Activate、簽發 Permit 或 UserData 變更，必須待現役 `B1_EFFECTFUL` 原始契約重新編譯取得真正 `PROMPT_COMPILE_PASS`、完成對應合法 Native Issuer/ECP/Permission/Checker Binding，再使用**由 Compiler 合法產生**的效果子指令執行。**不得透過本檔繞過 Compiler 的 fail-closed 規則。**
>
> **Owner 的常設工程裁決：** 一般唯讀診斷、原始證據對帳、隔離工作區修補候選、例行分析、受影測試、可逆候選、符合既有 Repo 權限與 WriteSet 的提交／PR 候選，無須反覆詢問口頭同意。Owner 已同意本 Mission 在合法有效 Native Policy、簽章、Token 與權限範圍內自動前進。這不等於已存在或可自行偽造 SourceFreeze、TaskKind、Signature、Permit、BreakGlass、UserData Consent、Independent AO 或 Release Approval。無效的 Gate 只阻斷該**受影效果**；其餘合法工作持續推進；沒有合法入口時必須準確上報，不可假裝完成或無限空轉。
>
> **核心分工：Codex 只做 B1 外援 Bootstrap Repair，不承包全部 SBL／FHS-MSC Full Product。** HG-KSEOS 保持唯一 Native Issuer、Hermes 保持 Durable Scheduler、Fabric 負責生效 Policy、PIPD 為唯一合法 Compiler、SBL 為既有產品入口。G-B 完成後撤銷 Codex 外援 Principal，剩餘完整 SBL DOC-00～13／FHS-MSC 工程交給恢復後的 HGK／Hermes；Codex 日後只可作合法 Native WorkOrder 下的 Worker。

## 0. Machine Header

```yaml
artifact: FHS_MSC_B1_CODEX_CONTINUOUS_RESUME_COMMAND
version: 2026-10-27-r3
mission_id: FHS-MSC-B1-CODEX-CONTINUOUS-REPAIR-20261026-R1
input_resume_run_id: 20261027T004542
changeset: CONTINUATION
initial_claim_ceiling: LOCAL_RECOVERY_CANDIDATE_NOT_NATIVE_ACCEPTED
initial_RECOVERY_READONLY: PROMPT_COMPILE_PASS
initial_B1_EFFECTFUL: PROMPT_COMPILE_BLOCKED
first_fail: PL-003
additional_conflict: PL-004/CR_ORACLE_001_OPEN
initial_live_native_workorders: 0
initial_product_changes: 0
initial_gate_A: HOLD
initial_gate_B: HOLD
start_action: RECOVER_IN_PLACE_READONLY
host_task_kind: DISCOVER_AND_BIND_EXISTING_REGISTERED_KIND
native_effect_policy: COMPILED_CHILD_AND_ACTUAL_EFFECT_PERMIT_ONLY
halt_policy: PARK_ONLY_AFFECTED_SCOPE_CONTINUE_INDEPENDENT_ELIGIBLE_WORK
termination: INDEPENDENT_NATIVE_B1_ACCEPTANCE_AND_REAL_HANDOFF_OR_EXPLICIT_EXTERNAL_HOLD
```

## 1. Mission / ChangeSet（確定目的）

本次不是重新建立施工計畫，而是**續接兩輪已存在的真實 Evidence**，優先解鎖 PL-003/PL-004，再對本地 HERMES／HG-KSEOS／Fabric／SBL 的現役路徑完成 B1 受影最小修復、POS/NEG/EDGE/SEC、獨立驗收、G-A 與三個 Domain Golden WorkOrders、G-B 外援撤銷及下一 Process/Session 的 Native Successor；之後交付可由 HGK/Hermes 消費的 Full Product Handoff。**不得因一個 session 結束而宣稱工作已完成；也不得因正式 Gate 未成立而偽造自主持續進度。**

執行原則：優先重用既有 Raw、Candidate、Code、讀回與合法路由；只針對 first failure 修最小受影範圍。每一獨立子任務保存 immutable checkpoint、refusal reason、reentry predicate 與 next legal action。若會話還能運作，持續執行可合法推進的下一子任務；若無法創立真 Hermes Native 排程，輸出完整恢復資料，**明示本地 session 不具備後台自動續行**，不可說任務正在背景執行。

**交付物**：`RESUME_R3_B1_SITUATION.json`、`PL003_ROUTE_BINDING_READBACK.json`、`CR_ORACLE_001_DECISION_STATUS.json`、`COMPILER_STAGE_RECEIPTS`、`B1_COMPLIANCE_MATRIX`、`R1_R4_BUILD_ORDERS`、`GATES_AND_GWO_RECEIPTS`、`HOST_AND_REPO_READBACK`、`B1_COMPLETION_LEDGER.json`、`NATIVE_FULL_PRODUCT_HANDOFF`、`B1_Resume_R3_Checkpoint.json`、`B1_Resume_R3_Execution_Report.md`。所有包含位址、Token 或私人配置的 Raw 只放受 ACL 保護的本機 evidence 範圍；公開 Repo 只投影許可的已去敏候選。

## 2. Authority / Files-first order（嚴格沿用）

1. **先取真實前輪工件**：上一輪 `B1_Resume_Execution_Report.md`（Resume run `20261027T004542`）、`B1_Resume_Checkpoint.json`、`B1_Resume_Evidence.zip`；同時取上一輪 `B1_Execution_Report.md`、`B1_Resume_Checkpoint.json`、`B1_COMPLETION_LEDGER.json`、`B1_Evidence_20261027.zip`。以本機 `C:\Projects\Agent_Workspace\知識庫\實作相關DOC\Fabric vNext\Semantic World OS Fabric\SBL_PIPD` 及前次真正輸出目錄定位，**不能假設附件的雲端路徑是 Windows 路徑**。ZIP 使用 `ZipFile.testzip`、拒絕路徑穿越／symlink／size bomb、讀個別 member；不可無檢查解壓或執行 ZIP 腳本。
2. **上位藍圖**：`FHS-MSC_藍圖_r2` → `SBL_PIPD-LS-PKG_DOC-00`～`DOC-13` → B1 r3 `FHS_MSC_B1_PIPD_LS_PKG_00`～`08`（各自真本地 SHA、行錨、主體／Owner）。B1 r3 規範高於同主體 r2 候選。Canonical `PIPD-LIFECYCLE-SPEC@1.1.0`、PIPD DOC02/DOC03/DOC07，且真安裝 P4 Schema/ABI 均需比對，不因其中一冊較新便覆寫其他 Owner。
3. **前輪交接契約**：`FHS-MSC_B1_本地 Codex 高自動化連續修補、施工與驗收執行規劃方案`、`FHS-MSC B1 工程範圍與 Codex → HG-KSEOS／Hermes 交接鑑定`、Master Mission Prompt、Resume r2、已凍結的 R00/R17 來源收據。版本不同按具體 Owner 的法位裁決，不自行取最大日期。
4. **輔助路由**：已安裝 `sbl-commander-sp`（只接受 Frozen PI/PD、Root/HEAD/WriteSet、原始執行收據、Maker 不得自驗）；`00_KNOW_INDEX`～`19_KP_INDEX_CROSSWALK`；`construction-acceptance-prompt-compiler_SKILL.md` 及其 `references/*.md`、`prompt-contract.schema.json`、`scripts/prompt_contract_compiler.py`；Fabric、HG-KSEOS、FAR 操作手冊。Skill 存在≠ Host 真 Loaded；`HOST_PENDING` 保持直到有效讀回。
5. **本輪證據 ZIP**：先驗證其 SHA、member/CRC；以 `02_contracts/B1_EFFECTFUL/compiler-report.json`、`02_contracts/RECOVERY_READONLY/compiler-receipt.json`、`02_contracts/SCOPE_SEPARATION.json`、`01_native_discovery/*`、`03_candidate/*`、`04_verify/*`、`B1_Native_Handoff_Packet/*`、`B1_Open_TT_and_Owner_Decision_Packets/*`、`05_handoff/OPEN_TT.json`、`B1_Completion_Ledger.json` 作精確 resume，不重讀不相關私人內容。工具輸出是觀測資料，不能自行變更 Authority 或 Claim。

本輪已核對的上傳 ZIP SHA-256：`08209264120d3a7ae7606e3f08e8415d31618c7ccb138a010dc104528e673060`；178 members；`testzip=None`；總解壓宣告量 21,236,410 bytes。回報 SHA、Checkpoint SHA 應以本機重新 hash 為準。舊有效 source pins 與 Main HEAD 只作快照；**每張 WorkOrder 前重新查當前 Source、Root file-ID、HEAD、NUL-safe Dirty、Policy Epoch、Loaded、Issuer 與現役權限**。

## 3. Intent / Non-goals / Claim ceiling

**Codex 在此只受委任：** 解除 Bootstrap 受影阻斷、完成必要 31 個 Work Slot 的合法有界執行／觀測、驗證三個 GWO、G-A/G-B、Next Native Mission Handoff。對 949 原身份、192 適用性矩陣與 81 具名資產逐筆留原身份和狀態，不代表全部新增／安裝／發布。完整 SBL DOC00～13、FHS-MSC M1～M4、所有其他 Host/Mode 的後續產品開發必須移交 HGK/Hermes，不能以外援名義一直施工。

**Claim ladder**：`SOURCE_IDENTITY → RECOVERY_READONLY_COMPILE_PASS → B1_EFFECTFUL_COMPILE_PASS → NATIVE_ADMISSION → CANDIDATE_PATCH_TESTED → HOST_EFFECTIVE → INDEPENDENT_ACCEPTED → G-A/GWO/G-B → NATIVE_HANDOFF`，每一層有不同 subject、證據及簽章；未實作不 PASS，合法 `HOLD` 不算測試 FAIL。`PROMPT_COMPILE_PASS` 不等於 Permit、PR Merge、Release 或 Host Loaded。

**禁區**：用聊天指示生成、複製或偽簽 Native SourceFreeze／TaskKind／Permit／Oracle Ratification；為解除 PL-003 而降低 `required_source_families` 或將 missing 硬改 reviewed；刪除 `CR_ORACLE_001_OPEN`；以經過時效的歷史 SFR 當新核准；用已存在 BreakGlass policy/schema 冒充發行／授權；改安裝中 P4 Cache；以單一 primary model 投影冒充 GPT route served；用 `git clean/reset --hard/stash/add -A` 處理既有大型 Dirty；直接 push 到 `main`、自簽 Independent Checker；以 README/ZIP/CI success 替代真活 Host。

**Token 原則**：若需使用 `C:\Projects\Agent_Workspace\API KEY\GITHUB-REPO_SHW097-4.txt`，只經授權 OS Credential Store／process-scoped helper 在本機讀取並用於正確 repo 之 Git auth，不將值讀進模型對話、stdout/stderr、Process argv、Git URL、日誌、PR、commit、Evidence 或配置，不外洩。當前僅查憑證是否可合法使用／scope 是否足夠；沒有實際被核准的 Repo 變更，不為了 PR 數量建立空提交或無意義 push。

## 4. Active / Deferred / Forbidden scope（本輪常設代位裁決）

- **立即可做：** 對照兩輪收據、準確定位 Owner/Registry/TaskKind/Issuer 發行端點，對授權綁定路由做只讀 API/introspection、獨立隔離 Oracle 10-test 外的有價值負例、源碼最小候選、實際現役 hotpath 診斷、R4 provider/transport 調查、PR19 首個 guard 根因定位、full product DAG 升級準備、產出可簽核的決策封包；不用再次請 OWNER 同意普通決策。
- **可寫隔離區：** 建立全新 **per-run** 工作資料夾、source-bound candidate、私有 output receipts；僅本次 run 明確 WriteSet，留前輪不可變；沒有既有 Native 審批不得修改四個產品工作樹。
- **條件式可做：** 真 Repo 改動、HGK state 建立、TaskKind 登記、Policy Activate、Hermes Queue Submit、UserData add/remove、Release／Merge 等。必須取得該資產真正合法的獨立 Native/Owner 授權，當輪有效 Subject/Scope/TTL/Signature/ECP/Permit，以及獨立 Readback。按原生項目分卡、分效果與權限；不能拿一般聊天委任替代。
- **暫不做：** 擴建無關新系統、重構全部 HGK/PIPD/Fabric、無必要新增 DB/Issuer／Scheduler、所有 24 donors 的安裝、所有 192 格的主機安裝及完整 SWOF W3 mutation。保留原始 Source Disposition 與重新啟用條件。

**代位工程裁決（非原生簽章）**：

1. Oracle 採 **「Canonical Authoring＝DOC-07；現役 P4 `DOC-03 DOMAIN_ORACLES`＝Legacy Serialized ABI」** 作為優先 Ratification 候選；不改本機現役 Schema，優先採 namespace crosswalk/adapter 保相容。正式 RESOLVED 須原 Owner 體系批准與獨立 Same-Subject Tests，否則仍 QUARANTINE。
2. HGK 缺失 topology 文件：**優先修復真已批准來源/Projection 指向**，不創建新的 TaskKind；若所有現役路由不存在，提出修復提案和最小 Owner-signed registry 更新，由 Native Owner 走真發行流程。`workspace_kind`、Compiler `CONTINUATION` 均不等於 Native TaskKind。
3. Model 路由：OpenAI GPT vs OpenCode DeepSeek 宣告與 primary arm 不符，**根因在 Registry 定義，不在 Assignment 投影**；不再重跑 0-change resync 企圖“修復”。只為真有效 Policy/Registry 做合法補正，再量 Required==Served/Principal。禁止無聲 fallback 或把 provider/model 名稱當證據。
4. PIPD PR19 是確定性的 **Stage-C WriteSet Guard**：兩個受拒 ADR (`ADR-0008-repository-state-and-hygiene-inventory.md`、`ADR-0009-session-handover-and-next-session-start.md`) 不在前輪 base `f4021aef...` 允許集合。先決定這些檔是否屬 PR 範圍，再由原 Repo Owner **縮減 PR 改動或簽核新 WriteSet**；不得僅為 CI 綠燈放寬 guards。它不自動阻斷現有合法 read-only Bootstrap 工作。
5. SourceFreeze `SFR-HGK-20260807-001` 的 106 項歷史來源 Manifest digest 相符，但缺本輪 Mission/Issuer/Sign/PolicyEpoch/Expiry/Revoke，不准當 B1 原生准入。優先透過**原有合法簽發路由**產生**本輪新受影**簽核工件；不回填舊 receipt 或把新的 unsigned JSON 當原生有效。
6. BreakGlass `RP002-BREAK-GLASS/1` 若只有 schema/policy 而未驗證具體端點、Principal/Scope/TTL/Approval/監看/回復，不得啟動；若真合法 Recovery Policy 路由存在，須現役發行的獨立憑證且僅一次受影操作，附撤銷與獨立驗證。

## 5. Baseline / Reuse / Do-not-redo

**已知且可由前輪 Evidence 重新證明的事實，不重做為產品測試：**

| 項目 | Resume r2 已知事實 | r3 決策 |
|---|---|---|
| R0 先前 Evidence | 8 工件 CRC/path/hash 通過；100 source pin 99 原位，1 relocation 同 SHA；Root HEAD/dirty 不變 | 重驗 SHA 和 fresh currentness，差異受影增量檢查，不把 source relocate 當 source loss |
| Readonly Compiler | `RECOVERY_READONLY` lint/activation/acceptance/compile 4/4 PASS；`PL-012` self-acceptance NEG 被拒 | 復用已編譯隔離 Prompt 的合法唯讀範圍；新 Contract revalidate，不用其 PASS 當 effect grant |
| Effectful Compiler | 103 required／101 reviewed／2 missing；`PL-003×2 + PL-004×1`，四命令 exit2 | 只修真正未綁的兩個 source families 與一個 authority conflict；不能刪 required |
| Oracle | DOC-07 canonical vs P4 `DOC-03 DOMAIN_ORACLES` legacy ABI；10/10 Maker isolated tests；proposal SHA `86ed8510...` | 只作相容候選，補 Owner Ratification 與 Checker；拒絕直接改 P4 Schema const |
| HGK TaskKind | `HGK_STACK_MANIFEST` 指向缺失 `HGK/HGK_TASK_TOPOLOGY_POLICY.yaml`；`git ls-files --error-unmatch` exit1 | 查真 Release/Tar/History/Projection Owner 與可修復引用；不能直接補一份自簽 TaskKind |
| Historical SourceFreeze | SFR-HGK-20260807-001 106 source/manifest hash一致，但欠簽章等六欄 | 只保留歷史引據，發現合法 current issuance，再以本次 Subject 產新真票據 |
| Hermes Kanban | `kanban.db` 只讀 Schema已觀測，含 tasks/task_runs/idempotency_key；非 TaskKind Registry | 繼續只讀 schema／合法 API 查詢，不改 DB 或把 workspace_kind 當 native task kind |
| R4 | 現有 resync 3次 changes=0，誤假設已被否證；PLAN/VERIFY declared GPT 但 DeepSeek primary arm | 診斷 registry／actual hosted route，不重跑無效 resync 當新工作 |
| PR19 | 失敗是 Stage-C allowed WriteSet 中拒兩個 ADR，head `3e35c1c...`；offline另過 | 先判 B1 當前是否依賴該 PR；條件成立才修 exact PR/guard 配置 |
| Native effects | R1/R2/R3/R4 live、三 GWO、G-A/G-B、外援 Revoke、Native Successor 全未執行 | 禁止任何效果 PASS 假收據；每個依真 Receiver/Journals 生成 |
| Repo state | SBL/PIPD/Fabric/HGK 的已知 HEAD 未變，Dirty/Untracked 非零 | Fresh NUL-safe status 和寫入前 ACL/Realpath/HASH，使用隔離 worktree，不覆蓋既有資料 |
| Full Product handoff | 22-node DAG candidate_only；`native_durable_workorder=null`, queue_ack=null | Native 可用後才依既有 Kind 轉正，接手整個 SBL/FHS-MSC，外援退場 |

**上一輪 reference local HEAD（需重新量測）**：

| Root | HEAD |
|---|---|
| SBL | `10d510f7b052e6139fd4eb536f970c0245002e17` |
| PIPD | `39079c02b8f2a3a3e63d3f2a2d5537805d3a3594` |
| Fabric | `bb06b7a6c17c45c777a636e9dae3196e21eb77b9` |
| HG-KSEOS | `086a9402189a2bb0ac3b198a7a9805b3dcbe38d8` |

GitHub 參考 `main`（本次查證；不是本機 active loaded）：SBL `dc5428f23d15f0ec56cbc3d25b22f5381fce8771`；Fabric `bcd91043b89b69c9d2f08309e46e31898ac87d89`；PIPD-LS-SP `e95942abcb6aa07e69304607ab8afc22a74fc67d`。三庫遠端以 `shw097-team` 既有實際 origin 為準；本機 HGK origin 尚無經核對的 Remote。三庫 `main` 非保護分支的事實不能解讀為允許直接 push 主線。

## 6. Implementation and qualification gates（立刻開始的分階段可執行次序）

### R3-0：在既有唯讀 PASS 範圍內恢復，不再回到初始盤點

1. 產 `new resume_run_id`，上一輪 `resume-20261027T004542` 連同 Raw Receipts 完全 immutable；重讀其 `B1_Resume_Checkpoint.json` 的 `Mission_State=PARTIAL_WITH_EXPLICIT_HOLDS`、`phase=R0_R1_READONLY_COMPILE_R2_CANDIDATE_R3_EFFECTFUL_HOLD`、source digest、Root HEAD/Dirty；所有差異分列 `CHANGED/UNCHANGED/UNVERIFIED`，每項附實際 probe 命令、exit、SHA。
2. 有真 `RECOVERY_READONLY` Compiler Receipt 且與 Contract SHA/Compiler SHA 一致，**直接依其合法 `thin-prompt.md` 維持 read-only/isolated 恢復**，不必在相同 source SHA 下將同一測試重跑四次；如現役輸入或 Compiler changed，只重編受影唯讀子契約。
3. 保留 ZIP 原始 member，不依名稱 `executor_scripts/` 執行，避免將工具產生的候選 Python 自動當受信任可運行程式。任何腳本先靜態審核、安全封閉範圍、hash，再在容器／隔離環境測試。
4. 明確對照 ZIP 內 `B1_Completion_Ledger.json` 原始身份：27/31/120/124/38/949/192/81 與原本所有 `NOT_RUN`，維持歷史／當前 disposition 分開，不得將 10 個 Maker tests 計入 Native parents/children。

### R3-1：PL-003 的可驗原生發行／TaskKind 路由查找（最優先）

1. 以已具體定位的 `01_native_discovery/FINAL_STATIC_AUTHORITY_FACTS.json`、`SHARED_SPINE_READONLY_SCHEMA.json`、`ROUTE_AND_AUTHORITY_SOURCE_INDEX.json`、`OWNER_DECISION_PACKET_PL003.json` 為已知起點；只在 current canonical HGK/Fabric/PIPD root 的 **已登記** artifacts、合法元資料 API、歷史 tag/bundle、主機設定與有效 Owner 路由內做有界 read-only discovery，從既有 binding 修復錯誤 locator，不要猜 Native Kind 名稱。
2. 缺 `HGK/HGK_TASK_TOPOLOGY_POLICY.yaml`，先辨別：git track 歷史有否 rename、installed release 是否另有 projection、`HGK_STACK_MANIFEST` 是否指錯真 canonical 路徑、是否只是未生成的合法機器投影；產 `TASK_KIND_PROVENANCE_GRID{reference_path,history_candidate,writer_owner,issuer,allowed_fix,currentness}`。只在真來源證據證明原址為 canonical 且合法 Authorize 時提出受影補正候選。沒有既有原生註冊機制就 `REGISTERED_KIND_UNAVAILABLE`，不硬造 `B1_RECOVERY`。
3. 檢查原有效的 Authoritative SourceFreeze/Approval Issuer 與 Signing API、簽章驗證、申請路由；`SFR-HGK-20260807-001` 只可作歷史來源，不繼承其無法證明的 Permission。重新提交上輪 `OWNER_DECISION_PACKET_PL003` 給**真實且經驗證**的 Owner/Issuer endpoint，帶現行 Source Manifest SHA 與最小 B1 repair WorkSet、TTL、revocation、no cross-effect policy；如端點需交互登入或人類簽章，僅此時提出具體一次性 HITL，不能依普通聊天自動代簽。
4. 只有當兩個 Required Families 各有 `{exact registered kind/version/owner/policy epoch,mission-bound signed source approval,signature verification,expiry,revocation,native ACK}` 並精確 bind `B1_EFFECTFUL` Current Source 時，將 `required/reviewed/missing` 由實際 locator 更新；不減少原 103 項或把 candidate 改 signer。
5. 若 Issuer 真故障且 PIPD Compiler effectful 形成循環依賴，偵測既有 `RP002-BREAK-GLASS/1` 是否含真正允許當前受影的 Owner-signed `authority_ref`, approver, reason, subject, duration, pre/post-readback, audit, revoke, restoration、且發行端點可驗；**有真合法流程才使用**。沒有就產完整 `BOOTSTRAP_RECOVERY_PATH_DECISION`與 `PL003_EVIDENCE_OWNER_HANDOFF`，標記受影效果 HOLD，繼續不依賴它的離線診斷與測試；不要直接打開 SQLite／policy file 偽造合法狀態。

### R3-2：Oracle `PL-004` 最小 Ratification/兼容閉合

1. 直接重用已建立 `ORACLE_ABI_CROSSWALK` 和 `03_candidate/oracle_namespace_candidate.py` 及 `test_oracle_namespace_candidate.py` 的10/10 maker測試（SHA `86ed85102ba36b782292de301ff99c4f4a5c848b81ecb8209cf8d3a6344d581f`）；繼續試重要 NEG，包括 legacy accept、canonical DOC07 trace、foreign subject/owner、source hash mismatch、conflicting const、trace-to-content hash、rollback。避免重新讀所有巨大文件來「重新發現」衝突。
2. 從現役 PIPD DOC-02／DOC-07／P4 Schema Owner 取得**versioned namespace Ratification**，明確 `canonical_authored_by=DOC-07`、`legacy_serialized_field=DOC-03 DOMAIN_ORACLES`、PIPD DOC03 Environment-Binding 為不同法位、例外更迭規則、受影 consumer mapping、ABI backward compat、rollback/expiry、owner signature、同版本 SHA。不能憑本聊天裁決把 PL004 刪掉。
3. 讓真獨立不同 principal 的 checker 對同 source/candidate/ABI 做至少 legacy+new canonical POS、foreign/mismatched NEG、EDGE/SEC、rollback；不能以 Maker 10/10 自驗當 Checker PASS。只有正式 Ratification及原始 Checker receipt 俱全才由原 Owner `CR_ORACLE_001_OPEN` → RESOLVED，保存歷史 TT；若仍無 Owner signing route，準備明確唯一請求，不新增第二 Oracle Writer。

### R3-3：重新跑真 Effectful Compiler，合法渲染 Child WorkOrders

1. 以 ZIP `02_contracts/B1_EFFECTFUL_CONTRACT.json` 的 103 required/101 reviewed/2 missing、27 Atoms、4 Journeys、64 acceptance edges、原分類作基礎，更新**確已簽發**的 Required Source binding 和正式 Oracle conflict disposition；`CONTINUATION` 是 Compiler ChangeSet，不是 Native `TaskKind`。
2. 依本機 `prompt_contract_compiler.py` 的 `--help` 與 schema 在獨立候選目錄重跑 `lint → activation → acceptance → compile --out-dir`，同一 Contract/Compiler SHA，記每 command exit/stdout/stderr/report SHA。須四次真 PASS 且沒有 PL003/PL004，才使用 compiler rendered 子 Prompt，必要時 duplication check；**禁止先行另 render 效果 Prompt**。
3. 之後還須逐張從現役 Policy/Issuer 取得 Binding：`root+HEAD+dirty+writeset`，單一 EffectClass，合法 PI/PD/ECP，Actor principal，subject SHA/epoch，Permit/TTL/Nonce，預/後世界證據，對應 Checker 分離。純 OBS 使用 `NO_EFFECT` 而非假 Permit。若 Compiler PASS 而 Native Permit 未生效，仍僅允許 read-only；不因 Compiler 成功便越過 Native Gate。

### R3-4：R1–R4 最小修復施工（須 R3-3 真 PASS／正式子指令）

| RepairCone | 真現役修補範圍 | POS、NEG、回復、驗收 |
|---|---|---|
| R1 Issuer | `grant_required`／Subject／Epoch／Scope／Nonce／TTL／Permit-before-spawn | wrong/expired/replay/UNKNOWN_EFFECT 無非法 Spawn；真 Issuer 及 Receiver ACK；安全的 compensation rollback |
| R2 Hermes | 真 `runner.py → advance.py` 或新量得 import hotpath；durable cursor、CAS Lease Generation、公平 B/C 前進、effect at-most-once | A blocked、B/C 不 starvation；stale Lease/dual claim deny；UNKNOWN_EFFECT 先 world-read/reconcile，不 blind retry |
| R3 Fabric | 原有 approved Stage→Activate→Loaded→Consumer、Policy Epoch/SourceSHA | 三域 raw（STAGE、LOADED、CONSUMER）及同 Subject digest；Stage-only/foreign epoch/reverse projection DENY；Rollback generation readback |
| R4 Lanes | 合法 Policy/Registry Source 補正 PLAN/EXECUTE/VERIFY_SECURITY provider/model/transport/principal；Maker/Checker 分離 | 前輪 Assignment `resync changes=0` 反證沿用；實測 Required==Served 且真 Principal；不能無聲 fallback 到 DeepSeek／GPT 別臂 |

對每個 Cone：實際最小 `write_set`、source/HEAD pin、preimage、真 Red fixture、局部候選修改、Green、NEG、EDGE、SEC、affected regression、Host effective activation、rollback、獨立 Checker。根因相同連續失敗兩輪，park 受影，不重寫整個倉庫；受影以外仍可施工。

### R3-5：G-A（六項合取）及三個 GWO（真實世界效果）

`G-A=PASS` 必須同時具備 Native Issuer Live、Hermes Queue Fair Durable、Fabric `approved==active==loaded` 真 Consumer ACK、三路 required==served+Principal、逐 WO Mandatory/Selected 方法實際調用（同 policy epoch）、不同 Principal 的獨立 Checker。每項獨立 Raw；缺任何一項 G-A HOLD。

- `GWO-FABRIC`：SBL Proposal→合法 Stage→Fabric Owner Activate→HGK Consumer effective ACK；每張受影 WO 分離 DEV/OPS，不以 Stage 當 Loaded。
- `GWO-HGK`：SBL WorkOrder 候選→HGK Native Issuer→Hermes Durable Queue/Lease CAS→受限可逆效果→獨立 Checker；A/B/C fair、重播、ghost、未知效果均有負例。
- `GWO-SBL`：Host OPS Install/Doctor/Load 與 USER effect分離；在有單獨 UserData Owner 同意、Issuer 和隔離目錄後，真 CLI 執行 `init → add --title → list --json（新進程） → remove --id <actual-id> → list --json → uninstall --yes`。`--data-dir` 在 subcommand 前；`delete` 是拒收負例（exit2），duplicate title exit3、empty title exit2、foreign files uninstall exit5；無 USER Permit=`NOFIT_USER_ISSUER_UNBOUND/HOLD`，不能以 OPS 替代。

B1 的 27/31/120/124/38 與 949（66 Required／254 Conditional／629 Deferred）、192、81 必逐一從 Original Ledger 取得自己的 ID、來源、適用性、Owner、實際 POS/NEG/EDGE/SEC、Raw、Gate 與 reentry；不要把分母保存等同 Case PASS。對 `KANBAN/SWARM/GSTACK/OPENSPEC/CODEX`，查真 signed effective method policy；必選但未真 invoke=`METHOD_REQUIRED_NOT_INVOKED`，未選也須有合法 scope 說明。192 Matrix 是身份/適用性全集，不等於要求安裝所有 Host。48+ 個 Runner 無真註冊端點則 `BLOCKED_MISSING_RUNNER`，不能憑 YAML 或測試標題假造 Runner。

### R3-6：G-B／Codex 外援撤銷／真 Native Successor

G-A + 3 Domain GWO 有效後，依外援 Principal 原生授權憑證**實際存在**之狀態撤銷（若原來未綁定，記 `NO_TEMP_NATIVE_GRANT_TO_REVOKE` 並驗證沒有外援存留，而不是偽造撤銷事件）；在新的 Process/Session／Durable Journal 上由 HGK/Hermes **自行**啟動 `WO-B1-C8` 正式原生工作，不是 Codex 新輪詢觸發。Raw 匹配 Native Issuer、Lease、Effect、Checker；已撤銷憑證必在 Spawn 前 DENY，無其它資源殘留。缺 Native Scheduler 真自啟能力則 G-B HOLD。

### R3-7：Native Full Product 交接（B1 完成後才正式）

現有 `B1_Native_Handoff_Packet/NEXT_NATIVE_MISSION_DAG.json` 已有 **22 節點候選**，含 Full SBL DOC-00～13；不要重新發明另一套規劃 DAG。原生 Gate 生效後，依現役 TaskKind 把每節點變正式 PIPD/HGK 可消費 WorkOrder，保留 Source/Owner/Dep/Effect/Oracle/Repo/Host 及 Deferred reentry；讀回真正 `native_workorder_id/native_queue_ack/durable_cursor`，啟動至少一個原生 Next Job（有合法 Permit）。所有 Full Product 未完成責任交給修好後 HGK/Hermes，**不由本次 Codex 外援自己實作**；SWOF 只做 PREW3_SHADOW W2 唯讀 ACK/NACK，無 W3 Mutation。

## 7. Failure / HITL / Repair / Resume（避免無謂停工，但不取消安全 Gate）

依 `source/authority → path/currentness → security/issuer/token → effect class/ECP → required method → execution/idempotency → readback → checker/trace → gate` 回報 first true failure。當一條 work lane 被阻：

1. 立即記 `PARKED(reason, owner, required_evidence, authorized_route, reentry_predicate, impact)`；不要將任務全域標 Done，也不要在無合法事件來源時啟動無限 polling。
2. 自動繼續**不依賴該阻擋**的其它 work lane，如 Oracle 相容負例、Root/Loaded read-only 量測、Host import 識別、遠端 exact PR readback、Runner ABI audit、Full Product Handoff 補全。獨立支線隔離並只用准入的 WorkSet，不在共享 Root 寫。
3. 真 Native Owner／Issuer/Checker 若有可驗機器 API，使用它自動提出 Decision Packet 並讀回 ACK；若 API 需要現場密鑰／外部互動批准，精確輸出**一次性必要授權**的 subject、Scope、TTL、工件 hash、發行入口、意義與無授權的安全替代（read-only）。不反覆索求普通工程裁決。
4. 有真恢復事件才自動 Resume，重綁 HEAD/policy/subject，最多兩次相同根因自動修補，之後提具名 `TT/FirstFail`；`UNKNOWN_EFFECT` 一律 reconcile-first，重播操作必須受原生 Effect Journal/At-Most-Once 限制。
5. 外援 session 不保證在使用者關閉桌面後仍能繼續；真 Durable Scheduler 成立前，只能交回本地 checkpoint。**Never claim a future unattended run that was not actually registered.**

## 8. Evidence / Independent acceptance / Candidate binding

本地 outputs 建立新的不可變 `resume-r3-<UTC>/<stage>/`；保存所有來源 path/hash/line、差異摘要、Bounded Build Order、命令與退出碼、stdout/stderr SHA、更新前後 4 Repo Dirty NUL Manifest、Candidate SHA、Compiler Receipts、Domain Raw POS/NEG/EDGE/SEC、獨立 Checker 真 Principal/公鑰驗證與 Verdict、Host Binary/Active/Loaded SHA、Rollback、GitHub 讀回、Full Product Handoff、Checkpoint。所有 Machine Receipts 應攜帶 `mission/run/subject_sha/policy_epoch/root/head/writeset/wo/operation/effect/principal/nonce_or_event_ref/raw_sha/checker_ref/claim_ceiling` 之適用欄。

對四 Repo 保護原有 Dirty/Untracked：SBL 上次 4 modified+52438 untracked，PIPD 6532 untracked，Fabric 1 modified+51 untracked，HGK 2 modified+1 untracked。**先快照，不清理、不蓋檔**；寫入需合法 Repo ECP/WriteSet，正規 branch/PR／sanitized owner投影；SBL/Fabric/PIPD 的 GitHub origin 逐個驗證；HGK origin 上次是空，不得自作主張映射到 Fabric。真 GitHub Credential 只能走本機 secure helper／OS secret store，不得出現在 transcript。真有候選修改才 create branch/PR，遠端讀 HEAD/tree/CI，CI PASS != Native Effective Load。

Independent Checker 不可由 Maker 本人、相同簽章權限或相同寫入 Principal 冒充。若指定 Principal 缺失，保留候選並讓 Owner 的現有 Checker route 依法綁定，任何未經獨立驗收的項目都只是 Candidate。

## 9. Termination / Final output

**只有**實際滿足全部適用的 B1 原生修復/測試/受影矩陣、R1～R4 Live Readback、G-A 六項、三 GWO 不同實效果、G-B 新 Session Native Successor、獨立 Checker、外援授權撤銷與合法 Native Full Product 交接，才可以輸出經有效簽章的 B1 scoped PASS。949/192/81 的所有原始身份保留、Condition/Deferred 有 source-bound disposition，但不把 629 Deferred 元件列為需立即安裝的產品功能。剩餘 Full Product 工程必留正式 Native Queue/Owner；不等於 Full Product Release。

若外部 Owner 憑證／Signature／合法 Registry 仍不能取得：本輪結果只能 `PARTIAL_WITH_EXPLICIT_HOLDS`，輸出具體阻擋、證據和最小可提交 Owner Packet；已通過唯讀 Compiler 不失效，已完成 Maker tests 不清零。禁止用 `PROMPT_COMPILE_BLOCKED` 情況下渲染 Effectful 子 Prompt，禁止自簽 Native AO；**安全完成與如實交付優於偽成功。**

最後交付給人類 OWNER（繁體中文）：
1. `phase/claim_ceiling/actual side effects/first_fail`；
2. `27/31/120/124/38/949/192/81` 各自的 PASS/FAIL/HOLD/NOT_RUN/N_A 完整分母，受影 Cond/Deferred 裁決；
3. `PL003/PL004` 是否有真 Signature/RegisteredKind/Ratification 與 Compiler PASS，附 Receipt SHA；
4. `R1-R4/G-A/GWO-FAB/HGK/SBL/G-B/Native Successor` 同 Subject/Native ID/Checker/Raw；
5. Git Root HEAD/Dirty/binary/active/loaded/remote branch/PR/CI/Source digest；
6. 受影未完成和唯一下一步 `next legal native action`、合法任務重啟指標，Rollback/Revoke 結果；
7. Full Product 交接 DAG 真是否已在 Native Queue 發行與 ACK，不得把 Candidate DAG 說成已接管。

### 附錄 A｜31 張不可遺漏的 B1 Work Slot（只作索引，執行法位以 B1 DOC-02 原文及 Native Contract 為準）

| Slot 原 ID | EffectClass | EffectKey |
|---|---|---|
| `OBS-B1-A1` | `READ_ONLY_PROBE` | `ROOT_RAW` |
| `WO-B1-A2` | `HOST_OPERATIONS` | `ISSUER_SUBJECT` |
| `WO-B1-A3` | `HOST_OPERATIONS` | `QUEUE_WO` |
| `WO-B1-A4` | `HOST_OPERATIONS` | `RECEIVER_ABI` |
| `OBS-B1-A5` | `READ_ONLY_PROBE` | `MODEL_LANES` |
| `WO-B1-A6` | `HOST_OPERATIONS` | `EFFECT_JOURNAL` |
| `OBS-B1-A7` | `READ_ONLY_PROBE` | `RAW_EVIDENCE` |
| `WO-B1-A8` | `REPOSITORY_WRITE` | `NATIVE_HOTPATH` |
| `WO-B1-A9` | `HOST_OPERATIONS` | `NATIVE_CONTINUATION` |
| `OBS-B1-B1` | `READ_ONLY_PROBE` | `SOURCE_ATOMS` |
| `OBS-B1-B2` | `READ_ONLY_PROBE` | `REPO_CONTEXT` |
| `WO-B1-B3-DEV` | `REPOSITORY_WRITE` | `SBL_TO_NATIVE__DEV` |
| `WO-B1-B3-OPS` | `HOST_OPERATIONS` | `SBL_TO_NATIVE__OPS` |
| `WO-B1-B4-DEV` | `REPOSITORY_WRITE` | `ECP_SELECTOR__DEV` |
| `WO-B1-B4-OPS` | `HOST_OPERATIONS` | `ECP_SELECTOR__OPS` |
| `WO-B1-B5-DEV` | `REPOSITORY_WRITE` | `THREE_SP__DEV` |
| `WO-B1-B5-OPS` | `HOST_OPERATIONS` | `THREE_SP__OPS` |
| `WO-B1-B6-USER` | `USER_DATA_EFFECT` | `TODO_PERSISTENCE` |
| `OBS-B1-B7` | `READ_ONLY_PROBE` | `NOFIT_ROUTE` |
| `OBS-B1-B8` | `READ_ONLY_PROBE` | `TRACE_GRAPH` |
| `OBS-B1-B9` | `READ_ONLY_PROBE` | `R15_COVERAGE` |
| `WO-B1-C1` | `HOST_OPERATIONS` | `FABRIC_PROMOTION` |
| `WO-B1-C2` | `HOST_OPERATIONS` | `HGK_GWO` |
| `WO-B1-C3-OPS` | `HOST_OPERATIONS` | `SBL_GWO__INSTALL` |
| `WO-B1-C3-USER` | `USER_DATA_EFFECT` | `SBL_GWO__USER` |
| `WO-B1-C4` | `HOST_OPERATIONS` | `EXTERNAL_GRANT` |
| `WO-B1-C5` | `REPOSITORY_WRITE` | `CODEX_MINPATCH` |
| `WO-B1-C6` | `HOST_OPERATIONS` | `REVOKE_RACE` |
| `OBS-B1-C7` | `READ_ONLY_PROBE` | `FOUR_LAYER_ID` |
| `WO-B1-C8` | `HOST_OPERATIONS` | `NATIVE_SUCCESSOR` |
| `OBS-B1-C9` | `READ_ONLY_PROBE` | `TRIPLE_GWO` |

### 附錄 B｜分母與檢測矩陣讀回（每次檢查都需原始 ID 和單獨證據）

- [ ] 27 B1 Requirement Atom，各自來源 Clause／Owner／PI Sidecar／Oracle／現在有效性。
- [ ] 31 WO/OBS（上述表格）逐卡 `NO_EFFECT` 或單一生效 ECP，DEV/OPS/USER 不混用。
- [ ] 120 Parent TQAEP（27×POS/NEG/EDGE/SEC + 3 GWO×POS/NEG/EDGE/SEC）。
- [ ] 124 Child TQAEP（31×POS/NEG/EDGE/SEC），子卡不能共享兄弟 receipt。
- [ ] 38 conformance nodes，依 B1 DOC-05 每節點做 Owner/Schema/Oracle/Runner/Checker 逐條裁決。
- [ ] 949 R15 原 IDs，66 B1_REQUIRED／254 CONDITIONAL／629 FULL_PRODUCT_DEFERRED，18 Families、16 User Moments；逐項 retained disposition 不縮分母。
- [ ] 192 Kind×Mode×Host×Provider-off cells，8×3×4×2；依現役環境及選用路由決定合法 supported/no-fit/reentry，不將尚未實作格標 PASS。
- [ ] 81 named assets＝19 native contracts +13 CLI verbs +25 METHOD +24 donor slots；真正選用才執行，用 original method invocation receipt 而不是安裝存在性。
- [ ] R1/R2/R3/R4：每個 live path 的有效 Root／HEAD／Policy／Loaded、red→green、POS/NEG/EDGE/SEC、rollback、不同 checker。
- [ ] G-A：六個 conjunct 各自 raw evidence；三個 GWO 的 operation/resource/receipt domain 身份不得重用。
- [ ] G-B：真 Revoke 或合法 No-Grant-to-Revoke 受審核結論、下一新 Session native durable workorder、queue ACK、自己觸發效果、獨立 Checker；失敗不得報 native takeover。
- [ ] GitHub：只對真 modified/admitted repo 建立受限 branch/PR，secret scan、遠端 tree/blob SHA、CI exact head；不自動 merge 主線。
- [ ] 最終 claim、Rollback、Residue、Owner TT、Full-Product Native Handoff 都與同一 candidate／policy epoch／true Host 綁定。

**立即開始執行 R3-0；復用已編譯 PASS 的唯讀恢復範圍，不等待新聊天批准。遇到真原生授權缺口只停止該效果並完成其餘合法工作；將缺少的真實簽發／人工動作濃縮成一份一次性 Owner Decision Packet。任何真 Native Gate 未閉合時不得以語言催促替代合法簽章。**
