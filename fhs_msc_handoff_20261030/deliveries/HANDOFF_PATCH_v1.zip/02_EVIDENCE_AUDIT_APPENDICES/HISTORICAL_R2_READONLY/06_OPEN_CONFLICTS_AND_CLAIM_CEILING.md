> **R2 受影更新 / CURRENT**：R2 尚未核定項：`CR-HOST-192`（DeepSeek 48 vs ChatGPT 48）、`CR-CELL-PROVIDEROFF`、`CR-69-OriginalDisposition`（Donor24+Method25，Native20 的字面分類不等於原 Owner ACK）、`CR-DOC04-STATE-MAP`、`CR-REPO-WINDOWS-CURRENTNESS`、`CR-NATIVE-RUNNER-282`、`CR-CHECKER-AND-ISSUER`。僅停受影 Native effect；合法 L0/L1 繼續。

# 06｜Open Conflicts、受影 HOLD、Claim Ceiling 與解鎖責任

**Current ClaimCeiling**：`SOURCE_BOUND_INTEGRATED_DESIGN_WITH_LOCAL_READBACK`，對已完成作者端測試可主張 `STATIC_AUTHOR_SIDE_PASS`（若實際測試通過）；任何 `HOST_LOADED/ACTUALLY_INVOKED/WORLD_READBACK/INDEPENDENT_CASE_PASS/OWNER_RATIFIED/RELEASED` 均未直接取證。

| CR | 第一失敗/缺件 | 唯一 Owner/Reader | 只受影停點 | 解鎖條件 |
|---|---|---|---|---|
| CR-DOC04-STATE-MAP | PIPD Stage T4/T5 state incompatibility | PIPD DOC-04 Owner | PI promotion/有風險生命週期 state transition | read current canonical transition table and issue Owner ACK |
| CR-ORACLE-001 | SBL DOC-03 vs DOC-07 acceptance oracle lineage | SBL Product/Assurance Owner | 真 Checker promotion | preserve both oracle refs; owner signs mapping |
| CR-N14-001 | 14 SBL DOC count or native namespace source conflict | SBL Product Writer | DOC names/qualified bundle | owner confirms canonical enumeration |
| CR-CELL-PROVIDEROFF | Legacy ON/OFF vs ProviderOff label mismatch | SBL Host/Product Owner | 192 cell affected provider transitions | Owner binds exact raw token semantics |
| CR-HOST-LOCAL-HEAD | Windows local git HEAD/index/untracked/reparse/ACL unobserved | 4 Repo Owner/Host | PD binding and RepoWrite | read local genuine RepoContext |
| CR-POLICY-LOADED | Fabric Active/Loaded/Consumer Policy SHA not observed | Fabric/HGK Host Owner | HOST_OP/REPO_WRITE admission | fetch active+loaded+consumer ACK same epoch |
| CR-LANE-RESOLVER | HGK lane_route_resolver explicitly isolated candidate | HGK Launcher Owner | W18 actual model served | original launcher bind and prove actual request/response |
| CR-HERMES-NATIVE | No fresh PID/Host ECP/Journal/real raw | HGK/Hermes Owner | B1/W18 and bounded effects | real Worker runs and world readback |
| CR-TQAEP-CHECKER | No real Registry runner/Independent Checker credential | TQAEP/Checker Owner | 282 B1+96 Oracle actual pass | real runner binding + distinct credential + same-candidate raw |
| CR-DEFAULT-LICENSE | 485 identities upstream license/Host install not fully bound | Tech/License/Host Owner | need-qualified Default activation | pin upstream/license/HostCaps then install/trigger/test |
| CR-FAR-IDENTITY | FAR external tool name upstream ambiguous | original SBL Technology Owner | FAR adoption only | bind original identity/upstream/commit/license |
| CR-USER-MANUALS | Original formal FHS-B1 manuals not provided as separate current approved sources | respective Domain Owner | manual-specific claims | provide original manual or owner equivalence ratification |

## 治理收斂的實用規則
- 去重 `QuestionLedger` 同 Subject/SourceSHA/Scope/Epoch 已有答案；不重問、也不因無 Host 讓合法資料和設計全停。
- 同樣產品 mandatory 諾言不因 Host missing 降為 optional；只影響被需求激活的能力。
- Product/DOC design may be complete while Native is pending。作者端已封裝的 MD/ZIP 不是 Issuer grant、獨立 Checker 或發行。
- 有原訂 ECP/WriteSet/Grant 的工作按原範圍採用，不以本指令冒 grant。

## 交付分項判決
- **文件讀回與原 ID 字串守恆**：機械檢驗，結果見 `04_SCHEMA_FIXTURES...`。
- **實質跨 Domain 設計**：來源及條款高保留整合；Full semantic acceptance 尚未取得原 Domain Owner 與獨立反例審查，故 `PARTIAL_WITH_AFFECTED_HOLDS`。
- **Native/Host/Release**：`NATIVE_NOT_RUN`，Release `BLOCKED`。
