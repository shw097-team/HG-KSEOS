# 01｜四 GitHub Repo 當期基準、原始碼 Reader 與 Diff 的證據界線

**讀取**：2026-10-30 GitHub 連接器唯讀 get_repo/branches/main/fetch_file/contents；`main` SHA 四庫與指令固定比較錨一致。GitHub main **不是 Windows 本機**。

| Repo | GitHub main HEAD | 對 10/30 固定比較錨 | 本地 Windows HEAD / dirty |
|---|---|---|---|
| `HG-KSEOS` | `f6dfb1e57162dc3868dc488482d249fc095eb429` | MATCH | NOT_OBSERVED |
| `SBL` | `fd62537a7ba29c3f2905fe42ddde9534674405d7` | MATCH | NOT_OBSERVED |
| `Fabric` | `316b691460638bdf38475c2c58aaad406aa6eb4f` | MATCH | NOT_OBSERVED |
| `PIPD-LS-SP` | `f6335a94157c61da75d92121d14c43feb413e981` | MATCH | NOT_OBSERVED |

## Source-backed 原相對路徑／blob 錨

| Repo | 路徑 | blob SHA | 真源邊界 |
|---|---|---|---|
| HG-KSEOS | `src/hg_kseos/providers.py` | `b3face42a4f827b7b15e4542881bf1c02d42d423` | GitHub file content/read-only；不代表 Host installed |
| HG-KSEOS | `src/hg_kseos/lane_route_resolver.py` | `7b11ddbddd39620453f18116fbb8844c20a2eeb0` | GitHub file content/read-only；不代表 Host installed |
| SBL | `sbl_harness/__init__.py` | `25ed781467d1068fc5ebdf7076c2fb8044024980` | GitHub file content/read-only；不代表 Host installed |
| SBL | `sbl_core/modes.py` | `5ae0e0da78f82971052a51b0c409f38f10753368` | GitHub file content/read-only；不代表 Host installed |
| Fabric | `FABRIC/fabric/consumers/hgk_policy_consumer.py` | `24345683f40709f9f7dad11b8d4c343a08eddcb1` | GitHub file content/read-only；不代表 Host installed |
| PIPD-LS-SP | `src/pipd_ls_sp/cli.py` | `4a2e13fbbdd77e1f775a90c4a6d105901311e7ab` | GitHub file content/read-only；不代表 Host installed |
| PIPD-LS-SP | `src/pipd_ls_sp/pipeline.py` | `75799b744e8ace9ba69efb7ab5be0570fd320ed6` | GitHub file content/read-only；不代表 Host installed |
| PIPD-LS-SP | `src/pipd_ls_sp/registry.py` | `e71043e918d7f030700c952674db39120b095d3c` | GitHub file content/read-only；不代表 Host installed |
| PIPD-LS-SP | `requirements.lock` | `56d2dd62e931ac6e351b96a38df63b6f6411c7f9` | GitHub file content/read-only；不代表 Host installed |

## 唯讀函數與具名缺口
## 四庫 2026-10-30 `main` 原始碼錨定（GitHub 唯讀）

| Repo/HEAD | 原始碼實測存在的路徑／符號 | 接線或禁止 | 本輪效力 |
|---|---|---|---|
| `Fabric` `316b691460638bdf38475c2c58aaad406aa6eb4f` | `FABRIC/fabric/consumers/hgk_policy_consumer.py` `route_event`、`load_router`；`rp002/RP002_CHANGE_CLASS_ROUTER.yaml` | `route_event` 依 change_class 選原 HERMES_NATIVE/ORACLE_TO_HGK 等 Consumer；文件不能把 `apply_preapproved` 的 raw hash 當真 HGK active grant | REMOTE_SOURCE_OBSERVED；Host Loaded 未證 |
| `HG-KSEOS` `f6dfb1e57162dc3868dc488482d249fc095eb429` | `src/hg_kseos/providers.py` `ProviderRegistry.advance` / lifecycle；`src/hg_kseos/lane_route_resolver.py` | Provider PIN/Installed/Certified/Enabled 順序，不跨級；lane resolver 檔案註記 `CANDIDATE, ISOLATED. Not wired into the launcher`，不得宣稱已 served/loaded | REMOTE_SOURCE_OBSERVED；Launcher bind HOLD |
| `SBL` `fd62537a7ba29c3f2905fe42ddde9534674405d7` | `sbl_harness/__init__.py` 的 `HARNESS_ABI`/`HGK_PIN`；`sbl_core/modes.py` `MODES`、`DISPOSITIONS` | PREW3_SHADOW=`SHADOW_NOEFFECT`，SWOF_CONNECTED=`BLOCKED_EXTERNAL`；SBL Adapter 不簽 HGK Permit | REMOTE_SOURCE_OBSERVED；Host consumer ACK HOLD |
| `PIPD-LS-SP` `f6335a94157c61da75d92121d14c43feb413e981` | `src/pipd_ls_sp/cli.py` `COMMANDS` 恰 13；`pipeline.py` deterministic；`registry.py` `SOURCE_ORDER` 恰19；`requirements.lock` | 19 Contract/13 CLI exact-set，`requirements.lock` version-pinned 但**未 hash-pinned**；不可因 lock 存在自稱供應鏈完全可再現 | REMOTE_SOURCE_OBSERVED；Windows SchemaHost HOLD |

**來源證據界線**：GitHub commit/檔案 blob SHA 不是 Windows process PID、loaded hash、Owner grant、Issuer Permit 或 Native Runner 調用；本輪沒有看到 local HEAD/index/untracked，禁止推定本機 dirty=0。所有 Repo patch 須有現役 Owner 的 exact WriteSet/DEV-ECP/受權 Scope。本版可提供 static patch 契約，不能執行真四庫修改。


**可核證的差異**：四個 GitHub HEAD 對題定 anchor 的 commit-level diff = 0（相同 SHA）；不代表未讀全部 repo tree，也不代表本地 dirty = 0。
**未達到的差異驗證**：Windows .git `HEAD/index/untracked`、所有歷史 source snapshots、binary native diff、Host loaded Policy、Model served/true request、原 PIPD CLI 真本機運行、Repo 寫授權與 protected checker 均 NOT_OBSERVED。

具名可執行原 Host 的補查路線：原 Owner 在真 Windows Repo root 唯讀 `git rev-parse HEAD`、`git status --porcelain=v1 -uno` 及另外 `git ls-files --others --exclude-standard`，原 Context Reader 再驗重解析/ACL；**禁止** clean/reset。

## 四庫 Git Trees 完整路徑樹列舉（當期非截斷）

GitHub 連接器唯讀 `GET /git/trees/main?recursive=1` 已逐 repo 取得 `truncated=false` 的原生樹 Metadata；因此此處的**路徑索引**可以稱為 GitHub main 的完整可回傳樹，**絕不能**稱 6,464 個檔案的全文語義均已審核、也不是 Windows checkout。

| Repo | tree/HEAD SHA | Entries | Files | Dirs | truncated |
|---|---|---:|---:|---:|---|
| HG-KSEOS | `f6dfb1e57162dc3868dc488482d249fc095eb429` | 82 | 72 | 10 | `false` |
| SBL | `fd62537a7ba29c3f2905fe42ddde9534674405d7` | 315 | 257 | 58 | `false` |
| Fabric | `316b691460638bdf38475c2c58aaad406aa6eb4f` | 4809 | 4175 | 634 | `false` |
| PIPD-LS-SP | `f6335a94157c61da75d92121d14c43feb413e981` | 2430 | 1960 | 470 | `false` |

共 7,636 tree entries、6,464 blobs、1,172 directory entries。實際程式內容只精讀 9 個具名關鍵原路徑；其他 6,455 blobs 的實質 ABI/函式/測例仍為 `SOURCE_CODE_NOT_FULLY_READ`，不得冒稱四庫所有程式已驗收。

此輸入由 GitHub Connector 取得的 metadata 並未匯出成每個 blob 的本地 JSON，因此 machine JSON 僅保存數量、SHA、truncated 判斷，**不是完整每檔路徑清冊**。需要逐 file 的 Source/Method Binding 時應由原 Repo Reader 再讀該受影 scope 的 `tree/blob`，不阻擋已有設計正文的交付。


## R2 四庫當期原始碼接線與變更界線（精確路徑）

- `Fabric/FABRIC/fabric/consumers/hgk_policy_consumer.py` 真 `load_router()` 對應原 Repo 的 `FABRIC/rp002/RP002_CHANGE_CLASS_ROUTER.yaml`；router blob `3fd4e63bb4a9ef8bab247f114234629ebdf15f08`，不得錯寫 root `/rp002/`。原 Windows 常量仍須 Host 確認，且 Stage Policy≠Active/Loaded/Consumed。
- `HG-KSEOS/src/hg_kseos/spine.py` blob `0c00c3785c7fe478b61ccc6caa90254963924f6d` 具有 `SharedSpine`；`lane_admission.py` blob `66e55c8fa527c759971e271e25b52acdf0b04733` 明示 CANDIDATE（HTTP200≠真正 Tool Roundtrip）；`cli.py` blob `87ac77a0459e84db796e0554459f651f6d062fac`、`harness.py` blob `4777365f47a4410bf9266d8b2584ce53aa06b2aa` 可讀但未 Host invoke。
- `SBL/sbl_core/m04_bridge.py` blob `0d9ea8f096ad79b6cfdf31767d84215165aec436` 有 `bind_repo_context/GovernedBuildBridge`；`m05_verify.py` `d098298d6ebe558ff34321c72924ae34df074055` 用生效 claim ceiling 和真 evidential statuses；`tests/test_modes.py` `07a20f8efdc07578d199531d808890ce047a2431` 存在相關 NEG，而非已對本次 Host 跑過。
- `PIPD-LS-SP/src/pipd_ls_sp/repo_context.py` blob `31e334ce8c0c309acf0250d3be0be3f76b116490` 的 RepoContext 由真 Git/FS probe 得來，拒絕使用者自述 head 充當 current；`validate.py` blob `7c3145cd002bec1f8496b257fe932c826a6c109b` 僅 deterministic validators；不能用 local schema-shape PASS 當正式 Writer ACK。
- 四庫 HEAD 仍依 2026-10-30 直接唯讀查詢：HGK `f6dfb1e57162dc3868dc488482d249fc095eb429`、SBL `fd62537a7ba29c3f2905fe42ddde9534674405d7`、Fabric `316b691460638bdf38475c2c58aaad406aa6eb4f`、PIPD `f6335a94157c61da75d92121d14c43feb413e981`。因未取得當期 Windows Worktree/Active Policy/Loaded SHA/Issuer，這不是原 Host Actual Effect。

**建議的有界 Patch WorkSet（提案，不改 Repo）**：先由各原 Repo Owner 以唯讀 `git status --porcelain=v2 -z`、`git rev-parse HEAD`、`git ls-files`、`git diff --name-status`、Host Effective Loader/Registry 取得 preimage；之後只依 actual missing edge 定 exact patch / POS / NEG / rollback。發現 dirty／untracked 絕不 reset/clean；缺原 Permit 不执行寫入。
