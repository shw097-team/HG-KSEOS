# R2 Source Currentness/High-Retention Archive

- Version `2026-10-30_r2_HIGH_RETENTION_AUDIT_PATCHED_SOURCE_BOUND`；Original Source 17 historical chunks and 14 SBL original DOCs retained both as inert fenced text in BODY and verifiable bytes in Evidence archive.
- Each CURRENT R15/Cell/Asset  ID has one effective mapping in `_machine/R2_CURRENT_SECTION_MAP.json`; old literal headings inside ~fence are **historical code**, not active Markdown headings. Downstream must parse Markdown headings, not naive substring occurrence.
- Raw archive is never an independent authoritative release. Current Domain Writers remain original SBL/PIPD/HGK/Fabric.
- 14 SBL direct original file retention equals exactly **75,630 physical source lines**, every byte pinned to mounted original files. 14 reader's multiple subrequirements are design candidates, not 7,649 independent Checker passes.
- Four remote GitHub `main` SHAs {'HG-KSEOS': 'f6dfb1e57162dc3868dc488482d249fc095eb429', 'SBL': 'fd62537a7ba29c3f2905fe42ddde9534674405d7', 'Fabric': '316b691460638bdf38475c2c58aaad406aa6eb4f', 'PIPD-LS-SP': 'f6335a94157c61da75d92121d14c43feb413e981'}; local Windows RepoContext is not observed. Presenting remote SHA as active Host receipt would fail.
- Original instruction SHA `835934a4397c9840de0d4c529f1800414f1c679ba797d61c67529060e1c5a8c7`, Audit R1 SHA `63306f728009bbd88f2af0123f9507529d77e5321cb4be14ee866fa28aaf3c7f`.
