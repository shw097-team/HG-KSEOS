## 高保留原 BODY Revision2 實質正文（沿用未受影區；遇 r2 修補採本冊前段）

---
artifact_id: FHS-MSC-R2-BODY-10B
formal_name: 27 PI到31 PD Slot的逐邊Effect/ECP/TQAEP
short_name: BODY-10B
version: 2026-10-29-r2-revision2
source_set_hash_or_pending: f86b217ae3c3ee28183570f4bf3d4f08d4d00e9b86d1de1a641a630f8682d1a1
intended_consumer: 原領域 Owner 與下游 Reader
owner_role: 作者端規格修補者；原 Domain Writer 不移轉
design_status: SOURCE_BOUND_REPAIR_CANDIDATE
claim_ceiling: AUTHOR_STATIC_ONLY; NATIVE_NOT_RUN; CHECKER_NOT_RUN; RELEASE_NOT_RUN
supersession_scope: 本輪作者候選revision2；保留前版封存；不取代任何原Canonical Writer版本
AUDIT_F_IDs:
- F-03
- F-15
---

# 27 PI到31 PD Slot的逐邊Effect/ECP/TQAEP

## R2-10B-EDGES：27 Atom→31 Slot逐邊分流

31 Slot不是27 Atom的任意填表；每邊由原PD slot具名身份及同B1原子後綴解析。OBS只SOURCE_READ，不要求fake operation nonce；DEV/OPS/USER分開送原ECP Writer，實際Native effects均NATIVE_NOT_RUN。TQAEP四類POS/NEG/EDGE/SEC回到本atom的原測例，細節在BODY-10A。

原PI 27有原5 enum/sidecar映射、獨立Input/Output/Oracle；以下edge是額外設計Reader，不塞原strict PIPD top-level shape。Schema讀回、Profile12→9、Oracle DOC07↔legacy DOC03仍需原Owner ACK，缺時只受影promotion HOLD。既有admitted WO仍按原同scope receipt resume。
### EDGE-OBS-B1-A1

- trace：PI-B1-A1 → PD-01/OBS-B1-A1；domain=ROOT_RAW；v1:L418。
- trigger/input：原子本域需求＋下方原PD slot的Input，轉原Consumer typed output，原source/owner不可改。
- ACC/POS：Same handle/file-ID inside signed root; two scans no change；本域判準：same file ID and signed root; staged/unstaged/untracked snapshot stable。
- NEG：`alias/junction traversal or changed HEAD -> ROOT_ALIAS_OR_PATH_ESCAPE`。NEG 細分碼 `ROOT_ALIAS_OR_PATH_ESCAPE` → canonical `ROOT_ALIAS_OR_PATH_ESCAPE`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- effect/ECP：原READ_ONLY_PROBE → Reader投影SOURCE_READ / NA_NO_EFFECT；同subject/scope，禁止借DEV grant做OPS。
- TQAEP：TQ-B1-A1-POS, TQ-B1-A1-NEG, TQ-B1-A1-EDGE, TQ-B1-A1-SEC；Reader=原PIPD Binder/ECP Writer→原HGK Receiver。
- first_fail：SLOT_EFFECT_OR_ORACLE_BIND_HOLD；下一合法動作：讀回本Slot原root/HEAD/Receiver/Oracle，合法讀取補binding，非空才能交原Writer。
- exit/resume：drop stale observation/re-read，無effect rollback；NATIVE_NOT_RUN。

### EDGE-WO-B1-A2

- trace：PI-B1-A2 → PD-02/WO-B1-A2；domain=ISSUER_SUBJECT；v1:L453。
- trigger/input：原子本域需求＋下方原PD slot的Input，轉原Consumer typed output，原source/owner不可改。
- ACC/POS：Token signature/principal/nonce/subject/TTL checked native-side before spawn；本域判準：issuer-signed exact subject/scope checked before spawn; nonce consumed once。
- NEG：`wrong issuer or replayed nonce -> PERMIT_SUBJECT_NONCE_REPLAY`。NEG 細分碼 `PERMIT_SUBJECT_NONCE_REPLAY` → canonical `PERMIT_SUBJECT_NONCE_REPLAY`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- effect/ECP：原HOST_OPERATIONS → Reader投影HOST_OP / OPS ECP；同subject/scope，禁止借DEV grant做OPS。
- TQAEP：TQ-B1-A2-POS, TQ-B1-A2-NEG, TQ-B1-A2-EDGE, TQ-B1-A2-SEC；Reader=原PIPD Binder/ECP Writer→原HGK Receiver。
- first_fail：SLOT_EFFECT_OR_ORACLE_BIND_HOLD；下一合法動作：讀回本Slot原root/HEAD/Receiver/Oracle，合法讀取補binding，非空才能交原Writer。
- exit/resume：原scope preimage/Host/User補償；UNKNOWN先reconcile，Scope/Epoch fresh再准入；NATIVE_NOT_RUN。

### EDGE-WO-B1-A3

- trace：PI-B1-A3 → PD-03/WO-B1-A3；domain=QUEUE_WO；v1:L496。
- trigger/input：原子本域需求＋下方原PD slot的Input，轉原Consumer typed output，原source/owner不可改。
- ACC/POS：Scan at most K blocked cards, B/C independent advance; CAS generation single holder；本域判準：blocked A parked; independent B/C progressed within bounded K; generation CAS unique。
- NEG：`duplicate claim, starved B/C or stale generation -> LOST_LEASE_OR_DUPLICATE_CLAIM`。NEG 細分碼 `LOST_LEASE_OR_DUPLICATE_CLAIM` → canonical `LOST_LEASE_OR_DUPLICATE_CLAIM`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- effect/ECP：原HOST_OPERATIONS → Reader投影HOST_OP / OPS ECP；同subject/scope，禁止借DEV grant做OPS。
- TQAEP：TQ-B1-A3-POS, TQ-B1-A3-NEG, TQ-B1-A3-EDGE, TQ-B1-A3-SEC；Reader=原PIPD Binder/ECP Writer→原HGK Receiver。
- first_fail：SLOT_EFFECT_OR_ORACLE_BIND_HOLD；下一合法動作：讀回本Slot原root/HEAD/Receiver/Oracle，合法讀取補binding，非空才能交原Writer。
- exit/resume：原scope preimage/Host/User補償；UNKNOWN先reconcile，Scope/Epoch fresh再准入；NATIVE_NOT_RUN。

### EDGE-WO-B1-A4

- trace：PI-B1-A4 → PD-04/WO-B1-A4；domain=RECEIVER_ABI；v1:L538。
- trigger/input：原子本域需求＋下方原PD slot的Input，轉原Consumer typed output，原source/owner不可改。
- ACC/POS：Ack contains issuer and host identity; mocked ACK rejected；本域判準：true receiver ACK signed for exact subject; mock ACK never qualifies。
- NEG：`mocked ACK/wrong ABI/absent native event -> RECEIVER_NOT_LIVE`。NEG 細分碼 `LIVE_RECEIVER_NOT_VERIFIED` → canonical `RECEIVER_NOT_LIVE`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- effect/ECP：原HOST_OPERATIONS → Reader投影HOST_OP / OPS ECP；同subject/scope，禁止借DEV grant做OPS。
- TQAEP：TQ-B1-A4-POS, TQ-B1-A4-NEG, TQ-B1-A4-EDGE, TQ-B1-A4-SEC；Reader=原PIPD Binder/ECP Writer→原HGK Receiver。
- first_fail：SLOT_EFFECT_OR_ORACLE_BIND_HOLD；下一合法動作：讀回本Slot原root/HEAD/Receiver/Oracle，合法讀取補binding，非空才能交原Writer。
- exit/resume：原scope preimage/Host/User補償；UNKNOWN先reconcile，Scope/Epoch fresh再准入；NATIVE_NOT_RUN。

### EDGE-OBS-B1-A5

- trace：PI-B1-A5 → PD-05/OBS-B1-A5；domain=MODEL_LANES；v1:L581。
- trigger/input：原子本域需求＋下方原PD slot的Input，轉原Consumer typed output，原source/owner不可改。
- ACC/POS：Every required lane served in exact epoch/host; one lane failure blocks Gate；本域判準：each mandatory lane actually served, same host and policy epoch。
- NEG：`silent model fallback or missing served arm -> MODEL_REQUIRED_NOT_SERVED`。NEG 細分碼 `SERVED_MODEL_MISMATCH` → canonical `MODEL_REQUIRED_NOT_SERVED`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- effect/ECP：原READ_ONLY_PROBE → Reader投影SOURCE_READ / NA_NO_EFFECT；同subject/scope，禁止借DEV grant做OPS。
- TQAEP：TQ-B1-A5-POS, TQ-B1-A5-NEG, TQ-B1-A5-EDGE, TQ-B1-A5-SEC；Reader=原PIPD Binder/ECP Writer→原HGK Receiver。
- first_fail：SLOT_EFFECT_OR_ORACLE_BIND_HOLD；下一合法動作：讀回本Slot原root/HEAD/Receiver/Oracle，合法讀取補binding，非空才能交原Writer。
- exit/resume：drop stale observation/re-read，無effect rollback；NATIVE_NOT_RUN。

### EDGE-WO-B1-A6

- trace：PI-B1-A6 → PD-06/WO-B1-A6；domain=EFFECT_JOURNAL；v1:L618。
- trigger/input：原子本域需求＋下方原PD slot的Input，轉原Consumer typed output，原source/owner不可改。
- ACC/POS：UNKNOWN_EFFECT cannot retry until world-state reconciled；本域判準：at-most-once effect; UNKNOWN_EFFECT reconciled before any next claim。
- NEG：`duplicate operation or retry-on-timeout -> UNKNOWN_EFFECT_REPLAY`。NEG 細分碼 `DUPLICATE_OR_UNKNOWN_EFFECT` → canonical `UNKNOWN_EFFECT_REPLAY`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- effect/ECP：原HOST_OPERATIONS → Reader投影HOST_OP / OPS ECP；同subject/scope，禁止借DEV grant做OPS。
- TQAEP：TQ-B1-A6-POS, TQ-B1-A6-NEG, TQ-B1-A6-EDGE, TQ-B1-A6-SEC；Reader=原PIPD Binder/ECP Writer→原HGK Receiver。
- first_fail：SLOT_EFFECT_OR_ORACLE_BIND_HOLD；下一合法動作：讀回本Slot原root/HEAD/Receiver/Oracle，合法讀取補binding，非空才能交原Writer。
- exit/resume：原scope preimage/Host/User補償；UNKNOWN先reconcile，Scope/Epoch fresh再准入；NATIVE_NOT_RUN。

### EDGE-OBS-B1-A7

- trace：PI-B1-A7 → PD-07/OBS-B1-A7；domain=RAW_EVIDENCE；v1:L660。
- trigger/input：原子本域需求＋下方原PD slot的Input，轉原Consumer typed output，原source/owner不可改。
- ACC/POS：Maker!=Checker; no self-attested checker receipt；本域判準：distinct principal checker receipt matches same candidate and non-empty RAW。
- NEG：`self-attested or mismatched witness -> RAW_OR_CHECKER_MISMATCH`。NEG 細分碼 `RAW_SUBJECT_OR_WITNESS_MISSING` → canonical `RAW_OR_CHECKER_MISMATCH`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- effect/ECP：原READ_ONLY_PROBE → Reader投影SOURCE_READ / NA_NO_EFFECT；同subject/scope，禁止借DEV grant做OPS。
- TQAEP：TQ-B1-A7-POS, TQ-B1-A7-NEG, TQ-B1-A7-EDGE, TQ-B1-A7-SEC；Reader=原PIPD Binder/ECP Writer→原HGK Receiver。
- first_fail：SLOT_EFFECT_OR_ORACLE_BIND_HOLD；下一合法動作：讀回本Slot原root/HEAD/Receiver/Oracle，合法讀取補binding，非空才能交原Writer。
- exit/resume：drop stale observation/re-read，無effect rollback；NATIVE_NOT_RUN。

### EDGE-WO-B1-A8

- trace：PI-B1-A8 → PD-08/WO-B1-A8；domain=NATIVE_HOTPATH；v1:L695。
- trigger/input：原子本域需求＋下方原PD slot的Input，轉原Consumer typed output，原source/owner不可改。
- ACC/POS：Exact current hotpath with rollback pointer and independent regression；本域判準：exact loaded callsite identified and scoped regression independent。
- NEG：`unbounded writes or missing red reproducer -> HOTPATH_UNRESOLVED`。NEG 細分碼 `UNMEASURED_REPAIR_OR_SCOPE_ESCAPE` → canonical `HOTPATH_UNRESOLVED`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- effect/ECP：原REPOSITORY_WRITE → Reader投影REPO_WRITE / DEV ECP；同subject/scope，禁止借DEV grant做OPS。
- TQAEP：TQ-B1-A8-POS, TQ-B1-A8-NEG, TQ-B1-A8-EDGE, TQ-B1-A8-SEC；Reader=原PIPD Binder/ECP Writer→原HGK Receiver。
- first_fail：SLOT_EFFECT_OR_ORACLE_BIND_HOLD；下一合法動作：讀回本Slot原root/HEAD/Receiver/Oracle，合法讀取補binding，非空才能交原Writer。
- exit/resume：原scope preimage/Host/User補償；UNKNOWN先reconcile，Scope/Epoch fresh再准入；NATIVE_NOT_RUN。

### EDGE-WO-B1-A9

- trace：PI-B1-A9 → PD-09/WO-B1-A9；domain=NATIVE_CONTINUATION；v1:L732。
- trigger/input：原子本域需求＋下方原PD slot的Input，轉原Consumer typed output，原source/owner不可改。
- ACC/POS：Resume after external token revoked, initiated by native source；本域判準：native successor advances after external revoke with new session and no external trigger。
- NEG：`external actor still triggering -> EXTERNAL_TRIGGER_STILL_REQUIRED`。NEG 細分碼 `EXTERNAL_REENTRY_OR_NONNATIVE_SUCCESSOR` → canonical `EXTERNAL_TRIGGER_STILL_REQUIRED`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- effect/ECP：原HOST_OPERATIONS → Reader投影HOST_OP / OPS ECP；同subject/scope，禁止借DEV grant做OPS。
- TQAEP：TQ-B1-A9-POS, TQ-B1-A9-NEG, TQ-B1-A9-EDGE, TQ-B1-A9-SEC；Reader=原PIPD Binder/ECP Writer→原HGK Receiver。
- first_fail：SLOT_EFFECT_OR_ORACLE_BIND_HOLD；下一合法動作：讀回本Slot原root/HEAD/Receiver/Oracle，合法讀取補binding，非空才能交原Writer。
- exit/resume：原scope preimage/Host/User補償；UNKNOWN先reconcile，Scope/Epoch fresh再准入；NATIVE_NOT_RUN。

### EDGE-OBS-B1-B1

- trace：PI-B1-B1 → PD-10/OBS-B1-B1；domain=SOURCE_ATOMS；v1:L774。
- trigger/input：原子本域需求＋下方原PD slot的Input，轉原Consumer typed output，原source/owner不可改。
- ACC/POS：Missing/ambiguous clause opens TT; no fabricated PI issuer；本域判準：one-to-one source clause/owner/oracle joins; missing clause is HOLD。
- NEG：`missing oracle or fabricated source -> PI_SOURCE_OR_ORACLE_UNBOUND`。NEG 細分碼 `UNKNOWN_ATOM_SOURCE` → canonical `PI_SOURCE_OR_ORACLE_UNBOUND`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- effect/ECP：原READ_ONLY_PROBE → Reader投影SOURCE_READ / NA_NO_EFFECT；同subject/scope，禁止借DEV grant做OPS。
- TQAEP：TQ-B1-B1-POS, TQ-B1-B1-NEG, TQ-B1-B1-EDGE, TQ-B1-B1-SEC；Reader=原PIPD Binder/ECP Writer→原HGK Receiver。
- first_fail：SLOT_EFFECT_OR_ORACLE_BIND_HOLD；下一合法動作：讀回本Slot原root/HEAD/Receiver/Oracle，合法讀取補binding，非空才能交原Writer。
- exit/resume：drop stale observation/re-read，無effect rollback；NATIVE_NOT_RUN。

### EDGE-OBS-B1-B2

- trace：PI-B1-B2 → PD-11/OBS-B1-B2；domain=REPO_CONTEXT；v1:L809。
- trigger/input：原子本域需求＋下方原PD slot的Input，轉原Consumer typed output，原source/owner不可改。
- ACC/POS：No DEV effect for observation; no PD when no writable scope；本域判準：P4 PD only with actual repo root, HEAD and affected-only allowed write scope。
- NEG：`stale/escaping context -> REPO_CONTEXT_NOT_FRESH`。NEG 細分碼 `PD_CONTEXT_STALE_OR_PATH_ESCAPE` → canonical `REPO_CONTEXT_NOT_FRESH`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- effect/ECP：原READ_ONLY_PROBE → Reader投影SOURCE_READ / NA_NO_EFFECT；同subject/scope，禁止借DEV grant做OPS。
- TQAEP：TQ-B1-B2-POS, TQ-B1-B2-NEG, TQ-B1-B2-EDGE, TQ-B1-B2-SEC；Reader=原PIPD Binder/ECP Writer→原HGK Receiver。
- first_fail：SLOT_EFFECT_OR_ORACLE_BIND_HOLD；下一合法動作：讀回本Slot原root/HEAD/Receiver/Oracle，合法讀取補binding，非空才能交原Writer。
- exit/resume：drop stale observation/re-read，無effect rollback；NATIVE_NOT_RUN。

### EDGE-WO-B1-B3-DEV

- trace：PI-B1-B3 → PD-12/WO-B1-B3-DEV；domain=SBL_TO_NATIVE；v1:L845。
- trigger/input：原子本域需求＋下方原PD slot的Input，轉原Consumer typed output，原source/owner不可改。
- ACC/POS：DEV file patch != OPS native admission; two WO, two ECP where affected；本域判準：DEV/OPS different WOs, separate source diff and real native ACK。
- NEG：`second issuer or shared receipt -> SECOND_ISSUER_OR_MIXED_EFFECT`。NEG 細分碼 `HANDOFF_ABI_OR_MOCK_ACK` → canonical `SECOND_ISSUER_OR_MIXED_EFFECT`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- effect/ECP：原REPOSITORY_WRITE → Reader投影REPO_WRITE / DEV ECP；同subject/scope，禁止借DEV grant做OPS。
- TQAEP：TQ-B1-B3-POS, TQ-B1-B3-NEG, TQ-B1-B3-EDGE, TQ-B1-B3-SEC；Reader=原PIPD Binder/ECP Writer→原HGK Receiver。
- first_fail：SLOT_EFFECT_OR_ORACLE_BIND_HOLD；下一合法動作：讀回本Slot原root/HEAD/Receiver/Oracle，合法讀取補binding，非空才能交原Writer。
- exit/resume：原scope preimage/Host/User補償；UNKNOWN先reconcile，Scope/Epoch fresh再准入；NATIVE_NOT_RUN。

### EDGE-WO-B1-B3-OPS

- trace：PI-B1-B3 → PD-13/WO-B1-B3-OPS；domain=SBL_TO_NATIVE；v1:L882。
- trigger/input：原子本域需求＋下方原PD slot的Input，轉原Consumer typed output，原source/owner不可改。
- ACC/POS：DEV file patch != OPS native admission; two WO, two ECP where affected；本域判準：DEV/OPS different WOs, separate source diff and real native ACK。
- NEG：`second issuer or shared receipt -> SECOND_ISSUER_OR_MIXED_EFFECT`。NEG 細分碼 `HANDOFF_ABI_OR_MOCK_ACK` → canonical `SECOND_ISSUER_OR_MIXED_EFFECT`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- effect/ECP：原HOST_OPERATIONS → Reader投影HOST_OP / OPS ECP；同subject/scope，禁止借DEV grant做OPS。
- TQAEP：TQ-B1-B3-POS, TQ-B1-B3-NEG, TQ-B1-B3-EDGE, TQ-B1-B3-SEC；Reader=原PIPD Binder/ECP Writer→原HGK Receiver。
- first_fail：SLOT_EFFECT_OR_ORACLE_BIND_HOLD；下一合法動作：讀回本Slot原root/HEAD/Receiver/Oracle，合法讀取補binding，非空才能交原Writer。
- exit/resume：原scope preimage/Host/User補償；UNKNOWN先reconcile，Scope/Epoch fresh再准入；NATIVE_NOT_RUN。

### EDGE-WO-B1-B4-DEV

- trace：PI-B1-B4 → PD-14/WO-B1-B4-DEV；domain=ECP_SELECTOR；v1:L924。
- trigger/input：原子本域需求＋下方原PD slot的Input，轉原Consumer typed output，原source/owner不可改。
- ACC/POS：Ambiguous/multiple ECP gets NACK before dispatch；本域判準：one active ECP per WO; split iff distinct effects。
- NEG：`two active ECPs/unknown class -> ECP_MULTIPLE_OR_CLASS_UNKNOWN`。NEG 細分碼 `ECP_DOUBLE_ACTIVE_OR_CLASS_MISMATCH` → canonical `ECP_MULTIPLE_OR_CLASS_UNKNOWN`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- effect/ECP：原REPOSITORY_WRITE → Reader投影REPO_WRITE / DEV ECP；同subject/scope，禁止借DEV grant做OPS。
- TQAEP：TQ-B1-B4-POS, TQ-B1-B4-NEG, TQ-B1-B4-EDGE, TQ-B1-B4-SEC；Reader=原PIPD Binder/ECP Writer→原HGK Receiver。
- first_fail：SLOT_EFFECT_OR_ORACLE_BIND_HOLD；下一合法動作：讀回本Slot原root/HEAD/Receiver/Oracle，合法讀取補binding，非空才能交原Writer。
- exit/resume：原scope preimage/Host/User補償；UNKNOWN先reconcile，Scope/Epoch fresh再准入；NATIVE_NOT_RUN。

### EDGE-WO-B1-B4-OPS

- trace：PI-B1-B4 → PD-15/WO-B1-B4-OPS；domain=ECP_SELECTOR；v1:L961。
- trigger/input：原子本域需求＋下方原PD slot的Input，轉原Consumer typed output，原source/owner不可改。
- ACC/POS：Ambiguous/multiple ECP gets NACK before dispatch；本域判準：one active ECP per WO; split iff distinct effects。
- NEG：`two active ECPs/unknown class -> ECP_MULTIPLE_OR_CLASS_UNKNOWN`。NEG 細分碼 `ECP_DOUBLE_ACTIVE_OR_CLASS_MISMATCH` → canonical `ECP_MULTIPLE_OR_CLASS_UNKNOWN`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- effect/ECP：原HOST_OPERATIONS → Reader投影HOST_OP / OPS ECP；同subject/scope，禁止借DEV grant做OPS。
- TQAEP：TQ-B1-B4-POS, TQ-B1-B4-NEG, TQ-B1-B4-EDGE, TQ-B1-B4-SEC；Reader=原PIPD Binder/ECP Writer→原HGK Receiver。
- first_fail：SLOT_EFFECT_OR_ORACLE_BIND_HOLD；下一合法動作：讀回本Slot原root/HEAD/Receiver/Oracle，合法讀取補binding，非空才能交原Writer。
- exit/resume：原scope preimage/Host/User補償；UNKNOWN先reconcile，Scope/Epoch fresh再准入；NATIVE_NOT_RUN。

### EDGE-WO-B1-B5-DEV

- trace：PI-B1-B5 → PD-16/WO-B1-B5-DEV；domain=THREE_SP；v1:L1002。
- trigger/input：原子本域需求＋下方原PD slot的Input，轉原Consumer typed output，原source/owner不可改。
- ACC/POS：Three separate true host-issued identities; ZIP-only denied；本域判準：three host identities and isolated permission readbacks; ZIP-only not pass。
- NEG：`missing host invocation -> SP_HOST_LOAD_UNPROVEN`。NEG 細分碼 `SP_ROLE_OR_HOST_NOT_ACTUALLY_LOADED` → canonical `SP_HOST_LOAD_UNPROVEN`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- effect/ECP：原REPOSITORY_WRITE → Reader投影REPO_WRITE / DEV ECP；同subject/scope，禁止借DEV grant做OPS。
- TQAEP：TQ-B1-B5-POS, TQ-B1-B5-NEG, TQ-B1-B5-EDGE, TQ-B1-B5-SEC；Reader=原PIPD Binder/ECP Writer→原HGK Receiver。
- first_fail：SLOT_EFFECT_OR_ORACLE_BIND_HOLD；下一合法動作：讀回本Slot原root/HEAD/Receiver/Oracle，合法讀取補binding，非空才能交原Writer。
- exit/resume：原scope preimage/Host/User補償；UNKNOWN先reconcile，Scope/Epoch fresh再准入；NATIVE_NOT_RUN。

### EDGE-WO-B1-B5-OPS

- trace：PI-B1-B5 → PD-17/WO-B1-B5-OPS；domain=THREE_SP；v1:L1039。
- trigger/input：原子本域需求＋下方原PD slot的Input，轉原Consumer typed output，原source/owner不可改。
- ACC/POS：Three separate true host-issued identities; ZIP-only denied；本域判準：three host identities and isolated permission readbacks; ZIP-only not pass。
- NEG：`missing host invocation -> SP_HOST_LOAD_UNPROVEN`。NEG 細分碼 `SP_ROLE_OR_HOST_NOT_ACTUALLY_LOADED` → canonical `SP_HOST_LOAD_UNPROVEN`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- effect/ECP：原HOST_OPERATIONS → Reader投影HOST_OP / OPS ECP；同subject/scope，禁止借DEV grant做OPS。
- TQAEP：TQ-B1-B5-POS, TQ-B1-B5-NEG, TQ-B1-B5-EDGE, TQ-B1-B5-SEC；Reader=原PIPD Binder/ECP Writer→原HGK Receiver。
- first_fail：SLOT_EFFECT_OR_ORACLE_BIND_HOLD；下一合法動作：讀回本Slot原root/HEAD/Receiver/Oracle，合法讀取補binding，非空才能交原Writer。
- exit/resume：原scope preimage/Host/User補償；UNKNOWN先reconcile，Scope/Epoch fresh再准入；NATIVE_NOT_RUN。

### EDGE-WO-B1-B6-USER

- trace：PI-B1-B6 → PD-18/WO-B1-B6-USER；domain=TODO_PERSISTENCE；v1:L1081。
- trigger/input：原子本域需求＋下方原PD slot的Input，轉原Consumer typed output，原source/owner不可改。
- ACC/POS：User data add/delete not DEV; rollback state + uninstall exact sandbox；本域判準：isolated store add -> separate list -> delete -> zero residue。
- NEG：`user effect misclassified or no actual state -> CLI_EFFECT_MISCLASSIFIED`。NEG 細分碼 `USER_TASK_EXECUTION_NOT_OBSERVED` → canonical `CLI_EFFECT_MISCLASSIFIED`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- effect/ECP：原USER_DATA_EFFECT → Reader投影USER_OP / USER OPS ECP；同subject/scope，禁止借DEV grant做OPS。
- TQAEP：TQ-B1-B6-POS, TQ-B1-B6-NEG, TQ-B1-B6-EDGE, TQ-B1-B6-SEC；Reader=原PIPD Binder/ECP Writer→原HGK Receiver。
- first_fail：SLOT_EFFECT_OR_ORACLE_BIND_HOLD；下一合法動作：讀回本Slot原root/HEAD/Receiver/Oracle，合法讀取補binding，非空才能交原Writer。
- exit/resume：原scope preimage/Host/User補償；UNKNOWN先reconcile，Scope/Epoch fresh再准入；NATIVE_NOT_RUN。

### EDGE-OBS-B1-B7

- trace：PI-B1-B7 → PD-19/OBS-B1-B7；domain=NOFIT_ROUTE；v1:L1118。
- trigger/input：原子本域需求＋下方原PD slot的Input，轉原Consumer typed output，原source/owner不可改。
- ACC/POS：Provider-off never silent swap or third-party issue；本域判準：deterministic capability NOFIT with user-readable reason and zero unauthorized delta。
- NEG：`silent fallback -> NOFIT_OR_PROVIDER_OFF`。NEG 細分碼 `GUARDRAIL_BYPASS_OR_NOFIT_INCOMPLETE` → canonical `NOFIT_OR_PROVIDER_OFF`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- effect/ECP：原READ_ONLY_PROBE → Reader投影SOURCE_READ / NA_NO_EFFECT；同subject/scope，禁止借DEV grant做OPS。
- TQAEP：TQ-B1-B7-POS, TQ-B1-B7-NEG, TQ-B1-B7-EDGE, TQ-B1-B7-SEC；Reader=原PIPD Binder/ECP Writer→原HGK Receiver。
- first_fail：SLOT_EFFECT_OR_ORACLE_BIND_HOLD；下一合法動作：讀回本Slot原root/HEAD/Receiver/Oracle，合法讀取補binding，非空才能交原Writer。
- exit/resume：drop stale observation/re-read，無effect rollback；NATIVE_NOT_RUN。

### EDGE-OBS-B1-B8

- trace：PI-B1-B8 → PD-20/OBS-B1-B8；domain=TRACE_GRAPH；v1:L1154。
- trigger/input：原子本域需求＋下方原PD slot的Input，轉原Consumer typed output，原source/owner不可改。
- ACC/POS：Any orphan/alias/hash-mismatch yields TRACE_CLOSURE_FAIL；本域判準：nonempty exact IDs and hashes, zero orphans and zero bad edges。
- NEG：`foreign/sibling witness -> TRACE_CLOSURE_FAIL`。NEG 細分碼 `SUBJECT_HASH_BREAK_OR_ORPHAN` → canonical `TRACE_CLOSURE_FAIL`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- effect/ECP：原READ_ONLY_PROBE → Reader投影SOURCE_READ / NA_NO_EFFECT；同subject/scope，禁止借DEV grant做OPS。
- TQAEP：TQ-B1-B8-POS, TQ-B1-B8-NEG, TQ-B1-B8-EDGE, TQ-B1-B8-SEC；Reader=原PIPD Binder/ECP Writer→原HGK Receiver。
- first_fail：SLOT_EFFECT_OR_ORACLE_BIND_HOLD；下一合法動作：讀回本Slot原root/HEAD/Receiver/Oracle，合法讀取補binding，非空才能交原Writer。
- exit/resume：drop stale observation/re-read，無effect rollback；NATIVE_NOT_RUN。

### EDGE-OBS-B1-B9

- trace：PI-B1-B9 → PD-21/OBS-B1-B9；domain=R15_COVERAGE；v1:L1193。
- trigger/input：原子本域需求＋下方原PD slot的Input，轉原Consumer typed output，原source/owner不可改。
- ACC/POS：No silent ID drops; deferred != verified; no orphan family；本域判準：949 unique 18-family IDs, 66/254/629 and source-specific disposition。
- NEG：`missing ID or generic proxy pass -> R15_DENOMINATOR_SHRINK`。NEG 細分碼 `FULL_PRODUCT_PROXY_PASS` → canonical `R15_DENOMINATOR_SHRINK`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- effect/ECP：原READ_ONLY_PROBE → Reader投影SOURCE_READ / NA_NO_EFFECT；同subject/scope，禁止借DEV grant做OPS。
- TQAEP：TQ-B1-B9-POS, TQ-B1-B9-NEG, TQ-B1-B9-EDGE, TQ-B1-B9-SEC；Reader=原PIPD Binder/ECP Writer→原HGK Receiver。
- first_fail：SLOT_EFFECT_OR_ORACLE_BIND_HOLD；下一合法動作：讀回本Slot原root/HEAD/Receiver/Oracle，合法讀取補binding，非空才能交原Writer。
- exit/resume：drop stale observation/re-read，無effect rollback；NATIVE_NOT_RUN。

### EDGE-WO-B1-C1

- trace：PI-B1-C1 → PD-22/WO-B1-C1；domain=FABRIC_PROMOTION；v1:L1229。
- trigger/input：原子本域需求＋下方原PD slot的Input，轉原Consumer typed output，原source/owner不可改。
- ACC/POS：Stage/CI only never equals loaded; per-effect token；本域判準：independent stage approval; active and loaded exact digest; consumer projection ACK。
- NEG：`stage mistaken as active or missing consumer -> FABRIC_LOADED_ABSENT`。NEG 細分碼 `FABRIC_REVERSE_PROJECTION_OR_POLICY_EPOCH` → canonical `FABRIC_LOADED_ABSENT`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- effect/ECP：原HOST_OPERATIONS → Reader投影HOST_OP / OPS ECP；同subject/scope，禁止借DEV grant做OPS。
- TQAEP：TQ-B1-C1-POS, TQ-B1-C1-NEG, TQ-B1-C1-EDGE, TQ-B1-C1-SEC；Reader=原PIPD Binder/ECP Writer→原HGK Receiver。
- first_fail：SLOT_EFFECT_OR_ORACLE_BIND_HOLD；下一合法動作：讀回本Slot原root/HEAD/Receiver/Oracle，合法讀取補binding，非空才能交原Writer。
- exit/resume：原scope preimage/Host/User補償；UNKNOWN先reconcile，Scope/Epoch fresh再准入；NATIVE_NOT_RUN。

### EDGE-WO-B1-C2

- trace：PI-B1-C2 → PD-23/WO-B1-C2；domain=HGK_GWO；v1:L1271。
- trigger/input：原子本域需求＋下方原PD slot的Input，轉原Consumer typed output，原source/owner不可改。
- ACC/POS：Canary native same WO signature; fake mock ignored；本域判準：true SBL entry -> native HGK issuer -> Hermes lease -> reversible observable result。
- NEG：`ghost worker/forged permit -> GWO_HGK_NOT_NATIVE`。NEG 細分碼 `HGK_FORGED_PERMIT_OR_GHOST_WORKER` → canonical `GWO_HGK_NOT_NATIVE`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- effect/ECP：原HOST_OPERATIONS → Reader投影HOST_OP / OPS ECP；同subject/scope，禁止借DEV grant做OPS。
- TQAEP：TQ-B1-C2-POS, TQ-B1-C2-NEG, TQ-B1-C2-EDGE, TQ-B1-C2-SEC；Reader=原PIPD Binder/ECP Writer→原HGK Receiver。
- first_fail：SLOT_EFFECT_OR_ORACLE_BIND_HOLD；下一合法動作：讀回本Slot原root/HEAD/Receiver/Oracle，合法讀取補binding，非空才能交原Writer。
- exit/resume：原scope preimage/Host/User補償；UNKNOWN先reconcile，Scope/Epoch fresh再准入；NATIVE_NOT_RUN。

### EDGE-WO-B1-C3-OPS

- trace：PI-B1-C3 → PD-24/WO-B1-C3-OPS；domain=SBL_GWO；v1:L1314。
- trigger/input：原子本域需求＋下方原PD slot的Input，轉原Consumer typed output，原source/owner不可改。
- ACC/POS：CLI add/delete and install/uninstall are effects; exact data restored；本域判準：separate Host install and USER effects with independent readbacks。
- NEG：`install count used as add success -> GWO_SBL_USER_STATE_UNPROVEN`。NEG 細分碼 `SBL_EMPTY_TEST_OR_NO_USER_OUTCOME` → canonical `GWO_SBL_USER_STATE_UNPROVEN`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- effect/ECP：原HOST_OPERATIONS → Reader投影HOST_OP / OPS ECP；同subject/scope，禁止借DEV grant做OPS。
- TQAEP：TQ-B1-C3-POS, TQ-B1-C3-NEG, TQ-B1-C3-EDGE, TQ-B1-C3-SEC；Reader=原PIPD Binder/ECP Writer→原HGK Receiver。
- first_fail：SLOT_EFFECT_OR_ORACLE_BIND_HOLD；下一合法動作：讀回本Slot原root/HEAD/Receiver/Oracle，合法讀取補binding，非空才能交原Writer。
- exit/resume：原scope preimage/Host/User補償；UNKNOWN先reconcile，Scope/Epoch fresh再准入；NATIVE_NOT_RUN。

### EDGE-WO-B1-C3-USER

- trace：PI-B1-C3 → PD-25/WO-B1-C3-USER；domain=SBL_GWO；v1:L1358。
- trigger/input：原子本域需求＋下方原PD slot的Input，轉原Consumer typed output，原source/owner不可改。
- ACC/POS：CLI add/delete and install/uninstall are effects; exact data restored；本域判準：separate Host install and USER effects with independent readbacks。
- NEG：`install count used as add success -> GWO_SBL_USER_STATE_UNPROVEN`。NEG 細分碼 `SBL_EMPTY_TEST_OR_NO_USER_OUTCOME` → canonical `GWO_SBL_USER_STATE_UNPROVEN`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- effect/ECP：原USER_DATA_EFFECT → Reader投影USER_OP / USER OPS ECP；同subject/scope，禁止借DEV grant做OPS。
- TQAEP：TQ-B1-C3-POS, TQ-B1-C3-NEG, TQ-B1-C3-EDGE, TQ-B1-C3-SEC；Reader=原PIPD Binder/ECP Writer→原HGK Receiver。
- first_fail：SLOT_EFFECT_OR_ORACLE_BIND_HOLD；下一合法動作：讀回本Slot原root/HEAD/Receiver/Oracle，合法讀取補binding，非空才能交原Writer。
- exit/resume：原scope preimage/Host/User補償；UNKNOWN先reconcile，Scope/Epoch fresh再准入；NATIVE_NOT_RUN。

### EDGE-WO-B1-C4

- trace：PI-B1-C4 → PD-26/WO-B1-C4；domain=EXTERNAL_GRANT；v1:L1395。
- trigger/input：原子本域需求＋下方原PD slot的Input，轉原Consumer typed output，原source/owner不可改。
- ACC/POS：No broader GitHub/Windows authority via standing mission；本域判準：bounded external grant and no residual capability on revoke。
- NEG：`scope expansion -> EXTERNAL_SCOPE_ESCAPED`。NEG 細分碼 `EXTERNAL_GRANT_SCOPE_OR_TTL` → canonical `EXTERNAL_SCOPE_ESCAPED`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- effect/ECP：原HOST_OPERATIONS → Reader投影HOST_OP / OPS ECP；同subject/scope，禁止借DEV grant做OPS。
- TQAEP：TQ-B1-C4-POS, TQ-B1-C4-NEG, TQ-B1-C4-EDGE, TQ-B1-C4-SEC；Reader=原PIPD Binder/ECP Writer→原HGK Receiver。
- first_fail：SLOT_EFFECT_OR_ORACLE_BIND_HOLD；下一合法動作：讀回本Slot原root/HEAD/Receiver/Oracle，合法讀取補binding，非空才能交原Writer。
- exit/resume：原scope preimage/Host/User補償；UNKNOWN先reconcile，Scope/Epoch fresh再准入；NATIVE_NOT_RUN。

### EDGE-WO-B1-C5

- trace：PI-B1-C5 → PD-27/WO-B1-C5；domain=CODEX_MINPATCH；v1:L1437。
- trigger/input：原子本域需求＋下方原PD slot的Input，轉原Consumer typed output，原source/owner不可改。
- ACC/POS：No edit outside allowlist; narrow rollback；本域判準：only affected files changed and full regression independent。
- NEG：`checker edits same diff or no red test -> UNBOUNDED_PATCH_OR_REGRESSION`。NEG 細分碼 `CODEX_UNMEASURED_PATCH_OR_CHECKER_MUTATION` → canonical `UNBOUNDED_PATCH_OR_REGRESSION`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- effect/ECP：原REPOSITORY_WRITE → Reader投影REPO_WRITE / DEV ECP；同subject/scope，禁止借DEV grant做OPS。
- TQAEP：TQ-B1-C5-POS, TQ-B1-C5-NEG, TQ-B1-C5-EDGE, TQ-B1-C5-SEC；Reader=原PIPD Binder/ECP Writer→原HGK Receiver。
- first_fail：SLOT_EFFECT_OR_ORACLE_BIND_HOLD；下一合法動作：讀回本Slot原root/HEAD/Receiver/Oracle，合法讀取補binding，非空才能交原Writer。
- exit/resume：原scope preimage/Host/User補償；UNKNOWN先reconcile，Scope/Epoch fresh再准入；NATIVE_NOT_RUN。

### EDGE-WO-B1-C6

- trace：PI-B1-C6 → PD-28/WO-B1-C6；domain=REVOKE_RACE；v1:L1474。
- trigger/input：原子本域需求＋下方原PD slot的Input，轉原Consumer typed output，原source/owner不可改。
- ACC/POS：Unknown effect not erased, previously admitted in-flight reconciled；本域判準：post-revoke use fails before spawn; existing effects reconciled。
- NEG：`reused token after revoke -> REVOKED_TOKEN_REPLAY`。NEG 細分碼 `POST_REVOKE_TOKEN_REPLAY` → canonical `REVOKED_TOKEN_REPLAY`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- effect/ECP：原HOST_OPERATIONS → Reader投影HOST_OP / OPS ECP；同subject/scope，禁止借DEV grant做OPS。
- TQAEP：TQ-B1-C6-POS, TQ-B1-C6-NEG, TQ-B1-C6-EDGE, TQ-B1-C6-SEC；Reader=原PIPD Binder/ECP Writer→原HGK Receiver。
- first_fail：SLOT_EFFECT_OR_ORACLE_BIND_HOLD；下一合法動作：讀回本Slot原root/HEAD/Receiver/Oracle，合法讀取補binding，非空才能交原Writer。
- exit/resume：原scope preimage/Host/User補償；UNKNOWN先reconcile，Scope/Epoch fresh再准入；NATIVE_NOT_RUN。

### EDGE-OBS-B1-C7

- trace：PI-B1-C7 → PD-29/OBS-B1-C7；domain=FOUR_LAYER_ID；v1:L1515。
- trigger/input：原子本域需求＋下方原PD slot的Input，轉原Consumer typed output，原source/owner不可改。
- ACC/POS：No source hash used as proof of loaded binary；本域判準：all four identity layers tied to same subject, not merely file on disk。
- NEG：`green patch with stale loaded binary -> LOADED_BINARY_MISMATCH`。NEG 細分碼 `PATCH_GREEN_NOT_LOADED` → canonical `LOADED_BINARY_MISMATCH`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- effect/ECP：原READ_ONLY_PROBE → Reader投影SOURCE_READ / NA_NO_EFFECT；同subject/scope，禁止借DEV grant做OPS。
- TQAEP：TQ-B1-C7-POS, TQ-B1-C7-NEG, TQ-B1-C7-EDGE, TQ-B1-C7-SEC；Reader=原PIPD Binder/ECP Writer→原HGK Receiver。
- first_fail：SLOT_EFFECT_OR_ORACLE_BIND_HOLD；下一合法動作：讀回本Slot原root/HEAD/Receiver/Oracle，合法讀取補binding，非空才能交原Writer。
- exit/resume：drop stale observation/re-read，無effect rollback；NATIVE_NOT_RUN。

### EDGE-WO-B1-C8

- trace：PI-B1-C8 → PD-30/WO-B1-C8；domain=NATIVE_SUCCESSOR；v1:L1550。
- trigger/input：原子本域需求＋下方原PD slot的Input，轉原Consumer typed output，原source/owner不可改。
- ACC/POS：Post-turn continuation must originate in Hermes native source；本域判準：fresh separate session native trigger progresses after external account revoked。
- NEG：`successor still external-triggered -> NATIVE_SUCCESSOR_NOT_PROVEN`。NEG 細分碼 `NATIVE_SUCCESSOR_NOT_AUTONOMOUS` → canonical `NATIVE_SUCCESSOR_NOT_PROVEN`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- effect/ECP：原HOST_OPERATIONS → Reader投影HOST_OP / OPS ECP；同subject/scope，禁止借DEV grant做OPS。
- TQAEP：TQ-B1-C8-POS, TQ-B1-C8-NEG, TQ-B1-C8-EDGE, TQ-B1-C8-SEC；Reader=原PIPD Binder/ECP Writer→原HGK Receiver。
- first_fail：SLOT_EFFECT_OR_ORACLE_BIND_HOLD；下一合法動作：讀回本Slot原root/HEAD/Receiver/Oracle，合法讀取補binding，非空才能交原Writer。
- exit/resume：原scope preimage/Host/User補償；UNKNOWN先reconcile，Scope/Epoch fresh再准入；NATIVE_NOT_RUN。

### EDGE-OBS-B1-C9

- trace：PI-B1-C9 → PD-31/OBS-B1-C9；domain=TRIPLE_GWO；v1:L1592。
- trigger/input：原子本域需求＋下方原PD slot的Input，轉原Consumer typed output，原source/owner不可改。
- ACC/POS：Swapped receipts, same principal, absent third yields FAIL；本域判準：3 different domain receipts, all same intended crosswalk, not aliases。
- NEG：`same receipt reused -> GWO_RECEIPT_ALIAS`。NEG 細分碼 `THREE_GWO_PROXY_PASS` → canonical `GWO_RECEIPT_ALIAS`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- effect/ECP：原READ_ONLY_PROBE → Reader投影SOURCE_READ / NA_NO_EFFECT；同subject/scope，禁止借DEV grant做OPS。
- TQAEP：TQ-B1-C9-POS, TQ-B1-C9-NEG, TQ-B1-C9-EDGE, TQ-B1-C9-SEC；Reader=原PIPD Binder/ECP Writer→原HGK Receiver。
- first_fail：SLOT_EFFECT_OR_ORACLE_BIND_HOLD；下一合法動作：讀回本Slot原root/HEAD/Receiver/Oracle，合法讀取補binding，非空才能交原Writer。
- exit/resume：drop stale observation/re-read，無effect rollback；NATIVE_NOT_RUN。

## 27 Atom反向讀回

| Atom | 對應SlotIDs | ECP分流 | 本域Consumer/Oracle |
|---|---|---|---|
| PI-B1-A1 | ['OBS-B1-A1'] | ['NA_NO_EFFECT'] | ROOT_RAW |
| PI-B1-A2 | ['WO-B1-A2'] | ['OPS ECP'] | ISSUER_SUBJECT |
| PI-B1-A3 | ['WO-B1-A3'] | ['OPS ECP'] | QUEUE_WO |
| PI-B1-A4 | ['WO-B1-A4'] | ['OPS ECP'] | RECEIVER_ABI |
| PI-B1-A5 | ['OBS-B1-A5'] | ['NA_NO_EFFECT'] | MODEL_LANES |
| PI-B1-A6 | ['WO-B1-A6'] | ['OPS ECP'] | EFFECT_JOURNAL |
| PI-B1-A7 | ['OBS-B1-A7'] | ['NA_NO_EFFECT'] | RAW_EVIDENCE |
| PI-B1-A8 | ['WO-B1-A8'] | ['DEV ECP'] | NATIVE_HOTPATH |
| PI-B1-A9 | ['WO-B1-A9'] | ['OPS ECP'] | NATIVE_CONTINUATION |
| PI-B1-B1 | ['OBS-B1-B1'] | ['NA_NO_EFFECT'] | SOURCE_ATOMS |
| PI-B1-B2 | ['OBS-B1-B2'] | ['NA_NO_EFFECT'] | REPO_CONTEXT |
| PI-B1-B3 | ['WO-B1-B3-DEV', 'WO-B1-B3-OPS'] | ['DEV ECP', 'OPS ECP'] | SBL_TO_NATIVE |
| PI-B1-B4 | ['WO-B1-B4-DEV', 'WO-B1-B4-OPS'] | ['DEV ECP', 'OPS ECP'] | ECP_SELECTOR |
| PI-B1-B5 | ['WO-B1-B5-DEV', 'WO-B1-B5-OPS'] | ['DEV ECP', 'OPS ECP'] | THREE_SP |
| PI-B1-B6 | ['WO-B1-B6-USER'] | ['USER OPS ECP'] | TODO_PERSISTENCE |
| PI-B1-B7 | ['OBS-B1-B7'] | ['NA_NO_EFFECT'] | NOFIT_ROUTE |
| PI-B1-B8 | ['OBS-B1-B8'] | ['NA_NO_EFFECT'] | TRACE_GRAPH |
| PI-B1-B9 | ['OBS-B1-B9'] | ['NA_NO_EFFECT'] | R15_COVERAGE |
| PI-B1-C1 | ['WO-B1-C1'] | ['OPS ECP'] | FABRIC_PROMOTION |
| PI-B1-C2 | ['WO-B1-C2'] | ['OPS ECP'] | HGK_GWO |
| PI-B1-C3 | ['WO-B1-C3-OPS', 'WO-B1-C3-USER'] | ['OPS ECP', 'USER OPS ECP'] | SBL_GWO |
| PI-B1-C4 | ['WO-B1-C4'] | ['OPS ECP'] | EXTERNAL_GRANT |
| PI-B1-C5 | ['WO-B1-C5'] | ['DEV ECP'] | CODEX_MINPATCH |
| PI-B1-C6 | ['WO-B1-C6'] | ['OPS ECP'] | REVOKE_RACE |
| PI-B1-C7 | ['OBS-B1-C7'] | ['NA_NO_EFFECT'] | FOUR_LAYER_ID |
| PI-B1-C8 | ['WO-B1-C8'] | ['OPS ECP'] | NATIVE_SUCCESSOR |
| PI-B1-C9 | ['OBS-B1-C9'] | ['NA_NO_EFFECT'] | TRIPLE_GWO |

## 保留原27 PI、31 PD、DEV/OPS細節（原形狀與具體域Oracle）


# B1 27 PI 原子與 31 PD Work/Observation Slot 逐項實質正文

本卷是保留原生來源逐條正文的 **設計 Reader**：每條來源規範都需在該 Subject 的真 Host/Registry 綁定後才可能產生正式 effect 或驗收。沒有當期 Raw/Signer/Checker 就只能宣 `DESIGN_SPECIFIED/NOT_EXECUTED`，不得借其他 Case 的歷史 PASS。

## 跨 PI/PD/WorkOrder 原子級綁定

先由 PIPD 原生 Writer 讀 Source/Authority/Profile，再把 PI 27 原子 individual trace 晚綁 31 個各自 `OBS-B1` 或 `WO-B1` 的 EffectClass；後續 L3 必有真 DEV/OPS ECP、HGK Issuer/Receiver、Same Candidate/Scope/Epoch、Raw and protected Checker。READ_ONLY_PROBE 無 effect Permit 但需要合法 Read Scope。不能用任意 31 槽填滿 27 atom 的獨立驗收。

## B1 DOC01：27 PI 原子完整來源正文

# DOC-B1-PI｜27 Requirement Atoms／P4 Native Compiler 及五軸 Sidecar

<a id="repair-source-abi"></a>
## 本候選修訂：Source／Oracle／Profile 明確分層（RCA-01/02/12/34/46）

依 DOC-00 `repair-control` 分 C0 現存 Source、C2 authority conflict、C5 runtime readiness 及 L3 Effect Admission。27 `PI-B1-*` 維持原身分／順序與 SourceRef；原生五 REQ enum 不被 B1 Atom 取代。下方 Profile JSON 是已安裝 P4 input schema 的形狀，並非十二風險軸的完成評估。

Oracle Canonical Authoring Owner 為 **PIPD DOC-07**；已讀 P4 0.1.1 PI output schema 的 `acceptance.oracle_source` 仍固定 `DOC-03 DOMAIN_ORACLES`。記為 `CANONICAL_DOC07 + LEGACY_DOC03_ABI_CANDIDATE / CR-ORACLE-001_OPEN`。分支 A：PIPD Owner 提供可驗版本化 alias／adapter，包含 Writer 身分、來源 clause hash、schema digest、批准及正負 roundtrip，才可綁定；分支 B：無批准或 Writer／來源不符，`ORACLE_UNBOUND`，只 HOLD 消費此 Oracle 的正式編譯／ECP／TQAEP，不阻無關唯讀。不得由 B1 作者把兩字串直接認定同 Writer。

PIPD DOC-06 十二 calibrated complexity axes 與 P4 九個輸入 enum 為不同 schema。保留完整十二軸 level/rationale/evidence/veto、九軸選擇及版本化逐軸 loss map；`PROFILE_MAPPING_UNBOUND` 時不選較輕 Profile。分支 A：現役 Owner-approved resolver 可證所有風險／Safety Veto 不降級，才可產生正式 ProfileBinding；分支 B：缺映射、未知 veto、任一風險在投影消失即拒收受影映射。不可直接把十二軸塞入 strict P4 JSON，也不可刪三軸洗綠。

Model 邊界為三個實體 Lane `PLAN / EXECUTE / VERIFY_SECURITY`；TPM／Commander／Execute／Challenge 是角色配置，Pin／Pool／Session 是路由層，不創第四 Lane。每 Lane 真 request／Required／Served／PolicyEpoch／raw 分開讀回，Provider-off 不准靜默 fallback。R4 未實跑只記 NOT_RUN。

受影交叉引用：`00`（來源定位 `FHS_MSC_B1_PIPD_LS_PKG_00_GOVERNANCE_AND_CONTROL.md#repair-control`，非本包相對連結）、`02`（來源定位 `FHS_MSC_B1_PIPD_LS_PKG_02_DOC_B1_PD.md#repair-binding`，非本包相對連結）、`07`（來源定位 `FHS_MSC_B1_PIPD_LS_PKG_07_NATIVE_TOOLCHAIN_EXACT_USAGE.md#repair-tool-binding`，非本包相對連結）、`08`（來源定位 `FHS_MSC_B1_PIPD_LS_PKG_08_GOLDEN_WORKORDERS_E2E.md#repair-gwo-entry`，非本包相對連結）。

## 1. P4 原生 strict input（允許真的 JSON Schema 驗證；不假造 output identity）

**Profile input `urn:pipd:skill:pipd-profile-tailor:input:1`**：

```json
{
  "axes": [
    "intent",
    "knowledge",
    "verification",
    "release",
    "trust_boundary",
    "preexisting_repo",
    "profile",
    "tech_candidates",
    "host_surface"
  ],
  "profile": "ASSURED",
  "provider_off_required": true
}
```
**Profile 期望條件（不是捏造 ProfileBinding）**：有效 profile ASSURED、artifact_depth L4_FAILURE_RECOVERY、canonical_truth single；output 必由 plugin 產生真正 subject_id/content_hash/version/schema_version/escalated/escalation_reason/axes/vetoes/assurance。
**Negative fixture**：注入 `profile_request`／`project_atom_adapter` 當額外頂層欄位、雙軸或 `profile=ELITE`，`additionalProperties:false`/enum/uniqueItems 必拒；原生 schema 決不能被自製 sidecar 擴欄。

## 2. 原生 Intake/PI adapter 轉換程序

`B1 Goal + source locators` → P4 `pipd-route-intake` (strict goal/sources) → 由原生路由推導五軸 `REQ-INTENT,REQ-KNOWLEDGE,REQ-VERIFY,REQ-DELIVER,REQ-GOVERN` 中受影集合；不足立即 fail closed。P4 `pipd-authority-source` 只能在 family digest/locator/Owner 無衝突時建立正式 SourceFreezeManifest；本文件只有候選清單。

**PI native input 形狀（僅適用持有真 IntentCard 的 Host；以下值為設計規則，沒有編造 subject/hash）**：

```python
def make_p4_pi_input(intent_from_native, profile_binding_from_native, project_atoms, owner_oracles):
    allowed={'REQ-INTENT','REQ-KNOWLEDGE','REQ-VERIFY','REQ-DELIVER','REQ-GOVERN'}
    assert intent_from_native['subject_id'].startswith('INTENT-')
    assert profile_binding_from_native['schema_version']=='ProfileBinding@1'
    # Important: P4 input atoms are native REQ-* ONLY, and owner must be PIPD-EC.
    native=[]
    for req in intent_from_native['atoms']:
        key=req['req_id']; assert key in allowed
        oracle=owner_oracles.get(key)
        if not oracle or not oracle.get('source_clause') or not oracle.get('acceptance_cue'):
            raise ValueError('PI_SEMANTIC_OR_ORACLE_UNBOUND')
        native.append({'req_id':key,'source_clause':oracle['source_clause'],
                       'owner':'PIPD-EC','acceptance_cue':oracle['acceptance_cue'],
                       'risk_guard':oracle['risk_guard']})
    return {'intent':{'subject_id':intent_from_native['subject_id'],
                      'content_hash':intent_from_native['content_hash']},
            'profile':profile_binding_from_native['profile'],
            'atoms':native,'goal':intent_from_native['goal']}
# Output mapping to B1 is separately owned, never sent as a native P4 top-level key.
```
**Sidecar**：對每個 27 Atom 記 `{project_atom_id,source_clause_hash,original_owner,mapped_native_req_id,loss_flags,owner_approval_ref}`。loss_flags 非空或 oracle 未簽，native PI 即使可編譯也不能替本 B1 domain 直接出 ECP。

## 3. 27 個獨立可反證的 Atom（所附 runner 為 Owner 綁定候選）

### PI-B1-A1｜ROOT_RAW

- **上位來源**：FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_BLUEPRINT_AND_SKELETON_r2.md@dddc6b5993c88b9a2365aa9435ee492a543add3ebe4c89d79c58c58f9d16dbab#L257-L263 excerpt_sha256=a407811782933d9d0f3fe0a44acebcd59d73125f60021b0adc1f337cd97d2ecc; Owner：`Host/RootMap Owner`。
- **必要輸入與狀態**：`Windows realpath, git -C status --porcelain=v1 -z -uall, HEAD, index, reparse ancestors`；合法狀態：`CandidateRoot→ResolvedHandle→SnapshottedIndex→FRESH_OR_STALE`。
- **業務作用/可觀察成功**：Same handle/file-ID inside signed root; two scans no change；本域判準：same file ID and signed root; staged/unstaged/untracked snapshot stable。
- **候選 Owner ABI**：`root_probe`；其專屬 typed fields：`real_root,git_head,status_index,reparse_chain,root_handle`；明確定位前 `RUNNER_NOT_BOUND`，不可使用通用 OWNER_APPROVED_NATIVE_DOMAIN_ADAPTER 當假指令。
- **NEG/EDGE/SEC**：`alias/junction traversal or changed HEAD -> ROOT_ALIAS_OR_PATH_ESCAPE`。NEG 細分碼 `ROOT_ALIAS_OR_PATH_ESCAPE` → canonical `ROOT_ALIAS_OR_PATH_ESCAPE`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- **權限與回復**：- **Scope & rollback**：effect_class=READ_ONLY_PROBE、effect_key=ROOT_RAW；No mutation; drop stale probe, repeat fresh read。合法重試不得越過 at-most-once，對 UNKNOWN_EFFECT 先觀測 reconcile。；formal oracle/Owner status=UNBOUND。；真 effect 未執行時停止、隔離 observation，不要求無效的 rollback token。
- **可閉合 Join**：來源 Clause→PI-B1-A1→PD 的 WO/OBS→每個 effect ECP/NO_EFFECT→`TQ-B1-A1-POS/NEG/EDGE/SEC`→相同 subject immutable raw→Independent Checker；無 raw 永遠 `PLANNED/NOT_RUN`。

### PI-B1-A2｜ISSUER_SUBJECT

- **上位來源**：FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_BLUEPRINT_AND_SKELETON_r2.md@dddc6b5993c88b9a2365aa9435ee492a543add3ebe4c89d79c58c58f9d16dbab#L270-L276 excerpt_sha256=5b927350aee06a401945b3e3261b9809bb5af16adad5f9ae0b4f71c5a2b2b0e7; Owner：`HGK Native Issuer Owner`。
- **必要輸入與狀態**：`subject+epoch+scope+operation+ttl+nonce+issuer identity`；合法狀態：`Unissued→ValidatedRequest→NativePermitOrNack→ConsumedNonce`。
- **業務作用/可觀察成功**：Token signature/principal/nonce/subject/TTL checked native-side before spawn；本域判準：issuer-signed exact subject/scope checked before spawn; nonce consumed once。
- **候選 Owner ABI**：`native_issuer`；其專屬 typed fields：`issuer_identity,subject_sha,nonce,ttl,policy_epoch,grant_signature`；明確定位前 `RUNNER_NOT_BOUND`，不可使用通用 OWNER_APPROVED_NATIVE_DOMAIN_ADAPTER 當假指令。
- **NEG/EDGE/SEC**：`wrong issuer or replayed nonce -> PERMIT_SUBJECT_NONCE_REPLAY`。NEG 細分碼 `PERMIT_SUBJECT_NONCE_REPLAY` → canonical `PERMIT_SUBJECT_NONCE_REPLAY`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- **權限與回復**：- **Scope & rollback**：effect_class=OPS_NATIVE_HANDOFF、effect_key=ISSUER_SUBJECT；Invalidate grant; reconcile any in-flight effect; no replay。合法重試不得越過 at-most-once，對 UNKNOWN_EFFECT 先觀測 reconcile。；formal oracle/Owner status=UNBOUND。；真 effect 未執行時停止、隔離 observation，不要求無效的 rollback token。
- **可閉合 Join**：來源 Clause→PI-B1-A2→PD 的 WO/OBS→每個 effect ECP/NO_EFFECT→`TQ-B1-A2-POS/NEG/EDGE/SEC`→相同 subject immutable raw→Independent Checker；無 raw 永遠 `PLANNED/NOT_RUN`。

### PI-B1-A3｜QUEUE_WO

- **上位來源**：FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_BLUEPRINT_AND_SKELETON_r2.md@dddc6b5993c88b9a2365aa9435ee492a543add3ebe4c89d79c58c58f9d16dbab#L283-L289 excerpt_sha256=49402a7a88250a14862e94a00d1478b9aa47bfcc0f5daff2581da0e06005ee26; Owner：`Hermes Queue Owner`。
- **必要輸入與狀態**：`durable queue cursor, lease_generation, bounded K scan, resource lock`；合法狀態：`Queued→ClaimCAS→Running→Checkpoint/Parked→Terminal`。
- **業務作用/可觀察成功**：Scan at most K blocked cards, B/C independent advance; CAS generation single holder；本域判準：blocked A parked; independent B/C progressed within bounded K; generation CAS unique。
- **候選 Owner ABI**：`hermes_queue`；其專屬 typed fields：`queue_id,persisted_cursor,lease_generation,claimed_by,park_reason`；明確定位前 `RUNNER_NOT_BOUND`，不可使用通用 OWNER_APPROVED_NATIVE_DOMAIN_ADAPTER 當假指令。
- **NEG/EDGE/SEC**：`duplicate claim, starved B/C or stale generation -> LOST_LEASE_OR_DUPLICATE_CLAIM`。NEG 細分碼 `LOST_LEASE_OR_DUPLICATE_CLAIM` → canonical `LOST_LEASE_OR_DUPLICATE_CLAIM`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- **權限與回復**：- **Scope & rollback**：effect_class=OPS_RUNTIME_ACTIVATE、effect_key=QUEUE_WO；PARK blocked card with wake predicate; fence stale generation。合法重試不得越過 at-most-once，對 UNKNOWN_EFFECT 先觀測 reconcile。；formal oracle/Owner status=UNBOUND。；真 effect 未執行時停止、隔離 observation，不要求無效的 rollback token。
- **可閉合 Join**：來源 Clause→PI-B1-A3→PD 的 WO/OBS→每個 effect ECP/NO_EFFECT→`TQ-B1-A3-POS/NEG/EDGE/SEC`→相同 subject immutable raw→Independent Checker；無 raw 永遠 `PLANNED/NOT_RUN`。

### PI-B1-A4｜RECEIVER_ABI

- **上位來源**：FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_BLUEPRINT_AND_SKELETON_r2.md@dddc6b5993c88b9a2365aa9435ee492a543add3ebe4c89d79c58c58f9d16dbab#L296-L302 excerpt_sha256=0b2c8e188fc383e3527787eea20b618ff837b84830a8c96e4816819aa324aea2; Owner：`HGK Receiver Owner`。
- **必要輸入與狀態**：`HGK receiver typed ABI and issued WO, not mock mapping`；合法狀態：`ContractProposed→NativeAdmitted→AckOrNack→SameWOReadback`。
- **業務作用/可觀察成功**：Ack contains issuer and host identity; mocked ACK rejected；本域判準：true receiver ACK signed for exact subject; mock ACK never qualifies。
- **候選 Owner ABI**：`native_receiver`；其專屬 typed fields：`abi_id,issuer,wo_id,subject_sha,ack_or_nack,native_event`；明確定位前 `RUNNER_NOT_BOUND`，不可使用通用 OWNER_APPROVED_NATIVE_DOMAIN_ADAPTER 當假指令。
- **NEG/EDGE/SEC**：`mocked ACK/wrong ABI/absent native event -> RECEIVER_NOT_LIVE`。NEG 細分碼 `LIVE_RECEIVER_NOT_VERIFIED` → canonical `RECEIVER_NOT_LIVE`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- **權限與回復**：- **Scope & rollback**：effect_class=OPS_NATIVE_HANDOFF、effect_key=RECEIVER_ABI；No effect on NACK; rollback only affected admitted WO。合法重試不得越過 at-most-once，對 UNKNOWN_EFFECT 先觀測 reconcile。；formal oracle/Owner status=UNBOUND。；真 effect 未執行時停止、隔離 observation，不要求無效的 rollback token。
- **可閉合 Join**：來源 Clause→PI-B1-A4→PD 的 WO/OBS→每個 effect ECP/NO_EFFECT→`TQ-B1-A4-POS/NEG/EDGE/SEC`→相同 subject immutable raw→Independent Checker；無 raw 永遠 `PLANNED/NOT_RUN`。

### PI-B1-A5｜MODEL_LANES

- **上位來源**：FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_BLUEPRINT_AND_SKELETON_r2.md@dddc6b5993c88b9a2365aa9435ee492a543add3ebe4c89d79c58c58f9d16dbab#L309-L315 excerpt_sha256=466b5f697418b83d4ab49dbcae5945edeb48ae526dfacbcee2829951ebebb569; Owner：`Model/Lane Owner`。
- **必要輸入與狀態**：`required vs served PLAN/EXECUTE/VERIFY, version, epoch, digest`；合法狀態：`RequiredSet→HostServedProbe→EpochJoined→CoherentOrHold`。
- **業務作用/可觀察成功**：Every required lane served in exact epoch/host; one lane failure blocks Gate；本域判準：each mandatory lane actually served, same host and policy epoch。
- **候選 Owner ABI**：`host_lane_readback`；其專屬 typed fields：`PLAN,EXECUTE,VERIFY_SECURITY,required_arm,served_arm,epoch,loaded_sha`；明確定位前 `RUNNER_NOT_BOUND`，不可使用通用 OWNER_APPROVED_NATIVE_DOMAIN_ADAPTER 當假指令。
- **NEG/EDGE/SEC**：`silent model fallback or missing served arm -> MODEL_REQUIRED_NOT_SERVED`。NEG 細分碼 `SERVED_MODEL_MISMATCH` → canonical `MODEL_REQUIRED_NOT_SERVED`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- **權限與回復**：- **Scope & rollback**：effect_class=READ_ONLY_PROBE、effect_key=MODEL_LANES；Hold lane and independent affected dependent WO。合法重試不得越過 at-most-once，對 UNKNOWN_EFFECT 先觀測 reconcile。；formal oracle/Owner status=UNBOUND。；真 effect 未執行時停止、隔離 observation，不要求無效的 rollback token。
- **可閉合 Join**：來源 Clause→PI-B1-A5→PD 的 WO/OBS→每個 effect ECP/NO_EFFECT→`TQ-B1-A5-POS/NEG/EDGE/SEC`→相同 subject immutable raw→Independent Checker；無 raw 永遠 `PLANNED/NOT_RUN`。

### PI-B1-A6｜EFFECT_JOURNAL

- **上位來源**：FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_BLUEPRINT_AND_SKELETON_r2.md@dddc6b5993c88b9a2365aa9435ee492a543add3ebe4c89d79c58c58f9d16dbab#L322-L328 excerpt_sha256=36433fc130be7d86047b82bebf6e10490313b917528b9d98fba2583a9ef252d4; Owner：`Effect Journal Owner`。
- **必要輸入與狀態**：`operation ID, effect fingerprint, pre/posthash, outcome receipt, CAS fence`；合法狀態：`Prepared→Claimed→InFlight→ObservedSuccess/Unknown→Reconciled`。
- **業務作用/可觀察成功**：UNKNOWN_EFFECT cannot retry until world-state reconciled；本域判準：at-most-once effect; UNKNOWN_EFFECT reconciled before any next claim。
- **候選 Owner ABI**：`effect_journal`；其專屬 typed fields：`operation_id,preimage,observed_postimage,CAS_fence,unknown_effect`；明確定位前 `RUNNER_NOT_BOUND`，不可使用通用 OWNER_APPROVED_NATIVE_DOMAIN_ADAPTER 當假指令。
- **NEG/EDGE/SEC**：`duplicate operation or retry-on-timeout -> UNKNOWN_EFFECT_REPLAY`。NEG 細分碼 `DUPLICATE_OR_UNKNOWN_EFFECT` → canonical `UNKNOWN_EFFECT_REPLAY`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- **權限與回復**：- **Scope & rollback**：effect_class=OPS_RUNTIME_ACTIVATE、effect_key=EFFECT_JOURNAL；At-most-once, no retry of unknown; compensating rollback separate permit。合法重試不得越過 at-most-once，對 UNKNOWN_EFFECT 先觀測 reconcile。；formal oracle/Owner status=UNBOUND。；真 effect 未執行時停止、隔離 observation，不要求無效的 rollback token。
- **可閉合 Join**：來源 Clause→PI-B1-A6→PD 的 WO/OBS→每個 effect ECP/NO_EFFECT→`TQ-B1-A6-POS/NEG/EDGE/SEC`→相同 subject immutable raw→Independent Checker；無 raw 永遠 `PLANNED/NOT_RUN`。

### PI-B1-A7｜RAW_EVIDENCE

- **上位來源**：FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_BLUEPRINT_AND_SKELETON_r2.md@dddc6b5993c88b9a2365aa9435ee492a543add3ebe4c89d79c58c58f9d16dbab#L335-L341 excerpt_sha256=3c2e93ea528eec98d6f251c4e3ee1ffd2676fc028a38e4887b0c20194a37976b; Owner：`Independent AO`。
- **必要輸入與狀態**：`immutable raw hashes, witness signatures, subject/source/evidence SHA`；合法狀態：`ReceiptObserved→SourceSHAJoined→CheckerValidated→AcceptedOrRejected`。
- **業務作用/可觀察成功**：Maker!=Checker; no self-attested checker receipt；本域判準：distinct principal checker receipt matches same candidate and non-empty RAW。
- **候選 Owner ABI**：`immutable_evidence`；其專屬 typed fields：`raw_receipt,subject_sha,candidate_sha,checker_principal,witness`；明確定位前 `RUNNER_NOT_BOUND`，不可使用通用 OWNER_APPROVED_NATIVE_DOMAIN_ADAPTER 當假指令。
- **NEG/EDGE/SEC**：`self-attested or mismatched witness -> RAW_OR_CHECKER_MISMATCH`。NEG 細分碼 `RAW_SUBJECT_OR_WITNESS_MISSING` → canonical `RAW_OR_CHECKER_MISMATCH`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- **權限與回復**：- **Scope & rollback**：effect_class=READ_ONLY_PROBE、effect_key=RAW_EVIDENCE；Reject stale evidence and rerun only affected independent evaluation。合法重試不得越過 at-most-once，對 UNKNOWN_EFFECT 先觀測 reconcile。；formal oracle/Owner status=UNBOUND。；真 effect 未執行時停止、隔離 observation，不要求無效的 rollback token。
- **可閉合 Join**：來源 Clause→PI-B1-A7→PD 的 WO/OBS→每個 effect ECP/NO_EFFECT→`TQ-B1-A7-POS/NEG/EDGE/SEC`→相同 subject immutable raw→Independent Checker；無 raw 永遠 `PLANNED/NOT_RUN`。

### PI-B1-A8｜NATIVE_HOTPATH

- **上位來源**：FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_BLUEPRINT_AND_SKELETON_r2.md@dddc6b5993c88b9a2365aa9435ee492a543add3ebe4c89d79c58c58f9d16dbab#L348-L354 excerpt_sha256=f5e7c8c1351b8a63b6cdb6bb4b9b4bc17f7969074815dba121cadbf8105c09e1; Owner：`Fabric/HGK Dev Owner`。
- **必要輸入與狀態**：`identified deployed module and file digest; no historical blind replacement`；合法狀態：`RedReproducer→ScopedPreimage→MinimalPatch→Green→Review`。
- **業務作用/可觀察成功**：Exact current hotpath with rollback pointer and independent regression；本域判準：exact loaded callsite identified and scoped regression independent。
- **候選 Owner ABI**：`repo_diff`；其專屬 typed fields：`root,head,preimage,diff,writeset,red_green,postimage`；明確定位前 `RUNNER_NOT_BOUND`，不可使用通用 OWNER_APPROVED_NATIVE_DOMAIN_ADAPTER 當假指令。
- **NEG/EDGE/SEC**：`unbounded writes or missing red reproducer -> HOTPATH_UNRESOLVED`。NEG 細分碼 `UNMEASURED_REPAIR_OR_SCOPE_ESCAPE` → canonical `HOTPATH_UNRESOLVED`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- **權限與回復**：- **Scope & rollback**：effect_class=DEV_SOURCE_PATCH、effect_key=NATIVE_HOTPATH；Restore preimage; preserve untracked unrelated files。合法重試不得越過 at-most-once，對 UNKNOWN_EFFECT 先觀測 reconcile。；formal oracle/Owner status=UNBOUND。；真 effect 未執行時停止、隔離 observation，不要求無效的 rollback token。
- **可閉合 Join**：來源 Clause→PI-B1-A8→PD 的 WO/OBS→每個 effect ECP/NO_EFFECT→`TQ-B1-A8-POS/NEG/EDGE/SEC`→相同 subject immutable raw→Independent Checker；無 raw 永遠 `PLANNED/NOT_RUN`。

### PI-B1-A9｜NATIVE_CONTINUATION

- **上位來源**：FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_BLUEPRINT_AND_SKELETON_r2.md@dddc6b5993c88b9a2365aa9435ee492a543add3ebe4c89d79c58c58f9d16dbab#L361-L367 excerpt_sha256=a847c96af6ea83e51c5715836e8ab69d64ca6bf1f156becf292c6a7aeecfbbc3; Owner：`Hermes Continuation Owner`。
- **必要輸入與狀態**：`post-turn native trigger, mandate, persisted cursor and epoch`；合法狀態：`T0Proposal→T1Admit→T2NativeSpawn→T3Checkpoint→T4NativeResume`。
- **業務作用/可觀察成功**：Resume after external token revoked, initiated by native source；本域判準：native successor advances after external revoke with new session and no external trigger。
- **候選 Owner ABI**：`native_continuation`；其專屬 typed fields：`external_revoke,post_turn_source,issued_wo,native_claim,session_exit`；明確定位前 `RUNNER_NOT_BOUND`，不可使用通用 OWNER_APPROVED_NATIVE_DOMAIN_ADAPTER 當假指令。
- **NEG/EDGE/SEC**：`external actor still triggering -> EXTERNAL_TRIGGER_STILL_REQUIRED`。NEG 細分碼 `EXTERNAL_REENTRY_OR_NONNATIVE_SUCCESSOR` → canonical `EXTERNAL_TRIGGER_STILL_REQUIRED`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- **權限與回復**：- **Scope & rollback**：effect_class=OPS_RUNTIME_ACTIVATE、effect_key=NATIVE_CONTINUATION；Stop new external grant; reconcile in-flight; deny external replay。合法重試不得越過 at-most-once，對 UNKNOWN_EFFECT 先觀測 reconcile。；formal oracle/Owner status=UNBOUND。；真 effect 未執行時停止、隔離 observation，不要求無效的 rollback token。
- **可閉合 Join**：來源 Clause→PI-B1-A9→PD 的 WO/OBS→每個 effect ECP/NO_EFFECT→`TQ-B1-A9-POS/NEG/EDGE/SEC`→相同 subject immutable raw→Independent Checker；無 raw 永遠 `PLANNED/NOT_RUN`。

### PI-B1-B1｜SOURCE_ATOMS

- **上位來源**：FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_BLUEPRINT_AND_SKELETON_r2.md@dddc6b5993c88b9a2365aa9435ee492a543add3ebe4c89d79c58c58f9d16dbab#L374-L380 excerpt_sha256=bb7372aa3db524290bf4ad3a02fca0616c407398bb77c4af2e31e3169cdb808d; Owner：`PIPD Source Owner`。
- **必要輸入與狀態**：`16 REQ/27 atom, clause span+SHA, DOC03 domain oracles`；合法狀態：`RawSources→AtomCrosswalk→OracleBoundOrHold→PIProposed`。
- **業務作用/可觀察成功**：Missing/ambiguous clause opens TT; no fabricated PI issuer；本域判準：one-to-one source clause/owner/oracle joins; missing clause is HOLD。
- **候選 Owner ABI**：`source_oracle`；其專屬 typed fields：`clause_sha,atom_id,source_owner,domain_oracle,trace_edges`；明確定位前 `RUNNER_NOT_BOUND`，不可使用通用 OWNER_APPROVED_NATIVE_DOMAIN_ADAPTER 當假指令。
- **NEG/EDGE/SEC**：`missing oracle or fabricated source -> PI_SOURCE_OR_ORACLE_UNBOUND`。NEG 細分碼 `UNKNOWN_ATOM_SOURCE` → canonical `PI_SOURCE_OR_ORACLE_UNBOUND`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- **權限與回復**：- **Scope & rollback**：effect_class=READ_ONLY_PROBE、effect_key=SOURCE_ATOMS；HOLD only affected PI atoms。合法重試不得越過 at-most-once，對 UNKNOWN_EFFECT 先觀測 reconcile。；formal oracle/Owner status=UNBOUND。；真 effect 未執行時停止、隔離 observation，不要求無效的 rollback token。
- **可閉合 Join**：來源 Clause→PI-B1-B1→PD 的 WO/OBS→每個 effect ECP/NO_EFFECT→`TQ-B1-B1-POS/NEG/EDGE/SEC`→相同 subject immutable raw→Independent Checker；無 raw 永遠 `PLANNED/NOT_RUN`。

### PI-B1-B2｜REPO_CONTEXT

- **上位來源**：FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_BLUEPRINT_AND_SKELETON_r2.md@dddc6b5993c88b9a2365aa9435ee492a543add3ebe4c89d79c58c58f9d16dbab#L387-L393 excerpt_sha256=6c9fb64be67e0403e9c1c3770dca91d62f000442b9033f400f3795adb4125f4b; Owner：`PIPD PD Binder Owner`。
- **必要輸入與狀態**：`git status staged,unstaged,untracked, head, root handle`；合法狀態：`RepoRequested→RootRead→HEADAndStatusRead→BindingProposed`。
- **業務作用/可觀察成功**：No DEV effect for observation; no PD when no writable scope；本域判準：P4 PD only with actual repo root, HEAD and affected-only allowed write scope。
- **候選 Owner ABI**：`repo_context_probe`；其專屬 typed fields：`realpath,head,index,untracked,writable_scope,currentness`；明確定位前 `RUNNER_NOT_BOUND`，不可使用通用 OWNER_APPROVED_NATIVE_DOMAIN_ADAPTER 當假指令。
- **NEG/EDGE/SEC**：`stale/escaping context -> REPO_CONTEXT_NOT_FRESH`。NEG 細分碼 `PD_CONTEXT_STALE_OR_PATH_ESCAPE` → canonical `REPO_CONTEXT_NOT_FRESH`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- **權限與回復**：- **Scope & rollback**：effect_class=READ_ONLY_PROBE、effect_key=REPO_CONTEXT；Invalidate PD draft and rescan; no source edit。合法重試不得越過 at-most-once，對 UNKNOWN_EFFECT 先觀測 reconcile。；formal oracle/Owner status=UNBOUND。；真 effect 未執行時停止、隔離 observation，不要求無效的 rollback token。
- **可閉合 Join**：來源 Clause→PI-B1-B2→PD 的 WO/OBS→每個 effect ECP/NO_EFFECT→`TQ-B1-B2-POS/NEG/EDGE/SEC`→相同 subject immutable raw→Independent Checker；無 raw 永遠 `PLANNED/NOT_RUN`。

### PI-B1-B3｜SBL_TO_NATIVE

- **上位來源**：FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_BLUEPRINT_AND_SKELETON_r2.md@dddc6b5993c88b9a2365aa9435ee492a543add3ebe4c89d79c58c58f9d16dbab#L400-L406 excerpt_sha256=63c3bc490b96a2d0ea478857938af921681a7d228560fcc663e5722c5f6e2493; Owner：`SBL Bridge & HGK Owner`。
- **必要輸入與狀態**：`SBL m03/m04, candidate ECP, HGK receiver request`；合法狀態：`AdapterPatchCandidate→ReadOnlyTranslator→NativeHandoff→Ack/Nack`。
- **業務作用/可觀察成功**：DEV file patch != OPS native admission; two WO, two ECP where affected；本域判準：DEV/OPS different WOs, separate source diff and real native ACK。
- **候選 Owner ABI**：`bridge_handoff`；其專屬 typed fields：`sbl_entry,candidate,dev_diff,ops_handoff,native_receiver_ack`；明確定位前 `RUNNER_NOT_BOUND`，不可使用通用 OWNER_APPROVED_NATIVE_DOMAIN_ADAPTER 當假指令。
- **NEG/EDGE/SEC**：`second issuer or shared receipt -> SECOND_ISSUER_OR_MIXED_EFFECT`。NEG 細分碼 `HANDOFF_ABI_OR_MOCK_ACK` → canonical `SECOND_ISSUER_OR_MIXED_EFFECT`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- **權限與回復**：- **Scope & rollback**：effect_class=SPLIT_DEV_OPS、effect_key=SBL_TO_NATIVE；Undo adapter diff or cancel only native WO as appropriate。合法重試不得越過 at-most-once，對 UNKNOWN_EFFECT 先觀測 reconcile。；formal oracle/Owner status=UNBOUND。；真 effect 未執行時停止、隔離 observation，不要求無效的 rollback token。
- **可閉合 Join**：來源 Clause→PI-B1-B3→PD 的 WO/OBS→每個 effect ECP/NO_EFFECT→`TQ-B1-B3-POS/NEG/EDGE/SEC`→相同 subject immutable raw→Independent Checker；無 raw 永遠 `PLANNED/NOT_RUN`。

### PI-B1-B4｜ECP_SELECTOR

- **上位來源**：FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_BLUEPRINT_AND_SKELETON_r2.md@dddc6b5993c88b9a2365aa9435ee492a543add3ebe4c89d79c58c58f9d16dbab#L413-L419 excerpt_sha256=c9ce7d9b56e9debce81bac87d09e24c93eabde5b45107b53608ade2222ed415c; Owner：`HGK ECP Selection Owner`。
- **必要輸入與狀態**：`one WorkOrder one active ECP/effect class, source and target locks`；合法狀態：`EffectInventory→PerWOClass→OneActiveECP→IssuerGate`。
- **業務作用/可觀察成功**：Ambiguous/multiple ECP gets NACK before dispatch；本域判準：one active ECP per WO; split iff distinct effects。
- **候選 Owner ABI**：`ecp_selection`；其專屬 typed fields：`wo_id,effect_class,active_ecp_count,issuer_ack`；明確定位前 `RUNNER_NOT_BOUND`，不可使用通用 OWNER_APPROVED_NATIVE_DOMAIN_ADAPTER 當假指令。
- **NEG/EDGE/SEC**：`two active ECPs/unknown class -> ECP_MULTIPLE_OR_CLASS_UNKNOWN`。NEG 細分碼 `ECP_DOUBLE_ACTIVE_OR_CLASS_MISMATCH` → canonical `ECP_MULTIPLE_OR_CLASS_UNKNOWN`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- **權限與回復**：- **Scope & rollback**：effect_class=SPLIT_DEV_OPS、effect_key=ECP_SELECTOR；No issue; split and recompile affected WO。合法重試不得越過 at-most-once，對 UNKNOWN_EFFECT 先觀測 reconcile。；formal oracle/Owner status=UNBOUND。；真 effect 未執行時停止、隔離 observation，不要求無效的 rollback token。
- **可閉合 Join**：來源 Clause→PI-B1-B4→PD 的 WO/OBS→每個 effect ECP/NO_EFFECT→`TQ-B1-B4-POS/NEG/EDGE/SEC`→相同 subject immutable raw→Independent Checker；無 raw 永遠 `PLANNED/NOT_RUN`。

### PI-B1-B5｜THREE_SP

- **上位來源**：FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_BLUEPRINT_AND_SKELETON_r2.md@dddc6b5993c88b9a2365aa9435ee492a543add3ebe4c89d79c58c58f9d16dbab#L426-L432 excerpt_sha256=952cd82b4dae2a0dfbdff09a927d98d8a887ac29fdadb174c2956fd269147590; Owner：`SP Host Owner`。
- **必要輸入與狀態**：`TPM, Commander, Challenge independent Host principals`；合法狀態：`Package→InstallCandidate→HostLoadedReadback→Invoke/Deny→Uninstall`。
- **業務作用/可觀察成功**：Three separate true host-issued identities; ZIP-only denied；本域判準：three host identities and isolated permission readbacks; ZIP-only not pass。
- **候選 Owner ABI**：`sp_host_load`；其專屬 typed fields：`TPM_SP,COMMANDER_SP,CHALLENGE_SP,host_invocation,loaded_sha`；明確定位前 `RUNNER_NOT_BOUND`，不可使用通用 OWNER_APPROVED_NATIVE_DOMAIN_ADAPTER 當假指令。
- **NEG/EDGE/SEC**：`missing host invocation -> SP_HOST_LOAD_UNPROVEN`。NEG 細分碼 `SP_ROLE_OR_HOST_NOT_ACTUALLY_LOADED` → canonical `SP_HOST_LOAD_UNPROVEN`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- **權限與回復**：- **Scope & rollback**：effect_class=SPLIT_DEV_OPS、effect_key=THREE_SP；Revoke host grants then uninstall/residue readback。合法重試不得越過 at-most-once，對 UNKNOWN_EFFECT 先觀測 reconcile。；formal oracle/Owner status=UNBOUND。；真 effect 未執行時停止、隔離 observation，不要求無效的 rollback token。
- **可閉合 Join**：來源 Clause→PI-B1-B5→PD 的 WO/OBS→每個 effect ECP/NO_EFFECT→`TQ-B1-B5-POS/NEG/EDGE/SEC`→相同 subject immutable raw→Independent Checker；無 raw 永遠 `PLANNED/NOT_RUN`。

### PI-B1-B6｜TODO_PERSISTENCE

- **上位來源**：FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_BLUEPRINT_AND_SKELETON_r2.md@dddc6b5993c88b9a2365aa9435ee492a543add3ebe4c89d79c58c58f9d16dbab#L439-L445 excerpt_sha256=2997cb3163cbc87b6f42ff3f35dda7f4bbda31f8307e64523c45b3d47c29cdd4; Owner：`SBL CLI/User Data Owner`。
- **必要輸入與狀態**：`sbl-todo package install and isolated state dir`；合法狀態：`Installed→ListBefore→AddCommitted→ListAfter→DeleteCommitted→Uninstall`。
- **業務作用/可觀察成功**：User data add/delete not DEV; rollback state + uninstall exact sandbox；本域判準：isolated store add -> separate list -> delete -> zero residue。
- **候選 Owner ABI**：`sbl_todo`；其專屬 typed fields：`data_dir,task_id,add_response,list_response,delete_response,uninstall`；明確定位前 `RUNNER_NOT_BOUND`，不可使用通用 OWNER_APPROVED_NATIVE_DOMAIN_ADAPTER 當假指令。
- **NEG/EDGE/SEC**：`user effect misclassified or no actual state -> CLI_EFFECT_MISCLASSIFIED`。NEG 細分碼 `USER_TASK_EXECUTION_NOT_OBSERVED` → canonical `CLI_EFFECT_MISCLASSIFIED`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- **權限與回復**：- **Scope & rollback**：effect_class=USER_DATA_EFFECT、effect_key=TODO_PERSISTENCE；Restore user data backup; revoke install permission。合法重試不得越過 at-most-once，對 UNKNOWN_EFFECT 先觀測 reconcile。；formal oracle/Owner status=UNBOUND。；真 effect 未執行時停止、隔離 observation，不要求無效的 rollback token。
- **可閉合 Join**：來源 Clause→PI-B1-B6→PD 的 WO/OBS→每個 effect ECP/NO_EFFECT→`TQ-B1-B6-POS/NEG/EDGE/SEC`→相同 subject immutable raw→Independent Checker；無 raw 永遠 `PLANNED/NOT_RUN`。

### PI-B1-B7｜NOFIT_ROUTE

- **上位來源**：FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_BLUEPRINT_AND_SKELETON_r2.md@dddc6b5993c88b9a2365aa9435ee492a543add3ebe4c89d79c58c58f9d16dbab#L452-L458 excerpt_sha256=1970685e4fbf0fc946c6bd719330aa9358c54294b1e271848aa9208f39414e12; Owner：`PIPD TechnologyAdmission Owner`。
- **必要輸入與狀態**：`Tool×Kind×Mode×Host×Provider, pinned license/currentness`；合法狀態：`CapabilityWanted→ProviderHostProbe→SelectOrNoFit→OwnerReview`。
- **業務作用/可觀察成功**：Provider-off never silent swap or third-party issue；本域判準：deterministic capability NOFIT with user-readable reason and zero unauthorized delta。
- **候選 Owner ABI**：`no_fit`；其專屬 typed fields：`required_capability,host,provider_off,owner,refusal,zero_effect`；明確定位前 `RUNNER_NOT_BOUND`，不可使用通用 OWNER_APPROVED_NATIVE_DOMAIN_ADAPTER 當假指令。
- **NEG/EDGE/SEC**：`silent fallback -> NOFIT_OR_PROVIDER_OFF`。NEG 細分碼 `GUARDRAIL_BYPASS_OR_NOFIT_INCOMPLETE` → canonical `NOFIT_OR_PROVIDER_OFF`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- **權限與回復**：- **Scope & rollback**：effect_class=READ_ONLY_PROBE、effect_key=NOFIT_ROUTE；Emit NoFitReceipt and stop affected effect。合法重試不得越過 at-most-once，對 UNKNOWN_EFFECT 先觀測 reconcile。；formal oracle/Owner status=UNBOUND。；真 effect 未執行時停止、隔離 observation，不要求無效的 rollback token。
- **可閉合 Join**：來源 Clause→PI-B1-B7→PD 的 WO/OBS→每個 effect ECP/NO_EFFECT→`TQ-B1-B7-POS/NEG/EDGE/SEC`→相同 subject immutable raw→Independent Checker；無 raw 永遠 `PLANNED/NOT_RUN`。

### PI-B1-B8｜TRACE_GRAPH

- **上位來源**：FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_BLUEPRINT_AND_SKELETON_r2.md@dddc6b5993c88b9a2365aa9435ee492a543add3ebe4c89d79c58c58f9d16dbab#L465-L471 excerpt_sha256=0d98c897b2c33d2601e515e1caa76fd699aed6e7e1063885fcda9a18e4f668f6; Owner：`PIPD Trace Owner`。
- **必要輸入與狀態**：`PI→PD→CC→ECP→WO→TQAEP→Raw→Checker→Gate`；合法狀態：`EdgesCollected→HashesValidated→OrphansChecked→ClosureOrFail`。
- **業務作用/可觀察成功**：Any orphan/alias/hash-mismatch yields TRACE_CLOSURE_FAIL；本域判準：nonempty exact IDs and hashes, zero orphans and zero bad edges。
- **候選 Owner ABI**：`trace_closure`；其專屬 typed fields：`pi,pd,cc,ecp,wo,tqaep,raw,checker,edges`；明確定位前 `RUNNER_NOT_BOUND`，不可使用通用 OWNER_APPROVED_NATIVE_DOMAIN_ADAPTER 當假指令。
- **NEG/EDGE/SEC**：`foreign/sibling witness -> TRACE_CLOSURE_FAIL`。NEG 細分碼 `SUBJECT_HASH_BREAK_OR_ORPHAN` → canonical `TRACE_CLOSURE_FAIL`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- **權限與回復**：- **Scope & rollback**：effect_class=READ_ONLY_PROBE、effect_key=TRACE_GRAPH；Quarantine affected chain; no claim escalation。合法重試不得越過 at-most-once，對 UNKNOWN_EFFECT 先觀測 reconcile。；formal oracle/Owner status=UNBOUND。；真 effect 未執行時停止、隔離 observation，不要求無效的 rollback token。
- **可閉合 Join**：來源 Clause→PI-B1-B8→PD 的 WO/OBS→每個 effect ECP/NO_EFFECT→`TQ-B1-B8-POS/NEG/EDGE/SEC`→相同 subject immutable raw→Independent Checker；無 raw 永遠 `PLANNED/NOT_RUN`。

### PI-B1-B9｜R15_COVERAGE

- **上位來源**：FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_BLUEPRINT_AND_SKELETON_r2.md@dddc6b5993c88b9a2365aa9435ee492a543add3ebe4c89d79c58c58f9d16dbab#L478-L484 excerpt_sha256=e913b0d4725c5b01dcd67d27a04e5718545e21775c050e769e574c37a0e175f0; Owner：`SBL Product Owner`。
- **必要輸入與狀態**：`18-family individual source meaning & owner & disposition`；合法狀態：`R15Indexed→949Distinct→DispositionBound→ReviewPending`。
- **業務作用/可觀察成功**：No silent ID drops; deferred != verified; no orphan family；本域判準：949 unique 18-family IDs, 66/254/629 and source-specific disposition。
- **候選 Owner ABI**：`baseline_denominator`；其專屬 typed fields：`949_ids,18_families,required,conditional,deferred,owners`；明確定位前 `RUNNER_NOT_BOUND`，不可使用通用 OWNER_APPROVED_NATIVE_DOMAIN_ADAPTER 當假指令。
- **NEG/EDGE/SEC**：`missing ID or generic proxy pass -> R15_DENOMINATOR_SHRINK`。NEG 細分碼 `FULL_PRODUCT_PROXY_PASS` → canonical `R15_DENOMINATOR_SHRINK`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- **權限與回復**：- **Scope & rollback**：effect_class=READ_ONLY_PROBE、effect_key=R15_COVERAGE；Recover original source row and review disposition。合法重試不得越過 at-most-once，對 UNKNOWN_EFFECT 先觀測 reconcile。；formal oracle/Owner status=UNBOUND。；真 effect 未執行時停止、隔離 observation，不要求無效的 rollback token。
- **可閉合 Join**：來源 Clause→PI-B1-B9→PD 的 WO/OBS→每個 effect ECP/NO_EFFECT→`TQ-B1-B9-POS/NEG/EDGE/SEC`→相同 subject immutable raw→Independent Checker；無 raw 永遠 `PLANNED/NOT_RUN`。

### PI-B1-C1｜FABRIC_PROMOTION

- **上位來源**：FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_BLUEPRINT_AND_SKELETON_r2.md@dddc6b5993c88b9a2365aa9435ee492a543add3ebe4c89d79c58c58f9d16dbab#L491-L497 excerpt_sha256=cc185ce3c026aac6a530981840cef2159dfe3f916b938263f8a1a614ae066b46; Owner：`Fabric Activation Owner`。
- **必要輸入與狀態**：`policy sha, stage/active/loaded epoch, native loader witness`；合法狀態：`SourceCandidate→StageSeal→OwnerApprove→Active→HostLoadedReadback`。
- **業務作用/可觀察成功**：Stage/CI only never equals loaded; per-effect token；本域判準：independent stage approval; active and loaded exact digest; consumer projection ACK。
- **候選 Owner ABI**：`fabric_activator`；其專屬 typed fields：`approved_stage,active_policy,loaded_sha,consumer_trace,rollback`；明確定位前 `RUNNER_NOT_BOUND`，不可使用通用 OWNER_APPROVED_NATIVE_DOMAIN_ADAPTER 當假指令。
- **NEG/EDGE/SEC**：`stage mistaken as active or missing consumer -> FABRIC_LOADED_ABSENT`。NEG 細分碼 `FABRIC_REVERSE_PROJECTION_OR_POLICY_EPOCH` → canonical `FABRIC_LOADED_ABSENT`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- **權限與回復**：- **Scope & rollback**：effect_class=OPS_NATIVE_HANDOFF、effect_key=FABRIC_PROMOTION；Revert only candidate promotion; do not overwrite active without permit。合法重試不得越過 at-most-once，對 UNKNOWN_EFFECT 先觀測 reconcile。；formal oracle/Owner status=UNBOUND。；真 effect 未執行時停止、隔離 observation，不要求無效的 rollback token。
- **可閉合 Join**：來源 Clause→PI-B1-C1→PD 的 WO/OBS→每個 effect ECP/NO_EFFECT→`TQ-B1-C1-POS/NEG/EDGE/SEC`→相同 subject immutable raw→Independent Checker；無 raw 永遠 `PLANNED/NOT_RUN`。

### PI-B1-C2｜HGK_GWO

- **上位來源**：FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_BLUEPRINT_AND_SKELETON_r2.md@dddc6b5993c88b9a2365aa9435ee492a543add3ebe4c89d79c58c58f9d16dbab#L504-L510 excerpt_sha256=e11481b248bb5c8b2eeffc818f6abc15cc243aaaafa58eac7d0de0982d156466; Owner：`HGK Runtime Owner`。
- **必要輸入與狀態**：`HGK actual issuer+Hermes lease+journal`；合法狀態：`PermissionSigned→LeaseClaim→NativeWorker→RawReceipt`。
- **業務作用/可觀察成功**：Canary native same WO signature; fake mock ignored；本域判準：true SBL entry -> native HGK issuer -> Hermes lease -> reversible observable result。
- **候選 Owner ABI**：`hgk_native_golden`；其專屬 typed fields：`sbl_start,issued_wo,issuer,lease,worker_receipt,readback`；明確定位前 `RUNNER_NOT_BOUND`，不可使用通用 OWNER_APPROVED_NATIVE_DOMAIN_ADAPTER 當假指令。
- **NEG/EDGE/SEC**：`ghost worker/forged permit -> GWO_HGK_NOT_NATIVE`。NEG 細分碼 `HGK_FORGED_PERMIT_OR_GHOST_WORKER` → canonical `GWO_HGK_NOT_NATIVE`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- **權限與回復**：- **Scope & rollback**：effect_class=OPS_RUNTIME_ACTIVATE、effect_key=HGK_GWO；Reconcile in-flight effect, then release affected lock。合法重試不得越過 at-most-once，對 UNKNOWN_EFFECT 先觀測 reconcile。；formal oracle/Owner status=UNBOUND。；真 effect 未執行時停止、隔離 observation，不要求無效的 rollback token。
- **可閉合 Join**：來源 Clause→PI-B1-C2→PD 的 WO/OBS→每個 effect ECP/NO_EFFECT→`TQ-B1-C2-POS/NEG/EDGE/SEC`→相同 subject immutable raw→Independent Checker；無 raw 永遠 `PLANNED/NOT_RUN`。

### PI-B1-C3｜SBL_GWO

- **上位來源**：FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_BLUEPRINT_AND_SKELETON_r2.md@dddc6b5993c88b9a2365aa9435ee492a543add3ebe4c89d79c58c58f9d16dbab#L517-L523 excerpt_sha256=1975f524a2a0a74c966b68ff49f559adef2677fa3edf5d63006ec17c6e8c6af3; Owner：`SBL Product/User Owner`。
- **必要輸入與狀態**：`wheel, install identity, isolated todo db, delete tombstone`；合法狀態：`Build→Install→ListBefore→Add→ListAfter→Delete→Uninstall`。
- **業務作用/可觀察成功**：CLI add/delete and install/uninstall are effects; exact data restored；本域判準：separate Host install and USER effects with independent readbacks。
- **候選 Owner ABI**：`sbl_user_golden`；其專屬 typed fields：`sbl_entry,stack_install,consent,todo_add,list,delete,uninstall`；明確定位前 `RUNNER_NOT_BOUND`，不可使用通用 OWNER_APPROVED_NATIVE_DOMAIN_ADAPTER 當假指令。
- **NEG/EDGE/SEC**：`install count used as add success -> GWO_SBL_USER_STATE_UNPROVEN`。NEG 細分碼 `SBL_EMPTY_TEST_OR_NO_USER_OUTCOME` → canonical `GWO_SBL_USER_STATE_UNPROVEN`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- **權限與回復**：- **Scope & rollback**：effect_class=SPLIT_INSTALL_USERDATA、effect_key=SBL_GWO；Delete only owned sandbox and restore preimage。合法重試不得越過 at-most-once，對 UNKNOWN_EFFECT 先觀測 reconcile。；formal oracle/Owner status=UNBOUND。；真 effect 未執行時停止、隔離 observation，不要求無效的 rollback token。
- **可閉合 Join**：來源 Clause→PI-B1-C3→PD 的 WO/OBS→每個 effect ECP/NO_EFFECT→`TQ-B1-C3-POS/NEG/EDGE/SEC`→相同 subject immutable raw→Independent Checker；無 raw 永遠 `PLANNED/NOT_RUN`。

### PI-B1-C4｜EXTERNAL_GRANT

- **上位來源**：FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_BLUEPRINT_AND_SKELETON_r2.md@dddc6b5993c88b9a2365aa9435ee492a543add3ebe4c89d79c58c58f9d16dbab#L530-L536 excerpt_sha256=bca5b8b0bbc5e73220f14ddb7c3d3dfca5b5d4c7eb508a04ade1cba49cd77caf; Owner：`External Delegation Owner`。
- **必要輸入與狀態**：`external principal, repo/scope/TTL/epoch bound`；合法狀態：`RequestScope→GrantTimed→TaskScoped→RevokeNew`。
- **業務作用/可觀察成功**：No broader GitHub/Windows authority via standing mission；本域判準：bounded external grant and no residual capability on revoke。
- **候選 Owner ABI**：`delegation`；其專屬 typed fields：`owner_scope,ttl,principal,revocation,zero_scope_escape`；明確定位前 `RUNNER_NOT_BOUND`，不可使用通用 OWNER_APPROVED_NATIVE_DOMAIN_ADAPTER 當假指令。
- **NEG/EDGE/SEC**：`scope expansion -> EXTERNAL_SCOPE_ESCAPED`。NEG 細分碼 `EXTERNAL_GRANT_SCOPE_OR_TTL` → canonical `EXTERNAL_SCOPE_ESCAPED`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- **權限與回復**：- **Scope & rollback**：effect_class=OPS_NATIVE_HANDOFF、effect_key=EXTERNAL_GRANT；Stop new delegated work; revoke key; no blanket cancel。合法重試不得越過 at-most-once，對 UNKNOWN_EFFECT 先觀測 reconcile。；formal oracle/Owner status=UNBOUND。；真 effect 未執行時停止、隔離 observation，不要求無效的 rollback token。
- **可閉合 Join**：來源 Clause→PI-B1-C4→PD 的 WO/OBS→每個 effect ECP/NO_EFFECT→`TQ-B1-C4-POS/NEG/EDGE/SEC`→相同 subject immutable raw→Independent Checker；無 raw 永遠 `PLANNED/NOT_RUN`。

### PI-B1-C5｜CODEX_MINPATCH

- **上位來源**：FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_BLUEPRINT_AND_SKELETON_r2.md@dddc6b5993c88b9a2365aa9435ee492a543add3ebe4c89d79c58c58f9d16dbab#L543-L549 excerpt_sha256=35386b7a209b25024893873cefa1d47e493d5ba83da77c0add6bd9c684caf0fd; Owner：`Codex Maker + Dev Owner`。
- **必要輸入與狀態**：`actual current hotpath and preimage, working tree tree-id`；合法狀態：`RedNativeFixture→Preimage→ScopedPatch→Green→IndependentReview`。
- **業務作用/可觀察成功**：No edit outside allowlist; narrow rollback；本域判準：only affected files changed and full regression independent。
- **候選 Owner ABI**：`bounded_coding`；其專屬 typed fields：`write_scope,preimage,red_test,patch,green_test,checker`；明確定位前 `RUNNER_NOT_BOUND`，不可使用通用 OWNER_APPROVED_NATIVE_DOMAIN_ADAPTER 當假指令。
- **NEG/EDGE/SEC**：`checker edits same diff or no red test -> UNBOUNDED_PATCH_OR_REGRESSION`。NEG 細分碼 `CODEX_UNMEASURED_PATCH_OR_CHECKER_MUTATION` → canonical `UNBOUNDED_PATCH_OR_REGRESSION`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- **權限與回復**：- **Scope & rollback**：effect_class=DEV_SOURCE_PATCH、effect_key=CODEX_MINPATCH；Restore patch preimage and retain red fixture。合法重試不得越過 at-most-once，對 UNKNOWN_EFFECT 先觀測 reconcile。；formal oracle/Owner status=UNBOUND。；真 effect 未執行時停止、隔離 observation，不要求無效的 rollback token。
- **可閉合 Join**：來源 Clause→PI-B1-C5→PD 的 WO/OBS→每個 effect ECP/NO_EFFECT→`TQ-B1-C5-POS/NEG/EDGE/SEC`→相同 subject immutable raw→Independent Checker；無 raw 永遠 `PLANNED/NOT_RUN`。

### PI-B1-C6｜REVOKE_RACE

- **上位來源**：FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_BLUEPRINT_AND_SKELETON_r2.md@dddc6b5993c88b9a2365aa9435ee492a543add3ebe4c89d79c58c58f9d16dbab#L556-L562 excerpt_sha256=2f5d7d883429aeb5c263b9c06057c3b1037264453f9b5fc3a13a3111b1617e1b; Owner：`Revoke/Effect Owner`。
- **必要輸入與狀態**：`token consumed map, outstanding effect IDs, event cursor`；合法狀態：`StopNew→RevokeNew→InFlightUnknownReconcile→PostDeny`。
- **業務作用/可觀察成功**：Unknown effect not erased, previously admitted in-flight reconciled；本域判準：post-revoke use fails before spawn; existing effects reconciled。
- **候選 Owner ABI**：`revoke_boundary`；其專屬 typed fields：`old_nonce,revocation_epoch,attempt_after_revoke,denied_effect`；明確定位前 `RUNNER_NOT_BOUND`，不可使用通用 OWNER_APPROVED_NATIVE_DOMAIN_ADAPTER 當假指令。
- **NEG/EDGE/SEC**：`reused token after revoke -> REVOKED_TOKEN_REPLAY`。NEG 細分碼 `POST_REVOKE_TOKEN_REPLAY` → canonical `REVOKED_TOKEN_REPLAY`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- **權限與回復**：- **Scope & rollback**：effect_class=OPS_NATIVE_HANDOFF、effect_key=REVOKE_RACE；Leave affected lock held until reconciled。合法重試不得越過 at-most-once，對 UNKNOWN_EFFECT 先觀測 reconcile。；formal oracle/Owner status=UNBOUND。；真 effect 未執行時停止、隔離 observation，不要求無效的 rollback token。
- **可閉合 Join**：來源 Clause→PI-B1-C6→PD 的 WO/OBS→每個 effect ECP/NO_EFFECT→`TQ-B1-C6-POS/NEG/EDGE/SEC`→相同 subject immutable raw→Independent Checker；無 raw 永遠 `PLANNED/NOT_RUN`。

### PI-B1-C7｜FOUR_LAYER_ID

- **上位來源**：FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_BLUEPRINT_AND_SKELETON_r2.md@dddc6b5993c88b9a2365aa9435ee492a543add3ebe4c89d79c58c58f9d16dbab#L569-L575 excerpt_sha256=d8dd698fe26bd66a63c8939c49c25a298e09026daa0059853ab62ffd65ddf9a7; Owner：`Native Loader Owner`。
- **必要輸入與狀態**：`source, build, installed, loaded four separately witnessed hashes`；合法狀態：`SourceSHA→BuildSHA→InstallSHA→LoadedSHA`。
- **業務作用/可觀察成功**：No source hash used as proof of loaded binary；本域判準：all four identity layers tied to same subject, not merely file on disk。
- **候選 Owner ABI**：`loaded_identity`；其專屬 typed fields：`source_sha,installed_binary_sha,host_loaded_sha,served_model,policy_epoch`；明確定位前 `RUNNER_NOT_BOUND`，不可使用通用 OWNER_APPROVED_NATIVE_DOMAIN_ADAPTER 當假指令。
- **NEG/EDGE/SEC**：`green patch with stale loaded binary -> LOADED_BINARY_MISMATCH`。NEG 細分碼 `PATCH_GREEN_NOT_LOADED` → canonical `LOADED_BINARY_MISMATCH`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- **權限與回復**：- **Scope & rollback**：effect_class=READ_ONLY_PROBE、effect_key=FOUR_LAYER_ID；HOLD activation; do not advertise runtime ready。合法重試不得越過 at-most-once，對 UNKNOWN_EFFECT 先觀測 reconcile。；formal oracle/Owner status=UNBOUND。；真 effect 未執行時停止、隔離 observation，不要求無效的 rollback token。
- **可閉合 Join**：來源 Clause→PI-B1-C7→PD 的 WO/OBS→每個 effect ECP/NO_EFFECT→`TQ-B1-C7-POS/NEG/EDGE/SEC`→相同 subject immutable raw→Independent Checker；無 raw 永遠 `PLANNED/NOT_RUN`。

### PI-B1-C8｜NATIVE_SUCCESSOR

- **上位來源**：FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_BLUEPRINT_AND_SKELETON_r2.md@dddc6b5993c88b9a2365aa9435ee492a543add3ebe4c89d79c58c58f9d16dbab#L582-L588 excerpt_sha256=00d8e06843af4cc584634ba47c33d9995efe665fca78b8b1ec45501317f49b9d; Owner：`Hermes Continuation Owner`。
- **必要輸入與狀態**：`native scheduler event without external session, same subject hash`；合法狀態：`ExternalRevoked→NativeTrigger→NativeRun→DurableCheckpoint`。
- **業務作用/可觀察成功**：Post-turn continuation must originate in Hermes native source；本域判準：fresh separate session native trigger progresses after external account revoked。
- **候選 Owner ABI**：`post_revoke_successor`；其專屬 typed fields：`external_stop,ledger_cursor,issuer,successor_wo,native_origin`；明確定位前 `RUNNER_NOT_BOUND`，不可使用通用 OWNER_APPROVED_NATIVE_DOMAIN_ADAPTER 當假指令。
- **NEG/EDGE/SEC**：`successor still external-triggered -> NATIVE_SUCCESSOR_NOT_PROVEN`。NEG 細分碼 `NATIVE_SUCCESSOR_NOT_AUTONOMOUS` → canonical `NATIVE_SUCCESSOR_NOT_PROVEN`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- **權限與回復**：- **Scope & rollback**：effect_class=OPS_RUNTIME_ACTIVATE、effect_key=NATIVE_SUCCESSOR；Do not reenable external principal as hidden fallback。合法重試不得越過 at-most-once，對 UNKNOWN_EFFECT 先觀測 reconcile。；formal oracle/Owner status=UNBOUND。；真 effect 未執行時停止、隔離 observation，不要求無效的 rollback token。
- **可閉合 Join**：來源 Clause→PI-B1-C8→PD 的 WO/OBS→每個 effect ECP/NO_EFFECT→`TQ-B1-C8-POS/NEG/EDGE/SEC`→相同 subject immutable raw→Independent Checker；無 raw 永遠 `PLANNED/NOT_RUN`。

### PI-B1-C9｜TRIPLE_GWO

- **上位來源**：FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_BLUEPRINT_AND_SKELETON_r2.md@dddc6b5993c88b9a2365aa9435ee492a543add3ebe4c89d79c58c58f9d16dbab#L595-L601 excerpt_sha256=06ab64321c1cf87e60d87e74a209c0a17b28244ee0da01dab18ed8c3d6e1d4a7; Owner：`Independent AO + 3 Domain Owners`。
- **必要輸入與狀態**：`Fabric,HGK,SBL distinct effect and owner receipts`；合法狀態：`ThreeDistinctSubjects→ThreeRawSets→IndependentVerdict→GBGate`。
- **業務作用/可觀察成功**：Swapped receipts, same principal, absent third yields FAIL；本域判準：3 different domain receipts, all same intended crosswalk, not aliases。
- **候選 Owner ABI**：`triple_golden_join`；其專屬 typed fields：`fabric_receipt,hgk_receipt,sbl_receipt,revoke_receipt,join_subject`；明確定位前 `RUNNER_NOT_BOUND`，不可使用通用 OWNER_APPROVED_NATIVE_DOMAIN_ADAPTER 當假指令。
- **NEG/EDGE/SEC**：`same receipt reused -> GWO_RECEIPT_ALIAS`。NEG 細分碼 `THREE_GWO_PROXY_PASS` → canonical `GWO_RECEIPT_ALIAS`；EDGE 僅在本域引入適用 drift（不強制 READ_ONLY 具有 lease 或 TODO 有 Git HEAD）；SEC 以同域 token/host/alias 攻擊為反例。
- **權限與回復**：- **Scope & rollback**：effect_class=READ_ONLY_PROBE、effect_key=TRIPLE_GWO；Gate HOLD; rerun only missing subject independently。合法重試不得越過 at-most-once，對 UNKNOWN_EFFECT 先觀測 reconcile。；formal oracle/Owner status=UNBOUND。；真 effect 未執行時停止、隔離 observation，不要求無效的 rollback token。
- **可閉合 Join**：來源 Clause→PI-B1-C9→PD 的 WO/OBS→每個 effect ECP/NO_EFFECT→`TQ-B1-C9-POS/NEG/EDGE/SEC`→相同 subject immutable raw→Independent Checker；無 raw 永遠 `PLANNED/NOT_RUN`。


## B1 DOC02：31 Work/Observation Slot 完整來源正文

# DOC-B1-PD｜31 個 WO／OBS 完整影響分類、晚綁、效果轉移

<a id="repair-binding"></a>
## 本候選修訂：31 槽執行投影與受影准入（RCA-05/15/17/21/25/27）

本冊 §2 的 31 個完整 payload、Oracle、NEG、rollback 是原身分定義；分派函式只計算設計候選的 binding eligibility，不發 Token、不寫 Queue、不代表准入成功。READ_ONLY 的 `permission=NONE` 只指無 Native effect token，仍須合法 Read Scope。Repo 寫入要真 DEV admission；Host/User 不得借 RepoContext／DEV Token。

每槽之衍生投影欄位為 `slot_id, effect_class, source_ref, binding_required, depends_on, blocked_by, evidence_kind, next_action, policy_epoch, runtime_state`。原 ID／分類由 §2 的唯一 slot JSON 解析；隨包 EXECUTION_PROJECTION_CANDIDATE.json 含 31 筆完整 locator。本次 policy_epoch／actual_binding／SharedSpine 狀態均未讀回，保持 null／UNVERIFIED，禁止假造 READY。`depends_on=null` 表示待 discovery，與已證沒有依賴的 `[]` 不同。先做合法唯讀確認實際消費邊，僅該受影子圖 HOLD。

十 OBS、五 REPO、十四 HOST、兩 USER 不合併；`BLOCKED_NO_ISSUER` 只適用消費 Native Permit 的槽。R3/R4 沒有真合法 probe，狀態 NOT_RUN，不能寫 ACTIVATOR_FAILED／MODEL_SERVE_MISMATCH。當前政策強制方法仍須另做 DOC-00 resolver；binding eligibility 不繞過方法或獨立驗收。

受影交叉引用：`00`（來源定位 `FHS_MSC_B1_PIPD_LS_PKG_00_GOVERNANCE_AND_CONTROL.md#repair-control`，非本包相對連結）、`07`（來源定位 `FHS_MSC_B1_PIPD_LS_PKG_07_NATIVE_TOOLCHAIN_EXACT_USAGE.md#repair-tool-binding`，非本包相對連結）、`08`（來源定位 `FHS_MSC_B1_PIPD_LS_PKG_08_GOLDEN_WORKORDERS_E2E.md#repair-gwo-entry`，非本包相對連結）。

**禁止**：對 Host state/User state 假造 `RepoContext`；觀測卡不得因此產生 P4 PD。Host 需要 Native Owner Adapter，未拿到 runtime ABI 時限 `HOLD_NOT_BOUND`。

## 1. 正式 late-bind 決策函式（設計工具，非 Host 實測）

```python
def choose_binding(slot, repo_probe=None, host_probe=None, read_probe=None):
    # DESIGN eligibility only. Flags denote already-validated native evidence,
    # never caller self-issued grants; no effect or live dispatch occurs here.
    k=slot['effect_class']
    if k == 'READ_ONLY_PROBE':
        if not read_probe or not all(read_probe.get(x) is True for x in
                                     ('read_scope_valid','same_subject','fresh','no_mutation')):
            return {'status':'HOLD','first_fail':'READ_SCOPE_OR_CURRENTNESS_UNBOUND'}
        return {'status':'READ_ONLY','permission':'NONE','effect':'NO_EFFECT'}
    if k == 'REPOSITORY_WRITE':
        if not repo_probe or not all(repo_probe.get(x) for x in ('real_root','head','writable_scope')):
            return {'status':'HOLD','first_fail':'REPO_CONTEXT_MISSING'}
        if repo_probe.get('dirty_conflict') or repo_probe.get('path_escape') or repo_probe.get('currentness') != 'FRESH':
            return {'status':'HOLD','first_fail':'REPO_CONTEXT_NOT_FRESH'}
        if not all(repo_probe.get(x) is True for x in ('owner_scope_valid','dev_admission_valid','dev_ecp_valid')):
            return {'status':'HOLD','first_fail':'L2_ADMISSION_HOLD'}
        return {'status':'READY_FOR_OWNER_REVIEW','writer':'Codex','scope':repo_probe['writable_scope']}
    if k in ('HOST_OPERATIONS','USER_DATA_EFFECT'):
        required=('active_policy_epoch','issuer','receiver','ecp_ref','evidence_ref')
        if not host_probe or not all(host_probe.get(x) for x in required):
            return {'status':'HOLD','first_fail':'NATIVE_ISSUER_OR_POLICY_UNBOUND'}
        if k == 'USER_DATA_EFFECT' and not all(host_probe.get(x) is True for x in
                                               ('user_consent','user_issuer','synthetic_scope_valid')):
            return {'status':'NOFIT','first_fail':'USER_ISSUER_OR_CONSENT_MISSING'}
        if not all(host_probe.get(x) is True for x in
                   ('permit_valid','same_subject','scope_valid','nonce_fresh','ttl_valid','not_revoked','preimage_valid')):
            return {'status':'NACK','first_fail':'PERMIT_SUBJECT_NONCE_REPLAY'}
        return {'status':'READY_FOR_OWNER_REVIEW','effect':'USER_ONLY' if k == 'USER_DATA_EFFECT' else 'OPS_ONLY'}
    raise ValueError('EFFECT_CLASS_UNKNOWN')
```

## 2. 每個原始 WO/OBS 的個別判準（Operation、Schema、Readback、Rollback）

### PD-01｜OBS-B1-A1 — ROOT_RAW / READ_ONLY_PROBE

**原 r2 段落位置**：L411；**需求 Owner**：Host/RootMap Owner；domain invariant：same file ID and signed root; staged/unstaged/untracked snapshot stable。
**作用程序**：READ ONLY exact root_probe source/host probe; no WorkOrder issue, no ECP, no rollback token。
```json
{
  "atom": "B1-A1",
  "cross_effect_receipt_reuse": false,
  "current_binding_state": "READ_ONLY_SCOPE_PENDING",
  "effect_class": "READ_ONLY_PROBE",
  "effect_key": "ROOT_RAW",
  "needed_fields": [
    "subject_ref",
    "source_hash",
    "read_scope",
    "owner",
    "observation_time"
  ],
  "operation": "READ ONLY exact root_probe source/host probe; no WorkOrder issue, no ECP, no rollback token",
  "permission": "NONE_READ_ONLY",
  "readback_fields": [
    "real_root",
    "git_head",
    "status_index",
    "reparse_chain",
    "root_handle",
    "no_effect_witness"
  ],
  "schema": "B1.PD.EFFECT_SLOT@r3",
  "slot_id": "OBS-B1-A1"
}
```
**個別 NEG**：alias/junction traversal or changed HEAD -> ROOT_ALIAS_OR_PATH_ESCAPE; alias and stale observations must close without world mutation。`OBS-B1-A1` 產生獨立 `operation_id:OBS-B1-A1`、`RAW:OBS-B1-A1`、`OR:OBS-B1-A1`；只允許事前 hash 相同且合法 dependency 的上游 receipt，不可當作自己的 effect receipt。
**閉合條件**：Source→PI-B1-A1→OBS-B1-A1→只一 ECP 或 NO_EFFECT→`TQ-CHILD-OBS-B1-A1-POS/NEG/EDGE/SEC`→checker。Missing current binding ⇒ `HOLD`，不得把本 schema 範本稱為 issued WorkOrder。

### PD-02｜WO-B1-A2 — ISSUER_SUBJECT / HOST_OPERATIONS

**原 r2 段落位置**：L416；**需求 Owner**：HGK Native Issuer Owner；domain invariant：issuer-signed exact subject/scope checked before spawn; nonce consumed once。
**作用程序**：validate token{subject,policy_epoch,principal,nonce,scope,ttl} -> issuer signed ACK/NACK; consume nonce only on accepted native operation。
```json
{
  "atom": "B1-A2",
  "cross_effect_receipt_reuse": false,
  "current_binding_state": "HOLD_PENDING_TRUE_OWNER_AND_HOST",
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "ISSUER_SUBJECT",
  "needed_fields": [
    "subject_sha",
    "active_policy_epoch",
    "issuer_identity",
    "token_ref",
    "operation_id",
    "nonce",
    "ttl",
    "host_id",
    "expected_prestate_sha"
  ],
  "operation": "validate token{subject,policy_epoch,principal,nonce,scope,ttl} -> issuer signed ACK/NACK; consume nonce only on accepted native operation",
  "permission": "OWNER_BOUND_TOKEN_REQUIRED",
  "readback_fields": [
    "issuer_identity",
    "subject_sha",
    "nonce",
    "ttl",
    "policy_epoch",
    "grant_signature",
    "native_event_id",
    "operation_id",
    "effect_postimage_sha",
    "evidence_ref"
  ],
  "schema": "B1.PD.EFFECT_SLOT@r3",
  "slot_id": "WO-B1-A2"
}
```
**個別 NEG**：wrong issuer or replayed nonce -> PERMIT_SUBJECT_NONCE_REPLAY; expired/mismatched token or unknown effect -> NACK/RECONCILE。`WO-B1-A2` 產生獨立 `operation_id:WO-B1-A2`、`RAW:WO-B1-A2`、`OR:WO-B1-A2`；只允許事前 hash 相同且合法 dependency 的上游 receipt，不可當作自己的 effect receipt。
**閉合條件**：Source→PI-B1-A2→WO-B1-A2→只一 ECP 或 NO_EFFECT→`TQ-CHILD-WO-B1-A2-POS/NEG/EDGE/SEC`→checker。Missing current binding ⇒ `HOLD`，不得把本 schema 範本稱為 issued WorkOrder。

### PD-03｜WO-B1-A3 — QUEUE_WO / HOST_OPERATIONS

**原 r2 段落位置**：L424；**需求 Owner**：Hermes Queue Owner；domain invariant：blocked A parked; independent B/C progressed within bounded K; generation CAS unique。
**作用程序**：enqueue durable WO -> bounded K round-robin scan -> ClaimCAS lease_generation -> heartbeat -> checkpoint/PARK with predicate。
```json
{
  "atom": "B1-A3",
  "cross_effect_receipt_reuse": false,
  "current_binding_state": "HOLD_PENDING_TRUE_OWNER_AND_HOST",
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "QUEUE_WO",
  "needed_fields": [
    "subject_sha",
    "active_policy_epoch",
    "issuer_identity",
    "token_ref",
    "operation_id",
    "nonce",
    "ttl",
    "host_id",
    "expected_prestate_sha"
  ],
  "operation": "enqueue durable WO -> bounded K round-robin scan -> ClaimCAS lease_generation -> heartbeat -> checkpoint/PARK with predicate",
  "permission": "OWNER_BOUND_TOKEN_REQUIRED",
  "readback_fields": [
    "queue_id",
    "persisted_cursor",
    "lease_generation",
    "claimed_by",
    "park_reason",
    "native_event_id",
    "operation_id",
    "effect_postimage_sha",
    "evidence_ref"
  ],
  "schema": "B1.PD.EFFECT_SLOT@r3",
  "slot_id": "WO-B1-A3"
}
```
**個別 NEG**：duplicate claim, starved B/C or stale generation -> LOST_LEASE_OR_DUPLICATE_CLAIM; expired/mismatched token or unknown effect -> NACK/RECONCILE。`WO-B1-A3` 產生獨立 `operation_id:WO-B1-A3`、`RAW:WO-B1-A3`、`OR:WO-B1-A3`；只允許事前 hash 相同且合法 dependency 的上游 receipt，不可當作自己的 effect receipt。
**閉合條件**：Source→PI-B1-A3→WO-B1-A3→只一 ECP 或 NO_EFFECT→`TQ-CHILD-WO-B1-A3-POS/NEG/EDGE/SEC`→checker。Missing current binding ⇒ `HOLD`，不得把本 schema 範本稱為 issued WorkOrder。

### PD-04｜WO-B1-A4 — RECEIVER_ABI / HOST_OPERATIONS

**原 r2 段落位置**：L432；**需求 Owner**：HGK Receiver Owner；domain invariant：true receiver ACK signed for exact subject; mock ACK never qualifies。
**作用程序**：serialize existing typed receiver request -> native receiver validates ABI+Permit -> native event ACK/NACK -> same WO readback。
```json
{
  "atom": "B1-A4",
  "cross_effect_receipt_reuse": false,
  "current_binding_state": "HOLD_PENDING_TRUE_OWNER_AND_HOST",
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "RECEIVER_ABI",
  "needed_fields": [
    "subject_sha",
    "active_policy_epoch",
    "issuer_identity",
    "token_ref",
    "operation_id",
    "nonce",
    "ttl",
    "host_id",
    "expected_prestate_sha"
  ],
  "operation": "serialize existing typed receiver request -> native receiver validates ABI+Permit -> native event ACK/NACK -> same WO readback",
  "permission": "OWNER_BOUND_TOKEN_REQUIRED",
  "readback_fields": [
    "abi_id",
    "issuer",
    "wo_id",
    "subject_sha",
    "ack_or_nack",
    "native_event",
    "native_event_id",
    "operation_id",
    "effect_postimage_sha",
    "evidence_ref"
  ],
  "schema": "B1.PD.EFFECT_SLOT@r3",
  "slot_id": "WO-B1-A4"
}
```
**個別 NEG**：mocked ACK/wrong ABI/absent native event -> RECEIVER_NOT_LIVE; expired/mismatched token or unknown effect -> NACK/RECONCILE。`WO-B1-A4` 產生獨立 `operation_id:WO-B1-A4`、`RAW:WO-B1-A4`、`OR:WO-B1-A4`；只允許事前 hash 相同且合法 dependency 的上游 receipt，不可當作自己的 effect receipt。
**閉合條件**：Source→PI-B1-A4→WO-B1-A4→只一 ECP 或 NO_EFFECT→`TQ-CHILD-WO-B1-A4-POS/NEG/EDGE/SEC`→checker。Missing current binding ⇒ `HOLD`，不得把本 schema 範本稱為 issued WorkOrder。

### PD-05｜OBS-B1-A5 — MODEL_LANES / READ_ONLY_PROBE

**原 r2 段落位置**：L440；**需求 Owner**：Model/Lane Owner；domain invariant：each mandatory lane actually served, same host and policy epoch。
**作用程序**：READ ONLY exact host_lane_readback source/host probe; no WorkOrder issue, no ECP, no rollback token。
```json
{
  "atom": "B1-A5",
  "cross_effect_receipt_reuse": false,
  "current_binding_state": "READ_ONLY_SCOPE_PENDING",
  "effect_class": "READ_ONLY_PROBE",
  "effect_key": "MODEL_LANES",
  "needed_fields": [
    "subject_ref",
    "source_hash",
    "read_scope",
    "owner",
    "observation_time"
  ],
  "operation": "READ ONLY exact host_lane_readback source/host probe; no WorkOrder issue, no ECP, no rollback token",
  "permission": "NONE_READ_ONLY",
  "readback_fields": [
    "PLAN",
    "EXECUTE",
    "VERIFY_SECURITY",
    "required_arm",
    "served_arm",
    "epoch",
    "loaded_sha",
    "no_effect_witness"
  ],
  "schema": "B1.PD.EFFECT_SLOT@r3",
  "slot_id": "OBS-B1-A5"
}
```
**個別 NEG**：silent model fallback or missing served arm -> MODEL_REQUIRED_NOT_SERVED; alias and stale observations must close without world mutation。`OBS-B1-A5` 產生獨立 `operation_id:OBS-B1-A5`、`RAW:OBS-B1-A5`、`OR:OBS-B1-A5`；只允許事前 hash 相同且合法 dependency 的上游 receipt，不可當作自己的 effect receipt。
**閉合條件**：Source→PI-B1-A5→OBS-B1-A5→只一 ECP 或 NO_EFFECT→`TQ-CHILD-OBS-B1-A5-POS/NEG/EDGE/SEC`→checker。Missing current binding ⇒ `HOLD`，不得把本 schema 範本稱為 issued WorkOrder。

### PD-06｜WO-B1-A6 — EFFECT_JOURNAL / HOST_OPERATIONS

**原 r2 段落位置**：L445；**需求 Owner**：Effect Journal Owner；domain invariant：at-most-once effect; UNKNOWN_EFFECT reconciled before any next claim。
**作用程序**：prepare operation fingerprint -> CAS claim -> execute at most once -> read world state -> reconcile UNKNOWN without blind retry。
```json
{
  "atom": "B1-A6",
  "cross_effect_receipt_reuse": false,
  "current_binding_state": "HOLD_PENDING_TRUE_OWNER_AND_HOST",
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "EFFECT_JOURNAL",
  "needed_fields": [
    "subject_sha",
    "active_policy_epoch",
    "issuer_identity",
    "token_ref",
    "operation_id",
    "nonce",
    "ttl",
    "host_id",
    "expected_prestate_sha"
  ],
  "operation": "prepare operation fingerprint -> CAS claim -> execute at most once -> read world state -> reconcile UNKNOWN without blind retry",
  "permission": "OWNER_BOUND_TOKEN_REQUIRED",
  "readback_fields": [
    "operation_id",
    "preimage",
    "observed_postimage",
    "CAS_fence",
    "unknown_effect",
    "native_event_id",
    "operation_id",
    "effect_postimage_sha",
    "evidence_ref"
  ],
  "schema": "B1.PD.EFFECT_SLOT@r3",
  "slot_id": "WO-B1-A6"
}
```
**個別 NEG**：duplicate operation or retry-on-timeout -> UNKNOWN_EFFECT_REPLAY; expired/mismatched token or unknown effect -> NACK/RECONCILE。`WO-B1-A6` 產生獨立 `operation_id:WO-B1-A6`、`RAW:WO-B1-A6`、`OR:WO-B1-A6`；只允許事前 hash 相同且合法 dependency 的上游 receipt，不可當作自己的 effect receipt。
**閉合條件**：Source→PI-B1-A6→WO-B1-A6→只一 ECP 或 NO_EFFECT→`TQ-CHILD-WO-B1-A6-POS/NEG/EDGE/SEC`→checker。Missing current binding ⇒ `HOLD`，不得把本 schema 範本稱為 issued WorkOrder。

### PD-07｜OBS-B1-A7 — RAW_EVIDENCE / READ_ONLY_PROBE

**原 r2 段落位置**：L453；**需求 Owner**：Independent AO；domain invariant：distinct principal checker receipt matches same candidate and non-empty RAW。
**作用程序**：READ ONLY exact immutable_evidence source/host probe; no WorkOrder issue, no ECP, no rollback token。
```json
{
  "atom": "B1-A7",
  "cross_effect_receipt_reuse": false,
  "current_binding_state": "READ_ONLY_SCOPE_PENDING",
  "effect_class": "READ_ONLY_PROBE",
  "effect_key": "RAW_EVIDENCE",
  "needed_fields": [
    "subject_ref",
    "source_hash",
    "read_scope",
    "owner",
    "observation_time"
  ],
  "operation": "READ ONLY exact immutable_evidence source/host probe; no WorkOrder issue, no ECP, no rollback token",
  "permission": "NONE_READ_ONLY",
  "readback_fields": [
    "raw_receipt",
    "subject_sha",
    "candidate_sha",
    "checker_principal",
    "witness",
    "no_effect_witness"
  ],
  "schema": "B1.PD.EFFECT_SLOT@r3",
  "slot_id": "OBS-B1-A7"
}
```
**個別 NEG**：self-attested or mismatched witness -> RAW_OR_CHECKER_MISMATCH; alias and stale observations must close without world mutation。`OBS-B1-A7` 產生獨立 `operation_id:OBS-B1-A7`、`RAW:OBS-B1-A7`、`OR:OBS-B1-A7`；只允許事前 hash 相同且合法 dependency 的上游 receipt，不可當作自己的 effect receipt。
**閉合條件**：Source→PI-B1-A7→OBS-B1-A7→只一 ECP 或 NO_EFFECT→`TQ-CHILD-OBS-B1-A7-POS/NEG/EDGE/SEC`→checker。Missing current binding ⇒ `HOLD`，不得把本 schema 範本稱為 issued WorkOrder。

### PD-08｜WO-B1-A8 — NATIVE_HOTPATH / REPOSITORY_WRITE

**原 r2 段落位置**：L458；**需求 Owner**：Fabric/HGK Dev Owner；domain invariant：exact loaded callsite identified and scoped regression independent。
**作用程序**：Codex bounded patch ONLY for NATIVE_HOTPATH: identify actual import/callsite; freeze preimage and red test; scoped source diff; green+negative+rollback。
```json
{
  "atom": "B1-A8",
  "cross_effect_receipt_reuse": false,
  "current_binding_state": "HOLD_PENDING_TRUE_OWNER_AND_HOST",
  "effect_class": "REPOSITORY_WRITE",
  "effect_key": "NATIVE_HOTPATH",
  "needed_fields": [
    "real_root",
    "git_head",
    "status_porcelain_z",
    "writable_scope",
    "preimage_sha",
    "red_test",
    "candidate_sha",
    "authorization_ref"
  ],
  "operation": "Codex bounded patch ONLY for NATIVE_HOTPATH: identify actual import/callsite; freeze preimage and red test; scoped source diff; green+negative+rollback",
  "permission": "REPO_WRITER_SCOPE",
  "readback_fields": [
    "git_head_after",
    "changed_paths",
    "prepost_sha",
    "red_green_receipts",
    "rollback_readback"
  ],
  "schema": "B1.PD.EFFECT_SLOT@r3",
  "slot_id": "WO-B1-A8"
}
```
**個別 NEG**：write out of root, stale HEAD, changed untracked, or no preimage → deny; rollback only approved changed paths。`WO-B1-A8` 產生獨立 `operation_id:WO-B1-A8`、`RAW:WO-B1-A8`、`OR:WO-B1-A8`；只允許事前 hash 相同且合法 dependency 的上游 receipt，不可當作自己的 effect receipt。
**閉合條件**：Source→PI-B1-A8→WO-B1-A8→只一 ECP 或 NO_EFFECT→`TQ-CHILD-WO-B1-A8-POS/NEG/EDGE/SEC`→checker。Missing current binding ⇒ `HOLD`，不得把本 schema 範本稱為 issued WorkOrder。

### PD-09｜WO-B1-A9 — NATIVE_CONTINUATION / HOST_OPERATIONS

**原 r2 段落位置**：L466；**需求 Owner**：Hermes Continuation Owner；domain invariant：native successor advances after external revoke with new session and no external trigger。
**作用程序**：external session stop -> durable T2 post-turn native scheduler -> T3 checkpoint -> T4 resume under fresh native WO。
```json
{
  "atom": "B1-A9",
  "cross_effect_receipt_reuse": false,
  "current_binding_state": "HOLD_PENDING_TRUE_OWNER_AND_HOST",
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "NATIVE_CONTINUATION",
  "needed_fields": [
    "subject_sha",
    "active_policy_epoch",
    "issuer_identity",
    "token_ref",
    "operation_id",
    "nonce",
    "ttl",
    "host_id",
    "expected_prestate_sha"
  ],
  "operation": "external session stop -> durable T2 post-turn native scheduler -> T3 checkpoint -> T4 resume under fresh native WO",
  "permission": "OWNER_BOUND_TOKEN_REQUIRED",
  "readback_fields": [
    "external_revoke",
    "post_turn_source",
    "issued_wo",
    "native_claim",
    "session_exit",
    "native_event_id",
    "operation_id",
    "effect_postimage_sha",
    "evidence_ref"
  ],
  "schema": "B1.PD.EFFECT_SLOT@r3",
  "slot_id": "WO-B1-A9"
}
```
**個別 NEG**：external actor still triggering -> EXTERNAL_TRIGGER_STILL_REQUIRED; expired/mismatched token or unknown effect -> NACK/RECONCILE。`WO-B1-A9` 產生獨立 `operation_id:WO-B1-A9`、`RAW:WO-B1-A9`、`OR:WO-B1-A9`；只允許事前 hash 相同且合法 dependency 的上游 receipt，不可當作自己的 effect receipt。
**閉合條件**：Source→PI-B1-A9→WO-B1-A9→只一 ECP 或 NO_EFFECT→`TQ-CHILD-WO-B1-A9-POS/NEG/EDGE/SEC`→checker。Missing current binding ⇒ `HOLD`，不得把本 schema 範本稱為 issued WorkOrder。

### PD-10｜OBS-B1-B1 — SOURCE_ATOMS / READ_ONLY_PROBE

**原 r2 段落位置**：L474；**需求 Owner**：PIPD Source Owner；domain invariant：one-to-one source clause/owner/oracle joins; missing clause is HOLD。
**作用程序**：READ ONLY exact source_oracle source/host probe; no WorkOrder issue, no ECP, no rollback token。
```json
{
  "atom": "B1-B1",
  "cross_effect_receipt_reuse": false,
  "current_binding_state": "READ_ONLY_SCOPE_PENDING",
  "effect_class": "READ_ONLY_PROBE",
  "effect_key": "SOURCE_ATOMS",
  "needed_fields": [
    "subject_ref",
    "source_hash",
    "read_scope",
    "owner",
    "observation_time"
  ],
  "operation": "READ ONLY exact source_oracle source/host probe; no WorkOrder issue, no ECP, no rollback token",
  "permission": "NONE_READ_ONLY",
  "readback_fields": [
    "clause_sha",
    "atom_id",
    "source_owner",
    "domain_oracle",
    "trace_edges",
    "no_effect_witness"
  ],
  "schema": "B1.PD.EFFECT_SLOT@r3",
  "slot_id": "OBS-B1-B1"
}
```
**個別 NEG**：missing oracle or fabricated source -> PI_SOURCE_OR_ORACLE_UNBOUND; alias and stale observations must close without world mutation。`OBS-B1-B1` 產生獨立 `operation_id:OBS-B1-B1`、`RAW:OBS-B1-B1`、`OR:OBS-B1-B1`；只允許事前 hash 相同且合法 dependency 的上游 receipt，不可當作自己的 effect receipt。
**閉合條件**：Source→PI-B1-B1→OBS-B1-B1→只一 ECP 或 NO_EFFECT→`TQ-CHILD-OBS-B1-B1-POS/NEG/EDGE/SEC`→checker。Missing current binding ⇒ `HOLD`，不得把本 schema 範本稱為 issued WorkOrder。

### PD-11｜OBS-B1-B2 — REPO_CONTEXT / READ_ONLY_PROBE

**原 r2 段落位置**：L479；**需求 Owner**：PIPD PD Binder Owner；domain invariant：P4 PD only with actual repo root, HEAD and affected-only allowed write scope。
**作用程序**：READ ONLY exact repo_context_probe source/host probe; no WorkOrder issue, no ECP, no rollback token。
```json
{
  "atom": "B1-B2",
  "cross_effect_receipt_reuse": false,
  "current_binding_state": "READ_ONLY_SCOPE_PENDING",
  "effect_class": "READ_ONLY_PROBE",
  "effect_key": "REPO_CONTEXT",
  "needed_fields": [
    "subject_ref",
    "source_hash",
    "read_scope",
    "owner",
    "observation_time"
  ],
  "operation": "READ ONLY exact repo_context_probe source/host probe; no WorkOrder issue, no ECP, no rollback token",
  "permission": "NONE_READ_ONLY",
  "readback_fields": [
    "realpath",
    "head",
    "index",
    "untracked",
    "writable_scope",
    "currentness",
    "no_effect_witness"
  ],
  "schema": "B1.PD.EFFECT_SLOT@r3",
  "slot_id": "OBS-B1-B2"
}
```
**個別 NEG**：stale/escaping context -> REPO_CONTEXT_NOT_FRESH; alias and stale observations must close without world mutation。`OBS-B1-B2` 產生獨立 `operation_id:OBS-B1-B2`、`RAW:OBS-B1-B2`、`OR:OBS-B1-B2`；只允許事前 hash 相同且合法 dependency 的上游 receipt，不可當作自己的 effect receipt。
**閉合條件**：Source→PI-B1-B2→OBS-B1-B2→只一 ECP 或 NO_EFFECT→`TQ-CHILD-OBS-B1-B2-POS/NEG/EDGE/SEC`→checker。Missing current binding ⇒ `HOLD`，不得把本 schema 範本稱為 issued WorkOrder。

### PD-12｜WO-B1-B3-DEV — SBL_TO_NATIVE__DEV / REPOSITORY_WRITE

**原 r2 段落位置**：L484；**需求 Owner**：SBL Bridge & HGK Owner；domain invariant：DEV/OPS different WOs, separate source diff and real native ACK。
**作用程序**：Codex bounded patch ONLY for SBL_TO_NATIVE__DEV: identify actual import/callsite; freeze preimage and red test; scoped source diff; green+negative+rollback。
```json
{
  "atom": "B1-B3",
  "cross_effect_receipt_reuse": false,
  "current_binding_state": "HOLD_PENDING_TRUE_OWNER_AND_HOST",
  "effect_class": "REPOSITORY_WRITE",
  "effect_key": "SBL_TO_NATIVE__DEV",
  "needed_fields": [
    "real_root",
    "git_head",
    "status_porcelain_z",
    "writable_scope",
    "preimage_sha",
    "red_test",
    "candidate_sha",
    "authorization_ref"
  ],
  "operation": "Codex bounded patch ONLY for SBL_TO_NATIVE__DEV: identify actual import/callsite; freeze preimage and red test; scoped source diff; green+negative+rollback",
  "permission": "REPO_WRITER_SCOPE",
  "readback_fields": [
    "git_head_after",
    "changed_paths",
    "prepost_sha",
    "red_green_receipts",
    "rollback_readback"
  ],
  "schema": "B1.PD.EFFECT_SLOT@r3",
  "slot_id": "WO-B1-B3-DEV"
}
```
**個別 NEG**：write out of root, stale HEAD, changed untracked, or no preimage → deny; rollback only approved changed paths。`WO-B1-B3-DEV` 產生獨立 `operation_id:WO-B1-B3-DEV`、`RAW:WO-B1-B3-DEV`、`OR:WO-B1-B3-DEV`；只允許事前 hash 相同且合法 dependency 的上游 receipt，不可當作自己的 effect receipt。
**閉合條件**：Source→PI-B1-B3→WO-B1-B3-DEV→只一 ECP 或 NO_EFFECT→`TQ-CHILD-WO-B1-B3-DEV-POS/NEG/EDGE/SEC`→checker。Missing current binding ⇒ `HOLD`，不得把本 schema 範本稱為 issued WorkOrder。

### PD-13｜WO-B1-B3-OPS — SBL_TO_NATIVE__OPS / HOST_OPERATIONS

**原 r2 段落位置**：L492；**需求 Owner**：SBL Bridge & HGK Owner；domain invariant：DEV/OPS different WOs, separate source diff and real native ACK。
**作用程序**：consume DEV handoff digest -> native receiver validates ABI; SBL never signs issuer event。
```json
{
  "atom": "B1-B3",
  "cross_effect_receipt_reuse": false,
  "current_binding_state": "HOLD_PENDING_TRUE_OWNER_AND_HOST",
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "SBL_TO_NATIVE__OPS",
  "needed_fields": [
    "subject_sha",
    "active_policy_epoch",
    "issuer_identity",
    "token_ref",
    "operation_id",
    "nonce",
    "ttl",
    "host_id",
    "expected_prestate_sha"
  ],
  "operation": "consume DEV handoff digest -> native receiver validates ABI; SBL never signs issuer event",
  "permission": "OWNER_BOUND_TOKEN_REQUIRED",
  "readback_fields": [
    "sbl_entry",
    "candidate",
    "dev_diff",
    "ops_handoff",
    "native_receiver_ack",
    "native_event_id",
    "operation_id",
    "effect_postimage_sha",
    "evidence_ref"
  ],
  "schema": "B1.PD.EFFECT_SLOT@r3",
  "slot_id": "WO-B1-B3-OPS"
}
```
**個別 NEG**：second issuer or shared receipt -> SECOND_ISSUER_OR_MIXED_EFFECT; expired/mismatched token or unknown effect -> NACK/RECONCILE。`WO-B1-B3-OPS` 產生獨立 `operation_id:WO-B1-B3-OPS`、`RAW:WO-B1-B3-OPS`、`OR:WO-B1-B3-OPS`；只允許事前 hash 相同且合法 dependency 的上游 receipt，不可當作自己的 effect receipt。
**閉合條件**：Source→PI-B1-B3→WO-B1-B3-OPS→只一 ECP 或 NO_EFFECT→`TQ-CHILD-WO-B1-B3-OPS-POS/NEG/EDGE/SEC`→checker。Missing current binding ⇒ `HOLD`，不得把本 schema 範本稱為 issued WorkOrder。

### PD-14｜WO-B1-B4-DEV — ECP_SELECTOR__DEV / REPOSITORY_WRITE

**原 r2 段落位置**：L500；**需求 Owner**：HGK ECP Selection Owner；domain invariant：one active ECP per WO; split iff distinct effects。
**作用程序**：Codex bounded patch ONLY for ECP_SELECTOR__DEV: identify actual import/callsite; freeze preimage and red test; scoped source diff; green+negative+rollback。
```json
{
  "atom": "B1-B4",
  "cross_effect_receipt_reuse": false,
  "current_binding_state": "HOLD_PENDING_TRUE_OWNER_AND_HOST",
  "effect_class": "REPOSITORY_WRITE",
  "effect_key": "ECP_SELECTOR__DEV",
  "needed_fields": [
    "real_root",
    "git_head",
    "status_porcelain_z",
    "writable_scope",
    "preimage_sha",
    "red_test",
    "candidate_sha",
    "authorization_ref"
  ],
  "operation": "Codex bounded patch ONLY for ECP_SELECTOR__DEV: identify actual import/callsite; freeze preimage and red test; scoped source diff; green+negative+rollback",
  "permission": "REPO_WRITER_SCOPE",
  "readback_fields": [
    "git_head_after",
    "changed_paths",
    "prepost_sha",
    "red_green_receipts",
    "rollback_readback"
  ],
  "schema": "B1.PD.EFFECT_SLOT@r3",
  "slot_id": "WO-B1-B4-DEV"
}
```
**個別 NEG**：write out of root, stale HEAD, changed untracked, or no preimage → deny; rollback only approved changed paths。`WO-B1-B4-DEV` 產生獨立 `operation_id:WO-B1-B4-DEV`、`RAW:WO-B1-B4-DEV`、`OR:WO-B1-B4-DEV`；只允許事前 hash 相同且合法 dependency 的上游 receipt，不可當作自己的 effect receipt。
**閉合條件**：Source→PI-B1-B4→WO-B1-B4-DEV→只一 ECP 或 NO_EFFECT→`TQ-CHILD-WO-B1-B4-DEV-POS/NEG/EDGE/SEC`→checker。Missing current binding ⇒ `HOLD`，不得把本 schema 範本稱為 issued WorkOrder。

### PD-15｜WO-B1-B4-OPS — ECP_SELECTOR__OPS / HOST_OPERATIONS

**原 r2 段落位置**：L508；**需求 Owner**：HGK ECP Selection Owner；domain invariant：one active ECP per WO; split iff distinct effects。
**作用程序**：consume DEV selector correction receipt -> native Issuer enforces one active ECP and one effect class。
```json
{
  "atom": "B1-B4",
  "cross_effect_receipt_reuse": false,
  "current_binding_state": "HOLD_PENDING_TRUE_OWNER_AND_HOST",
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "ECP_SELECTOR__OPS",
  "needed_fields": [
    "subject_sha",
    "active_policy_epoch",
    "issuer_identity",
    "token_ref",
    "operation_id",
    "nonce",
    "ttl",
    "host_id",
    "expected_prestate_sha"
  ],
  "operation": "consume DEV selector correction receipt -> native Issuer enforces one active ECP and one effect class",
  "permission": "OWNER_BOUND_TOKEN_REQUIRED",
  "readback_fields": [
    "wo_id",
    "effect_class",
    "active_ecp_count",
    "issuer_ack",
    "native_event_id",
    "operation_id",
    "effect_postimage_sha",
    "evidence_ref"
  ],
  "schema": "B1.PD.EFFECT_SLOT@r3",
  "slot_id": "WO-B1-B4-OPS"
}
```
**個別 NEG**：two active ECPs/unknown class -> ECP_MULTIPLE_OR_CLASS_UNKNOWN; expired/mismatched token or unknown effect -> NACK/RECONCILE。`WO-B1-B4-OPS` 產生獨立 `operation_id:WO-B1-B4-OPS`、`RAW:WO-B1-B4-OPS`、`OR:WO-B1-B4-OPS`；只允許事前 hash 相同且合法 dependency 的上游 receipt，不可當作自己的 effect receipt。
**閉合條件**：Source→PI-B1-B4→WO-B1-B4-OPS→只一 ECP 或 NO_EFFECT→`TQ-CHILD-WO-B1-B4-OPS-POS/NEG/EDGE/SEC`→checker。Missing current binding ⇒ `HOLD`，不得把本 schema 範本稱為 issued WorkOrder。

### PD-16｜WO-B1-B5-DEV — THREE_SP__DEV / REPOSITORY_WRITE

**原 r2 段落位置**：L516；**需求 Owner**：SP Host Owner；domain invariant：three host identities and isolated permission readbacks; ZIP-only not pass。
**作用程序**：Codex bounded patch ONLY for THREE_SP__DEV: identify actual import/callsite; freeze preimage and red test; scoped source diff; green+negative+rollback。
```json
{
  "atom": "B1-B5",
  "cross_effect_receipt_reuse": false,
  "current_binding_state": "HOLD_PENDING_TRUE_OWNER_AND_HOST",
  "effect_class": "REPOSITORY_WRITE",
  "effect_key": "THREE_SP__DEV",
  "needed_fields": [
    "real_root",
    "git_head",
    "status_porcelain_z",
    "writable_scope",
    "preimage_sha",
    "red_test",
    "candidate_sha",
    "authorization_ref"
  ],
  "operation": "Codex bounded patch ONLY for THREE_SP__DEV: identify actual import/callsite; freeze preimage and red test; scoped source diff; green+negative+rollback",
  "permission": "REPO_WRITER_SCOPE",
  "readback_fields": [
    "git_head_after",
    "changed_paths",
    "prepost_sha",
    "red_green_receipts",
    "rollback_readback"
  ],
  "schema": "B1.PD.EFFECT_SLOT@r3",
  "slot_id": "WO-B1-B5-DEV"
}
```
**個別 NEG**：write out of root, stale HEAD, changed untracked, or no preimage → deny; rollback only approved changed paths。`WO-B1-B5-DEV` 產生獨立 `operation_id:WO-B1-B5-DEV`、`RAW:WO-B1-B5-DEV`、`OR:WO-B1-B5-DEV`；只允許事前 hash 相同且合法 dependency 的上游 receipt，不可當作自己的 effect receipt。
**閉合條件**：Source→PI-B1-B5→WO-B1-B5-DEV→只一 ECP 或 NO_EFFECT→`TQ-CHILD-WO-B1-B5-DEV-POS/NEG/EDGE/SEC`→checker。Missing current binding ⇒ `HOLD`，不得把本 schema 範本稱為 issued WorkOrder。

### PD-17｜WO-B1-B5-OPS — THREE_SP__OPS / HOST_OPERATIONS

**原 r2 段落位置**：L524；**需求 Owner**：SP Host Owner；domain invariant：three host identities and isolated permission readbacks; ZIP-only not pass。
**作用程序**：consume DEV packaging receipt -> host loader installs/loads 3 independent SP identities and proves actual invoke + deny。
```json
{
  "atom": "B1-B5",
  "cross_effect_receipt_reuse": false,
  "current_binding_state": "HOLD_PENDING_TRUE_OWNER_AND_HOST",
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "THREE_SP__OPS",
  "needed_fields": [
    "subject_sha",
    "active_policy_epoch",
    "issuer_identity",
    "token_ref",
    "operation_id",
    "nonce",
    "ttl",
    "host_id",
    "expected_prestate_sha"
  ],
  "operation": "consume DEV packaging receipt -> host loader installs/loads 3 independent SP identities and proves actual invoke + deny",
  "permission": "OWNER_BOUND_TOKEN_REQUIRED",
  "readback_fields": [
    "TPM_SP",
    "COMMANDER_SP",
    "CHALLENGE_SP",
    "host_invocation",
    "loaded_sha",
    "native_event_id",
    "operation_id",
    "effect_postimage_sha",
    "evidence_ref"
  ],
  "schema": "B1.PD.EFFECT_SLOT@r3",
  "slot_id": "WO-B1-B5-OPS"
}
```
**個別 NEG**：missing host invocation -> SP_HOST_LOAD_UNPROVEN; expired/mismatched token or unknown effect -> NACK/RECONCILE。`WO-B1-B5-OPS` 產生獨立 `operation_id:WO-B1-B5-OPS`、`RAW:WO-B1-B5-OPS`、`OR:WO-B1-B5-OPS`；只允許事前 hash 相同且合法 dependency 的上游 receipt，不可當作自己的 effect receipt。
**閉合條件**：Source→PI-B1-B5→WO-B1-B5-OPS→只一 ECP 或 NO_EFFECT→`TQ-CHILD-WO-B1-B5-OPS-POS/NEG/EDGE/SEC`→checker。Missing current binding ⇒ `HOLD`，不得把本 schema 範本稱為 issued WorkOrder。

### PD-18｜WO-B1-B6-USER — TODO_PERSISTENCE / USER_DATA_EFFECT

**原 r2 段落位置**：L532；**需求 Owner**：SBL CLI/User Data Owner；domain invariant：isolated store add -> separate list -> remove --id -> zero residue。
**作用程序**：SBL existing sbl-todo --data-dir <isolated> init/add/list/remove --id <ACTUAL_TASK_ID>; user consent and separate USER issuer decision, no OPS/DEV ECP。
```json
{
  "atom": "B1-B6",
  "cross_effect_receipt_reuse": false,
  "current_binding_state": "HOLD_PENDING_TRUE_OWNER_AND_HOST",
  "effect_class": "USER_DATA_EFFECT",
  "effect_key": "TODO_PERSISTENCE",
  "needed_fields": [
    "consenting_principal",
    "isolated_data_dir",
    "sbl_todo_binary_sha",
    "user_effect_issuer_ref",
    "record_id",
    "prestate_snapshot",
    "consent_scope"
  ],
  "operation": "SBL existing sbl-todo --data-dir <isolated> init/add/list/remove --id <ACTUAL_TASK_ID>; user consent and separate USER issuer decision, no OPS/DEV ECP",
  "permission": "USER_CONSENT_AND_USER_ISSUER",
  "readback_fields": [
    "task_id",
    "add_ack",
    "list_json",
    "delete_ack",
    "record_version",
    "uninstall_residue"
  ],
  "schema": "B1.PD.EFFECT_SLOT@r3",
  "slot_id": "WO-B1-B6-USER"
}
```
**個別 NEG**：missing user consent/issuer, wrong data_dir, duplicated id → no effect / distinct NoFitReceipt。`WO-B1-B6-USER` 產生獨立 `operation_id:WO-B1-B6-USER`、`RAW:WO-B1-B6-USER`、`OR:WO-B1-B6-USER`；只允許事前 hash 相同且合法 dependency 的上游 receipt，不可當作自己的 effect receipt。
**閉合條件**：Source→PI-B1-B6→WO-B1-B6-USER→只一 ECP 或 NO_EFFECT→`TQ-CHILD-WO-B1-B6-USER-POS/NEG/EDGE/SEC`→checker。Missing current binding ⇒ `HOLD`，不得把本 schema 範本稱為 issued WorkOrder。

### PD-19｜OBS-B1-B7 — NOFIT_ROUTE / READ_ONLY_PROBE

**原 r2 段落位置**：L540；**需求 Owner**：PIPD TechnologyAdmission Owner；domain invariant：deterministic capability NOFIT with user-readable reason and zero unauthorized delta。
**作用程序**：READ ONLY exact no_fit source/host probe; no WorkOrder issue, no ECP, no rollback token。
```json
{
  "atom": "B1-B7",
  "cross_effect_receipt_reuse": false,
  "current_binding_state": "READ_ONLY_SCOPE_PENDING",
  "effect_class": "READ_ONLY_PROBE",
  "effect_key": "NOFIT_ROUTE",
  "needed_fields": [
    "subject_ref",
    "source_hash",
    "read_scope",
    "owner",
    "observation_time"
  ],
  "operation": "READ ONLY exact no_fit source/host probe; no WorkOrder issue, no ECP, no rollback token",
  "permission": "NONE_READ_ONLY",
  "readback_fields": [
    "required_capability",
    "host",
    "provider_off",
    "owner",
    "refusal",
    "zero_effect",
    "no_effect_witness"
  ],
  "schema": "B1.PD.EFFECT_SLOT@r3",
  "slot_id": "OBS-B1-B7"
}
```
**個別 NEG**：silent fallback -> NOFIT_OR_PROVIDER_OFF; alias and stale observations must close without world mutation。`OBS-B1-B7` 產生獨立 `operation_id:OBS-B1-B7`、`RAW:OBS-B1-B7`、`OR:OBS-B1-B7`；只允許事前 hash 相同且合法 dependency 的上游 receipt，不可當作自己的 effect receipt。
**閉合條件**：Source→PI-B1-B7→OBS-B1-B7→只一 ECP 或 NO_EFFECT→`TQ-CHILD-OBS-B1-B7-POS/NEG/EDGE/SEC`→checker。Missing current binding ⇒ `HOLD`，不得把本 schema 範本稱為 issued WorkOrder。

### PD-20｜OBS-B1-B8 — TRACE_GRAPH / READ_ONLY_PROBE

**原 r2 段落位置**：L545；**需求 Owner**：PIPD Trace Owner；domain invariant：nonempty exact IDs and hashes, zero orphans and zero bad edges。
**作用程序**：READ ONLY exact trace_closure source/host probe; no WorkOrder issue, no ECP, no rollback token。
```json
{
  "atom": "B1-B8",
  "cross_effect_receipt_reuse": false,
  "current_binding_state": "READ_ONLY_SCOPE_PENDING",
  "effect_class": "READ_ONLY_PROBE",
  "effect_key": "TRACE_GRAPH",
  "needed_fields": [
    "subject_ref",
    "source_hash",
    "read_scope",
    "owner",
    "observation_time"
  ],
  "operation": "READ ONLY exact trace_closure source/host probe; no WorkOrder issue, no ECP, no rollback token",
  "permission": "NONE_READ_ONLY",
  "readback_fields": [
    "pi",
    "pd",
    "cc",
    "ecp",
    "wo",
    "tqaep",
    "raw",
    "checker",
    "edges",
    "no_effect_witness"
  ],
  "schema": "B1.PD.EFFECT_SLOT@r3",
  "slot_id": "OBS-B1-B8"
}
```
**個別 NEG**：foreign/sibling witness -> TRACE_CLOSURE_FAIL; alias and stale observations must close without world mutation。`OBS-B1-B8` 產生獨立 `operation_id:OBS-B1-B8`、`RAW:OBS-B1-B8`、`OR:OBS-B1-B8`；只允許事前 hash 相同且合法 dependency 的上游 receipt，不可當作自己的 effect receipt。
**閉合條件**：Source→PI-B1-B8→OBS-B1-B8→只一 ECP 或 NO_EFFECT→`TQ-CHILD-OBS-B1-B8-POS/NEG/EDGE/SEC`→checker。Missing current binding ⇒ `HOLD`，不得把本 schema 範本稱為 issued WorkOrder。

### PD-21｜OBS-B1-B9 — R15_COVERAGE / READ_ONLY_PROBE

**原 r2 段落位置**：L550；**需求 Owner**：SBL Product Owner；domain invariant：949 unique 18-family IDs, 66/254/629 and source-specific disposition。
**作用程序**：READ ONLY exact baseline_denominator source/host probe; no WorkOrder issue, no ECP, no rollback token。
```json
{
  "atom": "B1-B9",
  "cross_effect_receipt_reuse": false,
  "current_binding_state": "READ_ONLY_SCOPE_PENDING",
  "effect_class": "READ_ONLY_PROBE",
  "effect_key": "R15_COVERAGE",
  "needed_fields": [
    "subject_ref",
    "source_hash",
    "read_scope",
    "owner",
    "observation_time"
  ],
  "operation": "READ ONLY exact baseline_denominator source/host probe; no WorkOrder issue, no ECP, no rollback token",
  "permission": "NONE_READ_ONLY",
  "readback_fields": [
    "949_ids",
    "18_families",
    "required",
    "conditional",
    "deferred",
    "owners",
    "no_effect_witness"
  ],
  "schema": "B1.PD.EFFECT_SLOT@r3",
  "slot_id": "OBS-B1-B9"
}
```
**個別 NEG**：missing ID or generic proxy pass -> R15_DENOMINATOR_SHRINK; alias and stale observations must close without world mutation。`OBS-B1-B9` 產生獨立 `operation_id:OBS-B1-B9`、`RAW:OBS-B1-B9`、`OR:OBS-B1-B9`；只允許事前 hash 相同且合法 dependency 的上游 receipt，不可當作自己的 effect receipt。
**閉合條件**：Source→PI-B1-B9→OBS-B1-B9→只一 ECP 或 NO_EFFECT→`TQ-CHILD-OBS-B1-B9-POS/NEG/EDGE/SEC`→checker。Missing current binding ⇒ `HOLD`，不得把本 schema 範本稱為 issued WorkOrder。

### PD-22｜WO-B1-C1 — FABRIC_PROMOTION / HOST_OPERATIONS

**原 r2 段落位置**：L555；**需求 Owner**：Fabric Activation Owner；domain invariant：independent stage approval; active and loaded exact digest; consumer projection ACK。
**作用程序**：Fabric Owner stage policy+approval -> native activate -> independent active/loaded SHA reader -> rollback to previous generation。
```json
{
  "atom": "B1-C1",
  "cross_effect_receipt_reuse": false,
  "current_binding_state": "HOLD_PENDING_TRUE_OWNER_AND_HOST",
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "FABRIC_PROMOTION",
  "needed_fields": [
    "subject_sha",
    "active_policy_epoch",
    "issuer_identity",
    "token_ref",
    "operation_id",
    "nonce",
    "ttl",
    "host_id",
    "expected_prestate_sha"
  ],
  "operation": "Fabric Owner stage policy+approval -> native activate -> independent active/loaded SHA reader -> rollback to previous generation",
  "permission": "OWNER_BOUND_TOKEN_REQUIRED",
  "readback_fields": [
    "approved_stage",
    "active_policy",
    "loaded_sha",
    "consumer_trace",
    "rollback",
    "native_event_id",
    "operation_id",
    "effect_postimage_sha",
    "evidence_ref"
  ],
  "schema": "B1.PD.EFFECT_SLOT@r3",
  "slot_id": "WO-B1-C1"
}
```
**個別 NEG**：stage mistaken as active or missing consumer -> FABRIC_LOADED_ABSENT; expired/mismatched token or unknown effect -> NACK/RECONCILE。`WO-B1-C1` 產生獨立 `operation_id:WO-B1-C1`、`RAW:WO-B1-C1`、`OR:WO-B1-C1`；只允許事前 hash 相同且合法 dependency 的上游 receipt，不可當作自己的 effect receipt。
**閉合條件**：Source→PI-B1-C1→WO-B1-C1→只一 ECP 或 NO_EFFECT→`TQ-CHILD-WO-B1-C1-POS/NEG/EDGE/SEC`→checker。Missing current binding ⇒ `HOLD`，不得把本 schema 範本稱為 issued WorkOrder。

### PD-23｜WO-B1-C2 — HGK_GWO / HOST_OPERATIONS

**原 r2 段落位置**：L563；**需求 Owner**：HGK Runtime Owner；domain invariant：true SBL entry -> native HGK issuer -> Hermes lease -> reversible observable result。
**作用程序**：SBL real entry -> HGK typed request -> native issue+durable queue -> Hermes worker outcome -> independent readback。
```json
{
  "atom": "B1-C2",
  "cross_effect_receipt_reuse": false,
  "current_binding_state": "HOLD_PENDING_TRUE_OWNER_AND_HOST",
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "HGK_GWO",
  "needed_fields": [
    "subject_sha",
    "active_policy_epoch",
    "issuer_identity",
    "token_ref",
    "operation_id",
    "nonce",
    "ttl",
    "host_id",
    "expected_prestate_sha"
  ],
  "operation": "SBL real entry -> HGK typed request -> native issue+durable queue -> Hermes worker outcome -> independent readback",
  "permission": "OWNER_BOUND_TOKEN_REQUIRED",
  "readback_fields": [
    "sbl_start",
    "issued_wo",
    "issuer",
    "lease",
    "worker_receipt",
    "readback",
    "native_event_id",
    "operation_id",
    "effect_postimage_sha",
    "evidence_ref"
  ],
  "schema": "B1.PD.EFFECT_SLOT@r3",
  "slot_id": "WO-B1-C2"
}
```
**個別 NEG**：ghost worker/forged permit -> GWO_HGK_NOT_NATIVE; expired/mismatched token or unknown effect -> NACK/RECONCILE。`WO-B1-C2` 產生獨立 `operation_id:WO-B1-C2`、`RAW:WO-B1-C2`、`OR:WO-B1-C2`；只允許事前 hash 相同且合法 dependency 的上游 receipt，不可當作自己的 effect receipt。
**閉合條件**：Source→PI-B1-C2→WO-B1-C2→只一 ECP 或 NO_EFFECT→`TQ-CHILD-WO-B1-C2-POS/NEG/EDGE/SEC`→checker。Missing current binding ⇒ `HOLD`，不得把本 schema 範本稱為 issued WorkOrder。

### PD-24｜WO-B1-C3-OPS — SBL_GWO__INSTALL / HOST_OPERATIONS

**原 r2 段落位置**：L571；**需求 Owner**：SBL Product/User Owner；domain invariant：separate Host install and USER effects with independent readbacks。
**作用程序**：install allowed SBL stack in isolated root -> doctor -> status -> uninstall+residue readback。
```json
{
  "atom": "B1-C3",
  "cross_effect_receipt_reuse": false,
  "current_binding_state": "HOLD_PENDING_TRUE_OWNER_AND_HOST",
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "SBL_GWO__INSTALL",
  "needed_fields": [
    "subject_sha",
    "active_policy_epoch",
    "issuer_identity",
    "token_ref",
    "operation_id",
    "nonce",
    "ttl",
    "host_id",
    "expected_prestate_sha"
  ],
  "operation": "install allowed SBL stack in isolated root -> doctor -> status -> uninstall+residue readback",
  "permission": "OWNER_BOUND_TOKEN_REQUIRED",
  "readback_fields": [
    "sbl_entry",
    "stack_install",
    "consent",
    "todo_add",
    "list",
    "delete",
    "uninstall",
    "native_event_id",
    "operation_id",
    "effect_postimage_sha",
    "evidence_ref"
  ],
  "schema": "B1.PD.EFFECT_SLOT@r3",
  "slot_id": "WO-B1-C3-OPS"
}
```
**個別 NEG**：install count used as add success -> GWO_SBL_USER_STATE_UNPROVEN; expired/mismatched token or unknown effect -> NACK/RECONCILE。`WO-B1-C3-OPS` 產生獨立 `operation_id:WO-B1-C3-OPS`、`RAW:WO-B1-C3-OPS`、`OR:WO-B1-C3-OPS`；只允許事前 hash 相同且合法 dependency 的上游 receipt，不可當作自己的 effect receipt。
**閉合條件**：Source→PI-B1-C3→WO-B1-C3-OPS→只一 ECP 或 NO_EFFECT→`TQ-CHILD-WO-B1-C3-OPS-POS/NEG/EDGE/SEC`→checker。Missing current binding ⇒ `HOLD`，不得把本 schema 範本稱為 issued WorkOrder。

### PD-25｜WO-B1-C3-USER — SBL_GWO__USER / USER_DATA_EFFECT

**原 r2 段落位置**：L579；**需求 Owner**：SBL Product/User Owner；domain invariant：separate Host install and USER effects with independent readbacks。
**作用程序**：SBL existing sbl-todo --data-dir <isolated> init/add/list/remove --id <ACTUAL_TASK_ID>; user consent and separate USER issuer decision, no OPS/DEV ECP。
```json
{
  "atom": "B1-C3",
  "cross_effect_receipt_reuse": false,
  "current_binding_state": "HOLD_PENDING_TRUE_OWNER_AND_HOST",
  "effect_class": "USER_DATA_EFFECT",
  "effect_key": "SBL_GWO__USER",
  "needed_fields": [
    "consenting_principal",
    "isolated_data_dir",
    "sbl_todo_binary_sha",
    "user_effect_issuer_ref",
    "record_id",
    "prestate_snapshot",
    "consent_scope"
  ],
  "operation": "SBL existing sbl-todo --data-dir <isolated> init/add/list/remove --id <ACTUAL_TASK_ID>; user consent and separate USER issuer decision, no OPS/DEV ECP",
  "permission": "USER_CONSENT_AND_USER_ISSUER",
  "readback_fields": [
    "task_id",
    "add_ack",
    "list_json",
    "delete_ack",
    "record_version",
    "uninstall_residue"
  ],
  "schema": "B1.PD.EFFECT_SLOT@r3",
  "slot_id": "WO-B1-C3-USER"
}
```
**個別 NEG**：missing user consent/issuer, wrong data_dir, duplicated id → no effect / distinct NoFitReceipt。`WO-B1-C3-USER` 產生獨立 `operation_id:WO-B1-C3-USER`、`RAW:WO-B1-C3-USER`、`OR:WO-B1-C3-USER`；只允許事前 hash 相同且合法 dependency 的上游 receipt，不可當作自己的 effect receipt。
**閉合條件**：Source→PI-B1-C3→WO-B1-C3-USER→只一 ECP 或 NO_EFFECT→`TQ-CHILD-WO-B1-C3-USER-POS/NEG/EDGE/SEC`→checker。Missing current binding ⇒ `HOLD`，不得把本 schema 範本稱為 issued WorkOrder。

### PD-26｜WO-B1-C4 — EXTERNAL_GRANT / HOST_OPERATIONS

**原 r2 段落位置**：L587；**需求 Owner**：External Delegation Owner；domain invariant：bounded external grant and no residual capability on revoke。
**作用程序**：grant scoped principal with TTL and nonce -> revoke -> check post-revoke rejection and reconcile in-flight。
```json
{
  "atom": "B1-C4",
  "cross_effect_receipt_reuse": false,
  "current_binding_state": "HOLD_PENDING_TRUE_OWNER_AND_HOST",
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "EXTERNAL_GRANT",
  "needed_fields": [
    "subject_sha",
    "active_policy_epoch",
    "issuer_identity",
    "token_ref",
    "operation_id",
    "nonce",
    "ttl",
    "host_id",
    "expected_prestate_sha"
  ],
  "operation": "grant scoped principal with TTL and nonce -> revoke -> check post-revoke rejection and reconcile in-flight",
  "permission": "OWNER_BOUND_TOKEN_REQUIRED",
  "readback_fields": [
    "owner_scope",
    "ttl",
    "principal",
    "revocation",
    "zero_scope_escape",
    "native_event_id",
    "operation_id",
    "effect_postimage_sha",
    "evidence_ref"
  ],
  "schema": "B1.PD.EFFECT_SLOT@r3",
  "slot_id": "WO-B1-C4"
}
```
**個別 NEG**：scope expansion -> EXTERNAL_SCOPE_ESCAPED; expired/mismatched token or unknown effect -> NACK/RECONCILE。`WO-B1-C4` 產生獨立 `operation_id:WO-B1-C4`、`RAW:WO-B1-C4`、`OR:WO-B1-C4`；只允許事前 hash 相同且合法 dependency 的上游 receipt，不可當作自己的 effect receipt。
**閉合條件**：Source→PI-B1-C4→WO-B1-C4→只一 ECP 或 NO_EFFECT→`TQ-CHILD-WO-B1-C4-POS/NEG/EDGE/SEC`→checker。Missing current binding ⇒ `HOLD`，不得把本 schema 範本稱為 issued WorkOrder。

### PD-27｜WO-B1-C5 — CODEX_MINPATCH / REPOSITORY_WRITE

**原 r2 段落位置**：L595；**需求 Owner**：Codex Maker + Dev Owner；domain invariant：only affected files changed and full regression independent。
**作用程序**：Codex bounded patch ONLY for CODEX_MINPATCH: identify actual import/callsite; freeze preimage and red test; scoped source diff; green+negative+rollback。
```json
{
  "atom": "B1-C5",
  "cross_effect_receipt_reuse": false,
  "current_binding_state": "HOLD_PENDING_TRUE_OWNER_AND_HOST",
  "effect_class": "REPOSITORY_WRITE",
  "effect_key": "CODEX_MINPATCH",
  "needed_fields": [
    "real_root",
    "git_head",
    "status_porcelain_z",
    "writable_scope",
    "preimage_sha",
    "red_test",
    "candidate_sha",
    "authorization_ref"
  ],
  "operation": "Codex bounded patch ONLY for CODEX_MINPATCH: identify actual import/callsite; freeze preimage and red test; scoped source diff; green+negative+rollback",
  "permission": "REPO_WRITER_SCOPE",
  "readback_fields": [
    "git_head_after",
    "changed_paths",
    "prepost_sha",
    "red_green_receipts",
    "rollback_readback"
  ],
  "schema": "B1.PD.EFFECT_SLOT@r3",
  "slot_id": "WO-B1-C5"
}
```
**個別 NEG**：write out of root, stale HEAD, changed untracked, or no preimage → deny; rollback only approved changed paths。`WO-B1-C5` 產生獨立 `operation_id:WO-B1-C5`、`RAW:WO-B1-C5`、`OR:WO-B1-C5`；只允許事前 hash 相同且合法 dependency 的上游 receipt，不可當作自己的 effect receipt。
**閉合條件**：Source→PI-B1-C5→WO-B1-C5→只一 ECP 或 NO_EFFECT→`TQ-CHILD-WO-B1-C5-POS/NEG/EDGE/SEC`→checker。Missing current binding ⇒ `HOLD`，不得把本 schema 範本稱為 issued WorkOrder。

### PD-28｜WO-B1-C6 — REVOKE_RACE / HOST_OPERATIONS

**原 r2 段落位置**：L603；**需求 Owner**：Revoke/Effect Owner；domain invariant：post-revoke use fails before spawn; existing effects reconciled。
**作用程序**：revoke current grant -> attempt old token -> ensure zero new spawn and record denied native event。
```json
{
  "atom": "B1-C6",
  "cross_effect_receipt_reuse": false,
  "current_binding_state": "HOLD_PENDING_TRUE_OWNER_AND_HOST",
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "REVOKE_RACE",
  "needed_fields": [
    "subject_sha",
    "active_policy_epoch",
    "issuer_identity",
    "token_ref",
    "operation_id",
    "nonce",
    "ttl",
    "host_id",
    "expected_prestate_sha"
  ],
  "operation": "revoke current grant -> attempt old token -> ensure zero new spawn and record denied native event",
  "permission": "OWNER_BOUND_TOKEN_REQUIRED",
  "readback_fields": [
    "old_nonce",
    "revocation_epoch",
    "attempt_after_revoke",
    "denied_effect",
    "native_event_id",
    "operation_id",
    "effect_postimage_sha",
    "evidence_ref"
  ],
  "schema": "B1.PD.EFFECT_SLOT@r3",
  "slot_id": "WO-B1-C6"
}
```
**個別 NEG**：reused token after revoke -> REVOKED_TOKEN_REPLAY; expired/mismatched token or unknown effect -> NACK/RECONCILE。`WO-B1-C6` 產生獨立 `operation_id:WO-B1-C6`、`RAW:WO-B1-C6`、`OR:WO-B1-C6`；只允許事前 hash 相同且合法 dependency 的上游 receipt，不可當作自己的 effect receipt。
**閉合條件**：Source→PI-B1-C6→WO-B1-C6→只一 ECP 或 NO_EFFECT→`TQ-CHILD-WO-B1-C6-POS/NEG/EDGE/SEC`→checker。Missing current binding ⇒ `HOLD`，不得把本 schema 範本稱為 issued WorkOrder。

### PD-29｜OBS-B1-C7 — FOUR_LAYER_ID / READ_ONLY_PROBE

**原 r2 段落位置**：L611；**需求 Owner**：Native Loader Owner；domain invariant：all four identity layers tied to same subject, not merely file on disk。
**作用程序**：READ ONLY exact loaded_identity source/host probe; no WorkOrder issue, no ECP, no rollback token。
```json
{
  "atom": "B1-C7",
  "cross_effect_receipt_reuse": false,
  "current_binding_state": "READ_ONLY_SCOPE_PENDING",
  "effect_class": "READ_ONLY_PROBE",
  "effect_key": "FOUR_LAYER_ID",
  "needed_fields": [
    "subject_ref",
    "source_hash",
    "read_scope",
    "owner",
    "observation_time"
  ],
  "operation": "READ ONLY exact loaded_identity source/host probe; no WorkOrder issue, no ECP, no rollback token",
  "permission": "NONE_READ_ONLY",
  "readback_fields": [
    "source_sha",
    "installed_binary_sha",
    "host_loaded_sha",
    "served_model",
    "policy_epoch",
    "no_effect_witness"
  ],
  "schema": "B1.PD.EFFECT_SLOT@r3",
  "slot_id": "OBS-B1-C7"
}
```
**個別 NEG**：green patch with stale loaded binary -> LOADED_BINARY_MISMATCH; alias and stale observations must close without world mutation。`OBS-B1-C7` 產生獨立 `operation_id:OBS-B1-C7`、`RAW:OBS-B1-C7`、`OR:OBS-B1-C7`；只允許事前 hash 相同且合法 dependency 的上游 receipt，不可當作自己的 effect receipt。
**閉合條件**：Source→PI-B1-C7→OBS-B1-C7→只一 ECP 或 NO_EFFECT→`TQ-CHILD-OBS-B1-C7-POS/NEG/EDGE/SEC`→checker。Missing current binding ⇒ `HOLD`，不得把本 schema 範本稱為 issued WorkOrder。

### PD-30｜WO-B1-C8 — NATIVE_SUCCESSOR / HOST_OPERATIONS

**原 r2 段落位置**：L616；**需求 Owner**：Hermes Continuation Owner；domain invariant：fresh separate session native trigger progresses after external account revoked。
**作用程序**：revoke external helper -> separate session native issuer advances next WO -> ledger readback。
```json
{
  "atom": "B1-C8",
  "cross_effect_receipt_reuse": false,
  "current_binding_state": "HOLD_PENDING_TRUE_OWNER_AND_HOST",
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "NATIVE_SUCCESSOR",
  "needed_fields": [
    "subject_sha",
    "active_policy_epoch",
    "issuer_identity",
    "token_ref",
    "operation_id",
    "nonce",
    "ttl",
    "host_id",
    "expected_prestate_sha"
  ],
  "operation": "revoke external helper -> separate session native issuer advances next WO -> ledger readback",
  "permission": "OWNER_BOUND_TOKEN_REQUIRED",
  "readback_fields": [
    "external_stop",
    "ledger_cursor",
    "issuer",
    "successor_wo",
    "native_origin",
    "native_event_id",
    "operation_id",
    "effect_postimage_sha",
    "evidence_ref"
  ],
  "schema": "B1.PD.EFFECT_SLOT@r3",
  "slot_id": "WO-B1-C8"
}
```
**個別 NEG**：successor still external-triggered -> NATIVE_SUCCESSOR_NOT_PROVEN; expired/mismatched token or unknown effect -> NACK/RECONCILE。`WO-B1-C8` 產生獨立 `operation_id:WO-B1-C8`、`RAW:WO-B1-C8`、`OR:WO-B1-C8`；只允許事前 hash 相同且合法 dependency 的上游 receipt，不可當作自己的 effect receipt。
**閉合條件**：Source→PI-B1-C8→WO-B1-C8→只一 ECP 或 NO_EFFECT→`TQ-CHILD-WO-B1-C8-POS/NEG/EDGE/SEC`→checker。Missing current binding ⇒ `HOLD`，不得把本 schema 範本稱為 issued WorkOrder。

### PD-31｜OBS-B1-C9 — TRIPLE_GWO / READ_ONLY_PROBE

**原 r2 段落位置**：L624；**需求 Owner**：Independent AO + 3 Domain Owners；domain invariant：3 different domain receipts, all same intended crosswalk, not aliases。
**作用程序**：READ ONLY exact triple_golden_join source/host probe; no WorkOrder issue, no ECP, no rollback token。
```json
{
  "atom": "B1-C9",
  "cross_effect_receipt_reuse": false,
  "current_binding_state": "READ_ONLY_SCOPE_PENDING",
  "effect_class": "READ_ONLY_PROBE",
  "effect_key": "TRIPLE_GWO",
  "needed_fields": [
    "subject_ref",
    "source_hash",
    "read_scope",
    "owner",
    "observation_time"
  ],
  "operation": "READ ONLY exact triple_golden_join source/host probe; no WorkOrder issue, no ECP, no rollback token",
  "permission": "NONE_READ_ONLY",
  "readback_fields": [
    "fabric_receipt",
    "hgk_receipt",
    "sbl_receipt",
    "revoke_receipt",
    "join_subject",
    "no_effect_witness"
  ],
  "schema": "B1.PD.EFFECT_SLOT@r3",
  "slot_id": "OBS-B1-C9"
}
```
**個別 NEG**：same receipt reused -> GWO_RECEIPT_ALIAS; alias and stale observations must close without world mutation。`OBS-B1-C9` 產生獨立 `operation_id:OBS-B1-C9`、`RAW:OBS-B1-C9`、`OR:OBS-B1-C9`；只允許事前 hash 相同且合法 dependency 的上游 receipt，不可當作自己的 effect receipt。
**閉合條件**：Source→PI-B1-C9→OBS-B1-C9→只一 ECP 或 NO_EFFECT→`TQ-CHILD-OBS-B1-C9-POS/NEG/EDGE/SEC`→checker。Missing current binding ⇒ `HOLD`，不得把本 schema 範本稱為 issued WorkOrder。

## 3. 31 張卡逐卡 Mandatory Method Policy slot

| WO/OBS | 現役 policy snapshot | KANBAN | SWARM | GSTACK | OPENSPEC | CODEX |
|---|---|---|---|---|---|---|
| OBS-B1-A1 | HOLD_POLICY_EPOCH | evaluate(actual_policy,OBS-B1-A1) | evaluate(actual_policy,OBS-B1-A1) | evaluate(actual_policy,OBS-B1-A1) | evaluate(actual_policy,OBS-B1-A1) | evaluate(actual_policy,OBS-B1-A1) |
| WO-B1-A2 | HOLD_POLICY_EPOCH | evaluate(actual_policy,WO-B1-A2) | evaluate(actual_policy,WO-B1-A2) | evaluate(actual_policy,WO-B1-A2) | evaluate(actual_policy,WO-B1-A2) | evaluate(actual_policy,WO-B1-A2) |
| WO-B1-A3 | HOLD_POLICY_EPOCH | evaluate(actual_policy,WO-B1-A3) | evaluate(actual_policy,WO-B1-A3) | evaluate(actual_policy,WO-B1-A3) | evaluate(actual_policy,WO-B1-A3) | evaluate(actual_policy,WO-B1-A3) |
| WO-B1-A4 | HOLD_POLICY_EPOCH | evaluate(actual_policy,WO-B1-A4) | evaluate(actual_policy,WO-B1-A4) | evaluate(actual_policy,WO-B1-A4) | evaluate(actual_policy,WO-B1-A4) | evaluate(actual_policy,WO-B1-A4) |
| OBS-B1-A5 | HOLD_POLICY_EPOCH | evaluate(actual_policy,OBS-B1-A5) | evaluate(actual_policy,OBS-B1-A5) | evaluate(actual_policy,OBS-B1-A5) | evaluate(actual_policy,OBS-B1-A5) | evaluate(actual_policy,OBS-B1-A5) |
| WO-B1-A6 | HOLD_POLICY_EPOCH | evaluate(actual_policy,WO-B1-A6) | evaluate(actual_policy,WO-B1-A6) | evaluate(actual_policy,WO-B1-A6) | evaluate(actual_policy,WO-B1-A6) | evaluate(actual_policy,WO-B1-A6) |
| OBS-B1-A7 | HOLD_POLICY_EPOCH | evaluate(actual_policy,OBS-B1-A7) | evaluate(actual_policy,OBS-B1-A7) | evaluate(actual_policy,OBS-B1-A7) | evaluate(actual_policy,OBS-B1-A7) | evaluate(actual_policy,OBS-B1-A7) |
| WO-B1-A8 | HOLD_POLICY_EPOCH | evaluate(actual_policy,WO-B1-A8) | evaluate(actual_policy,WO-B1-A8) | evaluate(actual_policy,WO-B1-A8) | evaluate(actual_policy,WO-B1-A8) | evaluate(actual_policy,WO-B1-A8) |
| WO-B1-A9 | HOLD_POLICY_EPOCH | evaluate(actual_policy,WO-B1-A9) | evaluate(actual_policy,WO-B1-A9) | evaluate(actual_policy,WO-B1-A9) | evaluate(actual_policy,WO-B1-A9) | evaluate(actual_policy,WO-B1-A9) |
| OBS-B1-B1 | HOLD_POLICY_EPOCH | evaluate(actual_policy,OBS-B1-B1) | evaluate(actual_policy,OBS-B1-B1) | evaluate(actual_policy,OBS-B1-B1) | evaluate(actual_policy,OBS-B1-B1) | evaluate(actual_policy,OBS-B1-B1) |
| OBS-B1-B2 | HOLD_POLICY_EPOCH | evaluate(actual_policy,OBS-B1-B2) | evaluate(actual_policy,OBS-B1-B2) | evaluate(actual_policy,OBS-B1-B2) | evaluate(actual_policy,OBS-B1-B2) | evaluate(actual_policy,OBS-B1-B2) |
| WO-B1-B3-DEV | HOLD_POLICY_EPOCH | evaluate(actual_policy,WO-B1-B3-DEV) | evaluate(actual_policy,WO-B1-B3-DEV) | evaluate(actual_policy,WO-B1-B3-DEV) | evaluate(actual_policy,WO-B1-B3-DEV) | evaluate(actual_policy,WO-B1-B3-DEV) |
| WO-B1-B3-OPS | HOLD_POLICY_EPOCH | evaluate(actual_policy,WO-B1-B3-OPS) | evaluate(actual_policy,WO-B1-B3-OPS) | evaluate(actual_policy,WO-B1-B3-OPS) | evaluate(actual_policy,WO-B1-B3-OPS) | evaluate(actual_policy,WO-B1-B3-OPS) |
| WO-B1-B4-DEV | HOLD_POLICY_EPOCH | evaluate(actual_policy,WO-B1-B4-DEV) | evaluate(actual_policy,WO-B1-B4-DEV) | evaluate(actual_policy,WO-B1-B4-DEV) | evaluate(actual_policy,WO-B1-B4-DEV) | evaluate(actual_policy,WO-B1-B4-DEV) |
| WO-B1-B4-OPS | HOLD_POLICY_EPOCH | evaluate(actual_policy,WO-B1-B4-OPS) | evaluate(actual_policy,WO-B1-B4-OPS) | evaluate(actual_policy,WO-B1-B4-OPS) | evaluate(actual_policy,WO-B1-B4-OPS) | evaluate(actual_policy,WO-B1-B4-OPS) |
| WO-B1-B5-DEV | HOLD_POLICY_EPOCH | evaluate(actual_policy,WO-B1-B5-DEV) | evaluate(actual_policy,WO-B1-B5-DEV) | evaluate(actual_policy,WO-B1-B5-DEV) | evaluate(actual_policy,WO-B1-B5-DEV) | evaluate(actual_policy,WO-B1-B5-DEV) |
| WO-B1-B5-OPS | HOLD_POLICY_EPOCH | evaluate(actual_policy,WO-B1-B5-OPS) | evaluate(actual_policy,WO-B1-B5-OPS) | evaluate(actual_policy,WO-B1-B5-OPS) | evaluate(actual_policy,WO-B1-B5-OPS) | evaluate(actual_policy,WO-B1-B5-OPS) |
| WO-B1-B6-USER | HOLD_POLICY_EPOCH | evaluate(actual_policy,WO-B1-B6-USER) | evaluate(actual_policy,WO-B1-B6-USER) | evaluate(actual_policy,WO-B1-B6-USER) | evaluate(actual_policy,WO-B1-B6-USER) | evaluate(actual_policy,WO-B1-B6-USER) |
| OBS-B1-B7 | HOLD_POLICY_EPOCH | evaluate(actual_policy,OBS-B1-B7) | evaluate(actual_policy,OBS-B1-B7) | evaluate(actual_policy,OBS-B1-B7) | evaluate(actual_policy,OBS-B1-B7) | evaluate(actual_policy,OBS-B1-B7) |
| OBS-B1-B8 | HOLD_POLICY_EPOCH | evaluate(actual_policy,OBS-B1-B8) | evaluate(actual_policy,OBS-B1-B8) | evaluate(actual_policy,OBS-B1-B8) | evaluate(actual_policy,OBS-B1-B8) | evaluate(actual_policy,OBS-B1-B8) |
| OBS-B1-B9 | HOLD_POLICY_EPOCH | evaluate(actual_policy,OBS-B1-B9) | evaluate(actual_policy,OBS-B1-B9) | evaluate(actual_policy,OBS-B1-B9) | evaluate(actual_policy,OBS-B1-B9) | evaluate(actual_policy,OBS-B1-B9) |
| WO-B1-C1 | HOLD_POLICY_EPOCH | evaluate(actual_policy,WO-B1-C1) | evaluate(actual_policy,WO-B1-C1) | evaluate(actual_policy,WO-B1-C1) | evaluate(actual_policy,WO-B1-C1) | evaluate(actual_policy,WO-B1-C1) |
| WO-B1-C2 | HOLD_POLICY_EPOCH | evaluate(actual_policy,WO-B1-C2) | evaluate(actual_policy,WO-B1-C2) | evaluate(actual_policy,WO-B1-C2) | evaluate(actual_policy,WO-B1-C2) | evaluate(actual_policy,WO-B1-C2) |
| WO-B1-C3-OPS | HOLD_POLICY_EPOCH | evaluate(actual_policy,WO-B1-C3-OPS) | evaluate(actual_policy,WO-B1-C3-OPS) | evaluate(actual_policy,WO-B1-C3-OPS) | evaluate(actual_policy,WO-B1-C3-OPS) | evaluate(actual_policy,WO-B1-C3-OPS) |
| WO-B1-C3-USER | HOLD_POLICY_EPOCH | evaluate(actual_policy,WO-B1-C3-USER) | evaluate(actual_policy,WO-B1-C3-USER) | evaluate(actual_policy,WO-B1-C3-USER) | evaluate(actual_policy,WO-B1-C3-USER) | evaluate(actual_policy,WO-B1-C3-USER) |
| WO-B1-C4 | HOLD_POLICY_EPOCH | evaluate(actual_policy,WO-B1-C4) | evaluate(actual_policy,WO-B1-C4) | evaluate(actual_policy,WO-B1-C4) | evaluate(actual_policy,WO-B1-C4) | evaluate(actual_policy,WO-B1-C4) |
| WO-B1-C5 | HOLD_POLICY_EPOCH | evaluate(actual_policy,WO-B1-C5) | evaluate(actual_policy,WO-B1-C5) | evaluate(actual_policy,WO-B1-C5) | evaluate(actual_policy,WO-B1-C5) | evaluate(actual_policy,WO-B1-C5) |
| WO-B1-C6 | HOLD_POLICY_EPOCH | evaluate(actual_policy,WO-B1-C6) | evaluate(actual_policy,WO-B1-C6) | evaluate(actual_policy,WO-B1-C6) | evaluate(actual_policy,WO-B1-C6) | evaluate(actual_policy,WO-B1-C6) |
| OBS-B1-C7 | HOLD_POLICY_EPOCH | evaluate(actual_policy,OBS-B1-C7) | evaluate(actual_policy,OBS-B1-C7) | evaluate(actual_policy,OBS-B1-C7) | evaluate(actual_policy,OBS-B1-C7) | evaluate(actual_policy,OBS-B1-C7) |
| WO-B1-C8 | HOLD_POLICY_EPOCH | evaluate(actual_policy,WO-B1-C8) | evaluate(actual_policy,WO-B1-C8) | evaluate(actual_policy,WO-B1-C8) | evaluate(actual_policy,WO-B1-C8) | evaluate(actual_policy,WO-B1-C8) |
| OBS-B1-C9 | HOLD_POLICY_EPOCH | evaluate(actual_policy,OBS-B1-C9) | evaluate(actual_policy,OBS-B1-C9) | evaluate(actual_policy,OBS-B1-C9) | evaluate(actual_policy,OBS-B1-C9) | evaluate(actual_policy,OBS-B1-C9) |
