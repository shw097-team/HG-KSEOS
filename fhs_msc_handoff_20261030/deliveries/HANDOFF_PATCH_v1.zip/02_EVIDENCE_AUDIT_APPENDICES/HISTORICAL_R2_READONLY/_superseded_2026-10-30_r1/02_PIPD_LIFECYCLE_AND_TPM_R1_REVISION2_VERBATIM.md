## 高保留原 BODY Revision2 實質正文（沿用未受影區；遇 r2 修補採本冊前段）

---
artifact_id: FHS-MSC-R2-BODY-02
formal_name: PIPD 生命週期、TPM 18 Stage、19 Contract 與13 CLI
short_name: BODY-02
version: 2026-10-29-r2-revision2
source_set_hash_or_pending: f86b217ae3c3ee28183570f4bf3d4f08d4d00e9b86d1de1a641a630f8682d1a1
intended_consumer: 原領域 Owner 與下游 Reader
owner_role: 作者端規格修補者；原 Domain Writer 不移轉
design_status: SOURCE_BOUND_REPAIR_CANDIDATE
claim_ceiling: AUTHOR_STATIC_ONLY; NATIVE_NOT_RUN; CHECKER_NOT_RUN; RELEASE_NOT_RUN
supersession_scope: 本輪作者候選revision2；保留前版封存；不取代任何原Canonical Writer版本
AUDIT_F_IDs:
- F-03
- F-12
- F-13
---

# PIPD 生命週期、TPM 18 Stage、19 Contract 與13 CLI

## R2-02-HANDOFF：五個正式出口與候選隔離

SOURCE/PROFILE→PI：`pipd-route-intake` 只收 nonblank goal+contained sources；authority-source每family有file digest+locators，衝突拒freeze；profile-tailor九軸safety veto不得降級；pi-compile strict shape只有intent/profile/atoms/goal。POS原五REQ namespace可重播identity；NEG `_profile_meta` → schema NACK；project atom lossless sidecar不混入strict payload。

PI→PD：原pd-bind消費PI、真RepoContext與currentness。先read real root/HEAD/index/untracked/reparse/ACL，再late-bind exact writable scope；NEG stale HEAD或foreign subject→PD_BIND_NACK。沒有當期root evidence不得用README或歷史sha代用。

PD→DEV Construction/ECP：同subject的writable_scope/expected_changes/tests/rollback/evidence；exact preimage+原Issuer admission才可Repo effect。PD→OPS ECP：Host/User/Remote/Release分receiver/grant/nonce/TTL/epoch，不能套用DEV grant。POS分別對原Writer schema ACK；NEG ECP string當Permit→ADMISSION_DENIED。文稿僅候選，無真Compiler/Host ACK不得冒正式包。

TQAEP計畫→Checker：`SBL.PlannedTQAEP@1`保留per-atom POS/NEG/oracle/fixture，不提供live receipt。正式TQAEP/受保護check需不同credential及本輪Raw reader；Maker輸入receipt字串不能自簽。POS 真Reader查same candidate/Oracle/identity；NEG foreign receipt或same Maker→SELF_ACCEPTANCE_DENY。

DOC07 canonical Oracle↔legacy DOC03與十二風險軸→九context enum有語義落差；原Owner需提供alias/migration/loss ledger、roundtrip POS/NEG與Writer ACK。缺此只PI語義promotion及依賴ECP HOLD；不阻已合法admitted工作。

## R2-02-STAGE：K0–K3 與原18-stage投影

插件 corpus 24檔完整性重算PASS；K0原bytes/K1 clause index/K2相容提案/K3 bounded reader。歷史fixture不是live收據。T4/T5受CR-DOC04-STATE-MAP影響仍為formal HOLD，Draft SPEC可繼續。

| Stage | input→operation→output | Owner→Consumer | guard/first_fail/source |
|---|---|---|---|
| PM:T0 | ['goalcard', 'known_answer_refs', 'source_sha256'] → segregate facts from user guesses; detect unanswered JTBD → ProductKnownState@1(goal_sha,missing_questions) | ProductOwner → ProductOwner/PIPD Reader | GoalCard+known_answer_refs; source_sha present / KNOWN_ANSWER_REASK / {'source_id': 'SBL-04', 'sha256': 'ee90cb1c86f6f7350c11c9c962233a89b035ca41ff82c8968f7968608fc6f6e0', 'line': 510} |
| PM:T1 | ['persona', 'painledger', 'jtbd', 'source_sha256'] → rank questions by user information gain → QuestionPriority@1(qid,impact,source_ref) | ProductOwner → ProductOwner/PIPD Reader | Persona+PainLedger+JTBD; source_sha present / JTBD_UNBOUND / {'source_id': 'SBL-04', 'sha256': 'ee90cb1c86f6f7350c11c9c962233a89b035ca41ff82c8968f7968608fc6f6e0', 'line': 511} |
| PM:T2 | ['fuo', 'useroutcome', 'variants', 'source_sha256'] → define observable CLI/add,list,delete or brownfield user result → ProductSuccess@1(FUO,exit_code,negative_cases) | ProductOwner → ProductOwner/PIPD Reader | FUO+UserOutcome+variants; source_sha present / FUO_UNTESTABLE / {'source_id': 'SBL-04', 'sha256': 'ee90cb1c86f6f7350c11c9c962233a89b035ca41ff82c8968f7968608fc6f6e0', 'line': 512} |
| PM:T3 | ['productsuccess', 'primarykind', 'source_sha256'] → compile ProductSPEC draft and acceptance cues → ProductSPECDraft@1(journey_id,kind,acceptance_sha) | ProductOwner → ProductOwner/PIPD Reader | ProductSuccess+PrimaryKind; source_sha present / KIND_ID_DRIFT / {'source_id': 'SBL-04', 'sha256': 'ee90cb1c86f6f7350c11c9c962233a89b035ca41ff82c8968f7968608fc6f6e0', 'line': 513} |
| PM:T4 | ['productspecdraft', 'acc_neg', 'source_sha256'] → issue user-facing POS/NEG proposal, not Native verdict → ProductAcceptanceProposal@1(pos,neg,raw_expect) | ProductOwner → ProductOwner/PIPD Reader | ProductSPECDraft+ACC_NEG; source_sha present / ACC_NOT_BOUND / {'source_id': 'SBL-04', 'sha256': 'ee90cb1c86f6f7350c11c9c962233a89b035ca41ff82c8968f7968608fc6f6e0', 'line': 514} |
| PM:T5 | ['fuo_raw_refs', 'feedback', 'source_sha256'] → compare observable use vs claimed outcome; create repair request → ProductReviewRequest@1(gap,affected_journeys) | ProductOwner → ProductOwner/PIPD Reader | FUO_raw_refs+feedback; source_sha present / FUO_RAW_MISSING / {'source_id': 'SBL-04', 'sha256': 'ee90cb1c86f6f7350c11c9c962233a89b035ca41ff82c8968f7968608fc6f6e0', 'line': 515} |
| SE:T0 | ['repoboundaries', 'sourceindex', 'source_sha256'] → enumerate source/destination trust seams → SystemReadset@1(owners,sha,scope) | ArchitectureOwner → ArchitectureOwner/HostReader | RepoBoundaries+SourceIndex; source_sha present / SYSTEM_SOURCE_GAP / {'source_id': 'SBL-04', 'sha256': 'ee90cb1c86f6f7350c11c9c962233a89b035ca41ff82c8968f7968608fc6f6e0', 'line': 516} |
| SE:T1 | ['systemreadset', 'adrrefs', 'source_sha256'] → assign every seam to exactly one writer → OwnershipSeamMap@1(writer,reader,forbidden_effect) | ArchitectureOwner → ArchitectureOwner/HostReader | SystemReadset+ADRRefs; source_sha present / SEAM_OWNER_CONFLICT / {'source_id': 'SBL-04', 'sha256': 'ee90cb1c86f6f7350c11c9c962233a89b035ca41ff82c8968f7968608fc6f6e0', 'line': 517} |
| SE:T2 | ['riskinventory', 'hostcaps', 'source_sha256'] → trade off typed ABI and provider-off reliability → ADRSet@1(option,tradeoff,security_guard) | ArchitectureOwner → ArchitectureOwner/HostReader | RiskInventory+HostCaps; source_sha present / ARCHITECTURE_RISK_OPEN / {'source_id': 'SBL-04', 'sha256': 'ee90cb1c86f6f7350c11c9c962233a89b035ca41ff82c8968f7968608fc6f6e0', 'line': 518} |
| SE:T3 | ['adrset', 'c4', 'componentcards', 'source_sha256'] → bind schemas and compatibility version → ArchitectureSPEC@1(abi,compat,host_matrix) | ArchitectureOwner → ArchitectureOwner/HostReader | ADRSet+C4+ComponentCards; source_sha present / ABI_SCHEMA_MISMATCH / {'source_id': 'SBL-04', 'sha256': 'ee90cb1c86f6f7350c11c9c962233a89b035ca41ff82c8968f7968608fc6f6e0', 'line': 519} |
| SE:T4 | ['architecturespec', 'boundaryneg', 'source_sha256'] → test scope/token/provider-off/thin adapter semantics → ArchitectureNEGRequest@1(neg,oracle_source) | ArchitectureOwner → ArchitectureOwner/HostReader | ArchitectureSPEC+BoundaryNEG; source_sha present / PERMISSION_NEG_MISSING / {'source_id': 'SBL-04', 'sha256': 'ee90cb1c86f6f7350c11c9c962233a89b035ca41ff82c8968f7968608fc6f6e0', 'line': 520} |
| SE:T5 | ['nativerawrefs', 'integrationrisks', 'source_sha256'] → re-evaluate actual host ABI and raw results → ArchitectureReview@1(findings,repair_cone) | ArchitectureOwner → ArchitectureOwner/HostReader | NativeRawRefs+IntegrationRisks; source_sha present / HOST_RAW_MISSING / {'source_id': 'SBL-04', 'sha256': 'ee90cb1c86f6f7350c11c9c962233a89b035ca41ff82c8968f7968608fc6f6e0', 'line': 521} |
| TPgM:T0 | ['ownerroster', 'costtime', 'source_sha256'] → identify budget milestones without claiming approval → ProgramIntent@1(milestone,owner,risk) | ProgramOwner → ProgramOwner/NativeRouter | OwnerRoster+CostTime; source_sha present / MILESTONE_OWNER_MISSING / {'source_id': 'SBL-04', 'sha256': 'ee90cb1c86f6f7350c11c9c962233a89b035ca41ff82c8968f7968608fc6f6e0', 'line': 522} |
| TPgM:T1 | ['unknowndependencies', 'resourcecaps', 'source_sha256'] → record sequencing constraints and blocking decisions → SchedulingAssumptions@1(edges,confidence) | ProgramOwner → ProgramOwner/NativeRouter | UnknownDependencies+ResourceCaps; source_sha present / UNBOUNDED_WORK / {'source_id': 'SBL-04', 'sha256': 'ee90cb1c86f6f7350c11c9c962233a89b035ca41ff82c8968f7968608fc6f6e0', 'line': 523} |
| TPgM:T2 | ['ownergates', 'dependencyedges', 'source_sha256'] → toposort bounded DAG and cycle check → ProgramDAG@1(topo,locks,no_fit) | ProgramOwner → ProgramOwner/NativeRouter | OwnerGates+DependencyEdges; source_sha present / DAG_CYCLE / {'source_id': 'SBL-04', 'sha256': 'ee90cb1c86f6f7350c11c9c962233a89b035ca41ff82c8968f7968608fc6f6e0', 'line': 524} |
| TPgM:T3 | ['programdag', 'productspec', 'architecturespec', 'source_sha256'] → package work with traceable scope and approver → ProgramSPEC@1(wp,effort,owner,stop) | ProgramOwner → ProgramOwner/NativeRouter | ProgramDAG+ProductSPEC+ArchitectureSPEC; source_sha present / WP_SCOPE_UNKNOWN / {'source_id': 'SBL-04', 'sha256': 'ee90cb1c86f6f7350c11c9c962233a89b035ca41ff82c8968f7968608fc6f6e0', 'line': 525} |
| TPgM:T4 | ['pi_pd_refs', 'verifierreferral', 'source_sha256'] → route to correct Native ECP/Oracle Owner → HandoffReferral@1(expected_grants,oracle_conflict) | ProgramOwner → ProgramOwner/NativeRouter | PI_PD_refs+VerifierReferral; source_sha present / CR_ORACLE_001 / {'source_id': 'SBL-04', 'sha256': 'ee90cb1c86f6f7350c11c9c962233a89b035ca41ff82c8968f7968608fc6f6e0', 'line': 526} |
| TPgM:T5 | ['milestoneraw', 'issueledger', 'source_sha256'] → review schedule with evidence status; refreeze affected only → ProgramReview@1(blocked_waves,replan_cone) | ProgramOwner → ProgramOwner/NativeRouter | MilestoneRaw+IssueLedger; source_sha present / STALE_MILESTONE_EVIDENCE / {'source_id': 'SBL-04', 'sha256': 'ee90cb1c86f6f7350c11c9c962233a89b035ca41ff82c8968f7968608fc6f6e0', 'line': 527} |

## R2-02-CONTRACTS：19 種真Schema與domain invariant

當期Schema中多數內層properties是 `{}`。因此JSON Schema只驗required/unknown欄，不保證domain語義。下列專屬Reader invariant是來源約束的修補設計；Host Registry綁定與真semantic validator仍需原Owner。不得把此弱schema的syntactic PASS宣稱完整Native conformance。

### ArtifactIdentity

- 原 Registry source：C:\Projects\Agent_Workspace\PIPD\schemas\ArtifactIdentity.schema.json；SHA `67d26f18d26307410bf0be5369949eb525d477e053ee3a7091e54b97f6d4ad4c`；`$id=urn:pipd:s0:ArtifactIdentity:1`；schema dialect 2020-12；additionalProperties=false。
- Producer/Consumer：Owner: PIPD. Consumer: all planes.
- required：subject_id, version, content_hash, schema_version, supersedes, invalidates。
- 專屬 Reader invariant：相同 canonical body 得相同 content_hash；supersedes/invalidates 指到舊版本且不能自指。
- Domain NEG：alter body but retain content_hash → `HASH_MISMATCH`；與 missing-required/unknown-key 的 schema拒收分開。
- roundtrip：原 Reader重序列化 payload，再讀回相同identity/trace；schema syntactic fixture通過不證明content_hash/Principal/License有效。
- POS/NEG payload（只供本輪Schema fixture，不是live artifact）：
```json
{
  "valid_shape_only": {
    "subject_id": "STATIC-ArtifactIdentity",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:ArtifactIdentity:1",
    "supersedes": "STATIC_FIXTURE_ArtifactIdentity_supersedes",
    "invalidates": "STATIC_FIXTURE_ArtifactIdentity_invalidates"
  },
  "invalid_missing_required": {
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:ArtifactIdentity:1",
    "supersedes": "STATIC_FIXTURE_ArtifactIdentity_supersedes",
    "invalidates": "STATIC_FIXTURE_ArtifactIdentity_invalidates"
  },
  "invalid_unknown_field": {
    "subject_id": "STATIC-ArtifactIdentity",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:ArtifactIdentity:1",
    "supersedes": "STATIC_FIXTURE_ArtifactIdentity_supersedes",
    "invalidates": "STATIC_FIXTURE_ArtifactIdentity_invalidates",
    "_profile_meta": {
      "not": "native"
    }
  }
}
```

### AuthorityBinding

- 原 Registry source：C:\Projects\Agent_Workspace\PIPD\schemas\AuthorityBinding.schema.json；SHA `66f1b3ce91d7f12ad6a6350a6628afd6c600e3e7ff62408b714c6fa0f1898ded`；`$id=urn:pipd:s0:AuthorityBinding:1`；schema dialect 2020-12；additionalProperties=false。
- Producer/Consumer：Owner: PIPD. Consumer: all compilers/adapters.
- required：source_id, authority_rank, locator, supersession, conflict_state, subject_id, version, content_hash, schema_version。
- 專屬 Reader invariant：來源存在且 file SHA 符合；CURRENT 無 unresolved conflict 才可供 Compiler。
- Domain NEG：conflict_state=CONFLICT but promotion requested → `AUTHORITY_CONFLICT`；與 missing-required/unknown-key 的 schema拒收分開。
- roundtrip：原 Reader重序列化 payload，再讀回相同identity/trace；schema syntactic fixture通過不證明content_hash/Principal/License有效。
- POS/NEG payload（只供本輪Schema fixture，不是live artifact）：
```json
{
  "valid_shape_only": {
    "source_id": "STATIC_FIXTURE_AuthorityBinding_source_id",
    "authority_rank": "STATIC_FIXTURE_AuthorityBinding_authority_rank",
    "locator": "STATIC_FIXTURE_AuthorityBinding_locator",
    "supersession": "STATIC_FIXTURE_AuthorityBinding_supersession",
    "conflict_state": "STATIC_FIXTURE_AuthorityBinding_conflict_state",
    "subject_id": "STATIC-AuthorityBinding",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:AuthorityBinding:1"
  },
  "invalid_missing_required": {
    "authority_rank": "STATIC_FIXTURE_AuthorityBinding_authority_rank",
    "locator": "STATIC_FIXTURE_AuthorityBinding_locator",
    "supersession": "STATIC_FIXTURE_AuthorityBinding_supersession",
    "conflict_state": "STATIC_FIXTURE_AuthorityBinding_conflict_state",
    "subject_id": "STATIC-AuthorityBinding",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:AuthorityBinding:1"
  },
  "invalid_unknown_field": {
    "source_id": "STATIC_FIXTURE_AuthorityBinding_source_id",
    "authority_rank": "STATIC_FIXTURE_AuthorityBinding_authority_rank",
    "locator": "STATIC_FIXTURE_AuthorityBinding_locator",
    "supersession": "STATIC_FIXTURE_AuthorityBinding_supersession",
    "conflict_state": "STATIC_FIXTURE_AuthorityBinding_conflict_state",
    "subject_id": "STATIC-AuthorityBinding",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:AuthorityBinding:1",
    "_profile_meta": {
      "not": "native"
    }
  }
}
```

### ClaimCeiling

- 原 Registry source：C:\Projects\Agent_Workspace\PIPD\schemas\ClaimCeiling.schema.json；SHA `dbb2ce4dd322da99ca3b3067274b85928b995aba59ca3f04802d5e8ba253ab85`；`$id=urn:pipd:s0:ClaimCeiling:1`；schema dialect 2020-12；additionalProperties=false。
- Producer/Consumer：Owner: PIPD. Consumer: all planes.
- required：allowed_claims, forbidden_escalation, close_conditions, subject_id, version, content_hash, schema_version。
- 專屬 Reader invariant：allowed_claims需真證據階梯；forbidden_escalation與close_conditions有效。
- Domain NEG：AUTHOR_STATIC promoted to RELEASED → `CLAIM_ESCALATION`；與 missing-required/unknown-key 的 schema拒收分開。
- roundtrip：原 Reader重序列化 payload，再讀回相同identity/trace；schema syntactic fixture通過不證明content_hash/Principal/License有效。
- POS/NEG payload（只供本輪Schema fixture，不是live artifact）：
```json
{
  "valid_shape_only": {
    "allowed_claims": "STATIC_FIXTURE_ClaimCeiling_allowed_claims",
    "forbidden_escalation": "STATIC_FIXTURE_ClaimCeiling_forbidden_escalation",
    "close_conditions": "STATIC_FIXTURE_ClaimCeiling_close_conditions",
    "subject_id": "STATIC-ClaimCeiling",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:ClaimCeiling:1"
  },
  "invalid_missing_required": {
    "forbidden_escalation": "STATIC_FIXTURE_ClaimCeiling_forbidden_escalation",
    "close_conditions": "STATIC_FIXTURE_ClaimCeiling_close_conditions",
    "subject_id": "STATIC-ClaimCeiling",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:ClaimCeiling:1"
  },
  "invalid_unknown_field": {
    "allowed_claims": "STATIC_FIXTURE_ClaimCeiling_allowed_claims",
    "forbidden_escalation": "STATIC_FIXTURE_ClaimCeiling_forbidden_escalation",
    "close_conditions": "STATIC_FIXTURE_ClaimCeiling_close_conditions",
    "subject_id": "STATIC-ClaimCeiling",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:ClaimCeiling:1",
    "_profile_meta": {
      "not": "native"
    }
  }
}
```

### ConstructionContract

- 原 Registry source：C:\Projects\Agent_Workspace\PIPD\schemas\ConstructionContract.schema.json；SHA `1c56f15abd6e30d06f914f021b0b813f441689f9d47989ef48c7d7325557f0f2`；`$id=urn:pipd:s0:ConstructionContract:1`；schema dialect 2020-12；additionalProperties=false。
- Producer/Consumer：Owner: PIPD. Consumer: HGK adapter.
- required：subject, writable_scope, expected_changes, tests, rollback, evidence_expectations, subject_id, version, content_hash, schema_version。
- 專屬 Reader invariant：writable_scope exact contained paths，expected_changes/tests/rollback 對同 preimage。
- Domain NEG：scope=** or path escapes root → `CC_SCOPE`；與 missing-required/unknown-key 的 schema拒收分開。
- roundtrip：原 Reader重序列化 payload，再讀回相同identity/trace；schema syntactic fixture通過不證明content_hash/Principal/License有效。
- POS/NEG payload（只供本輪Schema fixture，不是live artifact）：
```json
{
  "valid_shape_only": {
    "subject": "STATIC_FIXTURE_ConstructionContract_subject",
    "writable_scope": "STATIC_FIXTURE_ConstructionContract_writable_scope",
    "expected_changes": "STATIC_FIXTURE_ConstructionContract_expected_changes",
    "tests": "STATIC_FIXTURE_ConstructionContract_tests",
    "rollback": "STATIC_FIXTURE_ConstructionContract_rollback",
    "evidence_expectations": "STATIC_FIXTURE_ConstructionContract_evidence_expectations",
    "subject_id": "STATIC-ConstructionContract",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:ConstructionContract:1"
  },
  "invalid_missing_required": {
    "writable_scope": "STATIC_FIXTURE_ConstructionContract_writable_scope",
    "expected_changes": "STATIC_FIXTURE_ConstructionContract_expected_changes",
    "tests": "STATIC_FIXTURE_ConstructionContract_tests",
    "rollback": "STATIC_FIXTURE_ConstructionContract_rollback",
    "evidence_expectations": "STATIC_FIXTURE_ConstructionContract_evidence_expectations",
    "subject_id": "STATIC-ConstructionContract",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:ConstructionContract:1"
  },
  "invalid_unknown_field": {
    "subject": "STATIC_FIXTURE_ConstructionContract_subject",
    "writable_scope": "STATIC_FIXTURE_ConstructionContract_writable_scope",
    "expected_changes": "STATIC_FIXTURE_ConstructionContract_expected_changes",
    "tests": "STATIC_FIXTURE_ConstructionContract_tests",
    "rollback": "STATIC_FIXTURE_ConstructionContract_rollback",
    "evidence_expectations": "STATIC_FIXTURE_ConstructionContract_evidence_expectations",
    "subject_id": "STATIC-ConstructionContract",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:ConstructionContract:1",
    "_profile_meta": {
      "not": "native"
    }
  }
}
```

### ECP

- 原 Registry source：C:\Projects\Agent_Workspace\PIPD\schemas\ECP.schema.json；SHA `c58a8f3ed42808ba20f0102bb6fc7074d4fa321ea779879aa5ceefc6864d1de8`；`$id=urn:pipd:s0:ECP:1`；schema dialect 2020-12；additionalProperties=false。
- Producer/Consumer：Owner: PIPD/ECP semantics. Consumer: HGK/TQAEP.
- required：effect_intent, permission, retries, idempotency, readback, rollback, subject_id, version, content_hash, schema_version。
- 專屬 Reader invariant：effect_intent/permission/retries/idempotency/readback/rollback按同scope；UNKNOWN不得重播。
- Domain NEG：DEV permission used for HOST_OP → `WRONG_EFFECT_GRANT`；與 missing-required/unknown-key 的 schema拒收分開。
- roundtrip：原 Reader重序列化 payload，再讀回相同identity/trace；schema syntactic fixture通過不證明content_hash/Principal/License有效。
- POS/NEG payload（只供本輪Schema fixture，不是live artifact）：
```json
{
  "valid_shape_only": {
    "effect_intent": "STATIC_FIXTURE_ECP_effect_intent",
    "permission": "STATIC_FIXTURE_ECP_permission",
    "retries": "STATIC_FIXTURE_ECP_retries",
    "idempotency": "STATIC_FIXTURE_ECP_idempotency",
    "readback": "STATIC_FIXTURE_ECP_readback",
    "rollback": "STATIC_FIXTURE_ECP_rollback",
    "subject_id": "STATIC-ECP",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:ECP:1"
  },
  "invalid_missing_required": {
    "permission": "STATIC_FIXTURE_ECP_permission",
    "retries": "STATIC_FIXTURE_ECP_retries",
    "idempotency": "STATIC_FIXTURE_ECP_idempotency",
    "readback": "STATIC_FIXTURE_ECP_readback",
    "rollback": "STATIC_FIXTURE_ECP_rollback",
    "subject_id": "STATIC-ECP",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:ECP:1"
  },
  "invalid_unknown_field": {
    "effect_intent": "STATIC_FIXTURE_ECP_effect_intent",
    "permission": "STATIC_FIXTURE_ECP_permission",
    "retries": "STATIC_FIXTURE_ECP_retries",
    "idempotency": "STATIC_FIXTURE_ECP_idempotency",
    "readback": "STATIC_FIXTURE_ECP_readback",
    "rollback": "STATIC_FIXTURE_ECP_rollback",
    "subject_id": "STATIC-ECP",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:ECP:1",
    "_profile_meta": {
      "not": "native"
    }
  }
}
```

### EvidenceExpectation

- 原 Registry source：C:\Projects\Agent_Workspace\PIPD\schemas\EvidenceExpectation.schema.json；SHA `02327839c21d5ba24d08dd52f9caa31a07616965c6235cece58487a810b99b7f`；`$id=urn:pipd:s0:EvidenceExpectation:1`；schema dialect 2020-12；additionalProperties=false。
- Producer/Consumer：Owner: PIPD/TQAEP. Consumer: HGK/CI/provider.
- required：expected_evidence_type, producer, postcondition, freshness, claim_effect, subject_id, version, content_hash, schema_version。
- 專屬 Reader invariant：expected_evidence_type/producer/postcondition/freshness/claim_effect只描述期待。
- Domain NEG：expected raw path promoted to observed receipt → `EXPECTED_IS_NOT_RAW`；與 missing-required/unknown-key 的 schema拒收分開。
- roundtrip：原 Reader重序列化 payload，再讀回相同identity/trace；schema syntactic fixture通過不證明content_hash/Principal/License有效。
- POS/NEG payload（只供本輪Schema fixture，不是live artifact）：
```json
{
  "valid_shape_only": {
    "expected_evidence_type": "STATIC_FIXTURE_EvidenceExpectation_expected_evidence_type",
    "producer": "STATIC_FIXTURE_EvidenceExpectation_producer",
    "postcondition": "STATIC_FIXTURE_EvidenceExpectation_postcondition",
    "freshness": "STATIC_FIXTURE_EvidenceExpectation_freshness",
    "claim_effect": "STATIC_FIXTURE_EvidenceExpectation_claim_effect",
    "subject_id": "STATIC-EvidenceExpectation",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:EvidenceExpectation:1"
  },
  "invalid_missing_required": {
    "producer": "STATIC_FIXTURE_EvidenceExpectation_producer",
    "postcondition": "STATIC_FIXTURE_EvidenceExpectation_postcondition",
    "freshness": "STATIC_FIXTURE_EvidenceExpectation_freshness",
    "claim_effect": "STATIC_FIXTURE_EvidenceExpectation_claim_effect",
    "subject_id": "STATIC-EvidenceExpectation",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:EvidenceExpectation:1"
  },
  "invalid_unknown_field": {
    "expected_evidence_type": "STATIC_FIXTURE_EvidenceExpectation_expected_evidence_type",
    "producer": "STATIC_FIXTURE_EvidenceExpectation_producer",
    "postcondition": "STATIC_FIXTURE_EvidenceExpectation_postcondition",
    "freshness": "STATIC_FIXTURE_EvidenceExpectation_freshness",
    "claim_effect": "STATIC_FIXTURE_EvidenceExpectation_claim_effect",
    "subject_id": "STATIC-EvidenceExpectation",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:EvidenceExpectation:1",
    "_profile_meta": {
      "not": "native"
    }
  }
}
```

### ExecutionBindingRef

- 原 Registry source：C:\Projects\Agent_Workspace\PIPD\schemas\ExecutionBindingRef.schema.json；SHA `7c98cebfee30d9719cb8fd2d565c44120ce8d1be5b231071c19528cae1e95f50`；`$id=urn:pipd:s0:ExecutionBindingRef:1`；schema dialect 2020-12；additionalProperties=false。
- Producer/Consumer：Owner: HGK adapter. Consumer: HGK. Schema seam only until S5. Receiver binding id/version/hash/lease/state; ACK only after HGK admission.
- required：receiver_binding_id, receiver_binding_version, receiver_binding_hash, lease, state, subject_id, version, content_hash, schema_version。
- 專屬 Reader invariant：receiver_binding_id/version/hash+lease/state同原HGK Reader；seam不取代Issuer。
- Domain NEG：foreign lease generation used to execute → `LEASE_FENCING_DENY`；與 missing-required/unknown-key 的 schema拒收分開。
- roundtrip：原 Reader重序列化 payload，再讀回相同identity/trace；schema syntactic fixture通過不證明content_hash/Principal/License有效。
- POS/NEG payload（只供本輪Schema fixture，不是live artifact）：
```json
{
  "valid_shape_only": {
    "receiver_binding_id": "STATIC_FIXTURE_ExecutionBindingRef_receiver_binding_id",
    "receiver_binding_version": "STATIC_FIXTURE_ExecutionBindingRef_receiver_binding_version",
    "receiver_binding_hash": "STATIC_FIXTURE_ExecutionBindingRef_receiver_binding_hash",
    "lease": "STATIC_FIXTURE_ExecutionBindingRef_lease",
    "state": "STATIC_FIXTURE_ExecutionBindingRef_state",
    "subject_id": "STATIC-ExecutionBindingRef",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:ExecutionBindingRef:1"
  },
  "invalid_missing_required": {
    "receiver_binding_version": "STATIC_FIXTURE_ExecutionBindingRef_receiver_binding_version",
    "receiver_binding_hash": "STATIC_FIXTURE_ExecutionBindingRef_receiver_binding_hash",
    "lease": "STATIC_FIXTURE_ExecutionBindingRef_lease",
    "state": "STATIC_FIXTURE_ExecutionBindingRef_state",
    "subject_id": "STATIC-ExecutionBindingRef",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:ExecutionBindingRef:1"
  },
  "invalid_unknown_field": {
    "receiver_binding_id": "STATIC_FIXTURE_ExecutionBindingRef_receiver_binding_id",
    "receiver_binding_version": "STATIC_FIXTURE_ExecutionBindingRef_receiver_binding_version",
    "receiver_binding_hash": "STATIC_FIXTURE_ExecutionBindingRef_receiver_binding_hash",
    "lease": "STATIC_FIXTURE_ExecutionBindingRef_lease",
    "state": "STATIC_FIXTURE_ExecutionBindingRef_state",
    "subject_id": "STATIC-ExecutionBindingRef",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:ExecutionBindingRef:1",
    "_profile_meta": {
      "not": "native"
    }
  }
}
```

### ExecutionHandoff

- 原 Registry source：C:\Projects\Agent_Workspace\PIPD\schemas\ExecutionHandoff.schema.json；SHA `7fa36d3e7fe6e7416111b975381a42f3f5ad46cc81d97b610f317548815bd77b`；`$id=urn:pipd:s0:ExecutionHandoff:1`；schema dialect 2020-12；additionalProperties=false。
- Producer/Consumer：Owner: PIPD. Consumer: HGK/other receiver.
- required：receiver, abi_version, payload_refs, ack_nack_state, subject_id, version, content_hash, schema_version。
- 專屬 Reader invariant：receiver/abi_version/payload_refs真ACK payload hash與Consumer scope。
- Domain NEG：NACK or wrong receiver treated as ACK → `HANDOFF_NACK`；與 missing-required/unknown-key 的 schema拒收分開。
- roundtrip：原 Reader重序列化 payload，再讀回相同identity/trace；schema syntactic fixture通過不證明content_hash/Principal/License有效。
- POS/NEG payload（只供本輪Schema fixture，不是live artifact）：
```json
{
  "valid_shape_only": {
    "receiver": "STATIC_FIXTURE_ExecutionHandoff_receiver",
    "abi_version": "STATIC_FIXTURE_ExecutionHandoff_abi_version",
    "payload_refs": "STATIC_FIXTURE_ExecutionHandoff_payload_refs",
    "ack_nack_state": "STATIC_FIXTURE_ExecutionHandoff_ack_nack_state",
    "subject_id": "STATIC-ExecutionHandoff",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:ExecutionHandoff:1"
  },
  "invalid_missing_required": {
    "abi_version": "STATIC_FIXTURE_ExecutionHandoff_abi_version",
    "payload_refs": "STATIC_FIXTURE_ExecutionHandoff_payload_refs",
    "ack_nack_state": "STATIC_FIXTURE_ExecutionHandoff_ack_nack_state",
    "subject_id": "STATIC-ExecutionHandoff",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:ExecutionHandoff:1"
  },
  "invalid_unknown_field": {
    "receiver": "STATIC_FIXTURE_ExecutionHandoff_receiver",
    "abi_version": "STATIC_FIXTURE_ExecutionHandoff_abi_version",
    "payload_refs": "STATIC_FIXTURE_ExecutionHandoff_payload_refs",
    "ack_nack_state": "STATIC_FIXTURE_ExecutionHandoff_ack_nack_state",
    "subject_id": "STATIC-ExecutionHandoff",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:ExecutionHandoff:1",
    "_profile_meta": {
      "not": "native"
    }
  }
}
```

### GENIEProjectionRef

- 原 Registry source：C:\Projects\Agent_Workspace\PIPD\schemas\GENIEProjectionRef.schema.json；SHA `22c88a0f9ec4ea4747967546f9a5ea7f19f0285be60ac42567fae2ca0b1c36ed`；`$id=urn:pipd:s0:GENIEProjectionRef:1`；schema dialect 2020-12；additionalProperties=false。
- Producer/Consumer：Owner: GENIE adapter. Consumer: GENIE compiler. Schema seam only until S6. Target references to ProductGraph, Profile, Bundle and GENIEArtifact; no truth writeback.
- required：target_refs, subject_id, version, content_hash, schema_version。
- 專屬 Reader invariant：僅讀GENIE target_refs，保留SCHEMA_SEAM_ONLY；不成第二Writer。
- Domain NEG：projection creates native GENIE authority → `GENIE_WRITER_COLLISION`；與 missing-required/unknown-key 的 schema拒收分開。
- roundtrip：原 Reader重序列化 payload，再讀回相同identity/trace；schema syntactic fixture通過不證明content_hash/Principal/License有效。
- POS/NEG payload（只供本輪Schema fixture，不是live artifact）：
```json
{
  "valid_shape_only": {
    "target_refs": {
      "ProductGraph": "STATIC_REFERENCE_ProductGraph",
      "Profile": "STATIC_REFERENCE_Profile",
      "Bundle": "STATIC_REFERENCE_Bundle",
      "GENIEArtifact": "STATIC_REFERENCE_GENIEArtifact"
    },
    "subject_id": "STATIC-GENIEProjectionRef",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:GENIEProjectionRef:1"
  },
  "invalid_missing_required": {
    "subject_id": "STATIC-GENIEProjectionRef",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:GENIEProjectionRef:1"
  },
  "invalid_unknown_field": {
    "target_refs": {
      "ProductGraph": "STATIC_REFERENCE_ProductGraph",
      "Profile": "STATIC_REFERENCE_Profile",
      "Bundle": "STATIC_REFERENCE_Bundle",
      "GENIEArtifact": "STATIC_REFERENCE_GENIEArtifact"
    },
    "subject_id": "STATIC-GENIEProjectionRef",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:GENIEProjectionRef:1",
    "_profile_meta": {
      "not": "native"
    }
  }
}
```

### PD-PKG

- 原 Registry source：C:\Projects\Agent_Workspace\PIPD\schemas\PD-PKG.schema.json；SHA `37291e8790e03839308a7c36125f9576d14da725a27480c9759ef5362d255541`；`$id=urn:pipd:s0:PD-PKG:1`；schema dialect 2020-12；additionalProperties=false。
- Producer/Consumer：Owner: PIPD. Consumer: execution handoff.
- required：RepoContext, currentness, late_bound_construction_binding, subject_id, version, content_hash, schema_version。
- 專屬 Reader invariant：RepoContext 是當期真 root/HEAD/index/untracked，currentness 與晚綁 scope一致。
- Domain NEG：HEAD drift with old RepoContext → `PD_BIND_STALE`；與 missing-required/unknown-key 的 schema拒收分開。
- roundtrip：原 Reader重序列化 payload，再讀回相同identity/trace；schema syntactic fixture通過不證明content_hash/Principal/License有效。
- POS/NEG payload（只供本輪Schema fixture，不是live artifact）：
```json
{
  "valid_shape_only": {
    "RepoContext": "STATIC_FIXTURE_PD-PKG_RepoContext",
    "currentness": "STATIC_FIXTURE_PD-PKG_currentness",
    "late_bound_construction_binding": "STATIC_FIXTURE_PD-PKG_late_bound_construction_binding",
    "subject_id": "STATIC-PD-PKG",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:PD-PKG:1"
  },
  "invalid_missing_required": {
    "currentness": "STATIC_FIXTURE_PD-PKG_currentness",
    "late_bound_construction_binding": "STATIC_FIXTURE_PD-PKG_late_bound_construction_binding",
    "subject_id": "STATIC-PD-PKG",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:PD-PKG:1"
  },
  "invalid_unknown_field": {
    "RepoContext": "STATIC_FIXTURE_PD-PKG_RepoContext",
    "currentness": "STATIC_FIXTURE_PD-PKG_currentness",
    "late_bound_construction_binding": "STATIC_FIXTURE_PD-PKG_late_bound_construction_binding",
    "subject_id": "STATIC-PD-PKG",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:PD-PKG:1",
    "_profile_meta": {
      "not": "native"
    }
  }
}
```

### PI-PKG

- 原 Registry source：C:\Projects\Agent_Workspace\PIPD\schemas\PI-PKG.schema.json；SHA `2a204aceba8d2764310a729c7c105301296e11d57d6c91f17bb8372214f793fe`；`$id=urn:pipd:s0:PI-PKG:1`；schema dialect 2020-12；additionalProperties=false。
- Producer/Consumer：Owner: PIPD. Consumer: PD binder.
- required：stable_semantic_contract, trace, acceptance, subject_id, version, content_hash, schema_version。
- 專屬 Reader invariant：stable_semantic_contract 包含全部原原子 trace；Oracle canonical Writer相容。
- Domain NEG：sidecar appended as top-level _profile_meta → `PI_SCHEMA`；與 missing-required/unknown-key 的 schema拒收分開。
- roundtrip：原 Reader重序列化 payload，再讀回相同identity/trace；schema syntactic fixture通過不證明content_hash/Principal/License有效。
- POS/NEG payload（只供本輪Schema fixture，不是live artifact）：
```json
{
  "valid_shape_only": {
    "stable_semantic_contract": "STATIC_FIXTURE_PI-PKG_stable_semantic_contract",
    "trace": "STATIC_FIXTURE_PI-PKG_trace",
    "acceptance": "STATIC_FIXTURE_PI-PKG_acceptance",
    "subject_id": "STATIC-PI-PKG",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:PI-PKG:1"
  },
  "invalid_missing_required": {
    "trace": "STATIC_FIXTURE_PI-PKG_trace",
    "acceptance": "STATIC_FIXTURE_PI-PKG_acceptance",
    "subject_id": "STATIC-PI-PKG",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:PI-PKG:1"
  },
  "invalid_unknown_field": {
    "stable_semantic_contract": "STATIC_FIXTURE_PI-PKG_stable_semantic_contract",
    "trace": "STATIC_FIXTURE_PI-PKG_trace",
    "acceptance": "STATIC_FIXTURE_PI-PKG_acceptance",
    "subject_id": "STATIC-PI-PKG",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:PI-PKG:1",
    "_profile_meta": {
      "not": "native"
    }
  }
}
```

### ProfileBinding

- 原 Registry source：C:\Projects\Agent_Workspace\PIPD\schemas\ProfileBinding.schema.json；SHA `b559fb70bb6ceb9d491c989cb5ec031f44d15bcad5b40e75d6649aa059a93556`；`$id=urn:pipd:s0:ProfileBinding:1`；schema dialect 2020-12；additionalProperties=false。
- Producer/Consumer：Owner: PIPD. Consumer: Skills/JIT/HGK.
- required：profile, axes, vetoes, artifact_depth, assurance, subject_id, version, content_hash, schema_version。
- 專屬 Reader invariant：九軸 strict enum、去重與 safety veto 只升級；十二軸另存 lossless bridge。
- Domain NEG：unknown axis or downgrade ASSURED → `PROFILE_VETO`；與 missing-required/unknown-key 的 schema拒收分開。
- roundtrip：原 Reader重序列化 payload，再讀回相同identity/trace；schema syntactic fixture通過不證明content_hash/Principal/License有效。
- POS/NEG payload（只供本輪Schema fixture，不是live artifact）：
```json
{
  "valid_shape_only": {
    "profile": "STATIC_FIXTURE_ProfileBinding_profile",
    "axes": "STATIC_FIXTURE_ProfileBinding_axes",
    "vetoes": "STATIC_FIXTURE_ProfileBinding_vetoes",
    "artifact_depth": "STATIC_FIXTURE_ProfileBinding_artifact_depth",
    "assurance": "STATIC_FIXTURE_ProfileBinding_assurance",
    "subject_id": "STATIC-ProfileBinding",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:ProfileBinding:1"
  },
  "invalid_missing_required": {
    "axes": "STATIC_FIXTURE_ProfileBinding_axes",
    "vetoes": "STATIC_FIXTURE_ProfileBinding_vetoes",
    "artifact_depth": "STATIC_FIXTURE_ProfileBinding_artifact_depth",
    "assurance": "STATIC_FIXTURE_ProfileBinding_assurance",
    "subject_id": "STATIC-ProfileBinding",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:ProfileBinding:1"
  },
  "invalid_unknown_field": {
    "profile": "STATIC_FIXTURE_ProfileBinding_profile",
    "axes": "STATIC_FIXTURE_ProfileBinding_axes",
    "vetoes": "STATIC_FIXTURE_ProfileBinding_vetoes",
    "artifact_depth": "STATIC_FIXTURE_ProfileBinding_artifact_depth",
    "assurance": "STATIC_FIXTURE_ProfileBinding_assurance",
    "subject_id": "STATIC-ProfileBinding",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:ProfileBinding:1",
    "_profile_meta": {
      "not": "native"
    }
  }
}
```

### RequirementAtom

- 原 Registry source：C:\Projects\Agent_Workspace\PIPD\schemas\RequirementAtom.schema.json；SHA `021f6a30cf178190281176138686447e492640cf97b125f9c21a0aa2fa31c684`；`$id=urn:pipd:s0:RequirementAtom:1`；schema dialect 2020-12；additionalProperties=false。
- Producer/Consumer：Owner: PIPD. Consumer: PI compiler/TQAEP.
- required：req_id, source_clause, owner, acceptance_cue, risk_guard, subject_id, version, content_hash, schema_version。
- 專屬 Reader invariant：source_clause 實讀、owner 可識別、acceptance_cue 可反證、risk_guard 不空；保留否定作用域。
- Domain NEG：positive wording replaces source prohibition → `ATOM_POLARITY_LOSS`；與 missing-required/unknown-key 的 schema拒收分開。
- roundtrip：原 Reader重序列化 payload，再讀回相同identity/trace；schema syntactic fixture通過不證明content_hash/Principal/License有效。
- POS/NEG payload（只供本輪Schema fixture，不是live artifact）：
```json
{
  "valid_shape_only": {
    "req_id": "STATIC_FIXTURE_RequirementAtom_req_id",
    "source_clause": "STATIC_FIXTURE_RequirementAtom_source_clause",
    "owner": "STATIC_FIXTURE_RequirementAtom_owner",
    "acceptance_cue": "STATIC_FIXTURE_RequirementAtom_acceptance_cue",
    "risk_guard": "STATIC_FIXTURE_RequirementAtom_risk_guard",
    "subject_id": "STATIC-RequirementAtom",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:RequirementAtom:1"
  },
  "invalid_missing_required": {
    "source_clause": "STATIC_FIXTURE_RequirementAtom_source_clause",
    "owner": "STATIC_FIXTURE_RequirementAtom_owner",
    "acceptance_cue": "STATIC_FIXTURE_RequirementAtom_acceptance_cue",
    "risk_guard": "STATIC_FIXTURE_RequirementAtom_risk_guard",
    "subject_id": "STATIC-RequirementAtom",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:RequirementAtom:1"
  },
  "invalid_unknown_field": {
    "req_id": "STATIC_FIXTURE_RequirementAtom_req_id",
    "source_clause": "STATIC_FIXTURE_RequirementAtom_source_clause",
    "owner": "STATIC_FIXTURE_RequirementAtom_owner",
    "acceptance_cue": "STATIC_FIXTURE_RequirementAtom_acceptance_cue",
    "risk_guard": "STATIC_FIXTURE_RequirementAtom_risk_guard",
    "subject_id": "STATIC-RequirementAtom",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:RequirementAtom:1",
    "_profile_meta": {
      "not": "native"
    }
  }
}
```

### SurfaceProjectionManifest

- 原 Registry source：C:\Projects\Agent_Workspace\PIPD\schemas\SurfaceProjectionManifest.schema.json；SHA `87f8057e8dac68f304ed4e9c2dd118a26c69428015769ab09d39398d34dcb57d`；`$id=urn:pipd:s0:SurfaceProjectionManifest:1`；schema dialect 2020-12；additionalProperties=false。
- Producer/Consumer：Owner: PIPD. Consumer: surface compiler.
- required：surface, source_hashes, generated_files, parity_loss, stale_rule, subject_id, version, content_hash, schema_version。
- 專屬 Reader invariant：surface/source_hashes/generated_files/parity_loss/stale_rule可重算；loss不默丟。
- Domain NEG：stale source hash still projected as current → `PROJECTION_STALE`；與 missing-required/unknown-key 的 schema拒收分開。
- roundtrip：原 Reader重序列化 payload，再讀回相同identity/trace；schema syntactic fixture通過不證明content_hash/Principal/License有效。
- POS/NEG payload（只供本輪Schema fixture，不是live artifact）：
```json
{
  "valid_shape_only": {
    "surface": "STATIC_FIXTURE_SurfaceProjectionManifest_surface",
    "source_hashes": "STATIC_FIXTURE_SurfaceProjectionManifest_source_hashes",
    "generated_files": "STATIC_FIXTURE_SurfaceProjectionManifest_generated_files",
    "parity_loss": "STATIC_FIXTURE_SurfaceProjectionManifest_parity_loss",
    "stale_rule": "STATIC_FIXTURE_SurfaceProjectionManifest_stale_rule",
    "subject_id": "STATIC-SurfaceProjectionManifest",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:SurfaceProjectionManifest:1"
  },
  "invalid_missing_required": {
    "source_hashes": "STATIC_FIXTURE_SurfaceProjectionManifest_source_hashes",
    "generated_files": "STATIC_FIXTURE_SurfaceProjectionManifest_generated_files",
    "parity_loss": "STATIC_FIXTURE_SurfaceProjectionManifest_parity_loss",
    "stale_rule": "STATIC_FIXTURE_SurfaceProjectionManifest_stale_rule",
    "subject_id": "STATIC-SurfaceProjectionManifest",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:SurfaceProjectionManifest:1"
  },
  "invalid_unknown_field": {
    "surface": "STATIC_FIXTURE_SurfaceProjectionManifest_surface",
    "source_hashes": "STATIC_FIXTURE_SurfaceProjectionManifest_source_hashes",
    "generated_files": "STATIC_FIXTURE_SurfaceProjectionManifest_generated_files",
    "parity_loss": "STATIC_FIXTURE_SurfaceProjectionManifest_parity_loss",
    "stale_rule": "STATIC_FIXTURE_SurfaceProjectionManifest_stale_rule",
    "subject_id": "STATIC-SurfaceProjectionManifest",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:SurfaceProjectionManifest:1",
    "_profile_meta": {
      "not": "native"
    }
  }
}
```

### TaskSpecSeed

- 原 Registry source：C:\Projects\Agent_Workspace\PIPD\schemas\TaskSpecSeed.schema.json；SHA `c6e086aef0e4f21179cba52c5187c33a3873b18732c669c4d03bcad057e9b6cc`；`$id=urn:pipd:s0:TaskSpecSeed:1`；schema dialect 2020-12；additionalProperties=false。
- Producer/Consumer：Owner: PIPD. Consumer: receiver adapter.
- required：goal, inputs, outputs, constraints, dependencies, tests, rollback, evidence, subject_id, version, content_hash, schema_version。
- 專屬 Reader invariant：goal→inputs→outputs→tests→rollback/evidence 可閉合且 dependencies 有具名輸出。
- Domain NEG：output has no consumer or test → `TASKSEED_INCOMPLETE`；與 missing-required/unknown-key 的 schema拒收分開。
- roundtrip：原 Reader重序列化 payload，再讀回相同identity/trace；schema syntactic fixture通過不證明content_hash/Principal/License有效。
- POS/NEG payload（只供本輪Schema fixture，不是live artifact）：
```json
{
  "valid_shape_only": {
    "goal": "STATIC_FIXTURE_TaskSpecSeed_goal",
    "inputs": "STATIC_FIXTURE_TaskSpecSeed_inputs",
    "outputs": "STATIC_FIXTURE_TaskSpecSeed_outputs",
    "constraints": "STATIC_FIXTURE_TaskSpecSeed_constraints",
    "dependencies": "STATIC_FIXTURE_TaskSpecSeed_dependencies",
    "tests": "STATIC_FIXTURE_TaskSpecSeed_tests",
    "rollback": "STATIC_FIXTURE_TaskSpecSeed_rollback",
    "evidence": "STATIC_FIXTURE_TaskSpecSeed_evidence",
    "subject_id": "STATIC-TaskSpecSeed",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:TaskSpecSeed:1"
  },
  "invalid_missing_required": {
    "inputs": "STATIC_FIXTURE_TaskSpecSeed_inputs",
    "outputs": "STATIC_FIXTURE_TaskSpecSeed_outputs",
    "constraints": "STATIC_FIXTURE_TaskSpecSeed_constraints",
    "dependencies": "STATIC_FIXTURE_TaskSpecSeed_dependencies",
    "tests": "STATIC_FIXTURE_TaskSpecSeed_tests",
    "rollback": "STATIC_FIXTURE_TaskSpecSeed_rollback",
    "evidence": "STATIC_FIXTURE_TaskSpecSeed_evidence",
    "subject_id": "STATIC-TaskSpecSeed",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:TaskSpecSeed:1"
  },
  "invalid_unknown_field": {
    "goal": "STATIC_FIXTURE_TaskSpecSeed_goal",
    "inputs": "STATIC_FIXTURE_TaskSpecSeed_inputs",
    "outputs": "STATIC_FIXTURE_TaskSpecSeed_outputs",
    "constraints": "STATIC_FIXTURE_TaskSpecSeed_constraints",
    "dependencies": "STATIC_FIXTURE_TaskSpecSeed_dependencies",
    "tests": "STATIC_FIXTURE_TaskSpecSeed_tests",
    "rollback": "STATIC_FIXTURE_TaskSpecSeed_rollback",
    "evidence": "STATIC_FIXTURE_TaskSpecSeed_evidence",
    "subject_id": "STATIC-TaskSpecSeed",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:TaskSpecSeed:1",
    "_profile_meta": {
      "not": "native"
    }
  }
}
```

### TechnologyAdmission

- 原 Registry source：C:\Projects\Agent_Workspace\PIPD\schemas\TechnologyAdmission.schema.json；SHA `40703552af4fb14c7aa87dd68ead6eac1cf7d272541fda273cf22b8fb109c4d6`；`$id=urn:pipd:s0:TechnologyAdmission:1`；schema dialect 2020-12；additionalProperties=false。
- Producer/Consumer：Owner: PIPD. Consumer: tool/provider adapters. Tightened from the untyped `{}` shape found in review: every field now carries a type and the source's 24-column design record (PKG-00 §9.2) is representable without additionalProperties loss.
- required：capability_need, candidate, disposition, pin_license_currentness, fallback_exit, subject_id, version, content_hash, schema_version, technology_id, external_name, capability_slot, license, immutable_pin。
- 專屬 Reader invariant：原 disposition 與17-state不默變；license+immutable_pin 真讀回，REJECT 不進 install。
- Domain NEG：REJECT candidate sent to installer → `TECH_ADMISSION_DENY`；與 missing-required/unknown-key 的 schema拒收分開。
- roundtrip：原 Reader重序列化 payload，再讀回相同identity/trace；schema syntactic fixture通過不證明content_hash/Principal/License有效。
- POS/NEG payload（只供本輪Schema fixture，不是live artifact）：
```json
{
  "valid_shape_only": {
    "capability_need": "STATIC_FIXTURE_TechnologyAdmission_capability_need",
    "candidate": "STATIC_FIXTURE_TechnologyAdmission_candidate",
    "disposition": "STATIC_FIXTURE_TechnologyAdmission_disposition",
    "pin_license_currentness": {},
    "fallback_exit": "STATIC_FIXTURE_TechnologyAdmission_fallback_exit",
    "subject_id": "STATIC-TechnologyAdmission",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:TechnologyAdmission:1",
    "technology_id": "STATIC_FIXTURE_TechnologyAdmission_technology_id",
    "external_name": "STATIC_FIXTURE_TechnologyAdmission_external_name",
    "capability_slot": "STATIC_FIXTURE_TechnologyAdmission_capability_slot",
    "license": "STATIC_FIXTURE_TechnologyAdmission_license",
    "immutable_pin": "STATIC_FIXTURE_TechnologyAdmission_immutable_pin"
  },
  "invalid_missing_required": {
    "candidate": "STATIC_FIXTURE_TechnologyAdmission_candidate",
    "disposition": "STATIC_FIXTURE_TechnologyAdmission_disposition",
    "pin_license_currentness": {},
    "fallback_exit": "STATIC_FIXTURE_TechnologyAdmission_fallback_exit",
    "subject_id": "STATIC-TechnologyAdmission",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:TechnologyAdmission:1",
    "technology_id": "STATIC_FIXTURE_TechnologyAdmission_technology_id",
    "external_name": "STATIC_FIXTURE_TechnologyAdmission_external_name",
    "capability_slot": "STATIC_FIXTURE_TechnologyAdmission_capability_slot",
    "license": "STATIC_FIXTURE_TechnologyAdmission_license",
    "immutable_pin": "STATIC_FIXTURE_TechnologyAdmission_immutable_pin"
  },
  "invalid_unknown_field": {
    "capability_need": "STATIC_FIXTURE_TechnologyAdmission_capability_need",
    "candidate": "STATIC_FIXTURE_TechnologyAdmission_candidate",
    "disposition": "STATIC_FIXTURE_TechnologyAdmission_disposition",
    "pin_license_currentness": {},
    "fallback_exit": "STATIC_FIXTURE_TechnologyAdmission_fallback_exit",
    "subject_id": "STATIC-TechnologyAdmission",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:TechnologyAdmission:1",
    "technology_id": "STATIC_FIXTURE_TechnologyAdmission_technology_id",
    "external_name": "STATIC_FIXTURE_TechnologyAdmission_external_name",
    "capability_slot": "STATIC_FIXTURE_TechnologyAdmission_capability_slot",
    "license": "STATIC_FIXTURE_TechnologyAdmission_license",
    "immutable_pin": "STATIC_FIXTURE_TechnologyAdmission_immutable_pin",
    "_profile_meta": {
      "not": "native"
    }
  }
}
```

### TQAEP

- 原 Registry source：C:\Projects\Agent_Workspace\PIPD\schemas\TQAEP.schema.json；SHA `d14092817befb5e81c470449b9ac5160b6fba7e3fcde450ec00d1cadc21820cd`；`$id=urn:pipd:s0:TQAEP:1`；schema dialect 2020-12；additionalProperties=false。
- Producer/Consumer：Owner: PIPD/TQAEP semantics. Consumer: Independent checker/release.
- required：tests, oracles, fixtures, acceptance, requalification, subject_id, version, content_hash, schema_version。
- 專屬 Reader invariant：tests/oracles/fixtures/acceptance/requalification 逐atom對應；受保護receipt另讀。
- Domain NEG：PlannedTQAEP or Maker expected interpreted as actual verdict → `SELF_ACCEPTANCE_DENY`；與 missing-required/unknown-key 的 schema拒收分開。
- roundtrip：原 Reader重序列化 payload，再讀回相同identity/trace；schema syntactic fixture通過不證明content_hash/Principal/License有效。
- POS/NEG payload（只供本輪Schema fixture，不是live artifact）：
```json
{
  "valid_shape_only": {
    "tests": "STATIC_FIXTURE_TQAEP_tests",
    "oracles": "STATIC_FIXTURE_TQAEP_oracles",
    "fixtures": "STATIC_FIXTURE_TQAEP_fixtures",
    "acceptance": "STATIC_FIXTURE_TQAEP_acceptance",
    "requalification": "STATIC_FIXTURE_TQAEP_requalification",
    "subject_id": "STATIC-TQAEP",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:TQAEP:1"
  },
  "invalid_missing_required": {
    "oracles": "STATIC_FIXTURE_TQAEP_oracles",
    "fixtures": "STATIC_FIXTURE_TQAEP_fixtures",
    "acceptance": "STATIC_FIXTURE_TQAEP_acceptance",
    "requalification": "STATIC_FIXTURE_TQAEP_requalification",
    "subject_id": "STATIC-TQAEP",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:TQAEP:1"
  },
  "invalid_unknown_field": {
    "tests": "STATIC_FIXTURE_TQAEP_tests",
    "oracles": "STATIC_FIXTURE_TQAEP_oracles",
    "fixtures": "STATIC_FIXTURE_TQAEP_fixtures",
    "acceptance": "STATIC_FIXTURE_TQAEP_acceptance",
    "requalification": "STATIC_FIXTURE_TQAEP_requalification",
    "subject_id": "STATIC-TQAEP",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:TQAEP:1",
    "_profile_meta": {
      "not": "native"
    }
  }
}
```

### TraceLink

- 原 Registry source：C:\Projects\Agent_Workspace\PIPD\schemas\TraceLink.schema.json；SHA `ff6ef713b95a1a2812bd31d2b10cdcc064671c986d29d0e69318dc5a9f54e5e4`；`$id=urn:pipd:s0:TraceLink:1`；schema dialect 2020-12；additionalProperties=false。
- Producer/Consumer：Owner: PIPD/TQAEP. Consumer: validators/checkers.
- required：from_type, from_id, from_hash, to_type, to_id, to_hash, rationale, subject_id, version, content_hash, schema_version。
- 專屬 Reader invariant：from_id/from_hash 與 to_id/to_hash 可在 bundle雙向解析；方向不交換。
- Domain NEG：to_hash names another candidate → `TRACE_HASH_MISMATCH`；與 missing-required/unknown-key 的 schema拒收分開。
- roundtrip：原 Reader重序列化 payload，再讀回相同identity/trace；schema syntactic fixture通過不證明content_hash/Principal/License有效。
- POS/NEG payload（只供本輪Schema fixture，不是live artifact）：
```json
{
  "valid_shape_only": {
    "from_type": "STATIC_FIXTURE_TraceLink_from_type",
    "from_id": "STATIC_FIXTURE_TraceLink_from_id",
    "from_hash": "STATIC_FIXTURE_TraceLink_from_hash",
    "to_type": "STATIC_FIXTURE_TraceLink_to_type",
    "to_id": "STATIC_FIXTURE_TraceLink_to_id",
    "to_hash": "STATIC_FIXTURE_TraceLink_to_hash",
    "rationale": "STATIC_FIXTURE_TraceLink_rationale",
    "subject_id": "STATIC-TraceLink",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:TraceLink:1"
  },
  "invalid_missing_required": {
    "from_id": "STATIC_FIXTURE_TraceLink_from_id",
    "from_hash": "STATIC_FIXTURE_TraceLink_from_hash",
    "to_type": "STATIC_FIXTURE_TraceLink_to_type",
    "to_id": "STATIC_FIXTURE_TraceLink_to_id",
    "to_hash": "STATIC_FIXTURE_TraceLink_to_hash",
    "rationale": "STATIC_FIXTURE_TraceLink_rationale",
    "subject_id": "STATIC-TraceLink",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:TraceLink:1"
  },
  "invalid_unknown_field": {
    "from_type": "STATIC_FIXTURE_TraceLink_from_type",
    "from_id": "STATIC_FIXTURE_TraceLink_from_id",
    "from_hash": "STATIC_FIXTURE_TraceLink_from_hash",
    "to_type": "STATIC_FIXTURE_TraceLink_to_type",
    "to_id": "STATIC_FIXTURE_TraceLink_to_id",
    "to_hash": "STATIC_FIXTURE_TraceLink_to_hash",
    "rationale": "STATIC_FIXTURE_TraceLink_rationale",
    "subject_id": "STATIC-TraceLink",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:TraceLink:1",
    "_profile_meta": {
      "not": "native"
    }
  }
}
```

### WorkOrderCandidate

- 原 Registry source：C:\Projects\Agent_Workspace\PIPD\schemas\WorkOrderCandidate.schema.json；SHA `03a8692f183f106ec7e4739b925c980ba07d68551627ca6af315fa9f9e2caf54`；`$id=urn:pipd:s0:WorkOrderCandidate:1`；schema dialect 2020-12；additionalProperties=false。
- Producer/Consumer：Owner: PIPD. Consumer: HGK admission. Candidate only; never runtime authority.
- required：candidate_only, subject_id, version, content_hash, schema_version。
- 專屬 Reader invariant：candidate_only=true；只送原HGK admission，不能直接 enqueue。
- Domain NEG：candidate_only=false → `CANDIDATE_NOT_AUTHORITY`；與 missing-required/unknown-key 的 schema拒收分開。
- roundtrip：原 Reader重序列化 payload，再讀回相同identity/trace；schema syntactic fixture通過不證明content_hash/Principal/License有效。
- POS/NEG payload（只供本輪Schema fixture，不是live artifact）：
```json
{
  "valid_shape_only": {
    "candidate_only": true,
    "subject_id": "STATIC-WorkOrderCandidate",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:WorkOrderCandidate:1"
  },
  "invalid_missing_required": {
    "subject_id": "STATIC-WorkOrderCandidate",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:WorkOrderCandidate:1"
  },
  "invalid_unknown_field": {
    "candidate_only": true,
    "subject_id": "STATIC-WorkOrderCandidate",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:WorkOrderCandidate:1",
    "_profile_meta": {
      "not": "native"
    }
  }
}
```


## R2-02-CLI：13 原 verb 的 parser 真讀回與額外 verb 衝突

當期 `C:/Projects/Agent_Workspace/PIPD/src/pipd_ls_sp/cli.py` SHA `6db0f828f0a445fcf3593b158c534d02a0a89f1e263746cabda8c043dd462cc9` 的 source module 已實跑 help/invalid parser；這是 SOURCE_MODULE_INVOKED，不是 installed binary Loaded Receipt。實作列14個verb，額外 compile-cc；原13保持獨立分母，額外verb為 `ABI_HOLD_CLI_13_14`，由PIPD CLI Owner決定版本相容/alias，不在本輪偷偷刪原需求或增第14條規範。

### pipd init

- binaryOrigin：source module via Python311 `-B -m pipd_ls_sp.cli`；cwd 本任務 work；installed binary origin NOT_OBSERVED。
- effectScope：LOCAL_DRAFT_WRITE_CANDIDATE_ONLY; repair actual repo scope requires L2；此輪只 `--help` 和 invalid flag，不執行該verb效果。
- helpSchema（exit=0）：

```text
usage: pipd init [-h]

options:
  -h, --help  show this help message and exit
```

- nonzero：`init --definitely-invalid-flag` exit=2，typed stdout：

```text
{
 "code": "USAGE_INVALID",
 "message": "invalid command line; see --help for the 13 commands",
 "verdict": "FAIL"
}
```

- 真實作用的POS/NEG與permission保留原下列契約；parser help成功不能聲稱compile/doctor功能已被本輪執行。

### pipd intake

- binaryOrigin：source module via Python311 `-B -m pipd_ls_sp.cli`；cwd 本任務 work；installed binary origin NOT_OBSERVED。
- effectScope：LOCAL_DRAFT_WRITE_CANDIDATE_ONLY; repair actual repo scope requires L2；此輪只 `--help` 和 invalid flag，不執行該verb效果。
- helpSchema（exit=0）：

```text
usage: pipd intake [-h] --goal GOAL [--source SOURCE]
                   [--constraint CONSTRAINT] [--non-goal NON_GOAL]

options:
  -h, --help            show this help message and exit
  --goal GOAL
  --source SOURCE
  --constraint CONSTRAINT
  --non-goal NON_GOAL
```

- nonzero：`intake --definitely-invalid-flag` exit=2，typed stdout：

```text
{
 "code": "USAGE_INVALID",
 "message": "invalid command line; see --help for the 13 commands",
 "verdict": "FAIL"
}
```

- 真實作用的POS/NEG與permission保留原下列契約；parser help成功不能聲稱compile/doctor功能已被本輪執行。

### pipd profile

- binaryOrigin：source module via Python311 `-B -m pipd_ls_sp.cli`；cwd 本任務 work；installed binary origin NOT_OBSERVED。
- effectScope：LOCAL_DRAFT_WRITE_CANDIDATE_ONLY; repair actual repo scope requires L2；此輪只 `--help` 和 invalid flag，不執行該verb效果。
- helpSchema（exit=0）：

```text
usage: pipd profile [-h] [--profile PROFILE] [--axis AXIS]

options:
  -h, --help         show this help message and exit
  --profile PROFILE
  --axis AXIS
```

- nonzero：`profile --definitely-invalid-flag` exit=2，typed stdout：

```text
{
 "code": "USAGE_INVALID",
 "message": "invalid command line; see --help for the 13 commands",
 "verdict": "FAIL"
}
```

- 真實作用的POS/NEG與permission保留原下列契約；parser help成功不能聲稱compile/doctor功能已被本輪執行。

### pipd compile-pi

- binaryOrigin：source module via Python311 `-B -m pipd_ls_sp.cli`；cwd 本任務 work；installed binary origin NOT_OBSERVED。
- effectScope：LOCAL_DRAFT_WRITE_CANDIDATE_ONLY; repair actual repo scope requires L2；此輪只 `--help` 和 invalid flag，不執行該verb效果。
- helpSchema（exit=0）：

```text
usage: pipd compile-pi [-h] --intent INTENT [--profile PROFILE] [--explain]
                       [--replay]

options:
  -h, --help         show this help message and exit
  --intent INTENT
  --profile PROFILE
  --explain
  --replay
```

- nonzero：`compile-pi --definitely-invalid-flag` exit=2，typed stdout：

```text
{
 "code": "USAGE_INVALID",
 "message": "invalid command line; see --help for the 13 commands",
 "verdict": "FAIL"
}
```

- 真實作用的POS/NEG與permission保留原下列契約；parser help成功不能聲稱compile/doctor功能已被本輪執行。

### pipd bind-pd

- binaryOrigin：source module via Python311 `-B -m pipd_ls_sp.cli`；cwd 本任務 work；installed binary origin NOT_OBSERVED。
- effectScope：LOCAL_DRAFT_WRITE_CANDIDATE_ONLY; repair actual repo scope requires L2；此輪只 `--help` 和 invalid flag，不執行該verb效果。
- helpSchema（exit=0）：

```text
usage: pipd bind-pd [-h] --pi PI [--repo-root REPO_ROOT] [--head HEAD]

options:
  -h, --help            show this help message and exit
  --pi PI
  --repo-root REPO_ROOT
  --head HEAD
```

- nonzero：`bind-pd --definitely-invalid-flag` exit=2，typed stdout：

```text
{
 "code": "USAGE_INVALID",
 "message": "invalid command line; see --help for the 13 commands",
 "verdict": "FAIL"
}
```

- 真實作用的POS/NEG與permission保留原下列契約；parser help成功不能聲稱compile/doctor功能已被本輪執行。

### pipd compile-ecp

- binaryOrigin：source module via Python311 `-B -m pipd_ls_sp.cli`；cwd 本任務 work；installed binary origin NOT_OBSERVED。
- effectScope：LOCAL_DRAFT_WRITE_CANDIDATE_ONLY; repair actual repo scope requires L2；此輪只 `--help` 和 invalid flag，不執行該verb效果。
- helpSchema（exit=0）：

```text
usage: pipd compile-ecp [-h] --pd PD --pi PI [--explain]

options:
  -h, --help  show this help message and exit
  --pd PD
  --pi PI
  --explain
```

- nonzero：`compile-ecp --definitely-invalid-flag` exit=2，typed stdout：

```text
{
 "code": "USAGE_INVALID",
 "message": "invalid command line; see --help for the 13 commands",
 "verdict": "FAIL"
}
```

- 真實作用的POS/NEG與permission保留原下列契約；parser help成功不能聲稱compile/doctor功能已被本輪執行。

### pipd compile-tqaep

- binaryOrigin：source module via Python311 `-B -m pipd_ls_sp.cli`；cwd 本任務 work；installed binary origin NOT_OBSERVED。
- effectScope：LOCAL_DRAFT_WRITE_CANDIDATE_ONLY; repair actual repo scope requires L2；此輪只 `--help` 和 invalid flag，不執行該verb效果。
- helpSchema（exit=0）：

```text
usage: pipd compile-tqaep [-h] --pi PI --ecp ECP [--maker MAKER]
                          [--checker CHECKER]
                          [--checker-receipt CHECKER_RECEIPT] [--explain]

options:
  -h, --help            show this help message and exit
  --pi PI
  --ecp ECP
  --maker MAKER
  --checker CHECKER
  --checker-receipt CHECKER_RECEIPT
  --explain
```

- nonzero：`compile-tqaep --definitely-invalid-flag` exit=2，typed stdout：

```text
{
 "code": "USAGE_INVALID",
 "message": "invalid command line; see --help for the 13 commands",
 "verdict": "FAIL"
}
```

- 真實作用的POS/NEG與permission保留原下列契約；parser help成功不能聲稱compile/doctor功能已被本輪執行。

### pipd validate

- binaryOrigin：source module via Python311 `-B -m pipd_ls_sp.cli`；cwd 本任務 work；installed binary origin NOT_OBSERVED。
- effectScope：SOURCE_READ；此輪只 `--help` 和 invalid flag，不執行該verb效果。
- helpSchema（exit=0）：

```text
usage: pipd validate [-h] --bundle BUNDLE [--explain]

options:
  -h, --help       show this help message and exit
  --bundle BUNDLE
  --explain
```

- nonzero：`validate --definitely-invalid-flag` exit=2，typed stdout：

```text
{
 "code": "USAGE_INVALID",
 "message": "invalid command line; see --help for the 13 commands",
 "verdict": "FAIL"
}
```

- 真實作用的POS/NEG與permission保留原下列契約；parser help成功不能聲稱compile/doctor功能已被本輪執行。

### pipd doctor

- binaryOrigin：source module via Python311 `-B -m pipd_ls_sp.cli`；cwd 本任務 work；installed binary origin NOT_OBSERVED。
- effectScope：SOURCE_READ；此輪只 `--help` 和 invalid flag，不執行該verb效果。
- helpSchema（exit=0）：

```text
usage: pipd doctor [-h]

options:
  -h, --help  show this help message and exit
```

- nonzero：`doctor --definitely-invalid-flag` exit=2，typed stdout：

```text
{
 "code": "USAGE_INVALID",
 "message": "invalid command line; see --help for the 13 commands",
 "verdict": "FAIL"
}
```

- 真實作用的POS/NEG與permission保留原下列契約；parser help成功不能聲稱compile/doctor功能已被本輪執行。

### pipd project

- binaryOrigin：source module via Python311 `-B -m pipd_ls_sp.cli`；cwd 本任務 work；installed binary origin NOT_OBSERVED。
- effectScope：LOCAL_DRAFT_WRITE_CANDIDATE_ONLY; repair actual repo scope requires L2；此輪只 `--help` 和 invalid flag，不執行該verb效果。
- helpSchema（exit=0）：

```text
usage: pipd project [-h] [--out OUT] [--root SUB_ROOT] [--dry-run]
                    [--allow-root ALLOW_ROOT] [--allow-replace]

options:
  -h, --help            show this help message and exit
  --out OUT
  --root SUB_ROOT
  --dry-run
  --allow-root ALLOW_ROOT
  --allow-replace
```

- nonzero：`project --definitely-invalid-flag` exit=2，typed stdout：

```text
{
 "code": "USAGE_INVALID",
 "message": "invalid command line; see --help for the 13 commands",
 "verdict": "FAIL"
}
```

- 真實作用的POS/NEG與permission保留原下列契約；parser help成功不能聲稱compile/doctor功能已被本輪執行。

### pipd export

- binaryOrigin：source module via Python311 `-B -m pipd_ls_sp.cli`；cwd 本任務 work；installed binary origin NOT_OBSERVED。
- effectScope：LOCAL_DRAFT_WRITE_CANDIDATE_ONLY; repair actual repo scope requires L2；此輪只 `--help` 和 invalid flag，不執行該verb效果。
- helpSchema（exit=0）：

```text
usage: pipd export [-h] [--out OUT] [--dry-run] [--root SUB_ROOT]
                   [--allow-root ALLOW_ROOT] [--allow-replace]

options:
  -h, --help            show this help message and exit
  --out OUT
  --dry-run
  --root SUB_ROOT
  --allow-root ALLOW_ROOT
  --allow-replace
```

- nonzero：`export --definitely-invalid-flag` exit=2，typed stdout：

```text
{
 "code": "USAGE_INVALID",
 "message": "invalid command line; see --help for the 13 commands",
 "verdict": "FAIL"
}
```

- 真實作用的POS/NEG與permission保留原下列契約；parser help成功不能聲稱compile/doctor功能已被本輪執行。

### pipd diff

- binaryOrigin：source module via Python311 `-B -m pipd_ls_sp.cli`；cwd 本任務 work；installed binary origin NOT_OBSERVED。
- effectScope：SOURCE_READ；此輪只 `--help` 和 invalid flag，不執行該verb效果。
- helpSchema（exit=0）：

```text
usage: pipd diff [-h] --a A --b B [--explain]

options:
  -h, --help  show this help message and exit
  --a A
  --b B
  --explain
```

- nonzero：`diff --definitely-invalid-flag` exit=2，typed stdout：

```text
{
 "code": "USAGE_INVALID",
 "message": "invalid command line; see --help for the 13 commands",
 "verdict": "FAIL"
}
```

- 真實作用的POS/NEG與permission保留原下列契約；parser help成功不能聲稱compile/doctor功能已被本輪執行。

### pipd repair

- binaryOrigin：source module via Python311 `-B -m pipd_ls_sp.cli`；cwd 本任務 work；installed binary origin NOT_OBSERVED。
- effectScope：LOCAL_DRAFT_WRITE_CANDIDATE_ONLY; repair actual repo scope requires L2；此輪只 `--help` 和 invalid flag，不執行該verb效果。
- helpSchema（exit=0）：

```text
usage: pipd repair [-h] --subject SUBJECT [--authorized-root AUTHORIZED_ROOT]
                   [--scope SCOPE] [--maker MAKER] [--dry-run]

options:
  -h, --help            show this help message and exit
  --subject SUBJECT
  --authorized-root AUTHORIZED_ROOT
  --scope SCOPE
  --maker MAKER
  --dry-run
```

- nonzero：`repair --definitely-invalid-flag` exit=2，typed stdout：

```text
{
 "code": "USAGE_INVALID",
 "message": "invalid command line; see --help for the 13 commands",
 "verdict": "FAIL"
}
```

- 真實作用的POS/NEG與permission保留原下列契約；parser help成功不能聲稱compile/doctor功能已被本輪執行。


## 保留的原生命周期與三SPEC接口


# TPM K0–K3、18 Stage 與八技能 PIPD 生命週期

> **效力**：本檔為 `BODY-02` 的來源約束施工設計候選，保留來源章節的原 ID、Decision、POS/NEG、HOLD；尚不是任何正式 PI/PD/ECP/Permit/WorkOrder/Checker Verdict 或 Release。凡提及 `PROPOSED` 的 ABI，需由原 Owner／Host Registry 真正綁定。

## 6. TPM-SP / Native FHS-TPM：18 Stage、K0–K3 與三種 SPEC 的真工程契約

本章對 v1 §0.1、§4.1 的操作級展開是正式現行設計：`sbl-tpm-sp` 的產品規劃功能不能冒充 PIPD Native Compiler。每張 Stage 的結果為 `PROPOSED`；`T4/T5` 原狀態對應 `CR-DOC04-STATE-MAP` 未決，任何草稿成功不可直接改 PIPD StateEnum。[SRC-53:§3.2–3.v2][PLUGIN:tpm-product-plan/tpm-system-plan/tpm-program-plan]

### 6.1 Cold Host K0→K1→K2→K3：24 個 base DOC 不重上傳

| 能力 | 精確動作與輸出、Reader | POS / NEG / FirstFail / 回退 |
|---|---|---|
| K0 ImmutableCorpusBundle@1 | SBL DOC00–13＋PIPD DOC00–09 的版本化完整 bytes/SHA/Domain Writer/License 編成 ImmutableCorpusManifest；TPM/Host Reader 必核算每一 bytes，FHS/B1 overlay 是可撤的非 Canonical 層。 | POS 離線 fresh host 讀回 24/24 同 digest；NEG 只有 SKILL.md 或偷要求已內建 DOC 重新上傳→K0_SOURCE_MISSING；回復前一已知好的 bundle。 |
| K1 ClauseIndex@1 | K0 原 bytes→heading/line span/TextSHA/parent/SourceRef，不改 source polarity；只允許受權 root 內定位，供 K3。 | POS 每節 readback 同文；NEG 任意 ../、重複 locator、stale SHA→K1_INDEX_DRIFT；依 K0 重建受影索引。 |
| K2 SupersessionConflictRegistry@1 | 以 Writer/domain/supersedes hash/scope 建 CurrentReadView，跨領域 PIPD/SBL 不是日期較新者自動覆蓋；輸出 ConflictTicket→Owner。 | POS 舊版可追溯/現行正確；NEG DOC07 跨 Writer 混合→K2_WRITER_CONFLICT；保留兩版及 HOLD。 |
| K3 OnDemandReadOnlyReader@1 | (subject, source_id,source_sha,clause,read_scope)→驗 K0–2，回 SourceBoundExcerpt（含原檔行號與 ACL）予三 SPEC；合法取用局部段落但基礎物理 bytes 已完整校驗。 | POS 同 SourceHash 再讀仍一致；NEG cached stale 或原 DOC prompt-injection 改權限→K3_SOURCE_UNTRUSTED；僅 invalidate 受影 Question/Spec。 |

**真正啟用**需 `PACKAGED→INSTALLED→HOST_LOADED→INVOKED→FUNCTIONALLY_QUALIFIED` 真證據；未實測的 Plugin 雖聲稱自帶 DOC，仍為 `HOST_PENDING`。K0 缺一件才只停使用該件的 Spec，不全域停 L0。[SRC-53:L198–207]

### 6.2 PM／SE／TPgM × T0–T5（18 張相互獨立 StageContract）

`T0 Discover/T1 Product/T2 System/T3 Program/T4 Handoff/T5 Review` 是**此包閱讀別名**，不替換原三個 Role StageMap。每列的 SourceRef、Owner、受影 CaseID 皆在產物中回帶；若 Stage 的 source/permission 不滿足，產 `StageNACK(first_fail,resume_predicate)` 而非虛構正式轉移。

| Role:Stage | EntryGuard / Operations | Typed Result → Consumer | POS / NEG 與續作 |
|---|---|---|---|

| PM:T0 | 有 Goal+Source → 去重提取 JTBD/persona | ProductKnownState@PROPOSED → PM/T1 | POS 相同 source 零重問；NEG 空 Source→SOURCE_MISSING；只 PARK 受影階段，T4/T5 狀態轉移待 Owner Schema |

| PM:T1 | 有 T0 Readset → 定義 pain/FUO/非目標 | ProductSuccess@PROPOSED → PM/T2 | POS FUO 有 ACC POS/NEG；NEG 抽象口號→FUO_UNBOUNDED；只 PARK 受影階段，T4/T5 狀態轉移待 Owner Schema |

| PM:T2 | 有 FUO/Kind → 建立 Journey/八 Kind 適用 | ProductSPECDraft@PROPOSED → TPM/PI Candidate | POS Kind 具 NoFit；NEG 其他 Kind 偷預設支援→KIND_NOFIT；只 PARK 受影階段，T4/T5 狀態轉移待 Owner Schema |

| PM:T3 | 有 draft + risk → 逐需求拆 ACC/NEG/Owner | ProductAcceptanceProposal@PROPOSED → PM/SE/T4 | POS 每子項有測試入口；NEG parent PASSED child 缺證→CHILD_TRACE_GAP；只 PARK 受影階段，T4/T5 狀態轉移待 Owner Schema |

| PM:T4 | 有 source/owner → 編 SpecCandidate handoff，不編 PI | ProductHandoffReferral@PROPOSED → PIPD intake | POS Schema/SourceHash可查；NEG 提案冒稱 Native PI→WRITER_DENIED；只 PARK 受影階段，T4/T5 狀態轉移待 Owner Schema |

| PM:T5 | 有原始測試或明確未跑 → 核 Raw/evidence與FUO | ProductReview@PROPOSED → PM/Owner | POS 能區分 NotRun/Fail；NEG 缺 Raw 說 DONE→FUO_RAW_MISSING；只 PARK 受影階段，T4/T5 狀態轉移待 Owner Schema |

| SE:T0 | 有來源/現役 host 可讀 → 建立架構所有權 | SystemReadset@PROPOSED → SE/T1 | POS 四域 Writer 分明；NEG 未知 PID 自填→HOST_UNVERIFIED；只 PARK 受影階段，T4/T5 狀態轉移待 Owner Schema |

| SE:T1 | 有 T0/Scope → 產 Boundary/ThreatModel | OwnershipSeamMap@PROPOSED → SE/T2 | POS 一 Writer/Effect；NEG 雙 Issuer→AUTHORITY_CONFLICT；只 PARK 受影階段，T4/T5 狀態轉移待 Owner Schema |

| SE:T2 | 有 Driver/HostCaps → 具名 ADR／版本 ABI | ArchitectureSPEC@PROPOSED → SE/T3 | POS 版號與 NEG；NEG 無 Schema 仍宣綁定→ABI_UNBOUND；只 PARK 受影階段，T4/T5 狀態轉移待 Owner Schema |

| SE:T3 | 有 SPEC / writer → 逐 edge 壓測、回退 | ArchitectureNEGRequest@PROPOSED → SE/T4 | POS wrong major DENY；NEG 靜默丟 unknown required→ABI_LOSS；只 PARK 受影階段，T4/T5 狀態轉移待 Owner Schema |

| SE:T4 | 有 Adapter Proposal → 原 Domain Writer 審查接線 | ArchitectureHandoff@PROPOSED → PIPD/HGK Reader | POS Only Proposal crossing；NEG 自稱 Loaded→HOST_RAW_MISSING；只 PARK 受影階段，T4/T5 狀態轉移待 Owner Schema |

| SE:T5 | 有同 SHA 實證 → review trace／負例 | ArchitectureReview@PROPOSED → SE/Owner | POS 不同 principal 待證；NEG 用 Maker 代 Checker→SOD_DENIED；只 PARK 受影階段，T4/T5 狀態轉移待 Owner Schema |

| TPgM:T0 | 有 subject/Goal → 盤點 scope/milestone | ProgramIntent@PROPOSED → TPgM/T1 | POS 跨 Session 可定位；NEG 只有 Chat 歷史→DURABLE_GAP；只 PARK 受影階段，T4/T5 狀態轉移待 Owner Schema |

| TPgM:T1 | 有風險 → 定預授權/成本/依賴 | SchedulingAssumptions@PROPOSED → TPgM/T2 | POS 不重啟無關卡；NEG 每卡重問 Owner→GOVERNANCE_OVERHEAD；只 PARK 受影階段，T4/T5 狀態轉移待 Owner Schema |

| TPgM:T2 | 有 3 SPEC → DAG/toposort/Owner split | ProgramDAG@PROPOSED → TPgM/T3 | POS 無 cycle；NEG 循環依賴→DAG_CYCLE；只 PARK 受影階段，T4/T5 狀態轉移待 Owner Schema |

| TPgM:T3 | 有合法卡 → 建立受限 WP/rollback | ProgramSPEC@PROPOSED → TPgM/T4 | POS 卡帶 scope/NEG；NEG ** write scope→WRITESET_DENIED；只 PARK 受影階段，T4/T5 狀態轉移待 Owner Schema |

| TPgM:T4 | 有真 PIPD 入口 → 生成受權 referral | HandoffReferral@PROPOSED → PIPD/HGK PLAN | POS 不冒充 ECP/Permit；NEG 跳過 SourceFreeze→PIPD_HOLD；只 PARK 受影階段，T4/T5 狀態轉移待 Owner Schema |

| TPgM:T5 | 有 Raw/checkpoint → 按原 Case 最小稽核 | ProgramReview@PROPOSED → TPgM/Owner | POS 未結案 card 續行；NEG 重跑 Done→REPLAY_DENIED；只 PARK 受影階段，T4/T5 狀態轉移待 Owner Schema |

### 6.3 三 SPEC 型別、KnownAnswer 與 GHP 決策

- **`ProductSPEC@DESIGN-1`**：必含 `subject_id,source_hash,goal,persona,pain,JTBD,FUO,primary_kind,scope,non_goals,user_journey,ACC_POS[],ACC_NEG[],risk,question_refs,assumptions,decision_owner`。`PIPD IntentCard` Consumer 只讀，絕不可把 Draft Spec 寫作 `PI-PKG`。POS CLI_USER 可得到可執行 help/list/remove，NEG 無來源假 FUO。
- **`ArchitectureSPEC@DESIGN-1`**：必含 `source_ref,C4_boundaries,components,single_writer_seams,threat_model,ADR,interface_contracts,schema_version,provider_off_behavior,host_matrix,policy_reader,license_security,rollback`。SE 與 PIPD/HGK 受影 Reader 消費。POS wrong major 被 NACK；NEG 非原 Owner 自建第二 Issuer。
- **`ProgramSPEC@DESIGN-1`**：必含 `milestones,task_dag,dependencies,work_packages,scope,write_set,task_kind,mode,owner,risk,required_grants,ECP_request,PIPD_refs,checker_request,raw_expectations,exit,rollback,resume_predicate,GithubDecision`。HGK PLAN 僅消費受權的 Proposal；POS 局部 PARK；NEG 把 949 件全部 READY。
- **`QuestionLedger`** Key=`(subject_id,source_sha,question_semantics,scope)`；KnownAnswer/受影 reuse 無過期就 `SKIP_WITH_SOURCE`，Unknown 且影響 FUO 才 `ASK_ONCE`；缺 source 明確 `SOURCE_MISSING`，有 source 卻沒讀到為 `READER_FAILURE`。Quick/Guided/Critical 依實際 risk 切換。
- **GitHub `GHP-01`** 本次 Delivery 決策一次 `(UNDECIDED|LOCAL_ONLY|DEFERRED|REMOTE_REQUESTED)`，`UNDECIDED` 不阻擋 L0/L1 本地測；**`GHP-02`** 僅當正式 Remote Push/Merge/Release 時讀 Publisher Credential/Scope/current HEAD/Policy，否則不得自行遠端突變。[SRC-53:L179–207]
## 7. PIPD-LS 原生 19 Contract、13 CLI 與雙衝突相容（細化 v1 §2）

`PIPD-LIFECYCLE-SPEC@1.1.0` 的 Schema Writer 仍是 PIPD DOC00–09，不是 TPM。以下 `ContractName` 是來源具名型別，**精確 `$id / fields-required / enum / digest` 在真 PIPD Owner Registry 讀回之前為 `BIND_HOLD`**；此表之建議欄是 `PROPOSED Reader projection`。禁止僅靠 `pipd validate` 一次成功就推論 TraceClosed。[SRC-MASTER:§VI][SRC-PIPD-02..09]
