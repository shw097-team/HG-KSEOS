## 高保留原 BODY Revision2 實質正文（沿用未受影區；遇 r2 修補採本冊前段）

---
artifact_id: FHS-MSC-R2-BODY-12
formal_name: 驗證、合法交接與交付層級
short_name: BODY-12
version: 2026-10-29-r2-revision2
source_set_hash_or_pending: f86b217ae3c3ee28183570f4bf3d4f08d4d00e9b86d1de1a641a630f8682d1a1
intended_consumer: 原領域 Owner 與下游 Reader
owner_role: 作者端規格修補者；原 Domain Writer 不移轉
design_status: SOURCE_BOUND_REPAIR_CANDIDATE
claim_ceiling: AUTHOR_STATIC_ONLY; NATIVE_NOT_RUN; CHECKER_NOT_RUN; RELEASE_NOT_RUN
supersession_scope: 本輪作者候選revision2；保留前版封存；不取代任何原Canonical Writer版本
AUDIT_F_IDs:
- F-22
- F-26
---

# 驗證、合法交接與交付層級

## R2-12-JOURNEY：同一 Subject 的可逆作者端切片

Goal「為普通目標產來源綁定變更規格」→ PM/SE/TPgM 三 SPEC（Portable TPM producer）→ IntentCard/Authority/Profile 候選（原 PIPD Reader）→ PI 候選（原 Writer ACK 前不 promotion）→ 真 RepoContext 的 PD 候選→DEV/OPS ECP 候選分開→Native PLAN proposal→Fabric Loaded/HGK Admission required→Hermes 原 Queue/worker expected→world Raw expected→獨立 Checker expected→bounded repair→交付。Source hash/candidate hash/Subject 逐邊不變；新 Candidate 必明示 supersedes，而非覆寫先前 Raw。

作者端 POS：缺 native permit 時正確停在 ADMISSION_HOLD，隔離 SPEC 檔仍交付可讀；NEG：把 ECP 字串當 Permit、把 PlannedTQAEP 當 Independent PASS、把舊 Host receipt 換入當期 source 均拒收。此例驗「合法停點」，沒有執行 Host 效果。

## R2-12-CLAIMS：不同驗收軸

FILE_READBACK_PASS、LOCAL_SCHEMA_FIXTURE_PASS、DESIGN_GUARD_PASS 僅是各自作者端證據。FULL_DOCUMENT_STATIC_PASS 需全部原語義及 26 項修復證據；SCHEMA_CONFORMANCE_VERIFIED 不等於 HOST_BOUND；HOST_BOUND 不等於 INSTALLED/ACTUALLY_INVOKED；WORLD_EFFECT_READBACK 不等於 INDEPENDENT_CASE_PASS；OWNER_RATIFIED/RELEASED 各需原主體本輪收據。

## R2-12-HANDOFF：下游接收與失敗

交付 typed refs：source manifest hash、candidate per-file hash、17 Body refs、26 closure refs、DAG、case plan、actual test logs、holds。Consumer 先驗 SHA/UTF8/LF/link，再讀原語義與當期 RepoContext；missing file、empty denominator、unknown schema、stale source → NACK，附 first_fail、affected_scope、具名 Owner、next_legal_action、resume_predicate。不得因靜態拒收器通過，推論所有 Native Case 已執行。

[根索引](../INDEX.md) · [來源證據](../02_EVIDENCE_APPENDICES/E01_SOURCE_MANIFEST_AND_SEARCH.md) · [需求覆蓋](../02_EVIDENCE_APPENDICES/E02_REQUIREMENT_TRACE_AND_DENOMINATORS.md) · [ABI/Fixtures](../02_EVIDENCE_APPENDICES/E03_ABI_SCHEMAS_AND_FIXTURE_AUDIT.md) · [衝突/HOLD](../02_EVIDENCE_APPENDICES/E04_CONFLICT_RCA_ADOPTION_AND_HOLDS.md) · [QA/readback](../02_EVIDENCE_APPENDICES/E05_QA_READBACK_AND_CLAIM_CEILING.md)。

READ_ONLY 工作完成後不需要效果回滾；REPO/HOST/USER/REMOTE/RELEASE 按 BODY-03 的不同 Done/補償/殘留規則。原 Gate/Case/ID 的未受影義務持續有效，文件缺件不能重設已准入工作。
