## 高保留原 BODY Revision2 實質正文（沿用未受影區；遇 r2 修補採本冊前段）

---
artifact_id: FHS-MSC-R2-BODY-05
formal_name: Portable Guide 與 Native Commander PLAN
short_name: BODY-05
version: 2026-10-29-r2-revision2
source_set_hash_or_pending: f86b217ae3c3ee28183570f4bf3d4f08d4d00e9b86d1de1a641a630f8682d1a1
intended_consumer: 原領域 Owner 與下游 Reader
owner_role: 作者端規格修補者；原 Domain Writer 不移轉
design_status: SOURCE_BOUND_REPAIR_CANDIDATE
claim_ceiling: AUTHOR_STATIC_ONLY; NATIVE_NOT_RUN; CHECKER_NOT_RUN; RELEASE_NOT_RUN
supersession_scope: 本輪作者候選revision2；保留前版封存；不取代任何原Canonical Writer版本
AUDIT_F_IDs:
- F-04
- F-20
---

# Portable Guide 與 Native Commander PLAN

## R2-05-ABC：Guide 與 Native PLAN 的反循環輸入

A READONLY：Portable Guide 讀 frozen SPEC/PI/PD/ECP/TQAEP、原 CurrentRevisionReader，回 PlanRevisionProposal；不需要它尚未建立的 WorkOrder，不能寫 Target Repo。B ADVISORY_LOCAL_WRITE：只在本輪隔離建議目錄記 proposal/diff，effect=LOCAL_DRAFT_WRITE；交原非 legacy Native PLAN Producer，CAS(base_revision,proposal_hash) 必得真 Writer ACK。C 若 A/B 缺權限或 loader，PARK 受影寫入，保留 source/ref/first_fail；不能呼叫已停用 sbl-commander-sp。

Probe 次序：確認 Host skill manifest+trigger/nontrigger→讀 loaded SHA（檔案在磁碟不是 loaded）→讀 Native PLAN schema/revision/reducer→檢同 Subject→submit proposal 只在原 Producer 能力和權限已存在時。Guide 不自行落 native WorkOrder，原 PLAN Writer 選合法 ready card，原 Issuer 後續准入。

POS：Reader 得 revision r，proposal base=r，原 Writer ACK r+1；NEG：base=r-1 → PLAN_CAS_NACK，不覆寫別人的 revision。POS：無 effect 權限仍可產唯讀計畫；NEG：為取得首 WorkOrder 先要求同 WorkOrder permit → BOOTSTRAP_DEPENDENCY_INVERSION。退出只撤本輪 proposal，不改原 PLAN state。

## 保留的領域實質設計（修補表格語法與狀態字樣）


# Portable Commander Guide 與 HGK PLAN Native Commander

> **效力**：本檔為 `BODY-05` 的來源約束施工設計候選，保留來源章節的原 ID、Decision、POS/NEG、HOLD；尚不是任何正式 PI/PD/ECP/Permit/WorkOrder/Checker Verdict 或 Release。凡提及 `PROPOSED` 的 ABI，需由原 Owner／Host Registry 真正綁定。

### 4.2 薄 Commander Guide + Native FHS-Commander

**Guide** 只讀Goal/Source/已批准 SPEC，輸出包含 next legal action、NoFit、限界 `GuideProposal@2`，不持有 Native Key、不能簽 WorkOrder、不自動 Spawn。正向：Host fresh-load 真 `SKILL.md` 並產帶 source 的建議；負向：無關對話零觸發、卸載後無殘留、老 `sbl-commander-sp` 不被 fallback。**Native** 綁 HGK `PLAN` role，對 `PlanRevisionProposal@2` 做 DAG cycle/duplicate ID/permission/expected_revision、CAS；同一 Work ID 不可多方獨立重提。變更權限：Guide 絕不能提升到 HGK Issuer；即使三模型分工是四角色，也沒有第四物理 Lane。[SRC-CMD:§2,§4,§5,§15]
### 11.1 薄 Commander Guide：逐功能 Owner/Trigger/輸入輸出/不觸發

`Guide` 只讀；合法 Output 只是 `GuideProposal@2`，不是 `WorkOrder` 或 `Permit`。原禁用 `sbl-commander-sp` 不自動恢復，不取消 SBL 原 Required Commander 產品義務。[SRC-06:§4.1]

| 原子 / 真 Trigger 與 Input→Output→Consumer | POS / NEG／退出 |
|---|---|

| GUIDE-01 **SourceReader** | 真 Host trigger：有規劃/有關 Source 且已授 ReadScope；Goal＋已獲准 source/manifest→SourceCurrentnessGraph@PROPOSED→Native TPM/Guide；POS 真 SourceSHA/HostLoaded 與 Fixture 同來源。 | NEG/FirstFail：來源章行+sourceSHA；缺正本 SOURCE_NOT_AVAILABLE；無關一般查詢 NOT_TRIGGERED；退出卸載 guide loader 並 fresh PID 證 0 residue，未裝只 HOST_PENDING。 |

| GUIDE-02 **TaskFit** | 真 Host trigger：有規劃/有關 Source 且已授 ReadScope；Kind×Mode×Host×ProviderOff/StandingScope→ApplicabilityDecision@PROPOSED→PLAN/TPM；POS 真 SourceSHA/HostLoaded 與 Fixture 同來源。 | NEG/FirstFail：unsupported Host NOFIT；ProviderOff 不默換；無關一般查詢 NOT_TRIGGERED；退出卸載 guide loader 並 fresh PID 證 0 residue，未裝只 HOST_PENDING。 |

| GUIDE-03 **Decision/Questions** | 真 Host trigger：有規劃/有關 Source 且已授 ReadScope；KnownAnswer+conflicting source→DeduplicatedOwnerDecisionPack@PROPOSED→Owner；POS 真 SourceSHA/HostLoaded 與 Fixture 同來源。 | NEG/FirstFail：已答不重問；Unknown 不當同意；無關一般查詢 NOT_TRIGGERED；退出卸載 guide loader 並 fresh PID 證 0 residue，未裝只 HOST_PENDING。 |

| GUIDE-04 **PlanSeed** | 真 Host trigger：有規劃/有關 Source 且已授 ReadScope；Approved Source/PI/PD Ref→SortedPlanSeed/DAGCandidate@PROPOSED→HGK PLAN；POS 真 SourceSHA/HostLoaded 與 Fixture 同來源。 | NEG/FirstFail：只 Proposal；產 token/擅自 shell→GUIDE_EFFECT_ESCALATION；無關一般查詢 NOT_TRIGGERED；退出卸載 guide loader 並 fresh PID 證 0 residue，未裝只 HOST_PENDING。 |

| GUIDE-05 **Preflight/NoFit** | 真 Host trigger：有規劃/有關 Source 且已授 ReadScope；Loader Registry/LoadedSHA/read ACL→TriggerOrNoFitReport@PROPOSED→Host/PLAN；POS 真 SourceSHA/HostLoaded 與 Fixture 同來源。 | NEG/FirstFail：Host 缺真 Loader 回 NOFIT，不全域停 L0；無關一般查詢 NOT_TRIGGERED；退出卸載 guide loader 並 fresh PID 證 0 residue，未裝只 HOST_PENDING。 |

| GUIDE-06 **KnownFix/Reentry** | 真 Host trigger：有規劃/有關 Source 且已授 ReadScope；FirstFail/Raw/VerifiedKnownFix→BoundedRepairSuggestion@PROPOSED→Maker/FAR；POS 真 SourceSHA/HostLoaded 與 Fixture 同來源。 | NEG/FirstFail：Root 未核假自修→UNBOUNDED_FIX；無關一般查詢 NOT_TRIGGERED；退出卸載 guide loader 並 fresh PID 證 0 residue，未裝只 HOST_PENDING。 |

**SKILL.md 包裝應含**：Frontmatter `name,description,version,owner,triggers,nontriggers`、ReaderRoute 來源授權、六功能程序、`allow_effect=false`、必需依賴/Host ABI、Positive/NonTrigger/Negative fixtures、source pins/License/NOTICE、uninstall；`HOST_LOADED` 需檢查真 Host loader Registry 及新 PID，純文字存在不等於 Enabled。

**`PlanRevisionProposal@2-PROPOSED` 最小兼容 schema**：`{schema_id,subject_sha,source_manifest_sha,expected_revision,producer_principal_ref,plan_nodes:[{node_id,depends_on,task_kind,read_scope,write_scope,effect_class,required_evidence}],forbidden_legacy_sp:true,proposed_only:true}`；`additionalProperties=false`，任何 `permit,token,execute_command,issuer_signature` 均拒收。`expected_revision` 只能 `HGK.getRevision()` 真讀；POS 無 duplicate/cycle/out-of-scope 且 CAS ack；NEG stale/unknown enum/legacy fallback/同一 DAG 未授 effect→`NACK_PLAN`。PIPD 合法 ECP＋Fabric Loaded＋Issuer 實際准入**先於執行**；但最初 readonly Proposal 走 A（既有非 Commander ABI）或 B（HGK PLAN Reader），兩者未綁只 C 局部 PARK，禁止反循環。[SRC-06:§4,§5,§20][SRC-B1-08]

## GuideProposal@2 vs PlanRevisionProposal@2

Portable `SBL-COMMANDER-GUIDE` 只消費 Goal/Source + 存在的 PIPD Reader；六個 Guide 原子皆不持有 Permit/Native token，不動 world。它產 `GuideProposal@2(subject,readset_sha,task_delta,expected_result,nontrigger_reasons)` 供人或 Native PLAN 參照。

Native `HGK.PLAN.SBL_COMMANDER` 在既有三 Lane 的 PLAN 子角色負責根據 Ready/Blocked/CAS/Owner 來源形成 `PlanRevisionProposal@2`，不建立第四物理 lane。提案需 expected_revision、同 Subject operation_id、無環 dependency graph、AffectedCone、RollbackPlan。CAS 失敗只重抓現役 plan，不新增控制器。

Bootstrap GWO 提案避免先有 WorkOrder 才准提出 WorkOrder 的循環：A 用真已註冊非 Legacy Producer；B Native PLAN 真 ABI；C A/B 均無時唯讀提案並 PARK 消費該入口。不得悄悄調回被禁用 `sbl-commander-sp` 或用 chat prompt 當 Native PermittedWO。

## 領域 v2 精確補強條款（保留正式原域 Writer，非 Native 生效證據）


### 領域回源段 1：`Commander-Skill_與_Native_FHS-Commander_升級藍圖_2026-10-28_v2_HIGH_RETENTION_FULL_DESTRUCTIVE_AUDIT_REPAIR.md:L82–L119`

> 本段原生設計來源，高保留嵌入供下游逐條實作；如需更改正式 Policy/Schema/Gate，應回原 Domain Writer 決策。

## 2｜三個 Commander 身份、雙形態使用者產品與能力逐維分工

### 2.1 原意不重置：產品義務與三種現役／目標身份

| 欄位 | (I) SBL Legacy commander_sp | (II) Portable Commander-Skill | (III) Native FHS-Commander |
|---|---|---|---|
| 法位/類型 | SBL 既有 build principal／Plugin/Skill 元件，產品義務保留 | AGENT_SKILL／Codex-first Portable Guide，候選 1.0.0 | HGK PLAN 角色能力；無新物理 Lane；PlanRevision Proposal Producer |
| 使用者 | 原 SBL 受治理 Builder | 使用 Codex CLI/Desktop/其他經核准 Host 的單人 Owner、普通開發者 | HGK/Hermes 常態任務，TPM/Planner/Executor/Checker 整合服務 |
| 支援 Host | 現 repo bridge；當期實機 HOST_PENDING | 第一目標 Codex CLI；條件支援 Hermes、Codex Desktop、Claude Code，逐 Host 真 effective load 測試 | 由現役 HGK 既有 Runtime/PLAN 回調；Windows Host Reader/Executor 需真現役 Registry |
| 觸發 | 有 frozen PI/PD/declared WriteSet 且合規 Host，重資格化之前不應在 B1 召喚 | Goal+Source 需要方案、Guide、DAG 草稿、NoFit/Next Legal Action；沒有有效 Permit 仍可給 read-only Guide | HGK 已建立合法 Mission/PI/PD/適用性；需要創建/修訂 WorkCards 和 Worker 計劃 |
| 非觸發 | B1 禁令適用 Subject、宿主未證 installed、Spec stale | 直接要求 Issuer、不可讀 Source、純不需要規劃的工作、Skill 未裝、Provider-off/NoFit | 單純無關資料詢問、HGK 不可讀的 Mission、未通過版本契約的自動執行 |
| 主要輸入 | PI/PD/ECP/Acceptance plan、root/head/writeset | goal、source_refs、optional Context/PI/PD 快照、mode/Host聲明、policy snapshot(唯讀) | canonical subject + PI/PD refs + ECP/TQAEP refs + policy epoch + SharedSpine snapshot + worker capacities |
| 唯一輸出 | scoped build order、Steps/Raw/candidate SHA（歷史能力） | GuideProposal@2、SourceBoundQuestionDelta、NoFit/Gap/FirstFail、PlanSeed@1（不可派工） | **單一** PlanRevisionProposal@2、有向 TaskDAG、resource budgets、RepairCone、AffectedOnlyReplan、handoff/park reason |
| 可做 | 在合法 effect scope 下產生候選變更／證據 | 讀取、解釋、建議最短合法路徑、提候選任務/工具、在 Skill 自己的隔離空間離線校驗 | 規劃優先序、依賴分析、成本路由、拆分子代理、無進度處置、讀現役狀態、提出修訂 |
| 禁止 | 自核正式驗收、越 WriteSet、越權代 Issuer | 執行世界 Effect、直接 Commit/Push/Token、私自啟用 Legacy、簽署 AO、替代 PIPD Writer | 自發 Permit、建立第二 Scheduler/Queue、越過 HGK Admission、同 Principal 簽 Checker、回寫 Fabric Policy |
| 版本/遷移 | 保持原 manifest SHA，REQUALIFICATION_HOLD；比較 Build 產品功能而非刪除 | 原 SBL-COMMANDER-GUIDE 名稱視 legacy 藍圖提案，正式外部名稱改採本文件 Commander-Skill 待 SBL 核定 | HGK.PLAN.FHS_COMMANDER 為**候選**角色鍵，正式命名需 HGK Registry/RoleBinding 核準 |
| 依賴/退出 | 原 Host ABI、正/負觸發、freeze/currentness、可逆停用 | 版本化 Host loader、SKILL.md＋JSON Schema、綁 SourceRef、無副作用 uninstaller | HGK PLAN lane served、SharedSpine CAS/lease、Hermes worker、PIPD reader、Fabric policy readback |
| 正例 | frozen order 只改 WriteSet，Raw readback、Maker≠Checker | 不帶 Permit 的新任務仍產 source-bound 改動建議且 world_effect=none | 一個 DAG 版本被 HGK 採納，B/C 能在 A PARK 時續行，不派未授權卡 |
| 負例 | HOST_PENDING 被當正式 B1 工具、Build Principal 產生 Permit | Skill 召喚舊 SP 或產外部 effect，NoFit 偷轉別的 Host | Planner 重啟隊列/issuer、Stale revision 勝過 CAS、UnknownEffect 重試外部寫 |
| 真驗收 | LEGACY-L01..L05 重資格化，非文件 PASS | PS-01..PS-09 四 Host 逐個 Clean/Loaded/Invoke/Uninstall POS/NEG | NC-01..NC-24、B1 E 原件/W18 E33..42 真 Raw/Checker、Owner Gate |

**產品不可降級**：SBL 的 `CLI_TOOL / AGENT_SKILL / SIMPLE_AGENT` 和 8 Kind、3 Mode、4 Host、3 SP、六邏輯模組、3 Golden Journeys，以及 Legacy Builder 的有效需求均保存於 SBL 上游，不因將其指揮入口瘦身而全部改成 Markdown Guide。`PREW3_SHADOW` 的 Planner 對接永遠 NoEffect；`SWOF_CONNECTED` 必依 SWOF Native Registry/Gate，由 SWOF Owner 判讀。[SBL-D01:C01; SBL-D04:C12–C15/C37; SBL-D07:C11; SBL-D10:C31/C38; SBL-D11:C29]

### 2.2 權限矩陣（操作的動詞，而非抽象身份）

| Actor | 原始資料讀取 | Proposal | Product/Policy 決策 | 原生派工 | Permit/Admission | 真 World Effect | Oracle/Checker | Release |
|---|---|---|---|---|---|---|---|---|
| Human Owner（單人） | 經授權 | 批准 scope/決定爭點 | 有權批准自己法域的異動；跨域依各 Owner 規則 | 只交 goal/範圍，非替代 durable scheduler | 可授權申請/Standing Scope；不自行偽造 Issuer 簽名 | 透過合法 Executor | 不因擔任 Owner 就自成獨立 Checker | 自己有權的 Release Decision，仍須前置 Raw |
| TPM-SP / Native TPM | 有權 Source/Spec | Intent/Spec/PI Request | 不能覆 PIPD Writer | 不 | 不 | 不 | 候選 ACC，不簽正式判決 | 不 |
| Portable Commander-Skill | 有權 Source 快照 | Guide/PlanSeed | 不 | 不 | 不 | 不 | 可給測試建議，不能正式 verdict | 不 |
| Native FHS-Commander@PLAN | Snapshot/版本化 Ref | **唯一** PlanRevision | DAG/資源策略的建議；不寫 Domain Policy | 只提交 HGK 待採納 Card plan | 不 | 不 | 可要求 Challenge，不能簽 Checker | 不 |
| HGK Native Issuer/Receiver | 有權 Policy/Scope | 回執 | 按合法 Policy Decision | **Admission/CAS 後** WorkCard 派入唯一 SharedSpine | **唯一**有權 Issuer | 不應由 Issuer 寫業務實效，除本來 Domain 實作 | 保護 Checker readset | 只提供受權 Gate receipt |
| Hermes Executor + Codex Worker | 受權 WorkCard/Repo | 修補候選及 effect journal | 僅 WorkOrder/ECP 內工程選擇 | 消費 HGK queue | 不自發 Token | **有權範圍**下執行，再 world readback | Maker 自檢/Raw，不簽獨立 PASS | 不 |
| Fabric Policy Writer/Activator/Consumer | Policy 生效鏈 | Stage proposal | Fabric Domain Owner 決策 | 非第二 Hermes dispatcher | Policy activation 而非 HGK Permit | 受控 Stage→Active→Loaded/Consumed | 對自身 Policy readback 作證 | 依 Fabric 原權限 |
| External Challenge-SP | frozen artifacts只讀 | Counterexample/Claim challenge | 不 | 不 | 不 | 不 | 僅候選 finding；不直接等於獨立 Checker | 不 |
| Independent Checker（不同真 Principal） | 受保護唯讀 Raw | Finding/Case verdict | 不改 Oracle Writer | 不 | 不 | 不得寫 Maker WorkSet | **正式** protected PASS/FAIL（憑分權、簽證） | 不直接替代 Publisher |
| PIPD Native Writer/Compiler | frozen Source / Context | PI/PD/ECP/TQAEP Native outputs | 每件各 Canonical Writer | 不 | **ECP 本身不授權** | 不 | Oracle Writer DOC07，Plan≠Verdict | CI/release 屬不同法域 |


### 領域回源段 2：`Commander-Skill_與_Native_FHS-Commander_升級藍圖_2026-10-28_v2_HIGH_RETENTION_FULL_DESTRUCTIVE_AUDIT_REPAIR.md:L171–L185`

> 本段原生設計來源，高保留嵌入供下游逐條實作；如需更改正式 Policy/Schema/Gate，應回原 Domain Writer 決策。

### 4.1 功能模組，輸入→輸出→拒收（六個獨立義務）

| 子模組 | Source/Trigger | 明確處理和輸出 | 禁止與 FirstFail；最短復原 |
|---|---|---|---|
| GUIDE-01 SourceReader | Goal + 原檔或已綁 manifest、有效 Read Scope | 來源章節/行/SourceSHA locator、Authority/CurrentnessGraph | 未讀原文/只轉述→SOURCE_NOT_AVAILABLE；先給限縮 NoFit，不自造 Source |
| GUIDE-02 TaskFit | Kind/Mode/Host/Effect×ProviderOff/Standing Scope | APPLICABLE / CONDITIONAL / NOFIT / NOT_TRIGGERED；有原因 | Provider-off 靜默改 Host、SBL 3×4 Host 用一個 PASS→HOST_NOFIT |
| GUIDE-03 Decision/Questions | 已回答問題 ledger + 冲突 SourceRef | 只問影響 ACC/許可的新增問題、合併 OwnerDecisionPack | 重問已回答/把 Unknown 當同意→QUESTION_POLICY_REGRESSION |
| GUIDE-04 PlanSeed | Approved source refs/PI/PD 快照 | 有序 Steps、DAG 建議、被授權 Reader/Owner、成本與風險；proposal_only=true | 產 WorkOrder/Permit/含 shell 自動執行→GUIDE_EFFECT_ESCALATION |
| GUIDE-05 Preflight/NoFit | 真 Host Registry、Skill load digest 或 absence | 確認是否觸發、合法 L0/L1 路線、缺件受影 PARK、可下載 Guide | 缺 HGK Native Runtime 導致純資料規劃停工→GLOBAL_HOLD_REGRESSION |
| GUIDE-06 KnownFix/Reentry | FirstFail, local diffs, verified KnownFix references | RepairSuggestion + Red/Green fixture 設計、rollback 和重入條件 | 未見 Root/Red 就廣域更動→UNBOUNDED_FIX，返讀最新 Source |

**真正的 Skill 套件設計**（建議路徑，非已存在）：`skills/fhs-commander-guide/SKILL.md`（觸發/非觸發/六步 guide）、`schemas/guide_proposal.v1.schema.json`、`references/reader_routes.md`（SOURCE_NOT_AVAILABLE 顯示規則）、`tests/positive_negative_cases.json`、`host/host_bindings.json`（僅已核准時寫實值）、`manifest.json`（version/supplier/license/source_sha/capability）。Host wrapper 最少知道 `name, version, description, triggers, nontriggers, allowed_read_scope, declared_no_effect, schema_ref, namespace, source_hash`，原生安裝命令依**宿主真 registry/parser** 探測，不自行發明 `codex skills install` 旗標。Skills 不是可信政策；Host 對 Skill source 先做 untrusted instruction suppression，不能將 AGENTS.md 的內容升成 Permit。

**`SKILL.md` v1 的實質使用契約**：當需要「規劃受限程式修補／檢查 PI/PD/ECP／安排多任務／釐清來源衝突」才觸發；當問純查詢、不需來源、目標是簽署/推送/真 Host effect、Provider-off、未取得合法 Scope 時不觸發或僅 NOFIT。執行順序 Source→Applicability→Allowed Level→Guide/PlanSeed→Typed NACK→Evidence Expectation；只允許本地輸出 GUIDE 檔及觀察性報告（具檔案輸出仍需文件 write permission），絕不執行 WorkOrder。清理需將 Host registry 列名、Loaded SHA/Process Readback、卸載後再次列名 0 殘留的 **乾淨 Host** Raw 同時保存。


### 領域回源段 3：`Commander-Skill_與_Native_FHS-Commander_升級藍圖_2026-10-28_v2_HIGH_RETENTION_FULL_DESTRUCTIVE_AUDIT_REPAIR.md:L440–L454`

> 本段原生設計來源，高保留嵌入供下游逐條實作；如需更改正式 Policy/Schema/Gate，應回原 Domain Writer 決策。

### 5.1 內建功能是原生規劃，不是把薄 Skill 複製進 HGK

| 子功能/責任 | Native Reader Input | 確切處理與 versioned output | 拒收/退出 |
|---|---|---|---|
| NC-F01 Intake & Plan Eligibility | frozen subject/PI/PD/Profile + HGK snapshot | PlanEligibility{subject,currentness,allowed_levels}；不依賴聊天記憶 | Unknown depends_on != []；PIPD 寫者衝突 HOLD 此 proposal |
| NC-F02 Task Graph | typed WorkCard seeds/effect classes | 有向 acyclic TaskDAG{node,edge,epoch,original_id}、拓樸次序 | cycle/orphan/duplicate TaskID/Effect collapse→NACK |
| NC-F03 PlanRevision | current durable Plan revision/expected_version | PlanRevisionProposal@2 單一 CAS expected，變更前後受影 closure | 同 Revision 多 Candidate/失去 owner 合一→STALE_REVISION |
| NC-F04 Resources/Workers | actual served Lane/method/resource quotas | worker capacity、parallel candidates、time/cost/retry budget | 必需 Lane direct 200 但工具回合沒跑→SERVE_UNPROVEN |
| NC-F05 Delegated Multi-agent | bounded child workCard, parent, maker/checker SoD | 子任務可追蹤 ID、scope、不共享 Issuer key；Join 回寫父端 observation | subagent 產 Permission，跨 scope→NACK_CHILD_SCOPE |
| NC-F06 FAR/KnownFix | FirstFail 原生索引/known fix receipts | only eligible RepairCone{root_cause,affected_ids,red,patch,green,rollback} | 只有猜測/未執行 Red 或未知 Effect 就重試→PARK |
| NC-F07 Replan/Recovery | SharedSpine cursor, lease generation, actual world state | affected-only replan + ready handoff + bounded retry；跨新 PID | stale fence commit、無真新 Process、已完成效果再次執行→DENY |
| NC-F08 Completion/Delivery | 真 WorkCard terminal/readback、Checker verdict | operational delivery candidate；source refs + remaining obligations | READY/RUNNING>0、任何原 W/E 未完成卻提前 Seal→INCOMPLETE |

**高自治不是所有工具每輪都開**：PLAN 任務可視需要選 SWARM/KANBAN/GStack/OpenSpec/Superpowers/FAR；必需能力按 Trigger/MethodRegistry 啟用，沒有適用性與真正 load 的工具不能用「已計畫」填報執行成功。成本控制採 `max_tokens_per_replan, max_discovery_rounds, max_retry_per_firstfail, max_parallel_workers, max_time, no_progress_detection` 等**配置候選**；精確量與 Policy Epoch 由 Owner/Native Host 注入，不能在文件憑空固定上限。[SBL-D04:C37; SBL-D13:C46; W18:§4/§10]


### 領域回源段 4：`Commander-Skill_與_Native_FHS-Commander_升級藍圖_2026-10-28_v2_HIGH_RETENTION_FULL_DESTRUCTIVE_AUDIT_REPAIR.md:L844–L872`

> 本段原生設計來源，高保留嵌入供下游逐條實作；如需更改正式 Policy/Schema/Gate，應回原 Domain Writer 決策。

### 5.3 可實作的 CAS/Replan 算法與不重播世界效果

```text
read: current Project/PlanRevision/TaskDAG/SharedSpine cursor + policy_epoch + SourceSHA
validate: one Source of Truth, no cycle/orphan, each node owner and effect class known
classify: missing credential/oracle/schema -> PARK affected descendants only
for runnable node:
  if OBS: check lawful read scope; do not require L3 permit
  if REPO/HOST/USER: resolve existing Owner-approved ECP/Issuer/Policy/Receiver
  create PROPOSAL, not workorder; only HGK may admit and publish to existing queue
HGK native commit:
  compare expected PlanRevision and policy epoch under native transaction
  validate readset/currentness, writeset, permission, nonce, subject, ttl, revocation
  CAS lease_generation (fencing); persist WorkCard before spawn
Hermes executor:
  bind actual process identity, executable SHA, served model identity
  run bounded worker; journal intent/result; world readback
  if timeout or crash and world effect unknown: DO NOT REPLAY; reconcile first
  checkpoint atomically and emit FirstFail where needed
Planner replan:
  recompute only impact closure; preserve DONE idempotency key and provenance
  CAS a new revision; stale propose must retry from fresh plan and revalidate
Completion:
  gate only if queue has no READY/RUNNING/UNKNOWN blocked by allowed dependencies
  require original oracle/real independent checker for respective outcomes
```

`operation_id` 綁 `subject + effect_class + resource + policy_epoch + native_issued_workorder_id`，不能跨已過期 Policy/Permit 重播同 nonce。Crash 後新 OS PID 從既有啟動路徑恢復、驗證 prior lease generation/TTL 並拒 stale worker commit；不應透過同一 Python 進程改 fake PID、也不以聊天 Session 記憶充當 checkpoint。`UNKNOWN_EFFECT` 必先調用原生 world-read adapter，確認 `APPLIED / NOT_APPLIED / INDETERMINATE`；仍不確定時停此 Effect，補償必有新 ECP/Permit。三類重試：Reader retry 可安全重查；Local DEV retry 受寫集及重播測試限額；Native effect retry 只在確認未應用且原生允許新的 operation/nonce 時進行。


### 領域回源段 5：`Commander-Skill_與_Native_FHS-Commander_升級藍圖_2026-10-28_v2_HIGH_RETENTION_FULL_DESTRUCTIVE_AUDIT_REPAIR.md:L883–L901`

> 本段原生設計來源，高保留嵌入供下游逐條實作；如需更改正式 Policy/Schema/Gate，應回原 Domain Writer 決策。

## 6｜PIPD 五件逐件正式讀取、Writer/Reader、ABI/拒收與授權界線

| 工件 | 真 Producer/Writer（不由 Commander 搶寫） | 最小適用必備：Source、schema、subject、versions | Commander Reader→行為／FirstFail | POS/NEG & 只停受影 |
|---|---|---|---|---|
| **PI** | TPM Intent 要求；PIPD DOC02 Canonical PI Compiler；SBL TPM 僅候選 consumer | frozen IntentCard，ProfileBinding 及原子 SourceClause/owner/ACC/risk/TraceLink，PI SHA+schema+profile epoch | PIReader 查 exact Source/Hash/Oracle provenance，產 eligible task obligations；缺原子 PI_ZERO_ATOM，缺來源 SOURCE_HOLD | POS N atoms/Trace 均真；NEG source hash 變更、zero atom，不准只靠字串 PI_READY |
| **PD** | PIPD DOC03 Canonical Binding；SBL TPM 不可自行換 Source Writer | PI exact SHA，RepoContext root/file-ID/HEAD/index/untracked/reparse、Host/OS、10 binding、WriteSet/Effects、late-bound hash | PDReader 拒 stale HEAD/absolute root/未定 Host；重讀不重編不相干 frozen PI | POS same HEAD/body/writeset；NEG out-root/stale branch→PD_REBIND_REQUIRED |
| **DEV ECP** | PIPD DOC05 execution-admission/handoff writer；Repo Domain DEV Owner | Exact repo root, HEAD, WriteSet, patch scope, rollback/test/permission references, subject SHA | DEV-ECPReader 只讓合法 L2 repair Candidate 入可審卡，不自發 Token | POS legitimate WorkSet patch；NEG writeset escape, cached SHA stale→PARK Repo affected card |
| **OPS ECP** | PIPD DOC05 + HGK/Host Domain Owner | Operation/Resource/Host SID, policy epoch, nonce TTL, receiver/issuer class, rollback/compensation refs | OPS-ECPReader request HGK admission；未批准只能 L1 discovery | POS exact scope Native issuer+Receiver；NEG HGK_TRUST_PROFILE=user 類未證環境開關、跨 Host Token→NACK |
| **TQAEP** | PIPD DOC07 Oracle/Fixture Writer + DOC07/B1 TQAEP plan Producer；Checker 是不同 protected Native Principal | one test per atom, POS/NEG/EDGE/SEC, OracleSource official, subject, maker/checker, required raw, frozen predicates | TQAEPReader 產 test scheduling proposal；PLAN 只求測試，無獨立 verdict | POS 真 runner+raw+independent receipt；NEG self-attestation or fixture-only→NOT_VERIFIED |

**共通五件 Reader 交易**：`DISCOVER→SOURCE/SCHEMA/PIN→SHA+Version Consistency→PROFILE+APPLICABILITY→CONFLICT/ORACLE LINK→CLASSIFY EFFECT→READ_ONLY_PROPOSAL→HGK ADMISSION`。`SourceBundleID` 用於關係追溯而非強迫五件同 SHA；每一件保留自己 `source_sha / artifact_sha / created_at / schema_version / writer / currentness_ref`。只有真正 L3 Effect Admission 的 HGK WorkCard/ECP consume step 需要當期 `policy_epoch`；一旦 Fabric Epoch 變更，不自動令無關 PI 原子失效。每件是否需凍結按原 PI/PD/ECP/TQAEP Writer 的本地時間點獨立判定，Reader 的一次讀件不等於五件全部 formally frozen。缺件只 PARK 依賴該工件的 DAG 子圖，合法 Source-only Intake/Preflight 仍可運行。

**兩個不得消音的 ABI 衝突**：

1. `CR-ORACLE-001`：官方 DOC07 為 Oracle Canonical Writer；現役 `pipd-pi-compile` SKILL.md 要 `acceptance.oracle_source=DOC-03 DOMAIN_ORACLES`，#20 unsigned compatibility API 還是 Draft。設計分支 A：PIPD Owner 提供 signed versioned alias/adapter + clause hash + schema digest + POS/NEG roundtrip，才可綁；B：缺批准/來源不一致→`ORACLE_UNBOUND`，只 HOLD 真消費該 oracle 的 PI promotion/ECP/正式 case verdict，不阻無關唯讀。
2. `Profile 12→9`：PIPD DOC06 12 complexity axes 與工具所見 9-shaped profile 不能直接截斷。ProfileCompiler Reader 保留全部 12 原值及來源，對映為 9 payload 時須記 LossMap/owner批准的適用性、risk guards/nullable、反例（第 10/11/12 軸改變不得 silent-drop）；缺正本 `PROFILE_BIND_HOLD`。`LITE/STANDARD/ASSURED` × `SYSTEM/SKILL_PLUGIN/AGENT_HARNESS/CUSTOM` 必按各適用條件，不因 Commander 純規劃都要求 ASSURED 全流程。[PIPD-D06; P4 `pipd-profile-tailor` actual schema before effect]

**相容性 fence**：`PI_READY != PREDEV_READY != ECP_ISSUED != EXECUTION_ADMITTED != NATIVE_EFFECT_VERIFIED != INDEPENDENT_CASE_PASS != RELEASED`；PIPD CLI 13 verb 與 19 schema 可作安裝/用法參考，但實機 `pipd` parser 行為須讀取真版號及安全 `--help`，沒有有效 token 不得試寫受保護 Repo。`sbl-tpm-sp` 只能在實際有版本化 Host Loader/Skill/ABI 被查證時作 Producer Adapter，不能因規劃名稱就宣稱安裝完成。[PIPD-D00–D09; SBL-D05; B1-D01/D02]

## R2-05-ACTUAL-PLAN：原Source入口讀回

| path/SHA | symbol/signature | interpretation |
|---|---|---|
| C:\Projects\Agent_Workspace\HG-KSEOS\src\hg_kseos\lifecycle.py / 5d4d03356d00c7e19299b7b3d5ddb4cd6dc202d80f164988ef70c033c528c684 | __init__(self, spine: SharedSpine) @L101; admit_workorders(self, project_id: str, *, admission_bundles: dict &#124; None=None) @L332; admit_requirement(self, project_id: str, requirement_id: str, wording: str, *, owner: str='owner', priority: str='P1', admission_bundles: dict &#124; None=None) @L574; completion_sweep(self, project_id: str) @L638 | 只讀AST入口；未調用admit/authorize或改state |
| C:\Projects\Agent_Workspace\HG-KSEOS\src\hg_kseos\native_admission.py / 314eeacd207c6808dfa7ddcf5ef12092861eeb2ff96b24ec5a216970fc889440 | hold_snapshot(self) @L245; authorize(self, connection, operation, request, bundle) @L445 | 只讀AST入口；未調用admit/authorize或改state |
| C:\Projects\Agent_Workspace\HG-KSEOS\src\hg_kseos\role_binding.py / 94084205266e1a841ce0f9be1696813085ef26fbda48ade830cf5f66eff2b938 | load_canonical_binding(spine: Any, workorder_id: Any) @L118; find_session_binding(spine: Any, session_id: Any) @L181 | 只讀AST入口；未調用admit/authorize或改state |

已讀原HGK `profiles/construction-commander/README.runtime-contract.md`：Denied candidate write / AcceptanceReceipt / promotion / release。本候選Guide只產隔離proposal，該profile本身不因此獲Writer權。Native PLAN Producer/CurrentRevisionReader若未有真binding仍C PARK，不回叫legacy。這個來源契約不保證現役Host已Loaded。
