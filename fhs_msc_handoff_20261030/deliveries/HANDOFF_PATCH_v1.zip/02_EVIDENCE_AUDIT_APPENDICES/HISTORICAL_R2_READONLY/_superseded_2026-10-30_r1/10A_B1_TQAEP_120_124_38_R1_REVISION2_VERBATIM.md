## 高保留原 BODY Revision2 實質正文（沿用未受影區；遇 r2 修補採本冊前段）

---
artifact_id: FHS-MSC-R2-BODY-10A
formal_name: B1 120 Parent、124 Child、38 Node與真Runner門面
short_name: BODY-10A
version: 2026-10-29-r2-revision2
source_set_hash_or_pending: f86b217ae3c3ee28183570f4bf3d4f08d4d00e9b86d1de1a641a630f8682d1a1
intended_consumer: 原領域 Owner 與下游 Reader
owner_role: 作者端規格修補者；原 Domain Writer 不移轉
design_status: SOURCE_BOUND_REPAIR_CANDIDATE
claim_ceiling: AUTHOR_STATIC_ONLY; NATIVE_NOT_RUN; CHECKER_NOT_RUN; RELEASE_NOT_RUN
supersession_scope: 本輪作者候選revision2；保留前版封存；不取代任何原Canonical Writer版本
AUDIT_F_IDs:
- F-16
---

# B1 120 Parent、124 Child、38 Node與真Runner門面

## R2-10A-RUNNER：RealRunnerBindingPerCase Resolver

CaseSpec與RunnerBinding、Raw、CheckerCredential分成四物，原120 Parent/124 Child/38 Node全部保留，不把BIND_FROM_NATIVE當任何收據。Resolver只讀原Native Registry，不建立第二Runner服務。每case輸入case_id、source clause SHA、subject/candidate、effect class、original oracle ref；回Binding或typed NOT_RUN。

Binding需原Registry提供：case_id、runner_entry(module/binary origin+SHA/version)、input_schema_id+digest、output/raw_schema_id+digest、call_signature、oracle_implementation+SHA、Host/process scope、permission_scope、checker credential reader ref（不能是Maker自填Principal）。與CaseSpec分開儲存；missing binding→NOT_RUN/RUNNER_NOT_BOUND；schema/case/source/subject不同→BINDING_SCOPE_NACK；exact case下才能發起真Runner。READ_ONLY不要求world nonce；欲effect之case才需原DEV/OPS admission。

原B1.DOMAIN.* RAW@1與B1.TQAEP.*是來源設計標籤；未在真Registry讀回前一律PROPOSED，不當canonical `$id`。本輪Resolver只測靜態拒收，不偽造可執行runner_entry。Node原pseudofunction不當binary command，九個UNRESOLVED源缺口由原PIPD Writer提供對應clause/schema後再綁。

POS（設計）：原Registry所回case_id/source/hash/Host與signature相符時形成RunnerInvocationCandidate；仍須原Issuer才effect。NEG：任何欄是BIND_FROM_NATIVE、BIND_PER_EFFECT、RETRIEVE_*、Maker預填expected、foreign Host、沒有真CheckerReader，均NOT_RUN或NACK，永不自動PASS。

Raw讀取後先核case/source/candidate/Host/operation，再執本case原domain_positive/domain_negative predicate，再由不同受保護principal簽。原verify_receipt最後CHECKER_DOMAIN_PREDICATE_REQUIRED保留，不以作者形狀檢查繞過。

退場：未跑的case不產effect rollback；真READ_ONLY丟快照；Repo回preimage；Host/User/Remote由原Owner做補償/residue；UNKNOWN world先reconcile。本case缺runner只PARK受影Case，其他可跑案保持READY。

## 每Case的當期binding/readback（非虛構Runner）

| Case | expected raw/fields | Oracle POS/NEG | binding/status |
|---|---|---|---|
| TQ-B1-A1-POS | B1.DOMAIN.root_probe.RAW@1 / ['real_root', 'git_head', 'status_index', 'reparse_chain', 'root_handle'] | same file ID and signed root; staged/unstaged/untracked snapshot stable / alias/junction traversal or changed HEAD -> ROOT_ALIAS_OR_PATH_ESCAPE | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-A1-NEG | B1.DOMAIN.root_probe.RAW@1 / ['real_root', 'git_head', 'status_index', 'reparse_chain', 'root_handle'] | same file ID and signed root; staged/unstaged/untracked snapshot stable / alias/junction traversal or changed HEAD -> ROOT_ALIAS_OR_PATH_ESCAPE | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-A1-EDGE | B1.DOMAIN.root_probe.RAW@1 / ['real_root', 'git_head', 'status_index', 'reparse_chain', 'root_handle'] | same file ID and signed root; staged/unstaged/untracked snapshot stable / alias/junction traversal or changed HEAD -> ROOT_ALIAS_OR_PATH_ESCAPE | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-A1-SEC | B1.DOMAIN.root_probe.RAW@1 / ['real_root', 'git_head', 'status_index', 'reparse_chain', 'root_handle'] | same file ID and signed root; staged/unstaged/untracked snapshot stable / alias/junction traversal or changed HEAD -> ROOT_ALIAS_OR_PATH_ESCAPE | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-A2-POS | B1.DOMAIN.native_issuer.RAW@1 / ['issuer_identity', 'subject_sha', 'nonce', 'ttl', 'policy_epoch', 'grant_signature'] | issuer-signed exact subject/scope checked before spawn; nonce consumed once / wrong issuer or replayed nonce -> PERMIT_SUBJECT_NONCE_REPLAY | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-A2-NEG | B1.DOMAIN.native_issuer.RAW@1 / ['issuer_identity', 'subject_sha', 'nonce', 'ttl', 'policy_epoch', 'grant_signature'] | issuer-signed exact subject/scope checked before spawn; nonce consumed once / wrong issuer or replayed nonce -> PERMIT_SUBJECT_NONCE_REPLAY | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-A2-EDGE | B1.DOMAIN.native_issuer.RAW@1 / ['issuer_identity', 'subject_sha', 'nonce', 'ttl', 'policy_epoch', 'grant_signature'] | issuer-signed exact subject/scope checked before spawn; nonce consumed once / wrong issuer or replayed nonce -> PERMIT_SUBJECT_NONCE_REPLAY | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-A2-SEC | B1.DOMAIN.native_issuer.RAW@1 / ['issuer_identity', 'subject_sha', 'nonce', 'ttl', 'policy_epoch', 'grant_signature'] | issuer-signed exact subject/scope checked before spawn; nonce consumed once / wrong issuer or replayed nonce -> PERMIT_SUBJECT_NONCE_REPLAY | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-A3-POS | B1.DOMAIN.hermes_queue.RAW@1 / ['queue_id', 'persisted_cursor', 'lease_generation', 'claimed_by', 'park_reason'] | blocked A parked; independent B/C progressed within bounded K; generation CAS unique / duplicate claim, starved B/C or stale generation -> LOST_LEASE_OR_DUPLICATE_CLAIM | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-A3-NEG | B1.DOMAIN.hermes_queue.RAW@1 / ['queue_id', 'persisted_cursor', 'lease_generation', 'claimed_by', 'park_reason'] | blocked A parked; independent B/C progressed within bounded K; generation CAS unique / duplicate claim, starved B/C or stale generation -> LOST_LEASE_OR_DUPLICATE_CLAIM | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-A3-EDGE | B1.DOMAIN.hermes_queue.RAW@1 / ['queue_id', 'persisted_cursor', 'lease_generation', 'claimed_by', 'park_reason'] | blocked A parked; independent B/C progressed within bounded K; generation CAS unique / duplicate claim, starved B/C or stale generation -> LOST_LEASE_OR_DUPLICATE_CLAIM | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-A3-SEC | B1.DOMAIN.hermes_queue.RAW@1 / ['queue_id', 'persisted_cursor', 'lease_generation', 'claimed_by', 'park_reason'] | blocked A parked; independent B/C progressed within bounded K; generation CAS unique / duplicate claim, starved B/C or stale generation -> LOST_LEASE_OR_DUPLICATE_CLAIM | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-A4-POS | B1.DOMAIN.native_receiver.RAW@1 / ['abi_id', 'issuer', 'wo_id', 'subject_sha', 'ack_or_nack', 'native_event'] | true receiver ACK signed for exact subject; mock ACK never qualifies / mocked ACK/wrong ABI/absent native event -> RECEIVER_NOT_LIVE | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-A4-NEG | B1.DOMAIN.native_receiver.RAW@1 / ['abi_id', 'issuer', 'wo_id', 'subject_sha', 'ack_or_nack', 'native_event'] | true receiver ACK signed for exact subject; mock ACK never qualifies / mocked ACK/wrong ABI/absent native event -> RECEIVER_NOT_LIVE | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-A4-EDGE | B1.DOMAIN.native_receiver.RAW@1 / ['abi_id', 'issuer', 'wo_id', 'subject_sha', 'ack_or_nack', 'native_event'] | true receiver ACK signed for exact subject; mock ACK never qualifies / mocked ACK/wrong ABI/absent native event -> RECEIVER_NOT_LIVE | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-A4-SEC | B1.DOMAIN.native_receiver.RAW@1 / ['abi_id', 'issuer', 'wo_id', 'subject_sha', 'ack_or_nack', 'native_event'] | true receiver ACK signed for exact subject; mock ACK never qualifies / mocked ACK/wrong ABI/absent native event -> RECEIVER_NOT_LIVE | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-A5-POS | B1.DOMAIN.host_lane_readback.RAW@1 / ['PLAN', 'EXECUTE', 'VERIFY_SECURITY', 'required_arm', 'served_arm', 'epoch', 'loaded_sha'] | each mandatory lane actually served, same host and policy epoch / silent model fallback or missing served arm -> MODEL_REQUIRED_NOT_SERVED | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-A5-NEG | B1.DOMAIN.host_lane_readback.RAW@1 / ['PLAN', 'EXECUTE', 'VERIFY_SECURITY', 'required_arm', 'served_arm', 'epoch', 'loaded_sha'] | each mandatory lane actually served, same host and policy epoch / silent model fallback or missing served arm -> MODEL_REQUIRED_NOT_SERVED | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-A5-EDGE | B1.DOMAIN.host_lane_readback.RAW@1 / ['PLAN', 'EXECUTE', 'VERIFY_SECURITY', 'required_arm', 'served_arm', 'epoch', 'loaded_sha'] | each mandatory lane actually served, same host and policy epoch / silent model fallback or missing served arm -> MODEL_REQUIRED_NOT_SERVED | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-A5-SEC | B1.DOMAIN.host_lane_readback.RAW@1 / ['PLAN', 'EXECUTE', 'VERIFY_SECURITY', 'required_arm', 'served_arm', 'epoch', 'loaded_sha'] | each mandatory lane actually served, same host and policy epoch / silent model fallback or missing served arm -> MODEL_REQUIRED_NOT_SERVED | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-A6-POS | B1.DOMAIN.effect_journal.RAW@1 / ['operation_id', 'preimage', 'observed_postimage', 'CAS_fence', 'unknown_effect'] | at-most-once effect; UNKNOWN_EFFECT reconciled before any next claim / duplicate operation or retry-on-timeout -> UNKNOWN_EFFECT_REPLAY | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-A6-NEG | B1.DOMAIN.effect_journal.RAW@1 / ['operation_id', 'preimage', 'observed_postimage', 'CAS_fence', 'unknown_effect'] | at-most-once effect; UNKNOWN_EFFECT reconciled before any next claim / duplicate operation or retry-on-timeout -> UNKNOWN_EFFECT_REPLAY | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-A6-EDGE | B1.DOMAIN.effect_journal.RAW@1 / ['operation_id', 'preimage', 'observed_postimage', 'CAS_fence', 'unknown_effect'] | at-most-once effect; UNKNOWN_EFFECT reconciled before any next claim / duplicate operation or retry-on-timeout -> UNKNOWN_EFFECT_REPLAY | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-A6-SEC | B1.DOMAIN.effect_journal.RAW@1 / ['operation_id', 'preimage', 'observed_postimage', 'CAS_fence', 'unknown_effect'] | at-most-once effect; UNKNOWN_EFFECT reconciled before any next claim / duplicate operation or retry-on-timeout -> UNKNOWN_EFFECT_REPLAY | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-A7-POS | B1.DOMAIN.immutable_evidence.RAW@1 / ['raw_receipt', 'subject_sha', 'candidate_sha', 'checker_principal', 'witness'] | distinct principal checker receipt matches same candidate and non-empty RAW / self-attested or mismatched witness -> RAW_OR_CHECKER_MISMATCH | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-A7-NEG | B1.DOMAIN.immutable_evidence.RAW@1 / ['raw_receipt', 'subject_sha', 'candidate_sha', 'checker_principal', 'witness'] | distinct principal checker receipt matches same candidate and non-empty RAW / self-attested or mismatched witness -> RAW_OR_CHECKER_MISMATCH | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-A7-EDGE | B1.DOMAIN.immutable_evidence.RAW@1 / ['raw_receipt', 'subject_sha', 'candidate_sha', 'checker_principal', 'witness'] | distinct principal checker receipt matches same candidate and non-empty RAW / self-attested or mismatched witness -> RAW_OR_CHECKER_MISMATCH | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-A7-SEC | B1.DOMAIN.immutable_evidence.RAW@1 / ['raw_receipt', 'subject_sha', 'candidate_sha', 'checker_principal', 'witness'] | distinct principal checker receipt matches same candidate and non-empty RAW / self-attested or mismatched witness -> RAW_OR_CHECKER_MISMATCH | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-A8-POS | B1.DOMAIN.repo_diff.RAW@1 / ['root', 'head', 'preimage', 'diff', 'writeset', 'red_green', 'postimage'] | exact loaded callsite identified and scoped regression independent / unbounded writes or missing red reproducer -> HOTPATH_UNRESOLVED | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-A8-NEG | B1.DOMAIN.repo_diff.RAW@1 / ['root', 'head', 'preimage', 'diff', 'writeset', 'red_green', 'postimage'] | exact loaded callsite identified and scoped regression independent / unbounded writes or missing red reproducer -> HOTPATH_UNRESOLVED | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-A8-EDGE | B1.DOMAIN.repo_diff.RAW@1 / ['root', 'head', 'preimage', 'diff', 'writeset', 'red_green', 'postimage'] | exact loaded callsite identified and scoped regression independent / unbounded writes or missing red reproducer -> HOTPATH_UNRESOLVED | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-A8-SEC | B1.DOMAIN.repo_diff.RAW@1 / ['root', 'head', 'preimage', 'diff', 'writeset', 'red_green', 'postimage'] | exact loaded callsite identified and scoped regression independent / unbounded writes or missing red reproducer -> HOTPATH_UNRESOLVED | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-A9-POS | B1.DOMAIN.native_continuation.RAW@1 / ['external_revoke', 'post_turn_source', 'issued_wo', 'native_claim', 'session_exit'] | native successor advances after external revoke with new session and no external trigger / external actor still triggering -> EXTERNAL_TRIGGER_STILL_REQUIRED | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-A9-NEG | B1.DOMAIN.native_continuation.RAW@1 / ['external_revoke', 'post_turn_source', 'issued_wo', 'native_claim', 'session_exit'] | native successor advances after external revoke with new session and no external trigger / external actor still triggering -> EXTERNAL_TRIGGER_STILL_REQUIRED | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-A9-EDGE | B1.DOMAIN.native_continuation.RAW@1 / ['external_revoke', 'post_turn_source', 'issued_wo', 'native_claim', 'session_exit'] | native successor advances after external revoke with new session and no external trigger / external actor still triggering -> EXTERNAL_TRIGGER_STILL_REQUIRED | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-A9-SEC | B1.DOMAIN.native_continuation.RAW@1 / ['external_revoke', 'post_turn_source', 'issued_wo', 'native_claim', 'session_exit'] | native successor advances after external revoke with new session and no external trigger / external actor still triggering -> EXTERNAL_TRIGGER_STILL_REQUIRED | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-B1-POS | B1.DOMAIN.source_oracle.RAW@1 / ['clause_sha', 'atom_id', 'source_owner', 'domain_oracle', 'trace_edges'] | one-to-one source clause/owner/oracle joins; missing clause is HOLD / missing oracle or fabricated source -> PI_SOURCE_OR_ORACLE_UNBOUND | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-B1-NEG | B1.DOMAIN.source_oracle.RAW@1 / ['clause_sha', 'atom_id', 'source_owner', 'domain_oracle', 'trace_edges'] | one-to-one source clause/owner/oracle joins; missing clause is HOLD / missing oracle or fabricated source -> PI_SOURCE_OR_ORACLE_UNBOUND | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-B1-EDGE | B1.DOMAIN.source_oracle.RAW@1 / ['clause_sha', 'atom_id', 'source_owner', 'domain_oracle', 'trace_edges'] | one-to-one source clause/owner/oracle joins; missing clause is HOLD / missing oracle or fabricated source -> PI_SOURCE_OR_ORACLE_UNBOUND | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-B1-SEC | B1.DOMAIN.source_oracle.RAW@1 / ['clause_sha', 'atom_id', 'source_owner', 'domain_oracle', 'trace_edges'] | one-to-one source clause/owner/oracle joins; missing clause is HOLD / missing oracle or fabricated source -> PI_SOURCE_OR_ORACLE_UNBOUND | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-B2-POS | B1.DOMAIN.repo_context_probe.RAW@1 / ['realpath', 'head', 'index', 'untracked', 'writable_scope', 'currentness'] | P4 PD only with actual repo root, HEAD and affected-only allowed write scope / stale/escaping context -> REPO_CONTEXT_NOT_FRESH | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-B2-NEG | B1.DOMAIN.repo_context_probe.RAW@1 / ['realpath', 'head', 'index', 'untracked', 'writable_scope', 'currentness'] | P4 PD only with actual repo root, HEAD and affected-only allowed write scope / stale/escaping context -> REPO_CONTEXT_NOT_FRESH | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-B2-EDGE | B1.DOMAIN.repo_context_probe.RAW@1 / ['realpath', 'head', 'index', 'untracked', 'writable_scope', 'currentness'] | P4 PD only with actual repo root, HEAD and affected-only allowed write scope / stale/escaping context -> REPO_CONTEXT_NOT_FRESH | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-B2-SEC | B1.DOMAIN.repo_context_probe.RAW@1 / ['realpath', 'head', 'index', 'untracked', 'writable_scope', 'currentness'] | P4 PD only with actual repo root, HEAD and affected-only allowed write scope / stale/escaping context -> REPO_CONTEXT_NOT_FRESH | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-B3-POS | B1.DOMAIN.bridge_handoff.RAW@1 / ['sbl_entry', 'candidate', 'dev_diff', 'ops_handoff', 'native_receiver_ack'] | DEV/OPS different WOs, separate source diff and real native ACK / second issuer or shared receipt -> SECOND_ISSUER_OR_MIXED_EFFECT | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-B3-NEG | B1.DOMAIN.bridge_handoff.RAW@1 / ['sbl_entry', 'candidate', 'dev_diff', 'ops_handoff', 'native_receiver_ack'] | DEV/OPS different WOs, separate source diff and real native ACK / second issuer or shared receipt -> SECOND_ISSUER_OR_MIXED_EFFECT | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-B3-EDGE | B1.DOMAIN.bridge_handoff.RAW@1 / ['sbl_entry', 'candidate', 'dev_diff', 'ops_handoff', 'native_receiver_ack'] | DEV/OPS different WOs, separate source diff and real native ACK / second issuer or shared receipt -> SECOND_ISSUER_OR_MIXED_EFFECT | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-B3-SEC | B1.DOMAIN.bridge_handoff.RAW@1 / ['sbl_entry', 'candidate', 'dev_diff', 'ops_handoff', 'native_receiver_ack'] | DEV/OPS different WOs, separate source diff and real native ACK / second issuer or shared receipt -> SECOND_ISSUER_OR_MIXED_EFFECT | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-B4-POS | B1.DOMAIN.ecp_selection.RAW@1 / ['wo_id', 'effect_class', 'active_ecp_count', 'issuer_ack'] | one active ECP per WO; split iff distinct effects / two active ECPs/unknown class -> ECP_MULTIPLE_OR_CLASS_UNKNOWN | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-B4-NEG | B1.DOMAIN.ecp_selection.RAW@1 / ['wo_id', 'effect_class', 'active_ecp_count', 'issuer_ack'] | one active ECP per WO; split iff distinct effects / two active ECPs/unknown class -> ECP_MULTIPLE_OR_CLASS_UNKNOWN | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-B4-EDGE | B1.DOMAIN.ecp_selection.RAW@1 / ['wo_id', 'effect_class', 'active_ecp_count', 'issuer_ack'] | one active ECP per WO; split iff distinct effects / two active ECPs/unknown class -> ECP_MULTIPLE_OR_CLASS_UNKNOWN | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-B4-SEC | B1.DOMAIN.ecp_selection.RAW@1 / ['wo_id', 'effect_class', 'active_ecp_count', 'issuer_ack'] | one active ECP per WO; split iff distinct effects / two active ECPs/unknown class -> ECP_MULTIPLE_OR_CLASS_UNKNOWN | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-B5-POS | B1.DOMAIN.sp_host_load.RAW@1 / ['TPM_SP', 'COMMANDER_SP', 'CHALLENGE_SP', 'host_invocation', 'loaded_sha'] | three host identities and isolated permission readbacks; ZIP-only not pass / missing host invocation -> SP_HOST_LOAD_UNPROVEN | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-B5-NEG | B1.DOMAIN.sp_host_load.RAW@1 / ['TPM_SP', 'COMMANDER_SP', 'CHALLENGE_SP', 'host_invocation', 'loaded_sha'] | three host identities and isolated permission readbacks; ZIP-only not pass / missing host invocation -> SP_HOST_LOAD_UNPROVEN | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-B5-EDGE | B1.DOMAIN.sp_host_load.RAW@1 / ['TPM_SP', 'COMMANDER_SP', 'CHALLENGE_SP', 'host_invocation', 'loaded_sha'] | three host identities and isolated permission readbacks; ZIP-only not pass / missing host invocation -> SP_HOST_LOAD_UNPROVEN | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-B5-SEC | B1.DOMAIN.sp_host_load.RAW@1 / ['TPM_SP', 'COMMANDER_SP', 'CHALLENGE_SP', 'host_invocation', 'loaded_sha'] | three host identities and isolated permission readbacks; ZIP-only not pass / missing host invocation -> SP_HOST_LOAD_UNPROVEN | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-B6-POS | B1.DOMAIN.sbl_todo.RAW@1 / ['data_dir', 'task_id', 'add_response', 'list_response', 'delete_response', 'uninstall'] | isolated store add -> separate list -> delete -> zero residue / user effect misclassified or no actual state -> CLI_EFFECT_MISCLASSIFIED | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-B6-NEG | B1.DOMAIN.sbl_todo.RAW@1 / ['data_dir', 'task_id', 'add_response', 'list_response', 'delete_response', 'uninstall'] | isolated store add -> separate list -> delete -> zero residue / user effect misclassified or no actual state -> CLI_EFFECT_MISCLASSIFIED | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-B6-EDGE | B1.DOMAIN.sbl_todo.RAW@1 / ['data_dir', 'task_id', 'add_response', 'list_response', 'delete_response', 'uninstall'] | isolated store add -> separate list -> delete -> zero residue / user effect misclassified or no actual state -> CLI_EFFECT_MISCLASSIFIED | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-B6-SEC | B1.DOMAIN.sbl_todo.RAW@1 / ['data_dir', 'task_id', 'add_response', 'list_response', 'delete_response', 'uninstall'] | isolated store add -> separate list -> delete -> zero residue / user effect misclassified or no actual state -> CLI_EFFECT_MISCLASSIFIED | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-B7-POS | B1.DOMAIN.no_fit.RAW@1 / ['required_capability', 'host', 'provider_off', 'owner', 'refusal', 'zero_effect'] | deterministic capability NOFIT with user-readable reason and zero unauthorized delta / silent fallback -> NOFIT_OR_PROVIDER_OFF | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-B7-NEG | B1.DOMAIN.no_fit.RAW@1 / ['required_capability', 'host', 'provider_off', 'owner', 'refusal', 'zero_effect'] | deterministic capability NOFIT with user-readable reason and zero unauthorized delta / silent fallback -> NOFIT_OR_PROVIDER_OFF | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-B7-EDGE | B1.DOMAIN.no_fit.RAW@1 / ['required_capability', 'host', 'provider_off', 'owner', 'refusal', 'zero_effect'] | deterministic capability NOFIT with user-readable reason and zero unauthorized delta / silent fallback -> NOFIT_OR_PROVIDER_OFF | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-B7-SEC | B1.DOMAIN.no_fit.RAW@1 / ['required_capability', 'host', 'provider_off', 'owner', 'refusal', 'zero_effect'] | deterministic capability NOFIT with user-readable reason and zero unauthorized delta / silent fallback -> NOFIT_OR_PROVIDER_OFF | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-B8-POS | B1.DOMAIN.trace_closure.RAW@1 / ['pi', 'pd', 'cc', 'ecp', 'wo', 'tqaep', 'raw', 'checker', 'edges'] | nonempty exact IDs and hashes, zero orphans and zero bad edges / foreign/sibling witness -> TRACE_CLOSURE_FAIL | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-B8-NEG | B1.DOMAIN.trace_closure.RAW@1 / ['pi', 'pd', 'cc', 'ecp', 'wo', 'tqaep', 'raw', 'checker', 'edges'] | nonempty exact IDs and hashes, zero orphans and zero bad edges / foreign/sibling witness -> TRACE_CLOSURE_FAIL | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-B8-EDGE | B1.DOMAIN.trace_closure.RAW@1 / ['pi', 'pd', 'cc', 'ecp', 'wo', 'tqaep', 'raw', 'checker', 'edges'] | nonempty exact IDs and hashes, zero orphans and zero bad edges / foreign/sibling witness -> TRACE_CLOSURE_FAIL | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-B8-SEC | B1.DOMAIN.trace_closure.RAW@1 / ['pi', 'pd', 'cc', 'ecp', 'wo', 'tqaep', 'raw', 'checker', 'edges'] | nonempty exact IDs and hashes, zero orphans and zero bad edges / foreign/sibling witness -> TRACE_CLOSURE_FAIL | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-B9-POS | B1.DOMAIN.baseline_denominator.RAW@1 / ['949_ids', '18_families', 'required', 'conditional', 'deferred', 'owners'] | 949 unique 18-family IDs, 66/254/629 and source-specific disposition / missing ID or generic proxy pass -> R15_DENOMINATOR_SHRINK | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-B9-NEG | B1.DOMAIN.baseline_denominator.RAW@1 / ['949_ids', '18_families', 'required', 'conditional', 'deferred', 'owners'] | 949 unique 18-family IDs, 66/254/629 and source-specific disposition / missing ID or generic proxy pass -> R15_DENOMINATOR_SHRINK | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-B9-EDGE | B1.DOMAIN.baseline_denominator.RAW@1 / ['949_ids', '18_families', 'required', 'conditional', 'deferred', 'owners'] | 949 unique 18-family IDs, 66/254/629 and source-specific disposition / missing ID or generic proxy pass -> R15_DENOMINATOR_SHRINK | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-B9-SEC | B1.DOMAIN.baseline_denominator.RAW@1 / ['949_ids', '18_families', 'required', 'conditional', 'deferred', 'owners'] | 949 unique 18-family IDs, 66/254/629 and source-specific disposition / missing ID or generic proxy pass -> R15_DENOMINATOR_SHRINK | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-C1-POS | B1.DOMAIN.fabric_activator.RAW@1 / ['approved_stage', 'active_policy', 'loaded_sha', 'consumer_trace', 'rollback'] | independent stage approval; active and loaded exact digest; consumer projection ACK / stage mistaken as active or missing consumer -> FABRIC_LOADED_ABSENT | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-C1-NEG | B1.DOMAIN.fabric_activator.RAW@1 / ['approved_stage', 'active_policy', 'loaded_sha', 'consumer_trace', 'rollback'] | independent stage approval; active and loaded exact digest; consumer projection ACK / stage mistaken as active or missing consumer -> FABRIC_LOADED_ABSENT | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-C1-EDGE | B1.DOMAIN.fabric_activator.RAW@1 / ['approved_stage', 'active_policy', 'loaded_sha', 'consumer_trace', 'rollback'] | independent stage approval; active and loaded exact digest; consumer projection ACK / stage mistaken as active or missing consumer -> FABRIC_LOADED_ABSENT | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-C1-SEC | B1.DOMAIN.fabric_activator.RAW@1 / ['approved_stage', 'active_policy', 'loaded_sha', 'consumer_trace', 'rollback'] | independent stage approval; active and loaded exact digest; consumer projection ACK / stage mistaken as active or missing consumer -> FABRIC_LOADED_ABSENT | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-C2-POS | B1.DOMAIN.hgk_native_golden.RAW@1 / ['sbl_start', 'issued_wo', 'issuer', 'lease', 'worker_receipt', 'readback'] | true SBL entry -> native HGK issuer -> Hermes lease -> reversible observable result / ghost worker/forged permit -> GWO_HGK_NOT_NATIVE | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-C2-NEG | B1.DOMAIN.hgk_native_golden.RAW@1 / ['sbl_start', 'issued_wo', 'issuer', 'lease', 'worker_receipt', 'readback'] | true SBL entry -> native HGK issuer -> Hermes lease -> reversible observable result / ghost worker/forged permit -> GWO_HGK_NOT_NATIVE | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-C2-EDGE | B1.DOMAIN.hgk_native_golden.RAW@1 / ['sbl_start', 'issued_wo', 'issuer', 'lease', 'worker_receipt', 'readback'] | true SBL entry -> native HGK issuer -> Hermes lease -> reversible observable result / ghost worker/forged permit -> GWO_HGK_NOT_NATIVE | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-C2-SEC | B1.DOMAIN.hgk_native_golden.RAW@1 / ['sbl_start', 'issued_wo', 'issuer', 'lease', 'worker_receipt', 'readback'] | true SBL entry -> native HGK issuer -> Hermes lease -> reversible observable result / ghost worker/forged permit -> GWO_HGK_NOT_NATIVE | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-C3-POS | B1.DOMAIN.sbl_user_golden.RAW@1 / ['sbl_entry', 'stack_install', 'consent', 'todo_add', 'list', 'delete', 'uninstall'] | separate Host install and USER effects with independent readbacks / install count used as add success -> GWO_SBL_USER_STATE_UNPROVEN | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-C3-NEG | B1.DOMAIN.sbl_user_golden.RAW@1 / ['sbl_entry', 'stack_install', 'consent', 'todo_add', 'list', 'delete', 'uninstall'] | separate Host install and USER effects with independent readbacks / install count used as add success -> GWO_SBL_USER_STATE_UNPROVEN | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-C3-EDGE | B1.DOMAIN.sbl_user_golden.RAW@1 / ['sbl_entry', 'stack_install', 'consent', 'todo_add', 'list', 'delete', 'uninstall'] | separate Host install and USER effects with independent readbacks / install count used as add success -> GWO_SBL_USER_STATE_UNPROVEN | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-C3-SEC | B1.DOMAIN.sbl_user_golden.RAW@1 / ['sbl_entry', 'stack_install', 'consent', 'todo_add', 'list', 'delete', 'uninstall'] | separate Host install and USER effects with independent readbacks / install count used as add success -> GWO_SBL_USER_STATE_UNPROVEN | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-C4-POS | B1.DOMAIN.delegation.RAW@1 / ['owner_scope', 'ttl', 'principal', 'revocation', 'zero_scope_escape'] | bounded external grant and no residual capability on revoke / scope expansion -> EXTERNAL_SCOPE_ESCAPED | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-C4-NEG | B1.DOMAIN.delegation.RAW@1 / ['owner_scope', 'ttl', 'principal', 'revocation', 'zero_scope_escape'] | bounded external grant and no residual capability on revoke / scope expansion -> EXTERNAL_SCOPE_ESCAPED | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-C4-EDGE | B1.DOMAIN.delegation.RAW@1 / ['owner_scope', 'ttl', 'principal', 'revocation', 'zero_scope_escape'] | bounded external grant and no residual capability on revoke / scope expansion -> EXTERNAL_SCOPE_ESCAPED | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-C4-SEC | B1.DOMAIN.delegation.RAW@1 / ['owner_scope', 'ttl', 'principal', 'revocation', 'zero_scope_escape'] | bounded external grant and no residual capability on revoke / scope expansion -> EXTERNAL_SCOPE_ESCAPED | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-C5-POS | B1.DOMAIN.bounded_coding.RAW@1 / ['write_scope', 'preimage', 'red_test', 'patch', 'green_test', 'checker'] | only affected files changed and full regression independent / checker edits same diff or no red test -> UNBOUNDED_PATCH_OR_REGRESSION | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-C5-NEG | B1.DOMAIN.bounded_coding.RAW@1 / ['write_scope', 'preimage', 'red_test', 'patch', 'green_test', 'checker'] | only affected files changed and full regression independent / checker edits same diff or no red test -> UNBOUNDED_PATCH_OR_REGRESSION | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-C5-EDGE | B1.DOMAIN.bounded_coding.RAW@1 / ['write_scope', 'preimage', 'red_test', 'patch', 'green_test', 'checker'] | only affected files changed and full regression independent / checker edits same diff or no red test -> UNBOUNDED_PATCH_OR_REGRESSION | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-C5-SEC | B1.DOMAIN.bounded_coding.RAW@1 / ['write_scope', 'preimage', 'red_test', 'patch', 'green_test', 'checker'] | only affected files changed and full regression independent / checker edits same diff or no red test -> UNBOUNDED_PATCH_OR_REGRESSION | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-C6-POS | B1.DOMAIN.revoke_boundary.RAW@1 / ['old_nonce', 'revocation_epoch', 'attempt_after_revoke', 'denied_effect'] | post-revoke use fails before spawn; existing effects reconciled / reused token after revoke -> REVOKED_TOKEN_REPLAY | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-C6-NEG | B1.DOMAIN.revoke_boundary.RAW@1 / ['old_nonce', 'revocation_epoch', 'attempt_after_revoke', 'denied_effect'] | post-revoke use fails before spawn; existing effects reconciled / reused token after revoke -> REVOKED_TOKEN_REPLAY | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-C6-EDGE | B1.DOMAIN.revoke_boundary.RAW@1 / ['old_nonce', 'revocation_epoch', 'attempt_after_revoke', 'denied_effect'] | post-revoke use fails before spawn; existing effects reconciled / reused token after revoke -> REVOKED_TOKEN_REPLAY | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-C6-SEC | B1.DOMAIN.revoke_boundary.RAW@1 / ['old_nonce', 'revocation_epoch', 'attempt_after_revoke', 'denied_effect'] | post-revoke use fails before spawn; existing effects reconciled / reused token after revoke -> REVOKED_TOKEN_REPLAY | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-C7-POS | B1.DOMAIN.loaded_identity.RAW@1 / ['source_sha', 'installed_binary_sha', 'host_loaded_sha', 'served_model', 'policy_epoch'] | all four identity layers tied to same subject, not merely file on disk / green patch with stale loaded binary -> LOADED_BINARY_MISMATCH | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-C7-NEG | B1.DOMAIN.loaded_identity.RAW@1 / ['source_sha', 'installed_binary_sha', 'host_loaded_sha', 'served_model', 'policy_epoch'] | all four identity layers tied to same subject, not merely file on disk / green patch with stale loaded binary -> LOADED_BINARY_MISMATCH | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-C7-EDGE | B1.DOMAIN.loaded_identity.RAW@1 / ['source_sha', 'installed_binary_sha', 'host_loaded_sha', 'served_model', 'policy_epoch'] | all four identity layers tied to same subject, not merely file on disk / green patch with stale loaded binary -> LOADED_BINARY_MISMATCH | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-C7-SEC | B1.DOMAIN.loaded_identity.RAW@1 / ['source_sha', 'installed_binary_sha', 'host_loaded_sha', 'served_model', 'policy_epoch'] | all four identity layers tied to same subject, not merely file on disk / green patch with stale loaded binary -> LOADED_BINARY_MISMATCH | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-C8-POS | B1.DOMAIN.post_revoke_successor.RAW@1 / ['external_stop', 'ledger_cursor', 'issuer', 'successor_wo', 'native_origin'] | fresh separate session native trigger progresses after external account revoked / successor still external-triggered -> NATIVE_SUCCESSOR_NOT_PROVEN | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-C8-NEG | B1.DOMAIN.post_revoke_successor.RAW@1 / ['external_stop', 'ledger_cursor', 'issuer', 'successor_wo', 'native_origin'] | fresh separate session native trigger progresses after external account revoked / successor still external-triggered -> NATIVE_SUCCESSOR_NOT_PROVEN | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-C8-EDGE | B1.DOMAIN.post_revoke_successor.RAW@1 / ['external_stop', 'ledger_cursor', 'issuer', 'successor_wo', 'native_origin'] | fresh separate session native trigger progresses after external account revoked / successor still external-triggered -> NATIVE_SUCCESSOR_NOT_PROVEN | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-C8-SEC | B1.DOMAIN.post_revoke_successor.RAW@1 / ['external_stop', 'ledger_cursor', 'issuer', 'successor_wo', 'native_origin'] | fresh separate session native trigger progresses after external account revoked / successor still external-triggered -> NATIVE_SUCCESSOR_NOT_PROVEN | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-C9-POS | B1.DOMAIN.triple_golden_join.RAW@1 / ['fabric_receipt', 'hgk_receipt', 'sbl_receipt', 'revoke_receipt', 'join_subject'] | 3 different domain receipts, all same intended crosswalk, not aliases / same receipt reused -> GWO_RECEIPT_ALIAS | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-C9-NEG | B1.DOMAIN.triple_golden_join.RAW@1 / ['fabric_receipt', 'hgk_receipt', 'sbl_receipt', 'revoke_receipt', 'join_subject'] | 3 different domain receipts, all same intended crosswalk, not aliases / same receipt reused -> GWO_RECEIPT_ALIAS | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-C9-EDGE | B1.DOMAIN.triple_golden_join.RAW@1 / ['fabric_receipt', 'hgk_receipt', 'sbl_receipt', 'revoke_receipt', 'join_subject'] | 3 different domain receipts, all same intended crosswalk, not aliases / same receipt reused -> GWO_RECEIPT_ALIAS | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-B1-C9-SEC | B1.DOMAIN.triple_golden_join.RAW@1 / ['fabric_receipt', 'hgk_receipt', 'sbl_receipt', 'revoke_receipt', 'join_subject'] | 3 different domain receipts, all same intended crosswalk, not aliases / same receipt reused -> GWO_RECEIPT_ALIAS | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-GWO-FABRIC-POS | B1.DOMAIN.golden_fabric.RAW@1 / ['sbl_entry', 'source_revision', 'stage', 'active', 'loaded_sha', 'consumer_ack'] | consumer sees exact activated policy and source projection, 2 separate effects / stage alone or projection swap -> GWO_DOMAIN_OR_PERMISSION_FAIL | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-GWO-FABRIC-NEG | B1.DOMAIN.golden_fabric.RAW@1 / ['sbl_entry', 'source_revision', 'stage', 'active', 'loaded_sha', 'consumer_ack'] | consumer sees exact activated policy and source projection, 2 separate effects / stage alone or projection swap -> GWO_DOMAIN_OR_PERMISSION_FAIL | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-GWO-FABRIC-EDGE | B1.DOMAIN.golden_fabric.RAW@1 / ['sbl_entry', 'source_revision', 'stage', 'active', 'loaded_sha', 'consumer_ack'] | consumer sees exact activated policy and source projection, 2 separate effects / stage alone or projection swap -> GWO_DOMAIN_OR_PERMISSION_FAIL | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-GWO-FABRIC-SEC | B1.DOMAIN.golden_fabric.RAW@1 / ['sbl_entry', 'source_revision', 'stage', 'active', 'loaded_sha', 'consumer_ack'] | consumer sees exact activated policy and source projection, 2 separate effects / stage alone or projection swap -> GWO_DOMAIN_OR_PERMISSION_FAIL | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-GWO-HGK-POS | B1.DOMAIN.golden_hgk.RAW@1 / ['sbl_entry', 'issuer_event', 'hermes_lease', 'reversible_result', 'post_revoke'] | true native card accepted and autonomously resumes after revoke / helper simulates native queue -> GWO_DOMAIN_OR_PERMISSION_FAIL | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-GWO-HGK-NEG | B1.DOMAIN.golden_hgk.RAW@1 / ['sbl_entry', 'issuer_event', 'hermes_lease', 'reversible_result', 'post_revoke'] | true native card accepted and autonomously resumes after revoke / helper simulates native queue -> GWO_DOMAIN_OR_PERMISSION_FAIL | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-GWO-HGK-EDGE | B1.DOMAIN.golden_hgk.RAW@1 / ['sbl_entry', 'issuer_event', 'hermes_lease', 'reversible_result', 'post_revoke'] | true native card accepted and autonomously resumes after revoke / helper simulates native queue -> GWO_DOMAIN_OR_PERMISSION_FAIL | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-GWO-HGK-SEC | B1.DOMAIN.golden_hgk.RAW@1 / ['sbl_entry', 'issuer_event', 'hermes_lease', 'reversible_result', 'post_revoke'] | true native card accepted and autonomously resumes after revoke / helper simulates native queue -> GWO_DOMAIN_OR_PERMISSION_FAIL | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-GWO-SBL-POS | B1.DOMAIN.golden_sbl.RAW@1 / ['sbl_entry', 'host_install', 'todo_add', 'todo_list', 'todo_delete', 'uninstall'] | user sees persisted isolated task and reversible erase, not proxy / install receipt equals data effect -> GWO_DOMAIN_OR_PERMISSION_FAIL | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-GWO-SBL-NEG | B1.DOMAIN.golden_sbl.RAW@1 / ['sbl_entry', 'host_install', 'todo_add', 'todo_list', 'todo_delete', 'uninstall'] | user sees persisted isolated task and reversible erase, not proxy / install receipt equals data effect -> GWO_DOMAIN_OR_PERMISSION_FAIL | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-GWO-SBL-EDGE | B1.DOMAIN.golden_sbl.RAW@1 / ['sbl_entry', 'host_install', 'todo_add', 'todo_list', 'todo_delete', 'uninstall'] | user sees persisted isolated task and reversible erase, not proxy / install receipt equals data effect -> GWO_DOMAIN_OR_PERMISSION_FAIL | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-GWO-SBL-SEC | B1.DOMAIN.golden_sbl.RAW@1 / ['sbl_entry', 'host_install', 'todo_add', 'todo_list', 'todo_delete', 'uninstall'] | user sees persisted isolated task and reversible erase, not proxy / install receipt equals data effect -> GWO_DOMAIN_OR_PERMISSION_FAIL | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-OBS-B1-A1-POS | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-OBS-B1-A1-NEG | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-OBS-B1-A1-EDGE | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-OBS-B1-A1-SEC | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-A2-POS | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-A2-NEG | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-A2-EDGE | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-A2-SEC | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-A3-POS | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-A3-NEG | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-A3-EDGE | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-A3-SEC | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-A4-POS | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-A4-NEG | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-A4-EDGE | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-A4-SEC | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-OBS-B1-A5-POS | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-OBS-B1-A5-NEG | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-OBS-B1-A5-EDGE | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-OBS-B1-A5-SEC | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-A6-POS | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-A6-NEG | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-A6-EDGE | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-A6-SEC | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-OBS-B1-A7-POS | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-OBS-B1-A7-NEG | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-OBS-B1-A7-EDGE | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-OBS-B1-A7-SEC | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-A8-POS | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-A8-NEG | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-A8-EDGE | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-A8-SEC | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-A9-POS | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-A9-NEG | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-A9-EDGE | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-A9-SEC | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-OBS-B1-B1-POS | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-OBS-B1-B1-NEG | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-OBS-B1-B1-EDGE | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-OBS-B1-B1-SEC | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-OBS-B1-B2-POS | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-OBS-B1-B2-NEG | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-OBS-B1-B2-EDGE | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-OBS-B1-B2-SEC | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-B3-DEV-POS | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-B3-DEV-NEG | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-B3-DEV-EDGE | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-B3-DEV-SEC | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-B3-OPS-POS | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-B3-OPS-NEG | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-B3-OPS-EDGE | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-B3-OPS-SEC | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-B4-DEV-POS | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-B4-DEV-NEG | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-B4-DEV-EDGE | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-B4-DEV-SEC | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-B4-OPS-POS | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-B4-OPS-NEG | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-B4-OPS-EDGE | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-B4-OPS-SEC | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-B5-DEV-POS | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-B5-DEV-NEG | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-B5-DEV-EDGE | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-B5-DEV-SEC | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-B5-OPS-POS | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-B5-OPS-NEG | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-B5-OPS-EDGE | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-B5-OPS-SEC | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-B6-USER-POS | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-B6-USER-NEG | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-B6-USER-EDGE | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-B6-USER-SEC | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-OBS-B1-B7-POS | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-OBS-B1-B7-NEG | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-OBS-B1-B7-EDGE | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-OBS-B1-B7-SEC | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-OBS-B1-B8-POS | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-OBS-B1-B8-NEG | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-OBS-B1-B8-EDGE | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-OBS-B1-B8-SEC | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-OBS-B1-B9-POS | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-OBS-B1-B9-NEG | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-OBS-B1-B9-EDGE | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-OBS-B1-B9-SEC | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-C1-POS | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-C1-NEG | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-C1-EDGE | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-C1-SEC | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-C2-POS | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-C2-NEG | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-C2-EDGE | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-C2-SEC | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-C3-OPS-POS | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-C3-OPS-NEG | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-C3-OPS-EDGE | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-C3-OPS-SEC | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-C3-USER-POS | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-C3-USER-NEG | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-C3-USER-EDGE | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-C3-USER-SEC | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-C4-POS | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-C4-NEG | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-C4-EDGE | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-C4-SEC | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-C5-POS | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-C5-NEG | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-C5-EDGE | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-C5-SEC | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-C6-POS | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-C6-NEG | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-C6-EDGE | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-C6-SEC | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-OBS-B1-C7-POS | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-OBS-B1-C7-NEG | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-OBS-B1-C7-EDGE | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-OBS-B1-C7-SEC | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-C8-POS | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-C8-NEG | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-C8-EDGE | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-WO-B1-C8-SEC | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-OBS-B1-C9-POS | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-OBS-B1-C9-NEG | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-OBS-B1-C9-EDGE | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| TQ-CHILD-OBS-B1-C9-SEC | PROPOSED_NODE_OUTPUT / [] | 原case完整domain Oracle見下方 / 原case完整NEG見下方 | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| B1-N01-01 | RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN / [] | typed native input/output roundtrip with nonempty subject & hash / remove required source/ABI/permission -> deterministic first fail, no output | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| B1-N01-02 | RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN / [] | typed native input/output roundtrip with nonempty subject & hash / remove required source/ABI/permission -> deterministic first fail, no output | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| B1-N01-03 | RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN / [] | typed native input/output roundtrip with nonempty subject & hash / remove required source/ABI/permission -> deterministic first fail, no output | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| B1-N01-04 | RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN / [] | typed native input/output roundtrip with nonempty subject & hash / remove required source/ABI/permission -> deterministic first fail, no output | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| B1-N01-05 | RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN / [] | typed native input/output roundtrip with nonempty subject & hash / remove required source/ABI/permission -> deterministic first fail, no output | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| B1-N01-06 | RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN / [] | typed native input/output roundtrip with nonempty subject & hash / remove required source/ABI/permission -> deterministic first fail, no output | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| B1-N01-07 | RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN / [] | typed native input/output roundtrip with nonempty subject & hash / remove required source/ABI/permission -> deterministic first fail, no output | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| B1-N01-08 | RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN / [] | typed native input/output roundtrip with nonempty subject & hash / remove required source/ABI/permission -> deterministic first fail, no output | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| B1-N02-01 | RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN / [] | typed native input/output roundtrip with nonempty subject & hash / remove required source/ABI/permission -> deterministic first fail, no output | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| B1-N02-02 | RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN / [] | typed native input/output roundtrip with nonempty subject & hash / remove required source/ABI/permission -> deterministic first fail, no output | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| B1-N02-03 | RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN / [] | typed native input/output roundtrip with nonempty subject & hash / remove required source/ABI/permission -> deterministic first fail, no output | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| B1-N02-04 | RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN / [] | typed native input/output roundtrip with nonempty subject & hash / remove required source/ABI/permission -> deterministic first fail, no output | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| B1-N02-05 | RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN / [] | typed native input/output roundtrip with nonempty subject & hash / remove required source/ABI/permission -> deterministic first fail, no output | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| B1-N02-06 | RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN / [] | typed native input/output roundtrip with nonempty subject & hash / remove required source/ABI/permission -> deterministic first fail, no output | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| B1-N02-07 | RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN / [] | typed native input/output roundtrip with nonempty subject & hash / remove required source/ABI/permission -> deterministic first fail, no output | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| B1-N03-01 | RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN / [] | typed native input/output roundtrip with nonempty subject & hash / remove required source/ABI/permission -> deterministic first fail, no output | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| B1-N03-02 | RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN / [] | typed native input/output roundtrip with nonempty subject & hash / remove required source/ABI/permission -> deterministic first fail, no output | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| B1-N03-03 | RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN / [] | typed native input/output roundtrip with nonempty subject & hash / remove required source/ABI/permission -> deterministic first fail, no output | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| B1-N03-04 | RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN / [] | typed native input/output roundtrip with nonempty subject & hash / remove required source/ABI/permission -> deterministic first fail, no output | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| B1-N03-05 | RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN / [] | typed native input/output roundtrip with nonempty subject & hash / remove required source/ABI/permission -> deterministic first fail, no output | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| B1-N03-06 | RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN / [] | typed native input/output roundtrip with nonempty subject & hash / remove required source/ABI/permission -> deterministic first fail, no output | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| B1-N03-07 | RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN / [] | typed native input/output roundtrip with nonempty subject & hash / remove required source/ABI/permission -> deterministic first fail, no output | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| B1-N03-08 | RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN / [] | typed native input/output roundtrip with nonempty subject & hash / remove required source/ABI/permission -> deterministic first fail, no output | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| B1-N04-01 | RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN / [] | typed native input/output roundtrip with nonempty subject & hash / remove required source/ABI/permission -> deterministic first fail, no output | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| B1-N04-02 | RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN / [] | typed native input/output roundtrip with nonempty subject & hash / remove required source/ABI/permission -> deterministic first fail, no output | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| B1-N04-03 | RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN / [] | typed native input/output roundtrip with nonempty subject & hash / remove required source/ABI/permission -> deterministic first fail, no output | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| B1-N04-04 | RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN / [] | typed native input/output roundtrip with nonempty subject & hash / remove required source/ABI/permission -> deterministic first fail, no output | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| B1-N04-05 | RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN / [] | typed native input/output roundtrip with nonempty subject & hash / remove required source/ABI/permission -> deterministic first fail, no output | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| B1-N04-06 | RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN / [] | typed native input/output roundtrip with nonempty subject & hash / remove required source/ABI/permission -> deterministic first fail, no output | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| B1-N04-07 | RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN / [] | typed native input/output roundtrip with nonempty subject & hash / remove required source/ABI/permission -> deterministic first fail, no output | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| B1-N05-01 | RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN / [] | typed native input/output roundtrip with nonempty subject & hash / remove required source/ABI/permission -> deterministic first fail, no output | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| B1-N05-02 | RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN / [] | typed native input/output roundtrip with nonempty subject & hash / remove required source/ABI/permission -> deterministic first fail, no output | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| B1-N05-03 | RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN / [] | typed native input/output roundtrip with nonempty subject & hash / remove required source/ABI/permission -> deterministic first fail, no output | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| B1-N05-04 | RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN / [] | typed native input/output roundtrip with nonempty subject & hash / remove required source/ABI/permission -> deterministic first fail, no output | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| B1-N05-05 | RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN / [] | typed native input/output roundtrip with nonempty subject & hash / remove required source/ABI/permission -> deterministic first fail, no output | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| B1-N05-06 | RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN / [] | typed native input/output roundtrip with nonempty subject & hash / remove required source/ABI/permission -> deterministic first fail, no output | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| B1-N05-07 | RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN / [] | typed native input/output roundtrip with nonempty subject & hash / remove required source/ABI/permission -> deterministic first fail, no output | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |
| B1-N05-08 | RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN / [] | typed native input/output roundtrip with nonempty subject & hash / remove required source/ABI/permission -> deterministic first fail, no output | RUNNER_NOT_BOUND; NATIVE_NOT_RUN |

## 原120/124/38每案完整輸入、Oracle與Fixture


# B1 120 Parent／124 Child Effect／38 Node 逐案 TQAEP 實質正文

本卷是保留原生來源逐條正文的 **設計 Reader**：每條來源規範都需在該 Subject 的真 Host/Registry 綁定後才可能產生正式 effect 或驗收。沒有當期 Raw/Signer/Checker 就只能宣 `DESIGN_SPECIFIED/NOT_EXECUTED`，不得借其他 Case 的歷史 PASS。

## 逐案原義與適用控制

Parent 共 120 案，Child Effect 124 案，Node 38 案；Parent、Child、Node 不得互相代簽；每筆需記 `original_case_id,source_sha,subject_sha,operation_id,runner_id,oracle_owner,expected_pos,expected_neg,raw_ref,checker_principal,first_fail,resume_predicate`。Source DOC05 的 `HOLD_SOURCE_CLAUSE`、`HOLD_OWNER_SCHEMA_ABI` 均不得因重排本卷而改成 `PASS`。

## 完整原 B1 DOC05 案例正文（高保留）

# DOC-B1-TQAEP｜120 Parent Cases、124 Child Effect Cases、38 Node Conformance

<a id="repair-evidence-stages"></a>
## 本候選修訂：測試階段與 Checker 真身份（RCA-08/11/13/21/23/26/36/40/45）

| 階段 | 可核驗內容 | 不得冒稱 |
|---|---|---|
| DEFINED／DESIGN_PLANNED | 120 Parent／124 Child／38 Node 定義、frozen Oracle、fixture/schema | 已取得 Runtime Raw |
| APPLICABLE | 當前 Effect／觸發條件、Source/Policy 版本有定位 | 全清冊已排程 |
| RUNNER_BOUND | 原 Owner registry 的 runner_id／abi_version／schema_id／executable_path／sha256／allowed_os／read_scope／permission_scope／owner_signature 全部可驗 | command string 就是 Runner |
| EXECUTED | 真 exit/stdout/stderr/raw bytes、時間、operation/resource/subject/epoch | Fixture/CI 即 Native PASS |
| INDEPENDENT_VERIFIED | 不同真 Principal／credential／key／只讀 ACL 及不可由 Maker 改寫的 verdict | 作者側 Reviewer 就是獨立 Checker |

本冊原測例完整保留，僅測定義可在本次 DOC 層實測；Native counterparts 全 NOT_RUN。`TEST_PLAN_PASS / FIXTURE_PASS / CI_PASS / NATIVE_VERDICT_PASS` 各自不同。缺 Runner/Owner 為 BLOCKED_MISSING_RUNNER_OR_BINDING，不改成真 FAIL/PASS。原 verifier 為前置拒收器，永遠不自行輸出 PASS。

Raw 只在相同 workorder／operation_id／resource／candidate_sha／epoch 下共用引用；三 GWO 不同 Domain/event 不能借 generic success。Manifest entries 不是 Raw bytes，所有必需原始位元須存在且 SHA 重算；歷史 r10 缺五筆只記歷史 MISSING，當前未重新定位不推定已找齊。Catalog denominator 不是 Scheduler queue；受影增量回歸保留未觸發條件與原 120/124/38 身分。

受影交叉引用：`00`（來源定位 `FHS_MSC_B1_PIPD_LS_PKG_00_GOVERNANCE_AND_CONTROL.md#repair-control`，非本包相對連結）、`02`（來源定位 `FHS_MSC_B1_PIPD_LS_PKG_02_DOC_B1_PD.md#repair-binding`，非本包相對連結）、`07`（來源定位 `FHS_MSC_B1_PIPD_LS_PKG_07_NATIVE_TOOLCHAIN_EXACT_USAGE.md#repair-tool-binding`，非本包相對連結）、`08`（來源定位 `FHS_MSC_B1_PIPD_LS_PKG_08_GOLDEN_WORKORDERS_E2E.md#repair-gwo-entry`，非本包相對連結）。

**法位區分**：以下每個 payload 是可 Schema-check 的 **測試定義**；若真 Host Runner/ActivePolicy/Subject/Raw 不存在，運行前置校驗明確 `BLOCKED_MISSING_RUNNER_OR_BINDING`。不得把 CLI command string 或設計 fixture 視作已執行測試。

## 1. Typed RawReceipt discriminator 與五種結果，不准共用空 schema 假通過

本契約的 runner adapter 需由 Domain Owner 另行註冊帶 `{runner_id,abi_version,schema_id,executable_path,sha256,allowed_os,read_scope,permission_scope,owner_signature}`；全部缺任一必要欄位拒收。Oracle 由不同 Checker 主體執行 `read-only` 以實際 raw path 取證，Maker 不得填 verdict。

```python
def verify_receipt(fixture, raw, runner_registry):
    r=runner_registry.get(fixture['runner_route'])
    needed=('runner_id','abi_version','schema_id','executable_path','sha256','allowed_os','read_scope','permission_scope','owner_signature')
    if not r or not all(r.get(k) for k in needed):
        return 'BLOCKED_MISSING_RUNNER'
    if not raw or not raw.get('candidate_sha') or not raw.get('subject_sha') or not raw.get('policy_epoch'):
        return 'BLOCKED_MISSING_BINDING_OR_RAW'
    keys=['candidate_sha','subject_sha','policy_epoch','workorder_id','operation_id']
    if any(raw.get(k)!=fixture['expected_identity'].get(k) for k in keys):
        return 'FAIL_SUBJECT_OR_OPERATION_ALIAS'
    if not raw.get('raw_sha') or not raw.get('domain_payload'):
        return 'FAIL_EMPTY_DENOMINATOR'
    import unicodedata
    norm=lambda v: unicodedata.normalize('NFKC',str(v)).casefold().strip()
    if not raw.get('maker_id') or not raw.get('checker_id') or norm(raw['maker_id'])==norm(raw['checker_id']):
        return 'FAIL_SELF_ACCEPTANCE'
    if not raw.get('maker_principal_uuid') or not raw.get('checker_principal_uuid'):
        return 'BLOCKED_CHECKER_IDENTITY_UNVERIFIED'
    if raw['maker_principal_uuid']==raw['checker_principal_uuid'] or raw.get('maker_sid')==raw.get('checker_sid') and raw.get('maker_sid'):
        return 'FAIL_SELF_ACCEPTANCE'
    if not all(raw.get(k) is True for k in ('credential_fingerprints_distinct','checker_readonly_acl_verified','maker_cannot_write_checker')):
        return 'BLOCKED_CHECKER_IDENTITY_UNVERIFIED'
    if fixture['effect_class']=='READ_ONLY_PROBE' and raw.get('mutation_count',0)!=0:
        return 'FAIL_READ_ONLY_EFFECT'
    if raw.get('domain_schema')!=fixture['readback']['schema_id']:
        return 'FAIL_WRONG_DOMAIN_SCHEMA'
    # Domain-specific predicates MUST be executed by the real approved checker,
    # not by this placeholder code. No automatic PASS is possible here.
    return 'CHECKER_DOMAIN_PREDICATE_REQUIRED'
```

## 2. 原有 120 個獨立測例（設計 schema，不替代原生 `TQAEP@1`）

### TQ-B1-A1-POS｜ROOT_RAW / POS

- **來源刺激**：source_clause=R15.1:L275(W00), R15.1:L276(W01), R15.1:L277(W02); preconditions=signed allowlisted root, git-index/status -uall, Windows reparse chain, installed binary identities; input_domain=root/owner_re; stimulus=Provide owner-issued exact-current signed allowlisted root, git-index/status -uall, Windows reparse chain, installed binary identities
```json
{
  "atom_or_gwo": "B1-A1",
  "canonical_first_fail": "ROOT_ALIAS_OR_PATH_ESCAPE",
  "case_type": "POS",
  "cross_sibling_acceptance": false,
  "domain": "ROOT_RAW",
  "effect_class": "READ_ONLY_PROBE",
  "expected_case_verdict": "DOMAIN_POSITIVE_AFTER_REAL_RUN",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "alias/junction traversal or changed HEAD -> ROOT_ALIAS_OR_PATH_ESCAPE",
    "domain_positive": "same file ID and signed root; staged/unstaged/untracked snapshot stable",
    "required_domain_fields": [
      "real_root",
      "git_head",
      "status_index",
      "reparse_chain",
      "root_handle"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.root_probe.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::OBS-B1-A1::POS"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L305-L305 excerpt_sha256=c227b3853ad3c9629e9641e09b8b975a2c91f1cdaf5cc5996077da6f1194e74a",
    "stimulus": "valid exact current Owner-supplied fixture only"
  },
  "runner_route": "OWNER_REGISTERED::root_probe",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-A1-POS",
  "workorder_refs": [
    "OBS-B1-A1"
  ]
}
```
- **拒收**：domain `root_probe` missing/typed raw absent => HOLD；實際 error `ROOT_ALIAS_OR_PATH_ESCAPE` 正規化 canonical `ROOT_ALIAS_OR_PATH_ESCAPE`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-A1-NEG｜ROOT_RAW / NEG

- **來源刺激**：source_clause=R15.1:L275(W00), R15.1:L276(W01), R15.1:L277(W02); preconditions=signed allowlisted root, git-index/status -uall, Windows reparse chain, installed binary identities; input_domain=root/owner_re; stimulus=alias root points across junction while textual prefix matches
```json
{
  "atom_or_gwo": "B1-A1",
  "canonical_first_fail": "ROOT_ALIAS_OR_PATH_ESCAPE",
  "case_type": "NEG",
  "cross_sibling_acceptance": false,
  "domain": "ROOT_RAW",
  "effect_class": "READ_ONLY_PROBE",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "alias/junction traversal or changed HEAD -> ROOT_ALIAS_OR_PATH_ESCAPE",
    "domain_positive": "same file ID and signed root; staged/unstaged/untracked snapshot stable",
    "required_domain_fields": [
      "real_root",
      "git_head",
      "status_index",
      "reparse_chain",
      "root_handle"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.root_probe.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::OBS-B1-A1::NEG"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L306-L306 excerpt_sha256=fb2fca0f34616a170369f5b09cd2d106d9ac74ce5a20871a95ddd02bfffd1c88",
    "stimulus": "alias root points across junction while textual prefix matches"
  },
  "runner_route": "OWNER_REGISTERED::root_probe",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-A1-NEG",
  "workorder_refs": [
    "OBS-B1-A1"
  ]
}
```
- **拒收**：domain `root_probe` missing/typed raw absent => HOLD；實際 error `ROOT_ALIAS_OR_PATH_ESCAPE` 正規化 canonical `ROOT_ALIAS_OR_PATH_ESCAPE`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-A1-EDGE｜ROOT_RAW / EDGE

- **來源刺激**：source_clause=R15.1:L275(W00), R15.1:L276(W01), R15.1:L277(W02); preconditions=signed allowlisted root, git-index/status -uall, Windows reparse chain, installed binary identities; input_domain=root/owner_re; stimulus=new untracked path appears after probe before PD bind
```json
{
  "atom_or_gwo": "B1-A1",
  "canonical_first_fail": "ROOT_ALIAS_OR_PATH_ESCAPE",
  "case_type": "EDGE",
  "cross_sibling_acceptance": false,
  "domain": "ROOT_RAW",
  "effect_class": "READ_ONLY_PROBE",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "alias/junction traversal or changed HEAD -> ROOT_ALIAS_OR_PATH_ESCAPE",
    "domain_positive": "same file ID and signed root; staged/unstaged/untracked snapshot stable",
    "required_domain_fields": [
      "real_root",
      "git_head",
      "status_index",
      "reparse_chain",
      "root_handle"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.root_probe.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::OBS-B1-A1::EDGE"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L307-L307 excerpt_sha256=dd6ff2b83b17f97c3671add1bcf3eb04f327909c22c78191cc60852d254ae73f",
    "stimulus": "introduce domain-applicable resource/currentness drift, preserve adjacent independent effects"
  },
  "runner_route": "OWNER_REGISTERED::root_probe",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-A1-EDGE",
  "workorder_refs": [
    "OBS-B1-A1"
  ]
}
```
- **拒收**：domain `root_probe` missing/typed raw absent => HOLD；實際 error `ROOT_ALIAS_OR_PATH_ESCAPE_EDGE` 正規化 canonical `ROOT_ALIAS_OR_PATH_ESCAPE`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-A1-SEC｜ROOT_RAW / SEC

- **來源刺激**：source_clause=R15.1:L275(W00), R15.1:L276(W01), R15.1:L277(W02); preconditions=signed allowlisted root, git-index/status -uall, Windows reparse chain, installed binary identities; input_domain=root/owner_re; stimulus=reparse ancestor redirects write outside allowlist
```json
{
  "atom_or_gwo": "B1-A1",
  "canonical_first_fail": "ROOT_ALIAS_OR_PATH_ESCAPE",
  "case_type": "SEC",
  "cross_sibling_acceptance": false,
  "domain": "ROOT_RAW",
  "effect_class": "READ_ONLY_PROBE",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "alias/junction traversal or changed HEAD -> ROOT_ALIAS_OR_PATH_ESCAPE",
    "domain_positive": "same file ID and signed root; staged/unstaged/untracked snapshot stable",
    "required_domain_fields": [
      "real_root",
      "git_head",
      "status_index",
      "reparse_chain",
      "root_handle"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.root_probe.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::OBS-B1-A1::SEC"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L308-L308 excerpt_sha256=c10b9516de8dbf240b16b68565711e58afb9f654c6ce8f27b78c950733a49147",
    "stimulus": "forge/replay this domain credential/subject or cross-swap sibling receipt"
  },
  "runner_route": "OWNER_REGISTERED::root_probe",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-A1-SEC",
  "workorder_refs": [
    "OBS-B1-A1"
  ]
}
```
- **拒收**：domain `root_probe` missing/typed raw absent => HOLD；實際 error `ROOT_ALIAS_OR_PATH_ESCAPE_SEC` 正規化 canonical `ROOT_ALIAS_OR_PATH_ESCAPE`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-A2-POS｜ISSUER_SUBJECT / POS

- **來源刺激**：source_clause=R15.1:§12; PIPD05:Receiver/Permission; preconditions=subject_hash, permission actor, effect_class, scope, nonce, ttl, epoch, policy digest; input_domain=native_issuer，subject_ref; stimulus=Provide owner-issued exact-current subject_hash, permission actor, effect_class, scope, nonce, ttl, epoch, policy digest
```json
{
  "atom_or_gwo": "B1-A2",
  "canonical_first_fail": "PERMIT_SUBJECT_NONCE_REPLAY",
  "case_type": "POS",
  "cross_sibling_acceptance": false,
  "domain": "ISSUER_SUBJECT",
  "effect_class": "HOST_OPERATIONS",
  "expected_case_verdict": "DOMAIN_POSITIVE_AFTER_REAL_RUN",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "wrong issuer or replayed nonce -> PERMIT_SUBJECT_NONCE_REPLAY",
    "domain_positive": "issuer-signed exact subject/scope checked before spawn; nonce consumed once",
    "required_domain_fields": [
      "issuer_identity",
      "subject_sha",
      "nonce",
      "ttl",
      "policy_epoch",
      "grant_signature"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.native_issuer.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::WO-B1-A2::POS"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L309-L309 excerpt_sha256=ad543c68b8cdd47e7011ee105c32a9101ebd3e07801224ed10f387902548963c",
    "stimulus": "valid exact current Owner-supplied fixture only"
  },
  "runner_route": "OWNER_REGISTERED::native_issuer",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-A2-POS",
  "workorder_refs": [
    "WO-B1-A2"
  ]
}
```
- **拒收**：domain `native_issuer` missing/typed raw absent => HOLD；實際 error `PERMIT_SUBJECT_NONCE_REPLAY` 正規化 canonical `PERMIT_SUBJECT_NONCE_REPLAY`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-A2-NEG｜ISSUER_SUBJECT / NEG

- **來源刺激**：source_clause=R15.1:§12; PIPD05:Receiver/Permission; preconditions=subject_hash, permission actor, effect_class, scope, nonce, ttl, epoch, policy digest; input_domain=native_issuer，subject_ref; stimulus=reuse valid token for different subject after a prior ACK
```json
{
  "atom_or_gwo": "B1-A2",
  "canonical_first_fail": "PERMIT_SUBJECT_NONCE_REPLAY",
  "case_type": "NEG",
  "cross_sibling_acceptance": false,
  "domain": "ISSUER_SUBJECT",
  "effect_class": "HOST_OPERATIONS",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "wrong issuer or replayed nonce -> PERMIT_SUBJECT_NONCE_REPLAY",
    "domain_positive": "issuer-signed exact subject/scope checked before spawn; nonce consumed once",
    "required_domain_fields": [
      "issuer_identity",
      "subject_sha",
      "nonce",
      "ttl",
      "policy_epoch",
      "grant_signature"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.native_issuer.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::WO-B1-A2::NEG"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L310-L310 excerpt_sha256=0ec8470f1f23487ac632f76bcd6b452cd4f36a02873bc21c6a7f5def2817b7e0",
    "stimulus": "reuse valid token for different subject after a prior ACK"
  },
  "runner_route": "OWNER_REGISTERED::native_issuer",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-A2-NEG",
  "workorder_refs": [
    "WO-B1-A2"
  ]
}
```
- **拒收**：domain `native_issuer` missing/typed raw absent => HOLD；實際 error `PERMIT_SUBJECT_NONCE_REPLAY` 正規化 canonical `PERMIT_SUBJECT_NONCE_REPLAY`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-A2-EDGE｜ISSUER_SUBJECT / EDGE

- **來源刺激**：source_clause=R15.1:§12; PIPD05:Receiver/Permission; preconditions=subject_hash, permission actor, effect_class, scope, nonce, ttl, epoch, policy digest; input_domain=native_issuer，subject_ref; stimulus=token expires between issue and first worker invocation
```json
{
  "atom_or_gwo": "B1-A2",
  "canonical_first_fail": "PERMIT_SUBJECT_NONCE_REPLAY",
  "case_type": "EDGE",
  "cross_sibling_acceptance": false,
  "domain": "ISSUER_SUBJECT",
  "effect_class": "HOST_OPERATIONS",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "wrong issuer or replayed nonce -> PERMIT_SUBJECT_NONCE_REPLAY",
    "domain_positive": "issuer-signed exact subject/scope checked before spawn; nonce consumed once",
    "required_domain_fields": [
      "issuer_identity",
      "subject_sha",
      "nonce",
      "ttl",
      "policy_epoch",
      "grant_signature"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.native_issuer.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::WO-B1-A2::EDGE"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L311-L311 excerpt_sha256=9d736d7a4f61db2426867099d67ff047eea5ecfd80657ca2d7d9b245cde5aaad",
    "stimulus": "introduce domain-applicable resource/currentness drift, preserve adjacent independent effects"
  },
  "runner_route": "OWNER_REGISTERED::native_issuer",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-A2-EDGE",
  "workorder_refs": [
    "WO-B1-A2"
  ]
}
```
- **拒收**：domain `native_issuer` missing/typed raw absent => HOLD；實際 error `PERMIT_SUBJECT_NONCE_REPLAY_EDGE` 正規化 canonical `PERMIT_SUBJECT_NONCE_REPLAY`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-A2-SEC｜ISSUER_SUBJECT / SEC

- **來源刺激**：source_clause=R15.1:§12; PIPD05:Receiver/Permission; preconditions=subject_hash, permission actor, effect_class, scope, nonce, ttl, epoch, policy digest; input_domain=native_issuer，subject_ref; stimulus=revoked principal presents previously consumed nonce
```json
{
  "atom_or_gwo": "B1-A2",
  "canonical_first_fail": "PERMIT_SUBJECT_NONCE_REPLAY",
  "case_type": "SEC",
  "cross_sibling_acceptance": false,
  "domain": "ISSUER_SUBJECT",
  "effect_class": "HOST_OPERATIONS",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "wrong issuer or replayed nonce -> PERMIT_SUBJECT_NONCE_REPLAY",
    "domain_positive": "issuer-signed exact subject/scope checked before spawn; nonce consumed once",
    "required_domain_fields": [
      "issuer_identity",
      "subject_sha",
      "nonce",
      "ttl",
      "policy_epoch",
      "grant_signature"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.native_issuer.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::WO-B1-A2::SEC"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L312-L312 excerpt_sha256=409f3ebf58d1b475da7f940a04e675abe2045a202e4c165d74d69be9afc7ce14",
    "stimulus": "forge/replay this domain credential/subject or cross-swap sibling receipt"
  },
  "runner_route": "OWNER_REGISTERED::native_issuer",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-A2-SEC",
  "workorder_refs": [
    "WO-B1-A2"
  ]
}
```
- **拒收**：domain `native_issuer` missing/typed raw absent => HOLD；實際 error `PERMIT_SUBJECT_NONCE_REPLAY_SEC` 正規化 canonical `PERMIT_SUBJECT_NONCE_REPLAY`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-A3-POS｜QUEUE_WO / POS

- **來源刺激**：source_clause=R15.1:L284(W09); preconditions=Native issued WO, queue card key, lease_generation, claimant principal, checkpoint cursor; input_domain=hermes/queue，subject_; stimulus=Provide owner-issued exact-current Native issued WO, queue card key, lease_generation, claimant principal, checkpoint cursor
```json
{
  "atom_or_gwo": "B1-A3",
  "canonical_first_fail": "LOST_LEASE_OR_DUPLICATE_CLAIM",
  "case_type": "POS",
  "cross_sibling_acceptance": false,
  "domain": "QUEUE_WO",
  "effect_class": "HOST_OPERATIONS",
  "expected_case_verdict": "DOMAIN_POSITIVE_AFTER_REAL_RUN",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "duplicate claim, starved B/C or stale generation -> LOST_LEASE_OR_DUPLICATE_CLAIM",
    "domain_positive": "blocked A parked; independent B/C progressed within bounded K; generation CAS unique",
    "required_domain_fields": [
      "queue_id",
      "persisted_cursor",
      "lease_generation",
      "claimed_by",
      "park_reason"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.hermes_queue.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::WO-B1-A3::POS"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L313-L313 excerpt_sha256=31880bb21f010d194cf2c150ac119579ed00a65b905f1e328966f82e0424f04c",
    "stimulus": "valid exact current Owner-supplied fixture only"
  },
  "runner_route": "OWNER_REGISTERED::hermes_queue",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-A3-POS",
  "workorder_refs": [
    "WO-B1-A3"
  ]
}
```
- **拒收**：domain `hermes_queue` missing/typed raw absent => HOLD；實際 error `LOST_LEASE_OR_DUPLICATE_CLAIM` 正規化 canonical `LOST_LEASE_OR_DUPLICATE_CLAIM`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-A3-NEG｜QUEUE_WO / NEG

- **來源刺激**：source_clause=R15.1:L284(W09); preconditions=Native issued WO, queue card key, lease_generation, claimant principal, checkpoint cursor; input_domain=hermes/queue，subject_; stimulus=crash/reclaim retries effect with unknown outcome
```json
{
  "atom_or_gwo": "B1-A3",
  "canonical_first_fail": "LOST_LEASE_OR_DUPLICATE_CLAIM",
  "case_type": "NEG",
  "cross_sibling_acceptance": false,
  "domain": "QUEUE_WO",
  "effect_class": "HOST_OPERATIONS",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "duplicate claim, starved B/C or stale generation -> LOST_LEASE_OR_DUPLICATE_CLAIM",
    "domain_positive": "blocked A parked; independent B/C progressed within bounded K; generation CAS unique",
    "required_domain_fields": [
      "queue_id",
      "persisted_cursor",
      "lease_generation",
      "claimed_by",
      "park_reason"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.hermes_queue.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::WO-B1-A3::NEG"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L314-L314 excerpt_sha256=2b8e7482d22f2535221e7f3dd268484cc905b1d7f3c02afcaa499dbed000454e",
    "stimulus": "crash/reclaim retries effect with unknown outcome"
  },
  "runner_route": "OWNER_REGISTERED::hermes_queue",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-A3-NEG",
  "workorder_refs": [
    "WO-B1-A3"
  ]
}
```
- **拒收**：domain `hermes_queue` missing/typed raw absent => HOLD；實際 error `LOST_LEASE_OR_DUPLICATE_CLAIM` 正規化 canonical `LOST_LEASE_OR_DUPLICATE_CLAIM`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-A3-EDGE｜QUEUE_WO / EDGE

- **來源刺激**：source_clause=R15.1:L284(W09); preconditions=Native issued WO, queue card key, lease_generation, claimant principal, checkpoint cursor; input_domain=hermes/queue，subject_; stimulus=two workers race CAS claim for same generation
```json
{
  "atom_or_gwo": "B1-A3",
  "canonical_first_fail": "LOST_LEASE_OR_DUPLICATE_CLAIM",
  "case_type": "EDGE",
  "cross_sibling_acceptance": false,
  "domain": "QUEUE_WO",
  "effect_class": "HOST_OPERATIONS",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "duplicate claim, starved B/C or stale generation -> LOST_LEASE_OR_DUPLICATE_CLAIM",
    "domain_positive": "blocked A parked; independent B/C progressed within bounded K; generation CAS unique",
    "required_domain_fields": [
      "queue_id",
      "persisted_cursor",
      "lease_generation",
      "claimed_by",
      "park_reason"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.hermes_queue.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::WO-B1-A3::EDGE"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L315-L315 excerpt_sha256=5f07e7a8e1cae5e45268373ce5ea74e1c50424285c35623032dfd727723cc7db",
    "stimulus": "introduce domain-applicable resource/currentness drift, preserve adjacent independent effects"
  },
  "runner_route": "OWNER_REGISTERED::hermes_queue",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-A3-EDGE",
  "workorder_refs": [
    "WO-B1-A3"
  ]
}
```
- **拒收**：domain `hermes_queue` missing/typed raw absent => HOLD；實際 error `LOST_LEASE_OR_DUPLICATE_CLAIM_EDGE` 正規化 canonical `LOST_LEASE_OR_DUPLICATE_CLAIM`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-A3-SEC｜QUEUE_WO / SEC

- **來源刺激**：source_clause=R15.1:L284(W09); preconditions=Native issued WO, queue card key, lease_generation, claimant principal, checkpoint cursor; input_domain=hermes/queue，subject_; stimulus=revoked worker heartbeats after lease fence
```json
{
  "atom_or_gwo": "B1-A3",
  "canonical_first_fail": "LOST_LEASE_OR_DUPLICATE_CLAIM",
  "case_type": "SEC",
  "cross_sibling_acceptance": false,
  "domain": "QUEUE_WO",
  "effect_class": "HOST_OPERATIONS",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "duplicate claim, starved B/C or stale generation -> LOST_LEASE_OR_DUPLICATE_CLAIM",
    "domain_positive": "blocked A parked; independent B/C progressed within bounded K; generation CAS unique",
    "required_domain_fields": [
      "queue_id",
      "persisted_cursor",
      "lease_generation",
      "claimed_by",
      "park_reason"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.hermes_queue.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::WO-B1-A3::SEC"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L316-L316 excerpt_sha256=3997dd339087e384d907a162877b358d26936e7ca62b86042f46841e6fef26de",
    "stimulus": "forge/replay this domain credential/subject or cross-swap sibling receipt"
  },
  "runner_route": "OWNER_REGISTERED::hermes_queue",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-A3-SEC",
  "workorder_refs": [
    "WO-B1-A3"
  ]
}
```
- **拒收**：domain `hermes_queue` missing/typed raw absent => HOLD；實際 error `LOST_LEASE_OR_DUPLICATE_CLAIM_SEC` 正規化 canonical `LOST_LEASE_OR_DUPLICATE_CLAIM`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-A4-POS｜RECEIVER_ABI / POS

- **來源刺激**：source_clause=PIPD05:H1-04; R15.1:§12; preconditions=SBL candidate envelope and actual installed HGK receiver schema/version/endpoint; input_domain=hgk/receiver，subject_ref+sha; stimulus=Provide owner-issued exact-current SBL candidate envelope and actual installed HGK receiver schema/version/endpoint
```json
{
  "atom_or_gwo": "B1-A4",
  "canonical_first_fail": "RECEIVER_NOT_LIVE",
  "case_type": "POS",
  "cross_sibling_acceptance": false,
  "domain": "RECEIVER_ABI",
  "effect_class": "HOST_OPERATIONS",
  "expected_case_verdict": "DOMAIN_POSITIVE_AFTER_REAL_RUN",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "mocked ACK/wrong ABI/absent native event -> RECEIVER_NOT_LIVE",
    "domain_positive": "true receiver ACK signed for exact subject; mock ACK never qualifies",
    "required_domain_fields": [
      "abi_id",
      "issuer",
      "wo_id",
      "subject_sha",
      "ack_or_nack",
      "native_event"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.native_receiver.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::WO-B1-A4::POS"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L317-L317 excerpt_sha256=d00f2e0fde9933915db356818e56adec7a3c9ec0aab6a5229a240cf32c965a5f",
    "stimulus": "valid exact current Owner-supplied fixture only"
  },
  "runner_route": "OWNER_REGISTERED::native_receiver",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-A4-POS",
  "workorder_refs": [
    "WO-B1-A4"
  ]
}
```
- **拒收**：domain `native_receiver` missing/typed raw absent => HOLD；實際 error `RECEIVER_NOT_LIVE` 正規化 canonical `RECEIVER_NOT_LIVE`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-A4-NEG｜RECEIVER_ABI / NEG

- **來源刺激**：source_clause=PIPD05:H1-04; R15.1:§12; preconditions=SBL candidate envelope and actual installed HGK receiver schema/version/endpoint; input_domain=hgk/receiver，subject_ref+sha; stimulus=PIPD fixture Receiver Map labelled NOT_RUN supplied as live ACK
```json
{
  "atom_or_gwo": "B1-A4",
  "canonical_first_fail": "RECEIVER_NOT_LIVE",
  "case_type": "NEG",
  "cross_sibling_acceptance": false,
  "domain": "RECEIVER_ABI",
  "effect_class": "HOST_OPERATIONS",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "mocked ACK/wrong ABI/absent native event -> RECEIVER_NOT_LIVE",
    "domain_positive": "true receiver ACK signed for exact subject; mock ACK never qualifies",
    "required_domain_fields": [
      "abi_id",
      "issuer",
      "wo_id",
      "subject_sha",
      "ack_or_nack",
      "native_event"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.native_receiver.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::WO-B1-A4::NEG"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L318-L318 excerpt_sha256=f1dec1613f0d65d88138f635c2f4b1e054dcc46334837cda24bd67838aae577e",
    "stimulus": "PIPD fixture Receiver Map labelled NOT_RUN supplied as live ACK"
  },
  "runner_route": "OWNER_REGISTERED::native_receiver",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-A4-NEG",
  "workorder_refs": [
    "WO-B1-A4"
  ]
}
```
- **拒收**：domain `native_receiver` missing/typed raw absent => HOLD；實際 error `LIVE_RECEIVER_NOT_VERIFIED` 正規化 canonical `RECEIVER_NOT_LIVE`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-A4-EDGE｜RECEIVER_ABI / EDGE

- **來源刺激**：source_clause=PIPD05:H1-04; R15.1:§12; preconditions=SBL candidate envelope and actual installed HGK receiver schema/version/endpoint; input_domain=hgk/receiver，subject_ref+sha; stimulus=receiver upgraded ABI while queue still holds old envelope
```json
{
  "atom_or_gwo": "B1-A4",
  "canonical_first_fail": "RECEIVER_NOT_LIVE",
  "case_type": "EDGE",
  "cross_sibling_acceptance": false,
  "domain": "RECEIVER_ABI",
  "effect_class": "HOST_OPERATIONS",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "mocked ACK/wrong ABI/absent native event -> RECEIVER_NOT_LIVE",
    "domain_positive": "true receiver ACK signed for exact subject; mock ACK never qualifies",
    "required_domain_fields": [
      "abi_id",
      "issuer",
      "wo_id",
      "subject_sha",
      "ack_or_nack",
      "native_event"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.native_receiver.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::WO-B1-A4::EDGE"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L319-L319 excerpt_sha256=bc39a3cd225f92036e879a91df0f4daedd016b71983c757f9039795bacb0b44e",
    "stimulus": "introduce domain-applicable resource/currentness drift, preserve adjacent independent effects"
  },
  "runner_route": "OWNER_REGISTERED::native_receiver",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-A4-EDGE",
  "workorder_refs": [
    "WO-B1-A4"
  ]
}
```
- **拒收**：domain `native_receiver` missing/typed raw absent => HOLD；實際 error `LIVE_RECEIVER_NOT_VERIFIED_EDGE` 正規化 canonical `RECEIVER_NOT_LIVE`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-A4-SEC｜RECEIVER_ABI / SEC

- **來源刺激**：source_clause=PIPD05:H1-04; R15.1:§12; preconditions=SBL candidate envelope and actual installed HGK receiver schema/version/endpoint; input_domain=hgk/receiver，subject_ref+sha; stimulus=untrusted payload smuggles effect_class override
```json
{
  "atom_or_gwo": "B1-A4",
  "canonical_first_fail": "RECEIVER_NOT_LIVE",
  "case_type": "SEC",
  "cross_sibling_acceptance": false,
  "domain": "RECEIVER_ABI",
  "effect_class": "HOST_OPERATIONS",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "mocked ACK/wrong ABI/absent native event -> RECEIVER_NOT_LIVE",
    "domain_positive": "true receiver ACK signed for exact subject; mock ACK never qualifies",
    "required_domain_fields": [
      "abi_id",
      "issuer",
      "wo_id",
      "subject_sha",
      "ack_or_nack",
      "native_event"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.native_receiver.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::WO-B1-A4::SEC"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L320-L320 excerpt_sha256=fdefb85d282d3fab40228a7d639f5cdc14dcb6762d2075284ebbe8a3b1bcbb7d",
    "stimulus": "forge/replay this domain credential/subject or cross-swap sibling receipt"
  },
  "runner_route": "OWNER_REGISTERED::native_receiver",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-A4-SEC",
  "workorder_refs": [
    "WO-B1-A4"
  ]
}
```
- **拒收**：domain `native_receiver` missing/typed raw absent => HOLD；實際 error `LIVE_RECEIVER_NOT_VERIFIED_SEC` 正規化 canonical `RECEIVER_NOT_LIVE`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-A5-POS｜MODEL_LANES / POS

- **來源刺激**：source_clause=R15.1:L283(W08); preconditions=required PLAN/EXECUTE/VERIFY model+provider; profile epoch, request id, loaded skill digest; input_domain=host/model_registry，; stimulus=Provide owner-issued exact-current required PLAN/EXECUTE/VERIFY model+provider; profile epoch, request id, loaded skill digest
```json
{
  "atom_or_gwo": "B1-A5",
  "canonical_first_fail": "MODEL_REQUIRED_NOT_SERVED",
  "case_type": "POS",
  "cross_sibling_acceptance": false,
  "domain": "MODEL_LANES",
  "effect_class": "READ_ONLY_PROBE",
  "expected_case_verdict": "DOMAIN_POSITIVE_AFTER_REAL_RUN",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "silent model fallback or missing served arm -> MODEL_REQUIRED_NOT_SERVED",
    "domain_positive": "each mandatory lane actually served, same host and policy epoch",
    "required_domain_fields": [
      "PLAN",
      "EXECUTE",
      "VERIFY_SECURITY",
      "required_arm",
      "served_arm",
      "epoch",
      "loaded_sha"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.host_lane_readback.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::OBS-B1-A5::POS"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L321-L321 excerpt_sha256=1498590050d094e6d2df97bff7c868c5b4169bf31241a4e85b033f67a7c60b60",
    "stimulus": "valid exact current Owner-supplied fixture only"
  },
  "runner_route": "OWNER_REGISTERED::host_lane_readback",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-A5-POS",
  "workorder_refs": [
    "OBS-B1-A5"
  ]
}
```
- **拒收**：domain `host_lane_readback` missing/typed raw absent => HOLD；實際 error `MODEL_REQUIRED_NOT_SERVED` 正規化 canonical `MODEL_REQUIRED_NOT_SERVED`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-A5-NEG｜MODEL_LANES / NEG

- **來源刺激**：source_clause=R15.1:L283(W08); preconditions=required PLAN/EXECUTE/VERIFY model+provider; profile epoch, request id, loaded skill digest; input_domain=host/model_registry，; stimulus=EXECUTE served model differs but PLAN pin is treated as proof
```json
{
  "atom_or_gwo": "B1-A5",
  "canonical_first_fail": "MODEL_REQUIRED_NOT_SERVED",
  "case_type": "NEG",
  "cross_sibling_acceptance": false,
  "domain": "MODEL_LANES",
  "effect_class": "READ_ONLY_PROBE",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "silent model fallback or missing served arm -> MODEL_REQUIRED_NOT_SERVED",
    "domain_positive": "each mandatory lane actually served, same host and policy epoch",
    "required_domain_fields": [
      "PLAN",
      "EXECUTE",
      "VERIFY_SECURITY",
      "required_arm",
      "served_arm",
      "epoch",
      "loaded_sha"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.host_lane_readback.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::OBS-B1-A5::NEG"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L322-L322 excerpt_sha256=6517396bdc8894584b6f82bec1d10aa45edc4a55ba84ee3c163f86fd1d9b4f15",
    "stimulus": "EXECUTE served model differs but PLAN pin is treated as proof"
  },
  "runner_route": "OWNER_REGISTERED::host_lane_readback",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-A5-NEG",
  "workorder_refs": [
    "OBS-B1-A5"
  ]
}
```
- **拒收**：domain `host_lane_readback` missing/typed raw absent => HOLD；實際 error `SERVED_MODEL_MISMATCH` 正規化 canonical `MODEL_REQUIRED_NOT_SERVED`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-A5-EDGE｜MODEL_LANES / EDGE

- **來源刺激**：source_clause=R15.1:L283(W08); preconditions=required PLAN/EXECUTE/VERIFY model+provider; profile epoch, request id, loaded skill digest; input_domain=host/model_registry，; stimulus=VERIFY epoch rotates after PLAN and before independent check
```json
{
  "atom_or_gwo": "B1-A5",
  "canonical_first_fail": "MODEL_REQUIRED_NOT_SERVED",
  "case_type": "EDGE",
  "cross_sibling_acceptance": false,
  "domain": "MODEL_LANES",
  "effect_class": "READ_ONLY_PROBE",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "silent model fallback or missing served arm -> MODEL_REQUIRED_NOT_SERVED",
    "domain_positive": "each mandatory lane actually served, same host and policy epoch",
    "required_domain_fields": [
      "PLAN",
      "EXECUTE",
      "VERIFY_SECURITY",
      "required_arm",
      "served_arm",
      "epoch",
      "loaded_sha"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.host_lane_readback.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::OBS-B1-A5::EDGE"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L323-L323 excerpt_sha256=fbb40b708853252b106b46752811381c3eec84f665dd567918af3d5e65579fcf",
    "stimulus": "introduce domain-applicable resource/currentness drift, preserve adjacent independent effects"
  },
  "runner_route": "OWNER_REGISTERED::host_lane_readback",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-A5-EDGE",
  "workorder_refs": [
    "OBS-B1-A5"
  ]
}
```
- **拒收**：domain `host_lane_readback` missing/typed raw absent => HOLD；實際 error `SERVED_MODEL_MISMATCH_EDGE` 正規化 canonical `MODEL_REQUIRED_NOT_SERVED`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-A5-SEC｜MODEL_LANES / SEC

- **來源刺激**：source_clause=R15.1:L283(W08); preconditions=required PLAN/EXECUTE/VERIFY model+provider; profile epoch, request id, loaded skill digest; input_domain=host/model_registry，; stimulus=different display alias hides same checker immutable principal
```json
{
  "atom_or_gwo": "B1-A5",
  "canonical_first_fail": "MODEL_REQUIRED_NOT_SERVED",
  "case_type": "SEC",
  "cross_sibling_acceptance": false,
  "domain": "MODEL_LANES",
  "effect_class": "READ_ONLY_PROBE",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "silent model fallback or missing served arm -> MODEL_REQUIRED_NOT_SERVED",
    "domain_positive": "each mandatory lane actually served, same host and policy epoch",
    "required_domain_fields": [
      "PLAN",
      "EXECUTE",
      "VERIFY_SECURITY",
      "required_arm",
      "served_arm",
      "epoch",
      "loaded_sha"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.host_lane_readback.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::OBS-B1-A5::SEC"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L324-L324 excerpt_sha256=c2899ff61beb1d8d6885fa120c69030b0fe8927b4d68ca2c4eaa82ecf2f48931",
    "stimulus": "forge/replay this domain credential/subject or cross-swap sibling receipt"
  },
  "runner_route": "OWNER_REGISTERED::host_lane_readback",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-A5-SEC",
  "workorder_refs": [
    "OBS-B1-A5"
  ]
}
```
- **拒收**：domain `host_lane_readback` missing/typed raw absent => HOLD；實際 error `SERVED_MODEL_MISMATCH_SEC` 正規化 canonical `MODEL_REQUIRED_NOT_SERVED`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-A6-POS｜EFFECT_JOURNAL / POS

- **來源刺激**：source_clause=R15.1:§12; R17v05:S2-17; preconditions=pre-dispatch operation_id, WO/ECP, generation, target resource version and current journal state; input_domain=native/effect_ob; stimulus=Provide owner-issued exact-current pre-dispatch operation_id, WO/ECP, generation, target resource version and current journal state
```json
{
  "atom_or_gwo": "B1-A6",
  "canonical_first_fail": "UNKNOWN_EFFECT_REPLAY",
  "case_type": "POS",
  "cross_sibling_acceptance": false,
  "domain": "EFFECT_JOURNAL",
  "effect_class": "HOST_OPERATIONS",
  "expected_case_verdict": "DOMAIN_POSITIVE_AFTER_REAL_RUN",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "duplicate operation or retry-on-timeout -> UNKNOWN_EFFECT_REPLAY",
    "domain_positive": "at-most-once effect; UNKNOWN_EFFECT reconciled before any next claim",
    "required_domain_fields": [
      "operation_id",
      "preimage",
      "observed_postimage",
      "CAS_fence",
      "unknown_effect"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.effect_journal.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::WO-B1-A6::POS"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L325-L325 excerpt_sha256=28ab533c40f22a98c945671f9d1e5b2352fecdf1d4442936a07d469ee9598ad2",
    "stimulus": "valid exact current Owner-supplied fixture only"
  },
  "runner_route": "OWNER_REGISTERED::effect_journal",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-A6-POS",
  "workorder_refs": [
    "WO-B1-A6"
  ]
}
```
- **拒收**：domain `effect_journal` missing/typed raw absent => HOLD；實際 error `UNKNOWN_EFFECT_REPLAY` 正規化 canonical `UNKNOWN_EFFECT_REPLAY`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-A6-NEG｜EFFECT_JOURNAL / NEG

- **來源刺激**：source_clause=R15.1:§12; R17v05:S2-17; preconditions=pre-dispatch operation_id, WO/ECP, generation, target resource version and current journal state; input_domain=native/effect_ob; stimulus=same operation_id commits twice after queue recovery
```json
{
  "atom_or_gwo": "B1-A6",
  "canonical_first_fail": "UNKNOWN_EFFECT_REPLAY",
  "case_type": "NEG",
  "cross_sibling_acceptance": false,
  "domain": "EFFECT_JOURNAL",
  "effect_class": "HOST_OPERATIONS",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "duplicate operation or retry-on-timeout -> UNKNOWN_EFFECT_REPLAY",
    "domain_positive": "at-most-once effect; UNKNOWN_EFFECT reconciled before any next claim",
    "required_domain_fields": [
      "operation_id",
      "preimage",
      "observed_postimage",
      "CAS_fence",
      "unknown_effect"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.effect_journal.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::WO-B1-A6::NEG"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L326-L326 excerpt_sha256=92296e0538e165fcce1aac0d4c2438cd861c4dc30c13a313a4388c7b44bf670b",
    "stimulus": "same operation_id commits twice after queue recovery"
  },
  "runner_route": "OWNER_REGISTERED::effect_journal",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-A6-NEG",
  "workorder_refs": [
    "WO-B1-A6"
  ]
}
```
- **拒收**：domain `effect_journal` missing/typed raw absent => HOLD；實際 error `DUPLICATE_OR_UNKNOWN_EFFECT` 正規化 canonical `UNKNOWN_EFFECT_REPLAY`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-A6-EDGE｜EFFECT_JOURNAL / EDGE

- **來源刺激**：source_clause=R15.1:§12; R17v05:S2-17; preconditions=pre-dispatch operation_id, WO/ECP, generation, target resource version and current journal state; input_domain=native/effect_ob; stimulus=worker exits after external effect but before ACK arrives
```json
{
  "atom_or_gwo": "B1-A6",
  "canonical_first_fail": "UNKNOWN_EFFECT_REPLAY",
  "case_type": "EDGE",
  "cross_sibling_acceptance": false,
  "domain": "EFFECT_JOURNAL",
  "effect_class": "HOST_OPERATIONS",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "duplicate operation or retry-on-timeout -> UNKNOWN_EFFECT_REPLAY",
    "domain_positive": "at-most-once effect; UNKNOWN_EFFECT reconciled before any next claim",
    "required_domain_fields": [
      "operation_id",
      "preimage",
      "observed_postimage",
      "CAS_fence",
      "unknown_effect"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.effect_journal.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::WO-B1-A6::EDGE"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L327-L327 excerpt_sha256=d522c21e90fd420dd5ace852b22964dc1effa123d3520454dea670840c732863",
    "stimulus": "introduce domain-applicable resource/currentness drift, preserve adjacent independent effects"
  },
  "runner_route": "OWNER_REGISTERED::effect_journal",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-A6-EDGE",
  "workorder_refs": [
    "WO-B1-A6"
  ]
}
```
- **拒收**：domain `effect_journal` missing/typed raw absent => HOLD；實際 error `DUPLICATE_OR_UNKNOWN_EFFECT_EDGE` 正規化 canonical `UNKNOWN_EFFECT_REPLAY`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-A6-SEC｜EFFECT_JOURNAL / SEC

- **來源刺激**：source_clause=R15.1:§12; R17v05:S2-17; preconditions=pre-dispatch operation_id, WO/ECP, generation, target resource version and current journal state; input_domain=native/effect_ob; stimulus=attacker forges NO_EFFECT without native observer witness
```json
{
  "atom_or_gwo": "B1-A6",
  "canonical_first_fail": "UNKNOWN_EFFECT_REPLAY",
  "case_type": "SEC",
  "cross_sibling_acceptance": false,
  "domain": "EFFECT_JOURNAL",
  "effect_class": "HOST_OPERATIONS",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "duplicate operation or retry-on-timeout -> UNKNOWN_EFFECT_REPLAY",
    "domain_positive": "at-most-once effect; UNKNOWN_EFFECT reconciled before any next claim",
    "required_domain_fields": [
      "operation_id",
      "preimage",
      "observed_postimage",
      "CAS_fence",
      "unknown_effect"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.effect_journal.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::WO-B1-A6::SEC"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L328-L328 excerpt_sha256=dc9b0c832a615e3b815ca03e6a81a4c8cb2f6de682b2c50dda97494640b37199",
    "stimulus": "forge/replay this domain credential/subject or cross-swap sibling receipt"
  },
  "runner_route": "OWNER_REGISTERED::effect_journal",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-A6-SEC",
  "workorder_refs": [
    "WO-B1-A6"
  ]
}
```
- **拒收**：domain `effect_journal` missing/typed raw absent => HOLD；實際 error `DUPLICATE_OR_UNKNOWN_EFFECT_SEC` 正規化 canonical `UNKNOWN_EFFECT_REPLAY`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-A7-POS｜RAW_EVIDENCE / POS

- **來源刺激**：source_clause=PIPD04:§10; PIPD07:§06; preconditions=exact source/PI/PD/WO/ECP hashes, command argv digest, native observer witness, stdout/stderr/exit; input_domain=evidence/immut; stimulus=Provide owner-issued exact-current exact source/PI/PD/WO/ECP hashes, command argv digest, native observer witness, stdout/stderr/exit
```json
{
  "atom_or_gwo": "B1-A7",
  "canonical_first_fail": "RAW_OR_CHECKER_MISMATCH",
  "case_type": "POS",
  "cross_sibling_acceptance": false,
  "domain": "RAW_EVIDENCE",
  "effect_class": "READ_ONLY_PROBE",
  "expected_case_verdict": "DOMAIN_POSITIVE_AFTER_REAL_RUN",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "self-attested or mismatched witness -> RAW_OR_CHECKER_MISMATCH",
    "domain_positive": "distinct principal checker receipt matches same candidate and non-empty RAW",
    "required_domain_fields": [
      "raw_receipt",
      "subject_sha",
      "candidate_sha",
      "checker_principal",
      "witness"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.immutable_evidence.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::OBS-B1-A7::POS"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L329-L329 excerpt_sha256=1e4f2b2393ddb72024d480bab753432b072faa2215d0fe0399a7790e025722cc",
    "stimulus": "valid exact current Owner-supplied fixture only"
  },
  "runner_route": "OWNER_REGISTERED::immutable_evidence",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-A7-POS",
  "workorder_refs": [
    "OBS-B1-A7"
  ]
}
```
- **拒收**：domain `immutable_evidence` missing/typed raw absent => HOLD；實際 error `RAW_OR_CHECKER_MISMATCH` 正規化 canonical `RAW_OR_CHECKER_MISMATCH`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-A7-NEG｜RAW_EVIDENCE / NEG

- **來源刺激**：source_clause=PIPD04:§10; PIPD07:§06; preconditions=exact source/PI/PD/WO/ECP hashes, command argv digest, native observer witness, stdout/stderr/exit; input_domain=evidence/immut; stimulus=copy an old successful log with a different WO hash
```json
{
  "atom_or_gwo": "B1-A7",
  "canonical_first_fail": "RAW_OR_CHECKER_MISMATCH",
  "case_type": "NEG",
  "cross_sibling_acceptance": false,
  "domain": "RAW_EVIDENCE",
  "effect_class": "READ_ONLY_PROBE",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "self-attested or mismatched witness -> RAW_OR_CHECKER_MISMATCH",
    "domain_positive": "distinct principal checker receipt matches same candidate and non-empty RAW",
    "required_domain_fields": [
      "raw_receipt",
      "subject_sha",
      "candidate_sha",
      "checker_principal",
      "witness"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.immutable_evidence.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::OBS-B1-A7::NEG"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L330-L330 excerpt_sha256=9a79fd482563fa1e1e3072e019dcf9084b3fd13628d43ed809325fe2d5a9d5d9",
    "stimulus": "copy an old successful log with a different WO hash"
  },
  "runner_route": "OWNER_REGISTERED::immutable_evidence",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-A7-NEG",
  "workorder_refs": [
    "OBS-B1-A7"
  ]
}
```
- **拒收**：domain `immutable_evidence` missing/typed raw absent => HOLD；實際 error `RAW_SUBJECT_OR_WITNESS_MISSING` 正規化 canonical `RAW_OR_CHECKER_MISMATCH`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-A7-EDGE｜RAW_EVIDENCE / EDGE

- **來源刺激**：source_clause=PIPD04:§10; PIPD07:§06; preconditions=exact source/PI/PD/WO/ECP hashes, command argv digest, native observer witness, stdout/stderr/exit; input_domain=evidence/immut; stimulus=stdout archived but stderr or exit missing
```json
{
  "atom_or_gwo": "B1-A7",
  "canonical_first_fail": "RAW_OR_CHECKER_MISMATCH",
  "case_type": "EDGE",
  "cross_sibling_acceptance": false,
  "domain": "RAW_EVIDENCE",
  "effect_class": "READ_ONLY_PROBE",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "self-attested or mismatched witness -> RAW_OR_CHECKER_MISMATCH",
    "domain_positive": "distinct principal checker receipt matches same candidate and non-empty RAW",
    "required_domain_fields": [
      "raw_receipt",
      "subject_sha",
      "candidate_sha",
      "checker_principal",
      "witness"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.immutable_evidence.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::OBS-B1-A7::EDGE"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L331-L331 excerpt_sha256=88c0fbc83f92d9823b0252f3b6ec8f193dfbc971c116f2f18c80f6573f61cc5d",
    "stimulus": "introduce domain-applicable resource/currentness drift, preserve adjacent independent effects"
  },
  "runner_route": "OWNER_REGISTERED::immutable_evidence",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-A7-EDGE",
  "workorder_refs": [
    "OBS-B1-A7"
  ]
}
```
- **拒收**：domain `immutable_evidence` missing/typed raw absent => HOLD；實際 error `RAW_SUBJECT_OR_WITNESS_MISSING_EDGE` 正規化 canonical `RAW_OR_CHECKER_MISMATCH`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-A7-SEC｜RAW_EVIDENCE / SEC

- **來源刺激**：source_clause=PIPD04:§10; PIPD07:§06; preconditions=exact source/PI/PD/WO/ECP hashes, command argv digest, native observer witness, stdout/stderr/exit; input_domain=evidence/immut; stimulus=checker swaps redacted output after hash sealing
```json
{
  "atom_or_gwo": "B1-A7",
  "canonical_first_fail": "RAW_OR_CHECKER_MISMATCH",
  "case_type": "SEC",
  "cross_sibling_acceptance": false,
  "domain": "RAW_EVIDENCE",
  "effect_class": "READ_ONLY_PROBE",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "self-attested or mismatched witness -> RAW_OR_CHECKER_MISMATCH",
    "domain_positive": "distinct principal checker receipt matches same candidate and non-empty RAW",
    "required_domain_fields": [
      "raw_receipt",
      "subject_sha",
      "candidate_sha",
      "checker_principal",
      "witness"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.immutable_evidence.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::OBS-B1-A7::SEC"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L332-L332 excerpt_sha256=cc7a3e6f4d8688a9d1b6d05460c1011c50444f69af51e3238b9593c7c289cb6e",
    "stimulus": "forge/replay this domain credential/subject or cross-swap sibling receipt"
  },
  "runner_route": "OWNER_REGISTERED::immutable_evidence",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-A7-SEC",
  "workorder_refs": [
    "OBS-B1-A7"
  ]
}
```
- **拒收**：domain `immutable_evidence` missing/typed raw absent => HOLD；實際 error `RAW_SUBJECT_OR_WITNESS_MISSING_SEC` 正規化 canonical `RAW_OR_CHECKER_MISMATCH`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-A8-POS｜NATIVE_HOTPATH / POS

- **來源刺激**：source_clause=R15.1:L276(W01), R15.1:L277(W02); preconditions=measured native firstfail, actual loaded hotpath, existing file preimages and protected Dirty/Untracked; input_domain=affected; stimulus=Provide owner-issued exact-current measured native firstfail, actual loaded hotpath, existing file preimages and protected Dirty/Untracked
```json
{
  "atom_or_gwo": "B1-A8",
  "canonical_first_fail": "HOTPATH_UNRESOLVED",
  "case_type": "POS",
  "cross_sibling_acceptance": false,
  "domain": "NATIVE_HOTPATH",
  "effect_class": "REPOSITORY_WRITE",
  "expected_case_verdict": "DOMAIN_POSITIVE_AFTER_REAL_RUN",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "unbounded writes or missing red reproducer -> HOTPATH_UNRESOLVED",
    "domain_positive": "exact loaded callsite identified and scoped regression independent",
    "required_domain_fields": [
      "root",
      "head",
      "preimage",
      "diff",
      "writeset",
      "red_green",
      "postimage"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.repo_diff.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::WO-B1-A8::POS"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L333-L333 excerpt_sha256=293bb59d8ff0583337a4542a82bf011919a621dcbc4ff48600a57a23d86053ca",
    "stimulus": "valid exact current Owner-supplied fixture only"
  },
  "runner_route": "OWNER_REGISTERED::repo_diff",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-A8-POS",
  "workorder_refs": [
    "WO-B1-A8"
  ]
}
```
- **拒收**：domain `repo_diff` missing/typed raw absent => HOLD；實際 error `HOTPATH_UNRESOLVED` 正規化 canonical `HOTPATH_UNRESOLVED`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-A8-NEG｜NATIVE_HOTPATH / NEG

- **來源刺激**：source_clause=R15.1:L276(W01), R15.1:L277(W02); preconditions=measured native firstfail, actual loaded hotpath, existing file preimages and protected Dirty/Untracked; input_domain=affected; stimulus=historic runner.py patch applied without confirming it is live hotpath
```json
{
  "atom_or_gwo": "B1-A8",
  "canonical_first_fail": "HOTPATH_UNRESOLVED",
  "case_type": "NEG",
  "cross_sibling_acceptance": false,
  "domain": "NATIVE_HOTPATH",
  "effect_class": "REPOSITORY_WRITE",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "unbounded writes or missing red reproducer -> HOTPATH_UNRESOLVED",
    "domain_positive": "exact loaded callsite identified and scoped regression independent",
    "required_domain_fields": [
      "root",
      "head",
      "preimage",
      "diff",
      "writeset",
      "red_green",
      "postimage"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.repo_diff.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::WO-B1-A8::NEG"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L334-L334 excerpt_sha256=e5f232374089d0c05149316a41ccb9e3a9f49b765e7b7d4215bdc84c5d1b1c96",
    "stimulus": "historic runner.py patch applied without confirming it is live hotpath"
  },
  "runner_route": "OWNER_REGISTERED::repo_diff",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-A8-NEG",
  "workorder_refs": [
    "WO-B1-A8"
  ]
}
```
- **拒收**：domain `repo_diff` missing/typed raw absent => HOLD；實際 error `UNMEASURED_REPAIR_OR_SCOPE_ESCAPE` 正規化 canonical `HOTPATH_UNRESOLVED`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-A8-EDGE｜NATIVE_HOTPATH / EDGE

- **來源刺激**：source_clause=R15.1:L276(W01), R15.1:L277(W02); preconditions=measured native firstfail, actual loaded hotpath, existing file preimages and protected Dirty/Untracked; input_domain=affected; stimulus=unrelated user changes appear during patch
```json
{
  "atom_or_gwo": "B1-A8",
  "canonical_first_fail": "HOTPATH_UNRESOLVED",
  "case_type": "EDGE",
  "cross_sibling_acceptance": false,
  "domain": "NATIVE_HOTPATH",
  "effect_class": "REPOSITORY_WRITE",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "unbounded writes or missing red reproducer -> HOTPATH_UNRESOLVED",
    "domain_positive": "exact loaded callsite identified and scoped regression independent",
    "required_domain_fields": [
      "root",
      "head",
      "preimage",
      "diff",
      "writeset",
      "red_green",
      "postimage"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.repo_diff.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::WO-B1-A8::EDGE"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L335-L335 excerpt_sha256=16a8fc90a4910a3aadf6148dc0ad506d25f161ca77d41f2d582baaf1cede2658",
    "stimulus": "introduce domain-applicable resource/currentness drift, preserve adjacent independent effects"
  },
  "runner_route": "OWNER_REGISTERED::repo_diff",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-A8-EDGE",
  "workorder_refs": [
    "WO-B1-A8"
  ]
}
```
- **拒收**：domain `repo_diff` missing/typed raw absent => HOLD；實際 error `UNMEASURED_REPAIR_OR_SCOPE_ESCAPE_EDGE` 正規化 canonical `HOTPATH_UNRESOLVED`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-A8-SEC｜NATIVE_HOTPATH / SEC

- **來源刺激**：source_clause=R15.1:L276(W01), R15.1:L277(W02); preconditions=measured native firstfail, actual loaded hotpath, existing file preimages and protected Dirty/Untracked; input_domain=affected; stimulus=Windows junction redirects approved textual file path
```json
{
  "atom_or_gwo": "B1-A8",
  "canonical_first_fail": "HOTPATH_UNRESOLVED",
  "case_type": "SEC",
  "cross_sibling_acceptance": false,
  "domain": "NATIVE_HOTPATH",
  "effect_class": "REPOSITORY_WRITE",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "unbounded writes or missing red reproducer -> HOTPATH_UNRESOLVED",
    "domain_positive": "exact loaded callsite identified and scoped regression independent",
    "required_domain_fields": [
      "root",
      "head",
      "preimage",
      "diff",
      "writeset",
      "red_green",
      "postimage"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.repo_diff.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::WO-B1-A8::SEC"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L336-L336 excerpt_sha256=ddd2ea6962c4020c5bf83afccaf39afc024dc5458fab6bf7cf8509a40daf3e1e",
    "stimulus": "forge/replay this domain credential/subject or cross-swap sibling receipt"
  },
  "runner_route": "OWNER_REGISTERED::repo_diff",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-A8-SEC",
  "workorder_refs": [
    "WO-B1-A8"
  ]
}
```
- **拒收**：domain `repo_diff` missing/typed raw absent => HOLD；實際 error `UNMEASURED_REPAIR_OR_SCOPE_ESCAPE_SEC` 正規化 canonical `HOTPATH_UNRESOLVED`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-A9-POS｜NATIVE_CONTINUATION / POS

- **來源刺激**：source_clause=R17v05:S2-14~17; preconditions=Codex repair grant, native issuer/queue identity, successor origin, revocation inventory; input_domain=native/continuation，su; stimulus=Provide owner-issued exact-current Codex repair grant, native issuer/queue identity, successor origin, revocation inventory
```json
{
  "atom_or_gwo": "B1-A9",
  "canonical_first_fail": "EXTERNAL_TRIGGER_STILL_REQUIRED",
  "case_type": "POS",
  "cross_sibling_acceptance": false,
  "domain": "NATIVE_CONTINUATION",
  "effect_class": "HOST_OPERATIONS",
  "expected_case_verdict": "DOMAIN_POSITIVE_AFTER_REAL_RUN",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "external actor still triggering -> EXTERNAL_TRIGGER_STILL_REQUIRED",
    "domain_positive": "native successor advances after external revoke with new session and no external trigger",
    "required_domain_fields": [
      "external_revoke",
      "post_turn_source",
      "issued_wo",
      "native_claim",
      "session_exit"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.native_continuation.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::WO-B1-A9::POS"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L337-L337 excerpt_sha256=aa0899cfc64bb7f43da4e1c3878a111c3df558ff831b2b378493b4c001860de8",
    "stimulus": "valid exact current Owner-supplied fixture only"
  },
  "runner_route": "OWNER_REGISTERED::native_continuation",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-A9-POS",
  "workorder_refs": [
    "WO-B1-A9"
  ]
}
```
- **拒收**：domain `native_continuation` missing/typed raw absent => HOLD；實際 error `EXTERNAL_TRIGGER_STILL_REQUIRED` 正規化 canonical `EXTERNAL_TRIGGER_STILL_REQUIRED`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-A9-NEG｜NATIVE_CONTINUATION / NEG

- **來源刺激**：source_clause=R17v05:S2-14~17; preconditions=Codex repair grant, native issuer/queue identity, successor origin, revocation inventory; input_domain=native/continuation，su; stimulus=Codex scripted API posts next WO after supposed exit
```json
{
  "atom_or_gwo": "B1-A9",
  "canonical_first_fail": "EXTERNAL_TRIGGER_STILL_REQUIRED",
  "case_type": "NEG",
  "cross_sibling_acceptance": false,
  "domain": "NATIVE_CONTINUATION",
  "effect_class": "HOST_OPERATIONS",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "external actor still triggering -> EXTERNAL_TRIGGER_STILL_REQUIRED",
    "domain_positive": "native successor advances after external revoke with new session and no external trigger",
    "required_domain_fields": [
      "external_revoke",
      "post_turn_source",
      "issued_wo",
      "native_claim",
      "session_exit"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.native_continuation.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::WO-B1-A9::NEG"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L338-L338 excerpt_sha256=62cb6074156632729010f65b0738ce5f9d6ea7440c6715a83765eefe45dfb8b7",
    "stimulus": "Codex scripted API posts next WO after supposed exit"
  },
  "runner_route": "OWNER_REGISTERED::native_continuation",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-A9-NEG",
  "workorder_refs": [
    "WO-B1-A9"
  ]
}
```
- **拒收**：domain `native_continuation` missing/typed raw absent => HOLD；實際 error `EXTERNAL_REENTRY_OR_NONNATIVE_SUCCESSOR` 正規化 canonical `EXTERNAL_TRIGGER_STILL_REQUIRED`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-A9-EDGE｜NATIVE_CONTINUATION / EDGE

- **來源刺激**：source_clause=R17v05:S2-14~17; preconditions=Codex repair grant, native issuer/queue identity, successor origin, revocation inventory; input_domain=native/continuation，su; stimulus=queued successor reclaims expired external lease instead of new native issuance
```json
{
  "atom_or_gwo": "B1-A9",
  "canonical_first_fail": "EXTERNAL_TRIGGER_STILL_REQUIRED",
  "case_type": "EDGE",
  "cross_sibling_acceptance": false,
  "domain": "NATIVE_CONTINUATION",
  "effect_class": "HOST_OPERATIONS",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "external actor still triggering -> EXTERNAL_TRIGGER_STILL_REQUIRED",
    "domain_positive": "native successor advances after external revoke with new session and no external trigger",
    "required_domain_fields": [
      "external_revoke",
      "post_turn_source",
      "issued_wo",
      "native_claim",
      "session_exit"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.native_continuation.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::WO-B1-A9::EDGE"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L339-L339 excerpt_sha256=2fab084daa6e750a8017f86a579de887806697602aec79482fa16712a085d8d7",
    "stimulus": "introduce domain-applicable resource/currentness drift, preserve adjacent independent effects"
  },
  "runner_route": "OWNER_REGISTERED::native_continuation",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-A9-EDGE",
  "workorder_refs": [
    "WO-B1-A9"
  ]
}
```
- **拒收**：domain `native_continuation` missing/typed raw absent => HOLD；實際 error `EXTERNAL_REENTRY_OR_NONNATIVE_SUCCESSOR_EDGE` 正規化 canonical `EXTERNAL_TRIGGER_STILL_REQUIRED`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-A9-SEC｜NATIVE_CONTINUATION / SEC

- **來源刺激**：source_clause=R17v05:S2-14~17; preconditions=Codex repair grant, native issuer/queue identity, successor origin, revocation inventory; input_domain=native/continuation，su; stimulus=external grant still can create WO despite EXIT flag
```json
{
  "atom_or_gwo": "B1-A9",
  "canonical_first_fail": "EXTERNAL_TRIGGER_STILL_REQUIRED",
  "case_type": "SEC",
  "cross_sibling_acceptance": false,
  "domain": "NATIVE_CONTINUATION",
  "effect_class": "HOST_OPERATIONS",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "external actor still triggering -> EXTERNAL_TRIGGER_STILL_REQUIRED",
    "domain_positive": "native successor advances after external revoke with new session and no external trigger",
    "required_domain_fields": [
      "external_revoke",
      "post_turn_source",
      "issued_wo",
      "native_claim",
      "session_exit"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.native_continuation.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::WO-B1-A9::SEC"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L340-L340 excerpt_sha256=8892d015019ceae898d44f291e157dea3b4caed9d6f5d7db430a56933e5419ad",
    "stimulus": "forge/replay this domain credential/subject or cross-swap sibling receipt"
  },
  "runner_route": "OWNER_REGISTERED::native_continuation",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-A9-SEC",
  "workorder_refs": [
    "WO-B1-A9"
  ]
}
```
- **拒收**：domain `native_continuation` missing/typed raw absent => HOLD；實際 error `EXTERNAL_REENTRY_OR_NONNATIVE_SUCCESSOR_SEC` 正規化 canonical `EXTERNAL_TRIGGER_STILL_REQUIRED`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-B1-POS｜SOURCE_ATOMS / POS

- **來源刺激**：source_clause=R15.1:L280(W05); preconditions=user request, owner-signed FUO, 3 missing superior sources and R15 exact clauses; input_domain=pipd/pi，subject_ref+sha 必連到 P; stimulus=Provide owner-issued exact-current user request, owner-signed FUO, 3 missing superior sources and R15 exact clauses
```json
{
  "atom_or_gwo": "B1-B1",
  "canonical_first_fail": "PI_SOURCE_OR_ORACLE_UNBOUND",
  "case_type": "POS",
  "cross_sibling_acceptance": false,
  "domain": "SOURCE_ATOMS",
  "effect_class": "READ_ONLY_PROBE",
  "expected_case_verdict": "DOMAIN_POSITIVE_AFTER_REAL_RUN",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "missing oracle or fabricated source -> PI_SOURCE_OR_ORACLE_UNBOUND",
    "domain_positive": "one-to-one source clause/owner/oracle joins; missing clause is HOLD",
    "required_domain_fields": [
      "clause_sha",
      "atom_id",
      "source_owner",
      "domain_oracle",
      "trace_edges"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.source_oracle.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::OBS-B1-B1::POS"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L341-L341 excerpt_sha256=161d868792e2edf3206e74cc3839c6e629af9f5ce780b0a6a915f51789f38d01",
    "stimulus": "valid exact current Owner-supplied fixture only"
  },
  "runner_route": "OWNER_REGISTERED::source_oracle",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-B1-POS",
  "workorder_refs": [
    "OBS-B1-B1"
  ]
}
```
- **拒收**：domain `source_oracle` missing/typed raw absent => HOLD；實際 error `PI_SOURCE_OR_ORACLE_UNBOUND` 正規化 canonical `PI_SOURCE_OR_ORACLE_UNBOUND`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-B1-NEG｜SOURCE_ATOMS / NEG

- **來源刺激**：source_clause=R15.1:L280(W05); preconditions=user request, owner-signed FUO, 3 missing superior sources and R15 exact clauses; input_domain=pipd/pi，subject_ref+sha 必連到 P; stimulus=one A2 atomic clause stands in for all A1..C9 clauses
```json
{
  "atom_or_gwo": "B1-B1",
  "canonical_first_fail": "PI_SOURCE_OR_ORACLE_UNBOUND",
  "case_type": "NEG",
  "cross_sibling_acceptance": false,
  "domain": "SOURCE_ATOMS",
  "effect_class": "READ_ONLY_PROBE",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "missing oracle or fabricated source -> PI_SOURCE_OR_ORACLE_UNBOUND",
    "domain_positive": "one-to-one source clause/owner/oracle joins; missing clause is HOLD",
    "required_domain_fields": [
      "clause_sha",
      "atom_id",
      "source_owner",
      "domain_oracle",
      "trace_edges"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.source_oracle.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::OBS-B1-B1::NEG"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L342-L342 excerpt_sha256=17c4b9fd6b20cf2d4ad7b375d1db22dd455c50a5482dd8ce7062b22565c72cda",
    "stimulus": "one A2 atomic clause stands in for all A1..C9 clauses"
  },
  "runner_route": "OWNER_REGISTERED::source_oracle",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-B1-NEG",
  "workorder_refs": [
    "OBS-B1-B1"
  ]
}
```
- **拒收**：domain `source_oracle` missing/typed raw absent => HOLD；實際 error `UNKNOWN_ATOM_SOURCE` 正規化 canonical `PI_SOURCE_OR_ORACLE_UNBOUND`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-B1-EDGE｜SOURCE_ATOMS / EDGE

- **來源刺激**：source_clause=R15.1:L280(W05); preconditions=user request, owner-signed FUO, 3 missing superior sources and R15 exact clauses; input_domain=pipd/pi，subject_ref+sha 必連到 P; stimulus=new signed R00 verdict changes only subset, invalidates dependent atoms
```json
{
  "atom_or_gwo": "B1-B1",
  "canonical_first_fail": "PI_SOURCE_OR_ORACLE_UNBOUND",
  "case_type": "EDGE",
  "cross_sibling_acceptance": false,
  "domain": "SOURCE_ATOMS",
  "effect_class": "READ_ONLY_PROBE",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "missing oracle or fabricated source -> PI_SOURCE_OR_ORACLE_UNBOUND",
    "domain_positive": "one-to-one source clause/owner/oracle joins; missing clause is HOLD",
    "required_domain_fields": [
      "clause_sha",
      "atom_id",
      "source_owner",
      "domain_oracle",
      "trace_edges"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.source_oracle.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::OBS-B1-B1::EDGE"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L343-L343 excerpt_sha256=852824ec8049abc5662aedbd845b18450b1cfb27b84290a2503f3e8316dd643d",
    "stimulus": "introduce domain-applicable resource/currentness drift, preserve adjacent independent effects"
  },
  "runner_route": "OWNER_REGISTERED::source_oracle",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-B1-EDGE",
  "workorder_refs": [
    "OBS-B1-B1"
  ]
}
```
- **拒收**：domain `source_oracle` missing/typed raw absent => HOLD；實際 error `UNKNOWN_ATOM_SOURCE_EDGE` 正規化 canonical `PI_SOURCE_OR_ORACLE_UNBOUND`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-B1-SEC｜SOURCE_ATOMS / SEC

- **來源刺激**：source_clause=R15.1:L280(W05); preconditions=user request, owner-signed FUO, 3 missing superior sources and R15 exact clauses; input_domain=pipd/pi，subject_ref+sha 必連到 P; stimulus=external donor instruction becomes upstream authority
```json
{
  "atom_or_gwo": "B1-B1",
  "canonical_first_fail": "PI_SOURCE_OR_ORACLE_UNBOUND",
  "case_type": "SEC",
  "cross_sibling_acceptance": false,
  "domain": "SOURCE_ATOMS",
  "effect_class": "READ_ONLY_PROBE",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "missing oracle or fabricated source -> PI_SOURCE_OR_ORACLE_UNBOUND",
    "domain_positive": "one-to-one source clause/owner/oracle joins; missing clause is HOLD",
    "required_domain_fields": [
      "clause_sha",
      "atom_id",
      "source_owner",
      "domain_oracle",
      "trace_edges"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.source_oracle.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::OBS-B1-B1::SEC"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L344-L344 excerpt_sha256=727cbaf1bf2c1866a1ff47b86d6f091e38618915f9418078a56c30493367aa3a",
    "stimulus": "forge/replay this domain credential/subject or cross-swap sibling receipt"
  },
  "runner_route": "OWNER_REGISTERED::source_oracle",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-B1-SEC",
  "workorder_refs": [
    "OBS-B1-B1"
  ]
}
```
- **拒收**：domain `source_oracle` missing/typed raw absent => HOLD；實際 error `UNKNOWN_ATOM_SOURCE_SEC` 正規化 canonical `PI_SOURCE_OR_ORACLE_UNBOUND`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-B2-POS｜REPO_CONTEXT / POS

- **來源刺激**：source_clause=PIPD03:PD-02/PD-04; preconditions=Fabric/HGK/SBL separate root, HEAD, dirty and untracked inventory, scope and actual owner ACL; input_domain=repo/late_binding，; stimulus=Provide owner-issued exact-current Fabric/HGK/SBL separate root, HEAD, dirty and untracked inventory, scope and actual owner ACL
```json
{
  "atom_or_gwo": "B1-B2",
  "canonical_first_fail": "REPO_CONTEXT_NOT_FRESH",
  "case_type": "POS",
  "cross_sibling_acceptance": false,
  "domain": "REPO_CONTEXT",
  "effect_class": "READ_ONLY_PROBE",
  "expected_case_verdict": "DOMAIN_POSITIVE_AFTER_REAL_RUN",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "stale/escaping context -> REPO_CONTEXT_NOT_FRESH",
    "domain_positive": "P4 PD only with actual repo root, HEAD and affected-only allowed write scope",
    "required_domain_fields": [
      "realpath",
      "head",
      "index",
      "untracked",
      "writable_scope",
      "currentness"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.repo_context_probe.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::OBS-B1-B2::POS"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L345-L345 excerpt_sha256=57f60d096725411f172bf6545f32d8d47cf2c279b703a5282515e4ac563c745a",
    "stimulus": "valid exact current Owner-supplied fixture only"
  },
  "runner_route": "OWNER_REGISTERED::repo_context_probe",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-B2-POS",
  "workorder_refs": [
    "OBS-B1-B2"
  ]
}
```
- **拒收**：domain `repo_context_probe` missing/typed raw absent => HOLD；實際 error `REPO_CONTEXT_NOT_FRESH` 正規化 canonical `REPO_CONTEXT_NOT_FRESH`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-B2-NEG｜REPO_CONTEXT / NEG

- **來源刺激**：source_clause=PIPD03:PD-02/PD-04; preconditions=Fabric/HGK/SBL separate root, HEAD, dirty and untracked inventory, scope and actual owner ACL; input_domain=repo/late_binding，; stimulus=SBL bridge dirty=bool used as full untracked proof
```json
{
  "atom_or_gwo": "B1-B2",
  "canonical_first_fail": "REPO_CONTEXT_NOT_FRESH",
  "case_type": "NEG",
  "cross_sibling_acceptance": false,
  "domain": "REPO_CONTEXT",
  "effect_class": "READ_ONLY_PROBE",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "stale/escaping context -> REPO_CONTEXT_NOT_FRESH",
    "domain_positive": "P4 PD only with actual repo root, HEAD and affected-only allowed write scope",
    "required_domain_fields": [
      "realpath",
      "head",
      "index",
      "untracked",
      "writable_scope",
      "currentness"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.repo_context_probe.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::OBS-B1-B2::NEG"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L346-L346 excerpt_sha256=f9263a7b1f3673b197c89b8f06a8ffd7966d835a1615bd79fd187c26ba6e70d3",
    "stimulus": "SBL bridge dirty=bool used as full untracked proof"
  },
  "runner_route": "OWNER_REGISTERED::repo_context_probe",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-B2-NEG",
  "workorder_refs": [
    "OBS-B1-B2"
  ]
}
```
- **拒收**：domain `repo_context_probe` missing/typed raw absent => HOLD；實際 error `PD_CONTEXT_STALE_OR_PATH_ESCAPE` 正規化 canonical `REPO_CONTEXT_NOT_FRESH`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-B2-EDGE｜REPO_CONTEXT / EDGE

- **來源刺激**：source_clause=PIPD03:PD-02/PD-04; preconditions=Fabric/HGK/SBL separate root, HEAD, dirty and untracked inventory, scope and actual owner ACL; input_domain=repo/late_binding，; stimulus=HEAD advances after PD but before native permit
```json
{
  "atom_or_gwo": "B1-B2",
  "canonical_first_fail": "REPO_CONTEXT_NOT_FRESH",
  "case_type": "EDGE",
  "cross_sibling_acceptance": false,
  "domain": "REPO_CONTEXT",
  "effect_class": "READ_ONLY_PROBE",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "stale/escaping context -> REPO_CONTEXT_NOT_FRESH",
    "domain_positive": "P4 PD only with actual repo root, HEAD and affected-only allowed write scope",
    "required_domain_fields": [
      "realpath",
      "head",
      "index",
      "untracked",
      "writable_scope",
      "currentness"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.repo_context_probe.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::OBS-B1-B2::EDGE"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L347-L347 excerpt_sha256=0e3e4b7ed8d5dfd74da591fc89adc8a9ef3e3d5db10bb73ac2488c94519123fc",
    "stimulus": "introduce domain-applicable resource/currentness drift, preserve adjacent independent effects"
  },
  "runner_route": "OWNER_REGISTERED::repo_context_probe",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-B2-EDGE",
  "workorder_refs": [
    "OBS-B1-B2"
  ]
}
```
- **拒收**：domain `repo_context_probe` missing/typed raw absent => HOLD；實際 error `PD_CONTEXT_STALE_OR_PATH_ESCAPE_EDGE` 正規化 canonical `REPO_CONTEXT_NOT_FRESH`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-B2-SEC｜REPO_CONTEXT / SEC

- **來源刺激**：source_clause=PIPD03:PD-02/PD-04; preconditions=Fabric/HGK/SBL separate root, HEAD, dirty and untracked inventory, scope and actual owner ACL; input_domain=repo/late_binding，; stimulus=symlink/reparse escapes repo owner root
```json
{
  "atom_or_gwo": "B1-B2",
  "canonical_first_fail": "REPO_CONTEXT_NOT_FRESH",
  "case_type": "SEC",
  "cross_sibling_acceptance": false,
  "domain": "REPO_CONTEXT",
  "effect_class": "READ_ONLY_PROBE",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "stale/escaping context -> REPO_CONTEXT_NOT_FRESH",
    "domain_positive": "P4 PD only with actual repo root, HEAD and affected-only allowed write scope",
    "required_domain_fields": [
      "realpath",
      "head",
      "index",
      "untracked",
      "writable_scope",
      "currentness"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.repo_context_probe.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::OBS-B1-B2::SEC"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L348-L348 excerpt_sha256=7f4d58ee284f6cf0dc825689a22a45717d25f556be21fb738d748113d70f1d2e",
    "stimulus": "forge/replay this domain credential/subject or cross-swap sibling receipt"
  },
  "runner_route": "OWNER_REGISTERED::repo_context_probe",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-B2-SEC",
  "workorder_refs": [
    "OBS-B1-B2"
  ]
}
```
- **拒收**：domain `repo_context_probe` missing/typed raw absent => HOLD；實際 error `PD_CONTEXT_STALE_OR_PATH_ESCAPE_SEC` 正規化 canonical `REPO_CONTEXT_NOT_FRESH`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-B3-POS｜SBL_TO_NATIVE / POS

- **來源刺激**：source_clause=R15.1:L278(W03), R15.1:L279(W04); preconditions=WorkOrderCandidate subject/PI/PD/ECP hashes and current native receiver ABI; input_domain=sbl/adapter，subject_ref+sha 必連到 PI; stimulus=Provide owner-issued exact-current WorkOrderCandidate subject/PI/PD/ECP hashes and current native receiver ABI
```json
{
  "atom_or_gwo": "B1-B3",
  "canonical_first_fail": "SECOND_ISSUER_OR_MIXED_EFFECT",
  "case_type": "POS",
  "cross_sibling_acceptance": false,
  "domain": "SBL_TO_NATIVE",
  "effect_class": "SPLIT_REQUIRED",
  "expected_case_verdict": "DOMAIN_POSITIVE_AFTER_REAL_RUN",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "second issuer or shared receipt -> SECOND_ISSUER_OR_MIXED_EFFECT",
    "domain_positive": "DEV/OPS different WOs, separate source diff and real native ACK",
    "required_domain_fields": [
      "sbl_entry",
      "candidate",
      "dev_diff",
      "ops_handoff",
      "native_receiver_ack"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.bridge_handoff.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::WO-B1-B3-DEV::POS",
      "OP::WO-B1-B3-OPS::POS"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L349-L349 excerpt_sha256=f0a91e478e5fac77f5641d3ffc557031c39348650cebe61d0bca72eb547afc33",
    "stimulus": "valid exact current Owner-supplied fixture only"
  },
  "runner_route": "OWNER_REGISTERED::bridge_handoff",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": false,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-B3-POS",
  "workorder_refs": [
    "WO-B1-B3-DEV",
    "WO-B1-B3-OPS"
  ]
}
```
- **拒收**：domain `bridge_handoff` missing/typed raw absent => HOLD；實際 error `SECOND_ISSUER_OR_MIXED_EFFECT` 正規化 canonical `SECOND_ISSUER_OR_MIXED_EFFECT`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-B3-NEG｜SBL_TO_NATIVE / NEG

- **來源刺激**：source_clause=R15.1:L278(W03), R15.1:L279(W04); preconditions=WorkOrderCandidate subject/PI/PD/ECP hashes and current native receiver ABI; input_domain=sbl/adapter，subject_ref+sha 必連到 PI; stimulus=client calls mock receiver and treats contract map as production
```json
{
  "atom_or_gwo": "B1-B3",
  "canonical_first_fail": "SECOND_ISSUER_OR_MIXED_EFFECT",
  "case_type": "NEG",
  "cross_sibling_acceptance": false,
  "domain": "SBL_TO_NATIVE",
  "effect_class": "SPLIT_REQUIRED",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "second issuer or shared receipt -> SECOND_ISSUER_OR_MIXED_EFFECT",
    "domain_positive": "DEV/OPS different WOs, separate source diff and real native ACK",
    "required_domain_fields": [
      "sbl_entry",
      "candidate",
      "dev_diff",
      "ops_handoff",
      "native_receiver_ack"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.bridge_handoff.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::WO-B1-B3-DEV::NEG",
      "OP::WO-B1-B3-OPS::NEG"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L350-L350 excerpt_sha256=3a9d565c821642306c70963f9e9447b4ac08df86f1dba564e04506a6408cb80e",
    "stimulus": "client calls mock receiver and treats contract map as production"
  },
  "runner_route": "OWNER_REGISTERED::bridge_handoff",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": false,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-B3-NEG",
  "workorder_refs": [
    "WO-B1-B3-DEV",
    "WO-B1-B3-OPS"
  ]
}
```
- **拒收**：domain `bridge_handoff` missing/typed raw absent => HOLD；實際 error `HANDOFF_ABI_OR_MOCK_ACK` 正規化 canonical `SECOND_ISSUER_OR_MIXED_EFFECT`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-B3-EDGE｜SBL_TO_NATIVE / EDGE

- **來源刺激**：source_clause=R15.1:L278(W03), R15.1:L279(W04); preconditions=WorkOrderCandidate subject/PI/PD/ECP hashes and current native receiver ABI; input_domain=sbl/adapter，subject_ref+sha 必連到 PI; stimulus=receiver schema changes between adapter build and actual load
```json
{
  "atom_or_gwo": "B1-B3",
  "canonical_first_fail": "SECOND_ISSUER_OR_MIXED_EFFECT",
  "case_type": "EDGE",
  "cross_sibling_acceptance": false,
  "domain": "SBL_TO_NATIVE",
  "effect_class": "SPLIT_REQUIRED",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "second issuer or shared receipt -> SECOND_ISSUER_OR_MIXED_EFFECT",
    "domain_positive": "DEV/OPS different WOs, separate source diff and real native ACK",
    "required_domain_fields": [
      "sbl_entry",
      "candidate",
      "dev_diff",
      "ops_handoff",
      "native_receiver_ack"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.bridge_handoff.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::WO-B1-B3-DEV::EDGE",
      "OP::WO-B1-B3-OPS::EDGE"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L351-L351 excerpt_sha256=2107cbbdffdfc7d0b61d88aa3727484af437d55de2dd279b69ce560ceac887f9",
    "stimulus": "introduce domain-applicable resource/currentness drift, preserve adjacent independent effects"
  },
  "runner_route": "OWNER_REGISTERED::bridge_handoff",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": false,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-B3-EDGE",
  "workorder_refs": [
    "WO-B1-B3-DEV",
    "WO-B1-B3-OPS"
  ]
}
```
- **拒收**：domain `bridge_handoff` missing/typed raw absent => HOLD；實際 error `HANDOFF_ABI_OR_MOCK_ACK_EDGE` 正規化 canonical `SECOND_ISSUER_OR_MIXED_EFFECT`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-B3-SEC｜SBL_TO_NATIVE / SEC

- **來源刺激**：source_clause=R15.1:L278(W03), R15.1:L279(W04); preconditions=WorkOrderCandidate subject/PI/PD/ECP hashes and current native receiver ABI; input_domain=sbl/adapter，subject_ref+sha 必連到 PI; stimulus=candidate adds hidden token/issuer fields rejected by native
```json
{
  "atom_or_gwo": "B1-B3",
  "canonical_first_fail": "SECOND_ISSUER_OR_MIXED_EFFECT",
  "case_type": "SEC",
  "cross_sibling_acceptance": false,
  "domain": "SBL_TO_NATIVE",
  "effect_class": "SPLIT_REQUIRED",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "second issuer or shared receipt -> SECOND_ISSUER_OR_MIXED_EFFECT",
    "domain_positive": "DEV/OPS different WOs, separate source diff and real native ACK",
    "required_domain_fields": [
      "sbl_entry",
      "candidate",
      "dev_diff",
      "ops_handoff",
      "native_receiver_ack"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.bridge_handoff.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::WO-B1-B3-DEV::SEC",
      "OP::WO-B1-B3-OPS::SEC"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L352-L352 excerpt_sha256=5b0438e7d3be075999eda3ff8f5739966d6a2e40b212e710846bd6f32cf1bb0d",
    "stimulus": "forge/replay this domain credential/subject or cross-swap sibling receipt"
  },
  "runner_route": "OWNER_REGISTERED::bridge_handoff",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": false,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-B3-SEC",
  "workorder_refs": [
    "WO-B1-B3-DEV",
    "WO-B1-B3-OPS"
  ]
}
```
- **拒收**：domain `bridge_handoff` missing/typed raw absent => HOLD；實際 error `HANDOFF_ABI_OR_MOCK_ACK_SEC` 正規化 canonical `SECOND_ISSUER_OR_MIXED_EFFECT`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-B4-POS｜ECP_SELECTOR / POS

- **來源刺激**：source_clause=PIPD05:§Receiver; R15.1:§4; preconditions=effect class, phase, dependency WO, selected single ECP, signed scope/ttl; input_domain=pipd/ecp_selector，subject_ref+sha 必連; stimulus=Provide owner-issued exact-current effect class, phase, dependency WO, selected single ECP, signed scope/ttl
```json
{
  "atom_or_gwo": "B1-B4",
  "canonical_first_fail": "ECP_MULTIPLE_OR_CLASS_UNKNOWN",
  "case_type": "POS",
  "cross_sibling_acceptance": false,
  "domain": "ECP_SELECTOR",
  "effect_class": "SPLIT_REQUIRED",
  "expected_case_verdict": "DOMAIN_POSITIVE_AFTER_REAL_RUN",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "two active ECPs/unknown class -> ECP_MULTIPLE_OR_CLASS_UNKNOWN",
    "domain_positive": "one active ECP per WO; split iff distinct effects",
    "required_domain_fields": [
      "wo_id",
      "effect_class",
      "active_ecp_count",
      "issuer_ack"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.ecp_selection.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::WO-B1-B4-DEV::POS",
      "OP::WO-B1-B4-OPS::POS"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L353-L353 excerpt_sha256=69f412d24df5fda12200ddb699aa3c3de6255801a5c3c5c8d32801868d1c1b11",
    "stimulus": "valid exact current Owner-supplied fixture only"
  },
  "runner_route": "OWNER_REGISTERED::ecp_selection",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": false,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-B4-POS",
  "workorder_refs": [
    "WO-B1-B4-DEV",
    "WO-B1-B4-OPS"
  ]
}
```
- **拒收**：domain `ecp_selection` missing/typed raw absent => HOLD；實際 error `ECP_MULTIPLE_OR_CLASS_UNKNOWN` 正規化 canonical `ECP_MULTIPLE_OR_CLASS_UNKNOWN`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-B4-NEG｜ECP_SELECTOR / NEG

- **來源刺激**：source_clause=PIPD05:§Receiver; R15.1:§4; preconditions=effect class, phase, dependency WO, selected single ECP, signed scope/ttl; input_domain=pipd/ecp_selector，subject_ref+sha 必連; stimulus=same WO has active OPS and DEV templates
```json
{
  "atom_or_gwo": "B1-B4",
  "canonical_first_fail": "ECP_MULTIPLE_OR_CLASS_UNKNOWN",
  "case_type": "NEG",
  "cross_sibling_acceptance": false,
  "domain": "ECP_SELECTOR",
  "effect_class": "SPLIT_REQUIRED",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "two active ECPs/unknown class -> ECP_MULTIPLE_OR_CLASS_UNKNOWN",
    "domain_positive": "one active ECP per WO; split iff distinct effects",
    "required_domain_fields": [
      "wo_id",
      "effect_class",
      "active_ecp_count",
      "issuer_ack"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.ecp_selection.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::WO-B1-B4-DEV::NEG",
      "OP::WO-B1-B4-OPS::NEG"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L354-L354 excerpt_sha256=725f7a3aa5342fdd1f75abf15a01c400ec8919c3cc8bedd16ad2bc776905c05d",
    "stimulus": "same WO has active OPS and DEV templates"
  },
  "runner_route": "OWNER_REGISTERED::ecp_selection",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": false,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-B4-NEG",
  "workorder_refs": [
    "WO-B1-B4-DEV",
    "WO-B1-B4-OPS"
  ]
}
```
- **拒收**：domain `ecp_selection` missing/typed raw absent => HOLD；實際 error `ECP_DOUBLE_ACTIVE_OR_CLASS_MISMATCH` 正規化 canonical `ECP_MULTIPLE_OR_CLASS_UNKNOWN`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-B4-EDGE｜ECP_SELECTOR / EDGE

- **來源刺激**：source_clause=PIPD05:§Receiver; R15.1:§4; preconditions=effect class, phase, dependency WO, selected single ECP, signed scope/ttl; input_domain=pipd/ecp_selector，subject_ref+sha 必連; stimulus=DEV patch completes but restart dependency lacks new OPS permit
```json
{
  "atom_or_gwo": "B1-B4",
  "canonical_first_fail": "ECP_MULTIPLE_OR_CLASS_UNKNOWN",
  "case_type": "EDGE",
  "cross_sibling_acceptance": false,
  "domain": "ECP_SELECTOR",
  "effect_class": "SPLIT_REQUIRED",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "two active ECPs/unknown class -> ECP_MULTIPLE_OR_CLASS_UNKNOWN",
    "domain_positive": "one active ECP per WO; split iff distinct effects",
    "required_domain_fields": [
      "wo_id",
      "effect_class",
      "active_ecp_count",
      "issuer_ack"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.ecp_selection.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::WO-B1-B4-DEV::EDGE",
      "OP::WO-B1-B4-OPS::EDGE"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L355-L355 excerpt_sha256=5c830b20f8b2eaead27098e754f0720cc8ed7263316d071830cff5683c84fbdb",
    "stimulus": "introduce domain-applicable resource/currentness drift, preserve adjacent independent effects"
  },
  "runner_route": "OWNER_REGISTERED::ecp_selection",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": false,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-B4-EDGE",
  "workorder_refs": [
    "WO-B1-B4-DEV",
    "WO-B1-B4-OPS"
  ]
}
```
- **拒收**：domain `ecp_selection` missing/typed raw absent => HOLD；實際 error `ECP_DOUBLE_ACTIVE_OR_CLASS_MISMATCH_EDGE` 正規化 canonical `ECP_MULTIPLE_OR_CLASS_UNKNOWN`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-B4-SEC｜ECP_SELECTOR / SEC

- **來源刺激**：source_clause=PIPD05:§Receiver; R15.1:§4; preconditions=effect class, phase, dependency WO, selected single ECP, signed scope/ttl; input_domain=pipd/ecp_selector，subject_ref+sha 必連; stimulus=client attempts to hot-reload under DEV token
```json
{
  "atom_or_gwo": "B1-B4",
  "canonical_first_fail": "ECP_MULTIPLE_OR_CLASS_UNKNOWN",
  "case_type": "SEC",
  "cross_sibling_acceptance": false,
  "domain": "ECP_SELECTOR",
  "effect_class": "SPLIT_REQUIRED",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "two active ECPs/unknown class -> ECP_MULTIPLE_OR_CLASS_UNKNOWN",
    "domain_positive": "one active ECP per WO; split iff distinct effects",
    "required_domain_fields": [
      "wo_id",
      "effect_class",
      "active_ecp_count",
      "issuer_ack"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.ecp_selection.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::WO-B1-B4-DEV::SEC",
      "OP::WO-B1-B4-OPS::SEC"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L356-L356 excerpt_sha256=3fa4a19a199cd68ed36d6c3c08c9bb86403e9169bc4575f11a35b5e66054530b",
    "stimulus": "forge/replay this domain credential/subject or cross-swap sibling receipt"
  },
  "runner_route": "OWNER_REGISTERED::ecp_selection",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": false,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-B4-SEC",
  "workorder_refs": [
    "WO-B1-B4-DEV",
    "WO-B1-B4-OPS"
  ]
}
```
- **拒收**：domain `ecp_selection` missing/typed raw absent => HOLD；實際 error `ECP_DOUBLE_ACTIVE_OR_CLASS_MISMATCH_SEC` 正規化 canonical `ECP_MULTIPLE_OR_CLASS_UNKNOWN`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-B5-POS｜THREE_SP / POS

- **來源刺激**：source_clause=R15.1:§3; preconditions=TPM goal payload, Commander typed DAG payload, external Challenge frozen candidate and separate principal; input_domain=sbl/sp_; stimulus=Provide owner-issued exact-current TPM goal payload, Commander typed DAG payload, external Challenge frozen candidate and separate principal
```json
{
  "atom_or_gwo": "B1-B5",
  "canonical_first_fail": "SP_HOST_LOAD_UNPROVEN",
  "case_type": "POS",
  "cross_sibling_acceptance": false,
  "domain": "THREE_SP",
  "effect_class": "SPLIT_REQUIRED",
  "expected_case_verdict": "DOMAIN_POSITIVE_AFTER_REAL_RUN",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "missing host invocation -> SP_HOST_LOAD_UNPROVEN",
    "domain_positive": "three host identities and isolated permission readbacks; ZIP-only not pass",
    "required_domain_fields": [
      "TPM_SP",
      "COMMANDER_SP",
      "CHALLENGE_SP",
      "host_invocation",
      "loaded_sha"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.sp_host_load.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::WO-B1-B5-DEV::POS",
      "OP::WO-B1-B5-OPS::POS"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L357-L357 excerpt_sha256=2ee3e4a36e7208a22388182d21dc26da7b300228ed7096db94c578e2138b4042",
    "stimulus": "valid exact current Owner-supplied fixture only"
  },
  "runner_route": "OWNER_REGISTERED::sp_host_load",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": false,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-B5-POS",
  "workorder_refs": [
    "WO-B1-B5-DEV",
    "WO-B1-B5-OPS"
  ]
}
```
- **拒收**：domain `sp_host_load` missing/typed raw absent => HOLD；實際 error `SP_HOST_LOAD_UNPROVEN` 正規化 canonical `SP_HOST_LOAD_UNPROVEN`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-B5-NEG｜THREE_SP / NEG

- **來源刺激**：source_clause=R15.1:§3; preconditions=TPM goal payload, Commander typed DAG payload, external Challenge frozen candidate and separate principal; input_domain=sbl/sp_; stimulus=Commander chat reply claimed to be HGK issued WorkOrder
```json
{
  "atom_or_gwo": "B1-B5",
  "canonical_first_fail": "SP_HOST_LOAD_UNPROVEN",
  "case_type": "NEG",
  "cross_sibling_acceptance": false,
  "domain": "THREE_SP",
  "effect_class": "SPLIT_REQUIRED",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "missing host invocation -> SP_HOST_LOAD_UNPROVEN",
    "domain_positive": "three host identities and isolated permission readbacks; ZIP-only not pass",
    "required_domain_fields": [
      "TPM_SP",
      "COMMANDER_SP",
      "CHALLENGE_SP",
      "host_invocation",
      "loaded_sha"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.sp_host_load.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::WO-B1-B5-DEV::NEG",
      "OP::WO-B1-B5-OPS::NEG"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L358-L358 excerpt_sha256=671ab2948ce22f31905b9b3b703600dcef0ab1a4e49c29bd867f2677922bdccb",
    "stimulus": "Commander chat reply claimed to be HGK issued WorkOrder"
  },
  "runner_route": "OWNER_REGISTERED::sp_host_load",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": false,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-B5-NEG",
  "workorder_refs": [
    "WO-B1-B5-DEV",
    "WO-B1-B5-OPS"
  ]
}
```
- **拒收**：domain `sp_host_load` missing/typed raw absent => HOLD；實際 error `SP_ROLE_OR_HOST_NOT_ACTUALLY_LOADED` 正規化 canonical `SP_HOST_LOAD_UNPROVEN`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-B5-EDGE｜THREE_SP / EDGE

- **來源刺激**：source_clause=R15.1:§3; preconditions=TPM goal payload, Commander typed DAG payload, external Challenge frozen candidate and separate principal; input_domain=sbl/sp_; stimulus=Host installed plugin changes independently between three invokes
```json
{
  "atom_or_gwo": "B1-B5",
  "canonical_first_fail": "SP_HOST_LOAD_UNPROVEN",
  "case_type": "EDGE",
  "cross_sibling_acceptance": false,
  "domain": "THREE_SP",
  "effect_class": "SPLIT_REQUIRED",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "missing host invocation -> SP_HOST_LOAD_UNPROVEN",
    "domain_positive": "three host identities and isolated permission readbacks; ZIP-only not pass",
    "required_domain_fields": [
      "TPM_SP",
      "COMMANDER_SP",
      "CHALLENGE_SP",
      "host_invocation",
      "loaded_sha"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.sp_host_load.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::WO-B1-B5-DEV::EDGE",
      "OP::WO-B1-B5-OPS::EDGE"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L359-L359 excerpt_sha256=91e5662048b4dcbb64c10f8fdbeca4fc04f23d70480f1ec1a4edb1ea66a84cc8",
    "stimulus": "introduce domain-applicable resource/currentness drift, preserve adjacent independent effects"
  },
  "runner_route": "OWNER_REGISTERED::sp_host_load",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": false,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-B5-EDGE",
  "workorder_refs": [
    "WO-B1-B5-DEV",
    "WO-B1-B5-OPS"
  ]
}
```
- **拒收**：domain `sp_host_load` missing/typed raw absent => HOLD；實際 error `SP_ROLE_OR_HOST_NOT_ACTUALLY_LOADED_EDGE` 正規化 canonical `SP_HOST_LOAD_UNPROVEN`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-B5-SEC｜THREE_SP / SEC

- **來源刺激**：source_clause=R15.1:§3; preconditions=TPM goal payload, Commander typed DAG payload, external Challenge frozen candidate and separate principal; input_domain=sbl/sp_; stimulus=same checker process attempts to act as maker
```json
{
  "atom_or_gwo": "B1-B5",
  "canonical_first_fail": "SP_HOST_LOAD_UNPROVEN",
  "case_type": "SEC",
  "cross_sibling_acceptance": false,
  "domain": "THREE_SP",
  "effect_class": "SPLIT_REQUIRED",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "missing host invocation -> SP_HOST_LOAD_UNPROVEN",
    "domain_positive": "three host identities and isolated permission readbacks; ZIP-only not pass",
    "required_domain_fields": [
      "TPM_SP",
      "COMMANDER_SP",
      "CHALLENGE_SP",
      "host_invocation",
      "loaded_sha"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.sp_host_load.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::WO-B1-B5-DEV::SEC",
      "OP::WO-B1-B5-OPS::SEC"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L360-L360 excerpt_sha256=dc431e6585d4d0ad1e1833149a01fdaca6f54f6dc243d009ef87ed08cc992d2f",
    "stimulus": "forge/replay this domain credential/subject or cross-swap sibling receipt"
  },
  "runner_route": "OWNER_REGISTERED::sp_host_load",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": false,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-B5-SEC",
  "workorder_refs": [
    "WO-B1-B5-DEV",
    "WO-B1-B5-OPS"
  ]
}
```
- **拒收**：domain `sp_host_load` missing/typed raw absent => HOLD；實際 error `SP_ROLE_OR_HOST_NOT_ACTUALLY_LOADED_SEC` 正規化 canonical `SP_HOST_LOAD_UNPROVEN`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-B6-POS｜TODO_PERSISTENCE / POS

- **來源刺激**：source_clause=R15.1:L281(W06), R15.1:L282(W07); preconditions=frozen CLI_TOOL TODO input seed, current install/test environment and affected source path; input_domain=sbl/cli_tool，subject; stimulus=Provide owner-issued exact-current frozen CLI_TOOL TODO input seed, current install/test environment and affected source path
```json
{
  "atom_or_gwo": "B1-B6",
  "canonical_first_fail": "CLI_EFFECT_MISCLASSIFIED",
  "case_type": "POS",
  "cross_sibling_acceptance": false,
  "domain": "TODO_PERSISTENCE",
  "effect_class": "USER_DATA_EFFECT",
  "expected_case_verdict": "DOMAIN_POSITIVE_AFTER_REAL_RUN",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "user effect misclassified or no actual state -> CLI_EFFECT_MISCLASSIFIED",
    "domain_positive": "isolated store add -> separate list -> delete -> zero residue",
    "required_domain_fields": [
      "data_dir",
      "task_id",
      "add_response",
      "list_response",
      "delete_response",
      "uninstall"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.sbl_todo.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::WO-B1-B6-USER::POS"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L361-L361 excerpt_sha256=8f84fdb9e9fae008524bf9c5b7242ea89141321e56e21ea7aa14741d32574079",
    "stimulus": "valid exact current Owner-supplied fixture only"
  },
  "runner_route": "OWNER_REGISTERED::sbl_todo",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-B6-POS",
  "workorder_refs": [
    "WO-B1-B6-USER"
  ]
}
```
- **拒收**：domain `sbl_todo` missing/typed raw absent => HOLD；實際 error `CLI_EFFECT_MISCLASSIFIED` 正規化 canonical `CLI_EFFECT_MISCLASSIFIED`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-B6-NEG｜TODO_PERSISTENCE / NEG

- **來源刺激**：source_clause=R15.1:L281(W06), R15.1:L282(W07); preconditions=frozen CLI_TOOL TODO input seed, current install/test environment and affected source path; input_domain=sbl/cli_tool，subject; stimulus=README-only ZIP is returned without runnable CLI
```json
{
  "atom_or_gwo": "B1-B6",
  "canonical_first_fail": "CLI_EFFECT_MISCLASSIFIED",
  "case_type": "NEG",
  "cross_sibling_acceptance": false,
  "domain": "TODO_PERSISTENCE",
  "effect_class": "USER_DATA_EFFECT",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "user effect misclassified or no actual state -> CLI_EFFECT_MISCLASSIFIED",
    "domain_positive": "isolated store add -> separate list -> delete -> zero residue",
    "required_domain_fields": [
      "data_dir",
      "task_id",
      "add_response",
      "list_response",
      "delete_response",
      "uninstall"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.sbl_todo.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::WO-B1-B6-USER::NEG"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L362-L362 excerpt_sha256=54e6da6477c73dc0e14aceb09109e0a69db08344fed2908699b0accd3bd82fbf",
    "stimulus": "README-only ZIP is returned without runnable CLI"
  },
  "runner_route": "OWNER_REGISTERED::sbl_todo",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-B6-NEG",
  "workorder_refs": [
    "WO-B1-B6-USER"
  ]
}
```
- **拒收**：domain `sbl_todo` missing/typed raw absent => HOLD；實際 error `USER_TASK_EXECUTION_NOT_OBSERVED` 正規化 canonical `CLI_EFFECT_MISCLASSIFIED`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-B6-EDGE｜TODO_PERSISTENCE / EDGE

- **來源刺激**：source_clause=R15.1:L281(W06), R15.1:L282(W07); preconditions=frozen CLI_TOOL TODO input seed, current install/test environment and affected source path; input_domain=sbl/cli_tool，subject; stimulus=provider-off while invocation is in flight
```json
{
  "atom_or_gwo": "B1-B6",
  "canonical_first_fail": "CLI_EFFECT_MISCLASSIFIED",
  "case_type": "EDGE",
  "cross_sibling_acceptance": false,
  "domain": "TODO_PERSISTENCE",
  "effect_class": "USER_DATA_EFFECT",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "user effect misclassified or no actual state -> CLI_EFFECT_MISCLASSIFIED",
    "domain_positive": "isolated store add -> separate list -> delete -> zero residue",
    "required_domain_fields": [
      "data_dir",
      "task_id",
      "add_response",
      "list_response",
      "delete_response",
      "uninstall"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.sbl_todo.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::WO-B1-B6-USER::EDGE"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L363-L363 excerpt_sha256=75d1ca893e28a0c6b045bb9f45dd88b9ac063cb689bd09e1657cdbe4c3b0a0bc",
    "stimulus": "introduce domain-applicable resource/currentness drift, preserve adjacent independent effects"
  },
  "runner_route": "OWNER_REGISTERED::sbl_todo",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-B6-EDGE",
  "workorder_refs": [
    "WO-B1-B6-USER"
  ]
}
```
- **拒收**：domain `sbl_todo` missing/typed raw absent => HOLD；實際 error `USER_TASK_EXECUTION_NOT_OBSERVED_EDGE` 正規化 canonical `CLI_EFFECT_MISCLASSIFIED`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-B6-SEC｜TODO_PERSISTENCE / SEC

- **來源刺激**：source_clause=R15.1:L281(W06), R15.1:L282(W07); preconditions=frozen CLI_TOOL TODO input seed, current install/test environment and affected source path; input_domain=sbl/cli_tool，subject; stimulus=CLI command accesses outside isolated fixture directory
```json
{
  "atom_or_gwo": "B1-B6",
  "canonical_first_fail": "CLI_EFFECT_MISCLASSIFIED",
  "case_type": "SEC",
  "cross_sibling_acceptance": false,
  "domain": "TODO_PERSISTENCE",
  "effect_class": "USER_DATA_EFFECT",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "user effect misclassified or no actual state -> CLI_EFFECT_MISCLASSIFIED",
    "domain_positive": "isolated store add -> separate list -> delete -> zero residue",
    "required_domain_fields": [
      "data_dir",
      "task_id",
      "add_response",
      "list_response",
      "delete_response",
      "uninstall"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.sbl_todo.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::WO-B1-B6-USER::SEC"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L364-L364 excerpt_sha256=7b3ebfe2d12bf0e34c8ed07d84c5e4ba1fa2be250c22a45897586e495ea30b78",
    "stimulus": "forge/replay this domain credential/subject or cross-swap sibling receipt"
  },
  "runner_route": "OWNER_REGISTERED::sbl_todo",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-B6-SEC",
  "workorder_refs": [
    "WO-B1-B6-USER"
  ]
}
```
- **拒收**：domain `sbl_todo` missing/typed raw absent => HOLD；實際 error `USER_TASK_EXECUTION_NOT_OBSERVED_SEC` 正規化 canonical `CLI_EFFECT_MISCLASSIFIED`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-B7-POS｜NOFIT_ROUTE / POS

- **來源刺激**：source_clause=R15.1:L278(C07); preconditions=effective provider availability, ACL, tool allowlist, NoFit schema, alternate read-only outcome; input_domain=policy/guardrails; stimulus=Provide owner-issued exact-current effective provider availability, ACL, tool allowlist, NoFit schema, alternate read-only outcome
```json
{
  "atom_or_gwo": "B1-B7",
  "canonical_first_fail": "NOFIT_OR_PROVIDER_OFF",
  "case_type": "POS",
  "cross_sibling_acceptance": false,
  "domain": "NOFIT_ROUTE",
  "effect_class": "READ_ONLY_PROBE",
  "expected_case_verdict": "DOMAIN_POSITIVE_AFTER_REAL_RUN",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "silent fallback -> NOFIT_OR_PROVIDER_OFF",
    "domain_positive": "deterministic capability NOFIT with user-readable reason and zero unauthorized delta",
    "required_domain_fields": [
      "required_capability",
      "host",
      "provider_off",
      "owner",
      "refusal",
      "zero_effect"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.no_fit.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::OBS-B1-B7::POS"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L365-L365 excerpt_sha256=abff4b0436342bb3b6bcdc9a4b4bbd2cf8558f2283e79293d05a328e6bbfaf9d",
    "stimulus": "valid exact current Owner-supplied fixture only"
  },
  "runner_route": "OWNER_REGISTERED::no_fit",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-B7-POS",
  "workorder_refs": [
    "OBS-B1-B7"
  ]
}
```
- **拒收**：domain `no_fit` missing/typed raw absent => HOLD；實際 error `NOFIT_OR_PROVIDER_OFF` 正規化 canonical `NOFIT_OR_PROVIDER_OFF`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-B7-NEG｜NOFIT_ROUTE / NEG

- **來源刺激**：source_clause=R15.1:L278(C07); preconditions=effective provider availability, ACL, tool allowlist, NoFit schema, alternate read-only outcome; input_domain=policy/guardrails; stimulus=provider-off auto silently switches unauthorized model
```json
{
  "atom_or_gwo": "B1-B7",
  "canonical_first_fail": "NOFIT_OR_PROVIDER_OFF",
  "case_type": "NEG",
  "cross_sibling_acceptance": false,
  "domain": "NOFIT_ROUTE",
  "effect_class": "READ_ONLY_PROBE",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "silent fallback -> NOFIT_OR_PROVIDER_OFF",
    "domain_positive": "deterministic capability NOFIT with user-readable reason and zero unauthorized delta",
    "required_domain_fields": [
      "required_capability",
      "host",
      "provider_off",
      "owner",
      "refusal",
      "zero_effect"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.no_fit.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::OBS-B1-B7::NEG"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L366-L366 excerpt_sha256=914f4facdd74de3934a6c0562b99ff1540cec15b5b6fd603e66891d8346e4d59",
    "stimulus": "provider-off auto silently switches unauthorized model"
  },
  "runner_route": "OWNER_REGISTERED::no_fit",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-B7-NEG",
  "workorder_refs": [
    "OBS-B1-B7"
  ]
}
```
- **拒收**：domain `no_fit` missing/typed raw absent => HOLD；實際 error `GUARDRAIL_BYPASS_OR_NOFIT_INCOMPLETE` 正規化 canonical `NOFIT_OR_PROVIDER_OFF`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-B7-EDGE｜NOFIT_ROUTE / EDGE

- **來源刺激**：source_clause=R15.1:L278(C07); preconditions=effective provider availability, ACL, tool allowlist, NoFit schema, alternate read-only outcome; input_domain=policy/guardrails; stimulus=read-only task waits while unrelated runnable card exists
```json
{
  "atom_or_gwo": "B1-B7",
  "canonical_first_fail": "NOFIT_OR_PROVIDER_OFF",
  "case_type": "EDGE",
  "cross_sibling_acceptance": false,
  "domain": "NOFIT_ROUTE",
  "effect_class": "READ_ONLY_PROBE",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "silent fallback -> NOFIT_OR_PROVIDER_OFF",
    "domain_positive": "deterministic capability NOFIT with user-readable reason and zero unauthorized delta",
    "required_domain_fields": [
      "required_capability",
      "host",
      "provider_off",
      "owner",
      "refusal",
      "zero_effect"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.no_fit.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::OBS-B1-B7::EDGE"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L367-L367 excerpt_sha256=d2151a318e4fd22e89c66a87795afdcd3278ac10d58e2143f235b028403a736a",
    "stimulus": "introduce domain-applicable resource/currentness drift, preserve adjacent independent effects"
  },
  "runner_route": "OWNER_REGISTERED::no_fit",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-B7-EDGE",
  "workorder_refs": [
    "OBS-B1-B7"
  ]
}
```
- **拒收**：domain `no_fit` missing/typed raw absent => HOLD；實際 error `GUARDRAIL_BYPASS_OR_NOFIT_INCOMPLETE_EDGE` 正規化 canonical `NOFIT_OR_PROVIDER_OFF`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-B7-SEC｜NOFIT_ROUTE / SEC

- **來源刺激**：source_clause=R15.1:L278(C07); preconditions=effective provider availability, ACL, tool allowlist, NoFit schema, alternate read-only outcome; input_domain=policy/guardrails; stimulus=credential-looking payload is reprinted in NoFit logs
```json
{
  "atom_or_gwo": "B1-B7",
  "canonical_first_fail": "NOFIT_OR_PROVIDER_OFF",
  "case_type": "SEC",
  "cross_sibling_acceptance": false,
  "domain": "NOFIT_ROUTE",
  "effect_class": "READ_ONLY_PROBE",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "silent fallback -> NOFIT_OR_PROVIDER_OFF",
    "domain_positive": "deterministic capability NOFIT with user-readable reason and zero unauthorized delta",
    "required_domain_fields": [
      "required_capability",
      "host",
      "provider_off",
      "owner",
      "refusal",
      "zero_effect"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.no_fit.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::OBS-B1-B7::SEC"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L368-L368 excerpt_sha256=c9f21940e9cd550207492552dd160e7073914f4333fca11923b29f2984f50559",
    "stimulus": "forge/replay this domain credential/subject or cross-swap sibling receipt"
  },
  "runner_route": "OWNER_REGISTERED::no_fit",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-B7-SEC",
  "workorder_refs": [
    "OBS-B1-B7"
  ]
}
```
- **拒收**：domain `no_fit` missing/typed raw absent => HOLD；實際 error `GUARDRAIL_BYPASS_OR_NOFIT_INCOMPLETE_SEC` 正規化 canonical `NOFIT_OR_PROVIDER_OFF`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-B8-POS｜TRACE_GRAPH / POS

- **來源刺激**：source_clause=PIPD04:§4; preconditions=Source→PI→PD→CC→ECP→WO→raw→checker subject/version/hash edges; input_domain=pipd/trace，subject_ref+sha 必連到 PI/PD，但本項擁有上述專屬欄位; stimulus=Provide owner-issued exact-current Source→PI→PD→CC→ECP→WO→raw→checker subject/version/hash edges
```json
{
  "atom_or_gwo": "B1-B8",
  "canonical_first_fail": "TRACE_CLOSURE_FAIL",
  "case_type": "POS",
  "cross_sibling_acceptance": false,
  "domain": "TRACE_GRAPH",
  "effect_class": "READ_ONLY_PROBE",
  "expected_case_verdict": "DOMAIN_POSITIVE_AFTER_REAL_RUN",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "foreign/sibling witness -> TRACE_CLOSURE_FAIL",
    "domain_positive": "nonempty exact IDs and hashes, zero orphans and zero bad edges",
    "required_domain_fields": [
      "pi",
      "pd",
      "cc",
      "ecp",
      "wo",
      "tqaep",
      "raw",
      "checker",
      "edges"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.trace_closure.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::OBS-B1-B8::POS"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L369-L369 excerpt_sha256=dc334f76c5977cf659f6c1555f48a8ca61dd2f4ca0d5bf3879f7e862cda321a8",
    "stimulus": "valid exact current Owner-supplied fixture only"
  },
  "runner_route": "OWNER_REGISTERED::trace_closure",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-B8-POS",
  "workorder_refs": [
    "OBS-B1-B8"
  ]
}
```
- **拒收**：domain `trace_closure` missing/typed raw absent => HOLD；實際 error `TRACE_CLOSURE_FAIL` 正規化 canonical `TRACE_CLOSURE_FAIL`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-B8-NEG｜TRACE_GRAPH / NEG

- **來源刺激**：source_clause=PIPD04:§4; preconditions=Source→PI→PD→CC→ECP→WO→raw→checker subject/version/hash edges; input_domain=pipd/trace，subject_ref+sha 必連到 PI/PD，但本項擁有上述專屬欄位; stimulus=raw receipt SHA belongs to another PI candidate
```json
{
  "atom_or_gwo": "B1-B8",
  "canonical_first_fail": "TRACE_CLOSURE_FAIL",
  "case_type": "NEG",
  "cross_sibling_acceptance": false,
  "domain": "TRACE_GRAPH",
  "effect_class": "READ_ONLY_PROBE",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "foreign/sibling witness -> TRACE_CLOSURE_FAIL",
    "domain_positive": "nonempty exact IDs and hashes, zero orphans and zero bad edges",
    "required_domain_fields": [
      "pi",
      "pd",
      "cc",
      "ecp",
      "wo",
      "tqaep",
      "raw",
      "checker",
      "edges"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.trace_closure.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::OBS-B1-B8::NEG"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L370-L370 excerpt_sha256=e12d723ef6eab1f579aceecd0cb1748273295cc66d2aace35a6ba9089c9ee147",
    "stimulus": "raw receipt SHA belongs to another PI candidate"
  },
  "runner_route": "OWNER_REGISTERED::trace_closure",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-B8-NEG",
  "workorder_refs": [
    "OBS-B1-B8"
  ]
}
```
- **拒收**：domain `trace_closure` missing/typed raw absent => HOLD；實際 error `SUBJECT_HASH_BREAK_OR_ORPHAN` 正規化 canonical `TRACE_CLOSURE_FAIL`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-B8-EDGE｜TRACE_GRAPH / EDGE

- **來源刺激**：source_clause=PIPD04:§4; preconditions=Source→PI→PD→CC→ECP→WO→raw→checker subject/version/hash edges; input_domain=pipd/trace，subject_ref+sha 必連到 PI/PD，但本項擁有上述專屬欄位; stimulus=source superseded after PI built, while PD bound old version
```json
{
  "atom_or_gwo": "B1-B8",
  "canonical_first_fail": "TRACE_CLOSURE_FAIL",
  "case_type": "EDGE",
  "cross_sibling_acceptance": false,
  "domain": "TRACE_GRAPH",
  "effect_class": "READ_ONLY_PROBE",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "foreign/sibling witness -> TRACE_CLOSURE_FAIL",
    "domain_positive": "nonempty exact IDs and hashes, zero orphans and zero bad edges",
    "required_domain_fields": [
      "pi",
      "pd",
      "cc",
      "ecp",
      "wo",
      "tqaep",
      "raw",
      "checker",
      "edges"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.trace_closure.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::OBS-B1-B8::EDGE"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L371-L371 excerpt_sha256=920d7f36ca527f097cdfdd0ee315bcd074f2af184edb19ed340ff91f22f59ab4",
    "stimulus": "introduce domain-applicable resource/currentness drift, preserve adjacent independent effects"
  },
  "runner_route": "OWNER_REGISTERED::trace_closure",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-B8-EDGE",
  "workorder_refs": [
    "OBS-B1-B8"
  ]
}
```
- **拒收**：domain `trace_closure` missing/typed raw absent => HOLD；實際 error `SUBJECT_HASH_BREAK_OR_ORPHAN_EDGE` 正規化 canonical `TRACE_CLOSURE_FAIL`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-B8-SEC｜TRACE_GRAPH / SEC

- **來源刺激**：source_clause=PIPD04:§4; preconditions=Source→PI→PD→CC→ECP→WO→raw→checker subject/version/hash edges; input_domain=pipd/trace，subject_ref+sha 必連到 PI/PD，但本項擁有上述專屬欄位; stimulus=untrusted sidecar attempts to override join hash
```json
{
  "atom_or_gwo": "B1-B8",
  "canonical_first_fail": "TRACE_CLOSURE_FAIL",
  "case_type": "SEC",
  "cross_sibling_acceptance": false,
  "domain": "TRACE_GRAPH",
  "effect_class": "READ_ONLY_PROBE",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "foreign/sibling witness -> TRACE_CLOSURE_FAIL",
    "domain_positive": "nonempty exact IDs and hashes, zero orphans and zero bad edges",
    "required_domain_fields": [
      "pi",
      "pd",
      "cc",
      "ecp",
      "wo",
      "tqaep",
      "raw",
      "checker",
      "edges"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.trace_closure.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::OBS-B1-B8::SEC"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L372-L372 excerpt_sha256=5959b6103476f4bd8c7a779bfb7f35efab4fecb7db99a7b0c89109d98b8d9073",
    "stimulus": "forge/replay this domain credential/subject or cross-swap sibling receipt"
  },
  "runner_route": "OWNER_REGISTERED::trace_closure",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-B8-SEC",
  "workorder_refs": [
    "OBS-B1-B8"
  ]
}
```
- **拒收**：domain `trace_closure` missing/typed raw absent => HOLD；實際 error `SUBJECT_HASH_BREAK_OR_ORPHAN_SEC` 正規化 canonical `TRACE_CLOSURE_FAIL`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-B9-POS｜R15_COVERAGE / POS

- **來源刺激**：source_clause=R15.1:§11,§16; preconditions=minimum B1 user outcome and full R15 8 kinds×3 modes denominators; input_domain=sbl/roadmap，subject_ref+sha 必連到 PI/PD，但本項擁有上; stimulus=Provide owner-issued exact-current minimum B1 user outcome and full R15 8 kinds×3 modes denominators
```json
{
  "atom_or_gwo": "B1-B9",
  "canonical_first_fail": "R15_DENOMINATOR_SHRINK",
  "case_type": "POS",
  "cross_sibling_acceptance": false,
  "domain": "R15_COVERAGE",
  "effect_class": "READ_ONLY_PROBE",
  "expected_case_verdict": "DOMAIN_POSITIVE_AFTER_REAL_RUN",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "missing ID or generic proxy pass -> R15_DENOMINATOR_SHRINK",
    "domain_positive": "949 unique 18-family IDs, 66/254/629 and source-specific disposition",
    "required_domain_fields": [
      "949_ids",
      "18_families",
      "required",
      "conditional",
      "deferred",
      "owners"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.baseline_denominator.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::OBS-B1-B9::POS"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L373-L373 excerpt_sha256=2d10504d1f17135777b96f307e06f6166fd6b049758a21bf983c19603e5ab3e9",
    "stimulus": "valid exact current Owner-supplied fixture only"
  },
  "runner_route": "OWNER_REGISTERED::baseline_denominator",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-B9-POS",
  "workorder_refs": [
    "OBS-B1-B9"
  ]
}
```
- **拒收**：domain `baseline_denominator` missing/typed raw absent => HOLD；實際 error `R15_DENOMINATOR_SHRINK` 正規化 canonical `R15_DENOMINATOR_SHRINK`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-B9-NEG｜R15_COVERAGE / NEG

- **來源刺激**：source_clause=R15.1:§11,§16; preconditions=minimum B1 user outcome and full R15 8 kinds×3 modes denominators; input_domain=sbl/roadmap，subject_ref+sha 必連到 PI/PD，但本項擁有上; stimulus=one CLI success advertised as all 24 Kind×Mode cells ready
```json
{
  "atom_or_gwo": "B1-B9",
  "canonical_first_fail": "R15_DENOMINATOR_SHRINK",
  "case_type": "NEG",
  "cross_sibling_acceptance": false,
  "domain": "R15_COVERAGE",
  "effect_class": "READ_ONLY_PROBE",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "missing ID or generic proxy pass -> R15_DENOMINATOR_SHRINK",
    "domain_positive": "949 unique 18-family IDs, 66/254/629 and source-specific disposition",
    "required_domain_fields": [
      "949_ids",
      "18_families",
      "required",
      "conditional",
      "deferred",
      "owners"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.baseline_denominator.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::OBS-B1-B9::NEG"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L374-L374 excerpt_sha256=09ed522a398e130a85145d97c2de9f231a11a635bffe6bc49bb26313a9b15e73",
    "stimulus": "one CLI success advertised as all 24 Kind×Mode cells ready"
  },
  "runner_route": "OWNER_REGISTERED::baseline_denominator",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-B9-NEG",
  "workorder_refs": [
    "OBS-B1-B9"
  ]
}
```
- **拒收**：domain `baseline_denominator` missing/typed raw absent => HOLD；實際 error `FULL_PRODUCT_PROXY_PASS` 正規化 canonical `R15_DENOMINATOR_SHRINK`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-B9-EDGE｜R15_COVERAGE / EDGE

- **來源刺激**：source_clause=R15.1:§11,§16; preconditions=minimum B1 user outcome and full R15 8 kinds×3 modes denominators; input_domain=sbl/roadmap，subject_ref+sha 必連到 PI/PD，但本項擁有上; stimulus=new donor may be evaluated without reopening committed requirements
```json
{
  "atom_or_gwo": "B1-B9",
  "canonical_first_fail": "R15_DENOMINATOR_SHRINK",
  "case_type": "EDGE",
  "cross_sibling_acceptance": false,
  "domain": "R15_COVERAGE",
  "effect_class": "READ_ONLY_PROBE",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "missing ID or generic proxy pass -> R15_DENOMINATOR_SHRINK",
    "domain_positive": "949 unique 18-family IDs, 66/254/629 and source-specific disposition",
    "required_domain_fields": [
      "949_ids",
      "18_families",
      "required",
      "conditional",
      "deferred",
      "owners"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.baseline_denominator.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::OBS-B1-B9::EDGE"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L375-L375 excerpt_sha256=3fafba1d1f4bac0a365885b1074f81f78f28afcd71ea459e3938889bf34a0d10",
    "stimulus": "introduce domain-applicable resource/currentness drift, preserve adjacent independent effects"
  },
  "runner_route": "OWNER_REGISTERED::baseline_denominator",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-B9-EDGE",
  "workorder_refs": [
    "OBS-B1-B9"
  ]
}
```
- **拒收**：domain `baseline_denominator` missing/typed raw absent => HOLD；實際 error `FULL_PRODUCT_PROXY_PASS_EDGE` 正規化 canonical `R15_DENOMINATOR_SHRINK`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-B9-SEC｜R15_COVERAGE / SEC

- **來源刺激**：source_clause=R15.1:§11,§16; preconditions=minimum B1 user outcome and full R15 8 kinds×3 modes denominators; input_domain=sbl/roadmap，subject_ref+sha 必連到 PI/PD，但本項擁有上; stimulus=mark full product RELEASED from candidate-only CI
```json
{
  "atom_or_gwo": "B1-B9",
  "canonical_first_fail": "R15_DENOMINATOR_SHRINK",
  "case_type": "SEC",
  "cross_sibling_acceptance": false,
  "domain": "R15_COVERAGE",
  "effect_class": "READ_ONLY_PROBE",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "missing ID or generic proxy pass -> R15_DENOMINATOR_SHRINK",
    "domain_positive": "949 unique 18-family IDs, 66/254/629 and source-specific disposition",
    "required_domain_fields": [
      "949_ids",
      "18_families",
      "required",
      "conditional",
      "deferred",
      "owners"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.baseline_denominator.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::OBS-B1-B9::SEC"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L376-L376 excerpt_sha256=f211483e6dfb7bc33f6d2a15b418ecdebcc2169e53176a00e11ff187ec64e58a",
    "stimulus": "forge/replay this domain credential/subject or cross-swap sibling receipt"
  },
  "runner_route": "OWNER_REGISTERED::baseline_denominator",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-B9-SEC",
  "workorder_refs": [
    "OBS-B1-B9"
  ]
}
```
- **拒收**：domain `baseline_denominator` missing/typed raw absent => HOLD；實際 error `FULL_PRODUCT_PROXY_PASS_SEC` 正規化 canonical `R15_DENOMINATOR_SHRINK`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-C1-POS｜FABRIC_PROMOTION / POS

- **來源刺激**：source_clause=R15.1:L277(W02), R15.1:L277(C02); preconditions=Inject a valid current owned active canonical PolicySource SHA, epoch, signed projection manifest and consuming reader; stimulus=Provide owner-issued exact-current active canonical PolicySource SHA, epoch, signed projection manifest and consuming reader
```json
{
  "atom_or_gwo": "B1-C1",
  "canonical_first_fail": "FABRIC_LOADED_ABSENT",
  "case_type": "POS",
  "cross_sibling_acceptance": false,
  "domain": "FABRIC_PROMOTION",
  "effect_class": "HOST_OPERATIONS",
  "expected_case_verdict": "DOMAIN_POSITIVE_AFTER_REAL_RUN",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "stage mistaken as active or missing consumer -> FABRIC_LOADED_ABSENT",
    "domain_positive": "independent stage approval; active and loaded exact digest; consumer projection ACK",
    "required_domain_fields": [
      "approved_stage",
      "active_policy",
      "loaded_sha",
      "consumer_trace",
      "rollback"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.fabric_activator.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::WO-B1-C1::POS"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L377-L377 excerpt_sha256=a4a31f89aa0ec7651cad79bcf40ecf2fb2bed8f3fe29b358803a4723e4871f48",
    "stimulus": "valid exact current Owner-supplied fixture only"
  },
  "runner_route": "OWNER_REGISTERED::fabric_activator",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-C1-POS",
  "workorder_refs": [
    "WO-B1-C1"
  ]
}
```
- **拒收**：domain `fabric_activator` missing/typed raw absent => HOLD；實際 error `FABRIC_LOADED_ABSENT` 正規化 canonical `FABRIC_LOADED_ABSENT`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-C1-NEG｜FABRIC_PROMOTION / NEG

- **來源刺激**：source_clause=R15.1:L277(W02), R15.1:L277(C02); preconditions=Inject a valid current owned active canonical PolicySource SHA, epoch, signed projection manifest and consuming reader; stimulus=projection file presented as canonical source to HGK APL
```json
{
  "atom_or_gwo": "B1-C1",
  "canonical_first_fail": "FABRIC_LOADED_ABSENT",
  "case_type": "NEG",
  "cross_sibling_acceptance": false,
  "domain": "FABRIC_PROMOTION",
  "effect_class": "HOST_OPERATIONS",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "stage mistaken as active or missing consumer -> FABRIC_LOADED_ABSENT",
    "domain_positive": "independent stage approval; active and loaded exact digest; consumer projection ACK",
    "required_domain_fields": [
      "approved_stage",
      "active_policy",
      "loaded_sha",
      "consumer_trace",
      "rollback"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.fabric_activator.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::WO-B1-C1::NEG"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L378-L378 excerpt_sha256=1bc6280e9e3432c75d1aa09c07e99887c760fe975fe4586724a4f664c77cd51d",
    "stimulus": "projection file presented as canonical source to HGK APL"
  },
  "runner_route": "OWNER_REGISTERED::fabric_activator",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-C1-NEG",
  "workorder_refs": [
    "WO-B1-C1"
  ]
}
```
- **拒收**：domain `fabric_activator` missing/typed raw absent => HOLD；實際 error `FABRIC_REVERSE_PROJECTION_OR_POLICY_EPOCH` 正規化 canonical `FABRIC_LOADED_ABSENT`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-C1-EDGE｜FABRIC_PROMOTION / EDGE

- **來源刺激**：source_clause=R15.1:L277(W02), R15.1:L277(C02); preconditions=Inject a valid current owned active canonical PolicySource SHA, epoch, signed projection manifest and consuming reader; stimulus=policy epoch rotates after projection derivation
```json
{
  "atom_or_gwo": "B1-C1",
  "canonical_first_fail": "FABRIC_LOADED_ABSENT",
  "case_type": "EDGE",
  "cross_sibling_acceptance": false,
  "domain": "FABRIC_PROMOTION",
  "effect_class": "HOST_OPERATIONS",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "stage mistaken as active or missing consumer -> FABRIC_LOADED_ABSENT",
    "domain_positive": "independent stage approval; active and loaded exact digest; consumer projection ACK",
    "required_domain_fields": [
      "approved_stage",
      "active_policy",
      "loaded_sha",
      "consumer_trace",
      "rollback"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.fabric_activator.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::WO-B1-C1::EDGE"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L379-L379 excerpt_sha256=bcf1de90f1743ddc70e7ff73bcd495587e3369fa2dad4bf7016176edc7c4250e",
    "stimulus": "introduce domain-applicable resource/currentness drift, preserve adjacent independent effects"
  },
  "runner_route": "OWNER_REGISTERED::fabric_activator",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-C1-EDGE",
  "workorder_refs": [
    "WO-B1-C1"
  ]
}
```
- **拒收**：domain `fabric_activator` missing/typed raw absent => HOLD；實際 error `FABRIC_REVERSE_PROJECTION_OR_POLICY_EPOCH_EDGE` 正規化 canonical `FABRIC_LOADED_ABSENT`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-C1-SEC｜FABRIC_PROMOTION / SEC

- **來源刺激**：source_clause=R15.1:L277(W02), R15.1:L277(C02); preconditions=Inject a valid current owned active canonical PolicySource SHA, epoch, signed projection manifest and consuming reader; stimulus=unissued policy write from sidecar attempt
```json
{
  "atom_or_gwo": "B1-C1",
  "canonical_first_fail": "FABRIC_LOADED_ABSENT",
  "case_type": "SEC",
  "cross_sibling_acceptance": false,
  "domain": "FABRIC_PROMOTION",
  "effect_class": "HOST_OPERATIONS",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "stage mistaken as active or missing consumer -> FABRIC_LOADED_ABSENT",
    "domain_positive": "independent stage approval; active and loaded exact digest; consumer projection ACK",
    "required_domain_fields": [
      "approved_stage",
      "active_policy",
      "loaded_sha",
      "consumer_trace",
      "rollback"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.fabric_activator.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::WO-B1-C1::SEC"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L380-L380 excerpt_sha256=96128ef4371b155df92f2af71b02942019e703dc49a38c21289da862926915ac",
    "stimulus": "forge/replay this domain credential/subject or cross-swap sibling receipt"
  },
  "runner_route": "OWNER_REGISTERED::fabric_activator",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-C1-SEC",
  "workorder_refs": [
    "WO-B1-C1"
  ]
}
```
- **拒收**：domain `fabric_activator` missing/typed raw absent => HOLD；實際 error `FABRIC_REVERSE_PROJECTION_OR_POLICY_EPOCH_SEC` 正規化 canonical `FABRIC_LOADED_ABSENT`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-C2-POS｜HGK_GWO / POS

- **來源刺激**：source_clause=R15.1:L276(W01), R15.1:L284(W09); preconditions=Inject a valid current owned issued small WO and verified existing native status-health canary schema; stimulus=Provide owner-issued exact-current issued small WO and verified existing native status-health canary schema
```json
{
  "atom_or_gwo": "B1-C2",
  "canonical_first_fail": "GWO_HGK_NOT_NATIVE",
  "case_type": "POS",
  "cross_sibling_acceptance": false,
  "domain": "HGK_GWO",
  "effect_class": "HOST_OPERATIONS",
  "expected_case_verdict": "DOMAIN_POSITIVE_AFTER_REAL_RUN",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "ghost worker/forged permit -> GWO_HGK_NOT_NATIVE",
    "domain_positive": "true SBL entry -> native HGK issuer -> Hermes lease -> reversible observable result",
    "required_domain_fields": [
      "sbl_start",
      "issued_wo",
      "issuer",
      "lease",
      "worker_receipt",
      "readback"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.hgk_native_golden.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::WO-B1-C2::POS"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L381-L381 excerpt_sha256=b8057a065a56a474758cc00e7f0428c19fff386289f0d908e275322f3d9676be",
    "stimulus": "valid exact current Owner-supplied fixture only"
  },
  "runner_route": "OWNER_REGISTERED::hgk_native_golden",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-C2-POS",
  "workorder_refs": [
    "WO-B1-C2"
  ]
}
```
- **拒收**：domain `hgk_native_golden` missing/typed raw absent => HOLD；實際 error `GWO_HGK_NOT_NATIVE` 正規化 canonical `GWO_HGK_NOT_NATIVE`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-C2-NEG｜HGK_GWO / NEG

- **來源刺激**：source_clause=R15.1:L276(W01), R15.1:L284(W09); preconditions=Inject a valid current owned issued small WO and verified existing native status-health canary schema; stimulus=forged permit drives actual worker
```json
{
  "atom_or_gwo": "B1-C2",
  "canonical_first_fail": "GWO_HGK_NOT_NATIVE",
  "case_type": "NEG",
  "cross_sibling_acceptance": false,
  "domain": "HGK_GWO",
  "effect_class": "HOST_OPERATIONS",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "ghost worker/forged permit -> GWO_HGK_NOT_NATIVE",
    "domain_positive": "true SBL entry -> native HGK issuer -> Hermes lease -> reversible observable result",
    "required_domain_fields": [
      "sbl_start",
      "issued_wo",
      "issuer",
      "lease",
      "worker_receipt",
      "readback"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.hgk_native_golden.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::WO-B1-C2::NEG"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L382-L382 excerpt_sha256=40b276bb9a268010e3d6276ec19a25c1b833c9e091f1b12e60e17af196860c00",
    "stimulus": "forged permit drives actual worker"
  },
  "runner_route": "OWNER_REGISTERED::hgk_native_golden",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-C2-NEG",
  "workorder_refs": [
    "WO-B1-C2"
  ]
}
```
- **拒收**：domain `hgk_native_golden` missing/typed raw absent => HOLD；實際 error `HGK_FORGED_PERMIT_OR_GHOST_WORKER` 正規化 canonical `GWO_HGK_NOT_NATIVE`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-C2-EDGE｜HGK_GWO / EDGE

- **來源刺激**：source_clause=R15.1:L276(W01), R15.1:L284(W09); preconditions=Inject a valid current owned issued small WO and verified existing native status-health canary schema; stimulus=reclaim stale generation after native worker crash
```json
{
  "atom_or_gwo": "B1-C2",
  "canonical_first_fail": "GWO_HGK_NOT_NATIVE",
  "case_type": "EDGE",
  "cross_sibling_acceptance": false,
  "domain": "HGK_GWO",
  "effect_class": "HOST_OPERATIONS",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "ghost worker/forged permit -> GWO_HGK_NOT_NATIVE",
    "domain_positive": "true SBL entry -> native HGK issuer -> Hermes lease -> reversible observable result",
    "required_domain_fields": [
      "sbl_start",
      "issued_wo",
      "issuer",
      "lease",
      "worker_receipt",
      "readback"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.hgk_native_golden.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::WO-B1-C2::EDGE"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L383-L383 excerpt_sha256=f3cd0385be841d9b75c0a81c77eab5eb6b650af9d88207a500db4952c538054f",
    "stimulus": "introduce domain-applicable resource/currentness drift, preserve adjacent independent effects"
  },
  "runner_route": "OWNER_REGISTERED::hgk_native_golden",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-C2-EDGE",
  "workorder_refs": [
    "WO-B1-C2"
  ]
}
```
- **拒收**：domain `hgk_native_golden` missing/typed raw absent => HOLD；實際 error `HGK_FORGED_PERMIT_OR_GHOST_WORKER_EDGE` 正規化 canonical `GWO_HGK_NOT_NATIVE`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-C2-SEC｜HGK_GWO / SEC

- **來源刺激**：source_clause=R15.1:L276(W01), R15.1:L284(W09); preconditions=Inject a valid current owned issued small WO and verified existing native status-health canary schema; stimulus=same principal signs both issuer and checker
```json
{
  "atom_or_gwo": "B1-C2",
  "canonical_first_fail": "GWO_HGK_NOT_NATIVE",
  "case_type": "SEC",
  "cross_sibling_acceptance": false,
  "domain": "HGK_GWO",
  "effect_class": "HOST_OPERATIONS",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "ghost worker/forged permit -> GWO_HGK_NOT_NATIVE",
    "domain_positive": "true SBL entry -> native HGK issuer -> Hermes lease -> reversible observable result",
    "required_domain_fields": [
      "sbl_start",
      "issued_wo",
      "issuer",
      "lease",
      "worker_receipt",
      "readback"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.hgk_native_golden.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::WO-B1-C2::SEC"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L384-L384 excerpt_sha256=d148ba6c685fd63457728b9f1863d27433fb237819488853d7bcd802fbc2fd6d",
    "stimulus": "forge/replay this domain credential/subject or cross-swap sibling receipt"
  },
  "runner_route": "OWNER_REGISTERED::hgk_native_golden",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-C2-SEC",
  "workorder_refs": [
    "WO-B1-C2"
  ]
}
```
- **拒收**：domain `hgk_native_golden` missing/typed raw absent => HOLD；實際 error `HGK_FORGED_PERMIT_OR_GHOST_WORKER_SEC` 正規化 canonical `GWO_HGK_NOT_NATIVE`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-C3-POS｜SBL_GWO / POS

- **來源刺激**：source_clause=R15.1:L280(W05), R15.1:L281(W06), R15.1:L282(W07); preconditions=Inject a valid current owned standalone CLI todo task actual input and output fixture; SBL source root and scoped test runner; stimulus=Provide owner-issued exact-current standalone CLI todo task actual input and output fixture; SBL source root and scoped test runner
```json
{
  "atom_or_gwo": "B1-C3",
  "canonical_first_fail": "GWO_SBL_USER_STATE_UNPROVEN",
  "case_type": "POS",
  "cross_sibling_acceptance": false,
  "domain": "SBL_GWO",
  "effect_class": "SPLIT_REQUIRED",
  "expected_case_verdict": "DOMAIN_POSITIVE_AFTER_REAL_RUN",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "install count used as add success -> GWO_SBL_USER_STATE_UNPROVEN",
    "domain_positive": "separate Host install and USER effects with independent readbacks",
    "required_domain_fields": [
      "sbl_entry",
      "stack_install",
      "consent",
      "todo_add",
      "list",
      "delete",
      "uninstall"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.sbl_user_golden.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::WO-B1-C3-OPS::POS",
      "OP::WO-B1-C3-USER::POS"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L385-L385 excerpt_sha256=b1d5390e38b37a7e90bedd599ff01678a512d33c3ea914f304e669490cc0f7e5",
    "stimulus": "valid exact current Owner-supplied fixture only"
  },
  "runner_route": "OWNER_REGISTERED::sbl_user_golden",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": false,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-C3-POS",
  "workorder_refs": [
    "WO-B1-C3-OPS",
    "WO-B1-C3-USER"
  ]
}
```
- **拒收**：domain `sbl_user_golden` missing/typed raw absent => HOLD；實際 error `GWO_SBL_USER_STATE_UNPROVEN` 正規化 canonical `GWO_SBL_USER_STATE_UNPROVEN`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-C3-NEG｜SBL_GWO / NEG

- **來源刺激**：source_clause=R15.1:L280(W05), R15.1:L281(W06), R15.1:L282(W07); preconditions=Inject a valid current owned standalone CLI todo task actual input and output fixture; SBL source root and scoped test runner; stimulus=empty test suite returns green and only README artifact
```json
{
  "atom_or_gwo": "B1-C3",
  "canonical_first_fail": "GWO_SBL_USER_STATE_UNPROVEN",
  "case_type": "NEG",
  "cross_sibling_acceptance": false,
  "domain": "SBL_GWO",
  "effect_class": "SPLIT_REQUIRED",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "install count used as add success -> GWO_SBL_USER_STATE_UNPROVEN",
    "domain_positive": "separate Host install and USER effects with independent readbacks",
    "required_domain_fields": [
      "sbl_entry",
      "stack_install",
      "consent",
      "todo_add",
      "list",
      "delete",
      "uninstall"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.sbl_user_golden.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::WO-B1-C3-OPS::NEG",
      "OP::WO-B1-C3-USER::NEG"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L386-L386 excerpt_sha256=64e9d331a215406918437d6c98a66e6561d94f5605da8c4364abe2c879a984b2",
    "stimulus": "empty test suite returns green and only README artifact"
  },
  "runner_route": "OWNER_REGISTERED::sbl_user_golden",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": false,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-C3-NEG",
  "workorder_refs": [
    "WO-B1-C3-OPS",
    "WO-B1-C3-USER"
  ]
}
```
- **拒收**：domain `sbl_user_golden` missing/typed raw absent => HOLD；實際 error `SBL_EMPTY_TEST_OR_NO_USER_OUTCOME` 正規化 canonical `GWO_SBL_USER_STATE_UNPROVEN`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-C3-EDGE｜SBL_GWO / EDGE

- **來源刺激**：source_clause=R15.1:L280(W05), R15.1:L281(W06), R15.1:L282(W07); preconditions=Inject a valid current owned standalone CLI todo task actual input and output fixture; SBL source root and scoped test runner; stimulus=provider-off during test invokes host
```json
{
  "atom_or_gwo": "B1-C3",
  "canonical_first_fail": "GWO_SBL_USER_STATE_UNPROVEN",
  "case_type": "EDGE",
  "cross_sibling_acceptance": false,
  "domain": "SBL_GWO",
  "effect_class": "SPLIT_REQUIRED",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "install count used as add success -> GWO_SBL_USER_STATE_UNPROVEN",
    "domain_positive": "separate Host install and USER effects with independent readbacks",
    "required_domain_fields": [
      "sbl_entry",
      "stack_install",
      "consent",
      "todo_add",
      "list",
      "delete",
      "uninstall"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.sbl_user_golden.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::WO-B1-C3-OPS::EDGE",
      "OP::WO-B1-C3-USER::EDGE"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L387-L387 excerpt_sha256=35b32c89b82428999327788148bb75141374012c4f8aca987e001cfb2364d732",
    "stimulus": "introduce domain-applicable resource/currentness drift, preserve adjacent independent effects"
  },
  "runner_route": "OWNER_REGISTERED::sbl_user_golden",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": false,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-C3-EDGE",
  "workorder_refs": [
    "WO-B1-C3-OPS",
    "WO-B1-C3-USER"
  ]
}
```
- **拒收**：domain `sbl_user_golden` missing/typed raw absent => HOLD；實際 error `SBL_EMPTY_TEST_OR_NO_USER_OUTCOME_EDGE` 正規化 canonical `GWO_SBL_USER_STATE_UNPROVEN`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-C3-SEC｜SBL_GWO / SEC

- **來源刺激**：source_clause=R15.1:L280(W05), R15.1:L281(W06), R15.1:L282(W07); preconditions=Inject a valid current owned standalone CLI todo task actual input and output fixture; SBL source root and scoped test runner; stimulus=out-of-scope process reads private home path
```json
{
  "atom_or_gwo": "B1-C3",
  "canonical_first_fail": "GWO_SBL_USER_STATE_UNPROVEN",
  "case_type": "SEC",
  "cross_sibling_acceptance": false,
  "domain": "SBL_GWO",
  "effect_class": "SPLIT_REQUIRED",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "install count used as add success -> GWO_SBL_USER_STATE_UNPROVEN",
    "domain_positive": "separate Host install and USER effects with independent readbacks",
    "required_domain_fields": [
      "sbl_entry",
      "stack_install",
      "consent",
      "todo_add",
      "list",
      "delete",
      "uninstall"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.sbl_user_golden.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::WO-B1-C3-OPS::SEC",
      "OP::WO-B1-C3-USER::SEC"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L388-L388 excerpt_sha256=f63d74536cc260d526a410cf9071f6d14931e68a009dae20e6f0b6d73b54ffeb",
    "stimulus": "forge/replay this domain credential/subject or cross-swap sibling receipt"
  },
  "runner_route": "OWNER_REGISTERED::sbl_user_golden",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": false,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-C3-SEC",
  "workorder_refs": [
    "WO-B1-C3-OPS",
    "WO-B1-C3-USER"
  ]
}
```
- **拒收**：domain `sbl_user_golden` missing/typed raw absent => HOLD；實際 error `SBL_EMPTY_TEST_OR_NO_USER_OUTCOME_SEC` 正規化 canonical `GWO_SBL_USER_STATE_UNPROVEN`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-C4-POS｜EXTERNAL_GRANT / POS

- **來源刺激**：source_clause=R17v05:S2-14; preconditions=Inject a valid current owned signed grant with immutable maker principal, permitted root/writepaths, ttl and first-fail seed; stimulus=Provide owner-issued exact-current signed grant with immutable maker principal, permitted root/writepaths, ttl and first-fail seed
```json
{
  "atom_or_gwo": "B1-C4",
  "canonical_first_fail": "EXTERNAL_SCOPE_ESCAPED",
  "case_type": "POS",
  "cross_sibling_acceptance": false,
  "domain": "EXTERNAL_GRANT",
  "effect_class": "HOST_OPERATIONS",
  "expected_case_verdict": "DOMAIN_POSITIVE_AFTER_REAL_RUN",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "scope expansion -> EXTERNAL_SCOPE_ESCAPED",
    "domain_positive": "bounded external grant and no residual capability on revoke",
    "required_domain_fields": [
      "owner_scope",
      "ttl",
      "principal",
      "revocation",
      "zero_scope_escape"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.delegation.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::WO-B1-C4::POS"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L389-L389 excerpt_sha256=492de47bcb200b92aab530c3d966f755eabb4e1b87d0c78cbb6a971654210c41",
    "stimulus": "valid exact current Owner-supplied fixture only"
  },
  "runner_route": "OWNER_REGISTERED::delegation",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-C4-POS",
  "workorder_refs": [
    "WO-B1-C4"
  ]
}
```
- **拒收**：domain `delegation` missing/typed raw absent => HOLD；實際 error `EXTERNAL_SCOPE_ESCAPED` 正規化 canonical `EXTERNAL_SCOPE_ESCAPED`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-C4-NEG｜EXTERNAL_GRANT / NEG

- **來源刺激**：source_clause=R17v05:S2-14; preconditions=Inject a valid current owned signed grant with immutable maker principal, permitted root/writepaths, ttl and first-fail seed; stimulus=expired grant still schedules new work
```json
{
  "atom_or_gwo": "B1-C4",
  "canonical_first_fail": "EXTERNAL_SCOPE_ESCAPED",
  "case_type": "NEG",
  "cross_sibling_acceptance": false,
  "domain": "EXTERNAL_GRANT",
  "effect_class": "HOST_OPERATIONS",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "scope expansion -> EXTERNAL_SCOPE_ESCAPED",
    "domain_positive": "bounded external grant and no residual capability on revoke",
    "required_domain_fields": [
      "owner_scope",
      "ttl",
      "principal",
      "revocation",
      "zero_scope_escape"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.delegation.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::WO-B1-C4::NEG"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L390-L390 excerpt_sha256=3fd6afba83462171fe0b54003fc5882b8ca4b048580cef7224909d3641885c35",
    "stimulus": "expired grant still schedules new work"
  },
  "runner_route": "OWNER_REGISTERED::delegation",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-C4-NEG",
  "workorder_refs": [
    "WO-B1-C4"
  ]
}
```
- **拒收**：domain `delegation` missing/typed raw absent => HOLD；實際 error `EXTERNAL_GRANT_SCOPE_OR_TTL` 正規化 canonical `EXTERNAL_SCOPE_ESCAPED`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-C4-EDGE｜EXTERNAL_GRANT / EDGE

- **來源刺激**：source_clause=R17v05:S2-14; preconditions=Inject a valid current owned signed grant with immutable maker principal, permitted root/writepaths, ttl and first-fail seed; stimulus=external task attempts second root inside declared root alias
```json
{
  "atom_or_gwo": "B1-C4",
  "canonical_first_fail": "EXTERNAL_SCOPE_ESCAPED",
  "case_type": "EDGE",
  "cross_sibling_acceptance": false,
  "domain": "EXTERNAL_GRANT",
  "effect_class": "HOST_OPERATIONS",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "scope expansion -> EXTERNAL_SCOPE_ESCAPED",
    "domain_positive": "bounded external grant and no residual capability on revoke",
    "required_domain_fields": [
      "owner_scope",
      "ttl",
      "principal",
      "revocation",
      "zero_scope_escape"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.delegation.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::WO-B1-C4::EDGE"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L391-L391 excerpt_sha256=d0007d8ba36eaa9e4e3ad191c0651b71af9206b58e356a57745c19f4abbb08ea",
    "stimulus": "introduce domain-applicable resource/currentness drift, preserve adjacent independent effects"
  },
  "runner_route": "OWNER_REGISTERED::delegation",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-C4-EDGE",
  "workorder_refs": [
    "WO-B1-C4"
  ]
}
```
- **拒收**：domain `delegation` missing/typed raw absent => HOLD；實際 error `EXTERNAL_GRANT_SCOPE_OR_TTL_EDGE` 正規化 canonical `EXTERNAL_SCOPE_ESCAPED`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-C4-SEC｜EXTERNAL_GRANT / SEC

- **來源刺激**：source_clause=R17v05:S2-14; preconditions=Inject a valid current owned signed grant with immutable maker principal, permitted root/writepaths, ttl and first-fail seed; stimulus=grant includes unlisted credential-bearing folder
```json
{
  "atom_or_gwo": "B1-C4",
  "canonical_first_fail": "EXTERNAL_SCOPE_ESCAPED",
  "case_type": "SEC",
  "cross_sibling_acceptance": false,
  "domain": "EXTERNAL_GRANT",
  "effect_class": "HOST_OPERATIONS",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "scope expansion -> EXTERNAL_SCOPE_ESCAPED",
    "domain_positive": "bounded external grant and no residual capability on revoke",
    "required_domain_fields": [
      "owner_scope",
      "ttl",
      "principal",
      "revocation",
      "zero_scope_escape"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.delegation.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::WO-B1-C4::SEC"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L392-L392 excerpt_sha256=a1c5896727a26b0b2d7882ed483ceba4196a82b669f0f9bae605edb556a71d3a",
    "stimulus": "forge/replay this domain credential/subject or cross-swap sibling receipt"
  },
  "runner_route": "OWNER_REGISTERED::delegation",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-C4-SEC",
  "workorder_refs": [
    "WO-B1-C4"
  ]
}
```
- **拒收**：domain `delegation` missing/typed raw absent => HOLD；實際 error `EXTERNAL_GRANT_SCOPE_OR_TTL_SEC` 正規化 canonical `EXTERNAL_SCOPE_ESCAPED`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-C5-POS｜CODEX_MINPATCH / POS

- **來源刺激**：source_clause=R15.1:L282(W07); preconditions=Inject a valid current owned chosen tracked hotpath, exact preimage SHA, recorded original RED and repair diff proposal; stimulus=Provide owner-issued exact-current chosen tracked hotpath, exact preimage SHA, recorded original RED and repair diff proposal
```json
{
  "atom_or_gwo": "B1-C5",
  "canonical_first_fail": "UNBOUNDED_PATCH_OR_REGRESSION",
  "case_type": "POS",
  "cross_sibling_acceptance": false,
  "domain": "CODEX_MINPATCH",
  "effect_class": "REPOSITORY_WRITE",
  "expected_case_verdict": "DOMAIN_POSITIVE_AFTER_REAL_RUN",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "checker edits same diff or no red test -> UNBOUNDED_PATCH_OR_REGRESSION",
    "domain_positive": "only affected files changed and full regression independent",
    "required_domain_fields": [
      "write_scope",
      "preimage",
      "red_test",
      "patch",
      "green_test",
      "checker"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.bounded_coding.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::WO-B1-C5::POS"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L393-L393 excerpt_sha256=e4b0e77186829bf4b4b29b8c7dc2f578cc8f56205f6cf0e5cb3777e32c91fc3f",
    "stimulus": "valid exact current Owner-supplied fixture only"
  },
  "runner_route": "OWNER_REGISTERED::bounded_coding",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-C5-POS",
  "workorder_refs": [
    "WO-B1-C5"
  ]
}
```
- **拒收**：domain `bounded_coding` missing/typed raw absent => HOLD；實際 error `UNBOUNDED_PATCH_OR_REGRESSION` 正規化 canonical `UNBOUNDED_PATCH_OR_REGRESSION`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-C5-NEG｜CODEX_MINPATCH / NEG

- **來源刺激**：source_clause=R15.1:L282(W07); preconditions=Inject a valid current owned chosen tracked hotpath, exact preimage SHA, recorded original RED and repair diff proposal; stimulus=patches file based on historical truncated SHA without native readback
```json
{
  "atom_or_gwo": "B1-C5",
  "canonical_first_fail": "UNBOUNDED_PATCH_OR_REGRESSION",
  "case_type": "NEG",
  "cross_sibling_acceptance": false,
  "domain": "CODEX_MINPATCH",
  "effect_class": "REPOSITORY_WRITE",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "checker edits same diff or no red test -> UNBOUNDED_PATCH_OR_REGRESSION",
    "domain_positive": "only affected files changed and full regression independent",
    "required_domain_fields": [
      "write_scope",
      "preimage",
      "red_test",
      "patch",
      "green_test",
      "checker"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.bounded_coding.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::WO-B1-C5::NEG"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L394-L394 excerpt_sha256=b7425abbcb7ea5eb61b462e4ce3e9b6742d87dce0c30a1abb61a9491fed22874",
    "stimulus": "patches file based on historical truncated SHA without native readback"
  },
  "runner_route": "OWNER_REGISTERED::bounded_coding",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-C5-NEG",
  "workorder_refs": [
    "WO-B1-C5"
  ]
}
```
- **拒收**：domain `bounded_coding` missing/typed raw absent => HOLD；實際 error `CODEX_UNMEASURED_PATCH_OR_CHECKER_MUTATION` 正規化 canonical `UNBOUNDED_PATCH_OR_REGRESSION`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-C5-EDGE｜CODEX_MINPATCH / EDGE

- **來源刺激**：source_clause=R15.1:L282(W07); preconditions=Inject a valid current owned chosen tracked hotpath, exact preimage SHA, recorded original RED and repair diff proposal; stimulus=hotpath moved, old path still green in isolated pytest
```json
{
  "atom_or_gwo": "B1-C5",
  "canonical_first_fail": "UNBOUNDED_PATCH_OR_REGRESSION",
  "case_type": "EDGE",
  "cross_sibling_acceptance": false,
  "domain": "CODEX_MINPATCH",
  "effect_class": "REPOSITORY_WRITE",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "checker edits same diff or no red test -> UNBOUNDED_PATCH_OR_REGRESSION",
    "domain_positive": "only affected files changed and full regression independent",
    "required_domain_fields": [
      "write_scope",
      "preimage",
      "red_test",
      "patch",
      "green_test",
      "checker"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.bounded_coding.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::WO-B1-C5::EDGE"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L395-L395 excerpt_sha256=b59c6fc634fc18eb5050645537fdf28128a8ce6a1930029ae8ebc9838a529a53",
    "stimulus": "introduce domain-applicable resource/currentness drift, preserve adjacent independent effects"
  },
  "runner_route": "OWNER_REGISTERED::bounded_coding",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-C5-EDGE",
  "workorder_refs": [
    "WO-B1-C5"
  ]
}
```
- **拒收**：domain `bounded_coding` missing/typed raw absent => HOLD；實際 error `CODEX_UNMEASURED_PATCH_OR_CHECKER_MUTATION_EDGE` 正規化 canonical `UNBOUNDED_PATCH_OR_REGRESSION`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-C5-SEC｜CODEX_MINPATCH / SEC

- **來源刺激**：source_clause=R15.1:L282(W07); preconditions=Inject a valid current owned chosen tracked hotpath, exact preimage SHA, recorded original RED and repair diff proposal; stimulus=Codex edits immutable checker/oracle to make green
```json
{
  "atom_or_gwo": "B1-C5",
  "canonical_first_fail": "UNBOUNDED_PATCH_OR_REGRESSION",
  "case_type": "SEC",
  "cross_sibling_acceptance": false,
  "domain": "CODEX_MINPATCH",
  "effect_class": "REPOSITORY_WRITE",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "checker edits same diff or no red test -> UNBOUNDED_PATCH_OR_REGRESSION",
    "domain_positive": "only affected files changed and full regression independent",
    "required_domain_fields": [
      "write_scope",
      "preimage",
      "red_test",
      "patch",
      "green_test",
      "checker"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.bounded_coding.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::WO-B1-C5::SEC"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L396-L396 excerpt_sha256=14daca32d065bc2abe93cabb3e46aca055ef38e54ff2c969f87878fcff27bc37",
    "stimulus": "forge/replay this domain credential/subject or cross-swap sibling receipt"
  },
  "runner_route": "OWNER_REGISTERED::bounded_coding",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-C5-SEC",
  "workorder_refs": [
    "WO-B1-C5"
  ]
}
```
- **拒收**：domain `bounded_coding` missing/typed raw absent => HOLD；實際 error `CODEX_UNMEASURED_PATCH_OR_CHECKER_MUTATION_SEC` 正規化 canonical `UNBOUNDED_PATCH_OR_REGRESSION`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-C6-POS｜REVOKE_RACE / POS

- **來源刺激**：source_clause=PIPD05:Admission; preconditions=Inject a valid current owned grant ledger, external runner identity, active sessions and all scoped tokens; stimulus=Provide owner-issued exact-current grant ledger, external runner identity, active sessions and all scoped tokens
```json
{
  "atom_or_gwo": "B1-C6",
  "canonical_first_fail": "REVOKED_TOKEN_REPLAY",
  "case_type": "POS",
  "cross_sibling_acceptance": false,
  "domain": "REVOKE_RACE",
  "effect_class": "HOST_OPERATIONS",
  "expected_case_verdict": "DOMAIN_POSITIVE_AFTER_REAL_RUN",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "reused token after revoke -> REVOKED_TOKEN_REPLAY",
    "domain_positive": "post-revoke use fails before spawn; existing effects reconciled",
    "required_domain_fields": [
      "old_nonce",
      "revocation_epoch",
      "attempt_after_revoke",
      "denied_effect"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.revoke_boundary.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::WO-B1-C6::POS"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L397-L397 excerpt_sha256=f92d47efed34f1b04bafd8b67b9f3420f92fabb14499c8d12ec21c5bfa14b87d",
    "stimulus": "valid exact current Owner-supplied fixture only"
  },
  "runner_route": "OWNER_REGISTERED::revoke_boundary",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-C6-POS",
  "workorder_refs": [
    "WO-B1-C6"
  ]
}
```
- **拒收**：domain `revoke_boundary` missing/typed raw absent => HOLD；實際 error `REVOKED_TOKEN_REPLAY` 正規化 canonical `REVOKED_TOKEN_REPLAY`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-C6-NEG｜REVOKE_RACE / NEG

- **來源刺激**：source_clause=PIPD05:Admission; preconditions=Inject a valid current owned grant ledger, external runner identity, active sessions and all scoped tokens; stimulus=expired grant token still accepted in new dispatch
```json
{
  "atom_or_gwo": "B1-C6",
  "canonical_first_fail": "REVOKED_TOKEN_REPLAY",
  "case_type": "NEG",
  "cross_sibling_acceptance": false,
  "domain": "REVOKE_RACE",
  "effect_class": "HOST_OPERATIONS",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "reused token after revoke -> REVOKED_TOKEN_REPLAY",
    "domain_positive": "post-revoke use fails before spawn; existing effects reconciled",
    "required_domain_fields": [
      "old_nonce",
      "revocation_epoch",
      "attempt_after_revoke",
      "denied_effect"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.revoke_boundary.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::WO-B1-C6::NEG"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L398-L398 excerpt_sha256=4f538765cc2013181e3748df20bfcc8c558df073d96fad9d4d8556c6877fc680",
    "stimulus": "expired grant token still accepted in new dispatch"
  },
  "runner_route": "OWNER_REGISTERED::revoke_boundary",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-C6-NEG",
  "workorder_refs": [
    "WO-B1-C6"
  ]
}
```
- **拒收**：domain `revoke_boundary` missing/typed raw absent => HOLD；實際 error `POST_REVOKE_TOKEN_REPLAY` 正規化 canonical `REVOKED_TOKEN_REPLAY`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-C6-EDGE｜REVOKE_RACE / EDGE

- **來源刺激**：source_clause=PIPD05:Admission; preconditions=Inject a valid current owned grant ledger, external runner identity, active sessions and all scoped tokens; stimulus=inflight pre-revoke operation has UNKNOWN_EFFECT
```json
{
  "atom_or_gwo": "B1-C6",
  "canonical_first_fail": "REVOKED_TOKEN_REPLAY",
  "case_type": "EDGE",
  "cross_sibling_acceptance": false,
  "domain": "REVOKE_RACE",
  "effect_class": "HOST_OPERATIONS",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "reused token after revoke -> REVOKED_TOKEN_REPLAY",
    "domain_positive": "post-revoke use fails before spawn; existing effects reconciled",
    "required_domain_fields": [
      "old_nonce",
      "revocation_epoch",
      "attempt_after_revoke",
      "denied_effect"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.revoke_boundary.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::WO-B1-C6::EDGE"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L399-L399 excerpt_sha256=471791a2acf34e5dc1bd5fb0bbd26bce77ad05832f78d362e5fe3f48b75b7dde",
    "stimulus": "introduce domain-applicable resource/currentness drift, preserve adjacent independent effects"
  },
  "runner_route": "OWNER_REGISTERED::revoke_boundary",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-C6-EDGE",
  "workorder_refs": [
    "WO-B1-C6"
  ]
}
```
- **拒收**：domain `revoke_boundary` missing/typed raw absent => HOLD；實際 error `POST_REVOKE_TOKEN_REPLAY_EDGE` 正規化 canonical `REVOKED_TOKEN_REPLAY`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-C6-SEC｜REVOKE_RACE / SEC

- **來源刺激**：source_clause=PIPD05:Admission; preconditions=Inject a valid current owned grant ledger, external runner identity, active sessions and all scoped tokens; stimulus=revoked privilege can create successor under alternate alias
```json
{
  "atom_or_gwo": "B1-C6",
  "canonical_first_fail": "REVOKED_TOKEN_REPLAY",
  "case_type": "SEC",
  "cross_sibling_acceptance": false,
  "domain": "REVOKE_RACE",
  "effect_class": "HOST_OPERATIONS",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "reused token after revoke -> REVOKED_TOKEN_REPLAY",
    "domain_positive": "post-revoke use fails before spawn; existing effects reconciled",
    "required_domain_fields": [
      "old_nonce",
      "revocation_epoch",
      "attempt_after_revoke",
      "denied_effect"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.revoke_boundary.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::WO-B1-C6::SEC"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L400-L400 excerpt_sha256=aaeddc13a8a2125acb9aa6ea5417aa43cecb134f9acf6ec7a77a2fb69f3ae3cd",
    "stimulus": "forge/replay this domain credential/subject or cross-swap sibling receipt"
  },
  "runner_route": "OWNER_REGISTERED::revoke_boundary",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-C6-SEC",
  "workorder_refs": [
    "WO-B1-C6"
  ]
}
```
- **拒收**：domain `revoke_boundary` missing/typed raw absent => HOLD；實際 error `POST_REVOKE_TOKEN_REPLAY_SEC` 正規化 canonical `REVOKED_TOKEN_REPLAY`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-C7-POS｜FOUR_LAYER_ID / POS

- **來源刺激**：source_clause=R15.1:L283(W08), R15.1:L284(W09); preconditions=Inject a valid current owned patched code head, installed binary hash, loaded process hash, receiver instance SHA; stimulus=Provide owner-issued exact-current patched code head, installed binary hash, loaded process hash, receiver instance SHA
```json
{
  "atom_or_gwo": "B1-C7",
  "canonical_first_fail": "LOADED_BINARY_MISMATCH",
  "case_type": "POS",
  "cross_sibling_acceptance": false,
  "domain": "FOUR_LAYER_ID",
  "effect_class": "READ_ONLY_PROBE",
  "expected_case_verdict": "DOMAIN_POSITIVE_AFTER_REAL_RUN",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "green patch with stale loaded binary -> LOADED_BINARY_MISMATCH",
    "domain_positive": "all four identity layers tied to same subject, not merely file on disk",
    "required_domain_fields": [
      "source_sha",
      "installed_binary_sha",
      "host_loaded_sha",
      "served_model",
      "policy_epoch"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.loaded_identity.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::OBS-B1-C7::POS"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L401-L401 excerpt_sha256=3b03853e2a47695d1828316035e44f7ebd8c0e16c56a04e0295c2b1cd19af552",
    "stimulus": "valid exact current Owner-supplied fixture only"
  },
  "runner_route": "OWNER_REGISTERED::loaded_identity",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-C7-POS",
  "workorder_refs": [
    "OBS-B1-C7"
  ]
}
```
- **拒收**：domain `loaded_identity` missing/typed raw absent => HOLD；實際 error `LOADED_BINARY_MISMATCH` 正規化 canonical `LOADED_BINARY_MISMATCH`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-C7-NEG｜FOUR_LAYER_ID / NEG

- **來源刺激**：source_clause=R15.1:L283(W08), R15.1:L284(W09); preconditions=Inject a valid current owned patched code head, installed binary hash, loaded process hash, receiver instance SHA; stimulus=green unit tests but running service unchanged
```json
{
  "atom_or_gwo": "B1-C7",
  "canonical_first_fail": "LOADED_BINARY_MISMATCH",
  "case_type": "NEG",
  "cross_sibling_acceptance": false,
  "domain": "FOUR_LAYER_ID",
  "effect_class": "READ_ONLY_PROBE",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "green patch with stale loaded binary -> LOADED_BINARY_MISMATCH",
    "domain_positive": "all four identity layers tied to same subject, not merely file on disk",
    "required_domain_fields": [
      "source_sha",
      "installed_binary_sha",
      "host_loaded_sha",
      "served_model",
      "policy_epoch"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.loaded_identity.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::OBS-B1-C7::NEG"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L402-L402 excerpt_sha256=7f0f8374da91c3df6d8d753ad3def5458f38c8fff2af02bc101ca95b38e0268f",
    "stimulus": "green unit tests but running service unchanged"
  },
  "runner_route": "OWNER_REGISTERED::loaded_identity",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-C7-NEG",
  "workorder_refs": [
    "OBS-B1-C7"
  ]
}
```
- **拒收**：domain `loaded_identity` missing/typed raw absent => HOLD；實際 error `PATCH_GREEN_NOT_LOADED` 正規化 canonical `LOADED_BINARY_MISMATCH`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-C7-EDGE｜FOUR_LAYER_ID / EDGE

- **來源刺激**：source_clause=R15.1:L283(W08), R15.1:L284(W09); preconditions=Inject a valid current owned patched code head, installed binary hash, loaded process hash, receiver instance SHA; stimulus=old process stays resident after new binaries installed
```json
{
  "atom_or_gwo": "B1-C7",
  "canonical_first_fail": "LOADED_BINARY_MISMATCH",
  "case_type": "EDGE",
  "cross_sibling_acceptance": false,
  "domain": "FOUR_LAYER_ID",
  "effect_class": "READ_ONLY_PROBE",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "green patch with stale loaded binary -> LOADED_BINARY_MISMATCH",
    "domain_positive": "all four identity layers tied to same subject, not merely file on disk",
    "required_domain_fields": [
      "source_sha",
      "installed_binary_sha",
      "host_loaded_sha",
      "served_model",
      "policy_epoch"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.loaded_identity.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::OBS-B1-C7::EDGE"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L403-L403 excerpt_sha256=2db4685d41b59a9d77f764e5cfc218cf60cd9d29df5954b84fdd4763c89bcad4",
    "stimulus": "introduce domain-applicable resource/currentness drift, preserve adjacent independent effects"
  },
  "runner_route": "OWNER_REGISTERED::loaded_identity",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-C7-EDGE",
  "workorder_refs": [
    "OBS-B1-C7"
  ]
}
```
- **拒收**：domain `loaded_identity` missing/typed raw absent => HOLD；實際 error `PATCH_GREEN_NOT_LOADED_EDGE` 正規化 canonical `LOADED_BINARY_MISMATCH`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-C7-SEC｜FOUR_LAYER_ID / SEC

- **來源刺激**：source_clause=R15.1:L283(W08), R15.1:L284(W09); preconditions=Inject a valid current owned patched code head, installed binary hash, loaded process hash, receiver instance SHA; stimulus=fake loaded SHA supplied by proposed SBL bridge
```json
{
  "atom_or_gwo": "B1-C7",
  "canonical_first_fail": "LOADED_BINARY_MISMATCH",
  "case_type": "SEC",
  "cross_sibling_acceptance": false,
  "domain": "FOUR_LAYER_ID",
  "effect_class": "READ_ONLY_PROBE",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "green patch with stale loaded binary -> LOADED_BINARY_MISMATCH",
    "domain_positive": "all four identity layers tied to same subject, not merely file on disk",
    "required_domain_fields": [
      "source_sha",
      "installed_binary_sha",
      "host_loaded_sha",
      "served_model",
      "policy_epoch"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.loaded_identity.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::OBS-B1-C7::SEC"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L404-L404 excerpt_sha256=f0a23e9181f13aac121f5ba1245323e8eef1dbd41a7e67185e22e0cc3c429dc4",
    "stimulus": "forge/replay this domain credential/subject or cross-swap sibling receipt"
  },
  "runner_route": "OWNER_REGISTERED::loaded_identity",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-C7-SEC",
  "workorder_refs": [
    "OBS-B1-C7"
  ]
}
```
- **拒收**：domain `loaded_identity` missing/typed raw absent => HOLD；實際 error `PATCH_GREEN_NOT_LOADED_SEC` 正規化 canonical `LOADED_BINARY_MISMATCH`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-C8-POS｜NATIVE_SUCCESSOR / POS

- **來源刺激**：source_clause=R17v05:S2-17; preconditions=Inject a valid current owned sealed external STOP and Native-only scheduler trigger with new work identity; stimulus=Provide owner-issued exact-current sealed external STOP and Native-only scheduler trigger with new work identity
```json
{
  "atom_or_gwo": "B1-C8",
  "canonical_first_fail": "NATIVE_SUCCESSOR_NOT_PROVEN",
  "case_type": "POS",
  "cross_sibling_acceptance": false,
  "domain": "NATIVE_SUCCESSOR",
  "effect_class": "HOST_OPERATIONS",
  "expected_case_verdict": "DOMAIN_POSITIVE_AFTER_REAL_RUN",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "successor still external-triggered -> NATIVE_SUCCESSOR_NOT_PROVEN",
    "domain_positive": "fresh separate session native trigger progresses after external account revoked",
    "required_domain_fields": [
      "external_stop",
      "ledger_cursor",
      "issuer",
      "successor_wo",
      "native_origin"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.post_revoke_successor.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::WO-B1-C8::POS"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L405-L405 excerpt_sha256=8034a4439e0ff7f858f200f7ddfb94ae18047cea068fc660c174e49bc06d100b",
    "stimulus": "valid exact current Owner-supplied fixture only"
  },
  "runner_route": "OWNER_REGISTERED::post_revoke_successor",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-C8-POS",
  "workorder_refs": [
    "WO-B1-C8"
  ]
}
```
- **拒收**：domain `post_revoke_successor` missing/typed raw absent => HOLD；實際 error `NATIVE_SUCCESSOR_NOT_PROVEN` 正規化 canonical `NATIVE_SUCCESSOR_NOT_PROVEN`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-C8-NEG｜NATIVE_SUCCESSOR / NEG

- **來源刺激**：source_clause=R17v05:S2-17; preconditions=Inject a valid current owned sealed external STOP and Native-only scheduler trigger with new work identity; stimulus=external Codex script supplies supposedly autonomous next WO
```json
{
  "atom_or_gwo": "B1-C8",
  "canonical_first_fail": "NATIVE_SUCCESSOR_NOT_PROVEN",
  "case_type": "NEG",
  "cross_sibling_acceptance": false,
  "domain": "NATIVE_SUCCESSOR",
  "effect_class": "HOST_OPERATIONS",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "successor still external-triggered -> NATIVE_SUCCESSOR_NOT_PROVEN",
    "domain_positive": "fresh separate session native trigger progresses after external account revoked",
    "required_domain_fields": [
      "external_stop",
      "ledger_cursor",
      "issuer",
      "successor_wo",
      "native_origin"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.post_revoke_successor.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::WO-B1-C8::NEG"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L406-L406 excerpt_sha256=fff2d7017cf828a49f6675d08e3de6293664d58c0140f34bded59a24c6a3654c",
    "stimulus": "external Codex script supplies supposedly autonomous next WO"
  },
  "runner_route": "OWNER_REGISTERED::post_revoke_successor",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-C8-NEG",
  "workorder_refs": [
    "WO-B1-C8"
  ]
}
```
- **拒收**：domain `post_revoke_successor` missing/typed raw absent => HOLD；實際 error `NATIVE_SUCCESSOR_NOT_AUTONOMOUS` 正規化 canonical `NATIVE_SUCCESSOR_NOT_PROVEN`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-C8-EDGE｜NATIVE_SUCCESSOR / EDGE

- **來源刺激**：source_clause=R17v05:S2-17; preconditions=Inject a valid current owned sealed external STOP and Native-only scheduler trigger with new work identity; stimulus=queue de-duplicates next task into stale external card
```json
{
  "atom_or_gwo": "B1-C8",
  "canonical_first_fail": "NATIVE_SUCCESSOR_NOT_PROVEN",
  "case_type": "EDGE",
  "cross_sibling_acceptance": false,
  "domain": "NATIVE_SUCCESSOR",
  "effect_class": "HOST_OPERATIONS",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "successor still external-triggered -> NATIVE_SUCCESSOR_NOT_PROVEN",
    "domain_positive": "fresh separate session native trigger progresses after external account revoked",
    "required_domain_fields": [
      "external_stop",
      "ledger_cursor",
      "issuer",
      "successor_wo",
      "native_origin"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.post_revoke_successor.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::WO-B1-C8::EDGE"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L407-L407 excerpt_sha256=b29ce02c9c59141cd9b68694401b2759a3cac019386a94e119a13f95d4bdc645",
    "stimulus": "introduce domain-applicable resource/currentness drift, preserve adjacent independent effects"
  },
  "runner_route": "OWNER_REGISTERED::post_revoke_successor",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-C8-EDGE",
  "workorder_refs": [
    "WO-B1-C8"
  ]
}
```
- **拒收**：domain `post_revoke_successor` missing/typed raw absent => HOLD；實際 error `NATIVE_SUCCESSOR_NOT_AUTONOMOUS_EDGE` 正規化 canonical `NATIVE_SUCCESSOR_NOT_PROVEN`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-C8-SEC｜NATIVE_SUCCESSOR / SEC

- **來源刺激**：source_clause=R17v05:S2-17; preconditions=Inject a valid current owned sealed external STOP and Native-only scheduler trigger with new work identity; stimulus=external token remains runnable as shadow webhook
```json
{
  "atom_or_gwo": "B1-C8",
  "canonical_first_fail": "NATIVE_SUCCESSOR_NOT_PROVEN",
  "case_type": "SEC",
  "cross_sibling_acceptance": false,
  "domain": "NATIVE_SUCCESSOR",
  "effect_class": "HOST_OPERATIONS",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "successor still external-triggered -> NATIVE_SUCCESSOR_NOT_PROVEN",
    "domain_positive": "fresh separate session native trigger progresses after external account revoked",
    "required_domain_fields": [
      "external_stop",
      "ledger_cursor",
      "issuer",
      "successor_wo",
      "native_origin"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.post_revoke_successor.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::WO-B1-C8::SEC"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L408-L408 excerpt_sha256=39c93fc52387ccc2f4b64c2f9ac834159877dbd8a9dd49e5fa038fd20330210e",
    "stimulus": "forge/replay this domain credential/subject or cross-swap sibling receipt"
  },
  "runner_route": "OWNER_REGISTERED::post_revoke_successor",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-C8-SEC",
  "workorder_refs": [
    "WO-B1-C8"
  ]
}
```
- **拒收**：domain `post_revoke_successor` missing/typed raw absent => HOLD；實際 error `NATIVE_SUCCESSOR_NOT_AUTONOMOUS_SEC` 正規化 canonical `NATIVE_SUCCESSOR_NOT_PROVEN`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-C9-POS｜TRIPLE_GWO / POS

- **來源刺激**：source_clause=R15.1:L279(C05), R15.1:L289(C24); preconditions=Inject a valid current owned Fabric/HGK/SBL separate candidate hashes, raw receipt and independent checker actor; stimulus=Provide owner-issued exact-current Fabric/HGK/SBL separate candidate hashes, raw receipt and independent checker actor
```json
{
  "atom_or_gwo": "B1-C9",
  "canonical_first_fail": "GWO_RECEIPT_ALIAS",
  "case_type": "POS",
  "cross_sibling_acceptance": false,
  "domain": "TRIPLE_GWO",
  "effect_class": "READ_ONLY_PROBE",
  "expected_case_verdict": "DOMAIN_POSITIVE_AFTER_REAL_RUN",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "same receipt reused -> GWO_RECEIPT_ALIAS",
    "domain_positive": "3 different domain receipts, all same intended crosswalk, not aliases",
    "required_domain_fields": [
      "fabric_receipt",
      "hgk_receipt",
      "sbl_receipt",
      "revoke_receipt",
      "join_subject"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.triple_golden_join.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::OBS-B1-C9::POS"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L409-L409 excerpt_sha256=17ffd535aa799185fcdaad289c60f7944ba9e3fdca4f89baebd9cebe82e792b5",
    "stimulus": "valid exact current Owner-supplied fixture only"
  },
  "runner_route": "OWNER_REGISTERED::triple_golden_join",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-C9-POS",
  "workorder_refs": [
    "OBS-B1-C9"
  ]
}
```
- **拒收**：domain `triple_golden_join` missing/typed raw absent => HOLD；實際 error `GWO_RECEIPT_ALIAS` 正規化 canonical `GWO_RECEIPT_ALIAS`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-C9-NEG｜TRIPLE_GWO / NEG

- **來源刺激**：source_clause=R15.1:L279(C05), R15.1:L289(C24); preconditions=Inject a valid current owned Fabric/HGK/SBL separate candidate hashes, raw receipt and independent checker actor; stimulus=single HGK golden pass substitutes Fabric and SBL
```json
{
  "atom_or_gwo": "B1-C9",
  "canonical_first_fail": "GWO_RECEIPT_ALIAS",
  "case_type": "NEG",
  "cross_sibling_acceptance": false,
  "domain": "TRIPLE_GWO",
  "effect_class": "READ_ONLY_PROBE",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "same receipt reused -> GWO_RECEIPT_ALIAS",
    "domain_positive": "3 different domain receipts, all same intended crosswalk, not aliases",
    "required_domain_fields": [
      "fabric_receipt",
      "hgk_receipt",
      "sbl_receipt",
      "revoke_receipt",
      "join_subject"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.triple_golden_join.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::OBS-B1-C9::NEG"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L410-L410 excerpt_sha256=b62e1c24b4dad73e71475dea4a174666e761ac36ef81be4d36100006c1b4e33d",
    "stimulus": "single HGK golden pass substitutes Fabric and SBL"
  },
  "runner_route": "OWNER_REGISTERED::triple_golden_join",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-C9-NEG",
  "workorder_refs": [
    "OBS-B1-C9"
  ]
}
```
- **拒收**：domain `triple_golden_join` missing/typed raw absent => HOLD；實際 error `THREE_GWO_PROXY_PASS` 正規化 canonical `GWO_RECEIPT_ALIAS`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-C9-EDGE｜TRIPLE_GWO / EDGE

- **來源刺激**：source_clause=R15.1:L279(C05), R15.1:L289(C24); preconditions=Inject a valid current owned Fabric/HGK/SBL separate candidate hashes, raw receipt and independent checker actor; stimulus=Fabric approved, HGK pending, SBL stale on rollup
```json
{
  "atom_or_gwo": "B1-C9",
  "canonical_first_fail": "GWO_RECEIPT_ALIAS",
  "case_type": "EDGE",
  "cross_sibling_acceptance": false,
  "domain": "TRIPLE_GWO",
  "effect_class": "READ_ONLY_PROBE",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "same receipt reused -> GWO_RECEIPT_ALIAS",
    "domain_positive": "3 different domain receipts, all same intended crosswalk, not aliases",
    "required_domain_fields": [
      "fabric_receipt",
      "hgk_receipt",
      "sbl_receipt",
      "revoke_receipt",
      "join_subject"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.triple_golden_join.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::OBS-B1-C9::EDGE"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L411-L411 excerpt_sha256=56e4d2104b9893d4f8b63e4312d44b2341e484bae7f8d07229210c9fb575fa43",
    "stimulus": "introduce domain-applicable resource/currentness drift, preserve adjacent independent effects"
  },
  "runner_route": "OWNER_REGISTERED::triple_golden_join",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-C9-EDGE",
  "workorder_refs": [
    "OBS-B1-C9"
  ]
}
```
- **拒收**：domain `triple_golden_join` missing/typed raw absent => HOLD；實際 error `THREE_GWO_PROXY_PASS_EDGE` 正規化 canonical `GWO_RECEIPT_ALIAS`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-B1-C9-SEC｜TRIPLE_GWO / SEC

- **來源刺激**：source_clause=R15.1:L279(C05), R15.1:L289(C24); preconditions=Inject a valid current owned Fabric/HGK/SBL separate candidate hashes, raw receipt and independent checker actor; stimulus=maker masquerades as independent product acceptance
```json
{
  "atom_or_gwo": "B1-C9",
  "canonical_first_fail": "GWO_RECEIPT_ALIAS",
  "case_type": "SEC",
  "cross_sibling_acceptance": false,
  "domain": "TRIPLE_GWO",
  "effect_class": "READ_ONLY_PROBE",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "same receipt reused -> GWO_RECEIPT_ALIAS",
    "domain_positive": "3 different domain receipts, all same intended crosswalk, not aliases",
    "required_domain_fields": [
      "fabric_receipt",
      "hgk_receipt",
      "sbl_receipt",
      "revoke_receipt",
      "join_subject"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.triple_golden_join.RAW@1"
  },
  "runner_input": {
    "operation_ids": [
      "OP::OBS-B1-C9::SEC"
    ],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L412-L412 excerpt_sha256=a94cae5c3d882ccbeb6b3c798a405465f93830d102203462bab8860d067f0c3c",
    "stimulus": "forge/replay this domain credential/subject or cross-swap sibling receipt"
  },
  "runner_route": "OWNER_REGISTERED::triple_golden_join",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": true,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-B1-C9-SEC",
  "workorder_refs": [
    "OBS-B1-C9"
  ]
}
```
- **拒收**：domain `triple_golden_join` missing/typed raw absent => HOLD；實際 error `THREE_GWO_PROXY_PASS_SEC` 正規化 canonical `GWO_RECEIPT_ALIAS`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-GWO-FABRIC-POS｜GWO-FABRIC / POS

- **來源刺激**：subject=GWO-FABRIC; source=R15:L277 W02 / policy Source→Stage→Approval→Active→NativeLoaded; fields=policy_epoch,source_sha,stage_sha,approved_sha,active_sha,loaded_module_sha; owner=Fabric native loader/policy owner; host_binding=REQUIRED_AT_RUN; same_sha=True
```json
{
  "atom_or_gwo": "GWO-FABRIC",
  "canonical_first_fail": "GWO_DOMAIN_OR_PERMISSION_FAIL",
  "case_type": "POS",
  "cross_sibling_acceptance": false,
  "domain": "GWO-FABRIC",
  "effect_class": "CROSS_DOMAIN_GOLDEN",
  "expected_case_verdict": "DOMAIN_POSITIVE_AFTER_REAL_RUN",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "stage alone or projection swap -> GWO_DOMAIN_OR_PERMISSION_FAIL",
    "domain_positive": "consumer sees exact activated policy and source projection, 2 separate effects",
    "required_domain_fields": [
      "sbl_entry",
      "source_revision",
      "stage",
      "active",
      "loaded_sha",
      "consumer_ack"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.golden_fabric.RAW@1"
  },
  "runner_input": {
    "operation_ids": [],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L413-L413 excerpt_sha256=1c9439c9dac2fd46580379c789525402973b1ca9de73adccf904e9ae70d23cab",
    "stimulus": "valid exact current Owner-supplied fixture only"
  },
  "runner_route": "OWNER_REGISTERED::golden_fabric",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": false,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-GWO-FABRIC-POS",
  "workorder_refs": []
}
```
- **拒收**：domain `golden_fabric` missing/typed raw absent => HOLD；實際 error `GWO_DOMAIN_OR_PERMISSION_FAIL` 正規化 canonical `GWO_DOMAIN_OR_PERMISSION_FAIL`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-GWO-FABRIC-NEG｜GWO-FABRIC / NEG

- **來源刺激**：subject=GWO-FABRIC; source=R15:L277 W02 / policy Source→Stage→Approval→Active→NativeLoaded; fields=policy_epoch,source_sha,stage_sha,approved_sha,active_sha,loaded_module_sha; owner=Fabric native loader/policy owner; host_binding=REQUIRED_AT_RUN; same_sha=True
```json
{
  "atom_or_gwo": "GWO-FABRIC",
  "canonical_first_fail": "GWO_DOMAIN_OR_PERMISSION_FAIL",
  "case_type": "NEG",
  "cross_sibling_acceptance": false,
  "domain": "GWO-FABRIC",
  "effect_class": "CROSS_DOMAIN_GOLDEN",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "stage alone or projection swap -> GWO_DOMAIN_OR_PERMISSION_FAIL",
    "domain_positive": "consumer sees exact activated policy and source projection, 2 separate effects",
    "required_domain_fields": [
      "sbl_entry",
      "source_revision",
      "stage",
      "active",
      "loaded_sha",
      "consumer_ack"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.golden_fabric.RAW@1"
  },
  "runner_input": {
    "operation_ids": [],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L414-L414 excerpt_sha256=9ec42b527d661208cc0977f6dc9c704569250e5394df433ca27975cdce0caba0",
    "stimulus": "`subject`=GWO-FABRIC; `source`=R15:L277 W02 / policy Source→Stage→Approval→Active→NativeLoaded; `fields`=policy_epoch,source_sha,stage_sha,approved_sha,active_sha,loaded_module_sha; `owner`=Fabric native loader/policy owner; `host_binding`=REQUIRED_AT_RUN; `same_sha`=True"
  },
  "runner_route": "OWNER_REGISTERED::golden_fabric",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": false,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-GWO-FABRIC-NEG",
  "workorder_refs": []
}
```
- **拒收**：domain `golden_fabric` missing/typed raw absent => HOLD；實際 error `GWO_DOMAIN_OR_PERMISSION_FAIL` 正規化 canonical `GWO_DOMAIN_OR_PERMISSION_FAIL`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-GWO-FABRIC-EDGE｜GWO-FABRIC / EDGE

- **來源刺激**：subject=GWO-FABRIC; source=R15:L277 W02 / policy Source→Stage→Approval→Active→NativeLoaded; fields=policy_epoch,source_sha,stage_sha,approved_sha,active_sha,loaded_module_sha; owner=Fabric native loader/policy owner; host_binding=REQUIRED_AT_RUN; same_sha=True
```json
{
  "atom_or_gwo": "GWO-FABRIC",
  "canonical_first_fail": "GWO_DOMAIN_OR_PERMISSION_FAIL",
  "case_type": "EDGE",
  "cross_sibling_acceptance": false,
  "domain": "GWO-FABRIC",
  "effect_class": "CROSS_DOMAIN_GOLDEN",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "stage alone or projection swap -> GWO_DOMAIN_OR_PERMISSION_FAIL",
    "domain_positive": "consumer sees exact activated policy and source projection, 2 separate effects",
    "required_domain_fields": [
      "sbl_entry",
      "source_revision",
      "stage",
      "active",
      "loaded_sha",
      "consumer_ack"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.golden_fabric.RAW@1"
  },
  "runner_input": {
    "operation_ids": [],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L415-L415 excerpt_sha256=335121aa142f3f7f40adc2c86f7aab4375e55f48006d433f4d8211b2ca36d2b5",
    "stimulus": "introduce domain-applicable resource/currentness drift, preserve adjacent independent effects"
  },
  "runner_route": "OWNER_REGISTERED::golden_fabric",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": false,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-GWO-FABRIC-EDGE",
  "workorder_refs": []
}
```
- **拒收**：domain `golden_fabric` missing/typed raw absent => HOLD；實際 error `GWO_DOMAIN_OR_PERMISSION_FAIL` 正規化 canonical `GWO_DOMAIN_OR_PERMISSION_FAIL`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-GWO-FABRIC-SEC｜GWO-FABRIC / SEC

- **來源刺激**：subject=GWO-FABRIC; source=R15:L277 W02 / policy Source→Stage→Approval→Active→NativeLoaded; fields=policy_epoch,source_sha,stage_sha,approved_sha,active_sha,loaded_module_sha; owner=Fabric native loader/policy owner; host_binding=REQUIRED_AT_RUN; same_sha=True
```json
{
  "atom_or_gwo": "GWO-FABRIC",
  "canonical_first_fail": "GWO_DOMAIN_OR_PERMISSION_FAIL",
  "case_type": "SEC",
  "cross_sibling_acceptance": false,
  "domain": "GWO-FABRIC",
  "effect_class": "CROSS_DOMAIN_GOLDEN",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "stage alone or projection swap -> GWO_DOMAIN_OR_PERMISSION_FAIL",
    "domain_positive": "consumer sees exact activated policy and source projection, 2 separate effects",
    "required_domain_fields": [
      "sbl_entry",
      "source_revision",
      "stage",
      "active",
      "loaded_sha",
      "consumer_ack"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.golden_fabric.RAW@1"
  },
  "runner_input": {
    "operation_ids": [],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L416-L416 excerpt_sha256=c18837fe91612a0a2bf4a0f161acdfae765011eca7146da81c4430bb3c9ed134",
    "stimulus": "forge/replay this domain credential/subject or cross-swap sibling receipt"
  },
  "runner_route": "OWNER_REGISTERED::golden_fabric",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": false,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-GWO-FABRIC-SEC",
  "workorder_refs": []
}
```
- **拒收**：domain `golden_fabric` missing/typed raw absent => HOLD；實際 error `GWO_DOMAIN_OR_PERMISSION_FAIL` 正規化 canonical `GWO_DOMAIN_OR_PERMISSION_FAIL`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-GWO-HGK-POS｜GWO-HGK / POS

- **來源刺激**：subject=GWO-HGK; source=R15:L276 W01 / Issuer Permit+Hermes lease+EffectJournal; fields=issuer_id,wo_id,ecp_id,token_nonce,lease_generation,effect_journal_sha; owner=HGK Native Issuer + Hermes lease owner; host_binding=REQUIRED_AT_RUN; same_sha=True
```json
{
  "atom_or_gwo": "GWO-HGK",
  "canonical_first_fail": "GWO_DOMAIN_OR_PERMISSION_FAIL",
  "case_type": "POS",
  "cross_sibling_acceptance": false,
  "domain": "GWO-HGK",
  "effect_class": "CROSS_DOMAIN_GOLDEN",
  "expected_case_verdict": "DOMAIN_POSITIVE_AFTER_REAL_RUN",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "helper simulates native queue -> GWO_DOMAIN_OR_PERMISSION_FAIL",
    "domain_positive": "true native card accepted and autonomously resumes after revoke",
    "required_domain_fields": [
      "sbl_entry",
      "issuer_event",
      "hermes_lease",
      "reversible_result",
      "post_revoke"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.golden_hgk.RAW@1"
  },
  "runner_input": {
    "operation_ids": [],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L417-L417 excerpt_sha256=500ee85a3f3a473d0281cfe6c0fc1c385036c394b37ddc81d7322075e6635b40",
    "stimulus": "valid exact current Owner-supplied fixture only"
  },
  "runner_route": "OWNER_REGISTERED::golden_hgk",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": false,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-GWO-HGK-POS",
  "workorder_refs": []
}
```
- **拒收**：domain `golden_hgk` missing/typed raw absent => HOLD；實際 error `GWO_DOMAIN_OR_PERMISSION_FAIL` 正規化 canonical `GWO_DOMAIN_OR_PERMISSION_FAIL`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-GWO-HGK-NEG｜GWO-HGK / NEG

- **來源刺激**：subject=GWO-HGK; source=R15:L276 W01 / Issuer Permit+Hermes lease+EffectJournal; fields=issuer_id,wo_id,ecp_id,token_nonce,lease_generation,effect_journal_sha; owner=HGK Native Issuer + Hermes lease owner; host_binding=REQUIRED_AT_RUN; same_sha=True
```json
{
  "atom_or_gwo": "GWO-HGK",
  "canonical_first_fail": "GWO_DOMAIN_OR_PERMISSION_FAIL",
  "case_type": "NEG",
  "cross_sibling_acceptance": false,
  "domain": "GWO-HGK",
  "effect_class": "CROSS_DOMAIN_GOLDEN",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "helper simulates native queue -> GWO_DOMAIN_OR_PERMISSION_FAIL",
    "domain_positive": "true native card accepted and autonomously resumes after revoke",
    "required_domain_fields": [
      "sbl_entry",
      "issuer_event",
      "hermes_lease",
      "reversible_result",
      "post_revoke"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.golden_hgk.RAW@1"
  },
  "runner_input": {
    "operation_ids": [],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L418-L418 excerpt_sha256=0bbab972227fe8481017094d928df9c9172dfc1762d97ef962723d206db54c24",
    "stimulus": "`subject`=GWO-HGK; `source`=R15:L276 W01 / Issuer Permit+Hermes lease+EffectJournal; `fields`=issuer_id,wo_id,ecp_id,token_nonce,lease_generation,effect_journal_sha; `owner`=HGK Native Issuer + Hermes lease owner; `host_binding`=REQUIRED_AT_RUN; `same_sha`=True"
  },
  "runner_route": "OWNER_REGISTERED::golden_hgk",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": false,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-GWO-HGK-NEG",
  "workorder_refs": []
}
```
- **拒收**：domain `golden_hgk` missing/typed raw absent => HOLD；實際 error `GWO_DOMAIN_OR_PERMISSION_FAIL` 正規化 canonical `GWO_DOMAIN_OR_PERMISSION_FAIL`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-GWO-HGK-EDGE｜GWO-HGK / EDGE

- **來源刺激**：subject=GWO-HGK; source=R15:L276 W01 / Issuer Permit+Hermes lease+EffectJournal; fields=issuer_id,wo_id,ecp_id,token_nonce,lease_generation,effect_journal_sha; owner=HGK Native Issuer + Hermes lease owner; host_binding=REQUIRED_AT_RUN; same_sha=True
```json
{
  "atom_or_gwo": "GWO-HGK",
  "canonical_first_fail": "GWO_DOMAIN_OR_PERMISSION_FAIL",
  "case_type": "EDGE",
  "cross_sibling_acceptance": false,
  "domain": "GWO-HGK",
  "effect_class": "CROSS_DOMAIN_GOLDEN",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "helper simulates native queue -> GWO_DOMAIN_OR_PERMISSION_FAIL",
    "domain_positive": "true native card accepted and autonomously resumes after revoke",
    "required_domain_fields": [
      "sbl_entry",
      "issuer_event",
      "hermes_lease",
      "reversible_result",
      "post_revoke"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.golden_hgk.RAW@1"
  },
  "runner_input": {
    "operation_ids": [],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L419-L419 excerpt_sha256=75ba8c67d67373ae3972044111ccd792305557021baaeb4444ce34b1745463ed",
    "stimulus": "introduce domain-applicable resource/currentness drift, preserve adjacent independent effects"
  },
  "runner_route": "OWNER_REGISTERED::golden_hgk",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": false,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-GWO-HGK-EDGE",
  "workorder_refs": []
}
```
- **拒收**：domain `golden_hgk` missing/typed raw absent => HOLD；實際 error `GWO_DOMAIN_OR_PERMISSION_FAIL` 正規化 canonical `GWO_DOMAIN_OR_PERMISSION_FAIL`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-GWO-HGK-SEC｜GWO-HGK / SEC

- **來源刺激**：subject=GWO-HGK; source=R15:L276 W01 / Issuer Permit+Hermes lease+EffectJournal; fields=issuer_id,wo_id,ecp_id,token_nonce,lease_generation,effect_journal_sha; owner=HGK Native Issuer + Hermes lease owner; host_binding=REQUIRED_AT_RUN; same_sha=True
```json
{
  "atom_or_gwo": "GWO-HGK",
  "canonical_first_fail": "GWO_DOMAIN_OR_PERMISSION_FAIL",
  "case_type": "SEC",
  "cross_sibling_acceptance": false,
  "domain": "GWO-HGK",
  "effect_class": "CROSS_DOMAIN_GOLDEN",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "helper simulates native queue -> GWO_DOMAIN_OR_PERMISSION_FAIL",
    "domain_positive": "true native card accepted and autonomously resumes after revoke",
    "required_domain_fields": [
      "sbl_entry",
      "issuer_event",
      "hermes_lease",
      "reversible_result",
      "post_revoke"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.golden_hgk.RAW@1"
  },
  "runner_input": {
    "operation_ids": [],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L420-L420 excerpt_sha256=9d7b9f6464297a2f8992928270de995943ab9f2d1584d461601a9c4a3f1e65e8",
    "stimulus": "forge/replay this domain credential/subject or cross-swap sibling receipt"
  },
  "runner_route": "OWNER_REGISTERED::golden_hgk",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": false,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-GWO-HGK-SEC",
  "workorder_refs": []
}
```
- **拒收**：domain `golden_hgk` missing/typed raw absent => HOLD；實際 error `GWO_DOMAIN_OR_PERMISSION_FAIL` 正規化 canonical `GWO_DOMAIN_OR_PERMISSION_FAIL`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-GWO-SBL-POS｜GWO-SBL / POS

- **來源刺激**：subject=GWO-SBL; source=R15:L281 W06 / sbl-todo wheel/install/add/list/delete/uninstall; fields=wheel_sha,install_id,user_state_root,record_id,preimage_sha,postimage_sha; owner=SBL CLI Host/User owner; host_binding=REQUIRED_AT_RUN; same_sha=True
```json
{
  "atom_or_gwo": "GWO-SBL",
  "canonical_first_fail": "GWO_DOMAIN_OR_PERMISSION_FAIL",
  "case_type": "POS",
  "cross_sibling_acceptance": false,
  "domain": "GWO-SBL",
  "effect_class": "CROSS_DOMAIN_GOLDEN",
  "expected_case_verdict": "DOMAIN_POSITIVE_AFTER_REAL_RUN",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "install receipt equals data effect -> GWO_DOMAIN_OR_PERMISSION_FAIL",
    "domain_positive": "user sees persisted isolated task and reversible erase, not proxy",
    "required_domain_fields": [
      "sbl_entry",
      "host_install",
      "todo_add",
      "todo_list",
      "todo_delete",
      "uninstall"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.golden_sbl.RAW@1"
  },
  "runner_input": {
    "operation_ids": [],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L421-L421 excerpt_sha256=a50c8ef13084f3b32160297c554e86f51c0b2107fc9e777c214003fafe697388",
    "stimulus": "valid exact current Owner-supplied fixture only"
  },
  "runner_route": "OWNER_REGISTERED::golden_sbl",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": false,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-GWO-SBL-POS",
  "workorder_refs": []
}
```
- **拒收**：domain `golden_sbl` missing/typed raw absent => HOLD；實際 error `GWO_DOMAIN_OR_PERMISSION_FAIL` 正規化 canonical `GWO_DOMAIN_OR_PERMISSION_FAIL`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-GWO-SBL-NEG｜GWO-SBL / NEG

- **來源刺激**：subject=GWO-SBL; source=R15:L281 W06 / sbl-todo wheel/install/add/list/delete/uninstall; fields=wheel_sha,install_id,user_state_root,record_id,preimage_sha,postimage_sha; owner=SBL CLI Host/User owner; host_binding=REQUIRED_AT_RUN; same_sha=True
```json
{
  "atom_or_gwo": "GWO-SBL",
  "canonical_first_fail": "GWO_DOMAIN_OR_PERMISSION_FAIL",
  "case_type": "NEG",
  "cross_sibling_acceptance": false,
  "domain": "GWO-SBL",
  "effect_class": "CROSS_DOMAIN_GOLDEN",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "install receipt equals data effect -> GWO_DOMAIN_OR_PERMISSION_FAIL",
    "domain_positive": "user sees persisted isolated task and reversible erase, not proxy",
    "required_domain_fields": [
      "sbl_entry",
      "host_install",
      "todo_add",
      "todo_list",
      "todo_delete",
      "uninstall"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.golden_sbl.RAW@1"
  },
  "runner_input": {
    "operation_ids": [],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L422-L422 excerpt_sha256=4ce4e879b4d8bcbfc5646eb8269e7328ae7f3e20458fb3eb1ce986ad7393ff68",
    "stimulus": "`subject`=GWO-SBL; `source`=R15:L281 W06 / sbl-todo wheel/install/add/list/delete/uninstall; `fields`=wheel_sha,install_id,user_state_root,record_id,preimage_sha,postimage_sha; `owner`=SBL CLI Host/User owner; `host_binding`=REQUIRED_AT_RUN; `same_sha`=True"
  },
  "runner_route": "OWNER_REGISTERED::golden_sbl",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": false,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-GWO-SBL-NEG",
  "workorder_refs": []
}
```
- **拒收**：domain `golden_sbl` missing/typed raw absent => HOLD；實際 error `GWO_DOMAIN_OR_PERMISSION_FAIL` 正規化 canonical `GWO_DOMAIN_OR_PERMISSION_FAIL`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-GWO-SBL-EDGE｜GWO-SBL / EDGE

- **來源刺激**：subject=GWO-SBL; source=R15:L281 W06 / sbl-todo wheel/install/add/list/delete/uninstall; fields=wheel_sha,install_id,user_state_root,record_id,preimage_sha,postimage_sha; owner=SBL CLI Host/User owner; host_binding=REQUIRED_AT_RUN; same_sha=True
```json
{
  "atom_or_gwo": "GWO-SBL",
  "canonical_first_fail": "GWO_DOMAIN_OR_PERMISSION_FAIL",
  "case_type": "EDGE",
  "cross_sibling_acceptance": false,
  "domain": "GWO-SBL",
  "effect_class": "CROSS_DOMAIN_GOLDEN",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "install receipt equals data effect -> GWO_DOMAIN_OR_PERMISSION_FAIL",
    "domain_positive": "user sees persisted isolated task and reversible erase, not proxy",
    "required_domain_fields": [
      "sbl_entry",
      "host_install",
      "todo_add",
      "todo_list",
      "todo_delete",
      "uninstall"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.golden_sbl.RAW@1"
  },
  "runner_input": {
    "operation_ids": [],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L423-L423 excerpt_sha256=17a80aa8fe62cb33c52d05449f825ab1515791ef294f96d95244b614d29bbfb3",
    "stimulus": "introduce domain-applicable resource/currentness drift, preserve adjacent independent effects"
  },
  "runner_route": "OWNER_REGISTERED::golden_sbl",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": false,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-GWO-SBL-EDGE",
  "workorder_refs": []
}
```
- **拒收**：domain `golden_sbl` missing/typed raw absent => HOLD；實際 error `GWO_DOMAIN_OR_PERMISSION_FAIL` 正規化 canonical `GWO_DOMAIN_OR_PERMISSION_FAIL`；多 WO 只能由後述 child 的各自 raw 評定。

### TQ-GWO-SBL-SEC｜GWO-SBL / SEC

- **來源刺激**：subject=GWO-SBL; source=R15:L281 W06 / sbl-todo wheel/install/add/list/delete/uninstall; fields=wheel_sha,install_id,user_state_root,record_id,preimage_sha,postimage_sha; owner=SBL CLI Host/User owner; host_binding=REQUIRED_AT_RUN; same_sha=True
```json
{
  "atom_or_gwo": "GWO-SBL",
  "canonical_first_fail": "GWO_DOMAIN_OR_PERMISSION_FAIL",
  "case_type": "SEC",
  "cross_sibling_acceptance": false,
  "domain": "GWO-SBL",
  "effect_class": "CROSS_DOMAIN_GOLDEN",
  "expected_case_verdict": "DOMAIN_DENIAL_PROVEN_BY_NATIVE_RAW",
  "expected_identity": {
    "candidate_sha": "BIND_FROM_NATIVE",
    "operation_id": "BIND_PER_EFFECT",
    "policy_epoch": "BIND_FROM_ACTIVE",
    "subject_sha": "BIND_FROM_NATIVE",
    "workorder_id": "BIND_PER_EFFECT"
  },
  "readback": {
    "distinct_native_events": true,
    "domain_negative": "install receipt equals data effect -> GWO_DOMAIN_OR_PERMISSION_FAIL",
    "domain_positive": "user sees persisted isolated task and reversible erase, not proxy",
    "required_domain_fields": [
      "sbl_entry",
      "host_install",
      "todo_add",
      "todo_list",
      "todo_delete",
      "uninstall"
    ],
    "same_candidate_sha": true,
    "schema_id": "B1.DOMAIN.golden_sbl.RAW@1"
  },
  "runner_input": {
    "operation_ids": [],
    "required_current_fields": [
      "active_policy_epoch",
      "candidate_sha",
      "subject_sha",
      "repo_or_host_binding"
    ],
    "source_clause": "FHS-MSC_B1_Bootstrap_Repair_PIPD-LS-PKG_草案(1).md@b519b8e78399204d5232e8a612293ffc24583dc98a2e4f60a74ed851f0ea63e6#L424-L424 excerpt_sha256=a6d6a1e6ffbe06faf1bf85c2faff98eefa61a63cffdf179fc8b18789b37fae3a",
    "stimulus": "forge/replay this domain credential/subject or cross-swap sibling receipt"
  },
  "runner_route": "OWNER_REGISTERED::golden_sbl",
  "runner_status": "BLOCKED_MISSING_RUNNER_OR_BINDING",
  "schema": "B1.TQAEP.CASE@3",
  "single_effect_evidence": false,
  "status": "DESIGN_PLANNED_NOT_RUN",
  "test_id": "TQ-GWO-SBL-SEC",
  "workorder_refs": []
}
```
- **拒收**：domain `golden_sbl` missing/typed raw absent => HOLD；實際 error `GWO_DOMAIN_OR_PERMISSION_FAIL` 正規化 canonical `GWO_DOMAIN_OR_PERMISSION_FAIL`；多 WO 只能由後述 child 的各自 raw 評定。

## 3. 31×4 = 124 個獨立 Child Effect/OBS Fixture（不以 parent 多 WO 假合一）

### TQ-CHILD-OBS-B1-A1-POS

```json
{
  "effect_class": "READ_ONLY_PROBE",
  "effect_key": "ROOT_RAW",
  "expected": "VALID_RAW_CHECKER_PASS",
  "id": "TQ-CHILD-OBS-B1-A1-POS",
  "native_issuer": "NONE_READ_ONLY",
  "operation_id": "OP::OBS-B1-A1::POS",
  "oracle_first_fail": "ROOT_ALIAS_OR_PATH_ESCAPE",
  "parent_id": "TQ-B1-A1-POS",
  "postcondition": "same effect, separately observed no mutation",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.root_probe.RAW@1",
  "required_binding": "READ_SCOPE",
  "required_fields": [
    "real_root",
    "git_head",
    "status_index",
    "reparse_chain",
    "root_handle"
  ],
  "rollback_or_recovery": "INVALIDATE_READ_CACHE",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "same file ID and signed root; staged/unstaged/untracked snapshot stable",
  "witness_status": "NOT_RUN",
  "workorder_id": "OBS-B1-A1"
}
```

### TQ-CHILD-OBS-B1-A1-NEG

```json
{
  "effect_class": "READ_ONLY_PROBE",
  "effect_key": "ROOT_RAW",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-OBS-B1-A1-NEG",
  "native_issuer": "NONE_READ_ONLY",
  "operation_id": "OP::OBS-B1-A1::NEG",
  "oracle_first_fail": "ROOT_ALIAS_OR_PATH_ESCAPE",
  "parent_id": "TQ-B1-A1-NEG",
  "postcondition": "same effect, separately observed no mutation",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.root_probe.RAW@1",
  "required_binding": "READ_SCOPE",
  "required_fields": [
    "real_root",
    "git_head",
    "status_index",
    "reparse_chain",
    "root_handle"
  ],
  "rollback_or_recovery": "INVALIDATE_READ_CACHE",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "alias/junction traversal or changed HEAD -> ROOT_ALIAS_OR_PATH_ESCAPE",
  "witness_status": "NOT_RUN",
  "workorder_id": "OBS-B1-A1"
}
```

### TQ-CHILD-OBS-B1-A1-EDGE

```json
{
  "effect_class": "READ_ONLY_PROBE",
  "effect_key": "ROOT_RAW",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-OBS-B1-A1-EDGE",
  "native_issuer": "NONE_READ_ONLY",
  "operation_id": "OP::OBS-B1-A1::EDGE",
  "oracle_first_fail": "ROOT_ALIAS_OR_PATH_ESCAPE",
  "parent_id": "TQ-B1-A1-EDGE",
  "postcondition": "same effect, separately observed no mutation",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.root_probe.RAW@1",
  "required_binding": "READ_SCOPE",
  "required_fields": [
    "real_root",
    "git_head",
    "status_index",
    "reparse_chain",
    "root_handle"
  ],
  "rollback_or_recovery": "INVALIDATE_READ_CACHE",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "domain-relevant stale version/lease/TTL/HEAD only if applicable",
  "witness_status": "NOT_RUN",
  "workorder_id": "OBS-B1-A1"
}
```

### TQ-CHILD-OBS-B1-A1-SEC

```json
{
  "effect_class": "READ_ONLY_PROBE",
  "effect_key": "ROOT_RAW",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-OBS-B1-A1-SEC",
  "native_issuer": "NONE_READ_ONLY",
  "operation_id": "OP::OBS-B1-A1::SEC",
  "oracle_first_fail": "ROOT_ALIAS_OR_PATH_ESCAPE",
  "parent_id": "TQ-B1-A1-SEC",
  "postcondition": "same effect, separately observed no mutation",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.root_probe.RAW@1",
  "required_binding": "READ_SCOPE",
  "required_fields": [
    "real_root",
    "git_head",
    "status_index",
    "reparse_chain",
    "root_handle"
  ],
  "rollback_or_recovery": "INVALIDATE_READ_CACHE",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "wrong owner/receipt/effect/class boundary",
  "witness_status": "NOT_RUN",
  "workorder_id": "OBS-B1-A1"
}
```

### TQ-CHILD-WO-B1-A2-POS

```json
{
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "ISSUER_SUBJECT",
  "expected": "VALID_RAW_CHECKER_PASS",
  "id": "TQ-CHILD-WO-B1-A2-POS",
  "native_issuer": "HGK_NATIVE_OWNER_REQUIRED",
  "operation_id": "OP::WO-B1-A2::POS",
  "oracle_first_fail": "PERMIT_SUBJECT_NONCE_REPLAY",
  "parent_id": "TQ-B1-A2-POS",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.native_issuer.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "issuer_identity",
    "subject_sha",
    "nonce",
    "ttl",
    "policy_epoch",
    "grant_signature"
  ],
  "rollback_or_recovery": "OWNER_SCOPED_COMPENSATION",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "issuer-signed exact subject/scope checked before spawn; nonce consumed once",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-A2"
}
```

### TQ-CHILD-WO-B1-A2-NEG

```json
{
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "ISSUER_SUBJECT",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-WO-B1-A2-NEG",
  "native_issuer": "HGK_NATIVE_OWNER_REQUIRED",
  "operation_id": "OP::WO-B1-A2::NEG",
  "oracle_first_fail": "PERMIT_SUBJECT_NONCE_REPLAY",
  "parent_id": "TQ-B1-A2-NEG",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.native_issuer.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "issuer_identity",
    "subject_sha",
    "nonce",
    "ttl",
    "policy_epoch",
    "grant_signature"
  ],
  "rollback_or_recovery": "OWNER_SCOPED_COMPENSATION",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "wrong issuer or replayed nonce -> PERMIT_SUBJECT_NONCE_REPLAY",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-A2"
}
```

### TQ-CHILD-WO-B1-A2-EDGE

```json
{
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "ISSUER_SUBJECT",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-WO-B1-A2-EDGE",
  "native_issuer": "HGK_NATIVE_OWNER_REQUIRED",
  "operation_id": "OP::WO-B1-A2::EDGE",
  "oracle_first_fail": "PERMIT_SUBJECT_NONCE_REPLAY",
  "parent_id": "TQ-B1-A2-EDGE",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.native_issuer.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "issuer_identity",
    "subject_sha",
    "nonce",
    "ttl",
    "policy_epoch",
    "grant_signature"
  ],
  "rollback_or_recovery": "OWNER_SCOPED_COMPENSATION",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "domain-relevant stale version/lease/TTL/HEAD only if applicable",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-A2"
}
```

### TQ-CHILD-WO-B1-A2-SEC

```json
{
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "ISSUER_SUBJECT",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-WO-B1-A2-SEC",
  "native_issuer": "HGK_NATIVE_OWNER_REQUIRED",
  "operation_id": "OP::WO-B1-A2::SEC",
  "oracle_first_fail": "PERMIT_SUBJECT_NONCE_REPLAY",
  "parent_id": "TQ-B1-A2-SEC",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.native_issuer.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "issuer_identity",
    "subject_sha",
    "nonce",
    "ttl",
    "policy_epoch",
    "grant_signature"
  ],
  "rollback_or_recovery": "OWNER_SCOPED_COMPENSATION",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "wrong owner/receipt/effect/class boundary",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-A2"
}
```

### TQ-CHILD-WO-B1-A3-POS

```json
{
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "QUEUE_WO",
  "expected": "VALID_RAW_CHECKER_PASS",
  "id": "TQ-CHILD-WO-B1-A3-POS",
  "native_issuer": "HGK_NATIVE_OWNER_REQUIRED",
  "operation_id": "OP::WO-B1-A3::POS",
  "oracle_first_fail": "LOST_LEASE_OR_DUPLICATE_CLAIM",
  "parent_id": "TQ-B1-A3-POS",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.hermes_queue.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "queue_id",
    "persisted_cursor",
    "lease_generation",
    "claimed_by",
    "park_reason"
  ],
  "rollback_or_recovery": "OWNER_SCOPED_COMPENSATION",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "blocked A parked; independent B/C progressed within bounded K; generation CAS unique",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-A3"
}
```

### TQ-CHILD-WO-B1-A3-NEG

```json
{
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "QUEUE_WO",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-WO-B1-A3-NEG",
  "native_issuer": "HGK_NATIVE_OWNER_REQUIRED",
  "operation_id": "OP::WO-B1-A3::NEG",
  "oracle_first_fail": "LOST_LEASE_OR_DUPLICATE_CLAIM",
  "parent_id": "TQ-B1-A3-NEG",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.hermes_queue.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "queue_id",
    "persisted_cursor",
    "lease_generation",
    "claimed_by",
    "park_reason"
  ],
  "rollback_or_recovery": "OWNER_SCOPED_COMPENSATION",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "duplicate claim, starved B/C or stale generation -> LOST_LEASE_OR_DUPLICATE_CLAIM",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-A3"
}
```

### TQ-CHILD-WO-B1-A3-EDGE

```json
{
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "QUEUE_WO",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-WO-B1-A3-EDGE",
  "native_issuer": "HGK_NATIVE_OWNER_REQUIRED",
  "operation_id": "OP::WO-B1-A3::EDGE",
  "oracle_first_fail": "LOST_LEASE_OR_DUPLICATE_CLAIM",
  "parent_id": "TQ-B1-A3-EDGE",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.hermes_queue.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "queue_id",
    "persisted_cursor",
    "lease_generation",
    "claimed_by",
    "park_reason"
  ],
  "rollback_or_recovery": "OWNER_SCOPED_COMPENSATION",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "domain-relevant stale version/lease/TTL/HEAD only if applicable",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-A3"
}
```

### TQ-CHILD-WO-B1-A3-SEC

```json
{
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "QUEUE_WO",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-WO-B1-A3-SEC",
  "native_issuer": "HGK_NATIVE_OWNER_REQUIRED",
  "operation_id": "OP::WO-B1-A3::SEC",
  "oracle_first_fail": "LOST_LEASE_OR_DUPLICATE_CLAIM",
  "parent_id": "TQ-B1-A3-SEC",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.hermes_queue.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "queue_id",
    "persisted_cursor",
    "lease_generation",
    "claimed_by",
    "park_reason"
  ],
  "rollback_or_recovery": "OWNER_SCOPED_COMPENSATION",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "wrong owner/receipt/effect/class boundary",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-A3"
}
```

### TQ-CHILD-WO-B1-A4-POS

```json
{
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "RECEIVER_ABI",
  "expected": "VALID_RAW_CHECKER_PASS",
  "id": "TQ-CHILD-WO-B1-A4-POS",
  "native_issuer": "HGK_NATIVE_OWNER_REQUIRED",
  "operation_id": "OP::WO-B1-A4::POS",
  "oracle_first_fail": "RECEIVER_NOT_LIVE",
  "parent_id": "TQ-B1-A4-POS",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.native_receiver.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "abi_id",
    "issuer",
    "wo_id",
    "subject_sha",
    "ack_or_nack",
    "native_event"
  ],
  "rollback_or_recovery": "OWNER_SCOPED_COMPENSATION",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "true receiver ACK signed for exact subject; mock ACK never qualifies",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-A4"
}
```

### TQ-CHILD-WO-B1-A4-NEG

```json
{
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "RECEIVER_ABI",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-WO-B1-A4-NEG",
  "native_issuer": "HGK_NATIVE_OWNER_REQUIRED",
  "operation_id": "OP::WO-B1-A4::NEG",
  "oracle_first_fail": "RECEIVER_NOT_LIVE",
  "parent_id": "TQ-B1-A4-NEG",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.native_receiver.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "abi_id",
    "issuer",
    "wo_id",
    "subject_sha",
    "ack_or_nack",
    "native_event"
  ],
  "rollback_or_recovery": "OWNER_SCOPED_COMPENSATION",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "mocked ACK/wrong ABI/absent native event -> RECEIVER_NOT_LIVE",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-A4"
}
```

### TQ-CHILD-WO-B1-A4-EDGE

```json
{
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "RECEIVER_ABI",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-WO-B1-A4-EDGE",
  "native_issuer": "HGK_NATIVE_OWNER_REQUIRED",
  "operation_id": "OP::WO-B1-A4::EDGE",
  "oracle_first_fail": "RECEIVER_NOT_LIVE",
  "parent_id": "TQ-B1-A4-EDGE",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.native_receiver.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "abi_id",
    "issuer",
    "wo_id",
    "subject_sha",
    "ack_or_nack",
    "native_event"
  ],
  "rollback_or_recovery": "OWNER_SCOPED_COMPENSATION",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "domain-relevant stale version/lease/TTL/HEAD only if applicable",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-A4"
}
```

### TQ-CHILD-WO-B1-A4-SEC

```json
{
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "RECEIVER_ABI",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-WO-B1-A4-SEC",
  "native_issuer": "HGK_NATIVE_OWNER_REQUIRED",
  "operation_id": "OP::WO-B1-A4::SEC",
  "oracle_first_fail": "RECEIVER_NOT_LIVE",
  "parent_id": "TQ-B1-A4-SEC",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.native_receiver.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "abi_id",
    "issuer",
    "wo_id",
    "subject_sha",
    "ack_or_nack",
    "native_event"
  ],
  "rollback_or_recovery": "OWNER_SCOPED_COMPENSATION",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "wrong owner/receipt/effect/class boundary",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-A4"
}
```

### TQ-CHILD-OBS-B1-A5-POS

```json
{
  "effect_class": "READ_ONLY_PROBE",
  "effect_key": "MODEL_LANES",
  "expected": "VALID_RAW_CHECKER_PASS",
  "id": "TQ-CHILD-OBS-B1-A5-POS",
  "native_issuer": "NONE_READ_ONLY",
  "operation_id": "OP::OBS-B1-A5::POS",
  "oracle_first_fail": "MODEL_REQUIRED_NOT_SERVED",
  "parent_id": "TQ-B1-A5-POS",
  "postcondition": "same effect, separately observed no mutation",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.host_lane_readback.RAW@1",
  "required_binding": "READ_SCOPE",
  "required_fields": [
    "PLAN",
    "EXECUTE",
    "VERIFY_SECURITY",
    "required_arm",
    "served_arm",
    "epoch",
    "loaded_sha"
  ],
  "rollback_or_recovery": "INVALIDATE_READ_CACHE",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "each mandatory lane actually served, same host and policy epoch",
  "witness_status": "NOT_RUN",
  "workorder_id": "OBS-B1-A5"
}
```

### TQ-CHILD-OBS-B1-A5-NEG

```json
{
  "effect_class": "READ_ONLY_PROBE",
  "effect_key": "MODEL_LANES",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-OBS-B1-A5-NEG",
  "native_issuer": "NONE_READ_ONLY",
  "operation_id": "OP::OBS-B1-A5::NEG",
  "oracle_first_fail": "MODEL_REQUIRED_NOT_SERVED",
  "parent_id": "TQ-B1-A5-NEG",
  "postcondition": "same effect, separately observed no mutation",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.host_lane_readback.RAW@1",
  "required_binding": "READ_SCOPE",
  "required_fields": [
    "PLAN",
    "EXECUTE",
    "VERIFY_SECURITY",
    "required_arm",
    "served_arm",
    "epoch",
    "loaded_sha"
  ],
  "rollback_or_recovery": "INVALIDATE_READ_CACHE",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "silent model fallback or missing served arm -> MODEL_REQUIRED_NOT_SERVED",
  "witness_status": "NOT_RUN",
  "workorder_id": "OBS-B1-A5"
}
```

### TQ-CHILD-OBS-B1-A5-EDGE

```json
{
  "effect_class": "READ_ONLY_PROBE",
  "effect_key": "MODEL_LANES",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-OBS-B1-A5-EDGE",
  "native_issuer": "NONE_READ_ONLY",
  "operation_id": "OP::OBS-B1-A5::EDGE",
  "oracle_first_fail": "MODEL_REQUIRED_NOT_SERVED",
  "parent_id": "TQ-B1-A5-EDGE",
  "postcondition": "same effect, separately observed no mutation",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.host_lane_readback.RAW@1",
  "required_binding": "READ_SCOPE",
  "required_fields": [
    "PLAN",
    "EXECUTE",
    "VERIFY_SECURITY",
    "required_arm",
    "served_arm",
    "epoch",
    "loaded_sha"
  ],
  "rollback_or_recovery": "INVALIDATE_READ_CACHE",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "domain-relevant stale version/lease/TTL/HEAD only if applicable",
  "witness_status": "NOT_RUN",
  "workorder_id": "OBS-B1-A5"
}
```

### TQ-CHILD-OBS-B1-A5-SEC

```json
{
  "effect_class": "READ_ONLY_PROBE",
  "effect_key": "MODEL_LANES",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-OBS-B1-A5-SEC",
  "native_issuer": "NONE_READ_ONLY",
  "operation_id": "OP::OBS-B1-A5::SEC",
  "oracle_first_fail": "MODEL_REQUIRED_NOT_SERVED",
  "parent_id": "TQ-B1-A5-SEC",
  "postcondition": "same effect, separately observed no mutation",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.host_lane_readback.RAW@1",
  "required_binding": "READ_SCOPE",
  "required_fields": [
    "PLAN",
    "EXECUTE",
    "VERIFY_SECURITY",
    "required_arm",
    "served_arm",
    "epoch",
    "loaded_sha"
  ],
  "rollback_or_recovery": "INVALIDATE_READ_CACHE",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "wrong owner/receipt/effect/class boundary",
  "witness_status": "NOT_RUN",
  "workorder_id": "OBS-B1-A5"
}
```

### TQ-CHILD-WO-B1-A6-POS

```json
{
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "EFFECT_JOURNAL",
  "expected": "VALID_RAW_CHECKER_PASS",
  "id": "TQ-CHILD-WO-B1-A6-POS",
  "native_issuer": "HGK_NATIVE_OWNER_REQUIRED",
  "operation_id": "OP::WO-B1-A6::POS",
  "oracle_first_fail": "UNKNOWN_EFFECT_REPLAY",
  "parent_id": "TQ-B1-A6-POS",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.effect_journal.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "operation_id",
    "preimage",
    "observed_postimage",
    "CAS_fence",
    "unknown_effect"
  ],
  "rollback_or_recovery": "OWNER_SCOPED_COMPENSATION",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "at-most-once effect; UNKNOWN_EFFECT reconciled before any next claim",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-A6"
}
```

### TQ-CHILD-WO-B1-A6-NEG

```json
{
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "EFFECT_JOURNAL",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-WO-B1-A6-NEG",
  "native_issuer": "HGK_NATIVE_OWNER_REQUIRED",
  "operation_id": "OP::WO-B1-A6::NEG",
  "oracle_first_fail": "UNKNOWN_EFFECT_REPLAY",
  "parent_id": "TQ-B1-A6-NEG",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.effect_journal.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "operation_id",
    "preimage",
    "observed_postimage",
    "CAS_fence",
    "unknown_effect"
  ],
  "rollback_or_recovery": "OWNER_SCOPED_COMPENSATION",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "duplicate operation or retry-on-timeout -> UNKNOWN_EFFECT_REPLAY",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-A6"
}
```

### TQ-CHILD-WO-B1-A6-EDGE

```json
{
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "EFFECT_JOURNAL",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-WO-B1-A6-EDGE",
  "native_issuer": "HGK_NATIVE_OWNER_REQUIRED",
  "operation_id": "OP::WO-B1-A6::EDGE",
  "oracle_first_fail": "UNKNOWN_EFFECT_REPLAY",
  "parent_id": "TQ-B1-A6-EDGE",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.effect_journal.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "operation_id",
    "preimage",
    "observed_postimage",
    "CAS_fence",
    "unknown_effect"
  ],
  "rollback_or_recovery": "OWNER_SCOPED_COMPENSATION",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "domain-relevant stale version/lease/TTL/HEAD only if applicable",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-A6"
}
```

### TQ-CHILD-WO-B1-A6-SEC

```json
{
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "EFFECT_JOURNAL",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-WO-B1-A6-SEC",
  "native_issuer": "HGK_NATIVE_OWNER_REQUIRED",
  "operation_id": "OP::WO-B1-A6::SEC",
  "oracle_first_fail": "UNKNOWN_EFFECT_REPLAY",
  "parent_id": "TQ-B1-A6-SEC",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.effect_journal.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "operation_id",
    "preimage",
    "observed_postimage",
    "CAS_fence",
    "unknown_effect"
  ],
  "rollback_or_recovery": "OWNER_SCOPED_COMPENSATION",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "wrong owner/receipt/effect/class boundary",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-A6"
}
```

### TQ-CHILD-OBS-B1-A7-POS

```json
{
  "effect_class": "READ_ONLY_PROBE",
  "effect_key": "RAW_EVIDENCE",
  "expected": "VALID_RAW_CHECKER_PASS",
  "id": "TQ-CHILD-OBS-B1-A7-POS",
  "native_issuer": "NONE_READ_ONLY",
  "operation_id": "OP::OBS-B1-A7::POS",
  "oracle_first_fail": "RAW_OR_CHECKER_MISMATCH",
  "parent_id": "TQ-B1-A7-POS",
  "postcondition": "same effect, separately observed no mutation",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.immutable_evidence.RAW@1",
  "required_binding": "READ_SCOPE",
  "required_fields": [
    "raw_receipt",
    "subject_sha",
    "candidate_sha",
    "checker_principal",
    "witness"
  ],
  "rollback_or_recovery": "INVALIDATE_READ_CACHE",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "distinct principal checker receipt matches same candidate and non-empty RAW",
  "witness_status": "NOT_RUN",
  "workorder_id": "OBS-B1-A7"
}
```

### TQ-CHILD-OBS-B1-A7-NEG

```json
{
  "effect_class": "READ_ONLY_PROBE",
  "effect_key": "RAW_EVIDENCE",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-OBS-B1-A7-NEG",
  "native_issuer": "NONE_READ_ONLY",
  "operation_id": "OP::OBS-B1-A7::NEG",
  "oracle_first_fail": "RAW_OR_CHECKER_MISMATCH",
  "parent_id": "TQ-B1-A7-NEG",
  "postcondition": "same effect, separately observed no mutation",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.immutable_evidence.RAW@1",
  "required_binding": "READ_SCOPE",
  "required_fields": [
    "raw_receipt",
    "subject_sha",
    "candidate_sha",
    "checker_principal",
    "witness"
  ],
  "rollback_or_recovery": "INVALIDATE_READ_CACHE",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "self-attested or mismatched witness -> RAW_OR_CHECKER_MISMATCH",
  "witness_status": "NOT_RUN",
  "workorder_id": "OBS-B1-A7"
}
```

### TQ-CHILD-OBS-B1-A7-EDGE

```json
{
  "effect_class": "READ_ONLY_PROBE",
  "effect_key": "RAW_EVIDENCE",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-OBS-B1-A7-EDGE",
  "native_issuer": "NONE_READ_ONLY",
  "operation_id": "OP::OBS-B1-A7::EDGE",
  "oracle_first_fail": "RAW_OR_CHECKER_MISMATCH",
  "parent_id": "TQ-B1-A7-EDGE",
  "postcondition": "same effect, separately observed no mutation",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.immutable_evidence.RAW@1",
  "required_binding": "READ_SCOPE",
  "required_fields": [
    "raw_receipt",
    "subject_sha",
    "candidate_sha",
    "checker_principal",
    "witness"
  ],
  "rollback_or_recovery": "INVALIDATE_READ_CACHE",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "domain-relevant stale version/lease/TTL/HEAD only if applicable",
  "witness_status": "NOT_RUN",
  "workorder_id": "OBS-B1-A7"
}
```

### TQ-CHILD-OBS-B1-A7-SEC

```json
{
  "effect_class": "READ_ONLY_PROBE",
  "effect_key": "RAW_EVIDENCE",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-OBS-B1-A7-SEC",
  "native_issuer": "NONE_READ_ONLY",
  "operation_id": "OP::OBS-B1-A7::SEC",
  "oracle_first_fail": "RAW_OR_CHECKER_MISMATCH",
  "parent_id": "TQ-B1-A7-SEC",
  "postcondition": "same effect, separately observed no mutation",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.immutable_evidence.RAW@1",
  "required_binding": "READ_SCOPE",
  "required_fields": [
    "raw_receipt",
    "subject_sha",
    "candidate_sha",
    "checker_principal",
    "witness"
  ],
  "rollback_or_recovery": "INVALIDATE_READ_CACHE",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "wrong owner/receipt/effect/class boundary",
  "witness_status": "NOT_RUN",
  "workorder_id": "OBS-B1-A7"
}
```

### TQ-CHILD-WO-B1-A8-POS

```json
{
  "effect_class": "REPOSITORY_WRITE",
  "effect_key": "NATIVE_HOTPATH",
  "expected": "VALID_RAW_CHECKER_PASS",
  "id": "TQ-CHILD-WO-B1-A8-POS",
  "native_issuer": "REPO_Codex_P4_OWNER_BOUND",
  "operation_id": "OP::WO-B1-A8::POS",
  "oracle_first_fail": "HOTPATH_UNRESOLVED",
  "parent_id": "TQ-B1-A8-POS",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.repo_diff.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "root",
    "head",
    "preimage",
    "diff",
    "writeset",
    "red_green",
    "postimage"
  ],
  "rollback_or_recovery": "RESTORE_APPROVED_PREIMAGE",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "exact loaded callsite identified and scoped regression independent",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-A8"
}
```

### TQ-CHILD-WO-B1-A8-NEG

```json
{
  "effect_class": "REPOSITORY_WRITE",
  "effect_key": "NATIVE_HOTPATH",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-WO-B1-A8-NEG",
  "native_issuer": "REPO_Codex_P4_OWNER_BOUND",
  "operation_id": "OP::WO-B1-A8::NEG",
  "oracle_first_fail": "HOTPATH_UNRESOLVED",
  "parent_id": "TQ-B1-A8-NEG",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.repo_diff.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "root",
    "head",
    "preimage",
    "diff",
    "writeset",
    "red_green",
    "postimage"
  ],
  "rollback_or_recovery": "RESTORE_APPROVED_PREIMAGE",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "unbounded writes or missing red reproducer -> HOTPATH_UNRESOLVED",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-A8"
}
```

### TQ-CHILD-WO-B1-A8-EDGE

```json
{
  "effect_class": "REPOSITORY_WRITE",
  "effect_key": "NATIVE_HOTPATH",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-WO-B1-A8-EDGE",
  "native_issuer": "REPO_Codex_P4_OWNER_BOUND",
  "operation_id": "OP::WO-B1-A8::EDGE",
  "oracle_first_fail": "HOTPATH_UNRESOLVED",
  "parent_id": "TQ-B1-A8-EDGE",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.repo_diff.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "root",
    "head",
    "preimage",
    "diff",
    "writeset",
    "red_green",
    "postimage"
  ],
  "rollback_or_recovery": "RESTORE_APPROVED_PREIMAGE",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "domain-relevant stale version/lease/TTL/HEAD only if applicable",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-A8"
}
```

### TQ-CHILD-WO-B1-A8-SEC

```json
{
  "effect_class": "REPOSITORY_WRITE",
  "effect_key": "NATIVE_HOTPATH",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-WO-B1-A8-SEC",
  "native_issuer": "REPO_Codex_P4_OWNER_BOUND",
  "operation_id": "OP::WO-B1-A8::SEC",
  "oracle_first_fail": "HOTPATH_UNRESOLVED",
  "parent_id": "TQ-B1-A8-SEC",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.repo_diff.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "root",
    "head",
    "preimage",
    "diff",
    "writeset",
    "red_green",
    "postimage"
  ],
  "rollback_or_recovery": "RESTORE_APPROVED_PREIMAGE",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "wrong owner/receipt/effect/class boundary",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-A8"
}
```

### TQ-CHILD-WO-B1-A9-POS

```json
{
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "NATIVE_CONTINUATION",
  "expected": "VALID_RAW_CHECKER_PASS",
  "id": "TQ-CHILD-WO-B1-A9-POS",
  "native_issuer": "HGK_NATIVE_OWNER_REQUIRED",
  "operation_id": "OP::WO-B1-A9::POS",
  "oracle_first_fail": "EXTERNAL_TRIGGER_STILL_REQUIRED",
  "parent_id": "TQ-B1-A9-POS",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.native_continuation.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "external_revoke",
    "post_turn_source",
    "issued_wo",
    "native_claim",
    "session_exit"
  ],
  "rollback_or_recovery": "OWNER_SCOPED_COMPENSATION",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "native successor advances after external revoke with new session and no external trigger",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-A9"
}
```

### TQ-CHILD-WO-B1-A9-NEG

```json
{
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "NATIVE_CONTINUATION",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-WO-B1-A9-NEG",
  "native_issuer": "HGK_NATIVE_OWNER_REQUIRED",
  "operation_id": "OP::WO-B1-A9::NEG",
  "oracle_first_fail": "EXTERNAL_TRIGGER_STILL_REQUIRED",
  "parent_id": "TQ-B1-A9-NEG",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.native_continuation.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "external_revoke",
    "post_turn_source",
    "issued_wo",
    "native_claim",
    "session_exit"
  ],
  "rollback_or_recovery": "OWNER_SCOPED_COMPENSATION",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "external actor still triggering -> EXTERNAL_TRIGGER_STILL_REQUIRED",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-A9"
}
```

### TQ-CHILD-WO-B1-A9-EDGE

```json
{
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "NATIVE_CONTINUATION",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-WO-B1-A9-EDGE",
  "native_issuer": "HGK_NATIVE_OWNER_REQUIRED",
  "operation_id": "OP::WO-B1-A9::EDGE",
  "oracle_first_fail": "EXTERNAL_TRIGGER_STILL_REQUIRED",
  "parent_id": "TQ-B1-A9-EDGE",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.native_continuation.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "external_revoke",
    "post_turn_source",
    "issued_wo",
    "native_claim",
    "session_exit"
  ],
  "rollback_or_recovery": "OWNER_SCOPED_COMPENSATION",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "domain-relevant stale version/lease/TTL/HEAD only if applicable",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-A9"
}
```

### TQ-CHILD-WO-B1-A9-SEC

```json
{
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "NATIVE_CONTINUATION",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-WO-B1-A9-SEC",
  "native_issuer": "HGK_NATIVE_OWNER_REQUIRED",
  "operation_id": "OP::WO-B1-A9::SEC",
  "oracle_first_fail": "EXTERNAL_TRIGGER_STILL_REQUIRED",
  "parent_id": "TQ-B1-A9-SEC",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.native_continuation.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "external_revoke",
    "post_turn_source",
    "issued_wo",
    "native_claim",
    "session_exit"
  ],
  "rollback_or_recovery": "OWNER_SCOPED_COMPENSATION",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "wrong owner/receipt/effect/class boundary",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-A9"
}
```

### TQ-CHILD-OBS-B1-B1-POS

```json
{
  "effect_class": "READ_ONLY_PROBE",
  "effect_key": "SOURCE_ATOMS",
  "expected": "VALID_RAW_CHECKER_PASS",
  "id": "TQ-CHILD-OBS-B1-B1-POS",
  "native_issuer": "NONE_READ_ONLY",
  "operation_id": "OP::OBS-B1-B1::POS",
  "oracle_first_fail": "PI_SOURCE_OR_ORACLE_UNBOUND",
  "parent_id": "TQ-B1-B1-POS",
  "postcondition": "same effect, separately observed no mutation",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.source_oracle.RAW@1",
  "required_binding": "READ_SCOPE",
  "required_fields": [
    "clause_sha",
    "atom_id",
    "source_owner",
    "domain_oracle",
    "trace_edges"
  ],
  "rollback_or_recovery": "INVALIDATE_READ_CACHE",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "one-to-one source clause/owner/oracle joins; missing clause is HOLD",
  "witness_status": "NOT_RUN",
  "workorder_id": "OBS-B1-B1"
}
```

### TQ-CHILD-OBS-B1-B1-NEG

```json
{
  "effect_class": "READ_ONLY_PROBE",
  "effect_key": "SOURCE_ATOMS",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-OBS-B1-B1-NEG",
  "native_issuer": "NONE_READ_ONLY",
  "operation_id": "OP::OBS-B1-B1::NEG",
  "oracle_first_fail": "PI_SOURCE_OR_ORACLE_UNBOUND",
  "parent_id": "TQ-B1-B1-NEG",
  "postcondition": "same effect, separately observed no mutation",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.source_oracle.RAW@1",
  "required_binding": "READ_SCOPE",
  "required_fields": [
    "clause_sha",
    "atom_id",
    "source_owner",
    "domain_oracle",
    "trace_edges"
  ],
  "rollback_or_recovery": "INVALIDATE_READ_CACHE",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "missing oracle or fabricated source -> PI_SOURCE_OR_ORACLE_UNBOUND",
  "witness_status": "NOT_RUN",
  "workorder_id": "OBS-B1-B1"
}
```

### TQ-CHILD-OBS-B1-B1-EDGE

```json
{
  "effect_class": "READ_ONLY_PROBE",
  "effect_key": "SOURCE_ATOMS",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-OBS-B1-B1-EDGE",
  "native_issuer": "NONE_READ_ONLY",
  "operation_id": "OP::OBS-B1-B1::EDGE",
  "oracle_first_fail": "PI_SOURCE_OR_ORACLE_UNBOUND",
  "parent_id": "TQ-B1-B1-EDGE",
  "postcondition": "same effect, separately observed no mutation",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.source_oracle.RAW@1",
  "required_binding": "READ_SCOPE",
  "required_fields": [
    "clause_sha",
    "atom_id",
    "source_owner",
    "domain_oracle",
    "trace_edges"
  ],
  "rollback_or_recovery": "INVALIDATE_READ_CACHE",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "domain-relevant stale version/lease/TTL/HEAD only if applicable",
  "witness_status": "NOT_RUN",
  "workorder_id": "OBS-B1-B1"
}
```

### TQ-CHILD-OBS-B1-B1-SEC

```json
{
  "effect_class": "READ_ONLY_PROBE",
  "effect_key": "SOURCE_ATOMS",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-OBS-B1-B1-SEC",
  "native_issuer": "NONE_READ_ONLY",
  "operation_id": "OP::OBS-B1-B1::SEC",
  "oracle_first_fail": "PI_SOURCE_OR_ORACLE_UNBOUND",
  "parent_id": "TQ-B1-B1-SEC",
  "postcondition": "same effect, separately observed no mutation",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.source_oracle.RAW@1",
  "required_binding": "READ_SCOPE",
  "required_fields": [
    "clause_sha",
    "atom_id",
    "source_owner",
    "domain_oracle",
    "trace_edges"
  ],
  "rollback_or_recovery": "INVALIDATE_READ_CACHE",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "wrong owner/receipt/effect/class boundary",
  "witness_status": "NOT_RUN",
  "workorder_id": "OBS-B1-B1"
}
```

### TQ-CHILD-OBS-B1-B2-POS

```json
{
  "effect_class": "READ_ONLY_PROBE",
  "effect_key": "REPO_CONTEXT",
  "expected": "VALID_RAW_CHECKER_PASS",
  "id": "TQ-CHILD-OBS-B1-B2-POS",
  "native_issuer": "NONE_READ_ONLY",
  "operation_id": "OP::OBS-B1-B2::POS",
  "oracle_first_fail": "REPO_CONTEXT_NOT_FRESH",
  "parent_id": "TQ-B1-B2-POS",
  "postcondition": "same effect, separately observed no mutation",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.repo_context_probe.RAW@1",
  "required_binding": "READ_SCOPE",
  "required_fields": [
    "realpath",
    "head",
    "index",
    "untracked",
    "writable_scope",
    "currentness"
  ],
  "rollback_or_recovery": "INVALIDATE_READ_CACHE",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "P4 PD only with actual repo root, HEAD and affected-only allowed write scope",
  "witness_status": "NOT_RUN",
  "workorder_id": "OBS-B1-B2"
}
```

### TQ-CHILD-OBS-B1-B2-NEG

```json
{
  "effect_class": "READ_ONLY_PROBE",
  "effect_key": "REPO_CONTEXT",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-OBS-B1-B2-NEG",
  "native_issuer": "NONE_READ_ONLY",
  "operation_id": "OP::OBS-B1-B2::NEG",
  "oracle_first_fail": "REPO_CONTEXT_NOT_FRESH",
  "parent_id": "TQ-B1-B2-NEG",
  "postcondition": "same effect, separately observed no mutation",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.repo_context_probe.RAW@1",
  "required_binding": "READ_SCOPE",
  "required_fields": [
    "realpath",
    "head",
    "index",
    "untracked",
    "writable_scope",
    "currentness"
  ],
  "rollback_or_recovery": "INVALIDATE_READ_CACHE",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "stale/escaping context -> REPO_CONTEXT_NOT_FRESH",
  "witness_status": "NOT_RUN",
  "workorder_id": "OBS-B1-B2"
}
```

### TQ-CHILD-OBS-B1-B2-EDGE

```json
{
  "effect_class": "READ_ONLY_PROBE",
  "effect_key": "REPO_CONTEXT",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-OBS-B1-B2-EDGE",
  "native_issuer": "NONE_READ_ONLY",
  "operation_id": "OP::OBS-B1-B2::EDGE",
  "oracle_first_fail": "REPO_CONTEXT_NOT_FRESH",
  "parent_id": "TQ-B1-B2-EDGE",
  "postcondition": "same effect, separately observed no mutation",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.repo_context_probe.RAW@1",
  "required_binding": "READ_SCOPE",
  "required_fields": [
    "realpath",
    "head",
    "index",
    "untracked",
    "writable_scope",
    "currentness"
  ],
  "rollback_or_recovery": "INVALIDATE_READ_CACHE",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "domain-relevant stale version/lease/TTL/HEAD only if applicable",
  "witness_status": "NOT_RUN",
  "workorder_id": "OBS-B1-B2"
}
```

### TQ-CHILD-OBS-B1-B2-SEC

```json
{
  "effect_class": "READ_ONLY_PROBE",
  "effect_key": "REPO_CONTEXT",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-OBS-B1-B2-SEC",
  "native_issuer": "NONE_READ_ONLY",
  "operation_id": "OP::OBS-B1-B2::SEC",
  "oracle_first_fail": "REPO_CONTEXT_NOT_FRESH",
  "parent_id": "TQ-B1-B2-SEC",
  "postcondition": "same effect, separately observed no mutation",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.repo_context_probe.RAW@1",
  "required_binding": "READ_SCOPE",
  "required_fields": [
    "realpath",
    "head",
    "index",
    "untracked",
    "writable_scope",
    "currentness"
  ],
  "rollback_or_recovery": "INVALIDATE_READ_CACHE",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "wrong owner/receipt/effect/class boundary",
  "witness_status": "NOT_RUN",
  "workorder_id": "OBS-B1-B2"
}
```

### TQ-CHILD-WO-B1-B3-DEV-POS

```json
{
  "effect_class": "REPOSITORY_WRITE",
  "effect_key": "SBL_TO_NATIVE__DEV",
  "expected": "VALID_RAW_CHECKER_PASS",
  "id": "TQ-CHILD-WO-B1-B3-DEV-POS",
  "native_issuer": "REPO_Codex_P4_OWNER_BOUND",
  "operation_id": "OP::WO-B1-B3-DEV::POS",
  "oracle_first_fail": "SECOND_ISSUER_OR_MIXED_EFFECT",
  "parent_id": "TQ-B1-B3-POS",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.bridge_handoff.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "sbl_entry",
    "candidate",
    "dev_diff",
    "ops_handoff",
    "native_receiver_ack"
  ],
  "rollback_or_recovery": "RESTORE_APPROVED_PREIMAGE",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "DEV/OPS different WOs, separate source diff and real native ACK",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-B3-DEV"
}
```

### TQ-CHILD-WO-B1-B3-DEV-NEG

```json
{
  "effect_class": "REPOSITORY_WRITE",
  "effect_key": "SBL_TO_NATIVE__DEV",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-WO-B1-B3-DEV-NEG",
  "native_issuer": "REPO_Codex_P4_OWNER_BOUND",
  "operation_id": "OP::WO-B1-B3-DEV::NEG",
  "oracle_first_fail": "SECOND_ISSUER_OR_MIXED_EFFECT",
  "parent_id": "TQ-B1-B3-NEG",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.bridge_handoff.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "sbl_entry",
    "candidate",
    "dev_diff",
    "ops_handoff",
    "native_receiver_ack"
  ],
  "rollback_or_recovery": "RESTORE_APPROVED_PREIMAGE",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "second issuer or shared receipt -> SECOND_ISSUER_OR_MIXED_EFFECT",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-B3-DEV"
}
```

### TQ-CHILD-WO-B1-B3-DEV-EDGE

```json
{
  "effect_class": "REPOSITORY_WRITE",
  "effect_key": "SBL_TO_NATIVE__DEV",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-WO-B1-B3-DEV-EDGE",
  "native_issuer": "REPO_Codex_P4_OWNER_BOUND",
  "operation_id": "OP::WO-B1-B3-DEV::EDGE",
  "oracle_first_fail": "SECOND_ISSUER_OR_MIXED_EFFECT",
  "parent_id": "TQ-B1-B3-EDGE",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.bridge_handoff.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "sbl_entry",
    "candidate",
    "dev_diff",
    "ops_handoff",
    "native_receiver_ack"
  ],
  "rollback_or_recovery": "RESTORE_APPROVED_PREIMAGE",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "domain-relevant stale version/lease/TTL/HEAD only if applicable",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-B3-DEV"
}
```

### TQ-CHILD-WO-B1-B3-DEV-SEC

```json
{
  "effect_class": "REPOSITORY_WRITE",
  "effect_key": "SBL_TO_NATIVE__DEV",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-WO-B1-B3-DEV-SEC",
  "native_issuer": "REPO_Codex_P4_OWNER_BOUND",
  "operation_id": "OP::WO-B1-B3-DEV::SEC",
  "oracle_first_fail": "SECOND_ISSUER_OR_MIXED_EFFECT",
  "parent_id": "TQ-B1-B3-SEC",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.bridge_handoff.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "sbl_entry",
    "candidate",
    "dev_diff",
    "ops_handoff",
    "native_receiver_ack"
  ],
  "rollback_or_recovery": "RESTORE_APPROVED_PREIMAGE",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "wrong owner/receipt/effect/class boundary",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-B3-DEV"
}
```

### TQ-CHILD-WO-B1-B3-OPS-POS

```json
{
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "SBL_TO_NATIVE__OPS",
  "expected": "VALID_RAW_CHECKER_PASS",
  "id": "TQ-CHILD-WO-B1-B3-OPS-POS",
  "native_issuer": "HGK_NATIVE_OWNER_REQUIRED",
  "operation_id": "OP::WO-B1-B3-OPS::POS",
  "oracle_first_fail": "SECOND_ISSUER_OR_MIXED_EFFECT",
  "parent_id": "TQ-B1-B3-POS",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.bridge_handoff.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "sbl_entry",
    "candidate",
    "dev_diff",
    "ops_handoff",
    "native_receiver_ack"
  ],
  "rollback_or_recovery": "OWNER_SCOPED_COMPENSATION",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "DEV/OPS different WOs, separate source diff and real native ACK",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-B3-OPS"
}
```

### TQ-CHILD-WO-B1-B3-OPS-NEG

```json
{
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "SBL_TO_NATIVE__OPS",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-WO-B1-B3-OPS-NEG",
  "native_issuer": "HGK_NATIVE_OWNER_REQUIRED",
  "operation_id": "OP::WO-B1-B3-OPS::NEG",
  "oracle_first_fail": "SECOND_ISSUER_OR_MIXED_EFFECT",
  "parent_id": "TQ-B1-B3-NEG",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.bridge_handoff.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "sbl_entry",
    "candidate",
    "dev_diff",
    "ops_handoff",
    "native_receiver_ack"
  ],
  "rollback_or_recovery": "OWNER_SCOPED_COMPENSATION",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "second issuer or shared receipt -> SECOND_ISSUER_OR_MIXED_EFFECT",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-B3-OPS"
}
```

### TQ-CHILD-WO-B1-B3-OPS-EDGE

```json
{
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "SBL_TO_NATIVE__OPS",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-WO-B1-B3-OPS-EDGE",
  "native_issuer": "HGK_NATIVE_OWNER_REQUIRED",
  "operation_id": "OP::WO-B1-B3-OPS::EDGE",
  "oracle_first_fail": "SECOND_ISSUER_OR_MIXED_EFFECT",
  "parent_id": "TQ-B1-B3-EDGE",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.bridge_handoff.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "sbl_entry",
    "candidate",
    "dev_diff",
    "ops_handoff",
    "native_receiver_ack"
  ],
  "rollback_or_recovery": "OWNER_SCOPED_COMPENSATION",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "domain-relevant stale version/lease/TTL/HEAD only if applicable",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-B3-OPS"
}
```

### TQ-CHILD-WO-B1-B3-OPS-SEC

```json
{
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "SBL_TO_NATIVE__OPS",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-WO-B1-B3-OPS-SEC",
  "native_issuer": "HGK_NATIVE_OWNER_REQUIRED",
  "operation_id": "OP::WO-B1-B3-OPS::SEC",
  "oracle_first_fail": "SECOND_ISSUER_OR_MIXED_EFFECT",
  "parent_id": "TQ-B1-B3-SEC",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.bridge_handoff.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "sbl_entry",
    "candidate",
    "dev_diff",
    "ops_handoff",
    "native_receiver_ack"
  ],
  "rollback_or_recovery": "OWNER_SCOPED_COMPENSATION",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "wrong owner/receipt/effect/class boundary",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-B3-OPS"
}
```

### TQ-CHILD-WO-B1-B4-DEV-POS

```json
{
  "effect_class": "REPOSITORY_WRITE",
  "effect_key": "ECP_SELECTOR__DEV",
  "expected": "VALID_RAW_CHECKER_PASS",
  "id": "TQ-CHILD-WO-B1-B4-DEV-POS",
  "native_issuer": "REPO_Codex_P4_OWNER_BOUND",
  "operation_id": "OP::WO-B1-B4-DEV::POS",
  "oracle_first_fail": "ECP_MULTIPLE_OR_CLASS_UNKNOWN",
  "parent_id": "TQ-B1-B4-POS",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.ecp_selection.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "wo_id",
    "effect_class",
    "active_ecp_count",
    "issuer_ack"
  ],
  "rollback_or_recovery": "RESTORE_APPROVED_PREIMAGE",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "one active ECP per WO; split iff distinct effects",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-B4-DEV"
}
```

### TQ-CHILD-WO-B1-B4-DEV-NEG

```json
{
  "effect_class": "REPOSITORY_WRITE",
  "effect_key": "ECP_SELECTOR__DEV",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-WO-B1-B4-DEV-NEG",
  "native_issuer": "REPO_Codex_P4_OWNER_BOUND",
  "operation_id": "OP::WO-B1-B4-DEV::NEG",
  "oracle_first_fail": "ECP_MULTIPLE_OR_CLASS_UNKNOWN",
  "parent_id": "TQ-B1-B4-NEG",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.ecp_selection.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "wo_id",
    "effect_class",
    "active_ecp_count",
    "issuer_ack"
  ],
  "rollback_or_recovery": "RESTORE_APPROVED_PREIMAGE",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "two active ECPs/unknown class -> ECP_MULTIPLE_OR_CLASS_UNKNOWN",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-B4-DEV"
}
```

### TQ-CHILD-WO-B1-B4-DEV-EDGE

```json
{
  "effect_class": "REPOSITORY_WRITE",
  "effect_key": "ECP_SELECTOR__DEV",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-WO-B1-B4-DEV-EDGE",
  "native_issuer": "REPO_Codex_P4_OWNER_BOUND",
  "operation_id": "OP::WO-B1-B4-DEV::EDGE",
  "oracle_first_fail": "ECP_MULTIPLE_OR_CLASS_UNKNOWN",
  "parent_id": "TQ-B1-B4-EDGE",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.ecp_selection.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "wo_id",
    "effect_class",
    "active_ecp_count",
    "issuer_ack"
  ],
  "rollback_or_recovery": "RESTORE_APPROVED_PREIMAGE",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "domain-relevant stale version/lease/TTL/HEAD only if applicable",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-B4-DEV"
}
```

### TQ-CHILD-WO-B1-B4-DEV-SEC

```json
{
  "effect_class": "REPOSITORY_WRITE",
  "effect_key": "ECP_SELECTOR__DEV",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-WO-B1-B4-DEV-SEC",
  "native_issuer": "REPO_Codex_P4_OWNER_BOUND",
  "operation_id": "OP::WO-B1-B4-DEV::SEC",
  "oracle_first_fail": "ECP_MULTIPLE_OR_CLASS_UNKNOWN",
  "parent_id": "TQ-B1-B4-SEC",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.ecp_selection.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "wo_id",
    "effect_class",
    "active_ecp_count",
    "issuer_ack"
  ],
  "rollback_or_recovery": "RESTORE_APPROVED_PREIMAGE",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "wrong owner/receipt/effect/class boundary",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-B4-DEV"
}
```

### TQ-CHILD-WO-B1-B4-OPS-POS

```json
{
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "ECP_SELECTOR__OPS",
  "expected": "VALID_RAW_CHECKER_PASS",
  "id": "TQ-CHILD-WO-B1-B4-OPS-POS",
  "native_issuer": "HGK_NATIVE_OWNER_REQUIRED",
  "operation_id": "OP::WO-B1-B4-OPS::POS",
  "oracle_first_fail": "ECP_MULTIPLE_OR_CLASS_UNKNOWN",
  "parent_id": "TQ-B1-B4-POS",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.ecp_selection.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "wo_id",
    "effect_class",
    "active_ecp_count",
    "issuer_ack"
  ],
  "rollback_or_recovery": "OWNER_SCOPED_COMPENSATION",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "one active ECP per WO; split iff distinct effects",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-B4-OPS"
}
```

### TQ-CHILD-WO-B1-B4-OPS-NEG

```json
{
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "ECP_SELECTOR__OPS",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-WO-B1-B4-OPS-NEG",
  "native_issuer": "HGK_NATIVE_OWNER_REQUIRED",
  "operation_id": "OP::WO-B1-B4-OPS::NEG",
  "oracle_first_fail": "ECP_MULTIPLE_OR_CLASS_UNKNOWN",
  "parent_id": "TQ-B1-B4-NEG",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.ecp_selection.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "wo_id",
    "effect_class",
    "active_ecp_count",
    "issuer_ack"
  ],
  "rollback_or_recovery": "OWNER_SCOPED_COMPENSATION",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "two active ECPs/unknown class -> ECP_MULTIPLE_OR_CLASS_UNKNOWN",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-B4-OPS"
}
```

### TQ-CHILD-WO-B1-B4-OPS-EDGE

```json
{
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "ECP_SELECTOR__OPS",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-WO-B1-B4-OPS-EDGE",
  "native_issuer": "HGK_NATIVE_OWNER_REQUIRED",
  "operation_id": "OP::WO-B1-B4-OPS::EDGE",
  "oracle_first_fail": "ECP_MULTIPLE_OR_CLASS_UNKNOWN",
  "parent_id": "TQ-B1-B4-EDGE",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.ecp_selection.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "wo_id",
    "effect_class",
    "active_ecp_count",
    "issuer_ack"
  ],
  "rollback_or_recovery": "OWNER_SCOPED_COMPENSATION",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "domain-relevant stale version/lease/TTL/HEAD only if applicable",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-B4-OPS"
}
```

### TQ-CHILD-WO-B1-B4-OPS-SEC

```json
{
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "ECP_SELECTOR__OPS",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-WO-B1-B4-OPS-SEC",
  "native_issuer": "HGK_NATIVE_OWNER_REQUIRED",
  "operation_id": "OP::WO-B1-B4-OPS::SEC",
  "oracle_first_fail": "ECP_MULTIPLE_OR_CLASS_UNKNOWN",
  "parent_id": "TQ-B1-B4-SEC",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.ecp_selection.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "wo_id",
    "effect_class",
    "active_ecp_count",
    "issuer_ack"
  ],
  "rollback_or_recovery": "OWNER_SCOPED_COMPENSATION",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "wrong owner/receipt/effect/class boundary",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-B4-OPS"
}
```

### TQ-CHILD-WO-B1-B5-DEV-POS

```json
{
  "effect_class": "REPOSITORY_WRITE",
  "effect_key": "THREE_SP__DEV",
  "expected": "VALID_RAW_CHECKER_PASS",
  "id": "TQ-CHILD-WO-B1-B5-DEV-POS",
  "native_issuer": "REPO_Codex_P4_OWNER_BOUND",
  "operation_id": "OP::WO-B1-B5-DEV::POS",
  "oracle_first_fail": "SP_HOST_LOAD_UNPROVEN",
  "parent_id": "TQ-B1-B5-POS",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.sp_host_load.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "TPM_SP",
    "COMMANDER_SP",
    "CHALLENGE_SP",
    "host_invocation",
    "loaded_sha"
  ],
  "rollback_or_recovery": "RESTORE_APPROVED_PREIMAGE",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "three host identities and isolated permission readbacks; ZIP-only not pass",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-B5-DEV"
}
```

### TQ-CHILD-WO-B1-B5-DEV-NEG

```json
{
  "effect_class": "REPOSITORY_WRITE",
  "effect_key": "THREE_SP__DEV",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-WO-B1-B5-DEV-NEG",
  "native_issuer": "REPO_Codex_P4_OWNER_BOUND",
  "operation_id": "OP::WO-B1-B5-DEV::NEG",
  "oracle_first_fail": "SP_HOST_LOAD_UNPROVEN",
  "parent_id": "TQ-B1-B5-NEG",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.sp_host_load.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "TPM_SP",
    "COMMANDER_SP",
    "CHALLENGE_SP",
    "host_invocation",
    "loaded_sha"
  ],
  "rollback_or_recovery": "RESTORE_APPROVED_PREIMAGE",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "missing host invocation -> SP_HOST_LOAD_UNPROVEN",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-B5-DEV"
}
```

### TQ-CHILD-WO-B1-B5-DEV-EDGE

```json
{
  "effect_class": "REPOSITORY_WRITE",
  "effect_key": "THREE_SP__DEV",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-WO-B1-B5-DEV-EDGE",
  "native_issuer": "REPO_Codex_P4_OWNER_BOUND",
  "operation_id": "OP::WO-B1-B5-DEV::EDGE",
  "oracle_first_fail": "SP_HOST_LOAD_UNPROVEN",
  "parent_id": "TQ-B1-B5-EDGE",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.sp_host_load.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "TPM_SP",
    "COMMANDER_SP",
    "CHALLENGE_SP",
    "host_invocation",
    "loaded_sha"
  ],
  "rollback_or_recovery": "RESTORE_APPROVED_PREIMAGE",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "domain-relevant stale version/lease/TTL/HEAD only if applicable",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-B5-DEV"
}
```

### TQ-CHILD-WO-B1-B5-DEV-SEC

```json
{
  "effect_class": "REPOSITORY_WRITE",
  "effect_key": "THREE_SP__DEV",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-WO-B1-B5-DEV-SEC",
  "native_issuer": "REPO_Codex_P4_OWNER_BOUND",
  "operation_id": "OP::WO-B1-B5-DEV::SEC",
  "oracle_first_fail": "SP_HOST_LOAD_UNPROVEN",
  "parent_id": "TQ-B1-B5-SEC",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.sp_host_load.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "TPM_SP",
    "COMMANDER_SP",
    "CHALLENGE_SP",
    "host_invocation",
    "loaded_sha"
  ],
  "rollback_or_recovery": "RESTORE_APPROVED_PREIMAGE",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "wrong owner/receipt/effect/class boundary",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-B5-DEV"
}
```

### TQ-CHILD-WO-B1-B5-OPS-POS

```json
{
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "THREE_SP__OPS",
  "expected": "VALID_RAW_CHECKER_PASS",
  "id": "TQ-CHILD-WO-B1-B5-OPS-POS",
  "native_issuer": "HGK_NATIVE_OWNER_REQUIRED",
  "operation_id": "OP::WO-B1-B5-OPS::POS",
  "oracle_first_fail": "SP_HOST_LOAD_UNPROVEN",
  "parent_id": "TQ-B1-B5-POS",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.sp_host_load.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "TPM_SP",
    "COMMANDER_SP",
    "CHALLENGE_SP",
    "host_invocation",
    "loaded_sha"
  ],
  "rollback_or_recovery": "OWNER_SCOPED_COMPENSATION",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "three host identities and isolated permission readbacks; ZIP-only not pass",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-B5-OPS"
}
```

### TQ-CHILD-WO-B1-B5-OPS-NEG

```json
{
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "THREE_SP__OPS",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-WO-B1-B5-OPS-NEG",
  "native_issuer": "HGK_NATIVE_OWNER_REQUIRED",
  "operation_id": "OP::WO-B1-B5-OPS::NEG",
  "oracle_first_fail": "SP_HOST_LOAD_UNPROVEN",
  "parent_id": "TQ-B1-B5-NEG",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.sp_host_load.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "TPM_SP",
    "COMMANDER_SP",
    "CHALLENGE_SP",
    "host_invocation",
    "loaded_sha"
  ],
  "rollback_or_recovery": "OWNER_SCOPED_COMPENSATION",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "missing host invocation -> SP_HOST_LOAD_UNPROVEN",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-B5-OPS"
}
```

### TQ-CHILD-WO-B1-B5-OPS-EDGE

```json
{
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "THREE_SP__OPS",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-WO-B1-B5-OPS-EDGE",
  "native_issuer": "HGK_NATIVE_OWNER_REQUIRED",
  "operation_id": "OP::WO-B1-B5-OPS::EDGE",
  "oracle_first_fail": "SP_HOST_LOAD_UNPROVEN",
  "parent_id": "TQ-B1-B5-EDGE",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.sp_host_load.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "TPM_SP",
    "COMMANDER_SP",
    "CHALLENGE_SP",
    "host_invocation",
    "loaded_sha"
  ],
  "rollback_or_recovery": "OWNER_SCOPED_COMPENSATION",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "domain-relevant stale version/lease/TTL/HEAD only if applicable",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-B5-OPS"
}
```

### TQ-CHILD-WO-B1-B5-OPS-SEC

```json
{
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "THREE_SP__OPS",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-WO-B1-B5-OPS-SEC",
  "native_issuer": "HGK_NATIVE_OWNER_REQUIRED",
  "operation_id": "OP::WO-B1-B5-OPS::SEC",
  "oracle_first_fail": "SP_HOST_LOAD_UNPROVEN",
  "parent_id": "TQ-B1-B5-SEC",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.sp_host_load.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "TPM_SP",
    "COMMANDER_SP",
    "CHALLENGE_SP",
    "host_invocation",
    "loaded_sha"
  ],
  "rollback_or_recovery": "OWNER_SCOPED_COMPENSATION",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "wrong owner/receipt/effect/class boundary",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-B5-OPS"
}
```

### TQ-CHILD-WO-B1-B6-USER-POS

```json
{
  "effect_class": "USER_DATA_EFFECT",
  "effect_key": "TODO_PERSISTENCE",
  "expected": "VALID_RAW_CHECKER_PASS",
  "id": "TQ-CHILD-WO-B1-B6-USER-POS",
  "native_issuer": "SBL_USER_DATA_ISSUER_REQUIRED",
  "operation_id": "OP::WO-B1-B6-USER::POS",
  "oracle_first_fail": "CLI_EFFECT_MISCLASSIFIED",
  "parent_id": "TQ-B1-B6-POS",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.sbl_todo.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "data_dir",
    "task_id",
    "add_response",
    "list_response",
    "delete_response",
    "uninstall"
  ],
  "rollback_or_recovery": "RESTORE_USER_RECORD_PREIMAGE",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "isolated store add -> separate list -> delete -> zero residue",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-B6-USER"
}
```

### TQ-CHILD-WO-B1-B6-USER-NEG

```json
{
  "effect_class": "USER_DATA_EFFECT",
  "effect_key": "TODO_PERSISTENCE",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-WO-B1-B6-USER-NEG",
  "native_issuer": "SBL_USER_DATA_ISSUER_REQUIRED",
  "operation_id": "OP::WO-B1-B6-USER::NEG",
  "oracle_first_fail": "CLI_EFFECT_MISCLASSIFIED",
  "parent_id": "TQ-B1-B6-NEG",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.sbl_todo.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "data_dir",
    "task_id",
    "add_response",
    "list_response",
    "delete_response",
    "uninstall"
  ],
  "rollback_or_recovery": "RESTORE_USER_RECORD_PREIMAGE",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "user effect misclassified or no actual state -> CLI_EFFECT_MISCLASSIFIED",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-B6-USER"
}
```

### TQ-CHILD-WO-B1-B6-USER-EDGE

```json
{
  "effect_class": "USER_DATA_EFFECT",
  "effect_key": "TODO_PERSISTENCE",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-WO-B1-B6-USER-EDGE",
  "native_issuer": "SBL_USER_DATA_ISSUER_REQUIRED",
  "operation_id": "OP::WO-B1-B6-USER::EDGE",
  "oracle_first_fail": "CLI_EFFECT_MISCLASSIFIED",
  "parent_id": "TQ-B1-B6-EDGE",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.sbl_todo.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "data_dir",
    "task_id",
    "add_response",
    "list_response",
    "delete_response",
    "uninstall"
  ],
  "rollback_or_recovery": "RESTORE_USER_RECORD_PREIMAGE",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "domain-relevant stale version/lease/TTL/HEAD only if applicable",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-B6-USER"
}
```

### TQ-CHILD-WO-B1-B6-USER-SEC

```json
{
  "effect_class": "USER_DATA_EFFECT",
  "effect_key": "TODO_PERSISTENCE",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-WO-B1-B6-USER-SEC",
  "native_issuer": "SBL_USER_DATA_ISSUER_REQUIRED",
  "operation_id": "OP::WO-B1-B6-USER::SEC",
  "oracle_first_fail": "CLI_EFFECT_MISCLASSIFIED",
  "parent_id": "TQ-B1-B6-SEC",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.sbl_todo.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "data_dir",
    "task_id",
    "add_response",
    "list_response",
    "delete_response",
    "uninstall"
  ],
  "rollback_or_recovery": "RESTORE_USER_RECORD_PREIMAGE",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "wrong owner/receipt/effect/class boundary",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-B6-USER"
}
```

### TQ-CHILD-OBS-B1-B7-POS

```json
{
  "effect_class": "READ_ONLY_PROBE",
  "effect_key": "NOFIT_ROUTE",
  "expected": "VALID_RAW_CHECKER_PASS",
  "id": "TQ-CHILD-OBS-B1-B7-POS",
  "native_issuer": "NONE_READ_ONLY",
  "operation_id": "OP::OBS-B1-B7::POS",
  "oracle_first_fail": "NOFIT_OR_PROVIDER_OFF",
  "parent_id": "TQ-B1-B7-POS",
  "postcondition": "same effect, separately observed no mutation",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.no_fit.RAW@1",
  "required_binding": "READ_SCOPE",
  "required_fields": [
    "required_capability",
    "host",
    "provider_off",
    "owner",
    "refusal",
    "zero_effect"
  ],
  "rollback_or_recovery": "INVALIDATE_READ_CACHE",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "deterministic capability NOFIT with user-readable reason and zero unauthorized delta",
  "witness_status": "NOT_RUN",
  "workorder_id": "OBS-B1-B7"
}
```

### TQ-CHILD-OBS-B1-B7-NEG

```json
{
  "effect_class": "READ_ONLY_PROBE",
  "effect_key": "NOFIT_ROUTE",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-OBS-B1-B7-NEG",
  "native_issuer": "NONE_READ_ONLY",
  "operation_id": "OP::OBS-B1-B7::NEG",
  "oracle_first_fail": "NOFIT_OR_PROVIDER_OFF",
  "parent_id": "TQ-B1-B7-NEG",
  "postcondition": "same effect, separately observed no mutation",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.no_fit.RAW@1",
  "required_binding": "READ_SCOPE",
  "required_fields": [
    "required_capability",
    "host",
    "provider_off",
    "owner",
    "refusal",
    "zero_effect"
  ],
  "rollback_or_recovery": "INVALIDATE_READ_CACHE",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "silent fallback -> NOFIT_OR_PROVIDER_OFF",
  "witness_status": "NOT_RUN",
  "workorder_id": "OBS-B1-B7"
}
```

### TQ-CHILD-OBS-B1-B7-EDGE

```json
{
  "effect_class": "READ_ONLY_PROBE",
  "effect_key": "NOFIT_ROUTE",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-OBS-B1-B7-EDGE",
  "native_issuer": "NONE_READ_ONLY",
  "operation_id": "OP::OBS-B1-B7::EDGE",
  "oracle_first_fail": "NOFIT_OR_PROVIDER_OFF",
  "parent_id": "TQ-B1-B7-EDGE",
  "postcondition": "same effect, separately observed no mutation",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.no_fit.RAW@1",
  "required_binding": "READ_SCOPE",
  "required_fields": [
    "required_capability",
    "host",
    "provider_off",
    "owner",
    "refusal",
    "zero_effect"
  ],
  "rollback_or_recovery": "INVALIDATE_READ_CACHE",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "domain-relevant stale version/lease/TTL/HEAD only if applicable",
  "witness_status": "NOT_RUN",
  "workorder_id": "OBS-B1-B7"
}
```

### TQ-CHILD-OBS-B1-B7-SEC

```json
{
  "effect_class": "READ_ONLY_PROBE",
  "effect_key": "NOFIT_ROUTE",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-OBS-B1-B7-SEC",
  "native_issuer": "NONE_READ_ONLY",
  "operation_id": "OP::OBS-B1-B7::SEC",
  "oracle_first_fail": "NOFIT_OR_PROVIDER_OFF",
  "parent_id": "TQ-B1-B7-SEC",
  "postcondition": "same effect, separately observed no mutation",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.no_fit.RAW@1",
  "required_binding": "READ_SCOPE",
  "required_fields": [
    "required_capability",
    "host",
    "provider_off",
    "owner",
    "refusal",
    "zero_effect"
  ],
  "rollback_or_recovery": "INVALIDATE_READ_CACHE",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "wrong owner/receipt/effect/class boundary",
  "witness_status": "NOT_RUN",
  "workorder_id": "OBS-B1-B7"
}
```

### TQ-CHILD-OBS-B1-B8-POS

```json
{
  "effect_class": "READ_ONLY_PROBE",
  "effect_key": "TRACE_GRAPH",
  "expected": "VALID_RAW_CHECKER_PASS",
  "id": "TQ-CHILD-OBS-B1-B8-POS",
  "native_issuer": "NONE_READ_ONLY",
  "operation_id": "OP::OBS-B1-B8::POS",
  "oracle_first_fail": "TRACE_CLOSURE_FAIL",
  "parent_id": "TQ-B1-B8-POS",
  "postcondition": "same effect, separately observed no mutation",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.trace_closure.RAW@1",
  "required_binding": "READ_SCOPE",
  "required_fields": [
    "pi",
    "pd",
    "cc",
    "ecp",
    "wo",
    "tqaep",
    "raw",
    "checker",
    "edges"
  ],
  "rollback_or_recovery": "INVALIDATE_READ_CACHE",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "nonempty exact IDs and hashes, zero orphans and zero bad edges",
  "witness_status": "NOT_RUN",
  "workorder_id": "OBS-B1-B8"
}
```

### TQ-CHILD-OBS-B1-B8-NEG

```json
{
  "effect_class": "READ_ONLY_PROBE",
  "effect_key": "TRACE_GRAPH",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-OBS-B1-B8-NEG",
  "native_issuer": "NONE_READ_ONLY",
  "operation_id": "OP::OBS-B1-B8::NEG",
  "oracle_first_fail": "TRACE_CLOSURE_FAIL",
  "parent_id": "TQ-B1-B8-NEG",
  "postcondition": "same effect, separately observed no mutation",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.trace_closure.RAW@1",
  "required_binding": "READ_SCOPE",
  "required_fields": [
    "pi",
    "pd",
    "cc",
    "ecp",
    "wo",
    "tqaep",
    "raw",
    "checker",
    "edges"
  ],
  "rollback_or_recovery": "INVALIDATE_READ_CACHE",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "foreign/sibling witness -> TRACE_CLOSURE_FAIL",
  "witness_status": "NOT_RUN",
  "workorder_id": "OBS-B1-B8"
}
```

### TQ-CHILD-OBS-B1-B8-EDGE

```json
{
  "effect_class": "READ_ONLY_PROBE",
  "effect_key": "TRACE_GRAPH",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-OBS-B1-B8-EDGE",
  "native_issuer": "NONE_READ_ONLY",
  "operation_id": "OP::OBS-B1-B8::EDGE",
  "oracle_first_fail": "TRACE_CLOSURE_FAIL",
  "parent_id": "TQ-B1-B8-EDGE",
  "postcondition": "same effect, separately observed no mutation",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.trace_closure.RAW@1",
  "required_binding": "READ_SCOPE",
  "required_fields": [
    "pi",
    "pd",
    "cc",
    "ecp",
    "wo",
    "tqaep",
    "raw",
    "checker",
    "edges"
  ],
  "rollback_or_recovery": "INVALIDATE_READ_CACHE",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "domain-relevant stale version/lease/TTL/HEAD only if applicable",
  "witness_status": "NOT_RUN",
  "workorder_id": "OBS-B1-B8"
}
```

### TQ-CHILD-OBS-B1-B8-SEC

```json
{
  "effect_class": "READ_ONLY_PROBE",
  "effect_key": "TRACE_GRAPH",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-OBS-B1-B8-SEC",
  "native_issuer": "NONE_READ_ONLY",
  "operation_id": "OP::OBS-B1-B8::SEC",
  "oracle_first_fail": "TRACE_CLOSURE_FAIL",
  "parent_id": "TQ-B1-B8-SEC",
  "postcondition": "same effect, separately observed no mutation",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.trace_closure.RAW@1",
  "required_binding": "READ_SCOPE",
  "required_fields": [
    "pi",
    "pd",
    "cc",
    "ecp",
    "wo",
    "tqaep",
    "raw",
    "checker",
    "edges"
  ],
  "rollback_or_recovery": "INVALIDATE_READ_CACHE",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "wrong owner/receipt/effect/class boundary",
  "witness_status": "NOT_RUN",
  "workorder_id": "OBS-B1-B8"
}
```

### TQ-CHILD-OBS-B1-B9-POS

```json
{
  "effect_class": "READ_ONLY_PROBE",
  "effect_key": "R15_COVERAGE",
  "expected": "VALID_RAW_CHECKER_PASS",
  "id": "TQ-CHILD-OBS-B1-B9-POS",
  "native_issuer": "NONE_READ_ONLY",
  "operation_id": "OP::OBS-B1-B9::POS",
  "oracle_first_fail": "R15_DENOMINATOR_SHRINK",
  "parent_id": "TQ-B1-B9-POS",
  "postcondition": "same effect, separately observed no mutation",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.baseline_denominator.RAW@1",
  "required_binding": "READ_SCOPE",
  "required_fields": [
    "949_ids",
    "18_families",
    "required",
    "conditional",
    "deferred",
    "owners"
  ],
  "rollback_or_recovery": "INVALIDATE_READ_CACHE",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "949 unique 18-family IDs, 66/254/629 and source-specific disposition",
  "witness_status": "NOT_RUN",
  "workorder_id": "OBS-B1-B9"
}
```

### TQ-CHILD-OBS-B1-B9-NEG

```json
{
  "effect_class": "READ_ONLY_PROBE",
  "effect_key": "R15_COVERAGE",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-OBS-B1-B9-NEG",
  "native_issuer": "NONE_READ_ONLY",
  "operation_id": "OP::OBS-B1-B9::NEG",
  "oracle_first_fail": "R15_DENOMINATOR_SHRINK",
  "parent_id": "TQ-B1-B9-NEG",
  "postcondition": "same effect, separately observed no mutation",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.baseline_denominator.RAW@1",
  "required_binding": "READ_SCOPE",
  "required_fields": [
    "949_ids",
    "18_families",
    "required",
    "conditional",
    "deferred",
    "owners"
  ],
  "rollback_or_recovery": "INVALIDATE_READ_CACHE",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "missing ID or generic proxy pass -> R15_DENOMINATOR_SHRINK",
  "witness_status": "NOT_RUN",
  "workorder_id": "OBS-B1-B9"
}
```

### TQ-CHILD-OBS-B1-B9-EDGE

```json
{
  "effect_class": "READ_ONLY_PROBE",
  "effect_key": "R15_COVERAGE",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-OBS-B1-B9-EDGE",
  "native_issuer": "NONE_READ_ONLY",
  "operation_id": "OP::OBS-B1-B9::EDGE",
  "oracle_first_fail": "R15_DENOMINATOR_SHRINK",
  "parent_id": "TQ-B1-B9-EDGE",
  "postcondition": "same effect, separately observed no mutation",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.baseline_denominator.RAW@1",
  "required_binding": "READ_SCOPE",
  "required_fields": [
    "949_ids",
    "18_families",
    "required",
    "conditional",
    "deferred",
    "owners"
  ],
  "rollback_or_recovery": "INVALIDATE_READ_CACHE",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "domain-relevant stale version/lease/TTL/HEAD only if applicable",
  "witness_status": "NOT_RUN",
  "workorder_id": "OBS-B1-B9"
}
```

### TQ-CHILD-OBS-B1-B9-SEC

```json
{
  "effect_class": "READ_ONLY_PROBE",
  "effect_key": "R15_COVERAGE",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-OBS-B1-B9-SEC",
  "native_issuer": "NONE_READ_ONLY",
  "operation_id": "OP::OBS-B1-B9::SEC",
  "oracle_first_fail": "R15_DENOMINATOR_SHRINK",
  "parent_id": "TQ-B1-B9-SEC",
  "postcondition": "same effect, separately observed no mutation",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.baseline_denominator.RAW@1",
  "required_binding": "READ_SCOPE",
  "required_fields": [
    "949_ids",
    "18_families",
    "required",
    "conditional",
    "deferred",
    "owners"
  ],
  "rollback_or_recovery": "INVALIDATE_READ_CACHE",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "wrong owner/receipt/effect/class boundary",
  "witness_status": "NOT_RUN",
  "workorder_id": "OBS-B1-B9"
}
```

### TQ-CHILD-WO-B1-C1-POS

```json
{
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "FABRIC_PROMOTION",
  "expected": "VALID_RAW_CHECKER_PASS",
  "id": "TQ-CHILD-WO-B1-C1-POS",
  "native_issuer": "HGK_NATIVE_OWNER_REQUIRED",
  "operation_id": "OP::WO-B1-C1::POS",
  "oracle_first_fail": "FABRIC_LOADED_ABSENT",
  "parent_id": "TQ-B1-C1-POS",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.fabric_activator.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "approved_stage",
    "active_policy",
    "loaded_sha",
    "consumer_trace",
    "rollback"
  ],
  "rollback_or_recovery": "OWNER_SCOPED_COMPENSATION",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "independent stage approval; active and loaded exact digest; consumer projection ACK",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-C1"
}
```

### TQ-CHILD-WO-B1-C1-NEG

```json
{
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "FABRIC_PROMOTION",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-WO-B1-C1-NEG",
  "native_issuer": "HGK_NATIVE_OWNER_REQUIRED",
  "operation_id": "OP::WO-B1-C1::NEG",
  "oracle_first_fail": "FABRIC_LOADED_ABSENT",
  "parent_id": "TQ-B1-C1-NEG",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.fabric_activator.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "approved_stage",
    "active_policy",
    "loaded_sha",
    "consumer_trace",
    "rollback"
  ],
  "rollback_or_recovery": "OWNER_SCOPED_COMPENSATION",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "stage mistaken as active or missing consumer -> FABRIC_LOADED_ABSENT",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-C1"
}
```

### TQ-CHILD-WO-B1-C1-EDGE

```json
{
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "FABRIC_PROMOTION",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-WO-B1-C1-EDGE",
  "native_issuer": "HGK_NATIVE_OWNER_REQUIRED",
  "operation_id": "OP::WO-B1-C1::EDGE",
  "oracle_first_fail": "FABRIC_LOADED_ABSENT",
  "parent_id": "TQ-B1-C1-EDGE",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.fabric_activator.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "approved_stage",
    "active_policy",
    "loaded_sha",
    "consumer_trace",
    "rollback"
  ],
  "rollback_or_recovery": "OWNER_SCOPED_COMPENSATION",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "domain-relevant stale version/lease/TTL/HEAD only if applicable",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-C1"
}
```

### TQ-CHILD-WO-B1-C1-SEC

```json
{
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "FABRIC_PROMOTION",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-WO-B1-C1-SEC",
  "native_issuer": "HGK_NATIVE_OWNER_REQUIRED",
  "operation_id": "OP::WO-B1-C1::SEC",
  "oracle_first_fail": "FABRIC_LOADED_ABSENT",
  "parent_id": "TQ-B1-C1-SEC",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.fabric_activator.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "approved_stage",
    "active_policy",
    "loaded_sha",
    "consumer_trace",
    "rollback"
  ],
  "rollback_or_recovery": "OWNER_SCOPED_COMPENSATION",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "wrong owner/receipt/effect/class boundary",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-C1"
}
```

### TQ-CHILD-WO-B1-C2-POS

```json
{
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "HGK_GWO",
  "expected": "VALID_RAW_CHECKER_PASS",
  "id": "TQ-CHILD-WO-B1-C2-POS",
  "native_issuer": "HGK_NATIVE_OWNER_REQUIRED",
  "operation_id": "OP::WO-B1-C2::POS",
  "oracle_first_fail": "GWO_HGK_NOT_NATIVE",
  "parent_id": "TQ-B1-C2-POS",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.hgk_native_golden.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "sbl_start",
    "issued_wo",
    "issuer",
    "lease",
    "worker_receipt",
    "readback"
  ],
  "rollback_or_recovery": "OWNER_SCOPED_COMPENSATION",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "true SBL entry -> native HGK issuer -> Hermes lease -> reversible observable result",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-C2"
}
```

### TQ-CHILD-WO-B1-C2-NEG

```json
{
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "HGK_GWO",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-WO-B1-C2-NEG",
  "native_issuer": "HGK_NATIVE_OWNER_REQUIRED",
  "operation_id": "OP::WO-B1-C2::NEG",
  "oracle_first_fail": "GWO_HGK_NOT_NATIVE",
  "parent_id": "TQ-B1-C2-NEG",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.hgk_native_golden.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "sbl_start",
    "issued_wo",
    "issuer",
    "lease",
    "worker_receipt",
    "readback"
  ],
  "rollback_or_recovery": "OWNER_SCOPED_COMPENSATION",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "ghost worker/forged permit -> GWO_HGK_NOT_NATIVE",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-C2"
}
```

### TQ-CHILD-WO-B1-C2-EDGE

```json
{
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "HGK_GWO",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-WO-B1-C2-EDGE",
  "native_issuer": "HGK_NATIVE_OWNER_REQUIRED",
  "operation_id": "OP::WO-B1-C2::EDGE",
  "oracle_first_fail": "GWO_HGK_NOT_NATIVE",
  "parent_id": "TQ-B1-C2-EDGE",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.hgk_native_golden.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "sbl_start",
    "issued_wo",
    "issuer",
    "lease",
    "worker_receipt",
    "readback"
  ],
  "rollback_or_recovery": "OWNER_SCOPED_COMPENSATION",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "domain-relevant stale version/lease/TTL/HEAD only if applicable",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-C2"
}
```

### TQ-CHILD-WO-B1-C2-SEC

```json
{
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "HGK_GWO",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-WO-B1-C2-SEC",
  "native_issuer": "HGK_NATIVE_OWNER_REQUIRED",
  "operation_id": "OP::WO-B1-C2::SEC",
  "oracle_first_fail": "GWO_HGK_NOT_NATIVE",
  "parent_id": "TQ-B1-C2-SEC",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.hgk_native_golden.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "sbl_start",
    "issued_wo",
    "issuer",
    "lease",
    "worker_receipt",
    "readback"
  ],
  "rollback_or_recovery": "OWNER_SCOPED_COMPENSATION",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "wrong owner/receipt/effect/class boundary",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-C2"
}
```

### TQ-CHILD-WO-B1-C3-OPS-POS

```json
{
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "SBL_GWO__INSTALL",
  "expected": "VALID_RAW_CHECKER_PASS",
  "id": "TQ-CHILD-WO-B1-C3-OPS-POS",
  "native_issuer": "HGK_NATIVE_OWNER_REQUIRED",
  "operation_id": "OP::WO-B1-C3-OPS::POS",
  "oracle_first_fail": "GWO_SBL_USER_STATE_UNPROVEN",
  "parent_id": "TQ-B1-C3-POS",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.sbl_user_golden.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "sbl_entry",
    "stack_install",
    "consent",
    "todo_add",
    "list",
    "delete",
    "uninstall"
  ],
  "rollback_or_recovery": "OWNER_SCOPED_COMPENSATION",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "separate Host install and USER effects with independent readbacks",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-C3-OPS"
}
```

### TQ-CHILD-WO-B1-C3-OPS-NEG

```json
{
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "SBL_GWO__INSTALL",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-WO-B1-C3-OPS-NEG",
  "native_issuer": "HGK_NATIVE_OWNER_REQUIRED",
  "operation_id": "OP::WO-B1-C3-OPS::NEG",
  "oracle_first_fail": "GWO_SBL_USER_STATE_UNPROVEN",
  "parent_id": "TQ-B1-C3-NEG",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.sbl_user_golden.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "sbl_entry",
    "stack_install",
    "consent",
    "todo_add",
    "list",
    "delete",
    "uninstall"
  ],
  "rollback_or_recovery": "OWNER_SCOPED_COMPENSATION",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "install count used as add success -> GWO_SBL_USER_STATE_UNPROVEN",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-C3-OPS"
}
```

### TQ-CHILD-WO-B1-C3-OPS-EDGE

```json
{
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "SBL_GWO__INSTALL",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-WO-B1-C3-OPS-EDGE",
  "native_issuer": "HGK_NATIVE_OWNER_REQUIRED",
  "operation_id": "OP::WO-B1-C3-OPS::EDGE",
  "oracle_first_fail": "GWO_SBL_USER_STATE_UNPROVEN",
  "parent_id": "TQ-B1-C3-EDGE",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.sbl_user_golden.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "sbl_entry",
    "stack_install",
    "consent",
    "todo_add",
    "list",
    "delete",
    "uninstall"
  ],
  "rollback_or_recovery": "OWNER_SCOPED_COMPENSATION",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "domain-relevant stale version/lease/TTL/HEAD only if applicable",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-C3-OPS"
}
```

### TQ-CHILD-WO-B1-C3-OPS-SEC

```json
{
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "SBL_GWO__INSTALL",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-WO-B1-C3-OPS-SEC",
  "native_issuer": "HGK_NATIVE_OWNER_REQUIRED",
  "operation_id": "OP::WO-B1-C3-OPS::SEC",
  "oracle_first_fail": "GWO_SBL_USER_STATE_UNPROVEN",
  "parent_id": "TQ-B1-C3-SEC",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.sbl_user_golden.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "sbl_entry",
    "stack_install",
    "consent",
    "todo_add",
    "list",
    "delete",
    "uninstall"
  ],
  "rollback_or_recovery": "OWNER_SCOPED_COMPENSATION",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "wrong owner/receipt/effect/class boundary",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-C3-OPS"
}
```

### TQ-CHILD-WO-B1-C3-USER-POS

```json
{
  "effect_class": "USER_DATA_EFFECT",
  "effect_key": "SBL_GWO__USER",
  "expected": "VALID_RAW_CHECKER_PASS",
  "id": "TQ-CHILD-WO-B1-C3-USER-POS",
  "native_issuer": "SBL_USER_DATA_ISSUER_REQUIRED",
  "operation_id": "OP::WO-B1-C3-USER::POS",
  "oracle_first_fail": "GWO_SBL_USER_STATE_UNPROVEN",
  "parent_id": "TQ-B1-C3-POS",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.sbl_user_golden.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "sbl_entry",
    "stack_install",
    "consent",
    "todo_add",
    "list",
    "delete",
    "uninstall"
  ],
  "rollback_or_recovery": "RESTORE_USER_RECORD_PREIMAGE",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "separate Host install and USER effects with independent readbacks",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-C3-USER"
}
```

### TQ-CHILD-WO-B1-C3-USER-NEG

```json
{
  "effect_class": "USER_DATA_EFFECT",
  "effect_key": "SBL_GWO__USER",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-WO-B1-C3-USER-NEG",
  "native_issuer": "SBL_USER_DATA_ISSUER_REQUIRED",
  "operation_id": "OP::WO-B1-C3-USER::NEG",
  "oracle_first_fail": "GWO_SBL_USER_STATE_UNPROVEN",
  "parent_id": "TQ-B1-C3-NEG",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.sbl_user_golden.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "sbl_entry",
    "stack_install",
    "consent",
    "todo_add",
    "list",
    "delete",
    "uninstall"
  ],
  "rollback_or_recovery": "RESTORE_USER_RECORD_PREIMAGE",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "install count used as add success -> GWO_SBL_USER_STATE_UNPROVEN",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-C3-USER"
}
```

### TQ-CHILD-WO-B1-C3-USER-EDGE

```json
{
  "effect_class": "USER_DATA_EFFECT",
  "effect_key": "SBL_GWO__USER",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-WO-B1-C3-USER-EDGE",
  "native_issuer": "SBL_USER_DATA_ISSUER_REQUIRED",
  "operation_id": "OP::WO-B1-C3-USER::EDGE",
  "oracle_first_fail": "GWO_SBL_USER_STATE_UNPROVEN",
  "parent_id": "TQ-B1-C3-EDGE",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.sbl_user_golden.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "sbl_entry",
    "stack_install",
    "consent",
    "todo_add",
    "list",
    "delete",
    "uninstall"
  ],
  "rollback_or_recovery": "RESTORE_USER_RECORD_PREIMAGE",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "domain-relevant stale version/lease/TTL/HEAD only if applicable",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-C3-USER"
}
```

### TQ-CHILD-WO-B1-C3-USER-SEC

```json
{
  "effect_class": "USER_DATA_EFFECT",
  "effect_key": "SBL_GWO__USER",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-WO-B1-C3-USER-SEC",
  "native_issuer": "SBL_USER_DATA_ISSUER_REQUIRED",
  "operation_id": "OP::WO-B1-C3-USER::SEC",
  "oracle_first_fail": "GWO_SBL_USER_STATE_UNPROVEN",
  "parent_id": "TQ-B1-C3-SEC",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.sbl_user_golden.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "sbl_entry",
    "stack_install",
    "consent",
    "todo_add",
    "list",
    "delete",
    "uninstall"
  ],
  "rollback_or_recovery": "RESTORE_USER_RECORD_PREIMAGE",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "wrong owner/receipt/effect/class boundary",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-C3-USER"
}
```

### TQ-CHILD-WO-B1-C4-POS

```json
{
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "EXTERNAL_GRANT",
  "expected": "VALID_RAW_CHECKER_PASS",
  "id": "TQ-CHILD-WO-B1-C4-POS",
  "native_issuer": "HGK_NATIVE_OWNER_REQUIRED",
  "operation_id": "OP::WO-B1-C4::POS",
  "oracle_first_fail": "EXTERNAL_SCOPE_ESCAPED",
  "parent_id": "TQ-B1-C4-POS",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.delegation.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "owner_scope",
    "ttl",
    "principal",
    "revocation",
    "zero_scope_escape"
  ],
  "rollback_or_recovery": "OWNER_SCOPED_COMPENSATION",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "bounded external grant and no residual capability on revoke",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-C4"
}
```

### TQ-CHILD-WO-B1-C4-NEG

```json
{
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "EXTERNAL_GRANT",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-WO-B1-C4-NEG",
  "native_issuer": "HGK_NATIVE_OWNER_REQUIRED",
  "operation_id": "OP::WO-B1-C4::NEG",
  "oracle_first_fail": "EXTERNAL_SCOPE_ESCAPED",
  "parent_id": "TQ-B1-C4-NEG",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.delegation.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "owner_scope",
    "ttl",
    "principal",
    "revocation",
    "zero_scope_escape"
  ],
  "rollback_or_recovery": "OWNER_SCOPED_COMPENSATION",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "scope expansion -> EXTERNAL_SCOPE_ESCAPED",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-C4"
}
```

### TQ-CHILD-WO-B1-C4-EDGE

```json
{
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "EXTERNAL_GRANT",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-WO-B1-C4-EDGE",
  "native_issuer": "HGK_NATIVE_OWNER_REQUIRED",
  "operation_id": "OP::WO-B1-C4::EDGE",
  "oracle_first_fail": "EXTERNAL_SCOPE_ESCAPED",
  "parent_id": "TQ-B1-C4-EDGE",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.delegation.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "owner_scope",
    "ttl",
    "principal",
    "revocation",
    "zero_scope_escape"
  ],
  "rollback_or_recovery": "OWNER_SCOPED_COMPENSATION",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "domain-relevant stale version/lease/TTL/HEAD only if applicable",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-C4"
}
```

### TQ-CHILD-WO-B1-C4-SEC

```json
{
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "EXTERNAL_GRANT",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-WO-B1-C4-SEC",
  "native_issuer": "HGK_NATIVE_OWNER_REQUIRED",
  "operation_id": "OP::WO-B1-C4::SEC",
  "oracle_first_fail": "EXTERNAL_SCOPE_ESCAPED",
  "parent_id": "TQ-B1-C4-SEC",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.delegation.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "owner_scope",
    "ttl",
    "principal",
    "revocation",
    "zero_scope_escape"
  ],
  "rollback_or_recovery": "OWNER_SCOPED_COMPENSATION",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "wrong owner/receipt/effect/class boundary",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-C4"
}
```

### TQ-CHILD-WO-B1-C5-POS

```json
{
  "effect_class": "REPOSITORY_WRITE",
  "effect_key": "CODEX_MINPATCH",
  "expected": "VALID_RAW_CHECKER_PASS",
  "id": "TQ-CHILD-WO-B1-C5-POS",
  "native_issuer": "REPO_Codex_P4_OWNER_BOUND",
  "operation_id": "OP::WO-B1-C5::POS",
  "oracle_first_fail": "UNBOUNDED_PATCH_OR_REGRESSION",
  "parent_id": "TQ-B1-C5-POS",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.bounded_coding.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "write_scope",
    "preimage",
    "red_test",
    "patch",
    "green_test",
    "checker"
  ],
  "rollback_or_recovery": "RESTORE_APPROVED_PREIMAGE",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "only affected files changed and full regression independent",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-C5"
}
```

### TQ-CHILD-WO-B1-C5-NEG

```json
{
  "effect_class": "REPOSITORY_WRITE",
  "effect_key": "CODEX_MINPATCH",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-WO-B1-C5-NEG",
  "native_issuer": "REPO_Codex_P4_OWNER_BOUND",
  "operation_id": "OP::WO-B1-C5::NEG",
  "oracle_first_fail": "UNBOUNDED_PATCH_OR_REGRESSION",
  "parent_id": "TQ-B1-C5-NEG",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.bounded_coding.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "write_scope",
    "preimage",
    "red_test",
    "patch",
    "green_test",
    "checker"
  ],
  "rollback_or_recovery": "RESTORE_APPROVED_PREIMAGE",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "checker edits same diff or no red test -> UNBOUNDED_PATCH_OR_REGRESSION",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-C5"
}
```

### TQ-CHILD-WO-B1-C5-EDGE

```json
{
  "effect_class": "REPOSITORY_WRITE",
  "effect_key": "CODEX_MINPATCH",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-WO-B1-C5-EDGE",
  "native_issuer": "REPO_Codex_P4_OWNER_BOUND",
  "operation_id": "OP::WO-B1-C5::EDGE",
  "oracle_first_fail": "UNBOUNDED_PATCH_OR_REGRESSION",
  "parent_id": "TQ-B1-C5-EDGE",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.bounded_coding.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "write_scope",
    "preimage",
    "red_test",
    "patch",
    "green_test",
    "checker"
  ],
  "rollback_or_recovery": "RESTORE_APPROVED_PREIMAGE",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "domain-relevant stale version/lease/TTL/HEAD only if applicable",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-C5"
}
```

### TQ-CHILD-WO-B1-C5-SEC

```json
{
  "effect_class": "REPOSITORY_WRITE",
  "effect_key": "CODEX_MINPATCH",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-WO-B1-C5-SEC",
  "native_issuer": "REPO_Codex_P4_OWNER_BOUND",
  "operation_id": "OP::WO-B1-C5::SEC",
  "oracle_first_fail": "UNBOUNDED_PATCH_OR_REGRESSION",
  "parent_id": "TQ-B1-C5-SEC",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.bounded_coding.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "write_scope",
    "preimage",
    "red_test",
    "patch",
    "green_test",
    "checker"
  ],
  "rollback_or_recovery": "RESTORE_APPROVED_PREIMAGE",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "wrong owner/receipt/effect/class boundary",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-C5"
}
```

### TQ-CHILD-WO-B1-C6-POS

```json
{
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "REVOKE_RACE",
  "expected": "VALID_RAW_CHECKER_PASS",
  "id": "TQ-CHILD-WO-B1-C6-POS",
  "native_issuer": "HGK_NATIVE_OWNER_REQUIRED",
  "operation_id": "OP::WO-B1-C6::POS",
  "oracle_first_fail": "REVOKED_TOKEN_REPLAY",
  "parent_id": "TQ-B1-C6-POS",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.revoke_boundary.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "old_nonce",
    "revocation_epoch",
    "attempt_after_revoke",
    "denied_effect"
  ],
  "rollback_or_recovery": "OWNER_SCOPED_COMPENSATION",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "post-revoke use fails before spawn; existing effects reconciled",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-C6"
}
```

### TQ-CHILD-WO-B1-C6-NEG

```json
{
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "REVOKE_RACE",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-WO-B1-C6-NEG",
  "native_issuer": "HGK_NATIVE_OWNER_REQUIRED",
  "operation_id": "OP::WO-B1-C6::NEG",
  "oracle_first_fail": "REVOKED_TOKEN_REPLAY",
  "parent_id": "TQ-B1-C6-NEG",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.revoke_boundary.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "old_nonce",
    "revocation_epoch",
    "attempt_after_revoke",
    "denied_effect"
  ],
  "rollback_or_recovery": "OWNER_SCOPED_COMPENSATION",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "reused token after revoke -> REVOKED_TOKEN_REPLAY",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-C6"
}
```

### TQ-CHILD-WO-B1-C6-EDGE

```json
{
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "REVOKE_RACE",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-WO-B1-C6-EDGE",
  "native_issuer": "HGK_NATIVE_OWNER_REQUIRED",
  "operation_id": "OP::WO-B1-C6::EDGE",
  "oracle_first_fail": "REVOKED_TOKEN_REPLAY",
  "parent_id": "TQ-B1-C6-EDGE",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.revoke_boundary.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "old_nonce",
    "revocation_epoch",
    "attempt_after_revoke",
    "denied_effect"
  ],
  "rollback_or_recovery": "OWNER_SCOPED_COMPENSATION",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "domain-relevant stale version/lease/TTL/HEAD only if applicable",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-C6"
}
```

### TQ-CHILD-WO-B1-C6-SEC

```json
{
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "REVOKE_RACE",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-WO-B1-C6-SEC",
  "native_issuer": "HGK_NATIVE_OWNER_REQUIRED",
  "operation_id": "OP::WO-B1-C6::SEC",
  "oracle_first_fail": "REVOKED_TOKEN_REPLAY",
  "parent_id": "TQ-B1-C6-SEC",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.revoke_boundary.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "old_nonce",
    "revocation_epoch",
    "attempt_after_revoke",
    "denied_effect"
  ],
  "rollback_or_recovery": "OWNER_SCOPED_COMPENSATION",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "wrong owner/receipt/effect/class boundary",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-C6"
}
```

### TQ-CHILD-OBS-B1-C7-POS

```json
{
  "effect_class": "READ_ONLY_PROBE",
  "effect_key": "FOUR_LAYER_ID",
  "expected": "VALID_RAW_CHECKER_PASS",
  "id": "TQ-CHILD-OBS-B1-C7-POS",
  "native_issuer": "NONE_READ_ONLY",
  "operation_id": "OP::OBS-B1-C7::POS",
  "oracle_first_fail": "LOADED_BINARY_MISMATCH",
  "parent_id": "TQ-B1-C7-POS",
  "postcondition": "same effect, separately observed no mutation",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.loaded_identity.RAW@1",
  "required_binding": "READ_SCOPE",
  "required_fields": [
    "source_sha",
    "installed_binary_sha",
    "host_loaded_sha",
    "served_model",
    "policy_epoch"
  ],
  "rollback_or_recovery": "INVALIDATE_READ_CACHE",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "all four identity layers tied to same subject, not merely file on disk",
  "witness_status": "NOT_RUN",
  "workorder_id": "OBS-B1-C7"
}
```

### TQ-CHILD-OBS-B1-C7-NEG

```json
{
  "effect_class": "READ_ONLY_PROBE",
  "effect_key": "FOUR_LAYER_ID",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-OBS-B1-C7-NEG",
  "native_issuer": "NONE_READ_ONLY",
  "operation_id": "OP::OBS-B1-C7::NEG",
  "oracle_first_fail": "LOADED_BINARY_MISMATCH",
  "parent_id": "TQ-B1-C7-NEG",
  "postcondition": "same effect, separately observed no mutation",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.loaded_identity.RAW@1",
  "required_binding": "READ_SCOPE",
  "required_fields": [
    "source_sha",
    "installed_binary_sha",
    "host_loaded_sha",
    "served_model",
    "policy_epoch"
  ],
  "rollback_or_recovery": "INVALIDATE_READ_CACHE",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "green patch with stale loaded binary -> LOADED_BINARY_MISMATCH",
  "witness_status": "NOT_RUN",
  "workorder_id": "OBS-B1-C7"
}
```

### TQ-CHILD-OBS-B1-C7-EDGE

```json
{
  "effect_class": "READ_ONLY_PROBE",
  "effect_key": "FOUR_LAYER_ID",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-OBS-B1-C7-EDGE",
  "native_issuer": "NONE_READ_ONLY",
  "operation_id": "OP::OBS-B1-C7::EDGE",
  "oracle_first_fail": "LOADED_BINARY_MISMATCH",
  "parent_id": "TQ-B1-C7-EDGE",
  "postcondition": "same effect, separately observed no mutation",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.loaded_identity.RAW@1",
  "required_binding": "READ_SCOPE",
  "required_fields": [
    "source_sha",
    "installed_binary_sha",
    "host_loaded_sha",
    "served_model",
    "policy_epoch"
  ],
  "rollback_or_recovery": "INVALIDATE_READ_CACHE",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "domain-relevant stale version/lease/TTL/HEAD only if applicable",
  "witness_status": "NOT_RUN",
  "workorder_id": "OBS-B1-C7"
}
```

### TQ-CHILD-OBS-B1-C7-SEC

```json
{
  "effect_class": "READ_ONLY_PROBE",
  "effect_key": "FOUR_LAYER_ID",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-OBS-B1-C7-SEC",
  "native_issuer": "NONE_READ_ONLY",
  "operation_id": "OP::OBS-B1-C7::SEC",
  "oracle_first_fail": "LOADED_BINARY_MISMATCH",
  "parent_id": "TQ-B1-C7-SEC",
  "postcondition": "same effect, separately observed no mutation",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.loaded_identity.RAW@1",
  "required_binding": "READ_SCOPE",
  "required_fields": [
    "source_sha",
    "installed_binary_sha",
    "host_loaded_sha",
    "served_model",
    "policy_epoch"
  ],
  "rollback_or_recovery": "INVALIDATE_READ_CACHE",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "wrong owner/receipt/effect/class boundary",
  "witness_status": "NOT_RUN",
  "workorder_id": "OBS-B1-C7"
}
```

### TQ-CHILD-WO-B1-C8-POS

```json
{
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "NATIVE_SUCCESSOR",
  "expected": "VALID_RAW_CHECKER_PASS",
  "id": "TQ-CHILD-WO-B1-C8-POS",
  "native_issuer": "HGK_NATIVE_OWNER_REQUIRED",
  "operation_id": "OP::WO-B1-C8::POS",
  "oracle_first_fail": "NATIVE_SUCCESSOR_NOT_PROVEN",
  "parent_id": "TQ-B1-C8-POS",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.post_revoke_successor.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "external_stop",
    "ledger_cursor",
    "issuer",
    "successor_wo",
    "native_origin"
  ],
  "rollback_or_recovery": "OWNER_SCOPED_COMPENSATION",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "fresh separate session native trigger progresses after external account revoked",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-C8"
}
```

### TQ-CHILD-WO-B1-C8-NEG

```json
{
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "NATIVE_SUCCESSOR",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-WO-B1-C8-NEG",
  "native_issuer": "HGK_NATIVE_OWNER_REQUIRED",
  "operation_id": "OP::WO-B1-C8::NEG",
  "oracle_first_fail": "NATIVE_SUCCESSOR_NOT_PROVEN",
  "parent_id": "TQ-B1-C8-NEG",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.post_revoke_successor.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "external_stop",
    "ledger_cursor",
    "issuer",
    "successor_wo",
    "native_origin"
  ],
  "rollback_or_recovery": "OWNER_SCOPED_COMPENSATION",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "successor still external-triggered -> NATIVE_SUCCESSOR_NOT_PROVEN",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-C8"
}
```

### TQ-CHILD-WO-B1-C8-EDGE

```json
{
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "NATIVE_SUCCESSOR",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-WO-B1-C8-EDGE",
  "native_issuer": "HGK_NATIVE_OWNER_REQUIRED",
  "operation_id": "OP::WO-B1-C8::EDGE",
  "oracle_first_fail": "NATIVE_SUCCESSOR_NOT_PROVEN",
  "parent_id": "TQ-B1-C8-EDGE",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.post_revoke_successor.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "external_stop",
    "ledger_cursor",
    "issuer",
    "successor_wo",
    "native_origin"
  ],
  "rollback_or_recovery": "OWNER_SCOPED_COMPENSATION",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "domain-relevant stale version/lease/TTL/HEAD only if applicable",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-C8"
}
```

### TQ-CHILD-WO-B1-C8-SEC

```json
{
  "effect_class": "HOST_OPERATIONS",
  "effect_key": "NATIVE_SUCCESSOR",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-WO-B1-C8-SEC",
  "native_issuer": "HGK_NATIVE_OWNER_REQUIRED",
  "operation_id": "OP::WO-B1-C8::SEC",
  "oracle_first_fail": "NATIVE_SUCCESSOR_NOT_PROVEN",
  "parent_id": "TQ-B1-C8-SEC",
  "postcondition": "same operation_id + own effect witness, no sibling reuse",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.post_revoke_successor.RAW@1",
  "required_binding": "OWNER_APPROVED_EFFECT_BINDING",
  "required_fields": [
    "external_stop",
    "ledger_cursor",
    "issuer",
    "successor_wo",
    "native_origin"
  ],
  "rollback_or_recovery": "OWNER_SCOPED_COMPENSATION",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "wrong owner/receipt/effect/class boundary",
  "witness_status": "NOT_RUN",
  "workorder_id": "WO-B1-C8"
}
```

### TQ-CHILD-OBS-B1-C9-POS

```json
{
  "effect_class": "READ_ONLY_PROBE",
  "effect_key": "TRIPLE_GWO",
  "expected": "VALID_RAW_CHECKER_PASS",
  "id": "TQ-CHILD-OBS-B1-C9-POS",
  "native_issuer": "NONE_READ_ONLY",
  "operation_id": "OP::OBS-B1-C9::POS",
  "oracle_first_fail": "GWO_RECEIPT_ALIAS",
  "parent_id": "TQ-B1-C9-POS",
  "postcondition": "same effect, separately observed no mutation",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.triple_golden_join.RAW@1",
  "required_binding": "READ_SCOPE",
  "required_fields": [
    "fabric_receipt",
    "hgk_receipt",
    "sbl_receipt",
    "revoke_receipt",
    "join_subject"
  ],
  "rollback_or_recovery": "INVALIDATE_READ_CACHE",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "3 different domain receipts, all same intended crosswalk, not aliases",
  "witness_status": "NOT_RUN",
  "workorder_id": "OBS-B1-C9"
}
```

### TQ-CHILD-OBS-B1-C9-NEG

```json
{
  "effect_class": "READ_ONLY_PROBE",
  "effect_key": "TRIPLE_GWO",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-OBS-B1-C9-NEG",
  "native_issuer": "NONE_READ_ONLY",
  "operation_id": "OP::OBS-B1-C9::NEG",
  "oracle_first_fail": "GWO_RECEIPT_ALIAS",
  "parent_id": "TQ-B1-C9-NEG",
  "postcondition": "same effect, separately observed no mutation",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.triple_golden_join.RAW@1",
  "required_binding": "READ_SCOPE",
  "required_fields": [
    "fabric_receipt",
    "hgk_receipt",
    "sbl_receipt",
    "revoke_receipt",
    "join_subject"
  ],
  "rollback_or_recovery": "INVALIDATE_READ_CACHE",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "same receipt reused -> GWO_RECEIPT_ALIAS",
  "witness_status": "NOT_RUN",
  "workorder_id": "OBS-B1-C9"
}
```

### TQ-CHILD-OBS-B1-C9-EDGE

```json
{
  "effect_class": "READ_ONLY_PROBE",
  "effect_key": "TRIPLE_GWO",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-OBS-B1-C9-EDGE",
  "native_issuer": "NONE_READ_ONLY",
  "operation_id": "OP::OBS-B1-C9::EDGE",
  "oracle_first_fail": "GWO_RECEIPT_ALIAS",
  "parent_id": "TQ-B1-C9-EDGE",
  "postcondition": "same effect, separately observed no mutation",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.triple_golden_join.RAW@1",
  "required_binding": "READ_SCOPE",
  "required_fields": [
    "fabric_receipt",
    "hgk_receipt",
    "sbl_receipt",
    "revoke_receipt",
    "join_subject"
  ],
  "rollback_or_recovery": "INVALIDATE_READ_CACHE",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "domain-relevant stale version/lease/TTL/HEAD only if applicable",
  "witness_status": "NOT_RUN",
  "workorder_id": "OBS-B1-C9"
}
```

### TQ-CHILD-OBS-B1-C9-SEC

```json
{
  "effect_class": "READ_ONLY_PROBE",
  "effect_key": "TRIPLE_GWO",
  "expected": "NACK_OR_SAFE_RECONCILE",
  "id": "TQ-CHILD-OBS-B1-C9-SEC",
  "native_issuer": "NONE_READ_ONLY",
  "operation_id": "OP::OBS-B1-C9::SEC",
  "oracle_first_fail": "GWO_RECEIPT_ALIAS",
  "parent_id": "TQ-B1-C9-SEC",
  "postcondition": "same effect, separately observed no mutation",
  "precondition": "exact subject, currentness and intended resource before effect",
  "readback_schema": "B1.DOMAIN.triple_golden_join.RAW@1",
  "required_binding": "READ_SCOPE",
  "required_fields": [
    "fabric_receipt",
    "hgk_receipt",
    "sbl_receipt",
    "revoke_receipt",
    "join_subject"
  ],
  "rollback_or_recovery": "INVALIDATE_READ_CACHE",
  "schema": "B1.TQAEP.EFFECT_CHILD@3",
  "stimulus": "wrong owner/receipt/effect/class boundary",
  "witness_status": "NOT_RUN",
  "workorder_id": "OBS-B1-C9"
}
```

## 4. 38 Node 個別 Compiler / Writer / Oracle 與九項未解 source

下表列 **真實既有技能名稱**、Writer 目標檔內 Node 索引、可機檢的預期 evidence path 命名規則；該路徑是未產生的 *ExpectedArtifactLocator*，不是目前存在的 RawReceipt。九筆 `UNRESOLVED` 保留個別 `CR-NODE-xxx`，沒有 Owner 原文不得假補。

### B1-N01-01｜N01 / HOLD_OWNER_SCHEMA_ABI

```json
{
  "expected_raw_oracle_locator": "N01/NODE-B1-N01-01-checker-raw.json",
  "first_fail": "SCHEMA_OR_OWNER_UNBOUND",
  "native_operation": "SKILL_CONTRACT_NOT_GENERIC_VALIDATE_AND_COMPILE",
  "native_skill_candidates": [
    "pipd-route-intake",
    "pipd-authority-source",
    "pipd-profile-tailor",
    "pipd-pi-compile"
  ],
  "node_id": "B1-N01-01",
  "oracle_negative": "remove required source/ABI/permission -> deterministic first fail, no output",
  "oracle_positive": "typed native input/output roundtrip with nonempty subject & hash",
  "original_pseudofunction": "validate_and_compile_identity",
  "owner_writer": "PI",
  "precondition": "real source+owner+schema/ABI resolution before native build",
  "required_schema_id": "RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN",
  "source_clause_candidate": "PIPD_LS_DOC-02_2026-10-07_r2_HIGH_RETENTION_AUDIT_PATCHED_FULL_REPAIR_FULL_SUBSTANTIVE_BODY (1).md@L2; sha256:a021998dd3b63015e89af1dd40e0b413744a69b872da46c6bf5f4d92f7f23d0b; literal:artifact_id: \"PIPD_LS_DOC-02\"",
  "source_owner_signature_required": true,
  "status": "HOLD_OWNER_SCHEMA_ABI",
  "writer_artifact_locator": "N01/NODE-B1-N01-01-writer.json"
}
```

### B1-N01-02｜N01 / HOLD_SOURCE_CLAUSE

```json
{
  "expected_raw_oracle_locator": "N01/NODE-B1-N01-02-checker-raw.json",
  "first_fail": "CLAUSE_LOCATOR_UNRESOLVED",
  "native_operation": "SKILL_CONTRACT_NOT_GENERIC_VALIDATE_AND_COMPILE",
  "native_skill_candidates": [
    "pipd-route-intake",
    "pipd-authority-source",
    "pipd-profile-tailor",
    "pipd-pi-compile"
  ],
  "node_id": "B1-N01-02",
  "oracle_negative": "remove required source/ABI/permission -> deterministic first fail, no output",
  "oracle_positive": "typed native input/output roundtrip with nonempty subject & hash",
  "original_pseudofunction": "validate_and_compile_source_authority",
  "owner_writer": "PI",
  "precondition": "real source+owner+schema/ABI resolution before native build",
  "required_schema_id": "RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN",
  "source_clause_candidate": "PIPD_LS_DOC-02_2026-10-07_r2_HIGH_RETENTION_AUDIT_PATCHED_FULL_REPAIR_FULL_SUBSTANTIVE_BODY (1).md:UNRESOLVED; sha256:a021998dd3b63015e89af1dd40e0b413744a69b872da46c6bf5f4d92f7f23d0b; literal:",
  "source_owner_signature_required": true,
  "status": "HOLD_SOURCE_CLAUSE",
  "writer_artifact_locator": "N01/NODE-B1-N01-02-writer.json"
}
```

### B1-N01-03｜N01 / HOLD_SOURCE_CLAUSE

```json
{
  "expected_raw_oracle_locator": "N01/NODE-B1-N01-03-checker-raw.json",
  "first_fail": "CLAUSE_LOCATOR_UNRESOLVED",
  "native_operation": "SKILL_CONTRACT_NOT_GENERIC_VALIDATE_AND_COMPILE",
  "native_skill_candidates": [
    "pipd-route-intake",
    "pipd-authority-source",
    "pipd-profile-tailor",
    "pipd-pi-compile"
  ],
  "node_id": "B1-N01-03",
  "oracle_negative": "remove required source/ABI/permission -> deterministic first fail, no output",
  "oracle_positive": "typed native input/output roundtrip with nonempty subject & hash",
  "original_pseudofunction": "validate_and_compile_intent_card",
  "owner_writer": "PI",
  "precondition": "real source+owner+schema/ABI resolution before native build",
  "required_schema_id": "RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN",
  "source_clause_candidate": "PIPD_LS_DOC-02_2026-10-07_r2_HIGH_RETENTION_AUDIT_PATCHED_FULL_REPAIR_FULL_SUBSTANTIVE_BODY (1).md:UNRESOLVED; sha256:a021998dd3b63015e89af1dd40e0b413744a69b872da46c6bf5f4d92f7f23d0b; literal:",
  "source_owner_signature_required": true,
  "status": "HOLD_SOURCE_CLAUSE",
  "writer_artifact_locator": "N01/NODE-B1-N01-03-writer.json"
}
```

### B1-N01-04｜N01 / HOLD_SOURCE_CLAUSE

```json
{
  "expected_raw_oracle_locator": "N01/NODE-B1-N01-04-checker-raw.json",
  "first_fail": "CLAUSE_LOCATOR_UNRESOLVED",
  "native_operation": "SKILL_CONTRACT_NOT_GENERIC_VALIDATE_AND_COMPILE",
  "native_skill_candidates": [
    "pipd-route-intake",
    "pipd-authority-source",
    "pipd-profile-tailor",
    "pipd-pi-compile"
  ],
  "node_id": "B1-N01-04",
  "oracle_negative": "remove required source/ABI/permission -> deterministic first fail, no output",
  "oracle_positive": "typed native input/output roundtrip with nonempty subject & hash",
  "original_pseudofunction": "validate_and_compile_profile_binding",
  "owner_writer": "PI",
  "precondition": "real source+owner+schema/ABI resolution before native build",
  "required_schema_id": "RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN",
  "source_clause_candidate": "PIPD_LS_DOC-02_2026-10-07_r2_HIGH_RETENTION_AUDIT_PATCHED_FULL_REPAIR_FULL_SUBSTANTIVE_BODY (1).md:UNRESOLVED; sha256:a021998dd3b63015e89af1dd40e0b413744a69b872da46c6bf5f4d92f7f23d0b; literal:",
  "source_owner_signature_required": true,
  "status": "HOLD_SOURCE_CLAUSE",
  "writer_artifact_locator": "N01/NODE-B1-N01-04-writer.json"
}
```

### B1-N01-05｜N01 / HOLD_OWNER_SCHEMA_ABI

```json
{
  "expected_raw_oracle_locator": "N01/NODE-B1-N01-05-checker-raw.json",
  "first_fail": "SCHEMA_OR_OWNER_UNBOUND",
  "native_operation": "SKILL_CONTRACT_NOT_GENERIC_VALIDATE_AND_COMPILE",
  "native_skill_candidates": [
    "pipd-route-intake",
    "pipd-authority-source",
    "pipd-profile-tailor",
    "pipd-pi-compile"
  ],
  "node_id": "B1-N01-05",
  "oracle_negative": "remove required source/ABI/permission -> deterministic first fail, no output",
  "oracle_positive": "typed native input/output roundtrip with nonempty subject & hash",
  "original_pseudofunction": "validate_and_compile_requirements_spec",
  "owner_writer": "PI",
  "precondition": "real source+owner+schema/ABI resolution before native build",
  "required_schema_id": "RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN",
  "source_clause_candidate": "PIPD_LS_DOC-02_2026-10-07_r2_HIGH_RETENTION_AUDIT_PATCHED_FULL_REPAIR_FULL_SUBSTANTIVE_BODY (1).md@L11193; sha256:a021998dd3b63015e89af1dd40e0b413744a69b872da46c6bf5f4d92f7f23d0b; literal:      \"field\": \"source_clause\",",
  "source_owner_signature_required": true,
  "status": "HOLD_OWNER_SCHEMA_ABI",
  "writer_artifact_locator": "N01/NODE-B1-N01-05-writer.json"
}
```

### B1-N01-06｜N01 / HOLD_OWNER_SCHEMA_ABI

```json
{
  "expected_raw_oracle_locator": "N01/NODE-B1-N01-06-checker-raw.json",
  "first_fail": "SCHEMA_OR_OWNER_UNBOUND",
  "native_operation": "SKILL_CONTRACT_NOT_GENERIC_VALIDATE_AND_COMPILE",
  "native_skill_candidates": [
    "pipd-route-intake",
    "pipd-authority-source",
    "pipd-profile-tailor",
    "pipd-pi-compile"
  ],
  "node_id": "B1-N01-06",
  "oracle_negative": "remove required source/ABI/permission -> deterministic first fail, no output",
  "oracle_positive": "typed native input/output roundtrip with nonempty subject & hash",
  "original_pseudofunction": "validate_and_compile_oracle_conflicts",
  "owner_writer": "PI",
  "precondition": "real source+owner+schema/ABI resolution before native build",
  "required_schema_id": "RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN",
  "source_clause_candidate": "PIPD_LS_DOC-02_2026-10-07_r2_HIGH_RETENTION_AUDIT_PATCHED_FULL_REPAIR_FULL_SUBSTANTIVE_BODY (1).md@L62; sha256:a021998dd3b63015e89af1dd40e0b413744a69b872da46c6bf5f4d92f7f23d0b; literal:**Mission:** compile `SOURCE → INTENT → ATOMIC REQUIREMENT → CANONICAL OBJECT → ARCHITECTURE/INTERFACE → SPEC",
  "source_owner_signature_required": true,
  "status": "HOLD_OWNER_SCHEMA_ABI",
  "writer_artifact_locator": "N01/NODE-B1-N01-06-writer.json"
}
```

### B1-N01-07｜N01 / HOLD_SOURCE_CLAUSE

```json
{
  "expected_raw_oracle_locator": "N01/NODE-B1-N01-07-checker-raw.json",
  "first_fail": "CLAUSE_LOCATOR_UNRESOLVED",
  "native_operation": "SKILL_CONTRACT_NOT_GENERIC_VALIDATE_AND_COMPILE",
  "native_skill_candidates": [
    "pipd-route-intake",
    "pipd-authority-source",
    "pipd-profile-tailor",
    "pipd-pi-compile"
  ],
  "node_id": "B1-N01-07",
  "oracle_negative": "remove required source/ABI/permission -> deterministic first fail, no output",
  "oracle_positive": "typed native input/output roundtrip with nonempty subject & hash",
  "original_pseudofunction": "validate_and_compile_trace_links",
  "owner_writer": "PI",
  "precondition": "real source+owner+schema/ABI resolution before native build",
  "required_schema_id": "RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN",
  "source_clause_candidate": "PIPD_LS_DOC-02_2026-10-07_r2_HIGH_RETENTION_AUDIT_PATCHED_FULL_REPAIR_FULL_SUBSTANTIVE_BODY (1).md:UNRESOLVED; sha256:a021998dd3b63015e89af1dd40e0b413744a69b872da46c6bf5f4d92f7f23d0b; literal:",
  "source_owner_signature_required": true,
  "status": "HOLD_SOURCE_CLAUSE",
  "writer_artifact_locator": "N01/NODE-B1-N01-07-writer.json"
}
```

### B1-N01-08｜N01 / HOLD_OWNER_SCHEMA_ABI

```json
{
  "expected_raw_oracle_locator": "N01/NODE-B1-N01-08-checker-raw.json",
  "first_fail": "SCHEMA_OR_OWNER_UNBOUND",
  "native_operation": "SKILL_CONTRACT_NOT_GENERIC_VALIDATE_AND_COMPILE",
  "native_skill_candidates": [
    "pipd-route-intake",
    "pipd-authority-source",
    "pipd-profile-tailor",
    "pipd-pi-compile"
  ],
  "node_id": "B1-N01-08",
  "oracle_negative": "remove required source/ABI/permission -> deterministic first fail, no output",
  "oracle_positive": "typed native input/output roundtrip with nonempty subject & hash",
  "original_pseudofunction": "validate_and_compile_claim_boundary",
  "owner_writer": "PI",
  "precondition": "real source+owner+schema/ABI resolution before native build",
  "required_schema_id": "RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN",
  "source_clause_candidate": "PIPD_LS_DOC-02_2026-10-07_r2_HIGH_RETENTION_AUDIT_PATCHED_FULL_REPAIR_FULL_SUBSTANTIVE_BODY (1).md@L19; sha256:a021998dd3b63015e89af1dd40e0b413744a69b872da46c6bf5f4d92f7f23d0b; literal:claim_ceiling: \"DOC02_R2_FULL_SUBSTANTIVE_BODY_MATERIALIZED_AUTHOR_SIDE_VALIDATED_PENDING_INDEPENDENT_REAUDIT_",
  "source_owner_signature_required": true,
  "status": "HOLD_OWNER_SCHEMA_ABI",
  "writer_artifact_locator": "N01/NODE-B1-N01-08-writer.json"
}
```

### B1-N02-01｜N02 / HOLD_OWNER_SCHEMA_ABI

```json
{
  "expected_raw_oracle_locator": "N02/NODE-B1-N02-01-checker-raw.json",
  "first_fail": "SCHEMA_OR_OWNER_UNBOUND",
  "native_operation": "SKILL_CONTRACT_NOT_GENERIC_VALIDATE_AND_COMPILE",
  "native_skill_candidates": [
    "pipd-pd-bind"
  ],
  "node_id": "B1-N02-01",
  "oracle_negative": "remove required source/ABI/permission -> deterministic first fail, no output",
  "oracle_positive": "typed native input/output roundtrip with nonempty subject & hash",
  "original_pseudofunction": "validate_and_compile_identity",
  "owner_writer": "PD",
  "precondition": "real source+owner+schema/ABI resolution before native build",
  "required_schema_id": "RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN",
  "source_clause_candidate": "PIPD_LS_DOC-03_2026-10-07_r2_AUDIT_REPAIR_FULL_SUBSTANTIVE_BODY.md@L2; sha256:d89d82dcd2c8603ec6b86c5ec8c40845e4594bc181adf5272bd48a3de7c88f0f; literal:artifact_id: PIPD_LS_DOC-03",
  "source_owner_signature_required": true,
  "status": "HOLD_OWNER_SCHEMA_ABI",
  "writer_artifact_locator": "N02/NODE-B1-N02-01-writer.json"
}
```

### B1-N02-02｜N02 / HOLD_OWNER_SCHEMA_ABI

```json
{
  "expected_raw_oracle_locator": "N02/NODE-B1-N02-02-checker-raw.json",
  "first_fail": "SCHEMA_OR_OWNER_UNBOUND",
  "native_operation": "SKILL_CONTRACT_NOT_GENERIC_VALIDATE_AND_COMPILE",
  "native_skill_candidates": [
    "pipd-pd-bind"
  ],
  "node_id": "B1-N02-02",
  "oracle_negative": "remove required source/ABI/permission -> deterministic first fail, no output",
  "oracle_positive": "typed native input/output roundtrip with nonempty subject & hash",
  "original_pseudofunction": "validate_and_compile_repo_context",
  "owner_writer": "PD",
  "precondition": "real source+owner+schema/ABI resolution before native build",
  "required_schema_id": "RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN",
  "source_clause_candidate": "PIPD_LS_DOC-03_2026-10-07_r2_AUDIT_REPAIR_FULL_SUBSTANTIVE_BODY.md@L188; sha256:d89d82dcd2c8603ec6b86c5ec8c40845e4594bc181adf5272bd48a3de7c88f0f; literal:`FrozenPIReference`, canonical `RepoContext`, `CurrentnessRecord/CurrentnessDiff`, `LateBoundResolutionLedger`",
  "source_owner_signature_required": true,
  "status": "HOLD_OWNER_SCHEMA_ABI",
  "writer_artifact_locator": "N02/NODE-B1-N02-02-writer.json"
}
```

### B1-N02-03｜N02 / HOLD_OWNER_SCHEMA_ABI

```json
{
  "expected_raw_oracle_locator": "N02/NODE-B1-N02-03-checker-raw.json",
  "first_fail": "SCHEMA_OR_OWNER_UNBOUND",
  "native_operation": "SKILL_CONTRACT_NOT_GENERIC_VALIDATE_AND_COMPILE",
  "native_skill_candidates": [
    "pipd-pd-bind"
  ],
  "node_id": "B1-N02-03",
  "oracle_negative": "remove required source/ABI/permission -> deterministic first fail, no output",
  "oracle_positive": "typed native input/output roundtrip with nonempty subject & hash",
  "original_pseudofunction": "validate_and_compile_workorder_latebind",
  "owner_writer": "PD",
  "precondition": "real source+owner+schema/ABI resolution before native build",
  "required_schema_id": "RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN",
  "source_clause_candidate": "PIPD_LS_DOC-03_2026-10-07_r2_AUDIT_REPAIR_FULL_SUBSTANTIVE_BODY.md@L335; sha256:d89d82dcd2c8603ec6b86c5ec8c40845e4594bc181adf5272bd48a3de7c88f0f; literal:all_required_late_bound_closed iff every required field satisfies:",
  "source_owner_signature_required": true,
  "status": "HOLD_OWNER_SCHEMA_ABI",
  "writer_artifact_locator": "N02/NODE-B1-N02-03-writer.json"
}
```

### B1-N02-04｜N02 / HOLD_SOURCE_CLAUSE

```json
{
  "expected_raw_oracle_locator": "N02/NODE-B1-N02-04-checker-raw.json",
  "first_fail": "CLAUSE_LOCATOR_UNRESOLVED",
  "native_operation": "SKILL_CONTRACT_NOT_GENERIC_VALIDATE_AND_COMPILE",
  "native_skill_candidates": [
    "pipd-pd-bind"
  ],
  "node_id": "B1-N02-04",
  "oracle_negative": "remove required source/ABI/permission -> deterministic first fail, no output",
  "oracle_positive": "typed native input/output roundtrip with nonempty subject & hash",
  "original_pseudofunction": "validate_and_compile_write_scope",
  "owner_writer": "PD",
  "precondition": "real source+owner+schema/ABI resolution before native build",
  "required_schema_id": "RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN",
  "source_clause_candidate": "PIPD_LS_DOC-03_2026-10-07_r2_AUDIT_REPAIR_FULL_SUBSTANTIVE_BODY.md:UNRESOLVED; sha256:d89d82dcd2c8603ec6b86c5ec8c40845e4594bc181adf5272bd48a3de7c88f0f; literal:",
  "source_owner_signature_required": true,
  "status": "HOLD_SOURCE_CLAUSE",
  "writer_artifact_locator": "N02/NODE-B1-N02-04-writer.json"
}
```

### B1-N02-05｜N02 / HOLD_SOURCE_CLAUSE

```json
{
  "expected_raw_oracle_locator": "N02/NODE-B1-N02-05-checker-raw.json",
  "first_fail": "CLAUSE_LOCATOR_UNRESOLVED",
  "native_operation": "SKILL_CONTRACT_NOT_GENERIC_VALIDATE_AND_COMPILE",
  "native_skill_candidates": [
    "pipd-pd-bind"
  ],
  "node_id": "B1-N02-05",
  "oracle_negative": "remove required source/ABI/permission -> deterministic first fail, no output",
  "oracle_positive": "typed native input/output roundtrip with nonempty subject & hash",
  "original_pseudofunction": "validate_and_compile_prepost_image",
  "owner_writer": "PD",
  "precondition": "real source+owner+schema/ABI resolution before native build",
  "required_schema_id": "RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN",
  "source_clause_candidate": "PIPD_LS_DOC-03_2026-10-07_r2_AUDIT_REPAIR_FULL_SUBSTANTIVE_BODY.md:UNRESOLVED; sha256:d89d82dcd2c8603ec6b86c5ec8c40845e4594bc181adf5272bd48a3de7c88f0f; literal:",
  "source_owner_signature_required": true,
  "status": "HOLD_SOURCE_CLAUSE",
  "writer_artifact_locator": "N02/NODE-B1-N02-05-writer.json"
}
```

### B1-N02-06｜N02 / HOLD_OWNER_SCHEMA_ABI

```json
{
  "expected_raw_oracle_locator": "N02/NODE-B1-N02-06-checker-raw.json",
  "first_fail": "SCHEMA_OR_OWNER_UNBOUND",
  "native_operation": "SKILL_CONTRACT_NOT_GENERIC_VALIDATE_AND_COMPILE",
  "native_skill_candidates": [
    "pipd-pd-bind"
  ],
  "node_id": "B1-N02-06",
  "oracle_negative": "remove required source/ABI/permission -> deterministic first fail, no output",
  "oracle_positive": "typed native input/output roundtrip with nonempty subject & hash",
  "original_pseudofunction": "validate_and_compile_stale_rollback",
  "owner_writer": "PD",
  "precondition": "real source+owner+schema/ABI resolution before native build",
  "required_schema_id": "RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN",
  "source_clause_candidate": "PIPD_LS_DOC-03_2026-10-07_r2_AUDIT_REPAIR_FULL_SUBSTANTIVE_BODY.md@L234; sha256:d89d82dcd2c8603ec6b86c5ec8c40845e4594bc181adf5272bd48a3de7c88f0f; literal:Wrong-subject, superseded, hash-mismatched or stale required PI is rejected. A semantic delta does not get pat",
  "source_owner_signature_required": true,
  "status": "HOLD_OWNER_SCHEMA_ABI",
  "writer_artifact_locator": "N02/NODE-B1-N02-06-writer.json"
}
```

### B1-N02-07｜N02 / HOLD_OWNER_SCHEMA_ABI

```json
{
  "expected_raw_oracle_locator": "N02/NODE-B1-N02-07-checker-raw.json",
  "first_fail": "SCHEMA_OR_OWNER_UNBOUND",
  "native_operation": "SKILL_CONTRACT_NOT_GENERIC_VALIDATE_AND_COMPILE",
  "native_skill_candidates": [
    "pipd-pd-bind"
  ],
  "node_id": "B1-N02-07",
  "oracle_negative": "remove required source/ABI/permission -> deterministic first fail, no output",
  "oracle_positive": "typed native input/output roundtrip with nonempty subject & hash",
  "original_pseudofunction": "validate_and_compile_handoff",
  "owner_writer": "PD",
  "precondition": "real source+owner+schema/ABI resolution before native build",
  "required_schema_id": "RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN",
  "source_clause_candidate": "PIPD_LS_DOC-03_2026-10-07_r2_AUDIT_REPAIR_FULL_SUBSTANTIVE_BODY.md@L188; sha256:d89d82dcd2c8603ec6b86c5ec8c40845e4594bc181adf5272bd48a3de7c88f0f; literal:`FrozenPIReference`, canonical `RepoContext`, `CurrentnessRecord/CurrentnessDiff`, `LateBoundResolutionLedger`",
  "source_owner_signature_required": true,
  "status": "HOLD_OWNER_SCHEMA_ABI",
  "writer_artifact_locator": "N02/NODE-B1-N02-07-writer.json"
}
```

### B1-N03-01｜N03 / HOLD_OWNER_SCHEMA_ABI

```json
{
  "expected_raw_oracle_locator": "N03/NODE-B1-N03-01-checker-raw.json",
  "first_fail": "SCHEMA_OR_OWNER_UNBOUND",
  "native_operation": "SKILL_CONTRACT_NOT_GENERIC_VALIDATE_AND_COMPILE",
  "native_skill_candidates": [
    "pipd-execution-contract"
  ],
  "node_id": "B1-N03-01",
  "oracle_negative": "remove required source/ABI/permission -> deterministic first fail, no output",
  "oracle_positive": "typed native input/output roundtrip with nonempty subject & hash",
  "original_pseudofunction": "validate_and_compile_identity",
  "owner_writer": "OPS-ECP",
  "precondition": "real source+owner+schema/ABI resolution before native build",
  "required_schema_id": "RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN",
  "source_clause_candidate": "PIPD_LS_DOC-05_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md@L2; sha256:7b40584540c162cda6debfd09a4c04321416706acdb03a7a3c2b41383dc585f4; literal:artifact_id: \"PIPD_LS_DOC-05\"",
  "source_owner_signature_required": true,
  "status": "HOLD_OWNER_SCHEMA_ABI",
  "writer_artifact_locator": "N03/NODE-B1-N03-01-writer.json"
}
```

### B1-N03-02｜N03 / HOLD_OWNER_SCHEMA_ABI

```json
{
  "expected_raw_oracle_locator": "N03/NODE-B1-N03-02-checker-raw.json",
  "first_fail": "SCHEMA_OR_OWNER_UNBOUND",
  "native_operation": "SKILL_CONTRACT_NOT_GENERIC_VALIDATE_AND_COMPILE",
  "native_skill_candidates": [
    "pipd-execution-contract"
  ],
  "node_id": "B1-N03-02",
  "oracle_negative": "remove required source/ABI/permission -> deterministic first fail, no output",
  "oracle_positive": "typed native input/output roundtrip with nonempty subject & hash",
  "original_pseudofunction": "validate_and_compile_effect_intent",
  "owner_writer": "OPS-ECP",
  "precondition": "real source+owner+schema/ABI resolution before native build",
  "required_schema_id": "RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN",
  "source_clause_candidate": "PIPD_LS_DOC-05_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md@L1028; sha256:7b40584540c162cda6debfd09a4c04321416706acdb03a7a3c2b41383dc585f4; literal:effect_intent_id: \"<stable id>\"",
  "source_owner_signature_required": true,
  "status": "HOLD_OWNER_SCHEMA_ABI",
  "writer_artifact_locator": "N03/NODE-B1-N03-02-writer.json"
}
```

### B1-N03-03｜N03 / HOLD_OWNER_SCHEMA_ABI

```json
{
  "expected_raw_oracle_locator": "N03/NODE-B1-N03-03-checker-raw.json",
  "first_fail": "SCHEMA_OR_OWNER_UNBOUND",
  "native_operation": "SKILL_CONTRACT_NOT_GENERIC_VALIDATE_AND_COMPILE",
  "native_skill_candidates": [
    "pipd-execution-contract"
  ],
  "node_id": "B1-N03-03",
  "oracle_negative": "remove required source/ABI/permission -> deterministic first fail, no output",
  "oracle_positive": "typed native input/output roundtrip with nonempty subject & hash",
  "original_pseudofunction": "validate_and_compile_issuer_policy",
  "owner_writer": "OPS-ECP",
  "precondition": "real source+owner+schema/ABI resolution before native build",
  "required_schema_id": "RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN",
  "source_clause_candidate": "PIPD_LS_DOC-05_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md@L3; sha256:7b40584540c162cda6debfd09a4c04321416706acdb03a7a3c2b41383dc585f4; literal:external_formal_name: \"Pre-Implementation & Pre-Dev Lifecycle Specification — DOC-05 Receiver / Permission / A",
  "source_owner_signature_required": true,
  "status": "HOLD_OWNER_SCHEMA_ABI",
  "writer_artifact_locator": "N03/NODE-B1-N03-03-writer.json"
}
```

### B1-N03-04｜N03 / HOLD_OWNER_SCHEMA_ABI

```json
{
  "expected_raw_oracle_locator": "N03/NODE-B1-N03-04-checker-raw.json",
  "first_fail": "SCHEMA_OR_OWNER_UNBOUND",
  "native_operation": "SKILL_CONTRACT_NOT_GENERIC_VALIDATE_AND_COMPILE",
  "native_skill_candidates": [
    "pipd-execution-contract"
  ],
  "node_id": "B1-N03-04",
  "oracle_negative": "remove required source/ABI/permission -> deterministic first fail, no output",
  "oracle_positive": "typed native input/output roundtrip with nonempty subject & hash",
  "original_pseudofunction": "validate_and_compile_token_ttl_nonce",
  "owner_writer": "OPS-ECP",
  "precondition": "real source+owner+schema/ABI resolution before native build",
  "required_schema_id": "RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN",
  "source_clause_candidate": "PIPD_LS_DOC-05_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md@L717; sha256:7b40584540c162cda6debfd09a4c04321416706acdb03a7a3c2b41383dc585f4; literal:nonce exists and is ISSUED, not CONSUMED/REVOKED/EXPIRED",
  "source_owner_signature_required": true,
  "status": "HOLD_OWNER_SCHEMA_ABI",
  "writer_artifact_locator": "N03/NODE-B1-N03-04-writer.json"
}
```

### B1-N03-05｜N03 / HOLD_SOURCE_CLAUSE

```json
{
  "expected_raw_oracle_locator": "N03/NODE-B1-N03-05-checker-raw.json",
  "first_fail": "CLAUSE_LOCATOR_UNRESOLVED",
  "native_operation": "SKILL_CONTRACT_NOT_GENERIC_VALIDATE_AND_COMPILE",
  "native_skill_candidates": [
    "pipd-execution-contract"
  ],
  "node_id": "B1-N03-05",
  "oracle_negative": "remove required source/ABI/permission -> deterministic first fail, no output",
  "oracle_positive": "typed native input/output roundtrip with nonempty subject & hash",
  "original_pseudofunction": "validate_and_compile_one_effect",
  "owner_writer": "OPS-ECP",
  "precondition": "real source+owner+schema/ABI resolution before native build",
  "required_schema_id": "RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN",
  "source_clause_candidate": "PIPD_LS_DOC-05_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md:UNRESOLVED; sha256:7b40584540c162cda6debfd09a4c04321416706acdb03a7a3c2b41383dc585f4; literal:",
  "source_owner_signature_required": true,
  "status": "HOLD_SOURCE_CLAUSE",
  "writer_artifact_locator": "N03/NODE-B1-N03-05-writer.json"
}
```

### B1-N03-06｜N03 / HOLD_OWNER_SCHEMA_ABI

```json
{
  "expected_raw_oracle_locator": "N03/NODE-B1-N03-06-checker-raw.json",
  "first_fail": "SCHEMA_OR_OWNER_UNBOUND",
  "native_operation": "SKILL_CONTRACT_NOT_GENERIC_VALIDATE_AND_COMPILE",
  "native_skill_candidates": [
    "pipd-execution-contract"
  ],
  "node_id": "B1-N03-06",
  "oracle_negative": "remove required source/ABI/permission -> deterministic first fail, no output",
  "oracle_positive": "typed native input/output roundtrip with nonempty subject & hash",
  "original_pseudofunction": "validate_and_compile_unknown_reconcile",
  "owner_writer": "OPS-ECP",
  "precondition": "real source+owner+schema/ABI resolution before native build",
  "required_schema_id": "RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN",
  "source_clause_candidate": "PIPD_LS_DOC-05_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md@L1096; sha256:7b40584540c162cda6debfd09a4c04321416706acdb03a7a3c2b41383dc585f4; literal:state: \"UNKNOWN_EFFECT / PARTIAL_EFFECT / CONFLICTING_EFFECT / CONFIRMED_EFFECT / FAILED_EFFECT / COMPENSATED_",
  "source_owner_signature_required": true,
  "status": "HOLD_OWNER_SCHEMA_ABI",
  "writer_artifact_locator": "N03/NODE-B1-N03-06-writer.json"
}
```

### B1-N03-07｜N03 / HOLD_OWNER_SCHEMA_ABI

```json
{
  "expected_raw_oracle_locator": "N03/NODE-B1-N03-07-checker-raw.json",
  "first_fail": "SCHEMA_OR_OWNER_UNBOUND",
  "native_operation": "SKILL_CONTRACT_NOT_GENERIC_VALIDATE_AND_COMPILE",
  "native_skill_candidates": [
    "pipd-execution-contract"
  ],
  "node_id": "B1-N03-07",
  "oracle_negative": "remove required source/ABI/permission -> deterministic first fail, no output",
  "oracle_positive": "typed native input/output roundtrip with nonempty subject & hash",
  "original_pseudofunction": "validate_and_compile_residue",
  "owner_writer": "OPS-ECP",
  "precondition": "real source+owner+schema/ABI resolution before native build",
  "required_schema_id": "RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN",
  "source_clause_candidate": "PIPD_LS_DOC-05_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md@L121; sha256:7b40584540c162cda6debfd09a4c04321416706acdb03a7a3c2b41383dc585f4; literal:7. rollback being declared without checkpoint/procedure/residue closure;",
  "source_owner_signature_required": true,
  "status": "HOLD_OWNER_SCHEMA_ABI",
  "writer_artifact_locator": "N03/NODE-B1-N03-07-writer.json"
}
```

### B1-N03-08｜N03 / HOLD_OWNER_SCHEMA_ABI

```json
{
  "expected_raw_oracle_locator": "N03/NODE-B1-N03-08-checker-raw.json",
  "first_fail": "SCHEMA_OR_OWNER_UNBOUND",
  "native_operation": "SKILL_CONTRACT_NOT_GENERIC_VALIDATE_AND_COMPILE",
  "native_skill_candidates": [
    "pipd-execution-contract"
  ],
  "node_id": "B1-N03-08",
  "oracle_negative": "remove required source/ABI/permission -> deterministic first fail, no output",
  "oracle_positive": "typed native input/output roundtrip with nonempty subject & hash",
  "original_pseudofunction": "validate_and_compile_rollback",
  "owner_writer": "OPS-ECP",
  "precondition": "real source+owner+schema/ABI resolution before native build",
  "required_schema_id": "RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN",
  "source_clause_candidate": "PIPD_LS_DOC-05_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md@L39; sha256:7b40584540c162cda6debfd09a4c04321416706acdb03a7a3c2b41383dc585f4; literal:> **Legal role.** This document is the r2 high-retention repaired DOC-05 substantive body for the receiver, pe",
  "source_owner_signature_required": true,
  "status": "HOLD_OWNER_SCHEMA_ABI",
  "writer_artifact_locator": "N03/NODE-B1-N03-08-writer.json"
}
```

### B1-N04-01｜N04 / HOLD_OWNER_SCHEMA_ABI

```json
{
  "expected_raw_oracle_locator": "N04/NODE-B1-N04-01-checker-raw.json",
  "first_fail": "SCHEMA_OR_OWNER_UNBOUND",
  "native_operation": "SKILL_CONTRACT_NOT_GENERIC_VALIDATE_AND_COMPILE",
  "native_skill_candidates": [
    "pipd-pd-bind",
    "pipd-execution-contract"
  ],
  "node_id": "B1-N04-01",
  "oracle_negative": "remove required source/ABI/permission -> deterministic first fail, no output",
  "oracle_positive": "typed native input/output roundtrip with nonempty subject & hash",
  "original_pseudofunction": "validate_and_compile_identity",
  "owner_writer": "DEV-ECP",
  "precondition": "real source+owner+schema/ABI resolution before native build",
  "required_schema_id": "RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN",
  "source_clause_candidate": "PIPD_LS_DOC-05_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md@L2; sha256:7b40584540c162cda6debfd09a4c04321416706acdb03a7a3c2b41383dc585f4; literal:artifact_id: \"PIPD_LS_DOC-05\"",
  "source_owner_signature_required": true,
  "status": "HOLD_OWNER_SCHEMA_ABI",
  "writer_artifact_locator": "N04/NODE-B1-N04-01-writer.json"
}
```

### B1-N04-02｜N04 / HOLD_SOURCE_CLAUSE

```json
{
  "expected_raw_oracle_locator": "N04/NODE-B1-N04-02-checker-raw.json",
  "first_fail": "CLAUSE_LOCATOR_UNRESOLVED",
  "native_operation": "SKILL_CONTRACT_NOT_GENERIC_VALIDATE_AND_COMPILE",
  "native_skill_candidates": [
    "pipd-pd-bind",
    "pipd-execution-contract"
  ],
  "node_id": "B1-N04-02",
  "oracle_negative": "remove required source/ABI/permission -> deterministic first fail, no output",
  "oracle_positive": "typed native input/output roundtrip with nonempty subject & hash",
  "original_pseudofunction": "validate_and_compile_worktree_scope",
  "owner_writer": "DEV-ECP",
  "precondition": "real source+owner+schema/ABI resolution before native build",
  "required_schema_id": "RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN",
  "source_clause_candidate": "PIPD_LS_DOC-05_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md:UNRESOLVED; sha256:7b40584540c162cda6debfd09a4c04321416706acdb03a7a3c2b41383dc585f4; literal:",
  "source_owner_signature_required": true,
  "status": "HOLD_SOURCE_CLAUSE",
  "writer_artifact_locator": "N04/NODE-B1-N04-02-writer.json"
}
```

### B1-N04-03｜N04 / HOLD_OWNER_SCHEMA_ABI

```json
{
  "expected_raw_oracle_locator": "N04/NODE-B1-N04-03-checker-raw.json",
  "first_fail": "SCHEMA_OR_OWNER_UNBOUND",
  "native_operation": "SKILL_CONTRACT_NOT_GENERIC_VALIDATE_AND_COMPILE",
  "native_skill_candidates": [
    "pipd-pd-bind",
    "pipd-execution-contract"
  ],
  "node_id": "B1-N04-03",
  "oracle_negative": "remove required source/ABI/permission -> deterministic first fail, no output",
  "oracle_positive": "typed native input/output roundtrip with nonempty subject & hash",
  "original_pseudofunction": "validate_and_compile_diff_preimage",
  "owner_writer": "DEV-ECP",
  "precondition": "real source+owner+schema/ABI resolution before native build",
  "required_schema_id": "RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN",
  "source_clause_candidate": "PIPD_LS_DOC-05_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md@L310; sha256:7b40584540c162cda6debfd09a4c04321416706acdb03a7a3c2b41383dc585f4; literal:A receiver record is valid only when it resolves to a named role/principal/agent surface and a target scope. A",
  "source_owner_signature_required": true,
  "status": "HOLD_OWNER_SCHEMA_ABI",
  "writer_artifact_locator": "N04/NODE-B1-N04-03-writer.json"
}
```

### B1-N04-04｜N04 / HOLD_OWNER_SCHEMA_ABI

```json
{
  "expected_raw_oracle_locator": "N04/NODE-B1-N04-04-checker-raw.json",
  "first_fail": "SCHEMA_OR_OWNER_UNBOUND",
  "native_operation": "SKILL_CONTRACT_NOT_GENERIC_VALIDATE_AND_COMPILE",
  "native_skill_candidates": [
    "pipd-pd-bind",
    "pipd-execution-contract"
  ],
  "node_id": "B1-N04-04",
  "oracle_negative": "remove required source/ABI/permission -> deterministic first fail, no output",
  "oracle_positive": "typed native input/output roundtrip with nonempty subject & hash",
  "original_pseudofunction": "validate_and_compile_tests",
  "owner_writer": "DEV-ECP",
  "precondition": "real source+owner+schema/ABI resolution before native build",
  "required_schema_id": "RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN",
  "source_clause_candidate": "PIPD_LS_DOC-05_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md@L3355; sha256:7b40584540c162cda6debfd09a4c04321416706acdb03a7a3c2b41383dc585f4; literal:/ TEST-DOC05-POS-001 / OR-DOC05-POS-001 / Positive / valid PREDEV_READY + canonical handoff + bundle + policy",
  "source_owner_signature_required": true,
  "status": "HOLD_OWNER_SCHEMA_ABI",
  "writer_artifact_locator": "N04/NODE-B1-N04-04-writer.json"
}
```

### B1-N04-05｜N04 / HOLD_OWNER_SCHEMA_ABI

```json
{
  "expected_raw_oracle_locator": "N04/NODE-B1-N04-05-checker-raw.json",
  "first_fail": "SCHEMA_OR_OWNER_UNBOUND",
  "native_operation": "SKILL_CONTRACT_NOT_GENERIC_VALIDATE_AND_COMPILE",
  "native_skill_candidates": [
    "pipd-pd-bind",
    "pipd-execution-contract"
  ],
  "node_id": "B1-N04-05",
  "oracle_negative": "remove required source/ABI/permission -> deterministic first fail, no output",
  "oracle_positive": "typed native input/output roundtrip with nonempty subject & hash",
  "original_pseudofunction": "validate_and_compile_permission",
  "owner_writer": "DEV-ECP",
  "precondition": "real source+owner+schema/ABI resolution before native build",
  "required_schema_id": "RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN",
  "source_clause_candidate": "PIPD_LS_DOC-05_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md@L3; sha256:7b40584540c162cda6debfd09a4c04321416706acdb03a7a3c2b41383dc585f4; literal:external_formal_name: \"Pre-Implementation & Pre-Dev Lifecycle Specification — DOC-05 Receiver / Permission / A",
  "source_owner_signature_required": true,
  "status": "HOLD_OWNER_SCHEMA_ABI",
  "writer_artifact_locator": "N04/NODE-B1-N04-05-writer.json"
}
```

### B1-N04-06｜N04 / HOLD_OWNER_SCHEMA_ABI

```json
{
  "expected_raw_oracle_locator": "N04/NODE-B1-N04-06-checker-raw.json",
  "first_fail": "SCHEMA_OR_OWNER_UNBOUND",
  "native_operation": "SKILL_CONTRACT_NOT_GENERIC_VALIDATE_AND_COMPILE",
  "native_skill_candidates": [
    "pipd-pd-bind",
    "pipd-execution-contract"
  ],
  "node_id": "B1-N04-06",
  "oracle_negative": "remove required source/ABI/permission -> deterministic first fail, no output",
  "oracle_positive": "typed native input/output roundtrip with nonempty subject & hash",
  "original_pseudofunction": "validate_and_compile_same_sha_checker",
  "owner_writer": "DEV-ECP",
  "precondition": "real source+owner+schema/ABI resolution before native build",
  "required_schema_id": "RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN",
  "source_clause_candidate": "PIPD_LS_DOC-05_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md@L143; sha256:7b40584540c162cda6debfd09a4c04321416706acdb03a7a3c2b41383dc585f4; literal:Primary consumers are execution receiver, implementation agent, operation receiver, human approver, checker/ac",
  "source_owner_signature_required": true,
  "status": "HOLD_OWNER_SCHEMA_ABI",
  "writer_artifact_locator": "N04/NODE-B1-N04-06-writer.json"
}
```

### B1-N04-07｜N04 / HOLD_OWNER_SCHEMA_ABI

```json
{
  "expected_raw_oracle_locator": "N04/NODE-B1-N04-07-checker-raw.json",
  "first_fail": "SCHEMA_OR_OWNER_UNBOUND",
  "native_operation": "SKILL_CONTRACT_NOT_GENERIC_VALIDATE_AND_COMPILE",
  "native_skill_candidates": [
    "pipd-pd-bind",
    "pipd-execution-contract"
  ],
  "node_id": "B1-N04-07",
  "oracle_negative": "remove required source/ABI/permission -> deterministic first fail, no output",
  "oracle_positive": "typed native input/output roundtrip with nonempty subject & hash",
  "original_pseudofunction": "validate_and_compile_rollback",
  "owner_writer": "DEV-ECP",
  "precondition": "real source+owner+schema/ABI resolution before native build",
  "required_schema_id": "RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN",
  "source_clause_candidate": "PIPD_LS_DOC-05_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md@L39; sha256:7b40584540c162cda6debfd09a4c04321416706acdb03a7a3c2b41383dc585f4; literal:> **Legal role.** This document is the r2 high-retention repaired DOC-05 substantive body for the receiver, pe",
  "source_owner_signature_required": true,
  "status": "HOLD_OWNER_SCHEMA_ABI",
  "writer_artifact_locator": "N04/NODE-B1-N04-07-writer.json"
}
```

### B1-N05-01｜N05 / HOLD_OWNER_SCHEMA_ABI

```json
{
  "expected_raw_oracle_locator": "N05/NODE-B1-N05-01-checker-raw.json",
  "first_fail": "SCHEMA_OR_OWNER_UNBOUND",
  "native_operation": "SKILL_CONTRACT_NOT_GENERIC_VALIDATE_AND_COMPILE",
  "native_skill_candidates": [
    "pipd-assurance-tqaep",
    "pipd-package-project"
  ],
  "node_id": "B1-N05-01",
  "oracle_negative": "remove required source/ABI/permission -> deterministic first fail, no output",
  "oracle_positive": "typed native input/output roundtrip with nonempty subject & hash",
  "original_pseudofunction": "validate_and_compile_identity",
  "owner_writer": "TQAEP",
  "precondition": "real source+owner+schema/ABI resolution before native build",
  "required_schema_id": "RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN",
  "source_clause_candidate": "PIPD_LS_DOC-07_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md@L2; sha256:a68dae1c3670d07bcfa3476a1e37463c534594df5cd65d8dab0dca064b5a9fc1; literal:artifact_id: \"PIPD_LS_DOC-07\"",
  "source_owner_signature_required": true,
  "status": "HOLD_OWNER_SCHEMA_ABI",
  "writer_artifact_locator": "N05/NODE-B1-N05-01-writer.json"
}
```

### B1-N05-02｜N05 / HOLD_OWNER_SCHEMA_ABI

```json
{
  "expected_raw_oracle_locator": "N05/NODE-B1-N05-02-checker-raw.json",
  "first_fail": "SCHEMA_OR_OWNER_UNBOUND",
  "native_operation": "SKILL_CONTRACT_NOT_GENERIC_VALIDATE_AND_COMPILE",
  "native_skill_candidates": [
    "pipd-assurance-tqaep",
    "pipd-package-project"
  ],
  "node_id": "B1-N05-02",
  "oracle_negative": "remove required source/ABI/permission -> deterministic first fail, no output",
  "oracle_positive": "typed native input/output roundtrip with nonempty subject & hash",
  "original_pseudofunction": "validate_and_compile_maker_checker",
  "owner_writer": "TQAEP",
  "precondition": "real source+owner+schema/ABI resolution before native build",
  "required_schema_id": "RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN",
  "source_clause_candidate": "PIPD_LS_DOC-07_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md@L58; sha256:a68dae1c3670d07bcfa3476a1e37463c534594df5cd65d8dab0dca064b5a9fc1; literal:> **Canonical role:** DOC-07 writes verification / oracle / fixture reference semantics. It supports `VERIFYIN",
  "source_owner_signature_required": true,
  "status": "HOLD_OWNER_SCHEMA_ABI",
  "writer_artifact_locator": "N05/NODE-B1-N05-02-writer.json"
}
```

### B1-N05-03｜N05 / HOLD_OWNER_SCHEMA_ABI

```json
{
  "expected_raw_oracle_locator": "N05/NODE-B1-N05-03-checker-raw.json",
  "first_fail": "SCHEMA_OR_OWNER_UNBOUND",
  "native_operation": "SKILL_CONTRACT_NOT_GENERIC_VALIDATE_AND_COMPILE",
  "native_skill_candidates": [
    "pipd-assurance-tqaep",
    "pipd-package-project"
  ],
  "node_id": "B1-N05-03",
  "oracle_negative": "remove required source/ABI/permission -> deterministic first fail, no output",
  "oracle_positive": "typed native input/output roundtrip with nonempty subject & hash",
  "original_pseudofunction": "validate_and_compile_oracle_ownership",
  "owner_writer": "TQAEP",
  "precondition": "real source+owner+schema/ABI resolution before native build",
  "required_schema_id": "RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN",
  "source_clause_candidate": "PIPD_LS_DOC-07_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md@L3; sha256:a68dae1c3670d07bcfa3476a1e37463c534594df5cd65d8dab0dca064b5a9fc1; literal:external_formal_name: \"Pre-Implementation & Pre-Dev Lifecycle Specification — DOC-07 Verification / Oracle / F",
  "source_owner_signature_required": true,
  "status": "HOLD_OWNER_SCHEMA_ABI",
  "writer_artifact_locator": "N05/NODE-B1-N05-03-writer.json"
}
```

### B1-N05-04｜N05 / HOLD_OWNER_SCHEMA_ABI

```json
{
  "expected_raw_oracle_locator": "N05/NODE-B1-N05-04-checker-raw.json",
  "first_fail": "SCHEMA_OR_OWNER_UNBOUND",
  "native_operation": "SKILL_CONTRACT_NOT_GENERIC_VALIDATE_AND_COMPILE",
  "native_skill_candidates": [
    "pipd-assurance-tqaep",
    "pipd-package-project"
  ],
  "node_id": "B1-N05-04",
  "oracle_negative": "remove required source/ABI/permission -> deterministic first fail, no output",
  "oracle_positive": "typed native input/output roundtrip with nonempty subject & hash",
  "original_pseudofunction": "validate_and_compile_pos_neg_edge_sec",
  "owner_writer": "TQAEP",
  "precondition": "real source+owner+schema/ABI resolution before native build",
  "required_schema_id": "RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN",
  "source_clause_candidate": "PIPD_LS_DOC-07_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md@L103; sha256:a68dae1c3670d07bcfa3476a1e37463c534594df5cd65d8dab0dca064b5a9fc1; literal:R2 is a design/specification artifact and local author-side materialization. It does not prove that any projec",
  "source_owner_signature_required": true,
  "status": "HOLD_OWNER_SCHEMA_ABI",
  "writer_artifact_locator": "N05/NODE-B1-N05-04-writer.json"
}
```

### B1-N05-05｜N05 / HOLD_OWNER_SCHEMA_ABI

```json
{
  "expected_raw_oracle_locator": "N05/NODE-B1-N05-05-checker-raw.json",
  "first_fail": "SCHEMA_OR_OWNER_UNBOUND",
  "native_operation": "SKILL_CONTRACT_NOT_GENERIC_VALIDATE_AND_COMPILE",
  "native_skill_candidates": [
    "pipd-assurance-tqaep",
    "pipd-package-project"
  ],
  "node_id": "B1-N05-05",
  "oracle_negative": "remove required source/ABI/permission -> deterministic first fail, no output",
  "oracle_positive": "typed native input/output roundtrip with nonempty subject & hash",
  "original_pseudofunction": "validate_and_compile_gwo_fixtures",
  "owner_writer": "TQAEP",
  "precondition": "real source+owner+schema/ABI resolution before native build",
  "required_schema_id": "RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN",
  "source_clause_candidate": "PIPD_LS_DOC-07_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md@L3; sha256:a68dae1c3670d07bcfa3476a1e37463c534594df5cd65d8dab0dca064b5a9fc1; literal:external_formal_name: \"Pre-Implementation & Pre-Dev Lifecycle Specification — DOC-07 Verification / Oracle / F",
  "source_owner_signature_required": true,
  "status": "HOLD_OWNER_SCHEMA_ABI",
  "writer_artifact_locator": "N05/NODE-B1-N05-05-writer.json"
}
```

### B1-N05-06｜N05 / HOLD_SOURCE_CLAUSE

```json
{
  "expected_raw_oracle_locator": "N05/NODE-B1-N05-06-checker-raw.json",
  "first_fail": "CLAUSE_LOCATOR_UNRESOLVED",
  "native_operation": "SKILL_CONTRACT_NOT_GENERIC_VALIDATE_AND_COMPILE",
  "native_skill_candidates": [
    "pipd-assurance-tqaep",
    "pipd-package-project"
  ],
  "node_id": "B1-N05-06",
  "oracle_negative": "remove required source/ABI/permission -> deterministic first fail, no output",
  "oracle_positive": "typed native input/output roundtrip with nonempty subject & hash",
  "original_pseudofunction": "validate_and_compile_evidence_expectation",
  "owner_writer": "TQAEP",
  "precondition": "real source+owner+schema/ABI resolution before native build",
  "required_schema_id": "RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN",
  "source_clause_candidate": "PIPD_LS_DOC-07_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md:UNRESOLVED; sha256:a68dae1c3670d07bcfa3476a1e37463c534594df5cd65d8dab0dca064b5a9fc1; literal:",
  "source_owner_signature_required": true,
  "status": "HOLD_SOURCE_CLAUSE",
  "writer_artifact_locator": "N05/NODE-B1-N05-06-writer.json"
}
```

### B1-N05-07｜N05 / HOLD_OWNER_SCHEMA_ABI

```json
{
  "expected_raw_oracle_locator": "N05/NODE-B1-N05-07-checker-raw.json",
  "first_fail": "SCHEMA_OR_OWNER_UNBOUND",
  "native_operation": "SKILL_CONTRACT_NOT_GENERIC_VALIDATE_AND_COMPILE",
  "native_skill_candidates": [
    "pipd-assurance-tqaep",
    "pipd-package-project"
  ],
  "node_id": "B1-N05-07",
  "oracle_negative": "remove required source/ABI/permission -> deterministic first fail, no output",
  "oracle_positive": "typed native input/output roundtrip with nonempty subject & hash",
  "original_pseudofunction": "validate_and_compile_requalification",
  "owner_writer": "TQAEP",
  "precondition": "real source+owner+schema/ABI resolution before native build",
  "required_schema_id": "RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN",
  "source_clause_candidate": "PIPD_LS_DOC-07_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md@L535; sha256:a68dae1c3670d07bcfa3476a1e37463c534594df5cd65d8dab0dca064b5a9fc1; literal:A fixture is executable evidence preparation. Every executable fixture binds exact subject/version/hash, basel",
  "source_owner_signature_required": true,
  "status": "HOLD_OWNER_SCHEMA_ABI",
  "writer_artifact_locator": "N05/NODE-B1-N05-07-writer.json"
}
```

### B1-N05-08｜N05 / HOLD_OWNER_SCHEMA_ABI

```json
{
  "expected_raw_oracle_locator": "N05/NODE-B1-N05-08-checker-raw.json",
  "first_fail": "SCHEMA_OR_OWNER_UNBOUND",
  "native_operation": "SKILL_CONTRACT_NOT_GENERIC_VALIDATE_AND_COMPILE",
  "native_skill_candidates": [
    "pipd-assurance-tqaep",
    "pipd-package-project"
  ],
  "node_id": "B1-N05-08",
  "oracle_negative": "remove required source/ABI/permission -> deterministic first fail, no output",
  "oracle_positive": "typed native input/output roundtrip with nonempty subject & hash",
  "original_pseudofunction": "validate_and_compile_acceptance",
  "owner_writer": "TQAEP",
  "precondition": "real source+owner+schema/ABI resolution before native build",
  "required_schema_id": "RETRIEVE_FROM_INSTALLED_SKILL_OR_CANONICAL_REGISTRY_AND_PIN",
  "source_clause_candidate": "PIPD_LS_DOC-07_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md@L109; sha256:a68dae1c3670d07bcfa3476a1e37463c534594df5cd65d8dab0dca064b5a9fc1; literal:The core rule is: **a claim is not accepted because the producer says it is true; it is accepted only when the",
  "source_owner_signature_required": true,
  "status": "HOLD_OWNER_SCHEMA_ABI",
  "writer_artifact_locator": "N05/NODE-B1-N05-08-writer.json"
}
```

## 5. Claim Ceiling and independent evidence

若真 PI/ECP、不同 Maker/Checker principal、CheckerExecutionReceipt、相同 subject raw 各項不存在，P4 `pipd-assurance-tqaep` 必 fail closed（`TQ_SOD / TQ_TRACE / TQ_ORACLE`）。`pipd-package-project` 的 LOCAL_QUALIFIED 起必有 approval receipt；本 B1 Design 不申請該 rung。
所有候選 `expected_raw_oracle_locator` 為未執行的名字，不是 `RawReceipt`。正式驗收只接受 Candidate SHA 已釘，first-fail Oracle 在 run 前凍結，獨立 checker 在其他 write surface 以唯讀運作的完整證據。
