## 高保留原 BODY Revision2 實質正文（沿用未受影區；遇 r2 修補採本冊前段）

---
artifact_id: FHS-MSC-R2-BODY-00
formal_name: 修補候選入口與當期判定
short_name: BODY-00
version: 2026-10-29-r2-revision2
source_set_hash_or_pending: f86b217ae3c3ee28183570f4bf3d4f08d4d00e9b86d1de1a641a630f8682d1a1
intended_consumer: 原領域 Owner 與下游 Reader
owner_role: 作者端規格修補者；原 Domain Writer 不移轉
design_status: SOURCE_BOUND_REPAIR_CANDIDATE
claim_ceiling: AUTHOR_STATIC_ONLY; NATIVE_NOT_RUN; CHECKER_NOT_RUN; RELEASE_NOT_RUN
supersession_scope: 本輪作者候選revision2；保留前版封存；不取代任何原Canonical Writer版本
AUDIT_F_IDs:
- F-01
- F-18
- F-24
---

# 修補候選入口與當期判定

本候選以 Master、五域 v2 及原 SBL/PIPD/B1 為設計來源。來源字節掃描與作者端拒收測試各自記錄；實機權限、獨立驗收與正式發行由原 Owner 提供。缺 v1 產出指令為 `SRC-L-009 SOURCE_HOLD`，不把舊清冊當當期來源讀取證據。

普通 Goal 的第一有用成果是：一份能交原 PIPD Writer 讀取的 Product/Architecture/Program SPEC 候選，並列出每個欲 effect 子圖的綁定差額。已有 admitted WorkOrder 時，核對原 Subject/SourceSHA/Scope/PolicyEpoch/TTL；通過就從原 SharedSpine cursor 繼續。不得重新要求 Owner 貼 B1 長 Prompt，也不得重新發出已消耗 nonce。

## R2-00-ENTRY：依消費工作進入正文

先讀 [產品與權威](01_PRODUCT_AUTHORITY_SPINE.md)，再讀 [生命週期](02_PIPD_LIFECYCLE_AND_TPM.md) 與 [ABI/效果](03_ARCHITECTURE_ABI_AND_EFFECT.md)。來源／Profile 衝突只 PARK 依賴該綁定的 PI promotion；L0 設計與合法 L1 Reader 繼續。實際施工的排程只用 [22 WP](11_WORKPACKAGES_AND_DAG.md) 的 typed edges，不能把此入口頁當第二 Scheduler。

## R2-00-TIER：唯一風險層級

`L0=設計/本輪隔離文稿；L1=唯讀/靜態；L2=有界受權 Repo 寫入；L3=受准入 Native/User/Remote 效果；L4=原 Publisher 發行`。tier 是此設計投影，不替代真 Host enum。EffectClass 是正交維度；對 legacy `L1 patch` 或 `HOST_LOAD_SCOPE` 必先拒收，再由原 Owner 重新綁定，不能重新解釋成許可。

POS：L1 Source reader 讀 54 份已定位來源，沒有 Repo diff；授權 L2 只更動 exact WriteSet。NEG：L1+REPO_WRITE 或 L1+HOST_OP → `DENY_EFFECT_MISMATCH`，尚未啟動 effect worker；傳入「以前批准」仍須比對 Scope/Epoch。

## R2-00-RESUME：單人 Owner 與局部工作

`QuestionKey=(subject,source_sha,scope,policy_epoch,question_id)`；已知有效答覆只讀回，不重新提問。A 需 Issuer 缺件則 PARK(A,owner,next_action,resume_predicate)；B source read、C 已授隔離文稿保持 READY。原 Queue 負責 fairness；此文件不造第二 Queue。POS：同一 key 連續兩次輸入 owner_prompts 第二次=0，B/C 有 output；NEG：只因 A PARK 將 B/C 改 WAIT → `GLOBAL_OVERBLOCKING`。elapsed、ready_progress、retry 記實數，不虛設未經來源核准的毫秒 SLA。

詳見 [修補閉環](../REPAIR_CLOSURE_REPORT.md)、[覆蓋實數](../COVERAGE_REPORT.md) 與 [來源解析](../02_EVIDENCE_APPENDICES/E01_SOURCE_MANIFEST_AND_SEARCH.md)。
