## 高保留原 BODY Revision2 實質正文（沿用未受影區；遇 r2 修補採本冊前段）

---
artifact_id: FHS-MSC-R2-BODY-10
formal_name: B1、W18、正常模式與單人 Owner
short_name: BODY-10
version: 2026-10-29-r2-revision2
source_set_hash_or_pending: f86b217ae3c3ee28183570f4bf3d4f08d4d00e9b86d1de1a641a630f8682d1a1
intended_consumer: 原領域 Owner 與下游 Reader
owner_role: 作者端規格修補者；原 Domain Writer 不移轉
design_status: SOURCE_BOUND_REPAIR_CANDIDATE
claim_ceiling: AUTHOR_STATIC_ONLY; NATIVE_NOT_RUN; CHECKER_NOT_RUN; RELEASE_NOT_RUN
supersession_scope: 本輪作者候選revision2；保留前版封存；不取代任何原Canonical Writer版本
AUDIT_F_IDs:
- F-15
- F-17
- F-18
---

# B1、W18、正常模式與單人 Owner

## R2-10-NORMAL：新 PID、普通 Goal、零 B1 專用 Prompt

NormalModeLaunchContract 是原 Hermes startup/default-profile Reader 的設計契約，不新建 launcher。輸入 ordinary_goal、fresh_session_id、原 default_profile_sha、既有 admitted work refs（可空）；output 為 pid/start_time/process_origin/loaded_profile_sha、auto-selection trace、每 Lane required/selected/served Raw 及 WorkID/cursor。啟動前從正式 profile loader 讀 manifest 與 hash；讀不到只 NORMAL_MODE_NOT_QUALIFIED，不能用 test-only profile 補位。

NM01：新目標 → TPM/SPEC→原 PIPD→合法 plan；NM02：既有 admitted work → 原 cursor resume，Owner 重問=0；NM03：provider-off/能力不足 → 正確 NOFIT 或離線合法 read，不能私換 provider。每條都用新 PID，禁止注入 B1 長 Prompt、手選 lane 或預填成功 receipt。

E33 的正式 default profile、E37 的受治理 route、E38 的真 served、E42 的移除 test-only 後重跑，連同原 E34–36/E39–41 全部保存原 Oracle。POS：新 PID 只給 ordinary goal，自動命中正式入口且三 Lane 按 need 真 served；NEG：拔掉 B1 專用 fixture 後失效卻仍 PASS → NORMAL_MODE_NOT_QUALIFIED。此測試需原 Host Owner 綁定 launcher，不以文件例子冒執行。

## R2-10-OWNER：效率與不阻斷驗收

GOV-UX-01 同 Subject/SourceSHA/Scope/Epoch 的有效 QuestionLedger answer 連續讀兩次，第二輪 unnecessary_owner_prompts=0；變更 scope 不可重用，需明列一個 material question。GOV-UX-02 issuer 缺件的 A PARK，合法 B/C READY 有 output；記 ready_progress、elapsed、retries。GOV-UX-03 只產 L0 SPEC 的普通 Goal 不得排三十項 Host installer；Default 產品承諾保留但僅 need-qualified scope 啟動 CAP-BOOT。

退出/重入：只有原 startup profile/Host Owner 能撤回部署；未部署的作者文稿只撤候選。未知 effect 先原 world reconciliation。G-A/G-B、三 GWO、NormalMode、Release 是不同 claim，不互相借 PASS。

## 保留的 B1/W18 原場景與 Gate


# B1 27/31/120/124/38、三 GWO、W18 正常模式與防重演

> **效力**：本檔為 `BODY-10` 的來源約束施工設計候選，保留來源章節的原 ID、Decision、POS/NEG、HOLD；尚不是任何正式 PI/PD/ECP/Permit/WorkOrder/Checker Verdict 或 Release。凡提及 `PROPOSED` 的 ABI，需由原 Owner／Host Registry 真正綁定。

## 13. B1 / 949 原子適用投影、W18 正確 E33–E42 與真 Native E2E 測試

### 13.1 949/192 原身分與 B1 五組分母的「逐 ID 可查」模型

- SBL `R15.1=949` 是產品範圍，不是 B1 的當期 READY 工作數。原 `Kind/KindMode/Host/Cell/Donor/Method/Technique/Test/Work/Risk/...` 各自含原 polarity；依 `product_scope,bootstrap_scope,conditional_triggered,deferred_with_reason,not_applicable_to_boot` 做 *衍生* 調度，不回寫原 Required、Deferred 或 Owner。
- B1 的 `27 PI atom / 31 effect slot / 120 parent case / 124 child effect case / 38 node case` 分別有原 ID；按 `PI_AtomID→effect_slot?→PIPD_ECP→WorkOrderID→CaseSpec{parent,child,node}→Raw/Oracle→ProtectedVerdict` 關聯，**禁止對一個 Gate 的 PASS 替代另一 Gate**。受影 slot 為 read-only 時沒有 Permit 但須 ReadScope；Repo Effect 必有 DEV ECP；Host/User/Remote 使用其各專用許可。
- `CaseBinding@PROPOSED` 一筆一原 ID：`source_id,original_id,source_clause,original_status,applicability,trigger,affected_slot_id,workorder_ref,ecp_ref,case_kind,runner_registry_ref,oracle_id,expected_raw_type,first_fail,resume_predicate`。沒有合法 `runner_registry_ref` → `NOT_RUN`，不是 `KNOWN_FAILED`；真 checker 必具真 credential/ACL 非模型字面。附錄為 949/192/27/31/120/124/38 原身份表；本章下列 27/31 分支作實體工作/驗收路由，不把清冊縮成單純計數。[SRC-MASTER:§III.2][SRC-B1-00..08]

### 13.2 B1 原 27 PI 逐個受影責任、31 槽 Consumer 入口

| B1 原身份 | 原業務方向／Producer→WorkPackage、Consumer | 觸發與逐項 POS/NEG / 原生約束 |
|---|---|---|

| PI-B1-A1 ROOT_RAW | SRC-B1-01 original atom；依 Original Clause 保留用途；派 WP-FHS-10 取得真 source/Subject/ECP_or_ReadScope 連結 → B1 TQAEP Reader。 | POS 原 Atom 正例 case 與所需 Raw 以原 owner oracle 校驗；NEG 缺 Slot/SourceSHA、錯 EffectClass 或合併不同 atom 的 Gate → B1_ATOM_TRACE_HOLD；原本未准入仍 NOT_RUN。 |

| PI-B1-A2 ISSUER_SUBJECT | SRC-B1-01 original atom；依 Original Clause 保留用途；派 WP-FHS-03 取得真 source/Subject/ECP_or_ReadScope 連結 → B1 TQAEP Reader。 | POS 原 Atom 正例 case 與所需 Raw 以原 owner oracle 校驗；NEG 缺 Slot/SourceSHA、錯 EffectClass 或合併不同 atom 的 Gate → B1_ATOM_TRACE_HOLD；原本未准入仍 NOT_RUN。 |

| PI-B1-A3 QUEUE_WO | SRC-B1-01 original atom；依 Original Clause 保留用途；派 WP-FHS-04 取得真 source/Subject/ECP_or_ReadScope 連結 → B1 TQAEP Reader。 | POS 原 Atom 正例 case 與所需 Raw 以原 owner oracle 校驗；NEG 缺 Slot/SourceSHA、錯 EffectClass 或合併不同 atom 的 Gate → B1_ATOM_TRACE_HOLD；原本未准入仍 NOT_RUN。 |

| PI-B1-A4 RECEIVER_ABI | SRC-B1-01 original atom；依 Original Clause 保留用途；派 WP-FHS-03 取得真 source/Subject/ECP_or_ReadScope 連結 → B1 TQAEP Reader。 | POS 原 Atom 正例 case 與所需 Raw 以原 owner oracle 校驗；NEG 缺 Slot/SourceSHA、錯 EffectClass 或合併不同 atom 的 Gate → B1_ATOM_TRACE_HOLD；原本未准入仍 NOT_RUN。 |

| PI-B1-A5 MODEL_LANES | SRC-B1-01 original atom；依 Original Clause 保留用途；派 WP-FHS-04 取得真 source/Subject/ECP_or_ReadScope 連結 → B1 TQAEP Reader。 | POS 原 Atom 正例 case 與所需 Raw 以原 owner oracle 校驗；NEG 缺 Slot/SourceSHA、錯 EffectClass 或合併不同 atom 的 Gate → B1_ATOM_TRACE_HOLD；原本未准入仍 NOT_RUN。 |

| PI-B1-A6 EFFECT_JOURNAL | SRC-B1-01 original atom；依 Original Clause 保留用途；派 WP-FHS-04 取得真 source/Subject/ECP_or_ReadScope 連結 → B1 TQAEP Reader。 | POS 原 Atom 正例 case 與所需 Raw 以原 owner oracle 校驗；NEG 缺 Slot/SourceSHA、錯 EffectClass 或合併不同 atom 的 Gate → B1_ATOM_TRACE_HOLD；原本未准入仍 NOT_RUN。 |

| PI-B1-A7 RAW_EVIDENCE | SRC-B1-01 original atom；依 Original Clause 保留用途；派 WP-FHS-10 取得真 source/Subject/ECP_or_ReadScope 連結 → B1 TQAEP Reader。 | POS 原 Atom 正例 case 與所需 Raw 以原 owner oracle 校驗；NEG 缺 Slot/SourceSHA、錯 EffectClass 或合併不同 atom 的 Gate → B1_ATOM_TRACE_HOLD；原本未准入仍 NOT_RUN。 |

| PI-B1-A8 NATIVE_HOTPATH | SRC-B1-01 original atom；依 Original Clause 保留用途；派 WP-FHS-10 取得真 source/Subject/ECP_or_ReadScope 連結 → B1 TQAEP Reader。 | POS 原 Atom 正例 case 與所需 Raw 以原 owner oracle 校驗；NEG 缺 Slot/SourceSHA、錯 EffectClass 或合併不同 atom 的 Gate → B1_ATOM_TRACE_HOLD；原本未准入仍 NOT_RUN。 |

| PI-B1-A9 NATIVE_CONTINUATION | SRC-B1-01 original atom；依 Original Clause 保留用途；派 WP-FHS-10 取得真 source/Subject/ECP_or_ReadScope 連結 → B1 TQAEP Reader。 | POS 原 Atom 正例 case 與所需 Raw 以原 owner oracle 校驗；NEG 缺 Slot/SourceSHA、錯 EffectClass 或合併不同 atom 的 Gate → B1_ATOM_TRACE_HOLD；原本未准入仍 NOT_RUN。 |

| PI-B1-B1 SOURCE_ATOMS | SRC-B1-01 original atom；依 Original Clause 保留用途；派 WP-FHS-05 取得真 source/Subject/ECP_or_ReadScope 連結 → B1 TQAEP Reader。 | POS 原 Atom 正例 case 與所需 Raw 以原 owner oracle 校驗；NEG 缺 Slot/SourceSHA、錯 EffectClass 或合併不同 atom 的 Gate → B1_ATOM_TRACE_HOLD；原本未准入仍 NOT_RUN。 |

| PI-B1-B2 REPO_CONTEXT | SRC-B1-01 original atom；依 Original Clause 保留用途；派 WP-FHS-10 取得真 source/Subject/ECP_or_ReadScope 連結 → B1 TQAEP Reader。 | POS 原 Atom 正例 case 與所需 Raw 以原 owner oracle 校驗；NEG 缺 Slot/SourceSHA、錯 EffectClass 或合併不同 atom 的 Gate → B1_ATOM_TRACE_HOLD；原本未准入仍 NOT_RUN。 |

| PI-B1-B3 SBL_TO_NATIVE | SRC-B1-01 original atom；依 Original Clause 保留用途；派 WP-FHS-10 取得真 source/Subject/ECP_or_ReadScope 連結 → B1 TQAEP Reader。 | POS 原 Atom 正例 case 與所需 Raw 以原 owner oracle 校驗；NEG 缺 Slot/SourceSHA、錯 EffectClass 或合併不同 atom 的 Gate → B1_ATOM_TRACE_HOLD；原本未准入仍 NOT_RUN。 |

| PI-B1-B4 ECP_SELECTOR | SRC-B1-01 original atom；依 Original Clause 保留用途；派 WP-FHS-10 取得真 source/Subject/ECP_or_ReadScope 連結 → B1 TQAEP Reader。 | POS 原 Atom 正例 case 與所需 Raw 以原 owner oracle 校驗；NEG 缺 Slot/SourceSHA、錯 EffectClass 或合併不同 atom 的 Gate → B1_ATOM_TRACE_HOLD；原本未准入仍 NOT_RUN。 |

| PI-B1-B5 THREE_SP | SRC-B1-01 original atom；依 Original Clause 保留用途；派 WP-FHS-10 取得真 source/Subject/ECP_or_ReadScope 連結 → B1 TQAEP Reader。 | POS 原 Atom 正例 case 與所需 Raw 以原 owner oracle 校驗；NEG 缺 Slot/SourceSHA、錯 EffectClass 或合併不同 atom 的 Gate → B1_ATOM_TRACE_HOLD；原本未准入仍 NOT_RUN。 |

| PI-B1-B6 TODO_PERSISTENCE | SRC-B1-01 original atom；依 Original Clause 保留用途；派 WP-FHS-10 取得真 source/Subject/ECP_or_ReadScope 連結 → B1 TQAEP Reader。 | POS 原 Atom 正例 case 與所需 Raw 以原 owner oracle 校驗；NEG 缺 Slot/SourceSHA、錯 EffectClass 或合併不同 atom 的 Gate → B1_ATOM_TRACE_HOLD；原本未准入仍 NOT_RUN。 |

| PI-B1-B7 NOFIT_ROUTE | SRC-B1-01 original atom；依 Original Clause 保留用途；派 WP-FHS-10 取得真 source/Subject/ECP_or_ReadScope 連結 → B1 TQAEP Reader。 | POS 原 Atom 正例 case 與所需 Raw 以原 owner oracle 校驗；NEG 缺 Slot/SourceSHA、錯 EffectClass 或合併不同 atom 的 Gate → B1_ATOM_TRACE_HOLD；原本未准入仍 NOT_RUN。 |

| PI-B1-B8 TRACE_GRAPH | SRC-B1-01 original atom；依 Original Clause 保留用途；派 WP-FHS-10 取得真 source/Subject/ECP_or_ReadScope 連結 → B1 TQAEP Reader。 | POS 原 Atom 正例 case 與所需 Raw 以原 owner oracle 校驗；NEG 缺 Slot/SourceSHA、錯 EffectClass 或合併不同 atom 的 Gate → B1_ATOM_TRACE_HOLD；原本未准入仍 NOT_RUN。 |

| PI-B1-B9 R15_COVERAGE | SRC-B1-01 original atom；依 Original Clause 保留用途；派 WP-FHS-10 取得真 source/Subject/ECP_or_ReadScope 連結 → B1 TQAEP Reader。 | POS 原 Atom 正例 case 與所需 Raw 以原 owner oracle 校驗；NEG 缺 Slot/SourceSHA、錯 EffectClass 或合併不同 atom 的 Gate → B1_ATOM_TRACE_HOLD；原本未准入仍 NOT_RUN。 |

| PI-B1-C1 FABRIC_PROMOTION | SRC-B1-01 original atom；依 Original Clause 保留用途；派 WP-FHS-10 取得真 source/Subject/ECP_or_ReadScope 連結 → B1 TQAEP Reader。 | POS 原 Atom 正例 case 與所需 Raw 以原 owner oracle 校驗；NEG 缺 Slot/SourceSHA、錯 EffectClass 或合併不同 atom 的 Gate → B1_ATOM_TRACE_HOLD；原本未准入仍 NOT_RUN。 |

| PI-B1-C2 HGK_GWO | SRC-B1-01 original atom；依 Original Clause 保留用途；派 WP-FHS-10 取得真 source/Subject/ECP_or_ReadScope 連結 → B1 TQAEP Reader。 | POS 原 Atom 正例 case 與所需 Raw 以原 owner oracle 校驗；NEG 缺 Slot/SourceSHA、錯 EffectClass 或合併不同 atom 的 Gate → B1_ATOM_TRACE_HOLD；原本未准入仍 NOT_RUN。 |

| PI-B1-C3 SBL_GWO | SRC-B1-01 original atom；依 Original Clause 保留用途；派 WP-FHS-10 取得真 source/Subject/ECP_or_ReadScope 連結 → B1 TQAEP Reader。 | POS 原 Atom 正例 case 與所需 Raw 以原 owner oracle 校驗；NEG 缺 Slot/SourceSHA、錯 EffectClass 或合併不同 atom 的 Gate → B1_ATOM_TRACE_HOLD；原本未准入仍 NOT_RUN。 |

| PI-B1-C4 EXTERNAL_GRANT | SRC-B1-01 original atom；依 Original Clause 保留用途；派 WP-FHS-10 取得真 source/Subject/ECP_or_ReadScope 連結 → B1 TQAEP Reader。 | POS 原 Atom 正例 case 與所需 Raw 以原 owner oracle 校驗；NEG 缺 Slot/SourceSHA、錯 EffectClass 或合併不同 atom 的 Gate → B1_ATOM_TRACE_HOLD；原本未准入仍 NOT_RUN。 |

| PI-B1-C5 CODEX_MINPATCH | SRC-B1-01 original atom；依 Original Clause 保留用途；派 WP-FHS-10 取得真 source/Subject/ECP_or_ReadScope 連結 → B1 TQAEP Reader。 | POS 原 Atom 正例 case 與所需 Raw 以原 owner oracle 校驗；NEG 缺 Slot/SourceSHA、錯 EffectClass 或合併不同 atom 的 Gate → B1_ATOM_TRACE_HOLD；原本未准入仍 NOT_RUN。 |

| PI-B1-C6 REVOKE_RACE | SRC-B1-01 original atom；依 Original Clause 保留用途；派 WP-FHS-10 取得真 source/Subject/ECP_or_ReadScope 連結 → B1 TQAEP Reader。 | POS 原 Atom 正例 case 與所需 Raw 以原 owner oracle 校驗；NEG 缺 Slot/SourceSHA、錯 EffectClass 或合併不同 atom 的 Gate → B1_ATOM_TRACE_HOLD；原本未准入仍 NOT_RUN。 |

| PI-B1-C7 FOUR_LAYER_ID | SRC-B1-01 original atom；依 Original Clause 保留用途；派 WP-FHS-10 取得真 source/Subject/ECP_or_ReadScope 連結 → B1 TQAEP Reader。 | POS 原 Atom 正例 case 與所需 Raw 以原 owner oracle 校驗；NEG 缺 Slot/SourceSHA、錯 EffectClass 或合併不同 atom 的 Gate → B1_ATOM_TRACE_HOLD；原本未准入仍 NOT_RUN。 |

| PI-B1-C8 NATIVE_SUCCESSOR | SRC-B1-01 original atom；依 Original Clause 保留用途；派 WP-FHS-10 取得真 source/Subject/ECP_or_ReadScope 連結 → B1 TQAEP Reader。 | POS 原 Atom 正例 case 與所需 Raw 以原 owner oracle 校驗；NEG 缺 Slot/SourceSHA、錯 EffectClass 或合併不同 atom 的 Gate → B1_ATOM_TRACE_HOLD；原本未准入仍 NOT_RUN。 |

| PI-B1-C9 TRIPLE_GWO | SRC-B1-01 original atom；依 Original Clause 保留用途；派 WP-FHS-10 取得真 source/Subject/ECP_or_ReadScope 連結 → B1 TQAEP Reader。 | POS 原 Atom 正例 case 與所需 Raw 以原 owner oracle 校驗；NEG 缺 Slot/SourceSHA、錯 EffectClass 或合併不同 atom 的 Gate → B1_ATOM_TRACE_HOLD；原本未准入仍 NOT_RUN。 |

| OBS-B1-A1（B1 PD effect slot） | 原 SRC-B1-02；SRC-B1-02:L112 / 真 RepoContext/Host admission 依 effect class；與 TQ-CHILD-OBS-B1-A1 具體測例 join；NOT_EXECUTED_THIS_ROUND；effect projection REPO_WRITE → WP-FHS-06 / HGK Receiver/TQAEP；不擅自將 None 設 Ready。 | POS 原 ECP/Oracle/WorkOrder/Readback 統一 Subject/PolicyEpoch；NEG 欠 RepoContext/Issuer/Checker registry→SLOT_ADMISSION_HOLD 只影響該槽，未 Run 不是 Fail，退出依原 preimage。 |

| WO-B1-A2（B1 PD effect slot） | 原 SRC-B1-02；SRC-B1-02:L155 / 真 RepoContext/Host admission 依 effect class；與 TQ-CHILD-WO-B1-A2 具體測例 join；NOT_EXECUTED_THIS_ROUND；effect projection REPO_WRITE → WP-FHS-06 / HGK Receiver/TQAEP；不擅自將 None 設 Ready。 | POS 原 ECP/Oracle/WorkOrder/Readback 統一 Subject/PolicyEpoch；NEG 欠 RepoContext/Issuer/Checker registry→SLOT_ADMISSION_HOLD 只影響該槽，未 Run 不是 Fail，退出依原 preimage。 |

| WO-B1-A3（B1 PD effect slot） | 原 SRC-B1-02；SRC-B1-02:L197 / 真 RepoContext/Host admission 依 effect class；與 TQ-CHILD-WO-B1-A3 具體測例 join；NOT_EXECUTED_THIS_ROUND；effect projection REPO_WRITE → WP-FHS-06 / HGK Receiver/TQAEP；不擅自將 None 設 Ready。 | POS 原 ECP/Oracle/WorkOrder/Readback 統一 Subject/PolicyEpoch；NEG 欠 RepoContext/Issuer/Checker registry→SLOT_ADMISSION_HOLD 只影響該槽，未 Run 不是 Fail，退出依原 preimage。 |

| WO-B1-A4（B1 PD effect slot） | 原 SRC-B1-02；SRC-B1-02:L240 / 真 RepoContext/Host admission 依 effect class；與 TQ-CHILD-WO-B1-A4 具體測例 join；NOT_EXECUTED_THIS_ROUND；effect projection REPO_WRITE → WP-FHS-06 / HGK Receiver/TQAEP；不擅自將 None 設 Ready。 | POS 原 ECP/Oracle/WorkOrder/Readback 統一 Subject/PolicyEpoch；NEG 欠 RepoContext/Issuer/Checker registry→SLOT_ADMISSION_HOLD 只影響該槽，未 Run 不是 Fail，退出依原 preimage。 |

| OBS-B1-A5（B1 PD effect slot） | 原 SRC-B1-02；SRC-B1-02:L277 / 真 RepoContext/Host admission 依 effect class；與 TQ-CHILD-OBS-B1-A5 具體測例 join；NOT_EXECUTED_THIS_ROUND；effect projection REPO_WRITE → WP-FHS-06 / HGK Receiver/TQAEP；不擅自將 None 設 Ready。 | POS 原 ECP/Oracle/WorkOrder/Readback 統一 Subject/PolicyEpoch；NEG 欠 RepoContext/Issuer/Checker registry→SLOT_ADMISSION_HOLD 只影響該槽，未 Run 不是 Fail，退出依原 preimage。 |

| WO-B1-A6（B1 PD effect slot） | 原 SRC-B1-02；SRC-B1-02:L319 / 真 RepoContext/Host admission 依 effect class；與 TQ-CHILD-WO-B1-A6 具體測例 join；NOT_EXECUTED_THIS_ROUND；effect projection REPO_WRITE → WP-FHS-06 / HGK Receiver/TQAEP；不擅自將 None 設 Ready。 | POS 原 ECP/Oracle/WorkOrder/Readback 統一 Subject/PolicyEpoch；NEG 欠 RepoContext/Issuer/Checker registry→SLOT_ADMISSION_HOLD 只影響該槽，未 Run 不是 Fail，退出依原 preimage。 |

| OBS-B1-A7（B1 PD effect slot） | 原 SRC-B1-02；SRC-B1-02:L354 / 真 RepoContext/Host admission 依 effect class；與 TQ-CHILD-OBS-B1-A7 具體測例 join；NOT_EXECUTED_THIS_ROUND；effect projection REPO_WRITE → WP-FHS-06 / HGK Receiver/TQAEP；不擅自將 None 設 Ready。 | POS 原 ECP/Oracle/WorkOrder/Readback 統一 Subject/PolicyEpoch；NEG 欠 RepoContext/Issuer/Checker registry→SLOT_ADMISSION_HOLD 只影響該槽，未 Run 不是 Fail，退出依原 preimage。 |

| WO-B1-A8（B1 PD effect slot） | 原 SRC-B1-02；SRC-B1-02:L391 / 真 RepoContext/Host admission 依 effect class；與 TQ-CHILD-WO-B1-A8 具體測例 join；NOT_EXECUTED_THIS_ROUND；effect projection REPO_WRITE → WP-FHS-06 / HGK Receiver/TQAEP；不擅自將 None 設 Ready。 | POS 原 ECP/Oracle/WorkOrder/Readback 統一 Subject/PolicyEpoch；NEG 欠 RepoContext/Issuer/Checker registry→SLOT_ADMISSION_HOLD 只影響該槽，未 Run 不是 Fail，退出依原 preimage。 |

| WO-B1-A9（B1 PD effect slot） | 原 SRC-B1-02；SRC-B1-02:L433 / 真 RepoContext/Host admission 依 effect class；與 TQ-CHILD-WO-B1-A9 具體測例 join；NOT_EXECUTED_THIS_ROUND；effect projection REPO_WRITE → WP-FHS-06 / HGK Receiver/TQAEP；不擅自將 None 設 Ready。 | POS 原 ECP/Oracle/WorkOrder/Readback 統一 Subject/PolicyEpoch；NEG 欠 RepoContext/Issuer/Checker registry→SLOT_ADMISSION_HOLD 只影響該槽，未 Run 不是 Fail，退出依原 preimage。 |

| OBS-B1-B1（B1 PD effect slot） | 原 SRC-B1-02；SRC-B1-02:L468 / 真 RepoContext/Host admission 依 effect class；與 TQ-CHILD-OBS-B1-B1 具體測例 join；NOT_EXECUTED_THIS_ROUND；effect projection REPO_WRITE → WP-FHS-06 / HGK Receiver/TQAEP；不擅自將 None 設 Ready。 | POS 原 ECP/Oracle/WorkOrder/Readback 統一 Subject/PolicyEpoch；NEG 欠 RepoContext/Issuer/Checker registry→SLOT_ADMISSION_HOLD 只影響該槽，未 Run 不是 Fail，退出依原 preimage。 |

| OBS-B1-B2（B1 PD effect slot） | 原 SRC-B1-02；SRC-B1-02:L504 / 真 RepoContext/Host admission 依 effect class；與 TQ-CHILD-OBS-B1-B2 具體測例 join；NOT_EXECUTED_THIS_ROUND；effect projection REPO_WRITE → WP-FHS-06 / HGK Receiver/TQAEP；不擅自將 None 設 Ready。 | POS 原 ECP/Oracle/WorkOrder/Readback 統一 Subject/PolicyEpoch；NEG 欠 RepoContext/Issuer/Checker registry→SLOT_ADMISSION_HOLD 只影響該槽，未 Run 不是 Fail，退出依原 preimage。 |

| WO-B1-B3-DEV（B1 PD effect slot） | 原 SRC-B1-02；SRC-B1-02:L541 / 真 RepoContext/Host admission 依 effect class；與 TQ-CHILD-WO-B1-B3-DEV 具體測例 join；NOT_EXECUTED_THIS_ROUND；effect projection REPO_WRITE → WP-FHS-06 / HGK Receiver/TQAEP；不擅自將 None 設 Ready。 | POS 原 ECP/Oracle/WorkOrder/Readback 統一 Subject/PolicyEpoch；NEG 欠 RepoContext/Issuer/Checker registry→SLOT_ADMISSION_HOLD 只影響該槽，未 Run 不是 Fail，退出依原 preimage。 |

| WO-B1-B3-OPS（B1 PD effect slot） | 原 SRC-B1-02；SRC-B1-02:L583 / 真 RepoContext/Host admission 依 effect class；與 TQ-CHILD-WO-B1-B3-OPS 具體測例 join；NOT_EXECUTED_THIS_ROUND；effect projection REPO_WRITE → WP-FHS-06 / HGK Receiver/TQAEP；不擅自將 None 設 Ready。 | POS 原 ECP/Oracle/WorkOrder/Readback 統一 Subject/PolicyEpoch；NEG 欠 RepoContext/Issuer/Checker registry→SLOT_ADMISSION_HOLD 只影響該槽，未 Run 不是 Fail，退出依原 preimage。 |

| WO-B1-B4-DEV（B1 PD effect slot） | 原 SRC-B1-02；SRC-B1-02:L620 / 真 RepoContext/Host admission 依 effect class；與 TQ-CHILD-WO-B1-B4-DEV 具體測例 join；NOT_EXECUTED_THIS_ROUND；effect projection REPO_WRITE → WP-FHS-06 / HGK Receiver/TQAEP；不擅自將 None 設 Ready。 | POS 原 ECP/Oracle/WorkOrder/Readback 統一 Subject/PolicyEpoch；NEG 欠 RepoContext/Issuer/Checker registry→SLOT_ADMISSION_HOLD 只影響該槽，未 Run 不是 Fail，退出依原 preimage。 |

| WO-B1-B4-OPS（B1 PD effect slot） | 原 SRC-B1-02；SRC-B1-02:L661 / 真 RepoContext/Host admission 依 effect class；與 TQ-CHILD-WO-B1-B4-OPS 具體測例 join；NOT_EXECUTED_THIS_ROUND；effect projection REPO_WRITE → WP-FHS-06 / HGK Receiver/TQAEP；不擅自將 None 設 Ready。 | POS 原 ECP/Oracle/WorkOrder/Readback 統一 Subject/PolicyEpoch；NEG 欠 RepoContext/Issuer/Checker registry→SLOT_ADMISSION_HOLD 只影響該槽，未 Run 不是 Fail，退出依原 preimage。 |

| WO-B1-B5-DEV（B1 PD effect slot） | 原 SRC-B1-02；SRC-B1-02:L698 / 真 RepoContext/Host admission 依 effect class；與 TQ-CHILD-WO-B1-B5-DEV 具體測例 join；NOT_EXECUTED_THIS_ROUND；effect projection REPO_WRITE → WP-FHS-06 / HGK Receiver/TQAEP；不擅自將 None 設 Ready。 | POS 原 ECP/Oracle/WorkOrder/Readback 統一 Subject/PolicyEpoch；NEG 欠 RepoContext/Issuer/Checker registry→SLOT_ADMISSION_HOLD 只影響該槽，未 Run 不是 Fail，退出依原 preimage。 |

| WO-B1-B5-OPS（B1 PD effect slot） | 原 SRC-B1-02；SRC-B1-02:L740 / 真 RepoContext/Host admission 依 effect class；與 TQ-CHILD-WO-B1-B5-OPS 具體測例 join；NOT_EXECUTED_THIS_ROUND；effect projection REPO_WRITE → WP-FHS-06 / HGK Receiver/TQAEP；不擅自將 None 設 Ready。 | POS 原 ECP/Oracle/WorkOrder/Readback 統一 Subject/PolicyEpoch；NEG 欠 RepoContext/Issuer/Checker registry→SLOT_ADMISSION_HOLD 只影響該槽，未 Run 不是 Fail，退出依原 preimage。 |

| WO-B1-B6-USER（B1 PD effect slot） | 原 SRC-B1-02；SRC-B1-02:L777 / 真 RepoContext/Host admission 依 effect class；與 TQ-CHILD-WO-B1-B6-USER 具體測例 join；NOT_EXECUTED_THIS_ROUND；effect projection REPO_WRITE → WP-FHS-06 / HGK Receiver/TQAEP；不擅自將 None 設 Ready。 | POS 原 ECP/Oracle/WorkOrder/Readback 統一 Subject/PolicyEpoch；NEG 欠 RepoContext/Issuer/Checker registry→SLOT_ADMISSION_HOLD 只影響該槽，未 Run 不是 Fail，退出依原 preimage。 |

| OBS-B1-B7（B1 PD effect slot） | 原 SRC-B1-02；SRC-B1-02:L813 / 真 RepoContext/Host admission 依 effect class；與 TQ-CHILD-OBS-B1-B7 具體測例 join；NOT_EXECUTED_THIS_ROUND；effect projection REPO_WRITE → WP-FHS-06 / HGK Receiver/TQAEP；不擅自將 None 設 Ready。 | POS 原 ECP/Oracle/WorkOrder/Readback 統一 Subject/PolicyEpoch；NEG 欠 RepoContext/Issuer/Checker registry→SLOT_ADMISSION_HOLD 只影響該槽，未 Run 不是 Fail，退出依原 preimage。 |

| OBS-B1-B8（B1 PD effect slot） | 原 SRC-B1-02；SRC-B1-02:L852 / 真 RepoContext/Host admission 依 effect class；與 TQ-CHILD-OBS-B1-B8 具體測例 join；NOT_EXECUTED_THIS_ROUND；effect projection REPO_WRITE → WP-FHS-06 / HGK Receiver/TQAEP；不擅自將 None 設 Ready。 | POS 原 ECP/Oracle/WorkOrder/Readback 統一 Subject/PolicyEpoch；NEG 欠 RepoContext/Issuer/Checker registry→SLOT_ADMISSION_HOLD 只影響該槽，未 Run 不是 Fail，退出依原 preimage。 |

| OBS-B1-B9（B1 PD effect slot） | 原 SRC-B1-02；SRC-B1-02:L888 / 真 RepoContext/Host admission 依 effect class；與 TQ-CHILD-OBS-B1-B9 具體測例 join；NOT_EXECUTED_THIS_ROUND；effect projection REPO_WRITE → WP-FHS-06 / HGK Receiver/TQAEP；不擅自將 None 設 Ready。 | POS 原 ECP/Oracle/WorkOrder/Readback 統一 Subject/PolicyEpoch；NEG 欠 RepoContext/Issuer/Checker registry→SLOT_ADMISSION_HOLD 只影響該槽，未 Run 不是 Fail，退出依原 preimage。 |

| WO-B1-C1（B1 PD effect slot） | 原 SRC-B1-02；SRC-B1-02:L930 / 真 RepoContext/Host admission 依 effect class；與 TQ-CHILD-WO-B1-C1 具體測例 join；NOT_EXECUTED_THIS_ROUND；effect projection REPO_WRITE → WP-FHS-06 / HGK Receiver/TQAEP；不擅自將 None 設 Ready。 | POS 原 ECP/Oracle/WorkOrder/Readback 統一 Subject/PolicyEpoch；NEG 欠 RepoContext/Issuer/Checker registry→SLOT_ADMISSION_HOLD 只影響該槽，未 Run 不是 Fail，退出依原 preimage。 |

| WO-B1-C2（B1 PD effect slot） | 原 SRC-B1-02；SRC-B1-02:L973 / 真 RepoContext/Host admission 依 effect class；與 TQ-CHILD-WO-B1-C2 具體測例 join；NOT_EXECUTED_THIS_ROUND；effect projection REPO_WRITE → WP-FHS-06 / HGK Receiver/TQAEP；不擅自將 None 設 Ready。 | POS 原 ECP/Oracle/WorkOrder/Readback 統一 Subject/PolicyEpoch；NEG 欠 RepoContext/Issuer/Checker registry→SLOT_ADMISSION_HOLD 只影響該槽，未 Run 不是 Fail，退出依原 preimage。 |

| WO-B1-C3-OPS（B1 PD effect slot） | 原 SRC-B1-02；SRC-B1-02:L1017 / 真 RepoContext/Host admission 依 effect class；與 TQ-CHILD-WO-B1-C3-OPS 具體測例 join；NOT_EXECUTED_THIS_ROUND；effect projection REPO_WRITE → WP-FHS-06 / HGK Receiver/TQAEP；不擅自將 None 設 Ready。 | POS 原 ECP/Oracle/WorkOrder/Readback 統一 Subject/PolicyEpoch；NEG 欠 RepoContext/Issuer/Checker registry→SLOT_ADMISSION_HOLD 只影響該槽，未 Run 不是 Fail，退出依原 preimage。 |

| WO-B1-C3-USER（B1 PD effect slot） | 原 SRC-B1-02；SRC-B1-02:L1054 / 真 RepoContext/Host admission 依 effect class；與 TQ-CHILD-WO-B1-C3-USER 具體測例 join；NOT_EXECUTED_THIS_ROUND；effect projection REPO_WRITE → WP-FHS-06 / HGK Receiver/TQAEP；不擅自將 None 設 Ready。 | POS 原 ECP/Oracle/WorkOrder/Readback 統一 Subject/PolicyEpoch；NEG 欠 RepoContext/Issuer/Checker registry→SLOT_ADMISSION_HOLD 只影響該槽，未 Run 不是 Fail，退出依原 preimage。 |

| WO-B1-C4（B1 PD effect slot） | 原 SRC-B1-02；SRC-B1-02:L1096 / 真 RepoContext/Host admission 依 effect class；與 TQ-CHILD-WO-B1-C4 具體測例 join；NOT_EXECUTED_THIS_ROUND；effect projection REPO_WRITE → WP-FHS-06 / HGK Receiver/TQAEP；不擅自將 None 設 Ready。 | POS 原 ECP/Oracle/WorkOrder/Readback 統一 Subject/PolicyEpoch；NEG 欠 RepoContext/Issuer/Checker registry→SLOT_ADMISSION_HOLD 只影響該槽，未 Run 不是 Fail，退出依原 preimage。 |

| WO-B1-C5（B1 PD effect slot） | 原 SRC-B1-02；SRC-B1-02:L1133 / 真 RepoContext/Host admission 依 effect class；與 TQ-CHILD-WO-B1-C5 具體測例 join；NOT_EXECUTED_THIS_ROUND；effect projection REPO_WRITE → WP-FHS-06 / HGK Receiver/TQAEP；不擅自將 None 設 Ready。 | POS 原 ECP/Oracle/WorkOrder/Readback 統一 Subject/PolicyEpoch；NEG 欠 RepoContext/Issuer/Checker registry→SLOT_ADMISSION_HOLD 只影響該槽，未 Run 不是 Fail，退出依原 preimage。 |

| WO-B1-C6（B1 PD effect slot） | 原 SRC-B1-02；SRC-B1-02:L1174 / 真 RepoContext/Host admission 依 effect class；與 TQ-CHILD-WO-B1-C6 具體測例 join；NOT_EXECUTED_THIS_ROUND；effect projection REPO_WRITE → WP-FHS-06 / HGK Receiver/TQAEP；不擅自將 None 設 Ready。 | POS 原 ECP/Oracle/WorkOrder/Readback 統一 Subject/PolicyEpoch；NEG 欠 RepoContext/Issuer/Checker registry→SLOT_ADMISSION_HOLD 只影響該槽，未 Run 不是 Fail，退出依原 preimage。 |

| OBS-B1-C7（B1 PD effect slot） | 原 SRC-B1-02；SRC-B1-02:L1209 / 真 RepoContext/Host admission 依 effect class；與 TQ-CHILD-OBS-B1-C7 具體測例 join；NOT_EXECUTED_THIS_ROUND；effect projection REPO_WRITE → WP-FHS-06 / HGK Receiver/TQAEP；不擅自將 None 設 Ready。 | POS 原 ECP/Oracle/WorkOrder/Readback 統一 Subject/PolicyEpoch；NEG 欠 RepoContext/Issuer/Checker registry→SLOT_ADMISSION_HOLD 只影響該槽，未 Run 不是 Fail，退出依原 preimage。 |

| WO-B1-C8（B1 PD effect slot） | 原 SRC-B1-02；SRC-B1-02:L1251 / 真 RepoContext/Host admission 依 effect class；與 TQ-CHILD-WO-B1-C8 具體測例 join；NOT_EXECUTED_THIS_ROUND；effect projection REPO_WRITE → WP-FHS-06 / HGK Receiver/TQAEP；不擅自將 None 設 Ready。 | POS 原 ECP/Oracle/WorkOrder/Readback 統一 Subject/PolicyEpoch；NEG 欠 RepoContext/Issuer/Checker registry→SLOT_ADMISSION_HOLD 只影響該槽，未 Run 不是 Fail，退出依原 preimage。 |

| OBS-B1-C9（B1 PD effect slot） | 原 SRC-B1-02；SRC-B1-02:L1286 / 真 RepoContext/Host admission 依 effect class；與 TQ-CHILD-OBS-B1-C9 具體測例 join；NOT_EXECUTED_THIS_ROUND；effect projection REPO_WRITE → WP-FHS-06 / HGK Receiver/TQAEP；不擅自將 None 設 Ready。 | POS 原 ECP/Oracle/WorkOrder/Readback 統一 Subject/PolicyEpoch；NEG 欠 RepoContext/Issuer/Checker registry→SLOT_ADMISSION_HOLD 只影響該槽，未 Run 不是 Fail，退出依原 preimage。 |

**31 槽受影派工完整性**：上表需由實際 `SRC-B1-02` 的原 JSON/slot ID 定義核驗，一個只讀槽不要求 HGK effect token、但不取消 ACL；`unknown` 表示尚待 discovery（非 `[]` 無依賴）；對每一受影 POS/NEG 仍須具真 Runner/Case raw。以 31 槽分別產投影卡並入 WP10，不創 31 張多餘人工 Owner 簽章。B1 `120+124=244` 是 parent+child test，38 node 不加當同分母替換；Native `120/124` 全合格需同原 CaseID/Reader 與有權 Checker 當期實測。[SRC-B1-02/05]

### 13.3 三張 Golden WorkOrders：三個 operation、三套 Raw/Checker，不能合一

| 原 WorkOrder | 真前置/Producer/效果 | 應證 POS Raw／NEG FirstFail／Rollback |
|---|---|---|
| GWO-FABRIC | 既有非 Legacy Proposal A/B 或合法 HGK PLAN；Fabric Policy 原 Owner 生效 consumer/Active/Loaded，必要 OPS ECP/Permit。 | POS operation_id_FABRIC, sourceSHA, active/loadedSHA, PolicyEpoch, consumerACK, world pre/post, checkerPrincipal；NEG Stage-only、沒有 Activator 卻宣稱 Loaded；回復前 Active Policy，保留原 signed raw。 |
| GWO-HGK | HGK 唯一 Registry/Resolver/Issuer/Receiver，真 nonce/TTL/SID、DEV/OPS ECP 依 effect class；Hermes 維持唯一 SharedSpine。 | POS 受權 effect one-time＋Protected Verdict；NEG wrong signer/old nonce/duplicate lease；unknown world effect 先 reconcile，需補償另 ECP。 |
| GWO-SBL | SBL原 Source/PI/PD、PLAN合法 A/B proposal Producer，禁止 legacy sbl-commander-sp；有真 WriteSet 才允許 Worker。 | POS same candidate/source SHA repo build/CLI skill user result/raw/Checker；NEG 已禁 Commander 自啟、產品源自改、B1 case 用 R15 949 自證；rollback Source/Host adapter 不捨棄原用戶需求。 |

三 GWO 各有自己的 `operation_id/candidateSHA/PolicyEpoch/Raw/Checker`；原 B1 `G-A` 六項與 `G-B` 各自只消費其正式 Gate/Case raw。GitHub 當期四庫 closure index 的 `mission_complete:true` 屬 Repo 可見 Evidence Claim，正式 `SourceFreeze:HOLD`/`release:NOT_RUN` 仍保留；本文未重跑 Windows Host，不能改寫為即時 `B1_NATIVE_ACCEPTED`。[SRC-08:§8][SRC-B1-08]

### 13.4 W18：E33–E42 **原 ID 原情境**（此表取代 v1 §8 的錯配）

W18 是 `Post-B1 Operational Readiness`，不加入 B1 `Required` 原分母；原 `W00–W17/E01–E32` 均留原義。以有權 B1 原 Gate 收據後依 HGK 現役 Reducer `same mission sub-scope` 或 `followup work ref` A/B 選擇，不創第二 Queue。`E33,E37,E38,E40,E42` 是必要 Must；其餘按原 Fixture 適用，不能自動 waive。以下每案都需要新 PID/Session、Source/Host/PolicyEpoch/DefaultProfileSHA 與每個 applicable Runner 原始 raw/負例，而非寫預期 PASS。[SRC-14:W18.1–W18.4][SRC-MASTER:L1834–1843][AUDIT:§5]

| E-ID / 原生 Fixture | Reader/Producer 操作、真 POS | 原 NEG/FirstFail／回退 |
|---|---|---|

| E33 **新 OS PID/Session＋正式 Default Profile**，普通 Goal＋Source 真 Intake | WP12 原受權 Reader；POS：新 PID commandline/env/profileSHA、manual_b1_prompt_count=0、Goal/Source→Intake Raw；與 SourceSHA/Subject/CandidateSHA/PolicyEpoch 一致，真可執行 Caller/Raw 才判該案。 | NEG：依賴 B1 長 Prompt/test-only profile→NORMAL_ENTRY_PROMPT_DEPENDENCY；PARK 該案/Host Adapter，修正後在**新 PID**重測；不得重定義 ID。 |

| E34 **新 Source/PI_READY/PREDEV_READY**，選八個合法 Quickstart 分支 | WP05/12 原受權 Reader；POS：Source/CurrentState/PIPD 真 State→合法 Quickstart 分支/NoEffect HandOff；與 SourceSHA/Subject/CandidateSHA/PolicyEpoch 一致，真可執行 Caller/Raw 才判該案。 | NEG：無 Source 造 PI／PreDev 直接 effect→PIPD_STATE_MISROUTE；PARK 該案/Host Adapter，修正後在**新 PID**重測；不得重定義 ID。 |

| E35 **已有 EXECUTION_ADMITTED + WorkSet**，驗 currentness 後直派 READY，**不重編 PI/PD** | WP04/12 原受權 Reader；POS：Admitted Bundle OriginalSHA/HEAD/TTL/Epoch/Scope 同當期；直接 ExistingWO READY ACK；與 SourceSHA/Subject/CandidateSHA/PolicyEpoch 一致，真可執行 Caller/Raw 才判該案。 | NEG：舊 Epoch/Scope 當現行→ADMISSION_MISMATCH；PARK 該案/Host Adapter，修正後在**新 PID**重測；不得重定義 ID。 |

| E36 **既有專案 Done＋Remaining**，新 Session 只輸入「接續」 | WP04/12 原受權 Reader；POS：讀 SharedSpine Journal/Cursor 復用同 Op、只有 Remaining dispatch；與 SourceSHA/Subject/CandidateSHA/PolicyEpoch 一致，真可執行 Caller/Raw 才判該案。 | NEG：重播 Done/只依聊天記憶→DURABLE_CONTEXT_NOT_REUSED；PARK 該案/Host Adapter，修正後在**新 PID**重測；不得重定義 ID。 |

| E37 **普通 Goal 未指定工具/模型/Lane**，Mandatory Method 自選且 **真 Invoke；Required==Served** | WP12/17 原受權 Reader；POS：real lane required/served provider+model+policy epoch、method invocation id + budget；與 SourceSHA/Subject/CandidateSHA/PolicyEpoch 一致，真可執行 Caller/Raw 才判該案。 | NEG：藏人工 prompt／漏必需方法/偷換替代→NATIVE_METHOD_AUTOROUTE_FAIL；PARK 該案/Host Adapter，修正後在**新 PID**重測；不得重定義 ID。 |

| E38 **已准入可逆 Repo/Host Effect**，Fabric Active/Loaded/Consumed＋HGK Permit＋Hermes World Raw＋Checker | WP06/08/12 原受權 Reader；POS：one admitted operation/nonce/CAS、WorldPrePostRaw、独立 protected verdict；與 SourceSHA/Subject/CandidateSHA/PolicyEpoch 一致，真可執行 Caller/Raw 才判該案。 | NEG：停在 Stage／無 Permit 效果→NATIVE_AUTOHANDOFF_UNPROVEN；PARK 該案/Host Adapter，修正後在**新 PID**重測；不得重定義 ID。 |

| E39 **純唯讀 Goal**，無 Repo Diff／Native Effect、無關工具不 Invoke | WP12/17 原受權 Reader；POS：repo_mutation=0/native_effect=0，method NOT_TRIGGERED_WITH_REASON；與 SourceSHA/Subject/CandidateSHA/PolicyEpoch 一致，真可執行 Caller/Raw 才判該案。 | NEG：強求 Admin/啟動無關 Tool mutate→UNNECESSARY_METHOD_TRIGGER；PARK 該案/Host Adapter，修正後在**新 PID**重測；不得重定義 ID。 |

| E40 **Session 關閉後全新 OS PID**，正式 Default Profile/Route Registry/Policy/Lane/LoadedSHA 持久 | WP12 原受權 Reader；POS：跨 PID 相同正式 profileSHA/source/loaded_SHA；完全不需 B1 prompt；與 SourceSHA/Subject/CandidateSHA/PolicyEpoch 一致，真可執行 Caller/Raw 才判該案。 | NEG：重啟掉 Profile/需要再貼 B1 長 Prompt→NORMAL_PROFILE_NOT_PERSISTENT；PARK 該案/Host Adapter，修正後在**新 PID**重測；不得重定義 ID。 |

| E41 **錯 Epoch／Expired Permit／Required≠Served**，受影 NACK/PARK，無關 B/C 照進 | WP12 原受權 Reader；POS：InvalidEffect zero、unrelated READY>0 仍派、Case-specific NACK raw；與 SourceSHA/Subject/CandidateSHA/PolicyEpoch 一致，真可執行 Caller/Raw 才判該案。 | NEG：模型偷換、全局 HOLD、重播 token→AUTOROUTE_FAIL_CLOSED_MISSING；PARK 該案/Host Adapter，修正後在**新 PID**重測；不得重定義 ID。 |

| E42 **移除四方 test-only Skill Binding**，新 Session 仍可 Invoke 正式 Native TPM/Commander/Challenge | WP11/12 原受權 Reader；POS：uninstall/registry fresh PID negative residue＋Native production paths Invoke Raw；與 SourceSHA/Subject/CandidateSHA/PolicyEpoch 一致，真可執行 Caller/Raw 才判該案。 | NEG：靠測試 Skill 才能工作→TEST_PROFILE_DEPENDENCY；PARK 該案/Host Adapter，修正後在**新 PID**重測；不得重定義 ID。 |

**三日常普通入口**：`NM01 新工程`＝只給 Goal+必要 PIPD 包，從原 Intake/Quickstart 到合法 Worker/Checker；`NM02 持久續工`＝一句「接續」＋合法 Project Locator，SharedSpine 只派 Remaining；`NM03 唯讀分析`＝Goal 明言不改碼，任何高權 Tool/Repo Diff/Effect 一律不觸發。三者每一個都在無 B1 長 Prompt、沒有隱形 tool route 的新 OS Process/Session 測試。W18 規定有條件順序 `E33 → E34/E35 → E37/E38 → E39 → E36/E40 → E41 → E42`；E42 後再冷啟 E33/E37/E38 作依賴清除負例。不同 E-ID 的 raw 不可互借，也不能以 portable test profile 模擬 Native。[SRC-14:W18 §§6.1, W18.2–W18.4]

### 13.5 Golden Journey POS/NEG/SEC/EDGE 原生 Runner 約束

| Journey / 原用戶可見成果 | 原生 Runner/證據（執行前須現役發現） | 反證與退出 |
|---|---|---|
| GJ-CLI | fresh host 安裝 wheel/bin→help/add/list/remove/uninstall；raw binarySHA/exit/stdout/stderr/user_result | 不認識子命令非零、資料超 ACL DENY、卸載無殘留；不把文字示範當 install。 |
| GJ-SKILL | 每個 Host 的 Loader Registry、適用與無關 prompt、loadedSHA、卸載新 PID | 非觸發或未裝都不得變成技能在場。 |
| GJ-SIMPLE_AGENT | one allowed tool+budget+grant 正向成功，撤銷後不再 effect | 不受限 agent/permission escalation/timeout 新 nonce replay DENY。 |
| GJ-TPM→PI→PD | K0..K3 +18 stages→正式 Writer raw/Trace/PIPD ECP；Owner與Reader分離 | 無 source 造 Native PI，12v9/Oracle collision 暗自修正 DENY。 |
| GJ-PLAN→EXECUTE | A/B合法 Proposal→Real Issuer→SharedSpine Lease→Hermes actual PID/Worker→WorldRaw | cycle/duplicate job/unknown effect replay/stale lease/new issuer 全 NACK。 |
| GJ-CHALLENGE | A/B/C分立，CaseSpec POS+NEG H4/SEAM 應用性，Different principal Protected AO | 只有自評/自簽禁止 Independent PASS。 |
| GJ-B1 | 27/31/120/124/38 分群+三 GWO/G-A/G-B 的原 Native Writer Raw | Repo claim不能代這次 Windows Live；各 Gate 獨立判。 |
| GJ-W18 | NM01–03/E33–E42 新 PID Default Profile；required/served、工具實 invoked、非觸發 | 仍需 B1 專用 long prompt、test-only binding、偷 fallback 各判失敗。 |
| GJ-RELEASE | 原 Publisher/Owner 真簽與 rollout/readback（不在本輪） | CI/PR/Markdown sealed 不等同 Signed Release。 |

**可判斷的驗收層級**：`DESIGN_SPECIFIED`, `STATIC_SCHEMA_VERIFIED`, `INSTALLED`, `HOST_LOADED`, `INVOKED`, `WORLD_EFFECT_READBACK`, `INDEPENDENT_CHECKER_VERDICT`, `OWNER_RATIFIED`, `RELEASED` 分開；本設計只把 Case/Owner/expected Raw 定義好，沒有親自執行 Windows 或獨立 AO。[SRC-PIPD-07/09]
## 14. 低治理高自治、3 Lane 模型/工具必需路由、效率與撤銷

### 14.1 三 Lane 每卡 Required/Served 與強制方法的原生證據

`PLAN/EXECUTE/VERIFY_SECURITY` 每個任務一個 `LaneRouteEvidence@PROPOSED` 投影：`{lane,subject_sha,work_id,policy_epoch,required:{provider,model,method_ids[],budget,quality_floor},selected:{...},served:{provider,model,method_invocations:[{id,runner_sha,exit,raw_ref}]},route_registry_sha,owner_fallback_ref}`。Real actual fields/enums 從 HGK 現役 Registry 探得，不做自造路由 token。`Required!=Served`（provider/model/method/epoch/timeout/price 或 permission 違反當期 Policy）→僅受影 WORK `NOFIT/PARK`；如果 Owner **已事前批准**在同 Host 同 Quality/Cost/Latency/Permission 的等價 fallback，需真負例/降級防護及 Reader Ack，不能因供應商 Off 自動亂換。`E37` 必須看真 Method Invoke，不看 Skill 名字/CLI 可載入。[SRC-08:§4.3][SRC-07:§5][SRC-14:W18]

| Method | 適用 Trigger／是否必須 Invoke | NEG / 不啟動的正當條件 |
|---|---|---|
| KANBAN | 現役 WorkBoard Policy MANDATORY 且任務有跨 Session 多卡→原 Hermes/HGK Board 實讀；只有單卡 L0 時可 NotTriggered。 | 生成第二 durable queue/幽靈 READY DENY；無 real route 時 METHOD_BIND_HOLD。 |
| SWARM | 真有可平行拆分、scope 不互撞、budget/agent principal 可核；必要時 route-before-spawn。 | 任意召四模型當四個 Checker/無限子代理 DENY；單任務 NotTriggered。 |
| FAR | 出現具證據 FirstFail、已驗 KnownFix 可用且 budget 允許；Red→Patch→Green 有界。 | 無故每題研究、世界效果自動重試或修改 Oracle DENY。 |
| OpenSpec | Brownfield source/change 真的符合原適用 Method，版本+真 Runner 綁定。 | 全部 Goal 都強制 CLI 產長 workflow 或替換 PI Canonical DENY。 |
| gstack / Superpowers / Spec Kit / Matt methods / GSD | 各以 §9 的原 OriginalDisposition＋Host Policy 適用結果啟用，不屬 Required 時具 NOT_SELECTED_WITH_REASON。 | 以 REF/DEFER/NO_SOURCE_EVIDENCE 強迫安裝錯；未實效不可宣稱方法已調用。 |

### 14.2 Owner Decision Only-once 與 L0–L4

| Effect/Case | 自動許可或受影 Owner Decision | 必須 NACK 的反例 |
|---|---|---|
| L0 設計 Source 讀/TPM問答 | 真 ACL/SourceRef 可讀就無需 L3 Permit；GHP01 去重問一次 GitHub 意向。 | 每次讀檔強求 Admin→GOVERNANCE_OVERBLOCK。 |
| L2 有界受權Repo Red/Patch/Green | 原 Standing Grant 仍滿足 subject/scope/TTL/epoch/risk/WriteSet 時重用，無效時只 PARK 受影。 | 擴 repo root、reparse escape、修改 Oracle Writer→請原 Owner 有權批准。 |
| L2 讀回/Verifier | ReadScope+真 Runner/Principal 獨立時直接讀已准入 Raw；缺就 NOT_RUN。 | Maker 使用不同模型角色但同 credential 假稱 SoD。 |
| L3 Repo/Host/User/Policy | 真 PIPD ECP + Fabric Loaded + HGK Issuer Permit + Host Gate，at-most-once；只對新高風險、跨域、不可逆/PolicyEpoch drift 另開 DecisionPack。 | Expired Permit/new nonce replay/範圍擴大無批准 DENY。 |
| L4 Remote Publish / Merge / Release | GHP02＋原 Domain Publisher/Owner 簽章＋Protected AO，正常 UNDECIDED/LOCAL_ONLY 可完成本地交付不 Push。 | 本地 CI綠自動 Remote Merge/Release DENY。 |

`StandingScope@PROPOSED` 去重鍵 = `(owner,subjectSHA,sourceManifestSHA,effectClass,writeSetHash,policyEpoch,TTL,risk_ceiling)`；任何降風險、變寬效果或 TTL 過期不可默繼承。`OwnerDecisionPack` 只帶原有真 Domain Owner 能核准的 conflict refs/options，未簽只有詢問建議。撤銷後未用的 Permit/Lease 立即不可 Claim，已未知效果必先 ReadWorld/reconcile，不重送已消耗 nonce。單人 Owner 不等於一個 Maker principal 可以合法充當受保護 Checker。

### 14.3 衡量開發速度和過度治理（不捏造 performance threshold）

每一匹配任務 Corpus 固定 `SourceSHA/HostBuild/ModelBudget/Risk/EffectClass` 後量測 `end_to_end_wall_time, human_prompt_count, duplicate_decision_count, ready_idle_seconds, CAS_wait, retry_count, rework_diff_lines, FirstFail_time_to_fix, artifact_count, token_cost, covered_atom_count, nofit_count, provider_off_count, resumed_without_reprompt, false_trigger`；按 `B0` 原舊路線／`B1` 本設計／`B2` 原生驗證後比較，分位數與置信區間需真執行，不能在文件先設假 PASS。驗收參數 `MAX_PROMPTS, MAX_WALLTIME, MAX_REWORK, MIN_TRACE_COVERAGE` 需原 Owner/產品驗收訂版，現為 `THRESHOLD_OWNER_PENDING`。W18 的 `manual_b1_bootstrap_prompt_count=0` 是原強制零條件而非任意性能目標。不能拿縮減安全 gate 的「快速」當成功。[SRC-53:§7][SRC-14:W18.4]

## 治理失效的可重跑反證/最小修正

**重複索權**：Key=(subject,sourceSHA,scope,epoch,decision_type) 命中有效既有 OwnerRecord→直接引用；NEG 同 Scope 重問；撤銷則新判准。**Permit 循環**：Proposal A/B 預先合法、只在 Effect 前要求 ECP/Issuer；NEG 候選需先持有自身未發 Permit。**SharedSpine 飢餓**：獨立 Ready/Blocked/Parked 佇列讀回，短 TTL Lease 與公平分派；NEG 一張缺 Source 使全部 Ready 停機。**CI 代理驗收**：同 `raw.world_hash` 和 Checker credential，CI 只屬供應鏈；NEG 綠色 PR 掩蓋 Native 0 run。**Host 安裝/載入分離**：實際 imported origin、binary SHA、PID、policy epoch；NEG repo grep 提示 loaded。

W18 `E33..E42` 的原受影 Mapping 必逐案例保留；尤其 E33/E37/E38/E40/E42 `Must`，而 E34/E35/E36/E39/E41 按原 Fixture Trigger 不能無故 waived。B1 的 G-A、G-B、三 GWO 及 W18 的 Case 是不同 Gate，均不可借對方舊 Receipt。
