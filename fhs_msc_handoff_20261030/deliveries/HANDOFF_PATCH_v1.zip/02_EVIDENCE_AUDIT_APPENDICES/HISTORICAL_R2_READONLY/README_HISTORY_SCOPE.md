# 唯讀歷史 bytes archive

此目錄不是本版有效 Reader。R2 manifest、mapping、test script、closure 與原文以原 bytes 保存；其中舊相對路徑、命令和候選收據只供追溯，不解析為當期契約。當期只使用 STATIC_REPAIR_v1/CURRENT_READER_LOCATORS_2221.json 與外側10–13附錄。歷史連結不改寫，以保持來源 SHA。
