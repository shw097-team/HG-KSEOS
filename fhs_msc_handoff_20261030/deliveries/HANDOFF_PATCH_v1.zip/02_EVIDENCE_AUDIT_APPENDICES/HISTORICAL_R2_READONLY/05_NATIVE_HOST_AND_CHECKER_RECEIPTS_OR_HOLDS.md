> **R2 受影更新 / CURRENT**：R2 實機狀態：HOST/LOADED/ISSUER/282 runner/Checker/Publisher 仍 `NOT_OBSERVED/NOT_RUN`，所有 R2 schema-shape/replay 只屬 AUTHOR_SIDE，不升 Claim。

# 05｜Native Host、Checker Receipt 與精確受影停點

| Layer | 本輪最新直接觀測 | 最低前提 | 可以合法做的下一步 |
|---|---|---|---|
| SKILL_AVAILABLE | 14 項 sbl-tpm-sp 技能的 `skill.md` 已實際讀取，8 pipd stage + TPM 6 | Installed plugin skill/contract | 來源綁定設計候選 |
| HOST_LOADED | NOT_OBSERVED：未取得使用者 Windows GPT/Hermes runtime loaded manifest | 真 Host process SHA + session | 原 Host Loader Reader 當期探查 |
| GitHub source | OBSERVED 4×main SHA + 9 個相對路徑 blob | GitHub connector readonly | 建立 source-bound patch / ABI candidate |
| LOCAL RepoContext | NOT_BOUND | 原 Windows root/HEAD/index/untracked/reparse/ACL | 原 RepoContext Reader 唯讀綁定 |
| Fabric Policy | NOT_OBSERVED | `Stage→OwnerApproved→Active→Loaded→ConsumerACK` | 原 Policy Owner/Host Consumer 收據 |
| HGK Issuer | NOT_OBSERVED | 原 Issuer signed exact scope/nonce/TTL/epoch | 有界原 WorkOrder/Permit |
| Hermes worker | NOT_OBSERVED | 新 PID/loaded profile/actual 3-lane served/operation intent/cursor | 真 Worker 受權運行 |
| B1 282 tests | 282 CASE/NODE SPECS，NATIVE_NOT_RUN | 本輪 Registry runner+Raw+Checker | 每 Case 原 Runner Binding→Native execution |
| W18 E33–E42 | NOT_RUN | Fresh PID ordinary goal/without B1 prompt/actual served | 原 Hermes/Host Owner 執行 UAT |
| Protected Checker | NOT_RUN / CREDENTIAL_UNBOUND | maker/checker distinct + same-candidate Raw/Oracle | 原 Independent Checker Writer |
| Owner Ratification | NOT_GRANTED | 原 Domain Owner 各自 ACK | 只對受影 capability 解除 HOLD |
| Production Release | NOT_RUN | 原 Publisher GHP-02 + checker/owner receipts | 原 Publisher |

## 同 Scope 真續工與復原約束
- 同 `Subject/SourceSHA/Scope/PolicyEpoch` 且未過期的 admitted WorkID cursor 原位恢復；不可再要求 Owner 重貼 B1 Prompt。
- `operation_id` UNKNOWN 先查 world commit/partial/no-effect，若是 NO_EFFECT 且原 Issuer 允許才可發新 nonce；不能盲重播。
- source/Policy/Host drift 只失效受影錐；已合法 L0/L1 SourceRead 可續。
- 外掛/作者端快照不能替 Host manifest、真 Signature 或 Checkers。
