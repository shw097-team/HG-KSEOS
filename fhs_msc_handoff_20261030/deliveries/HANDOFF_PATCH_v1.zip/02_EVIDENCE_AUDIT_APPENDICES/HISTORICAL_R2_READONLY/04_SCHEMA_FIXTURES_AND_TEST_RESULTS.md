> **R2 受影更新 / CURRENT**：R2 測試入口：`_machine/R2_STATIC_REPLAY.py`；原 R1 20 個静態 AUTHOR PASS 是歷史，不等於現行 R2 重播。新測試 raw、rc、測試程式 sha 在 `_machine/R2_REPLAY_EXECUTION_RECEIPT.json`。

# 04｜Schema/fixture 靜態測試（已實際執行作者端測試）

這裡只運行隔離 Python in-memory 身份集合、原 ID 在 BODY 的實際檢索、簡單 NEG guard、WP DAG 非循環。此處不是原 PIPD Compiler 實際運行，也不驗證與 Host 現役 Registry ABI 完全一致。

| Case | Expected | Actual | 結果 |
|---|---|---|---|
| `ST-01-17-BODY` | `True` | `True` | STATIC_PASS |
| `ST-02-14-SBL` | `True` | `True` | STATIC_PASS |
| `ST-03-10-PIPD` | `True` | `True` | STATIC_PASS |
| `ST-04-R15-949` | `949` | `949` | STATIC_PASS |
| `ST-05-CELL192` | `192` | `192` | STATIC_PASS |
| `ST-06-FIVE-ASSETS` | `485` | `485` | STATIC_PASS |
| `ST-07-B1-282` | `282` | `282` | STATIC_PASS |
| `ST-08-AC15` | `15` | `15` | STATIC_PASS |
| `ST-09-ORACLE96` | `96` | `96` | STATIC_PASS |
| `ST-10-WP22` | `22` | `22` | STATIC_PASS |
| `ST-11-INTAKE-NEG` | `INTAKE_INVALID` | `INTAKE_INVALID` | STATIC_PASS |
| `ST-12-TRAVERSAL-NEG` | `AUTHORITY_UNKNOWN` | `AUTHORITY_UNKNOWN` | STATIC_PASS |
| `ST-13-FAKE-CHECKER-NEG` | `TQ_SOD` | `TQ_SOD` | STATIC_PASS |
| `ST-14-UNKNOWN-EFFECT-NEG` | `RECONCILE_REQUIRED` | `RECONCILE_REQUIRED` | STATIC_PASS |
| `ST-15-DAG-ACYCLIC` | `True` | `True` | STATIC_PASS |
| `ST-16-DAG-CYCLE-INJECTION` | `False` | `False` | STATIC_PASS |
| `ST-17-ALL-IDS-IN-BODY` | `True` | `True` | STATIC_PASS |
| `ST-18-REPO-SHA-PIN` | `True` | `True` | STATIC_PASS |
| `ST-19-SBL-MODE-NO-EFFECT` | `True` | `True` | STATIC_PASS |
| `ST-20-PIPD-CLI13` | `True` | `True` | STATIC_PASS |

## 實質負例與下一個接收者

| 原域 | 必須拒收的刺激 | 合格 FirstFail | 有權 Reader／缺證 |
|---|---|---|
| PIPD Intake | blank goal/`../` | `INTAKE_INVALID/AUTHORITY_UNKNOWN` | 原 PIPD-EC Reader；本輪僅作者端形狀 |
| PI | unknown `_profile_meta` | `PI_SCHEMA` | 原 strict compiler；未使用私造 field |
| PD | missing true RepoContext/foreign root | `REPO_CONTEXT_MISSING` | 原 Binder（Windows Host 未綁） |
| DEV/OPS ECP | no token / wrong effect | `ECP_PERMISSION` | 原 Issuer/Writer（未獲 permit） |
| TQAEP | maker=checker/self receipt | `TQ_SOD` | Protected Checker（未執行） |
| Fabric/HGK | Stage-only/old epoch/foreign host | `POLICY_NOT_LOADED/FOREIGN_HOST_RECEIPT` | Policy Owner/Host Consumer (NOT_OBSERVED) |
| Hermes | stale lease and replayed nonce | `LEASE_FENCING_DENY` | 原 Journal/Issuer（NOT_OBSERVED） |
| Shadow | W2 frozen input tries world write | `SHADOW_NOEFFECT` | 原 SBL ModeGate Owner（NOT_INVOKED） |
| DefaultHotSwap | unknown license/install state | `ACTIVATION_HOLD` | Host/License Owner（NOT_BOUND） |

## 不誇大含義
- `STATIC_PASS` 僅證明本輪 Python/JSON/字串/graph predicate 的結果；真正 Domain Business Oracle、外部 Principal 及 Host runtime 均未操作。
- 機器對帳逐 ID 有正文位置並不等於語義獨立 Ratification。完整 JSON：`_machine/STATIC_AUTHOR_TEST_RESULTS.json` 與 `_machine/COVERAGE_LEDGER.json`。

## 原Case結構異構處置

B1 282 case 分為120 Parent、124 Child、38 Node，物理schema不同；初始泛用欄位讀取無法正確展示162件Child/Node 的完整Consumer/POS/Exit。已按原各schema的 `native_issuer/stimulus/rollback_or_recovery` 和 `owner_writer/oracle_positive/oracle_negative` 專屬欄位回填Evidence Ledger；沒有修改任一原case、也沒有偽造Runner結果。六欄非空率見 `02_FULL_COVERAGE_AND_TRACE.md`，此為可重算的作者端投影。
