#!/usr/bin/env python3
"""Deterministic author-side replay only; never a Protected Checker or Native proof.
Invocation: python R2_STATIC_REPLAY.py
Reads only this sealed candidate's local evidence, Body and historical snapshots.
"""
from __future__ import annotations
from pathlib import Path
import json,hashlib,re,collections,sys,platform
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
BODY=ROOT/'01_SUBSTANTIVE_BODY'
ARCH=ROOT/'02_EVIDENCE_AUDIT_APPENDICES'/'_superseded_2026-10-30_r1'
sha=lambda v:hashlib.sha256(v).hexdigest()
def ld(n):return json.loads((HERE/n).read_text(encoding='utf8'))
results=[]
def test(name,func):
 try: detail=func();results.append({'test':name,'pass':True,'detail':str(detail or 'PASS')})
 except Exception as e: results.append({'test':name,'pass':False,'detail':repr(e)})
def need(ok,msg='ASSERTION'):
 if not ok:raise AssertionError(msg)
def positives():
 dirs=list(BODY.glob('*.md'));sbl=list((BODY/'SBL_DOC00_13_INTEGRATED_READER_UPGRADES').glob('*.md'))
 need(len(dirs)==17 and len(sbl)==14,'DOC_BOOKS_COUNT')
 mapping=ld('R2_CURRENT_SECTION_MAP.json');need(len(mapping)==2221,'ACTIVE_MAP_COUNT')
 need(len({(r['group'],r['id']) for r in mapping})==2221,'ACTIVE_MAP_DUPLICATE')
 need(ld('R2_ACTIVE_READER_GAPS.json')==[],'ACTIVE_MAP_MISSING')
 for b in dirs:
  t=b.read_text(encoding='utf8');need('R2 高保留歷史' in t and '~~~~~~~markdown' in t,'HISTORICAL_NAMESPACE_MISSING:'+b.name)
 for d in sbl:
  t=d.read_text(encoding='utf8');need('~~~~~~~~~~markdown' in t and 'R2 原 Domain' in t,'SBL_DELTA_MISSING:'+d.name)
 return '17 BODY + 14 SBL + 2221 current locators'
def original_sbl():
 count=0
 for i in range(14):
  old=ARCH/f'SBL_DOC00_13_ORIGINAL_FULL_TEXT/SBL_DOC-{i:02d}_ORIGINAL_VERBATIM.md'
  need(old.exists(),f'ORIG_ARCHIVE_{i}')
  count+=len(old.read_text(encoding='utf8').splitlines())
 need(count==75630,'ORIGINAL_75630_NOT_PRESERVED')
 return f'original lines={count}, 14 read in full'
def check_sbl_decomp():
 objs=ld('R2_SBL_COMPOUND_ATOMIZATION.json');need(len(objs)>=1000,'SUBREQ_UNDERCOUNT')
 for o in objs:
  need(o['POS'] and o['NEG'] and o['receiver'] and o['source_text'] and o['first_fail'] and o['polarity'],'SUBREQ_FIELD')
 need(len({x['id'] for x in objs})==len(objs),'SUBREQ_DUP')
 children=ld('BASELINE_children149.json');need(len(children)==149 and len({x['id'] for x in children})==149,'CHILD_149')
 for x in children:
  need(x['positive_behavior'] and x['negative_mutation'] and x['parent_full'],'CHILD_UNBOUND:'+x['id'])
 return f'{len(objs)} proposed subrequirements; 149 source-specific child predicates'
def asset_guard():
 a=ld('R2_ASSET_SETS_PATCHED.json')
 for k,n in [('Native20',20),('Default30',30),('Donor24',24),('Method25',25),('TECH386',386)]:need(len(a[k])==n,k)
 d=ld('R2_69_ORIGINAL_DISPOSITION_BINDINGS.json');need(len(d)==69,'DISPOSITION_COUNT')
 need(all(not x['owner_ack'] for x in d),'FALSE_OWNER_ACK')
 need(all(x['resolution_status']!='SOURCE_LITERAL_AS_DESIGN_CLASS_NOT_OWNER_RATIFICATION' or x['literal_disposition'] for x in d),'SOURCE_DISPOSITION')
 for x in a['Default30']:need('MANDATED' in str(x.get('original_disposition','')) or 'DEFAULT' in str(x.get('original_disposition','')),'MANDATORY_DEMOTED:'+x['id'])
 return '485 assets, 69 decision separation, Default30 preserved'
def cell_guard():
 cells=ld('R2_CELLS192_SEMANTIC_UNBOUND.json');need(len(cells)==192,'CELL_TOTAL')
 need(all(x['host_provider_off_boolean'] is None and x['runtime_effect_allowed'] is False for x in cells),'UNRATIFIED_BOOLEAN')
 cs=ld('R2_CHATGPT_48_MIGRATION_PROPOSALS.json');need(len(cs)==48,'CHATGPT_48')
 need(all(x['historical_host']=='DeepSeek Harness' and x['proposed_host']=='ChatGPT' and x['status']=='MIGRATION_CANDIDATE_NOT_CURRENT_CELL' for x in cs),'HOST_RENAME')
 need(collections.Counter(x['host'] for x in cells)['DeepSeek Harness']==48,'ORIGINAL_HOST_LOSS')
 return '192 raw token preserved; ChatGPT 48 proposals, not renamed'
def runner_guard():
 x=ld('R2_NATIVE_RUNNER_BINDING_REQUESTS_282.json');need(len(x)==282,'CASE_TOTAL')
 need(len({c['case_id'] for c in x})==282,'CASE_DUP')
 need(all(c['runner_entry'] is None and c['execution_status']=='NATIVE_NOT_RUN' and c['required_new_evidence'] for c in x),'MOCK_AS_NATIVE')
 return '282 per-case unbound runner & oracle separate'
def pi_guard():
 import jsonschema
 D=HERE/'R2_OFFLINE_PIPD_CANDIDATES';r=ld('R2_PIPD_OFFLINE_SCHEMA_REPLAY.json');need(len(r)==6,'PIPD_SHAPES')
 for v in r:
  need(v['result']=='HISTORICAL_SCHEMA_SHAPE_PASS','SCHEMA_SHAPE_FAIL:'+v['artifact'])
  name={'PI':'05_PI_PKG_PROPOSAL','PD':'07_PD_UNBOUND_PROPOSAL','DEV_ECP':'09_DEV_ECP_UNISSUED','OPS_ECP':'10_OPS_ECP_UNISSUED','ConstructionContract':'08_CONSTRUCTION_CONTRACT_UNBOUND','PlannedTQAEP':'11_PLANNED_TQAEP_NO_RECEIPT'}[v['artifact']]
  obj=json.loads((D/(name+'.json')).read_text(encoding='utf8'))
  target={'PI':'PI-PKG','PD':'PD-PKG','DEV_ECP':'ECP','OPS_ECP':'ECP','ConstructionContract':'ConstructionContract','PlannedTQAEP':'TQAEP'}[v['artifact']]
  sc=json.loads((D/'historical_schema_snapshots'/(target+'.schema.json')).read_text(encoding='utf8'))
  jsonschema.Draft202012Validator(sc).validate(obj)
 need(json.loads((D/'11_PLANNED_TQAEP_NO_RECEIPT.json').read_text())['acceptance']['checker'] is None,'FAKE_CHECKER')
 return 'six historical S0 schema-shape records, no original Writer ACK'
def denies(reason,entry):
 if reason=='MISSING_GOAL':return bool(entry.get('goal'))
 if reason=='TRAVERSAL':return '..' not in entry.get('source','')
 if reason=='PROVIDER_POLICY':return entry.get('owner_ack_version') is not None and isinstance(entry.get('provider_off'),bool)
 if reason=='PD_SCOPE':return bool(entry.get('root')) and bool(entry.get('scope')) and entry.get('scope')!='**' and '..' not in entry.get('scope','') and entry.get('currentness')=='FRESH'
 if reason=='PERMISSION':return entry.get('token_required') and entry.get('token_issued') and entry.get('rollback_required')
 if reason=='INDEPENDENCE':return bool(entry.get('checker_receipt')) and entry.get('maker','').strip().casefold()!=entry.get('checker','').strip().casefold()
 if reason=='HOST_ALIAS':return entry.get('raw_host')==entry.get('expected_host')
 if reason=='ACTUAL_SERVED':return bool(entry.get('task_response_raw')) and bool(entry.get('actual_served'))
 if reason=='UNKNOWN_EFFECT':return not (entry.get('unknown_effect') and entry.get('retry_without_reconcile'))
 if reason=='AFFECTED_ONLY':return not(entry.get('unrelated_ready') and entry.get('global_stop'))
 if reason=='NO_REASK':return not(entry.get('known_answer') and entry.get('reask'))
 if reason=='CANDIDATE_SHA':return entry.get('subject')==entry.get('receipt_subject') and entry.get('candidate_sha')==entry.get('receipt_candidate_sha')
 if reason=='SOD':return entry.get('maker')!=entry.get('checker')
 if reason=='UNINSTALL_ALLOWLIST':return entry.get('target') in entry.get('manifest_owned',[])
 if reason=='NATIVE_RUNNER':return bool(entry.get('module_sha') and entry.get('raw_schema') and entry.get('checker_credential'))
 return False
NEG_FIXTURES=[('MISSING_GOAL',{'goal':''}),('TRAVERSAL',{'source':'../secret.md'}),('PROVIDER_POLICY',{'owner_ack_version':None,'provider_off':False}),('PD_SCOPE',{'root':'/repo','scope':'**','currentness':'FRESH'}),('PERMISSION',{'token_required':True,'token_issued':False,'rollback_required':True}),('INDEPENDENCE',{'checker_receipt':'SELF_ATTESTED','maker':'maker','checker':' maker '}),('HOST_ALIAS',{'raw_host':'DeepSeek Harness','expected_host':'ChatGPT'}),('ACTUAL_SERVED',{'selected':'gpt','actual_served':None,'task_response_raw':None}),('UNKNOWN_EFFECT',{'unknown_effect':True,'retry_without_reconcile':True}),('AFFECTED_ONLY',{'unrelated_ready':True,'global_stop':True}),('NO_REASK',{'known_answer':True,'reask':True}),('CANDIDATE_SHA',{'subject':'A','receipt_subject':'B','candidate_sha':'abc','receipt_candidate_sha':'abc'}),('SOD',{'maker':'Maker','checker':'Maker'}),('UNINSTALL_ALLOWLIST',{'target':'../../registry','manifest_owned':['own/adapter.json']}),('NATIVE_RUNNER',{'module_sha':None,'raw_schema':'TestRaw','checker_credential':None})]
POS_FIXTURES=[('MISSING_GOAL',{'goal':'produce bound SPEC'}),('TRAVERSAL',{'source':'input/source.md'}),('PROVIDER_POLICY',{'owner_ack_version':'ACK@1','provider_off':True}),('PD_SCOPE',{'root':'/repo','scope':'docs/repaired.md','currentness':'FRESH'}),('PERMISSION',{'token_required':True,'token_issued':True,'rollback_required':True}),('INDEPENDENCE',{'checker_receipt':'REAL_EXTERNAL_CHECKER_RECEIPT_IN_A_TEST_FIXTURE','maker':'A','checker':'B'}),('HOST_ALIAS',{'raw_host':'ChatGPT','expected_host':'ChatGPT'}),('ACTUAL_SERVED',{'actual_served':'model','task_response_raw':'nonempty raw'}),('UNKNOWN_EFFECT',{'unknown_effect':True,'retry_without_reconcile':False}),('AFFECTED_ONLY',{'unrelated_ready':True,'global_stop':False}),('NO_REASK',{'known_answer':True,'reask':False}),('CANDIDATE_SHA',{'subject':'A','receipt_subject':'A','candidate_sha':'abc','receipt_candidate_sha':'abc'}),('SOD',{'maker':'Maker','checker':'checker'}),('UNINSTALL_ALLOWLIST',{'target':'own/adapter.json','manifest_owned':['own/adapter.json']}),('NATIVE_RUNNER',{'module_sha':'test-only','raw_schema':'TestRaw','checker_credential':'test-only'})]
def replay_mutations():
 for name,x in NEG_FIXTURES:need(not denies(name,x),'NEG_FAILED_TO_REJECT:'+name)
 for name,x in POS_FIXTURES:need(denies(name,x),'POS_FAILED_TO_ACCEPT:'+name)
 return '15 negative and 15 positive synthetic gate fixtures (no actual live effect)'
def source_inventory():
 a=ld('R2_FULL_INPUT_SCAN.json');need(len(a)==68,'INPUT_SCAN_COUNT')
 b=ld('R2_CURRENT_LOCAL_SOURCE_INVENTORY.json');need(len(b)>=65,'SOURCE_INVENTORY_COUNT')
 return f'{len(a)} prior package files, {len(b)} locally mounted root sources full-read'
# 13 original denominator sets from previous sources, verify no invented ID removed.
def identity_sets():
 expected={'Native20':20,'Default30':30,'Donor24':24,'Method25':25,'TECH386':386,'R15':949,'Child':149,'Cell':192,'B1Edge':31,'B1Case':282,'ACEdge':15,'Oracle96':96,'WorkPackage':22}
 ids=ld('IDENTITY_SETS.json')
 for g,n in expected.items():need(len(ids[g])==n and len(set(ids[g]))==n,f'IDENTITY_{g}')
 return '2,221 original unique identities, 13 orthogonal groups'
for name,fn in [('BOOKS_AND_ACTIVE_MAPPING',positives),('ORIGINAL_SBL_75630',original_sbl),('SBL_ATOMS_AND_149_CHILDREN',check_sbl_decomp),('TECH_485_AND_69',asset_guard),('CELLS_192_AND_CHATGPT_48',cell_guard),('B1_NATIVE_CASE_282',runner_guard),('PIPD_S0_SHAPES',pi_guard),('POS_NEG_MUTATIONS_30',replay_mutations),('BASELINE_SOURCE_SCAN',source_inventory),('ALL_13_IDENTITY_SETS',identity_sets)]:test(name,fn)
print(json.dumps({'mode':'STATIC_AUTHOR_SIDE_OFFLINE','host':platform.platform(),'python':sys.version.split()[0],'tests':results,'pass':sum(x['pass'] for x in results),'fail':sum(not x['pass'] for x in results),'claim':'NOT_NATIVE_CHECKER'},ensure_ascii=False,indent=2))
sys.exit(0 if all(x['pass'] for x in results) else 1)
