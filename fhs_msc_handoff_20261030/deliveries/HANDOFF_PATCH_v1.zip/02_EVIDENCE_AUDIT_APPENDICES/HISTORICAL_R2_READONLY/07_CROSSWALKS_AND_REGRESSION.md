# 07｜全域雙向 Crosswalk、版本與 Regression

## BODY 17 本輪來源與 r2 受影分節
| 交付本冊 | 2026-10-29 BODY Source | 本輪 2026-10-30 增補 |
|---|---|---|
| `00_INDEX_AND_DECISION.md` | `00_INDEX_AND_DECISION(3).md` (fee2de9aadd6bb57…) | r2 §0 正文適用／來源法位 |
| `01_PRODUCT_AUTHORITY_SPINE.md` | `01_PRODUCT_AUTHORITY_SPINE(3).md` (48d3d533b03fb8de…) | r2 §1 Goal/Kind/Mode/Host、三 SP, 三 SPEC 本輪可交付實作 |
| `02_PIPD_LIFECYCLE_AND_TPM.md` | `02_PIPD_LIFECYCLE_AND_TPM(3).md` (f8d500ef14cb6c83…) | r2 §2 TPM 18 Stage／PIPD 19/13, plugin Stage 原合約與五出口 |
| `03_ARCHITECTURE_ABI_AND_EFFECT.md` | `03_ARCHITECTURE_ABI_AND_EFFECT(3).md` (696083e0db101a2a…) | 四庫 Reader／Effect 接線與原 ABI |
| `04_FABRIC_HGK_CONTROL.md` | `04_FABRIC_HGK_CONTROL(3).md` (e8fd5317b76bffe1…) | r2 §4 真四庫 ABI 與 Native Effect, 原始碼錨點 |
| `05_COMMANDER_GUIDE_AND_NATIVE_PLAN.md` | `05_COM~1.MD` (c8c706e9726888ca…) | r2 §1.3 角色與 Guide 入口 |
| `06_FHS_EXECUTE_HERMES_RUNTIME.md` | `06_FHS_EXECUTE_HERMES_RUNTIME(3).md` (d457b7b0ebd303ae…) | r2 §4.3/4.4 SharedSpine與W18 |
| `07_ACCEPTANCE_CHALLENGE.md` | `07_ACCEPTANCE_CHALLENGE(3).md` (5037c52d8bf6d0f2…) | r2 §8 AC15／96 Oracle 真 Consumer |
| `08_TECHNOLOGY_DEFAULT_HOTSWAP.md` | `08_TECHNOLOGY_DEFAULT_HOTSWAP(3).md` (29e1be9a0c602831…) | r2 §3 Need→Occupant／Load, r2 §5 五個正交集合 485 原身份 |
| `09_SBL_DOC00_13_FULL_UPGRADE.md` | `09_SBL_DOC00_13_FULL_UPGRADE(3).md` (a010b53b26eb5c90…) | 14冊 SBL 原意與逐DOC原條款／Consumer, r2 §1.4 15 TDR與原Kind經驗 |
| `09A_R15_949_ORIGINAL_ATOMS.md` | `09A_R15_949_ORIGINAL_ATOMS(3).md` (198bdcf7c301b1e9…) | r2 §6 全量 949 R15原子 |
| `09B_KIND_MODE_HOST_192.md` | `09B_KIND_MODE_HOST_192(3).md` (2c38c8e20858570c…) | r2 §7 全量192 個Kind×Mode×Host×Provider |
| `10_B1_W18_SELF_BOOTSTRAP.md` | `10_B1_W18_SELF_BOOTSTRAP(3).md` (a99a00d3a8bc5493…) | r2 §4.4 W18常態模式 |
| `10A_B1_TQAEP_120_124_38.md` | `10A_B1_TQAEP_120_124_38(3).md` (dba3759dd32043fd…) | r2 §10.2–10.x Case/Node真 Runner |
| `10B_B1_PI27_PD31.md` | `10B_B1_PI27_PD31(3).md` (9b2f863ff0b0242b…) | r2 §10.1 B1 27→31 Edge |
| `11_WORKPACKAGES_AND_DAG.md` | `11_WORKPACKAGES_AND_DAG(3).md` (0f0c226986b5bc57…) | r2 §9 22 WP typed DAG完整施工契約 |
| `12_VERIFICATION_AND_DELIVERY.md` | `12_VERIFICATION_AND_DELIVERY(3).md` (91835bc51e1767fe…) | r2 §11 身份回歸/四庫施工, r2 §12操作例/§13退出 |

## SBL 原14冊到 FHS integrated Reader 的逐冊來源範圍
| 原 DOC | 原SHA256 | 本輪原功能節選範圍 |
|---|---|---|
| DOC-00 | `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01` | L53–69 ## R00.r3.1｜五分鐘產品操作契約與七痛點→實體成果 |
| DOC-00 | `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01` | L70–80 ## C02.r3.base.1｜五權威域並列，不因較新時間跨 Owner 奪權 |
| DOC-01 | `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f` | L22–57 ## 產品讀者五分鐘 Quickview（當前設計正文入口） |
| DOC-02 | `4ff0cda5ab00ba5f577151e5b004d2167d933e912e302c9e3529b237ccb9e035` | L88–89 ## r1 可核回保留之 RoleActivationMatrix／Authority Graph（以 r2 上段為準） |
| DOC-02 | `4ff0cda5ab00ba5f577151e5b004d2167d933e912e302c9e3529b237ccb9e035` | L124–134 ## 六步可重現來源掃描與分母／失敗狀態 |
| DOC-03 | `ea69e1d3718ed86aecd74a3ebcc933960eacc30b586ab80fcb9f733037e33476` | L952–996 ## C18.2｜SBLAtom → P4 CanonicalAtom 無損 Adapter；不得直接送 Native |
| DOC-04 | `ee90cb1c86f6f7350c11c9c962233a89b035ca41ff82c8968f7968608fc6f6e0` | L292–302 ## C12.2 修補後六個 Flow Modules（各有輸入、輸出、Owner、Consumer、FirstFail） |
| DOC-04 | `ee90cb1c86f6f7350c11c9c962233a89b035ca41ff82c8968f7968608fc6f6e0` | L210–254 ## R04｜跨域 Typed ABI、HashLineage、Envelope、ACK/NACK 與安全資料流 |
| DOC-05 | `3b47a0b6224b1984a4047cf53aac5ac50615c93a560fea46e1b43d079a5d9f27` | L53–70 ## R00.2 入口、前提、出入口與 FirstFail |
| DOC-05 | `3b47a0b6224b1984a4047cf53aac5ac50615c93a560fea46e1b43d079a5d9f27` | L139–165 ## R01.3 P4 Skill 安裝可讀狀態、順序與 Owner |
| DOC-06 | `64ea4977dab3093301f82dc7469413cc754998fc53946467842e06d83645102b` | L174–218 ## C32.3｜24/24 Slot：互異 Trigger／非觸發／准許效果／輸出／撤銷；一槽一個來源原子 |
| DOC-06 | `64ea4977dab3093301f82dc7469413cc754998fc53946467842e06d83645102b` | L294–338 ## C33.2｜386/386 逐筆原身份保全＋差異化功能 Consumer／正負驗收／退出 |
| DOC-07 | `a366d3783c82089c5593ffabb0704d8507632cce45622684f7a0186f2ae310f8` | L162–179 ## C11.2｜PREW3_SHADOW：Frozen W2 Readset、NoEffect 與相容性 |
| DOC-07 | `a366d3783c82089c5593ffabb0704d8507632cce45622684f7a0186f2ae310f8` | L525–540 ## C27.3｜CredentialTokenScopeContract 與 Capability Broker |
| DOC-08 | `c7029c1ff07abe3135d33d3abf858a5fecedd911b494cd69c16eb1ddb8158288` | L194–223 ## C22.3｜EligibilityResolver 可執行決策，非「default ALLOW」 |
| DOC-08 | `c7029c1ff07abe3135d33d3abf858a5fecedd911b494cd69c16eb1ddb8158288` | L224–235 ## C22.4｜三條 Golden Journeys：可觀察 Before→After、Host/Installer Discovery 與破壞性 NEG |
| DOC-09 | `6450f7c15915ec8b304f4e5fd4093ea707434db8bae9d2bb6e66c30ab6eed2e1` | L84–90 ## R09-01.6｜九步 SOP 實質操作閉包與複合需求分解 |
| DOC-10 | `a64aa21c977334dd74d660a86377ee10c4d329aa5fde0dae25ff81a3e69e8d8f` | L95–132 ## 1.5｜GatePrecedenceRegistry v1（全冊唯一生效的 FirstFail 演算法） |
| DOC-10 | `a64aa21c977334dd74d660a86377ee10c4d329aa5fde0dae25ff81a3e69e8d8f` | L57–68 ## 1.1 三 Mode、三工作面與效果的明確判定序 |
| DOC-11 | `12f8705d780b76f264457c194a6ff359da8d74b5d6d8c83fa245b74d2a37508e` | L42–61 ## 動態專家路由（邏輯職能，非多人簽署） |
| DOC-11 | `12f8705d780b76f264457c194a6ff359da8d74b5d6d8c83fa245b74d2a37508e` | L16–19 ## r2 產品/技術設計修補總則 |
| DOC-12 | `d1e470d82ca14319582cb8947aa52007927aa38e726249b1430804cfe8c8ca56` | L39–83 ## D12-01.PATCH｜七痛點、十六 User Moments、三 Golden Journeys 的 Consumer-first 設計實體 |
| DOC-12 | `d1e470d82ca14319582cb8947aa52007927aa38e726249b1430804cfe8c8ca56` | L107–123 ## D12-01.3｜'PrimaryProductKind' 與 'DeliveryArtifactKind' 正交，Owner 先算 Applicabil |
| DOC-13 | `7cc0c8b17311130c875910b2548b93c28bd4e1c8ee04d300f85fc33d4c09beb1` | L572–576 ## C46.11｜對 C45/C47 的完整退出與 requalification 消費回路 |

## PIPD 原 10 冊/五出口讀取位置
| 出口/原Writer | 本輪設計 Reader | 不得偷越 |
|---|---|---|
| PI-PKG / PIPD DOC-02 | BODY-02, BODY-10B | 無原 compiler ACK 不宣稱 PI 正式 |
| PD-PKG / PIPD DOC-03 | BODY-02, BODY-03, BODY-10B | 無 local true RepoContext 不 late-bind |
| DEV ECP / 原 PIPD/ECP Writer | BODY-03, BODY-10B | 不共用 OPS grant |
| OPS ECP / 原 PIPD/HGK Issuer | BODY-04, BODY-06, BODY-10B | Host/Repo/Remote/User/Release 各自 Effect scope |
| Planned TQAEP / PIPD DOC-07 | BODY-07, BODY-10A | 計畫不等於真 Protected Checker |

## 主要回歸測例
- 949 R15 +149 SBL Child 的 original_positive/negative 不改極性；`SBL` ≠ `SWOF` 品牌／Owner。
- 192 Cells 原 `ON/OFF` raw token 保留；ProviderOff boolean 映射未 ratify 前不過關。
- Native20/Default30/Donor24/Method25/TECH386 五集合物理身份分開；不得合併成 install count。
- B1 27 PI/31 PD/282 Case+Node、W18 10 Test 以各自的第一失敗及 fresh PID 接收，無真 Reader 即 NOT_RUN。
- 22 WP typed DAG 無循環，WP17 不需 WP06 effect 才能開始 qualified install；SourceRead 不被 permit 擋。
- 正文版別同版只有一套；本冊 r2 受影文本在前，保留歷史 BODY 的未受影源意於後，不把並置當兩套 Canonical。


## 14個跨域Reader升級交付（附加於17主正文之外）

- `SBL DOC-00` → `01_SUBSTANTIVE_BODY/SBL_DOC00_13_INTEGRATED_READER_UPGRADES/SBL_PIPD-LS-PKG_DOC-00_FHS_INTEGRATED_UPGRADE.md`；468,106 bytes；SHA256=`bf177f018775fe2817fa740ea65125ec3e94bc57616fb787113f96ccd12b94e9`；保留原全文＋本輪Domain修補；非原Canonical Writer。
- `SBL DOC-01` → `01_SUBSTANTIVE_BODY/SBL_DOC00_13_INTEGRATED_READER_UPGRADES/SBL_PIPD-LS-PKG_DOC-01_FHS_INTEGRATED_UPGRADE.md`；1,044,734 bytes；SHA256=`68b92839fafffe61c29a5c2a128b115e4b0122613293cdc94728ab913b1766c4`；保留原全文＋本輪Domain修補；非原Canonical Writer。
- `SBL DOC-02` → `01_SUBSTANTIVE_BODY/SBL_DOC00_13_INTEGRATED_READER_UPGRADES/SBL_PIPD-LS-PKG_DOC-02_FHS_INTEGRATED_UPGRADE.md`；1,150,966 bytes；SHA256=`1e15ec7557babbb37e927b19a4c6f0b6964a0014462df861c9fc3bec8dba8e4f`；保留原全文＋本輪Domain修補；非原Canonical Writer。
- `SBL DOC-03` → `01_SUBSTANTIVE_BODY/SBL_DOC00_13_INTEGRATED_READER_UPGRADES/SBL_PIPD-LS-PKG_DOC-03_FHS_INTEGRATED_UPGRADE.md`；1,707,023 bytes；SHA256=`17f6d4c106cd99b66c4bf432dde7e70180a46f79b660cf9c414e4a7b267ac9cb`；保留原全文＋本輪Domain修補；非原Canonical Writer。
- `SBL DOC-04` → `01_SUBSTANTIVE_BODY/SBL_DOC00_13_INTEGRATED_READER_UPGRADES/SBL_PIPD-LS-PKG_DOC-04_FHS_INTEGRATED_UPGRADE.md`；620,890 bytes；SHA256=`87ae8700f2485ed52ee96357149ba2a19c9dc46bf427695b16c7cf91ab9057af`；保留原全文＋本輪Domain修補；非原Canonical Writer。
- `SBL DOC-05` → `01_SUBSTANTIVE_BODY/SBL_DOC00_13_INTEGRATED_READER_UPGRADES/SBL_PIPD-LS-PKG_DOC-05_FHS_INTEGRATED_UPGRADE.md`；2,385,099 bytes；SHA256=`89c4cbf1efc92dd7374162ff1a8c7b98a5cb04b9d17cd8c71e865dad1866a424`；保留原全文＋本輪Domain修補；非原Canonical Writer。
- `SBL DOC-06` → `01_SUBSTANTIVE_BODY/SBL_DOC00_13_INTEGRATED_READER_UPGRADES/SBL_PIPD-LS-PKG_DOC-06_FHS_INTEGRATED_UPGRADE.md`；1,557,631 bytes；SHA256=`2dc653a34b29fea4b7c10c01c7ce1b0d972a7ca565b36f17e16c883b1df36f21`；保留原全文＋本輪Domain修補；非原Canonical Writer。
- `SBL DOC-07` → `01_SUBSTANTIVE_BODY/SBL_DOC00_13_INTEGRATED_READER_UPGRADES/SBL_PIPD-LS-PKG_DOC-07_FHS_INTEGRATED_UPGRADE.md`；1,267,853 bytes；SHA256=`6607af1ae88cc15a3a0b8495b42b7fc71492dcae6f2c2b868188589d9e7e450f`；保留原全文＋本輪Domain修補；非原Canonical Writer。
- `SBL DOC-08` → `01_SUBSTANTIVE_BODY/SBL_DOC00_13_INTEGRATED_READER_UPGRADES/SBL_PIPD-LS-PKG_DOC-08_FHS_INTEGRATED_UPGRADE.md`；928,274 bytes；SHA256=`9a4e0a770b6872f662869a8cb3c52c2af81f656b32638409c6e158e32b8082de`；保留原全文＋本輪Domain修補；非原Canonical Writer。
- `SBL DOC-09` → `01_SUBSTANTIVE_BODY/SBL_DOC00_13_INTEGRATED_READER_UPGRADES/SBL_PIPD-LS-PKG_DOC-09_FHS_INTEGRATED_UPGRADE.md`；907,312 bytes；SHA256=`022cbf99588c0fe5ec04b86deca251f3d1e582694ad9320ccbf3e588fc666473`；保留原全文＋本輪Domain修補；非原Canonical Writer。
- `SBL DOC-10` → `01_SUBSTANTIVE_BODY/SBL_DOC00_13_INTEGRATED_READER_UPGRADES/SBL_PIPD-LS-PKG_DOC-10_FHS_INTEGRATED_UPGRADE.md`；1,400,680 bytes；SHA256=`abfbaa602c8c1979d7ad09916573fbb7b05ac5b60349568e824db90cbc28b5d0`；保留原全文＋本輪Domain修補；非原Canonical Writer。
- `SBL DOC-11` → `01_SUBSTANTIVE_BODY/SBL_DOC00_13_INTEGRATED_READER_UPGRADES/SBL_PIPD-LS-PKG_DOC-11_FHS_INTEGRATED_UPGRADE.md`；1,833,877 bytes；SHA256=`7572c46cf2a0f3670afe2cd289b5bdf080c61f964cb212c9cf82ce250ead1a53`；保留原全文＋本輪Domain修補；非原Canonical Writer。
- `SBL DOC-12` → `01_SUBSTANTIVE_BODY/SBL_DOC00_13_INTEGRATED_READER_UPGRADES/SBL_PIPD-LS-PKG_DOC-12_FHS_INTEGRATED_UPGRADE.md`；985,685 bytes；SHA256=`d1c661e480203e0099c4af9421b33a2e5edfb6bcfc70b2a10c539bfbfc1f9942`；保留原全文＋本輪Domain修補；非原Canonical Writer。
- `SBL DOC-13` → `01_SUBSTANTIVE_BODY/SBL_DOC00_13_INTEGRATED_READER_UPGRADES/SBL_PIPD-LS-PKG_DOC-13_FHS_INTEGRATED_UPGRADE.md`；1,253,826 bytes；SHA256=`c830cfba3a94a99ba3513ca15601c18850099eaeae936c3843289fb0f1e94f05`；保留原全文＋本輪Domain修補；非原Canonical Writer。
