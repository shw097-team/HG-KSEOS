# 03｜外部工具研究、採納與 HotSwap（SUPPORT，不是權威）

**檢索日期**：2026-10-30；主來源 GitHub Release API/官方更新。只對已決 Need 做當期深查，485 原身份個別處置仍由 BODY-08 與下面 SOURCE ledger 保留。不因外部 release 較新就自動變更任何 native occupant。

| 技術 | upstream/版別 | 日期 | 採納候選 | 可觀測差額 | 官方來源 |
|---|---|---|---|---|---|
| OpenSpec | Fission-AI/OpenSpec/v1.15.0 | 2026-10-24T00:50:05Z | USE_AS_METHOD_CANDIDATE; pin release and host/license before install | standalone + update --dry-run; does not issue HGK permits | https://github.com/Fission-AI/OpenSpec/releases/tag/v1.15.0 |
| Superpowers | obra/superpowers/v7.0.1 | 2026-10-21T21:05:11Z | READ_METHOD_OR_TRANSLATE_SKILL | brainstorming read context before questions; does not replace TPM Writer | https://github.com/obra/superpowers/releases/tag/v7.0.1 |
| Spec Kit | github/spec-kit/v1.2.5 | 2026-10-28T19:27:43Z | REUSE_OR_METHOD_BY_NEED | specify CLI and extensions, only in authorized source/host | https://github.com/github/spec-kit/releases/tag/v1.2.5 |
| gstack | garrytan/gstack/v1.91.318.0 | 2026-10-29T14:06:50Z | METHOD_OR_REUSE; NO_AUTO_INSTALL | regular release, stable channel readback; automation must not claim Host loaded | https://github.com/garrytan/gstack/releases/tag/v1.91.318.0 |
| CodeQL | github/codeql-action/v4.39.1 | 2026-10-21 | REUSE_EXISTING_CI_ONLY | security scanning is not independent native checker | https://github.com/github/codeql-action/blob/main/CHANGELOG.md |
| FAR | ORIGINAL_FHS_TECH_ID_NOT_RESOLVED/RESEARCH_UNVERIFIED | 2026-10-30 | DEFER_UNTIL_OWNER_PIN | FAR name is ambiguous; must bind original identity and upstream/license before use | N/A |

## 每個原具名資產的守恆採用原則
- 原資產全部保留 original_identity、disposition、Owner/Consumer；原 Default30 即便未 qualified，product_decision 仍 `MANDATED_DEFAULT`，效果只按 Need 停在 `ACTIVATION_HOLD`。
- 技術採用機 `Need → original CapabilityPlan → selected Qualified Occupant → Host EffectiveLoad → actual Consumer`；直接復用優先於翻譯 Skill，其次讀方法/有界建置，Reject/Defer 不安裝。
- 必須逐 Host 驗 upstream + commit/version + license + SHA pin + install/loader/trigger/nontrigger/uninstall + same-version POS/NEG parity + rollback，再提出 HotSwap Owner 決策。
- Repo 已有自有類似能力者先用原 Host qualified capability，不以泛用網路套件取代 Fabric/HGK 等唯一法位。

## 原始五集合未有完成安裝的逐筆狀態
| 集合 | 原ID數 | 作者側領域決策來源 | 安裝／載入／呼叫證據 |
|---|---:|---|---|
| Native20 | 20 | BODY-08 + 原 SBL DOC-06 | 本輪 Windows INSTALLED/LOADED/INVOKED/VERIFIED 未取證 |
| Default30 | 30 | BODY-08 + 原 SBL DOC-06 | 本輪 Windows INSTALLED/LOADED/INVOKED/VERIFIED 未取證 |
| Donor24 | 24 | BODY-08 + 原 SBL DOC-06 | 本輪 Windows INSTALLED/LOADED/INVOKED/VERIFIED 未取證 |
| Method25 | 25 | BODY-08 + 原 SBL DOC-06 | 本輪 Windows INSTALLED/LOADED/INVOKED/VERIFIED 未取證 |
| TECH386 | 386 | BODY-08 + 原 SBL DOC-06 | 本輪 Windows INSTALLED/LOADED/INVOKED/VERIFIED 未取證 |

### 具名 URL 重查線索
- https://openai.com/index/practical-guide-building-gpt-6/ （2026-10-02；模型部署/agent instructions SUPPORT）
- https://developers.openai.com/api/docs/guides/latest-model （當期開發者指南）
- https://github.com/Fission-AI/OpenSpec/releases
- https://github.com/obra/superpowers/releases
- https://github.com/github/spec-kit/releases
- https://github.com/garrytan/gstack/releases
- https://github.com/github/codeql-action/blob/main/CHANGELOG.md

## R2 受影選型研究更新（2026-10-30）

- **OpenSpec**：v1.15.0（2026-10-24）／原 URL `https://github.com/Fission-AI/OpenSpec/releases/tag/v1.15.0`；MethodDecision=`SELECTIVE_REUSE`；Hermes Project Skills/CLI: change delta/validate; check warning as error where policy requires。真 License/PIN/Host/Install/Invoke=PENDING_LICENSE_PIN_INSTALL_CHECK，不假 Installed。
- **Superpowers**：v7.0.1（2026-10-21）／原 URL `https://github.com/obra/superpowers/releases/tag/v7.0.1`；MethodDecision=`METHOD_REUSE`；bounded debug/TDD/negative fixtures, no separate Checker authority。真 License/PIN/Host/Install/Invoke=PENDING_LICENSE_PIN_INSTALL_CHECK，不假 Installed。
- **Spec Kit**：v1.2.5（2026-10-28）／原 URL `https://github.com/github/spec-kit/releases/tag/v1.2.5`；MethodDecision=`OPTIONAL_GREENFIELD`；only selected greenfield Need, not a second PIPD Canonical。真 License/PIN/Host/Install/Invoke=PENDING_LICENSE_PIN_INSTALL_CHECK，不假 Installed。
- **gstack**：v1.91.318.0（2026-10-29）／原 URL `https://github.com/garrytan/gstack/releases/tag/v1.91.318.0`；MethodDecision=`REVIEW_METHOD_ONLY`；No automatic /ship permit; host adapter/rollback pending。真 License/PIN/Host/Install/Invoke=PENDING_LICENSE_PIN_INSTALL_CHECK，不假 Installed。
- **FAR**：SOURCE_UNBOUND（N/A）／原 URL `https://github.com/shw097-team/Fabric`；MethodDecision=`REFERENCE_METHOD_ONLY`；Native FABRIC same owner, not a plugin duplicate。真 License/PIN/Host/Install/Invoke=CURRENT_NATIVE_ABI_UNBOUND，不假 Installed。

R2 的 485 原 ID 沒有 485 次重複安裝；由 Need/Host 原適用集合共用單一已合格 occupant，原 Default30 仍是必備產品義務。Source website 是 SUPPORT，不是原 Owner 批准。
