# Repo／Host 差額

本地 HG-KSEOS/SBL/Fabric/PIPD-worktree 的真實 Git 狀態與另一個 PIPD-LS-SP checkout 分別存於 `STATIC_REPAIR_v1/*_repo_readback.json`，包括 HEAD、index、staged、unstaged、全部 untracked path；沒有 reset/clean/checkout/fetch/push。遠端 main 只讀 shallow snapshot，不寫遠端。工作樹未提交內容沒有套用修補。

PIPD primary workspace CLI=14，remote main=13；完整命令集合與 source SHA 見 [版本表](STATIC_REPAIR_v1/PIPD_CLI_VERSIONED_EXACT_SETS.json)。原 workspace 既有 exact13 測試失敗保留。四庫正式 Host Loaded、Fabric active-consumed、HGK Permit、Hermes WorkID/lease/world effect、different-principal Checker、Publisher Receipt 均未在本輪執行；保持 NATIVE_NOT_RUN / CHECKER_NOT_RUN / RELEASE_NOT_RUN。

TPM plugin 24 DOC physical integrity PASS；SELECTED/LOCAL_PACKAGE_PRESENT/BOUND_TO_THIS_DRAFT/PYTHON_ADAPTER_INVOKED 與 HOST_PENDING 分列。包裝或 adapter 函數執行不能表示 Host 真載入。`SETUP` role 在該插件 StageContracts 中不存在，已記差額而不發假 Stage ACK。
