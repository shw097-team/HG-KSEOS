# 原測試、Schema、DAG／NEG 與 QA Raw

所有測試限作者端靜態。原 R2 replay 10/10、Revision2 原 validate 2788 PASS/1 FAIL（source path readback），原始失敗不抹；路徑搬移可用 exact SHA 重綁，不等於文字被改。另一個本地 PIPD 副本在 UTF8/Git fixture 正確設定後，108項原測試 PASS。Agent_Workspace 版本71項原可用測試有1 FAIL（CLI預期13、實際14）；前次缺測試模組與環境失敗的 raw 亦保留。

命令、cwd、Python、exit、elapsed、stdout/stderr SHA 見 `STATIC_REPAIR_v1/*.receipt.json`；原 stdout/stderr 在同目錄。兩個原 Compiler 均對全17冊 intake NACK；22 WP 的44條有限身份／拒收投影成功，原 Schema/semantic validator ACK 保存，不能冒全產品 PI。無 checker receipt 的 TQAEP 正確拒收；原插件 PlannedTQAEP schema/readback PASS 只代表計畫。

22 WP 原依賴圖以插件 `affected_work` 重算無環，CAP-BOOT 在首 effect 前。當期 effect/authority 欄逐卡明列；WriteSet 只在隔離文稿為有限輸出，Native 卡使用原 Owner/Receiver 的具名晚綁程序。Final global regression 重查原身份、locators、UTF8、連結、source hash、schema、DAG 及原 negative 守恆，結果單獨列狀態，不蓋過語義作者缺陷。
