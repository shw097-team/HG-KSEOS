# 本輪 SourceManifest／Authority／版本差異

本輪完整 byte decode 的本地來源文字檔：979；總 bytes：672,333,887。全文關鍵字／原 ID 掃描命令及 raw 已保存。逐來源真實 path、SHA、line、heading、Writer/Reader、supersession 見 [完整來源表](STATIC_REPAIR_v1/SourceManifest_ALL_LOCAL.json)。這是 bytes 及索引掃描，不能當全語義驗收。

四個遠端 main 已依使用者指定憑證唯讀取得完整當期檔案樹並逐 blob 讀取，共 6,464 檔；無 submodule/LFS 指標。四份 `*_remote_full_read.json` 保存每檔 SHA/大小/UTF-8 狀態；深度1只代表當期 main，未宣稱讀取全部 commit history。憑證未存入候選、ZIP 或日誌。

五個本地工作樹（含兩個不同 PIPD root）與四個遠端 main 分別核對：[逐檔差異](STATIC_REPAIR_v1/LOCAL_REMOTE_ALL_FILE_DIFFERENCES.json)、[本地 byte manifest](STATIC_REPAIR_v1/LOCAL_TRACKED_FULL_READ_MANIFEST.json)、[精確差額](STATIC_REPAIR_v1/LOCAL_READ_EXACT_GAPS.json)。本地 untracked 的全部 path/status 已保存；其下未全部逐 byte 讀取，不冒稱完整語義分母。原 Gitlink fixture 子樹與個別敏感檔名差額按表列出，不擴 scope 追入其他庫。

1694 個結構化來源座標已逐個重算 file SHA/line slice SHA，0 file mismatch、0 clause mismatch。這些多為設計中間來源，不能替代更上位 Domain 規範。舊 Revision2 manifest 的實體路徑用相同 SHA 重綁，[重綁結果](STATIC_REPAIR_v1/SOURCE_PATH_REBIND_BY_EXACT_SHA.json) 明列搬移與仍缺來源。原 Writer／Owner／Policy／ABI 各自生效；討論、歷史 Prompt、Source data 不取得本輪指令權。

已使用 [sbl-tpm-sp](STATIC_REPAIR_v1/TPM_PLUGIN_USE_RECEIPT.json)；插件內建 SBL14/PIPD10 由原 `corpus_manifest/read_clause` 驗 SHA。原 Plugin HOST_PENDING 不藉 Python adapter 呼叫提高。
