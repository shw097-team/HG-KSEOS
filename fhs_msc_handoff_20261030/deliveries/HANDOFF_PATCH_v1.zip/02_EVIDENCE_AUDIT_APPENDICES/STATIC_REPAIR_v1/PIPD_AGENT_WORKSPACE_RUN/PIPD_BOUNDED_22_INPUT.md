WP-FHS-00 must preserve its exact source identity.
WP-FHS-00 must reject WP-FHS-00.FIRST_FAIL:ROOT_CURRENTNESS_NOT_PROVEN.
WP-FHS-01 must preserve its exact source identity.
WP-FHS-01 must reject WP-FHS-01.FIRST_FAIL:PROFILE_OR_ORACLE_BIND_HOLD.
WP-FHS-02 must preserve its exact source identity.
WP-FHS-02 must reject WP-FHS-02.FIRST_FAIL:POLICY_NOT_LOADED.
WP-FHS-03 must preserve its exact source identity.
WP-FHS-03 must reject WP-FHS-03.FIRST_FAIL:ISSUER_BINDING_INVALID.
WP-FHS-04 must preserve its exact source identity.
WP-FHS-04 must reject WP-FHS-04.FIRST_FAIL:RUNTIME_LEASE_BINDING_DENY.
WP-FHS-05 must preserve its exact source identity.
WP-FHS-05 must reject WP-FHS-05.FIRST_FAIL:PIPD_FORMAL_PROMOTION_HOLD.
WP-FHS-06 must preserve its exact source identity.
WP-FHS-06 must reject WP-FHS-06.FIRST_FAIL:FIRST_EFFECT_CAPABILITY_MISSING.
WP-FHS-07 must preserve its exact source identity.
WP-FHS-07 must reject WP-FHS-07.FIRST_FAIL:COMMANDER_BOOTSTRAP_INVERSION.
WP-FHS-08 must preserve its exact source identity.
WP-FHS-08 must reject WP-FHS-08.FIRST_FAIL:EFFECT_REPLAY_DENY.
WP-FHS-09 must preserve its exact source identity.
WP-FHS-09 must reject WP-FHS-09.FIRST_FAIL:SELF_ACCEPTANCE_DENY.
WP-FHS-10 must preserve its exact source identity.
WP-FHS-10 must reject WP-FHS-10.FIRST_FAIL:GWO_EVIDENCE_JOIN_INCOMPLETE.
WP-FHS-11 must preserve its exact source identity.
WP-FHS-11 must reject WP-FHS-11.FIRST_FAIL:HOST_SP_MATRIX_INCOMPLETE.
WP-FHS-12 must preserve its exact source identity.
WP-FHS-12 must reject WP-FHS-12.FIRST_FAIL:NORMAL_MODE_NOT_QUALIFIED.
WP-FHS-13 must preserve its exact source identity.
WP-FHS-13 must reject WP-FHS-13.FIRST_FAIL:CAPABILITY_PARITY_NOT_PROVEN.
WP-FHS-14 must preserve its exact source identity.
WP-FHS-14 must reject WP-FHS-14.FIRST_FAIL:RELEASE_NOT_AUTHORIZED.
WP-FHS-15 must preserve its exact source identity.
WP-FHS-15 must reject WP-FHS-15.FIRST_FAIL:TPM_SOURCE_STAGE_GUARD.
WP-FHS-16 must preserve its exact source identity.
WP-FHS-16 must reject WP-FHS-16.FIRST_FAIL:DONOR_METHOD_DISPOSITION_DENY.
WP-FHS-17 must preserve its exact source identity.
WP-FHS-17 must reject WP-FHS-17.FIRST_FAIL:CAP_BOOT_DEPENDENCY_INVERSION.
WP-FHS-18 must preserve its exact source identity.
WP-FHS-18 must reject WP-FHS-18.FIRST_FAIL:REPAIR_SCOPE_DENY.
WP-FHS-19 must preserve its exact source identity.
WP-FHS-19 must reject WP-FHS-19.FIRST_FAIL:SUPPLY_CHAIN_EVIDENCE_MISSING.
WP-FHS-20 must preserve its exact source identity.
WP-FHS-20 must reject WP-FHS-20.FIRST_FAIL:HOST_CELL_EVIDENCE_FOREIGN.
WP-FHS-21 must preserve its exact source identity.
WP-FHS-21 must reject WP-FHS-21.FIRST_FAIL:ORACLE_CELL_NOT_PROVEN.
