from discover import *
from probe_repos import M,REPOS
from prepare_validation import execute
import sys
def main():
 root=Path(REPOS['PIPD-worktree']);snap=WORK/'pipd_workspace_snapshot';d=json.loads((M/'PIPD-worktree_repo_readback.json').read_text(encoding='utf-8'));records=[]
 for line in d['index']['stdout'].splitlines():
  if '\t' not in line:continue
  rel=line.split('\t',1)[1]
  if not (rel.startswith(('src/','schemas/','tests/','tools/','docs/','fixtures/','examples/','skills/')) or rel in ['pyproject.toml','README.md','LICENSE','OWNER_LICENSE_DECISION.yaml']):continue
  p=root/rel
  if not p.is_file():continue
  b=p.read_bytes();dest=snap/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b);records.append({'path':str(p),'sha256':sha(b),'relative':rel})
 dump(M/'PIPD_AGENT_WORKSPACE_SOURCE_SNAPSHOT.json',records)
 for file in ['pipeline.py','requirements.py','validate.py']:
  a=(root/'src/pipd_ls_sp'/file).read_bytes();b=(Path(REPOS['PIPD-LS-SP'])/'src/pipd_ls_sp'/file).read_bytes()
  print(file,'workspace_sha',sha(a),'public_local_sha',sha(b),'same',a==b)
 execute('PIPD_AGENT_WORKSPACE_EXISTING_TESTS',[sys.executable,'-X','utf8','-B','-m','unittest','tests.test_atomic_requirements','tests.test_negative_and_rollback','tests.test_s4r2_affected_only','tests.test_ce_repair_regression','tests.test_claim_ceiling_shape','tests.test_tqaep_design_positive','tests.test_s0_contracts','tests.test_s1_lite_slice','-v'],cwd=snap,extra_env={'PYTHONPATH':str(snap.resolve()/'src'),'PYTHONUTF8':'1','TEMP':str((WORK/'test_tmp_utf8').resolve()),'TMP':str((WORK/'test_tmp_utf8').resolve())})
if __name__=='__main__':main()
