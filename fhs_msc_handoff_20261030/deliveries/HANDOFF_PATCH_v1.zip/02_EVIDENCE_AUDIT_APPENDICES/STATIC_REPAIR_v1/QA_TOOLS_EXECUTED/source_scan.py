from discover import *
from probe_repos import M,REPOS
from prepare_validation import execute
from collections import Counter
def localpath(s):
 s=str(s).removeprefix('\\\\?\\')
 return Path('\\\\?\\'+s) if re.match(r'^[A-Za-z]:',s) else Path(s)
def main():
 inv=json.loads((WORK/'source_inventory.json').read_text(encoding='utf-8'))
 for row in inv:
  rel=row['relative'];row['path']=row['path'].removeprefix('\\\\?\\')
  row['authority_basis']='ORIGINAL_DOMAIN_WRITER_REQUIRED; date is not supersession'
  row['writer']='PIPD' if 'PIPD_LS_DOC-' in rel else 'SBL' if 'SBL_PIPD-LS-PKG_DOC-' in rel else 'FHS design author'
  row['reader']='Original domain Reader; FHS source-bound repair projection'
  row['supersession']='HISTORICAL_SUPPORT' if any(x in rel for x in ['\\OLD\\','_superseded','討論']) else 'SOURCE_OBSERVED_NOT_RATIFIED'
 dump(M/'SourceManifest_ALL_LOCAL.json',inv)
 ids=json.loads((OUT/'02_EVIDENCE_AUDIT_APPENDICES/_machine/IDENTITY_SETS.json').read_text(encoding='utf-8'))
 assets=json.loads((OUT/'02_EVIDENCE_AUDIT_APPENDICES/_machine/R2_ASSET_SETS_PATCHED.json').read_text(encoding='utf-8'))
 words=sorted(set([x for vs in ids.values() for x in vs]+[a['name'] for vs in assets.values() for a in vs]+['各有','分別','對應','每個','均須','且','PROPOSED','CANDIDATE','UNBOUND','HOLD','provider_off','DeepSeek Harness','Native20','Default30','Donor24','Method25','TECH386']))
 pat=WORK/'ALL_KEYWORDS_AND_ORIGINAL_IDS.txt';pat.write_text('\n'.join(words),encoding='utf-8')
 execute('FULL_CORPUS_KEYWORD_COUNT',['rg','--count-matches','--hidden','-F','-f',str(pat.resolve()),'-g','*.md','-g','*.json','-g','*.yaml','-g','*.py',str(ROOT).removeprefix('\\\\?\\')])
 # Re-read every structured source coordinate, not a representative sample.
 rawcache={};results=[]
 def walk(obj,origin):
  if isinstance(obj,dict):
   if all(k in obj for k in ['path','file_sha256','line_from','line_to']):
    p=localpath(obj['path']);key=str(p)
    try:
     if key not in rawcache:
      raw=p.read_bytes();rawcache[key]=(sha(raw),raw.decode('utf-8-sig').splitlines())
     digest,lines=rawcache[key];lo,hi=obj['line_from'],obj['line_to'];excerpt='\n'.join(lines[lo-1:hi]);actual=sha(excerpt.encode('utf-8'))
     results.append({'record':origin,'source':obj,'actual_sha256':digest,'file_match':digest==obj['file_sha256'],'range_valid':1<=lo<=hi<=len(lines),'clause_match':actual==obj.get('clause_sha256_lf'),'current_clause_sha256_lf':actual})
    except Exception as exc:results.append({'record':origin,'source':obj,'error':str(exc)})
   for k,v in obj.items():walk(v,origin+'/'+k)
  elif isinstance(obj,list):
   for i,v in enumerate(obj):walk(v,origin+'/'+str(i))
 mach=OUT/'02_EVIDENCE_AUDIT_APPENDICES/_machine'
 for n in ['BASELINE_asset_sets.json','BASELINE_r15_atoms949.json','BASELINE_children149.json','BASELINE_b1_edges31.json','BASELINE_b1_case_specs.json','BASELINE_challenge96.json','BASELINE_acceptance_edges15.json']:
  walk(json.loads((mach/n).read_text(encoding='utf-8')),n)
 dump(M/'ALL_STRUCTURED_SOURCE_COORDINATES.json',results)
 # Original bytes and old manifests remain immutable evidence; current mismatch is a new fact.
 diff=json.loads((WORK/'revision2_replay_snapshot/03_TESTS_AND_READBACK/source_recheck.json').read_text(encoding='utf-8'))
 dump(M/'REVISION2_SOURCE_RECHECK_DIFFERENCES.json',[x for x in diff if x['status']!='UNCHANGED'])
 print(json.dumps({'local_text_files':len(inv),'structured_locators':len(results),'source_files':len(rawcache),'file_sha_mismatch':sum(not x.get('file_match',False) for x in results),'clause_mismatch':sum(not x.get('clause_match',False) for x in results)},ensure_ascii=False))
if __name__=='__main__':main()
