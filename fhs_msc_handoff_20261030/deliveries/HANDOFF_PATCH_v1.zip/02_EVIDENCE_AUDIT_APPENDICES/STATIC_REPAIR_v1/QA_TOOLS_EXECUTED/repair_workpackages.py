from discover import *
from probe_repos import M
B=OUT/'01_SUBSTANTIVE_BODY';MACH=OUT/'02_EVIDENCE_AUDIT_APPENDICES/_machine'
SEAMS=[
('原 SourceReader/RepoProbe','SourceManifest + RepoContext readback','原 TPM/PIPD Source Reader','原來源根、四庫 HEAD/index/untracked、原檔 bytes；不輸入模型推測版本'),
('原 Authority/Profile Owner','AuthorityBinding/ProfileBinding 原 19-schema Registry','PIPD compile-pi','SourceFamily SHA、Domain Owner、原 Oracle、九 context 軸與十二風險分數獨立 sidecar'),
('Fabric Policy Owner','FABRIC/fabric/consumers/hgk_policy_consumer.py 原 Consumer ABI','HGK policy consumer','真 policy epoch/SourceSHA、已批准 policy ref、Host target；先讀原 active/loaded/consumed 分開證據'),
('HGK 原 Registry/Resolver/Issuer','原 HGK WorkOrder/ExecutionBinding/Permit ABI','原 HGK Receiver','原受權 WorkID、Subject、Scope、PolicyEpoch、TTL、nonce；文件 ECP 不充 Permit'),
('Hermes 原 runtime/journal Owner','原 WorkID/Queue/Lease/Journal ABI','原 bounded Worker','原 WorkID、queue item、lease generation、checkpoint；不建立新 queue 或 SQLite journal'),
('PIPD 原 Intake/PI/PD/ECP Compiler','PIPD schemas/registry.json 原 19 families','HGK construction/OPS adapters','三 SPEC、IntentCard、SourceFreeze、Profile、PI；PD 僅在真 RepoContext 晚綁'),
('已受權 Codex bounded Writer','ConstructionContract + DEV ECP + 原 HGK admission','原 Repo Reader/Checker','exact RepoContext、preimage、WriteSet、測試入口、有效 DEV grant、需要的 capability qualification'),
('原 SBL TPM/Commander PLAN Reader','PlanRevisionProposal + 原 PLAN CAS ABI','原 HGK PLAN Reader','Goal/KnownAnswer、SourceSHA、三 SPEC、原 plan revision；A 只讀、B 隔離候選、C effect 分開'),
('原 Hermes Dispatcher + bounded Worker','原 ExecutionBinding/lease fence/EffectRaw ABI','原 WorldRaw Collector','同 WorkID/operation intent/nonce/lease、原 effect receiver；三 lane required/selected/served'),
('原 WorldRaw Producer','原 TQAEP/Protected Checker Request ABI','不同 Principal 的原 Protected Checker','同 CandidateSHA/Subject/CaseID 的 WorldRaw、原 OracleSHA、Maker 與 Checker 權限分離'),
('Fabric/HGK/SBL 三個原 GWO Owner','B1 原 PI27→PD31→TQAEP ABI','三 GWO 各自原 Receiver','每個 GWO 各自 SourceSHA、Scope、Raw；G-A/G-B 不用單一 GWO 借證'),
('原 Portable SP packager/Host Loader','原各 Host install/load/invoke/remove manifest','各 Host 原 Skill Reader','TPM/Commander/Challenge 三 SP 本 Host pin、license、trigger/nontrigger；原八 PIPD skills 分開'),
('原 Hermes normal-entry Owner','W18 ordinary Goal/E33–E42 原 ABI','原 normal Profile/ToolAutoSelect Reader','fresh PID、普通 Goal、原 live Profile/ToolSelection、checkpoint；不要求 B1 長 Prompt'),
('原 TechnologyAdmission/Host capability Owner','原 Need/Occupant/HotSwap admission ABI','原有 Consumer 與 Host Loader','Need+Host+Scope+version、原 OriginalDisposition、舊/新 Occupant 的專屬 parity POS/NEG'),
('原 Publisher','原 Release/Retire + GHP-02 ABI','原發行 channel Reader','同 SubjectSHA 的供應鏈證據、Protected Checker、Publisher 權限；本輪無發布權'),
('原 TPM Corpus Reader/PM/SE/TPgM','SBL 三 SPECDraft + source-bound Stage contracts','原 PIPD Intake','SBL14/PIPD10 原 bytes/SHA、普通 Goal、KnownAnswer、18Stage 原來源；不重問已知答案'),
('原 SBL DOC06 TechnologyAdmission Owner','原 24 Donor Slot/25 Method Reader projection','原 TPM/PIPD/HGK 各受影 Consumer','逐 Slot/Method 的 Need、原 SourceSHA、Input/Output、OriginalDisposition；方法不冒已安裝 binary'),
('原 Host Installer + HGK 原 Issuer','CAP-BOOT 原 Host admission + manifest ABI','原 Host capability Registry/Consumer','已存在 Issuer 的最小合法 installer Scope、需要的 occupant pin/license、有效 OPS grant'),
('原 FAR/incident Reader + bounded Writer','原 FirstFail/RepairCone + DEV ECP ABI','原 affected rechallenge/Checker','真 FirstFail/repro、原 Oracle、最小依賴錐、budget、preimage、exact files；不改 Oracle 躲錯'),
('原 CI/supply-chain Reader','原 license/NOTICE/SBOM/dependency evidence ABI','原 release-readiness Reader','同 CandidateSHA 的 license/NOTICE/SBOM/lock、實際命令/stdout/stderr/exit；不把存在當 PASS'),
('原 Product/Host matrix Owner','原八 Kind×三 Mode×四 Host×Provider token Cell ABI','每個原 Cell 的原 Host Reader','192 原 CellID/Host/raw ON-OFF、明確 NoFit、該 Cell own Raw；DeepSeek48 原身份不改'),
('原 Acceptance/Oracle Owner','原 AC15/Oracle96/H4/SEAM Reader ABI','原 Protected AO Request Reader','每 Case 原 Oracle 類型、calibration、POS/NEG fixtures、Raw schema；計畫不冒實跑')]
def main():
 graph=json.loads((MACH/'BASELINE_wp_graph.json').read_text(encoding='utf-8'));p=B/'11_WORKPACKAGES_AND_DAG.md';t=p.read_text(encoding='utf-8');cards=[]
 for n,seam in zip(graph['nodes'],SEAMS):
  producer,abi,consumer,inputs=seam;ident=n['id'];effect=n['effect_class']
  if effect=='SOURCE_READ':writes=[];bind='唯讀原 admitted root；此工作不寫來源、不需要 Live Permit。'
  elif effect=='LOCAL_DRAFT_WRITE':writes=['隔離交付內 '+ident+' 本地候選檔'];bind='在本輪隔離 root 內先列 manifest exact relpath/preimage，新檔 preimage=ABSENT；不寫正式 Repo、Host 或 User store。'
  else:writes=[];bind='合法晚綁：由原 '+consumer+' 對 '+ident+' 的具名 target root/Host/operation 解析 canonical path/object identity、拒 alias/junction/traversal，列有限 exact WriteSet 與 preimage SHA；空集合或未簽 Scope 不准 effect。原 Owner/Issuer 綁 principal、epoch、TTL、nonce；文件中不預填任意實體路徑。'
  card={**n,'producer':producer,'abi_schema':abi,'consumer':consumer,'input':inputs,'output':n['output'],'write_set':writes,'late_binding_contract':bind,'admission':n['permission_basis'],'done':n['positive']+'；同 Subject/SourceSHA/operation 證據由原 Consumer 讀回；沒有 Raw 記 NOT_RUN。','evidence_expectation':{'producer':producer,'consumer':consumer,'type':'同 '+ident+' original operation 的 command/environment/exit/stdout/stderr 或原 Host WorldRaw','freshness':'same Subject+SourceSHA+CandidateSHA+Scope+PolicyEpoch','claim':'AUTHOR_STATIC_ONLY or NATIVE_NOT_RUN as observed'},'rollback':('只撤本輪 '+ident+' 隔離候選、恢復 exact preimage；原來源不動' if effect=='LOCAL_DRAFT_WRITE' else '丟棄 '+ident+' 唯讀快照後重讀' if effect=='SOURCE_READ' else '由原 '+producer+' 按 '+ident+' 原 receiver inverse/compensation 恢復 exact preimage；UNKNOWN 先 reconcile，保留原 journal/residue，不 reset 他人變更'),'resume':'重讀 '+ident+' 的 SourceSHA/HEAD/index/checkpoint 與依賴 ACK；已完成且同 key 不重播；UNKNOWN effect 只進原 Reconcile，變更只 invalidate 本卡受影下游。','NoFit':ident+' 的 '+n['first_fail']+' 只停本卡 effect 與依賴錐；既有 READ_ONLY/LOCAL_DRAFT READY 繼續。'}
  cards.append(card)
  replacement='\n'.join([f"### {ident}｜{n['name']}",f"- **Producer → ABI/Schema → Consumer**：{producer} → `{abi}` → {consumer}。",f"- **Input**：{inputs}。",f"- **Output**：{n['output']}。",f"- **DAG dependency**：{', '.join(n['depends_on']) or '無前置卡'}；依賴原服務，不創第二 Scheduler。",f"- **EffectClass / Admission**：`{effect}`；{n['permission_basis']}。",f"- **WriteSet / LateBind**：{bind}",f"- **POS**：{n['positive']}。",f"- **NEG / FirstFail**：{n['negative']} → `{n['first_fail']}`。",f"- **Done**：{card['done']}",f"- **EvidenceExpectation**：{card['evidence_expectation']['type']}；freshness={card['evidence_expectation']['freshness']}；Reader={consumer}。",f"- **NoFit / Exit**：{card['NoFit']}",f"- **Rollback**：{card['rollback']}。",f"- **Resume**：{card['resume']}",''])
  # Exact anchor remains a unique current locator; replace its card, retaining all original POS/NEG.
  anchor='current-'+sha(('WorkPackage:'+ident).encode())[:20]
  pattern=r'(<a id="'+anchor+r'"></a>\n)^#{2,5}[^\n]*\n.*?(?=^<a id="current-|^#{1,3} (?!'+re.escape(ident)+r')|\Z)'
  t,count=re.subn(pattern,lambda m:m[1]+replacement+'\n',t,flags=re.M|re.S)
  if count!=1:raise ValueError('WP_CARD_NOT_UNIQUE:'+ident+':'+str(count))
 p.write_text(t,encoding='utf-8',newline='\n');dump(M/'WORKPACKAGE_22_CONSTRUCTION_CONTRACTS.json',cards)
 # Source graph stays the original graph; verify once with the portable affected-only reader.
 from use_tpm_plugin import core_module
 core=core_module();dag={n['id']:n['depends_on'] for n in cards};result=core.affected_work(dag,[])
 dump(M/'DAG_22_RECOMPUTED.json',{'graph':dag,'topology':result,'bootstrap_order':result['order'].index('WP-FHS-17')<result['order'].index('WP-FHS-06')})
 print('22 WorkPackage cards directly rewritten; original graph acyclic; CAP-BOOT before first effect')
if __name__=='__main__':main()
