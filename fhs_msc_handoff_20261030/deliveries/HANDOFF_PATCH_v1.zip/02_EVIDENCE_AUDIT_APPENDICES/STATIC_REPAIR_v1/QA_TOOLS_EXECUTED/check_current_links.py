from discover import *
from probe_repos import M
from markdown_it import MarkdownIt
from urllib.parse import unquote,urlsplit
def scan():
 results=[]
 for p in (OUT/'01_SUBSTANTIVE_BODY').rglob('*.md'):
  t=p.read_text(encoding='utf-8');tokens=MarkdownIt().parse(t)
  for tok in tokens:
   for child in tok.children or []:
    if child.type not in ['link_open','image']:continue
    target=child.attrGet('href') if child.type=='link_open' else child.attrGet('src')
    if not target or re.match(r'^[A-Za-z][A-Za-z0-9+.-]*:',target):continue
    url=urlsplit(target);file=unquote(url.path);dest=(p.parent/file).resolve() if file else p.resolve();exists=dest.exists()
    results.append({'path':str(p.relative_to(OUT)).replace('\\','/'),'target':target,'resolved':str(dest).removeprefix('\\\\?\\'),'file_exists':exists,'fragment':unquote(url.fragment)})
 dump(M/'CURRENT_RELATIVE_LINKS.json',results)
 print('links',len(results),'missing',sum(not r['file_exists'] for r in results));print(json.dumps([r for r in results if not r['file_exists']][:35],ensure_ascii=False,indent=2))
if __name__=='__main__':scan()
