from discover import *
from probe_repos import M
from normalize_locators import marker_pattern
from retain_original_negatives import norm
import sys,copy
def main():
 initial=json.loads((M/'FINAL_GLOBAL_REGRESSION.json').read_text(encoding='utf-8'));dump(M/'FINAL_GLOBAL_REGRESSION_INITIAL.json',initial)
 rows=json.loads((M/'CURRENT_READER_LOCATORS_2221.json').read_text(encoding='utf-8'));aliases=[]
 for r in rows:
  prefix='CELL-' if r['group']=='Cell' else 'EDGE-' if r['group']=='B1Edge' else None
  if prefix and r['id'].startswith(prefix):
   label=r['id'];r['reader_label']=label;r['id']=label[len(prefix):];aliases.append({'group':r['group'],'original_id':r['id'],'reader_heading_label':label,'anchor':r['anchor'],'meaning':'VERSIONED_READER_NAMESPACE_ONLY_NOT_NEW_PRODUCT_ID'})
 dump(M/'CURRENT_READER_LOCATORS_2221.json',rows);dump(M/'ORIGINAL_ID_READER_NAMESPACE_BINDINGS_223.json',aliases)
 checks=json.loads((M/'ORIGINAL_NEGATIVE_RETENTION_ALL_RECORDS.json').read_text(encoding='utf-8'))
 for r in checks:
  if r['group']=='Cell':r['id']=r['id'].removeprefix('CELL-')
  if r['group']=='B1Edge':r['id']=r['id'].removeprefix('EDGE-')
 dump(M/'ORIGINAL_NEGATIVE_RETENTION_ALL_RECORDS.json',checks)
 # Use the original writer's explicit strip_sidecar API, rather than widening the schema.
 sys.path.insert(0,str((WORK/'pipd_workspace_snapshot/src').resolve()));from pipd_ls_sp import pipeline,validate
 p=M/'PIPD_AGENT_WORKSPACE_RUN/PIPD_BOUNDED_22_PI.json';raw=json.loads(p.read_text(encoding='utf-8'));record=pipeline.strip_sidecar(raw)
 dump(M/'PIPD_AGENT_WORKSPACE_RUN/PIPD_BOUNDED_22_PI_STRICT_RECORD.json',record);dump(M/'PIPD_AGENT_WORKSPACE_RUN/PIPD_PROFILE_NONRECORD_SIDECAR.json',{k:v for k,v in raw.items() if k.startswith('_')})
 ack=validate.validate_bundle({'PI-PKG':record},(WORK/'pipd_workspace_snapshot/schemas').resolve());dump(M/'PIPD_AGENT_WORKSPACE_RUN/PIPD_BOUNDED_22_PI_READER_ACK_INITIAL.json',json.loads((M/'PIPD_AGENT_WORKSPACE_RUN/PIPD_BOUNDED_22_PI_READER_ACK.json').read_text(encoding='utf-8')));dump(M/'PIPD_AGENT_WORKSPACE_RUN/PIPD_BOUNDED_22_PI_READER_ACK.json',ack)
 need=lambda ok,msg: (_ for _ in ()).throw(AssertionError(msg)) if not ok else None
 results=[];cache={}
 def run(name,fn):
  try:detail=fn();results.append({'test':name,'class':'INTEGRITY','status':'PASS','detail':detail})
  except Exception as exc:results.append({'test':name,'class':'INTEGRITY','status':'FAIL','detail':str(exc)})
 def locators():
  ids=json.loads((OUT/'02_EVIDENCE_AUDIT_APPENDICES/HISTORICAL_R2_READONLY/_machine/IDENTITY_SETS.json').read_text(encoding='utf-8'))
  for g,vs in ids.items():need({r['id'] for r in rows if r['group']==g}==set(vs),'ORIGINAL_ID_SET:'+g)
  for r in rows:
   if r['path'] not in cache:
    p=OUT/r['path'];b=p.read_bytes();cache[r['path']]=(b.decode('utf-8'),b.decode('utf-8').splitlines(),sha(b))
   text,lines,dg=cache[r['path']];need(dg==r['sha256'],'HASH');need(lines[r['line']-1]==f'<a id="{r["anchor"]}"></a>','LINE');pat=marker_pattern(r['group'],r['id']);need(bool(pat.search(lines[r['line']])),'OWN_HEADING');need(sum(bool(pat.search(x)) for x in lines)==1,'DUPLICATE')
  return {'original_ids':2221,'unique_current_locators':len({r['anchor'] for r in rows}),'explicit_namespace_aliases':len(aliases)}
 def neg():
  by={(r['group'],r['id']):r for r in rows}
  for c in checks:
   r=by[(c['group'],c['id'])];text=cache[r['path']][0];s=text.index(f'<a id="{r["anchor"]}"></a>');e=text.find('<a id="current-',s+4);e=len(text) if e<0 else e;need(norm(c['original_negative']) in norm(text[s:e]),'NEGATIVE_NOT_IN_OWN_CARD:'+c['id'])
  return {'original_negative_fields':len(checks),'retained_in_own_current_card':len(checks)}
 def schemas():
  need(ack['verdict']=='PASS','STRICT_PI_RECORD_NACK')
  for pre in [M,M/'PIPD_AGENT_WORKSPACE_RUN']:
   for file in ['PIPD_BOUNDED_22_PI_READER_ACK.json','PIPD_ISOLATED_TEST_READER_ACK.json']:need(json.loads((pre/file).read_text(encoding='utf-8'))['verdict']=='PASS','ORIGINAL_ACK')
  return 'Both versions original strict-record Readers ACK; original non-record profile sidecar stored separately; original NACK retained'
 run('ALL_2221_ORIGINAL_IDS_AND_UNIQUE_CURRENT_HEADINGS',locators);run('ORIGINAL_NEGATIVE_TEXT_CONSERVATION',neg);run('ORIGINAL_SCHEMA_AND_ADAPTER_ACKS',schemas)
 dump(M/'AFFECTED_RECHECK_AFTER_GLOBAL.json',{'scope':'ONLY_LOCATOR_NAMESPACES_DEPENDENT_NEGATIVE_CHECK_AND_STRICT_PI_ADAPTER','candidate_body_bytes_changed':False,'results':results,'first_author_failure_still_open':'SBL-D00-L00070-C01'})
 replace={r['test']:r for r in results};final={**initial,'checks':[replace.get(r['test'],r) for r in initial['checks']],'affected_recheck':'AFFECTED_RECHECK_AFTER_GLOBAL.json','global_repeated':False}
 final['integrity_pass']=sum(r['status']=='PASS' for r in final['checks'] if r['class']=='INTEGRITY');final['integrity_fail']=sum(r['status']=='FAIL' for r in final['checks'] if r['class']=='INTEGRITY')
 dump(M/'FINAL_GLOBAL_REGRESSION.json',final);print(json.dumps({'affected_results':results,'integrity_pass':final['integrity_pass'],'integrity_fail':final['integrity_fail'],'completion':final['completion']},ensure_ascii=False))
if __name__=='__main__':main()
