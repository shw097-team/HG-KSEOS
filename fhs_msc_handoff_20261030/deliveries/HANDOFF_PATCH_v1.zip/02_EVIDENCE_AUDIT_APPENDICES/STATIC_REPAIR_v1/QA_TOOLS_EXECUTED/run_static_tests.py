from discover import *
from prepare_validation import execute
from probe_repos import M,run
import sys,os
if __name__=='__main__':
 snap=(WORK/'pipd_source_snapshot').resolve();tmp=(WORK/'test_tmp_utf8').resolve();tmp.mkdir(exist_ok=True)
 for args in [['init','-q'],['add','--','src','schemas','tests','tools','docs','fixtures','examples','skills','pyproject.toml','setup.py','LICENSE','NOTICE'],['-c','user.name=Static Fixture','-c','user.email=static-fixture@localhost','commit','-qm','Isolated immutable test baseline']]:
  r=run(['git','-C',str(snap),*args]);dump(M/('ISOLATED_GIT_'+args[0].replace('-','')+'.json'),r)
 execute('PIPD_EXISTING_STATIC_TESTS_UTF8',[sys.executable,'-X','utf8','-B','-m','unittest','tests.test_atomic_requirements','tests.test_negative_and_rollback','tests.test_s4r2_affected_only','tests.test_ce_repair_regression','tests.test_claim_ceiling_shape','tests.test_tqaep_design_positive','tests.test_s0_contracts','tests.test_s1_lite_slice','-v'],cwd=snap,extra_env={'PYTHONPATH':str(snap/'src'),'PYTHONUTF8':'1','TEMP':str(tmp),'TMP':str(tmp)})
