from discover import *
from probe_repos import M,REPOS
from use_tpm_plugin import PLUGIN
from collections import Counter
B=OUT/'01_SUBSTANTIVE_BODY';E=OUT/'02_EVIDENCE_AUDIT_APPENDICES';MACH=E/'_machine'
VERSION='2026-10-30_CODEX-STATIC-REPAIR-v1.0_SOURCE_BOUND_HIGH_RETENTION'
def load(n):return json.loads((MACH/n).read_text(encoding='utf-8'))
def current(t):return t.split('## R2 高保留歷史',1)[0]
def source_rows():
 p=ROOT/'FHS-MSC/FHS-MSC_總藍圖/FHS-MSC_總藍圖.md';ls=p.read_text(encoding='utf-8-sig').splitlines();rows={}
 for n,line in enumerate(ls,1):
  m=re.match(r'^\|\s*`(METHOD-\d+|SLOT-[A-Z]+-\d+)`\s*\|',line)
  if m and m[1] not in rows:rows[m[1]]={'line':n,'text':line,'cells':[c.strip() for c in line.strip('|').split('|')]}
 return p,sha(p.read_bytes()),rows
def main():
 # Preserve input bytes before changing any delivery copy.
 arch=M/'INPUT_R2_VERBATIM';shutil.copytree(B,arch,dirs_exist_ok=True)
 dump(M/'INPUT_R2_BODY_SHA256.json',[{'path':str(p.relative_to(B)).replace('\\','/'),'sha256':sha(p.read_bytes())} for p in B.rglob('*.md')])
 changes=[];restored=[]
 for p in B.glob('*.md'):
  t=current(p.read_text(encoding='utf-8'));t=re.sub(r'## R2 現行／歷史 Reader 隔離\n.*?(?=\n## |\Z)','',t,flags=re.S)
  t=t.replace('此文件前半 r2 更新與後半歷史正文是一份整合 Candidate，不是平行的兩份現役 Canonical。','本冊有效設計正文包含未受影條文；原 Domain Canonical Writer 不移轉。')
  old=(REV/'01_BODY'/p.name).read_text(encoding='utf-8-sig')
  # Restore full untouched R2 clauses, never the repeated item catalogs that R2 rewrote.
  blocks=re.split(r'(?=^## )',old,flags=re.M)
  restored_blocks=[]
  for block in blocks:
   if not block.startswith('## R2-'):continue
   title=block.splitlines()[0]
   if title in t:continue
   if re.search(r'^#{3,6}\s+(?:Native20:|Default30:|Donor24:|Method25:|TECH386:|R15-|AC-C|TQ-|B1-N|[a-f0-9]{12}\b|WP-FHS-)',block,re.M):continue
   if len(block)>18000:continue
   restored_blocks.append(block.strip());restored.append({'book':p.name,'heading':title,'source':str(REV/'01_BODY'/p.name).removeprefix('\\\\?\\'),'sha256':sha(block.encode())})
  if restored_blocks:t+='\n\n## 本版未受影條文（完整沿用、當期生效）\n\n'+'\n\n'.join(restored_blocks)+'\n'
  # Historical prose is not part of the current parsing namespace. All input remains in evidence.
  header=f'<!-- artifact_version: {VERSION}; scope: FHS_DESIGN_READER; native: NATIVE_NOT_RUN; release: NOT_RUN -->\n\n'
  p.write_text(header+t.strip()+'\n',encoding='utf-8',newline='\n')
 dump(M/'RESTORED_UNAFFECTED_CURRENT_CLAUSES.json',restored)
 # Correct the observed version boundary, rather than trusting the old remote==local assumption.
 repo_rows=[]
 for name in ['HG-KSEOS','SBL','Fabric','PIPD-LS-SP']:
  d=json.loads((M/(name+'_repo_readback.json')).read_text(encoding='utf-8'));s=d['status']['stdout'].splitlines();remote=d['remote_main']['stdout'].split()[0]
  repo_rows.append(f"| {name} | `{d['HEAD']['stdout'].strip()}` | `{remote}` | {sum(x.startswith(('1 ','2 ','u ')) for x in s)} / {sum(x.startswith('? ') for x in s)} |")
 version_text='''## STATIC-v1 真實版本與本地實作綁定

| Repo | 本地 HEAD | 本輪遠端 main | tracked dirty entries / untracked entries |
|---|---|---|---|
'''+ '\n'.join(repo_rows)+'''

本地 HEAD、index blob、staged、unstaged、untracked 均分別保存；遠端以本輪授權憑證唯讀取得 main 完整 blob 樹。兩者不相同，不得以遠端 SHA 當本機 RepoContext。原 R2 的「四庫等同本地」前提在本輪撤銷。工作樹現有變更不由本輪修補、重設或清理。設計 Reader 的 SourceSHA 不等於 Loaded、Actual Served、Permit 或 Checker 收據。
'''
 for n in ['00_INDEX_AND_DECISION.md','03_ARCHITECTURE_ABI_AND_EFFECT.md']:
  p=B/n;t=p.read_text(encoding='utf-8');t=re.sub(r'^5\. \*\*四庫等同本地\*\*.*$','5. **本地與遠端分開綁定**：以本冊 STATIC-v1 的實測表及 index/untracked 原始輸出為準；不得從舊遠端 SHA 推定本機狀態。',t,flags=re.M)
  t=t.replace('本輪沒有看到 local HEAD/index/untracked，禁止推定本機 dirty=0。','本輪已保存 local HEAD/index/untracked 原始輸出；只對實測工作樹作判斷。')
  p.write_text(t+'\n'+version_text,encoding='utf-8',newline='\n')
 # Resolve the 69 dispositions against explicit source text, not guesses or new Owner decisions.
 master,mastersha,rows=source_rows();assets=load('R2_ASSET_SETS_PATCHED.json');resolved=[]
 donor_dispositions={'OpenSpec':'SELECTIVE_NATIVE_REUSE','Spec Kit':'OPTIONAL_GREENFIELD','mattpocock/skills':'METHOD_REUSE','GSD':'REFERENCE_ONLY/ARCHIVED_LINEAGE_CHECK','gstack':'REFERENCE/EVAL_ONLY','Superpowers':'METHOD_REUSE'}
 tech=B/'08_TECHNOLOGY_DEFAULT_HOTSWAP.md';t=tech.read_text(encoding='utf-8')
 for group in ['Native20','Donor24','Method25']:
  for a in assets[group]:
   ident=a['id'];row=rows.get(ident);disposition=a.get('r2_original_disposition_literal') or a['original_disposition'];detail=''
   if group=='Method25' and row:
    disposition=row['cells'][2].replace('`','').strip();detail=f"Need/輸出：{row['cells'][3]}；專屬 NEG：{row['cells'][4]}；適用、退出與回復：{row['cells'][5]}。"
   elif group=='Donor24' and row:
    donor=row['cells'][1];disposition=donor_dispositions[donor];detail=f"Need：{row['cells'][2]}；Input：{row['cells'][3]}；Output/Consumer：{row['cells'][4]}；專屬 NEG：{row['cells'][5]}；ProviderOff/退出/回復：{row['cells'][6]}。"
   elif group=='Native20':
    disposition=a.get('r2_original_disposition_literal') or a['original_disposition'];detail='原 Singleton/Role/Worker 類別照原行保留；類別不是安裝同意，也不是 Mandatory 的降級。'+a.get('domain_original','')
   else:raise ValueError('SOURCE_DISPOSITION_NOT_FOUND:'+ident)
   sr={'path':str(master).removeprefix('\\\\?\\'),'file_sha256':mastersha,'line':row['line']} if row else a['source']
   binding={'group':group,'id':ident,'original_disposition':disposition,'source':sr,'resolution':'SOURCE_RESOLVABLE_RESOLVED_DESIGN_ONLY','owner_ack':None,'native':'NATIVE_NOT_RUN','activation':'ORIGINAL_OWNER_POLICY_AND_HOST_QUALIFICATION_REQUIRED','detail':detail}
   resolved.append(binding)
   pat=r'(^#{3,4} '+re.escape(group+':'+ident)+r'[^\n]*\n)(.*?)(?=^#{1,4} |\Z)'
   def patch(m):
    text=m[2];text=text.replace('OWNER_DECISION_UNBOUND',disposition).replace('ACTIVATION_HOLD_UNTIL_DISPOSITION','ACTIVATION_REQUIRES_ORIGINAL_HOST_ADMISSION')
    text=re.sub(r'原處置：`?見原行之OriginalDisposition`?','原處置：`'+disposition+'`',text)
    return m[1]+text+'\n- **STATIC-v1 來源直接解綁**：`'+disposition+'`。'+detail+'\n- **專屬來源與合法邊界**：`'+str(sr)+'`；本項 disposition 可由來源解決，無須重問既有決策。原具名功能與 Consumer 保留；Host install/load/invoke、upstream immutable pin/license 若無實測仍屬受影 Native 差額。不得將此來源讀回當 Owner ratification 或允許外呼。\n\n'
   t,n=re.subn(pat,patch,t,flags=re.M|re.S)
   if n!=1:raise ValueError(f'ASSET_LOCATOR_{group}:{ident}={n}')
 dump(M/'DISPOSITIONS_69_SOURCE_RESOLVED.json',resolved);tech.write_text(t,encoding='utf-8',newline='\n')
 # The portable stage adapter's actual source-bound stages replace invented stage names.
 contracts=json.loads((M/'TPM_PLUGIN_STAGE_CONTRACTS_PINNED.json').read_text(encoding='utf-8'))['contracts']
 st=['## STATIC-v1 三角色 18 Stage：按插件原 Clause Reader 的實際契約','', '| Stage | 原 Input | 原操作 → Output／Consumer | Guard／FirstFail／退出 |','|---|---|---|---|']
 for c in contracts:
  st.append('| '+c['id']+' | '+', '.join(c['typed_input'])+' | '+c['operation']+' → '+c['typed_output']+' / '+c['consumer']+' | '+c['entry_guard']+'；'+c['first_fail']+'；'+c['exit_guard']+'；'+c['next_legal_action']+' |')
 st+=['','各列來源為 SBL-04 原 SourceSHA 與原 line，已由 `sbl-tpm-sp/scripts/core.py::read_clause` 驗 SHA 讀回；完整座標逐列保存。這是 Stage draft 接線，不將 T4/T5 提案升為原 StateEnum。T5 必須讀 Raw；缺 Raw 只退受影 T3/T4，不阻斷其他 READY。原版 PM:T2 與 T4 的不同提案名稱已退出當期 Stage Reader。']
 p=B/'02_PIPD_LIFECYCLE_AND_TPM.md';t=p.read_text(encoding='utf-8')
 t=re.sub(r'### 2\.2 18 Stage.*?(?=### 2\.3)', '\n'.join(st)+'\n\n',t,flags=re.S)
 # Remove the duplicate inherited stage table; it cannot remain a second current locator.
 t=re.sub(r'### 6\.2 PM／SE／TPgM.*?(?=### 6\.3)', '',t,flags=re.S)
 p.write_text(t,encoding='utf-8',newline='\n')
 # No raw ON/OFF token is an executable provider_off mapping.
 p=B/'09B_KIND_MODE_HOST_192.md';t=p.read_text(encoding='utf-8')
 t=t.replace('provider_off=false','provider_off=UNBOUND_FROM_LEGACY_TOKEN').replace('provider_off=true','provider_off=UNBOUND_FROM_LEGACY_TOKEN')
 t+='''
## STATIC-v1 Provider token 與執行布林的接線規則

本冊 192 原 Cell 的 ON/OFF 僅作原身份欄，沒有可呼叫 Provider 的推測轉換。`host_provider_off_boolean=null`、`runtime_effect_allowed=false` 直至原 Product/Provider Policy Owner 用同版本映射及原 Reader 完成綁定。POS：保留原 raw token、原 Host、原 CellID；在未知映射時可作文件／離線靜態處理而不外呼。NEG：從 ON 推定允許外呼、把 DeepSeek 48 Cell 改成 ChatGPT、借另一 Host Raw → 拒收。NoFit 只隔離需外呼的 Cell；恢復條件為同 Subject/PolicyEpoch 的有效映射與原 Host 收據。已批准 ProviderOff=true 時零 Provider 外呼是獨立安全義務，不受此 legacy label 衝突削弱。
''';p.write_text(t,encoding='utf-8',newline='\n')
 # Give every measured original identity exactly one explicit current Reader anchor.
 mapping=load('R2_CURRENT_SECTION_MAP.json');new=[]
 grouped={}
 for r in mapping:grouped.setdefault(r['current_path'],[]).append(r)
 for rel,records in grouped.items():
  p=OUT/rel;lines=p.read_text(encoding='utf-8').splitlines();used=set()
  for r in records:
   oldlines=(arch/Path(rel).relative_to('01_SUBSTANTIVE_BODY')).read_text(encoding='utf-8').splitlines()
   oldheading=oldlines[r['current_line']-1].strip()
   matches=[i for i,x in enumerate(lines) if x.strip()==oldheading and i not in used]
   if not matches:
    matches=[i for i,x in enumerate(lines) if x.startswith('#') and re.search(r'(?<![A-Za-z0-9_.-])'+re.escape(r['id'])+r'(?![A-Za-z0-9_.-])',x) and i not in used]
   if not matches:raise ValueError('CURRENT_ID_NOT_FOUND:'+r['group']+':'+r['id'])
   i=matches[0];used.add(i);anchor='current-'+sha((r['group']+':'+r['id']).encode())[:20];lines[i]=f'<a id="{anchor}"></a>\n'+lines[i]
   new.append({'group':r['group'],'id':r['id'],'path':rel,'anchor':anchor,'reader_role':'FHS_STATIC_v1_CURRENT_DESIGN','native':'NATIVE_NOT_RUN'})
  p.write_text('\n'.join(lines)+'\n',encoding='utf-8',newline='\n')
 for r in new:
  p=OUT/r['path'];lines=p.read_text(encoding='utf-8').splitlines();r['line']=next(i for i,x in enumerate(lines,1) if x==f'<a id="{r["anchor"]}"></a>');r['sha256']=sha(p.read_bytes())
 dump(M/'CURRENT_READER_LOCATORS_2221.json',new)
 dump(M/'DIRECT_REPAIR_CHANGE_LOG.json',{'version':VERSION,'body_books':17,'original_sbl_books':14,'dispositions_source_resolved':len(resolved),'restored_untouched_clauses':len(restored),'current_identity_locators':len(new),'history':'INPUT_R2_VERBATIM and prior evidence retained byte-for-byte','native':'NATIVE_NOT_RUN'})
 print('repaired 17 current bodies; 69 source dispositions; 18 source-bound stages; 192 provider guard; 2221 explicit current anchors; restored',len(restored),'clauses')
if __name__=='__main__':main()
