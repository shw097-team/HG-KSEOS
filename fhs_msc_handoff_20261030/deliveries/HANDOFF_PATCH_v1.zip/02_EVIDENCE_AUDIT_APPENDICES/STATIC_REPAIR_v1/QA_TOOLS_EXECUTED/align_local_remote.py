from discover import *
from probe_repos import M,REPOS
import ast
def main():
 summaries=[];alllocal=[];allfacts=[];diffs=[];gaps=[]
 for name in ['HG-KSEOS','SBL','Fabric','PIPD-LS-SP','PIPD-worktree']:
  d=json.loads((M/(name+'_repo_readback.json')).read_text(encoding='utf-8'));root=Path(REPOS[name]);local={}
  for row in d['index']['stdout'].splitlines():
   if '\t' not in row:continue
   rel=row.split('\t',1)[1]
   if row.startswith('160000 '):gaps.append({'repo':name,'path':rel,'reason':'LOCAL_INDEX_GITLINK_NO_BLOB_SUBTREE_NOT_INCLUDED','gitlink_object':row.split()[1]});continue
   if re.search(r'(?i)(?:^|/)(?:\.env(?:\.|$)|.*(?:api.?key|tokens?)\.txt$|.*\.(?:pem|key|pfx)$)',rel):gaps.append({'repo':name,'path':rel,'reason':'SENSITIVE_NAME_NOT_CONTENT_READ'});continue
   p=Path('\\\\?\\'+str(root/rel))
   try:
    raw=p.read_bytes();dg=sha(raw);text=None
    try:text=raw.decode('utf-8-sig')
    except UnicodeError:pass
    record={'repo':name,'path':rel,'absolute_path':str(root/rel),'sha256':dg,'bytes':len(raw),'utf8':text is not None,'index_object':row.split()[1]}
    local[rel]=record;alllocal.append(record)
    if text is not None and p.suffix.lower()=='.py':
     try:
      tree=ast.parse(text)
      for n in ast.walk(tree):
       if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)):
        allfacts.append({'repo':name,'path':rel,'name':n.name,'line':n.lineno,'kind':type(n).__name__,'sha256':dg})
     except SyntaxError:gaps.append({'repo':name,'path':rel,'reason':'PYTHON_AST_SYNTAX_UNSUPPORTED_OR_INVALID'})
    if p.name=='AGENTS.md' and text is not None:
     dest=M/'SCOPED_AGENTS_READBACK'/name/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw)
   except OSError as exc:gaps.append({'repo':name,'path':rel,'reason':str(exc)})
  remote=json.loads((M/(('PIPD-LS-SP' if name=='PIPD-worktree' else name)+'_remote_full_read.json')).read_text(encoding='utf-8'))
  for r in remote['files']:
   status='SAME_BYTES' if r['path'] in local and local[r['path']]['sha256']==r['sha256'] else 'DIFFERENT_BYTES' if r['path'] in local else 'REMOTE_PATH_NOT_TRACKED_LOCAL'
   diffs.append({'repo':name,'path':r['path'],'remote_main':remote['main'],'remote_sha256':r['sha256'],'local_sha256':local.get(r['path'],{}).get('sha256'),'status':status})
  remote_paths={r['path'] for r in remote['files']}
  for rel,r in local.items():
   if rel not in remote_paths:diffs.append({'repo':name,'path':rel,'local_sha256':r['sha256'],'status':'LOCAL_TRACKED_PATH_NOT_REMOTE_MAIN'})
  summaries.append({'repo':name,'local_tracked_read':len(local),'remote_main_read':len(remote['files']),'local_bytes_read':sum(x['bytes'] for x in local.values()),'differences':sum(x['repo']==name and x['status']!='SAME_BYTES' for x in diffs)})
 dump(M/'LOCAL_TRACKED_FULL_READ_MANIFEST.json',alllocal);dump(M/'LOCAL_REMOTE_ALL_FILE_DIFFERENCES.json',diffs);dump(M/'LOCAL_CODE_DEFINITION_INDEX.json',allfacts);dump(M/'LOCAL_READ_EXACT_GAPS.json',gaps);dump(M/'LOCAL_REMOTE_ALIGNMENT_SUMMARY.json',summaries)
 print(json.dumps({'summary':summaries,'code_definitions':len(allfacts),'gaps':len(gaps)},ensure_ascii=False))
if __name__=='__main__':main()
