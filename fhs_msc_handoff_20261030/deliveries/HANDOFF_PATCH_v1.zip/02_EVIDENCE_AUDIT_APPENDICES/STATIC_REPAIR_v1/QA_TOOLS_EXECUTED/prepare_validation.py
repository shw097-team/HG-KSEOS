from discover import *
from probe_repos import M, E, REPOS, run
import os, subprocess, time, sys
def execute(name,args,cwd=None,extra_env=None):
 env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONIOENCODING='utf-8',GIT_OPTIONAL_LOCKS='0')
 env.update(extra_env or {})
 start=time.perf_counter()
 try:
  r=subprocess.run(args,cwd=cwd,env=env,capture_output=True,timeout=240)
  out,err=r.stdout,r.stderr;code=r.returncode
 except subprocess.TimeoutExpired as exc:out,err=exc.stdout or b'',exc.stderr or b'';code='TIMEOUT'
 (M/(name+'.stdout.txt')).write_bytes(out);(M/(name+'.stderr.txt')).write_bytes(err)
 rec={'command':args,'cwd':str(cwd or Path.cwd()),'exit_code':code,'elapsed_seconds':time.perf_counter()-start,'stdout_sha256':sha(out),'stderr_sha256':sha(err),'python':sys.version,'platform':sys.platform,'claim':'AUTHOR_STATIC_ONLY'}
 dump(M/(name+'.receipt.json'),rec);print(name,code,out.decode('utf-8','replace')[-1400:],err.decode('utf-8','replace')[-500:])
 return rec
if __name__=='__main__':
 # A replay of the unchanged prior package is kept separate from the new acceptance.
 baseline=WORK/'R2_replay_snapshot';shutil.copytree(OUT,baseline,dirs_exist_ok=True,ignore=shutil.ignore_patterns('STATIC_REPAIR_v1'))
 execute('PRIOR_R2_STATIC_REPLAY',[sys.executable,'-B',str((baseline/'02_EVIDENCE_AUDIT_APPENDICES/_machine/R2_STATIC_REPLAY.py').resolve())])
 revsnap=WORK/'revision2_replay_snapshot';shutil.copytree(REV,revsnap,dirs_exist_ok=True,ignore=shutil.ignore_patterns('*.zip','*.sha256'))
 execute('PRIOR_REVISION2_VALIDATE',[sys.executable,'-B',str((revsnap/'tools/validate.py').resolve())])
 # Copy all tracked public implementation/configuration/test surfaces, with exact raw hashes.
 pip=Path(REPOS['PIPD-LS-SP']);snap=WORK/'pipd_source_snapshot';manifest=[]
 data=json.loads((M/'PIPD-LS-SP_repo_readback.json').read_text(encoding='utf-8'))
 for line in data['index']['stdout'].splitlines():
  if '\t' not in line:continue
  rel=line.split('\t',1)[1]
  if not (rel.startswith(('src/','schemas/','tests/','tools/','docs/','fixtures/','examples/','skills/','packaging/')) or rel in ['pyproject.toml','setup.py','README.md','LICENSE','NOTICE','OWNER_LICENSE_DECISION.yaml','requirements.lock','MANIFEST.in']):continue
  if re.search(r'(?i)(api.?key|tokens?\.txt|credential|secret[^_a-z])',rel):continue
  p=pip/rel
  if not p.is_file():continue
  b=p.read_bytes();dest=snap/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
  manifest.append({'path':str(p),'snapshot':str(dest.resolve()),'relative':rel,'sha256':sha(b),'bytes':len(b),'git_index_object':line.split()[1]})
 dump(M/'PIPD_SOURCE_SNAPSHOT_MANIFEST.json',manifest)
 execute('PIPD_EXISTING_STATIC_TESTS',[sys.executable,'-B','-m','unittest','tests.test_atomic_requirements','tests.test_negative_and_rollback','tests.test_s4r2_affected_only','tests.test_ce_repair_regression','tests.test_claim_ceiling_shape','tests.test_tqaep_design_positive','tests.test_s0_contracts','tests.test_s1_lite_slice','-v'],cwd=snap,extra_env={'PYTHONPATH':str((snap/'src').resolve())})
