from discover import *
from probe_repos import M
from prepare_validation import execute
import importlib.util,sys
PLUGIN=Path(r'C:\Users\user\.codex\plugins\cache\created-by-me-remote\sbl-tpm-sp\0.2.0rc1')
def core_module():
 spec=importlib.util.spec_from_file_location('source_bound_tpm_core',PLUGIN/'scripts/core.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);return mod
def main():
 core=core_module();mf=core.corpus_manifest(PLUGIN);dump(M/'TPM_PLUGIN_CORPUS_VERIFIED.json',mf)
 execute('TPM_PLUGIN_VERIFY_CORPUS',[sys.executable,'-B',str(PLUGIN/'scripts/verify_corpus.py'),str(PLUGIN)])
 dump(M/'TPM_PLUGIN_SBL04_CLAUSE_READBACK.json',core.read_clause(PLUGIN,'SBL-04',500,527))
 contracts=json.loads((PLUGIN/'references/contracts/stage-contracts.json').read_text(encoding='utf-8'))
 dump(M/'TPM_PLUGIN_STAGE_CONTRACTS_PINNED.json',contracts)
 refs=[{'path':str(PLUGIN/'skills'/s/'SKILL.md'),'sha256':sha((PLUGIN/'skills'/s/'SKILL.md').read_bytes())} for s in ['tpm-sp','tpm-setup','tpm-product-plan','tpm-system-plan','tpm-program-plan','pipd-authority-source','pipd-assurance-tqaep','pipd-package-project']]
 dump(M/'TPM_PLUGIN_USE_RECEIPT.json',{'plugin':'sbl-tpm-sp','version':'0.2.0rc1','source':str(PLUGIN),'SELECTED':True,'INSTALLED':'LOCAL_PACKAGE_PRESENT','BOUND':'THIS_SOURCE_BOUND_DOCUMENT_REPAIR_SUBJECT','INVOKED':['corpus_manifest','read_clause','plan_spec','decision_gate','affected_work'],'VERIFIED':'24_DOC_PHYSICAL_HASH_ONLY','HOST':'HOST_PENDING_NO_NATIVE_LOADER_RECEIPT','skills':refs,'setup_gap':'stage-contracts.json contains PM/SE/TPgM only; no SETUP role entries; no invented SETUP contract'})
 srcsha=sha((M/'SourceManifest_ALL_LOCAL.json').read_bytes());goal='FHS-MSC 17 冊來源約束正文修補及作者端靜態交付'
 accept=[{'requirement':'原身份及專屬語義保留','positive':'逐原 ID 與原句 SHA 及唯一當期 locator 一致','negative':'刪除 child 或用另一 Host 收據代替時拒收','oracle_ref':'STATIC_REPAIR_v1/ALL_STRUCTURED_SOURCE_COORDINATES.json'}, {'requirement':'權威與 Effect 隔離','positive':'來源只讀與隔離文稿可進行；有副作用工作由原 Owner 准入','negative':'DEV grant 冒用 OPS 或 Maker 自簽 Independent PASS 時拒收','oracle_ref':'BODY03/R2-03-EFFECT'}, {'requirement':'可重播靜態交付','positive':'兩 ZIP 逐檔 CRC、SHA、UTF-8 及連結讀回相同','negative':'少檔、byte drift、失效 current locator 時失敗','oracle_ref':'FINAL_GLOBAL_REGRESSION'}]
 common={'source_sha256':srcsha,'source_refs':[str(PKG/'藍圖/FHS-MSC_PIPD-LS-PKG_藍圖.md').removeprefix('\\\\?\\'),str(PKG/'藍圖/FHS-MSC_技術架構_選型更新_修補藍圖_2026-10-30_r2.md').removeprefix('\\\\?\\')],'goal':goal,'non_goals':['正式四庫寫入','Skill部署','Native Effect','Permit簽發','Release發布'],'acceptance':accept}
 product=core.plan_spec('Product',{**common,'persona':'來源包作者與下游工程 Reader','jtbd':'將現役規格整理為可追溯且可施工的 17 冊正文','fuo':'讀者可從入口定位原需求、專屬操作與正反例，取得真實作者端結果與雙 ZIP'})
 arch=core.plan_spec('Architecture',{**common,'adr':['Domain 原 Writer／Owner／ABI 優先於新日期','本地 HEAD/index/dirty 與遠端 main 分別記錄','Native 收據缺失保持 NATIVE_NOT_RUN'],'ownership_seams':[{'name':'PI/PD/ECP','writers':['PIPD original compiler']},{'name':'Policy','writers':['Fabric policy owner']},{'name':'Permit/Canonical transition','writers':['HGK original issuer/shared spine']},{'name':'Queue/Lease/Journal','writers':['Hermes original runtime']},{'name':'Independent verdict','writers':['Original Protected Checker']}],'abi_version':'SOURCE_BOUND_DESIGN/1','risk':['舊來源搬移與版本差異','量詞片段語義不完整','Host active/load/served 尚未實測']})
 nodes=json.loads((OUT/'02_EVIDENCE_AUDIT_APPENDICES/_machine/BASELINE_wp_graph.json').read_text(encoding='utf-8'))['nodes'];dag={n['id']:n['depends_on'] for n in nodes}
 prog=core.plan_spec('Program',{**common,'dag':dag,'owners':{n['id']:n['permission_basis'] for n in nodes},'work_packages':{n['id']:n for n in nodes},'resume_predicate':'先讀同 Subject/SourceSHA/checkpoint；僅重跑受影閉合；不重試 UNKNOWN Effect'})
 for name,obj in [('ProductSPEC',product),('ArchitectureSPEC',arch),('ProgramSPEC',prog)]:dump(M/(name+'.json'),obj)
 decision={'schema':'SBL.GitHubDeliveryDecision@1','subject_sha256':srcsha,'question_key':'github_publication_for_mission','state':'LOCAL_ONLY','scope':'isolated_document_delivery','owner_decision_ref':'USER_CODEX_STATIC_REPAIR_v1_WRITE_BOUNDARY'}
 dump(M/'GHP01_DECISION.json',{'input':decision,'result':core.decision_gate(decision,'LOCAL_DELIVERY',expected_subject=srcsha,expected_scope='isolated_document_delivery')})
 dump(M/'TPM_BOUNDED_HANDOFF.json',{'goal':goal,'fuo':product['fuo'],'non_goals':common['non_goals'],'assumptions':['原 Domain authority 未移轉'],'decisions':['來源與 Repo 全程唯讀；只寫隔離交付'],'acceptance':accept,'open_questions':[],'sources':refs,'write_scope':str(OUT).removeprefix('\\\\?\\'),'native':'NATIVE_NOT_RUN'})
 print('sbl-tpm-sp invoked: corpus 24/24; three SPEC drafts; bounded handoff; GHP01 LOCAL_ONLY; HOST_PENDING')
if __name__=='__main__':main()
