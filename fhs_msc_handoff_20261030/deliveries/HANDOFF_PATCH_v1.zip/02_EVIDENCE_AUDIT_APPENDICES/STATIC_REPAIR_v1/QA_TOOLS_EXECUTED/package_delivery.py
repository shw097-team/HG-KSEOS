from discover import *
from probe_repos import M
from markdown_it import MarkdownIt
from urllib.parse import urlsplit,unquote
import sys,platform,time
def main():
 report=json.loads((M/'FINAL_GLOBAL_REGRESSION.json').read_text(encoding='utf-8'))
 if report['integrity_fail']!=0:raise ValueError('STATIC_INTEGRITY_NOT_CLOSED')
 # Keep the semantic failure visible in every entrance and in the final external receipt.
 (OUT/'VERSION_AND_DELIVERY.md').write_text('''# 版本與交付說明

版本：2026-10-30 / CODEX-STATIC-REPAIR-v1.0 / SOURCE_BOUND / HIGH_RETENTION。

文件任務狀態：**REPAIR_INCOMPLETE**。第一作者端失敗：`AUTHOR_COMPOUND_SUBITEM_CONTRACT_INCOMPLETE / SBL-D00-L00070-C01`。7649筆 SBL 量詞候選仍未全部完成專屬子項施工契約，不能冒全量語義修補完成或把它們改標外部 HOLD。原 full17 Compiler intake NACK 保留；44條有限投影的編譯成功只在該範圍有效。

本輪已修補17主冊候選、保留14 SBL升級冊；恢復29個未受影條文、解析69個來源處置、校正18 Stage及22 WP完整施工欄位、建立2221個原身份的唯一 Current Reader，保留2403個原負例文字欄位。三種SPEC與PlannedTQAEP由已選用 sbl-tpm-sp adapter實際產生；Host仍是HOST_PENDING。

全局回歸執行一次，發現後僅重驗 Locator namespace、原負例位置與strict PI sidecar受影錐；最終13項物理／結構／原Reader檢查PASS，語義完成項FAIL。初始全局失敗與受影重查原始資料均保留。既有原測試：R2 10/10；另一個本地PIPD108/108；Agent_Workspace版本71項中1項CLI13/14失敗。Revision2來源路徑初驗1項失敗，26件以exact SHA定位搬移，3件仍缺；不可宣稱所有來源完全可得。

正文ZIP與證據ZIP全部修補後各正式封裝一次。解壓至同一資料夾；兩ZIP共有的SHA256_PAYLOAD_MANIFEST.json應同bytes。正文ZIP含Index及17+14正文；證據ZIP含獨立Markdown附錄、Raw、原來源追溯及作者端工具。歷史保留原bytes，舊連結/指令不作當期Reader；當期相對連結全部檢查。

SHA256_PAYLOAD_MANIFEST.json列本次封裝前payload，依構造不列自身。SHA256_DELIVERY_MANIFEST.md列兩ZIP及外部readback/入口檔，不列自身。PACKAGE_READBACK.json在封裝後產生，故不置於ZIP中，避免自我指涉。

Native=NATIVE_NOT_RUN；Protected Checker=NOT_RUN；Release=NOT_RUN。沒有修改正式四庫、部署Skill、執行Native Effect、簽Permit或發布Release。使用者指定GitHub憑證只用於四庫唯讀main下載，未記錄值或置入交付物。按REPAIR_INCOMPLETE及封裝讀回完成條件停止。
''',encoding='utf-8',newline='\n')
 (OUT/'EVIDENCE_INDEX.md').write_text('''# 作者端稽核證據入口

結果：REPAIR_INCOMPLETE；Native/Release未執行。

- [來源與Authority](02_EVIDENCE_AUDIT_APPENDICES/10_STATIC_v1_SOURCE_MANIFEST.md)
- [Repo與Host差額](02_EVIDENCE_AUDIT_APPENDICES/11_STATIC_v1_REPO_AND_HOST_DELTAS.md)
- [測試、Schema、DAG與NEG](02_EVIDENCE_AUDIT_APPENDICES/12_STATIC_v1_TESTS_AND_SCHEMA.md)
- [HOLD與ClaimCeiling](02_EVIDENCE_AUDIT_APPENDICES/13_STATIC_v1_CLAIM_CEILING.md)
- [最後全局回歸及受影重查](02_EVIDENCE_AUDIT_APPENDICES/STATIC_REPAIR_v1/FINAL_GLOBAL_REGRESSION.json)
- [第一作者端失敗](02_EVIDENCE_AUDIT_APPENDICES/STATIC_REPAIR_v1/FIRST_AUTHOR_FAILURE.json)
- [Finding F-01至F-16逐項狀態](02_EVIDENCE_AUDIT_APPENDICES/STATIC_REPAIR_v1/FINDINGS_F01_F16_CURRENT_CLOSURE.json)
- [版本與停止](VERSION_AND_DELIVERY.md)
''',encoding='utf-8',newline='\n')
 # Preserve the exact final author tooling in the evidence payload.
 q=M/'QA_TOOLS_EXECUTED';q.mkdir(exist_ok=True)
 for p in WORK.glob('*.py'):(q/p.name).write_bytes(p.read_bytes())
 # Recheck all current links after the small affected repairs and final entrance files.
 files=list((OUT/'01_SUBSTANTIVE_BODY').rglob('*.md'))+list(OUT.glob('*.md'))+list((OUT/'02_EVIDENCE_AUDIT_APPENDICES').glob('1*.md'));link_count=0
 for p in files:
  for token in MarkdownIt().parse(p.read_text(encoding='utf-8')):
   for c in token.children or []:
    if c.type!='link_open':continue
    target=c.attrGet('href')
    if not target or re.match(r'^[A-Za-z][A-Za-z0-9+.-]*:',target):continue
    u=urlsplit(target);dest=(p.parent/unquote(u.path)).resolve() if u.path else p.resolve()
    if not dest.exists():raise ValueError('FINAL_LINK_MISSING:'+str(p)+':'+target)
    link_count+=1
 # Files which are produced after payload freezing are excluded by construction.
 excluded={'SHA256_PAYLOAD_MANIFEST.json','SHA256_DELIVERY_MANIFEST.md','PACKAGE_READBACK.json'}
 payload=[]
 for p in sorted(OUT.rglob('*')):
  if not p.is_file() or p.suffix=='.zip' or p.name in excluded:continue
  b=p.read_bytes();b.decode('utf-8','strict');rel=p.relative_to(OUT).as_posix();payload.append({'path':rel,'sha256':sha(b),'bytes':len(b)})
 manifest={'schema':'AUTHOR.PayloadSHA256Manifest/1','scope':'COMBINED_BODY_AND_EVIDENCE_EXTRACTED_ROOT','self_excluded_by_construction':True,'files':payload,'task_status':'REPAIR_INCOMPLETE'}
 dump(OUT/'SHA256_PAYLOAD_MANIFEST.json',manifest)
 body_names=[x['path'] for x in payload if x['path'].startswith('01_SUBSTANTIVE_BODY/') or '/' not in x['path'] and x['path']!='EVIDENCE_INDEX.md']
 evidence_names=[x['path'] for x in payload if x['path'].startswith('02_EVIDENCE_AUDIT_APPENDICES/') or x['path'] in ['EVIDENCE_INDEX.md','VERSION_AND_DELIVERY.md']]
 body_names.append('SHA256_PAYLOAD_MANIFEST.json');evidence_names.append('SHA256_PAYLOAD_MANIFEST.json')
 receipts=[]
 for label,names in [('BODY',body_names),('EVIDENCE',evidence_names)]:
  name=f'FHS-MSC_{label}_2026-10-30_STATIC-REPAIR-v1_REPAIR-INCOMPLETE.zip';zp=OUT/name
  with zipfile.ZipFile(zp,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as arc:
   for rel in sorted(names):
    data=(OUT/rel).read_bytes();info=zipfile.ZipInfo(rel,date_time=(2026,10,30,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;arc.writestr(info,data)
  with zipfile.ZipFile(zp) as arc:
   if arc.testzip() is not None:raise ValueError('ZIP_CRC')
   if len(arc.namelist())!=len(set(arc.namelist())):raise ValueError('ZIP_DUPLICATE')
   if set(arc.namelist())!=set(names):raise ValueError('ZIP_ENTRY_SET')
   for rel in names:
    raw=arc.read(rel);raw.decode('utf-8','strict')
    if raw!=(OUT/rel).read_bytes():raise ValueError('ZIP_CONTENT_MISMATCH:'+rel)
  receipts.append({'type':label,'path':str(zp.resolve()).removeprefix('\\\\?\\'),'filename':name,'files':len(names),'bytes':zp.stat().st_size,'sha256':sha(zp.read_bytes()),'zip_crc':'PASS','UTF8':'PASS','per_file_SHA_and_exact_bytes':'PASS','formal_packaging_count':1})
 result={'schema':'AUTHOR.PackageReadback/1','task_status':'REPAIR_INCOMPLETE','first_fail':'SBL-D00-L00070-C01','static_integrity_checks_pass':report['integrity_pass'],'static_integrity_checks_fail':report['integrity_fail'],'semantic_completion':'FAIL','Native':'NATIVE_NOT_RUN','Release':'NOT_RUN','payload_files':len(payload),'current_relative_links_verified':link_count,'zips':receipts,'source_roots_modified':False,'credential_included':False,'windows_delivery_root':str(OUT.resolve()).removeprefix('\\\\?\\'),'python':sys.version,'platform':platform.platform()}
 dump(OUT/'PACKAGE_READBACK.json',result)
 selected=[OUT/r['filename'] for r in receipts]+[OUT/x for x in ['INDEX.md','EVIDENCE_INDEX.md','VERSION_AND_DELIVERY.md','SHA256_PAYLOAD_MANIFEST.json','PACKAGE_READBACK.json']]
 lines=['# 交付 SHA-256','', '文件狀態：REPAIR_INCOMPLETE；Native=NATIVE_NOT_RUN；Release=NOT_RUN。','', '| File | bytes | SHA-256 |','|---|---:|---|']
 for p in selected:lines.append(f'| {p.name} | {p.stat().st_size} | `{sha(p.read_bytes())}` |')
 lines+=['','本表依構造排除自身；payload manifest亦不列自身。兩ZIP各封裝一次、逐檔CRC/UTF8/SHA/bytes讀回通過。'];(OUT/'SHA256_DELIVERY_MANIFEST.md').write_text('\n'.join(lines)+'\n',encoding='utf-8',newline='\n')
 print(json.dumps(result,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
