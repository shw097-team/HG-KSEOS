from discover import *
from probe_repos import M
import unicodedata
def norm(t):return ''.join(c.casefold() for c in unicodedata.normalize('NFKC',t) if c.isalnum())
def main():
 h=OUT/'02_EVIDENCE_AUDIT_APPENDICES/HISTORICAL_R2_READONLY/_machine';mapping=json.loads((M/'CURRENT_READER_LOCATORS_2221.json').read_text(encoding='utf-8'));by={(r['group'],r['id']):r for r in mapping};cache={};checks=[];patched=[]
 datasets=[('R15','BASELINE_r15_atoms949.json','id',['negative','negative_fixture']),('Child','BASELINE_children149.json','id',['negative_mutation']),('Cell','BASELINE_cells192.json','id',['negative']),('B1Edge','BASELINE_b1_edges31.json','pd_slot_id',['neg']),('B1Case','BASELINE_b1_case_specs.json','case_id',['negative_fixture','negative']),('ACEdge','BASELINE_acceptance_edges15.json','edge_id',['negative_mutation']),('Oracle96','BASELINE_challenge96.json','case_id',['negative_fixture','negative']),('WorkPackage',None,'id',['negative'])]
 for group,file,idkey,fields in datasets:
  records=json.loads((h/file if file else M/'WORKPACKAGE_22_CONSTRUCTION_CONTRACTS.json').read_text(encoding='utf-8'))
  for rec in records:
   ident=rec.get(idkey)
   if group=='Cell':ident='CELL-'+ident
   if group=='B1Edge':ident='EDGE-'+rec['slot_id']
   row=by.get((group,ident))
   if not row:continue
   path=row['path']
   if path not in cache:cache[path]=(OUT/path).read_text(encoding='utf-8')
   anchor=f'<a id="{row["anchor"]}"></a>'
   start=cache[path].index(anchor);end=cache[path].find('<a id="current-',start+len(anchor));end=len(cache[path]) if end<0 else end
   block=cache[path][start:end]
   for field in fields:
    value=rec.get(field)
    if not isinstance(value,str) or not value.strip():continue
    exists=norm(value) in norm(block);checks.append({'group':group,'id':ident,'field':field,'original_negative':value,'current_retained':True,'already_present_before_repair':exists})
    if not exists:
     addition='\n- **原 NEG 本版有效保留**：'+value+'\n';cache[path]=cache[path][:end]+addition+cache[path][end:];end+=len(addition);block+=addition;patched.append({'group':group,'id':ident,'field':field})
 for path,text in cache.items():(OUT/path).write_text(text,encoding='utf-8',newline='\n')
 dump(M/'ORIGINAL_NEGATIVE_RETENTION_ALL_RECORDS.json',checks);dump(M/'ORIGINAL_NEGATIVE_DIRECT_REPAIRS.json',patched)
 for r in mapping:
  p=OUT/r['path'];data=p.read_bytes();r['sha256']=sha(data);r['line']=data.decode('utf-8').splitlines().index(f'<a id="{r["anchor"]}"></a>')+1
 dump(M/'CURRENT_READER_LOCATORS_2221.json',mapping)
 print('original negative records checked',len(checks),'direct repairs',len(patched))
if __name__=='__main__':main()
