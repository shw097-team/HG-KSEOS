from discover import *
from probe_repos import M,run
from prepare_validation import execute
import sys
if __name__=='__main__':
 snap=(WORK/'pipd_workspace_snapshot').resolve()
 for i,args in enumerate([['init','-q'],['add','--','src','schemas','tests','tools','docs','fixtures','skills','pyproject.toml','LICENSE'],['-c','user.name=Static Fixture','-c','user.email=static-fixture@localhost','commit','-qm','Isolated workspace-source static baseline']]):dump(M/f'WORKSPACE_ISOLATED_GIT_{i}.json',run(['git','-C',str(snap),*args]))
 execute('PIPD_AGENT_WORKSPACE_AVAILABLE_STATIC_TESTS',[sys.executable,'-X','utf8','-B','-m','unittest','tests.test_atomic_requirements','tests.test_negative_and_rollback','tests.test_tqaep_design_positive','tests.test_s0_contracts','tests.test_s1_lite_slice','tests.test_oracle_compat','-v'],cwd=snap,extra_env={'PYTHONPATH':str(snap/'src'),'PYTHONUTF8':'1','TEMP':str((WORK/'test_tmp_utf8').resolve()),'TMP':str((WORK/'test_tmp_utf8').resolve())})
 execute('PIPD_AGENT_WORKSPACE_STATIC_COMPILE',[sys.executable,'-X','utf8','-B',str((WORK/'static_compile.py').resolve()),'--workspace'],extra_env={'PYTHONUTF8':'1'})
