from discover import *
from probe_repos import M
from use_tpm_plugin import core_module,PLUGIN
import sys,traceback
def main():
 global M
 snapshot=WORK/('pipd_workspace_snapshot' if '--workspace' in sys.argv else 'pipd_source_snapshot')
 originM=M
 if '--workspace' in sys.argv:
  M=M/'PIPD_AGENT_WORKSPACE_RUN';M.mkdir(exist_ok=True)
 sys.path.insert(0,str((snapshot/'src').resolve()))
 from pipd_ls_sp import pipeline,validate
 records=[]
 def attempt(name,fn):
  try:
   obj=fn();dump(M/(name+'.json'),obj);records.append({'step':name,'status':'STATIC_COMPILER_OUTPUT','writer':'UNMODIFIED_PIPD_SOURCE_SNAPSHOT','native':'NATIVE_NOT_RUN'});return obj
  except Exception as exc:
   records.append({'step':name,'status':'NACK','exception_type':type(exc).__name__,'first_fail':str(exc),'native':'NATIVE_NOT_RUN'});return None
 sources=[str(p).removeprefix('\\\\?\\') for p in sorted((OUT/'01_SUBSTANTIVE_BODY').glob('*.md'))]
 full=attempt('PIPD_FULL17_INTAKE',lambda:pipeline.intake('Repair all source-bound FHS-MSC current documents',sources=sources))
 if full:attempt('PIPD_FULL17_PI',lambda:pipeline.compile_pi(full,'ASSURED'))
 # A separately named bounded projection exercises the real compiler, without claiming full17 coverage.
 projection=M/'PIPD_BOUNDED_22_INPUT.md';cards=json.loads((originM/'WORKPACKAGE_22_CONSTRUCTION_CONTRACTS.json').read_text(encoding='utf-8'))
 lines=[];traces=[]
 for c in cards:
  statement=f"{c['id']} must preserve its exact source identity."
  lines.append(statement)
  lines.append(f"{c['id']} must reject {c['first_fail']}.")
  traces.append({'id':c['id'],'card_source':'WORKPACKAGE_22_CONSTRUCTION_CONTRACTS.json','projected_obligations':['preserve exact source identity','reject original first_fail'],'excluded':'Other per-card engineering semantics are NOT claimed compiled by this bounded projection.'})
 projection.write_text('\n'.join(lines)+'\n',encoding='utf-8',newline='\n');dump(M/'PIPD_BOUNDED_22_PROJECTION_TRACE.json',traces)
 card=attempt('PIPD_BOUNDED_22_INTENT',lambda:pipeline.intake('Bounded static identity and rejection projection for 22 WorkPackages',sources=[str(projection).removeprefix('\\\\?\\')]))
 pi=attempt('PIPD_BOUNDED_22_PI',lambda:pipeline.compile_pi(card,'ASSURED'))
 if pi:
  result=validate.validate_bundle({'PI-PKG':pi},(snapshot/'schemas').resolve());dump(M/'PIPD_BOUNDED_22_PI_READER_ACK.json',result)
  replay=pipeline.compile_pi(card,'ASSURED');dump(M/'PIPD_BOUNDED_22_REPLAY.json',{'same_content_hash':pi['content_hash']==replay['content_hash'],'atoms':len(pipeline.atoms_of(pi)),'source_projection':'44 explicit limited obligations; not original full-product PI'})
  pd=attempt('PIPD_ISOLATED_TEST_PD',lambda:pipeline.bind_pd(pi,{'root':str(snapshot.resolve()),'writable_scope':'src/static_repair_candidate.md'}))
  if pd:
   cc=attempt('PIPD_ISOLATED_TEST_CONSTRUCTION',lambda:pipeline.compile_construction_contract(pd));ecp=attempt('PIPD_ISOLATED_TEST_DEV_ECP',lambda:pipeline.compile_ecp(pd,pi))
   dump(M/'PIPD_ISOLATED_TEST_READER_ACK.json',validate.validate_bundle({'PD-PKG':pd,'ConstructionContract':cc,'ECP':ecp},(snapshot/'schemas').resolve()))
   attempt('PIPD_NO_RECEIPT_TQAEP',lambda:pipeline.compile_tqaep(pi,ecp,maker='AUTHOR_STATIC_REPAIR',checker='ORIGINAL_PROTECTED_CHECKER_NOT_INVOKED',checker_execution_receipt=''))
  core=core_module();atoms=[];fixtures=M/'PLANNED_TQAEP_FIXTURES';fixtures.mkdir(exist_ok=True)
  for a in pipeline.atoms_of(pi):
   rid=a['req_id'];source=a['source_clause'];cue=a['acceptance_cue'];p=fixtures/(rid+'_POS.json');n=fixtures/(rid+'_NEG.json')
   dump(p,{'requirement':rid,'source':source,'expected':cue,'observed':None,'state':'PLANNED_NOT_RUN'})
   dump(n,{'requirement':rid,'source':source,'mutation':'violate exact bound predicate: '+cue,'observed':None,'state':'PLANNED_NOT_RUN'})
   atoms.append({'req_id':rid,'source_ref':source['source_ref'],'oracle_ref':a['risk_guard']['oracle']['id'],'positive_fixture':'PLANNED_TQAEP_FIXTURES/'+p.name,'negative_fixture':'PLANNED_TQAEP_FIXTURES/'+n.name})
  planned=core.planned_tqaep(pi['content_hash'],atoms)
  import jsonschema
  schema=json.loads((PLUGIN/'schemas/sbl-tpm/PlannedTQAEP.schema.json').read_text(encoding='utf-8'));jsonschema.Draft202012Validator(schema).validate(planned)
  dump(M/'SBL_PLANNED_TQAEP_RECEIPT_FREE.json',planned);dump(M/'SBL_PLANNED_TQAEP_SCHEMA_ACK.json',{'schema_sha256':sha((PLUGIN/'schemas/sbl-tpm/PlannedTQAEP.schema.json').read_bytes()),'tests':len(atoms),'result':'SCHEMA_AND_PLUGIN_READER_PASS','live_acceptance':'NOT_RUN'})
  dump(M/'PIPD_BOUNDED_CLAIM_CEILING.json',pipeline.claim_ceiling(['PROMPT_COMPILE_PASS']))
 dump(M/'PIPD_STATIC_COMPILER_EXECUTION.json',records)
 print(json.dumps(records,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
