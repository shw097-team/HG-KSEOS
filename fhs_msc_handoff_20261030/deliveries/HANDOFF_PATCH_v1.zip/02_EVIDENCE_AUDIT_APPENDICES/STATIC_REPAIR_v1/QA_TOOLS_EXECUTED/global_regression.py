from discover import *
from probe_repos import M
from use_tpm_plugin import core_module
from normalize_locators import marker_pattern
from retain_original_negatives import norm
from markdown_it import MarkdownIt
from urllib.parse import unquote,urlsplit
from collections import Counter
import sys,platform,copy,time
H=OUT/'02_EVIDENCE_AUDIT_APPENDICES/HISTORICAL_R2_READONLY/_machine'
def ld(p):return json.loads(p.read_text(encoding='utf-8'))
def need(ok,code):
 if not ok:raise AssertionError(code)
def main():
 start=time.perf_counter();results=[];body=OUT/'01_SUBSTANTIVE_BODY';cache={}
 def test(name,fn,kind='INTEGRITY'):
  try:d=fn();results.append({'test':name,'class':kind,'status':'PASS','detail':d})
  except Exception as exc:results.append({'test':name,'class':kind,'status':'FAIL','detail':str(exc)})
 def docs():
  expected={'00','01','02','03','04','05','06','07','08','09','09A','09B','10','10A','10B','11','12'}
  files=list(body.glob('*.md'));need({p.name.split('_')[0] for p in files}==expected,'17_BOOK_EXACT_SET')
  need(len(list((body/'SBL_DOC00_13_INTEGRATED_READER_UPGRADES').glob('*.md')))==14,'SBL14')
  return {'body':17,'SBL':14}
 test('BOOK_EXACT_SETS',docs)
 def locators():
  rows=ld(M/'CURRENT_READER_LOCATORS_2221.json');ids=ld(H/'IDENTITY_SETS.json')
  for g,vs in ids.items():need({r['id'] for r in rows if r['group']==g}==set(vs),'ID_CHANGED:'+g)
  need(len(rows)==2221 and len({r['anchor'] for r in rows})==2221,'DUP_OR_LOSS')
  for r in rows:
   if r['path'] not in cache:
    p=OUT/r['path'];data=p.read_bytes();cache[r['path']]={'text':data.decode('utf-8'),'sha':sha(data),'lines':data.decode('utf-8').splitlines()}
   c=cache[r['path']];need(c['sha']==r['sha256'],'CURRENT_SHA:'+r['id']);need(c['lines'][r['line']-1]==f'<a id="{r["anchor"]}"></a>','LOCATOR_LINE:'+r['id'])
   need(marker_pattern(r['group'],r['id']).search(c['lines'][r['line']]),'LOCATOR_NOT_OWN_HEADING:'+r['id'])
   need(sum(bool(marker_pattern(r['group'],r['id']).search(x)) for x in c['lines'])==1,'SECOND_CURRENT_DEFINITION:'+r['id'])
  return {'identities':len(rows),'unique_current_anchors':2221}
 test('ALL_2221_ORIGINAL_IDS_AND_UNIQUE_CURRENT_HEADINGS',locators)
 def negatives():
  checks=ld(M/'ORIGINAL_NEGATIVE_RETENTION_ALL_RECORDS.json');rows=ld(M/'CURRENT_READER_LOCATORS_2221.json');by={(r['group'],r['id']):r for r in rows}
  for c in checks:
   r=by[(c['group'],c['id'])];text=cache[r['path']]['text'];s=text.index(f'<a id="{r["anchor"]}"></a>');e=text.find('<a id="current-',s+4);e=len(text) if e<0 else e
   need(norm(c['original_negative']) in norm(text[s:e]),'ORIGINAL_NEG_LOST:'+c['group']+':'+c['id'])
  return {'original_negative_fields':len(checks),'direct_repairs':len(ld(M/'ORIGINAL_NEGATIVE_DIRECT_REPAIRS.json'))}
 test('ORIGINAL_NEGATIVE_TEXT_CONSERVATION',negatives)
 def source_hashes():
  rows=ld(M/'SourceManifest_ALL_LOCAL.json');bad=[]
  for r in rows:
   p=Path('\\\\?\\'+r['path']);actual=sha(p.read_bytes())
   if actual!=r['sha256']:bad.append({'path':r['path'],'expected':r['sha256'],'actual':actual})
  dump(M/'FINAL_SOURCE_HASH_DIFFERENCES.json',bad);need(not bad,'SOURCE_CHANGED:'+str(len(bad)));return {'files_rehashed':len(rows),'changed':0}
 test('ALL_LOCAL_SOURCE_TEXT_BYTES_REHASHED_UNCHANGED',source_hashes)
 def repo_hashes():
  bad=[];rows=ld(M/'LOCAL_TRACKED_FULL_READ_MANIFEST.json')
  for r in rows:
   actual=sha(Path('\\\\?\\'+r['absolute_path']).read_bytes())
   if actual!=r['sha256']:bad.append({'path':r['absolute_path'],'expected':r['sha256'],'actual':actual})
  dump(M/'FINAL_LOCAL_REPO_BYTE_DIFFERENCES.json',bad);need(not bad,'LOCAL_REPO_BYTES_CHANGED');return {'files_rehashed':len(rows),'changed':0}
 test('ALL_READ_LOCAL_REPO_BLOBS_UNCHANGED',repo_hashes)
 def sources():
  raw=ld(M/'ALL_STRUCTURED_SOURCE_COORDINATES.json');need(all(r.get('file_match') and r.get('clause_match') and r.get('range_valid') for r in raw),'SOURCE_COORDINATE_DRIFT')
  return {'structured_source_coordinates':len(raw),'source_alias_gaps':dict(Counter(x['resolution'] for x in ld(M/'SOURCE_PATH_REBIND_BY_EXACT_SHA.json')))}
 test('ALL_STRUCTURED_SOURCE_COORDINATES',sources)
 def histories():
  rows=ld(M/'INPUT_R2_BODY_SHA256.json')
  for r in rows:need(sha((M/'INPUT_R2_VERBATIM'/r['path']).read_bytes())==r['sha256'],'INPUT_R2_ARCHIVE_CHANGED')
  orig=OUT/'02_EVIDENCE_AUDIT_APPENDICES/HISTORICAL_R2_READONLY/_superseded_2026-10-30_r1/SBL_DOC00_13_ORIGINAL_FULL_TEXT'
  count=sum(len(p.read_text(encoding='utf-8').splitlines()) for p in orig.glob('*.md'));need(count==75630,'SBL_ORIGINAL_LINE_LOSS')
  return {'R2_input_books':len(rows),'original_SBL_lines':count,'history':'NON_CURRENT_NAMESPACED'}
 test('HIGH_RETENTION_INPUT_BYTES_AND_ORIGINAL_SBL',histories)
 def wp():
  cards=ld(M/'WORKPACKAGE_22_CONSTRUCTION_CONTRACTS.json');core=core_module();dag={r['id']:r['depends_on'] for r in cards};r=core.affected_work(dag,[])
  need(r['order'].index('WP-FHS-17')<r['order'].index('WP-FHS-06'),'BOOTSTRAP_INVERSION')
  fields=['producer','abi_schema','consumer','input','output','effect_class','admission','positive','negative','done','evidence_expectation','rollback','resume','late_binding_contract']
  for c in cards:need(all(c.get(k) for k in fields),'WORKPACKAGE_FIELD:'+c['id'])
  return {'nodes':len(cards),'dag':'ACYCLIC','bootstrap':'CAP_BOOT_BEFORE_EFFECT','native':'NATIVE_NOT_RUN'}
 test('DAG_WORKPACKAGE_SCOPE_AUTHORITY',wp)
 def assets():
  r=ld(M/'DISPOSITIONS_69_SOURCE_RESOLVED.json');need(len(r)==69 and all(x['original_disposition'] and x['source'] and x['owner_ack'] is None for x in r),'DISPOSITION_FALSE_OWNER')
  defaults=ld(H/'R2_ASSET_SETS_PATCHED.json')['Default30'];need(all('DEFAULT' in x['original_disposition'] or 'MANDATED' in x['original_disposition'] for x in defaults),'DEFAULT_DEMOTED')
  cells=ld(H/'R2_CELLS192_SEMANTIC_UNBOUND.json');need(len(cells)==192 and all(x['host_provider_off_boolean'] is None and x['runtime_effect_allowed'] is False for x in cells),'PROVIDER_MAPPING_GUESSED');need(sum(x['host']=='DeepSeek Harness' for x in cells)==48,'HOST_RENAME')
  return {'dispositions':69,'mandatory_defaults':30,'cells':192,'DeepSeek_preserved':48,'unratified_outbound_allowed':0}
 test('TECH_DISPOSITIONS_PROVIDER_AND_HOST_GUARDS',assets)
 def schema():
  for prefix in [M,M/'PIPD_AGENT_WORKSPACE_RUN']:
   for filename in ['PIPD_BOUNDED_22_PI_READER_ACK.json','PIPD_ISOLATED_TEST_READER_ACK.json']:
    need(ld(prefix/filename)['verdict']=='PASS','ORIGINAL_VALIDATOR_NACK:'+str(prefix/filename))
   need(ld(prefix/'SBL_PLANNED_TQAEP_SCHEMA_ACK.json')['live_acceptance']=='NOT_RUN','FAKE_CHECKER')
  return 'Both original Compiler versions: bounded schema/semantic Reader ACK; full17 NACK retained; PlannedTQAEP not live acceptance'
 test('ORIGINAL_SCHEMA_AND_ADAPTER_ACKS',schema)
 def actual_neg():
  sys.path.insert(0,str((WORK/'pipd_source_snapshot/src').resolve()));from pipd_ls_sp import pipeline,validate
  pi=ld(M/'PIPD_BOUNDED_22_PI.json');bad=copy.deepcopy(pi);bad['stable_semantic_contract']['goal']='tampered';need(validate.validate_bundle({'PI-PKG':bad},(WORK/'pipd_source_snapshot/schemas').resolve())['verdict']=='FAIL','TAMPER_ACCEPTED')
  def refuses(fn):
   try:fn()
   except Exception:return True
   return False
  core=core_module();need(refuses(lambda:core.affected_work({'A':['B'],'B':['A']},[])),'CYCLE_ACCEPTED');need(refuses(lambda:core.read_contained(M,'../outside')),'TRAVERSAL_ACCEPTED');need(refuses(lambda:pipeline.compile_tqaep(pi,ld(M/'PIPD_ISOLATED_TEST_DEV_ECP.json'),maker='Maker',checker=' maker ',checker_execution_receipt='')),'MAKER_SELF_ACCEPTED')
  return 'Real original Readers rejected PI tamper, cycle, traversal and self-checker; no fixture gate used as live proof'
 test('ORIGINAL_READER_NEGATIVE_MUTATIONS',actual_neg)
 def utf8_links():
  files=list(body.rglob('*.md'))+[OUT/'INDEX.md',OUT/'COVERAGE_REPORT.md',OUT/'REPAIR_CLOSURE_REPORT.md']+list((OUT/'02_EVIDENCE_AUDIT_APPENDICES').glob('1*.md'));links=[];bad=[]
  for p in files:
   text=p.read_bytes().decode('utf-8','strict');tokens=MarkdownIt().parse(text)
   for tok in tokens:
    for child in tok.children or []:
     if child.type!='link_open':continue
     dest=child.attrGet('href')
     if not dest or re.match(r'^[A-Za-z][A-Za-z0-9+.-]*:',dest):continue
     url=urlsplit(dest);target=(p.parent/unquote(url.path)).resolve() if url.path else p.resolve();good=target.exists();links.append({'file':str(p.relative_to(OUT)),'target':dest,'exists':good})
     if not good:bad.append(links[-1])
  dump(M/'FINAL_CURRENT_LINK_READBACK.json',links);need(not bad,'BROKEN_CURRENT_RELATIVE_LINKS:'+str(len(bad)))
  # All written deliverable text files, including historical bytes, must remain strict UTF-8.
  n=0
  for p in OUT.rglob('*'):
   if p.is_file() and p.suffix.lower() in ['.md','.json','.jsonl','.py','.txt','.sha256','.tsv']:
    p.read_bytes().decode('utf-8','strict');n+=1
  return {'current_relative_links':len(links),'broken':0,'UTF8_files':n,'history_links':'ORIGINAL_NON_CURRENT_BYTES_NOT_REWRITTEN'}
 test('UTF8_AND_CURRENT_RELATIVE_LINKS',utf8_links)
 def secret():
  key=Path(r'C:\Projects\Agent_Workspace\API KEY\GITHUB-REPO_SHW097-4.txt').read_text(encoding='utf-8-sig').strip();found=re.findall(r'(?:github_pat_[A-Za-z0-9_]+|gh[pousr]_[A-Za-z0-9]+)',key);token=(found[0] if found else key).encode();n=0
  for p in OUT.rglob('*'):
   if p.is_file():need(token not in p.read_bytes(),'CREDENTIAL_IN_DELIVERABLE');n+=1
  return {'files':n,'specified_credential_occurrences':0}
 test('SPECIFIED_CREDENTIAL_NOT_IN_DELIVERABLE',secret)
 test('AUTHOR_SEMANTIC_COMPLETION',lambda:need(not ld(M/'FIRST_AUTHOR_FAILURE.json'),'AUTHOR_COMPOUND_SUBITEM_CONTRACT_INCOMPLETE:SBL-D00-L00070-C01'),'COMPLETION')
 report={'scope':'ONCE_FINAL_GLOBAL_AUTHOR_SIDE_REGRESSION','python':sys.version,'platform':platform.platform(),'command':[sys.executable,'-B',str(Path(__file__).resolve())],'checks':results,'integrity_pass':sum(r['status']=='PASS' for r in results if r['class']=='INTEGRITY'),'integrity_fail':sum(r['status']=='FAIL' for r in results if r['class']=='INTEGRITY'),'completion':'REPAIR_INCOMPLETE','first_author_failure':'SBL-D00-L00070-C01','native':'NATIVE_NOT_RUN','release':'NOT_RUN','elapsed_seconds':time.perf_counter()-start}
 dump(M/'FINAL_GLOBAL_REGRESSION.json',report)
 print(json.dumps(report,ensure_ascii=False,indent=2));return 1 if any(x['status']=='FAIL' for x in results) else 0
if __name__=='__main__':sys.exit(main())
