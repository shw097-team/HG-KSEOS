from discover import *
from probe_repos import M
def marker_pattern(group,ident):
 key=(group+':'+ident) if group in ['Native20','Default30','Donor24','Method25','TECH386'] else 'CHILD-'+ident if group=='Child' else ('CELL-'+ident if group=='Cell' and not ident.startswith('CELL-') else 'EDGE-'+ident if group=='B1Edge' and not ident.startswith('EDGE-') else ident)
 return re.compile(r'^#{2,6}\s+(?:\d+\.\d+\s+)?'+re.escape(key)+r'(?=\s|[｜|:]|$)')
def main():
 rows=json.loads((M/'CURRENT_READER_LOCATORS_2221.json').read_text(encoding='utf-8'));grouped={};removed=[];new=[]
 for r in rows:grouped.setdefault(r['path'],[]).append(r)
 for path,rs in grouped.items():
  p=OUT/path;t=re.sub(r'^<a id="current-[a-f0-9]+"></a>\n','',p.read_text(encoding='utf-8'),flags=re.M);lines=t.splitlines();remove=set();anchors={}
  for r in rs:
   pat=marker_pattern(r['group'],r['id']);matches=[i for i,x in enumerate(lines) if pat.search(x)]
   if not matches:raise ValueError('NO_EXACT_CARD_HEADING:'+r['group']+':'+r['id'])
   for dup in matches[1:]:
    level=len(lines[dup])-len(lines[dup].lstrip('#'));end=dup+1
    while end<len(lines):
     if re.match(r'^#{1,'+str(level)+r'} ',lines[end]):break
     end+=1
    removed.append({'group':r['group'],'id':r['id'],'path':path,'text':'\n'.join(lines[dup:end]),'reason':'SECOND_CURRENT_DEFINITION_SUPERSEDED_BY_FIRST_R2_REPAIRED_CARD'})
    remove.update(range(dup,end))
   i=matches[0];anchors[i]=r
  result=[]
  for i,line in enumerate(lines):
   if i in remove:continue
   if i in anchors:
    r=anchors[i];result.append(f'<a id="{r["anchor"]}"></a>');new.append(r)
   result.append(line)
  p.write_text('\n'.join(result)+'\n',encoding='utf-8',newline='\n')
 for r in new:
  p=OUT/r['path'];ls=p.read_text(encoding='utf-8').splitlines();r['line']=ls.index(f'<a id="{r["anchor"]}"></a>')+1;r['sha256']=sha(p.read_bytes())
 dump(M/'CURRENT_READER_LOCATORS_2221.json',new);dump(M/'DUPLICATE_CURRENT_CARDS_MOVED_TO_INERT_EVIDENCE.json',removed)
 print('exact current headings',len(new),'removed duplicate current cards',len(removed))
if __name__=='__main__':main()
