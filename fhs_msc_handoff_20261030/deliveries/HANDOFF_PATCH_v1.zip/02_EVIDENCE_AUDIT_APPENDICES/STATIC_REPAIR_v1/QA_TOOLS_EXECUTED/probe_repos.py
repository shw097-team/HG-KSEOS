from discover import *
import subprocess, os, concurrent.futures
E=OUT/'02_EVIDENCE_AUDIT_APPENDICES'
M=E/'STATIC_REPAIR_v1';M.mkdir(exist_ok=True)
REPOS={'HG-KSEOS':r'C:\Projects\Agent_Workspace\HG-KSEOS','SBL':r'C:\Projects\Agent_Workspace\SBL','Fabric':r'C:\Projects\Agent_Workspace\Fabric','PIPD-LS-SP':r'C:\Projects\pipd-ls-sp','PIPD-worktree':r'C:\Projects\Agent_Workspace\PIPD'}
def run(args):
 env=dict(os.environ,GIT_OPTIONAL_LOCKS='0',GIT_TERMINAL_PROMPT='0',PYTHONDONTWRITEBYTECODE='1',PYTHONIOENCODING='utf-8')
 try:
  r=subprocess.run(args,capture_output=True,timeout=45,env=env)
  return {'command':args,'exit_code':r.returncode,'stdout':r.stdout.decode('utf-8','replace'),'stderr':r.stderr.decode('utf-8','replace')}
 except Exception as e:return {'command':args,'exit_code':None,'stdout':'','stderr':str(e)}
def probe(item):
 name,root=item;prefix=['git','-c','core.quotePath=false','-C',root];d={'name':name,'root':root}
 for key,args in {'HEAD':['rev-parse','HEAD'],'index':['ls-files','--stage'],'status':['status','--porcelain=v2','--branch','--untracked-files=all'],'staged':['diff','--cached','--name-status'],'unstaged':['diff','--name-status'],'origin_main':['rev-parse','refs/remotes/origin/main']}.items():d[key]=run(prefix+args)
 if name!='PIPD-worktree':d['remote_main']=run(['git','-c','credential.helper=','ls-remote',f'https://github.com/shw097-team/{name}.git','refs/heads/main'])
 dump(M/(name+'_repo_readback.json'),d)
 return {'name':name,'HEAD':d['HEAD']['stdout'].strip(),'status_exit':d['status']['exit_code'],'status_lines':len(d['status']['stdout'].splitlines()),'remote_main':d.get('remote_main',{})}
if __name__=='__main__':
 with concurrent.futures.ThreadPoolExecutor(max_workers=5) as pool: print(json.dumps(list(pool.map(probe,REPOS.items())),ensure_ascii=False))
