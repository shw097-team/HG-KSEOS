from discover import *
from probe_repos import M,REPOS
from collections import Counter
from markdown_it import MarkdownIt
import ast
B=OUT/'01_SUBSTANTIVE_BODY';E=OUT/'02_EVIDENCE_AUDIT_APPENDICES';MACH=E/'_machine'
def ld(p):return json.loads(p.read_text(encoding='utf-8'))
def put(p,t):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(t.strip()+'\n',encoding='utf-8',newline='\n')
def main():
 inv=ld(M/'SourceManifest_ALL_LOCAL.json');bysha={}
 for r in inv:bysha.setdefault(r['sha256'],[]).append(r['path'])
 original=ld(MACH/'BASELINE_source_manifest.json');reb=[]
 for r in original:
  old=r['path'];p=Path(old)
  if p.exists():state='ORIGINAL_PATH_PRESENT';paths=[old]
  elif r['sha256'] in bysha:state='EXACT_BYTES_RELOCATED';paths=bysha[r['sha256']]
  else:state='SOURCE_NOT_FOUND_BY_SHA';paths=[]
  reb.append({'original_path':old,'expected_sha256':r['sha256'],'resolution':state,'actual_paths':paths})
 dump(M/'SOURCE_PATH_REBIND_BY_EXACT_SHA.json',reb)
 # Author-side semantic debts are separated from lawful external evidence gaps.
 atoms=ld(MACH/'R2_SBL_COMPOUND_ATOMIZATION.json');generic=[a for a in atoms if '包含本片段逐字可對照' in a.get('POS','')]
 first=generic[0]
 failure={'status':'REPAIR_INCOMPLETE','first_fail':'AUTHOR_COMPOUND_SUBITEM_CONTRACT_INCOMPLETE','id':first['id'],'source_text':first['source_text'],'source_original_sha':first['source_original_sha'],'source_line_claim':first['line'],'observed_output_contract':first['output_contract'],'observed_POS':first['POS'],'observed_NEG':first['NEG'],'reason':'原條文列出 FUO 必報的 persona/clean_start/source_sha/selected_path/first_useful_output/elapsed_ms/questions_reasked/error_count/provider_off/consumer_acceptance；既有 SourceDecision 通用候選未逐欄給原義、專屬 Consumer、操作及專屬 POS/NEG。這是作者可由來源修補的缺陷，不能改標 Owner HOLD。','affected':'SBL 14 current upgrade books semantic compound contracts; full PI source adapter','generic_POS_records_measured':len(generic),'compound_candidates_measured':len(atoms),'native':'NATIVE_NOT_RUN','next_legal_action':'在隔離正文逐原 Parent/Child 完成全部語義展開後重編全量 input；本輪依使用者 REPAIR_INCOMPLETE 停止條件交付，不延伸 Native。'}
 dump(M/'FIRST_AUTHOR_FAILURE.json',failure)
 # Exact CLI sets from actual code, without importing repo modules or guessing active Host.
 sets={}
 for name,path in [('AGENT_WORKSPACE',Path(REPOS['PIPD-worktree'])),('OTHER_LOCAL',Path(REPOS['PIPD-LS-SP'])),('REMOTE_MAIN',WORK/'remote_main/PIPD-LS-SP/tree')]:
  p=path/'src/pipd_ls_sp/cli.py';tree=ast.parse(p.read_text(encoding='utf-8-sig'));value=None
  for n in ast.walk(tree):
   if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='COMMANDS' for t in n.targets):value=ast.literal_eval(n.value)
  sets[name]={'path':str(p.resolve()),'sha256':sha(p.read_bytes()),'commands':list(value),'count':len(value)}
 dump(M/'PIPD_CLI_VERSIONED_EXACT_SETS.json',sets)
 p=B/'02_PIPD_LIFECYCLE_AND_TPM.md';t=p.read_text(encoding='utf-8')
 t=t.replace('**原 CLI 精確 13 命令**','**遠端 main 此版 CLI 精確 13 命令**')
 t=t.replace('`compile-cc` 曾出現在別的歷史證據，**非四庫固定主線的第 14 個法定命令**；本版保持原 CLI Exact-set。','`Agent_Workspace/PIPD` 本地 HEAD `995c7ad0c69a05a0c5cf6528155a62020ce31f87` 的實作另外具有 `compile-cc`，實測 COMMANDS=14；遠端 main `f6335a94157c61da75d92121d14c43feb413e981` 為13。兩者分版本保存，不把本地14當遠端已生效契約，也不把它隱藏成不存在。')
 t+='''
## STATIC-v1 真 Compiler、版本差異與不能提高的 Claim

已使用原 `sbl-tpm-sp` corpus Reader、三 SPEC draft adapters 與 receipt-free PlannedTQAEP Reader；24 個內建基礎 DOC 的 bytes/SHA 通過。插件 StageContracts 沒有 SETUP role 條目，故不虛構 SETUP Stage ACK；Host 狀態維持 HOST_PENDING。

`C:/Projects/Agent_Workspace/PIPD` 和 `C:/Projects/pipd-ls-sp` 的 pipeline/requirements/validate 實作 SHA 不同。已各以隔離副本執行原 Compiler：17 冊完整正文 input 在 intake 以 `ambiguous compound: explicit subjects and predicates required` NACK；另列的 22 WP 之 44 條身份／拒收有限投影可編譯 PI、隔離 fixture PD、ConstructionContract、DEV ECP，均保存原 Validator ACK。這 44 條不是全產品 PI，不能代替 2,221 原身份或完整語義子項。PD 的 root 僅是本輪測試副本，不是正式四庫或 live RepoContext。

原 `compile-ecp` 所編此 fixture 是 Repo/DEV effect，不能改名 OPS grant。既有未簽 OPS ECP 保留候選與原 Owner/Host/Effect binding 差額；未看到原 OPS Compiler/Receiver 的 ACK 不宣稱已綁。無 checker receipt 的 Canonical TQAEP 呼叫正確 NACK；規劃改用插件原 `SBL.PlannedTQAEP@1`，其 fixtures 明記 PLANNED_NOT_RUN，不填假收據。

版本化測試：另一個本地 PIPD 版本的 108 項既有靜態測試通過；Agent_Workspace 版本實際可用的 71 項測試有 1 項失敗：`test_oracle_compat.OracleCompat.test_cli_exact_set_preserved` 預期13、實際14。原測試與失敗均保留，不改 Oracle 或正式 Repo 令其變綠。受影 `compile-cc` 與 CLI Exact-set 契約差異由原 PIPD Owner 決定；其他已合法的來源／設計工作不等待此決定。
'''
 put(p,t)
 # Fix legacy relative paths to the real current audit entry, not invented legacy files.
 repl={'../02_EVIDENCE_APPENDICES/E01_SOURCE_MANIFEST_AND_SEARCH.md':'../02_EVIDENCE_AUDIT_APPENDICES/10_STATIC_v1_SOURCE_MANIFEST.md','../02_EVIDENCE_APPENDICES/E02_REQUIREMENT_TRACE_AND_DENOMINATORS.md':'../COVERAGE_REPORT.md','../02_EVIDENCE_APPENDICES/E03_ABI_SCHEMAS_AND_FIXTURE_AUDIT.md':'../02_EVIDENCE_AUDIT_APPENDICES/12_STATIC_v1_TESTS_AND_SCHEMA.md','../02_EVIDENCE_APPENDICES/E04_CONFLICT_RCA_ADOPTION_AND_HOLDS.md':'../REPAIR_CLOSURE_REPORT.md','../02_EVIDENCE_APPENDICES/E05_QA_READBACK_AND_CLAIM_CEILING.md':'../02_EVIDENCE_AUDIT_APPENDICES/13_STATIC_v1_CLAIM_CEILING.md'}
 for p in B.rglob('*.md'):
  t=p.read_text(encoding='utf-8')
  for a,b in repl.items():t=t.replace(a,b)
  if p.parent.name=='SBL_DOC00_13_INTEGRATED_READER_UPGRADES':
   t='<!-- version: 2026-10-30_STATIC-REPAIR-v1; current semantic acceptance: REPAIR_INCOMPLETE -->\n\n'+t
  put(p,t)
 p=B/'03_ARCHITECTURE_ABI_AND_EFFECT.md';t=p.read_text(encoding='utf-8');t+='\n## STATIC-v1 Agent_Workspace 原 PIPD 工作樹\n\n本地主要實作另有 `C:/Projects/Agent_Workspace/PIPD`，HEAD=`995c7ad0c69a05a0c5cf6528155a62020ce31f87`；其 staged/unstaged/untracked 與 `C:/Projects/pipd-ls-sp` 分別保存。原四庫來源與遠端主線不預設相等；Compiler 細節差異依本版 BODY02 的分版本契約。\n';put(p,t)
 # Recompute measured denominators from separate input records and actual source section rows.
 assets=ld(MACH/'BASELINE_asset_sets.json');r15=ld(MACH/'BASELINE_r15_atoms949.json');child=ld(MACH/'BASELINE_children149.json');cells=ld(MACH/'BASELINE_cells192.json');edges=ld(MACH/'BASELINE_b1_edges31.json');cases=ld(MACH/'BASELINE_b1_case_specs.json');oracles=ld(MACH/'BASELINE_challenge96.json');ace=ld(MACH/'BASELINE_acceptance_edges15.json');wp=ld(M/'WORKPACKAGE_22_CONSTRUCTION_CONTRACTS.json')
 counts={k:len(v) for k,v in assets.items()};counts.update(R15=len(r15),Child=len(child),Cell=len(cells),B1_PI=len({x['atom_id'] for x in edges}),B1_PD_Edge=len(edges),B1_Case=len(cases),AC_Edge=len(ace),Oracle=len(oracles),WP=len(wp))
 master=(ROOT/'FHS-MSC/FHS-MSC_總藍圖/FHS-MSC_總藍圖.md').read_text(encoding='utf-8-sig');section=master.split('### III.2',1)[1].split('## IV.',1)[0];original_rows=re.findall(r'^\|\s*(\d+)\s*\|',section,re.M)
 counts['MASTER_R15_ROWS']=len(original_rows);counts['MASTER_R15_ORDINAL_UNIQUE']=len(set(original_rows));dump(M/'MEASURED_DENOMINATORS.json',counts)
 prior=ld(MACH/'R2_AUDIT_F01_F16_RESOLUTION_MATRIX.json');new=[]
 for r in prior:
  row={**r,'prior_state_retained':True,'this_round':'PRIOR_EVIDENCE_REUSED_NO_NATIVE_PROMOTION'}
  if r['finding'] in ['F-01','F-08']:row.update(this_round='REPAIR_INCOMPLETE_AUTHOR_COMPOUND_SEMANTICS',prior_state_retained=False,counterevidence='FIRST_AUTHOR_FAILURE.json; generic POS does not implement required semantic children')
  if r['finding']=='F-04':row.update(this_round='69_SOURCE_DESIGN_DISPOSITIONS_RESOLVED_HOST_NOT_RUN',prior_state_retained=False,counterevidence='Master §IV/§V explicit values; DISPOSITIONS_69_SOURCE_RESOLVED.json')
  if r['finding']=='F-06':row.update(this_round='LOCAL_REMOTE_FULL_BLOB_ALIGNMENT_RECORDED',prior_state_retained=False,counterevidence='Local HEAD differs from all four remote main; 5 local roots separately inventoried')
  if r['finding']=='F-07':row.update(this_round='FULL_PI_INPUT_REPAIR_INCOMPLETE_BOUNDED_COMPILER_ACK_ONLY',prior_state_retained=False,counterevidence='PIPD_STATIC_COMPILER_EXECUTION.json and workspace run')
  if r['finding']=='F-10':row.update(this_round='2221_EXACT_CURRENT_LOCATORS_REPAIRED',prior_state_retained=False,counterevidence='6 old WP locators and U03.1 pointed to references; AC-E01 ranged heading; 15 duplicate current cards removed')
  if r['finding']=='F-13':row.update(this_round='EXISTING_TESTS_REPLAYED_WITH_RAW_EXIT_AND_ENV',counterevidence='R2 10/10; Revision2 2788 pass plus source-path failure; other local 108 pass; workspace 71 with 1 actual CLI failure')
  new.append(row)
 dump(M/'FINDINGS_F01_F16_CURRENT_CLOSURE.json',new)
 # The legal external gaps do not conceal remaining author defects.
 holds=[{'id':'H-HOST-MAP','class':'OWNER_DECISION_REQUIRED','owner':'Original Product/Host Owner','reader':'原 192 Cell matrix Reader','affected':'DeepSeek48→ChatGPT candidate migration only','first_fail':'HOST_MATRIX_VERSION_UNRATIFIED','next':'原 Owner 批准具版本映射；原 ID/Host readback','resume':'same version+SourceSHA approved mapping'}, {'id':'H-PROVIDER','class':'OWNER_DECISION_REQUIRED','owner':'原 Provider Policy Owner','reader':'原 Host Provider Reader','affected':'需 Provider 外呼的 legacy ON/OFF cells','first_fail':'PROVIDER_BOOLEAN_UNBOUND','next':'原 Owner 明確 token→boolean mapping','resume':'有效 PolicyEpoch+mapping receipt；不得猜外呼'}, {'id':'H-NATIVE','class':'NATIVE_EVIDENCE_REQUIRED','owner':'Fabric Policy/HGK Issuer/Hermes Runtime/Protected Checker 各原 Owner','reader':'各原 Consumer','affected':'Native effect、loaded/served、282 Case、W18、Release','first_fail':'NATIVE_NOT_RUN','next':'另輪獲准才由原 Host/Issuer/Checker 執行','resume':'各原 Subject/Scope/Case 的真收據'}, {'id':'H-CLI14','class':'OWNER_DECISION_REQUIRED','owner':'PIPD original CLI/Schema Owner','reader':'COMMANDS exact-set / test_oracle_compat','affected':'Agent_Workspace compile-cc and exact 13/14 contract only','first_fail':'EXPECTED_13_ACTUAL_14','next':'原 Owner 決定正式版本與對應契約；若改 Repo 需另獲 exact RepoWrite admission','resume':'原版本決定、對齊的 schema/reader 與原測試 ACK'}]
 dump(M/'AFFECTED_EXTERNAL_HOLDS.json',holds)
 # Current independent audit appendices, all linked to raw evidence.
 put(E/'10_STATIC_v1_SOURCE_MANIFEST.md',f'''# 本輪 SourceManifest／Authority／版本差異

本輪完整 byte decode 的本地來源文字檔：{len(inv)}；總 bytes：{sum(x['bytes'] for x in inv):,}。全文關鍵字／原 ID 掃描命令及 raw 已保存。逐來源真實 path、SHA、line、heading、Writer/Reader、supersession 見 [完整來源表](STATIC_REPAIR_v1/SourceManifest_ALL_LOCAL.json)。這是 bytes 及索引掃描，不能當全語義驗收。

四個遠端 main 已依使用者指定憑證唯讀取得完整當期檔案樹並逐 blob 讀取，共 6,464 檔；無 submodule/LFS 指標。四份 `*_remote_full_read.json` 保存每檔 SHA/大小/UTF-8 狀態；深度1只代表當期 main，未宣稱讀取全部 commit history。憑證未存入候選、ZIP 或日誌。

五個本地工作樹（含兩個不同 PIPD root）與四個遠端 main 分別核對：[逐檔差異](STATIC_REPAIR_v1/LOCAL_REMOTE_ALL_FILE_DIFFERENCES.json)、[本地 byte manifest](STATIC_REPAIR_v1/LOCAL_TRACKED_FULL_READ_MANIFEST.json)、[精確差額](STATIC_REPAIR_v1/LOCAL_READ_EXACT_GAPS.json)。本地 untracked 的全部 path/status 已保存；其下未全部逐 byte 讀取，不冒稱完整語義分母。原 Gitlink fixture 子樹與個別敏感檔名差額按表列出，不擴 scope 追入其他庫。

1694 個結構化來源座標已逐個重算 file SHA/line slice SHA，0 file mismatch、0 clause mismatch。這些多為設計中間來源，不能替代更上位 Domain 規範。舊 Revision2 manifest 的實體路徑用相同 SHA 重綁，[重綁結果](STATIC_REPAIR_v1/SOURCE_PATH_REBIND_BY_EXACT_SHA.json) 明列搬移與仍缺來源。原 Writer／Owner／Policy／ABI 各自生效；討論、歷史 Prompt、Source data 不取得本輪指令權。

已使用 [sbl-tpm-sp](STATIC_REPAIR_v1/TPM_PLUGIN_USE_RECEIPT.json)；插件內建 SBL14/PIPD10 由原 `corpus_manifest/read_clause` 驗 SHA。原 Plugin HOST_PENDING 不藉 Python adapter 呼叫提高。
''')
 put(OUT/'COVERAGE_REPORT.md','# 原身份、分母與語義覆蓋\n\n| 集合 | 原資料重算數 |\n|---|---|\n'+'\n'.join(f'| {k} | {v} |' for k,v in counts.items())+f'''\n\n以上集合正交，不能相加成驗收百分比。17 主冊與14 SBL 升級冊現存；[2221 唯一 Current Reader](02_EVIDENCE_AUDIT_APPENDICES/STATIC_REPAIR_v1/CURRENT_READER_LOCATORS_2221.json) 由真實標題與 anchor 重建。保留原八 Kind、三 Mode、四 Host，DeepSeek48 不改名。三 SPEC 已由插件實際 materialize，但僅設計候選。

R2 的 {len(atoms)} 筆量詞候選中，量測 {len(generic)} 筆 POS 使用同類通用文字，尚未完成全部專屬子項施工契約；第一作者端失敗為 `{first['id']}`，詳 [第一失敗](02_EVIDENCE_AUDIT_APPENDICES/STATIC_REPAIR_v1/FIRST_AUTHOR_FAILURE.json)。本輪不能宣稱全量語義覆蓋或全量 PI 編譯。原 Negative、原原文與既有可用卡保留，不因未驗收而刪除。
''')
 put(OUT/'REPAIR_CLOSURE_REPORT.md','''# 修補與 Findings Closure

**任務結果：REPAIR_INCOMPLETE。** 本輪有實質正文修補及可讀回交付；仍存在可由來源修補的作者端量詞子項缺陷，依使用者停止條件如實交付後停止。

已直接改寫：69 筆處置、18 Stage source-bound 契約、22 WP 的 Producer/ABI/Consumer/Input/Output/Effect/WriteSet/Admission/POS/NEG/Done/Evidence/Rollback/Resume；恢復29個未受影實質條文；修正本地／遠端等同前提、Provider token 推測映射、7個非卡片 Locator、AC range locator 與15個重複當期定義。全部當期原身份有唯一 anchor，歷史原檔逐 bytes 保留於證據。

F-01～F-16 [逐 Finding 狀態、反證與修補](02_EVIDENCE_AUDIT_APPENDICES/STATIC_REPAIR_v1/FINDINGS_F01_F16_CURRENT_CLOSURE.json)；不將過去設計 closure 自動提升為 Native。第一失敗與尚未修補原因見 [FIRST_AUTHOR_FAILURE](02_EVIDENCE_AUDIT_APPENDICES/STATIC_REPAIR_v1/FIRST_AUTHOR_FAILURE.json)。此缺陷不是外部 Owner 缺口，不能改名 HOLD 掩蓋。

來源能解決的69筆 disposition 已落成明確設計值。Host／Policy／ABI 尚缺的正式綁定見 [受影外部缺口](02_EVIDENCE_AUDIT_APPENDICES/STATIC_REPAIR_v1/AFFECTED_EXTERNAL_HOLDS.json)；每項有原 Owner/Reader、第一失敗、下一合法動作、恢復條件。未造第二 Queue、Scheduler、Issuer、Checker 或 Canonical Writer；合法 READY source/draft 不等 Live Receipt。
''')
 put(E/'11_STATIC_v1_REPO_AND_HOST_DELTAS.md','''# Repo／Host 差額

本地 HG-KSEOS/SBL/Fabric/PIPD-worktree 的真實 Git 狀態與另一個 PIPD-LS-SP checkout 分別存於 `STATIC_REPAIR_v1/*_repo_readback.json`，包括 HEAD、index、staged、unstaged、全部 untracked path；沒有 reset/clean/checkout/fetch/push。遠端 main 只讀 shallow snapshot，不寫遠端。工作樹未提交內容沒有套用修補。

PIPD primary workspace CLI=14，remote main=13；完整命令集合與 source SHA 見 [版本表](STATIC_REPAIR_v1/PIPD_CLI_VERSIONED_EXACT_SETS.json)。原 workspace 既有 exact13 測試失敗保留。四庫正式 Host Loaded、Fabric active-consumed、HGK Permit、Hermes WorkID/lease/world effect、different-principal Checker、Publisher Receipt 均未在本輪執行；保持 NATIVE_NOT_RUN / CHECKER_NOT_RUN / RELEASE_NOT_RUN。

TPM plugin 24 DOC physical integrity PASS；SELECTED/LOCAL_PACKAGE_PRESENT/BOUND_TO_THIS_DRAFT/PYTHON_ADAPTER_INVOKED 與 HOST_PENDING 分列。包裝或 adapter 函數執行不能表示 Host 真載入。`SETUP` role 在該插件 StageContracts 中不存在，已記差額而不發假 Stage ACK。
''')
 put(E/'12_STATIC_v1_TESTS_AND_SCHEMA.md','''# 原測試、Schema、DAG／NEG 與 QA Raw

所有測試限作者端靜態。原 R2 replay 10/10、Revision2 原 validate 2788 PASS/1 FAIL（source path readback），原始失敗不抹；路徑搬移可用 exact SHA 重綁，不等於文字被改。另一個本地 PIPD 副本在 UTF8/Git fixture 正確設定後，108項原測試 PASS。Agent_Workspace 版本71項原可用測試有1 FAIL（CLI預期13、實際14）；前次缺測試模組與環境失敗的 raw 亦保留。

命令、cwd、Python、exit、elapsed、stdout/stderr SHA 見 `STATIC_REPAIR_v1/*.receipt.json`；原 stdout/stderr 在同目錄。兩個原 Compiler 均對全17冊 intake NACK；22 WP 的44條有限身份／拒收投影成功，原 Schema/semantic validator ACK 保存，不能冒全產品 PI。無 checker receipt 的 TQAEP 正確拒收；原插件 PlannedTQAEP schema/readback PASS 只代表計畫。

22 WP 原依賴圖以插件 `affected_work` 重算無環，CAP-BOOT 在首 effect 前。當期 effect/authority 欄逐卡明列；WriteSet 只在隔離文稿為有限輸出，Native 卡使用原 Owner/Receiver 的具名晚綁程序。Final global regression 重查原身份、locators、UTF8、連結、source hash、schema、DAG 及原 negative 守恆，結果單獨列狀態，不蓋過語義作者缺陷。
''')
 put(E/'13_STATIC_v1_CLAIM_CEILING.md','''# HOLD／ClaimCeiling／停止

文件修補總狀態 **REPAIR_INCOMPLETE**。不以 author fixture、數量、manifest、SourceSHA、schema shape 或本地封裝宣告 Native accepted。作者端物理／結構回歸結果與任務語義完成度分列。

第一失敗：`AUTHOR_COMPOUND_SUBITEM_CONTRACT_INCOMPLETE / SBL-D00-L00070-C01`。尚需按原 Parent/Child 的每個語義子項完成專屬 Consumer/operation/POS/NEG/NoFit/exit/recovery，以及完整 PI input projection；不能以共用 SourceDecision 模板取代。這是 REPAIR_INCOMPLETE，並非合法外部 HOLD。

合法外部缺口只影響對應子圖：[AFFECTED_EXTERNAL_HOLDS](STATIC_REPAIR_v1/AFFECTED_EXTERNAL_HOLDS.json)。Native=`NATIVE_NOT_RUN`；Independent Checker=`NOT_RUN`；Release=`NOT_RUN`。本輪無四庫變更、Skill部署、Native effect、Permit簽發或發布。兩 ZIP 讀回結束後停止，不無期限擴展施工。
''')
 names=sorted(p.name for p in B.glob('*.md'));put(OUT/'INDEX.md','''# FHS-MSC 靜態修補交付 v1

**REPAIR_INCOMPLETE**；Native=`NATIVE_NOT_RUN`；Release=`NOT_RUN`。此為隔離作者端候選，尚未完成全量語義修補。請先讀 [修補／第一失敗](REPAIR_CLOSURE_REPORT.md)、[實測覆蓋](COVERAGE_REPORT.md)、[來源與版本](02_EVIDENCE_AUDIT_APPENDICES/10_STATIC_v1_SOURCE_MANIFEST.md)、[測試](02_EVIDENCE_AUDIT_APPENDICES/12_STATIC_v1_TESTS_AND_SCHEMA.md)、[ClaimCeiling](02_EVIDENCE_AUDIT_APPENDICES/13_STATIC_v1_CLAIM_CEILING.md)。

17 冊當期實質正文：

'''+'\n'.join(f'- [{n}](01_SUBSTANTIVE_BODY/{n})' for n in names)+'''

原 SBL14 升級內容完整保留於 `01_SUBSTANTIVE_BODY/SBL_DOC00_13_INTEGRATED_READER_UPGRADES`。正文 ZIP 與證據 ZIP 請解壓至同一目錄，再使用相對連結。Index／版本／SHA Manifest／封裝讀回報告另置於交付根目錄；未提供或宣稱網路下載連結。
''')
 # Update line/SHA locators after all substantive edits; invariant test will verify again.
 mapping=ld(M/'CURRENT_READER_LOCATORS_2221.json');cache={}
 for r in mapping:
  if r['path'] not in cache:
   p=OUT/r['path'];cache[r['path']]=(p.read_text(encoding='utf-8').splitlines(),sha(p.read_bytes()))
  ls,dg=cache[r['path']];r['line']=ls.index(f'<a id="{r["anchor"]}"></a>')+1;r['sha256']=dg
 dump(M/'CURRENT_READER_LOCATORS_2221.json',mapping)
 print(json.dumps({'original_manifest_records':len(reb),'source_rebind':dict(Counter(r['resolution'] for r in reb)),'measured':counts,'generic_compound_records':len(generic),'first_fail':first['id'],'status':'REPAIR_INCOMPLETE'},ensure_ascii=False))
if __name__=='__main__':main()
