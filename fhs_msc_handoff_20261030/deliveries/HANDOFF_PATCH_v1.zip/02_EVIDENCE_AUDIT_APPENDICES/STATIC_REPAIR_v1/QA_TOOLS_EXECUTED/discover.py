from pathlib import Path
import json, hashlib, zipfile, shutil, re
ROOT=Path(r'\\?\C:\Projects\Agent_Workspace\知識庫\實作相關DOC\Fabric vNext\Semantic World OS Fabric\SBL_PIPD')
PKG=ROOT/'FHS-MSC/FHS-MSC_PIPD-LS-PKG'
R2=PKG/'FHS-MSC_PIPD-LS-PKG_DELIVERY_2026-10-30_R2'
REV=PKG/'SKELETON_SPINE/FHS-MSC_PIPD-LS-PKG_SKELETON_SPINE_REPAIRED_2026-10-29_r2-revision2'
OUT=Path('\\\\?\\'+str(Path('outputs/FHS-MSC_STATIC_REPAIR_2026-10-30_v1').resolve()))
WORK=Path('work')
def sha(b):return hashlib.sha256(b).hexdigest()
def dump(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding='utf-8')
if __name__=='__main__':
 OUT.mkdir(parents=True,exist_ok=True)
 shutil.copytree(R2/'01_SUBSTANTIVE_BODY',OUT/'01_SUBSTANTIVE_BODY',dirs_exist_ok=True)
 for z in R2.glob('*.zip'):
  with zipfile.ZipFile(z) as arc:
   infos=arc.infolist()
   dump(WORK/(z.stem+'_inventory.json'),[{'name':i.filename,'size':i.file_size} for i in infos])
   for i in infos:
    dest=(OUT/i.filename).resolve()
    if not dest.is_relative_to(OUT.resolve()):raise ValueError(i.filename)
   arc.extractall(OUT)
 inventory=[];errors=[]
 for p in ROOT.rglob('*'):
  if not p.is_file() or p.suffix.lower() not in {'.md','.json','.jsonl','.tsv','.yaml','.yml','.py','.txt'}:continue
  if re.search(r'(?i)(api.?key|token|secret|credential)',p.name):continue
  try:
   b=p.read_bytes();t=b.decode('utf-8-sig')
   inventory.append({'path':str(p),'relative':str(p.relative_to(ROOT)),'bytes':len(b),'sha256':sha(b),'lines':len(t.splitlines()),'headings':[{'line':n,'heading':s} for n,s in enumerate(t.splitlines(),1) if re.match('^#{1,6} ',s)]})
  except Exception as e:errors.append({'path':str(p),'error':str(e)})
 dump(WORK/'source_inventory.json',inventory);dump(WORK/'read_errors.json',errors)
 print(json.dumps({'files_full_byte_decoded':len(inventory),'bytes':sum(x['bytes'] for x in inventory),'errors':errors,'out':str(OUT.resolve()),'evidence_files':len(list(OUT.rglob('*')))},ensure_ascii=False))
