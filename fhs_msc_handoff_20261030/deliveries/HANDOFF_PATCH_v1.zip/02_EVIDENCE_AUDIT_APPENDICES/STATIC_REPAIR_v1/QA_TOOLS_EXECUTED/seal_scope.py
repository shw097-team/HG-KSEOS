from discover import *
from probe_repos import M
def main():
 e=OUT/'02_EVIDENCE_AUDIT_APPENDICES';hist=e/'HISTORICAL_R2_READONLY';hist.mkdir(exist_ok=True)
 for p in list(e.iterdir()):
  if p.name in ['_machine','_superseded_2026-10-30_r1'] or re.match(r'^0\d_.*\.md$',p.name):
   target=hist/p.name
   if not p.resolve().is_relative_to(OUT.resolve()) or not target.resolve().is_relative_to(OUT.resolve()):raise ValueError('HISTORY_MOVE_SCOPE')
   p.rename(target)
 (hist/'README_HISTORY_SCOPE.md').write_text('# 唯讀歷史 bytes archive\n\n此目錄不是本版有效 Reader。R2 manifest、mapping、test script、closure 與原文以原 bytes 保存；其中舊相對路徑、命令和候選收據只供追溯，不解析為當期契約。當期只使用 STATIC_REPAIR_v1/CURRENT_READER_LOCATORS_2221.json 與外側10–13附錄。歷史連結不改寫，以保持來源 SHA。\n',encoding='utf-8')
 for p in (OUT/'01_SUBSTANTIVE_BODY').rglob('*.md'):
  t=p.read_text(encoding='utf-8');t=t.replace('R2_CURRENT_SECTION_MAP.json','STATIC_REPAIR_v1/CURRENT_READER_LOCATORS_2221.json')
  p.write_text(t,encoding='utf-8',newline='\n')
 # Exact raw scripts as used; they ran in order before history namespacing.
 q=M/'QA_TOOLS_EXECUTED';q.mkdir(exist_ok=True)
 for p in WORK.glob('*.py'):(q/p.name).write_bytes(p.read_bytes())
 dump(e/'CURRENT_READER_SCOPE.json',{'current_main':'../01_SUBSTANTIVE_BODY/*.md','current_sbl':'../01_SUBSTANTIVE_BODY/SBL_DOC00_13_INTEGRATED_READER_UPGRADES/*.md','current_map':'STATIC_REPAIR_v1/CURRENT_READER_LOCATORS_2221.json','current_audit':['10_STATIC_v1_SOURCE_MANIFEST.md','11_STATIC_v1_REPO_AND_HOST_DELTAS.md','12_STATIC_v1_TESTS_AND_SCHEMA.md','13_STATIC_v1_CLAIM_CEILING.md'],'history_roots':['HISTORICAL_R2_READONLY','STATIC_REPAIR_v1/INPUT_R2_VERBATIM'],'history_semantics':'READ_ONLY_BYTES_NEVER_CURRENT_LOCATOR','claim':'REPAIR_INCOMPLETE'})
 # Refresh final source/anchor digests after the scope correction.
 mapping=json.loads((M/'CURRENT_READER_LOCATORS_2221.json').read_text(encoding='utf-8'));cache={}
 for r in mapping:
  if r['path'] not in cache:
   p=OUT/r['path'];cache[r['path']]=(p.read_text(encoding='utf-8').splitlines(),sha(p.read_bytes()))
  ls,dg=cache[r['path']];r['line']=ls.index(f'<a id="{r["anchor"]}"></a>')+1;r['sha256']=dg
 dump(M/'CURRENT_READER_LOCATORS_2221.json',mapping)
 print('Historical R2 physically namespaced; current map rehashed; executed scripts preserved')
if __name__=='__main__':main()
