from discover import *
from probe_repos import M
import os, subprocess, base64, tarfile, concurrent.futures, io, time
KEYFILE=Path(r'C:\Projects\Agent_Workspace\API KEY\GITHUB-REPO_SHW097-4.txt')
def main():
 raw=KEYFILE.read_text(encoding='utf-8-sig').strip()
 found=re.findall(r'(?:github_pat_[A-Za-z0-9_]+|gh[pousr]_[A-Za-z0-9]+)',raw)
 token=found[0] if found else raw if '\n' not in raw and len(raw)>20 else None
 if not token:raise RuntimeError('CREDENTIAL_FORMAT_UNRESOLVED_WITHOUT_DISCLOSURE')
 env=dict(os.environ,GIT_TERMINAL_PROMPT='0',GIT_OPTIONAL_LOCKS='0',GIT_CONFIG_COUNT='2',GIT_CONFIG_KEY_0='http.https://github.com/.extraheader',GIT_CONFIG_VALUE_0='AUTHORIZATION: basic '+base64.b64encode(('x-access-token:'+token).encode()).decode(),GIT_CONFIG_KEY_1='credential.helper',GIT_CONFIG_VALUE_1='')
 def cmd(args,timeout=300):
  s=time.perf_counter();r=subprocess.run(args,env=env,capture_output=True,timeout=timeout)
  err=r.stderr.decode('utf-8','replace').replace(token,'[REDACTED]')
  return r,{'command':args,'exit_code':r.returncode,'stderr':err,'elapsed_seconds':time.perf_counter()-s}
 def repo(name):
  base=WORK/'remote_main'/name;bare=base/'objects.git';base.mkdir(parents=True,exist_ok=True)
  if bare.exists():
   clone={'command':['REUSE_EXISTING_READONLY_CLONE',str(bare.resolve())],'exit_code':0};r=type('R',(),{'returncode':0})()
  else:r,clone=cmd(['git','clone','--bare','--depth','1','--single-branch','--branch','main',f'https://github.com/shw097-team/{name}.git',str(bare.resolve())])
  if r.returncode:dump(M/(name+'_remote_full_read.json'),{'clone':clone});return {'repo':name,'clone':r.returncode}
  head,_=cmd(['git',f'--git-dir={bare.resolve()}','rev-parse','HEAD'])
  archive,receipt=cmd(['git',f'--git-dir={bare.resolve()}','archive','--format=tar','HEAD'])
  files=[];special=[];text_bytes=0;binary_bytes=0
  if archive.returncode==0:
   with tarfile.open(fileobj=io.BytesIO(archive.stdout),mode='r:') as arc:
    for ent in arc:
     if ent.isdir():continue
     if not ent.isfile():special.append({'path':ent.name,'type':ent.type.decode('ascii','replace'),'linkname':ent.linkname});continue
     b=arc.extractfile(ent).read();rel=Path(ent.name);dest=(base/'tree'/rel).resolve()
     if not dest.is_relative_to((base/'tree').resolve()):raise RuntimeError('ARCHIVE_PATH_ESCAPE')
     dest=Path('\\\\?\\'+str(dest));dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
     try:t=b.decode('utf-8-sig');decoded=True;text_bytes+=len(b)
     except UnicodeError:decoded=False;binary_bytes+=len(b)
     files.append({'path':ent.name,'bytes':len(b),'sha256':sha(b),'utf8':decoded,'lfs_pointer':b.startswith(b'version https://git-lfs.github.com/spec/v1')})
  d={'repo':name,'source_url':f'https://github.com/shw097-team/{name}','main':head.stdout.decode().strip(),'credential_source':str(KEYFILE),'credential_value_recorded':False,'clone':clone,'archive':receipt,'files':files,'special_entries':special,'utf8_bytes':text_bytes,'binary_bytes':binary_bytes,'claim':'COMPLETE_MAIN_BLOB_BYTES_READ_NOT_SEMANTIC_ACCEPTANCE','history_scope':'DEPTH_1_CURRENT_MAIN','submodule_lfs_scope':'LINKS_AND_LFS_POINTERS_RECORDED_NOT_MATERIALIZED'}
  dump(M/(name+'_remote_full_read.json'),d)
  return {'repo':name,'main':d['main'],'files':len(files),'bytes':text_bytes+binary_bytes,'special_entries':len(special),'lfs':sum(x['lfs_pointer'] for x in files)}
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:print(json.dumps(list(pool.map(repo,['HG-KSEOS','SBL','Fabric','PIPD-LS-SP'])),ensure_ascii=False))
if __name__=='__main__':main()
