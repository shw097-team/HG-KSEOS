from discover import *
from probe_repos import M
from retain_original_negatives import norm
from normalize_locators import marker_pattern
def main():
 rows=json.loads((M/'CURRENT_READER_LOCATORS_2221.json').read_text(encoding='utf-8'));checks=json.loads((M/'ORIGINAL_NEGATIVE_RETENTION_ALL_RECORDS.json').read_text(encoding='utf-8'));by={(r['group'],r['id']):r for r in rows};cache={};patched=[]
 for c in checks:
  r=by[(c['group'],c['id'])];path=r['path']
  if path not in cache:cache[path]=(OUT/path).read_text(encoding='utf-8')
  text=cache[path];start=text.index(f'<a id="{r["anchor"]}"></a>');end=text.find('<a id="current-',start+4);end=len(text) if end<0 else end
  if norm(c['original_negative']) not in norm(text[start:end]):
   pos=text.index('\n',text.index('\n',start)+1)+1;addition='\n- **原 NEG 本版有效保留**：'+c['original_negative']+'\n';cache[path]=text[:pos]+addition+text[pos:];patched.append({'group':c['group'],'id':c['id'],'field':c['field']})
 for path,text in cache.items():(OUT/path).write_text(text,encoding='utf-8',newline='\n')
 hashcache={}
 for r in rows:
  if r['path'] not in hashcache:
   p=OUT/r['path'];raw=p.read_bytes();hashcache[r['path']]=(raw.decode('utf-8'),raw.decode('utf-8').splitlines(),sha(raw))
  text,lines,dg=hashcache[r['path']];r['sha256']=dg;r['line']=lines.index(f'<a id="{r["anchor"]}"></a>')+1
  if not marker_pattern(r['group'],r['id']).search(lines[r['line']]):raise ValueError('HEADING')
 for c in checks:
  r=by[(c['group'],c['id'])];text=hashcache[r['path']][0];start=text.index(f'<a id="{r["anchor"]}"></a>');end=text.find('<a id="current-',start+4);end=len(text) if end<0 else end
  if norm(c['original_negative']) not in norm(text[start:end]):raise ValueError('NEGATIVE_STILL_MISSING:'+c['id'])
 dump(M/'CURRENT_READER_LOCATORS_2221.json',rows);dump(M/'NEGATIVE_PLACEMENT_AFFECTED_RECHECK.json',{'repairs':patched,'all_original_negative_fields_rechecked':len(checks),'result':'PASS','current_locator_hashes_recomputed':len(rows)})
 report=json.loads((M/'FINAL_GLOBAL_REGRESSION.json').read_text(encoding='utf-8'))
 for c in report['checks']:
  if c['test']=='ORIGINAL_NEGATIVE_TEXT_CONSERVATION':c.update(status='PASS',detail={'original_negative_fields':len(checks),'placement_corrections':len(patched),'evidence':'NEGATIVE_PLACEMENT_AFFECTED_RECHECK.json'})
 report['integrity_pass']=sum(x['status']=='PASS' for x in report['checks'] if x['class']=='INTEGRITY');report['integrity_fail']=sum(x['status']=='FAIL' for x in report['checks'] if x['class']=='INTEGRITY');report['affected_rechecks']=['AFFECTED_RECHECK_AFTER_GLOBAL.json','NEGATIVE_PLACEMENT_AFFECTED_RECHECK.json'];dump(M/'FINAL_GLOBAL_REGRESSION.json',report)
 print(json.dumps({'negative_placement_repairs':len(patched),'original_negative_fields_retained':len(checks),'integrity_pass':report['integrity_pass'],'integrity_fail':report['integrity_fail'],'completion':'REPAIR_INCOMPLETE'},ensure_ascii=False))
if __name__=='__main__':main()
