from discover import *
from probe_repos import M
def main():
 checks=json.loads((M/'ORIGINAL_NEGATIVE_RETENTION_ALL_RECORDS.json').read_text(encoding='utf-8'));mapping=json.loads((M/'CURRENT_READER_LOCATORS_2221.json').read_text(encoding='utf-8'));by={(r['group'],r['id']):r for r in mapping};cache={}
 for rec in checks:
  if rec['already_present_before_repair']:continue
  r=by[(rec['group'],rec['id'])];path=r['path']
  if path not in cache:cache[path]=(OUT/path).read_text(encoding='utf-8')
  addition='\n- **原 NEG 本版有效保留**：'+rec['original_negative']+'\n';t=cache[path];at=t.find(addition)
  if at<0:raise ValueError('NEGATIVE_ADDITION_NOT_FOUND')
  t=t[:at]+t[at+len(addition):];start=t.index(f'<a id="{r["anchor"]}"></a>');header_end=t.index('\n',t.index('\n',start)+1);cache[path]=t[:header_end+1]+addition+t[header_end+1:]
 for path,t in cache.items():(OUT/path).write_text(t,encoding='utf-8',newline='\n')
 hashcache={}
 for r in mapping:
  if r['path'] not in hashcache:
   p=OUT/r['path'];hashcache[r['path']]=(p.read_text(encoding='utf-8').splitlines(),sha(p.read_bytes()))
  ls,dg=hashcache[r['path']];r['sha256']=dg;r['line']=ls.index(f'<a id="{r["anchor"]}"></a>')+1
 dump(M/'CURRENT_READER_LOCATORS_2221.json',mapping)
 print('517 source-specific original negatives located directly inside own current cards')
if __name__=='__main__':main()
