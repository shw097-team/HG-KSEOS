> **CURRENT FHS READER 2026-10-30_r2_HIGH_RETENTION_AUDIT_PATCHED_SOURCE_BOUND**；原 Domain Writer 不變；歷史 fenced block 不得作有效條位。

# 02 PIPD LIFECYCLE AND TPM｜FHS-MSC_PIPD-LS-PKG 2026-10-30 整合實質正文

> **FHS-MSC_PIPD-LS-PKG / 2026-10-30_r2_HIGH_RETENTION_AUDIT_PATCHED_SOURCE_BOUND / EFFECTIVE_DESIGN_READER**。本冊按同域來源整合 2026-10-29 BODY revision2 和 2026-10-30 r2 最新受影修補。R2 受影條款在本冊設計閱讀範圍優先於被修補之歷史片段；但不覆寫 SBL/PIPD/Fabric/HGK 原 Writer、已生效 Policy/ABI。全部 Native／Owner Ratification／IndependentChecker／Release 未在本沙盒執行。
>
> **ClaimCeiling** `SOURCE_BOUND_INTEGRATED_DESIGN_WITH_LOCAL_READBACK`；`REPO_SOURCE_REMOTE_OBSERVED` 不代表 `LOCAL_REPOCONTEXT_BOUND`，不得藉本檔取得原授權。此文件前半 r2 更新與後半歷史正文是一份整合 Candidate，不是平行的兩份現役 Canonical。


## 本輪同域受影修復：r2 §2 TPM 18 Stage／PIPD 19/13

## 2. TPM 18 Stage、K0–K3、PIPD 五出口、19 Contract、13 CLI 的施工編排

### 2.1 K0→K3 Cold Host 導入，不要求使用者重上傳24 DOC

`K0 ImmutableCorpusBundle`：14 SBL＋10 PIPD DOC bytes/sha/Owner/License→原 Host Reader，24/24 可校驗；`K1 ClauseIndex`：Heading/Line/TextSHA/ACL 索引；`K2 SupersessionConflictRegistry`：依同 Domain Writer/Scope/Supersedes 判 current，不由較新日期跨域篡位；`K3 OnDemandReader`：同 Subject/Source/Clause/ACL 輸出 SourceBoundExcerpt 給三 SPEC。發現 K0 缺文件、K1 stale、K2 writer conflict、K3 Injection 時各走受影 HOLD、退回前一可信 Readset；未全裝的 Host 不能稱 `HOST_LOADED`。[BODY02 §6.1]

### 2.2 18 Stage 的原 Input／Transformation／Output／Consumer／NEG

| Role/Stage | EntryGuard／Operation | Typed Output → Consumer | POS／NEG／Resume |
|---|---|---|---|
| PM:T0 | 有 Goal+Source → 去重提取 JTBD/persona | ProductKnownState@PROPOSED → PM/T1 | POS 相同 source 零重問；NEG 空 Source→SOURCE_MISSING；只 PARK 受影階段，T4/T5 狀態轉移待 Owner Schema |
| PM:T1 | 有 T0 Readset → 定義 pain/FUO/非目標 | ProductSuccess@PROPOSED → PM/T2 | POS FUO 有 ACC POS/NEG；NEG 抽象口號→FUO_UNBOUNDED；只 PARK 受影階段，T4/T5 狀態轉移待 Owner Schema |
| PM:T2 | 有 FUO/Kind → 建立 Journey/八 Kind 適用 | ProductSPECDraft@PROPOSED → TPM/PI Candidate | POS Kind 具 NoFit；NEG 其他 Kind 偷預設支援→KIND_NOFIT；只 PARK 受影階段，T4/T5 狀態轉移待 Owner Schema |
| PM:T3 | 有 draft + risk → 逐需求拆 ACC/NEG/Owner | ProductAcceptanceProposal@PROPOSED → PM/SE/T4 | POS 每子項有測試入口；NEG parent PASSED child 缺證→CHILD_TRACE_GAP；只 PARK 受影階段，T4/T5 狀態轉移待 Owner Schema |
| PM:T4 | 有 source/owner → 編 SpecCandidate handoff，不編 PI | ProductHandoffReferral@PROPOSED → PIPD intake | POS Schema/SourceHash可查；NEG 提案冒稱 Native PI→WRITER_DENIED；只 PARK 受影階段，T4/T5 狀態轉移待 Owner Schema |
| PM:T5 | 有原始測試或明確未跑 → 核 Raw/evidence與FUO | ProductReview@PROPOSED → PM/Owner | POS 能區分 NotRun/Fail；NEG 缺 Raw 說 DONE→FUO_RAW_MISSING；只 PARK 受影階段，T4/T5 狀態轉移待 Owner Schema |
| SE:T0 | 有來源/現役 host 可讀 → 建立架構所有權 | SystemReadset@PROPOSED → SE/T1 | POS 四域 Writer 分明；NEG 未知 PID 自填→HOST_UNVERIFIED；只 PARK 受影階段，T4/T5 狀態轉移待 Owner Schema |
| SE:T1 | 有 T0/Scope → 產 Boundary/ThreatModel | OwnershipSeamMap@PROPOSED → SE/T2 | POS 一 Writer/Effect；NEG 雙 Issuer→AUTHORITY_CONFLICT；只 PARK 受影階段，T4/T5 狀態轉移待 Owner Schema |
| SE:T2 | 有 Driver/HostCaps → 具名 ADR／版本 ABI | ArchitectureSPEC@PROPOSED → SE/T3 | POS 版號與 NEG；NEG 無 Schema 仍宣綁定→ABI_UNBOUND；只 PARK 受影階段，T4/T5 狀態轉移待 Owner Schema |
| SE:T3 | 有 SPEC / writer → 逐 edge 壓測、回退 | ArchitectureNEGRequest@PROPOSED → SE/T4 | POS wrong major DENY；NEG 靜默丟 unknown required→ABI_LOSS；只 PARK 受影階段，T4/T5 狀態轉移待 Owner Schema |
| SE:T4 | 有 Adapter Proposal → 原 Domain Writer 審查接線 | ArchitectureHandoff@PROPOSED → PIPD/HGK Reader | POS Only Proposal crossing；NEG 自稱 Loaded→HOST_RAW_MISSING；只 PARK 受影階段，T4/T5 狀態轉移待 Owner Schema |
| SE:T5 | 有同 SHA 實證 → review trace／負例 | ArchitectureReview@PROPOSED → SE/Owner | POS 不同 principal 待證；NEG 用 Maker 代 Checker→SOD_DENIED；只 PARK 受影階段，T4/T5 狀態轉移待 Owner Schema |
| TPgM:T0 | 有 subject/Goal → 盤點 scope/milestone | ProgramIntent@PROPOSED → TPgM/T1 | POS 跨 Session 可定位；NEG 只有 Chat 歷史→DURABLE_GAP；只 PARK 受影階段，T4/T5 狀態轉移待 Owner Schema |
| TPgM:T1 | 有風險 → 定預授權/成本/依賴 | SchedulingAssumptions@PROPOSED → TPgM/T2 | POS 不重啟無關卡；NEG 每卡重問 Owner→GOVERNANCE_OVERHEAD；只 PARK 受影階段，T4/T5 狀態轉移待 Owner Schema |
| TPgM:T2 | 有 3 SPEC → DAG/toposort/Owner split | ProgramDAG@PROPOSED → TPgM/T3 | POS 無 cycle；NEG 循環依賴→DAG_CYCLE；只 PARK 受影階段，T4/T5 狀態轉移待 Owner Schema |
| TPgM:T3 | 有合法卡 → 建立受限 WP/rollback | ProgramSPEC@PROPOSED → TPgM/T4 | POS 卡帶 scope/NEG；NEG ** write scope→WRITESET_DENIED；只 PARK 受影階段，T4/T5 狀態轉移待 Owner Schema |
| TPgM:T4 | 有真 PIPD 入口 → 生成受權 referral | HandoffReferral@PROPOSED → PIPD/HGK PLAN | POS 不冒充 ECP/Permit；NEG 跳過 SourceFreeze→PIPD_HOLD；只 PARK 受影階段，T4/T5 狀態轉移待 Owner Schema |
| TPgM:T5 | 有 Raw/checkpoint → 按原 Case 最小稽核 | ProgramReview@PROPOSED → TPgM/Owner | POS 未結案 card 續行；NEG 重跑 Done→REPLAY_DENIED；只 PARK 受影階段，T4/T5 狀態轉移待 Owner Schema |

**18 Stage 義務：** PM、SE、TPgM 各六個互相獨立的可追溯子項。Draft 跨 T4/T5 並不自動修改原 PIPD StateEnum，`CR-DOC04-STATE-MAP` 尚須原 Writer 對照；任一 Stage NoFit 只停相關依賴，不抹去合法已完成 Stage。K0–K3 是 Reader 的合法性，不是另一套新 Compiler。[BODY02 `R2-02-STAGE`]

### 2.3 PIPD 五個出口：每條分離，禁止用 PI/PD/ECP 串詞代替

| 出口 | Producer Input→原真能力→Output／Consumer | 受影 POS／NEG／Rollback |
|---|---|---|
| E1 `SOURCE/PROFILE→PI` | Goal＋SourceFamily ManifestSHA＋Profile nine-axis/Oracle→原 `pipd intake/profile/compile-pi` 和 PIPD DOC02 原 Writer→`PI-PKG/RequirementAtom` | POS strict schema＋SourceSHA 同 Subject；缺 Source、Profile veto、外欄或舊 Oracle alias NACK；不讓 Matt/OpenSpec Writer 簽 PI |
| E2 `PI→PD` | 真 PI＋RepoContext(root,HEAD,index,untracked,ACL)→原 `pipd bind-pd`→有界 PD-PKG＋WriteSet Candidate | POS exact Subject/HEAD/root；stale HEAD/`**`/path escape→只 PD HOLD，保留 PI |
| E3 `PD→DEV` | 原 PD＋preimage、exact files、Tests、Rollback→原 `pipd compile-ecp`/原 DEV Construction Owner→DEV ECP/ConstructionContract | POS 原 DEV Writer＋Original HGK Admission 才可 Repo Write；缺 WriteSet/Permit 禁 Apply；回原 preimage |
| E4 `PD→OPS/Host/User/Remote` | 原 PD＋HostTarget/PolicyEpoch/Effect/Compensation→原 `pipd compile-ecp`/OPS Writer→OPS ECP Proposal | POS 同 Host/Scope/Issuer；不能把 DEV Grant 轉成 Host/Remote Permit；UNKNOWN 經原 Receiver Reconcile |
| E5 `PD→PlannedTQAEP` | PD＋每 Atom 原 Oracle/ACC POS+NEG/CaseID→原 `pipd compile-tqaep`／DOC07→PlannedTQAEP | POS 原 Case/Oracle 可定位；未跑/同 Maker 並非 Checker PASS；回補受影 Case 而非重建全部 |

**原 CLI 精確 13 命令**：`init, intake, profile, compile-pi, bind-pd, compile-ecp, compile-tqaep, validate, doctor, project, export, diff, repair`。`compile-cc` 曾出現在別的歷史證據，**非四庫固定主線的第 14 個法定命令**；本版保持原 CLI Exact-set。正式 Verb Parser 以 `PIPD-LS-SP/src/pipd_ls_sp/cli.py::COMMANDS` 為 Code Fact；`pipeline.intake()` 等已存在 Python 函式的參數仍要按該版呼叫，不由本文擅改函式簽章。[BODY02 `R2-02-CLI`；PIPD 原 CLI Source]

**原 19 Schema**：`ArtifactIdentity`, `AuthorityBinding`, `RequirementAtom`, `ProfileBinding`, `TechnologyAdmission`, `PI-PKG`, `PD-PKG`, `TraceLink`, `TaskSpecSeed`, `ConstructionContract`, `WorkOrderCandidate`, `ECP`, `TQAEP`, `ExecutionHandoff`, `EvidenceExpectation`, `ClaimCeiling`, `SurfaceProjectionManifest`, `GENIEProjectionRef`, `ExecutionBindingRef`。原 `$id` 以 `schemas/registry.json` 讀值，名稱並非憑本文件新產生的 Schema；`GENIEProjectionRef/ExecutionBindingRef` 的 seam-only 仍依原 Registry 限制。19 中每個只有 Syntax PASS 不等於 Domain Semantic PASS。[PIPD Registry／BODY02 `R2-02-CONTRACTS`]

**PIPD 原八個正式 Skill（四庫 `skills/` 目錄逐名核對）**：各別執行 `PACKAGED/INSTALLED/LOADED/INVOKED/QUALIFIED` 的原 Host Reader 驗證；這些名稱不授予原 Publisher/Permit 權。

| 原 PIPD Skill | Need／輸入→能力→候選輸出／原 Consumer | 原負例與降級 |
|---|---|---|
| `pipd-route-intake` | Goal/Source→合法 Intake、Need/SourceRef→原 PIPD `intake` | 缺 Source/Foreign Scope→`INTAKE_HOLD` |
| `pipd-authority-source` | SourceFamily／SHA→Authority Binding Reader→原 `freeze_authority`／PIPD Writer | 跨 Writer／失效 SHA→`AUTHORITY_HOLD` |
| `pipd-profile-tailor` | Product/Host/Context→Profile candidate／Veto→原 `profile` | 非受支援 Surface／Safety veto→`PROFILE_HOLD` |
| `pipd-pi-compile` | RequirementAtom／Source→`compile-pi`→PI-PKG | Unknown Oracle/Schema drift→`PI_HOLD` |
| `pipd-pd-bind` | PI＋Repo HEAD/index/ACL→`bind-pd`→PD-PKG | Stale HEAD／Root Escape→`PD_HOLD` |
| `pipd-execution-contract` | PD/EffectScope→原 `compile-ecp`→DEV/OPS ECP | 無 Exact WriteSet/Permit→`ADMISSION_HOLD` |
| `pipd-assurance-tqaep` | PD/Oracle→`compile-tqaep`→PlannedTQAEP | 沒有 Protected Checker 不得 `INDEPENDENT_PASS` |
| `pipd-package-project` | 原合法工件→`project/export/validate`→受限發行候選 | 打包不等於 SourceFreeze/Release |

**狀態**：八項未有當期真 Host 8/8 Effective Load/Trigger/Nontrigger 完整 Receipt，保持 `HOST_PENDING`；`.hermes/skills/openspec-*` 是另一套 OpenSpec 方法 Skill，**不得與八個正式 Skill 混同**。具體 Skill 命令、輸入須核其同 SHA `SKILL.md`。[PIPD Repository `skills/`；PIPD DOC02/06/07]


### 2.4 19 Canonical Schema 專用 Reader／Required／NEG（全部具名）
原 Domain `schemas/registry.json` 才是 `$id` 真值；本欄原文的 SourcePath、SchemaShape、Invariant/NEG 作原位 Adapter 接線要求，外部 Skill 不得發 Schema。
#### ArtifactIdentity
- **出處**：`BODY-02:61`；原 Canonical Contract `ArtifactIdentity`。
- 原 Registry source：C:\Projects\Agent_Workspace\PIPD\schemas\ArtifactIdentity.schema.json；SHA `67d26f18d26307410bf0be5369949eb525d477e053ee3a7091e54b97f6d4ad4c`；`$id=urn:pipd:s0:ArtifactIdentity:1`；schema dialect 2020-12；additionalProperties=false。
- Producer/Consumer：Owner: PIPD. Consumer: all planes.
- required：subject_id, version, content_hash, schema_version, supersedes, invalidates。
- 專屬 Reader invariant：相同 canonical body 得相同 content_hash；supersedes/invalidates 指到舊版本且不能自指。
- Domain NEG：alter body but retain content_hash → `HASH_MISMATCH`；與 missing-required/unknown-key 的 schema拒收分開。
- roundtrip：原 Reader重序列化 payload，再讀回相同identity/trace；schema syntactic fixture通過不證明content_hash/Principal/License有效。
- **拒收**：本 Schema 專用 Reader 的 required/invariant/NEG 不符則僅停受影 Canonical Consumer；`jsonschema` syntax PASS 不能冒語義/Native PASS。

#### AuthorityBinding
- **出處**：`BODY-02:101`；原 Canonical Contract `AuthorityBinding`。
- 原 Registry source：C:\Projects\Agent_Workspace\PIPD\schemas\AuthorityBinding.schema.json；SHA `66f1b3ce91d7f12ad6a6350a6628afd6c600e3e7ff62408b714c6fa0f1898ded`；`$id=urn:pipd:s0:AuthorityBinding:1`；schema dialect 2020-12；additionalProperties=false。
- Producer/Consumer：Owner: PIPD. Consumer: all compilers/adapters.
- required：source_id, authority_rank, locator, supersession, conflict_state, subject_id, version, content_hash, schema_version。
- 專屬 Reader invariant：來源存在且 file SHA 符合；CURRENT 無 unresolved conflict 才可供 Compiler。
- Domain NEG：conflict_state=CONFLICT but promotion requested → `AUTHORITY_CONFLICT`；與 missing-required/unknown-key 的 schema拒收分開。
- roundtrip：原 Reader重序列化 payload，再讀回相同identity/trace；schema syntactic fixture通過不證明content_hash/Principal/License有效。
- **拒收**：本 Schema 專用 Reader 的 required/invariant/NEG 不符則僅停受影 Canonical Consumer；`jsonschema` syntax PASS 不能冒語義/Native PASS。

#### ClaimCeiling
- **出處**：`BODY-02:150`；原 Canonical Contract `ClaimCeiling`。
- 原 Registry source：C:\Projects\Agent_Workspace\PIPD\schemas\ClaimCeiling.schema.json；SHA `dbb2ce4dd322da99ca3b3067274b85928b995aba59ca3f04802d5e8ba253ab85`；`$id=urn:pipd:s0:ClaimCeiling:1`；schema dialect 2020-12；additionalProperties=false。
- Producer/Consumer：Owner: PIPD. Consumer: all planes.
- required：allowed_claims, forbidden_escalation, close_conditions, subject_id, version, content_hash, schema_version。
- 專屬 Reader invariant：allowed_claims需真證據階梯；forbidden_escalation與close_conditions有效。
- Domain NEG：AUTHOR_STATIC promoted to RELEASED → `CLAIM_ESCALATION`；與 missing-required/unknown-key 的 schema拒收分開。
- roundtrip：原 Reader重序列化 payload，再讀回相同identity/trace；schema syntactic fixture通過不證明content_hash/Principal/License有效。
- **拒收**：本 Schema 專用 Reader 的 required/invariant/NEG 不符則僅停受影 Canonical Consumer；`jsonschema` syntax PASS 不能冒語義/Native PASS。

#### ConstructionContract
- **出處**：`BODY-02:193`；原 Canonical Contract `ConstructionContract`。
- 原 Registry source：C:\Projects\Agent_Workspace\PIPD\schemas\ConstructionContract.schema.json；SHA `1c56f15abd6e30d06f914f021b0b813f441689f9d47989ef48c7d7325557f0f2`；`$id=urn:pipd:s0:ConstructionContract:1`；schema dialect 2020-12；additionalProperties=false。
- Producer/Consumer：Owner: PIPD. Consumer: HGK adapter.
- required：subject, writable_scope, expected_changes, tests, rollback, evidence_expectations, subject_id, version, content_hash, schema_version。
- 專屬 Reader invariant：writable_scope exact contained paths，expected_changes/tests/rollback 對同 preimage。
- Domain NEG：scope=** or path escapes root → `CC_SCOPE`；與 missing-required/unknown-key 的 schema拒收分開。
- roundtrip：原 Reader重序列化 payload，再讀回相同identity/trace；schema syntactic fixture通過不證明content_hash/Principal/License有效。
- **拒收**：本 Schema 專用 Reader 的 required/invariant/NEG 不符則僅停受影 Canonical Consumer；`jsonschema` syntax PASS 不能冒語義/Native PASS。

#### ECP
- **出處**：`BODY-02:245`；原 Canonical Contract `ECP`。
- 原 Registry source：C:\Projects\Agent_Workspace\PIPD\schemas\ECP.schema.json；SHA `c58a8f3ed42808ba20f0102bb6fc7074d4fa321ea779879aa5ceefc6864d1de8`；`$id=urn:pipd:s0:ECP:1`；schema dialect 2020-12；additionalProperties=false。
- Producer/Consumer：Owner: PIPD/ECP semantics. Consumer: HGK/TQAEP.
- required：effect_intent, permission, retries, idempotency, readback, rollback, subject_id, version, content_hash, schema_version。
- 專屬 Reader invariant：effect_intent/permission/retries/idempotency/readback/rollback按同scope；UNKNOWN不得重播。
- Domain NEG：DEV permission used for HOST_OP → `WRONG_EFFECT_GRANT`；與 missing-required/unknown-key 的 schema拒收分開。
- roundtrip：原 Reader重序列化 payload，再讀回相同identity/trace；schema syntactic fixture通過不證明content_hash/Principal/License有效。
- **拒收**：本 Schema 專用 Reader 的 required/invariant/NEG 不符則僅停受影 Canonical Consumer；`jsonschema` syntax PASS 不能冒語義/Native PASS。

#### EvidenceExpectation
- **出處**：`BODY-02:297`；原 Canonical Contract `EvidenceExpectation`。
- 原 Registry source：C:\Projects\Agent_Workspace\PIPD\schemas\EvidenceExpectation.schema.json；SHA `02327839c21d5ba24d08dd52f9caa31a07616965c6235cece58487a810b99b7f`；`$id=urn:pipd:s0:EvidenceExpectation:1`；schema dialect 2020-12；additionalProperties=false。
- Producer/Consumer：Owner: PIPD/TQAEP. Consumer: HGK/CI/provider.
- required：expected_evidence_type, producer, postcondition, freshness, claim_effect, subject_id, version, content_hash, schema_version。
- 專屬 Reader invariant：expected_evidence_type/producer/postcondition/freshness/claim_effect只描述期待。
- Domain NEG：expected raw path promoted to observed receipt → `EXPECTED_IS_NOT_RAW`；與 missing-required/unknown-key 的 schema拒收分開。
- roundtrip：原 Reader重序列化 payload，再讀回相同identity/trace；schema syntactic fixture通過不證明content_hash/Principal/License有效。
- **拒收**：本 Schema 專用 Reader 的 required/invariant/NEG 不符則僅停受影 Canonical Consumer；`jsonschema` syntax PASS 不能冒語義/Native PASS。

#### ExecutionBindingRef
- **出處**：`BODY-02:346`；原 Canonical Contract `ExecutionBindingRef`。
- 原 Registry source：C:\Projects\Agent_Workspace\PIPD\schemas\ExecutionBindingRef.schema.json；SHA `7c98cebfee30d9719cb8fd2d565c44120ce8d1be5b231071c19528cae1e95f50`；`$id=urn:pipd:s0:ExecutionBindingRef:1`；schema dialect 2020-12；additionalProperties=false。
- Producer/Consumer：Owner: HGK adapter. Consumer: HGK. Schema seam only until S5. Receiver binding id/version/hash/lease/state; ACK only after HGK admission.
- required：receiver_binding_id, receiver_binding_version, receiver_binding_hash, lease, state, subject_id, version, content_hash, schema_version。
- 專屬 Reader invariant：receiver_binding_id/version/hash+lease/state同原HGK Reader；seam不取代Issuer。
- Domain NEG：foreign lease generation used to execute → `LEASE_FENCING_DENY`；與 missing-required/unknown-key 的 schema拒收分開。
- roundtrip：原 Reader重序列化 payload，再讀回相同identity/trace；schema syntactic fixture通過不證明content_hash/Principal/License有效。
- **拒收**：本 Schema 專用 Reader 的 required/invariant/NEG 不符則僅停受影 Canonical Consumer；`jsonschema` syntax PASS 不能冒語義/Native PASS。

#### ExecutionHandoff
- **出處**：`BODY-02:395`；原 Canonical Contract `ExecutionHandoff`。
- 原 Registry source：C:\Projects\Agent_Workspace\PIPD\schemas\ExecutionHandoff.schema.json；SHA `7fa36d3e7fe6e7416111b975381a42f3f5ad46cc81d97b610f317548815bd77b`；`$id=urn:pipd:s0:ExecutionHandoff:1`；schema dialect 2020-12；additionalProperties=false。
- Producer/Consumer：Owner: PIPD. Consumer: HGK/other receiver.
- required：receiver, abi_version, payload_refs, ack_nack_state, subject_id, version, content_hash, schema_version。
- 專屬 Reader invariant：receiver/abi_version/payload_refs真ACK payload hash與Consumer scope。
- Domain NEG：NACK or wrong receiver treated as ACK → `HANDOFF_NACK`；與 missing-required/unknown-key 的 schema拒收分開。
- roundtrip：原 Reader重序列化 payload，再讀回相同identity/trace；schema syntactic fixture通過不證明content_hash/Principal/License有效。
- **拒收**：本 Schema 專用 Reader 的 required/invariant/NEG 不符則僅停受影 Canonical Consumer；`jsonschema` syntax PASS 不能冒語義/Native PASS。

#### GENIEProjectionRef
- **出處**：`BODY-02:441`；原 Canonical Contract `GENIEProjectionRef`。
- 原 Registry source：C:\Projects\Agent_Workspace\PIPD\schemas\GENIEProjectionRef.schema.json；SHA `22c88a0f9ec4ea4747967546f9a5ea7f19f0285be60ac42567fae2ca0b1c36ed`；`$id=urn:pipd:s0:GENIEProjectionRef:1`；schema dialect 2020-12；additionalProperties=false。
- Producer/Consumer：Owner: GENIE adapter. Consumer: GENIE compiler. Schema seam only until S6. Target references to ProductGraph, Profile, Bundle and GENIEArtifact; no truth writeback.
- required：target_refs, subject_id, version, content_hash, schema_version。
- 專屬 Reader invariant：僅讀GENIE target_refs，保留SCHEMA_SEAM_ONLY；不成第二Writer。
- Domain NEG：projection creates native GENIE authority → `GENIE_WRITER_COLLISION`；與 missing-required/unknown-key 的 schema拒收分開。
- roundtrip：原 Reader重序列化 payload，再讀回相同identity/trace；schema syntactic fixture通過不證明content_hash/Principal/License有效。
- **拒收**：本 Schema 專用 Reader 的 required/invariant/NEG 不符則僅停受影 Canonical Consumer；`jsonschema` syntax PASS 不能冒語義/Native PASS。

#### PD-PKG
- **出處**：`BODY-02:488`；原 Canonical Contract `PD-PKG`。
- 原 Registry source：C:\Projects\Agent_Workspace\PIPD\schemas\PD-PKG.schema.json；SHA `37291e8790e03839308a7c36125f9576d14da725a27480c9759ef5362d255541`；`$id=urn:pipd:s0:PD-PKG:1`；schema dialect 2020-12；additionalProperties=false。
- Producer/Consumer：Owner: PIPD. Consumer: execution handoff.
- required：RepoContext, currentness, late_bound_construction_binding, subject_id, version, content_hash, schema_version。
- 專屬 Reader invariant：RepoContext 是當期真 root/HEAD/index/untracked，currentness 與晚綁 scope一致。
- Domain NEG：HEAD drift with old RepoContext → `PD_BIND_STALE`；與 missing-required/unknown-key 的 schema拒收分開。
- roundtrip：原 Reader重序列化 payload，再讀回相同identity/trace；schema syntactic fixture通過不證明content_hash/Principal/License有效。
- **拒收**：本 Schema 專用 Reader 的 required/invariant/NEG 不符則僅停受影 Canonical Consumer；`jsonschema` syntax PASS 不能冒語義/Native PASS。

#### PI-PKG
- **出處**：`BODY-02:531`；原 Canonical Contract `PI-PKG`。
- 原 Registry source：C:\Projects\Agent_Workspace\PIPD\schemas\PI-PKG.schema.json；SHA `2a204aceba8d2764310a729c7c105301296e11d57d6c91f17bb8372214f793fe`；`$id=urn:pipd:s0:PI-PKG:1`；schema dialect 2020-12；additionalProperties=false。
- Producer/Consumer：Owner: PIPD. Consumer: PD binder.
- required：stable_semantic_contract, trace, acceptance, subject_id, version, content_hash, schema_version。
- 專屬 Reader invariant：stable_semantic_contract 包含全部原原子 trace；Oracle canonical Writer相容。
- Domain NEG：sidecar appended as top-level _profile_meta → `PI_SCHEMA`；與 missing-required/unknown-key 的 schema拒收分開。
- roundtrip：原 Reader重序列化 payload，再讀回相同identity/trace；schema syntactic fixture通過不證明content_hash/Principal/License有效。
- **拒收**：本 Schema 專用 Reader 的 required/invariant/NEG 不符則僅停受影 Canonical Consumer；`jsonschema` syntax PASS 不能冒語義/Native PASS。

#### ProfileBinding
- **出處**：`BODY-02:574`；原 Canonical Contract `ProfileBinding`。
- 原 Registry source：C:\Projects\Agent_Workspace\PIPD\schemas\ProfileBinding.schema.json；SHA `b559fb70bb6ceb9d491c989cb5ec031f44d15bcad5b40e75d6649aa059a93556`；`$id=urn:pipd:s0:ProfileBinding:1`；schema dialect 2020-12；additionalProperties=false。
- Producer/Consumer：Owner: PIPD. Consumer: Skills/JIT/HGK.
- required：profile, axes, vetoes, artifact_depth, assurance, subject_id, version, content_hash, schema_version。
- 專屬 Reader invariant：九軸 strict enum、去重與 safety veto 只升級；十二軸另存 lossless bridge。
- Domain NEG：unknown axis or downgrade ASSURED → `PROFILE_VETO`；與 missing-required/unknown-key 的 schema拒收分開。
- roundtrip：原 Reader重序列化 payload，再讀回相同identity/trace；schema syntactic fixture通過不證明content_hash/Principal/License有效。
- **拒收**：本 Schema 專用 Reader 的 required/invariant/NEG 不符則僅停受影 Canonical Consumer；`jsonschema` syntax PASS 不能冒語義/Native PASS。

#### RequirementAtom
- **出處**：`BODY-02:623`；原 Canonical Contract `RequirementAtom`。
- 原 Registry source：C:\Projects\Agent_Workspace\PIPD\schemas\RequirementAtom.schema.json；SHA `021f6a30cf178190281176138686447e492640cf97b125f9c21a0aa2fa31c684`；`$id=urn:pipd:s0:RequirementAtom:1`；schema dialect 2020-12；additionalProperties=false。
- Producer/Consumer：Owner: PIPD. Consumer: PI compiler/TQAEP.
- required：req_id, source_clause, owner, acceptance_cue, risk_guard, subject_id, version, content_hash, schema_version。
- 專屬 Reader invariant：source_clause 實讀、owner 可識別、acceptance_cue 可反證、risk_guard 不空；保留否定作用域。
- Domain NEG：positive wording replaces source prohibition → `ATOM_POLARITY_LOSS`；與 missing-required/unknown-key 的 schema拒收分開。
- roundtrip：原 Reader重序列化 payload，再讀回相同identity/trace；schema syntactic fixture通過不證明content_hash/Principal/License有效。
- **拒收**：本 Schema 專用 Reader 的 required/invariant/NEG 不符則僅停受影 Canonical Consumer；`jsonschema` syntax PASS 不能冒語義/Native PASS。

#### SurfaceProjectionManifest
- **出處**：`BODY-02:672`；原 Canonical Contract `SurfaceProjectionManifest`。
- 原 Registry source：C:\Projects\Agent_Workspace\PIPD\schemas\SurfaceProjectionManifest.schema.json；SHA `87f8057e8dac68f304ed4e9c2dd118a26c69428015769ab09d39398d34dcb57d`；`$id=urn:pipd:s0:SurfaceProjectionManifest:1`；schema dialect 2020-12；additionalProperties=false。
- Producer/Consumer：Owner: PIPD. Consumer: surface compiler.
- required：surface, source_hashes, generated_files, parity_loss, stale_rule, subject_id, version, content_hash, schema_version。
- 專屬 Reader invariant：surface/source_hashes/generated_files/parity_loss/stale_rule可重算；loss不默丟。
- Domain NEG：stale source hash still projected as current → `PROJECTION_STALE`；與 missing-required/unknown-key 的 schema拒收分開。
- roundtrip：原 Reader重序列化 payload，再讀回相同identity/trace；schema syntactic fixture通過不證明content_hash/Principal/License有效。
- **拒收**：本 Schema 專用 Reader 的 required/invariant/NEG 不符則僅停受影 Canonical Consumer；`jsonschema` syntax PASS 不能冒語義/Native PASS。

#### TaskSpecSeed
- **出處**：`BODY-02:721`；原 Canonical Contract `TaskSpecSeed`。
- 原 Registry source：C:\Projects\Agent_Workspace\PIPD\schemas\TaskSpecSeed.schema.json；SHA `c6e086aef0e4f21179cba52c5187c33a3873b18732c669c4d03bcad057e9b6cc`；`$id=urn:pipd:s0:TaskSpecSeed:1`；schema dialect 2020-12；additionalProperties=false。
- Producer/Consumer：Owner: PIPD. Consumer: receiver adapter.
- required：goal, inputs, outputs, constraints, dependencies, tests, rollback, evidence, subject_id, version, content_hash, schema_version。
- 專屬 Reader invariant：goal→inputs→outputs→tests→rollback/evidence 可閉合且 dependencies 有具名輸出。
- Domain NEG：output has no consumer or test → `TASKSEED_INCOMPLETE`；與 missing-required/unknown-key 的 schema拒收分開。
- roundtrip：原 Reader重序列化 payload，再讀回相同identity/trace；schema syntactic fixture通過不證明content_hash/Principal/License有效。
- **拒收**：本 Schema 專用 Reader 的 required/invariant/NEG 不符則僅停受影 Canonical Consumer；`jsonschema` syntax PASS 不能冒語義/Native PASS。

#### TechnologyAdmission
- **出處**：`BODY-02:779`；原 Canonical Contract `TechnologyAdmission`。
- 原 Registry source：C:\Projects\Agent_Workspace\PIPD\schemas\TechnologyAdmission.schema.json；SHA `40703552af4fb14c7aa87dd68ead6eac1cf7d272541fda273cf22b8fb109c4d6`；`$id=urn:pipd:s0:TechnologyAdmission:1`；schema dialect 2020-12；additionalProperties=false。
- Producer/Consumer：Owner: PIPD. Consumer: tool/provider adapters. Tightened from the untyped `{}` shape found in review: every field now carries a type and the source's 24-column design record (PKG-00 §9.2) is representable without additionalProperties loss.
- required：capability_need, candidate, disposition, pin_license_currentness, fallback_exit, subject_id, version, content_hash, schema_version, technology_id, external_name, capability_slot, license, immutable_pin。
- 專屬 Reader invariant：原 disposition 與17-state不默變；license+immutable_pin 真讀回，REJECT 不進 install。
- Domain NEG：REJECT candidate sent to installer → `TECH_ADMISSION_DENY`；與 missing-required/unknown-key 的 schema拒收分開。
- roundtrip：原 Reader重序列化 payload，再讀回相同identity/trace；schema syntactic fixture通過不證明content_hash/Principal/License有效。
- **拒收**：本 Schema 專用 Reader 的 required/invariant/NEG 不符則僅停受影 Canonical Consumer；`jsonschema` syntax PASS 不能冒語義/Native PASS。

#### TQAEP
- **出處**：`BODY-02:843`；原 Canonical Contract `TQAEP`。
- 原 Registry source：C:\Projects\Agent_Workspace\PIPD\schemas\TQAEP.schema.json；SHA `d14092817befb5e81c470449b9ac5160b6fba7e3fcde450ec00d1cadc21820cd`；`$id=urn:pipd:s0:TQAEP:1`；schema dialect 2020-12；additionalProperties=false。
- Producer/Consumer：Owner: PIPD/TQAEP semantics. Consumer: Independent checker/release.
- required：tests, oracles, fixtures, acceptance, requalification, subject_id, version, content_hash, schema_version。
- 專屬 Reader invariant：tests/oracles/fixtures/acceptance/requalification 逐atom對應；受保護receipt另讀。
- Domain NEG：PlannedTQAEP or Maker expected interpreted as actual verdict → `SELF_ACCEPTANCE_DENY`；與 missing-required/unknown-key 的 schema拒收分開。
- roundtrip：原 Reader重序列化 payload，再讀回相同identity/trace；schema syntactic fixture通過不證明content_hash/Principal/License有效。
- **拒收**：本 Schema 專用 Reader 的 required/invariant/NEG 不符則僅停受影 Canonical Consumer；`jsonschema` syntax PASS 不能冒語義/Native PASS。

#### TraceLink
- **出處**：`BODY-02:892`；原 Canonical Contract `TraceLink`。
- 原 Registry source：C:\Projects\Agent_Workspace\PIPD\schemas\TraceLink.schema.json；SHA `ff6ef713b95a1a2812bd31d2b10cdcc064671c986d29d0e69318dc5a9f54e5e4`；`$id=urn:pipd:s0:TraceLink:1`；schema dialect 2020-12；additionalProperties=false。
- Producer/Consumer：Owner: PIPD/TQAEP. Consumer: validators/checkers.
- required：from_type, from_id, from_hash, to_type, to_id, to_hash, rationale, subject_id, version, content_hash, schema_version。
- 專屬 Reader invariant：from_id/from_hash 與 to_id/to_hash 可在 bundle雙向解析；方向不交換。
- Domain NEG：to_hash names another candidate → `TRACE_HASH_MISMATCH`；與 missing-required/unknown-key 的 schema拒收分開。
- roundtrip：原 Reader重序列化 payload，再讀回相同identity/trace；schema syntactic fixture通過不證明content_hash/Principal/License有效。
- **拒收**：本 Schema 專用 Reader 的 required/invariant/NEG 不符則僅停受影 Canonical Consumer；`jsonschema` syntax PASS 不能冒語義/Native PASS。

#### WorkOrderCandidate
- **出處**：`BODY-02:947`；原 Canonical Contract `WorkOrderCandidate`。
- 原 Registry source：C:\Projects\Agent_Workspace\PIPD\schemas\WorkOrderCandidate.schema.json；SHA `03a8692f183f106ec7e4739b925c980ba07d68551627ca6af315fa9f9e2caf54`；`$id=urn:pipd:s0:WorkOrderCandidate:1`；schema dialect 2020-12；additionalProperties=false。
- Producer/Consumer：Owner: PIPD. Consumer: HGK admission. Candidate only; never runtime authority.
- required：candidate_only, subject_id, version, content_hash, schema_version。
- 專屬 Reader invariant：candidate_only=true；只送原HGK admission，不能直接 enqueue。
- Domain NEG：candidate_only=false → `CANDIDATE_NOT_AUTHORITY`；與 missing-required/unknown-key 的 schema拒收分開。
- roundtrip：原 Reader重序列化 payload，再讀回相同identity/trace；schema syntactic fixture通過不證明content_hash/Principal/License有效。
- **拒收**：本 Schema 專用 Reader 的 required/invariant/NEG 不符則僅停受影 Canonical Consumer；`jsonschema` syntax PASS 不能冒語義/Native PASS。

### 2.5 13 CLI 原 Verb 專屬操作及可重播失敗（全部具名）
每個 Verb 的合法 Flag/Parser 以原 PIPD `cli.py` 的 `COMMANDS`、同版本 `--help`/Tests 為準；此處載入原 BODY-02 的作用、輸入/輸出和負例，不產第14個命令。
#### pipd init
- **出處**：`BODY-02:989`；原 `pipd` Verb `pipd init`。
- binaryOrigin：source module via Python311 `-B -m pipd_ls_sp.cli`；cwd 本任務 work；installed binary origin NOT_OBSERVED。
- effectScope：LOCAL_DRAFT_WRITE_CANDIDATE_ONLY; repair actual repo scope requires L2；此輪只 `--help` 和 invalid flag，不執行該verb效果。
- helpSchema（exit=0）：
- nonzero：`init --definitely-invalid-flag` exit=2，typed stdout：
- 真實作用的POS/NEG與permission保留原下列契約；parser help成功不能聲稱compile/doctor功能已被本輪執行。
- **結果**：由原 CLI+Schema Reader 產同 Subject/Source/Scope 輸出；CLI Help/Dryrun 不等於 Native E2E。

#### pipd intake
- **出處**：`BODY-02:1014`；原 `pipd` Verb `pipd intake`。
- binaryOrigin：source module via Python311 `-B -m pipd_ls_sp.cli`；cwd 本任務 work；installed binary origin NOT_OBSERVED。
- effectScope：LOCAL_DRAFT_WRITE_CANDIDATE_ONLY; repair actual repo scope requires L2；此輪只 `--help` 和 invalid flag，不執行該verb效果。
- helpSchema（exit=0）：
- nonzero：`intake --definitely-invalid-flag` exit=2，typed stdout：
- 真實作用的POS/NEG與permission保留原下列契約；parser help成功不能聲稱compile/doctor功能已被本輪執行。
- **結果**：由原 CLI+Schema Reader 產同 Subject/Source/Scope 輸出；CLI Help/Dryrun 不等於 Native E2E。

#### pipd profile
- **出處**：`BODY-02:1044`；原 `pipd` Verb `pipd profile`。
- binaryOrigin：source module via Python311 `-B -m pipd_ls_sp.cli`；cwd 本任務 work；installed binary origin NOT_OBSERVED。
- effectScope：LOCAL_DRAFT_WRITE_CANDIDATE_ONLY; repair actual repo scope requires L2；此輪只 `--help` 和 invalid flag，不執行該verb效果。
- helpSchema（exit=0）：
- nonzero：`profile --definitely-invalid-flag` exit=2，typed stdout：
- 真實作用的POS/NEG與permission保留原下列契約；parser help成功不能聲稱compile/doctor功能已被本輪執行。
- **結果**：由原 CLI+Schema Reader 產同 Subject/Source/Scope 輸出；CLI Help/Dryrun 不等於 Native E2E。

#### pipd compile-pi
- **出處**：`BODY-02:1071`；原 `pipd` Verb `pipd compile-pi`。
- binaryOrigin：source module via Python311 `-B -m pipd_ls_sp.cli`；cwd 本任務 work；installed binary origin NOT_OBSERVED。
- effectScope：LOCAL_DRAFT_WRITE_CANDIDATE_ONLY; repair actual repo scope requires L2；此輪只 `--help` 和 invalid flag，不執行該verb效果。
- helpSchema（exit=0）：
- nonzero：`compile-pi --definitely-invalid-flag` exit=2，typed stdout：
- 真實作用的POS/NEG與permission保留原下列契約；parser help成功不能聲稱compile/doctor功能已被本輪執行。
- **結果**：由原 CLI+Schema Reader 產同 Subject/Source/Scope 輸出；CLI Help/Dryrun 不等於 Native E2E。

#### pipd bind-pd
- **出處**：`BODY-02:1101`；原 `pipd` Verb `pipd bind-pd`。
- binaryOrigin：source module via Python311 `-B -m pipd_ls_sp.cli`；cwd 本任務 work；installed binary origin NOT_OBSERVED。
- effectScope：LOCAL_DRAFT_WRITE_CANDIDATE_ONLY; repair actual repo scope requires L2；此輪只 `--help` 和 invalid flag，不執行該verb效果。
- helpSchema（exit=0）：
- nonzero：`bind-pd --definitely-invalid-flag` exit=2，typed stdout：
- 真實作用的POS/NEG與permission保留原下列契約；parser help成功不能聲稱compile/doctor功能已被本輪執行。
- **結果**：由原 CLI+Schema Reader 產同 Subject/Source/Scope 輸出；CLI Help/Dryrun 不等於 Native E2E。

#### pipd compile-ecp
- **出處**：`BODY-02:1129`；原 `pipd` Verb `pipd compile-ecp`。
- binaryOrigin：source module via Python311 `-B -m pipd_ls_sp.cli`；cwd 本任務 work；installed binary origin NOT_OBSERVED。
- effectScope：LOCAL_DRAFT_WRITE_CANDIDATE_ONLY; repair actual repo scope requires L2；此輪只 `--help` 和 invalid flag，不執行該verb效果。
- helpSchema（exit=0）：
- nonzero：`compile-ecp --definitely-invalid-flag` exit=2，typed stdout：
- 真實作用的POS/NEG與permission保留原下列契約；parser help成功不能聲稱compile/doctor功能已被本輪執行。
- **結果**：由原 CLI+Schema Reader 產同 Subject/Source/Scope 輸出；CLI Help/Dryrun 不等於 Native E2E。

#### pipd compile-tqaep
- **出處**：`BODY-02:1157`；原 `pipd` Verb `pipd compile-tqaep`。
- binaryOrigin：source module via Python311 `-B -m pipd_ls_sp.cli`；cwd 本任務 work；installed binary origin NOT_OBSERVED。
- effectScope：LOCAL_DRAFT_WRITE_CANDIDATE_ONLY; repair actual repo scope requires L2；此輪只 `--help` 和 invalid flag，不執行該verb效果。
- helpSchema（exit=0）：
- nonzero：`compile-tqaep --definitely-invalid-flag` exit=2，typed stdout：
- 真實作用的POS/NEG與permission保留原下列契約；parser help成功不能聲稱compile/doctor功能已被本輪執行。
- **結果**：由原 CLI+Schema Reader 產同 Subject/Source/Scope 輸出；CLI Help/Dryrun 不等於 Native E2E。

#### pipd validate
- **出處**：`BODY-02:1190`；原 `pipd` Verb `pipd validate`。
- binaryOrigin：source module via Python311 `-B -m pipd_ls_sp.cli`；cwd 本任務 work；installed binary origin NOT_OBSERVED。
- effectScope：SOURCE_READ；此輪只 `--help` 和 invalid flag，不執行該verb效果。
- helpSchema（exit=0）：
- nonzero：`validate --definitely-invalid-flag` exit=2，typed stdout：
- 真實作用的POS/NEG與permission保留原下列契約；parser help成功不能聲稱compile/doctor功能已被本輪執行。
- **結果**：由原 CLI+Schema Reader 產同 Subject/Source/Scope 輸出；CLI Help/Dryrun 不等於 Native E2E。

#### pipd doctor
- **出處**：`BODY-02:1217`；原 `pipd` Verb `pipd doctor`。
- binaryOrigin：source module via Python311 `-B -m pipd_ls_sp.cli`；cwd 本任務 work；installed binary origin NOT_OBSERVED。
- effectScope：SOURCE_READ；此輪只 `--help` 和 invalid flag，不執行該verb效果。
- helpSchema（exit=0）：
- nonzero：`doctor --definitely-invalid-flag` exit=2，typed stdout：
- 真實作用的POS/NEG與permission保留原下列契約；parser help成功不能聲稱compile/doctor功能已被本輪執行。
- **結果**：由原 CLI+Schema Reader 產同 Subject/Source/Scope 輸出；CLI Help/Dryrun 不等於 Native E2E。

#### pipd project
- **出處**：`BODY-02:1242`；原 `pipd` Verb `pipd project`。
- binaryOrigin：source module via Python311 `-B -m pipd_ls_sp.cli`；cwd 本任務 work；installed binary origin NOT_OBSERVED。
- effectScope：LOCAL_DRAFT_WRITE_CANDIDATE_ONLY; repair actual repo scope requires L2；此輪只 `--help` 和 invalid flag，不執行該verb效果。
- helpSchema（exit=0）：
- nonzero：`project --definitely-invalid-flag` exit=2，typed stdout：
- 真實作用的POS/NEG與permission保留原下列契約；parser help成功不能聲稱compile/doctor功能已被本輪執行。
- **結果**：由原 CLI+Schema Reader 產同 Subject/Source/Scope 輸出；CLI Help/Dryrun 不等於 Native E2E。

#### pipd export
- **出處**：`BODY-02:1273`；原 `pipd` Verb `pipd export`。
- binaryOrigin：source module via Python311 `-B -m pipd_ls_sp.cli`；cwd 本任務 work；installed binary origin NOT_OBSERVED。
- effectScope：LOCAL_DRAFT_WRITE_CANDIDATE_ONLY; repair actual repo scope requires L2；此輪只 `--help` 和 invalid flag，不執行該verb效果。
- helpSchema（exit=0）：
- nonzero：`export --definitely-invalid-flag` exit=2，typed stdout：
- 真實作用的POS/NEG與permission保留原下列契約；parser help成功不能聲稱compile/doctor功能已被本輪執行。
- **結果**：由原 CLI+Schema Reader 產同 Subject/Source/Scope 輸出；CLI Help/Dryrun 不等於 Native E2E。

#### pipd diff
- **出處**：`BODY-02:1304`；原 `pipd` Verb `pipd diff`。
- binaryOrigin：source module via Python311 `-B -m pipd_ls_sp.cli`；cwd 本任務 work；installed binary origin NOT_OBSERVED。
- effectScope：SOURCE_READ；此輪只 `--help` 和 invalid flag，不執行該verb效果。
- helpSchema（exit=0）：
- nonzero：`diff --definitely-invalid-flag` exit=2，typed stdout：
- 真實作用的POS/NEG與permission保留原下列契約；parser help成功不能聲稱compile/doctor功能已被本輪執行。
- **結果**：由原 CLI+Schema Reader 產同 Subject/Source/Scope 輸出；CLI Help/Dryrun 不等於 Native E2E。

#### pipd repair
- **出處**：`BODY-02:1332`；原 `pipd` Verb `pipd repair`。
- binaryOrigin：source module via Python311 `-B -m pipd_ls_sp.cli`；cwd 本任務 work；installed binary origin NOT_OBSERVED。
- effectScope：LOCAL_DRAFT_WRITE_CANDIDATE_ONLY; repair actual repo scope requires L2；此輪只 `--help` 和 invalid flag，不執行該verb效果。
- helpSchema（exit=0）：
- nonzero：`repair --definitely-invalid-flag` exit=2，typed stdout：
- 真實作用的POS/NEG與permission保留原下列契約；parser help成功不能聲稱compile/doctor功能已被本輪執行。
- **結果**：由原 CLI+Schema Reader 產同 Subject/Source/Scope 輸出；CLI Help/Dryrun 不等於 Native E2E。


## 本輪同域受影修復：plugin Stage 原合約與五出口

## 依 sbl-tpm-sp 實讀 SkillContract 的八階候選包（不冒正式 Canonical）

1. `pipd-route-intake`：Input 只接受非空 Goal + 至少一個不跳出 admitted root 的 source locator，輸出 content-addressed IntentCard。POS：可定位來源且按域產必要 atom；NEG：blank goal、空來源、`../` 立即 `INTAKE_INVALID/AUTHORITY_UNKNOWN`。
2. `pipd-authority-source`：每 family 的 SHA-256、file locator、Rank、supersession、conflict 必全部有據；本輪只造作者端 `SourceManifest`，未得原 Owner 正式 SourceFreeze，不能將物理 digest 擅升為正式 freeze。NEG：缺 SHA／跨 root／互斥來源 `AUTHORITY_UNKNOWN`。
3. `pipd-profile-tailor`：`LITE/STANDARD/ASSURED` 共九正交軸，safety veto 只升不降；provider-off parity 必須時由 LITE 升 STANDARD，超出 axis ceiling 依原合約升級；Profile T4/T5 `CR-DOC04-STATE-MAP` 仍 HOLD。
4. `pipd-pi-compile`：嚴格 Input 只有 intent/profile/atoms/goal；每 atom 必須有原 source_clause、owner、acceptance_cue、risk_guard；嚴禁 `_profile_meta` sidecar 偷塞 strict record。因未讀到真當期 Compiler Run，本輪提供 PI Proposal 和 atom TraceLink，不稱正式 `PI-PKG`。
5. `pipd-pd-bind`：必須本輪有真 RepoContext(root/head/tracked_files/currentness/writable_scope)，不接受 README 路徑當 repo root；沒有 Windows current HEAD/index/untracked 的時候 `REPO_CONTEXT_MISSING`，保留尚可用 SPEC/PI 設計。
6. `pipd-execution-contract`：DEV ConstructionContract/DEV ECP 與 OPS/USER/REMOTE/RELEASE 各自 permission/effect 不能混；exact WriteSet、preimage、expected changes/tests、at-most-once、readback residue、rollback pointer。原許可缺件只做 ECP design proposal，不 mint token。
7. `pipd-assurance-tqaep`：本輪為 `SBL.PlannedTQAEP@1`，每原 atom/case 有 POS/NEG、Oracle/fixture、raw expectation；真 `TQAEP` 的 `checker_execution_receipt` 必須是不同 principal、真正受保護 Reader 提供，禁止 SELF_ATTESTED。
8. `pipd-package-project`：完成文檔 hash、trace closure 和 EvidenceExpectation；本次最多 `AUTHOR_SIDE_STATIC_VALIDATED`，沒有 `LOCAL_QUALIFIED` 所需的原批准+Checker；正式 Claim Ladder 未越權。

**五個 PIPD 產物交付位置**：PI design 以 BODY-02 和 10B 的 original atom/trace；PD design 以 BODY-03/10B 的 repo late-binding contract；DEV ECP 以 BODY-03/10B 的 RepoWrite；OPS ECP 以 BODY-04/06/10B 的 Host effect；TQAEP design 以 BODY-07/10A 的 POS/NEG/Oracle/Fixture。五出口皆 `PROPOSED_WITH_EVIDENCE_GAP` 而非偽造的原 Runtime Record。


---


## R2 現行／歷史 Reader 隔離

本檔此處以上及本輪新增 R2 小節為**唯一當期整合設計 Reader**；前版 Revision2 已位元組保存於證據 ZIP `02_EVIDENCE_AUDIT_APPENDICES/_superseded_2026-10-30_r1/02_PIPD_LIFECYCLE_AND_TPM_R1_REVISION2_VERBATIM.md`（SHA256 `a2768e5488be88ea0b1fadbc460447937ba6f810e6c5af4a93d069e572b8d40f`）。歷史條位不得由 Parser 以同號 ID 當 CURRENT，也不得用歷史 HOLD 覆寫本輪受影修補。原 Domain Writer 法位不變。

## R2 PI：正式 Reader 對齊候選／當前保守停點

**三 SPEC 真實受影內容**：ProductSPEC 的 persona=單人 Owner、JTBD=普通 Goal 自動導向產品、FUO=八 Kind 中各有 Host 可測首成果或 NoFit、ACC=原產品 Oracle、NEG=README-only；ArchitectureSPEC 固定唯一 SBL Product Owner、PIPD Writer、Fabric Policy、HGK Issuer、Hermes Executor、Independent Checker，拒絕第二控制平面；ProgramSPEC 從原 22 WP typed DAG 做最小適用子圖、Resume=同 subject/source/scope/epoch。

- `IntentCard@1` 正式入參 **僅** `goal,sources[].rel,constraints,non_goals`，不可進 `_profile_meta`；原 Source locator 取上傳指令，`source_sha256=835934a4397c9840de0d4c529f1800414f1c679ba797d61c67529060e1c5a8c7`。負例：空 Goal/缺 Source/traversal 優先 `INTAKE_INVALID/AUTHORITY_UNKNOWN`。
- `ProfileBinding` 以 `ASSURED` 的本次安全 veto 設計提案；九軸與 T4/T5 原 Owner StateMap 仍 `CR-DOC04-STATE-MAP`，不能自行把 Profile 名稱當原 Ratified State。
- `PI-PKG` 入參 `intent(subject_id,content_hash),profile=ASSURED,goal,atoms[]`，本輪實例逐 atom 帶 `req_id,source_clause,owner,acceptance_cue,risk_guard`；當期 `PI-PKG` 只有 historical schema shape validation，**未由 PIPD 原 CLI Writer compile**；無 `Writer ACK` 不提升正式 PI。
- `SourceFreezeManifest` 要正式 SourceFamilies／AuthorityBinding；本輪 SourceManifest SHA 及 offline `IntentCard` 不是正式 SourceFreeze。原 Reader 缺 epoch/OwnerDecision 就受影 `SOURCEFREEZE_HOLD`，不阻擋 L0 Draft。
- Schema 對齊素材在證據 ZIP `_machine/R2_OFFLINE_PIPD_CANDIDATES/` 中，逐條 positive/negative 在本章文字已固化；只做本地草稿，不以範例 JSON 當正式五出口。

## R2 高保留歷史（不可執行，排除於本版 Parser）

以下內容完整保留先前 Revision2 的參考語義。**所有標題和 ID 均為 archive 文字，不是本版有效條位**；如需 source-level regression，可讀證據包未包裝的原檔及 SHA。

~~~~~~~markdown
## 高保留原 BODY Revision2 實質正文（沿用未受影區；遇 r2 修補採本冊前段）

---
artifact_id: FHS-MSC-R2-BODY-02
formal_name: PIPD 生命週期、TPM 18 Stage、19 Contract 與13 CLI
short_name: BODY-02
version: 2026-10-29-r2-revision2
source_set_hash_or_pending: f86b217ae3c3ee28183570f4bf3d4f08d4d00e9b86d1de1a641a630f8682d1a1
intended_consumer: 原領域 Owner 與下游 Reader
owner_role: 作者端規格修補者；原 Domain Writer 不移轉
design_status: SOURCE_BOUND_REPAIR_CANDIDATE
claim_ceiling: AUTHOR_STATIC_ONLY; NATIVE_NOT_RUN; CHECKER_NOT_RUN; RELEASE_NOT_RUN
supersession_scope: 本輪作者候選revision2；保留前版封存；不取代任何原Canonical Writer版本
AUDIT_F_IDs:
- F-03
- F-12
- F-13
---

# PIPD 生命週期、TPM 18 Stage、19 Contract 與13 CLI

## R2-02-HANDOFF：五個正式出口與候選隔離

SOURCE/PROFILE→PI：`pipd-route-intake` 只收 nonblank goal+contained sources；authority-source每family有file digest+locators，衝突拒freeze；profile-tailor九軸safety veto不得降級；pi-compile strict shape只有intent/profile/atoms/goal。POS原五REQ namespace可重播identity；NEG `_profile_meta` → schema NACK；project atom lossless sidecar不混入strict payload。

PI→PD：原pd-bind消費PI、真RepoContext與currentness。先read real root/HEAD/index/untracked/reparse/ACL，再late-bind exact writable scope；NEG stale HEAD或foreign subject→PD_BIND_NACK。沒有當期root evidence不得用README或歷史sha代用。

PD→DEV Construction/ECP：同subject的writable_scope/expected_changes/tests/rollback/evidence；exact preimage+原Issuer admission才可Repo effect。PD→OPS ECP：Host/User/Remote/Release分receiver/grant/nonce/TTL/epoch，不能套用DEV grant。POS分別對原Writer schema ACK；NEG ECP string當Permit→ADMISSION_DENIED。文稿僅候選，無真Compiler/Host ACK不得冒正式包。

TQAEP計畫→Checker：`SBL.PlannedTQAEP@1`保留per-atom POS/NEG/oracle/fixture，不提供live receipt。正式TQAEP/受保護check需不同credential及本輪Raw reader；Maker輸入receipt字串不能自簽。POS 真Reader查same candidate/Oracle/identity；NEG foreign receipt或same Maker→SELF_ACCEPTANCE_DENY。

DOC07 canonical Oracle↔legacy DOC03與十二風險軸→九context enum有語義落差；原Owner需提供alias/migration/loss ledger、roundtrip POS/NEG與Writer ACK。缺此只PI語義promotion及依賴ECP HOLD；不阻已合法admitted工作。

## R2-02-STAGE：K0–K3 與原18-stage投影

插件 corpus 24檔完整性重算PASS；K0原bytes/K1 clause index/K2相容提案/K3 bounded reader。歷史fixture不是live收據。T4/T5受CR-DOC04-STATE-MAP影響仍為formal HOLD，Draft SPEC可繼續。

| Stage | input→operation→output | Owner→Consumer | guard/first_fail/source |
|---|---|---|---|
| PM:T0 | ['goalcard', 'known_answer_refs', 'source_sha256'] → segregate facts from user guesses; detect unanswered JTBD → ProductKnownState@1(goal_sha,missing_questions) | ProductOwner → ProductOwner/PIPD Reader | GoalCard+known_answer_refs; source_sha present / KNOWN_ANSWER_REASK / {'source_id': 'SBL-04', 'sha256': 'ee90cb1c86f6f7350c11c9c962233a89b035ca41ff82c8968f7968608fc6f6e0', 'line': 510} |
| PM:T1 | ['persona', 'painledger', 'jtbd', 'source_sha256'] → rank questions by user information gain → QuestionPriority@1(qid,impact,source_ref) | ProductOwner → ProductOwner/PIPD Reader | Persona+PainLedger+JTBD; source_sha present / JTBD_UNBOUND / {'source_id': 'SBL-04', 'sha256': 'ee90cb1c86f6f7350c11c9c962233a89b035ca41ff82c8968f7968608fc6f6e0', 'line': 511} |
| PM:T2 | ['fuo', 'useroutcome', 'variants', 'source_sha256'] → define observable CLI/add,list,delete or brownfield user result → ProductSuccess@1(FUO,exit_code,negative_cases) | ProductOwner → ProductOwner/PIPD Reader | FUO+UserOutcome+variants; source_sha present / FUO_UNTESTABLE / {'source_id': 'SBL-04', 'sha256': 'ee90cb1c86f6f7350c11c9c962233a89b035ca41ff82c8968f7968608fc6f6e0', 'line': 512} |
| PM:T3 | ['productsuccess', 'primarykind', 'source_sha256'] → compile ProductSPEC draft and acceptance cues → ProductSPECDraft@1(journey_id,kind,acceptance_sha) | ProductOwner → ProductOwner/PIPD Reader | ProductSuccess+PrimaryKind; source_sha present / KIND_ID_DRIFT / {'source_id': 'SBL-04', 'sha256': 'ee90cb1c86f6f7350c11c9c962233a89b035ca41ff82c8968f7968608fc6f6e0', 'line': 513} |
| PM:T4 | ['productspecdraft', 'acc_neg', 'source_sha256'] → issue user-facing POS/NEG proposal, not Native verdict → ProductAcceptanceProposal@1(pos,neg,raw_expect) | ProductOwner → ProductOwner/PIPD Reader | ProductSPECDraft+ACC_NEG; source_sha present / ACC_NOT_BOUND / {'source_id': 'SBL-04', 'sha256': 'ee90cb1c86f6f7350c11c9c962233a89b035ca41ff82c8968f7968608fc6f6e0', 'line': 514} |
| PM:T5 | ['fuo_raw_refs', 'feedback', 'source_sha256'] → compare observable use vs claimed outcome; create repair request → ProductReviewRequest@1(gap,affected_journeys) | ProductOwner → ProductOwner/PIPD Reader | FUO_raw_refs+feedback; source_sha present / FUO_RAW_MISSING / {'source_id': 'SBL-04', 'sha256': 'ee90cb1c86f6f7350c11c9c962233a89b035ca41ff82c8968f7968608fc6f6e0', 'line': 515} |
| SE:T0 | ['repoboundaries', 'sourceindex', 'source_sha256'] → enumerate source/destination trust seams → SystemReadset@1(owners,sha,scope) | ArchitectureOwner → ArchitectureOwner/HostReader | RepoBoundaries+SourceIndex; source_sha present / SYSTEM_SOURCE_GAP / {'source_id': 'SBL-04', 'sha256': 'ee90cb1c86f6f7350c11c9c962233a89b035ca41ff82c8968f7968608fc6f6e0', 'line': 516} |
| SE:T1 | ['systemreadset', 'adrrefs', 'source_sha256'] → assign every seam to exactly one writer → OwnershipSeamMap@1(writer,reader,forbidden_effect) | ArchitectureOwner → ArchitectureOwner/HostReader | SystemReadset+ADRRefs; source_sha present / SEAM_OWNER_CONFLICT / {'source_id': 'SBL-04', 'sha256': 'ee90cb1c86f6f7350c11c9c962233a89b035ca41ff82c8968f7968608fc6f6e0', 'line': 517} |
| SE:T2 | ['riskinventory', 'hostcaps', 'source_sha256'] → trade off typed ABI and provider-off reliability → ADRSet@1(option,tradeoff,security_guard) | ArchitectureOwner → ArchitectureOwner/HostReader | RiskInventory+HostCaps; source_sha present / ARCHITECTURE_RISK_OPEN / {'source_id': 'SBL-04', 'sha256': 'ee90cb1c86f6f7350c11c9c962233a89b035ca41ff82c8968f7968608fc6f6e0', 'line': 518} |
| SE:T3 | ['adrset', 'c4', 'componentcards', 'source_sha256'] → bind schemas and compatibility version → ArchitectureSPEC@1(abi,compat,host_matrix) | ArchitectureOwner → ArchitectureOwner/HostReader | ADRSet+C4+ComponentCards; source_sha present / ABI_SCHEMA_MISMATCH / {'source_id': 'SBL-04', 'sha256': 'ee90cb1c86f6f7350c11c9c962233a89b035ca41ff82c8968f7968608fc6f6e0', 'line': 519} |
| SE:T4 | ['architecturespec', 'boundaryneg', 'source_sha256'] → test scope/token/provider-off/thin adapter semantics → ArchitectureNEGRequest@1(neg,oracle_source) | ArchitectureOwner → ArchitectureOwner/HostReader | ArchitectureSPEC+BoundaryNEG; source_sha present / PERMISSION_NEG_MISSING / {'source_id': 'SBL-04', 'sha256': 'ee90cb1c86f6f7350c11c9c962233a89b035ca41ff82c8968f7968608fc6f6e0', 'line': 520} |
| SE:T5 | ['nativerawrefs', 'integrationrisks', 'source_sha256'] → re-evaluate actual host ABI and raw results → ArchitectureReview@1(findings,repair_cone) | ArchitectureOwner → ArchitectureOwner/HostReader | NativeRawRefs+IntegrationRisks; source_sha present / HOST_RAW_MISSING / {'source_id': 'SBL-04', 'sha256': 'ee90cb1c86f6f7350c11c9c962233a89b035ca41ff82c8968f7968608fc6f6e0', 'line': 521} |
| TPgM:T0 | ['ownerroster', 'costtime', 'source_sha256'] → identify budget milestones without claiming approval → ProgramIntent@1(milestone,owner,risk) | ProgramOwner → ProgramOwner/NativeRouter | OwnerRoster+CostTime; source_sha present / MILESTONE_OWNER_MISSING / {'source_id': 'SBL-04', 'sha256': 'ee90cb1c86f6f7350c11c9c962233a89b035ca41ff82c8968f7968608fc6f6e0', 'line': 522} |
| TPgM:T1 | ['unknowndependencies', 'resourcecaps', 'source_sha256'] → record sequencing constraints and blocking decisions → SchedulingAssumptions@1(edges,confidence) | ProgramOwner → ProgramOwner/NativeRouter | UnknownDependencies+ResourceCaps; source_sha present / UNBOUNDED_WORK / {'source_id': 'SBL-04', 'sha256': 'ee90cb1c86f6f7350c11c9c962233a89b035ca41ff82c8968f7968608fc6f6e0', 'line': 523} |
| TPgM:T2 | ['ownergates', 'dependencyedges', 'source_sha256'] → toposort bounded DAG and cycle check → ProgramDAG@1(topo,locks,no_fit) | ProgramOwner → ProgramOwner/NativeRouter | OwnerGates+DependencyEdges; source_sha present / DAG_CYCLE / {'source_id': 'SBL-04', 'sha256': 'ee90cb1c86f6f7350c11c9c962233a89b035ca41ff82c8968f7968608fc6f6e0', 'line': 524} |
| TPgM:T3 | ['programdag', 'productspec', 'architecturespec', 'source_sha256'] → package work with traceable scope and approver → ProgramSPEC@1(wp,effort,owner,stop) | ProgramOwner → ProgramOwner/NativeRouter | ProgramDAG+ProductSPEC+ArchitectureSPEC; source_sha present / WP_SCOPE_UNKNOWN / {'source_id': 'SBL-04', 'sha256': 'ee90cb1c86f6f7350c11c9c962233a89b035ca41ff82c8968f7968608fc6f6e0', 'line': 525} |
| TPgM:T4 | ['pi_pd_refs', 'verifierreferral', 'source_sha256'] → route to correct Native ECP/Oracle Owner → HandoffReferral@1(expected_grants,oracle_conflict) | ProgramOwner → ProgramOwner/NativeRouter | PI_PD_refs+VerifierReferral; source_sha present / CR_ORACLE_001 / {'source_id': 'SBL-04', 'sha256': 'ee90cb1c86f6f7350c11c9c962233a89b035ca41ff82c8968f7968608fc6f6e0', 'line': 526} |
| TPgM:T5 | ['milestoneraw', 'issueledger', 'source_sha256'] → review schedule with evidence status; refreeze affected only → ProgramReview@1(blocked_waves,replan_cone) | ProgramOwner → ProgramOwner/NativeRouter | MilestoneRaw+IssueLedger; source_sha present / STALE_MILESTONE_EVIDENCE / {'source_id': 'SBL-04', 'sha256': 'ee90cb1c86f6f7350c11c9c962233a89b035ca41ff82c8968f7968608fc6f6e0', 'line': 527} |

## R2-02-CONTRACTS：19 種真Schema與domain invariant

當期Schema中多數內層properties是 `{}`。因此JSON Schema只驗required/unknown欄，不保證domain語義。下列專屬Reader invariant是來源約束的修補設計；Host Registry綁定與真semantic validator仍需原Owner。不得把此弱schema的syntactic PASS宣稱完整Native conformance。

### ArtifactIdentity

- 原 Registry source：C:\Projects\Agent_Workspace\PIPD\schemas\ArtifactIdentity.schema.json；SHA `67d26f18d26307410bf0be5369949eb525d477e053ee3a7091e54b97f6d4ad4c`；`$id=urn:pipd:s0:ArtifactIdentity:1`；schema dialect 2020-12；additionalProperties=false。
- Producer/Consumer：Owner: PIPD. Consumer: all planes.
- required：subject_id, version, content_hash, schema_version, supersedes, invalidates。
- 專屬 Reader invariant：相同 canonical body 得相同 content_hash；supersedes/invalidates 指到舊版本且不能自指。
- Domain NEG：alter body but retain content_hash → `HASH_MISMATCH`；與 missing-required/unknown-key 的 schema拒收分開。
- roundtrip：原 Reader重序列化 payload，再讀回相同identity/trace；schema syntactic fixture通過不證明content_hash/Principal/License有效。
- POS/NEG payload（只供本輪Schema fixture，不是live artifact）：
```json
{
  "valid_shape_only": {
    "subject_id": "STATIC-ArtifactIdentity",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:ArtifactIdentity:1",
    "supersedes": "STATIC_FIXTURE_ArtifactIdentity_supersedes",
    "invalidates": "STATIC_FIXTURE_ArtifactIdentity_invalidates"
  },
  "invalid_missing_required": {
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:ArtifactIdentity:1",
    "supersedes": "STATIC_FIXTURE_ArtifactIdentity_supersedes",
    "invalidates": "STATIC_FIXTURE_ArtifactIdentity_invalidates"
  },
  "invalid_unknown_field": {
    "subject_id": "STATIC-ArtifactIdentity",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:ArtifactIdentity:1",
    "supersedes": "STATIC_FIXTURE_ArtifactIdentity_supersedes",
    "invalidates": "STATIC_FIXTURE_ArtifactIdentity_invalidates",
    "_profile_meta": {
      "not": "native"
    }
  }
}
```

### AuthorityBinding

- 原 Registry source：C:\Projects\Agent_Workspace\PIPD\schemas\AuthorityBinding.schema.json；SHA `66f1b3ce91d7f12ad6a6350a6628afd6c600e3e7ff62408b714c6fa0f1898ded`；`$id=urn:pipd:s0:AuthorityBinding:1`；schema dialect 2020-12；additionalProperties=false。
- Producer/Consumer：Owner: PIPD. Consumer: all compilers/adapters.
- required：source_id, authority_rank, locator, supersession, conflict_state, subject_id, version, content_hash, schema_version。
- 專屬 Reader invariant：來源存在且 file SHA 符合；CURRENT 無 unresolved conflict 才可供 Compiler。
- Domain NEG：conflict_state=CONFLICT but promotion requested → `AUTHORITY_CONFLICT`；與 missing-required/unknown-key 的 schema拒收分開。
- roundtrip：原 Reader重序列化 payload，再讀回相同identity/trace；schema syntactic fixture通過不證明content_hash/Principal/License有效。
- POS/NEG payload（只供本輪Schema fixture，不是live artifact）：
```json
{
  "valid_shape_only": {
    "source_id": "STATIC_FIXTURE_AuthorityBinding_source_id",
    "authority_rank": "STATIC_FIXTURE_AuthorityBinding_authority_rank",
    "locator": "STATIC_FIXTURE_AuthorityBinding_locator",
    "supersession": "STATIC_FIXTURE_AuthorityBinding_supersession",
    "conflict_state": "STATIC_FIXTURE_AuthorityBinding_conflict_state",
    "subject_id": "STATIC-AuthorityBinding",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:AuthorityBinding:1"
  },
  "invalid_missing_required": {
    "authority_rank": "STATIC_FIXTURE_AuthorityBinding_authority_rank",
    "locator": "STATIC_FIXTURE_AuthorityBinding_locator",
    "supersession": "STATIC_FIXTURE_AuthorityBinding_supersession",
    "conflict_state": "STATIC_FIXTURE_AuthorityBinding_conflict_state",
    "subject_id": "STATIC-AuthorityBinding",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:AuthorityBinding:1"
  },
  "invalid_unknown_field": {
    "source_id": "STATIC_FIXTURE_AuthorityBinding_source_id",
    "authority_rank": "STATIC_FIXTURE_AuthorityBinding_authority_rank",
    "locator": "STATIC_FIXTURE_AuthorityBinding_locator",
    "supersession": "STATIC_FIXTURE_AuthorityBinding_supersession",
    "conflict_state": "STATIC_FIXTURE_AuthorityBinding_conflict_state",
    "subject_id": "STATIC-AuthorityBinding",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:AuthorityBinding:1",
    "_profile_meta": {
      "not": "native"
    }
  }
}
```

### ClaimCeiling

- 原 Registry source：C:\Projects\Agent_Workspace\PIPD\schemas\ClaimCeiling.schema.json；SHA `dbb2ce4dd322da99ca3b3067274b85928b995aba59ca3f04802d5e8ba253ab85`；`$id=urn:pipd:s0:ClaimCeiling:1`；schema dialect 2020-12；additionalProperties=false。
- Producer/Consumer：Owner: PIPD. Consumer: all planes.
- required：allowed_claims, forbidden_escalation, close_conditions, subject_id, version, content_hash, schema_version。
- 專屬 Reader invariant：allowed_claims需真證據階梯；forbidden_escalation與close_conditions有效。
- Domain NEG：AUTHOR_STATIC promoted to RELEASED → `CLAIM_ESCALATION`；與 missing-required/unknown-key 的 schema拒收分開。
- roundtrip：原 Reader重序列化 payload，再讀回相同identity/trace；schema syntactic fixture通過不證明content_hash/Principal/License有效。
- POS/NEG payload（只供本輪Schema fixture，不是live artifact）：
```json
{
  "valid_shape_only": {
    "allowed_claims": "STATIC_FIXTURE_ClaimCeiling_allowed_claims",
    "forbidden_escalation": "STATIC_FIXTURE_ClaimCeiling_forbidden_escalation",
    "close_conditions": "STATIC_FIXTURE_ClaimCeiling_close_conditions",
    "subject_id": "STATIC-ClaimCeiling",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:ClaimCeiling:1"
  },
  "invalid_missing_required": {
    "forbidden_escalation": "STATIC_FIXTURE_ClaimCeiling_forbidden_escalation",
    "close_conditions": "STATIC_FIXTURE_ClaimCeiling_close_conditions",
    "subject_id": "STATIC-ClaimCeiling",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:ClaimCeiling:1"
  },
  "invalid_unknown_field": {
    "allowed_claims": "STATIC_FIXTURE_ClaimCeiling_allowed_claims",
    "forbidden_escalation": "STATIC_FIXTURE_ClaimCeiling_forbidden_escalation",
    "close_conditions": "STATIC_FIXTURE_ClaimCeiling_close_conditions",
    "subject_id": "STATIC-ClaimCeiling",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:ClaimCeiling:1",
    "_profile_meta": {
      "not": "native"
    }
  }
}
```

### ConstructionContract

- 原 Registry source：C:\Projects\Agent_Workspace\PIPD\schemas\ConstructionContract.schema.json；SHA `1c56f15abd6e30d06f914f021b0b813f441689f9d47989ef48c7d7325557f0f2`；`$id=urn:pipd:s0:ConstructionContract:1`；schema dialect 2020-12；additionalProperties=false。
- Producer/Consumer：Owner: PIPD. Consumer: HGK adapter.
- required：subject, writable_scope, expected_changes, tests, rollback, evidence_expectations, subject_id, version, content_hash, schema_version。
- 專屬 Reader invariant：writable_scope exact contained paths，expected_changes/tests/rollback 對同 preimage。
- Domain NEG：scope=** or path escapes root → `CC_SCOPE`；與 missing-required/unknown-key 的 schema拒收分開。
- roundtrip：原 Reader重序列化 payload，再讀回相同identity/trace；schema syntactic fixture通過不證明content_hash/Principal/License有效。
- POS/NEG payload（只供本輪Schema fixture，不是live artifact）：
```json
{
  "valid_shape_only": {
    "subject": "STATIC_FIXTURE_ConstructionContract_subject",
    "writable_scope": "STATIC_FIXTURE_ConstructionContract_writable_scope",
    "expected_changes": "STATIC_FIXTURE_ConstructionContract_expected_changes",
    "tests": "STATIC_FIXTURE_ConstructionContract_tests",
    "rollback": "STATIC_FIXTURE_ConstructionContract_rollback",
    "evidence_expectations": "STATIC_FIXTURE_ConstructionContract_evidence_expectations",
    "subject_id": "STATIC-ConstructionContract",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:ConstructionContract:1"
  },
  "invalid_missing_required": {
    "writable_scope": "STATIC_FIXTURE_ConstructionContract_writable_scope",
    "expected_changes": "STATIC_FIXTURE_ConstructionContract_expected_changes",
    "tests": "STATIC_FIXTURE_ConstructionContract_tests",
    "rollback": "STATIC_FIXTURE_ConstructionContract_rollback",
    "evidence_expectations": "STATIC_FIXTURE_ConstructionContract_evidence_expectations",
    "subject_id": "STATIC-ConstructionContract",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:ConstructionContract:1"
  },
  "invalid_unknown_field": {
    "subject": "STATIC_FIXTURE_ConstructionContract_subject",
    "writable_scope": "STATIC_FIXTURE_ConstructionContract_writable_scope",
    "expected_changes": "STATIC_FIXTURE_ConstructionContract_expected_changes",
    "tests": "STATIC_FIXTURE_ConstructionContract_tests",
    "rollback": "STATIC_FIXTURE_ConstructionContract_rollback",
    "evidence_expectations": "STATIC_FIXTURE_ConstructionContract_evidence_expectations",
    "subject_id": "STATIC-ConstructionContract",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:ConstructionContract:1",
    "_profile_meta": {
      "not": "native"
    }
  }
}
```

### ECP

- 原 Registry source：C:\Projects\Agent_Workspace\PIPD\schemas\ECP.schema.json；SHA `c58a8f3ed42808ba20f0102bb6fc7074d4fa321ea779879aa5ceefc6864d1de8`；`$id=urn:pipd:s0:ECP:1`；schema dialect 2020-12；additionalProperties=false。
- Producer/Consumer：Owner: PIPD/ECP semantics. Consumer: HGK/TQAEP.
- required：effect_intent, permission, retries, idempotency, readback, rollback, subject_id, version, content_hash, schema_version。
- 專屬 Reader invariant：effect_intent/permission/retries/idempotency/readback/rollback按同scope；UNKNOWN不得重播。
- Domain NEG：DEV permission used for HOST_OP → `WRONG_EFFECT_GRANT`；與 missing-required/unknown-key 的 schema拒收分開。
- roundtrip：原 Reader重序列化 payload，再讀回相同identity/trace；schema syntactic fixture通過不證明content_hash/Principal/License有效。
- POS/NEG payload（只供本輪Schema fixture，不是live artifact）：
```json
{
  "valid_shape_only": {
    "effect_intent": "STATIC_FIXTURE_ECP_effect_intent",
    "permission": "STATIC_FIXTURE_ECP_permission",
    "retries": "STATIC_FIXTURE_ECP_retries",
    "idempotency": "STATIC_FIXTURE_ECP_idempotency",
    "readback": "STATIC_FIXTURE_ECP_readback",
    "rollback": "STATIC_FIXTURE_ECP_rollback",
    "subject_id": "STATIC-ECP",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:ECP:1"
  },
  "invalid_missing_required": {
    "permission": "STATIC_FIXTURE_ECP_permission",
    "retries": "STATIC_FIXTURE_ECP_retries",
    "idempotency": "STATIC_FIXTURE_ECP_idempotency",
    "readback": "STATIC_FIXTURE_ECP_readback",
    "rollback": "STATIC_FIXTURE_ECP_rollback",
    "subject_id": "STATIC-ECP",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:ECP:1"
  },
  "invalid_unknown_field": {
    "effect_intent": "STATIC_FIXTURE_ECP_effect_intent",
    "permission": "STATIC_FIXTURE_ECP_permission",
    "retries": "STATIC_FIXTURE_ECP_retries",
    "idempotency": "STATIC_FIXTURE_ECP_idempotency",
    "readback": "STATIC_FIXTURE_ECP_readback",
    "rollback": "STATIC_FIXTURE_ECP_rollback",
    "subject_id": "STATIC-ECP",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:ECP:1",
    "_profile_meta": {
      "not": "native"
    }
  }
}
```

### EvidenceExpectation

- 原 Registry source：C:\Projects\Agent_Workspace\PIPD\schemas\EvidenceExpectation.schema.json；SHA `02327839c21d5ba24d08dd52f9caa31a07616965c6235cece58487a810b99b7f`；`$id=urn:pipd:s0:EvidenceExpectation:1`；schema dialect 2020-12；additionalProperties=false。
- Producer/Consumer：Owner: PIPD/TQAEP. Consumer: HGK/CI/provider.
- required：expected_evidence_type, producer, postcondition, freshness, claim_effect, subject_id, version, content_hash, schema_version。
- 專屬 Reader invariant：expected_evidence_type/producer/postcondition/freshness/claim_effect只描述期待。
- Domain NEG：expected raw path promoted to observed receipt → `EXPECTED_IS_NOT_RAW`；與 missing-required/unknown-key 的 schema拒收分開。
- roundtrip：原 Reader重序列化 payload，再讀回相同identity/trace；schema syntactic fixture通過不證明content_hash/Principal/License有效。
- POS/NEG payload（只供本輪Schema fixture，不是live artifact）：
```json
{
  "valid_shape_only": {
    "expected_evidence_type": "STATIC_FIXTURE_EvidenceExpectation_expected_evidence_type",
    "producer": "STATIC_FIXTURE_EvidenceExpectation_producer",
    "postcondition": "STATIC_FIXTURE_EvidenceExpectation_postcondition",
    "freshness": "STATIC_FIXTURE_EvidenceExpectation_freshness",
    "claim_effect": "STATIC_FIXTURE_EvidenceExpectation_claim_effect",
    "subject_id": "STATIC-EvidenceExpectation",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:EvidenceExpectation:1"
  },
  "invalid_missing_required": {
    "producer": "STATIC_FIXTURE_EvidenceExpectation_producer",
    "postcondition": "STATIC_FIXTURE_EvidenceExpectation_postcondition",
    "freshness": "STATIC_FIXTURE_EvidenceExpectation_freshness",
    "claim_effect": "STATIC_FIXTURE_EvidenceExpectation_claim_effect",
    "subject_id": "STATIC-EvidenceExpectation",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:EvidenceExpectation:1"
  },
  "invalid_unknown_field": {
    "expected_evidence_type": "STATIC_FIXTURE_EvidenceExpectation_expected_evidence_type",
    "producer": "STATIC_FIXTURE_EvidenceExpectation_producer",
    "postcondition": "STATIC_FIXTURE_EvidenceExpectation_postcondition",
    "freshness": "STATIC_FIXTURE_EvidenceExpectation_freshness",
    "claim_effect": "STATIC_FIXTURE_EvidenceExpectation_claim_effect",
    "subject_id": "STATIC-EvidenceExpectation",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:EvidenceExpectation:1",
    "_profile_meta": {
      "not": "native"
    }
  }
}
```

### ExecutionBindingRef

- 原 Registry source：C:\Projects\Agent_Workspace\PIPD\schemas\ExecutionBindingRef.schema.json；SHA `7c98cebfee30d9719cb8fd2d565c44120ce8d1be5b231071c19528cae1e95f50`；`$id=urn:pipd:s0:ExecutionBindingRef:1`；schema dialect 2020-12；additionalProperties=false。
- Producer/Consumer：Owner: HGK adapter. Consumer: HGK. Schema seam only until S5. Receiver binding id/version/hash/lease/state; ACK only after HGK admission.
- required：receiver_binding_id, receiver_binding_version, receiver_binding_hash, lease, state, subject_id, version, content_hash, schema_version。
- 專屬 Reader invariant：receiver_binding_id/version/hash+lease/state同原HGK Reader；seam不取代Issuer。
- Domain NEG：foreign lease generation used to execute → `LEASE_FENCING_DENY`；與 missing-required/unknown-key 的 schema拒收分開。
- roundtrip：原 Reader重序列化 payload，再讀回相同identity/trace；schema syntactic fixture通過不證明content_hash/Principal/License有效。
- POS/NEG payload（只供本輪Schema fixture，不是live artifact）：
```json
{
  "valid_shape_only": {
    "receiver_binding_id": "STATIC_FIXTURE_ExecutionBindingRef_receiver_binding_id",
    "receiver_binding_version": "STATIC_FIXTURE_ExecutionBindingRef_receiver_binding_version",
    "receiver_binding_hash": "STATIC_FIXTURE_ExecutionBindingRef_receiver_binding_hash",
    "lease": "STATIC_FIXTURE_ExecutionBindingRef_lease",
    "state": "STATIC_FIXTURE_ExecutionBindingRef_state",
    "subject_id": "STATIC-ExecutionBindingRef",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:ExecutionBindingRef:1"
  },
  "invalid_missing_required": {
    "receiver_binding_version": "STATIC_FIXTURE_ExecutionBindingRef_receiver_binding_version",
    "receiver_binding_hash": "STATIC_FIXTURE_ExecutionBindingRef_receiver_binding_hash",
    "lease": "STATIC_FIXTURE_ExecutionBindingRef_lease",
    "state": "STATIC_FIXTURE_ExecutionBindingRef_state",
    "subject_id": "STATIC-ExecutionBindingRef",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:ExecutionBindingRef:1"
  },
  "invalid_unknown_field": {
    "receiver_binding_id": "STATIC_FIXTURE_ExecutionBindingRef_receiver_binding_id",
    "receiver_binding_version": "STATIC_FIXTURE_ExecutionBindingRef_receiver_binding_version",
    "receiver_binding_hash": "STATIC_FIXTURE_ExecutionBindingRef_receiver_binding_hash",
    "lease": "STATIC_FIXTURE_ExecutionBindingRef_lease",
    "state": "STATIC_FIXTURE_ExecutionBindingRef_state",
    "subject_id": "STATIC-ExecutionBindingRef",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:ExecutionBindingRef:1",
    "_profile_meta": {
      "not": "native"
    }
  }
}
```

### ExecutionHandoff

- 原 Registry source：C:\Projects\Agent_Workspace\PIPD\schemas\ExecutionHandoff.schema.json；SHA `7fa36d3e7fe6e7416111b975381a42f3f5ad46cc81d97b610f317548815bd77b`；`$id=urn:pipd:s0:ExecutionHandoff:1`；schema dialect 2020-12；additionalProperties=false。
- Producer/Consumer：Owner: PIPD. Consumer: HGK/other receiver.
- required：receiver, abi_version, payload_refs, ack_nack_state, subject_id, version, content_hash, schema_version。
- 專屬 Reader invariant：receiver/abi_version/payload_refs真ACK payload hash與Consumer scope。
- Domain NEG：NACK or wrong receiver treated as ACK → `HANDOFF_NACK`；與 missing-required/unknown-key 的 schema拒收分開。
- roundtrip：原 Reader重序列化 payload，再讀回相同identity/trace；schema syntactic fixture通過不證明content_hash/Principal/License有效。
- POS/NEG payload（只供本輪Schema fixture，不是live artifact）：
```json
{
  "valid_shape_only": {
    "receiver": "STATIC_FIXTURE_ExecutionHandoff_receiver",
    "abi_version": "STATIC_FIXTURE_ExecutionHandoff_abi_version",
    "payload_refs": "STATIC_FIXTURE_ExecutionHandoff_payload_refs",
    "ack_nack_state": "STATIC_FIXTURE_ExecutionHandoff_ack_nack_state",
    "subject_id": "STATIC-ExecutionHandoff",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:ExecutionHandoff:1"
  },
  "invalid_missing_required": {
    "abi_version": "STATIC_FIXTURE_ExecutionHandoff_abi_version",
    "payload_refs": "STATIC_FIXTURE_ExecutionHandoff_payload_refs",
    "ack_nack_state": "STATIC_FIXTURE_ExecutionHandoff_ack_nack_state",
    "subject_id": "STATIC-ExecutionHandoff",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:ExecutionHandoff:1"
  },
  "invalid_unknown_field": {
    "receiver": "STATIC_FIXTURE_ExecutionHandoff_receiver",
    "abi_version": "STATIC_FIXTURE_ExecutionHandoff_abi_version",
    "payload_refs": "STATIC_FIXTURE_ExecutionHandoff_payload_refs",
    "ack_nack_state": "STATIC_FIXTURE_ExecutionHandoff_ack_nack_state",
    "subject_id": "STATIC-ExecutionHandoff",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:ExecutionHandoff:1",
    "_profile_meta": {
      "not": "native"
    }
  }
}
```

### GENIEProjectionRef

- 原 Registry source：C:\Projects\Agent_Workspace\PIPD\schemas\GENIEProjectionRef.schema.json；SHA `22c88a0f9ec4ea4747967546f9a5ea7f19f0285be60ac42567fae2ca0b1c36ed`；`$id=urn:pipd:s0:GENIEProjectionRef:1`；schema dialect 2020-12；additionalProperties=false。
- Producer/Consumer：Owner: GENIE adapter. Consumer: GENIE compiler. Schema seam only until S6. Target references to ProductGraph, Profile, Bundle and GENIEArtifact; no truth writeback.
- required：target_refs, subject_id, version, content_hash, schema_version。
- 專屬 Reader invariant：僅讀GENIE target_refs，保留SCHEMA_SEAM_ONLY；不成第二Writer。
- Domain NEG：projection creates native GENIE authority → `GENIE_WRITER_COLLISION`；與 missing-required/unknown-key 的 schema拒收分開。
- roundtrip：原 Reader重序列化 payload，再讀回相同identity/trace；schema syntactic fixture通過不證明content_hash/Principal/License有效。
- POS/NEG payload（只供本輪Schema fixture，不是live artifact）：
```json
{
  "valid_shape_only": {
    "target_refs": {
      "ProductGraph": "STATIC_REFERENCE_ProductGraph",
      "Profile": "STATIC_REFERENCE_Profile",
      "Bundle": "STATIC_REFERENCE_Bundle",
      "GENIEArtifact": "STATIC_REFERENCE_GENIEArtifact"
    },
    "subject_id": "STATIC-GENIEProjectionRef",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:GENIEProjectionRef:1"
  },
  "invalid_missing_required": {
    "subject_id": "STATIC-GENIEProjectionRef",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:GENIEProjectionRef:1"
  },
  "invalid_unknown_field": {
    "target_refs": {
      "ProductGraph": "STATIC_REFERENCE_ProductGraph",
      "Profile": "STATIC_REFERENCE_Profile",
      "Bundle": "STATIC_REFERENCE_Bundle",
      "GENIEArtifact": "STATIC_REFERENCE_GENIEArtifact"
    },
    "subject_id": "STATIC-GENIEProjectionRef",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:GENIEProjectionRef:1",
    "_profile_meta": {
      "not": "native"
    }
  }
}
```

### PD-PKG

- 原 Registry source：C:\Projects\Agent_Workspace\PIPD\schemas\PD-PKG.schema.json；SHA `37291e8790e03839308a7c36125f9576d14da725a27480c9759ef5362d255541`；`$id=urn:pipd:s0:PD-PKG:1`；schema dialect 2020-12；additionalProperties=false。
- Producer/Consumer：Owner: PIPD. Consumer: execution handoff.
- required：RepoContext, currentness, late_bound_construction_binding, subject_id, version, content_hash, schema_version。
- 專屬 Reader invariant：RepoContext 是當期真 root/HEAD/index/untracked，currentness 與晚綁 scope一致。
- Domain NEG：HEAD drift with old RepoContext → `PD_BIND_STALE`；與 missing-required/unknown-key 的 schema拒收分開。
- roundtrip：原 Reader重序列化 payload，再讀回相同identity/trace；schema syntactic fixture通過不證明content_hash/Principal/License有效。
- POS/NEG payload（只供本輪Schema fixture，不是live artifact）：
```json
{
  "valid_shape_only": {
    "RepoContext": "STATIC_FIXTURE_PD-PKG_RepoContext",
    "currentness": "STATIC_FIXTURE_PD-PKG_currentness",
    "late_bound_construction_binding": "STATIC_FIXTURE_PD-PKG_late_bound_construction_binding",
    "subject_id": "STATIC-PD-PKG",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:PD-PKG:1"
  },
  "invalid_missing_required": {
    "currentness": "STATIC_FIXTURE_PD-PKG_currentness",
    "late_bound_construction_binding": "STATIC_FIXTURE_PD-PKG_late_bound_construction_binding",
    "subject_id": "STATIC-PD-PKG",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:PD-PKG:1"
  },
  "invalid_unknown_field": {
    "RepoContext": "STATIC_FIXTURE_PD-PKG_RepoContext",
    "currentness": "STATIC_FIXTURE_PD-PKG_currentness",
    "late_bound_construction_binding": "STATIC_FIXTURE_PD-PKG_late_bound_construction_binding",
    "subject_id": "STATIC-PD-PKG",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:PD-PKG:1",
    "_profile_meta": {
      "not": "native"
    }
  }
}
```

### PI-PKG

- 原 Registry source：C:\Projects\Agent_Workspace\PIPD\schemas\PI-PKG.schema.json；SHA `2a204aceba8d2764310a729c7c105301296e11d57d6c91f17bb8372214f793fe`；`$id=urn:pipd:s0:PI-PKG:1`；schema dialect 2020-12；additionalProperties=false。
- Producer/Consumer：Owner: PIPD. Consumer: PD binder.
- required：stable_semantic_contract, trace, acceptance, subject_id, version, content_hash, schema_version。
- 專屬 Reader invariant：stable_semantic_contract 包含全部原原子 trace；Oracle canonical Writer相容。
- Domain NEG：sidecar appended as top-level _profile_meta → `PI_SCHEMA`；與 missing-required/unknown-key 的 schema拒收分開。
- roundtrip：原 Reader重序列化 payload，再讀回相同identity/trace；schema syntactic fixture通過不證明content_hash/Principal/License有效。
- POS/NEG payload（只供本輪Schema fixture，不是live artifact）：
```json
{
  "valid_shape_only": {
    "stable_semantic_contract": "STATIC_FIXTURE_PI-PKG_stable_semantic_contract",
    "trace": "STATIC_FIXTURE_PI-PKG_trace",
    "acceptance": "STATIC_FIXTURE_PI-PKG_acceptance",
    "subject_id": "STATIC-PI-PKG",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:PI-PKG:1"
  },
  "invalid_missing_required": {
    "trace": "STATIC_FIXTURE_PI-PKG_trace",
    "acceptance": "STATIC_FIXTURE_PI-PKG_acceptance",
    "subject_id": "STATIC-PI-PKG",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:PI-PKG:1"
  },
  "invalid_unknown_field": {
    "stable_semantic_contract": "STATIC_FIXTURE_PI-PKG_stable_semantic_contract",
    "trace": "STATIC_FIXTURE_PI-PKG_trace",
    "acceptance": "STATIC_FIXTURE_PI-PKG_acceptance",
    "subject_id": "STATIC-PI-PKG",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:PI-PKG:1",
    "_profile_meta": {
      "not": "native"
    }
  }
}
```

### ProfileBinding

- 原 Registry source：C:\Projects\Agent_Workspace\PIPD\schemas\ProfileBinding.schema.json；SHA `b559fb70bb6ceb9d491c989cb5ec031f44d15bcad5b40e75d6649aa059a93556`；`$id=urn:pipd:s0:ProfileBinding:1`；schema dialect 2020-12；additionalProperties=false。
- Producer/Consumer：Owner: PIPD. Consumer: Skills/JIT/HGK.
- required：profile, axes, vetoes, artifact_depth, assurance, subject_id, version, content_hash, schema_version。
- 專屬 Reader invariant：九軸 strict enum、去重與 safety veto 只升級；十二軸另存 lossless bridge。
- Domain NEG：unknown axis or downgrade ASSURED → `PROFILE_VETO`；與 missing-required/unknown-key 的 schema拒收分開。
- roundtrip：原 Reader重序列化 payload，再讀回相同identity/trace；schema syntactic fixture通過不證明content_hash/Principal/License有效。
- POS/NEG payload（只供本輪Schema fixture，不是live artifact）：
```json
{
  "valid_shape_only": {
    "profile": "STATIC_FIXTURE_ProfileBinding_profile",
    "axes": "STATIC_FIXTURE_ProfileBinding_axes",
    "vetoes": "STATIC_FIXTURE_ProfileBinding_vetoes",
    "artifact_depth": "STATIC_FIXTURE_ProfileBinding_artifact_depth",
    "assurance": "STATIC_FIXTURE_ProfileBinding_assurance",
    "subject_id": "STATIC-ProfileBinding",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:ProfileBinding:1"
  },
  "invalid_missing_required": {
    "axes": "STATIC_FIXTURE_ProfileBinding_axes",
    "vetoes": "STATIC_FIXTURE_ProfileBinding_vetoes",
    "artifact_depth": "STATIC_FIXTURE_ProfileBinding_artifact_depth",
    "assurance": "STATIC_FIXTURE_ProfileBinding_assurance",
    "subject_id": "STATIC-ProfileBinding",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:ProfileBinding:1"
  },
  "invalid_unknown_field": {
    "profile": "STATIC_FIXTURE_ProfileBinding_profile",
    "axes": "STATIC_FIXTURE_ProfileBinding_axes",
    "vetoes": "STATIC_FIXTURE_ProfileBinding_vetoes",
    "artifact_depth": "STATIC_FIXTURE_ProfileBinding_artifact_depth",
    "assurance": "STATIC_FIXTURE_ProfileBinding_assurance",
    "subject_id": "STATIC-ProfileBinding",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:ProfileBinding:1",
    "_profile_meta": {
      "not": "native"
    }
  }
}
```

### RequirementAtom

- 原 Registry source：C:\Projects\Agent_Workspace\PIPD\schemas\RequirementAtom.schema.json；SHA `021f6a30cf178190281176138686447e492640cf97b125f9c21a0aa2fa31c684`；`$id=urn:pipd:s0:RequirementAtom:1`；schema dialect 2020-12；additionalProperties=false。
- Producer/Consumer：Owner: PIPD. Consumer: PI compiler/TQAEP.
- required：req_id, source_clause, owner, acceptance_cue, risk_guard, subject_id, version, content_hash, schema_version。
- 專屬 Reader invariant：source_clause 實讀、owner 可識別、acceptance_cue 可反證、risk_guard 不空；保留否定作用域。
- Domain NEG：positive wording replaces source prohibition → `ATOM_POLARITY_LOSS`；與 missing-required/unknown-key 的 schema拒收分開。
- roundtrip：原 Reader重序列化 payload，再讀回相同identity/trace；schema syntactic fixture通過不證明content_hash/Principal/License有效。
- POS/NEG payload（只供本輪Schema fixture，不是live artifact）：
```json
{
  "valid_shape_only": {
    "req_id": "STATIC_FIXTURE_RequirementAtom_req_id",
    "source_clause": "STATIC_FIXTURE_RequirementAtom_source_clause",
    "owner": "STATIC_FIXTURE_RequirementAtom_owner",
    "acceptance_cue": "STATIC_FIXTURE_RequirementAtom_acceptance_cue",
    "risk_guard": "STATIC_FIXTURE_RequirementAtom_risk_guard",
    "subject_id": "STATIC-RequirementAtom",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:RequirementAtom:1"
  },
  "invalid_missing_required": {
    "source_clause": "STATIC_FIXTURE_RequirementAtom_source_clause",
    "owner": "STATIC_FIXTURE_RequirementAtom_owner",
    "acceptance_cue": "STATIC_FIXTURE_RequirementAtom_acceptance_cue",
    "risk_guard": "STATIC_FIXTURE_RequirementAtom_risk_guard",
    "subject_id": "STATIC-RequirementAtom",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:RequirementAtom:1"
  },
  "invalid_unknown_field": {
    "req_id": "STATIC_FIXTURE_RequirementAtom_req_id",
    "source_clause": "STATIC_FIXTURE_RequirementAtom_source_clause",
    "owner": "STATIC_FIXTURE_RequirementAtom_owner",
    "acceptance_cue": "STATIC_FIXTURE_RequirementAtom_acceptance_cue",
    "risk_guard": "STATIC_FIXTURE_RequirementAtom_risk_guard",
    "subject_id": "STATIC-RequirementAtom",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:RequirementAtom:1",
    "_profile_meta": {
      "not": "native"
    }
  }
}
```

### SurfaceProjectionManifest

- 原 Registry source：C:\Projects\Agent_Workspace\PIPD\schemas\SurfaceProjectionManifest.schema.json；SHA `87f8057e8dac68f304ed4e9c2dd118a26c69428015769ab09d39398d34dcb57d`；`$id=urn:pipd:s0:SurfaceProjectionManifest:1`；schema dialect 2020-12；additionalProperties=false。
- Producer/Consumer：Owner: PIPD. Consumer: surface compiler.
- required：surface, source_hashes, generated_files, parity_loss, stale_rule, subject_id, version, content_hash, schema_version。
- 專屬 Reader invariant：surface/source_hashes/generated_files/parity_loss/stale_rule可重算；loss不默丟。
- Domain NEG：stale source hash still projected as current → `PROJECTION_STALE`；與 missing-required/unknown-key 的 schema拒收分開。
- roundtrip：原 Reader重序列化 payload，再讀回相同identity/trace；schema syntactic fixture通過不證明content_hash/Principal/License有效。
- POS/NEG payload（只供本輪Schema fixture，不是live artifact）：
```json
{
  "valid_shape_only": {
    "surface": "STATIC_FIXTURE_SurfaceProjectionManifest_surface",
    "source_hashes": "STATIC_FIXTURE_SurfaceProjectionManifest_source_hashes",
    "generated_files": "STATIC_FIXTURE_SurfaceProjectionManifest_generated_files",
    "parity_loss": "STATIC_FIXTURE_SurfaceProjectionManifest_parity_loss",
    "stale_rule": "STATIC_FIXTURE_SurfaceProjectionManifest_stale_rule",
    "subject_id": "STATIC-SurfaceProjectionManifest",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:SurfaceProjectionManifest:1"
  },
  "invalid_missing_required": {
    "source_hashes": "STATIC_FIXTURE_SurfaceProjectionManifest_source_hashes",
    "generated_files": "STATIC_FIXTURE_SurfaceProjectionManifest_generated_files",
    "parity_loss": "STATIC_FIXTURE_SurfaceProjectionManifest_parity_loss",
    "stale_rule": "STATIC_FIXTURE_SurfaceProjectionManifest_stale_rule",
    "subject_id": "STATIC-SurfaceProjectionManifest",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:SurfaceProjectionManifest:1"
  },
  "invalid_unknown_field": {
    "surface": "STATIC_FIXTURE_SurfaceProjectionManifest_surface",
    "source_hashes": "STATIC_FIXTURE_SurfaceProjectionManifest_source_hashes",
    "generated_files": "STATIC_FIXTURE_SurfaceProjectionManifest_generated_files",
    "parity_loss": "STATIC_FIXTURE_SurfaceProjectionManifest_parity_loss",
    "stale_rule": "STATIC_FIXTURE_SurfaceProjectionManifest_stale_rule",
    "subject_id": "STATIC-SurfaceProjectionManifest",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:SurfaceProjectionManifest:1",
    "_profile_meta": {
      "not": "native"
    }
  }
}
```

### TaskSpecSeed

- 原 Registry source：C:\Projects\Agent_Workspace\PIPD\schemas\TaskSpecSeed.schema.json；SHA `c6e086aef0e4f21179cba52c5187c33a3873b18732c669c4d03bcad057e9b6cc`；`$id=urn:pipd:s0:TaskSpecSeed:1`；schema dialect 2020-12；additionalProperties=false。
- Producer/Consumer：Owner: PIPD. Consumer: receiver adapter.
- required：goal, inputs, outputs, constraints, dependencies, tests, rollback, evidence, subject_id, version, content_hash, schema_version。
- 專屬 Reader invariant：goal→inputs→outputs→tests→rollback/evidence 可閉合且 dependencies 有具名輸出。
- Domain NEG：output has no consumer or test → `TASKSEED_INCOMPLETE`；與 missing-required/unknown-key 的 schema拒收分開。
- roundtrip：原 Reader重序列化 payload，再讀回相同identity/trace；schema syntactic fixture通過不證明content_hash/Principal/License有效。
- POS/NEG payload（只供本輪Schema fixture，不是live artifact）：
```json
{
  "valid_shape_only": {
    "goal": "STATIC_FIXTURE_TaskSpecSeed_goal",
    "inputs": "STATIC_FIXTURE_TaskSpecSeed_inputs",
    "outputs": "STATIC_FIXTURE_TaskSpecSeed_outputs",
    "constraints": "STATIC_FIXTURE_TaskSpecSeed_constraints",
    "dependencies": "STATIC_FIXTURE_TaskSpecSeed_dependencies",
    "tests": "STATIC_FIXTURE_TaskSpecSeed_tests",
    "rollback": "STATIC_FIXTURE_TaskSpecSeed_rollback",
    "evidence": "STATIC_FIXTURE_TaskSpecSeed_evidence",
    "subject_id": "STATIC-TaskSpecSeed",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:TaskSpecSeed:1"
  },
  "invalid_missing_required": {
    "inputs": "STATIC_FIXTURE_TaskSpecSeed_inputs",
    "outputs": "STATIC_FIXTURE_TaskSpecSeed_outputs",
    "constraints": "STATIC_FIXTURE_TaskSpecSeed_constraints",
    "dependencies": "STATIC_FIXTURE_TaskSpecSeed_dependencies",
    "tests": "STATIC_FIXTURE_TaskSpecSeed_tests",
    "rollback": "STATIC_FIXTURE_TaskSpecSeed_rollback",
    "evidence": "STATIC_FIXTURE_TaskSpecSeed_evidence",
    "subject_id": "STATIC-TaskSpecSeed",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:TaskSpecSeed:1"
  },
  "invalid_unknown_field": {
    "goal": "STATIC_FIXTURE_TaskSpecSeed_goal",
    "inputs": "STATIC_FIXTURE_TaskSpecSeed_inputs",
    "outputs": "STATIC_FIXTURE_TaskSpecSeed_outputs",
    "constraints": "STATIC_FIXTURE_TaskSpecSeed_constraints",
    "dependencies": "STATIC_FIXTURE_TaskSpecSeed_dependencies",
    "tests": "STATIC_FIXTURE_TaskSpecSeed_tests",
    "rollback": "STATIC_FIXTURE_TaskSpecSeed_rollback",
    "evidence": "STATIC_FIXTURE_TaskSpecSeed_evidence",
    "subject_id": "STATIC-TaskSpecSeed",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:TaskSpecSeed:1",
    "_profile_meta": {
      "not": "native"
    }
  }
}
```

### TechnologyAdmission

- 原 Registry source：C:\Projects\Agent_Workspace\PIPD\schemas\TechnologyAdmission.schema.json；SHA `40703552af4fb14c7aa87dd68ead6eac1cf7d272541fda273cf22b8fb109c4d6`；`$id=urn:pipd:s0:TechnologyAdmission:1`；schema dialect 2020-12；additionalProperties=false。
- Producer/Consumer：Owner: PIPD. Consumer: tool/provider adapters. Tightened from the untyped `{}` shape found in review: every field now carries a type and the source's 24-column design record (PKG-00 §9.2) is representable without additionalProperties loss.
- required：capability_need, candidate, disposition, pin_license_currentness, fallback_exit, subject_id, version, content_hash, schema_version, technology_id, external_name, capability_slot, license, immutable_pin。
- 專屬 Reader invariant：原 disposition 與17-state不默變；license+immutable_pin 真讀回，REJECT 不進 install。
- Domain NEG：REJECT candidate sent to installer → `TECH_ADMISSION_DENY`；與 missing-required/unknown-key 的 schema拒收分開。
- roundtrip：原 Reader重序列化 payload，再讀回相同identity/trace；schema syntactic fixture通過不證明content_hash/Principal/License有效。
- POS/NEG payload（只供本輪Schema fixture，不是live artifact）：
```json
{
  "valid_shape_only": {
    "capability_need": "STATIC_FIXTURE_TechnologyAdmission_capability_need",
    "candidate": "STATIC_FIXTURE_TechnologyAdmission_candidate",
    "disposition": "STATIC_FIXTURE_TechnologyAdmission_disposition",
    "pin_license_currentness": {},
    "fallback_exit": "STATIC_FIXTURE_TechnologyAdmission_fallback_exit",
    "subject_id": "STATIC-TechnologyAdmission",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:TechnologyAdmission:1",
    "technology_id": "STATIC_FIXTURE_TechnologyAdmission_technology_id",
    "external_name": "STATIC_FIXTURE_TechnologyAdmission_external_name",
    "capability_slot": "STATIC_FIXTURE_TechnologyAdmission_capability_slot",
    "license": "STATIC_FIXTURE_TechnologyAdmission_license",
    "immutable_pin": "STATIC_FIXTURE_TechnologyAdmission_immutable_pin"
  },
  "invalid_missing_required": {
    "candidate": "STATIC_FIXTURE_TechnologyAdmission_candidate",
    "disposition": "STATIC_FIXTURE_TechnologyAdmission_disposition",
    "pin_license_currentness": {},
    "fallback_exit": "STATIC_FIXTURE_TechnologyAdmission_fallback_exit",
    "subject_id": "STATIC-TechnologyAdmission",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:TechnologyAdmission:1",
    "technology_id": "STATIC_FIXTURE_TechnologyAdmission_technology_id",
    "external_name": "STATIC_FIXTURE_TechnologyAdmission_external_name",
    "capability_slot": "STATIC_FIXTURE_TechnologyAdmission_capability_slot",
    "license": "STATIC_FIXTURE_TechnologyAdmission_license",
    "immutable_pin": "STATIC_FIXTURE_TechnologyAdmission_immutable_pin"
  },
  "invalid_unknown_field": {
    "capability_need": "STATIC_FIXTURE_TechnologyAdmission_capability_need",
    "candidate": "STATIC_FIXTURE_TechnologyAdmission_candidate",
    "disposition": "STATIC_FIXTURE_TechnologyAdmission_disposition",
    "pin_license_currentness": {},
    "fallback_exit": "STATIC_FIXTURE_TechnologyAdmission_fallback_exit",
    "subject_id": "STATIC-TechnologyAdmission",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:TechnologyAdmission:1",
    "technology_id": "STATIC_FIXTURE_TechnologyAdmission_technology_id",
    "external_name": "STATIC_FIXTURE_TechnologyAdmission_external_name",
    "capability_slot": "STATIC_FIXTURE_TechnologyAdmission_capability_slot",
    "license": "STATIC_FIXTURE_TechnologyAdmission_license",
    "immutable_pin": "STATIC_FIXTURE_TechnologyAdmission_immutable_pin",
    "_profile_meta": {
      "not": "native"
    }
  }
}
```

### TQAEP

- 原 Registry source：C:\Projects\Agent_Workspace\PIPD\schemas\TQAEP.schema.json；SHA `d14092817befb5e81c470449b9ac5160b6fba7e3fcde450ec00d1cadc21820cd`；`$id=urn:pipd:s0:TQAEP:1`；schema dialect 2020-12；additionalProperties=false。
- Producer/Consumer：Owner: PIPD/TQAEP semantics. Consumer: Independent checker/release.
- required：tests, oracles, fixtures, acceptance, requalification, subject_id, version, content_hash, schema_version。
- 專屬 Reader invariant：tests/oracles/fixtures/acceptance/requalification 逐atom對應；受保護receipt另讀。
- Domain NEG：PlannedTQAEP or Maker expected interpreted as actual verdict → `SELF_ACCEPTANCE_DENY`；與 missing-required/unknown-key 的 schema拒收分開。
- roundtrip：原 Reader重序列化 payload，再讀回相同identity/trace；schema syntactic fixture通過不證明content_hash/Principal/License有效。
- POS/NEG payload（只供本輪Schema fixture，不是live artifact）：
```json
{
  "valid_shape_only": {
    "tests": "STATIC_FIXTURE_TQAEP_tests",
    "oracles": "STATIC_FIXTURE_TQAEP_oracles",
    "fixtures": "STATIC_FIXTURE_TQAEP_fixtures",
    "acceptance": "STATIC_FIXTURE_TQAEP_acceptance",
    "requalification": "STATIC_FIXTURE_TQAEP_requalification",
    "subject_id": "STATIC-TQAEP",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:TQAEP:1"
  },
  "invalid_missing_required": {
    "oracles": "STATIC_FIXTURE_TQAEP_oracles",
    "fixtures": "STATIC_FIXTURE_TQAEP_fixtures",
    "acceptance": "STATIC_FIXTURE_TQAEP_acceptance",
    "requalification": "STATIC_FIXTURE_TQAEP_requalification",
    "subject_id": "STATIC-TQAEP",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:TQAEP:1"
  },
  "invalid_unknown_field": {
    "tests": "STATIC_FIXTURE_TQAEP_tests",
    "oracles": "STATIC_FIXTURE_TQAEP_oracles",
    "fixtures": "STATIC_FIXTURE_TQAEP_fixtures",
    "acceptance": "STATIC_FIXTURE_TQAEP_acceptance",
    "requalification": "STATIC_FIXTURE_TQAEP_requalification",
    "subject_id": "STATIC-TQAEP",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:TQAEP:1",
    "_profile_meta": {
      "not": "native"
    }
  }
}
```

### TraceLink

- 原 Registry source：C:\Projects\Agent_Workspace\PIPD\schemas\TraceLink.schema.json；SHA `ff6ef713b95a1a2812bd31d2b10cdcc064671c986d29d0e69318dc5a9f54e5e4`；`$id=urn:pipd:s0:TraceLink:1`；schema dialect 2020-12；additionalProperties=false。
- Producer/Consumer：Owner: PIPD/TQAEP. Consumer: validators/checkers.
- required：from_type, from_id, from_hash, to_type, to_id, to_hash, rationale, subject_id, version, content_hash, schema_version。
- 專屬 Reader invariant：from_id/from_hash 與 to_id/to_hash 可在 bundle雙向解析；方向不交換。
- Domain NEG：to_hash names another candidate → `TRACE_HASH_MISMATCH`；與 missing-required/unknown-key 的 schema拒收分開。
- roundtrip：原 Reader重序列化 payload，再讀回相同identity/trace；schema syntactic fixture通過不證明content_hash/Principal/License有效。
- POS/NEG payload（只供本輪Schema fixture，不是live artifact）：
```json
{
  "valid_shape_only": {
    "from_type": "STATIC_FIXTURE_TraceLink_from_type",
    "from_id": "STATIC_FIXTURE_TraceLink_from_id",
    "from_hash": "STATIC_FIXTURE_TraceLink_from_hash",
    "to_type": "STATIC_FIXTURE_TraceLink_to_type",
    "to_id": "STATIC_FIXTURE_TraceLink_to_id",
    "to_hash": "STATIC_FIXTURE_TraceLink_to_hash",
    "rationale": "STATIC_FIXTURE_TraceLink_rationale",
    "subject_id": "STATIC-TraceLink",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:TraceLink:1"
  },
  "invalid_missing_required": {
    "from_id": "STATIC_FIXTURE_TraceLink_from_id",
    "from_hash": "STATIC_FIXTURE_TraceLink_from_hash",
    "to_type": "STATIC_FIXTURE_TraceLink_to_type",
    "to_id": "STATIC_FIXTURE_TraceLink_to_id",
    "to_hash": "STATIC_FIXTURE_TraceLink_to_hash",
    "rationale": "STATIC_FIXTURE_TraceLink_rationale",
    "subject_id": "STATIC-TraceLink",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:TraceLink:1"
  },
  "invalid_unknown_field": {
    "from_type": "STATIC_FIXTURE_TraceLink_from_type",
    "from_id": "STATIC_FIXTURE_TraceLink_from_id",
    "from_hash": "STATIC_FIXTURE_TraceLink_from_hash",
    "to_type": "STATIC_FIXTURE_TraceLink_to_type",
    "to_id": "STATIC_FIXTURE_TraceLink_to_id",
    "to_hash": "STATIC_FIXTURE_TraceLink_to_hash",
    "rationale": "STATIC_FIXTURE_TraceLink_rationale",
    "subject_id": "STATIC-TraceLink",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:TraceLink:1",
    "_profile_meta": {
      "not": "native"
    }
  }
}
```

### WorkOrderCandidate

- 原 Registry source：C:\Projects\Agent_Workspace\PIPD\schemas\WorkOrderCandidate.schema.json；SHA `03a8692f183f106ec7e4739b925c980ba07d68551627ca6af315fa9f9e2caf54`；`$id=urn:pipd:s0:WorkOrderCandidate:1`；schema dialect 2020-12；additionalProperties=false。
- Producer/Consumer：Owner: PIPD. Consumer: HGK admission. Candidate only; never runtime authority.
- required：candidate_only, subject_id, version, content_hash, schema_version。
- 專屬 Reader invariant：candidate_only=true；只送原HGK admission，不能直接 enqueue。
- Domain NEG：candidate_only=false → `CANDIDATE_NOT_AUTHORITY`；與 missing-required/unknown-key 的 schema拒收分開。
- roundtrip：原 Reader重序列化 payload，再讀回相同identity/trace；schema syntactic fixture通過不證明content_hash/Principal/License有效。
- POS/NEG payload（只供本輪Schema fixture，不是live artifact）：
```json
{
  "valid_shape_only": {
    "candidate_only": true,
    "subject_id": "STATIC-WorkOrderCandidate",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:WorkOrderCandidate:1"
  },
  "invalid_missing_required": {
    "subject_id": "STATIC-WorkOrderCandidate",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:WorkOrderCandidate:1"
  },
  "invalid_unknown_field": {
    "candidate_only": true,
    "subject_id": "STATIC-WorkOrderCandidate",
    "version": "1",
    "content_hash": "0000000000000000000000000000000000000000000000000000000000000000",
    "schema_version": "urn:pipd:s0:WorkOrderCandidate:1",
    "_profile_meta": {
      "not": "native"
    }
  }
}
```


## R2-02-CLI：13 原 verb 的 parser 真讀回與額外 verb 衝突

當期 `C:/Projects/Agent_Workspace/PIPD/src/pipd_ls_sp/cli.py` SHA `6db0f828f0a445fcf3593b158c534d02a0a89f1e263746cabda8c043dd462cc9` 的 source module 已實跑 help/invalid parser；這是 SOURCE_MODULE_INVOKED，不是 installed binary Loaded Receipt。實作列14個verb，額外 compile-cc；原13保持獨立分母，額外verb為 `ABI_HOLD_CLI_13_14`，由PIPD CLI Owner決定版本相容/alias，不在本輪偷偷刪原需求或增第14條規範。

### pipd init

- binaryOrigin：source module via Python311 `-B -m pipd_ls_sp.cli`；cwd 本任務 work；installed binary origin NOT_OBSERVED。
- effectScope：LOCAL_DRAFT_WRITE_CANDIDATE_ONLY; repair actual repo scope requires L2；此輪只 `--help` 和 invalid flag，不執行該verb效果。
- helpSchema（exit=0）：

```text
usage: pipd init [-h]

options:
  -h, --help  show this help message and exit
```

- nonzero：`init --definitely-invalid-flag` exit=2，typed stdout：

```text
{
 "code": "USAGE_INVALID",
 "message": "invalid command line; see --help for the 13 commands",
 "verdict": "FAIL"
}
```

- 真實作用的POS/NEG與permission保留原下列契約；parser help成功不能聲稱compile/doctor功能已被本輪執行。

### pipd intake

- binaryOrigin：source module via Python311 `-B -m pipd_ls_sp.cli`；cwd 本任務 work；installed binary origin NOT_OBSERVED。
- effectScope：LOCAL_DRAFT_WRITE_CANDIDATE_ONLY; repair actual repo scope requires L2；此輪只 `--help` 和 invalid flag，不執行該verb效果。
- helpSchema（exit=0）：

```text
usage: pipd intake [-h] --goal GOAL [--source SOURCE]
                   [--constraint CONSTRAINT] [--non-goal NON_GOAL]

options:
  -h, --help            show this help message and exit
  --goal GOAL
  --source SOURCE
  --constraint CONSTRAINT
  --non-goal NON_GOAL
```

- nonzero：`intake --definitely-invalid-flag` exit=2，typed stdout：

```text
{
 "code": "USAGE_INVALID",
 "message": "invalid command line; see --help for the 13 commands",
 "verdict": "FAIL"
}
```

- 真實作用的POS/NEG與permission保留原下列契約；parser help成功不能聲稱compile/doctor功能已被本輪執行。

### pipd profile

- binaryOrigin：source module via Python311 `-B -m pipd_ls_sp.cli`；cwd 本任務 work；installed binary origin NOT_OBSERVED。
- effectScope：LOCAL_DRAFT_WRITE_CANDIDATE_ONLY; repair actual repo scope requires L2；此輪只 `--help` 和 invalid flag，不執行該verb效果。
- helpSchema（exit=0）：

```text
usage: pipd profile [-h] [--profile PROFILE] [--axis AXIS]

options:
  -h, --help         show this help message and exit
  --profile PROFILE
  --axis AXIS
```

- nonzero：`profile --definitely-invalid-flag` exit=2，typed stdout：

```text
{
 "code": "USAGE_INVALID",
 "message": "invalid command line; see --help for the 13 commands",
 "verdict": "FAIL"
}
```

- 真實作用的POS/NEG與permission保留原下列契約；parser help成功不能聲稱compile/doctor功能已被本輪執行。

### pipd compile-pi

- binaryOrigin：source module via Python311 `-B -m pipd_ls_sp.cli`；cwd 本任務 work；installed binary origin NOT_OBSERVED。
- effectScope：LOCAL_DRAFT_WRITE_CANDIDATE_ONLY; repair actual repo scope requires L2；此輪只 `--help` 和 invalid flag，不執行該verb效果。
- helpSchema（exit=0）：

```text
usage: pipd compile-pi [-h] --intent INTENT [--profile PROFILE] [--explain]
                       [--replay]

options:
  -h, --help         show this help message and exit
  --intent INTENT
  --profile PROFILE
  --explain
  --replay
```

- nonzero：`compile-pi --definitely-invalid-flag` exit=2，typed stdout：

```text
{
 "code": "USAGE_INVALID",
 "message": "invalid command line; see --help for the 13 commands",
 "verdict": "FAIL"
}
```

- 真實作用的POS/NEG與permission保留原下列契約；parser help成功不能聲稱compile/doctor功能已被本輪執行。

### pipd bind-pd

- binaryOrigin：source module via Python311 `-B -m pipd_ls_sp.cli`；cwd 本任務 work；installed binary origin NOT_OBSERVED。
- effectScope：LOCAL_DRAFT_WRITE_CANDIDATE_ONLY; repair actual repo scope requires L2；此輪只 `--help` 和 invalid flag，不執行該verb效果。
- helpSchema（exit=0）：

```text
usage: pipd bind-pd [-h] --pi PI [--repo-root REPO_ROOT] [--head HEAD]

options:
  -h, --help            show this help message and exit
  --pi PI
  --repo-root REPO_ROOT
  --head HEAD
```

- nonzero：`bind-pd --definitely-invalid-flag` exit=2，typed stdout：

```text
{
 "code": "USAGE_INVALID",
 "message": "invalid command line; see --help for the 13 commands",
 "verdict": "FAIL"
}
```

- 真實作用的POS/NEG與permission保留原下列契約；parser help成功不能聲稱compile/doctor功能已被本輪執行。

### pipd compile-ecp

- binaryOrigin：source module via Python311 `-B -m pipd_ls_sp.cli`；cwd 本任務 work；installed binary origin NOT_OBSERVED。
- effectScope：LOCAL_DRAFT_WRITE_CANDIDATE_ONLY; repair actual repo scope requires L2；此輪只 `--help` 和 invalid flag，不執行該verb效果。
- helpSchema（exit=0）：

```text
usage: pipd compile-ecp [-h] --pd PD --pi PI [--explain]

options:
  -h, --help  show this help message and exit
  --pd PD
  --pi PI
  --explain
```

- nonzero：`compile-ecp --definitely-invalid-flag` exit=2，typed stdout：

```text
{
 "code": "USAGE_INVALID",
 "message": "invalid command line; see --help for the 13 commands",
 "verdict": "FAIL"
}
```

- 真實作用的POS/NEG與permission保留原下列契約；parser help成功不能聲稱compile/doctor功能已被本輪執行。

### pipd compile-tqaep

- binaryOrigin：source module via Python311 `-B -m pipd_ls_sp.cli`；cwd 本任務 work；installed binary origin NOT_OBSERVED。
- effectScope：LOCAL_DRAFT_WRITE_CANDIDATE_ONLY; repair actual repo scope requires L2；此輪只 `--help` 和 invalid flag，不執行該verb效果。
- helpSchema（exit=0）：

```text
usage: pipd compile-tqaep [-h] --pi PI --ecp ECP [--maker MAKER]
                          [--checker CHECKER]
                          [--checker-receipt CHECKER_RECEIPT] [--explain]

options:
  -h, --help            show this help message and exit
  --pi PI
  --ecp ECP
  --maker MAKER
  --checker CHECKER
  --checker-receipt CHECKER_RECEIPT
  --explain
```

- nonzero：`compile-tqaep --definitely-invalid-flag` exit=2，typed stdout：

```text
{
 "code": "USAGE_INVALID",
 "message": "invalid command line; see --help for the 13 commands",
 "verdict": "FAIL"
}
```

- 真實作用的POS/NEG與permission保留原下列契約；parser help成功不能聲稱compile/doctor功能已被本輪執行。

### pipd validate

- binaryOrigin：source module via Python311 `-B -m pipd_ls_sp.cli`；cwd 本任務 work；installed binary origin NOT_OBSERVED。
- effectScope：SOURCE_READ；此輪只 `--help` 和 invalid flag，不執行該verb效果。
- helpSchema（exit=0）：

```text
usage: pipd validate [-h] --bundle BUNDLE [--explain]

options:
  -h, --help       show this help message and exit
  --bundle BUNDLE
  --explain
```

- nonzero：`validate --definitely-invalid-flag` exit=2，typed stdout：

```text
{
 "code": "USAGE_INVALID",
 "message": "invalid command line; see --help for the 13 commands",
 "verdict": "FAIL"
}
```

- 真實作用的POS/NEG與permission保留原下列契約；parser help成功不能聲稱compile/doctor功能已被本輪執行。

### pipd doctor

- binaryOrigin：source module via Python311 `-B -m pipd_ls_sp.cli`；cwd 本任務 work；installed binary origin NOT_OBSERVED。
- effectScope：SOURCE_READ；此輪只 `--help` 和 invalid flag，不執行該verb效果。
- helpSchema（exit=0）：

```text
usage: pipd doctor [-h]

options:
  -h, --help  show this help message and exit
```

- nonzero：`doctor --definitely-invalid-flag` exit=2，typed stdout：

```text
{
 "code": "USAGE_INVALID",
 "message": "invalid command line; see --help for the 13 commands",
 "verdict": "FAIL"
}
```

- 真實作用的POS/NEG與permission保留原下列契約；parser help成功不能聲稱compile/doctor功能已被本輪執行。

### pipd project

- binaryOrigin：source module via Python311 `-B -m pipd_ls_sp.cli`；cwd 本任務 work；installed binary origin NOT_OBSERVED。
- effectScope：LOCAL_DRAFT_WRITE_CANDIDATE_ONLY; repair actual repo scope requires L2；此輪只 `--help` 和 invalid flag，不執行該verb效果。
- helpSchema（exit=0）：

```text
usage: pipd project [-h] [--out OUT] [--root SUB_ROOT] [--dry-run]
                    [--allow-root ALLOW_ROOT] [--allow-replace]

options:
  -h, --help            show this help message and exit
  --out OUT
  --root SUB_ROOT
  --dry-run
  --allow-root ALLOW_ROOT
  --allow-replace
```

- nonzero：`project --definitely-invalid-flag` exit=2，typed stdout：

```text
{
 "code": "USAGE_INVALID",
 "message": "invalid command line; see --help for the 13 commands",
 "verdict": "FAIL"
}
```

- 真實作用的POS/NEG與permission保留原下列契約；parser help成功不能聲稱compile/doctor功能已被本輪執行。

### pipd export

- binaryOrigin：source module via Python311 `-B -m pipd_ls_sp.cli`；cwd 本任務 work；installed binary origin NOT_OBSERVED。
- effectScope：LOCAL_DRAFT_WRITE_CANDIDATE_ONLY; repair actual repo scope requires L2；此輪只 `--help` 和 invalid flag，不執行該verb效果。
- helpSchema（exit=0）：

```text
usage: pipd export [-h] [--out OUT] [--dry-run] [--root SUB_ROOT]
                   [--allow-root ALLOW_ROOT] [--allow-replace]

options:
  -h, --help            show this help message and exit
  --out OUT
  --dry-run
  --root SUB_ROOT
  --allow-root ALLOW_ROOT
  --allow-replace
```

- nonzero：`export --definitely-invalid-flag` exit=2，typed stdout：

```text
{
 "code": "USAGE_INVALID",
 "message": "invalid command line; see --help for the 13 commands",
 "verdict": "FAIL"
}
```

- 真實作用的POS/NEG與permission保留原下列契約；parser help成功不能聲稱compile/doctor功能已被本輪執行。

### pipd diff

- binaryOrigin：source module via Python311 `-B -m pipd_ls_sp.cli`；cwd 本任務 work；installed binary origin NOT_OBSERVED。
- effectScope：SOURCE_READ；此輪只 `--help` 和 invalid flag，不執行該verb效果。
- helpSchema（exit=0）：

```text
usage: pipd diff [-h] --a A --b B [--explain]

options:
  -h, --help  show this help message and exit
  --a A
  --b B
  --explain
```

- nonzero：`diff --definitely-invalid-flag` exit=2，typed stdout：

```text
{
 "code": "USAGE_INVALID",
 "message": "invalid command line; see --help for the 13 commands",
 "verdict": "FAIL"
}
```

- 真實作用的POS/NEG與permission保留原下列契約；parser help成功不能聲稱compile/doctor功能已被本輪執行。

### pipd repair

- binaryOrigin：source module via Python311 `-B -m pipd_ls_sp.cli`；cwd 本任務 work；installed binary origin NOT_OBSERVED。
- effectScope：LOCAL_DRAFT_WRITE_CANDIDATE_ONLY; repair actual repo scope requires L2；此輪只 `--help` 和 invalid flag，不執行該verb效果。
- helpSchema（exit=0）：

```text
usage: pipd repair [-h] --subject SUBJECT [--authorized-root AUTHORIZED_ROOT]
                   [--scope SCOPE] [--maker MAKER] [--dry-run]

options:
  -h, --help            show this help message and exit
  --subject SUBJECT
  --authorized-root AUTHORIZED_ROOT
  --scope SCOPE
  --maker MAKER
  --dry-run
```

- nonzero：`repair --definitely-invalid-flag` exit=2，typed stdout：

```text
{
 "code": "USAGE_INVALID",
 "message": "invalid command line; see --help for the 13 commands",
 "verdict": "FAIL"
}
```

- 真實作用的POS/NEG與permission保留原下列契約；parser help成功不能聲稱compile/doctor功能已被本輪執行。


## 保留的原生命周期與三SPEC接口


# TPM K0–K3、18 Stage 與八技能 PIPD 生命週期

> **效力**：本檔為 `BODY-02` 的來源約束施工設計候選，保留來源章節的原 ID、Decision、POS/NEG、HOLD；尚不是任何正式 PI/PD/ECP/Permit/WorkOrder/Checker Verdict 或 Release。凡提及 `PROPOSED` 的 ABI，需由原 Owner／Host Registry 真正綁定。

## 6. TPM-SP / Native FHS-TPM：18 Stage、K0–K3 與三種 SPEC 的真工程契約

本章對 v1 §0.1、§4.1 的操作級展開是正式現行設計：`sbl-tpm-sp` 的產品規劃功能不能冒充 PIPD Native Compiler。每張 Stage 的結果為 `PROPOSED`；`T4/T5` 原狀態對應 `CR-DOC04-STATE-MAP` 未決，任何草稿成功不可直接改 PIPD StateEnum。[SRC-53:§3.2–3.v2][PLUGIN:tpm-product-plan/tpm-system-plan/tpm-program-plan]

### 6.1 Cold Host K0→K1→K2→K3：24 個 base DOC 不重上傳

| 能力 | 精確動作與輸出、Reader | POS / NEG / FirstFail / 回退 |
|---|---|---|
| K0 ImmutableCorpusBundle@1 | SBL DOC00–13＋PIPD DOC00–09 的版本化完整 bytes/SHA/Domain Writer/License 編成 ImmutableCorpusManifest；TPM/Host Reader 必核算每一 bytes，FHS/B1 overlay 是可撤的非 Canonical 層。 | POS 離線 fresh host 讀回 24/24 同 digest；NEG 只有 SKILL.md 或偷要求已內建 DOC 重新上傳→K0_SOURCE_MISSING；回復前一已知好的 bundle。 |
| K1 ClauseIndex@1 | K0 原 bytes→heading/line span/TextSHA/parent/SourceRef，不改 source polarity；只允許受權 root 內定位，供 K3。 | POS 每節 readback 同文；NEG 任意 ../、重複 locator、stale SHA→K1_INDEX_DRIFT；依 K0 重建受影索引。 |
| K2 SupersessionConflictRegistry@1 | 以 Writer/domain/supersedes hash/scope 建 CurrentReadView，跨領域 PIPD/SBL 不是日期較新者自動覆蓋；輸出 ConflictTicket→Owner。 | POS 舊版可追溯/現行正確；NEG DOC07 跨 Writer 混合→K2_WRITER_CONFLICT；保留兩版及 HOLD。 |
| K3 OnDemandReadOnlyReader@1 | (subject, source_id,source_sha,clause,read_scope)→驗 K0–2，回 SourceBoundExcerpt（含原檔行號與 ACL）予三 SPEC；合法取用局部段落但基礎物理 bytes 已完整校驗。 | POS 同 SourceHash 再讀仍一致；NEG cached stale 或原 DOC prompt-injection 改權限→K3_SOURCE_UNTRUSTED；僅 invalidate 受影 Question/Spec。 |

**真正啟用**需 `PACKAGED→INSTALLED→HOST_LOADED→INVOKED→FUNCTIONALLY_QUALIFIED` 真證據；未實測的 Plugin 雖聲稱自帶 DOC，仍為 `HOST_PENDING`。K0 缺一件才只停使用該件的 Spec，不全域停 L0。[SRC-53:L198–207]

### 6.2 PM／SE／TPgM × T0–T5（18 張相互獨立 StageContract）

`T0 Discover/T1 Product/T2 System/T3 Program/T4 Handoff/T5 Review` 是**此包閱讀別名**，不替換原三個 Role StageMap。每列的 SourceRef、Owner、受影 CaseID 皆在產物中回帶；若 Stage 的 source/permission 不滿足，產 `StageNACK(first_fail,resume_predicate)` 而非虛構正式轉移。

| Role:Stage | EntryGuard / Operations | Typed Result → Consumer | POS / NEG 與續作 |
|---|---|---|---|

| PM:T0 | 有 Goal+Source → 去重提取 JTBD/persona | ProductKnownState@PROPOSED → PM/T1 | POS 相同 source 零重問；NEG 空 Source→SOURCE_MISSING；只 PARK 受影階段，T4/T5 狀態轉移待 Owner Schema |

| PM:T1 | 有 T0 Readset → 定義 pain/FUO/非目標 | ProductSuccess@PROPOSED → PM/T2 | POS FUO 有 ACC POS/NEG；NEG 抽象口號→FUO_UNBOUNDED；只 PARK 受影階段，T4/T5 狀態轉移待 Owner Schema |

| PM:T2 | 有 FUO/Kind → 建立 Journey/八 Kind 適用 | ProductSPECDraft@PROPOSED → TPM/PI Candidate | POS Kind 具 NoFit；NEG 其他 Kind 偷預設支援→KIND_NOFIT；只 PARK 受影階段，T4/T5 狀態轉移待 Owner Schema |

| PM:T3 | 有 draft + risk → 逐需求拆 ACC/NEG/Owner | ProductAcceptanceProposal@PROPOSED → PM/SE/T4 | POS 每子項有測試入口；NEG parent PASSED child 缺證→CHILD_TRACE_GAP；只 PARK 受影階段，T4/T5 狀態轉移待 Owner Schema |

| PM:T4 | 有 source/owner → 編 SpecCandidate handoff，不編 PI | ProductHandoffReferral@PROPOSED → PIPD intake | POS Schema/SourceHash可查；NEG 提案冒稱 Native PI→WRITER_DENIED；只 PARK 受影階段，T4/T5 狀態轉移待 Owner Schema |

| PM:T5 | 有原始測試或明確未跑 → 核 Raw/evidence與FUO | ProductReview@PROPOSED → PM/Owner | POS 能區分 NotRun/Fail；NEG 缺 Raw 說 DONE→FUO_RAW_MISSING；只 PARK 受影階段，T4/T5 狀態轉移待 Owner Schema |

| SE:T0 | 有來源/現役 host 可讀 → 建立架構所有權 | SystemReadset@PROPOSED → SE/T1 | POS 四域 Writer 分明；NEG 未知 PID 自填→HOST_UNVERIFIED；只 PARK 受影階段，T4/T5 狀態轉移待 Owner Schema |

| SE:T1 | 有 T0/Scope → 產 Boundary/ThreatModel | OwnershipSeamMap@PROPOSED → SE/T2 | POS 一 Writer/Effect；NEG 雙 Issuer→AUTHORITY_CONFLICT；只 PARK 受影階段，T4/T5 狀態轉移待 Owner Schema |

| SE:T2 | 有 Driver/HostCaps → 具名 ADR／版本 ABI | ArchitectureSPEC@PROPOSED → SE/T3 | POS 版號與 NEG；NEG 無 Schema 仍宣綁定→ABI_UNBOUND；只 PARK 受影階段，T4/T5 狀態轉移待 Owner Schema |

| SE:T3 | 有 SPEC / writer → 逐 edge 壓測、回退 | ArchitectureNEGRequest@PROPOSED → SE/T4 | POS wrong major DENY；NEG 靜默丟 unknown required→ABI_LOSS；只 PARK 受影階段，T4/T5 狀態轉移待 Owner Schema |

| SE:T4 | 有 Adapter Proposal → 原 Domain Writer 審查接線 | ArchitectureHandoff@PROPOSED → PIPD/HGK Reader | POS Only Proposal crossing；NEG 自稱 Loaded→HOST_RAW_MISSING；只 PARK 受影階段，T4/T5 狀態轉移待 Owner Schema |

| SE:T5 | 有同 SHA 實證 → review trace／負例 | ArchitectureReview@PROPOSED → SE/Owner | POS 不同 principal 待證；NEG 用 Maker 代 Checker→SOD_DENIED；只 PARK 受影階段，T4/T5 狀態轉移待 Owner Schema |

| TPgM:T0 | 有 subject/Goal → 盤點 scope/milestone | ProgramIntent@PROPOSED → TPgM/T1 | POS 跨 Session 可定位；NEG 只有 Chat 歷史→DURABLE_GAP；只 PARK 受影階段，T4/T5 狀態轉移待 Owner Schema |

| TPgM:T1 | 有風險 → 定預授權/成本/依賴 | SchedulingAssumptions@PROPOSED → TPgM/T2 | POS 不重啟無關卡；NEG 每卡重問 Owner→GOVERNANCE_OVERHEAD；只 PARK 受影階段，T4/T5 狀態轉移待 Owner Schema |

| TPgM:T2 | 有 3 SPEC → DAG/toposort/Owner split | ProgramDAG@PROPOSED → TPgM/T3 | POS 無 cycle；NEG 循環依賴→DAG_CYCLE；只 PARK 受影階段，T4/T5 狀態轉移待 Owner Schema |

| TPgM:T3 | 有合法卡 → 建立受限 WP/rollback | ProgramSPEC@PROPOSED → TPgM/T4 | POS 卡帶 scope/NEG；NEG ** write scope→WRITESET_DENIED；只 PARK 受影階段，T4/T5 狀態轉移待 Owner Schema |

| TPgM:T4 | 有真 PIPD 入口 → 生成受權 referral | HandoffReferral@PROPOSED → PIPD/HGK PLAN | POS 不冒充 ECP/Permit；NEG 跳過 SourceFreeze→PIPD_HOLD；只 PARK 受影階段，T4/T5 狀態轉移待 Owner Schema |

| TPgM:T5 | 有 Raw/checkpoint → 按原 Case 最小稽核 | ProgramReview@PROPOSED → TPgM/Owner | POS 未結案 card 續行；NEG 重跑 Done→REPLAY_DENIED；只 PARK 受影階段，T4/T5 狀態轉移待 Owner Schema |

### 6.3 三 SPEC 型別、KnownAnswer 與 GHP 決策

- **`ProductSPEC@DESIGN-1`**：必含 `subject_id,source_hash,goal,persona,pain,JTBD,FUO,primary_kind,scope,non_goals,user_journey,ACC_POS[],ACC_NEG[],risk,question_refs,assumptions,decision_owner`。`PIPD IntentCard` Consumer 只讀，絕不可把 Draft Spec 寫作 `PI-PKG`。POS CLI_USER 可得到可執行 help/list/remove，NEG 無來源假 FUO。
- **`ArchitectureSPEC@DESIGN-1`**：必含 `source_ref,C4_boundaries,components,single_writer_seams,threat_model,ADR,interface_contracts,schema_version,provider_off_behavior,host_matrix,policy_reader,license_security,rollback`。SE 與 PIPD/HGK 受影 Reader 消費。POS wrong major 被 NACK；NEG 非原 Owner 自建第二 Issuer。
- **`ProgramSPEC@DESIGN-1`**：必含 `milestones,task_dag,dependencies,work_packages,scope,write_set,task_kind,mode,owner,risk,required_grants,ECP_request,PIPD_refs,checker_request,raw_expectations,exit,rollback,resume_predicate,GithubDecision`。HGK PLAN 僅消費受權的 Proposal；POS 局部 PARK；NEG 把 949 件全部 READY。
- **`QuestionLedger`** Key=`(subject_id,source_sha,question_semantics,scope)`；KnownAnswer/受影 reuse 無過期就 `SKIP_WITH_SOURCE`，Unknown 且影響 FUO 才 `ASK_ONCE`；缺 source 明確 `SOURCE_MISSING`，有 source 卻沒讀到為 `READER_FAILURE`。Quick/Guided/Critical 依實際 risk 切換。
- **GitHub `GHP-01`** 本次 Delivery 決策一次 `(UNDECIDED|LOCAL_ONLY|DEFERRED|REMOTE_REQUESTED)`，`UNDECIDED` 不阻擋 L0/L1 本地測；**`GHP-02`** 僅當正式 Remote Push/Merge/Release 時讀 Publisher Credential/Scope/current HEAD/Policy，否則不得自行遠端突變。[SRC-53:L179–207]
## 7. PIPD-LS 原生 19 Contract、13 CLI 與雙衝突相容（細化 v1 §2）

`PIPD-LIFECYCLE-SPEC@1.1.0` 的 Schema Writer 仍是 PIPD DOC00–09，不是 TPM。以下 `ContractName` 是來源具名型別，**精確 `$id / fields-required / enum / digest` 在真 PIPD Owner Registry 讀回之前為 `BIND_HOLD`**；此表之建議欄是 `PROPOSED Reader projection`。禁止僅靠 `pipd validate` 一次成功就推論 TraceClosed。[SRC-MASTER:§VI][SRC-PIPD-02..09]
~~~~~~~
