> **CURRENT FHS READER 2026-10-30_r2_HIGH_RETENTION_AUDIT_PATCHED_SOURCE_BOUND**；原 Domain Writer 不變；歷史 fenced block 不得作有效條位。

# 04 FABRIC HGK CONTROL｜FHS-MSC_PIPD-LS-PKG 2026-10-30 整合實質正文

> **FHS-MSC_PIPD-LS-PKG / 2026-10-30_r2_HIGH_RETENTION_AUDIT_PATCHED_SOURCE_BOUND / EFFECTIVE_DESIGN_READER**。本冊按同域來源整合 2026-10-29 BODY revision2 和 2026-10-30 r2 最新受影修補。R2 受影條款在本冊設計閱讀範圍優先於被修補之歷史片段；但不覆寫 SBL/PIPD/Fabric/HGK 原 Writer、已生效 Policy/ABI。全部 Native／Owner Ratification／IndependentChecker／Release 未在本沙盒執行。
>
> **ClaimCeiling** `SOURCE_BOUND_INTEGRATED_DESIGN_WITH_LOCAL_READBACK`；`REPO_SOURCE_REMOTE_OBSERVED` 不代表 `LOCAL_REPOCONTEXT_BOUND`，不得藉本檔取得原授權。此文件前半 r2 更新與後半歷史正文是一份整合 Candidate，不是平行的兩份現役 Canonical。


## 本輪同域受影修復：r2 §4 真四庫 ABI 與 Native Effect

## 4. 四庫確定性接線修補：真正的原 ABI 與受界停點

### 4.1 本次實查 Source 摘要（不要把假想方法寫成 HGK API）

| Repo 固定源 | 已證實的真定位／函式 | 可直接進行的最小工程轉換 | 缺失時封鎖與退回 |
|---|---|---|---|
| `Fabric/FABRIC/fabric/consumers/hgk_policy_consumer.py` | `FAB=Path(r"C:\Projects\Agent_Workspace\Fabric")`, `load_router()`, `route_event()`, `apply_preapproved()`；原 Router 檔在 `FABRIC/rp002/` | 原位相對 Trusted Fabric Root 定位、Reject `../`／Junction，保持 `route_event` 原回傳形狀；`apply_preapproved()` 僅 Canary，不替代 Active/Consumed | 找不到原 Active／Host Loaded/Consumed Reader→`POLICY_CONSUMED_HOLD`，保留 Stage |
| `HG-KSEOS/src/hg_kseos/spine.py` | `SharedSpine(database,schema)`, `.transaction()` 使用 SQLite BEGIN IMMEDIATE、WAL；原 taskspec 狀態 `DRAFT→ADMITTED→RUNNING→VERIFIED→PACKAGED` 等 | 原 WorkID/Lease/Reducer 只能用其所在模組正式 API；禁止 FHS 直接改 DB 表或創第二 Dispatcher | 缺原 Admission/Lease 入口→`NATIVE_BIND_HOLD`；只有設計 Proposal |
| `HG-KSEOS/src/hg_kseos/providers.py` | `ProviderRegistry(spine)`, `.import_protected_ledger(path)`, `.advance(...)`，`qualify_hermes_core()` 歷史測試固定 57/50/7 | 分離 legacy qualification fixture 與新版本具名不變量；原 lifecycle/Registry 保留 | 真版本 Pin/Raw/Served 缺→`QUALIFICATION_HOLD` |
| `HG-KSEOS/src/hg_kseos/lane_route_resolver.py` | 候選純計算 pool/fallback logic，明示非 Launcher | 將原現有可用 Launcher 對接原 Registry 的 Proposal，先核 Signature/Module SHA；不新增路由權威 | 入口不可定位→`ABI_BIND_HOLD`；不可當它正在生效 |
| `HG-KSEOS/src/hg_kseos/lane_admission.py` | `LaneAdmission`, `decide_status`, `write_receipt` 供候選 lane probe；`ADMITTED` 要實際 completed model call+tool roundtrip+served match | 只有原受保護 Receiver 可提升 Native Admission，候選 probe 不簽正式 Permit | 只有 HTTP 200→`UNPROVEN` |
| `SBL/sbl_harness/__init__.py` | `HGK_PIN` 指向原未見 `config/lane-route-slots.candidate.json`、`scripts/hgk-lane-dispatch.py`；`HARNESS_ABI` 提供 plan/execute/verify 但 `not_provided` 明示 native_effect/permit_signing/admission | 原位改由 HGK Owner 提供的正式 Registry Locator/Dispatcher Binding；SBL 僅 consume、安裝/卸載限其檔案 Allowlist | 正式入口未確認→`HARNESS_BIND_HOLD`，不能用 B1 候選直接執行 |
| `SBL/sbl_core/modes.py` | `ack_signature(issuer,permit_id,subject_id,key)` HMAC length-prefixed；`_ack_state()` 驗三欄＋Issuer Allowlist/secret | HMAC 作 ModeGate 初篩可以保留，真正 Effect 仍交原 HGK Receiver 檢 Scope/Epoch/TTL/Operation/Nonce/Subject | 不得以 HMAC mode ack-only 解鎖 `SWOF_CONNECTED` 任意效果 |
| `PIPD-LS-SP/src/pipd_ls_sp/cli.py` | `COMMANDS` 13 Exact-set；`src/pipd_ls_sp/pipeline.py::intake()`/`freeze_authority()`；`registry.py::SOURCE_ORDER` 19 Schema | 原 CLI/Pipeline 直接復用，驗 Source Digest、Repo Context、合法 Schema `$id`；保留 `compile-cc` 爭議為 Versioned Candidate | 不增第14命令；缺原 Writer Consent→`PIPD_ABI_HOLD` |
| `PIPD-LS-SP/requirements.lock` | 原 Lock 自述只版本 pin、未 hash-pin；原 `.hermes/skills/openspec-apply-change/SKILL.md` 標 `generatedBy:1.8.0` | 在原 Build Scope 補 Artifact Hash／Provenance，Skill 用既有 Project Skill Location 選單一有效來源，Validate 警告/Delta | 無 Hash/Host Loader Raw 只影響受影可重現供應鏈／Skill Claim，不阻無關 Reader |

### 4.2 五條正式 Typed Adapter Flow：Input/Producer→輸出→Consumer、正負例

1. **Policy Flow**：Original Fabric Source＋Owner Approved Epoch→原 `route_event()` 是決策 Reader，不是 Host Activation；由原 Host Consumer 產 `ActiveEpoch/LoadedSHA/ConsumedACK` 真 Receipt；HGK 只 consume 相同 PolicyEpoch。Stage/Canary 冒 Active→`POLICY_CONSUMED_HOLD`。回復原 epoch 只由 Fabric Owner 執行。
2. **Plan Flow**：SBL Goal/ThreeSPEC→Portable TPM/Commander 產 Candidate；有合法原 HGK PLAN Request 才由真 PLAN Writer 改 `PlanRevision`（CAS、原 WorkID、Scope/Owner）；文稿不自行更動 SharedSpine。錯 Revision/Foreign WorkID→`PLAN_REVISION_NACK`。
3. **Execution Flow**：PIPD PD/DEV/OPS ECP→原 HGK WorkOrder/Permit/Lease→Hermes pinned Profile+Worker；原 Worker/Tool 只執 exact `OperationSemanticID/WriteSet/HostTarget`；返回 Native Raw；若無實際 Issuer/launcher ABI 只能 `ADMISSION_HOLD`。真 Process PID、Loaded Module Origin、Requested/Served 都必讀。
4. **World Flow**：Hermes Tool 完成事件→原 Receiver 查受治理世界狀態和 Journal→分類 `APPLIED/PARTIAL/NO_EFFECT/UNKNOWN`；ToolDone 不等於 EffectKnown，未知必 `RECONCILE_REQUIRED`；Repo/Host/User/Remote 由各原 Owner 按原補償 ECP 清理 residue。
5. **Checker Flow**：Frozen World Raw+Original Oracle+Same Subject/Candidate/Scope→原 AC15 Handoff→有獨立 Credential/ACL 之 Protected Checker 判定→原 HGK Reducer ACK/HOLD；同模型不同不保證 SoD、同 Principal 更不能。正式 Release 需原 Publisher 與 SourceFreeze。

### 4.3 Native E2E 自主執行狀態機：Actor、事件、Fence、Unknown Effect、補償

| 事件／原狀態 | Actor、前置及受限 Payload | 成功後狀態與 World Readback | NEG／恢復／補償 |
|---|---|---|---|
| `GOAL_ACCEPTED` | SBL GoalCard/QuestionLedger，SourceSHA、Mode/Kind/Host | `SPEC_CANDIDATE`／合法 FUO | 缺來源→NEED_SOURCE，不能造 PI |
| `PLAN_READY` | TPM 三 SPEC＋PIPD PI/PD/ECP/TQAEP；Owner-bound Source/Scope | 原 WorkOrder 候選，尚不能 Effect | 缺 PIPD Writer/Oracle→PIPD_HOLD |
| `POLICY_CONSUMED` | Fabric 原 Owner ActiveEpoch＋真 Host Loaded/Consumed | 同 Epoch 所需資格成立 | 只有 Canary→POLICY_HOLD |
| `ADMISSION` | HGK 原 Issuer/Receiver 證 Permit/TTL/Nonce/Subject/Operation/WriteSet | `ADMITTED`（原 State Enum 讀值，不自造） | Foreign/Stale/Replay/OutScope→DENIED，不 Spawn |
| `LEASE_CAS` | HGK SharedSpine transaction、WorkerIdentity、LeaseGeneration/FencingToken | 唯一當期 holder 可進 `RUNNING` | 舊 Generation 的 Worker ACK 無效，不因 timeout 假定無效果 |
| `INTENT_DURABLE` | HGK 原 Journal 原 OperationSemanticID+PreImage+ExpectedWorldDiff | Durable operation intent，准 Worker bounded invoke | 不應先 Tool Invoke 後記 Intent；若存取失敗停止 |
| `EXECUTE` | Hermes 真 Loaded Profile＋Worker PID/ModuleSHA/ActualServed；Coder Tool ACL 由原 Receiver | 僅 exact Scope 操作，Raw 附 OperationRef | 子代理繼承 Toolset 不等於新 Permit；超 scope DENY |
| `WORLD_RECONCILE` | 原 Receiver 比對 PreImage/Journal/PostWorld | `APPLIED`、`PARTIAL`、`NO_EFFECT`、`UNKNOWN`（**判定分類**，非假定 Native enum） | `APPLIED` 只續收證據；`PARTIAL` 原 Compensation ECP；`NO_EFFECT` 仍須 fresh original admission；`UNKNOWN` HOLD、不可重試 |
| `CHECKER` | Original Protected AO 讀 Raw/Oracle，獨立 Principal/ACL | 原 verdict→Reducer 合法下一 State | Maker 自評、Oracle 被改或來源錯→VERIFICATION_HOLD |
| `CHECKPOINT/RESUME` | 新 PID 讀原 WorkID/LatestState/Lease/OpIntent/World，驗新 Scope/Epoch | 未受影依賴可繼續，已 Effect 不重執 | 已撤/過期 Permit 必重新原 Issuer 准入；舊 Holder CAS NACK |
| `RELEASE` | Original Publisher/SourceFreeze/Proof | 本 Scope 受准交付/發布 | 缺一 Receipt→RELEASE_HOLD，不假宣全域完成 |

**四個極端例子**：A 完成世界寫入但 ACK 遺失→B 新 PID 必以同 `OperationSemanticID` 從 Journal/World 認定 APPLIED，不得再呼叫一次；A Lease 已到期但後送 ACK→Fence 令其拒收，世界效果仍須 Reconcile；部分改檔→不以 Failed=NoEffect 直接重跑，進原 Compensation ECP；Provider quota→只有 Owner 池內相容下順位可自動切，Governance/ProviderOff 的否決不容替代。[BODY06 `R2-06-REDUCER`；BODY10]

### 4.4 W18 Ordinary Goal：真正 Fresh PID 日常入口，不依賴 B1 長 Prompt

```text
Host start (new PID)
 → 原批准 Default Profile / AGENTS.md / Project Skills Manifest read and SHA
 → Host effective load + invoke/noninvoke + true requested/served
 → User ordinary Goal + Source Locator + Kind + Mode
 → SBL KnownAnswer/MethodDecision and current Source/Policy/Scope
 → [existing admitted WorkID ? read cursor+world+lease : create source-bound SPEC]
 → [no effect ? First Useful Outcome : original HGK approved WorkOrder]
 → Hermes bounded Worker / true raw / original Checker
 → Checkpoint by existing HGK SharedSpine, not private chat state
```

三個正常情境：**首次有效來源**→首個合法 FUO，不要求貼 B1 長 Prompt；**同 WorkID 重開進程**→校 Scope/Policy/World，Resume 未完成且未重播 Effect；**來源或 Policy 變更**→只 invalidate 受影計畫並重核 Admission，無關成果保留。任何 `Default Profile/Skills/Served` 未真讀回→`W18_NORMAL_HOLD`，非假稱 AUTO_READY。[BODY10 `R2-10-NORMAL`]

### 4.5 知識與記憶、Windows／桌面、CI 安全三條既有 Consumer 路線

**Knowledge**：原 KnowledgeFactory/G-KNOW/HLPE/SRU_OROCHI 接 Source/DocETL（受權提取 bytes＋SHA）→原 Clause Index/FTS5、可審 Retrieval→同 SourceSHA Citation、Known Answer/Question Ledger→若失效重索引受影條目。`LLM Wiki` 只作已選 Source-backed 顯示或候選，不改原 Clauses；Mem0/Letta/Qdrant/Chroma/Milvus/Neo4j/pgvector 等是否採用依 TECH386 原處置，沒有效益差額不擴第二 Knowledge DB。記憶資料 `timestamp`／`citation` 不同於 Canonical Source Freeze。[RBWI Group03；BODY08 TECH386]

**Windows／Host/UI**：Hermes CLI/Windows Host 原 Process/Skill Loader 先用真 Loaded Module；Codex、Claude Code、ChatGPT 各依原 Host Capability 做不同 Install/Invoke/Permission 的 POS+NEG；`Windows App SDK/WinUI 3/Named Pipe/AG-UI/A2UI` 保留 TECH386 原 ID，只有明確 UI/Interop 的 Product Need 才依原選型施工。Notebook/Web Chat 不冒充 OS FileSystem/Process Tool，Web DOC_MOUNT 不等於 Private Plugin Qualification。[SBL DOC10；BODY08 TECH386:TECH]

**Supply Chain**：原 CI 一個責任明確的 Build Pipeline 按 Scope 選：`Gitleaks` 受影 Secret Scan，`CodeQL/Semgrep/Ruff/pytest` 靜態／單測，`Syft→CycloneDX/SPDX` SBOM，`Trivy/Grype/OSV` 按實際 Consumer 做漏洞匹配，`Cosign/SLSA/Artifact Attestation` 記建置來源（不能取代 Native/Checker/Release），`OPA/TUF/OpenSSF Scorecard` 只依原 TECH disposition 及安全 Need。10 月 eMudhra 信任鏈事件只使真受影 CA Bundle/HTTPS Consumer 需要重新驗證；不強制全量工具重裝。PIPD 原 `requirements.lock` 無 Artifact Hash，應在原 Builder/Publisher 受控補鎖並做可重現安裝，不能單用版本字串代表來源安全。


## 本輪同域受影修復：原始碼錨點

## 四庫 2026-10-30 `main` 原始碼錨定（GitHub 唯讀）

| Repo/HEAD | 原始碼實測存在的路徑／符號 | 接線或禁止 | 本輪效力 |
|---|---|---|---|
| `Fabric` `316b691460638bdf38475c2c58aaad406aa6eb4f` | `FABRIC/fabric/consumers/hgk_policy_consumer.py` `route_event`、`load_router`；`rp002/RP002_CHANGE_CLASS_ROUTER.yaml` | `route_event` 依 change_class 選原 HERMES_NATIVE/ORACLE_TO_HGK 等 Consumer；文件不能把 `apply_preapproved` 的 raw hash 當真 HGK active grant | REMOTE_SOURCE_OBSERVED；Host Loaded 未證 |
| `HG-KSEOS` `f6dfb1e57162dc3868dc488482d249fc095eb429` | `src/hg_kseos/providers.py` `ProviderRegistry.advance` / lifecycle；`src/hg_kseos/lane_route_resolver.py` | Provider PIN/Installed/Certified/Enabled 順序，不跨級；lane resolver 檔案註記 `CANDIDATE, ISOLATED. Not wired into the launcher`，不得宣稱已 served/loaded | REMOTE_SOURCE_OBSERVED；Launcher bind HOLD |
| `SBL` `fd62537a7ba29c3f2905fe42ddde9534674405d7` | `sbl_harness/__init__.py` 的 `HARNESS_ABI`/`HGK_PIN`；`sbl_core/modes.py` `MODES`、`DISPOSITIONS` | PREW3_SHADOW=`SHADOW_NOEFFECT`，SWOF_CONNECTED=`BLOCKED_EXTERNAL`；SBL Adapter 不簽 HGK Permit | REMOTE_SOURCE_OBSERVED；Host consumer ACK HOLD |
| `PIPD-LS-SP` `f6335a94157c61da75d92121d14c43feb413e981` | `src/pipd_ls_sp/cli.py` `COMMANDS` 恰 13；`pipeline.py` deterministic；`registry.py` `SOURCE_ORDER` 恰19；`requirements.lock` | 19 Contract/13 CLI exact-set，`requirements.lock` version-pinned 但**未 hash-pinned**；不可因 lock 存在自稱供應鏈完全可再現 | REMOTE_SOURCE_OBSERVED；Windows SchemaHost HOLD |

**來源證據界線**：GitHub commit/檔案 blob SHA 不是 Windows process PID、loaded hash、Owner grant、Issuer Permit 或 Native Runner 調用；本輪沒有看到 local HEAD/index/untracked，禁止推定本機 dirty=0。所有 Repo patch 須有現役 Owner 的 exact WriteSet/DEV-ECP/受權 Scope。本版可提供 static patch 契約，不能執行真四庫修改。


---


## R2 現行／歷史 Reader 隔離

本檔此處以上及本輪新增 R2 小節為**唯一當期整合設計 Reader**；前版 Revision2 已位元組保存於證據 ZIP `02_EVIDENCE_AUDIT_APPENDICES/_superseded_2026-10-30_r1/04_FABRIC_HGK_CONTROL_R1_REVISION2_VERBATIM.md`（SHA256 `63563a678bc932a45abe669cee0fc4d51e8dd31e3d2d673da9a05ccc17fe885d`）。歷史條位不得由 Parser 以同號 ID 當 CURRENT，也不得用歷史 HOLD 覆寫本輪受影修補。原 Domain Writer 法位不變。

## R2 高保留歷史（不可執行，排除於本版 Parser）

以下內容完整保留先前 Revision2 的參考語義。**所有標題和 ID 均為 archive 文字，不是本版有效條位**；如需 source-level regression，可讀證據包未包裝的原檔及 SHA。

~~~~~~~markdown
## 高保留原 BODY Revision2 實質正文（沿用未受影區；遇 r2 修補採本冊前段）

---
artifact_id: FHS-MSC-R2-BODY-04
formal_name: Fabric／HGK 單一控制平面
short_name: BODY-04
version: 2026-10-29-r2-revision2
source_set_hash_or_pending: f86b217ae3c3ee28183570f4bf3d4f08d4d00e9b86d1de1a641a630f8682d1a1
intended_consumer: 原領域 Owner 與下游 Reader
owner_role: 作者端規格修補者；原 Domain Writer 不移轉
design_status: SOURCE_BOUND_REPAIR_CANDIDATE
claim_ceiling: AUTHOR_STATIC_ONLY; NATIVE_NOT_RUN; CHECKER_NOT_RUN; RELEASE_NOT_RUN
supersession_scope: 本輪作者候選revision2；保留前版封存；不取代任何原Canonical Writer版本
AUDIT_F_IDs:
- F-03
- F-18
- F-26
---

# Fabric／HGK 單一控制平面

## R2-04-CURRENT：五層證據與現役唯讀起跑

Source→Stage→OwnerApprove→ActiveEpoch→LoadedSHA→ConsumerACK 各自是不同觀測。Stage/檔案存在只能證明候選可讀。原 Fabric Owner Reader 需回 active epoch、policy digest 和 host/process identity；HGK Reader 需回相同 epoch、loaded digest 與 consumer route ACK。Loaded 與 Active 不符只 PARK 依賴該 Policy 的 effect，合法 SOURCE_READ 繼續。

每 Lane 分開記 required、selected、served；PLAN/EXECUTE/VERIFY_SECURITY 必有該 task 的 request/response Raw、Provider identity、time 和 source/candidate。Model 已選而沒有 response 是 SERVED_NOT_OBSERVED。ProviderOff 不容許私換供應商，只有有來源證明的離線 Reader 或 NOFIT。

POS：同一 Subject 的 Policy digest 在 Active/Loaded/Consumer 三 Reader 一致，原 Issuer 才檢 scope/nonce/TTL。NEG：Stage-only、別 Host Loaded、過期 epoch 或別 task served → POLICY_NOT_LOADED / FOREIGN_HOST_RECEIPT。本輪 Repo HEAD 與 GitHub main 不一致，不能挑較新字串自動替換 Active。

退出：唯讀 probe 丟棄過時快照；Policy/Host 更新須另有 OPS ECP+原 Owner activation transaction，保留 preimage/epoch/consumer rollback ACK；UNKNOWN activation 先 reconcile，不藉文稿建立第二 Activator。

## 保留的領域實質設計（修補表格語法與狀態字樣）


# Fabric Policy × HG-KSEOS 原生控制接線

> **效力**：本檔為 `BODY-04` 的來源約束施工設計候選，保留來源章節的原 ID、Decision、POS/NEG、HOLD；尚不是任何正式 PI/PD/ECP/Permit/WorkOrder/Checker Verdict 或 Release。凡提及 `PROPOSED` 的 ABI，需由原 Owner／Host Registry 真正綁定。

### 4.5 Fabric Policy + HGK 唯一 Native Plane

Fabric Policy 源位→已批准 Stage→Active→Host Loaded→Consumer ACK 必是**五個不同證據**；歷史「Deploy OK」或 CI 綠燈不替代 Loaded。Active 的真 SHA、Epoch、Owner/Signer 與所用 Consumer process namespace 需一致。HGK 的 `Trust Profile→Resolver→Receiver imported origin→Issuer/Permit` 真連線由現役 API/OS ACL 證明，不能因存在 User Trust 文字設定就宣稱實際綁定。三 lane `required_provider/model` 與 `served_provider/model` 每一受影任務實讀，provider-off 不靜默降級。缺 Activator/Signer 只停 `PolicyActivation`，保留 L0/L1 及其他無關卡。[SRC-FHG:§3–5][SRC-B1-03]
### 14.1 三 Lane 每卡 Required/Served 與強制方法的原生證據

`PLAN/EXECUTE/VERIFY_SECURITY` 每個任務一個 `LaneRouteEvidence@PROPOSED` 投影：`{lane,subject_sha,work_id,policy_epoch,required:{provider,model,method_ids[],budget,quality_floor},selected:{...},served:{provider,model,method_invocations:[{id,runner_sha,exit,raw_ref}]},route_registry_sha,owner_fallback_ref}`。Real actual fields/enums 從 HGK 現役 Registry 探得，不做自造路由 token。`Required!=Served`（provider/model/method/epoch/timeout/price 或 permission 違反當期 Policy）→僅受影 WORK `NOFIT/PARK`；如果 Owner **已事前批准**在同 Host 同 Quality/Cost/Latency/Permission 的等價 fallback，需真負例/降級防護及 Reader Ack，不能因供應商 Off 自動亂換。`E37` 必須看真 Method Invoke，不看 Skill 名字/CLI 可載入。[SRC-08:§4.3][SRC-07:§5][SRC-14:W18]

| Method | 適用 Trigger／是否必須 Invoke | NEG / 不啟動的正當條件 |
|---|---|---|
| KANBAN | 現役 WorkBoard Policy MANDATORY 且任務有跨 Session 多卡→原 Hermes/HGK Board 實讀；只有單卡 L0 時可 NotTriggered。 | 生成第二 durable queue/幽靈 READY DENY；無 real route 時 METHOD_BIND_HOLD。 |
| SWARM | 真有可平行拆分、scope 不互撞、budget/agent principal 可核；必要時 route-before-spawn。 | 任意召四模型當四個 Checker/無限子代理 DENY；單任務 NotTriggered。 |
| FAR | 出現具證據 FirstFail、已驗 KnownFix 可用且 budget 允許；Red→Patch→Green 有界。 | 無故每題研究、世界效果自動重試或修改 Oracle DENY。 |
| OpenSpec | Brownfield source/change 真的符合原適用 Method，版本+真 Runner 綁定。 | 全部 Goal 都強制 CLI 產長 workflow 或替換 PI Canonical DENY。 |
| gstack / Superpowers / Spec Kit / Matt methods / GSD | 各以 §9 的原 OriginalDisposition＋Host Policy 適用結果啟用，不屬 Required 時具 NOT_SELECTED_WITH_REASON。 | 以 REF/DEFER/NO_SOURCE_EVIDENCE 強迫安裝錯；未實效不可宣稱方法已調用。 |

## 真 Policy Pipeline 與判拒次序

`PolicyIntent(source,subject,risk,scope)` → Fabric 既有 Policy Owner `Stage` → 適用 Owner Approve/Activate → HGK Consumer 真 `LoadedSHA+epoch` ACK → Issuer 以相同 Scope、TTL、Nonce 簽原生 Permit → Receiver 驗 ACL/Registry/subject/operation_id → SharedSpine Lease/CAS → Hermes Worker。`STAGED` 不能等同 `ACTIVE`，`ACTIVE` 不能等同 `LOADED`；無 LoadedSHA 只停真 Effect consumer。

分別驗證 `DENY_WRONG_KEY`（0 world diff）、`DENY_EXPIRED_NONCE`（0 replay）、`DENY_STALE_EPOCH`（0 work）、`DENY_SCOPE_ESCALATION`（低權不越權）、`UNKNOWN_EFFECT`（先 readback/reconcile，不重新消費 nonce）、`REVOKE`（已生效新工作拒入；合法已完成工作的 Raw 不抹除）。三 Lane 的 Required/Served/Model provider/source epoch/mandatory method 分 lane 真實收集，缺 served 無默許替代。

## 現役程式碼與限制（2026-10-29 倉庫唯讀）

GitHub `HG-KSEOS/src/hg_kseos/spine.py` 在 main 是 SQLite durable state/lease 實際程式碼檔，`Fabric/FABRIC/fabric/consumers/hgk_policy_consumer.py` 是 Policy thin consumer 的既有檔案。這證明**程式碼位址存在**，不是 Windows 最新 import/loaded path、Issuer、真模型 Served 或受保護 Checker 驗收。任何名為 `HGK_TRUST_PROFILE=user` 的文件建議未有真 Parser/Registry 證據前不得配置成現役開關。

## 領域 v2 精確補強條款（保留正式原域 Writer，非 Native 生效證據）


### 領域回源段 1：`FHS-MSC_FABRIC_and_HGK_升級藍圖_2026-10-28_v2_HIGH_RETENTION_AUDIT_REPAIR.md:L227–L346`

> 本段原生設計來源，高保留嵌入供下游逐條實作；如需更改正式 Policy/Schema/Gate，應回原 Domain Writer 決策。

## 3｜Fabric Policy Plane：As-Is → 可實施的 Stage／Active／Loaded／Consumed

### 3.1 權責與現役缺口

**As-Is（可從 Repo 證實）**：`FABRIC/control/PROMOTION_POLICY.yaml` 要求 subject frozen、exact candidate digest、acceptance receipt、rollback target、projection consistency，禁止 `auto_promotion_from_agent_output`。`FABRIC/fabric/consumers/hgk_policy_consumer.py` 的 `route_event` 以 RP002 ChangeClass 把 `RUNTIME_TRANSIENT`、`CONFIG_PREAPPROVED`、`PROFILE/SKILL/PIPELINE/STACK/PROVIDER`、`DOMAIN_CHANGE`、`CONSTITUTIONAL_CHANGE` 分路，`apply_preapproved()` 在可見 source 僅解析與讀回 config bytes，不具備可觀察 Live Consumer Activation；其所在 Fabric governance mirror 不代替原主機 Policy Engine。**To-Be** 由既有 Fabric Policy Owner 與 HGK Current Control Plane 的 Reader/Adapter 增補真交易和收據；**先查真 activator**，若已存在則只修讀回／不一致，不另建併行 Policy DB。

### 3.2 FP-01～07 精確狀態機（Adapter 提案，不宣稱既有 enum）

| 階段／事件 | 唯一可寫 Principal 與前提 | immutable 輸入→輸出 | POS／強制 NEG | 覆核及中斷行為 |
|---|---|---|---|---|
| SOURCE_PINNED | Fabric Policy Writer；已註冊 Subject/Source | PolicySourceID、source SHA、policy_kind、owner_id、scope、schema_version → candidate revision | POS 原來源 bytes digest 一致；NEG wrong subject、缺 schema/Owner、不受權來源 | 不符僅拒該 Policy Candidate；不影響已 Active Epoch |
| STAGED | Fabric Stager／在授權 Stage WriteSet | candidate SHA、base active epoch、read-only diff、rollback target、source refs → Stage Receipt | POS staged bytes/readback SHA；NEG stage 內越 WriteSet／不匹配 source | Stage 不得改 Live Reader pointer，且不准對外宣稱已作用 |
| OWNER_APPROVED | 真 Owner 批准作用於 exact tuple | signed (subject,candidate_sha,scope,base_epoch,expiry,risks,rollback_ref) → Approval Receipt | POS 驗真 key、nonce、TTL、subject；NEG stale base、scope widening、重放 | 已簽才進 Activate；Owner 授權可批量涵蓋同一 PlanRevision 但每寫 scope 有界 |
| ACTIVE_EPOCH | 原生當期 Activator（需 discovery）＋ HGK Policy Gate | CAS expected_active_epoch、candidate SHA、approval、rollback snapshot → new (active_epoch,sha) | POS 真原子 Active pointer/epoch 讀回；NEG CAS stale、policy mismatch、signature fail | CAS/lock failure 不修改 Live；失敗報 firstfail 對該 Consumer PARK |
| HOST_LOADED | 各註冊 Consumer 的 Host Loader，只能按授權讀／載 | (active_epoch,sha)、loader impl SHA、Host/OS Principal → (host_id,loaded_epoch,loaded_sha,load_ts) | POS fresh Host Process 真執行當期政策檢查；NEG reload 後仍舊 SHA/僅 README 顯示 | Host Loaded 不等於 Consumer used；對受影新效果阻斷，舊穩態視有效 Epoch 規則判 |
| CONSUMED_ACK | 原生 Operation Consumer 在實際 Gate Decision 回執 | loaded epoch/digest、operation ID、policy_decision、resource scope、principal → ACK + raw | POS Active=Loaded=Consumed sha/epoch 綁同 operation；NEG ACK 借他 Subject 或只讀 inspect | mismatch 立即 NACK、保留前像；可回退到舊 approved epoch 的獨立交易 |
| ROLLBACK/RECONCILE | Fabric Owner＋受限 Activator；已知有效 previous snapshot | compare actual world/loaded/active/ack → RECONCILED 或 UNKNOWN_EFFECT_HOLD | POS 原子切回經批准版本且 Host 重新 loaded/ACK；NEG 把快取恢復視為真世界回滾 | Unknown 不盲目重跑；補償/回滾另行 ECP/Permit；禁止刪原 Evidence |

**三類 Raw（本專項驗收契約，不是聲稱現役檔名）**：`RAW-FAB-STAGE` 有 `policy_id,source_sha,base_epoch,candidate_sha,stager_principal,stage_write_set,raw_bytes_digest,utc_time`；`RAW-FAB-ACTIVE` 有 `approval_signature_ref,expected_epoch,actual_epoch,active_sha,activation_result,policy_owner,currentness`；`RAW-FAB-CONSUME` 有 `host_id,host_pid,loader_binary_sha,loaded_epoch,loaded_sha,operation_id,consumed_sha,decision,ack_raw_digest,checker_ref`。以 `policy_id+subject_sha+epoch+operation_id` join；缺單類不擬造另一類，不以單份自評充三類。必要時另存 `RAW-FAB-ROLLBACK`，但只屬 rollback 事件，不取代三 Raw。

### 3.3 變更交易與非直通保證

1. **預備**：現有 Policy Source `source_hash`、Active Epoch `old_epoch`、全部受影 Host 的 Loaded Epoch 逐一讀；存 immutable previous snapshot；ChangeClass、Risk/EffectClass、Owner、WriteSet、Compensation Proposal 都有定位。未取得現役權責時 P0 只做唯讀。
2. **Stage**：寫 *候選* 專用 Stage Tree，使用 pinned digest 和 schema validation；先跑 Positive+Negative Policy Canaries（`unknown change class`、跨 Source、擴權、過期政策）；包括原 consumer `apply_preapproved()` 的 read-only 不得作真 apply canary。
3. **Approve+Activate**：Owner 於同一被鎖定 candidate SHA 上簽准；真原生 Active pointer 依 CAS epoch 切換。操作需使用已發 Native Admission 的 scope，不以 Stage/Approval 本身當 Execution Permit。
4. **Distribute/Load**：Host Loader 以簽章版本和實際檔案比對；異常拒絕該 Host 受影新操作。不能用 `import success` 判定 effective load；需一個禁止操作實例證政策被**實際拒絕**與一個合法實例證允許。
5. **Consume**：每個 Operation 的 HGK Receiver/Executor 帶 `policy_epoch+policy_sha` 到既有 Fabric policy Reader；ACK 必由相應 Host/Reader 的真 Principal 生成，獨立 Checker 比對。無法達成一致時 `POLICY_NOT_EFFECTIVE` 局部 PARK，不切換未知版本。
6. **復原**：Activation 前失敗只撤 Stage；Activation 後但尚未 Load，依 owner-gated reversal epoch/previous snapshot 回復；已有 world effect 時以 World Readback→Reconcile→獨立補償 permit，絕不 `git revert` 取代世界恢復。回復後再驗 full host loaded/consumed negative，保存每次 epoch 的證據。

**不繞過不變量**：`canonical_source_sha == active.source_sha == loaded.mapping.source_sha == consumed.mapping.source_sha`，且 `approved_map[host].projection_sha == loaded[host].projection_sha == consumed[host].projection_sha`；僅未經編譯且 bytes 完全相同才直接用同 SHA 比較、`active_epoch` 單調、Policy rollback 本身形成**新事件**不得倒寫歷史 epoch、未授權 principal 無法直接修改 active pointer/loader cache、轉譯 Adapter 不自帶 Policy Grant。多 Host 消費時逐 Host 回讀，不可一個 ACK 代理所有 Host。

### 3.4 Fabric 具體 POS／NEG／受影出口

`POS-FAB-01` 合法低風險 `CONFIG_PREAPPROVED`（前提：現役 Router/Activator 確已支援且 Owner 賦限）完成 Stage→Owner exact approval→Active epoch+1→新 PID Loader SHA→同操作 Policy ACK，原世界狀態可讀回。`NEG-FAB-01` 故意只 Stage，確認 Active 未變；`NEG-FAB-02` 激活後阻止新 PID reload，Consumed 必拒；`NEG-FAB-03` 另一 Policy ID/Scope、過期 epoch、wrong SHA、unsigned approval 均拒；`NEG-FAB-04` 注入崩潰於 Active 切換前/後，最多擁有一個有效 active pointer，恢復需 reconciliation。缺實體 activator：`FP_ACTIVATOR_UNBOUND`，**只 HOLD 受影 policy change/consumer verification，保留 L0/L1 及可獨立 L2**。


### 3.5 Policy Source→Compiled Projection→Host Decision：跨異質載入的有簽名語義對等（AUD-009/020）

**原則**：v1 的 `stage_sha==approved_sha==active_sha==loaded_sha==consumed_sha` 僅在五階段確定消費**完全相同 bytes** 的少數情形成立；不能對經 compilation/normalization 的各 Host 無條件比對同一 digest。Fabric Policy Owner 仍唯一控制 Policy Source 與 Promotion，HGK/Host 原消費者只作簽名的 projection readback，**不得自行升格來源法位**。

| 原子事件 | Writer／持久欄位 | 可反證條件／操作結果 |
|---|---|---|
| F-PSRC | Fabric Policy Writer：policy_id,policy_source_sha,policy_schema,source_version,owner,scope | Source 缺/不相符→SOURCE_NOT_PINNED，不執行 Stage |
| F-COMPILE | 受准入 Compiler：policy_source_sha,compiler_binary_sha,compiler_schema_version,target_host,projection_sha,semantic_contract_hash,compile_raw | 擴權、遺失 Deny、未知主體的轉譯→PROJECTION_SEMANTIC_MISMATCH；無 signed mapping 不合格 |
| F-APPROVE | Fabric 有權 Owner 對 (policy_id,source_sha,projection_sha(s),base_epoch,host_scope,expiry,rollback) 簽名；**逐 Host projection 預期可不同** | 只批准 Source 未批准輸出而後由任意 Compiler 替換→APPROVAL_PROJECTION_UNBOUND |
| F-ACTIVE | 原生 Activator CAS：epoch_new,approved_source_sha,accepted_projection_map_hash,activation_event_id | CAS stale／改用別的 compiler 結果→NACK，原 active 保持 |
| F-LOADED | 每個 **受影** Host Loader：host_id,process_id,loaded_binary_sha,loaded_projection_sha,source_mapping_ref,epoch | 同 Source SHA 但實際載入錯投影／舊 PID cache→LOADER_MISMATCH |
| F-CONSUMED | 實際 Policy Decision Reader：operation_id,host_id,decision_policy_ref,observed_projection_sha,epoch,allow_or_deny,raw_digest | 只讀 config 沒有實際判斷，不給 ACK；錯投影但 canonical sha 相同亦拒 |

**跨產物守恆式**：`approved_source_sha == active.source_sha == loaded.mapping.source_sha == consumed.mapping.source_sha` 且 `loaded.projection_sha == approved_map[host_id].projection_sha == consumed.observed_projection_sha`；若多個 Host 以不同編譯投影承接同一 Source，還須同一 `semantic_contract_hash` 已由 Owner 批准，並針對各 Host 個別 negative `Deny` 實驗。`affected_host_ids` 與 `affected_operation_classes` 是真依賴決定，健康 Host 的既有合法 Epoch 不因非受影 Host 失聯 GLOBAL_HOLD。回滾另開新 Epoch 交易、逐受影 Host reload/readback；不做原 Epoch 時間倒退。`RAW-FAB-STAGE/ACTIVE/CONSUME` 在 §3.2 的語義仍保留，但新增 mapping 證據才可支援異質宿主。

## 4｜HG-KSEOS 唯一 Native Control：Trust、Issuer、三 Lane、持久授權

### 4.1 控制權與 As-Is/To-Be

**As-Is**：`src/hg_kseos/spine.py` 可讀到 SharedSpine SQLite WAL、transaction `BEGIN IMMEDIATE`、Lease/State 基座；`lane_policy.py`/`lane_admission.py` 是候選 Policy/Probe；`lane_route_resolver.py` 明言未連入 launcher；B1 Closure `code/native_admission.py` 開頭標「unactivated repair」，需要 Owner-protected registry。**To-Be** 只在現役 HGK 的真 `ProtectedRegistry→Resolver→Issuer→Receiver→SharedSpine` 上做缺失修補，先讀 Windows Process executable/module origin/ACL/registry/schema，再綁同源 Adapter。**嚴禁**把 `b1_closure_.../code` 直接當 `site-packages` 內現役實裝，也不新增平行 lease table 或第二個 scheduler。

### 4.2 HG-01～06 Native 信任與授權鏈

| 節點 | 輸入／前置 | 真可觀察效果與原權威 | NEG／復原 |
|---|---|---|---|
| Trust Profile + OS ACL | OS SID、公鑰/憑證指紋、Scope、Key 調用權、有效期、Owner-approved profile、policy epoch | 真可信 Reader 的一致 root；User Trust 只在原生 Receiver 支援且已批准才有效；普通 Standard User 唯讀不需升 Administrator | 錯 SID/Root/ACL、私造 HGK_TRUST_PROFILE 環境變數均不能授權；變更 Trust Anchor 必新高權限 Gate |
| Protected Registry/Resolver | 完整 key identity、Runner executable path+sha、ABI/schema version、Operation class、allowed scope、Owner 註冊 | resolver readback 須與 Receiver import origin、loaded module sha、Trust source 同源 | signed registry 檔存在但 loaded binary 不相符→RUNNER_UNBOUND；只停消費該 Runner 的卡 |
| Proposal → Issuer | 經 SBL/PIPD 的 typed candidate、frozen clauses/source hash、subject、scope/operation、policy epoch、Owner Permit/Approval | 只有真受保護 HGK Issuer 可發原生 WorkOrder/Permit/ExecutionAdmission，PLAN/TPM/Codex 不得自己簽 | Proposal 任意字段/過期批准/不屬於 approved TaskKind→NACK，不借 demo key |
| Receiver | real signed WO、Permit、non-revoked nonce、TTL、scope、resource root、same subject/epoch、OS caller ACL | 執行入場前完成驗章+claim/mutex/fencing，保存 Raw Operation ID；世界寫入只在有權 Executor 持有效果 handle 時進行 | wrong principal/subject/root/scope/expired/replay/nonce/epoch → before-spawn deny；未知外部效果只 readback/reconcile |
| SharedSpine/CAS Lease | Ready card, dependencies, generation, claimed lease TTL, durable journal | CAS→RUNNING→EffectCommit/Checkpoint；claim 的 lease_generation 及 expected state 一致；失敗釋放／requeue受影卡 | stale generation 不能 commit；READY>0 / RUNNING>0 不得 Final；A PARK 不餓死 B/C |
| Protected Checker | immutable raw bundle (subject,source,policy_epoch,operation,version), frozen oracle, distinct verifier principal/credential/ACL | 實際 Checker 在 read-only protected scope 逐正負例回覆 Signed Verdict；Maker 無更改權 | 同一 Actor 切多角色、模型名不同但共用 key，不能證 SoD；Checker 缺失為 NOT_VERIFIED |

**Owner 低干預**：單一 Human Owner 可在一次 ceremony 批量批准「可預見、一致 policy epoch、Root、WriteSet、Operation 類別、時限」的有界許可；Issuer 為每筆不同 Operation 執行 nonce/lease gating，不再要求 Owner 逐平凡 read-only probe 重簽。任何新增 Root、Elevated effect、UserData/Remote Publish、Trust Anchor/Policy authority/Release 的實質風險提升仍需專門授權。Human Owner 與 Maker/Checker 不必是三個人，但受信任技術身份／ACL／密鑰不得虛擬分離。

### 4.3 三個*物理* Lane 與四種職能配置

| Physical lane | 角色池、允許輸入/輸出 | Desired Route（取自母藍圖 §X；只是目標設定） | 禁止和適用生效 |
|---|---|---|---|
| PLAN | Native TPM goal/source→SpecCandidate；Native Commander admitted source/PD/ECP→PlanRevisionProposal/TaskDAG | OpenAI gpt-6.1-sol medium；fallback deepseek-v4.1-flash、mimo-v2.6-flash（均需現役 provider pin/real served） | 不發 Permit、Signed WO、不直寫 Queue；PROPOSAL 由 HGK Issuer 審批；Guide 是介面非第四 Lane |
| EXECUTE | Hermes durable dispatch、Code Worker、必要技能與 Method Invocation → Real Effect Raw/Checkpoint | OpenCode Go deepseek-v4.1-flash；fallback MiMo V2.6-Flash、OpenAI GPT-6 Luna（僅候選） | 僅 admitted WorkOrder，真 Repo/Host/User Scope；工具成功不等世界 readback |
| VERIFY_SECURITY | External Challenge 分析候選反例 → Protected AO Checker 在獨立 principal/只讀 ACL 執行 frozen oracle/Raw Verdict | OpenAI gpt-6.1-sol medium；備援候選 DeepSeek V4.1/MiMo，須驗 maker served 不相同受禁止身份 | Challenge 輔助 ≠ 獨立 Checker；模型路由/credential 假 identity、Maker 讀寫 Checker Verdict 直接拒收 |

**四能力域不等於四 Lane**：`TPM`,`Commander` 共用 PLAN 執行槽但不同功能/Role Binding；`EXECUTE` 與 `Challenge/Checker` 各用既有 EXECUTE/VERIFY_SECURITY。所有路由變更由 HGK Model Policy Owner 簽版，`requested_provider/model/transport` 逐次對 `served_provider/model/transport`，不以 UI alias/HTTP 200/模型自報文字當 served raw。

三 Lane `ADMITTED` 機械最低條件：`actual served identity == effective_requested_arm`（fallback 時保留原始 desired 與 selection reason）、真完成 model call、真完成至少一次受控 tool roundtrip、同 subject+epoch、在有效 TTL 與 policy map 內、可驗出處（Process/Transport）。`DIRECT_COMPLETION_ONLY` 由已讀 `lane_admission.py` 明確不能授予 lane `ADMITTED`。Fallback 僅按現役已批准池與故障分類（quota/auth/server/timeout/transport），切換後再測 served；非 permitted route、Provider-off、SoD conflict 不可靜默回退。

### 4.4 READY→CAS→Effect→Checkpoint 的狀態機與死結修復

| 原子轉移 | 必需前置／執行後證據 | 可失敗狀態與重入 |
|---|---|---|
| INTENT→CANDIDATE | TPM source-bound Goal，PIPD Reader + versioned ProductIntent；重複 Intent 有穩定去重 Key | 缺 Source/Oracle →只 park 受影編譯；合法純文字規劃可作 |
| CANDIDATE→ADMITTED | SBL Planner Proposal，HGK Issuer 簽 WO/Permit，subject_sha/epoch/ttl/scope | 權限被拒 → PARK_REASON 記真 firstfail；不用再畫新 Mission |
| ADMITTED→READY | 真 DAG 依賴清零、Owner Scope/Runner Binding 完整、journal durable | depends_on:null 不可當 []；非適用不得投入 READY |
| READY→RUNNING | 只有 Hermes 原生 Executor 能領 CAS lease、記 PID、lease generation、WorkState Event | Claim 競態失敗 NACK；不擴全域 HOLD；其他卡可執行 |
| RUNNING→EFFECT_KNOWN | 進程 true spawn、真 Runner/Exec SHA、exit/raw，世界 readback/join operation_id | 崩潰/timeout/外部 ACK unknown →先 RECONCILE_REQUIRED，同 nonce 不重播 |
| EFFECT_KNOWN→CHECKPOINT | 更新 durable journal、CAS 原 generation、source/subject/epoch、result digest | 舊 generation stale 不能 commit；成功才可解開下一依賴 |
| CHECKPOINT→VERIFIED | 真 Protected Checker 讀 frozen Oracle 與 Raw；PASS 可觸發下一合法卡 | FAIL→bounded repair proposal；未執行→NOT_RUN；不能用 Maker selftest 冒充 |
| VERIFIED→FINISHED | 同 Mission 全部 applicable Required+Triggered Conditional 達標，Queue READY/RUNNING 空、無 unresolved blocking cone | Report/Seal 為資料，不會停止 Worker；未達保持 OPEN+ResumeHere |

**持久自治最小證明**：讓 Helper Session/Token 撤銷，進程結束後由已註冊現役 OS wakeup 產生**不同 OS PID+Session UUID**，僅讀 SharedSpine journal 自主接管下一 eligible READY；不得由人工重新貼長 Prompt 或同一 Session 重新發指令。若沒有現役 wakeup，先 discovery 再在 HGK Owner 授權下接線 OS 常駐機制，不造第二 Scheduler。at-most-once 設計以 `(operation_id,subject_sha,epoch,lease_gen)` 原有可用欄位綁定，若實際 ABI 不存在需 Versioned Adapter 或 Native Owner 變更。

### 4.5 Native 操作的精確拒收分類

`NOT_RUN` = 沒派發/真 Runner 不在；`BLOCKED_MISSING_BINDING` = 缺原生可驗路由，未開始；`REFUSED_PRESPAWN` = Gate 真拒收，**對拒收測例可為 POS**；`RUN_FAILED` = 真已執行且失敗，有 exit/raw；`UNKNOWN_EFFECT` = 可能產生世界效果但未證結果，**不得重試**；`CHECKER_HOLD` = Raw 存在但受保護獨立審查缺件；`NATIVE_VERIFIED` = 同 Subject/Version 凍結 Oracle、真 readback、真不同 principal Verdict。任何 Transition 必攜原始 subject/resource/epoch、firstfail 與再入條件，不用單個布林 `success` 吞掉語意。


### 4.6 Model Route：Desired→有效選擇→Actual Served／Credential／SoD（AUD-010）

`desired_primary` 僅是 Owner-signed pool 第一順位，絕不直接拿來與 fallback 後的 served 作必等。每次 dispatch 的 trace 須是 `desired_primary → selection_decision{policy_epoch,allowed_pool,reason,trigger,error_class} → effective_requested{provider,model,transport,endpoint_identity} → actual_served{provider,model,transport,request_id} → verified_principal/key/ACL → real_model_call+tool_roundtrip`。`actual_served` 只須等於**本次已准入的 effective request**，同時證明 fallback 在原 pool、error 屬可回退種類、沒有不允許的 Provider-off 或 SoD 衝突。DirectCompletion/HTTP 200、模型字串 alias、自稱 served、同 credential 的角色切換均不合格。POS `FHG-T15` 讓 Primary quota-error 而 fallback real served；NEG 令 fallback 不在 pool／Checker 改用 Maker 相同 principal→拒。回復直接撤銷當次 Routing Binding、重新讀取 Owner-signed pool，不能臨時擴權。

### 4.7 非循環合法 BOOTSTRAP_REPAIR：先保可讀／隔離 L2，真 L3 回原 HGK（AUD-011）

**入口判斷（不得自行發新 Issuer）**：現役 HGK Issuer/Receiver 未生效時，合法 L0 文件及 L1 原生唯讀不需等 Issuer；只有現有 Domain Policy、OS ACL 與可核驗 Owner standing authorization **明確容許**的本地隔離 L2，才可走 `BOOTSTRAP_REPAIR`，且其法位是該 Domain 現有 local worktree authorization，**不是 HGK Native ExecutionAdmission 的替代物**。未找到此既存授權則只進 `READ_ONLY_DIAGNOSIS` + `OWNER_DECISION_REQUIRED`，不寫磁碟。

| 非循環步骤 | 真前置→受限行為→固定後像 | 必然拒收／返回唯一控制 |
|---|---|---|
| BR0 DISCOVER | 唯讀 Root/HEAD/Dirty/ACL/Permit state/現役 Issue ABI，識別壞鏈第一個 Reader | 禁讀秘密，Issuer missing 不等於全庫不可讀 |
| BR1 AUTH_BOUND | Owner 在現有 Domain/OS 權限上授予 exact (repo/worktree,base_HEAD,readset,writeset,max_attempts,expiry,effect_class=L2)；明確記錄來源、授權和拒收器 | 無批准／高風險 Host effect／跨 Root→PARK/NOFIT；不可自造 permit 格式冒充 HGK |
| BR2 ISOLATE | 對既有 dirty/untracked 作保全，**新合法 worktree** 做紅燈基線、單一受影最小 patch、綠燈、diff、rollback pointer | 修改原 488/52/53892/25581 歷史 dirty 之類現況作類推猜測或無備份覆寫→拒 |
| BR3 LOCAL_CHECK | 別的可用 checker 只作 local candidate review；L2_LOCAL_TESTED 不提升 NATIVE_VERIFIED | 純 CI/自測/不同 prompt 冒獨立 AO→拒 |
| BR4 RETURN_NATIVE | 一旦 Protected Registry/Issuer/Receiver 恢復，任何**後續** Native effect 必使用真 HGK Permit/WorkOrder/SharedSpine→Hermes Runner，bootstrap branch 停止新 effect | 將 L2 standing approval 默升 L3、或在並行 Issuer 中繼續→拒 |

**最低工件** `RepairCone`, `authorization_ref`, `base_head`, `write_set`, `preimage_sha`, `firstfail`, `red_green_raw`, `rollback_ref`, `effect_excluded`, `return_to_native_criterion`, `reentry_when`。限定此表的 `bootstrap` 是**本地有界修補操作級**，不獨立建立長壽 scheduler、policy、acceptance。檢查 `FHG-T30` + `AUD-FHG-T13`。


### 領域回源段 2：`FHS-MSC_FABRIC_and_HGK_升級藍圖_2026-10-28_v2_HIGH_RETENTION_AUDIT_REPAIR.md:L347–L516`

> 本段原生設計來源，高保留嵌入供下游逐條實作；如需更改正式 Policy/Schema/Gate，應回原 Domain Writer 決策。

## 5｜Fabric↔HGK↔Hermes↔SBL↔PIPD 的真正 E2E 接線與 Adapter

### 5.1 As-Is→To-Be 的 ownership 隔離拓樸

```mermaid
flowchart LR
  U[Human Owner Goal + Source] --> T[SBL TPM<br/>portable/Native PLAN]
  T --> PI[PIPD Canonical<br/>PI / PD / ECP / TQAEP Reader]
  PI --> C[SBL Commander<br/>PlanRevision Proposal]
  F[Fabric Policy Source] --> ST[Stage → Owner Approve<br/>Active Epoch]
  ST --> LC[Host Policy Loaded<br/>Consumed ACK]
  C --> HG[HG-KSEOS Sole Control<br/>Registry / Issuer / Receiver]
  LC --> HG
  HG --> SP[HGK SharedSpine<br/>READY / CAS Lease / Journal]
  SP --> H[Hermes durable<br/>EXECUTE dispatcher]
  H --> EX[Bounded Codex/Native Executor]
  EX --> RB[Real world/readback<br/>immutable Raw]
  RB --> V[Protected Checker<br/>VERIFY_SECURITY]
  V --> SP
  RB --> FAR[FAR FirstFail<br/>read-only research]
  FAR --> C
  V --> D[Owner reviewed Release<br/>separate L4]
```

**Source/Policy 不同邊**：`PIPD` 是候選 spec / lifecycle writer，`SBL PLAN` 是 Proposal writer，`HGK` 才有真 ADMIT/WO/Permit；Fabric 是治理 Policy Writer，Policy activation 由現役授權 consumer/owner 實作；Hermes 不是 Issuer；FAR 只做 candidate evidence/patch/OwnerChoice；Checker 無 effect write。

### 5.2 最小 Typed Exchange（僅 Sidecar 契約，不是 Native Schema 宣告）

以下 `FHG-Integration-Envelope@1-CANDIDATE` 是互操作上的**驗證責任清單**，不得直接冒充既有 PIPD/HGK schema；實際 Writer/Reader 必從現役 registry 暴露 schema ID、ABI version、digest 和 `supported_fields`，無法表達欄位時以外部 read-only reference bridge 且 Owner 書面決議，禁止向原生 JSON 強塞未知欄位。

```json
{
  "schema_id": "FHG-Integration-Envelope@1-CANDIDATE",
  "subject": {"id": "BIND_NATIVE", "sha256": "BIND_NATIVE"},
  "source": {"refs": ["SOURCE_URI#CLAUSE"], "sha256": "BIND_SOURCE"},
  "proposal": {"revision": "BIND_SBL", "producer_principal": "PLAN_ONLY"},
  "policy": {"id": "BIND_FABRIC", "epoch": "BIND_LIVE", "digest": "BIND_LIVE"},
  "work": {"operation_id": "BIND_HGK", "workorder_ref": "BIND_HGK_OR_NULL", "permit_ref": "BIND_HGK_OR_NULL", "effect_class": "BIND_ECP"},
  "lease": {"generation": null, "holder_pid": null},
  "evidence": {"raw_refs": [], "world_readback_ref": null, "checker_ref": null},
  "proposal_only": true,
  "native_admission_ref": null,
  "abi_binding_map": {
    "writer_subject": "BIND_NATIVE_OWNER",
    "schema_id": "DISCOVER_NATIVE_SCHEMA",
    "registry_sha": "DISCOVER_NATIVE_REGISTRY",
    "reader_module_sha": "DISCOVER_IMPORTED_MODULE",
    "field_map": "OWNER_APPROVED_MAPPING_PENDING",
    "source_clause_sha": "BIND_ORIGINAL_CLAUSE",
    "owner_decision_ref": null,
    "currentness": "HOST_NOT_OBSERVED"
  },
  "status": "PROPOSAL_ONLY_NOT_ADMITTED"
}
```

| 欄位組 | Native 優先 Writer／既有 ABI discovery | Adapter 必做的驗證 | 缺件/NEG |
|---|---|---|---|
| subject/source hash | PIPD PI/PD Current Source；HGK WorkSpec 主體 | SourceRef→blob SHA→Subject/Repo HEAD 綁定；不得只用檔名 | Source mismatch SOURCE_STALE, affected compilation HOLD |
| policy epoch/sha | Fabric Activator/Consumer 真版本；HGK Policy Reader | active=loaded=consumed 同 Subject/Operation；epoch monotonic | POLICY_NOT_EFFECTIVE, effect denied, read-only unaffected |
| proposal_revision | SBL PLAN Native/Portable current proposal ABI | DAG version、dependency coverage、Creator Principal，無權改 Issuer | Planner output with permit_id or false Actor→NACK |
| workorder/permit | **HGK Issuer** 原生 schema，PIPD ECP 為約束 | signature/Subject/Root/TTL/nonce/permission/readset/writeset | self-signed WO、ECP 當 permit 均拒 |
| operation_id/lease_gen | HGK SharedSpine/Receiver | Exactly known outcome reconciliation、fencing compare generation、at-most-once | process crash + reused nonce or stale gen cannot commit |
| principal/credential | OS Trust/Protected Registry 與 Checker AO | real SID/Key fingerprint/ACL、Reader/Writer分離 | AI 角色名或不同 prompt 不證 SoD |
| raw/readback/checker | Hermes Executor、Host Consumer、Protected Checker | raw bytes/exit/PID/digest/Subject/epoch/negative result 綁定 | CI PASS、Fixture PASS、Model vote 不准當 NATIVE PASS |

**ABI 映射規則**：若 Repo `SBL` 的 `sbl-stack` 已支援 `install/status/doctor`，只能讀回其本地 Stack；不可臆造 `sbl-stack plan.propose`；若 PIPD 13 verbs 中確無 `issue-permit`，不得自行加 CLI Verb，改走已存在 HGK Issuer。Node/SQLite/PowerShell 的範例命令只有 Host 重新確認 parser 的版本後才允許投入正式 WorkOrder。

### 5.3 序列一：成功路徑（有真正適用許可）

```mermaid
sequenceDiagram
    actor User as Human Owner
    participant S as SBL TPM / Commander
    participant P as PIPD Canonical
    participant F as Fabric Active Policy / Host Loader
    participant G as HGK Issuer / Receiver / SharedSpine
    participant H as Hermes Executor
    participant V as Independent Checker
    User->>S: Goal + Source (normal task)
    S->>P: source-bound Intent → PI/PD candidate
    P-->>S: versioned artifacts, ECP constraints, test plan
    S->>G: PlanRevision Proposal (not a permit)
    G->>F: read ActiveEpoch / LoadedDigest / ConsumerPolicy
    F-->>G: active source→signed host projection→loaded/consumed ACK same operation
    G->>G: verify OS trust, signer, subject, scope, nonce
    G-->>H: Admitted WO + READY journal
    H->>G: CAS lease (fencing generation)
    G-->>H: claim accepted
    H->>H: run bounded Codex/Native Runner
    H-->>G: exit/raw + world readback + checkpoint
    G->>V: immutable subject-bound evidence + frozen oracle
    V-->>G: independent PASS or finding
    G-->>User: verified user outcome / scoped claim ceiling
```

### 5.4 序列二：拒收路徑（stage only／wrong permit／provider-off）

```mermaid
sequenceDiagram
    participant S as SBL PLAN
    participant F as Fabric Consumer
    participant G as HGK Admission
    participant H as Hermes
    S->>G: proposal with Stage SHA only / no ActiveEpoch
    G->>F: check actual policy Loaded/Consumed
    F-->>G: NACK POLICY_NOT_EFFECTIVE
    G-->>S: PARK only affected plan, named firstfail
    Note over G,H: No READY effect card; no spawn; other eligible jobs continue
    S->>G: wrong scope / expired nonce / ProviderOff fallback
    G-->>S: REFUSED_PRESPAWN or NOFIT with raw
    Note over S,G: Do not silently downgrade model, kind or effect class
```

### 5.5 序列三：Crash／未知效果／跨進程恢復

```mermaid
sequenceDiagram
    participant G as HGK SharedSpine
    participant H1 as Hermes Worker PID-A
    participant R as Real World / Receiver
    participant H2 as Native Wakeup Worker PID-B
    participant C as Protected Checker
    G->>H1: READY → CAS lease generation 5
    H1->>R: operation OP-1 (at-most-once effect)
    R-->>H1: network timeout, outcome unknown
    Note over H1: PID-A crashes before checkpoint
    G->>G: journal stale lease; RECONCILE_REQUIRED
    G->>H2: OS wakeup new PID + new Session
    H2->>R: read actual OP-1 world effect (no re-exec)
    R-->>H2: effect found with operation identity
    H2->>G: CAS generation 6, reconcile + checkpoint
    G->>C: original immutable raw + world readback
    C-->>G: verdict, same subject+epoch
    Note over G,H2: Previous generation 5 cannot commit; no duplicate effect
```

### 5.6 SBL Kind×Mode×Host 與雙 Module Taxonomy 的真正宿主行為

| 產品 Kind / Mode / Host | 受影 Fabric/HGK 能力 | 實際安裝判準與替代／NoFit |
|---|---|---|
| CLI_TOOL | SBL sbl-stack local install、Source/WriteSet/JSON exit | STANDALONE 在 4 Host 的其中一個已支援 Host 真 Fresh Process；無 Plugin 不影響本地 CLI；真卸載無 foreign data 消失 |
| AGENT_SKILL | Portable manifest/loader，Host trust/read permission | Host Discovery/Install/Trigger/Nontrigger/Unload；Provider-off 下有源可驗 NoFit 或降為純說明，**不假稱 Loaded** |
| SIMPLE_AGENT | HGK tool allowlist、Time/Budget、Hermes Worker lease | 有 HGK Permit 的單一 bounded operation；無授權維持 candidate，不把多 Skill 包裝為 Agent OS |
| PLUGIN/PROFILE | Host Plugin entitlement + Account Install; Native RoleBinding/Default Profile | 原 DEFERRED_UNVERIFIED，有 Provider/Host 及合格 Publisher 才可 Enabled；不靜默丟失其產品義務 |
| AGENT_OS/AI_SYSTEM | 非 v0.1 可執行宿主 | 原 UNSUPPORTED_V0_1，NoFit 仍保留產品身份，不誤升格 |
| GENIE/GENIE.md | SWOF W2 shadow reader | W3 原 Native Owner/Gate 未准不得 effect；ReadOnly Spec 包保存 |
| PREW3_SHADOW（任何 Kind） | Shadow-only observer | No Effect；即使有 PIPD ECP 或 Skill trigger 也不能寫世界 |
| SWOF_CONNECTED | 真 Native W3 Receiver ACK 才可能 effect | 沒有 issuer/permit/subject/signature/Native ACK 僅設計 Reader，禁止借 HGK Stage 成 W3 grant |

總藍圖 **兩套 M1–M6**：新 `Guided Spec→Governed Build→Evidence-based Verify→Bounded Repair` 的 `M05 Evidence/M06 Bounded Repair` 是目前 `sbl_core/` 技術實現之一；舊 SBL `M5 Repair` 與 `M6 Distribution/Host` 是原產品設計域要求。映射的消費合約要保留 `new_core.m05`/`new_core.m06` 與 `legacy_product.m5`/`legacy_product.m6_host` 的兩個具名 Namespace；不能由 `SBLM06` 程式存在就自動滿足四 Host Distribution。


### 5.7 PIPD TQAEP 四級生命週期與合法早期測試計畫出口（AUD-006/007）

`TEST_PLAN_MATERIALIZED != RUNNER_BOUND != EFFECT_EXECUTED != INDEPENDENT_VERIFIED`。**上游 PIPD DOC-03/05/07 的原 Writer 法位不變**；v1 附錄 D `pipd compile-tqaep --checker-receipt <RAW_RECEIPT>` 是可能造成循環的來源示例，不能不經真 P4 parser 检验就要求第一個 TestPlan 提前有實機收據。本稿不自造正式 CLI flag。

| 階段／Owner | 可用資料與合法輸出 | 真 POS／NEG／受影 HOLD |
|---|---|---|
| TQAEP_PLAN_DEFINED／PIPD Plan Writer | Frozen Subject+Oracle/ACC/FailureCondition+POS/NEG fixture+預期 Runner/SoD/claim ceiling → **ReadOnlyTestPlan/PlanCandidate** | 不必事先有 Checker Receipt；未凍結 Source/Oracle 則該 Plan NACK；不授 Native effect |
| TQAEP_RUNNER_BOUND／PIPD/Runner Owner | Plan + Host real Runner/Schema/ABI/Permission/Actual WriteSet+test dataset → RunnerBinding | 僅 Runner --help 或 Demo registry 不等於已綁；missing binding 只阻該 case 的 Live |
| TQAEP_EXECUTED／HGK admitted Executor | 真 Permit/WorkOrder/Runner invocation/exit/raw/WorldReadback → Evidence | Fixture/CI PASS 不能冒充 Live；Unknown Effect 先 reconcile |
| TQAEP_INDEPENDENT_VERIFIED／Protected Checker | Frozen Oracle+exact executed Raw+different protected OS Principal/ACL+signed verdict → Independent Receipt | 同 Maker、未執行、Receipt 借用他 Subject、改 Oracle 均拒 |

**真正 P4 CLI/Schema 不允許 PLAN without Receipt 時**：Owner 不可要求違反現役 schema；設計者先依合法 `ReadOnlyTestPlan` 路徑留計畫，列 `PIPD_TQAEP_PLAN_ABI_BLOCKED`，只 PARK 受影正式 TQAEP Compile/Native Live。由 PIPD Canonical Owner 核准 versioned Reader Adapter 才轉正，不造未發布的 `--plan-only` flag。`FHG-P3-01→FHG-T22/23` 加入 `AUD-FHG-T06` 以 non-circular test 確認。

### 5.8 FHG Sidecar ABI Binding（AUD-019，絕非 Native Schema）

§5.2 的 `FHG-Integration-Envelope@1-CANDIDATE` **必帶** `proposal_only=true`, `abi_binding_map={writer_subject,schema_id,registry_sha,reader_module_sha,field_map,source_clause_sha,owner_decision_ref,currentness}`，且標註 `native_admission_ref=null`（直到有權 HGK Writer 已發真准入）。其唯一合法輸出是 **integration design projection**，不得輸入 HGK/PIPD/Fabric native parser 當 Canonical Consent。Adapter 必先以真 schema discovery 驗證 field map；原生不支援某欄即以隔離 sidecar reference 保存（不可擅加原 JSON keys）；至少測 wrong subject、unknown schema、version skew、stale sha、legacy Oracle ownership 和 12/9 Profile risk axes 不丟失。需用`source_file_sha+exact_clause_locator+clause_digest` 綁原條文，換版只 invalidate 受影投影。
~~~~~~~


## R2 四庫當期原始碼接線與變更界線（精確路徑）

- `Fabric/FABRIC/fabric/consumers/hgk_policy_consumer.py` 真 `load_router()` 對應原 Repo 的 `FABRIC/rp002/RP002_CHANGE_CLASS_ROUTER.yaml`；router blob `3fd4e63bb4a9ef8bab247f114234629ebdf15f08`，不得錯寫 root `/rp002/`。原 Windows 常量仍須 Host 確認，且 Stage Policy≠Active/Loaded/Consumed。
- `HG-KSEOS/src/hg_kseos/spine.py` blob `0c00c3785c7fe478b61ccc6caa90254963924f6d` 具有 `SharedSpine`；`lane_admission.py` blob `66e55c8fa527c759971e271e25b52acdf0b04733` 明示 CANDIDATE（HTTP200≠真正 Tool Roundtrip）；`cli.py` blob `87ac77a0459e84db796e0554459f651f6d062fac`、`harness.py` blob `4777365f47a4410bf9266d8b2584ce53aa06b2aa` 可讀但未 Host invoke。
- `SBL/sbl_core/m04_bridge.py` blob `0d9ea8f096ad79b6cfdf31767d84215165aec436` 有 `bind_repo_context/GovernedBuildBridge`；`m05_verify.py` `d098298d6ebe558ff34321c72924ae34df074055` 用生效 claim ceiling 和真 evidential statuses；`tests/test_modes.py` `07a20f8efdc07578d199531d808890ce047a2431` 存在相關 NEG，而非已對本次 Host 跑過。
- `PIPD-LS-SP/src/pipd_ls_sp/repo_context.py` blob `31e334ce8c0c309acf0250d3be0be3f76b116490` 的 RepoContext 由真 Git/FS probe 得來，拒絕使用者自述 head 充當 current；`validate.py` blob `7c3145cd002bec1f8496b257fe932c826a6c109b` 僅 deterministic validators；不能用 local schema-shape PASS 當正式 Writer ACK。
- 四庫 HEAD 仍依 2026-10-30 直接唯讀查詢：HGK `f6dfb1e57162dc3868dc488482d249fc095eb429`、SBL `fd62537a7ba29c3f2905fe42ddde9534674405d7`、Fabric `316b691460638bdf38475c2c58aaad406aa6eb4f`、PIPD `f6335a94157c61da75d92121d14c43feb413e981`。因未取得當期 Windows Worktree/Active Policy/Loaded SHA/Issuer，這不是原 Host Actual Effect。

**建議的有界 Patch WorkSet（提案，不改 Repo）**：先由各原 Repo Owner 以唯讀 `git status --porcelain=v2 -z`、`git rev-parse HEAD`、`git ls-files`、`git diff --name-status`、Host Effective Loader/Registry 取得 preimage；之後只依 actual missing edge 定 exact patch / POS / NEG / rollback。發現 dirty／untracked 絕不 reset/clean；缺原 Permit 不执行寫入。
