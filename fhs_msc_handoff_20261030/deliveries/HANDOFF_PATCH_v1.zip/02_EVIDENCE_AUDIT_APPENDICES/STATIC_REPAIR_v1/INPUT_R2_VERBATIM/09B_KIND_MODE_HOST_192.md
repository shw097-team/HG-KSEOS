> **CURRENT FHS READER 2026-10-30_r2_HIGH_RETENTION_AUDIT_PATCHED_SOURCE_BOUND**；原 Domain Writer 不變；歷史 fenced block 不得作有效條位。

# 09B KIND MODE HOST 192｜FHS-MSC_PIPD-LS-PKG 2026-10-30 整合實質正文

> **FHS-MSC_PIPD-LS-PKG / 2026-10-30_r2_HIGH_RETENTION_AUDIT_PATCHED_SOURCE_BOUND / EFFECTIVE_DESIGN_READER**。本冊按同域來源整合 2026-10-29 BODY revision2 和 2026-10-30 r2 最新受影修補。R2 受影條款在本冊設計閱讀範圍優先於被修補之歷史片段；但不覆寫 SBL/PIPD/Fabric/HGK 原 Writer、已生效 Policy/ABI。全部 Native／Owner Ratification／IndependentChecker／Release 未在本沙盒執行。
>
> **ClaimCeiling** `SOURCE_BOUND_INTEGRATED_DESIGN_WITH_LOCAL_READBACK`；`REPO_SOURCE_REMOTE_OBSERVED` 不代表 `LOCAL_REPOCONTEXT_BOUND`，不得藉本檔取得原授權。此文件前半 r2 更新與後半歷史正文是一份整合 Candidate，不是平行的兩份現役 Canonical。


## 本輪同域受影修復：r2 §7 全量192 個Kind×Mode×Host×Provider

## 7. SBL 192 個 Kind×Mode×Host×Provider Legacy Cell：逐 Cell 生效行為

`CELL-<id>` 都保留原 `Kind/Mode/Host/legacy=ON|OFF`，並由本節每筆 Source Clause 的 ModeGate、HostCaps、POS/NEG、NoFit/卸載綁定。**原來源 ON/OFF 欄位有標籤語義衝突**：BODY09B 候選提出 ON→provider_off=UNBOUND_OWNER_ACK_REQUIRED、OFF→true，但仍需原 Product/Host Owner 签；未決為 `OWNER_BIND_HOLD`，不得以名稱猜測正式 Provider Enum，更不得 Provider-off 外呼。SWOF_W2 Shadow 無可寫世界；合法本地產品 Build 是另一 Subject。[BODY09B `R2-09B-CELL`]

### CELL-d0cf30ffd7c1｜CLI_TOOL/STANDALONE｜Hermes Agent｜legacy=ON
- **原定位**：`BODY-09B:26`；真 Cell Id `CELL-d0cf30ffd7c1`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L29，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；OS process runner，不要求Host skill loader。
- input→behavior→typed output：source-bound input→乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Hermes Agent/CLI_TOOL/STANDALONE/ON：原Hermes tool/skill loader與worker fresh PID驗乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒無entrypoint或退出碼未記錄；若raw.host不等於Hermes Agent或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無OS process runner，不要求Host skill loader，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `d0cf30ffd7c1` 的唯讀 Cell 產品設計候選。

### CELL-e8a4077d37ad｜CLI_TOOL/STANDALONE｜Hermes Agent｜legacy=OFF
- **原定位**：`BODY-09B:37`；真 Cell Id `CELL-e8a4077d37ad`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L30，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；OS process runner，不要求Host skill loader。
- input→behavior→typed output：source-bound input→乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Hermes Agent/CLI_TOOL/STANDALONE/OFF：原Hermes tool/skill loader與worker fresh PID驗乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒無entrypoint或退出碼未記錄；若raw.host不等於Hermes Agent或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無OS process runner，不要求Host skill loader，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `e8a4077d37ad` 的唯讀 Cell 產品設計候選。

### CELL-6582a70fd427｜CLI_TOOL/STANDALONE｜Codex｜legacy=ON
- **原定位**：`BODY-09B:48`；真 Cell Id `CELL-6582a70fd427`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L31，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；OS process runner，不要求Host skill loader。
- input→behavior→typed output：source-bound input→乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Codex/CLI_TOOL/STANDALONE/ON：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒無entrypoint或退出碼未記錄；若raw.host不等於Codex或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無OS process runner，不要求Host skill loader，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `6582a70fd427` 的唯讀 Cell 產品設計候選。

### CELL-434c21c50bc3｜CLI_TOOL/STANDALONE｜Codex｜legacy=OFF
- **原定位**：`BODY-09B:59`；真 Cell Id `CELL-434c21c50bc3`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L32，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；OS process runner，不要求Host skill loader。
- input→behavior→typed output：source-bound input→乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Codex/CLI_TOOL/STANDALONE/OFF：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒無entrypoint或退出碼未記錄；若raw.host不等於Codex或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無OS process runner，不要求Host skill loader，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `434c21c50bc3` 的唯讀 Cell 產品設計候選。

### CELL-41348f62f97c｜CLI_TOOL/STANDALONE｜Claude Code｜legacy=ON
- **原定位**：`BODY-09B:70`；真 Cell Id `CELL-41348f62f97c`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L33，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；OS process runner，不要求Host skill loader。
- input→behavior→typed output：source-bound input→乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Claude Code/CLI_TOOL/STANDALONE/ON：Claude Code當期原loader＋乾淨session驗乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒無entrypoint或退出碼未記錄；若raw.host不等於Claude Code或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無OS process runner，不要求Host skill loader，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `41348f62f97c` 的唯讀 Cell 產品設計候選。

### CELL-4bf76833ac66｜CLI_TOOL/STANDALONE｜Claude Code｜legacy=OFF
- **原定位**：`BODY-09B:81`；真 Cell Id `CELL-4bf76833ac66`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L34，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；OS process runner，不要求Host skill loader。
- input→behavior→typed output：source-bound input→乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Claude Code/CLI_TOOL/STANDALONE/OFF：Claude Code當期原loader＋乾淨session驗乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒無entrypoint或退出碼未記錄；若raw.host不等於Claude Code或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無OS process runner，不要求Host skill loader，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `4bf76833ac66` 的唯讀 Cell 產品設計候選。

### CELL-2738990e2c09｜CLI_TOOL/STANDALONE｜DeepSeek Harness｜legacy=ON
- **原定位**：`BODY-09B:92`；真 Cell Id `CELL-2738990e2c09`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L35，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；OS process runner，不要求Host skill loader。
- input→behavior→typed output：source-bound input→乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：DeepSeek Harness/CLI_TOOL/STANDALONE/ON：實際Harness adapter/capability reader；API_ONLY不能充loader驗乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒無entrypoint或退出碼未記錄；若raw.host不等於DeepSeek Harness或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無OS process runner，不要求Host skill loader，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `2738990e2c09` 的唯讀 Cell 產品設計候選。

### CELL-3869542dc2f7｜CLI_TOOL/STANDALONE｜DeepSeek Harness｜legacy=OFF
- **原定位**：`BODY-09B:103`；真 Cell Id `CELL-3869542dc2f7`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L36，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；OS process runner，不要求Host skill loader。
- input→behavior→typed output：source-bound input→乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：DeepSeek Harness/CLI_TOOL/STANDALONE/OFF：實際Harness adapter/capability reader；API_ONLY不能充loader驗乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒無entrypoint或退出碼未記錄；若raw.host不等於DeepSeek Harness或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無OS process runner，不要求Host skill loader，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `3869542dc2f7` 的唯讀 Cell 產品設計候選。

### CELL-1407c7aa1d27｜CLI_TOOL/PREW3_SHADOW｜Hermes Agent｜legacy=ON
- **原定位**：`BODY-09B:114`；真 Cell Id `CELL-1407c7aa1d27`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L37，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；OS process runner，不要求Host skill loader。
- input→behavior→typed output：source-bound input→乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Hermes Agent/CLI_TOOL/PREW3_SHADOW/ON：原Hermes tool/skill loader與worker fresh PID驗乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒無entrypoint或退出碼未記錄；若raw.host不等於Hermes Agent或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無OS process runner，不要求Host skill loader，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `1407c7aa1d27` 的唯讀 Cell 產品設計候選。

### CELL-6b424688af61｜CLI_TOOL/PREW3_SHADOW｜Hermes Agent｜legacy=OFF
- **原定位**：`BODY-09B:125`；真 Cell Id `CELL-6b424688af61`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L38，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；OS process runner，不要求Host skill loader。
- input→behavior→typed output：source-bound input→乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Hermes Agent/CLI_TOOL/PREW3_SHADOW/OFF：原Hermes tool/skill loader與worker fresh PID驗乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒無entrypoint或退出碼未記錄；若raw.host不等於Hermes Agent或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無OS process runner，不要求Host skill loader，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `6b424688af61` 的唯讀 Cell 產品設計候選。

### CELL-56eaea595d3d｜CLI_TOOL/PREW3_SHADOW｜Codex｜legacy=ON
- **原定位**：`BODY-09B:136`；真 Cell Id `CELL-56eaea595d3d`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L39，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；OS process runner，不要求Host skill loader。
- input→behavior→typed output：source-bound input→乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Codex/CLI_TOOL/PREW3_SHADOW/ON：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒無entrypoint或退出碼未記錄；若raw.host不等於Codex或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無OS process runner，不要求Host skill loader，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `56eaea595d3d` 的唯讀 Cell 產品設計候選。

### CELL-0dff6839fdf7｜CLI_TOOL/PREW3_SHADOW｜Codex｜legacy=OFF
- **原定位**：`BODY-09B:147`；真 Cell Id `CELL-0dff6839fdf7`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L40，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；OS process runner，不要求Host skill loader。
- input→behavior→typed output：source-bound input→乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Codex/CLI_TOOL/PREW3_SHADOW/OFF：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒無entrypoint或退出碼未記錄；若raw.host不等於Codex或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無OS process runner，不要求Host skill loader，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `0dff6839fdf7` 的唯讀 Cell 產品設計候選。

### CELL-1cf2ae4386cb｜CLI_TOOL/PREW3_SHADOW｜Claude Code｜legacy=ON
- **原定位**：`BODY-09B:158`；真 Cell Id `CELL-1cf2ae4386cb`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L41，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；OS process runner，不要求Host skill loader。
- input→behavior→typed output：source-bound input→乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Claude Code/CLI_TOOL/PREW3_SHADOW/ON：Claude Code當期原loader＋乾淨session驗乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒無entrypoint或退出碼未記錄；若raw.host不等於Claude Code或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無OS process runner，不要求Host skill loader，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `1cf2ae4386cb` 的唯讀 Cell 產品設計候選。

### CELL-b6b3031965fa｜CLI_TOOL/PREW3_SHADOW｜Claude Code｜legacy=OFF
- **原定位**：`BODY-09B:169`；真 Cell Id `CELL-b6b3031965fa`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L42，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；OS process runner，不要求Host skill loader。
- input→behavior→typed output：source-bound input→乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Claude Code/CLI_TOOL/PREW3_SHADOW/OFF：Claude Code當期原loader＋乾淨session驗乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒無entrypoint或退出碼未記錄；若raw.host不等於Claude Code或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無OS process runner，不要求Host skill loader，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `b6b3031965fa` 的唯讀 Cell 產品設計候選。

### CELL-e78d746c7bf7｜CLI_TOOL/PREW3_SHADOW｜DeepSeek Harness｜legacy=ON
- **原定位**：`BODY-09B:180`；真 Cell Id `CELL-e78d746c7bf7`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L43，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；OS process runner，不要求Host skill loader。
- input→behavior→typed output：source-bound input→乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：DeepSeek Harness/CLI_TOOL/PREW3_SHADOW/ON：實際Harness adapter/capability reader；API_ONLY不能充loader驗乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒無entrypoint或退出碼未記錄；若raw.host不等於DeepSeek Harness或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無OS process runner，不要求Host skill loader，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `e78d746c7bf7` 的唯讀 Cell 產品設計候選。

### CELL-fabd535f6b8d｜CLI_TOOL/PREW3_SHADOW｜DeepSeek Harness｜legacy=OFF
- **原定位**：`BODY-09B:191`；真 Cell Id `CELL-fabd535f6b8d`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L44，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；OS process runner，不要求Host skill loader。
- input→behavior→typed output：source-bound input→乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：DeepSeek Harness/CLI_TOOL/PREW3_SHADOW/OFF：實際Harness adapter/capability reader；API_ONLY不能充loader驗乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒無entrypoint或退出碼未記錄；若raw.host不等於DeepSeek Harness或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無OS process runner，不要求Host skill loader，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `fabd535f6b8d` 的唯讀 Cell 產品設計候選。

### CELL-68f927602c56｜CLI_TOOL/SWOF_CONNECTED｜Hermes Agent｜legacy=ON
- **原定位**：`BODY-09B:202`；真 Cell Id `CELL-68f927602c56`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L45，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；OS process runner，不要求Host skill loader。
- input→behavior→typed output：source-bound input→乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Hermes Agent/CLI_TOOL/SWOF_CONNECTED/ON：原Hermes tool/skill loader與worker fresh PID驗乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒無entrypoint或退出碼未記錄；若raw.host不等於Hermes Agent或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無OS process runner，不要求Host skill loader，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `68f927602c56` 的唯讀 Cell 產品設計候選。

### CELL-09a9c6d13bb7｜CLI_TOOL/SWOF_CONNECTED｜Hermes Agent｜legacy=OFF
- **原定位**：`BODY-09B:213`；真 Cell Id `CELL-09a9c6d13bb7`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L46，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；OS process runner，不要求Host skill loader。
- input→behavior→typed output：source-bound input→乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Hermes Agent/CLI_TOOL/SWOF_CONNECTED/OFF：原Hermes tool/skill loader與worker fresh PID驗乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒無entrypoint或退出碼未記錄；若raw.host不等於Hermes Agent或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無OS process runner，不要求Host skill loader，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `09a9c6d13bb7` 的唯讀 Cell 產品設計候選。

### CELL-62767ea0b8e8｜CLI_TOOL/SWOF_CONNECTED｜Codex｜legacy=ON
- **原定位**：`BODY-09B:224`；真 Cell Id `CELL-62767ea0b8e8`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L47，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；OS process runner，不要求Host skill loader。
- input→behavior→typed output：source-bound input→乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Codex/CLI_TOOL/SWOF_CONNECTED/ON：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒無entrypoint或退出碼未記錄；若raw.host不等於Codex或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無OS process runner，不要求Host skill loader，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `62767ea0b8e8` 的唯讀 Cell 產品設計候選。

### CELL-739b3b5375fc｜CLI_TOOL/SWOF_CONNECTED｜Codex｜legacy=OFF
- **原定位**：`BODY-09B:235`；真 Cell Id `CELL-739b3b5375fc`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L48，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；OS process runner，不要求Host skill loader。
- input→behavior→typed output：source-bound input→乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Codex/CLI_TOOL/SWOF_CONNECTED/OFF：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒無entrypoint或退出碼未記錄；若raw.host不等於Codex或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無OS process runner，不要求Host skill loader，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `739b3b5375fc` 的唯讀 Cell 產品設計候選。

### CELL-944d6c462137｜CLI_TOOL/SWOF_CONNECTED｜Claude Code｜legacy=ON
- **原定位**：`BODY-09B:246`；真 Cell Id `CELL-944d6c462137`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L49，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；OS process runner，不要求Host skill loader。
- input→behavior→typed output：source-bound input→乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Claude Code/CLI_TOOL/SWOF_CONNECTED/ON：Claude Code當期原loader＋乾淨session驗乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒無entrypoint或退出碼未記錄；若raw.host不等於Claude Code或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無OS process runner，不要求Host skill loader，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `944d6c462137` 的唯讀 Cell 產品設計候選。

### CELL-1444ab821832｜CLI_TOOL/SWOF_CONNECTED｜Claude Code｜legacy=OFF
- **原定位**：`BODY-09B:257`；真 Cell Id `CELL-1444ab821832`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L50，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；OS process runner，不要求Host skill loader。
- input→behavior→typed output：source-bound input→乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Claude Code/CLI_TOOL/SWOF_CONNECTED/OFF：Claude Code當期原loader＋乾淨session驗乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒無entrypoint或退出碼未記錄；若raw.host不等於Claude Code或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無OS process runner，不要求Host skill loader，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `1444ab821832` 的唯讀 Cell 產品設計候選。

### CELL-f5c5147c11c1｜CLI_TOOL/SWOF_CONNECTED｜DeepSeek Harness｜legacy=ON
- **原定位**：`BODY-09B:268`；真 Cell Id `CELL-f5c5147c11c1`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L51，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；OS process runner，不要求Host skill loader。
- input→behavior→typed output：source-bound input→乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：DeepSeek Harness/CLI_TOOL/SWOF_CONNECTED/ON：實際Harness adapter/capability reader；API_ONLY不能充loader驗乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒無entrypoint或退出碼未記錄；若raw.host不等於DeepSeek Harness或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無OS process runner，不要求Host skill loader，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `f5c5147c11c1` 的唯讀 Cell 產品設計候選。

### CELL-5bd80e6cf274｜CLI_TOOL/SWOF_CONNECTED｜DeepSeek Harness｜legacy=OFF
- **原定位**：`BODY-09B:279`；真 Cell Id `CELL-5bd80e6cf274`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L52，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；OS process runner，不要求Host skill loader。
- input→behavior→typed output：source-bound input→乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：DeepSeek Harness/CLI_TOOL/SWOF_CONNECTED/OFF：實際Harness adapter/capability reader；API_ONLY不能充loader驗乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒無entrypoint或退出碼未記錄；若raw.host不等於DeepSeek Harness或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無OS process runner，不要求Host skill loader，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `5bd80e6cf274` 的唯讀 Cell 產品設計候選。

### CELL-b368d7497e83｜AGENT_SKILL/STANDALONE｜Hermes Agent｜legacy=ON
- **原定位**：`BODY-09B:290`；真 Cell Id `CELL-b368d7497e83`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L53，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；實際skill loader；API_ONLY無loader為NOFIT。
- input→behavior→typed output：source-bound input→SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Hermes Agent/AGENT_SKILL/STANDALONE/ON：原Hermes tool/skill loader與worker fresh PID驗SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒copy-only或錯誤trigger；若raw.host不等於Hermes Agent或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無實際skill loader；API_ONLY無loader為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `b368d7497e83` 的唯讀 Cell 產品設計候選。

### CELL-a488c020ca0b｜AGENT_SKILL/STANDALONE｜Hermes Agent｜legacy=OFF
- **原定位**：`BODY-09B:301`；真 Cell Id `CELL-a488c020ca0b`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L54，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；實際skill loader；API_ONLY無loader為NOFIT。
- input→behavior→typed output：source-bound input→SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Hermes Agent/AGENT_SKILL/STANDALONE/OFF：原Hermes tool/skill loader與worker fresh PID驗SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒copy-only或錯誤trigger；若raw.host不等於Hermes Agent或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無實際skill loader；API_ONLY無loader為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `a488c020ca0b` 的唯讀 Cell 產品設計候選。

### CELL-cab792bba33a｜AGENT_SKILL/STANDALONE｜Codex｜legacy=ON
- **原定位**：`BODY-09B:312`；真 Cell Id `CELL-cab792bba33a`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L55，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；實際skill loader；API_ONLY無loader為NOFIT。
- input→behavior→typed output：source-bound input→SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Codex/AGENT_SKILL/STANDALONE/ON：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒copy-only或錯誤trigger；若raw.host不等於Codex或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無實際skill loader；API_ONLY無loader為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `cab792bba33a` 的唯讀 Cell 產品設計候選。

### CELL-220de7b8b1e7｜AGENT_SKILL/STANDALONE｜Codex｜legacy=OFF
- **原定位**：`BODY-09B:323`；真 Cell Id `CELL-220de7b8b1e7`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L56，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；實際skill loader；API_ONLY無loader為NOFIT。
- input→behavior→typed output：source-bound input→SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Codex/AGENT_SKILL/STANDALONE/OFF：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒copy-only或錯誤trigger；若raw.host不等於Codex或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無實際skill loader；API_ONLY無loader為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `220de7b8b1e7` 的唯讀 Cell 產品設計候選。

### CELL-e05964530c47｜AGENT_SKILL/STANDALONE｜Claude Code｜legacy=ON
- **原定位**：`BODY-09B:334`；真 Cell Id `CELL-e05964530c47`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L57，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；實際skill loader；API_ONLY無loader為NOFIT。
- input→behavior→typed output：source-bound input→SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Claude Code/AGENT_SKILL/STANDALONE/ON：Claude Code當期原loader＋乾淨session驗SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒copy-only或錯誤trigger；若raw.host不等於Claude Code或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無實際skill loader；API_ONLY無loader為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `e05964530c47` 的唯讀 Cell 產品設計候選。

### CELL-ea5d66500738｜AGENT_SKILL/STANDALONE｜Claude Code｜legacy=OFF
- **原定位**：`BODY-09B:345`；真 Cell Id `CELL-ea5d66500738`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L58，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；實際skill loader；API_ONLY無loader為NOFIT。
- input→behavior→typed output：source-bound input→SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Claude Code/AGENT_SKILL/STANDALONE/OFF：Claude Code當期原loader＋乾淨session驗SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒copy-only或錯誤trigger；若raw.host不等於Claude Code或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無實際skill loader；API_ONLY無loader為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `ea5d66500738` 的唯讀 Cell 產品設計候選。

### CELL-cb678bd208a8｜AGENT_SKILL/STANDALONE｜DeepSeek Harness｜legacy=ON
- **原定位**：`BODY-09B:356`；真 Cell Id `CELL-cb678bd208a8`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L59，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；實際skill loader；API_ONLY無loader為NOFIT。
- input→behavior→typed output：source-bound input→SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：DeepSeek Harness/AGENT_SKILL/STANDALONE/ON：實際Harness adapter/capability reader；API_ONLY不能充loader驗SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒copy-only或錯誤trigger；若raw.host不等於DeepSeek Harness或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無實際skill loader；API_ONLY無loader為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `cb678bd208a8` 的唯讀 Cell 產品設計候選。

### CELL-6e1c0fb8d36b｜AGENT_SKILL/STANDALONE｜DeepSeek Harness｜legacy=OFF
- **原定位**：`BODY-09B:367`；真 Cell Id `CELL-6e1c0fb8d36b`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L60，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；實際skill loader；API_ONLY無loader為NOFIT。
- input→behavior→typed output：source-bound input→SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：DeepSeek Harness/AGENT_SKILL/STANDALONE/OFF：實際Harness adapter/capability reader；API_ONLY不能充loader驗SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒copy-only或錯誤trigger；若raw.host不等於DeepSeek Harness或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無實際skill loader；API_ONLY無loader為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `6e1c0fb8d36b` 的唯讀 Cell 產品設計候選。

### CELL-dd676737681e｜AGENT_SKILL/PREW3_SHADOW｜Hermes Agent｜legacy=ON
- **原定位**：`BODY-09B:378`；真 Cell Id `CELL-dd676737681e`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L61，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；實際skill loader；API_ONLY無loader為NOFIT。
- input→behavior→typed output：source-bound input→SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Hermes Agent/AGENT_SKILL/PREW3_SHADOW/ON：原Hermes tool/skill loader與worker fresh PID驗SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒copy-only或錯誤trigger；若raw.host不等於Hermes Agent或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無實際skill loader；API_ONLY無loader為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `dd676737681e` 的唯讀 Cell 產品設計候選。

### CELL-6c0ad0177a48｜AGENT_SKILL/PREW3_SHADOW｜Hermes Agent｜legacy=OFF
- **原定位**：`BODY-09B:389`；真 Cell Id `CELL-6c0ad0177a48`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L62，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；實際skill loader；API_ONLY無loader為NOFIT。
- input→behavior→typed output：source-bound input→SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Hermes Agent/AGENT_SKILL/PREW3_SHADOW/OFF：原Hermes tool/skill loader與worker fresh PID驗SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒copy-only或錯誤trigger；若raw.host不等於Hermes Agent或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無實際skill loader；API_ONLY無loader為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `6c0ad0177a48` 的唯讀 Cell 產品設計候選。

### CELL-702455102b0e｜AGENT_SKILL/PREW3_SHADOW｜Codex｜legacy=ON
- **原定位**：`BODY-09B:400`；真 Cell Id `CELL-702455102b0e`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L63，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；實際skill loader；API_ONLY無loader為NOFIT。
- input→behavior→typed output：source-bound input→SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Codex/AGENT_SKILL/PREW3_SHADOW/ON：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒copy-only或錯誤trigger；若raw.host不等於Codex或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無實際skill loader；API_ONLY無loader為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `702455102b0e` 的唯讀 Cell 產品設計候選。

### CELL-d7b2369a3d11｜AGENT_SKILL/PREW3_SHADOW｜Codex｜legacy=OFF
- **原定位**：`BODY-09B:411`；真 Cell Id `CELL-d7b2369a3d11`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L64，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；實際skill loader；API_ONLY無loader為NOFIT。
- input→behavior→typed output：source-bound input→SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Codex/AGENT_SKILL/PREW3_SHADOW/OFF：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒copy-only或錯誤trigger；若raw.host不等於Codex或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無實際skill loader；API_ONLY無loader為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `d7b2369a3d11` 的唯讀 Cell 產品設計候選。

### CELL-3b2af66f8936｜AGENT_SKILL/PREW3_SHADOW｜Claude Code｜legacy=ON
- **原定位**：`BODY-09B:422`；真 Cell Id `CELL-3b2af66f8936`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L65，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；實際skill loader；API_ONLY無loader為NOFIT。
- input→behavior→typed output：source-bound input→SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Claude Code/AGENT_SKILL/PREW3_SHADOW/ON：Claude Code當期原loader＋乾淨session驗SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒copy-only或錯誤trigger；若raw.host不等於Claude Code或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無實際skill loader；API_ONLY無loader為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `3b2af66f8936` 的唯讀 Cell 產品設計候選。

### CELL-46f0028dabe2｜AGENT_SKILL/PREW3_SHADOW｜Claude Code｜legacy=OFF
- **原定位**：`BODY-09B:433`；真 Cell Id `CELL-46f0028dabe2`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L66，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；實際skill loader；API_ONLY無loader為NOFIT。
- input→behavior→typed output：source-bound input→SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Claude Code/AGENT_SKILL/PREW3_SHADOW/OFF：Claude Code當期原loader＋乾淨session驗SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒copy-only或錯誤trigger；若raw.host不等於Claude Code或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無實際skill loader；API_ONLY無loader為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `46f0028dabe2` 的唯讀 Cell 產品設計候選。

### CELL-ae3081300a06｜AGENT_SKILL/PREW3_SHADOW｜DeepSeek Harness｜legacy=ON
- **原定位**：`BODY-09B:444`；真 Cell Id `CELL-ae3081300a06`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L67，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；實際skill loader；API_ONLY無loader為NOFIT。
- input→behavior→typed output：source-bound input→SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：DeepSeek Harness/AGENT_SKILL/PREW3_SHADOW/ON：實際Harness adapter/capability reader；API_ONLY不能充loader驗SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒copy-only或錯誤trigger；若raw.host不等於DeepSeek Harness或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無實際skill loader；API_ONLY無loader為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `ae3081300a06` 的唯讀 Cell 產品設計候選。

### CELL-79aa1ca6c95f｜AGENT_SKILL/PREW3_SHADOW｜DeepSeek Harness｜legacy=OFF
- **原定位**：`BODY-09B:455`；真 Cell Id `CELL-79aa1ca6c95f`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L68，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；實際skill loader；API_ONLY無loader為NOFIT。
- input→behavior→typed output：source-bound input→SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：DeepSeek Harness/AGENT_SKILL/PREW3_SHADOW/OFF：實際Harness adapter/capability reader；API_ONLY不能充loader驗SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒copy-only或錯誤trigger；若raw.host不等於DeepSeek Harness或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無實際skill loader；API_ONLY無loader為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `79aa1ca6c95f` 的唯讀 Cell 產品設計候選。

### CELL-706d7dabb0a0｜AGENT_SKILL/SWOF_CONNECTED｜Hermes Agent｜legacy=ON
- **原定位**：`BODY-09B:466`；真 Cell Id `CELL-706d7dabb0a0`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L69，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；實際skill loader；API_ONLY無loader為NOFIT。
- input→behavior→typed output：source-bound input→SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Hermes Agent/AGENT_SKILL/SWOF_CONNECTED/ON：原Hermes tool/skill loader與worker fresh PID驗SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒copy-only或錯誤trigger；若raw.host不等於Hermes Agent或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無實際skill loader；API_ONLY無loader為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `706d7dabb0a0` 的唯讀 Cell 產品設計候選。

### CELL-aab24b0f82f9｜AGENT_SKILL/SWOF_CONNECTED｜Hermes Agent｜legacy=OFF
- **原定位**：`BODY-09B:477`；真 Cell Id `CELL-aab24b0f82f9`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L70，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；實際skill loader；API_ONLY無loader為NOFIT。
- input→behavior→typed output：source-bound input→SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Hermes Agent/AGENT_SKILL/SWOF_CONNECTED/OFF：原Hermes tool/skill loader與worker fresh PID驗SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒copy-only或錯誤trigger；若raw.host不等於Hermes Agent或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無實際skill loader；API_ONLY無loader為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `aab24b0f82f9` 的唯讀 Cell 產品設計候選。

### CELL-75634c7787b2｜AGENT_SKILL/SWOF_CONNECTED｜Codex｜legacy=ON
- **原定位**：`BODY-09B:488`；真 Cell Id `CELL-75634c7787b2`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L71，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；實際skill loader；API_ONLY無loader為NOFIT。
- input→behavior→typed output：source-bound input→SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Codex/AGENT_SKILL/SWOF_CONNECTED/ON：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒copy-only或錯誤trigger；若raw.host不等於Codex或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無實際skill loader；API_ONLY無loader為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `75634c7787b2` 的唯讀 Cell 產品設計候選。

### CELL-e341b6d0f605｜AGENT_SKILL/SWOF_CONNECTED｜Codex｜legacy=OFF
- **原定位**：`BODY-09B:499`；真 Cell Id `CELL-e341b6d0f605`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L72，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；實際skill loader；API_ONLY無loader為NOFIT。
- input→behavior→typed output：source-bound input→SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Codex/AGENT_SKILL/SWOF_CONNECTED/OFF：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒copy-only或錯誤trigger；若raw.host不等於Codex或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無實際skill loader；API_ONLY無loader為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `e341b6d0f605` 的唯讀 Cell 產品設計候選。

### CELL-e9941d45073f｜AGENT_SKILL/SWOF_CONNECTED｜Claude Code｜legacy=ON
- **原定位**：`BODY-09B:510`；真 Cell Id `CELL-e9941d45073f`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L73，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；實際skill loader；API_ONLY無loader為NOFIT。
- input→behavior→typed output：source-bound input→SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Claude Code/AGENT_SKILL/SWOF_CONNECTED/ON：Claude Code當期原loader＋乾淨session驗SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒copy-only或錯誤trigger；若raw.host不等於Claude Code或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無實際skill loader；API_ONLY無loader為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `e9941d45073f` 的唯讀 Cell 產品設計候選。

### CELL-e51ce0738940｜AGENT_SKILL/SWOF_CONNECTED｜Claude Code｜legacy=OFF
- **原定位**：`BODY-09B:521`；真 Cell Id `CELL-e51ce0738940`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L74，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；實際skill loader；API_ONLY無loader為NOFIT。
- input→behavior→typed output：source-bound input→SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Claude Code/AGENT_SKILL/SWOF_CONNECTED/OFF：Claude Code當期原loader＋乾淨session驗SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒copy-only或錯誤trigger；若raw.host不等於Claude Code或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無實際skill loader；API_ONLY無loader為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `e51ce0738940` 的唯讀 Cell 產品設計候選。

### CELL-48757186c510｜AGENT_SKILL/SWOF_CONNECTED｜DeepSeek Harness｜legacy=ON
- **原定位**：`BODY-09B:532`；真 Cell Id `CELL-48757186c510`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L75，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；實際skill loader；API_ONLY無loader為NOFIT。
- input→behavior→typed output：source-bound input→SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：DeepSeek Harness/AGENT_SKILL/SWOF_CONNECTED/ON：實際Harness adapter/capability reader；API_ONLY不能充loader驗SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒copy-only或錯誤trigger；若raw.host不等於DeepSeek Harness或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無實際skill loader；API_ONLY無loader為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `48757186c510` 的唯讀 Cell 產品設計候選。

### CELL-9df05458d74f｜AGENT_SKILL/SWOF_CONNECTED｜DeepSeek Harness｜legacy=OFF
- **原定位**：`BODY-09B:543`；真 Cell Id `CELL-9df05458d74f`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L76，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；實際skill loader；API_ONLY無loader為NOFIT。
- input→behavior→typed output：source-bound input→SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：DeepSeek Harness/AGENT_SKILL/SWOF_CONNECTED/OFF：實際Harness adapter/capability reader；API_ONLY不能充loader驗SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒copy-only或錯誤trigger；若raw.host不等於DeepSeek Harness或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無實際skill loader；API_ONLY無loader為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `9df05458d74f` 的唯讀 Cell 產品設計候選。

### CELL-52b5e63d094d｜SIMPLE_AGENT/STANDALONE｜Hermes Agent｜legacy=ON
- **原定位**：`BODY-09B:554`；真 Cell Id `CELL-52b5e63d094d`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L77，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；原Host tool-call runner；無tool capability為NOFIT。
- input→behavior→typed output：source-bound input→agent config+tool allowlist+timeout/attempt budget+stop checkpoint→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Hermes Agent/SIMPLE_AGENT/STANDALONE/ON：原Hermes tool/skill loader與worker fresh PID驗agent config+tool allowlist+timeout/attempt budget+stop checkpoint；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒無限loop或工具擴權；若raw.host不等於Hermes Agent或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無原Host tool-call runner；無tool capability為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `52b5e63d094d` 的唯讀 Cell 產品設計候選。

### CELL-1c821c1ea7d8｜SIMPLE_AGENT/STANDALONE｜Hermes Agent｜legacy=OFF
- **原定位**：`BODY-09B:565`；真 Cell Id `CELL-1c821c1ea7d8`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L78，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；原Host tool-call runner；無tool capability為NOFIT。
- input→behavior→typed output：source-bound input→agent config+tool allowlist+timeout/attempt budget+stop checkpoint→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Hermes Agent/SIMPLE_AGENT/STANDALONE/OFF：原Hermes tool/skill loader與worker fresh PID驗agent config+tool allowlist+timeout/attempt budget+stop checkpoint；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒無限loop或工具擴權；若raw.host不等於Hermes Agent或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無原Host tool-call runner；無tool capability為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `1c821c1ea7d8` 的唯讀 Cell 產品設計候選。

### CELL-3a2a9dad37ae｜SIMPLE_AGENT/STANDALONE｜Codex｜legacy=ON
- **原定位**：`BODY-09B:576`；真 Cell Id `CELL-3a2a9dad37ae`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L79，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；原Host tool-call runner；無tool capability為NOFIT。
- input→behavior→typed output：source-bound input→agent config+tool allowlist+timeout/attempt budget+stop checkpoint→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Codex/SIMPLE_AGENT/STANDALONE/ON：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗agent config+tool allowlist+timeout/attempt budget+stop checkpoint；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒無限loop或工具擴權；若raw.host不等於Codex或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無原Host tool-call runner；無tool capability為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `3a2a9dad37ae` 的唯讀 Cell 產品設計候選。

### CELL-87b5a1fe58cf｜SIMPLE_AGENT/STANDALONE｜Codex｜legacy=OFF
- **原定位**：`BODY-09B:587`；真 Cell Id `CELL-87b5a1fe58cf`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L80，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；原Host tool-call runner；無tool capability為NOFIT。
- input→behavior→typed output：source-bound input→agent config+tool allowlist+timeout/attempt budget+stop checkpoint→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Codex/SIMPLE_AGENT/STANDALONE/OFF：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗agent config+tool allowlist+timeout/attempt budget+stop checkpoint；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒無限loop或工具擴權；若raw.host不等於Codex或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無原Host tool-call runner；無tool capability為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `87b5a1fe58cf` 的唯讀 Cell 產品設計候選。

### CELL-9e24d28c894c｜SIMPLE_AGENT/STANDALONE｜Claude Code｜legacy=ON
- **原定位**：`BODY-09B:598`；真 Cell Id `CELL-9e24d28c894c`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L81，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；原Host tool-call runner；無tool capability為NOFIT。
- input→behavior→typed output：source-bound input→agent config+tool allowlist+timeout/attempt budget+stop checkpoint→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Claude Code/SIMPLE_AGENT/STANDALONE/ON：Claude Code當期原loader＋乾淨session驗agent config+tool allowlist+timeout/attempt budget+stop checkpoint；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒無限loop或工具擴權；若raw.host不等於Claude Code或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無原Host tool-call runner；無tool capability為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `9e24d28c894c` 的唯讀 Cell 產品設計候選。

### CELL-94a990f58257｜SIMPLE_AGENT/STANDALONE｜Claude Code｜legacy=OFF
- **原定位**：`BODY-09B:609`；真 Cell Id `CELL-94a990f58257`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L82，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；原Host tool-call runner；無tool capability為NOFIT。
- input→behavior→typed output：source-bound input→agent config+tool allowlist+timeout/attempt budget+stop checkpoint→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Claude Code/SIMPLE_AGENT/STANDALONE/OFF：Claude Code當期原loader＋乾淨session驗agent config+tool allowlist+timeout/attempt budget+stop checkpoint；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒無限loop或工具擴權；若raw.host不等於Claude Code或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無原Host tool-call runner；無tool capability為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `94a990f58257` 的唯讀 Cell 產品設計候選。

### CELL-f0a4964020d6｜SIMPLE_AGENT/STANDALONE｜DeepSeek Harness｜legacy=ON
- **原定位**：`BODY-09B:620`；真 Cell Id `CELL-f0a4964020d6`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L83，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；原Host tool-call runner；無tool capability為NOFIT。
- input→behavior→typed output：source-bound input→agent config+tool allowlist+timeout/attempt budget+stop checkpoint→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：DeepSeek Harness/SIMPLE_AGENT/STANDALONE/ON：實際Harness adapter/capability reader；API_ONLY不能充loader驗agent config+tool allowlist+timeout/attempt budget+stop checkpoint；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒無限loop或工具擴權；若raw.host不等於DeepSeek Harness或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無原Host tool-call runner；無tool capability為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `f0a4964020d6` 的唯讀 Cell 產品設計候選。

### CELL-8ba7cd2138c5｜SIMPLE_AGENT/STANDALONE｜DeepSeek Harness｜legacy=OFF
- **原定位**：`BODY-09B:631`；真 Cell Id `CELL-8ba7cd2138c5`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L84，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；原Host tool-call runner；無tool capability為NOFIT。
- input→behavior→typed output：source-bound input→agent config+tool allowlist+timeout/attempt budget+stop checkpoint→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：DeepSeek Harness/SIMPLE_AGENT/STANDALONE/OFF：實際Harness adapter/capability reader；API_ONLY不能充loader驗agent config+tool allowlist+timeout/attempt budget+stop checkpoint；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒無限loop或工具擴權；若raw.host不等於DeepSeek Harness或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無原Host tool-call runner；無tool capability為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `8ba7cd2138c5` 的唯讀 Cell 產品設計候選。

### CELL-e704b0923b71｜SIMPLE_AGENT/PREW3_SHADOW｜Hermes Agent｜legacy=ON
- **原定位**：`BODY-09B:642`；真 Cell Id `CELL-e704b0923b71`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L85，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；原Host tool-call runner；無tool capability為NOFIT。
- input→behavior→typed output：source-bound input→agent config+tool allowlist+timeout/attempt budget+stop checkpoint→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Hermes Agent/SIMPLE_AGENT/PREW3_SHADOW/ON：原Hermes tool/skill loader與worker fresh PID驗agent config+tool allowlist+timeout/attempt budget+stop checkpoint；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒無限loop或工具擴權；若raw.host不等於Hermes Agent或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無原Host tool-call runner；無tool capability為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `e704b0923b71` 的唯讀 Cell 產品設計候選。

### CELL-834018317c72｜SIMPLE_AGENT/PREW3_SHADOW｜Hermes Agent｜legacy=OFF
- **原定位**：`BODY-09B:653`；真 Cell Id `CELL-834018317c72`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L86，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；原Host tool-call runner；無tool capability為NOFIT。
- input→behavior→typed output：source-bound input→agent config+tool allowlist+timeout/attempt budget+stop checkpoint→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Hermes Agent/SIMPLE_AGENT/PREW3_SHADOW/OFF：原Hermes tool/skill loader與worker fresh PID驗agent config+tool allowlist+timeout/attempt budget+stop checkpoint；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒無限loop或工具擴權；若raw.host不等於Hermes Agent或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無原Host tool-call runner；無tool capability為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `834018317c72` 的唯讀 Cell 產品設計候選。

### CELL-a433df5357ac｜SIMPLE_AGENT/PREW3_SHADOW｜Codex｜legacy=ON
- **原定位**：`BODY-09B:664`；真 Cell Id `CELL-a433df5357ac`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L87，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；原Host tool-call runner；無tool capability為NOFIT。
- input→behavior→typed output：source-bound input→agent config+tool allowlist+timeout/attempt budget+stop checkpoint→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Codex/SIMPLE_AGENT/PREW3_SHADOW/ON：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗agent config+tool allowlist+timeout/attempt budget+stop checkpoint；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒無限loop或工具擴權；若raw.host不等於Codex或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無原Host tool-call runner；無tool capability為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `a433df5357ac` 的唯讀 Cell 產品設計候選。

### CELL-d92746482fe6｜SIMPLE_AGENT/PREW3_SHADOW｜Codex｜legacy=OFF
- **原定位**：`BODY-09B:675`；真 Cell Id `CELL-d92746482fe6`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L88，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；原Host tool-call runner；無tool capability為NOFIT。
- input→behavior→typed output：source-bound input→agent config+tool allowlist+timeout/attempt budget+stop checkpoint→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Codex/SIMPLE_AGENT/PREW3_SHADOW/OFF：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗agent config+tool allowlist+timeout/attempt budget+stop checkpoint；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒無限loop或工具擴權；若raw.host不等於Codex或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無原Host tool-call runner；無tool capability為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `d92746482fe6` 的唯讀 Cell 產品設計候選。

### CELL-3083c98d4210｜SIMPLE_AGENT/PREW3_SHADOW｜Claude Code｜legacy=ON
- **原定位**：`BODY-09B:686`；真 Cell Id `CELL-3083c98d4210`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L89，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；原Host tool-call runner；無tool capability為NOFIT。
- input→behavior→typed output：source-bound input→agent config+tool allowlist+timeout/attempt budget+stop checkpoint→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Claude Code/SIMPLE_AGENT/PREW3_SHADOW/ON：Claude Code當期原loader＋乾淨session驗agent config+tool allowlist+timeout/attempt budget+stop checkpoint；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒無限loop或工具擴權；若raw.host不等於Claude Code或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無原Host tool-call runner；無tool capability為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `3083c98d4210` 的唯讀 Cell 產品設計候選。

### CELL-97174a3d45e8｜SIMPLE_AGENT/PREW3_SHADOW｜Claude Code｜legacy=OFF
- **原定位**：`BODY-09B:697`；真 Cell Id `CELL-97174a3d45e8`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L90，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；原Host tool-call runner；無tool capability為NOFIT。
- input→behavior→typed output：source-bound input→agent config+tool allowlist+timeout/attempt budget+stop checkpoint→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Claude Code/SIMPLE_AGENT/PREW3_SHADOW/OFF：Claude Code當期原loader＋乾淨session驗agent config+tool allowlist+timeout/attempt budget+stop checkpoint；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒無限loop或工具擴權；若raw.host不等於Claude Code或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無原Host tool-call runner；無tool capability為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `97174a3d45e8` 的唯讀 Cell 產品設計候選。

### CELL-84fa01909649｜SIMPLE_AGENT/PREW3_SHADOW｜DeepSeek Harness｜legacy=ON
- **原定位**：`BODY-09B:708`；真 Cell Id `CELL-84fa01909649`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L91，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；原Host tool-call runner；無tool capability為NOFIT。
- input→behavior→typed output：source-bound input→agent config+tool allowlist+timeout/attempt budget+stop checkpoint→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：DeepSeek Harness/SIMPLE_AGENT/PREW3_SHADOW/ON：實際Harness adapter/capability reader；API_ONLY不能充loader驗agent config+tool allowlist+timeout/attempt budget+stop checkpoint；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒無限loop或工具擴權；若raw.host不等於DeepSeek Harness或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無原Host tool-call runner；無tool capability為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `84fa01909649` 的唯讀 Cell 產品設計候選。

### CELL-f77b24e32aaa｜SIMPLE_AGENT/PREW3_SHADOW｜DeepSeek Harness｜legacy=OFF
- **原定位**：`BODY-09B:719`；真 Cell Id `CELL-f77b24e32aaa`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L92，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；原Host tool-call runner；無tool capability為NOFIT。
- input→behavior→typed output：source-bound input→agent config+tool allowlist+timeout/attempt budget+stop checkpoint→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：DeepSeek Harness/SIMPLE_AGENT/PREW3_SHADOW/OFF：實際Harness adapter/capability reader；API_ONLY不能充loader驗agent config+tool allowlist+timeout/attempt budget+stop checkpoint；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒無限loop或工具擴權；若raw.host不等於DeepSeek Harness或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無原Host tool-call runner；無tool capability為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `f77b24e32aaa` 的唯讀 Cell 產品設計候選。

### CELL-c1788f1272d7｜SIMPLE_AGENT/SWOF_CONNECTED｜Hermes Agent｜legacy=ON
- **原定位**：`BODY-09B:730`；真 Cell Id `CELL-c1788f1272d7`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L93，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；原Host tool-call runner；無tool capability為NOFIT。
- input→behavior→typed output：source-bound input→agent config+tool allowlist+timeout/attempt budget+stop checkpoint→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Hermes Agent/SIMPLE_AGENT/SWOF_CONNECTED/ON：原Hermes tool/skill loader與worker fresh PID驗agent config+tool allowlist+timeout/attempt budget+stop checkpoint；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒無限loop或工具擴權；若raw.host不等於Hermes Agent或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無原Host tool-call runner；無tool capability為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `c1788f1272d7` 的唯讀 Cell 產品設計候選。

### CELL-2a6bfd344f3f｜SIMPLE_AGENT/SWOF_CONNECTED｜Hermes Agent｜legacy=OFF
- **原定位**：`BODY-09B:741`；真 Cell Id `CELL-2a6bfd344f3f`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L94，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；原Host tool-call runner；無tool capability為NOFIT。
- input→behavior→typed output：source-bound input→agent config+tool allowlist+timeout/attempt budget+stop checkpoint→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Hermes Agent/SIMPLE_AGENT/SWOF_CONNECTED/OFF：原Hermes tool/skill loader與worker fresh PID驗agent config+tool allowlist+timeout/attempt budget+stop checkpoint；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒無限loop或工具擴權；若raw.host不等於Hermes Agent或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無原Host tool-call runner；無tool capability為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `2a6bfd344f3f` 的唯讀 Cell 產品設計候選。

### CELL-e2daf2609c40｜SIMPLE_AGENT/SWOF_CONNECTED｜Codex｜legacy=ON
- **原定位**：`BODY-09B:752`；真 Cell Id `CELL-e2daf2609c40`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L95，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；原Host tool-call runner；無tool capability為NOFIT。
- input→behavior→typed output：source-bound input→agent config+tool allowlist+timeout/attempt budget+stop checkpoint→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Codex/SIMPLE_AGENT/SWOF_CONNECTED/ON：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗agent config+tool allowlist+timeout/attempt budget+stop checkpoint；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒無限loop或工具擴權；若raw.host不等於Codex或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無原Host tool-call runner；無tool capability為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `e2daf2609c40` 的唯讀 Cell 產品設計候選。

### CELL-d880b5ac23a4｜SIMPLE_AGENT/SWOF_CONNECTED｜Codex｜legacy=OFF
- **原定位**：`BODY-09B:763`；真 Cell Id `CELL-d880b5ac23a4`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L96，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；原Host tool-call runner；無tool capability為NOFIT。
- input→behavior→typed output：source-bound input→agent config+tool allowlist+timeout/attempt budget+stop checkpoint→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Codex/SIMPLE_AGENT/SWOF_CONNECTED/OFF：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗agent config+tool allowlist+timeout/attempt budget+stop checkpoint；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒無限loop或工具擴權；若raw.host不等於Codex或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無原Host tool-call runner；無tool capability為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `d880b5ac23a4` 的唯讀 Cell 產品設計候選。

### CELL-ef6dac107879｜SIMPLE_AGENT/SWOF_CONNECTED｜Claude Code｜legacy=ON
- **原定位**：`BODY-09B:774`；真 Cell Id `CELL-ef6dac107879`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L97，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；原Host tool-call runner；無tool capability為NOFIT。
- input→behavior→typed output：source-bound input→agent config+tool allowlist+timeout/attempt budget+stop checkpoint→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Claude Code/SIMPLE_AGENT/SWOF_CONNECTED/ON：Claude Code當期原loader＋乾淨session驗agent config+tool allowlist+timeout/attempt budget+stop checkpoint；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒無限loop或工具擴權；若raw.host不等於Claude Code或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無原Host tool-call runner；無tool capability為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `ef6dac107879` 的唯讀 Cell 產品設計候選。

### CELL-c1ae4375bd05｜SIMPLE_AGENT/SWOF_CONNECTED｜Claude Code｜legacy=OFF
- **原定位**：`BODY-09B:785`；真 Cell Id `CELL-c1ae4375bd05`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L98，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；原Host tool-call runner；無tool capability為NOFIT。
- input→behavior→typed output：source-bound input→agent config+tool allowlist+timeout/attempt budget+stop checkpoint→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Claude Code/SIMPLE_AGENT/SWOF_CONNECTED/OFF：Claude Code當期原loader＋乾淨session驗agent config+tool allowlist+timeout/attempt budget+stop checkpoint；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒無限loop或工具擴權；若raw.host不等於Claude Code或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無原Host tool-call runner；無tool capability為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `c1ae4375bd05` 的唯讀 Cell 產品設計候選。

### CELL-09c21bb6612b｜SIMPLE_AGENT/SWOF_CONNECTED｜DeepSeek Harness｜legacy=ON
- **原定位**：`BODY-09B:796`；真 Cell Id `CELL-09c21bb6612b`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L99，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；原Host tool-call runner；無tool capability為NOFIT。
- input→behavior→typed output：source-bound input→agent config+tool allowlist+timeout/attempt budget+stop checkpoint→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：DeepSeek Harness/SIMPLE_AGENT/SWOF_CONNECTED/ON：實際Harness adapter/capability reader；API_ONLY不能充loader驗agent config+tool allowlist+timeout/attempt budget+stop checkpoint；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒無限loop或工具擴權；若raw.host不等於DeepSeek Harness或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無原Host tool-call runner；無tool capability為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `09c21bb6612b` 的唯讀 Cell 產品設計候選。

### CELL-9be3a648f57b｜SIMPLE_AGENT/SWOF_CONNECTED｜DeepSeek Harness｜legacy=OFF
- **原定位**：`BODY-09B:807`；真 Cell Id `CELL-9be3a648f57b`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L100，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；原Host tool-call runner；無tool capability為NOFIT。
- input→behavior→typed output：source-bound input→agent config+tool allowlist+timeout/attempt budget+stop checkpoint→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：DeepSeek Harness/SIMPLE_AGENT/SWOF_CONNECTED/OFF：實際Harness adapter/capability reader；API_ONLY不能充loader驗agent config+tool allowlist+timeout/attempt budget+stop checkpoint；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒無限loop或工具擴權；若raw.host不等於DeepSeek Harness或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無原Host tool-call runner；無tool capability為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `9be3a648f57b` 的唯讀 Cell 產品設計候選。

### CELL-90776ef8d07b｜PLUGIN/STANDALONE｜Hermes Agent｜legacy=ON
- **原定位**：`BODY-09B:818`；真 Cell Id `CELL-90776ef8d07b`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L101，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；原Host plugin loader；API_ONLY為NOFIT。
- input→behavior→typed output：source-bound input→manifest publisher/version/license/permissions；Host載入、調用及移除→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Hermes Agent/PLUGIN/STANDALONE/ON：原Hermes tool/skill loader與worker fresh PID驗manifest publisher/version/license/permissions；Host載入、調用及移除；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒不支援Host或未讀manifest權限；若raw.host不等於Hermes Agent或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無原Host plugin loader；API_ONLY為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `90776ef8d07b` 的唯讀 Cell 產品設計候選。

### CELL-f6718f8c8a9f｜PLUGIN/STANDALONE｜Hermes Agent｜legacy=OFF
- **原定位**：`BODY-09B:829`；真 Cell Id `CELL-f6718f8c8a9f`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L102，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；原Host plugin loader；API_ONLY為NOFIT。
- input→behavior→typed output：source-bound input→manifest publisher/version/license/permissions；Host載入、調用及移除→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Hermes Agent/PLUGIN/STANDALONE/OFF：原Hermes tool/skill loader與worker fresh PID驗manifest publisher/version/license/permissions；Host載入、調用及移除；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒不支援Host或未讀manifest權限；若raw.host不等於Hermes Agent或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無原Host plugin loader；API_ONLY為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `f6718f8c8a9f` 的唯讀 Cell 產品設計候選。

### CELL-b4c34ec88f14｜PLUGIN/STANDALONE｜Codex｜legacy=ON
- **原定位**：`BODY-09B:840`；真 Cell Id `CELL-b4c34ec88f14`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L103，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；原Host plugin loader；API_ONLY為NOFIT。
- input→behavior→typed output：source-bound input→manifest publisher/version/license/permissions；Host載入、調用及移除→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Codex/PLUGIN/STANDALONE/ON：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗manifest publisher/version/license/permissions；Host載入、調用及移除；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒不支援Host或未讀manifest權限；若raw.host不等於Codex或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無原Host plugin loader；API_ONLY為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `b4c34ec88f14` 的唯讀 Cell 產品設計候選。

### CELL-530a88ba777d｜PLUGIN/STANDALONE｜Codex｜legacy=OFF
- **原定位**：`BODY-09B:851`；真 Cell Id `CELL-530a88ba777d`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L104，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；原Host plugin loader；API_ONLY為NOFIT。
- input→behavior→typed output：source-bound input→manifest publisher/version/license/permissions；Host載入、調用及移除→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Codex/PLUGIN/STANDALONE/OFF：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗manifest publisher/version/license/permissions；Host載入、調用及移除；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒不支援Host或未讀manifest權限；若raw.host不等於Codex或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無原Host plugin loader；API_ONLY為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `530a88ba777d` 的唯讀 Cell 產品設計候選。

### CELL-1a9181fe48c5｜PLUGIN/STANDALONE｜Claude Code｜legacy=ON
- **原定位**：`BODY-09B:862`；真 Cell Id `CELL-1a9181fe48c5`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L105，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；原Host plugin loader；API_ONLY為NOFIT。
- input→behavior→typed output：source-bound input→manifest publisher/version/license/permissions；Host載入、調用及移除→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Claude Code/PLUGIN/STANDALONE/ON：Claude Code當期原loader＋乾淨session驗manifest publisher/version/license/permissions；Host載入、調用及移除；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒不支援Host或未讀manifest權限；若raw.host不等於Claude Code或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無原Host plugin loader；API_ONLY為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `1a9181fe48c5` 的唯讀 Cell 產品設計候選。

### CELL-5334bc0dc4e0｜PLUGIN/STANDALONE｜Claude Code｜legacy=OFF
- **原定位**：`BODY-09B:873`；真 Cell Id `CELL-5334bc0dc4e0`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L106，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；原Host plugin loader；API_ONLY為NOFIT。
- input→behavior→typed output：source-bound input→manifest publisher/version/license/permissions；Host載入、調用及移除→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Claude Code/PLUGIN/STANDALONE/OFF：Claude Code當期原loader＋乾淨session驗manifest publisher/version/license/permissions；Host載入、調用及移除；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒不支援Host或未讀manifest權限；若raw.host不等於Claude Code或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無原Host plugin loader；API_ONLY為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `5334bc0dc4e0` 的唯讀 Cell 產品設計候選。

### CELL-ecca30d3d545｜PLUGIN/STANDALONE｜DeepSeek Harness｜legacy=ON
- **原定位**：`BODY-09B:884`；真 Cell Id `CELL-ecca30d3d545`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L107，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；原Host plugin loader；API_ONLY為NOFIT。
- input→behavior→typed output：source-bound input→manifest publisher/version/license/permissions；Host載入、調用及移除→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：DeepSeek Harness/PLUGIN/STANDALONE/ON：實際Harness adapter/capability reader；API_ONLY不能充loader驗manifest publisher/version/license/permissions；Host載入、調用及移除；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒不支援Host或未讀manifest權限；若raw.host不等於DeepSeek Harness或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無原Host plugin loader；API_ONLY為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `ecca30d3d545` 的唯讀 Cell 產品設計候選。

### CELL-6acbaf567779｜PLUGIN/STANDALONE｜DeepSeek Harness｜legacy=OFF
- **原定位**：`BODY-09B:895`；真 Cell Id `CELL-6acbaf567779`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L108，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；原Host plugin loader；API_ONLY為NOFIT。
- input→behavior→typed output：source-bound input→manifest publisher/version/license/permissions；Host載入、調用及移除→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：DeepSeek Harness/PLUGIN/STANDALONE/OFF：實際Harness adapter/capability reader；API_ONLY不能充loader驗manifest publisher/version/license/permissions；Host載入、調用及移除；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒不支援Host或未讀manifest權限；若raw.host不等於DeepSeek Harness或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無原Host plugin loader；API_ONLY為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `6acbaf567779` 的唯讀 Cell 產品設計候選。

### CELL-f686d9f67c17｜PLUGIN/PREW3_SHADOW｜Hermes Agent｜legacy=ON
- **原定位**：`BODY-09B:906`；真 Cell Id `CELL-f686d9f67c17`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L109，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；原Host plugin loader；API_ONLY為NOFIT。
- input→behavior→typed output：source-bound input→manifest publisher/version/license/permissions；Host載入、調用及移除→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Hermes Agent/PLUGIN/PREW3_SHADOW/ON：原Hermes tool/skill loader與worker fresh PID驗manifest publisher/version/license/permissions；Host載入、調用及移除；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒不支援Host或未讀manifest權限；若raw.host不等於Hermes Agent或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無原Host plugin loader；API_ONLY為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `f686d9f67c17` 的唯讀 Cell 產品設計候選。

### CELL-675386c0f943｜PLUGIN/PREW3_SHADOW｜Hermes Agent｜legacy=OFF
- **原定位**：`BODY-09B:917`；真 Cell Id `CELL-675386c0f943`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L110，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；原Host plugin loader；API_ONLY為NOFIT。
- input→behavior→typed output：source-bound input→manifest publisher/version/license/permissions；Host載入、調用及移除→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Hermes Agent/PLUGIN/PREW3_SHADOW/OFF：原Hermes tool/skill loader與worker fresh PID驗manifest publisher/version/license/permissions；Host載入、調用及移除；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒不支援Host或未讀manifest權限；若raw.host不等於Hermes Agent或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無原Host plugin loader；API_ONLY為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `675386c0f943` 的唯讀 Cell 產品設計候選。

### CELL-412732ed745d｜PLUGIN/PREW3_SHADOW｜Codex｜legacy=ON
- **原定位**：`BODY-09B:928`；真 Cell Id `CELL-412732ed745d`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L111，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；原Host plugin loader；API_ONLY為NOFIT。
- input→behavior→typed output：source-bound input→manifest publisher/version/license/permissions；Host載入、調用及移除→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Codex/PLUGIN/PREW3_SHADOW/ON：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗manifest publisher/version/license/permissions；Host載入、調用及移除；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒不支援Host或未讀manifest權限；若raw.host不等於Codex或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無原Host plugin loader；API_ONLY為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `412732ed745d` 的唯讀 Cell 產品設計候選。

### CELL-9cc9f40bc2ac｜PLUGIN/PREW3_SHADOW｜Codex｜legacy=OFF
- **原定位**：`BODY-09B:939`；真 Cell Id `CELL-9cc9f40bc2ac`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L112，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；原Host plugin loader；API_ONLY為NOFIT。
- input→behavior→typed output：source-bound input→manifest publisher/version/license/permissions；Host載入、調用及移除→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Codex/PLUGIN/PREW3_SHADOW/OFF：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗manifest publisher/version/license/permissions；Host載入、調用及移除；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒不支援Host或未讀manifest權限；若raw.host不等於Codex或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無原Host plugin loader；API_ONLY為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `9cc9f40bc2ac` 的唯讀 Cell 產品設計候選。

### CELL-2259ef3f0dc2｜PLUGIN/PREW3_SHADOW｜Claude Code｜legacy=ON
- **原定位**：`BODY-09B:950`；真 Cell Id `CELL-2259ef3f0dc2`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L113，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；原Host plugin loader；API_ONLY為NOFIT。
- input→behavior→typed output：source-bound input→manifest publisher/version/license/permissions；Host載入、調用及移除→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Claude Code/PLUGIN/PREW3_SHADOW/ON：Claude Code當期原loader＋乾淨session驗manifest publisher/version/license/permissions；Host載入、調用及移除；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒不支援Host或未讀manifest權限；若raw.host不等於Claude Code或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無原Host plugin loader；API_ONLY為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `2259ef3f0dc2` 的唯讀 Cell 產品設計候選。

### CELL-4f536bbc5402｜PLUGIN/PREW3_SHADOW｜Claude Code｜legacy=OFF
- **原定位**：`BODY-09B:961`；真 Cell Id `CELL-4f536bbc5402`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L114，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；原Host plugin loader；API_ONLY為NOFIT。
- input→behavior→typed output：source-bound input→manifest publisher/version/license/permissions；Host載入、調用及移除→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Claude Code/PLUGIN/PREW3_SHADOW/OFF：Claude Code當期原loader＋乾淨session驗manifest publisher/version/license/permissions；Host載入、調用及移除；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒不支援Host或未讀manifest權限；若raw.host不等於Claude Code或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無原Host plugin loader；API_ONLY為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `4f536bbc5402` 的唯讀 Cell 產品設計候選。

### CELL-bc4919027c0c｜PLUGIN/PREW3_SHADOW｜DeepSeek Harness｜legacy=ON
- **原定位**：`BODY-09B:972`；真 Cell Id `CELL-bc4919027c0c`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L115，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；原Host plugin loader；API_ONLY為NOFIT。
- input→behavior→typed output：source-bound input→manifest publisher/version/license/permissions；Host載入、調用及移除→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：DeepSeek Harness/PLUGIN/PREW3_SHADOW/ON：實際Harness adapter/capability reader；API_ONLY不能充loader驗manifest publisher/version/license/permissions；Host載入、調用及移除；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒不支援Host或未讀manifest權限；若raw.host不等於DeepSeek Harness或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無原Host plugin loader；API_ONLY為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `bc4919027c0c` 的唯讀 Cell 產品設計候選。

### CELL-06bbd5e5ecb2｜PLUGIN/PREW3_SHADOW｜DeepSeek Harness｜legacy=OFF
- **原定位**：`BODY-09B:983`；真 Cell Id `CELL-06bbd5e5ecb2`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L116，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；原Host plugin loader；API_ONLY為NOFIT。
- input→behavior→typed output：source-bound input→manifest publisher/version/license/permissions；Host載入、調用及移除→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：DeepSeek Harness/PLUGIN/PREW3_SHADOW/OFF：實際Harness adapter/capability reader；API_ONLY不能充loader驗manifest publisher/version/license/permissions；Host載入、調用及移除；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒不支援Host或未讀manifest權限；若raw.host不等於DeepSeek Harness或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無原Host plugin loader；API_ONLY為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `06bbd5e5ecb2` 的唯讀 Cell 產品設計候選。

### CELL-d19d2e42002a｜PLUGIN/SWOF_CONNECTED｜Hermes Agent｜legacy=ON
- **原定位**：`BODY-09B:994`；真 Cell Id `CELL-d19d2e42002a`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L117，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；原Host plugin loader；API_ONLY為NOFIT。
- input→behavior→typed output：source-bound input→manifest publisher/version/license/permissions；Host載入、調用及移除→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Hermes Agent/PLUGIN/SWOF_CONNECTED/ON：原Hermes tool/skill loader與worker fresh PID驗manifest publisher/version/license/permissions；Host載入、調用及移除；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒不支援Host或未讀manifest權限；若raw.host不等於Hermes Agent或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無原Host plugin loader；API_ONLY為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `d19d2e42002a` 的唯讀 Cell 產品設計候選。

### CELL-49cdd601f213｜PLUGIN/SWOF_CONNECTED｜Hermes Agent｜legacy=OFF
- **原定位**：`BODY-09B:1005`；真 Cell Id `CELL-49cdd601f213`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L118，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；原Host plugin loader；API_ONLY為NOFIT。
- input→behavior→typed output：source-bound input→manifest publisher/version/license/permissions；Host載入、調用及移除→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Hermes Agent/PLUGIN/SWOF_CONNECTED/OFF：原Hermes tool/skill loader與worker fresh PID驗manifest publisher/version/license/permissions；Host載入、調用及移除；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒不支援Host或未讀manifest權限；若raw.host不等於Hermes Agent或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無原Host plugin loader；API_ONLY為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `49cdd601f213` 的唯讀 Cell 產品設計候選。

### CELL-54d1a08c379f｜PLUGIN/SWOF_CONNECTED｜Codex｜legacy=ON
- **原定位**：`BODY-09B:1016`；真 Cell Id `CELL-54d1a08c379f`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L119，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；原Host plugin loader；API_ONLY為NOFIT。
- input→behavior→typed output：source-bound input→manifest publisher/version/license/permissions；Host載入、調用及移除→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Codex/PLUGIN/SWOF_CONNECTED/ON：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗manifest publisher/version/license/permissions；Host載入、調用及移除；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒不支援Host或未讀manifest權限；若raw.host不等於Codex或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無原Host plugin loader；API_ONLY為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `54d1a08c379f` 的唯讀 Cell 產品設計候選。

### CELL-2ce069d50986｜PLUGIN/SWOF_CONNECTED｜Codex｜legacy=OFF
- **原定位**：`BODY-09B:1027`；真 Cell Id `CELL-2ce069d50986`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L120，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；原Host plugin loader；API_ONLY為NOFIT。
- input→behavior→typed output：source-bound input→manifest publisher/version/license/permissions；Host載入、調用及移除→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Codex/PLUGIN/SWOF_CONNECTED/OFF：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗manifest publisher/version/license/permissions；Host載入、調用及移除；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒不支援Host或未讀manifest權限；若raw.host不等於Codex或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無原Host plugin loader；API_ONLY為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `2ce069d50986` 的唯讀 Cell 產品設計候選。

### CELL-afca4537e0b5｜PLUGIN/SWOF_CONNECTED｜Claude Code｜legacy=ON
- **原定位**：`BODY-09B:1038`；真 Cell Id `CELL-afca4537e0b5`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L121，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；原Host plugin loader；API_ONLY為NOFIT。
- input→behavior→typed output：source-bound input→manifest publisher/version/license/permissions；Host載入、調用及移除→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Claude Code/PLUGIN/SWOF_CONNECTED/ON：Claude Code當期原loader＋乾淨session驗manifest publisher/version/license/permissions；Host載入、調用及移除；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒不支援Host或未讀manifest權限；若raw.host不等於Claude Code或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無原Host plugin loader；API_ONLY為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `afca4537e0b5` 的唯讀 Cell 產品設計候選。

### CELL-ae862affcd7c｜PLUGIN/SWOF_CONNECTED｜Claude Code｜legacy=OFF
- **原定位**：`BODY-09B:1049`；真 Cell Id `CELL-ae862affcd7c`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L122，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；原Host plugin loader；API_ONLY為NOFIT。
- input→behavior→typed output：source-bound input→manifest publisher/version/license/permissions；Host載入、調用及移除→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Claude Code/PLUGIN/SWOF_CONNECTED/OFF：Claude Code當期原loader＋乾淨session驗manifest publisher/version/license/permissions；Host載入、調用及移除；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒不支援Host或未讀manifest權限；若raw.host不等於Claude Code或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無原Host plugin loader；API_ONLY為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `ae862affcd7c` 的唯讀 Cell 產品設計候選。

### CELL-8bf8d2ec3581｜PLUGIN/SWOF_CONNECTED｜DeepSeek Harness｜legacy=ON
- **原定位**：`BODY-09B:1060`；真 Cell Id `CELL-8bf8d2ec3581`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L123，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；原Host plugin loader；API_ONLY為NOFIT。
- input→behavior→typed output：source-bound input→manifest publisher/version/license/permissions；Host載入、調用及移除→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：DeepSeek Harness/PLUGIN/SWOF_CONNECTED/ON：實際Harness adapter/capability reader；API_ONLY不能充loader驗manifest publisher/version/license/permissions；Host載入、調用及移除；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒不支援Host或未讀manifest權限；若raw.host不等於DeepSeek Harness或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無原Host plugin loader；API_ONLY為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `8bf8d2ec3581` 的唯讀 Cell 產品設計候選。

### CELL-085bc8fd7622｜PLUGIN/SWOF_CONNECTED｜DeepSeek Harness｜legacy=OFF
- **原定位**：`BODY-09B:1071`；真 Cell Id `CELL-085bc8fd7622`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L124，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；原Host plugin loader；API_ONLY為NOFIT。
- input→behavior→typed output：source-bound input→manifest publisher/version/license/permissions；Host載入、調用及移除→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：DeepSeek Harness/PLUGIN/SWOF_CONNECTED/OFF：實際Harness adapter/capability reader；API_ONLY不能充loader驗manifest publisher/version/license/permissions；Host載入、調用及移除；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒不支援Host或未讀manifest權限；若raw.host不等於DeepSeek Harness或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無原Host plugin loader；API_ONLY為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `085bc8fd7622` 的唯讀 Cell 產品設計候選。

### CELL-f6053f9a9dbf｜PROFILE/STANDALONE｜Hermes Agent｜legacy=ON
- **原定位**：`BODY-09B:1082`；真 Cell Id `CELL-f6053f9a9dbf`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L125，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；原Host Profile Reader；無profile interface為NOFIT。
- input→behavior→typed output：source-bound input→ProfileBinding/applicability+scope/loaded SHA與卸載還原→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Hermes Agent/PROFILE/STANDALONE/ON：原Hermes tool/skill loader與worker fresh PID驗ProfileBinding/applicability+scope/loaded SHA與卸載還原；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒selected當loaded或跨Scope套Profile；若raw.host不等於Hermes Agent或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無原Host Profile Reader；無profile interface為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `f6053f9a9dbf` 的唯讀 Cell 產品設計候選。

### CELL-48759a93f265｜PROFILE/STANDALONE｜Hermes Agent｜legacy=OFF
- **原定位**：`BODY-09B:1093`；真 Cell Id `CELL-48759a93f265`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L126，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；原Host Profile Reader；無profile interface為NOFIT。
- input→behavior→typed output：source-bound input→ProfileBinding/applicability+scope/loaded SHA與卸載還原→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Hermes Agent/PROFILE/STANDALONE/OFF：原Hermes tool/skill loader與worker fresh PID驗ProfileBinding/applicability+scope/loaded SHA與卸載還原；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒selected當loaded或跨Scope套Profile；若raw.host不等於Hermes Agent或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無原Host Profile Reader；無profile interface為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `48759a93f265` 的唯讀 Cell 產品設計候選。

### CELL-ce7ed7519316｜PROFILE/STANDALONE｜Codex｜legacy=ON
- **原定位**：`BODY-09B:1104`；真 Cell Id `CELL-ce7ed7519316`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L127，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；原Host Profile Reader；無profile interface為NOFIT。
- input→behavior→typed output：source-bound input→ProfileBinding/applicability+scope/loaded SHA與卸載還原→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Codex/PROFILE/STANDALONE/ON：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗ProfileBinding/applicability+scope/loaded SHA與卸載還原；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒selected當loaded或跨Scope套Profile；若raw.host不等於Codex或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無原Host Profile Reader；無profile interface為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `ce7ed7519316` 的唯讀 Cell 產品設計候選。

### CELL-e9109bda38f1｜PROFILE/STANDALONE｜Codex｜legacy=OFF
- **原定位**：`BODY-09B:1115`；真 Cell Id `CELL-e9109bda38f1`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L128，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；原Host Profile Reader；無profile interface為NOFIT。
- input→behavior→typed output：source-bound input→ProfileBinding/applicability+scope/loaded SHA與卸載還原→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Codex/PROFILE/STANDALONE/OFF：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗ProfileBinding/applicability+scope/loaded SHA與卸載還原；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒selected當loaded或跨Scope套Profile；若raw.host不等於Codex或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無原Host Profile Reader；無profile interface為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `e9109bda38f1` 的唯讀 Cell 產品設計候選。

### CELL-67282ac08b7e｜PROFILE/STANDALONE｜Claude Code｜legacy=ON
- **原定位**：`BODY-09B:1126`；真 Cell Id `CELL-67282ac08b7e`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L129，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；原Host Profile Reader；無profile interface為NOFIT。
- input→behavior→typed output：source-bound input→ProfileBinding/applicability+scope/loaded SHA與卸載還原→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Claude Code/PROFILE/STANDALONE/ON：Claude Code當期原loader＋乾淨session驗ProfileBinding/applicability+scope/loaded SHA與卸載還原；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒selected當loaded或跨Scope套Profile；若raw.host不等於Claude Code或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無原Host Profile Reader；無profile interface為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `67282ac08b7e` 的唯讀 Cell 產品設計候選。

### CELL-77fe98764ab5｜PROFILE/STANDALONE｜Claude Code｜legacy=OFF
- **原定位**：`BODY-09B:1137`；真 Cell Id `CELL-77fe98764ab5`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L130，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；原Host Profile Reader；無profile interface為NOFIT。
- input→behavior→typed output：source-bound input→ProfileBinding/applicability+scope/loaded SHA與卸載還原→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Claude Code/PROFILE/STANDALONE/OFF：Claude Code當期原loader＋乾淨session驗ProfileBinding/applicability+scope/loaded SHA與卸載還原；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒selected當loaded或跨Scope套Profile；若raw.host不等於Claude Code或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無原Host Profile Reader；無profile interface為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `77fe98764ab5` 的唯讀 Cell 產品設計候選。

### CELL-24e9aedd8086｜PROFILE/STANDALONE｜DeepSeek Harness｜legacy=ON
- **原定位**：`BODY-09B:1148`；真 Cell Id `CELL-24e9aedd8086`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L131，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；原Host Profile Reader；無profile interface為NOFIT。
- input→behavior→typed output：source-bound input→ProfileBinding/applicability+scope/loaded SHA與卸載還原→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：DeepSeek Harness/PROFILE/STANDALONE/ON：實際Harness adapter/capability reader；API_ONLY不能充loader驗ProfileBinding/applicability+scope/loaded SHA與卸載還原；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒selected當loaded或跨Scope套Profile；若raw.host不等於DeepSeek Harness或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無原Host Profile Reader；無profile interface為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `24e9aedd8086` 的唯讀 Cell 產品設計候選。

### CELL-75540fe3412c｜PROFILE/STANDALONE｜DeepSeek Harness｜legacy=OFF
- **原定位**：`BODY-09B:1159`；真 Cell Id `CELL-75540fe3412c`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L132，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；原Host Profile Reader；無profile interface為NOFIT。
- input→behavior→typed output：source-bound input→ProfileBinding/applicability+scope/loaded SHA與卸載還原→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：DeepSeek Harness/PROFILE/STANDALONE/OFF：實際Harness adapter/capability reader；API_ONLY不能充loader驗ProfileBinding/applicability+scope/loaded SHA與卸載還原；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒selected當loaded或跨Scope套Profile；若raw.host不等於DeepSeek Harness或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無原Host Profile Reader；無profile interface為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `75540fe3412c` 的唯讀 Cell 產品設計候選。

### CELL-e3f461767442｜PROFILE/PREW3_SHADOW｜Hermes Agent｜legacy=ON
- **原定位**：`BODY-09B:1170`；真 Cell Id `CELL-e3f461767442`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L133，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；原Host Profile Reader；無profile interface為NOFIT。
- input→behavior→typed output：source-bound input→ProfileBinding/applicability+scope/loaded SHA與卸載還原→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Hermes Agent/PROFILE/PREW3_SHADOW/ON：原Hermes tool/skill loader與worker fresh PID驗ProfileBinding/applicability+scope/loaded SHA與卸載還原；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒selected當loaded或跨Scope套Profile；若raw.host不等於Hermes Agent或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無原Host Profile Reader；無profile interface為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `e3f461767442` 的唯讀 Cell 產品設計候選。

### CELL-491bbc480824｜PROFILE/PREW3_SHADOW｜Hermes Agent｜legacy=OFF
- **原定位**：`BODY-09B:1181`；真 Cell Id `CELL-491bbc480824`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L134，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；原Host Profile Reader；無profile interface為NOFIT。
- input→behavior→typed output：source-bound input→ProfileBinding/applicability+scope/loaded SHA與卸載還原→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Hermes Agent/PROFILE/PREW3_SHADOW/OFF：原Hermes tool/skill loader與worker fresh PID驗ProfileBinding/applicability+scope/loaded SHA與卸載還原；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒selected當loaded或跨Scope套Profile；若raw.host不等於Hermes Agent或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無原Host Profile Reader；無profile interface為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `491bbc480824` 的唯讀 Cell 產品設計候選。

### CELL-24862363699e｜PROFILE/PREW3_SHADOW｜Codex｜legacy=ON
- **原定位**：`BODY-09B:1192`；真 Cell Id `CELL-24862363699e`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L135，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；原Host Profile Reader；無profile interface為NOFIT。
- input→behavior→typed output：source-bound input→ProfileBinding/applicability+scope/loaded SHA與卸載還原→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Codex/PROFILE/PREW3_SHADOW/ON：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗ProfileBinding/applicability+scope/loaded SHA與卸載還原；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒selected當loaded或跨Scope套Profile；若raw.host不等於Codex或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無原Host Profile Reader；無profile interface為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `24862363699e` 的唯讀 Cell 產品設計候選。

### CELL-b41a32121615｜PROFILE/PREW3_SHADOW｜Codex｜legacy=OFF
- **原定位**：`BODY-09B:1203`；真 Cell Id `CELL-b41a32121615`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L136，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；原Host Profile Reader；無profile interface為NOFIT。
- input→behavior→typed output：source-bound input→ProfileBinding/applicability+scope/loaded SHA與卸載還原→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Codex/PROFILE/PREW3_SHADOW/OFF：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗ProfileBinding/applicability+scope/loaded SHA與卸載還原；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒selected當loaded或跨Scope套Profile；若raw.host不等於Codex或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無原Host Profile Reader；無profile interface為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `b41a32121615` 的唯讀 Cell 產品設計候選。

### CELL-8605451d5dd2｜PROFILE/PREW3_SHADOW｜Claude Code｜legacy=ON
- **原定位**：`BODY-09B:1214`；真 Cell Id `CELL-8605451d5dd2`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L137，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；原Host Profile Reader；無profile interface為NOFIT。
- input→behavior→typed output：source-bound input→ProfileBinding/applicability+scope/loaded SHA與卸載還原→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Claude Code/PROFILE/PREW3_SHADOW/ON：Claude Code當期原loader＋乾淨session驗ProfileBinding/applicability+scope/loaded SHA與卸載還原；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒selected當loaded或跨Scope套Profile；若raw.host不等於Claude Code或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無原Host Profile Reader；無profile interface為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `8605451d5dd2` 的唯讀 Cell 產品設計候選。

### CELL-9ca3d0377ed8｜PROFILE/PREW3_SHADOW｜Claude Code｜legacy=OFF
- **原定位**：`BODY-09B:1225`；真 Cell Id `CELL-9ca3d0377ed8`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L138，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；原Host Profile Reader；無profile interface為NOFIT。
- input→behavior→typed output：source-bound input→ProfileBinding/applicability+scope/loaded SHA與卸載還原→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Claude Code/PROFILE/PREW3_SHADOW/OFF：Claude Code當期原loader＋乾淨session驗ProfileBinding/applicability+scope/loaded SHA與卸載還原；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒selected當loaded或跨Scope套Profile；若raw.host不等於Claude Code或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無原Host Profile Reader；無profile interface為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `9ca3d0377ed8` 的唯讀 Cell 產品設計候選。

### CELL-dd12df59427a｜PROFILE/PREW3_SHADOW｜DeepSeek Harness｜legacy=ON
- **原定位**：`BODY-09B:1236`；真 Cell Id `CELL-dd12df59427a`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L139，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；原Host Profile Reader；無profile interface為NOFIT。
- input→behavior→typed output：source-bound input→ProfileBinding/applicability+scope/loaded SHA與卸載還原→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：DeepSeek Harness/PROFILE/PREW3_SHADOW/ON：實際Harness adapter/capability reader；API_ONLY不能充loader驗ProfileBinding/applicability+scope/loaded SHA與卸載還原；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒selected當loaded或跨Scope套Profile；若raw.host不等於DeepSeek Harness或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無原Host Profile Reader；無profile interface為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `dd12df59427a` 的唯讀 Cell 產品設計候選。

### CELL-5ce6176dde4b｜PROFILE/PREW3_SHADOW｜DeepSeek Harness｜legacy=OFF
- **原定位**：`BODY-09B:1247`；真 Cell Id `CELL-5ce6176dde4b`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L140，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；原Host Profile Reader；無profile interface為NOFIT。
- input→behavior→typed output：source-bound input→ProfileBinding/applicability+scope/loaded SHA與卸載還原→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：DeepSeek Harness/PROFILE/PREW3_SHADOW/OFF：實際Harness adapter/capability reader；API_ONLY不能充loader驗ProfileBinding/applicability+scope/loaded SHA與卸載還原；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒selected當loaded或跨Scope套Profile；若raw.host不等於DeepSeek Harness或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無原Host Profile Reader；無profile interface為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `5ce6176dde4b` 的唯讀 Cell 產品設計候選。

### CELL-40ec4e4388b4｜PROFILE/SWOF_CONNECTED｜Hermes Agent｜legacy=ON
- **原定位**：`BODY-09B:1258`；真 Cell Id `CELL-40ec4e4388b4`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L141，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；原Host Profile Reader；無profile interface為NOFIT。
- input→behavior→typed output：source-bound input→ProfileBinding/applicability+scope/loaded SHA與卸載還原→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Hermes Agent/PROFILE/SWOF_CONNECTED/ON：原Hermes tool/skill loader與worker fresh PID驗ProfileBinding/applicability+scope/loaded SHA與卸載還原；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒selected當loaded或跨Scope套Profile；若raw.host不等於Hermes Agent或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無原Host Profile Reader；無profile interface為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `40ec4e4388b4` 的唯讀 Cell 產品設計候選。

### CELL-0836e4dc5096｜PROFILE/SWOF_CONNECTED｜Hermes Agent｜legacy=OFF
- **原定位**：`BODY-09B:1269`；真 Cell Id `CELL-0836e4dc5096`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L142，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；原Host Profile Reader；無profile interface為NOFIT。
- input→behavior→typed output：source-bound input→ProfileBinding/applicability+scope/loaded SHA與卸載還原→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Hermes Agent/PROFILE/SWOF_CONNECTED/OFF：原Hermes tool/skill loader與worker fresh PID驗ProfileBinding/applicability+scope/loaded SHA與卸載還原；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒selected當loaded或跨Scope套Profile；若raw.host不等於Hermes Agent或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無原Host Profile Reader；無profile interface為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `0836e4dc5096` 的唯讀 Cell 產品設計候選。

### CELL-57abd1af6eca｜PROFILE/SWOF_CONNECTED｜Codex｜legacy=ON
- **原定位**：`BODY-09B:1280`；真 Cell Id `CELL-57abd1af6eca`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L143，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；原Host Profile Reader；無profile interface為NOFIT。
- input→behavior→typed output：source-bound input→ProfileBinding/applicability+scope/loaded SHA與卸載還原→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Codex/PROFILE/SWOF_CONNECTED/ON：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗ProfileBinding/applicability+scope/loaded SHA與卸載還原；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒selected當loaded或跨Scope套Profile；若raw.host不等於Codex或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無原Host Profile Reader；無profile interface為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `57abd1af6eca` 的唯讀 Cell 產品設計候選。

### CELL-9bf92fc1f576｜PROFILE/SWOF_CONNECTED｜Codex｜legacy=OFF
- **原定位**：`BODY-09B:1291`；真 Cell Id `CELL-9bf92fc1f576`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L144，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；原Host Profile Reader；無profile interface為NOFIT。
- input→behavior→typed output：source-bound input→ProfileBinding/applicability+scope/loaded SHA與卸載還原→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Codex/PROFILE/SWOF_CONNECTED/OFF：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗ProfileBinding/applicability+scope/loaded SHA與卸載還原；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒selected當loaded或跨Scope套Profile；若raw.host不等於Codex或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無原Host Profile Reader；無profile interface為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `9bf92fc1f576` 的唯讀 Cell 產品設計候選。

### CELL-ac9b0f671ba6｜PROFILE/SWOF_CONNECTED｜Claude Code｜legacy=ON
- **原定位**：`BODY-09B:1302`；真 Cell Id `CELL-ac9b0f671ba6`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L145，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；原Host Profile Reader；無profile interface為NOFIT。
- input→behavior→typed output：source-bound input→ProfileBinding/applicability+scope/loaded SHA與卸載還原→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Claude Code/PROFILE/SWOF_CONNECTED/ON：Claude Code當期原loader＋乾淨session驗ProfileBinding/applicability+scope/loaded SHA與卸載還原；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒selected當loaded或跨Scope套Profile；若raw.host不等於Claude Code或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無原Host Profile Reader；無profile interface為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `ac9b0f671ba6` 的唯讀 Cell 產品設計候選。

### CELL-c798b8d56448｜PROFILE/SWOF_CONNECTED｜Claude Code｜legacy=OFF
- **原定位**：`BODY-09B:1313`；真 Cell Id `CELL-c798b8d56448`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L146，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；原Host Profile Reader；無profile interface為NOFIT。
- input→behavior→typed output：source-bound input→ProfileBinding/applicability+scope/loaded SHA與卸載還原→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Claude Code/PROFILE/SWOF_CONNECTED/OFF：Claude Code當期原loader＋乾淨session驗ProfileBinding/applicability+scope/loaded SHA與卸載還原；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒selected當loaded或跨Scope套Profile；若raw.host不等於Claude Code或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無原Host Profile Reader；無profile interface為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `c798b8d56448` 的唯讀 Cell 產品設計候選。

### CELL-44b29464a95a｜PROFILE/SWOF_CONNECTED｜DeepSeek Harness｜legacy=ON
- **原定位**：`BODY-09B:1324`；真 Cell Id `CELL-44b29464a95a`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L147，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；原Host Profile Reader；無profile interface為NOFIT。
- input→behavior→typed output：source-bound input→ProfileBinding/applicability+scope/loaded SHA與卸載還原→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：DeepSeek Harness/PROFILE/SWOF_CONNECTED/ON：實際Harness adapter/capability reader；API_ONLY不能充loader驗ProfileBinding/applicability+scope/loaded SHA與卸載還原；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒selected當loaded或跨Scope套Profile；若raw.host不等於DeepSeek Harness或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無原Host Profile Reader；無profile interface為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `44b29464a95a` 的唯讀 Cell 產品設計候選。

### CELL-db54604c0f5b｜PROFILE/SWOF_CONNECTED｜DeepSeek Harness｜legacy=OFF
- **原定位**：`BODY-09B:1335`；真 Cell Id `CELL-db54604c0f5b`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L148，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；原Host Profile Reader；無profile interface為NOFIT。
- input→behavior→typed output：source-bound input→ProfileBinding/applicability+scope/loaded SHA與卸載還原→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：DeepSeek Harness/PROFILE/SWOF_CONNECTED/OFF：實際Harness adapter/capability reader；API_ONLY不能充loader驗ProfileBinding/applicability+scope/loaded SHA與卸載還原；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒selected當loaded或跨Scope套Profile；若raw.host不等於DeepSeek Harness或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無原Host Profile Reader；無profile interface為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `db54604c0f5b` 的唯讀 Cell 產品設計候選。

### CELL-afca55403585｜AGENT_OS/STANDALONE｜Hermes Agent｜legacy=ON
- **原定位**：`BODY-09B:1346`；真 Cell Id `CELL-afca55403585`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L149，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT。
- input→behavior→typed output：source-bound input→正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Hermes Agent/AGENT_OS/STANDALONE/ON：原Hermes tool/skill loader與worker fresh PID驗正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒規劃文本冒可執行OS；若raw.host不等於Hermes Agent或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `afca55403585` 的唯讀 Cell 產品設計候選。

### CELL-df93f59a1365｜AGENT_OS/STANDALONE｜Hermes Agent｜legacy=OFF
- **原定位**：`BODY-09B:1357`；真 Cell Id `CELL-df93f59a1365`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L150，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT。
- input→behavior→typed output：source-bound input→正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Hermes Agent/AGENT_OS/STANDALONE/OFF：原Hermes tool/skill loader與worker fresh PID驗正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒規劃文本冒可執行OS；若raw.host不等於Hermes Agent或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `df93f59a1365` 的唯讀 Cell 產品設計候選。

### CELL-6c851f664a31｜AGENT_OS/STANDALONE｜Codex｜legacy=ON
- **原定位**：`BODY-09B:1368`；真 Cell Id `CELL-6c851f664a31`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L151，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT。
- input→behavior→typed output：source-bound input→正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Codex/AGENT_OS/STANDALONE/ON：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒規劃文本冒可執行OS；若raw.host不等於Codex或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `6c851f664a31` 的唯讀 Cell 產品設計候選。

### CELL-0af202afbd93｜AGENT_OS/STANDALONE｜Codex｜legacy=OFF
- **原定位**：`BODY-09B:1379`；真 Cell Id `CELL-0af202afbd93`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L152，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT。
- input→behavior→typed output：source-bound input→正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Codex/AGENT_OS/STANDALONE/OFF：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒規劃文本冒可執行OS；若raw.host不等於Codex或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `0af202afbd93` 的唯讀 Cell 產品設計候選。

### CELL-97fb84872359｜AGENT_OS/STANDALONE｜Claude Code｜legacy=ON
- **原定位**：`BODY-09B:1390`；真 Cell Id `CELL-97fb84872359`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L153，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT。
- input→behavior→typed output：source-bound input→正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Claude Code/AGENT_OS/STANDALONE/ON：Claude Code當期原loader＋乾淨session驗正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒規劃文本冒可執行OS；若raw.host不等於Claude Code或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `97fb84872359` 的唯讀 Cell 產品設計候選。

### CELL-c226c99e3199｜AGENT_OS/STANDALONE｜Claude Code｜legacy=OFF
- **原定位**：`BODY-09B:1401`；真 Cell Id `CELL-c226c99e3199`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L154，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT。
- input→behavior→typed output：source-bound input→正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Claude Code/AGENT_OS/STANDALONE/OFF：Claude Code當期原loader＋乾淨session驗正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒規劃文本冒可執行OS；若raw.host不等於Claude Code或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `c226c99e3199` 的唯讀 Cell 產品設計候選。

### CELL-9e3a12ad436c｜AGENT_OS/STANDALONE｜DeepSeek Harness｜legacy=ON
- **原定位**：`BODY-09B:1412`；真 Cell Id `CELL-9e3a12ad436c`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L155，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT。
- input→behavior→typed output：source-bound input→正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：DeepSeek Harness/AGENT_OS/STANDALONE/ON：實際Harness adapter/capability reader；API_ONLY不能充loader驗正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒規劃文本冒可執行OS；若raw.host不等於DeepSeek Harness或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `9e3a12ad436c` 的唯讀 Cell 產品設計候選。

### CELL-f18950ce731b｜AGENT_OS/STANDALONE｜DeepSeek Harness｜legacy=OFF
- **原定位**：`BODY-09B:1423`；真 Cell Id `CELL-f18950ce731b`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L156，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT。
- input→behavior→typed output：source-bound input→正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：DeepSeek Harness/AGENT_OS/STANDALONE/OFF：實際Harness adapter/capability reader；API_ONLY不能充loader驗正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒規劃文本冒可執行OS；若raw.host不等於DeepSeek Harness或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `f18950ce731b` 的唯讀 Cell 產品設計候選。

### CELL-4199689808cf｜AGENT_OS/PREW3_SHADOW｜Hermes Agent｜legacy=ON
- **原定位**：`BODY-09B:1434`；真 Cell Id `CELL-4199689808cf`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L157，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT。
- input→behavior→typed output：source-bound input→正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Hermes Agent/AGENT_OS/PREW3_SHADOW/ON：原Hermes tool/skill loader與worker fresh PID驗正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒規劃文本冒可執行OS；若raw.host不等於Hermes Agent或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `4199689808cf` 的唯讀 Cell 產品設計候選。

### CELL-b6ed07348d18｜AGENT_OS/PREW3_SHADOW｜Hermes Agent｜legacy=OFF
- **原定位**：`BODY-09B:1445`；真 Cell Id `CELL-b6ed07348d18`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L158，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT。
- input→behavior→typed output：source-bound input→正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Hermes Agent/AGENT_OS/PREW3_SHADOW/OFF：原Hermes tool/skill loader與worker fresh PID驗正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒規劃文本冒可執行OS；若raw.host不等於Hermes Agent或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `b6ed07348d18` 的唯讀 Cell 產品設計候選。

### CELL-ae25f61ef832｜AGENT_OS/PREW3_SHADOW｜Codex｜legacy=ON
- **原定位**：`BODY-09B:1456`；真 Cell Id `CELL-ae25f61ef832`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L159，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT。
- input→behavior→typed output：source-bound input→正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Codex/AGENT_OS/PREW3_SHADOW/ON：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒規劃文本冒可執行OS；若raw.host不等於Codex或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `ae25f61ef832` 的唯讀 Cell 產品設計候選。

### CELL-ec0547fd0acf｜AGENT_OS/PREW3_SHADOW｜Codex｜legacy=OFF
- **原定位**：`BODY-09B:1467`；真 Cell Id `CELL-ec0547fd0acf`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L160，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT。
- input→behavior→typed output：source-bound input→正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Codex/AGENT_OS/PREW3_SHADOW/OFF：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒規劃文本冒可執行OS；若raw.host不等於Codex或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `ec0547fd0acf` 的唯讀 Cell 產品設計候選。

### CELL-2331ca9034c4｜AGENT_OS/PREW3_SHADOW｜Claude Code｜legacy=ON
- **原定位**：`BODY-09B:1478`；真 Cell Id `CELL-2331ca9034c4`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L161，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT。
- input→behavior→typed output：source-bound input→正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Claude Code/AGENT_OS/PREW3_SHADOW/ON：Claude Code當期原loader＋乾淨session驗正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒規劃文本冒可執行OS；若raw.host不等於Claude Code或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `2331ca9034c4` 的唯讀 Cell 產品設計候選。

### CELL-c7f9eff2fddd｜AGENT_OS/PREW3_SHADOW｜Claude Code｜legacy=OFF
- **原定位**：`BODY-09B:1489`；真 Cell Id `CELL-c7f9eff2fddd`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L162，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT。
- input→behavior→typed output：source-bound input→正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Claude Code/AGENT_OS/PREW3_SHADOW/OFF：Claude Code當期原loader＋乾淨session驗正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒規劃文本冒可執行OS；若raw.host不等於Claude Code或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `c7f9eff2fddd` 的唯讀 Cell 產品設計候選。

### CELL-f93b6704ee69｜AGENT_OS/PREW3_SHADOW｜DeepSeek Harness｜legacy=ON
- **原定位**：`BODY-09B:1500`；真 Cell Id `CELL-f93b6704ee69`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L163，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT。
- input→behavior→typed output：source-bound input→正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：DeepSeek Harness/AGENT_OS/PREW3_SHADOW/ON：實際Harness adapter/capability reader；API_ONLY不能充loader驗正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒規劃文本冒可執行OS；若raw.host不等於DeepSeek Harness或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `f93b6704ee69` 的唯讀 Cell 產品設計候選。

### CELL-91838cb6a697｜AGENT_OS/PREW3_SHADOW｜DeepSeek Harness｜legacy=OFF
- **原定位**：`BODY-09B:1511`；真 Cell Id `CELL-91838cb6a697`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L164，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT。
- input→behavior→typed output：source-bound input→正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：DeepSeek Harness/AGENT_OS/PREW3_SHADOW/OFF：實際Harness adapter/capability reader；API_ONLY不能充loader驗正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒規劃文本冒可執行OS；若raw.host不等於DeepSeek Harness或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `91838cb6a697` 的唯讀 Cell 產品設計候選。

### CELL-78e42a13bbff｜AGENT_OS/SWOF_CONNECTED｜Hermes Agent｜legacy=ON
- **原定位**：`BODY-09B:1522`；真 Cell Id `CELL-78e42a13bbff`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L165，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT。
- input→behavior→typed output：source-bound input→正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Hermes Agent/AGENT_OS/SWOF_CONNECTED/ON：原Hermes tool/skill loader與worker fresh PID驗正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒規劃文本冒可執行OS；若raw.host不等於Hermes Agent或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `78e42a13bbff` 的唯讀 Cell 產品設計候選。

### CELL-8c30f1274481｜AGENT_OS/SWOF_CONNECTED｜Hermes Agent｜legacy=OFF
- **原定位**：`BODY-09B:1533`；真 Cell Id `CELL-8c30f1274481`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L166，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT。
- input→behavior→typed output：source-bound input→正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Hermes Agent/AGENT_OS/SWOF_CONNECTED/OFF：原Hermes tool/skill loader與worker fresh PID驗正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒規劃文本冒可執行OS；若raw.host不等於Hermes Agent或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `8c30f1274481` 的唯讀 Cell 產品設計候選。

### CELL-9fdb959e54cd｜AGENT_OS/SWOF_CONNECTED｜Codex｜legacy=ON
- **原定位**：`BODY-09B:1544`；真 Cell Id `CELL-9fdb959e54cd`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L167，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT。
- input→behavior→typed output：source-bound input→正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Codex/AGENT_OS/SWOF_CONNECTED/ON：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒規劃文本冒可執行OS；若raw.host不等於Codex或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `9fdb959e54cd` 的唯讀 Cell 產品設計候選。

### CELL-16b0d6f0aa4b｜AGENT_OS/SWOF_CONNECTED｜Codex｜legacy=OFF
- **原定位**：`BODY-09B:1555`；真 Cell Id `CELL-16b0d6f0aa4b`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L168，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT。
- input→behavior→typed output：source-bound input→正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Codex/AGENT_OS/SWOF_CONNECTED/OFF：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒規劃文本冒可執行OS；若raw.host不等於Codex或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `16b0d6f0aa4b` 的唯讀 Cell 產品設計候選。

### CELL-9f3a107b084e｜AGENT_OS/SWOF_CONNECTED｜Claude Code｜legacy=ON
- **原定位**：`BODY-09B:1566`；真 Cell Id `CELL-9f3a107b084e`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L169，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT。
- input→behavior→typed output：source-bound input→正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Claude Code/AGENT_OS/SWOF_CONNECTED/ON：Claude Code當期原loader＋乾淨session驗正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒規劃文本冒可執行OS；若raw.host不等於Claude Code或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `9f3a107b084e` 的唯讀 Cell 產品設計候選。

### CELL-378b78d029ac｜AGENT_OS/SWOF_CONNECTED｜Claude Code｜legacy=OFF
- **原定位**：`BODY-09B:1577`；真 Cell Id `CELL-378b78d029ac`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L170，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT。
- input→behavior→typed output：source-bound input→正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Claude Code/AGENT_OS/SWOF_CONNECTED/OFF：Claude Code當期原loader＋乾淨session驗正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒規劃文本冒可執行OS；若raw.host不等於Claude Code或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `378b78d029ac` 的唯讀 Cell 產品設計候選。

### CELL-10cbe7b8ba17｜AGENT_OS/SWOF_CONNECTED｜DeepSeek Harness｜legacy=ON
- **原定位**：`BODY-09B:1588`；真 Cell Id `CELL-10cbe7b8ba17`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L171，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT。
- input→behavior→typed output：source-bound input→正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：DeepSeek Harness/AGENT_OS/SWOF_CONNECTED/ON：實際Harness adapter/capability reader；API_ONLY不能充loader驗正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒規劃文本冒可執行OS；若raw.host不等於DeepSeek Harness或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `10cbe7b8ba17` 的唯讀 Cell 產品設計候選。

### CELL-95ae8bfac0e7｜AGENT_OS/SWOF_CONNECTED｜DeepSeek Harness｜legacy=OFF
- **原定位**：`BODY-09B:1599`；真 Cell Id `CELL-95ae8bfac0e7`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L172，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT。
- input→behavior→typed output：source-bound input→正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：DeepSeek Harness/AGENT_OS/SWOF_CONNECTED/OFF：實際Harness adapter/capability reader；API_ONLY不能充loader驗正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒規劃文本冒可執行OS；若raw.host不等於DeepSeek Harness或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `95ae8bfac0e7` 的唯讀 Cell 產品設計候選。

### CELL-d0ea4e9314ef｜AI_SYSTEM/STANDALONE｜Hermes Agent｜legacy=ON
- **原定位**：`BODY-09B:1610`；真 Cell Id `CELL-d0ea4e9314ef`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L173，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；實際system deployment orchestrator；無部署接口為NOFIT。
- input→behavior→typed output：source-bound input→多組件DAG/ABI/部署健康/退場的整體consumer readback→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Hermes Agent/AI_SYSTEM/STANDALONE/ON：原Hermes tool/skill loader與worker fresh PID驗多組件DAG/ABI/部署健康/退場的整體consumer readback；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒單Agent demo冒完整系統；若raw.host不等於Hermes Agent或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無實際system deployment orchestrator；無部署接口為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `d0ea4e9314ef` 的唯讀 Cell 產品設計候選。

### CELL-e90fb5ce4fd3｜AI_SYSTEM/STANDALONE｜Hermes Agent｜legacy=OFF
- **原定位**：`BODY-09B:1621`；真 Cell Id `CELL-e90fb5ce4fd3`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L174，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；實際system deployment orchestrator；無部署接口為NOFIT。
- input→behavior→typed output：source-bound input→多組件DAG/ABI/部署健康/退場的整體consumer readback→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Hermes Agent/AI_SYSTEM/STANDALONE/OFF：原Hermes tool/skill loader與worker fresh PID驗多組件DAG/ABI/部署健康/退場的整體consumer readback；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒單Agent demo冒完整系統；若raw.host不等於Hermes Agent或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無實際system deployment orchestrator；無部署接口為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `e90fb5ce4fd3` 的唯讀 Cell 產品設計候選。

### CELL-980e1f8cdbf6｜AI_SYSTEM/STANDALONE｜Codex｜legacy=ON
- **原定位**：`BODY-09B:1632`；真 Cell Id `CELL-980e1f8cdbf6`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L175，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；實際system deployment orchestrator；無部署接口為NOFIT。
- input→behavior→typed output：source-bound input→多組件DAG/ABI/部署健康/退場的整體consumer readback→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Codex/AI_SYSTEM/STANDALONE/ON：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗多組件DAG/ABI/部署健康/退場的整體consumer readback；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒單Agent demo冒完整系統；若raw.host不等於Codex或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無實際system deployment orchestrator；無部署接口為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `980e1f8cdbf6` 的唯讀 Cell 產品設計候選。

### CELL-80e6856b5e3c｜AI_SYSTEM/STANDALONE｜Codex｜legacy=OFF
- **原定位**：`BODY-09B:1643`；真 Cell Id `CELL-80e6856b5e3c`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L176，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；實際system deployment orchestrator；無部署接口為NOFIT。
- input→behavior→typed output：source-bound input→多組件DAG/ABI/部署健康/退場的整體consumer readback→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Codex/AI_SYSTEM/STANDALONE/OFF：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗多組件DAG/ABI/部署健康/退場的整體consumer readback；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒單Agent demo冒完整系統；若raw.host不等於Codex或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無實際system deployment orchestrator；無部署接口為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `80e6856b5e3c` 的唯讀 Cell 產品設計候選。

### CELL-ec2d6ac66d18｜AI_SYSTEM/STANDALONE｜Claude Code｜legacy=ON
- **原定位**：`BODY-09B:1654`；真 Cell Id `CELL-ec2d6ac66d18`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L177，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；實際system deployment orchestrator；無部署接口為NOFIT。
- input→behavior→typed output：source-bound input→多組件DAG/ABI/部署健康/退場的整體consumer readback→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Claude Code/AI_SYSTEM/STANDALONE/ON：Claude Code當期原loader＋乾淨session驗多組件DAG/ABI/部署健康/退場的整體consumer readback；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒單Agent demo冒完整系統；若raw.host不等於Claude Code或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無實際system deployment orchestrator；無部署接口為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `ec2d6ac66d18` 的唯讀 Cell 產品設計候選。

### CELL-4ed5ad806797｜AI_SYSTEM/STANDALONE｜Claude Code｜legacy=OFF
- **原定位**：`BODY-09B:1665`；真 Cell Id `CELL-4ed5ad806797`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L178，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；實際system deployment orchestrator；無部署接口為NOFIT。
- input→behavior→typed output：source-bound input→多組件DAG/ABI/部署健康/退場的整體consumer readback→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Claude Code/AI_SYSTEM/STANDALONE/OFF：Claude Code當期原loader＋乾淨session驗多組件DAG/ABI/部署健康/退場的整體consumer readback；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒單Agent demo冒完整系統；若raw.host不等於Claude Code或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無實際system deployment orchestrator；無部署接口為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `4ed5ad806797` 的唯讀 Cell 產品設計候選。

### CELL-f478ba7d0b9a｜AI_SYSTEM/STANDALONE｜DeepSeek Harness｜legacy=ON
- **原定位**：`BODY-09B:1676`；真 Cell Id `CELL-f478ba7d0b9a`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L179，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；實際system deployment orchestrator；無部署接口為NOFIT。
- input→behavior→typed output：source-bound input→多組件DAG/ABI/部署健康/退場的整體consumer readback→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：DeepSeek Harness/AI_SYSTEM/STANDALONE/ON：實際Harness adapter/capability reader；API_ONLY不能充loader驗多組件DAG/ABI/部署健康/退場的整體consumer readback；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒單Agent demo冒完整系統；若raw.host不等於DeepSeek Harness或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無實際system deployment orchestrator；無部署接口為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `f478ba7d0b9a` 的唯讀 Cell 產品設計候選。

### CELL-057db0593627｜AI_SYSTEM/STANDALONE｜DeepSeek Harness｜legacy=OFF
- **原定位**：`BODY-09B:1687`；真 Cell Id `CELL-057db0593627`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L180，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；實際system deployment orchestrator；無部署接口為NOFIT。
- input→behavior→typed output：source-bound input→多組件DAG/ABI/部署健康/退場的整體consumer readback→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：DeepSeek Harness/AI_SYSTEM/STANDALONE/OFF：實際Harness adapter/capability reader；API_ONLY不能充loader驗多組件DAG/ABI/部署健康/退場的整體consumer readback；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒單Agent demo冒完整系統；若raw.host不等於DeepSeek Harness或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無實際system deployment orchestrator；無部署接口為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `057db0593627` 的唯讀 Cell 產品設計候選。

### CELL-cb6fcd8de73c｜AI_SYSTEM/PREW3_SHADOW｜Hermes Agent｜legacy=ON
- **原定位**：`BODY-09B:1698`；真 Cell Id `CELL-cb6fcd8de73c`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L181，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；實際system deployment orchestrator；無部署接口為NOFIT。
- input→behavior→typed output：source-bound input→多組件DAG/ABI/部署健康/退場的整體consumer readback→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Hermes Agent/AI_SYSTEM/PREW3_SHADOW/ON：原Hermes tool/skill loader與worker fresh PID驗多組件DAG/ABI/部署健康/退場的整體consumer readback；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒單Agent demo冒完整系統；若raw.host不等於Hermes Agent或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無實際system deployment orchestrator；無部署接口為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `cb6fcd8de73c` 的唯讀 Cell 產品設計候選。

### CELL-41ed105d02da｜AI_SYSTEM/PREW3_SHADOW｜Hermes Agent｜legacy=OFF
- **原定位**：`BODY-09B:1709`；真 Cell Id `CELL-41ed105d02da`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L182，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；實際system deployment orchestrator；無部署接口為NOFIT。
- input→behavior→typed output：source-bound input→多組件DAG/ABI/部署健康/退場的整體consumer readback→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Hermes Agent/AI_SYSTEM/PREW3_SHADOW/OFF：原Hermes tool/skill loader與worker fresh PID驗多組件DAG/ABI/部署健康/退場的整體consumer readback；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒單Agent demo冒完整系統；若raw.host不等於Hermes Agent或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無實際system deployment orchestrator；無部署接口為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `41ed105d02da` 的唯讀 Cell 產品設計候選。

### CELL-836112ec4da9｜AI_SYSTEM/PREW3_SHADOW｜Codex｜legacy=ON
- **原定位**：`BODY-09B:1720`；真 Cell Id `CELL-836112ec4da9`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L183，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；實際system deployment orchestrator；無部署接口為NOFIT。
- input→behavior→typed output：source-bound input→多組件DAG/ABI/部署健康/退場的整體consumer readback→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Codex/AI_SYSTEM/PREW3_SHADOW/ON：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗多組件DAG/ABI/部署健康/退場的整體consumer readback；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒單Agent demo冒完整系統；若raw.host不等於Codex或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無實際system deployment orchestrator；無部署接口為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `836112ec4da9` 的唯讀 Cell 產品設計候選。

### CELL-83cb46793f3b｜AI_SYSTEM/PREW3_SHADOW｜Codex｜legacy=OFF
- **原定位**：`BODY-09B:1731`；真 Cell Id `CELL-83cb46793f3b`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L184，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；實際system deployment orchestrator；無部署接口為NOFIT。
- input→behavior→typed output：source-bound input→多組件DAG/ABI/部署健康/退場的整體consumer readback→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Codex/AI_SYSTEM/PREW3_SHADOW/OFF：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗多組件DAG/ABI/部署健康/退場的整體consumer readback；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒單Agent demo冒完整系統；若raw.host不等於Codex或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無實際system deployment orchestrator；無部署接口為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `83cb46793f3b` 的唯讀 Cell 產品設計候選。

### CELL-39e031d42387｜AI_SYSTEM/PREW3_SHADOW｜Claude Code｜legacy=ON
- **原定位**：`BODY-09B:1742`；真 Cell Id `CELL-39e031d42387`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L185，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；實際system deployment orchestrator；無部署接口為NOFIT。
- input→behavior→typed output：source-bound input→多組件DAG/ABI/部署健康/退場的整體consumer readback→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Claude Code/AI_SYSTEM/PREW3_SHADOW/ON：Claude Code當期原loader＋乾淨session驗多組件DAG/ABI/部署健康/退場的整體consumer readback；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒單Agent demo冒完整系統；若raw.host不等於Claude Code或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無實際system deployment orchestrator；無部署接口為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `39e031d42387` 的唯讀 Cell 產品設計候選。

### CELL-f250e0e5814a｜AI_SYSTEM/PREW3_SHADOW｜Claude Code｜legacy=OFF
- **原定位**：`BODY-09B:1753`；真 Cell Id `CELL-f250e0e5814a`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L186，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；實際system deployment orchestrator；無部署接口為NOFIT。
- input→behavior→typed output：source-bound input→多組件DAG/ABI/部署健康/退場的整體consumer readback→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Claude Code/AI_SYSTEM/PREW3_SHADOW/OFF：Claude Code當期原loader＋乾淨session驗多組件DAG/ABI/部署健康/退場的整體consumer readback；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒單Agent demo冒完整系統；若raw.host不等於Claude Code或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無實際system deployment orchestrator；無部署接口為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `f250e0e5814a` 的唯讀 Cell 產品設計候選。

### CELL-9742bec81e5a｜AI_SYSTEM/PREW3_SHADOW｜DeepSeek Harness｜legacy=ON
- **原定位**：`BODY-09B:1764`；真 Cell Id `CELL-9742bec81e5a`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L187，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；實際system deployment orchestrator；無部署接口為NOFIT。
- input→behavior→typed output：source-bound input→多組件DAG/ABI/部署健康/退場的整體consumer readback→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：DeepSeek Harness/AI_SYSTEM/PREW3_SHADOW/ON：實際Harness adapter/capability reader；API_ONLY不能充loader驗多組件DAG/ABI/部署健康/退場的整體consumer readback；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒單Agent demo冒完整系統；若raw.host不等於DeepSeek Harness或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無實際system deployment orchestrator；無部署接口為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `9742bec81e5a` 的唯讀 Cell 產品設計候選。

### CELL-237ac6308b3f｜AI_SYSTEM/PREW3_SHADOW｜DeepSeek Harness｜legacy=OFF
- **原定位**：`BODY-09B:1775`；真 Cell Id `CELL-237ac6308b3f`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L188，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；實際system deployment orchestrator；無部署接口為NOFIT。
- input→behavior→typed output：source-bound input→多組件DAG/ABI/部署健康/退場的整體consumer readback→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：DeepSeek Harness/AI_SYSTEM/PREW3_SHADOW/OFF：實際Harness adapter/capability reader；API_ONLY不能充loader驗多組件DAG/ABI/部署健康/退場的整體consumer readback；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒單Agent demo冒完整系統；若raw.host不等於DeepSeek Harness或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無實際system deployment orchestrator；無部署接口為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `237ac6308b3f` 的唯讀 Cell 產品設計候選。

### CELL-762256559527｜AI_SYSTEM/SWOF_CONNECTED｜Hermes Agent｜legacy=ON
- **原定位**：`BODY-09B:1786`；真 Cell Id `CELL-762256559527`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L189，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；實際system deployment orchestrator；無部署接口為NOFIT。
- input→behavior→typed output：source-bound input→多組件DAG/ABI/部署健康/退場的整體consumer readback→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Hermes Agent/AI_SYSTEM/SWOF_CONNECTED/ON：原Hermes tool/skill loader與worker fresh PID驗多組件DAG/ABI/部署健康/退場的整體consumer readback；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒單Agent demo冒完整系統；若raw.host不等於Hermes Agent或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無實際system deployment orchestrator；無部署接口為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `762256559527` 的唯讀 Cell 產品設計候選。

### CELL-42f5aee6701f｜AI_SYSTEM/SWOF_CONNECTED｜Hermes Agent｜legacy=OFF
- **原定位**：`BODY-09B:1797`；真 Cell Id `CELL-42f5aee6701f`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L190，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；實際system deployment orchestrator；無部署接口為NOFIT。
- input→behavior→typed output：source-bound input→多組件DAG/ABI/部署健康/退場的整體consumer readback→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Hermes Agent/AI_SYSTEM/SWOF_CONNECTED/OFF：原Hermes tool/skill loader與worker fresh PID驗多組件DAG/ABI/部署健康/退場的整體consumer readback；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒單Agent demo冒完整系統；若raw.host不等於Hermes Agent或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無實際system deployment orchestrator；無部署接口為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `42f5aee6701f` 的唯讀 Cell 產品設計候選。

### CELL-7b1a7a42e067｜AI_SYSTEM/SWOF_CONNECTED｜Codex｜legacy=ON
- **原定位**：`BODY-09B:1808`；真 Cell Id `CELL-7b1a7a42e067`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L191，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；實際system deployment orchestrator；無部署接口為NOFIT。
- input→behavior→typed output：source-bound input→多組件DAG/ABI/部署健康/退場的整體consumer readback→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Codex/AI_SYSTEM/SWOF_CONNECTED/ON：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗多組件DAG/ABI/部署健康/退場的整體consumer readback；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒單Agent demo冒完整系統；若raw.host不等於Codex或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無實際system deployment orchestrator；無部署接口為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `7b1a7a42e067` 的唯讀 Cell 產品設計候選。

### CELL-f171ddc0382c｜AI_SYSTEM/SWOF_CONNECTED｜Codex｜legacy=OFF
- **原定位**：`BODY-09B:1819`；真 Cell Id `CELL-f171ddc0382c`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L192，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；實際system deployment orchestrator；無部署接口為NOFIT。
- input→behavior→typed output：source-bound input→多組件DAG/ABI/部署健康/退場的整體consumer readback→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Codex/AI_SYSTEM/SWOF_CONNECTED/OFF：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗多組件DAG/ABI/部署健康/退場的整體consumer readback；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒單Agent demo冒完整系統；若raw.host不等於Codex或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無實際system deployment orchestrator；無部署接口為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `f171ddc0382c` 的唯讀 Cell 產品設計候選。

### CELL-a50d9bf4ec2f｜AI_SYSTEM/SWOF_CONNECTED｜Claude Code｜legacy=ON
- **原定位**：`BODY-09B:1830`；真 Cell Id `CELL-a50d9bf4ec2f`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L193，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；實際system deployment orchestrator；無部署接口為NOFIT。
- input→behavior→typed output：source-bound input→多組件DAG/ABI/部署健康/退場的整體consumer readback→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Claude Code/AI_SYSTEM/SWOF_CONNECTED/ON：Claude Code當期原loader＋乾淨session驗多組件DAG/ABI/部署健康/退場的整體consumer readback；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒單Agent demo冒完整系統；若raw.host不等於Claude Code或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無實際system deployment orchestrator；無部署接口為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `a50d9bf4ec2f` 的唯讀 Cell 產品設計候選。

### CELL-90274105bfbf｜AI_SYSTEM/SWOF_CONNECTED｜Claude Code｜legacy=OFF
- **原定位**：`BODY-09B:1841`；真 Cell Id `CELL-90274105bfbf`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L194，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；實際system deployment orchestrator；無部署接口為NOFIT。
- input→behavior→typed output：source-bound input→多組件DAG/ABI/部署健康/退場的整體consumer readback→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Claude Code/AI_SYSTEM/SWOF_CONNECTED/OFF：Claude Code當期原loader＋乾淨session驗多組件DAG/ABI/部署健康/退場的整體consumer readback；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒單Agent demo冒完整系統；若raw.host不等於Claude Code或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無實際system deployment orchestrator；無部署接口為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `90274105bfbf` 的唯讀 Cell 產品設計候選。

### CELL-b85f95d3b255｜AI_SYSTEM/SWOF_CONNECTED｜DeepSeek Harness｜legacy=ON
- **原定位**：`BODY-09B:1852`；真 Cell Id `CELL-b85f95d3b255`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L195，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；實際system deployment orchestrator；無部署接口為NOFIT。
- input→behavior→typed output：source-bound input→多組件DAG/ABI/部署健康/退場的整體consumer readback→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：DeepSeek Harness/AI_SYSTEM/SWOF_CONNECTED/ON：實際Harness adapter/capability reader；API_ONLY不能充loader驗多組件DAG/ABI/部署健康/退場的整體consumer readback；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒單Agent demo冒完整系統；若raw.host不等於DeepSeek Harness或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無實際system deployment orchestrator；無部署接口為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `b85f95d3b255` 的唯讀 Cell 產品設計候選。

### CELL-1746d4d5a88d｜AI_SYSTEM/SWOF_CONNECTED｜DeepSeek Harness｜legacy=OFF
- **原定位**：`BODY-09B:1863`；真 Cell Id `CELL-1746d4d5a88d`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L196，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；實際system deployment orchestrator；無部署接口為NOFIT。
- input→behavior→typed output：source-bound input→多組件DAG/ABI/部署健康/退場的整體consumer readback→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：DeepSeek Harness/AI_SYSTEM/SWOF_CONNECTED/OFF：實際Harness adapter/capability reader；API_ONLY不能充loader驗多組件DAG/ABI/部署健康/退場的整體consumer readback；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒單Agent demo冒完整系統；若raw.host不等於DeepSeek Harness或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無實際system deployment orchestrator；無部署接口為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `1746d4d5a88d` 的唯讀 Cell 產品設計候選。

### CELL-336e267c9f1b｜GENIE/GENIE.md/STANDALONE｜Hermes Agent｜legacy=ON
- **原定位**：`BODY-09B:1874`；真 Cell Id `CELL-336e267c9f1b`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L197，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT。
- input→behavior→typed output：source-bound input→原SWOF版本化GENIE reference/schema與Owner關聯讀回→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Hermes Agent/GENIE/GENIE.md/STANDALONE/ON：原Hermes tool/skill loader與worker fresh PID驗原SWOF版本化GENIE reference/schema與Owner關聯讀回；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒任意GENIE.md冒正式生成或部署；若raw.host不等於Hermes Agent或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `336e267c9f1b` 的唯讀 Cell 產品設計候選。

### CELL-8f240272c803｜GENIE/GENIE.md/STANDALONE｜Hermes Agent｜legacy=OFF
- **原定位**：`BODY-09B:1885`；真 Cell Id `CELL-8f240272c803`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L198，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT。
- input→behavior→typed output：source-bound input→原SWOF版本化GENIE reference/schema與Owner關聯讀回→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Hermes Agent/GENIE/GENIE.md/STANDALONE/OFF：原Hermes tool/skill loader與worker fresh PID驗原SWOF版本化GENIE reference/schema與Owner關聯讀回；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒任意GENIE.md冒正式生成或部署；若raw.host不等於Hermes Agent或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `8f240272c803` 的唯讀 Cell 產品設計候選。

### CELL-5c0c72c957ed｜GENIE/GENIE.md/STANDALONE｜Codex｜legacy=ON
- **原定位**：`BODY-09B:1896`；真 Cell Id `CELL-5c0c72c957ed`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L199，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT。
- input→behavior→typed output：source-bound input→原SWOF版本化GENIE reference/schema與Owner關聯讀回→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Codex/GENIE/GENIE.md/STANDALONE/ON：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗原SWOF版本化GENIE reference/schema與Owner關聯讀回；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒任意GENIE.md冒正式生成或部署；若raw.host不等於Codex或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `5c0c72c957ed` 的唯讀 Cell 產品設計候選。

### CELL-d9f0da8c1631｜GENIE/GENIE.md/STANDALONE｜Codex｜legacy=OFF
- **原定位**：`BODY-09B:1907`；真 Cell Id `CELL-d9f0da8c1631`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L200，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT。
- input→behavior→typed output：source-bound input→原SWOF版本化GENIE reference/schema與Owner關聯讀回→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Codex/GENIE/GENIE.md/STANDALONE/OFF：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗原SWOF版本化GENIE reference/schema與Owner關聯讀回；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒任意GENIE.md冒正式生成或部署；若raw.host不等於Codex或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `d9f0da8c1631` 的唯讀 Cell 產品設計候選。

### CELL-070f95d5c154｜GENIE/GENIE.md/STANDALONE｜Claude Code｜legacy=ON
- **原定位**：`BODY-09B:1918`；真 Cell Id `CELL-070f95d5c154`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L201，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT。
- input→behavior→typed output：source-bound input→原SWOF版本化GENIE reference/schema與Owner關聯讀回→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Claude Code/GENIE/GENIE.md/STANDALONE/ON：Claude Code當期原loader＋乾淨session驗原SWOF版本化GENIE reference/schema與Owner關聯讀回；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒任意GENIE.md冒正式生成或部署；若raw.host不等於Claude Code或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `070f95d5c154` 的唯讀 Cell 產品設計候選。

### CELL-479fa09ec346｜GENIE/GENIE.md/STANDALONE｜Claude Code｜legacy=OFF
- **原定位**：`BODY-09B:1929`；真 Cell Id `CELL-479fa09ec346`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L202，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT。
- input→behavior→typed output：source-bound input→原SWOF版本化GENIE reference/schema與Owner關聯讀回→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Claude Code/GENIE/GENIE.md/STANDALONE/OFF：Claude Code當期原loader＋乾淨session驗原SWOF版本化GENIE reference/schema與Owner關聯讀回；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒任意GENIE.md冒正式生成或部署；若raw.host不等於Claude Code或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `479fa09ec346` 的唯讀 Cell 產品設計候選。

### CELL-9af02fa9e8ed｜GENIE/GENIE.md/STANDALONE｜DeepSeek Harness｜legacy=ON
- **原定位**：`BODY-09B:1940`；真 Cell Id `CELL-9af02fa9e8ed`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L203，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT。
- input→behavior→typed output：source-bound input→原SWOF版本化GENIE reference/schema與Owner關聯讀回→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：DeepSeek Harness/GENIE/GENIE.md/STANDALONE/ON：實際Harness adapter/capability reader；API_ONLY不能充loader驗原SWOF版本化GENIE reference/schema與Owner關聯讀回；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒任意GENIE.md冒正式生成或部署；若raw.host不等於DeepSeek Harness或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `9af02fa9e8ed` 的唯讀 Cell 產品設計候選。

### CELL-c38a7e723977｜GENIE/GENIE.md/STANDALONE｜DeepSeek Harness｜legacy=OFF
- **原定位**：`BODY-09B:1951`；真 Cell Id `CELL-c38a7e723977`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L204，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT。
- input→behavior→typed output：source-bound input→原SWOF版本化GENIE reference/schema與Owner關聯讀回→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：DeepSeek Harness/GENIE/GENIE.md/STANDALONE/OFF：實際Harness adapter/capability reader；API_ONLY不能充loader驗原SWOF版本化GENIE reference/schema與Owner關聯讀回；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒任意GENIE.md冒正式生成或部署；若raw.host不等於DeepSeek Harness或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `c38a7e723977` 的唯讀 Cell 產品設計候選。

### CELL-510726a815d2｜GENIE/GENIE.md/PREW3_SHADOW｜Hermes Agent｜legacy=ON
- **原定位**：`BODY-09B:1962`；真 Cell Id `CELL-510726a815d2`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L205，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT。
- input→behavior→typed output：source-bound input→原SWOF版本化GENIE reference/schema與Owner關聯讀回→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Hermes Agent/GENIE/GENIE.md/PREW3_SHADOW/ON：原Hermes tool/skill loader與worker fresh PID驗原SWOF版本化GENIE reference/schema與Owner關聯讀回；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒任意GENIE.md冒正式生成或部署；若raw.host不等於Hermes Agent或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `510726a815d2` 的唯讀 Cell 產品設計候選。

### CELL-f842f5e447d1｜GENIE/GENIE.md/PREW3_SHADOW｜Hermes Agent｜legacy=OFF
- **原定位**：`BODY-09B:1973`；真 Cell Id `CELL-f842f5e447d1`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L206，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT。
- input→behavior→typed output：source-bound input→原SWOF版本化GENIE reference/schema與Owner關聯讀回→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Hermes Agent/GENIE/GENIE.md/PREW3_SHADOW/OFF：原Hermes tool/skill loader與worker fresh PID驗原SWOF版本化GENIE reference/schema與Owner關聯讀回；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒任意GENIE.md冒正式生成或部署；若raw.host不等於Hermes Agent或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `f842f5e447d1` 的唯讀 Cell 產品設計候選。

### CELL-82305af511e2｜GENIE/GENIE.md/PREW3_SHADOW｜Codex｜legacy=ON
- **原定位**：`BODY-09B:1984`；真 Cell Id `CELL-82305af511e2`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L207，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT。
- input→behavior→typed output：source-bound input→原SWOF版本化GENIE reference/schema與Owner關聯讀回→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Codex/GENIE/GENIE.md/PREW3_SHADOW/ON：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗原SWOF版本化GENIE reference/schema與Owner關聯讀回；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒任意GENIE.md冒正式生成或部署；若raw.host不等於Codex或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `82305af511e2` 的唯讀 Cell 產品設計候選。

### CELL-bf764d5ba2c2｜GENIE/GENIE.md/PREW3_SHADOW｜Codex｜legacy=OFF
- **原定位**：`BODY-09B:1995`；真 Cell Id `CELL-bf764d5ba2c2`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L208，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT。
- input→behavior→typed output：source-bound input→原SWOF版本化GENIE reference/schema與Owner關聯讀回→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Codex/GENIE/GENIE.md/PREW3_SHADOW/OFF：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗原SWOF版本化GENIE reference/schema與Owner關聯讀回；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒任意GENIE.md冒正式生成或部署；若raw.host不等於Codex或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `bf764d5ba2c2` 的唯讀 Cell 產品設計候選。

### CELL-d69adf2f1965｜GENIE/GENIE.md/PREW3_SHADOW｜Claude Code｜legacy=ON
- **原定位**：`BODY-09B:2006`；真 Cell Id `CELL-d69adf2f1965`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L209，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT。
- input→behavior→typed output：source-bound input→原SWOF版本化GENIE reference/schema與Owner關聯讀回→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Claude Code/GENIE/GENIE.md/PREW3_SHADOW/ON：Claude Code當期原loader＋乾淨session驗原SWOF版本化GENIE reference/schema與Owner關聯讀回；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒任意GENIE.md冒正式生成或部署；若raw.host不等於Claude Code或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `d69adf2f1965` 的唯讀 Cell 產品設計候選。

### CELL-1ef60244801f｜GENIE/GENIE.md/PREW3_SHADOW｜Claude Code｜legacy=OFF
- **原定位**：`BODY-09B:2017`；真 Cell Id `CELL-1ef60244801f`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L210，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT。
- input→behavior→typed output：source-bound input→原SWOF版本化GENIE reference/schema與Owner關聯讀回→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Claude Code/GENIE/GENIE.md/PREW3_SHADOW/OFF：Claude Code當期原loader＋乾淨session驗原SWOF版本化GENIE reference/schema與Owner關聯讀回；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒任意GENIE.md冒正式生成或部署；若raw.host不等於Claude Code或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `1ef60244801f` 的唯讀 Cell 產品設計候選。

### CELL-98d011df32e5｜GENIE/GENIE.md/PREW3_SHADOW｜DeepSeek Harness｜legacy=ON
- **原定位**：`BODY-09B:2028`；真 Cell Id `CELL-98d011df32e5`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L211，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT。
- input→behavior→typed output：source-bound input→原SWOF版本化GENIE reference/schema與Owner關聯讀回→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：DeepSeek Harness/GENIE/GENIE.md/PREW3_SHADOW/ON：實際Harness adapter/capability reader；API_ONLY不能充loader驗原SWOF版本化GENIE reference/schema與Owner關聯讀回；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒任意GENIE.md冒正式生成或部署；若raw.host不等於DeepSeek Harness或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `98d011df32e5` 的唯讀 Cell 產品設計候選。

### CELL-880fcebbf48e｜GENIE/GENIE.md/PREW3_SHADOW｜DeepSeek Harness｜legacy=OFF
- **原定位**：`BODY-09B:2039`；真 Cell Id `CELL-880fcebbf48e`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L212，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT。
- input→behavior→typed output：source-bound input→原SWOF版本化GENIE reference/schema與Owner關聯讀回→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：DeepSeek Harness/GENIE/GENIE.md/PREW3_SHADOW/OFF：實際Harness adapter/capability reader；API_ONLY不能充loader驗原SWOF版本化GENIE reference/schema與Owner關聯讀回；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒任意GENIE.md冒正式生成或部署；若raw.host不等於DeepSeek Harness或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `880fcebbf48e` 的唯讀 Cell 產品設計候選。

### CELL-a8a335dada5e｜GENIE/GENIE.md/SWOF_CONNECTED｜Hermes Agent｜legacy=ON
- **原定位**：`BODY-09B:2050`；真 Cell Id `CELL-a8a335dada5e`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L213，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT。
- input→behavior→typed output：source-bound input→原SWOF版本化GENIE reference/schema與Owner關聯讀回→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Hermes Agent/GENIE/GENIE.md/SWOF_CONNECTED/ON：原Hermes tool/skill loader與worker fresh PID驗原SWOF版本化GENIE reference/schema與Owner關聯讀回；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒任意GENIE.md冒正式生成或部署；若raw.host不等於Hermes Agent或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `a8a335dada5e` 的唯讀 Cell 產品設計候選。

### CELL-f9d246f739b8｜GENIE/GENIE.md/SWOF_CONNECTED｜Hermes Agent｜legacy=OFF
- **原定位**：`BODY-09B:2061`；真 Cell Id `CELL-f9d246f739b8`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L214，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT。
- input→behavior→typed output：source-bound input→原SWOF版本化GENIE reference/schema與Owner關聯讀回→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Hermes Agent/GENIE/GENIE.md/SWOF_CONNECTED/OFF：原Hermes tool/skill loader與worker fresh PID驗原SWOF版本化GENIE reference/schema與Owner關聯讀回；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒任意GENIE.md冒正式生成或部署；若raw.host不等於Hermes Agent或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `f9d246f739b8` 的唯讀 Cell 產品設計候選。

### CELL-8ed9eebf58e7｜GENIE/GENIE.md/SWOF_CONNECTED｜Codex｜legacy=ON
- **原定位**：`BODY-09B:2072`；真 Cell Id `CELL-8ed9eebf58e7`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L215，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT。
- input→behavior→typed output：source-bound input→原SWOF版本化GENIE reference/schema與Owner關聯讀回→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Codex/GENIE/GENIE.md/SWOF_CONNECTED/ON：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗原SWOF版本化GENIE reference/schema與Owner關聯讀回；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒任意GENIE.md冒正式生成或部署；若raw.host不等於Codex或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `8ed9eebf58e7` 的唯讀 Cell 產品設計候選。

### CELL-b6fc7bd2585b｜GENIE/GENIE.md/SWOF_CONNECTED｜Codex｜legacy=OFF
- **原定位**：`BODY-09B:2083`；真 Cell Id `CELL-b6fc7bd2585b`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L216，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT。
- input→behavior→typed output：source-bound input→原SWOF版本化GENIE reference/schema與Owner關聯讀回→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Codex/GENIE/GENIE.md/SWOF_CONNECTED/OFF：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗原SWOF版本化GENIE reference/schema與Owner關聯讀回；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒任意GENIE.md冒正式生成或部署；若raw.host不等於Codex或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `b6fc7bd2585b` 的唯讀 Cell 產品設計候選。

### CELL-ea0c6cc43029｜GENIE/GENIE.md/SWOF_CONNECTED｜Claude Code｜legacy=ON
- **原定位**：`BODY-09B:2094`；真 Cell Id `CELL-ea0c6cc43029`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L217，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT。
- input→behavior→typed output：source-bound input→原SWOF版本化GENIE reference/schema與Owner關聯讀回→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Claude Code/GENIE/GENIE.md/SWOF_CONNECTED/ON：Claude Code當期原loader＋乾淨session驗原SWOF版本化GENIE reference/schema與Owner關聯讀回；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒任意GENIE.md冒正式生成或部署；若raw.host不等於Claude Code或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `ea0c6cc43029` 的唯讀 Cell 產品設計候選。

### CELL-425204fe1c0f｜GENIE/GENIE.md/SWOF_CONNECTED｜Claude Code｜legacy=OFF
- **原定位**：`BODY-09B:2105`；真 Cell Id `CELL-425204fe1c0f`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L218，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT。
- input→behavior→typed output：source-bound input→原SWOF版本化GENIE reference/schema與Owner關聯讀回→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Claude Code/GENIE/GENIE.md/SWOF_CONNECTED/OFF：Claude Code當期原loader＋乾淨session驗原SWOF版本化GENIE reference/schema與Owner關聯讀回；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒任意GENIE.md冒正式生成或部署；若raw.host不等於Claude Code或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `425204fe1c0f` 的唯讀 Cell 產品設計候選。

### CELL-fc762041aa9d｜GENIE/GENIE.md/SWOF_CONNECTED｜DeepSeek Harness｜legacy=ON
- **原定位**：`BODY-09B:2116`；真 Cell Id `CELL-fc762041aa9d`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L219，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT。
- input→behavior→typed output：source-bound input→原SWOF版本化GENIE reference/schema與Owner關聯讀回→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：DeepSeek Harness/GENIE/GENIE.md/SWOF_CONNECTED/ON：實際Harness adapter/capability reader；API_ONLY不能充loader驗原SWOF版本化GENIE reference/schema與Owner關聯讀回；provider_off=UNBOUND_OWNER_ACK_REQUIRED：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒任意GENIE.md冒正式生成或部署；若raw.host不等於DeepSeek Harness或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

- **R2 生效隔離**：raw_token=`ON`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `fc762041aa9d` 的唯讀 Cell 產品設計候選。

### CELL-5370fdd74e46｜GENIE/GENIE.md/SWOF_CONNECTED｜DeepSeek Harness｜legacy=OFF
- **原定位**：`BODY-09B:2127`；真 Cell Id `CELL-5370fdd74e46`（不得借其他 Host/Mode 之 receipt）。
- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L220，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT。
- input→behavior→typed output：source-bound input→原SWOF版本化GENIE reference/schema與Owner關聯讀回→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：DeepSeek Harness/GENIE/GENIE.md/SWOF_CONNECTED/OFF：實際Harness adapter/capability reader；API_ONLY不能充loader驗原SWOF版本化GENIE reference/schema與Owner關聯讀回；provider_off=UNBOUND_OWNER_ACK_REQUIRED：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒任意GENIE.md冒正式生成或部署；若raw.host不等於DeepSeek Harness或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。


---


## R2 現行／歷史 Reader 隔離

本檔此處以上及本輪新增 R2 小節為**唯一當期整合設計 Reader**；前版 Revision2 已位元組保存於證據 ZIP `02_EVIDENCE_AUDIT_APPENDICES/_superseded_2026-10-30_r1/09B_KIND_MODE_HOST_192_R1_REVISION2_VERBATIM.md`（SHA256 `514f580ed8f2b9a31d685bf3d2c8ff653a843dd11c4051f920d0018b42727761`）。歷史條位不得由 Parser 以同號 ID 當 CURRENT，也不得用歷史 HOLD 覆寫本輪受影修補。原 Domain Writer 法位不變。

- **R2 生效隔離**：raw_token=`OFF`；semantic_mapping_status=`UNBOUND_OWNER_CONFLICT`；host_provider_off_boolean=`null`；owner_ack_version=`null`；`runtime_effect_allowed=false`，不得使用同段舊 candidate 規則產生真正 Provider 呼叫；只能產 `5370fdd74e46` 的唯讀 Cell 產品設計候選。

## R2 四 Host 衝突的完整受影遷移候選（48/48，不覆寫原 CellID）


### PROPOSAL-CHATGPT-2738990e2c09｜`CLI_TOOL` × `STANDALONE` × legacy `ON`
- 源身份：`CELL-2738990e2c09` / `DeepSeek Harness`（保留，不改名）；產品要求另為 `ChatGPT`，本 ID **尚非 Original 192 Cell**。
- 原 Reader/Owner：SBL Product Owner＋ChatGPT Host Owner；input=原 ProductKind/Mode/SourceSHA/Token + HostCaps/Version/Effect；host_adapter=ChatGPT API-only under supported surface（未證實的 OS loader 原封不動 NOFIT）。
- 正例候選：只做唯讀 Source/Goal→ChatGPT supported UX result 或已證 Host SDK handler，記 requested Kind/Mode/ProviderOnOff 未核定；True Host Loader 功能等實機。
- 負例：假造 ChatGPT 擁有 DeepSeek 進程／host runner，或用 `CELL-2738990e2c09` 的 Raw 當 ChatGPT → `HOST_IDENTITY_DRIFT`；`PREW3_SHADOW` 禁 World Write。
- 退出：Original ID untouched；未有核定版本/HostCaps/ProviderToken 就 `CR-HOST-192` 下 `MIGRATION_HOLD`；產品承諾仍列。

### PROPOSAL-CHATGPT-3869542dc2f7｜`CLI_TOOL` × `STANDALONE` × legacy `OFF`
- 源身份：`CELL-3869542dc2f7` / `DeepSeek Harness`（保留，不改名）；產品要求另為 `ChatGPT`，本 ID **尚非 Original 192 Cell**。
- 原 Reader/Owner：SBL Product Owner＋ChatGPT Host Owner；input=原 ProductKind/Mode/SourceSHA/Token + HostCaps/Version/Effect；host_adapter=ChatGPT API-only under supported surface（未證實的 OS loader 原封不動 NOFIT）。
- 正例候選：只做唯讀 Source/Goal→ChatGPT supported UX result 或已證 Host SDK handler，記 requested Kind/Mode/ProviderOnOff 未核定；True Host Loader 功能等實機。
- 負例：假造 ChatGPT 擁有 DeepSeek 進程／host runner，或用 `CELL-3869542dc2f7` 的 Raw 當 ChatGPT → `HOST_IDENTITY_DRIFT`；`PREW3_SHADOW` 禁 World Write。
- 退出：Original ID untouched；未有核定版本/HostCaps/ProviderToken 就 `CR-HOST-192` 下 `MIGRATION_HOLD`；產品承諾仍列。

### PROPOSAL-CHATGPT-e78d746c7bf7｜`CLI_TOOL` × `PREW3_SHADOW` × legacy `ON`
- 源身份：`CELL-e78d746c7bf7` / `DeepSeek Harness`（保留，不改名）；產品要求另為 `ChatGPT`，本 ID **尚非 Original 192 Cell**。
- 原 Reader/Owner：SBL Product Owner＋ChatGPT Host Owner；input=原 ProductKind/Mode/SourceSHA/Token + HostCaps/Version/Effect；host_adapter=ChatGPT API-only under supported surface（未證實的 OS loader 原封不動 NOFIT）。
- 正例候選：只做唯讀 Source/Goal→ChatGPT supported UX result 或已證 Host SDK handler，記 requested Kind/Mode/ProviderOnOff 未核定；True Host Loader 功能等實機。
- 負例：假造 ChatGPT 擁有 DeepSeek 進程／host runner，或用 `CELL-e78d746c7bf7` 的 Raw 當 ChatGPT → `HOST_IDENTITY_DRIFT`；`PREW3_SHADOW` 禁 World Write。
- 退出：Original ID untouched；未有核定版本/HostCaps/ProviderToken 就 `CR-HOST-192` 下 `MIGRATION_HOLD`；產品承諾仍列。

### PROPOSAL-CHATGPT-fabd535f6b8d｜`CLI_TOOL` × `PREW3_SHADOW` × legacy `OFF`
- 源身份：`CELL-fabd535f6b8d` / `DeepSeek Harness`（保留，不改名）；產品要求另為 `ChatGPT`，本 ID **尚非 Original 192 Cell**。
- 原 Reader/Owner：SBL Product Owner＋ChatGPT Host Owner；input=原 ProductKind/Mode/SourceSHA/Token + HostCaps/Version/Effect；host_adapter=ChatGPT API-only under supported surface（未證實的 OS loader 原封不動 NOFIT）。
- 正例候選：只做唯讀 Source/Goal→ChatGPT supported UX result 或已證 Host SDK handler，記 requested Kind/Mode/ProviderOnOff 未核定；True Host Loader 功能等實機。
- 負例：假造 ChatGPT 擁有 DeepSeek 進程／host runner，或用 `CELL-fabd535f6b8d` 的 Raw 當 ChatGPT → `HOST_IDENTITY_DRIFT`；`PREW3_SHADOW` 禁 World Write。
- 退出：Original ID untouched；未有核定版本/HostCaps/ProviderToken 就 `CR-HOST-192` 下 `MIGRATION_HOLD`；產品承諾仍列。

### PROPOSAL-CHATGPT-f5c5147c11c1｜`CLI_TOOL` × `SWOF_CONNECTED` × legacy `ON`
- 源身份：`CELL-f5c5147c11c1` / `DeepSeek Harness`（保留，不改名）；產品要求另為 `ChatGPT`，本 ID **尚非 Original 192 Cell**。
- 原 Reader/Owner：SBL Product Owner＋ChatGPT Host Owner；input=原 ProductKind/Mode/SourceSHA/Token + HostCaps/Version/Effect；host_adapter=ChatGPT API-only under supported surface（未證實的 OS loader 原封不動 NOFIT）。
- 正例候選：只做唯讀 Source/Goal→ChatGPT supported UX result 或已證 Host SDK handler，記 requested Kind/Mode/ProviderOnOff 未核定；True Host Loader 功能等實機。
- 負例：假造 ChatGPT 擁有 DeepSeek 進程／host runner，或用 `CELL-f5c5147c11c1` 的 Raw 當 ChatGPT → `HOST_IDENTITY_DRIFT`；`PREW3_SHADOW` 禁 World Write。
- 退出：Original ID untouched；未有核定版本/HostCaps/ProviderToken 就 `CR-HOST-192` 下 `MIGRATION_HOLD`；產品承諾仍列。

### PROPOSAL-CHATGPT-5bd80e6cf274｜`CLI_TOOL` × `SWOF_CONNECTED` × legacy `OFF`
- 源身份：`CELL-5bd80e6cf274` / `DeepSeek Harness`（保留，不改名）；產品要求另為 `ChatGPT`，本 ID **尚非 Original 192 Cell**。
- 原 Reader/Owner：SBL Product Owner＋ChatGPT Host Owner；input=原 ProductKind/Mode/SourceSHA/Token + HostCaps/Version/Effect；host_adapter=ChatGPT API-only under supported surface（未證實的 OS loader 原封不動 NOFIT）。
- 正例候選：只做唯讀 Source/Goal→ChatGPT supported UX result 或已證 Host SDK handler，記 requested Kind/Mode/ProviderOnOff 未核定；True Host Loader 功能等實機。
- 負例：假造 ChatGPT 擁有 DeepSeek 進程／host runner，或用 `CELL-5bd80e6cf274` 的 Raw 當 ChatGPT → `HOST_IDENTITY_DRIFT`；`PREW3_SHADOW` 禁 World Write。
- 退出：Original ID untouched；未有核定版本/HostCaps/ProviderToken 就 `CR-HOST-192` 下 `MIGRATION_HOLD`；產品承諾仍列。

### PROPOSAL-CHATGPT-cb678bd208a8｜`AGENT_SKILL` × `STANDALONE` × legacy `ON`
- 源身份：`CELL-cb678bd208a8` / `DeepSeek Harness`（保留，不改名）；產品要求另為 `ChatGPT`，本 ID **尚非 Original 192 Cell**。
- 原 Reader/Owner：SBL Product Owner＋ChatGPT Host Owner；input=原 ProductKind/Mode/SourceSHA/Token + HostCaps/Version/Effect；host_adapter=ChatGPT API-only under supported surface（未證實的 OS loader 原封不動 NOFIT）。
- 正例候選：只做唯讀 Source/Goal→ChatGPT supported UX result 或已證 Host SDK handler，記 requested Kind/Mode/ProviderOnOff 未核定；True Host Loader 功能等實機。
- 負例：假造 ChatGPT 擁有 DeepSeek 進程／host runner，或用 `CELL-cb678bd208a8` 的 Raw 當 ChatGPT → `HOST_IDENTITY_DRIFT`；`PREW3_SHADOW` 禁 World Write。
- 退出：Original ID untouched；未有核定版本/HostCaps/ProviderToken 就 `CR-HOST-192` 下 `MIGRATION_HOLD`；產品承諾仍列。

### PROPOSAL-CHATGPT-6e1c0fb8d36b｜`AGENT_SKILL` × `STANDALONE` × legacy `OFF`
- 源身份：`CELL-6e1c0fb8d36b` / `DeepSeek Harness`（保留，不改名）；產品要求另為 `ChatGPT`，本 ID **尚非 Original 192 Cell**。
- 原 Reader/Owner：SBL Product Owner＋ChatGPT Host Owner；input=原 ProductKind/Mode/SourceSHA/Token + HostCaps/Version/Effect；host_adapter=ChatGPT API-only under supported surface（未證實的 OS loader 原封不動 NOFIT）。
- 正例候選：只做唯讀 Source/Goal→ChatGPT supported UX result 或已證 Host SDK handler，記 requested Kind/Mode/ProviderOnOff 未核定；True Host Loader 功能等實機。
- 負例：假造 ChatGPT 擁有 DeepSeek 進程／host runner，或用 `CELL-6e1c0fb8d36b` 的 Raw 當 ChatGPT → `HOST_IDENTITY_DRIFT`；`PREW3_SHADOW` 禁 World Write。
- 退出：Original ID untouched；未有核定版本/HostCaps/ProviderToken 就 `CR-HOST-192` 下 `MIGRATION_HOLD`；產品承諾仍列。

### PROPOSAL-CHATGPT-ae3081300a06｜`AGENT_SKILL` × `PREW3_SHADOW` × legacy `ON`
- 源身份：`CELL-ae3081300a06` / `DeepSeek Harness`（保留，不改名）；產品要求另為 `ChatGPT`，本 ID **尚非 Original 192 Cell**。
- 原 Reader/Owner：SBL Product Owner＋ChatGPT Host Owner；input=原 ProductKind/Mode/SourceSHA/Token + HostCaps/Version/Effect；host_adapter=ChatGPT API-only under supported surface（未證實的 OS loader 原封不動 NOFIT）。
- 正例候選：只做唯讀 Source/Goal→ChatGPT supported UX result 或已證 Host SDK handler，記 requested Kind/Mode/ProviderOnOff 未核定；True Host Loader 功能等實機。
- 負例：假造 ChatGPT 擁有 DeepSeek 進程／host runner，或用 `CELL-ae3081300a06` 的 Raw 當 ChatGPT → `HOST_IDENTITY_DRIFT`；`PREW3_SHADOW` 禁 World Write。
- 退出：Original ID untouched；未有核定版本/HostCaps/ProviderToken 就 `CR-HOST-192` 下 `MIGRATION_HOLD`；產品承諾仍列。

### PROPOSAL-CHATGPT-79aa1ca6c95f｜`AGENT_SKILL` × `PREW3_SHADOW` × legacy `OFF`
- 源身份：`CELL-79aa1ca6c95f` / `DeepSeek Harness`（保留，不改名）；產品要求另為 `ChatGPT`，本 ID **尚非 Original 192 Cell**。
- 原 Reader/Owner：SBL Product Owner＋ChatGPT Host Owner；input=原 ProductKind/Mode/SourceSHA/Token + HostCaps/Version/Effect；host_adapter=ChatGPT API-only under supported surface（未證實的 OS loader 原封不動 NOFIT）。
- 正例候選：只做唯讀 Source/Goal→ChatGPT supported UX result 或已證 Host SDK handler，記 requested Kind/Mode/ProviderOnOff 未核定；True Host Loader 功能等實機。
- 負例：假造 ChatGPT 擁有 DeepSeek 進程／host runner，或用 `CELL-79aa1ca6c95f` 的 Raw 當 ChatGPT → `HOST_IDENTITY_DRIFT`；`PREW3_SHADOW` 禁 World Write。
- 退出：Original ID untouched；未有核定版本/HostCaps/ProviderToken 就 `CR-HOST-192` 下 `MIGRATION_HOLD`；產品承諾仍列。

### PROPOSAL-CHATGPT-48757186c510｜`AGENT_SKILL` × `SWOF_CONNECTED` × legacy `ON`
- 源身份：`CELL-48757186c510` / `DeepSeek Harness`（保留，不改名）；產品要求另為 `ChatGPT`，本 ID **尚非 Original 192 Cell**。
- 原 Reader/Owner：SBL Product Owner＋ChatGPT Host Owner；input=原 ProductKind/Mode/SourceSHA/Token + HostCaps/Version/Effect；host_adapter=ChatGPT API-only under supported surface（未證實的 OS loader 原封不動 NOFIT）。
- 正例候選：只做唯讀 Source/Goal→ChatGPT supported UX result 或已證 Host SDK handler，記 requested Kind/Mode/ProviderOnOff 未核定；True Host Loader 功能等實機。
- 負例：假造 ChatGPT 擁有 DeepSeek 進程／host runner，或用 `CELL-48757186c510` 的 Raw 當 ChatGPT → `HOST_IDENTITY_DRIFT`；`PREW3_SHADOW` 禁 World Write。
- 退出：Original ID untouched；未有核定版本/HostCaps/ProviderToken 就 `CR-HOST-192` 下 `MIGRATION_HOLD`；產品承諾仍列。

### PROPOSAL-CHATGPT-9df05458d74f｜`AGENT_SKILL` × `SWOF_CONNECTED` × legacy `OFF`
- 源身份：`CELL-9df05458d74f` / `DeepSeek Harness`（保留，不改名）；產品要求另為 `ChatGPT`，本 ID **尚非 Original 192 Cell**。
- 原 Reader/Owner：SBL Product Owner＋ChatGPT Host Owner；input=原 ProductKind/Mode/SourceSHA/Token + HostCaps/Version/Effect；host_adapter=ChatGPT API-only under supported surface（未證實的 OS loader 原封不動 NOFIT）。
- 正例候選：只做唯讀 Source/Goal→ChatGPT supported UX result 或已證 Host SDK handler，記 requested Kind/Mode/ProviderOnOff 未核定；True Host Loader 功能等實機。
- 負例：假造 ChatGPT 擁有 DeepSeek 進程／host runner，或用 `CELL-9df05458d74f` 的 Raw 當 ChatGPT → `HOST_IDENTITY_DRIFT`；`PREW3_SHADOW` 禁 World Write。
- 退出：Original ID untouched；未有核定版本/HostCaps/ProviderToken 就 `CR-HOST-192` 下 `MIGRATION_HOLD`；產品承諾仍列。

### PROPOSAL-CHATGPT-f0a4964020d6｜`SIMPLE_AGENT` × `STANDALONE` × legacy `ON`
- 源身份：`CELL-f0a4964020d6` / `DeepSeek Harness`（保留，不改名）；產品要求另為 `ChatGPT`，本 ID **尚非 Original 192 Cell**。
- 原 Reader/Owner：SBL Product Owner＋ChatGPT Host Owner；input=原 ProductKind/Mode/SourceSHA/Token + HostCaps/Version/Effect；host_adapter=ChatGPT API-only under supported surface（未證實的 OS loader 原封不動 NOFIT）。
- 正例候選：只做唯讀 Source/Goal→ChatGPT supported UX result 或已證 Host SDK handler，記 requested Kind/Mode/ProviderOnOff 未核定；True Host Loader 功能等實機。
- 負例：假造 ChatGPT 擁有 DeepSeek 進程／host runner，或用 `CELL-f0a4964020d6` 的 Raw 當 ChatGPT → `HOST_IDENTITY_DRIFT`；`PREW3_SHADOW` 禁 World Write。
- 退出：Original ID untouched；未有核定版本/HostCaps/ProviderToken 就 `CR-HOST-192` 下 `MIGRATION_HOLD`；產品承諾仍列。

### PROPOSAL-CHATGPT-8ba7cd2138c5｜`SIMPLE_AGENT` × `STANDALONE` × legacy `OFF`
- 源身份：`CELL-8ba7cd2138c5` / `DeepSeek Harness`（保留，不改名）；產品要求另為 `ChatGPT`，本 ID **尚非 Original 192 Cell**。
- 原 Reader/Owner：SBL Product Owner＋ChatGPT Host Owner；input=原 ProductKind/Mode/SourceSHA/Token + HostCaps/Version/Effect；host_adapter=ChatGPT API-only under supported surface（未證實的 OS loader 原封不動 NOFIT）。
- 正例候選：只做唯讀 Source/Goal→ChatGPT supported UX result 或已證 Host SDK handler，記 requested Kind/Mode/ProviderOnOff 未核定；True Host Loader 功能等實機。
- 負例：假造 ChatGPT 擁有 DeepSeek 進程／host runner，或用 `CELL-8ba7cd2138c5` 的 Raw 當 ChatGPT → `HOST_IDENTITY_DRIFT`；`PREW3_SHADOW` 禁 World Write。
- 退出：Original ID untouched；未有核定版本/HostCaps/ProviderToken 就 `CR-HOST-192` 下 `MIGRATION_HOLD`；產品承諾仍列。

### PROPOSAL-CHATGPT-84fa01909649｜`SIMPLE_AGENT` × `PREW3_SHADOW` × legacy `ON`
- 源身份：`CELL-84fa01909649` / `DeepSeek Harness`（保留，不改名）；產品要求另為 `ChatGPT`，本 ID **尚非 Original 192 Cell**。
- 原 Reader/Owner：SBL Product Owner＋ChatGPT Host Owner；input=原 ProductKind/Mode/SourceSHA/Token + HostCaps/Version/Effect；host_adapter=ChatGPT API-only under supported surface（未證實的 OS loader 原封不動 NOFIT）。
- 正例候選：只做唯讀 Source/Goal→ChatGPT supported UX result 或已證 Host SDK handler，記 requested Kind/Mode/ProviderOnOff 未核定；True Host Loader 功能等實機。
- 負例：假造 ChatGPT 擁有 DeepSeek 進程／host runner，或用 `CELL-84fa01909649` 的 Raw 當 ChatGPT → `HOST_IDENTITY_DRIFT`；`PREW3_SHADOW` 禁 World Write。
- 退出：Original ID untouched；未有核定版本/HostCaps/ProviderToken 就 `CR-HOST-192` 下 `MIGRATION_HOLD`；產品承諾仍列。

### PROPOSAL-CHATGPT-f77b24e32aaa｜`SIMPLE_AGENT` × `PREW3_SHADOW` × legacy `OFF`
- 源身份：`CELL-f77b24e32aaa` / `DeepSeek Harness`（保留，不改名）；產品要求另為 `ChatGPT`，本 ID **尚非 Original 192 Cell**。
- 原 Reader/Owner：SBL Product Owner＋ChatGPT Host Owner；input=原 ProductKind/Mode/SourceSHA/Token + HostCaps/Version/Effect；host_adapter=ChatGPT API-only under supported surface（未證實的 OS loader 原封不動 NOFIT）。
- 正例候選：只做唯讀 Source/Goal→ChatGPT supported UX result 或已證 Host SDK handler，記 requested Kind/Mode/ProviderOnOff 未核定；True Host Loader 功能等實機。
- 負例：假造 ChatGPT 擁有 DeepSeek 進程／host runner，或用 `CELL-f77b24e32aaa` 的 Raw 當 ChatGPT → `HOST_IDENTITY_DRIFT`；`PREW3_SHADOW` 禁 World Write。
- 退出：Original ID untouched；未有核定版本/HostCaps/ProviderToken 就 `CR-HOST-192` 下 `MIGRATION_HOLD`；產品承諾仍列。

### PROPOSAL-CHATGPT-09c21bb6612b｜`SIMPLE_AGENT` × `SWOF_CONNECTED` × legacy `ON`
- 源身份：`CELL-09c21bb6612b` / `DeepSeek Harness`（保留，不改名）；產品要求另為 `ChatGPT`，本 ID **尚非 Original 192 Cell**。
- 原 Reader/Owner：SBL Product Owner＋ChatGPT Host Owner；input=原 ProductKind/Mode/SourceSHA/Token + HostCaps/Version/Effect；host_adapter=ChatGPT API-only under supported surface（未證實的 OS loader 原封不動 NOFIT）。
- 正例候選：只做唯讀 Source/Goal→ChatGPT supported UX result 或已證 Host SDK handler，記 requested Kind/Mode/ProviderOnOff 未核定；True Host Loader 功能等實機。
- 負例：假造 ChatGPT 擁有 DeepSeek 進程／host runner，或用 `CELL-09c21bb6612b` 的 Raw 當 ChatGPT → `HOST_IDENTITY_DRIFT`；`PREW3_SHADOW` 禁 World Write。
- 退出：Original ID untouched；未有核定版本/HostCaps/ProviderToken 就 `CR-HOST-192` 下 `MIGRATION_HOLD`；產品承諾仍列。

### PROPOSAL-CHATGPT-9be3a648f57b｜`SIMPLE_AGENT` × `SWOF_CONNECTED` × legacy `OFF`
- 源身份：`CELL-9be3a648f57b` / `DeepSeek Harness`（保留，不改名）；產品要求另為 `ChatGPT`，本 ID **尚非 Original 192 Cell**。
- 原 Reader/Owner：SBL Product Owner＋ChatGPT Host Owner；input=原 ProductKind/Mode/SourceSHA/Token + HostCaps/Version/Effect；host_adapter=ChatGPT API-only under supported surface（未證實的 OS loader 原封不動 NOFIT）。
- 正例候選：只做唯讀 Source/Goal→ChatGPT supported UX result 或已證 Host SDK handler，記 requested Kind/Mode/ProviderOnOff 未核定；True Host Loader 功能等實機。
- 負例：假造 ChatGPT 擁有 DeepSeek 進程／host runner，或用 `CELL-9be3a648f57b` 的 Raw 當 ChatGPT → `HOST_IDENTITY_DRIFT`；`PREW3_SHADOW` 禁 World Write。
- 退出：Original ID untouched；未有核定版本/HostCaps/ProviderToken 就 `CR-HOST-192` 下 `MIGRATION_HOLD`；產品承諾仍列。

### PROPOSAL-CHATGPT-ecca30d3d545｜`PLUGIN` × `STANDALONE` × legacy `ON`
- 源身份：`CELL-ecca30d3d545` / `DeepSeek Harness`（保留，不改名）；產品要求另為 `ChatGPT`，本 ID **尚非 Original 192 Cell**。
- 原 Reader/Owner：SBL Product Owner＋ChatGPT Host Owner；input=原 ProductKind/Mode/SourceSHA/Token + HostCaps/Version/Effect；host_adapter=ChatGPT API-only under supported surface（未證實的 OS loader 原封不動 NOFIT）。
- 正例候選：只做唯讀 Source/Goal→ChatGPT supported UX result 或已證 Host SDK handler，記 requested Kind/Mode/ProviderOnOff 未核定；True Host Loader 功能等實機。
- 負例：假造 ChatGPT 擁有 DeepSeek 進程／host runner，或用 `CELL-ecca30d3d545` 的 Raw 當 ChatGPT → `HOST_IDENTITY_DRIFT`；`PREW3_SHADOW` 禁 World Write。
- 退出：Original ID untouched；未有核定版本/HostCaps/ProviderToken 就 `CR-HOST-192` 下 `MIGRATION_HOLD`；產品承諾仍列。

### PROPOSAL-CHATGPT-6acbaf567779｜`PLUGIN` × `STANDALONE` × legacy `OFF`
- 源身份：`CELL-6acbaf567779` / `DeepSeek Harness`（保留，不改名）；產品要求另為 `ChatGPT`，本 ID **尚非 Original 192 Cell**。
- 原 Reader/Owner：SBL Product Owner＋ChatGPT Host Owner；input=原 ProductKind/Mode/SourceSHA/Token + HostCaps/Version/Effect；host_adapter=ChatGPT API-only under supported surface（未證實的 OS loader 原封不動 NOFIT）。
- 正例候選：只做唯讀 Source/Goal→ChatGPT supported UX result 或已證 Host SDK handler，記 requested Kind/Mode/ProviderOnOff 未核定；True Host Loader 功能等實機。
- 負例：假造 ChatGPT 擁有 DeepSeek 進程／host runner，或用 `CELL-6acbaf567779` 的 Raw 當 ChatGPT → `HOST_IDENTITY_DRIFT`；`PREW3_SHADOW` 禁 World Write。
- 退出：Original ID untouched；未有核定版本/HostCaps/ProviderToken 就 `CR-HOST-192` 下 `MIGRATION_HOLD`；產品承諾仍列。

### PROPOSAL-CHATGPT-bc4919027c0c｜`PLUGIN` × `PREW3_SHADOW` × legacy `ON`
- 源身份：`CELL-bc4919027c0c` / `DeepSeek Harness`（保留，不改名）；產品要求另為 `ChatGPT`，本 ID **尚非 Original 192 Cell**。
- 原 Reader/Owner：SBL Product Owner＋ChatGPT Host Owner；input=原 ProductKind/Mode/SourceSHA/Token + HostCaps/Version/Effect；host_adapter=ChatGPT API-only under supported surface（未證實的 OS loader 原封不動 NOFIT）。
- 正例候選：只做唯讀 Source/Goal→ChatGPT supported UX result 或已證 Host SDK handler，記 requested Kind/Mode/ProviderOnOff 未核定；True Host Loader 功能等實機。
- 負例：假造 ChatGPT 擁有 DeepSeek 進程／host runner，或用 `CELL-bc4919027c0c` 的 Raw 當 ChatGPT → `HOST_IDENTITY_DRIFT`；`PREW3_SHADOW` 禁 World Write。
- 退出：Original ID untouched；未有核定版本/HostCaps/ProviderToken 就 `CR-HOST-192` 下 `MIGRATION_HOLD`；產品承諾仍列。

### PROPOSAL-CHATGPT-06bbd5e5ecb2｜`PLUGIN` × `PREW3_SHADOW` × legacy `OFF`
- 源身份：`CELL-06bbd5e5ecb2` / `DeepSeek Harness`（保留，不改名）；產品要求另為 `ChatGPT`，本 ID **尚非 Original 192 Cell**。
- 原 Reader/Owner：SBL Product Owner＋ChatGPT Host Owner；input=原 ProductKind/Mode/SourceSHA/Token + HostCaps/Version/Effect；host_adapter=ChatGPT API-only under supported surface（未證實的 OS loader 原封不動 NOFIT）。
- 正例候選：只做唯讀 Source/Goal→ChatGPT supported UX result 或已證 Host SDK handler，記 requested Kind/Mode/ProviderOnOff 未核定；True Host Loader 功能等實機。
- 負例：假造 ChatGPT 擁有 DeepSeek 進程／host runner，或用 `CELL-06bbd5e5ecb2` 的 Raw 當 ChatGPT → `HOST_IDENTITY_DRIFT`；`PREW3_SHADOW` 禁 World Write。
- 退出：Original ID untouched；未有核定版本/HostCaps/ProviderToken 就 `CR-HOST-192` 下 `MIGRATION_HOLD`；產品承諾仍列。

### PROPOSAL-CHATGPT-8bf8d2ec3581｜`PLUGIN` × `SWOF_CONNECTED` × legacy `ON`
- 源身份：`CELL-8bf8d2ec3581` / `DeepSeek Harness`（保留，不改名）；產品要求另為 `ChatGPT`，本 ID **尚非 Original 192 Cell**。
- 原 Reader/Owner：SBL Product Owner＋ChatGPT Host Owner；input=原 ProductKind/Mode/SourceSHA/Token + HostCaps/Version/Effect；host_adapter=ChatGPT API-only under supported surface（未證實的 OS loader 原封不動 NOFIT）。
- 正例候選：只做唯讀 Source/Goal→ChatGPT supported UX result 或已證 Host SDK handler，記 requested Kind/Mode/ProviderOnOff 未核定；True Host Loader 功能等實機。
- 負例：假造 ChatGPT 擁有 DeepSeek 進程／host runner，或用 `CELL-8bf8d2ec3581` 的 Raw 當 ChatGPT → `HOST_IDENTITY_DRIFT`；`PREW3_SHADOW` 禁 World Write。
- 退出：Original ID untouched；未有核定版本/HostCaps/ProviderToken 就 `CR-HOST-192` 下 `MIGRATION_HOLD`；產品承諾仍列。

### PROPOSAL-CHATGPT-085bc8fd7622｜`PLUGIN` × `SWOF_CONNECTED` × legacy `OFF`
- 源身份：`CELL-085bc8fd7622` / `DeepSeek Harness`（保留，不改名）；產品要求另為 `ChatGPT`，本 ID **尚非 Original 192 Cell**。
- 原 Reader/Owner：SBL Product Owner＋ChatGPT Host Owner；input=原 ProductKind/Mode/SourceSHA/Token + HostCaps/Version/Effect；host_adapter=ChatGPT API-only under supported surface（未證實的 OS loader 原封不動 NOFIT）。
- 正例候選：只做唯讀 Source/Goal→ChatGPT supported UX result 或已證 Host SDK handler，記 requested Kind/Mode/ProviderOnOff 未核定；True Host Loader 功能等實機。
- 負例：假造 ChatGPT 擁有 DeepSeek 進程／host runner，或用 `CELL-085bc8fd7622` 的 Raw 當 ChatGPT → `HOST_IDENTITY_DRIFT`；`PREW3_SHADOW` 禁 World Write。
- 退出：Original ID untouched；未有核定版本/HostCaps/ProviderToken 就 `CR-HOST-192` 下 `MIGRATION_HOLD`；產品承諾仍列。

### PROPOSAL-CHATGPT-24e9aedd8086｜`PROFILE` × `STANDALONE` × legacy `ON`
- 源身份：`CELL-24e9aedd8086` / `DeepSeek Harness`（保留，不改名）；產品要求另為 `ChatGPT`，本 ID **尚非 Original 192 Cell**。
- 原 Reader/Owner：SBL Product Owner＋ChatGPT Host Owner；input=原 ProductKind/Mode/SourceSHA/Token + HostCaps/Version/Effect；host_adapter=ChatGPT API-only under supported surface（未證實的 OS loader 原封不動 NOFIT）。
- 正例候選：只做唯讀 Source/Goal→ChatGPT supported UX result 或已證 Host SDK handler，記 requested Kind/Mode/ProviderOnOff 未核定；True Host Loader 功能等實機。
- 負例：假造 ChatGPT 擁有 DeepSeek 進程／host runner，或用 `CELL-24e9aedd8086` 的 Raw 當 ChatGPT → `HOST_IDENTITY_DRIFT`；`PREW3_SHADOW` 禁 World Write。
- 退出：Original ID untouched；未有核定版本/HostCaps/ProviderToken 就 `CR-HOST-192` 下 `MIGRATION_HOLD`；產品承諾仍列。

### PROPOSAL-CHATGPT-75540fe3412c｜`PROFILE` × `STANDALONE` × legacy `OFF`
- 源身份：`CELL-75540fe3412c` / `DeepSeek Harness`（保留，不改名）；產品要求另為 `ChatGPT`，本 ID **尚非 Original 192 Cell**。
- 原 Reader/Owner：SBL Product Owner＋ChatGPT Host Owner；input=原 ProductKind/Mode/SourceSHA/Token + HostCaps/Version/Effect；host_adapter=ChatGPT API-only under supported surface（未證實的 OS loader 原封不動 NOFIT）。
- 正例候選：只做唯讀 Source/Goal→ChatGPT supported UX result 或已證 Host SDK handler，記 requested Kind/Mode/ProviderOnOff 未核定；True Host Loader 功能等實機。
- 負例：假造 ChatGPT 擁有 DeepSeek 進程／host runner，或用 `CELL-75540fe3412c` 的 Raw 當 ChatGPT → `HOST_IDENTITY_DRIFT`；`PREW3_SHADOW` 禁 World Write。
- 退出：Original ID untouched；未有核定版本/HostCaps/ProviderToken 就 `CR-HOST-192` 下 `MIGRATION_HOLD`；產品承諾仍列。

### PROPOSAL-CHATGPT-dd12df59427a｜`PROFILE` × `PREW3_SHADOW` × legacy `ON`
- 源身份：`CELL-dd12df59427a` / `DeepSeek Harness`（保留，不改名）；產品要求另為 `ChatGPT`，本 ID **尚非 Original 192 Cell**。
- 原 Reader/Owner：SBL Product Owner＋ChatGPT Host Owner；input=原 ProductKind/Mode/SourceSHA/Token + HostCaps/Version/Effect；host_adapter=ChatGPT API-only under supported surface（未證實的 OS loader 原封不動 NOFIT）。
- 正例候選：只做唯讀 Source/Goal→ChatGPT supported UX result 或已證 Host SDK handler，記 requested Kind/Mode/ProviderOnOff 未核定；True Host Loader 功能等實機。
- 負例：假造 ChatGPT 擁有 DeepSeek 進程／host runner，或用 `CELL-dd12df59427a` 的 Raw 當 ChatGPT → `HOST_IDENTITY_DRIFT`；`PREW3_SHADOW` 禁 World Write。
- 退出：Original ID untouched；未有核定版本/HostCaps/ProviderToken 就 `CR-HOST-192` 下 `MIGRATION_HOLD`；產品承諾仍列。

### PROPOSAL-CHATGPT-5ce6176dde4b｜`PROFILE` × `PREW3_SHADOW` × legacy `OFF`
- 源身份：`CELL-5ce6176dde4b` / `DeepSeek Harness`（保留，不改名）；產品要求另為 `ChatGPT`，本 ID **尚非 Original 192 Cell**。
- 原 Reader/Owner：SBL Product Owner＋ChatGPT Host Owner；input=原 ProductKind/Mode/SourceSHA/Token + HostCaps/Version/Effect；host_adapter=ChatGPT API-only under supported surface（未證實的 OS loader 原封不動 NOFIT）。
- 正例候選：只做唯讀 Source/Goal→ChatGPT supported UX result 或已證 Host SDK handler，記 requested Kind/Mode/ProviderOnOff 未核定；True Host Loader 功能等實機。
- 負例：假造 ChatGPT 擁有 DeepSeek 進程／host runner，或用 `CELL-5ce6176dde4b` 的 Raw 當 ChatGPT → `HOST_IDENTITY_DRIFT`；`PREW3_SHADOW` 禁 World Write。
- 退出：Original ID untouched；未有核定版本/HostCaps/ProviderToken 就 `CR-HOST-192` 下 `MIGRATION_HOLD`；產品承諾仍列。

### PROPOSAL-CHATGPT-44b29464a95a｜`PROFILE` × `SWOF_CONNECTED` × legacy `ON`
- 源身份：`CELL-44b29464a95a` / `DeepSeek Harness`（保留，不改名）；產品要求另為 `ChatGPT`，本 ID **尚非 Original 192 Cell**。
- 原 Reader/Owner：SBL Product Owner＋ChatGPT Host Owner；input=原 ProductKind/Mode/SourceSHA/Token + HostCaps/Version/Effect；host_adapter=ChatGPT API-only under supported surface（未證實的 OS loader 原封不動 NOFIT）。
- 正例候選：只做唯讀 Source/Goal→ChatGPT supported UX result 或已證 Host SDK handler，記 requested Kind/Mode/ProviderOnOff 未核定；True Host Loader 功能等實機。
- 負例：假造 ChatGPT 擁有 DeepSeek 進程／host runner，或用 `CELL-44b29464a95a` 的 Raw 當 ChatGPT → `HOST_IDENTITY_DRIFT`；`PREW3_SHADOW` 禁 World Write。
- 退出：Original ID untouched；未有核定版本/HostCaps/ProviderToken 就 `CR-HOST-192` 下 `MIGRATION_HOLD`；產品承諾仍列。

### PROPOSAL-CHATGPT-db54604c0f5b｜`PROFILE` × `SWOF_CONNECTED` × legacy `OFF`
- 源身份：`CELL-db54604c0f5b` / `DeepSeek Harness`（保留，不改名）；產品要求另為 `ChatGPT`，本 ID **尚非 Original 192 Cell**。
- 原 Reader/Owner：SBL Product Owner＋ChatGPT Host Owner；input=原 ProductKind/Mode/SourceSHA/Token + HostCaps/Version/Effect；host_adapter=ChatGPT API-only under supported surface（未證實的 OS loader 原封不動 NOFIT）。
- 正例候選：只做唯讀 Source/Goal→ChatGPT supported UX result 或已證 Host SDK handler，記 requested Kind/Mode/ProviderOnOff 未核定；True Host Loader 功能等實機。
- 負例：假造 ChatGPT 擁有 DeepSeek 進程／host runner，或用 `CELL-db54604c0f5b` 的 Raw 當 ChatGPT → `HOST_IDENTITY_DRIFT`；`PREW3_SHADOW` 禁 World Write。
- 退出：Original ID untouched；未有核定版本/HostCaps/ProviderToken 就 `CR-HOST-192` 下 `MIGRATION_HOLD`；產品承諾仍列。

### PROPOSAL-CHATGPT-9e3a12ad436c｜`AGENT_OS` × `STANDALONE` × legacy `ON`
- 源身份：`CELL-9e3a12ad436c` / `DeepSeek Harness`（保留，不改名）；產品要求另為 `ChatGPT`，本 ID **尚非 Original 192 Cell**。
- 原 Reader/Owner：SBL Product Owner＋ChatGPT Host Owner；input=原 ProductKind/Mode/SourceSHA/Token + HostCaps/Version/Effect；host_adapter=ChatGPT API-only under supported surface（未證實的 OS loader 原封不動 NOFIT）。
- 正例候選：只做唯讀 Source/Goal→ChatGPT supported UX result 或已證 Host SDK handler，記 requested Kind/Mode/ProviderOnOff 未核定；True Host Loader 功能等實機。
- 負例：假造 ChatGPT 擁有 DeepSeek 進程／host runner，或用 `CELL-9e3a12ad436c` 的 Raw 當 ChatGPT → `HOST_IDENTITY_DRIFT`；`PREW3_SHADOW` 禁 World Write。
- 退出：Original ID untouched；未有核定版本/HostCaps/ProviderToken 就 `CR-HOST-192` 下 `MIGRATION_HOLD`；產品承諾仍列。

### PROPOSAL-CHATGPT-f18950ce731b｜`AGENT_OS` × `STANDALONE` × legacy `OFF`
- 源身份：`CELL-f18950ce731b` / `DeepSeek Harness`（保留，不改名）；產品要求另為 `ChatGPT`，本 ID **尚非 Original 192 Cell**。
- 原 Reader/Owner：SBL Product Owner＋ChatGPT Host Owner；input=原 ProductKind/Mode/SourceSHA/Token + HostCaps/Version/Effect；host_adapter=ChatGPT API-only under supported surface（未證實的 OS loader 原封不動 NOFIT）。
- 正例候選：只做唯讀 Source/Goal→ChatGPT supported UX result 或已證 Host SDK handler，記 requested Kind/Mode/ProviderOnOff 未核定；True Host Loader 功能等實機。
- 負例：假造 ChatGPT 擁有 DeepSeek 進程／host runner，或用 `CELL-f18950ce731b` 的 Raw 當 ChatGPT → `HOST_IDENTITY_DRIFT`；`PREW3_SHADOW` 禁 World Write。
- 退出：Original ID untouched；未有核定版本/HostCaps/ProviderToken 就 `CR-HOST-192` 下 `MIGRATION_HOLD`；產品承諾仍列。

### PROPOSAL-CHATGPT-f93b6704ee69｜`AGENT_OS` × `PREW3_SHADOW` × legacy `ON`
- 源身份：`CELL-f93b6704ee69` / `DeepSeek Harness`（保留，不改名）；產品要求另為 `ChatGPT`，本 ID **尚非 Original 192 Cell**。
- 原 Reader/Owner：SBL Product Owner＋ChatGPT Host Owner；input=原 ProductKind/Mode/SourceSHA/Token + HostCaps/Version/Effect；host_adapter=ChatGPT API-only under supported surface（未證實的 OS loader 原封不動 NOFIT）。
- 正例候選：只做唯讀 Source/Goal→ChatGPT supported UX result 或已證 Host SDK handler，記 requested Kind/Mode/ProviderOnOff 未核定；True Host Loader 功能等實機。
- 負例：假造 ChatGPT 擁有 DeepSeek 進程／host runner，或用 `CELL-f93b6704ee69` 的 Raw 當 ChatGPT → `HOST_IDENTITY_DRIFT`；`PREW3_SHADOW` 禁 World Write。
- 退出：Original ID untouched；未有核定版本/HostCaps/ProviderToken 就 `CR-HOST-192` 下 `MIGRATION_HOLD`；產品承諾仍列。

### PROPOSAL-CHATGPT-91838cb6a697｜`AGENT_OS` × `PREW3_SHADOW` × legacy `OFF`
- 源身份：`CELL-91838cb6a697` / `DeepSeek Harness`（保留，不改名）；產品要求另為 `ChatGPT`，本 ID **尚非 Original 192 Cell**。
- 原 Reader/Owner：SBL Product Owner＋ChatGPT Host Owner；input=原 ProductKind/Mode/SourceSHA/Token + HostCaps/Version/Effect；host_adapter=ChatGPT API-only under supported surface（未證實的 OS loader 原封不動 NOFIT）。
- 正例候選：只做唯讀 Source/Goal→ChatGPT supported UX result 或已證 Host SDK handler，記 requested Kind/Mode/ProviderOnOff 未核定；True Host Loader 功能等實機。
- 負例：假造 ChatGPT 擁有 DeepSeek 進程／host runner，或用 `CELL-91838cb6a697` 的 Raw 當 ChatGPT → `HOST_IDENTITY_DRIFT`；`PREW3_SHADOW` 禁 World Write。
- 退出：Original ID untouched；未有核定版本/HostCaps/ProviderToken 就 `CR-HOST-192` 下 `MIGRATION_HOLD`；產品承諾仍列。

### PROPOSAL-CHATGPT-10cbe7b8ba17｜`AGENT_OS` × `SWOF_CONNECTED` × legacy `ON`
- 源身份：`CELL-10cbe7b8ba17` / `DeepSeek Harness`（保留，不改名）；產品要求另為 `ChatGPT`，本 ID **尚非 Original 192 Cell**。
- 原 Reader/Owner：SBL Product Owner＋ChatGPT Host Owner；input=原 ProductKind/Mode/SourceSHA/Token + HostCaps/Version/Effect；host_adapter=ChatGPT API-only under supported surface（未證實的 OS loader 原封不動 NOFIT）。
- 正例候選：只做唯讀 Source/Goal→ChatGPT supported UX result 或已證 Host SDK handler，記 requested Kind/Mode/ProviderOnOff 未核定；True Host Loader 功能等實機。
- 負例：假造 ChatGPT 擁有 DeepSeek 進程／host runner，或用 `CELL-10cbe7b8ba17` 的 Raw 當 ChatGPT → `HOST_IDENTITY_DRIFT`；`PREW3_SHADOW` 禁 World Write。
- 退出：Original ID untouched；未有核定版本/HostCaps/ProviderToken 就 `CR-HOST-192` 下 `MIGRATION_HOLD`；產品承諾仍列。

### PROPOSAL-CHATGPT-95ae8bfac0e7｜`AGENT_OS` × `SWOF_CONNECTED` × legacy `OFF`
- 源身份：`CELL-95ae8bfac0e7` / `DeepSeek Harness`（保留，不改名）；產品要求另為 `ChatGPT`，本 ID **尚非 Original 192 Cell**。
- 原 Reader/Owner：SBL Product Owner＋ChatGPT Host Owner；input=原 ProductKind/Mode/SourceSHA/Token + HostCaps/Version/Effect；host_adapter=ChatGPT API-only under supported surface（未證實的 OS loader 原封不動 NOFIT）。
- 正例候選：只做唯讀 Source/Goal→ChatGPT supported UX result 或已證 Host SDK handler，記 requested Kind/Mode/ProviderOnOff 未核定；True Host Loader 功能等實機。
- 負例：假造 ChatGPT 擁有 DeepSeek 進程／host runner，或用 `CELL-95ae8bfac0e7` 的 Raw 當 ChatGPT → `HOST_IDENTITY_DRIFT`；`PREW3_SHADOW` 禁 World Write。
- 退出：Original ID untouched；未有核定版本/HostCaps/ProviderToken 就 `CR-HOST-192` 下 `MIGRATION_HOLD`；產品承諾仍列。

### PROPOSAL-CHATGPT-f478ba7d0b9a｜`AI_SYSTEM` × `STANDALONE` × legacy `ON`
- 源身份：`CELL-f478ba7d0b9a` / `DeepSeek Harness`（保留，不改名）；產品要求另為 `ChatGPT`，本 ID **尚非 Original 192 Cell**。
- 原 Reader/Owner：SBL Product Owner＋ChatGPT Host Owner；input=原 ProductKind/Mode/SourceSHA/Token + HostCaps/Version/Effect；host_adapter=ChatGPT API-only under supported surface（未證實的 OS loader 原封不動 NOFIT）。
- 正例候選：只做唯讀 Source/Goal→ChatGPT supported UX result 或已證 Host SDK handler，記 requested Kind/Mode/ProviderOnOff 未核定；True Host Loader 功能等實機。
- 負例：假造 ChatGPT 擁有 DeepSeek 進程／host runner，或用 `CELL-f478ba7d0b9a` 的 Raw 當 ChatGPT → `HOST_IDENTITY_DRIFT`；`PREW3_SHADOW` 禁 World Write。
- 退出：Original ID untouched；未有核定版本/HostCaps/ProviderToken 就 `CR-HOST-192` 下 `MIGRATION_HOLD`；產品承諾仍列。

### PROPOSAL-CHATGPT-057db0593627｜`AI_SYSTEM` × `STANDALONE` × legacy `OFF`
- 源身份：`CELL-057db0593627` / `DeepSeek Harness`（保留，不改名）；產品要求另為 `ChatGPT`，本 ID **尚非 Original 192 Cell**。
- 原 Reader/Owner：SBL Product Owner＋ChatGPT Host Owner；input=原 ProductKind/Mode/SourceSHA/Token + HostCaps/Version/Effect；host_adapter=ChatGPT API-only under supported surface（未證實的 OS loader 原封不動 NOFIT）。
- 正例候選：只做唯讀 Source/Goal→ChatGPT supported UX result 或已證 Host SDK handler，記 requested Kind/Mode/ProviderOnOff 未核定；True Host Loader 功能等實機。
- 負例：假造 ChatGPT 擁有 DeepSeek 進程／host runner，或用 `CELL-057db0593627` 的 Raw 當 ChatGPT → `HOST_IDENTITY_DRIFT`；`PREW3_SHADOW` 禁 World Write。
- 退出：Original ID untouched；未有核定版本/HostCaps/ProviderToken 就 `CR-HOST-192` 下 `MIGRATION_HOLD`；產品承諾仍列。

### PROPOSAL-CHATGPT-9742bec81e5a｜`AI_SYSTEM` × `PREW3_SHADOW` × legacy `ON`
- 源身份：`CELL-9742bec81e5a` / `DeepSeek Harness`（保留，不改名）；產品要求另為 `ChatGPT`，本 ID **尚非 Original 192 Cell**。
- 原 Reader/Owner：SBL Product Owner＋ChatGPT Host Owner；input=原 ProductKind/Mode/SourceSHA/Token + HostCaps/Version/Effect；host_adapter=ChatGPT API-only under supported surface（未證實的 OS loader 原封不動 NOFIT）。
- 正例候選：只做唯讀 Source/Goal→ChatGPT supported UX result 或已證 Host SDK handler，記 requested Kind/Mode/ProviderOnOff 未核定；True Host Loader 功能等實機。
- 負例：假造 ChatGPT 擁有 DeepSeek 進程／host runner，或用 `CELL-9742bec81e5a` 的 Raw 當 ChatGPT → `HOST_IDENTITY_DRIFT`；`PREW3_SHADOW` 禁 World Write。
- 退出：Original ID untouched；未有核定版本/HostCaps/ProviderToken 就 `CR-HOST-192` 下 `MIGRATION_HOLD`；產品承諾仍列。

### PROPOSAL-CHATGPT-237ac6308b3f｜`AI_SYSTEM` × `PREW3_SHADOW` × legacy `OFF`
- 源身份：`CELL-237ac6308b3f` / `DeepSeek Harness`（保留，不改名）；產品要求另為 `ChatGPT`，本 ID **尚非 Original 192 Cell**。
- 原 Reader/Owner：SBL Product Owner＋ChatGPT Host Owner；input=原 ProductKind/Mode/SourceSHA/Token + HostCaps/Version/Effect；host_adapter=ChatGPT API-only under supported surface（未證實的 OS loader 原封不動 NOFIT）。
- 正例候選：只做唯讀 Source/Goal→ChatGPT supported UX result 或已證 Host SDK handler，記 requested Kind/Mode/ProviderOnOff 未核定；True Host Loader 功能等實機。
- 負例：假造 ChatGPT 擁有 DeepSeek 進程／host runner，或用 `CELL-237ac6308b3f` 的 Raw 當 ChatGPT → `HOST_IDENTITY_DRIFT`；`PREW3_SHADOW` 禁 World Write。
- 退出：Original ID untouched；未有核定版本/HostCaps/ProviderToken 就 `CR-HOST-192` 下 `MIGRATION_HOLD`；產品承諾仍列。

### PROPOSAL-CHATGPT-b85f95d3b255｜`AI_SYSTEM` × `SWOF_CONNECTED` × legacy `ON`
- 源身份：`CELL-b85f95d3b255` / `DeepSeek Harness`（保留，不改名）；產品要求另為 `ChatGPT`，本 ID **尚非 Original 192 Cell**。
- 原 Reader/Owner：SBL Product Owner＋ChatGPT Host Owner；input=原 ProductKind/Mode/SourceSHA/Token + HostCaps/Version/Effect；host_adapter=ChatGPT API-only under supported surface（未證實的 OS loader 原封不動 NOFIT）。
- 正例候選：只做唯讀 Source/Goal→ChatGPT supported UX result 或已證 Host SDK handler，記 requested Kind/Mode/ProviderOnOff 未核定；True Host Loader 功能等實機。
- 負例：假造 ChatGPT 擁有 DeepSeek 進程／host runner，或用 `CELL-b85f95d3b255` 的 Raw 當 ChatGPT → `HOST_IDENTITY_DRIFT`；`PREW3_SHADOW` 禁 World Write。
- 退出：Original ID untouched；未有核定版本/HostCaps/ProviderToken 就 `CR-HOST-192` 下 `MIGRATION_HOLD`；產品承諾仍列。

### PROPOSAL-CHATGPT-1746d4d5a88d｜`AI_SYSTEM` × `SWOF_CONNECTED` × legacy `OFF`
- 源身份：`CELL-1746d4d5a88d` / `DeepSeek Harness`（保留，不改名）；產品要求另為 `ChatGPT`，本 ID **尚非 Original 192 Cell**。
- 原 Reader/Owner：SBL Product Owner＋ChatGPT Host Owner；input=原 ProductKind/Mode/SourceSHA/Token + HostCaps/Version/Effect；host_adapter=ChatGPT API-only under supported surface（未證實的 OS loader 原封不動 NOFIT）。
- 正例候選：只做唯讀 Source/Goal→ChatGPT supported UX result 或已證 Host SDK handler，記 requested Kind/Mode/ProviderOnOff 未核定；True Host Loader 功能等實機。
- 負例：假造 ChatGPT 擁有 DeepSeek 進程／host runner，或用 `CELL-1746d4d5a88d` 的 Raw 當 ChatGPT → `HOST_IDENTITY_DRIFT`；`PREW3_SHADOW` 禁 World Write。
- 退出：Original ID untouched；未有核定版本/HostCaps/ProviderToken 就 `CR-HOST-192` 下 `MIGRATION_HOLD`；產品承諾仍列。

### PROPOSAL-CHATGPT-9af02fa9e8ed｜`GENIE/GENIE.md` × `STANDALONE` × legacy `ON`
- 源身份：`CELL-9af02fa9e8ed` / `DeepSeek Harness`（保留，不改名）；產品要求另為 `ChatGPT`，本 ID **尚非 Original 192 Cell**。
- 原 Reader/Owner：SBL Product Owner＋ChatGPT Host Owner；input=原 ProductKind/Mode/SourceSHA/Token + HostCaps/Version/Effect；host_adapter=ChatGPT API-only under supported surface（未證實的 OS loader 原封不動 NOFIT）。
- 正例候選：只做唯讀 Source/Goal→ChatGPT supported UX result 或已證 Host SDK handler，記 requested Kind/Mode/ProviderOnOff 未核定；True Host Loader 功能等實機。
- 負例：假造 ChatGPT 擁有 DeepSeek 進程／host runner，或用 `CELL-9af02fa9e8ed` 的 Raw 當 ChatGPT → `HOST_IDENTITY_DRIFT`；`PREW3_SHADOW` 禁 World Write。
- 退出：Original ID untouched；未有核定版本/HostCaps/ProviderToken 就 `CR-HOST-192` 下 `MIGRATION_HOLD`；產品承諾仍列。

### PROPOSAL-CHATGPT-c38a7e723977｜`GENIE/GENIE.md` × `STANDALONE` × legacy `OFF`
- 源身份：`CELL-c38a7e723977` / `DeepSeek Harness`（保留，不改名）；產品要求另為 `ChatGPT`，本 ID **尚非 Original 192 Cell**。
- 原 Reader/Owner：SBL Product Owner＋ChatGPT Host Owner；input=原 ProductKind/Mode/SourceSHA/Token + HostCaps/Version/Effect；host_adapter=ChatGPT API-only under supported surface（未證實的 OS loader 原封不動 NOFIT）。
- 正例候選：只做唯讀 Source/Goal→ChatGPT supported UX result 或已證 Host SDK handler，記 requested Kind/Mode/ProviderOnOff 未核定；True Host Loader 功能等實機。
- 負例：假造 ChatGPT 擁有 DeepSeek 進程／host runner，或用 `CELL-c38a7e723977` 的 Raw 當 ChatGPT → `HOST_IDENTITY_DRIFT`；`PREW3_SHADOW` 禁 World Write。
- 退出：Original ID untouched；未有核定版本/HostCaps/ProviderToken 就 `CR-HOST-192` 下 `MIGRATION_HOLD`；產品承諾仍列。

### PROPOSAL-CHATGPT-98d011df32e5｜`GENIE/GENIE.md` × `PREW3_SHADOW` × legacy `ON`
- 源身份：`CELL-98d011df32e5` / `DeepSeek Harness`（保留，不改名）；產品要求另為 `ChatGPT`，本 ID **尚非 Original 192 Cell**。
- 原 Reader/Owner：SBL Product Owner＋ChatGPT Host Owner；input=原 ProductKind/Mode/SourceSHA/Token + HostCaps/Version/Effect；host_adapter=ChatGPT API-only under supported surface（未證實的 OS loader 原封不動 NOFIT）。
- 正例候選：只做唯讀 Source/Goal→ChatGPT supported UX result 或已證 Host SDK handler，記 requested Kind/Mode/ProviderOnOff 未核定；True Host Loader 功能等實機。
- 負例：假造 ChatGPT 擁有 DeepSeek 進程／host runner，或用 `CELL-98d011df32e5` 的 Raw 當 ChatGPT → `HOST_IDENTITY_DRIFT`；`PREW3_SHADOW` 禁 World Write。
- 退出：Original ID untouched；未有核定版本/HostCaps/ProviderToken 就 `CR-HOST-192` 下 `MIGRATION_HOLD`；產品承諾仍列。

### PROPOSAL-CHATGPT-880fcebbf48e｜`GENIE/GENIE.md` × `PREW3_SHADOW` × legacy `OFF`
- 源身份：`CELL-880fcebbf48e` / `DeepSeek Harness`（保留，不改名）；產品要求另為 `ChatGPT`，本 ID **尚非 Original 192 Cell**。
- 原 Reader/Owner：SBL Product Owner＋ChatGPT Host Owner；input=原 ProductKind/Mode/SourceSHA/Token + HostCaps/Version/Effect；host_adapter=ChatGPT API-only under supported surface（未證實的 OS loader 原封不動 NOFIT）。
- 正例候選：只做唯讀 Source/Goal→ChatGPT supported UX result 或已證 Host SDK handler，記 requested Kind/Mode/ProviderOnOff 未核定；True Host Loader 功能等實機。
- 負例：假造 ChatGPT 擁有 DeepSeek 進程／host runner，或用 `CELL-880fcebbf48e` 的 Raw 當 ChatGPT → `HOST_IDENTITY_DRIFT`；`PREW3_SHADOW` 禁 World Write。
- 退出：Original ID untouched；未有核定版本/HostCaps/ProviderToken 就 `CR-HOST-192` 下 `MIGRATION_HOLD`；產品承諾仍列。

### PROPOSAL-CHATGPT-fc762041aa9d｜`GENIE/GENIE.md` × `SWOF_CONNECTED` × legacy `ON`
- 源身份：`CELL-fc762041aa9d` / `DeepSeek Harness`（保留，不改名）；產品要求另為 `ChatGPT`，本 ID **尚非 Original 192 Cell**。
- 原 Reader/Owner：SBL Product Owner＋ChatGPT Host Owner；input=原 ProductKind/Mode/SourceSHA/Token + HostCaps/Version/Effect；host_adapter=ChatGPT API-only under supported surface（未證實的 OS loader 原封不動 NOFIT）。
- 正例候選：只做唯讀 Source/Goal→ChatGPT supported UX result 或已證 Host SDK handler，記 requested Kind/Mode/ProviderOnOff 未核定；True Host Loader 功能等實機。
- 負例：假造 ChatGPT 擁有 DeepSeek 進程／host runner，或用 `CELL-fc762041aa9d` 的 Raw 當 ChatGPT → `HOST_IDENTITY_DRIFT`；`PREW3_SHADOW` 禁 World Write。
- 退出：Original ID untouched；未有核定版本/HostCaps/ProviderToken 就 `CR-HOST-192` 下 `MIGRATION_HOLD`；產品承諾仍列。

### PROPOSAL-CHATGPT-5370fdd74e46｜`GENIE/GENIE.md` × `SWOF_CONNECTED` × legacy `OFF`
- 源身份：`CELL-5370fdd74e46` / `DeepSeek Harness`（保留，不改名）；產品要求另為 `ChatGPT`，本 ID **尚非 Original 192 Cell**。
- 原 Reader/Owner：SBL Product Owner＋ChatGPT Host Owner；input=原 ProductKind/Mode/SourceSHA/Token + HostCaps/Version/Effect；host_adapter=ChatGPT API-only under supported surface（未證實的 OS loader 原封不動 NOFIT）。
- 正例候選：只做唯讀 Source/Goal→ChatGPT supported UX result 或已證 Host SDK handler，記 requested Kind/Mode/ProviderOnOff 未核定；True Host Loader 功能等實機。
- 負例：假造 ChatGPT 擁有 DeepSeek 進程／host runner，或用 `CELL-5370fdd74e46` 的 Raw 當 ChatGPT → `HOST_IDENTITY_DRIFT`；`PREW3_SHADOW` 禁 World Write。
- 退出：Original ID untouched；未有核定版本/HostCaps/ProviderToken 就 `CR-HOST-192` 下 `MIGRATION_HOLD`；產品承諾仍列。

## R2 高保留歷史（不可執行，排除於本版 Parser）

以下內容完整保留先前 Revision2 的參考語義。**所有標題和 ID 均為 archive 文字，不是本版有效條位**；如需 source-level regression，可讀證據包未包裝的原檔及 SHA。

~~~~~~~markdown
## 高保留原 BODY Revision2 實質正文（沿用未受影區；遇 r2 修補採本冊前段）

---
artifact_id: FHS-MSC-R2-BODY-09B
formal_name: 192 Cell 的Host、Provider與Mode實質契約
short_name: BODY-09B
version: 2026-10-29-r2-revision2
source_set_hash_or_pending: f86b217ae3c3ee28183570f4bf3d4f08d4d00e9b86d1de1a641a630f8682d1a1
intended_consumer: 原領域 Owner 與下游 Reader
owner_role: 作者端規格修補者；原 Domain Writer 不移轉
design_status: SOURCE_BOUND_REPAIR_CANDIDATE
claim_ceiling: AUTHOR_STATIC_ONLY; NATIVE_NOT_RUN; CHECKER_NOT_RUN; RELEASE_NOT_RUN
supersession_scope: 本輪作者候選revision2；保留前版封存；不取代任何原Canonical Writer版本
AUDIT_F_IDs:
- F-07
- F-08
---

# 192 Cell 的Host、Provider與Mode實質契約

## R2-09B-CELL：四Host與Provider差異

保留原192 CellID、Kind、Mode、Host、原ON/OFF字串。舊表ProviderOff欄寫ON，但PROVIDER_OFF敘述出現在OFF列，為來源label矛盾。本候選顯式保留raw token並提議OFF→provider_off=true、ON→false；此映射尚需原Host/Product Owner確認。原Owner確認前該boolean轉接OWNER_BIND_HOLD，不能把猜測當formal enum。192×本Host預期功能在下列逐Cell完整定義。

SWOF_W2_SHADOW_NO_WRITE只讀frozen input，不執行wheel build、不寫w3 packet。PRODUCT_BUILD_LOCAL為另一subject，在受權隔離output內建置，若涉及Repo patch則L2 DEV ECP，若純隔離產物可LOCAL_DRAFT_WRITE；其成功不得提升SWOF Shadow效力。

Cell Reader先核exact kind/mode/host/provider token/source/candidate/session，再驗Host capability和本Kind功能。POS依實際predicate產本Cell Raw；NEG若Host不符、ProviderOff偷外呼、API_ONLY冒loader、MODE授權不符立即NACK。所有Native案例仍NATIVE_NOT_RUN。
### CELL-d0cf30ffd7c1｜CLI_TOOL/STANDALONE｜Hermes Agent｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L29，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；OS process runner，不要求Host skill loader。
- input→behavior→typed output：source-bound input→乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Hermes Agent/CLI_TOOL/STANDALONE/ON：原Hermes tool/skill loader與worker fresh PID驗乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒無entrypoint或退出碼未記錄；若raw.host不等於Hermes Agent或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無OS process runner，不要求Host skill loader，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-e8a4077d37ad｜CLI_TOOL/STANDALONE｜Hermes Agent｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L30，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；OS process runner，不要求Host skill loader。
- input→behavior→typed output：source-bound input→乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Hermes Agent/CLI_TOOL/STANDALONE/OFF：原Hermes tool/skill loader與worker fresh PID驗乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒無entrypoint或退出碼未記錄；若raw.host不等於Hermes Agent或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無OS process runner，不要求Host skill loader，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-6582a70fd427｜CLI_TOOL/STANDALONE｜Codex｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L31，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；OS process runner，不要求Host skill loader。
- input→behavior→typed output：source-bound input→乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Codex/CLI_TOOL/STANDALONE/ON：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒無entrypoint或退出碼未記錄；若raw.host不等於Codex或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無OS process runner，不要求Host skill loader，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-434c21c50bc3｜CLI_TOOL/STANDALONE｜Codex｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L32，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；OS process runner，不要求Host skill loader。
- input→behavior→typed output：source-bound input→乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Codex/CLI_TOOL/STANDALONE/OFF：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒無entrypoint或退出碼未記錄；若raw.host不等於Codex或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無OS process runner，不要求Host skill loader，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-41348f62f97c｜CLI_TOOL/STANDALONE｜Claude Code｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L33，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；OS process runner，不要求Host skill loader。
- input→behavior→typed output：source-bound input→乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Claude Code/CLI_TOOL/STANDALONE/ON：Claude Code當期原loader＋乾淨session驗乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒無entrypoint或退出碼未記錄；若raw.host不等於Claude Code或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無OS process runner，不要求Host skill loader，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-4bf76833ac66｜CLI_TOOL/STANDALONE｜Claude Code｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L34，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；OS process runner，不要求Host skill loader。
- input→behavior→typed output：source-bound input→乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Claude Code/CLI_TOOL/STANDALONE/OFF：Claude Code當期原loader＋乾淨session驗乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒無entrypoint或退出碼未記錄；若raw.host不等於Claude Code或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無OS process runner，不要求Host skill loader，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-2738990e2c09｜CLI_TOOL/STANDALONE｜DeepSeek Harness｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L35，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；OS process runner，不要求Host skill loader。
- input→behavior→typed output：source-bound input→乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：DeepSeek Harness/CLI_TOOL/STANDALONE/ON：實際Harness adapter/capability reader；API_ONLY不能充loader驗乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒無entrypoint或退出碼未記錄；若raw.host不等於DeepSeek Harness或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無OS process runner，不要求Host skill loader，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-3869542dc2f7｜CLI_TOOL/STANDALONE｜DeepSeek Harness｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L36，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；OS process runner，不要求Host skill loader。
- input→behavior→typed output：source-bound input→乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：DeepSeek Harness/CLI_TOOL/STANDALONE/OFF：實際Harness adapter/capability reader；API_ONLY不能充loader驗乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒無entrypoint或退出碼未記錄；若raw.host不等於DeepSeek Harness或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無OS process runner，不要求Host skill loader，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-1407c7aa1d27｜CLI_TOOL/PREW3_SHADOW｜Hermes Agent｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L37，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；OS process runner，不要求Host skill loader。
- input→behavior→typed output：source-bound input→乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Hermes Agent/CLI_TOOL/PREW3_SHADOW/ON：原Hermes tool/skill loader與worker fresh PID驗乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒無entrypoint或退出碼未記錄；若raw.host不等於Hermes Agent或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無OS process runner，不要求Host skill loader，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-6b424688af61｜CLI_TOOL/PREW3_SHADOW｜Hermes Agent｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L38，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；OS process runner，不要求Host skill loader。
- input→behavior→typed output：source-bound input→乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Hermes Agent/CLI_TOOL/PREW3_SHADOW/OFF：原Hermes tool/skill loader與worker fresh PID驗乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒無entrypoint或退出碼未記錄；若raw.host不等於Hermes Agent或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無OS process runner，不要求Host skill loader，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-56eaea595d3d｜CLI_TOOL/PREW3_SHADOW｜Codex｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L39，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；OS process runner，不要求Host skill loader。
- input→behavior→typed output：source-bound input→乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Codex/CLI_TOOL/PREW3_SHADOW/ON：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒無entrypoint或退出碼未記錄；若raw.host不等於Codex或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無OS process runner，不要求Host skill loader，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-0dff6839fdf7｜CLI_TOOL/PREW3_SHADOW｜Codex｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L40，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；OS process runner，不要求Host skill loader。
- input→behavior→typed output：source-bound input→乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Codex/CLI_TOOL/PREW3_SHADOW/OFF：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒無entrypoint或退出碼未記錄；若raw.host不等於Codex或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無OS process runner，不要求Host skill loader，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-1cf2ae4386cb｜CLI_TOOL/PREW3_SHADOW｜Claude Code｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L41，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；OS process runner，不要求Host skill loader。
- input→behavior→typed output：source-bound input→乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Claude Code/CLI_TOOL/PREW3_SHADOW/ON：Claude Code當期原loader＋乾淨session驗乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒無entrypoint或退出碼未記錄；若raw.host不等於Claude Code或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無OS process runner，不要求Host skill loader，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-b6b3031965fa｜CLI_TOOL/PREW3_SHADOW｜Claude Code｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L42，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；OS process runner，不要求Host skill loader。
- input→behavior→typed output：source-bound input→乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Claude Code/CLI_TOOL/PREW3_SHADOW/OFF：Claude Code當期原loader＋乾淨session驗乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒無entrypoint或退出碼未記錄；若raw.host不等於Claude Code或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無OS process runner，不要求Host skill loader，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-e78d746c7bf7｜CLI_TOOL/PREW3_SHADOW｜DeepSeek Harness｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L43，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；OS process runner，不要求Host skill loader。
- input→behavior→typed output：source-bound input→乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：DeepSeek Harness/CLI_TOOL/PREW3_SHADOW/ON：實際Harness adapter/capability reader；API_ONLY不能充loader驗乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒無entrypoint或退出碼未記錄；若raw.host不等於DeepSeek Harness或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無OS process runner，不要求Host skill loader，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-fabd535f6b8d｜CLI_TOOL/PREW3_SHADOW｜DeepSeek Harness｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L44，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；OS process runner，不要求Host skill loader。
- input→behavior→typed output：source-bound input→乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：DeepSeek Harness/CLI_TOOL/PREW3_SHADOW/OFF：實際Harness adapter/capability reader；API_ONLY不能充loader驗乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒無entrypoint或退出碼未記錄；若raw.host不等於DeepSeek Harness或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無OS process runner，不要求Host skill loader，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-68f927602c56｜CLI_TOOL/SWOF_CONNECTED｜Hermes Agent｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L45，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；OS process runner，不要求Host skill loader。
- input→behavior→typed output：source-bound input→乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Hermes Agent/CLI_TOOL/SWOF_CONNECTED/ON：原Hermes tool/skill loader與worker fresh PID驗乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒無entrypoint或退出碼未記錄；若raw.host不等於Hermes Agent或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無OS process runner，不要求Host skill loader，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-09a9c6d13bb7｜CLI_TOOL/SWOF_CONNECTED｜Hermes Agent｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L46，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；OS process runner，不要求Host skill loader。
- input→behavior→typed output：source-bound input→乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Hermes Agent/CLI_TOOL/SWOF_CONNECTED/OFF：原Hermes tool/skill loader與worker fresh PID驗乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒無entrypoint或退出碼未記錄；若raw.host不等於Hermes Agent或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無OS process runner，不要求Host skill loader，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-62767ea0b8e8｜CLI_TOOL/SWOF_CONNECTED｜Codex｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L47，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；OS process runner，不要求Host skill loader。
- input→behavior→typed output：source-bound input→乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Codex/CLI_TOOL/SWOF_CONNECTED/ON：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒無entrypoint或退出碼未記錄；若raw.host不等於Codex或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無OS process runner，不要求Host skill loader，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-739b3b5375fc｜CLI_TOOL/SWOF_CONNECTED｜Codex｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L48，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；OS process runner，不要求Host skill loader。
- input→behavior→typed output：source-bound input→乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Codex/CLI_TOOL/SWOF_CONNECTED/OFF：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒無entrypoint或退出碼未記錄；若raw.host不等於Codex或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無OS process runner，不要求Host skill loader，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-944d6c462137｜CLI_TOOL/SWOF_CONNECTED｜Claude Code｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L49，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；OS process runner，不要求Host skill loader。
- input→behavior→typed output：source-bound input→乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Claude Code/CLI_TOOL/SWOF_CONNECTED/ON：Claude Code當期原loader＋乾淨session驗乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒無entrypoint或退出碼未記錄；若raw.host不等於Claude Code或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無OS process runner，不要求Host skill loader，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-1444ab821832｜CLI_TOOL/SWOF_CONNECTED｜Claude Code｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L50，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；OS process runner，不要求Host skill loader。
- input→behavior→typed output：source-bound input→乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Claude Code/CLI_TOOL/SWOF_CONNECTED/OFF：Claude Code當期原loader＋乾淨session驗乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒無entrypoint或退出碼未記錄；若raw.host不等於Claude Code或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無OS process runner，不要求Host skill loader，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-f5c5147c11c1｜CLI_TOOL/SWOF_CONNECTED｜DeepSeek Harness｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L51，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；OS process runner，不要求Host skill loader。
- input→behavior→typed output：source-bound input→乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：DeepSeek Harness/CLI_TOOL/SWOF_CONNECTED/ON：實際Harness adapter/capability reader；API_ONLY不能充loader驗乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒無entrypoint或退出碼未記錄；若raw.host不等於DeepSeek Harness或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無OS process runner，不要求Host skill loader，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-5bd80e6cf274｜CLI_TOOL/SWOF_CONNECTED｜DeepSeek Harness｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L52，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；OS process runner，不要求Host skill loader。
- input→behavior→typed output：source-bound input→乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：DeepSeek Harness/CLI_TOOL/SWOF_CONNECTED/OFF：實際Harness adapter/capability reader；API_ONLY不能充loader驗乾淨binary/script/wheel的entrypoint/help/JSON/nonzero/uninstall；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒無entrypoint或退出碼未記錄；若raw.host不等於DeepSeek Harness或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無OS process runner，不要求Host skill loader，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-b368d7497e83｜AGENT_SKILL/STANDALONE｜Hermes Agent｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L53，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；實際skill loader；API_ONLY無loader為NOFIT。
- input→behavior→typed output：source-bound input→SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Hermes Agent/AGENT_SKILL/STANDALONE/ON：原Hermes tool/skill loader與worker fresh PID驗SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒copy-only或錯誤trigger；若raw.host不等於Hermes Agent或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無實際skill loader；API_ONLY無loader為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-a488c020ca0b｜AGENT_SKILL/STANDALONE｜Hermes Agent｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L54，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；實際skill loader；API_ONLY無loader為NOFIT。
- input→behavior→typed output：source-bound input→SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Hermes Agent/AGENT_SKILL/STANDALONE/OFF：原Hermes tool/skill loader與worker fresh PID驗SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒copy-only或錯誤trigger；若raw.host不等於Hermes Agent或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無實際skill loader；API_ONLY無loader為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-cab792bba33a｜AGENT_SKILL/STANDALONE｜Codex｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L55，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；實際skill loader；API_ONLY無loader為NOFIT。
- input→behavior→typed output：source-bound input→SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Codex/AGENT_SKILL/STANDALONE/ON：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒copy-only或錯誤trigger；若raw.host不等於Codex或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無實際skill loader；API_ONLY無loader為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-220de7b8b1e7｜AGENT_SKILL/STANDALONE｜Codex｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L56，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；實際skill loader；API_ONLY無loader為NOFIT。
- input→behavior→typed output：source-bound input→SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Codex/AGENT_SKILL/STANDALONE/OFF：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒copy-only或錯誤trigger；若raw.host不等於Codex或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無實際skill loader；API_ONLY無loader為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-e05964530c47｜AGENT_SKILL/STANDALONE｜Claude Code｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L57，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；實際skill loader；API_ONLY無loader為NOFIT。
- input→behavior→typed output：source-bound input→SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Claude Code/AGENT_SKILL/STANDALONE/ON：Claude Code當期原loader＋乾淨session驗SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒copy-only或錯誤trigger；若raw.host不等於Claude Code或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無實際skill loader；API_ONLY無loader為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-ea5d66500738｜AGENT_SKILL/STANDALONE｜Claude Code｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L58，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；實際skill loader；API_ONLY無loader為NOFIT。
- input→behavior→typed output：source-bound input→SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Claude Code/AGENT_SKILL/STANDALONE/OFF：Claude Code當期原loader＋乾淨session驗SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒copy-only或錯誤trigger；若raw.host不等於Claude Code或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無實際skill loader；API_ONLY無loader為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-cb678bd208a8｜AGENT_SKILL/STANDALONE｜DeepSeek Harness｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L59，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；實際skill loader；API_ONLY無loader為NOFIT。
- input→behavior→typed output：source-bound input→SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：DeepSeek Harness/AGENT_SKILL/STANDALONE/ON：實際Harness adapter/capability reader；API_ONLY不能充loader驗SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒copy-only或錯誤trigger；若raw.host不等於DeepSeek Harness或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無實際skill loader；API_ONLY無loader為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-6e1c0fb8d36b｜AGENT_SKILL/STANDALONE｜DeepSeek Harness｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L60，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；實際skill loader；API_ONLY無loader為NOFIT。
- input→behavior→typed output：source-bound input→SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：DeepSeek Harness/AGENT_SKILL/STANDALONE/OFF：實際Harness adapter/capability reader；API_ONLY不能充loader驗SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒copy-only或錯誤trigger；若raw.host不等於DeepSeek Harness或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無實際skill loader；API_ONLY無loader為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-dd676737681e｜AGENT_SKILL/PREW3_SHADOW｜Hermes Agent｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L61，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；實際skill loader；API_ONLY無loader為NOFIT。
- input→behavior→typed output：source-bound input→SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Hermes Agent/AGENT_SKILL/PREW3_SHADOW/ON：原Hermes tool/skill loader與worker fresh PID驗SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒copy-only或錯誤trigger；若raw.host不等於Hermes Agent或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無實際skill loader；API_ONLY無loader為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-6c0ad0177a48｜AGENT_SKILL/PREW3_SHADOW｜Hermes Agent｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L62，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；實際skill loader；API_ONLY無loader為NOFIT。
- input→behavior→typed output：source-bound input→SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Hermes Agent/AGENT_SKILL/PREW3_SHADOW/OFF：原Hermes tool/skill loader與worker fresh PID驗SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒copy-only或錯誤trigger；若raw.host不等於Hermes Agent或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無實際skill loader；API_ONLY無loader為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-702455102b0e｜AGENT_SKILL/PREW3_SHADOW｜Codex｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L63，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；實際skill loader；API_ONLY無loader為NOFIT。
- input→behavior→typed output：source-bound input→SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Codex/AGENT_SKILL/PREW3_SHADOW/ON：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒copy-only或錯誤trigger；若raw.host不等於Codex或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無實際skill loader；API_ONLY無loader為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-d7b2369a3d11｜AGENT_SKILL/PREW3_SHADOW｜Codex｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L64，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；實際skill loader；API_ONLY無loader為NOFIT。
- input→behavior→typed output：source-bound input→SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Codex/AGENT_SKILL/PREW3_SHADOW/OFF：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒copy-only或錯誤trigger；若raw.host不等於Codex或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無實際skill loader；API_ONLY無loader為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-3b2af66f8936｜AGENT_SKILL/PREW3_SHADOW｜Claude Code｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L65，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；實際skill loader；API_ONLY無loader為NOFIT。
- input→behavior→typed output：source-bound input→SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Claude Code/AGENT_SKILL/PREW3_SHADOW/ON：Claude Code當期原loader＋乾淨session驗SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒copy-only或錯誤trigger；若raw.host不等於Claude Code或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無實際skill loader；API_ONLY無loader為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-46f0028dabe2｜AGENT_SKILL/PREW3_SHADOW｜Claude Code｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L66，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；實際skill loader；API_ONLY無loader為NOFIT。
- input→behavior→typed output：source-bound input→SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Claude Code/AGENT_SKILL/PREW3_SHADOW/OFF：Claude Code當期原loader＋乾淨session驗SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒copy-only或錯誤trigger；若raw.host不等於Claude Code或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無實際skill loader；API_ONLY無loader為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-ae3081300a06｜AGENT_SKILL/PREW3_SHADOW｜DeepSeek Harness｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L67，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；實際skill loader；API_ONLY無loader為NOFIT。
- input→behavior→typed output：source-bound input→SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：DeepSeek Harness/AGENT_SKILL/PREW3_SHADOW/ON：實際Harness adapter/capability reader；API_ONLY不能充loader驗SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒copy-only或錯誤trigger；若raw.host不等於DeepSeek Harness或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無實際skill loader；API_ONLY無loader為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-79aa1ca6c95f｜AGENT_SKILL/PREW3_SHADOW｜DeepSeek Harness｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L68，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；實際skill loader；API_ONLY無loader為NOFIT。
- input→behavior→typed output：source-bound input→SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：DeepSeek Harness/AGENT_SKILL/PREW3_SHADOW/OFF：實際Harness adapter/capability reader；API_ONLY不能充loader驗SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒copy-only或錯誤trigger；若raw.host不等於DeepSeek Harness或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無實際skill loader；API_ONLY無loader為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-706d7dabb0a0｜AGENT_SKILL/SWOF_CONNECTED｜Hermes Agent｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L69，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；實際skill loader；API_ONLY無loader為NOFIT。
- input→behavior→typed output：source-bound input→SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Hermes Agent/AGENT_SKILL/SWOF_CONNECTED/ON：原Hermes tool/skill loader與worker fresh PID驗SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒copy-only或錯誤trigger；若raw.host不等於Hermes Agent或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無實際skill loader；API_ONLY無loader為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-aab24b0f82f9｜AGENT_SKILL/SWOF_CONNECTED｜Hermes Agent｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L70，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；實際skill loader；API_ONLY無loader為NOFIT。
- input→behavior→typed output：source-bound input→SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Hermes Agent/AGENT_SKILL/SWOF_CONNECTED/OFF：原Hermes tool/skill loader與worker fresh PID驗SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒copy-only或錯誤trigger；若raw.host不等於Hermes Agent或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無實際skill loader；API_ONLY無loader為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-75634c7787b2｜AGENT_SKILL/SWOF_CONNECTED｜Codex｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L71，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；實際skill loader；API_ONLY無loader為NOFIT。
- input→behavior→typed output：source-bound input→SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Codex/AGENT_SKILL/SWOF_CONNECTED/ON：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒copy-only或錯誤trigger；若raw.host不等於Codex或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無實際skill loader；API_ONLY無loader為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-e341b6d0f605｜AGENT_SKILL/SWOF_CONNECTED｜Codex｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L72，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；實際skill loader；API_ONLY無loader為NOFIT。
- input→behavior→typed output：source-bound input→SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Codex/AGENT_SKILL/SWOF_CONNECTED/OFF：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒copy-only或錯誤trigger；若raw.host不等於Codex或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無實際skill loader；API_ONLY無loader為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-e9941d45073f｜AGENT_SKILL/SWOF_CONNECTED｜Claude Code｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L73，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；實際skill loader；API_ONLY無loader為NOFIT。
- input→behavior→typed output：source-bound input→SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Claude Code/AGENT_SKILL/SWOF_CONNECTED/ON：Claude Code當期原loader＋乾淨session驗SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒copy-only或錯誤trigger；若raw.host不等於Claude Code或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無實際skill loader；API_ONLY無loader為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-e51ce0738940｜AGENT_SKILL/SWOF_CONNECTED｜Claude Code｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L74，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；實際skill loader；API_ONLY無loader為NOFIT。
- input→behavior→typed output：source-bound input→SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Claude Code/AGENT_SKILL/SWOF_CONNECTED/OFF：Claude Code當期原loader＋乾淨session驗SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒copy-only或錯誤trigger；若raw.host不等於Claude Code或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無實際skill loader；API_ONLY無loader為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-48757186c510｜AGENT_SKILL/SWOF_CONNECTED｜DeepSeek Harness｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L75，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；實際skill loader；API_ONLY無loader為NOFIT。
- input→behavior→typed output：source-bound input→SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：DeepSeek Harness/AGENT_SKILL/SWOF_CONNECTED/ON：實際Harness adapter/capability reader；API_ONLY不能充loader驗SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒copy-only或錯誤trigger；若raw.host不等於DeepSeek Harness或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無實際skill loader；API_ONLY無loader為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-9df05458d74f｜AGENT_SKILL/SWOF_CONNECTED｜DeepSeek Harness｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L76，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；實際skill loader；API_ONLY無loader為NOFIT。
- input→behavior→typed output：source-bound input→SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：DeepSeek Harness/AGENT_SKILL/SWOF_CONNECTED/OFF：實際Harness adapter/capability reader；API_ONLY不能充loader驗SKILL.md/reference/manifest在允許Host discover/load/trigger/nontrigger/unload；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒copy-only或錯誤trigger；若raw.host不等於DeepSeek Harness或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無實際skill loader；API_ONLY無loader為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-52b5e63d094d｜SIMPLE_AGENT/STANDALONE｜Hermes Agent｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L77，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；原Host tool-call runner；無tool capability為NOFIT。
- input→behavior→typed output：source-bound input→agent config+tool allowlist+timeout/attempt budget+stop checkpoint→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Hermes Agent/SIMPLE_AGENT/STANDALONE/ON：原Hermes tool/skill loader與worker fresh PID驗agent config+tool allowlist+timeout/attempt budget+stop checkpoint；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒無限loop或工具擴權；若raw.host不等於Hermes Agent或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無原Host tool-call runner；無tool capability為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-1c821c1ea7d8｜SIMPLE_AGENT/STANDALONE｜Hermes Agent｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L78，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；原Host tool-call runner；無tool capability為NOFIT。
- input→behavior→typed output：source-bound input→agent config+tool allowlist+timeout/attempt budget+stop checkpoint→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Hermes Agent/SIMPLE_AGENT/STANDALONE/OFF：原Hermes tool/skill loader與worker fresh PID驗agent config+tool allowlist+timeout/attempt budget+stop checkpoint；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒無限loop或工具擴權；若raw.host不等於Hermes Agent或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無原Host tool-call runner；無tool capability為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-3a2a9dad37ae｜SIMPLE_AGENT/STANDALONE｜Codex｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L79，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；原Host tool-call runner；無tool capability為NOFIT。
- input→behavior→typed output：source-bound input→agent config+tool allowlist+timeout/attempt budget+stop checkpoint→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Codex/SIMPLE_AGENT/STANDALONE/ON：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗agent config+tool allowlist+timeout/attempt budget+stop checkpoint；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒無限loop或工具擴權；若raw.host不等於Codex或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無原Host tool-call runner；無tool capability為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-87b5a1fe58cf｜SIMPLE_AGENT/STANDALONE｜Codex｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L80，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；原Host tool-call runner；無tool capability為NOFIT。
- input→behavior→typed output：source-bound input→agent config+tool allowlist+timeout/attempt budget+stop checkpoint→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Codex/SIMPLE_AGENT/STANDALONE/OFF：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗agent config+tool allowlist+timeout/attempt budget+stop checkpoint；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒無限loop或工具擴權；若raw.host不等於Codex或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無原Host tool-call runner；無tool capability為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-9e24d28c894c｜SIMPLE_AGENT/STANDALONE｜Claude Code｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L81，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；原Host tool-call runner；無tool capability為NOFIT。
- input→behavior→typed output：source-bound input→agent config+tool allowlist+timeout/attempt budget+stop checkpoint→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Claude Code/SIMPLE_AGENT/STANDALONE/ON：Claude Code當期原loader＋乾淨session驗agent config+tool allowlist+timeout/attempt budget+stop checkpoint；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒無限loop或工具擴權；若raw.host不等於Claude Code或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無原Host tool-call runner；無tool capability為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-94a990f58257｜SIMPLE_AGENT/STANDALONE｜Claude Code｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L82，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；原Host tool-call runner；無tool capability為NOFIT。
- input→behavior→typed output：source-bound input→agent config+tool allowlist+timeout/attempt budget+stop checkpoint→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Claude Code/SIMPLE_AGENT/STANDALONE/OFF：Claude Code當期原loader＋乾淨session驗agent config+tool allowlist+timeout/attempt budget+stop checkpoint；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒無限loop或工具擴權；若raw.host不等於Claude Code或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無原Host tool-call runner；無tool capability為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-f0a4964020d6｜SIMPLE_AGENT/STANDALONE｜DeepSeek Harness｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L83，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；原Host tool-call runner；無tool capability為NOFIT。
- input→behavior→typed output：source-bound input→agent config+tool allowlist+timeout/attempt budget+stop checkpoint→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：DeepSeek Harness/SIMPLE_AGENT/STANDALONE/ON：實際Harness adapter/capability reader；API_ONLY不能充loader驗agent config+tool allowlist+timeout/attempt budget+stop checkpoint；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒無限loop或工具擴權；若raw.host不等於DeepSeek Harness或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無原Host tool-call runner；無tool capability為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-8ba7cd2138c5｜SIMPLE_AGENT/STANDALONE｜DeepSeek Harness｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L84，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；原Host tool-call runner；無tool capability為NOFIT。
- input→behavior→typed output：source-bound input→agent config+tool allowlist+timeout/attempt budget+stop checkpoint→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：DeepSeek Harness/SIMPLE_AGENT/STANDALONE/OFF：實際Harness adapter/capability reader；API_ONLY不能充loader驗agent config+tool allowlist+timeout/attempt budget+stop checkpoint；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒無限loop或工具擴權；若raw.host不等於DeepSeek Harness或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無原Host tool-call runner；無tool capability為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-e704b0923b71｜SIMPLE_AGENT/PREW3_SHADOW｜Hermes Agent｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L85，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；原Host tool-call runner；無tool capability為NOFIT。
- input→behavior→typed output：source-bound input→agent config+tool allowlist+timeout/attempt budget+stop checkpoint→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Hermes Agent/SIMPLE_AGENT/PREW3_SHADOW/ON：原Hermes tool/skill loader與worker fresh PID驗agent config+tool allowlist+timeout/attempt budget+stop checkpoint；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒無限loop或工具擴權；若raw.host不等於Hermes Agent或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無原Host tool-call runner；無tool capability為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-834018317c72｜SIMPLE_AGENT/PREW3_SHADOW｜Hermes Agent｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L86，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；原Host tool-call runner；無tool capability為NOFIT。
- input→behavior→typed output：source-bound input→agent config+tool allowlist+timeout/attempt budget+stop checkpoint→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Hermes Agent/SIMPLE_AGENT/PREW3_SHADOW/OFF：原Hermes tool/skill loader與worker fresh PID驗agent config+tool allowlist+timeout/attempt budget+stop checkpoint；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒無限loop或工具擴權；若raw.host不等於Hermes Agent或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無原Host tool-call runner；無tool capability為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-a433df5357ac｜SIMPLE_AGENT/PREW3_SHADOW｜Codex｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L87，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；原Host tool-call runner；無tool capability為NOFIT。
- input→behavior→typed output：source-bound input→agent config+tool allowlist+timeout/attempt budget+stop checkpoint→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Codex/SIMPLE_AGENT/PREW3_SHADOW/ON：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗agent config+tool allowlist+timeout/attempt budget+stop checkpoint；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒無限loop或工具擴權；若raw.host不等於Codex或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無原Host tool-call runner；無tool capability為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-d92746482fe6｜SIMPLE_AGENT/PREW3_SHADOW｜Codex｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L88，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；原Host tool-call runner；無tool capability為NOFIT。
- input→behavior→typed output：source-bound input→agent config+tool allowlist+timeout/attempt budget+stop checkpoint→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Codex/SIMPLE_AGENT/PREW3_SHADOW/OFF：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗agent config+tool allowlist+timeout/attempt budget+stop checkpoint；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒無限loop或工具擴權；若raw.host不等於Codex或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無原Host tool-call runner；無tool capability為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-3083c98d4210｜SIMPLE_AGENT/PREW3_SHADOW｜Claude Code｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L89，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；原Host tool-call runner；無tool capability為NOFIT。
- input→behavior→typed output：source-bound input→agent config+tool allowlist+timeout/attempt budget+stop checkpoint→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Claude Code/SIMPLE_AGENT/PREW3_SHADOW/ON：Claude Code當期原loader＋乾淨session驗agent config+tool allowlist+timeout/attempt budget+stop checkpoint；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒無限loop或工具擴權；若raw.host不等於Claude Code或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無原Host tool-call runner；無tool capability為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-97174a3d45e8｜SIMPLE_AGENT/PREW3_SHADOW｜Claude Code｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L90，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；原Host tool-call runner；無tool capability為NOFIT。
- input→behavior→typed output：source-bound input→agent config+tool allowlist+timeout/attempt budget+stop checkpoint→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Claude Code/SIMPLE_AGENT/PREW3_SHADOW/OFF：Claude Code當期原loader＋乾淨session驗agent config+tool allowlist+timeout/attempt budget+stop checkpoint；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒無限loop或工具擴權；若raw.host不等於Claude Code或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無原Host tool-call runner；無tool capability為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-84fa01909649｜SIMPLE_AGENT/PREW3_SHADOW｜DeepSeek Harness｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L91，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；原Host tool-call runner；無tool capability為NOFIT。
- input→behavior→typed output：source-bound input→agent config+tool allowlist+timeout/attempt budget+stop checkpoint→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：DeepSeek Harness/SIMPLE_AGENT/PREW3_SHADOW/ON：實際Harness adapter/capability reader；API_ONLY不能充loader驗agent config+tool allowlist+timeout/attempt budget+stop checkpoint；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒無限loop或工具擴權；若raw.host不等於DeepSeek Harness或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無原Host tool-call runner；無tool capability為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-f77b24e32aaa｜SIMPLE_AGENT/PREW3_SHADOW｜DeepSeek Harness｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L92，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；原Host tool-call runner；無tool capability為NOFIT。
- input→behavior→typed output：source-bound input→agent config+tool allowlist+timeout/attempt budget+stop checkpoint→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：DeepSeek Harness/SIMPLE_AGENT/PREW3_SHADOW/OFF：實際Harness adapter/capability reader；API_ONLY不能充loader驗agent config+tool allowlist+timeout/attempt budget+stop checkpoint；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒無限loop或工具擴權；若raw.host不等於DeepSeek Harness或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無原Host tool-call runner；無tool capability為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-c1788f1272d7｜SIMPLE_AGENT/SWOF_CONNECTED｜Hermes Agent｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L93，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；原Host tool-call runner；無tool capability為NOFIT。
- input→behavior→typed output：source-bound input→agent config+tool allowlist+timeout/attempt budget+stop checkpoint→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Hermes Agent/SIMPLE_AGENT/SWOF_CONNECTED/ON：原Hermes tool/skill loader與worker fresh PID驗agent config+tool allowlist+timeout/attempt budget+stop checkpoint；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒無限loop或工具擴權；若raw.host不等於Hermes Agent或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無原Host tool-call runner；無tool capability為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-2a6bfd344f3f｜SIMPLE_AGENT/SWOF_CONNECTED｜Hermes Agent｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L94，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；原Host tool-call runner；無tool capability為NOFIT。
- input→behavior→typed output：source-bound input→agent config+tool allowlist+timeout/attempt budget+stop checkpoint→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Hermes Agent/SIMPLE_AGENT/SWOF_CONNECTED/OFF：原Hermes tool/skill loader與worker fresh PID驗agent config+tool allowlist+timeout/attempt budget+stop checkpoint；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒無限loop或工具擴權；若raw.host不等於Hermes Agent或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無原Host tool-call runner；無tool capability為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-e2daf2609c40｜SIMPLE_AGENT/SWOF_CONNECTED｜Codex｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L95，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；原Host tool-call runner；無tool capability為NOFIT。
- input→behavior→typed output：source-bound input→agent config+tool allowlist+timeout/attempt budget+stop checkpoint→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Codex/SIMPLE_AGENT/SWOF_CONNECTED/ON：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗agent config+tool allowlist+timeout/attempt budget+stop checkpoint；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒無限loop或工具擴權；若raw.host不等於Codex或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無原Host tool-call runner；無tool capability為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-d880b5ac23a4｜SIMPLE_AGENT/SWOF_CONNECTED｜Codex｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L96，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；原Host tool-call runner；無tool capability為NOFIT。
- input→behavior→typed output：source-bound input→agent config+tool allowlist+timeout/attempt budget+stop checkpoint→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Codex/SIMPLE_AGENT/SWOF_CONNECTED/OFF：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗agent config+tool allowlist+timeout/attempt budget+stop checkpoint；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒無限loop或工具擴權；若raw.host不等於Codex或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無原Host tool-call runner；無tool capability為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-ef6dac107879｜SIMPLE_AGENT/SWOF_CONNECTED｜Claude Code｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L97，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；原Host tool-call runner；無tool capability為NOFIT。
- input→behavior→typed output：source-bound input→agent config+tool allowlist+timeout/attempt budget+stop checkpoint→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Claude Code/SIMPLE_AGENT/SWOF_CONNECTED/ON：Claude Code當期原loader＋乾淨session驗agent config+tool allowlist+timeout/attempt budget+stop checkpoint；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒無限loop或工具擴權；若raw.host不等於Claude Code或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無原Host tool-call runner；無tool capability為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-c1ae4375bd05｜SIMPLE_AGENT/SWOF_CONNECTED｜Claude Code｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L98，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；原Host tool-call runner；無tool capability為NOFIT。
- input→behavior→typed output：source-bound input→agent config+tool allowlist+timeout/attempt budget+stop checkpoint→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Claude Code/SIMPLE_AGENT/SWOF_CONNECTED/OFF：Claude Code當期原loader＋乾淨session驗agent config+tool allowlist+timeout/attempt budget+stop checkpoint；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒無限loop或工具擴權；若raw.host不等於Claude Code或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無原Host tool-call runner；無tool capability為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-09c21bb6612b｜SIMPLE_AGENT/SWOF_CONNECTED｜DeepSeek Harness｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L99，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；原Host tool-call runner；無tool capability為NOFIT。
- input→behavior→typed output：source-bound input→agent config+tool allowlist+timeout/attempt budget+stop checkpoint→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：DeepSeek Harness/SIMPLE_AGENT/SWOF_CONNECTED/ON：實際Harness adapter/capability reader；API_ONLY不能充loader驗agent config+tool allowlist+timeout/attempt budget+stop checkpoint；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒無限loop或工具擴權；若raw.host不等於DeepSeek Harness或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無原Host tool-call runner；無tool capability為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-9be3a648f57b｜SIMPLE_AGENT/SWOF_CONNECTED｜DeepSeek Harness｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L100，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；原Host tool-call runner；無tool capability為NOFIT。
- input→behavior→typed output：source-bound input→agent config+tool allowlist+timeout/attempt budget+stop checkpoint→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：DeepSeek Harness/SIMPLE_AGENT/SWOF_CONNECTED/OFF：實際Harness adapter/capability reader；API_ONLY不能充loader驗agent config+tool allowlist+timeout/attempt budget+stop checkpoint；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒無限loop或工具擴權；若raw.host不等於DeepSeek Harness或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無原Host tool-call runner；無tool capability為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-90776ef8d07b｜PLUGIN/STANDALONE｜Hermes Agent｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L101，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；原Host plugin loader；API_ONLY為NOFIT。
- input→behavior→typed output：source-bound input→manifest publisher/version/license/permissions；Host載入、調用及移除→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Hermes Agent/PLUGIN/STANDALONE/ON：原Hermes tool/skill loader與worker fresh PID驗manifest publisher/version/license/permissions；Host載入、調用及移除；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒不支援Host或未讀manifest權限；若raw.host不等於Hermes Agent或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無原Host plugin loader；API_ONLY為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-f6718f8c8a9f｜PLUGIN/STANDALONE｜Hermes Agent｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L102，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；原Host plugin loader；API_ONLY為NOFIT。
- input→behavior→typed output：source-bound input→manifest publisher/version/license/permissions；Host載入、調用及移除→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Hermes Agent/PLUGIN/STANDALONE/OFF：原Hermes tool/skill loader與worker fresh PID驗manifest publisher/version/license/permissions；Host載入、調用及移除；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒不支援Host或未讀manifest權限；若raw.host不等於Hermes Agent或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無原Host plugin loader；API_ONLY為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-b4c34ec88f14｜PLUGIN/STANDALONE｜Codex｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L103，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；原Host plugin loader；API_ONLY為NOFIT。
- input→behavior→typed output：source-bound input→manifest publisher/version/license/permissions；Host載入、調用及移除→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Codex/PLUGIN/STANDALONE/ON：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗manifest publisher/version/license/permissions；Host載入、調用及移除；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒不支援Host或未讀manifest權限；若raw.host不等於Codex或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無原Host plugin loader；API_ONLY為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-530a88ba777d｜PLUGIN/STANDALONE｜Codex｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L104，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；原Host plugin loader；API_ONLY為NOFIT。
- input→behavior→typed output：source-bound input→manifest publisher/version/license/permissions；Host載入、調用及移除→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Codex/PLUGIN/STANDALONE/OFF：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗manifest publisher/version/license/permissions；Host載入、調用及移除；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒不支援Host或未讀manifest權限；若raw.host不等於Codex或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無原Host plugin loader；API_ONLY為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-1a9181fe48c5｜PLUGIN/STANDALONE｜Claude Code｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L105，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；原Host plugin loader；API_ONLY為NOFIT。
- input→behavior→typed output：source-bound input→manifest publisher/version/license/permissions；Host載入、調用及移除→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Claude Code/PLUGIN/STANDALONE/ON：Claude Code當期原loader＋乾淨session驗manifest publisher/version/license/permissions；Host載入、調用及移除；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒不支援Host或未讀manifest權限；若raw.host不等於Claude Code或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無原Host plugin loader；API_ONLY為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-5334bc0dc4e0｜PLUGIN/STANDALONE｜Claude Code｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L106，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；原Host plugin loader；API_ONLY為NOFIT。
- input→behavior→typed output：source-bound input→manifest publisher/version/license/permissions；Host載入、調用及移除→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Claude Code/PLUGIN/STANDALONE/OFF：Claude Code當期原loader＋乾淨session驗manifest publisher/version/license/permissions；Host載入、調用及移除；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒不支援Host或未讀manifest權限；若raw.host不等於Claude Code或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無原Host plugin loader；API_ONLY為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-ecca30d3d545｜PLUGIN/STANDALONE｜DeepSeek Harness｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L107，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；原Host plugin loader；API_ONLY為NOFIT。
- input→behavior→typed output：source-bound input→manifest publisher/version/license/permissions；Host載入、調用及移除→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：DeepSeek Harness/PLUGIN/STANDALONE/ON：實際Harness adapter/capability reader；API_ONLY不能充loader驗manifest publisher/version/license/permissions；Host載入、調用及移除；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒不支援Host或未讀manifest權限；若raw.host不等於DeepSeek Harness或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無原Host plugin loader；API_ONLY為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-6acbaf567779｜PLUGIN/STANDALONE｜DeepSeek Harness｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L108，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；原Host plugin loader；API_ONLY為NOFIT。
- input→behavior→typed output：source-bound input→manifest publisher/version/license/permissions；Host載入、調用及移除→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：DeepSeek Harness/PLUGIN/STANDALONE/OFF：實際Harness adapter/capability reader；API_ONLY不能充loader驗manifest publisher/version/license/permissions；Host載入、調用及移除；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒不支援Host或未讀manifest權限；若raw.host不等於DeepSeek Harness或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無原Host plugin loader；API_ONLY為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-f686d9f67c17｜PLUGIN/PREW3_SHADOW｜Hermes Agent｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L109，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；原Host plugin loader；API_ONLY為NOFIT。
- input→behavior→typed output：source-bound input→manifest publisher/version/license/permissions；Host載入、調用及移除→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Hermes Agent/PLUGIN/PREW3_SHADOW/ON：原Hermes tool/skill loader與worker fresh PID驗manifest publisher/version/license/permissions；Host載入、調用及移除；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒不支援Host或未讀manifest權限；若raw.host不等於Hermes Agent或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無原Host plugin loader；API_ONLY為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-675386c0f943｜PLUGIN/PREW3_SHADOW｜Hermes Agent｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L110，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；原Host plugin loader；API_ONLY為NOFIT。
- input→behavior→typed output：source-bound input→manifest publisher/version/license/permissions；Host載入、調用及移除→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Hermes Agent/PLUGIN/PREW3_SHADOW/OFF：原Hermes tool/skill loader與worker fresh PID驗manifest publisher/version/license/permissions；Host載入、調用及移除；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒不支援Host或未讀manifest權限；若raw.host不等於Hermes Agent或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無原Host plugin loader；API_ONLY為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-412732ed745d｜PLUGIN/PREW3_SHADOW｜Codex｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L111，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；原Host plugin loader；API_ONLY為NOFIT。
- input→behavior→typed output：source-bound input→manifest publisher/version/license/permissions；Host載入、調用及移除→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Codex/PLUGIN/PREW3_SHADOW/ON：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗manifest publisher/version/license/permissions；Host載入、調用及移除；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒不支援Host或未讀manifest權限；若raw.host不等於Codex或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無原Host plugin loader；API_ONLY為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-9cc9f40bc2ac｜PLUGIN/PREW3_SHADOW｜Codex｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L112，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；原Host plugin loader；API_ONLY為NOFIT。
- input→behavior→typed output：source-bound input→manifest publisher/version/license/permissions；Host載入、調用及移除→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Codex/PLUGIN/PREW3_SHADOW/OFF：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗manifest publisher/version/license/permissions；Host載入、調用及移除；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒不支援Host或未讀manifest權限；若raw.host不等於Codex或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無原Host plugin loader；API_ONLY為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-2259ef3f0dc2｜PLUGIN/PREW3_SHADOW｜Claude Code｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L113，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；原Host plugin loader；API_ONLY為NOFIT。
- input→behavior→typed output：source-bound input→manifest publisher/version/license/permissions；Host載入、調用及移除→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Claude Code/PLUGIN/PREW3_SHADOW/ON：Claude Code當期原loader＋乾淨session驗manifest publisher/version/license/permissions；Host載入、調用及移除；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒不支援Host或未讀manifest權限；若raw.host不等於Claude Code或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無原Host plugin loader；API_ONLY為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-4f536bbc5402｜PLUGIN/PREW3_SHADOW｜Claude Code｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L114，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；原Host plugin loader；API_ONLY為NOFIT。
- input→behavior→typed output：source-bound input→manifest publisher/version/license/permissions；Host載入、調用及移除→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Claude Code/PLUGIN/PREW3_SHADOW/OFF：Claude Code當期原loader＋乾淨session驗manifest publisher/version/license/permissions；Host載入、調用及移除；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒不支援Host或未讀manifest權限；若raw.host不等於Claude Code或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無原Host plugin loader；API_ONLY為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-bc4919027c0c｜PLUGIN/PREW3_SHADOW｜DeepSeek Harness｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L115，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；原Host plugin loader；API_ONLY為NOFIT。
- input→behavior→typed output：source-bound input→manifest publisher/version/license/permissions；Host載入、調用及移除→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：DeepSeek Harness/PLUGIN/PREW3_SHADOW/ON：實際Harness adapter/capability reader；API_ONLY不能充loader驗manifest publisher/version/license/permissions；Host載入、調用及移除；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒不支援Host或未讀manifest權限；若raw.host不等於DeepSeek Harness或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無原Host plugin loader；API_ONLY為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-06bbd5e5ecb2｜PLUGIN/PREW3_SHADOW｜DeepSeek Harness｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L116，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；原Host plugin loader；API_ONLY為NOFIT。
- input→behavior→typed output：source-bound input→manifest publisher/version/license/permissions；Host載入、調用及移除→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：DeepSeek Harness/PLUGIN/PREW3_SHADOW/OFF：實際Harness adapter/capability reader；API_ONLY不能充loader驗manifest publisher/version/license/permissions；Host載入、調用及移除；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒不支援Host或未讀manifest權限；若raw.host不等於DeepSeek Harness或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無原Host plugin loader；API_ONLY為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-d19d2e42002a｜PLUGIN/SWOF_CONNECTED｜Hermes Agent｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L117，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；原Host plugin loader；API_ONLY為NOFIT。
- input→behavior→typed output：source-bound input→manifest publisher/version/license/permissions；Host載入、調用及移除→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Hermes Agent/PLUGIN/SWOF_CONNECTED/ON：原Hermes tool/skill loader與worker fresh PID驗manifest publisher/version/license/permissions；Host載入、調用及移除；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒不支援Host或未讀manifest權限；若raw.host不等於Hermes Agent或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無原Host plugin loader；API_ONLY為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-49cdd601f213｜PLUGIN/SWOF_CONNECTED｜Hermes Agent｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L118，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；原Host plugin loader；API_ONLY為NOFIT。
- input→behavior→typed output：source-bound input→manifest publisher/version/license/permissions；Host載入、調用及移除→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Hermes Agent/PLUGIN/SWOF_CONNECTED/OFF：原Hermes tool/skill loader與worker fresh PID驗manifest publisher/version/license/permissions；Host載入、調用及移除；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒不支援Host或未讀manifest權限；若raw.host不等於Hermes Agent或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無原Host plugin loader；API_ONLY為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-54d1a08c379f｜PLUGIN/SWOF_CONNECTED｜Codex｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L119，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；原Host plugin loader；API_ONLY為NOFIT。
- input→behavior→typed output：source-bound input→manifest publisher/version/license/permissions；Host載入、調用及移除→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Codex/PLUGIN/SWOF_CONNECTED/ON：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗manifest publisher/version/license/permissions；Host載入、調用及移除；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒不支援Host或未讀manifest權限；若raw.host不等於Codex或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無原Host plugin loader；API_ONLY為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-2ce069d50986｜PLUGIN/SWOF_CONNECTED｜Codex｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L120，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；原Host plugin loader；API_ONLY為NOFIT。
- input→behavior→typed output：source-bound input→manifest publisher/version/license/permissions；Host載入、調用及移除→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Codex/PLUGIN/SWOF_CONNECTED/OFF：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗manifest publisher/version/license/permissions；Host載入、調用及移除；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒不支援Host或未讀manifest權限；若raw.host不等於Codex或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無原Host plugin loader；API_ONLY為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-afca4537e0b5｜PLUGIN/SWOF_CONNECTED｜Claude Code｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L121，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；原Host plugin loader；API_ONLY為NOFIT。
- input→behavior→typed output：source-bound input→manifest publisher/version/license/permissions；Host載入、調用及移除→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Claude Code/PLUGIN/SWOF_CONNECTED/ON：Claude Code當期原loader＋乾淨session驗manifest publisher/version/license/permissions；Host載入、調用及移除；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒不支援Host或未讀manifest權限；若raw.host不等於Claude Code或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無原Host plugin loader；API_ONLY為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-ae862affcd7c｜PLUGIN/SWOF_CONNECTED｜Claude Code｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L122，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；原Host plugin loader；API_ONLY為NOFIT。
- input→behavior→typed output：source-bound input→manifest publisher/version/license/permissions；Host載入、調用及移除→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Claude Code/PLUGIN/SWOF_CONNECTED/OFF：Claude Code當期原loader＋乾淨session驗manifest publisher/version/license/permissions；Host載入、調用及移除；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒不支援Host或未讀manifest權限；若raw.host不等於Claude Code或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無原Host plugin loader；API_ONLY為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-8bf8d2ec3581｜PLUGIN/SWOF_CONNECTED｜DeepSeek Harness｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L123，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；原Host plugin loader；API_ONLY為NOFIT。
- input→behavior→typed output：source-bound input→manifest publisher/version/license/permissions；Host載入、調用及移除→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：DeepSeek Harness/PLUGIN/SWOF_CONNECTED/ON：實際Harness adapter/capability reader；API_ONLY不能充loader驗manifest publisher/version/license/permissions；Host載入、調用及移除；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒不支援Host或未讀manifest權限；若raw.host不等於DeepSeek Harness或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無原Host plugin loader；API_ONLY為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-085bc8fd7622｜PLUGIN/SWOF_CONNECTED｜DeepSeek Harness｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L124，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；原Host plugin loader；API_ONLY為NOFIT。
- input→behavior→typed output：source-bound input→manifest publisher/version/license/permissions；Host載入、調用及移除→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：DeepSeek Harness/PLUGIN/SWOF_CONNECTED/OFF：實際Harness adapter/capability reader；API_ONLY不能充loader驗manifest publisher/version/license/permissions；Host載入、調用及移除；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒不支援Host或未讀manifest權限；若raw.host不等於DeepSeek Harness或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無原Host plugin loader；API_ONLY為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-f6053f9a9dbf｜PROFILE/STANDALONE｜Hermes Agent｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L125，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；原Host Profile Reader；無profile interface為NOFIT。
- input→behavior→typed output：source-bound input→ProfileBinding/applicability+scope/loaded SHA與卸載還原→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Hermes Agent/PROFILE/STANDALONE/ON：原Hermes tool/skill loader與worker fresh PID驗ProfileBinding/applicability+scope/loaded SHA與卸載還原；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒selected當loaded或跨Scope套Profile；若raw.host不等於Hermes Agent或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無原Host Profile Reader；無profile interface為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-48759a93f265｜PROFILE/STANDALONE｜Hermes Agent｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L126，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；原Host Profile Reader；無profile interface為NOFIT。
- input→behavior→typed output：source-bound input→ProfileBinding/applicability+scope/loaded SHA與卸載還原→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Hermes Agent/PROFILE/STANDALONE/OFF：原Hermes tool/skill loader與worker fresh PID驗ProfileBinding/applicability+scope/loaded SHA與卸載還原；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒selected當loaded或跨Scope套Profile；若raw.host不等於Hermes Agent或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無原Host Profile Reader；無profile interface為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-ce7ed7519316｜PROFILE/STANDALONE｜Codex｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L127，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；原Host Profile Reader；無profile interface為NOFIT。
- input→behavior→typed output：source-bound input→ProfileBinding/applicability+scope/loaded SHA與卸載還原→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Codex/PROFILE/STANDALONE/ON：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗ProfileBinding/applicability+scope/loaded SHA與卸載還原；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒selected當loaded或跨Scope套Profile；若raw.host不等於Codex或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無原Host Profile Reader；無profile interface為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-e9109bda38f1｜PROFILE/STANDALONE｜Codex｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L128，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；原Host Profile Reader；無profile interface為NOFIT。
- input→behavior→typed output：source-bound input→ProfileBinding/applicability+scope/loaded SHA與卸載還原→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Codex/PROFILE/STANDALONE/OFF：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗ProfileBinding/applicability+scope/loaded SHA與卸載還原；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒selected當loaded或跨Scope套Profile；若raw.host不等於Codex或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無原Host Profile Reader；無profile interface為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-67282ac08b7e｜PROFILE/STANDALONE｜Claude Code｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L129，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；原Host Profile Reader；無profile interface為NOFIT。
- input→behavior→typed output：source-bound input→ProfileBinding/applicability+scope/loaded SHA與卸載還原→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Claude Code/PROFILE/STANDALONE/ON：Claude Code當期原loader＋乾淨session驗ProfileBinding/applicability+scope/loaded SHA與卸載還原；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒selected當loaded或跨Scope套Profile；若raw.host不等於Claude Code或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無原Host Profile Reader；無profile interface為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-77fe98764ab5｜PROFILE/STANDALONE｜Claude Code｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L130，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；原Host Profile Reader；無profile interface為NOFIT。
- input→behavior→typed output：source-bound input→ProfileBinding/applicability+scope/loaded SHA與卸載還原→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Claude Code/PROFILE/STANDALONE/OFF：Claude Code當期原loader＋乾淨session驗ProfileBinding/applicability+scope/loaded SHA與卸載還原；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒selected當loaded或跨Scope套Profile；若raw.host不等於Claude Code或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無原Host Profile Reader；無profile interface為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-24e9aedd8086｜PROFILE/STANDALONE｜DeepSeek Harness｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L131，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；原Host Profile Reader；無profile interface為NOFIT。
- input→behavior→typed output：source-bound input→ProfileBinding/applicability+scope/loaded SHA與卸載還原→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：DeepSeek Harness/PROFILE/STANDALONE/ON：實際Harness adapter/capability reader；API_ONLY不能充loader驗ProfileBinding/applicability+scope/loaded SHA與卸載還原；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒selected當loaded或跨Scope套Profile；若raw.host不等於DeepSeek Harness或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無原Host Profile Reader；無profile interface為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-75540fe3412c｜PROFILE/STANDALONE｜DeepSeek Harness｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L132，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；原Host Profile Reader；無profile interface為NOFIT。
- input→behavior→typed output：source-bound input→ProfileBinding/applicability+scope/loaded SHA與卸載還原→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：DeepSeek Harness/PROFILE/STANDALONE/OFF：實際Harness adapter/capability reader；API_ONLY不能充loader驗ProfileBinding/applicability+scope/loaded SHA與卸載還原；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒selected當loaded或跨Scope套Profile；若raw.host不等於DeepSeek Harness或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無原Host Profile Reader；無profile interface為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-e3f461767442｜PROFILE/PREW3_SHADOW｜Hermes Agent｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L133，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；原Host Profile Reader；無profile interface為NOFIT。
- input→behavior→typed output：source-bound input→ProfileBinding/applicability+scope/loaded SHA與卸載還原→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Hermes Agent/PROFILE/PREW3_SHADOW/ON：原Hermes tool/skill loader與worker fresh PID驗ProfileBinding/applicability+scope/loaded SHA與卸載還原；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒selected當loaded或跨Scope套Profile；若raw.host不等於Hermes Agent或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無原Host Profile Reader；無profile interface為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-491bbc480824｜PROFILE/PREW3_SHADOW｜Hermes Agent｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L134，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；原Host Profile Reader；無profile interface為NOFIT。
- input→behavior→typed output：source-bound input→ProfileBinding/applicability+scope/loaded SHA與卸載還原→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Hermes Agent/PROFILE/PREW3_SHADOW/OFF：原Hermes tool/skill loader與worker fresh PID驗ProfileBinding/applicability+scope/loaded SHA與卸載還原；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒selected當loaded或跨Scope套Profile；若raw.host不等於Hermes Agent或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無原Host Profile Reader；無profile interface為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-24862363699e｜PROFILE/PREW3_SHADOW｜Codex｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L135，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；原Host Profile Reader；無profile interface為NOFIT。
- input→behavior→typed output：source-bound input→ProfileBinding/applicability+scope/loaded SHA與卸載還原→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Codex/PROFILE/PREW3_SHADOW/ON：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗ProfileBinding/applicability+scope/loaded SHA與卸載還原；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒selected當loaded或跨Scope套Profile；若raw.host不等於Codex或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無原Host Profile Reader；無profile interface為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-b41a32121615｜PROFILE/PREW3_SHADOW｜Codex｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L136，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；原Host Profile Reader；無profile interface為NOFIT。
- input→behavior→typed output：source-bound input→ProfileBinding/applicability+scope/loaded SHA與卸載還原→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Codex/PROFILE/PREW3_SHADOW/OFF：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗ProfileBinding/applicability+scope/loaded SHA與卸載還原；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒selected當loaded或跨Scope套Profile；若raw.host不等於Codex或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無原Host Profile Reader；無profile interface為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-8605451d5dd2｜PROFILE/PREW3_SHADOW｜Claude Code｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L137，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；原Host Profile Reader；無profile interface為NOFIT。
- input→behavior→typed output：source-bound input→ProfileBinding/applicability+scope/loaded SHA與卸載還原→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Claude Code/PROFILE/PREW3_SHADOW/ON：Claude Code當期原loader＋乾淨session驗ProfileBinding/applicability+scope/loaded SHA與卸載還原；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒selected當loaded或跨Scope套Profile；若raw.host不等於Claude Code或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無原Host Profile Reader；無profile interface為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-9ca3d0377ed8｜PROFILE/PREW3_SHADOW｜Claude Code｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L138，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；原Host Profile Reader；無profile interface為NOFIT。
- input→behavior→typed output：source-bound input→ProfileBinding/applicability+scope/loaded SHA與卸載還原→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Claude Code/PROFILE/PREW3_SHADOW/OFF：Claude Code當期原loader＋乾淨session驗ProfileBinding/applicability+scope/loaded SHA與卸載還原；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒selected當loaded或跨Scope套Profile；若raw.host不等於Claude Code或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無原Host Profile Reader；無profile interface為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-dd12df59427a｜PROFILE/PREW3_SHADOW｜DeepSeek Harness｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L139，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；原Host Profile Reader；無profile interface為NOFIT。
- input→behavior→typed output：source-bound input→ProfileBinding/applicability+scope/loaded SHA與卸載還原→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：DeepSeek Harness/PROFILE/PREW3_SHADOW/ON：實際Harness adapter/capability reader；API_ONLY不能充loader驗ProfileBinding/applicability+scope/loaded SHA與卸載還原；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒selected當loaded或跨Scope套Profile；若raw.host不等於DeepSeek Harness或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無原Host Profile Reader；無profile interface為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-5ce6176dde4b｜PROFILE/PREW3_SHADOW｜DeepSeek Harness｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L140，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；原Host Profile Reader；無profile interface為NOFIT。
- input→behavior→typed output：source-bound input→ProfileBinding/applicability+scope/loaded SHA與卸載還原→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：DeepSeek Harness/PROFILE/PREW3_SHADOW/OFF：實際Harness adapter/capability reader；API_ONLY不能充loader驗ProfileBinding/applicability+scope/loaded SHA與卸載還原；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒selected當loaded或跨Scope套Profile；若raw.host不等於DeepSeek Harness或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無原Host Profile Reader；無profile interface為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-40ec4e4388b4｜PROFILE/SWOF_CONNECTED｜Hermes Agent｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L141，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；原Host Profile Reader；無profile interface為NOFIT。
- input→behavior→typed output：source-bound input→ProfileBinding/applicability+scope/loaded SHA與卸載還原→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Hermes Agent/PROFILE/SWOF_CONNECTED/ON：原Hermes tool/skill loader與worker fresh PID驗ProfileBinding/applicability+scope/loaded SHA與卸載還原；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒selected當loaded或跨Scope套Profile；若raw.host不等於Hermes Agent或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無原Host Profile Reader；無profile interface為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-0836e4dc5096｜PROFILE/SWOF_CONNECTED｜Hermes Agent｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L142，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；原Host Profile Reader；無profile interface為NOFIT。
- input→behavior→typed output：source-bound input→ProfileBinding/applicability+scope/loaded SHA與卸載還原→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Hermes Agent/PROFILE/SWOF_CONNECTED/OFF：原Hermes tool/skill loader與worker fresh PID驗ProfileBinding/applicability+scope/loaded SHA與卸載還原；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒selected當loaded或跨Scope套Profile；若raw.host不等於Hermes Agent或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無原Host Profile Reader；無profile interface為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-57abd1af6eca｜PROFILE/SWOF_CONNECTED｜Codex｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L143，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；原Host Profile Reader；無profile interface為NOFIT。
- input→behavior→typed output：source-bound input→ProfileBinding/applicability+scope/loaded SHA與卸載還原→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Codex/PROFILE/SWOF_CONNECTED/ON：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗ProfileBinding/applicability+scope/loaded SHA與卸載還原；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒selected當loaded或跨Scope套Profile；若raw.host不等於Codex或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無原Host Profile Reader；無profile interface為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-9bf92fc1f576｜PROFILE/SWOF_CONNECTED｜Codex｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L144，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；原Host Profile Reader；無profile interface為NOFIT。
- input→behavior→typed output：source-bound input→ProfileBinding/applicability+scope/loaded SHA與卸載還原→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Codex/PROFILE/SWOF_CONNECTED/OFF：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗ProfileBinding/applicability+scope/loaded SHA與卸載還原；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒selected當loaded或跨Scope套Profile；若raw.host不等於Codex或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無原Host Profile Reader；無profile interface為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-ac9b0f671ba6｜PROFILE/SWOF_CONNECTED｜Claude Code｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L145，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；原Host Profile Reader；無profile interface為NOFIT。
- input→behavior→typed output：source-bound input→ProfileBinding/applicability+scope/loaded SHA與卸載還原→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Claude Code/PROFILE/SWOF_CONNECTED/ON：Claude Code當期原loader＋乾淨session驗ProfileBinding/applicability+scope/loaded SHA與卸載還原；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒selected當loaded或跨Scope套Profile；若raw.host不等於Claude Code或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無原Host Profile Reader；無profile interface為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-c798b8d56448｜PROFILE/SWOF_CONNECTED｜Claude Code｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L146，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；原Host Profile Reader；無profile interface為NOFIT。
- input→behavior→typed output：source-bound input→ProfileBinding/applicability+scope/loaded SHA與卸載還原→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Claude Code/PROFILE/SWOF_CONNECTED/OFF：Claude Code當期原loader＋乾淨session驗ProfileBinding/applicability+scope/loaded SHA與卸載還原；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒selected當loaded或跨Scope套Profile；若raw.host不等於Claude Code或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無原Host Profile Reader；無profile interface為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-44b29464a95a｜PROFILE/SWOF_CONNECTED｜DeepSeek Harness｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L147，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；原Host Profile Reader；無profile interface為NOFIT。
- input→behavior→typed output：source-bound input→ProfileBinding/applicability+scope/loaded SHA與卸載還原→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：DeepSeek Harness/PROFILE/SWOF_CONNECTED/ON：實際Harness adapter/capability reader；API_ONLY不能充loader驗ProfileBinding/applicability+scope/loaded SHA與卸載還原；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒selected當loaded或跨Scope套Profile；若raw.host不等於DeepSeek Harness或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無原Host Profile Reader；無profile interface為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-db54604c0f5b｜PROFILE/SWOF_CONNECTED｜DeepSeek Harness｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L148，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；原Host Profile Reader；無profile interface為NOFIT。
- input→behavior→typed output：source-bound input→ProfileBinding/applicability+scope/loaded SHA與卸載還原→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：DeepSeek Harness/PROFILE/SWOF_CONNECTED/OFF：實際Harness adapter/capability reader；API_ONLY不能充loader驗ProfileBinding/applicability+scope/loaded SHA與卸載還原；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒selected當loaded或跨Scope套Profile；若raw.host不等於DeepSeek Harness或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無原Host Profile Reader；無profile interface為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-afca55403585｜AGENT_OS/STANDALONE｜Hermes Agent｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L149，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT。
- input→behavior→typed output：source-bound input→正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Hermes Agent/AGENT_OS/STANDALONE/ON：原Hermes tool/skill loader與worker fresh PID驗正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒規劃文本冒可執行OS；若raw.host不等於Hermes Agent或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-df93f59a1365｜AGENT_OS/STANDALONE｜Hermes Agent｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L150，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT。
- input→behavior→typed output：source-bound input→正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Hermes Agent/AGENT_OS/STANDALONE/OFF：原Hermes tool/skill loader與worker fresh PID驗正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒規劃文本冒可執行OS；若raw.host不等於Hermes Agent或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-6c851f664a31｜AGENT_OS/STANDALONE｜Codex｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L151，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT。
- input→behavior→typed output：source-bound input→正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Codex/AGENT_OS/STANDALONE/ON：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒規劃文本冒可執行OS；若raw.host不等於Codex或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-0af202afbd93｜AGENT_OS/STANDALONE｜Codex｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L152，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT。
- input→behavior→typed output：source-bound input→正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Codex/AGENT_OS/STANDALONE/OFF：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒規劃文本冒可執行OS；若raw.host不等於Codex或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-97fb84872359｜AGENT_OS/STANDALONE｜Claude Code｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L153，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT。
- input→behavior→typed output：source-bound input→正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Claude Code/AGENT_OS/STANDALONE/ON：Claude Code當期原loader＋乾淨session驗正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒規劃文本冒可執行OS；若raw.host不等於Claude Code或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-c226c99e3199｜AGENT_OS/STANDALONE｜Claude Code｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L154，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT。
- input→behavior→typed output：source-bound input→正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Claude Code/AGENT_OS/STANDALONE/OFF：Claude Code當期原loader＋乾淨session驗正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒規劃文本冒可執行OS；若raw.host不等於Claude Code或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-9e3a12ad436c｜AGENT_OS/STANDALONE｜DeepSeek Harness｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L155，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT。
- input→behavior→typed output：source-bound input→正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：DeepSeek Harness/AGENT_OS/STANDALONE/ON：實際Harness adapter/capability reader；API_ONLY不能充loader驗正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒規劃文本冒可執行OS；若raw.host不等於DeepSeek Harness或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-f18950ce731b｜AGENT_OS/STANDALONE｜DeepSeek Harness｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L156，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT。
- input→behavior→typed output：source-bound input→正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：DeepSeek Harness/AGENT_OS/STANDALONE/OFF：實際Harness adapter/capability reader；API_ONLY不能充loader驗正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒規劃文本冒可執行OS；若raw.host不等於DeepSeek Harness或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-4199689808cf｜AGENT_OS/PREW3_SHADOW｜Hermes Agent｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L157，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT。
- input→behavior→typed output：source-bound input→正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Hermes Agent/AGENT_OS/PREW3_SHADOW/ON：原Hermes tool/skill loader與worker fresh PID驗正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒規劃文本冒可執行OS；若raw.host不等於Hermes Agent或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-b6ed07348d18｜AGENT_OS/PREW3_SHADOW｜Hermes Agent｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L158，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT。
- input→behavior→typed output：source-bound input→正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Hermes Agent/AGENT_OS/PREW3_SHADOW/OFF：原Hermes tool/skill loader與worker fresh PID驗正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒規劃文本冒可執行OS；若raw.host不等於Hermes Agent或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-ae25f61ef832｜AGENT_OS/PREW3_SHADOW｜Codex｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L159，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT。
- input→behavior→typed output：source-bound input→正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Codex/AGENT_OS/PREW3_SHADOW/ON：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒規劃文本冒可執行OS；若raw.host不等於Codex或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-ec0547fd0acf｜AGENT_OS/PREW3_SHADOW｜Codex｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L160，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT。
- input→behavior→typed output：source-bound input→正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Codex/AGENT_OS/PREW3_SHADOW/OFF：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒規劃文本冒可執行OS；若raw.host不等於Codex或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-2331ca9034c4｜AGENT_OS/PREW3_SHADOW｜Claude Code｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L161，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT。
- input→behavior→typed output：source-bound input→正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Claude Code/AGENT_OS/PREW3_SHADOW/ON：Claude Code當期原loader＋乾淨session驗正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒規劃文本冒可執行OS；若raw.host不等於Claude Code或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-c7f9eff2fddd｜AGENT_OS/PREW3_SHADOW｜Claude Code｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L162，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT。
- input→behavior→typed output：source-bound input→正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Claude Code/AGENT_OS/PREW3_SHADOW/OFF：Claude Code當期原loader＋乾淨session驗正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒規劃文本冒可執行OS；若raw.host不等於Claude Code或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-f93b6704ee69｜AGENT_OS/PREW3_SHADOW｜DeepSeek Harness｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L163，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT。
- input→behavior→typed output：source-bound input→正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：DeepSeek Harness/AGENT_OS/PREW3_SHADOW/ON：實際Harness adapter/capability reader；API_ONLY不能充loader驗正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒規劃文本冒可執行OS；若raw.host不等於DeepSeek Harness或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-91838cb6a697｜AGENT_OS/PREW3_SHADOW｜DeepSeek Harness｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L164，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT。
- input→behavior→typed output：source-bound input→正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：DeepSeek Harness/AGENT_OS/PREW3_SHADOW/OFF：實際Harness adapter/capability reader；API_ONLY不能充loader驗正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒規劃文本冒可執行OS；若raw.host不等於DeepSeek Harness或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-78e42a13bbff｜AGENT_OS/SWOF_CONNECTED｜Hermes Agent｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L165，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT。
- input→behavior→typed output：source-bound input→正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Hermes Agent/AGENT_OS/SWOF_CONNECTED/ON：原Hermes tool/skill loader與worker fresh PID驗正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒規劃文本冒可執行OS；若raw.host不等於Hermes Agent或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-8c30f1274481｜AGENT_OS/SWOF_CONNECTED｜Hermes Agent｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L166，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT。
- input→behavior→typed output：source-bound input→正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Hermes Agent/AGENT_OS/SWOF_CONNECTED/OFF：原Hermes tool/skill loader與worker fresh PID驗正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒規劃文本冒可執行OS；若raw.host不等於Hermes Agent或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-9fdb959e54cd｜AGENT_OS/SWOF_CONNECTED｜Codex｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L167，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT。
- input→behavior→typed output：source-bound input→正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Codex/AGENT_OS/SWOF_CONNECTED/ON：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒規劃文本冒可執行OS；若raw.host不等於Codex或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-16b0d6f0aa4b｜AGENT_OS/SWOF_CONNECTED｜Codex｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L168，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT。
- input→behavior→typed output：source-bound input→正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Codex/AGENT_OS/SWOF_CONNECTED/OFF：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒規劃文本冒可執行OS；若raw.host不等於Codex或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-9f3a107b084e｜AGENT_OS/SWOF_CONNECTED｜Claude Code｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L169，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT。
- input→behavior→typed output：source-bound input→正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Claude Code/AGENT_OS/SWOF_CONNECTED/ON：Claude Code當期原loader＋乾淨session驗正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒規劃文本冒可執行OS；若raw.host不等於Claude Code或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-378b78d029ac｜AGENT_OS/SWOF_CONNECTED｜Claude Code｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L170，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT。
- input→behavior→typed output：source-bound input→正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Claude Code/AGENT_OS/SWOF_CONNECTED/OFF：Claude Code當期原loader＋乾淨session驗正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒規劃文本冒可執行OS；若raw.host不等於Claude Code或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-10cbe7b8ba17｜AGENT_OS/SWOF_CONNECTED｜DeepSeek Harness｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L171，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT。
- input→behavior→typed output：source-bound input→正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：DeepSeek Harness/AGENT_OS/SWOF_CONNECTED/ON：實際Harness adapter/capability reader；API_ONLY不能充loader驗正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒規劃文本冒可執行OS；若raw.host不等於DeepSeek Harness或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-95ae8bfac0e7｜AGENT_OS/SWOF_CONNECTED｜DeepSeek Harness｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L172，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT。
- input→behavior→typed output：source-bound input→正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：DeepSeek Harness/AGENT_OS/SWOF_CONNECTED/OFF：實際Harness adapter/capability reader；API_ONLY不能充loader驗正式OS lifecycle/Registry/Team/Phase的原Reader與受權部署；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒規劃文本冒可執行OS；若raw.host不等於DeepSeek Harness或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無Native OS lifecycle；便攜Host只能規格預覽，無接口為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-d0ea4e9314ef｜AI_SYSTEM/STANDALONE｜Hermes Agent｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L173，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；實際system deployment orchestrator；無部署接口為NOFIT。
- input→behavior→typed output：source-bound input→多組件DAG/ABI/部署健康/退場的整體consumer readback→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Hermes Agent/AI_SYSTEM/STANDALONE/ON：原Hermes tool/skill loader與worker fresh PID驗多組件DAG/ABI/部署健康/退場的整體consumer readback；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒單Agent demo冒完整系統；若raw.host不等於Hermes Agent或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無實際system deployment orchestrator；無部署接口為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-e90fb5ce4fd3｜AI_SYSTEM/STANDALONE｜Hermes Agent｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L174，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；實際system deployment orchestrator；無部署接口為NOFIT。
- input→behavior→typed output：source-bound input→多組件DAG/ABI/部署健康/退場的整體consumer readback→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Hermes Agent/AI_SYSTEM/STANDALONE/OFF：原Hermes tool/skill loader與worker fresh PID驗多組件DAG/ABI/部署健康/退場的整體consumer readback；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒單Agent demo冒完整系統；若raw.host不等於Hermes Agent或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無實際system deployment orchestrator；無部署接口為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-980e1f8cdbf6｜AI_SYSTEM/STANDALONE｜Codex｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L175，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；實際system deployment orchestrator；無部署接口為NOFIT。
- input→behavior→typed output：source-bound input→多組件DAG/ABI/部署健康/退場的整體consumer readback→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Codex/AI_SYSTEM/STANDALONE/ON：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗多組件DAG/ABI/部署健康/退場的整體consumer readback；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒單Agent demo冒完整系統；若raw.host不等於Codex或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無實際system deployment orchestrator；無部署接口為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-80e6856b5e3c｜AI_SYSTEM/STANDALONE｜Codex｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L176，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；實際system deployment orchestrator；無部署接口為NOFIT。
- input→behavior→typed output：source-bound input→多組件DAG/ABI/部署健康/退場的整體consumer readback→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Codex/AI_SYSTEM/STANDALONE/OFF：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗多組件DAG/ABI/部署健康/退場的整體consumer readback；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒單Agent demo冒完整系統；若raw.host不等於Codex或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無實際system deployment orchestrator；無部署接口為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-ec2d6ac66d18｜AI_SYSTEM/STANDALONE｜Claude Code｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L177，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；實際system deployment orchestrator；無部署接口為NOFIT。
- input→behavior→typed output：source-bound input→多組件DAG/ABI/部署健康/退場的整體consumer readback→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Claude Code/AI_SYSTEM/STANDALONE/ON：Claude Code當期原loader＋乾淨session驗多組件DAG/ABI/部署健康/退場的整體consumer readback；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒單Agent demo冒完整系統；若raw.host不等於Claude Code或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無實際system deployment orchestrator；無部署接口為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-4ed5ad806797｜AI_SYSTEM/STANDALONE｜Claude Code｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L178，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；實際system deployment orchestrator；無部署接口為NOFIT。
- input→behavior→typed output：source-bound input→多組件DAG/ABI/部署健康/退場的整體consumer readback→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Claude Code/AI_SYSTEM/STANDALONE/OFF：Claude Code當期原loader＋乾淨session驗多組件DAG/ABI/部署健康/退場的整體consumer readback；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒單Agent demo冒完整系統；若raw.host不等於Claude Code或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無實際system deployment orchestrator；無部署接口為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-f478ba7d0b9a｜AI_SYSTEM/STANDALONE｜DeepSeek Harness｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L179，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；實際system deployment orchestrator；無部署接口為NOFIT。
- input→behavior→typed output：source-bound input→多組件DAG/ABI/部署健康/退場的整體consumer readback→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：DeepSeek Harness/AI_SYSTEM/STANDALONE/ON：實際Harness adapter/capability reader；API_ONLY不能充loader驗多組件DAG/ABI/部署健康/退場的整體consumer readback；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒單Agent demo冒完整系統；若raw.host不等於DeepSeek Harness或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無實際system deployment orchestrator；無部署接口為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-057db0593627｜AI_SYSTEM/STANDALONE｜DeepSeek Harness｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L180，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；實際system deployment orchestrator；無部署接口為NOFIT。
- input→behavior→typed output：source-bound input→多組件DAG/ABI/部署健康/退場的整體consumer readback→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：DeepSeek Harness/AI_SYSTEM/STANDALONE/OFF：實際Harness adapter/capability reader；API_ONLY不能充loader驗多組件DAG/ABI/部署健康/退場的整體consumer readback；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒單Agent demo冒完整系統；若raw.host不等於DeepSeek Harness或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無實際system deployment orchestrator；無部署接口為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-cb6fcd8de73c｜AI_SYSTEM/PREW3_SHADOW｜Hermes Agent｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L181，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；實際system deployment orchestrator；無部署接口為NOFIT。
- input→behavior→typed output：source-bound input→多組件DAG/ABI/部署健康/退場的整體consumer readback→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Hermes Agent/AI_SYSTEM/PREW3_SHADOW/ON：原Hermes tool/skill loader與worker fresh PID驗多組件DAG/ABI/部署健康/退場的整體consumer readback；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒單Agent demo冒完整系統；若raw.host不等於Hermes Agent或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無實際system deployment orchestrator；無部署接口為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-41ed105d02da｜AI_SYSTEM/PREW3_SHADOW｜Hermes Agent｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L182，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；實際system deployment orchestrator；無部署接口為NOFIT。
- input→behavior→typed output：source-bound input→多組件DAG/ABI/部署健康/退場的整體consumer readback→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Hermes Agent/AI_SYSTEM/PREW3_SHADOW/OFF：原Hermes tool/skill loader與worker fresh PID驗多組件DAG/ABI/部署健康/退場的整體consumer readback；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒單Agent demo冒完整系統；若raw.host不等於Hermes Agent或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無實際system deployment orchestrator；無部署接口為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-836112ec4da9｜AI_SYSTEM/PREW3_SHADOW｜Codex｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L183，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；實際system deployment orchestrator；無部署接口為NOFIT。
- input→behavior→typed output：source-bound input→多組件DAG/ABI/部署健康/退場的整體consumer readback→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Codex/AI_SYSTEM/PREW3_SHADOW/ON：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗多組件DAG/ABI/部署健康/退場的整體consumer readback；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒單Agent demo冒完整系統；若raw.host不等於Codex或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無實際system deployment orchestrator；無部署接口為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-83cb46793f3b｜AI_SYSTEM/PREW3_SHADOW｜Codex｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L184，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；實際system deployment orchestrator；無部署接口為NOFIT。
- input→behavior→typed output：source-bound input→多組件DAG/ABI/部署健康/退場的整體consumer readback→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Codex/AI_SYSTEM/PREW3_SHADOW/OFF：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗多組件DAG/ABI/部署健康/退場的整體consumer readback；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒單Agent demo冒完整系統；若raw.host不等於Codex或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無實際system deployment orchestrator；無部署接口為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-39e031d42387｜AI_SYSTEM/PREW3_SHADOW｜Claude Code｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L185，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；實際system deployment orchestrator；無部署接口為NOFIT。
- input→behavior→typed output：source-bound input→多組件DAG/ABI/部署健康/退場的整體consumer readback→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Claude Code/AI_SYSTEM/PREW3_SHADOW/ON：Claude Code當期原loader＋乾淨session驗多組件DAG/ABI/部署健康/退場的整體consumer readback；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒單Agent demo冒完整系統；若raw.host不等於Claude Code或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無實際system deployment orchestrator；無部署接口為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-f250e0e5814a｜AI_SYSTEM/PREW3_SHADOW｜Claude Code｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L186，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；實際system deployment orchestrator；無部署接口為NOFIT。
- input→behavior→typed output：source-bound input→多組件DAG/ABI/部署健康/退場的整體consumer readback→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Claude Code/AI_SYSTEM/PREW3_SHADOW/OFF：Claude Code當期原loader＋乾淨session驗多組件DAG/ABI/部署健康/退場的整體consumer readback；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒單Agent demo冒完整系統；若raw.host不等於Claude Code或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無實際system deployment orchestrator；無部署接口為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-9742bec81e5a｜AI_SYSTEM/PREW3_SHADOW｜DeepSeek Harness｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L187，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；實際system deployment orchestrator；無部署接口為NOFIT。
- input→behavior→typed output：source-bound input→多組件DAG/ABI/部署健康/退場的整體consumer readback→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：DeepSeek Harness/AI_SYSTEM/PREW3_SHADOW/ON：實際Harness adapter/capability reader；API_ONLY不能充loader驗多組件DAG/ABI/部署健康/退場的整體consumer readback；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒單Agent demo冒完整系統；若raw.host不等於DeepSeek Harness或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無實際system deployment orchestrator；無部署接口為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-237ac6308b3f｜AI_SYSTEM/PREW3_SHADOW｜DeepSeek Harness｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L188，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；實際system deployment orchestrator；無部署接口為NOFIT。
- input→behavior→typed output：source-bound input→多組件DAG/ABI/部署健康/退場的整體consumer readback→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：DeepSeek Harness/AI_SYSTEM/PREW3_SHADOW/OFF：實際Harness adapter/capability reader；API_ONLY不能充loader驗多組件DAG/ABI/部署健康/退場的整體consumer readback；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒單Agent demo冒完整系統；若raw.host不等於DeepSeek Harness或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無實際system deployment orchestrator；無部署接口為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-762256559527｜AI_SYSTEM/SWOF_CONNECTED｜Hermes Agent｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L189，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；實際system deployment orchestrator；無部署接口為NOFIT。
- input→behavior→typed output：source-bound input→多組件DAG/ABI/部署健康/退場的整體consumer readback→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Hermes Agent/AI_SYSTEM/SWOF_CONNECTED/ON：原Hermes tool/skill loader與worker fresh PID驗多組件DAG/ABI/部署健康/退場的整體consumer readback；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒單Agent demo冒完整系統；若raw.host不等於Hermes Agent或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無實際system deployment orchestrator；無部署接口為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-42f5aee6701f｜AI_SYSTEM/SWOF_CONNECTED｜Hermes Agent｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L190，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；實際system deployment orchestrator；無部署接口為NOFIT。
- input→behavior→typed output：source-bound input→多組件DAG/ABI/部署健康/退場的整體consumer readback→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Hermes Agent/AI_SYSTEM/SWOF_CONNECTED/OFF：原Hermes tool/skill loader與worker fresh PID驗多組件DAG/ABI/部署健康/退場的整體consumer readback；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒單Agent demo冒完整系統；若raw.host不等於Hermes Agent或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無實際system deployment orchestrator；無部署接口為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-7b1a7a42e067｜AI_SYSTEM/SWOF_CONNECTED｜Codex｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L191，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；實際system deployment orchestrator；無部署接口為NOFIT。
- input→behavior→typed output：source-bound input→多組件DAG/ABI/部署健康/退場的整體consumer readback→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Codex/AI_SYSTEM/SWOF_CONNECTED/ON：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗多組件DAG/ABI/部署健康/退場的整體consumer readback；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒單Agent demo冒完整系統；若raw.host不等於Codex或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無實際system deployment orchestrator；無部署接口為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-f171ddc0382c｜AI_SYSTEM/SWOF_CONNECTED｜Codex｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L192，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；實際system deployment orchestrator；無部署接口為NOFIT。
- input→behavior→typed output：source-bound input→多組件DAG/ABI/部署健康/退場的整體consumer readback→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Codex/AI_SYSTEM/SWOF_CONNECTED/OFF：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗多組件DAG/ABI/部署健康/退場的整體consumer readback；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒單Agent demo冒完整系統；若raw.host不等於Codex或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無實際system deployment orchestrator；無部署接口為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-a50d9bf4ec2f｜AI_SYSTEM/SWOF_CONNECTED｜Claude Code｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L193，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；實際system deployment orchestrator；無部署接口為NOFIT。
- input→behavior→typed output：source-bound input→多組件DAG/ABI/部署健康/退場的整體consumer readback→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Claude Code/AI_SYSTEM/SWOF_CONNECTED/ON：Claude Code當期原loader＋乾淨session驗多組件DAG/ABI/部署健康/退場的整體consumer readback；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒單Agent demo冒完整系統；若raw.host不等於Claude Code或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無實際system deployment orchestrator；無部署接口為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-90274105bfbf｜AI_SYSTEM/SWOF_CONNECTED｜Claude Code｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L194，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；實際system deployment orchestrator；無部署接口為NOFIT。
- input→behavior→typed output：source-bound input→多組件DAG/ABI/部署健康/退場的整體consumer readback→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Claude Code/AI_SYSTEM/SWOF_CONNECTED/OFF：Claude Code當期原loader＋乾淨session驗多組件DAG/ABI/部署健康/退場的整體consumer readback；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒單Agent demo冒完整系統；若raw.host不等於Claude Code或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無實際system deployment orchestrator；無部署接口為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-b85f95d3b255｜AI_SYSTEM/SWOF_CONNECTED｜DeepSeek Harness｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L195，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；實際system deployment orchestrator；無部署接口為NOFIT。
- input→behavior→typed output：source-bound input→多組件DAG/ABI/部署健康/退場的整體consumer readback→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：DeepSeek Harness/AI_SYSTEM/SWOF_CONNECTED/ON：實際Harness adapter/capability reader；API_ONLY不能充loader驗多組件DAG/ABI/部署健康/退場的整體consumer readback；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒單Agent demo冒完整系統；若raw.host不等於DeepSeek Harness或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無實際system deployment orchestrator；無部署接口為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-1746d4d5a88d｜AI_SYSTEM/SWOF_CONNECTED｜DeepSeek Harness｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L196，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；實際system deployment orchestrator；無部署接口為NOFIT。
- input→behavior→typed output：source-bound input→多組件DAG/ABI/部署健康/退場的整體consumer readback→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：DeepSeek Harness/AI_SYSTEM/SWOF_CONNECTED/OFF：實際Harness adapter/capability reader；API_ONLY不能充loader驗多組件DAG/ABI/部署健康/退場的整體consumer readback；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒單Agent demo冒完整系統；若raw.host不等於DeepSeek Harness或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無實際system deployment orchestrator；無部署接口為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-336e267c9f1b｜GENIE/GENIE.md/STANDALONE｜Hermes Agent｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L197，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT。
- input→behavior→typed output：source-bound input→原SWOF版本化GENIE reference/schema與Owner關聯讀回→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Hermes Agent/GENIE/GENIE.md/STANDALONE/ON：原Hermes tool/skill loader與worker fresh PID驗原SWOF版本化GENIE reference/schema與Owner關聯讀回；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒任意GENIE.md冒正式生成或部署；若raw.host不等於Hermes Agent或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-8f240272c803｜GENIE/GENIE.md/STANDALONE｜Hermes Agent｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L198，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT。
- input→behavior→typed output：source-bound input→原SWOF版本化GENIE reference/schema與Owner關聯讀回→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Hermes Agent/GENIE/GENIE.md/STANDALONE/OFF：原Hermes tool/skill loader與worker fresh PID驗原SWOF版本化GENIE reference/schema與Owner關聯讀回；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒任意GENIE.md冒正式生成或部署；若raw.host不等於Hermes Agent或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-5c0c72c957ed｜GENIE/GENIE.md/STANDALONE｜Codex｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L199，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT。
- input→behavior→typed output：source-bound input→原SWOF版本化GENIE reference/schema與Owner關聯讀回→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Codex/GENIE/GENIE.md/STANDALONE/ON：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗原SWOF版本化GENIE reference/schema與Owner關聯讀回；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒任意GENIE.md冒正式生成或部署；若raw.host不等於Codex或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-d9f0da8c1631｜GENIE/GENIE.md/STANDALONE｜Codex｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L200，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT。
- input→behavior→typed output：source-bound input→原SWOF版本化GENIE reference/schema與Owner關聯讀回→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Codex/GENIE/GENIE.md/STANDALONE/OFF：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗原SWOF版本化GENIE reference/schema與Owner關聯讀回；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒任意GENIE.md冒正式生成或部署；若raw.host不等於Codex或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-070f95d5c154｜GENIE/GENIE.md/STANDALONE｜Claude Code｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L201，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT。
- input→behavior→typed output：source-bound input→原SWOF版本化GENIE reference/schema與Owner關聯讀回→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Claude Code/GENIE/GENIE.md/STANDALONE/ON：Claude Code當期原loader＋乾淨session驗原SWOF版本化GENIE reference/schema與Owner關聯讀回；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒任意GENIE.md冒正式生成或部署；若raw.host不等於Claude Code或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-479fa09ec346｜GENIE/GENIE.md/STANDALONE｜Claude Code｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L202，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT。
- input→behavior→typed output：source-bound input→原SWOF版本化GENIE reference/schema與Owner關聯讀回→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Claude Code/GENIE/GENIE.md/STANDALONE/OFF：Claude Code當期原loader＋乾淨session驗原SWOF版本化GENIE reference/schema與Owner關聯讀回；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒任意GENIE.md冒正式生成或部署；若raw.host不等於Claude Code或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-9af02fa9e8ed｜GENIE/GENIE.md/STANDALONE｜DeepSeek Harness｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L203，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT。
- input→behavior→typed output：source-bound input→原SWOF版本化GENIE reference/schema與Owner關聯讀回→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：DeepSeek Harness/GENIE/GENIE.md/STANDALONE/ON：實際Harness adapter/capability reader；API_ONLY不能充loader驗原SWOF版本化GENIE reference/schema與Owner關聯讀回；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒任意GENIE.md冒正式生成或部署；若raw.host不等於DeepSeek Harness或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-c38a7e723977｜GENIE/GENIE.md/STANDALONE｜DeepSeek Harness｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L204，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT。
- input→behavior→typed output：source-bound input→原SWOF版本化GENIE reference/schema與Owner關聯讀回→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：STANDALONE_USER_CONSENT; no HGK dependency for local non-native outcome；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：DeepSeek Harness/GENIE/GENIE.md/STANDALONE/OFF：實際Harness adapter/capability reader；API_ONLY不能充loader驗原SWOF版本化GENIE reference/schema與Owner關聯讀回；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒任意GENIE.md冒正式生成或部署；若raw.host不等於DeepSeek Harness或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-510726a815d2｜GENIE/GENIE.md/PREW3_SHADOW｜Hermes Agent｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L205，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT。
- input→behavior→typed output：source-bound input→原SWOF版本化GENIE reference/schema與Owner關聯讀回→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Hermes Agent/GENIE/GENIE.md/PREW3_SHADOW/ON：原Hermes tool/skill loader與worker fresh PID驗原SWOF版本化GENIE reference/schema與Owner關聯讀回；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒任意GENIE.md冒正式生成或部署；若raw.host不等於Hermes Agent或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-f842f5e447d1｜GENIE/GENIE.md/PREW3_SHADOW｜Hermes Agent｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L206，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT。
- input→behavior→typed output：source-bound input→原SWOF版本化GENIE reference/schema與Owner關聯讀回→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Hermes Agent/GENIE/GENIE.md/PREW3_SHADOW/OFF：原Hermes tool/skill loader與worker fresh PID驗原SWOF版本化GENIE reference/schema與Owner關聯讀回；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒任意GENIE.md冒正式生成或部署；若raw.host不等於Hermes Agent或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-82305af511e2｜GENIE/GENIE.md/PREW3_SHADOW｜Codex｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L207，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT。
- input→behavior→typed output：source-bound input→原SWOF版本化GENIE reference/schema與Owner關聯讀回→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Codex/GENIE/GENIE.md/PREW3_SHADOW/ON：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗原SWOF版本化GENIE reference/schema與Owner關聯讀回；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒任意GENIE.md冒正式生成或部署；若raw.host不等於Codex或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-bf764d5ba2c2｜GENIE/GENIE.md/PREW3_SHADOW｜Codex｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L208，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT。
- input→behavior→typed output：source-bound input→原SWOF版本化GENIE reference/schema與Owner關聯讀回→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Codex/GENIE/GENIE.md/PREW3_SHADOW/OFF：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗原SWOF版本化GENIE reference/schema與Owner關聯讀回；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒任意GENIE.md冒正式生成或部署；若raw.host不等於Codex或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-d69adf2f1965｜GENIE/GENIE.md/PREW3_SHADOW｜Claude Code｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L209，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT。
- input→behavior→typed output：source-bound input→原SWOF版本化GENIE reference/schema與Owner關聯讀回→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Claude Code/GENIE/GENIE.md/PREW3_SHADOW/ON：Claude Code當期原loader＋乾淨session驗原SWOF版本化GENIE reference/schema與Owner關聯讀回；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒任意GENIE.md冒正式生成或部署；若raw.host不等於Claude Code或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-1ef60244801f｜GENIE/GENIE.md/PREW3_SHADOW｜Claude Code｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L210，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT。
- input→behavior→typed output：source-bound input→原SWOF版本化GENIE reference/schema與Owner關聯讀回→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Claude Code/GENIE/GENIE.md/PREW3_SHADOW/OFF：Claude Code當期原loader＋乾淨session驗原SWOF版本化GENIE reference/schema與Owner關聯讀回；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒任意GENIE.md冒正式生成或部署；若raw.host不等於Claude Code或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-98d011df32e5｜GENIE/GENIE.md/PREW3_SHADOW｜DeepSeek Harness｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L211，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT。
- input→behavior→typed output：source-bound input→原SWOF版本化GENIE reference/schema與Owner關聯讀回→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：DeepSeek Harness/GENIE/GENIE.md/PREW3_SHADOW/ON：實際Harness adapter/capability reader；API_ONLY不能充loader驗原SWOF版本化GENIE reference/schema與Owner關聯讀回；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒任意GENIE.md冒正式生成或部署；若raw.host不等於DeepSeek Harness或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-880fcebbf48e｜GENIE/GENIE.md/PREW3_SHADOW｜DeepSeek Harness｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L212，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT。
- input→behavior→typed output：source-bound input→原SWOF版本化GENIE reference/schema與Owner關聯讀回→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：SOURCE_READ/NO_SWOF_WRITE；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：DeepSeek Harness/GENIE/GENIE.md/PREW3_SHADOW/OFF：實際Harness adapter/capability reader；API_ONLY不能充loader驗原SWOF版本化GENIE reference/schema與Owner關聯讀回；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒任意GENIE.md冒正式生成或部署；若raw.host不等於DeepSeek Harness或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-a8a335dada5e｜GENIE/GENIE.md/SWOF_CONNECTED｜Hermes Agent｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L213，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT。
- input→behavior→typed output：source-bound input→原SWOF版本化GENIE reference/schema與Owner關聯讀回→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Hermes Agent/GENIE/GENIE.md/SWOF_CONNECTED/ON：原Hermes tool/skill loader與worker fresh PID驗原SWOF版本化GENIE reference/schema與Owner關聯讀回；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒任意GENIE.md冒正式生成或部署；若raw.host不等於Hermes Agent或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-f9d246f739b8｜GENIE/GENIE.md/SWOF_CONNECTED｜Hermes Agent｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L214，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：原Hermes tool/skill loader與worker fresh PID；原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT。
- input→behavior→typed output：source-bound input→原SWOF版本化GENIE reference/schema與Owner關聯讀回→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Hermes Agent/GENIE/GENIE.md/SWOF_CONNECTED/OFF：原Hermes tool/skill loader與worker fresh PID驗原SWOF版本化GENIE reference/schema與Owner關聯讀回；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=journal cursor/lease_generation/worker_pid。
- NEG/first_fail：Hermes Agent此cell拒任意GENIE.md冒正式生成或部署；若raw.host不等於Hermes Agent或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Hermes Agent若無原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT，由Hermes原Journal/Worker Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Hermes Agent依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-8ed9eebf58e7｜GENIE/GENIE.md/SWOF_CONNECTED｜Codex｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L215，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT。
- input→behavior→typed output：source-bound input→原SWOF版本化GENIE reference/schema與Owner關聯讀回→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Codex/GENIE/GENIE.md/SWOF_CONNECTED/ON：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗原SWOF版本化GENIE reference/schema與Owner關聯讀回；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒任意GENIE.md冒正式生成或部署；若raw.host不等於Codex或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-b6fc7bd2585b｜GENIE/GENIE.md/SWOF_CONNECTED｜Codex｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L216，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Codex Host skill/plugin discovery＋乾淨chat/CLI session；原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT。
- input→behavior→typed output：source-bound input→原SWOF版本化GENIE reference/schema與Owner關聯讀回→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Codex/GENIE/GENIE.md/SWOF_CONNECTED/OFF：Codex Host skill/plugin discovery＋乾淨chat/CLI session驗原SWOF版本化GENIE reference/schema與Owner關聯讀回；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=Host manifest/loaded SHA/trigger invocation。
- NEG/first_fail：Codex此cell拒任意GENIE.md冒正式生成或部署；若raw.host不等於Codex或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Codex若無原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT，由Codex Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Codex依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-ea0c6cc43029｜GENIE/GENIE.md/SWOF_CONNECTED｜Claude Code｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L217，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT。
- input→behavior→typed output：source-bound input→原SWOF版本化GENIE reference/schema與Owner關聯讀回→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：Claude Code/GENIE/GENIE.md/SWOF_CONNECTED/ON：Claude Code當期原loader＋乾淨session驗原SWOF版本化GENIE reference/schema與Owner關聯讀回；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒任意GENIE.md冒正式生成或部署；若raw.host不等於Claude Code或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-425204fe1c0f｜GENIE/GENIE.md/SWOF_CONNECTED｜Claude Code｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L218，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：Claude Code當期原loader＋乾淨session；原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT。
- input→behavior→typed output：source-bound input→原SWOF版本化GENIE reference/schema與Owner關聯讀回→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：Claude Code/GENIE/GENIE.md/SWOF_CONNECTED/OFF：Claude Code當期原loader＋乾淨session驗原SWOF版本化GENIE reference/schema與Owner關聯讀回；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=原Host允許的manifest/permission/effective load。
- NEG/first_fail：Claude Code此cell拒任意GENIE.md冒正式生成或部署；若raw.host不等於Claude Code或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：Claude Code若無原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT，由Claude Code Host Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：Claude Code依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-fc762041aa9d｜GENIE/GENIE.md/SWOF_CONNECTED｜DeepSeek Harness｜legacy=ON

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L219，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT。
- input→behavior→typed output：source-bound input→原SWOF版本化GENIE reference/schema與Owner關聯讀回→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback。
- POS：DeepSeek Harness/GENIE/GENIE.md/SWOF_CONNECTED/ON：實際Harness adapter/capability reader；API_ONLY不能充loader驗原SWOF版本化GENIE reference/schema與Owner關聯讀回；provider_off=false：需provider時驗本cell原Policy允許的served Raw；provider缺件→NOFIT，不私fallback；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒任意GENIE.md冒正式生成或部署；若raw.host不等於DeepSeek Harness或provider行為違ON原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。

### CELL-5370fdd74e46｜GENIE/GENIE.md/SWOF_CONNECTED｜DeepSeek Harness｜legacy=OFF

- Trigger/input：此Kind需求在此Mode與此Host被要求；source v1:L220，SHA `41cdd5e5ab16bc2b44ab47155e6cd09e81eef98c56753ae7dd03d0484385a4cd`。
- route/HostCaps：實際Harness adapter/capability reader；API_ONLY不能充loader；原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT。
- input→behavior→typed output：source-bound input→原SWOF版本化GENIE reference/schema與Owner關聯讀回→CellOutcome(cell_id,host,session,capability,artifact_sha,actual_raw_sha,status)。
- effect/permission：ORIGINAL_SWOF_W3_ADMISSION+OPS/DEV_BY_EFFECT；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商。
- POS：DeepSeek Harness/GENIE/GENIE.md/SWOF_CONNECTED/OFF：實際Harness adapter/capability reader；API_ONLY不能充loader驗原SWOF版本化GENIE reference/schema與Owner關聯讀回；provider_off=true：零provider網路呼叫；有離線實作才可完成，需模型但無離線runner→NOFIT，不換供應商；同cell/Host/session raw=harness ABI/tool_result/session identity。
- NEG/first_fail：DeepSeek Harness此cell拒任意GENIE.md冒正式生成或部署；若raw.host不等於DeepSeek Harness或provider行為違OFF原label對照則CELL_RECEIPT_SCOPE_NACK。
- NoFit：DeepSeek Harness若無原GENIE Compiler/Reader；便攜Host只read refs，無接口為NOFIT，由DeepSeek Harness Owner回NO_FIT_WITH_REASON；不借其它Host收據。
- exit/resume：DeepSeek Harness依此Kind原loader卸載/撤Profile或停止受影runner；Reader無effect只丟快照，UNKNOWN先reconcile；重新probe本Host能力與原Owner provider label map後再測。NATIVE_NOT_RUN。
~~~~~~~
