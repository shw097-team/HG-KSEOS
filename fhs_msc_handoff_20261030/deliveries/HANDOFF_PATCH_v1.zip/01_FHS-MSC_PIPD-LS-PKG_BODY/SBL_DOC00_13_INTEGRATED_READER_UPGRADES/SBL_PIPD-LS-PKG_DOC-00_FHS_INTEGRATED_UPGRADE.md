<!-- version: 2026-10-30_STATIC-REPAIR-v1; current semantic acceptance: REPAIR_INCOMPLETE -->

# SBL DOC-00｜FHS 整合設計 Reader：2026-10-30_r2_HIGH_RETENTION_AUDIT_PATCHED_SOURCE_BOUND

> **整合、覆蓋、取代**：本冊取代 2026-10-30 r1 在「FHS 跨域設計 Reader」範圍的模板及其隱含當期作用。SBL DOC-00 原 Canonical Writer 不變；舊版原文 1591 行原位元組內容另存 `02_EVIDENCE_AUDIT_APPENDICES/_superseded_2026-10-30_r1/SBL_DOC00_13_ORIGINAL_FULL_TEXT/SBL_DOC-00_ORIGINAL_VERBATIM.md`（SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`）。原文仍可查但不可與現行 FHS Reader 競爭版本。複合條文由下列各自具 ID 的受影功能規範處理，**不得藉 machine split 自稱原 Owner 語義已 Ratified**。

## R2 原 Domain 端到端 Reader 合約

- 原 Writer：SBL DOC-00 原產品／領域 Owner；本冊**只有整合候選**寫權。
- 原 Receiver：SBL Product Owner/Doc Reader；當期輸出 `SourceDecision{source_id,owner,status,first_fail}`；`SourceSHA` 與原 clause locator 必同輪綁定。
- 原受影最小效果：SOURCE_READ/LOCAL_DRAFT_WRITE；任何 REPO_WRITE/HOST_OP/REMOTE/RELEASE 仍需原 PIPD/Issuer 有效准入。
- 實質函式：`read_original_clause→split_with_polarity→bind_original_consumer→produce_00_candidate→check_own_pos_and_neg→affected_only_resume`。
- 本冊拒收碼：`SOURCE_AUTHORITY_UNRESOLVED`；沒 Host/Owner ACK 只能 `DESIGN_SOURCE_BOUND`／`HOST_PENDING`，不得宣稱 Runtime PASS。
- Retire/rollback：僅撤銷這次隔離 proposal、保留 source 和前一正式版本；不 reset Repo、不刪本機 Journal/原 Oracle。

## 各原 Parent／複合子要求：逐條 FHS DeltaSpec（本輪掃描全量，未抽樣）

每筆下列 `Source` 是原句；`Target` 是受影整合候選，不替代原句義。POS 與 NEG 逐條對應原子化片段；若原句否定的作用域複雜或缺實際 ABI，`semantic_state=REVIEW_REQUIRED`，不能用一次 generic 測試覆蓋多個子項。

### SBL-D00-L00070-C01｜R00.r3.1｜五分鐘產品操作契約與七痛點→實體成果
- **原條款（非摘要代替）**：共同 UX 量測協議**：每個 FUO 回報 `persona,clean_start,source_sha,selected_path,first_useful_output,elapsed_ms,questions_reasked,error_count,provider_off,consumer_acceptance`。
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L65`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L00070-C01` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L00070-C01` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L00070-C01` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L00070-C02｜R00.r3.1｜五分鐘產品操作契約與七痛點→實體成果
- **原條款（非摘要代替）**：本文建議將 P03 同來源重問目標設為 0、每 Journey 回合使用者主觀「可用」且可重播；
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L65`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L00070-C02` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L00070-C02` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L00070-C02` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L00070-C03｜R00.r3.1｜五分鐘產品操作契約與七痛點→實體成果
- **原條款（非摘要代替）**：所有時效及操作次數為 **UAT 待量測門檻**，
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L65`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L00070-C03` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L00070-C03` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L00070-C03` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L00070-C04｜R00.r3.1｜五分鐘產品操作契約與七痛點→實體成果
- **原條款（非摘要代替）**：READ_ONLY_DESIGN` 時僅有可檢閱 Spec，
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L65`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L00070-C04` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L00070-C04` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L00070-C04` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L00070-C05｜R00.r3.1｜五分鐘產品操作契約與七痛點→實體成果
- **原條款（非摘要代替）**：不宣稱 CLI 已可執行。
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L65`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L00070-C05` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L00070-C05` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L00070-C05` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L00096-C01｜R01.r3.2｜當輪物理全集 1:1 完整 Manifest 與 20 詞全文檢索
- **原條款（非摘要代替）**：此次只掃描真實存在的 Markdown 檔，
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L91`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L00096-C01` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L00096-C01` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L00096-C01` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L00096-C02｜R01.r3.2｜當輪物理全集 1:1 完整 Manifest 與 20 詞全文檢索
- **原條款（非摘要代替）**：排除本次成果本身**以免自循環。
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L91`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L00096-C02` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L00096-C02` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L00096-C02` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L00096-C03｜R01.r3.2｜當輪物理全集 1:1 完整 Manifest 與 20 詞全文檢索
- **原條款（非摘要代替）**：對每一件執行 `read_bytes → decode(strict UTF-8) → sha256 → splitlines → 20 regex 全文計數`，
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L91`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L00096-C03` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L00096-C03` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L00096-C03` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L00096-C04｜R01.r3.2｜當輪物理全集 1:1 完整 Manifest 與 20 詞全文檢索
- **原條款（非摘要代替）**：非**獨立的 clause-level semantic closure；
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L91`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L00096-C04` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L00096-C04` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L00096-C04` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L00096-C05｜R01.r3.2｜當輪物理全集 1:1 完整 Manifest 與 20 詞全文檢索
- **原條款（非摘要代替）**：檔案群的法位仍按 Owner Scope 分隔。
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L91`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L00096-C05` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L00096-C05` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L00096-C05` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L00337-C01｜R01.r3.1｜四份高優先新增來源與物理路徑
- **原條款（非摘要代替）**：SRC-0079 修補規則**：對舊 Inventory 的 URL percent-encoded 或其他 Unicode display alias，
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L332`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L00337-C01` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L00337-C01` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L00337-C01` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L00337-C02｜R01.r3.1｜四份高優先新增來源與物理路徑
- **原條款（非摘要代替）**：建立 `path_alias_resolved_by_sha`，
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L332`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L00337-C02` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L00337-C02` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L00337-C02` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L00337-C03｜R01.r3.1｜四份高優先新增來源與物理路徑
- **原條款（非摘要代替）**：以真正 `Path.name` 實體名為唯一開啟路徑；
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L332`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L00337-C03` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L00337-C03` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L00337-C03` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L00337-C04｜R01.r3.1｜四份高優先新增來源與物理路徑
- **原條款（非摘要代替）**：在生成引用時同時要求 `exists=true` 且 `sha256(expected)==sha256(actual)`。
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L332`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L00337-C04` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L00337-C04` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L00337-C04` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L00337-C05｜R01.r3.1｜四份高優先新增來源與物理路徑
- **原條款（非摘要代替）**：若路徑不存在但 sha 相同只能 `ALIAS_MATCH_HOLD`，
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L332`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L00337-C05` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L00337-C05` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L00337-C05` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L00337-C06｜R01.r3.1｜四份高優先新增來源與物理路徑
- **原條款（非摘要代替）**：先補正物理目錄再允許交接。
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L332`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L00337-C06` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L00337-C06` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L00337-C06` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L00337-C07｜R01.r3.1｜四份高優先新增來源與物理路徑
- **原條款（非摘要代替）**：POS：原始 Unicode 名稱存在並符合 SHA；
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L332`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L00337-C07` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L00337-C07` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L00337-C07` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L00337-C08｜R01.r3.1｜四份高優先新增來源與物理路徑
- **原條款（非摘要代替）**：NEG：只有 percent-encoded 名，
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L332`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L00337-C08` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L00337-C08` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L00337-C08` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L00337-C09｜R01.r3.1｜四份高優先新增來源與物理路徑
- **原條款（非摘要代替）**：開啟失敗→`FILE_LOCATOR_NOT_FOUND`。
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L332`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `NEGATIVE`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L00337-C09` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L00337-C09` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L00337-C09` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L00345-C01｜C16.r3.base.1｜本輪最小職能集合及歷史角色分母隔離
- **原條款（非摘要代替）**：領域/職位(來源原名)
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L340`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L00345-C01` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L00345-C01` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L00345-C01` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L00345-C02｜C16.r3.base.1｜本輪最小職能集合及歷史角色分母隔離
- **原條款（非摘要代替）**：對應 DOC-00 H1
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L340`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L00345-C02` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L00345-C02` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L00345-C02` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L00376-C01｜C16.r3.base.2｜HISTORICAL_vs_CURRENT_ROLE_CROSSWALK
- **原條款（非摘要代替）**：舊 DOC-00 r2 的「72 專家」
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L371`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L00376-C01` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L00376-C01` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L00376-C01` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L00376-C02｜C16.r3.base.2｜HISTORICAL_vs_CURRENT_ROLE_CROSSWALK
- **原條款（非摘要代替）**：CR_ROLE_72_58_OPEN
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L371`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L00376-C02` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L00376-C02` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L00376-C02` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L00469-C01｜C48.r3.1｜45 個一級章節的來源實體與 Owning DOC 的實質 H1 檢索
- **原條款（非摘要代替）**：路由實際拒收**：DOC-12 DELIVER `C-037` 不能被 Doc-03 的要求表取代；
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L464`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L00469-C01` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L00469-C01` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L00469-C01` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L00469-C02｜C48.r3.1｜45 個一級章節的來源實體與 Owning DOC 的實質 H1 檢索
- **原條款（非摘要代替）**：第 20 ECP 需 token/rollback，
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L464`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L00469-C02` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L00469-C02` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L00469-C02` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L00469-C03｜C48.r3.1｜45 個一級章節的來源實體與 Owning DOC 的實質 H1 檢索
- **原條款（非摘要代替）**：不能用 TestPlan 當效果權；
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L464`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L00469-C03` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L00469-C03` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L00469-C03` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L00469-C04｜C48.r3.1｜45 個一級章節的來源實體與 Owning DOC 的實質 H1 檢索
- **原條款（非摘要代替）**：第 21 Checker 必真實不同身份。
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L464`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L00469-C04` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L00469-C04` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L00469-C04` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L00469-C05｜C48.r3.1｜45 個一級章節的來源實體與 Owning DOC 的實質 H1 檢索
- **原條款（非摘要代替）**：對每個列寫 `GlobalH1Binding{global_id,source_control_clause,owner_doc,owner_h1_exact,authoritative_subject_sha,consumer,positive,negative,firstfail}`，
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L464`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L00469-C05` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L00469-C05` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L00469-C05` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L00469-C06｜C48.r3.1｜45 個一級章節的來源實體與 Owning DOC 的實質 H1 檢索
- **原條款（非摘要代替）**：若 `owner_h1_exact` 沒有 Owner 批准則 `H1_UNVERIFIED`，
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L464`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L00469-C06` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L00469-C06` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L00469-C06` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L00469-C07｜C48.r3.1｜45 個一級章節的來源實體與 Owning DOC 的實質 H1 檢索
- **原條款（非摘要代替）**：保留候選映射但不得 FULL_PASS。
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L464`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `NEGATIVE`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L00469-C07` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L00469-C07` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L00469-C07` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L00475-C01｜R02.r3.base.1｜七 Primary Kinds × 八 ProductKind 正交契約
- **原條款（非摘要代替）**：Canonical SWOF 7 Kind 的原始計數為 11/43/82/18/29/18/30 = 231，
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L470`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L00475-C01` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L00475-C01` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L00475-C01` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L00475-C02｜R02.r3.base.1｜七 Primary Kinds × 八 ProductKind 正交契約
- **原條款（非摘要代替）**：另有 59 Relation /72 MC；
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L470`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L00475-C02` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L00475-C02` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L00475-C02` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L00475-C03｜R02.r3.base.1｜七 Primary Kinds × 八 ProductKind 正交契約
- **原條款（非摘要代替）**：它們屬於 SWOF 來源分母，
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L470`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L00475-C03` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L00475-C03` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L00475-C03` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L00475-C04｜R02.r3.base.1｜七 Primary Kinds × 八 ProductKind 正交契約
- **原條款（非摘要代替）**：不可誤記為 SBL 真的新建分子。
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L470`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `NEGATIVE`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L00475-C04` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L00475-C04` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L00475-C04` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L00475-C05｜R02.r3.base.1｜七 Primary Kinds × 八 ProductKind 正交契約
- **原條款（非摘要代替）**：每個已引用 entity 恰一 `primary_kind`；
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L470`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L00475-C05` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L00475-C05` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L00475-C05` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L00475-C06｜R02.r3.base.1｜七 Primary Kinds × 八 ProductKind 正交契約
- **原條款（非摘要代替）**：一個 SBL `ProductKind` 可投影到多種 entity kind，
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L470`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L00475-C06` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L00475-C06` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L00475-C06` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L00515-C01｜R02.r3.1｜16 個 Moment 逐個 FUO、錯誤與測量
- **原條款（非摘要代替）**：M15 Private Use
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L510`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L00515-C01` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L00515-C01` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L00515-C01` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L00515-C02｜R02.r3.1｜16 個 Moment 逐個 FUO、錯誤與測量
- **原條款（非摘要代替）**：Private Web User
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L510`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L00515-C02` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L00515-C02` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L00515-C02` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L00515-C03｜R02.r3.1｜16 個 Moment 逐個 FUO、錯誤與測量
- **原條款（非摘要代替）**：3 SP × 私人 ZIP/Claude Native/MD
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L510`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L00515-C03` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L00515-C03` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L00515-C03` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L00515-C04｜R02.r3.1｜16 個 Moment 逐個 FUO、錯誤與測量
- **原條款（非摘要代替）**：合法包＋用戶上傳＋調用
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L510`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L00515-C04` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L00515-C04` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L00515-C04` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L00515-C05｜R02.r3.1｜16 個 Moment 逐個 FUO、錯誤與測量
- **原條款（非摘要代替）**：MD≠工具 Runtime
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L510`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L00515-C05` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L00515-C05` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L00515-C05` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L00515-C06｜R02.r3.1｜16 個 Moment 逐個 FUO、錯誤與測量
- **原條款（非摘要代替）**：pre: source/version known where required;
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L510`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L00515-C06` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L00515-C06` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L00515-C06` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L00515-C07｜R02.r3.1｜16 個 Moment 逐個 FUO、錯誤與測量
- **原條款（非摘要代替）**：consumer_accept=M15` observable
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L510`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L00515-C07` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L00515-C07` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L00515-C07` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L00515-C08｜R02.r3.1｜16 個 Moment 逐個 FUO、錯誤與測量
- **原條款（非摘要代替）**：User confirms artifact readable and can name next step;
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L510`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L00515-C08` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L00515-C08` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L00515-C08` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L00515-C09｜R02.r3.1｜16 個 Moment 逐個 FUO、錯誤與測量
- **原條款（非摘要代替）**：measurable in UAT
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L510`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L00515-C09` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L00515-C09` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L00515-C09` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L00515-C10｜R02.r3.1｜16 個 Moment 逐個 FUO、錯誤與測量
- **原條款（非摘要代替）**：NEG: wrong SHA or absent output;
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L510`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L00515-C10` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L00515-C10` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L00515-C10` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L00515-C11｜R02.r3.1｜16 個 Moment 逐個 FUO、錯誤與測量
- **原條款（非摘要代替）**：retry bounded once
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L510`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L00515-C11` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L00515-C11` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L00515-C11` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L00515-C12｜R02.r3.1｜16 個 Moment 逐個 FUO、錯誤與測量
- **原條款（非摘要代替）**：回退單一 Web session
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L510`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L00515-C12` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L00515-C12` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L00515-C12` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L00515-C13｜R02.r3.1｜16 個 Moment 逐個 FUO、錯誤與測量
- **原條款（非摘要代替）**：DESIGN_THRESHOLD_PROPOSED;
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L510`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L00515-C13` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L00515-C13` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L00515-C13` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L00515-C14｜R02.r3.1｜16 個 Moment 逐個 FUO、錯誤與測量
- **原條款（非摘要代替）**：NOT_MEASURED
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L510`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L00515-C14` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L00515-C14` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L00515-C14` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L00570-C01｜R03.r3.base.1｜正式製程下游契約，不構成本輪執行收據
- **原條款（非摘要代替）**：Goal+SourceLocator → IntentCard → AuthorityBinding/SourceFreezeManifest → ProfileBinding → PI-PKG → 真 RepoContext 晚綁定 PD-PKG → ConstructionContract + ONE ECP → TQAEP/Independent Checker → Evidence/TraceClosure/ClaimCeiling → Receiver/Release/Evolution`。
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L565`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L00570-C01` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L00570-C01` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L00570-C01` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L00570-C02｜R03.r3.base.1｜正式製程下游契約，不構成本輪執行收據
- **原條款（非摘要代替）**：每一步的輸入/輸出必符合 PIPD 官方 Schema，
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L565`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L00570-C02` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L00570-C02` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L00570-C02` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L00570-C03｜R03.r3.base.1｜正式製程下游契約，不構成本輪執行收據
- **原條款（非摘要代替）**：SBL 本檔只能顯示讀序及合法 Caller/Owner。
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L565`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L00570-C03` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L00570-C03` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L00570-C03` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L00615-C01｜R04.r3.base.1｜六 Donor × 24 Core 能力的原始行為決策，不另寫第七套 Compiler
- **原條款（非摘要代替）**：To-spec／To-tickets
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L610`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L00615-C01` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L00615-C01` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L00615-C01` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L00615-C02｜R04.r3.base.1｜六 Donor × 24 Core 能力的原始行為決策，不另寫第七套 Compiler
- **原條款（非摘要代替）**：每 Task 對應 SPEC/Acceptance；
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L610`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L00615-C02` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L00615-C02` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L00615-C02` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L00615-C03｜R04.r3.base.1｜六 Donor × 24 Core 能力的原始行為決策，不另寫第七套 Compiler
- **原條款（非摘要代替）**：SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L227
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L610`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L00615-C03` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L00615-C03` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L00615-C03` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L00659-C01｜R04.r3.2｜386/386 Universe 按法位完整拆列；226 技術/協定/研究與 160 歷史規則不混為安裝數
- **原條款（非摘要代替）**：Exact name
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L654`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L00659-C01` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L00659-C01` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L00659-C01` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L00659-C02｜R04.r3.2｜386/386 Universe 按法位完整拆列；226 技術/協定/研究與 160 歷史規則不混為安裝數
- **原條款（非摘要代替）**：原始 Disposition
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L654`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L00659-C02` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L00659-C02` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L00659-C02` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L00659-C03｜R04.r3.2｜386/386 Universe 按法位完整拆列；226 技術/協定/研究與 160 歷史規則不混為安裝數
- **原條款（非摘要代替）**：個別功能 POS / I/O
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L654`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L00659-C03` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L00659-C03` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L00659-C03` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L00659-C04｜R04.r3.2｜386/386 Universe 按法位完整拆列；226 技術/協定/研究與 160 歷史規則不混為安裝數
- **原條款（非摘要代替）**：特定 NEG / first failure
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L654`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L00659-C04` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L00659-C04` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L00659-C04` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L00659-C05｜R04.r3.2｜386/386 Universe 按法位完整拆列；226 技術/協定/研究與 160 歷史規則不混為安裝數
- **原條款（非摘要代替）**：Adapter ABI
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L654`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L00659-C05` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L00659-C05` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L00659-C05` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L00659-C06｜R04.r3.2｜386/386 Universe 按法位完整拆列；226 技術/協定/研究與 160 歷史規則不混為安裝數
- **原條款（非摘要代替）**：Owner＋pin＋license＋退出
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L654`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L00659-C06` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L00659-C06` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L00659-C06` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01054-C01｜R04.r3.4｜25/25 Methods 逐項 Trigger／NonTrigger／IO／競合／退出
- **原條款（非摘要代替）**：同一名字可出現在 386 技術列，
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1049`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01054-C01` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01054-C01` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01054-C01` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01054-C02｜R04.r3.4｜25/25 Methods 逐項 Trigger／NonTrigger／IO／競合／退出
- **原條款（非摘要代替）**：但兩者不可藉名稱合併 Source ID。
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1049`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `NEGATIVE`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01054-C02` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01054-C02` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01054-C02` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01054-C03｜R04.r3.4｜25/25 Methods 逐項 Trigger／NonTrigger／IO／競合／退出
- **原條款（非摘要代替）**：METHOD_ONLY`/`PROTOCOL_ONLY` 不得被強迫要求 install receipt；
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1049`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `NEGATIVE`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01054-C03` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01054-C03` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01054-C03` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01054-C04｜R04.r3.4｜25/25 Methods 逐項 Trigger／NonTrigger／IO／競合／退出
- **原條款（非摘要代替）**：軟體方法只在 Host/Version/License 對應的 qualification 後可執行，
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1049`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01054-C04` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01054-C04` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01054-C04` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01054-C05｜R04.r3.4｜25/25 Methods 逐項 Trigger／NonTrigger／IO／競合／退出
- **原條款（非摘要代替）**：否則人工 read-only。
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1049`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01054-C05` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01054-C05` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01054-C05` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01084-C01｜R04.r3.5｜15 首選 Wheel 的不降級選型門檻
- **原條款（非摘要代替）**：本表拆分 `design_preferred`、`research_observed`、`current_pin_verified`、`install/activation`、`rights`；
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1079`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01084-C01` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01084-C01` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01084-C01` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01084-C02｜R04.r3.5｜15 首選 Wheel 的不降級選型門檻
- **原條款（非摘要代替）**：版本未重新驗證且沒有真安裝收據時一律 `PIN_UNVERIFIED/INSTALL_PENDING`，
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1079`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01084-C02` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01084-C02` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01084-C02` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01084-C03｜R04.r3.5｜15 首選 Wheel 的不降級選型門檻
- **原條款（非摘要代替）**：不沿用舊 Snapshot 的 v1.0.0 作當前自動降版**。
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1079`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01084-C03` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01084-C03` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01084-C03` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01084-C04｜R04.r3.5｜15 首選 Wheel 的不降級選型門檻
- **原條款（非摘要代替）**：OpenSpec/Spec Kit、P4、Fabric/HGK 等角色各有不可互換的負例與原生 Owner。
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1079`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `NEGATIVE`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01084-C04` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01084-C04` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01084-C04` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01110-C01｜R05.r3.base.1｜SPEC、LEDGER、DELIVER 三視圖共用 Canonical Truth，而非三套 SSOT
- **原條款（非摘要代替）**：LEDGER（事實證據）**：`SourceInventory,AuthorityBindingRef,DecisionLedger,TraceLedger,ConflictLedger,AdmissionLedger,EffectExpectation,TT`，
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1105`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01110-C01` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01110-C01` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01110-C01` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01110-C02｜R05.r3.base.1｜SPEC、LEDGER、DELIVER 三視圖共用 Canonical Truth，而非三套 SSOT
- **原條款（非摘要代替）**：每個 entry 記 `(subject_id, source_sha, producer_identity, timestamp, validity, supersedes, first_fail)`；
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1105`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01110-C02` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01110-C02` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01110-C02` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01110-C03｜R05.r3.base.1｜SPEC、LEDGER、DELIVER 三視圖共用 Canonical Truth，而非三套 SSOT
- **原條款（非摘要代替）**：不許交接時丟掉失敗事件。
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1105`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `NEGATIVE`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01110-C03` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01110-C03` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01110-C03` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01132-C01｜R05.r3.base.2｜可拒收的 DOC-00 HandoffEnvelope（候選形狀，非 PIPD 新 Schema）
- **原條款（非摘要代替）**：讀者應驗證 `DOC_id` 與檔案 SHA/版本、`source_clause` 非空、正/負 Oracle 對應、Scope 不超出 request。
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1127`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01132-C01` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01132-C01` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01132-C01` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01132-C02｜R05.r3.base.2｜可拒收的 DOC-00 HandoffEnvelope（候選形狀，非 PIPD 新 Schema）
- **原條款（非摘要代替）**：禁止用本 JSON 假名建立真正 HGK TaskSpecSeed/WorkOrder。
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1127`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `NEGATIVE`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01132-C02` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01132-C02` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01132-C02` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01287-C01｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：## C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1282`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01287-C01` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01287-C01` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01287-C01` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01291-C01｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：來源 subject 消歧與 10 問準確原句
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1286`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01291-C01` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01291-C01` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01291-C01` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01291-C02｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：POS: 讀取 C02 的對應具名 record 並以已述來源、輸入、輸出與失敗碼驗證
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1286`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `NEGATIVE`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01291-C02` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01291-C02` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01291-C02` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01291-C03｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：NEG: 移除 F-001 專用物件/模擬錯來源→ F-001_SUBSTANTIVE_MISSING
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1286`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01291-C03` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01291-C03` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01291-C03` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01291-C04｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：Owner by controlling DOC;
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1286`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01291-C04` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01291-C04` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01291-C04` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01291-C05｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：author local check only
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1286`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01291-C05` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01291-C05` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01291-C05` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01291-C06｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：BODY_REPAIRED_CANDIDATE;
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1286`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01291-C06` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01291-C06` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01291-C06` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01291-C07｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：NOT_INDEPENDENTLY_VERIFIED
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1286`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01291-C07` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01291-C07` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01291-C07` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01292-C01｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：單一現行正文/歷史分離
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1287`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01292-C01` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01292-C01` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01292-C01` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01292-C02｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：POS: 讀取 R00 的對應具名 record 並以已述來源、輸入、輸出與失敗碼驗證
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1287`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `NEGATIVE`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01292-C02` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01292-C02` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01292-C02` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01292-C03｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：NEG: 移除 F-002 專用物件/模擬錯來源→ F-002_SUBSTANTIVE_MISSING
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1287`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01292-C03` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01292-C03` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01292-C03` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01292-C04｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：Owner by controlling DOC;
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1287`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01292-C04` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01292-C04` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01292-C04` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01292-C05｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：author local check only
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1287`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01292-C05` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01292-C05` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01292-C05` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01292-C06｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：BODY_REPAIRED_CANDIDATE;
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1287`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01292-C06` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01292-C06` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01292-C06` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01292-C07｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：NOT_INDEPENDENTLY_VERIFIED
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1287`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01292-C07` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01292-C07` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01292-C07` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01293-C01｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：386 法位分類和技術逐項
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1288`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01293-C01` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01293-C01` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01293-C01` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01293-C02｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：POS: 讀取 R04 的對應具名 record 並以已述來源、輸入、輸出與失敗碼驗證
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1288`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `NEGATIVE`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01293-C02` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01293-C02` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01293-C02` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01293-C03｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：NEG: 移除 F-003 專用物件/模擬錯來源→ F-003_SUBSTANTIVE_MISSING
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1288`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01293-C03` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01293-C03` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01293-C03` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01293-C04｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：Owner by controlling DOC;
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1288`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01293-C04` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01293-C04` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01293-C04` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01293-C05｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：author local check only
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1288`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01293-C05` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01293-C05` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01293-C05` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01293-C06｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：BODY_REPAIRED_CANDIDATE;
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1288`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01293-C06` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01293-C06` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01293-C06` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01293-C07｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：NOT_INDEPENDENTLY_VERIFIED
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1288`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01293-C07` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01293-C07` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01293-C07` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01294-C01｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：226 專用 pos-neg
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1289`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01294-C01` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01294-C01` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01294-C01` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01294-C02｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：POS: 讀取 R04 的對應具名 record 並以已述來源、輸入、輸出與失敗碼驗證
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1289`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `NEGATIVE`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01294-C02` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01294-C02` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01294-C02` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01294-C03｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：NEG: 移除 F-004 專用物件/模擬錯來源→ F-004_SUBSTANTIVE_MISSING
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1289`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01294-C03` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01294-C03` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01294-C03` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01294-C04｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：Owner by controlling DOC;
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1289`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01294-C04` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01294-C04` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01294-C04` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01294-C05｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：author local check only
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1289`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01294-C05` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01294-C05` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01294-C05` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01294-C06｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：BODY_REPAIRED_CANDIDATE;
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1289`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01294-C06` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01294-C06` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01294-C06` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01294-C07｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：NOT_INDEPENDENTLY_VERIFIED
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1289`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01294-C07` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01294-C07` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01294-C07` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01295-C01｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：45 owner H1 實質 locator
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1290`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01295-C01` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01295-C01` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01295-C01` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01295-C02｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：POS: 讀取 C48 的對應具名 record 並以已述來源、輸入、輸出與失敗碼驗證
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1290`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `NEGATIVE`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01295-C02` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01295-C02` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01295-C02` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01295-C03｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：NEG: 移除 F-005 專用物件/模擬錯來源→ F-005_SUBSTANTIVE_MISSING
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1290`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01295-C03` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01295-C03` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01295-C03` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01295-C04｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：Owner by controlling DOC;
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1290`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01295-C04` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01295-C04` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01295-C04` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01295-C05｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：author local check only
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1290`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01295-C05` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01295-C05` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01295-C05` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01295-C06｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：BODY_REPAIRED_CANDIDATE;
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1290`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01295-C06` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01295-C06` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01295-C06` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01295-C07｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：NOT_INDEPENDENTLY_VERIFIED
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1290`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01295-C07` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01295-C07` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01295-C07` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01296-C01｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：38 個 Surface
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1291`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01296-C01` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01296-C01` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01296-C01` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01296-C02｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：POS: 讀取 R06 的對應具名 record 並以已述來源、輸入、輸出與失敗碼驗證
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1291`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `NEGATIVE`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01296-C02` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01296-C02` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01296-C02` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01296-C03｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：NEG: 移除 F-006 專用物件/模擬錯來源→ F-006_SUBSTANTIVE_MISSING
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1291`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01296-C03` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01296-C03` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01296-C03` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01296-C04｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：Owner by controlling DOC;
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1291`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01296-C04` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01296-C04` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01296-C04` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01296-C05｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：author local check only
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1291`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01296-C05` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01296-C05` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01296-C05` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01296-C06｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：BODY_REPAIRED_CANDIDATE;
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1291`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01296-C06` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01296-C06` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01296-C06` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01296-C07｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：NOT_INDEPENDENTLY_VERIFIED
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1291`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01296-C07` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01296-C07` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01296-C07` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01297-C01｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：15 Wheel TDR
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1292`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01297-C01` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01297-C01` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01297-C01` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01297-C02｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：POS: 讀取 R04 的對應具名 record 並以已述來源、輸入、輸出與失敗碼驗證
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1292`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `NEGATIVE`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01297-C02` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01297-C02` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01297-C02` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01297-C03｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：NEG: 移除 F-007 專用物件/模擬錯來源→ F-007_SUBSTANTIVE_MISSING
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1292`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01297-C03` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01297-C03` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01297-C03` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01297-C04｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：Owner by controlling DOC;
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1292`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01297-C04` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01297-C04` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01297-C04` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01297-C05｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：author local check only
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1292`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01297-C05` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01297-C05` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01297-C05` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01297-C06｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：BODY_REPAIRED_CANDIDATE;
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1292`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01297-C06` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01297-C06` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01297-C06` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01297-C07｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：NOT_INDEPENDENTLY_VERIFIED
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1292`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01297-C07` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01297-C07` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01297-C07` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01298-C01｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：25 Methods
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1293`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01298-C01` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01298-C01` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01298-C01` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01298-C02｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：POS: 讀取 R04 的對應具名 record 並以已述來源、輸入、輸出與失敗碼驗證
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1293`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `NEGATIVE`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01298-C02` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01298-C02` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01298-C02` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01298-C03｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：NEG: 移除 F-008 專用物件/模擬錯來源→ F-008_SUBSTANTIVE_MISSING
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1293`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01298-C03` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01298-C03` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01298-C03` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01298-C04｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：Owner by controlling DOC;
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1293`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01298-C04` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01298-C04` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01298-C04` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01298-C05｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：author local check only
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1293`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01298-C05` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01298-C05` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01298-C05` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01298-C06｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：BODY_REPAIRED_CANDIDATE;
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1293`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01298-C06` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01298-C06` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01298-C06` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01298-C07｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：NOT_INDEPENDENTLY_VERIFIED
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1293`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01298-C07` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01298-C07` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01298-C07` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01299-C01｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：16 Moments／3 Golden Journeys
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1294`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01299-C01` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01299-C01` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01299-C01` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01299-C02｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：POS: 讀取 R02 的對應具名 record 並以已述來源、輸入、輸出與失敗碼驗證
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1294`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `NEGATIVE`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01299-C02` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01299-C02` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01299-C02` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01299-C03｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：NEG: 移除 F-009 專用物件/模擬錯來源→ F-009_SUBSTANTIVE_MISSING
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1294`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01299-C03` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01299-C03` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01299-C03` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01299-C04｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：Owner by controlling DOC;
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1294`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01299-C04` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01299-C04` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01299-C04` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01299-C05｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：author local check only
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1294`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01299-C05` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01299-C05` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01299-C05` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01299-C06｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：BODY_REPAIRED_CANDIDATE;
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1294`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01299-C06` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01299-C06` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01299-C06` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01299-C07｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：NOT_INDEPENDENTLY_VERIFIED
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1294`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01299-C07` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01299-C07` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01299-C07` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01300-C01｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：POS: 讀取 R00 的對應具名 record 並以已述來源、輸入、輸出與失敗碼驗證
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1295`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `NEGATIVE`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01300-C01` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01300-C01` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01300-C01` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01300-C02｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：NEG: 移除 F-010 專用物件/模擬錯來源→ F-010_SUBSTANTIVE_MISSING
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1295`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01300-C02` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01300-C02` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01300-C02` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01300-C03｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：Owner by controlling DOC;
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1295`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01300-C03` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01300-C03` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01300-C03` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01300-C04｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：author local check only
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1295`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01300-C04` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01300-C04` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01300-C04` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01300-C05｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：BODY_REPAIRED_CANDIDATE;
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1295`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01300-C05` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01300-C05` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01300-C05` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01300-C06｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：NOT_INDEPENDENTLY_VERIFIED
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1295`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01300-C06` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01300-C06` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01300-C06` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01301-C01｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：Three SP／六模組
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1296`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01301-C01` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01301-C01` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01301-C01` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01301-C02｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：POS: 讀取 R06 的對應具名 record 並以已述來源、輸入、輸出與失敗碼驗證
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1296`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `NEGATIVE`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01301-C02` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01301-C02` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01301-C02` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01301-C03｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：NEG: 移除 F-011 專用物件/模擬錯來源→ F-011_SUBSTANTIVE_MISSING
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1296`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01301-C03` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01301-C03` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01301-C03` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01301-C04｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：Owner by controlling DOC;
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1296`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01301-C04` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01301-C04` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01301-C04` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01301-C05｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：author local check only
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1296`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01301-C05` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01301-C05` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01301-C05` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01301-C06｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：BODY_REPAIRED_CANDIDATE;
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1296`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01301-C06` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01301-C06` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01301-C06` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01301-C07｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：NOT_INDEPENDENTLY_VERIFIED
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1296`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01301-C07` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01301-C07` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01301-C07` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01302-C01｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：Dogfood & SWOF feedback
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1297`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01302-C01` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01302-C01` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01302-C01` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01302-C02｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：POS: 讀取 C54 的對應具名 record 並以已述來源、輸入、輸出與失敗碼驗證
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1297`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `NEGATIVE`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01302-C02` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01302-C02` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01302-C02` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01302-C03｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：NEG: 移除 F-012 專用物件/模擬錯來源→ F-012_SUBSTANTIVE_MISSING
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1297`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01302-C03` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01302-C03` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01302-C03` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01302-C04｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：Owner by controlling DOC;
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1297`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01302-C04` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01302-C04` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01302-C04` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01302-C05｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：author local check only
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1297`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01302-C05` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01302-C05` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01302-C05` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01302-C06｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：BODY_REPAIRED_CANDIDATE;
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1297`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01302-C06` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01302-C06` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01302-C06` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01302-C07｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：NOT_INDEPENDENTLY_VERIFIED
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1297`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01302-C07` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01302-C07` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01302-C07` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01303-C01｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：N11/N14/26/28/58/72 先讀路由
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1298`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01303-C01` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01303-C01` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01303-C01` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01303-C02｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：POS: 讀取 C02 的對應具名 record 並以已述來源、輸入、輸出與失敗碼驗證
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1298`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `NEGATIVE`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01303-C02` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01303-C02` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01303-C02` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01303-C03｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：NEG: 移除 F-013 專用物件/模擬錯來源→ F-013_SUBSTANTIVE_MISSING
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1298`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01303-C03` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01303-C03` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01303-C03` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01303-C04｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：Owner by controlling DOC;
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1298`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01303-C04` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01303-C04` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01303-C04` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01303-C05｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：author local check only
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1298`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01303-C05` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01303-C05` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01303-C05` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01303-C06｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：BODY_REPAIRED_CANDIDATE;
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1298`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01303-C06` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01303-C06` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01303-C06` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01303-C07｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：NOT_INDEPENDENTLY_VERIFIED
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1298`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01303-C07` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01303-C07` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01303-C07` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01304-C01｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：Oracle Crosswalk
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1299`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01304-C01` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01304-C01` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01304-C01` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01304-C02｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：POS: 讀取 C02 的對應具名 record 並以已述來源、輸入、輸出與失敗碼驗證
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1299`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `NEGATIVE`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01304-C02` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01304-C02` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01304-C02` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01304-C03｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：NEG: 移除 F-014 專用物件/模擬錯來源→ F-014_SUBSTANTIVE_MISSING
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1299`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01304-C03` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01304-C03` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01304-C03` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01304-C04｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：Owner by controlling DOC;
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1299`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01304-C04` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01304-C04` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01304-C04` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01304-C05｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：author local check only
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1299`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01304-C05` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01304-C05` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01304-C05` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01304-C06｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：BODY_REPAIRED_CANDIDATE;
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1299`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01304-C06` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01304-C06` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01304-C06` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01304-C07｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：NOT_INDEPENDENTLY_VERIFIED
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1299`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01304-C07` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01304-C07` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01304-C07` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01305-C01｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：POS: 讀取 R01 的對應具名 record 並以已述來源、輸入、輸出與失敗碼驗證
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1300`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `NEGATIVE`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01305-C01` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01305-C01` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01305-C01` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01305-C02｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：NEG: 移除 F-015 專用物件/模擬錯來源→ F-015_SUBSTANTIVE_MISSING
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1300`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01305-C02` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01305-C02` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01305-C02` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01305-C03｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：Owner by controlling DOC;
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1300`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01305-C03` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01305-C03` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01305-C03` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01305-C04｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：author local check only
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1300`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01305-C04` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01305-C04` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01305-C04` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01305-C05｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：BODY_REPAIRED_CANDIDATE;
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1300`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01305-C05` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01305-C05` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01305-C05` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01305-C06｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：NOT_INDEPENDENTLY_VERIFIED
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1300`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01305-C06` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01305-C06` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01305-C06` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01306-C01｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：39 Cell predicate
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1301`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01306-C01` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01306-C01` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01306-C01` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01306-C02｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：POS: 讀取 R02 的對應具名 record 並以已述來源、輸入、輸出與失敗碼驗證
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1301`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `NEGATIVE`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01306-C02` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01306-C02` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01306-C02` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01306-C03｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：NEG: 移除 F-016 專用物件/模擬錯來源→ F-016_SUBSTANTIVE_MISSING
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1301`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01306-C03` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01306-C03` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01306-C03` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01306-C04｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：Owner by controlling DOC;
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1301`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01306-C04` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01306-C04` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01306-C04` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01306-C05｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：author local check only
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1301`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01306-C05` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01306-C05` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01306-C05` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01306-C06｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：BODY_REPAIRED_CANDIDATE;
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1301`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01306-C06` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01306-C06` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01306-C06` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01306-C07｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：NOT_INDEPENDENTLY_VERIFIED
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1301`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01306-C07` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01306-C07` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01306-C07` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01307-C01｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：history disposition 不平行正文
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1302`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01307-C01` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01307-C01` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01307-C01` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01307-C02｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：POS: 讀取 R10 的對應具名 record 並以已述來源、輸入、輸出與失敗碼驗證
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1302`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `NEGATIVE`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01307-C02` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01307-C02` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01307-C02` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01307-C03｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：NEG: 移除 F-017 專用物件/模擬錯來源→ F-017_SUBSTANTIVE_MISSING
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1302`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01307-C03` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01307-C03` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01307-C03` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01307-C04｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：Owner by controlling DOC;
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1302`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01307-C04` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01307-C04` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01307-C04` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01307-C05｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：author local check only
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1302`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01307-C05` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01307-C05` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01307-C05` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01307-C06｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：BODY_REPAIRED_CANDIDATE;
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1302`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01307-C06` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01307-C06` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01307-C06` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01307-C07｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：NOT_INDEPENDENTLY_VERIFIED
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1302`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01307-C07` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01307-C07` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01307-C07` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01308-C01｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：Spec-to-Atom 轉譯
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1303`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01308-C01` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01308-C01` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01308-C01` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01308-C02｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：POS: 讀取 R04 的對應具名 record 並以已述來源、輸入、輸出與失敗碼驗證
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1303`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `NEGATIVE`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01308-C02` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01308-C02` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01308-C02` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01308-C03｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：NEG: 移除 F-018 專用物件/模擬錯來源→ F-018_SUBSTANTIVE_MISSING
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1303`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01308-C03` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01308-C03` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01308-C03` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01308-C04｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：Owner by controlling DOC;
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1303`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01308-C04` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01308-C04` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01308-C04` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01308-C05｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：author local check only
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1303`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01308-C05` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01308-C05` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01308-C05` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01308-C06｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：BODY_REPAIRED_CANDIDATE;
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1303`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01308-C06` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01308-C06` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01308-C06` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01308-C07｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：NOT_INDEPENDENTLY_VERIFIED
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1303`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01308-C07` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01308-C07` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01308-C07` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01309-C01｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：research pin vs selected pin
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1304`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01309-C01` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01309-C01` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01309-C01` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01309-C02｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：POS: 讀取 R08 的對應具名 record 並以已述來源、輸入、輸出與失敗碼驗證
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1304`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `NEGATIVE`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01309-C02` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01309-C02` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01309-C02` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01309-C03｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：NEG: 移除 F-019 專用物件/模擬錯來源→ F-019_SUBSTANTIVE_MISSING
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1304`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01309-C03` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01309-C03` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01309-C03` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01309-C04｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：Owner by controlling DOC;
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1304`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01309-C04` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01309-C04` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01309-C04` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01309-C05｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：author local check only
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1304`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01309-C05` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01309-C05` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01309-C05` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01309-C06｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：BODY_REPAIRED_CANDIDATE;
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1304`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01309-C06` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01309-C06` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01309-C06` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01309-C07｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：NOT_INDEPENDENTLY_VERIFIED
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1304`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01309-C07` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01309-C07` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01309-C07` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01310-C01｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：POS: 讀取 R05 的對應具名 record 並以已述來源、輸入、輸出與失敗碼驗證
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1305`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `NEGATIVE`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01310-C01` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01310-C01` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01310-C01` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01310-C02｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：NEG: 移除 F-020 專用物件/模擬錯來源→ F-020_SUBSTANTIVE_MISSING
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1305`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01310-C02` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01310-C02` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01310-C02` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01310-C03｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：Owner by controlling DOC;
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1305`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01310-C03` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01310-C03` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01310-C03` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01310-C04｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：author local check only
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1305`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01310-C04` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01310-C04` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01310-C04` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01310-C05｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：BODY_REPAIRED_CANDIDATE;
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1305`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01310-C05` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01310-C05` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01310-C05` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01310-C06｜C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
- **原條款（非摘要代替）**：NOT_INDEPENDENTLY_VERIFIED
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1305`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01310-C06` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01310-C06` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01310-C06` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01313-C01｜Compound 要求原子化
- **原條款（非摘要代替）**：來源出現「各有／分別／對應／逐項／每一／所有」時，
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1308`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01313-C01` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01313-C01` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01313-C01` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01313-C02｜Compound 要求原子化
- **原條款（非摘要代替）**：自動拆出 `parent_req_id,child_req_id,quantifier_target,source_sha,source_clause,scope,acceptance_predicate,negative_fixture,consumer`；
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1308`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01313-C02` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01313-C02` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01313-C02` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01313-C03｜Compound 要求原子化
- **原條款（非摘要代替）**：禁止讓 `各有 POS+NEG` 保留為父條一條。
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1308`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `NEGATIVE`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01313-C03` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01313-C03` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01313-C03` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01313-C04｜Compound 要求原子化
- **原條款（非摘要代替）**：範例「三 SP 各有 Host 安裝」→三個 `SP` ×指定 Host 的十二項獨立測試；
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1308`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01313-C04` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01313-C04` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01313-C04` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01313-C05｜Compound 要求原子化
- **原條款（非摘要代替）**：38 surfaces 各有 uninstall`→38 個 uninstall checks；
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1308`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01313-C05` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01313-C05` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01313-C05` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01313-C06｜Compound 要求原子化
- **原條款（非摘要代替）**：39 Gate` 每 cell R/C/F/N 獨立條件和禁止測試。
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1308`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `NEGATIVE`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01313-C06` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01313-C06` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01313-C06` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01313-C07｜Compound 要求原子化
- **原條款（非摘要代替）**：解析器數量核對不等於語義閉合。
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1308`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01313-C07` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01313-C07` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01313-C07` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01319-C01｜C53.r3.base.1｜Source family disposition、完整性分母與正式 Freeze 缺口
- **原條款（非摘要代替）**：歷史 DOC00 r2 的 186 個物理來源清冊已保留在各 `HISTORICAL_R2_SUBSTANCE` 區塊供回歸；
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1314`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01319-C01` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01319-C01` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01319-C01` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01319-C02｜C53.r3.base.1｜Source family disposition、完整性分母與正式 Freeze 缺口
- **原條款（非摘要代替）**：本節的 *本輪* 分母在 R01 機器原始清冊。
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1314`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01319-C02` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01319-C02` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01319-C02` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01319-C03｜C53.r3.base.1｜Source family disposition、完整性分母與正式 Freeze 缺口
- **原條款（非摘要代替）**：每個 family 的 bytes/hash 仍應由當輪來源重算，
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1314`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01319-C03` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01319-C03` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01319-C03` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01319-C04｜C53.r3.base.1｜Source family disposition、完整性分母與正式 Freeze 缺口
- **原條款（非摘要代替）**：不能用老 r2 的 SHA 代替新附件的 SHA。
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1314`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01319-C04` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01319-C04` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01319-C04` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01319-C05｜C53.r3.base.1｜Source family disposition、完整性分母與正式 Freeze 缺口
- **原條款（非摘要代替）**：FamilyCount 僅目前上傳實體數，
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1314`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01319-C05` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01319-C05` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01319-C05` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01319-C06｜C53.r3.base.1｜Source family disposition、完整性分母與正式 Freeze 缺口
- **原條款（非摘要代替）**：不代表原資料庫全冊。
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1314`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01319-C06` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01319-C06` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01319-C06` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01340-C01｜C53.r3.base.1｜Source family disposition、完整性分母與正式 Freeze 缺口
- **原條款（非摘要代替）**：MissingSources / Scope Gaps**：`PORTABLE_MOUNT_PROFILE.md` 及 `GRP-01～09` 目前不在本輪 sandbox（只見歷史文件內的預期 hash，
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1335`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01340-C01` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01340-C01` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01340-C01` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01340-C02｜C53.r3.base.1｜Source family disposition、完整性分母與正式 Freeze 缺口
- **原條款（非摘要代替）**：SBL_PIPD-LS-PKG_總藍圖`、`SBL_PIPD-LS-PKG_全DOC藍圖`、`SBL_PIPD-LS-PKG_整合校正10問_回答` 本輪無獨立原件；
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1335`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01340-C02` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01340-C02` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01340-C02` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01340-C03｜C53.r3.base.1｜Source family disposition、完整性分母與正式 Freeze 缺口
- **原條款（非摘要代替）**：Fabric_HG-KSEOS 原資料庫的每個原生文件未全作獨立實體；
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1335`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01340-C03` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01340-C03` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01340-C03` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01340-C04｜C53.r3.base.1｜Source family disposition、完整性分母與正式 Freeze 缺口
- **原條款（非摘要代替）**：DOC-12/13 r1 與 AUDIT 原件未取得。
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1335`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01340-C04` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01340-C04` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01340-C04` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01340-C05｜C53.r3.base.1｜Source family disposition、完整性分母與正式 Freeze 缺口
- **原條款（非摘要代替）**：以上全部保留 `SOURCE_MISSING / FULL_REQUESTED_CORPUS_COVERAGE_NOT_PROVEN`，
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1335`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01340-C05` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01340-C05` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01340-C05` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01340-C06｜C53.r3.base.1｜Source family disposition、完整性分母與正式 Freeze 缺口
- **原條款（非摘要代替）**：對受影正式 Freeze/PI/Candidate-accepted Claim 一律 HOLD。
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1335`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01340-C06` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01340-C06` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01340-C06` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01351-C01｜R06.r3.base.1｜五條可直接消費的端到端 ReaderRoute（不虛構真執行）
- **原條款（非摘要代替）**：每個 profile 只在本輪設計上呈現完整讀序、必要外部證據與拒收，
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1346`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01351-C01` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01351-C01` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01351-C01` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01351-C02｜R06.r3.base.1｜五條可直接消費的端到端 ReaderRoute（不虛構真執行）
- **原條款（非摘要代替）**：不表示這些案例已實際運行。
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1346`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01351-C02` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01351-C02` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01351-C02` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01351-C03｜R06.r3.base.1｜五條可直接消費的端到端 ReaderRoute（不虛構真執行）
- **原條款（非摘要代替）**：ReaderRequest` 必有 goal/task/product_kind/mode/host/locator if given；
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1346`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01351-C03` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01351-C03` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01351-C03` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01351-C04｜R06.r3.base.1｜五條可直接消費的端到端 ReaderRoute（不虛構真執行）
- **原條款（非摘要代替）**：ReaderRoute` 提供 next DOC、正/負驗證及缺證；
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1346`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01351-C04` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01351-C04` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01351-C04` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01351-C05｜R06.r3.base.1｜五條可直接消費的端到端 ReaderRoute（不虛構真執行）
- **原條款（非摘要代替）**：HandoffEnvelope` 必提供 Owner、Claim、Readset Hash 與 return/NACK。
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1346`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01351-C05` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01351-C05` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01351-C05` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01361-C01｜R06.r3.base.2｜跨 Host 正交限定
- **原條款（非摘要代替）**：Host Family 是 Hermes / Codex / Claude Code / DeepSeek Harness，
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1356`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01361-C01` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01361-C01` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01361-C01` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01361-C02｜R06.r3.base.2｜跨 Host 正交限定
- **原條款（非摘要代替）**：另有 ChatGPT Web / Claude Web 私有體驗；
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1356`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01361-C02` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01361-C02` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01361-C02` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01361-C03｜R06.r3.base.2｜跨 Host 正交限定
- **原條款（非摘要代替）**：每個 Host 必須有 install/translate/activate/use/negative probe/uninstall/readback 個別結果，
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1356`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01361-C03` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01361-C03` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01361-C03` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01361-C04｜R06.r3.base.2｜跨 Host 正交限定
- **原條款（非摘要代替）**：不能用 Markdown 檔案或 GitHub 上的下載包假稱有效載入。
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1356`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01361-C04` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01361-C04` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01361-C04` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01361-C05｜R06.r3.base.2｜跨 Host 正交限定
- **原條款（非摘要代替）**：SBL Core + TPM-SP/Commander-SP/Acceptance-SP` 的同一 Canonical Truth 在 Host 端只作 projection，
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1356`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01361-C05` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01361-C05` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01361-C05` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01361-C06｜R06.r3.base.2｜跨 Host 正交限定
- **原條款（非摘要代替）**：Host-specific 裝載差異由 DOC-10/12 Owner 裁決。
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1356`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01361-C06` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01361-C06` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01361-C06` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01495-C01｜R08.r3.base.2｜研究強度與系統准入的明確拆層
- **原條款（非摘要代替）**：mattpocock/skills 目前可見 `v1.3.1` 與 repo 配置規範，
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1490`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01495-C01` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01495-C01` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01495-C01` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01495-C02｜R08.r3.base.2｜研究強度與系統准入的明確拆層
- **原條款（非摘要代替）**：正式啟用必 pin 到單個 skill 的對應 commit/path，
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1490`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01495-C02` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01495-C02` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01495-C02` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01495-C03｜R08.r3.base.2｜研究強度與系統准入的明確拆層
- **原條款（非摘要代替）**：並驗證 repo-specific config；
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1490`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01495-C03` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01495-C03` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01495-C03` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01495-C04｜R08.r3.base.2｜研究強度與系統准入的明確拆層
- **原條款（非摘要代替）**：Beta/in-progress 子技能不能預設已穩定。
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1490`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01495-C04` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01495-C04` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01495-C04` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01498-C01｜R08.r3.base.2｜研究強度與系統准入的明確拆層
- **原條款（非摘要代替）**：每個研究項若沒有另一不同 Owner 的實質互證，
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1493`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01498-C01` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01498-C01` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01498-C01` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01498-C02｜R08.r3.base.2｜研究強度與系統准入的明確拆層
- **原條款（非摘要代替）**：強度標記 `UNVERIFIED_SINGLE_SOURCE`；
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1493`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01498-C02` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01498-C02` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01498-C02` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01498-C03｜R08.r3.base.2｜研究強度與系統准入的明確拆層
- **原條款（非摘要代替）**：下游 admission 術語需做 `compare_release/tag/commit/license/host_support/CVEs/POS_NEG/rollback`。
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1493`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01498-C03` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01498-C03` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01498-C03` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01501-C01｜R08.r3.2｜2026-10-20 官方公開版本觀測（研究證據，不等於 Install Pin）
- **原條款（非摘要代替）**：研究讀回官方 Release/Commit 頁：OpenSpec [GitHub releases](https://github.com/Fission-AI/OpenSpec/releases) 顯示 `v1.14.3`（2026-10-17 發布，
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1496`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01501-C01` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01501-C01` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01501-C01` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01501-C02｜R08.r3.2｜2026-10-20 官方公開版本觀測（研究證據，不等於 Install Pin）
- **原條款（非摘要代替）**：具 linked specs/safe glob 修復）；
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1496`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01501-C02` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01501-C02` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01501-C02` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01501-C03｜R08.r3.2｜2026-10-20 官方公開版本觀測（研究證據，不等於 Install Pin）
- **原條款（非摘要代替）**：Spec Kit [GitHub releases](https://github.com/github/spec-kit/releases) 的歷史 `v1.0.6` 不是可無條件聲稱的現行鎖版，
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1496`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01501-C03` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01501-C03` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01501-C03` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01501-C04｜R08.r3.2｜2026-10-20 官方公開版本觀測（研究證據，不等於 Install Pin）
- **原條款（非摘要代替）**：官方九月 newsletter [版本概覽](https://github.com/github/spec-kit/blob/main/newsletters/2026-September.md) 已提 1.0.3～1.0.13 釋出；
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1496`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01501-C04` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01501-C04` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01501-C04` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01501-C05｜R08.r3.2｜2026-10-20 官方公開版本觀測（研究證據，不等於 Install Pin）
- **原條款（非摘要代替）**：Superpowers [GitHub commit](https://github.com/obra/superpowers/commit/main) 與 [Issue #2513](https://github.com/obra/superpowers/issues/2513) 指向 2026-10-10 的 `v7.0.0`，
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1496`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01501-C05` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01501-C05` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01501-C05` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01501-C06｜R08.r3.2｜2026-10-20 官方公開版本觀測（研究證據，不等於 Install Pin）
- **原條款（非摘要代替）**：不能將 rNEXT `v6.4.2` 直接視為 2026-10-20 最高相容候選。
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1496`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01501-C06` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01501-C06` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01501-C06` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01501-C07｜R08.r3.2｜2026-10-20 官方公開版本觀測（研究證據，不等於 Install Pin）
- **原條款（非摘要代替）**：每個實際來源需再由 Owner 固定 `tag+full commit SHA+signed release+license+Host` 並完成兼容驗證。
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1496`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01501-C07` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01501-C07` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01501-C07` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01501-C08｜R08.r3.2｜2026-10-20 官方公開版本觀測（研究證據，不等於 Install Pin）
- **原條款（非摘要代替）**：未取得上述確認時 `current_selected_version=UNRATIFIED`、`install=BLOCKED`，
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1496`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01501-C08` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01501-C08` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01501-C08` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01501-C09｜R08.r3.2｜2026-10-20 官方公開版本觀測（研究證據，不等於 Install Pin）
- **原條款（非摘要代替）**：不藉外部公開發布奪去既有原上位 disposition，
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1496`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01501-C09` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01501-C09` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01501-C09` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01501-C10｜R08.r3.2｜2026-10-20 官方公開版本觀測（研究證據，不等於 Install Pin）
- **原條款（非摘要代替）**：亦不得因版本更新而無聲升級。
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1496`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `NEGATIVE`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01501-C10` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01501-C10` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01501-C10` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

### SBL-D00-L01532-C01｜R09.r3.1｜作者端 7 步全量掃描的明確不同分母
- **原條款（非摘要代替）**：5. **子要求**：`各有/分別/對應` 每一個父句拆 subatom 並按 39/38/45 等分母檢查。
- **Source**：`SBL_DOC-00_ORIGINAL_VERBATIM.md:L1527`；SHA256 `bd9c1a85ea0cae68fa8cde617e5592fca6123f72b4caf1a9d2894167d9a82e01`；polarity `POSITIVE_OR_CONDITIONAL`。
- **原子化動作**：由 `SBL Product Owner/Doc Reader` 讀取上述**單個子句**及其相鄰原 Parent/NEG，在 `SourceSHA/Subject/Mode/Host/Scope` 同一性前提下，將該子句的原要求映射為 `SourceDecision{source_id,owner,status,first_fail}` 裡對應的結果欄；空值或與原文極性不等時拒收，不將其它 Child 的結果混合。
- **POS／觀測**：在 `SBL-D00-L01532-C01` 的原文前提及受影 Host/Mode 有效、原 SourceSHA 相同時，`SourceDecision{source_id,owner,status,first_fail}` 包含本片段逐字可對照的可觀測結果。
- **NEG／first fail**：將 `SBL-D00-L01532-C01` 原子要求刪除、極性反轉或改由其它 Parent/Host/Scope 的 Raw 冒充，原 `SBL Product Owner/Doc Reader` 必回 `SOURCE_AUTHORITY_UNRESOLVED`；原文否定條件不可由本候選倒轉。
- **NoFit/退出/續工**：原 consumer/Host/Writer 尚未取得時只令本 `SBL-D00-L01532-C01` 及依賴工作 `AFFECTED_HOLD`，保留原 SBL Product 功能義務；Reader 丟棄候選後依同 SourceSHA 重試，UNKNOWN effect 先 WorldReconcile。`NATIVE_NOT_RUN`。

## 原 SBL DOC 全量高保留回歸（此處非現行 FHS DeltaSpec）

原 Canonical SBL Source 字節已於 Evidence Archive 保留。下列原文可提供原句/負例/業務脈絡回讀，**不會與前段 R2 受影修補爭奪當期 Reader**。

~~~~~~~~~~markdown
---
artifact_id: SBL_PIPD-LS-PKG_DOC-00
artifact_type: FULL_SUBSTANTIVE_DESIGN_BODY_AUDIT_REPAIR
version: 2026-10-20-r3
supersedes: 2026-10-20-rNEXT
supersedes_sha256: bea453786f4110866dbc587fa0e009ef4df633b11be02e283272cbd52fcd4a8d
audit_basis: AUDIT_SBL_PIPD-LS-PKG_DOC-00_2026-10-20_FULL_SUBSTANTIVE_DESTRUCTIVE_REVIEW(1).md
root_task_kind: DESIGN
producer: GPT-6_AUTHOR
claim_ceiling: AUTHOR_SIDE_SUBSTANTIVE_DESIGN_REPAIRED_NOT_FORMAL_ACCEPTED
source_freeze: HOLD
oracle_conflict: CR-ORACLE-001_OPEN
owner_ratification: UNBOUND
independent_checker: NOT_EXECUTED
repo_binding: NOT_BOUND
native_effect: DENY
release: BLOCKED
locale: zh-TW
---

**本版作用**：r3 以單一現行實質正文取代 rNEXT，保留其 17 個法定 DOC-00 H1 的不降級章位；每項工程設計由使用者動作、輸入、轉換、具名輸出、禁止條件及收件者構成，無效的 `LEGACY/NEXT` 雙正文已移除。附屬清冊為本檔章節內有效資料，不是平行歷史法位；rNEXT 為可查的 superseded 原物理檔。`AUTHOR_SIDE` 不表示獨立 Checker，也不授予 Repo/Native/金融交易效果。**若獨立全量語義審查不能支持全部 F-001～020，則「最終定案」僅指本次作者端修補候選，正式發布仍 HOLD。**

**上位來源界線**：SBL v2.0r1 是 SBL 產品 Writer；SBL《設計規劃》10 卷是原意；PIPD-LS-SP P4 與 DOC-00～09 管正式 PI/PD/ECP/TQAEP；HGK/Fabric 唯一 Native Effect；SWOF Native Registry/Receiver 是接收端。2026-10-16 的三份 **SWOF_SQS-THC** 總藍圖、全 DOC 藍圖與十問回答已實體取得，但屬金融產品的平行域決策與集成約束，**不是**先前缺失的 `SBL_PIPD-LS-PKG_總藍圖`、`SBL_PIPD-LS-PKG_全DOC藍圖` 或 SBL 十問的同一份原件。其 Q01～10 不得跨 Subject 直接冒稱 SBL 十問 Owner 裁決。

## 來源精確 Hash（設計基線，不是正式 SourceFreeze）
| 實體檔案 | SHA-256 | bytes |
|---|---|---:|
| `SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md` | `83ea1bef8d045bf0a100a27599fcb2d51b1e9ed993d6ccc5c7d70708753dd747` | 1,004,172 |
| `SBL_PIPD-LS-PKG_DOC-00_2026-10-20_rNEXT_FULL_SUBSTANTIVE_FINAL_DESIGN.md` | `bea453786f4110866dbc587fa0e009ef4df633b11be02e283272cbd52fcd4a8d` | 1,325,406 |
| `AUDIT_SBL_PIPD-LS-PKG_DOC-00_2026-10-20_FULL_SUBSTANTIVE_DESTRUCTIVE_REVIEW(1).md` | `c4f2420c2607232f1b422064cabf197b49f365518f05d21d35c362d4aac00eae` | 230,451 |
| `SWOF_SQS-THC_PIPD-LS-PKG_整合校正10問_回答.md` | `8032d76d6ce36e9917ad4fc86512477516c323ccf60e77f93eeff868b6c23248` | 647,953 |
| `SWOF_SQS-THC PIPD-LS-PKG 總藍圖 r2.md` | `f0eb41ae4593be8cf7b124727090f5e5b22a7a7c3fe7f157f719a5bd87c7fbe4` | 1,579,164 |
| `SWOF_SQS-THC_PIPD-LS-PKG_全DOC藍圖.md` | `3ddb214e9bc11525b2aaa47b6c18e3012316ef31561073fba08683ad7662b0a4` | 756,608 |


# R00｜文件身份、五分鐘讀者卡與本輪讀取資格

## R00.r3.base.1｜本輪正式讀取身份與第一個有用成果（2026-10-20）
本單一 MD 是 **SBL DOC-00 編輯性導覽、來源邊界及交接規格**，不是 PIPD 官方 `PIPD_LS_DOC-00`，也不是 PI/PD Compiler、Native WorkOrder、Token、Human Approval、獨立 Checker 或 Release。上位 SBL 的產品路線保持 `Guided Spec → Governed Build → Evidence-based Verify → Bounded Repair`。任務輸入是實際 `goal、source locator、ProductKind、system_mode、host、desired_operation`，若初始僅給 goal，可在 `DISCOVERY` 輸出來源候選與讀冊路由，但不得把文稿產物稱為使用者真正 FUO。

**五分鐘冷啟動**：① 先讀本 `R00` 判斷唯讀／設計／要求副作用；② 到 `R02` 判別 ProductKind 與 SWOF Primary Kind（正交）；③ 用 `C48` 取得唯一主責 DOC；④ 到 `R03/C02` 核驗正式 PIPD 及權威；⑤ 在 `R07` 處理 FirstFail，最後 `C54` 形成可拒收的 HandoffEnvelope。任何權限、版本、來源不成立時只准回報 HOLD 與補件路由。

| 狀態 | 進入條件 | 可輸出 | 禁止輸出 | 轉移首次失敗 |
|---|---|---|---|---|
| DISCOVERY | 非空 goal，來源可能尚未齊備 | GoalCard、SourceLocatorCandidate、Readset 建議 | 正式 IntentCard/PI/PD/Permit | `INTAKE_INVALID`/`SOURCE_LOCATOR_MISSING` |
| BOUND_READ | 確實可解碼的來源 byte/hash、合法 Reader 區域 | SourceInventory、RequirementDisposition、ReaderRoute、差異/Conflict 候選 | 宣告正式 SourceFreeze、Native 觸發 | `AUTHORITY_UNKNOWN`/`CR_OPEN` |
| NATIVE_ELIGIBLE（由原 Owner 決定） | 真 Repo HEAD/currentness、正式 PI/PD、ONE ECP、Token、Owner 接收與驗證 | 可評估的施工請求（非由 DOC-00 發出） | DOC-00 自身核發執行資格 | `NO_REPO_CONTEXT`/`NO_TOKEN`/`EFFECT_UNPROVEN` |

本輪物理來源分母 197 個 Markdown（包含本次新上傳之 GPT-6 指令，排除本交付成品），舊 r2 使用的 162／172／186 一律只作歷史快照；全部原始 bytes SHA 及檔名在 R01。表內資料是本輪檔案掃描，不是 PIPD `SourceFreezeManifest`。

**Author-side Claim**：文檔實質更新且本地讀回可稽核；本輪 `INDEPENDENT_PASS=NOT_PERFORMED`、`FORMAL_SOURCE_FREEZE=HOLD`、`NATIVE_EFFECT=NOT_PERFORMED`。R10 有實體檔案驗證結果/外部可重算演算法，不能自簽任何後段資格。

## R00.r3.1｜五分鐘產品操作契約與七痛點→實體成果
人類入口 `goal + source_locator（可為待提供的查詢結果而非已凍結） + requested ProductKind + mode`；TPM 問最多一個**已被來源核對確有必要**的阻擋問題（單問僅為設計 UX 假說，不是已實測閾值），輸出 `GoalCard`、`MethodDecision` 和可讀 `MissingInput`。若只有 goal 而無來源，顯示「需一份文件或合法來源路徑」並可先進行無效應探索，不虛構 PI 或開始施工。七痛點的「成果」是以下可操作功能，非抽象品質宣言。
| Pain | 來源痛點 | SBL 產品行為 | 所借輪子／Owner | Input→可讀 FUO | 首次拒收 NEG | Moments／Journey | 詳規 DOC |
|---|---|---|---|---|---|---|---|
| P01 | 選型困難 | 目標→風險／Host／TaskKind 分流；返回 MethodDecision 的推薦、排除原因與 no-fit | MP-01；TPM-SP／DOC03 | GoalCard → RouteCard{selected,excluded,reason,missing} | 未定位來源卻輸出 install 命令 | M00-M02／GJ01 | DOC01/03/06 |
| P02 | 跨工具交接斷裂 | 以 subject_sha／typed_ref／owner／schema_version 關聯 PI/PD/DELIVER，只把 proposal 翻譯進合法 Writer | P4 route→PI→PD | HandoffEnvelope → typed ACK/NACK | 異主體或 stale head 被 ACK | M03-M06／GJ02 | DOC02/05/09 |
| P03 | 重問與決策遺失 | QuestionLedger 記 qkey／source sha／decision version，同版本不重問；變更需重算依賴 | Matt grill-with-docs；DecisionLedger | AnsweredQuestionSet → DeltaQuestions | same hash 反覆問或 source drift 不重問 | M01-M03／GJ01 | DOC01/03/10 |
| P04 | Writer 碰撞 | Typed OwnerMap 先定唯一 PIPD/HGK/SWOF Writer；OpenSpec/Spec Kit 僅 proposal | OpenSpec；Spec Kit→PIPD | SourceDelta → ReqAtomProposal | 由 SBL 直接宣稱正式 PI-PKG、Native Permit | M03-M07／GJ02 | DOC02/04/05 |
| P05 | 虛假 PASS | 同 subject SHA 的 POS/NEG 及真 RawReceipt；Checker 不同 principal 且有實體收據 | Superpowers；gstack；P4 TQAEP | TestCandidate → TQAEP/IndependentFinding | maker 自簽或 exit=0 且 0 tests | M08-M10／GJ02 | DOC08/09 |
| P06 | 宿主掛載失真 | 每 Host install/register/effective-load/trigger/deny/uninstall/readback | GENIEMAKER；Host Adapter | InstallSession → HostEffectivenessProof | 只有 ZIP/SKILL.md，loader 未列舉 | M14-M15／GJ03 | DOC10/12 |
| P07 | 最後一哩 FUO 缺失 | 新環境手動使用得到結果並能撤銷；Provider-off 走功能受限路徑 | DeliverBOM/Consumer UAT | Build → ConsumerOutcome/UninstallReceipt | 只有 README 或模擬沒清楚標示 | M12-M15／GJ01-03 | DOC12/13 |

**共同 UX 量測協議**：每個 FUO 回報 `persona,clean_start,source_sha,selected_path,first_useful_output,elapsed_ms,questions_reasked,error_count,provider_off,consumer_acceptance`。本文建議將 P03 同來源重問目標設為 0、每 Journey 回合使用者主觀「可用」且可重播；所有時效及操作次數為 **UAT 待量測門檻**，非已達標 KPI。`READ_ONLY_DESIGN` 時僅有可檢閱 Spec，不宣稱 CLI 已可執行。


# C02｜上位藍圖、設計規劃與文件來源的憲制／裁決優先序

## C02.r3.base.1｜五權威域並列，不因較新時間跨 Owner 奪權
| Domain | Formal Writer / Owner | 此 DOC-00 可投影 | 禁止的跨域替代 | 首敗 |
|---|---|---|---|---|
| SBL 產品/UX | SBL Product Owner + `SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md` | FUO、三 SP、八 ProductKind、GJ/ModeGate 的設計 reader | 本 DOC 寫第二 Product Truth | `SBL_PRODUCT_AUTHORITY_MISMATCH` |
| PIPD PI/PD | `PIPD-LIFECYCLE-SPEC@1.1.0`＋ PIPD DOC-00～09 各 Writer | 只讀 S0～S8 製程、TypedRef、Claim Ladder | OpenSpec/SpecKit/SBL 原文冒充正式 PI/PD | `AUTHORITY_UNKNOWN` |
| SWOF | SWOF Canonical/ABI/Release/Domain Owner | 7 PrimaryKinds/231 Entity/59 Relation/72 MC source-bound projection | SBL 建立新 SWOF identity/同名覆寫 | `DOMAIN_OWNER_MISMATCH` |
| HGK/Fabric | HG-KSEOS sole Native control plane；Fabric policy / Hermes runtime 分域 | Token、Effect、Readback/rollback 的預期契約 | 由 DOC-00、Skill 文案自行核准效果 | `NATIVE_PERMIT_MISSING` |
| Independent / Human | 真獨立 Checker principal + 人類 Release Owner | 預期判準、Negative Fixture、證據清單 | Maker 自簽獨立 PASS／生成 Human Token | `SOD_VIOLATION` |

**已核對的敏感衝突** `CR-ORACLE-001`：P4 `pipd-pi-compile/skill.md` 寫 `oracle_source=DOC-03 DOMAIN_ORACLES`，而 PIPD `DOC-07` 為 Verification/Oracle/Fixture 正式 writer；二者為不同抽象/來源，並非單憑名稱即可認定必然衝突或等價。直到原 PIPD Owner 提供 `OracleBinding` 指向的 `oracle_id/predicate_hash/version` 且批准映射，不得向 PI 編譯器注入臆造 alias；受影需求 `ORACLE_BINDING_HOLD`，未受影的只讀導覽可繼續。

## C02.r3.1｜外加 SWOF 十問與 SBL 主寫者的 cross-domain 防混淆
2026-10-16 `SWOF_SQS-THC_PIPD-LS-PKG_整合校正10問_回答.md` 屬金融 Project `SWOF_SQS-THC`，Q01～Q10 50 項屬該產品 Domain 設計建議；僅 D-033（62 章）、D-044（NoTrade/EMPTY/EXPIRED 合法）、D-075（Paper/XQ≠BrokerFill）由其自述為 locked，其他 47 項仍待 Owner。這三條亦**不是 SBL DOC-00 的 45 章/七痛點的直接規範**。SBL→SWOF 接入只以 typed proposal 交給正確 Receiver；SWOF Domain Writer/R09 veto/R00 人類授權/BrokerFill 事實不被本文件寫回。遇到同名十問或 `PIPD-LS-PKG_總藍圖`：先比對 `subject_id,artifact_id,source_hash,owner_scope`；不匹配回 `SUBJECT_SCOPE_MISMATCH`，SBL 原控制原件仍列 `SOURCE_GAP`，不得移花接木。

### Oracle 權威交叉綁定（CR-ORACLE-001 保持 OPEN）
`pipd-pi-compile` 的 `oracle_source=DOC-03 DOMAIN_ORACLES` 與 PIPD DOC-07 Verification/Oracle writer 之間不可以字串相似性自動等同。正式 Writer 需要 `OracleCrosswalk{oracle_id,domain_oracle_ref,verification_writer_ref,predicate_version,positive_fixture_sha,negative_fixture_sha,candidate_subject_sha,authority_receipt}`；缺任一 ref 或來源裁決時 `ORACLE_BINDING_CONFLICT → HOLD`。POS 例：DOC-03 predicate `exit_code=0 AND valid_json AND tests>0` 與 DOC-07 fixture 明確同版本同 SHA 可追；NEG：兩個 Writer 對「exit=0」的分母衝突、卻自動接受。


# R01｜SourceInventory 與機器可重算物理分母

## R01.r3.2｜當輪物理全集 1:1 完整 Manifest 與 20 詞全文檢索
此次只掃描真實存在的 Markdown 檔，**排除本次成果本身**以免自循環。對每一件執行 `read_bytes → decode(strict UTF-8) → sha256 → splitlines → 20 regex 全文計數`，全數讀取並非抽查。計數為句法索引，**非**獨立的 clause-level semantic closure；檔案群的法位仍按 Owner Scope 分隔。

原物理檔 202 份，180,445,606 bytes，1,729,738 行；UTF-8 errors=0；duplicate SHA groups=0。

| 真 physical basename | SHA-256 | bytes | lines | keyword occurrences | read state |
|---|---|---:|---:|---:|---|
| (舊版)實作驗收指揮官.md | 92e3550dc62f4640862b349ac7734cc72f9f199e6a41eff39689b489eae8596c | 449365 | 8657 | 696 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| AI_AGENT_SPEC_專業技術文檔_DOC-00_2026-07-28_r1.md | a9edaf3c3fb0579b32292b153a2c835ec5c20b944faedab7003c405415f1224d | 530454 | 5401 | 479 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| AI_AGENT_SPEC_專業技術文檔_DOC-01_2026-07-28_r1.md | b08307be1057b036f6fca05451caa5ed8ad322aa9fbb755ead82aa1447a2317c | 554279 | 6932 | 1263 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| AI_AGENT_SPEC_專業技術文檔_DOC-02_2026-07-28_r1.md | 14a2a76315bde04d4b5e3e7cff317d827d0ebc0440e32fa5fba4270271edc005 | 458503 | 7001 | 1391 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| AI_AGENT_SPEC_專業技術文檔_DOC-03_2026-07-28_r1.md | 14d972db19b013b8db4a94e4d5586642437e0cb3e207854a99145ddb993699c8 | 495181 | 2808 | 1279 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| AI_AGENT_SPEC_專業技術文檔_DOC-04_2026-07-28_r1.md | c4677512c56349d848f6c978abcdd19e4f6c98e088ede8e4ab4fdfbfccf63491 | 714615 | 6816 | 1309 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| AI_AGENT_SPEC_專業技術文檔_DOC-05_2026-07-28_r1.md | 46fe50e093f80b0e8169e1b3b3eadac8959c262978f5d22af0bd98eb85ab03fc | 383000 | 3237 | 752 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| AI_AGENT_SPEC_專業技術文檔_DOC-06_2026-07-28_r1.md | d87fd4b5c4a8bf9093903aaa9f32042efa0df921c3038e80811526f8b763dec7 | 686309 | 2925 | 946 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| AI_AGENT_SPEC_專業技術文檔_DOC-07_2026-07-28_r1.md | 71aeec31488a65c5c53eea75a4cf9f64da67982b5088df048e5aa0fcf64ea10b | 968967 | 3943 | 2767 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| AI_AGENT_SPEC_專業技術文檔_DOC-08_2026-07-28_r1.md | 27c1dbdcb67cce60d6a9ddab26cd5cc6e9ddf8e5a8d6884387b26f9091971e47 | 493745 | 3360 | 1185 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| AI_AGENT_SPEC_專業技術文檔_DOC-09_2026-07-28_r1.md | 69f781d864b374e1666267506688222cfe81b9f0872980d8cfe195c03281e1c9 | 919418 | 4028 | 2084 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| AI_AGENT_SPEC_專業技術文檔_DOC-10_2026-07-28_r1.md | 44e36aebd9a58c549766097b432d450a504e298c54558747970c463dee30086f | 605954 | 3457 | 1195 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| AUDIT_SBL_PIPD-LS-PKG_DOC-00_2026-10-20_FULL_SUBSTANTIVE_DESTRUCTIVE_REVIEW(1).md | c4f2420c2607232f1b422064cabf197b49f365518f05d21d35c362d4aac00eae | 230451 | 1225 | 3063 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| GPTs_GENIEMAKER_專業技術文檔_DOC-00.md | 999cd6e694cefade51aca550ac0246cecc5069fc0c051cae27ecb7990f44621b | 119737 | 1101 | 64 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| GPTs_GENIEMAKER_專業技術文檔_DOC-01.md | 7875a0a4c3dc76c862b0c446b8600f184a78025ecf7967963aa896f2f10c1bd8 | 120106 | 1593 | 92 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| GPTs_GENIEMAKER_專業技術文檔_DOC-02.md | 7d1adf14e4d7d8c190999964432f8c01771ed77087522072a41dfd741c933728 | 122421 | 1377 | 165 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| GPTs_GENIEMAKER_專業技術文檔_DOC-03.md | c22c007a488ead9b862920cbe936679a7f26eaaccb33c81b84b45cdd24873879 | 151280 | 1842 | 137 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| GPTs_GENIEMAKER_專業技術文檔_DOC-04.md | ac4dcc500f99ccb28d395d8fdd74085e36514daa75caf2b44f0e3bf277f47c87 | 80806 | 1454 | 67 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| GPTs_GENIEMAKER_專業技術文檔_DOC-05.md | c88c7488a0bce9d804b3ba5b16195bf111a0d6efacc20e38779962b5b4686ea9 | 96515 | 1439 | 117 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| GPTs_GENIEMAKER_專業技術文檔_DOC-06.md | 5a7c0f0ba31f901c7aa8c49e1d9dc4e2a17cc7530632dc5ad678aeb77630f1a7 | 119095 | 1567 | 306 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| GPTs_GENIEMAKER_專業技術文檔_DOC-07.md | 3e0ca72bdff43f4aeb86bedd5fd72517c0ef7509f3bb9db40221b2815af6b56b | 99696 | 1405 | 149 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| GPTs_GENIEMAKER_專業技術文檔_DOC-08.md | db3e48b463d0d565ab0b802af339b583f6257600cda691a21f1afbea8640e04d | 188513 | 1734 | 341 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| GPTs_GENIEMAKER_專業技術文檔_DOC-09.md | 658666910a19a2a78b320490564365ad07494cd98f3b6b04ba0b7708ad95c10b | 166120 | 2202 | 190 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| GPTs_GENIEMAKER_專業技術文檔_DOC-10.md | d40bccf19512a5434a99c93cac232c0ab656a5f88251c68896fe26f6873ce0dc | 118734 | 1439 | 165 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| GPTs_GENIEMAKER_專業技術文檔_DOC-11.md | 323658af5e9d5f185f91767d7008f047d033e005ca1d077e310c0c3402c6a34c | 122903 | 1445 | 131 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| GPTs_GENIEMAKER_專業技術文檔_DOC-12.md | 7f596a3f11878bcd859e2413342059e950112da98b110ca2009f896f13896f60 | 110634 | 1434 | 133 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| GPTs_GENIEMAKER_設計實作_vol-01.md | 216a8cbab2c7737ab52bdc63a1dd6ba29e2d50bd4eeb25878c406eeb97b94b3a | 636627 | 10158 | 1504 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| GPTs_GENIEMAKER_設計實作_vol-02.md | 8a4eb3a4412cb414f898bf0988a359c95bf07e488be5ced076611e2b6c5f3b32 | 679732 | 9542 | 1328 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| GPTs_GENIEMAKER_設計實作_vol-03.md | d7a771f405c38da69ae0c13855f142d43c970d62b75dc68352a6af146c96ae7f | 630489 | 6639 | 1053 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| GPTs_GENIEMAKER_設計實作_vol-04.md | 8d082e95124f8812fc4e06cb15137966073b75be6145f7426679894ecdb55c49 | 687947 | 6559 | 1122 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| GPTs_GENIEMAKER_設計實作_vol-05.md | e0ed54539b374ee6a77f0b11f8ae6487f91b10944f4ac34bf778d81e9c67f3a9 | 685301 | 7174 | 1378 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| GPTs_GENIEMAKER_設計實作_vol-06.md | 1e0f2621576d69ee16c01cbfc32f9ae92dfe14c43e3801014ff0928851993c14 | 855271 | 11063 | 1535 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| GPTs_GENIEMAKER_設計實作_vol-07.md | ead80aab9be7bbbb1e20428d15eae8030df36918b09436b8038db709a62adeb6 | 768471 | 6803 | 1554 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| GPTs_GENIEMAKER_設計實作_vol-08.md | 13e1f4a1299dc46622e07b3699cbc11519a1a3f9212a6460042943ec51a91fb5 | 701309 | 8981 | 1407 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| GPTs_GENIEMAKER_設計實作_vol-09.md | 12e6b3d827fa8642542fb5b9511fd8ca5b189acb2f2bc73febe694cf5585d900 | 718650 | 7744 | 1390 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| GPTs_GENIEMAKER_設計實作_vol-10.md | d4472004a6f8cb0f084175462081bda5a53c9e87e8268eeca08aecb788727df1 | 811259 | 10130 | 1375 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| HG-KSEOS_P0-CIP-PACK.md | 68b62b9ee2bb2b3ae5d172ccbb5a4182b20727dda8197e19e4a46905b518d911 | 6763034 | 69376 | 25449 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| HG-KSEOS_實作RBWI_WP_控制工件_PACK_FINAL_r2_Group-01_Authority_Source_Requirements.md | 218fa5014b994af7ed397ce3bd634fba18b6445cd0f0cf59423050fb969095fe | 4580319 | 7546 | 15078 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| HG-KSEOS_實作RBWI_WP_控制工件_PACK_FINAL_r2_Group-02_HLPE_Windows_Hermes_Distillation.md | 1930deb7be33fdcbe28d81e68cc7b85c92ad33b8516153e27df5da62eb838153 | 1049522 | 7456 | 2654 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| HG-KSEOS_實作RBWI_WP_控制工件_PACK_FINAL_r2_Group-03_Context_Memory_RAG_Agents_Harness_Loops.md | d3f3c6cab95e8866f9f55b33d8f8c761a54320514cb5d294bc4e00c79828b0dc | 308674 | 3747 | 1083 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| HG-KSEOS_實作RBWI_WP_控制工件_PACK_FINAL_r2_Group-04_ControlPlane_Providers_ToolTranslation.md | bdf2e1f8c5b6f08f26ed9cb5b2e19429fe4b7ad8d859937c205e7486e0f58b25 | 237629 | 2394 | 901 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| HG-KSEOS_實作RBWI_WP_控制工件_PACK_FINAL_r2_Group-05_Coding_Security_Verification_SRE.md | a6dd3b01eff638e0a2afa1bca41fd1587fc7ee1197db7f1dd5e78ba6d429e3c7 | 299330 | 3425 | 1135 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| HG-KSEOS_實作RBWI_WP_控制工件_PACK_FINAL_r2_Group-06_Evidence_DR_Evolution_Handoff_Release.md | a89a9fa6e1e0cfb8413d6fa0b647c3329791d7cf1c3cd88192689949aff57c87 | 336662 | 3639 | 1083 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| HG-KSEOS_實作RBWI_WP_控制工件_PACK_FINAL_r2_Group-07_CrossPack_Registries_Executable_Control_Contracts.md | 8a30cb146a3be4ade7d5bee3bf17174d4c1b50452f3e23e5638d7568ac9f16e2 | 2091956 | 17592 | 10705 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| HG-KSEOS_實作前開發文檔包.md | 7e287444c99112978ec1740adaaa848511dbc49737bb3419790f3efd4241e76f | 2311551 | 10395 | 6603 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| PIPD-LS-SP_PIPD-PKG-00.md | 89b60fde8b7bb93522c897a250a3ffbf9f2c4f91556493e74ee2da269710ecfe | 594228 | 10742 | 3242 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| PIPD-LS-SP_PIPD-PKG-01_2026-10-08_r2_HIGH_RETENTION_AUDIT_PATCHED_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md | 4c468e38d461595f21cd4d696dd2b97b655a438d7c8ef2fa1fec29637f8e139f | 984996 | 21587 | 3810 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| PIPD-LS-SP_PIPD-PKG-02_2026-10-08_r2_HIGH_RETENTION_AUDIT_PATCHED_FULL_REPAIR_FULL_INTEGRATED_SUBSTANTIVE_BODY.md | decf42108f693563b1127064864b891d233ace2cf63b33db8f8e57e5ef29e977 | 676216 | 10158 | 2884 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| PIPD-LS-SP_PIPD-PKG-03_2026-10-08_r2_HIGH_RETENTION_AUDIT_PATCHED_FULL_REPAIR_FULL_INTEGRATED_SUBSTANTIVE_BODY.md | a8d61dc4ab3062f401427c0787f596093671c6e0d7408c6e924be3362423043f | 735475 | 19674 | 2498 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| PIPD-LS-SP_PIPD-PKG-04_2026-10-08_r2_HIGH_RETENTION_AUDIT_PATCHED_FULL_REPAIR_FULL_INTEGRATED_SUBSTANTIVE_BODY.md | 967c0a4906d735f7f0973987b6162993d8a87d88d8675d9bd1675f31b1055a77 | 840568 | 16528 | 4628 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| PIPD-LS-SP_PIPD-PKG-05_2026-10-08_r2_HIGH_RETENTION_AUDIT_PATCHED_FULL_REPAIR_FULL_INTEGRATED_SUBSTANTIVE_BODY.md | b01b170519b1343c6f4593b4e039b28bb9b4f3f68dbd9c17be52b198d542ff94 | 295627 | 4199 | 898 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| PIPD-LS-SP_PIPD-PKG-06_2026-10-08_r2_HIGH_RETENTION_AUDIT_PATCHED_FULL_REPAIR_FULL_INTEGRATED_SUBSTANTIVE_BODY.md | 073592099de22584e12b5ca892c52b298ccca2504f759e723c258a52c2b14dc9 | 307177 | 4821 | 914 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| PIPD-LS-SP_PIPD-PKG-07_2026-10-08_r2_HIGH_RETENTION_AUDIT_PATCHED_FULL_REPAIR_FULL_INTEGRATED_SUBSTANTIVE_BODY.md | 213b49c53f060ea780657def96a22b7e2815a222726874187d154f844a5c9872 | 736406 | 14993 | 3503 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| PIPD-LS-SP_PIPD-PKG-08_2026-10-08_r2_HIGH_RETENTION_AUDIT_PATCHED_FULL_REPAIR_FULL_INTEGRATED_SUBSTANTIVE_BODY.md | e93fe81371192b43c2b583423a33cfb728b6a6b99a7eef48ef19ff2516e18445 | 712350 | 15916 | 2302 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| PIPD-LS-SP_PIPD-PKG-09_2026-10-08_r2_HIGH_RETENTION_AUDIT_PATCHED_FULL_REPAIR_FULL_INTEGRATED_SUBSTANTIVE_BODY.md | b2952652d511ff726fac0b7f80147f807d1624ad4392c682635aa5582e386197 | 733299 | 12555 | 2104 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| PIPD-LS-SP_PIPD-PKG-10_2026-10-08_r2_HIGH_RETENTION_AUDIT_PATCHED_FULL_REPAIR_FULL_INTEGRATED_SUBSTANTIVE_BODY.md | e089fa095aa83f130be4846b478edc14bea9f410d4cc99ad52e4b6b5375391bd | 1099995 | 11934 | 2765 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| PIPD-LS-SP_skeleton.md | a320d344785da9700aff8f48699b307ef150e0bb89d15735722f2930e46faa0e | 16078915 | 262863 | 60216 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| PIPD_LS_DOC-00_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md | be3a672ec20aa0e6b5e0e35097fc08de749bfe7f59f827d18e38aef67dd68ea4 | 251982 | 2292 | 575 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| PIPD_LS_DOC-01_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md | b753f2e5cdd5598a818f8a113d57b7f815aeb3f1dfa061ce74c76bb3553ac8c7 | 177451 | 2592 | 577 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| PIPD_LS_DOC-02_2026-10-07_r2_HIGH_RETENTION_AUDIT_PATCHED_FULL_REPAIR_FULL_SUBSTANTIVE_BODY (1).md | a021998dd3b63015e89af1dd40e0b413744a69b872da46c6bf5f4d92f7f23d0b | 1306240 | 18413 | 5105 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| PIPD_LS_DOC-03_2026-10-07_r2_AUDIT_REPAIR_FULL_SUBSTANTIVE_BODY.md | d89d82dcd2c8603ec6b86c5ec8c40845e4594bc181adf5272bd48a3de7c88f0f | 454167 | 1911 | 1269 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| PIPD_LS_DOC-04_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md | fa64d84da3d747b183e4affff62f4d2fb86c80bb5075f5dd933c09b20caeddcf | 181988 | 4052 | 789 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| PIPD_LS_DOC-05_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md | 7b40584540c162cda6debfd09a4c04321416706acdb03a7a3c2b41383dc585f4 | 227894 | 3946 | 491 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| PIPD_LS_DOC-06_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md | 20e44ea4dd8e53c9b0a076ce861136bbea86f52687019307f6e995cd9079d303 | 405028 | 3790 | 1333 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| PIPD_LS_DOC-07_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md | a68dae1c3670d07bcfa3476a1e37463c534594df5cd65d8dab0dca064b5a9fc1 | 689563 | 12915 | 3009 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| PIPD_LS_DOC-08_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md | e46caa7e440392a6cfa7a86421aead5bce8a2a229fec97b133429db6b6748e42 | 197972 | 2501 | 787 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| PIPD_LS_DOC-09_2026-10-07_r2_HIGH_RETENTION_AUDIT_PATCHED_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md | eaf0aefe2b4711c140fc3274223d88fdc38ad4ec2b7184f756a0f2471f3b0b54 | 144948 | 2451 | 586 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| PIPD_LS_canonical_standard.md | 6f6aafece90b34e33786647e14fee840f5424893995b3164cbb52953a5c4f14a | 209157 | 7176 | 479 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| PROMPT／實作／驗收_紀錄_vol-01.md | 33403c295f3c07ee2591712af3b2a1affe5c9e27765c383240c50c5edb3bd8a9 | 882879 | 19519 | 2378 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| PROMPT／實作／驗收_紀錄_vol-02.md | 1763fce6177cdeaccdf7e28499cc08ae50bda8cfada0f240ade63d017079453c | 963217 | 32141 | 2367 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| PROMPT／實作／驗收_紀錄_vol-03.md | eeaf27f461150926cbe90ffab7a296f7061230d98b52cd643a1d2b83f97df937 | 891612 | 18733 | 2505 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| PROMPT／實作／驗收_紀錄_vol-04.md | f72548baf5b66d1c68638a7115fc7110da84efc71364f90e7c489fc1094135e7 | 900051 | 9271 | 3659 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| PROMPT／實作／驗收_紀錄_vol-05.md | cbb8c0ca820f11540b354d6af22436eca69022933e37169782b4886a12e07950 | 970819 | 4127 | 4153 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| PROMPT／實作／驗收_紀錄_vol-06.md | 487335abcdd53cdeb17fa4a24a9312d59b9e899e8065c02292f60b73fbbcc26d | 975283 | 3532 | 3896 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| PROMPT／實作／驗收_紀錄_vol-07.md | 578b886db3c9e3c507f00e810144d4c562d8a84528d2fc79a6e1b4d0edd3519b | 973034 | 3726 | 2961 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| PROMPT／實作／驗收_紀錄_vol-08.md | 368f060632847c1e6b3e65e3140c6ab05d8445b2667e0592ab4381949d93c453 | 1017515 | 3906 | 3942 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| PROMPT／實作／驗收_紀錄_vol-09.md | 9474245165e89596e941ffdd20251fd2d5e20d5dd881e2bfe759d68b02306e6d | 1006349 | 4242 | 3778 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| PROMPT／實作／驗收_紀錄_vol-10.md | 6466f2416d140911de1dc9122b4f3f86eb8dfa63d484154106304e0740a00256 | 932235 | 5958 | 3398 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SBL_PIPD-LS-PKG_DOC-00(1).md | 5f82ab6f1a668d088752891caf36f081328aee6d2ce7422fe8d5a60826e23003 | 1110205 | 3774 | 8350 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SBL_PIPD-LS-PKG_DOC-00_2026-10-20_rNEXT_FULL_SUBSTANTIVE_FINAL_DESIGN.md | bea453786f4110866dbc587fa0e009ef4df633b11be02e283272cbd52fcd4a8d | 1325406 | 4746 | 10213 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SBL_PIPD-LS-PKG_DOC-00_GPT-6_%E6%9C%80%E7%B5%82%E5%8D%87%E7%B4%9A%E6%8C%87%E4%BB%A4_2026-10-20.md | d26d4a1edfc4e2d6b3c4d05f958d09fc593133e5fdeee44c27f508c47fb3d5f0 | 33714 | 229 | 217 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SBL_PIPD-LS-PKG_DOC-00_藍圖+skeleton(4).md | 739ebd2ff520b8be190738e84501efad55e796504285c7376757bd67bb01d7dd | 718872 | 3087 | 4944 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SBL_PIPD-LS-PKG_DOC-01(3).md | 43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f | 1041962 | 4938 | 7070 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SBL_PIPD-LS-PKG_DOC-01_藍圖+skeleton(1).md | 08a5e3a8ef2552167b4533362b2188517b5ed0b40ae3fb1676ebcc176f196b74 | 814911 | 3106 | 6198 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SBL_PIPD-LS-PKG_DOC-02(3).md | 4ff0cda5ab00ba5f577151e5b004d2167d933e912e302c9e3529b237ccb9e035 | 1148207 | 11084 | 7367 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SBL_PIPD-LS-PKG_DOC-02_藍圖+skeleton(1).md | b008439f1b83029f0b5cd4b00a98048b2e356e05132ce52d16fc9c5c5d314068 | 2001457 | 15165 | 10169 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SBL_PIPD-LS-PKG_DOC-03(4).md | ea69e1d3718ed86aecd74a3ebcc933960eacc30b586ab80fcb9f733037e33476 | 1704253 | 4851 | 12925 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SBL_PIPD-LS-PKG_DOC-03_藍圖+skeleton(1).md | c6ab2e9bc45021f7bedf892f52d02bb733a61a76e31943b86304cd79dd94ecf2 | 946523 | 4090 | 8307 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SBL_PIPD-LS-PKG_DOC-04(3).md | ee90cb1c86f6f7350c11c9c962233a89b035ca41ff82c8968f7968608fc6f6e0 | 618110 | 3036 | 6209 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SBL_PIPD-LS-PKG_DOC-04_藍圖+skeleton(1).md | 100d2fd13de042581badab191ba6b05a798c9920359b7d613c48d472cc29ae17 | 270052 | 1800 | 2731 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SBL_PIPD-LS-PKG_DOC-05(3).md | 3b47a0b6224b1984a4047cf53aac5ac50615c93a560fea46e1b43d079a5d9f27 | 2382349 | 7888 | 21281 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SBL_PIPD-LS-PKG_DOC-05_藍圖+skeleton(1).md | f66e29009d6284e00642784d26efb68ae16881185522a29968f8dfb29d15cbc3 | 662077 | 2985 | 4998 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SBL_PIPD-LS-PKG_DOC-06(4).md | 64ea4977dab3093301f82dc7469413cc754998fc53946467842e06d83645102b | 1554880 | 2858 | 11136 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SBL_PIPD-LS-PKG_DOC-06_藍圖+skeleton(1).md | 65f3a181cec967bf323083637e484b696e373be41a797a20f28aa65ad0a50a61 | 948395 | 2129 | 7565 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SBL_PIPD-LS-PKG_DOC-07(3).md | a366d3783c82089c5593ffabb0704d8507632cce45622684f7a0186f2ae310f8 | 1265128 | 3620 | 9074 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SBL_PIPD-LS-PKG_DOC-07_藍圖+skeleton(3).md | b6f00f3e0dd4744c6b18ec0485d10fce2eb37a326f66ab6cd957354b9c015ebf | 457031 | 1604 | 3829 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SBL_PIPD-LS-PKG_DOC-08(2).md | c7029c1ff07abe3135d33d3abf858a5fecedd911b494cd69c16eb1ddb8158288 | 925526 | 11139 | 6462 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SBL_PIPD-LS-PKG_DOC-08_藍圖+skeleton(1).md | 603c3ea9bbef41c4e932fb8921df81289668c589a1fed8147ec9c5fe286f074f | 756188 | 2662 | 5912 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SBL_PIPD-LS-PKG_DOC-09.md | 6450f7c15915ec8b304f4e5fd4093ea707434db8bae9d2bb6e66c30ab6eed2e1 | 904598 | 3978 | 5912 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SBL_PIPD-LS-PKG_DOC-09_藍圖+skeleton(1).md | a5e0b8f9d44bf87430563485e3ca93707f1ebfbb4680114f59dc1870515e9b2a | 507131 | 1981 | 3125 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SBL_PIPD-LS-PKG_DOC-10(2).md | a64aa21c977334dd74d660a86377ee10c4d329aa5fde0dae25ff81a3e69e8d8f | 1397936 | 3888 | 8045 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SBL_PIPD-LS-PKG_DOC-10_藍圖+skeleton(1).md | 2777e2d920a842aba2707d1768d819bdb69af5d90d819c67d7419b46e5e7154b | 246399 | 1636 | 1368 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SBL_PIPD-LS-PKG_DOC-11(2).md | 12f8705d780b76f264457c194a6ff359da8d74b5d6d8c83fa245b74d2a37508e | 1831131 | 5005 | 9533 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SBL_PIPD-LS-PKG_DOC-11_藍圖+skeleton(1).md | 505ee7223201af8f103dccc6210d81dd75110e69140fb7e4836adf450b6c71e7 | 965892 | 2862 | 4641 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SBL_PIPD-LS-PKG_DOC-12.md | d1e470d82ca14319582cb8947aa52007927aa38e726249b1430804cfe8c8ca56 | 982931 | 7940 | 6339 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SBL_PIPD-LS-PKG_DOC-12_藍圖+skeleton(1).md | 99b5e215f0b5cbea39fe323a150743b0a1de101d345ff9f2cb0136061621ac39 | 385853 | 4040 | 2362 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SBL_PIPD-LS-PKG_DOC-13.md | 7cc0c8b17311130c875910b2548b93c28bd4e1c8ee04d300f85fc33d4c09beb1 | 1251068 | 3814 | 9964 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SBL_PIPD-LS-PKG_DOC-13_藍圖+skeleton(3).md | ce7db11e7f4b29b32838f9f737f8d8029f21ac7fbf2968c2e1f86eac96025454 | 521551 | 1763 | 4133 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SBL_PIPD-LS-PKG_主體主軸核心角度_全域融合重構規劃(2).md | 6c0638bdd1c9c7a99e145071652a8a89ce976a567400c0ca404abd90a1d79866 | 174654 | 1241 | 1702 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SBL_PIPD-LS-PKG_專家角色職位與專精領域總表(2).md | ba8dd9f762f40858354c5da133e48f023e87223a7659362dcc7d38db5038d9e1 | 147622 | 1544 | 991 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SBL_PIPD-LS-PKG｜不可降級、不可壓平成小節或附錄的一級章節.md | 8893cf2e7bba92fdff6ad38113c9043e747f1a021a26de9e902e2fa4217b8e2b | 200933 | 1764 | 1590 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SBL_PIPD-LS-PKG｜必須涵蓋的設計規劃、設計原意、用戶需求、預期成果、7 Primary Kinds 與 8 ProductKind(1).md | 94113c3ffacbbe3c5f4fc497cddbecaf78700153b01ee14e27ead603980c45c1 | 535572 | 1833 | 3858 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SBL_PIPD-LS-PKG｜指定整合與工程基座全域規劃(1).md | 7f745d5ec612bd654d0bca89254eb846d462ccd3b1607691469613ec2ef5de51 | 548125 | 1870 | 3766 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SBL_PIPD-LS-PKG｜相關要求／驗收／標準／檢測／交付／SPEC／LEDGER／DELIVER(1).md | 24dff81c67b863060d0dde6bfdbde489e7828503f1b4029d51f250ffbbcfc26c | 574720 | 2080 | 4560 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SBL_總討論-A(1).md | 3a409f079518790bf0c48b6734536f3b86b12473f5673a5d425651d31a7742c4 | 493615 | 9014 | 1957 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SBL_總討論-B(1).md | f933363d908cc4219c7d0194fec3823dae5778da50f79b84a22802b4d4c6d68a | 329105 | 5918 | 1181 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SBL_設計規劃_vol-01.md | 7939aef18e3b11db87534109c00a36f4cbaeb07d5b5431e8f17e6e3597eb3dbd | 942441 | 16880 | 3767 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SBL_設計規劃_vol-02.md | fb580cf54a871530efc6d36a8a820725775744f9b705fef2531677a02fb204fc | 946915 | 8097 | 4305 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SBL_設計規劃_vol-03.md | 1c8bf908c21a6d1517e1b12dba7f4e05f001476840910bbe6a92ab8f1f6f1d1f | 913081 | 10771 | 5568 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SBL_設計規劃_vol-04.md | fcdd9fd9e8325e9c6224d991be18cf55b4850ba35f531599c756b93df1f4d8b2 | 950283 | 33542 | 3641 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SBL_設計規劃_vol-05.md | 8f4fd549beede761c969d39b6b6642b24c6c05e25dce56e88778d74121447673 | 899459 | 16279 | 3074 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SBL_設計規劃_vol-06.md | 898b3992f4fb06df510b5a4dcdb5c803f4ad75898cdb82f544defa6ec69a7a9f | 926276 | 14246 | 3843 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SBL_設計規劃_vol-07.md | 42eb65e38babf48ca6971d182f9fbdac6cd35c685d2fd9eeaf33c5048c5db0b3 | 921374 | 6513 | 3659 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SBL_設計規劃_vol-08.md | ecefdc2c06d92fe210cb68a855655270e2a419a8331860b8af43304b7460816d | 915908 | 10233 | 3225 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SBL_設計規劃_vol-09.md | 6de8ef4b290fae53f81e9482b1d74e920a32600455c2f7ca2b9cc7a1f595ed8c | 923769 | 10981 | 6389 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SBL_設計規劃_vol-10.md | 905a3ac50dd94c04f9ada5b9aa06d38835f03c6a5f23a94ace051c32ad7fc8ac | 931489 | 8490 | 5972 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SBL｜SpecBuild Loop：整合工程總藍圖(1).md | b31269a123550584c7430a37585687a739882d3493e669f065ba50038cb809bf | 364010 | 4145 | 1717 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md | 83ea1bef8d045bf0a100a27599fcb2d51b1e9ed993d6ccc5c7d70708753dd747 | 1004172 | 6303 | 5659 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SBL｜三方協作_升級藍圖 R2(6).md | 96185b35b7bc4e32b36802ea8d99f18b4f59ac9e52a02b9869206e04bfe68418 | 371936 | 5392 | 1389 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SDLC_PRW_HLPE_SKILLS_PLUGIN_R2.md | afa73b3542fde82b1ac2134d41a351240004d6c81304c3ff22e6e76874201926 | 4708011 | 26846 | 17931 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SDLC_PRW_HLPE_vol-01.md | 95b6917cf61de46c3d99b3ae8d4a4680b9dc427c224d2448f1d0cc66a48eefe4 | 767664 | 10255 | 1243 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SDLC_PRW_HLPE_vol-02.md | 9bbf5ae1e750ddd43a1d5647f655d61d4d9cffe63d6742eb4429b7c83e98c926 | 808950 | 10386 | 1208 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SDLC_PRW_HLPE_vol-03.md | 410a2003de2f0e002b3a5b4d18dd0ce2b571197c437c114a0bbbad03724a39b1 | 767828 | 5657 | 2313 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SDLC_PRW_HLPE_vol-04.md | ec7d296dea36472cf617f21a421ad97a3b527321925fc81e3da04409e40574f8 | 695700 | 4551 | 1345 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SDLC_PRW_HLPE_vol-05.md | 79d5dd52dc16e2813b58346439028dce3d5f0835a11057d8b2f8bf6f33971a9d | 745192 | 7191 | 2948 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SDLC_PRW_HLPE_vol-06.md | be46e7f17272c0c0487e97a19f0ff041178b6c2cdfa051c5d6d5d6dbe229be0a | 761850 | 916 | 2834 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SDLC_PRW_HLPE_vol-07.md | 394fa6b8bae571c3f292bbb82d863203370eb9d6c800fd1724c92b92471188f2 | 782721 | 1300 | 2916 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SDLC_PRW_HLPE_vol-08.md | 83a5436c40ad4badf28dd2176140a0e7ae83bb9b7e1fba119872b6d2ce0f263d | 729566 | 7604 | 2935 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SDLC_PRW_HLPE_vol-09.md | eb19bf27887af9b90203a33e90fd5b83b4fb1bbbda133748aa58939bbe1569d8 | 740535 | 6552 | 3611 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SDLC_PRW_HLPE_vol-10.md | 39a5ca11787d584d314b2d753e50edf275bb81b7c0c9530471d588ba23966120 | 726176 | 2745 | 2609 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SDLC_PRW_HLPE_vol-11.md | 0f36c4523ed3abb7c4842c865d9f3995c0d6a521c729332acb5b1662c7b6f951 | 740083 | 848 | 2991 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SDLC_PRW_HLPE_vol-12.md | 88fff58df3f3ce4c46826d25fe5351c8be3ce064a3cc9bec65565810b8d30e51 | 724954 | 828 | 2753 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SDLC_PRW_HLPE_vol-13.md | dc496418832da26c8b1c056f4bc994fc4c87aad0e2954544ea4fbee1fbefd697 | 760176 | 2776 | 3240 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SDLC_PRW_HLPE_vol-14.md | 2554aff14796afadcddfb2d1b51046548df5793414fd7515b2e2606f58e10943 | 740252 | 3210 | 4715 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SDLC_PRW_HLPE_vol-15.md | c0e581e1f4dfc35218fa629bee3b24e590e4f88385ac7d02aef691a8621d099c | 731051 | 4503 | 1517 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SDLC_PRW_HLPE_vol-16.md | c0be59ff0262132bba171baac6b29d24381e010052a659eb8070f4e46ffaf0a1 | 727974 | 15016 | 3006 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SDLC_PRW_HLPE_vol-17.md | b79d98b3d294e37ac0603168153ecb2feea63a3d8760e7ae472d219e6a46064e | 752053 | 22252 | 2730 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SDLC_PRW_HLPE_vol-18.md | c2611049ebde19e7dc4f6f9e3db00c16fb9665e5759adc43afaa0943ed09e5fc | 622913 | 12359 | 1741 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SDLC_PRW_HLPE_vol-19.md | 5c41f6b6904ffeff0094e8be4c1da1a8882441c037ea9809e024b1f812d1ac78 | 714200 | 12629 | 1928 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SDLC_PRW_HLPE_vol-20.md | 3bba84892ff9947c040f8d8e7c60e43187c29806efd22cf25508f92b261dd786 | 717747 | 12218 | 2333 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SRU_OROCHI_實作前開發文檔_vol-01.md | 578df35c1acd4158dd634a44ba643667450b5e31a9575ae4e41d69c02d4ab1ad | 696150 | 8443 | 2304 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SRU_OROCHI_實作前開發文檔_vol-02.md | 8bb917f02c794db86592ad12b5db46f74714957cd217c16a8934b0e5a0eed57a | 700328 | 5921 | 1532 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SRU_OROCHI_實作前開發文檔_vol-03.md | 3a316536e0b8c9c29e9a167087ee1ed9f66721c4768dc866c9e26865adc8041d | 689546 | 7804 | 1922 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SRU_OROCHI_實作前開發文檔_vol-04.md | 80cfd2f21790234ff6d3bd448396050aecd2562677ffd89a7c7b73201ca50709 | 650919 | 6898 | 1624 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SRU_OROCHI_實作前開發文檔_vol-05.md | bdf937ae2f252f07bb72c10962dfbb651c8a49826c4582514e38beb02013de89 | 721224 | 7803 | 2300 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SWOF-F_SWOF-GENIE_All-IW_PD-PKG-00_2026-09-19_r2_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md | dc71306353a69409d0e9909041482fe482575c09e2f1bab05ac51a81ef36c0de | 678938 | 3312 | 3974 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SWOF-F_SWOF-GENIE_All-IW_PD-PKG-01_2026-09-20_r2_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md | 090d689b35fe928bba96845cc5fc5dcdc0f17f274354b025aa2ffa95586bfa68 | 1751280 | 16314 | 7789 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SWOF-F_SWOF-GENIE_All-IW_PD-PKG-02_2026-09-21_r2_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md | fd4c7b3d27ed55760ce6d726ab9764c85ee240423e183f252d6a080e7afe16d4 | 1180569 | 8408 | 5659 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SWOF-F_SWOF-GENIE_All-IW_PD-PKG-03_2026-09-22_r2_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md | c8edfe2c704da26245eca1c1f2bf5d050c344d59e9a996d0606cc02a1b217491 | 668903 | 5815 | 3428 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SWOF-F_SWOF-GENIE_All-IW_PD-PKG-04_2026-09-25_r2_HIGH_RETENTION_FULL_REPAIR_FULL_INTEGRATED_SUBSTANTIVE_BODY (1).md | 8211e450c1c68d26012dd9c4644cd7b2d9639ca5eb5c2e50078db143b8648c6b | 1723907 | 11190 | 12719 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SWOF-F_SWOF-GENIE_All-IW_PD-PKG-05_2026-09-23_r3_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md | 45a29510ba36318e581fc43db2c58b6b3e6f2bec0374c6cec754f71b5f521388 | 439056 | 5039 | 2351 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SWOF-F_SWOF-GENIE_All-IW_PD-PKG-06_2026-09-24_r2_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md | 8b05ac7cf0b68b09c01fa5fdc38caa9db6002c2dd33414ec6c89b08007fa7b63 | 1428389 | 11381 | 6658 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SWOF-F_SWOF-GENIE_All-IW_PD-PKG-07_2026-09-22_r2_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md | 4b5ae7e4ec213dce4fbac30ade01486d1fd77679c95cafe7d100de160929cac0 | 650820 | 5063 | 2909 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SWOF-F_SWOF-GENIE_All-IW_PD-PKG-08_2026-09-25_r2_FULL_REPAIR_FULL_INTEGRATED_SUBSTANTIVE_BODY.md | 3d6491e6a56b14e908fe6ff711395e84500231c35d81d0c16bdef5ee7523fbd5 | 577971 | 3003 | 3664 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SWOF-F_SWOF-GENIE_All-IW_PD-PKG-09_2026-09-24_r2_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md | f608bc048b338f71bff9bc3fdb0aed3e066de3a68092a6a41ba1aad32eba997e | 605338 | 3868 | 4023 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SWOF-F_SWOF-GENIE_All-IW_PD-PKG-10_2026-09-25_r2_FULL_REPAIR_FULL_INTEGRATED_SUBSTANTIVE_BODY.md | 76063a6fd497285333d283a3e515fcca33eb9b25729e80bceaf541b4ecbba2b4 | 510896 | 4543 | 3654 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SWOF-F_SWOF-GENIE_All-IW_PD-PKG-11_2026-09-27_r2_FULL_REPAIR_FULL_INTEGRATED_SUBSTANTIVE_BODY.md | 9da8ecc1f163439afa60a71a77ed784385e14496f342377dd35c91bda89038ed | 1323931 | 12447 | 6625 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SWOF-F_SWOF-GENIE_All-IW_PD-PKG-12_2026-09-29_r2_FULL_REPAIR_FULL_INTEGRATED_SUBSTANTIVE_BODY.md | 3e60f49072e269c7be5cd9bcf38aec3b204492a13b531e817567d36e132f8677 | 665484 | 7162 | 3427 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SWOF-F_SWOF-GENIE_All-IW_PD-PKG-13_2026-09-29_r2_HIGH_RETENTION_AUDIT_PATCHED_FULL_SUBSTANTIVE_BODY.md | e2ec36c473dbcb5918a195a1ea2ae74a247f6404c303c87da1506498d32123fb | 822164 | 3669 | 4681 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SWOF-F_SWOF-GENIE_All-IW_PD-PKG-14_2026-09-30_r2_HIGH_RETENTION_AUDIT_PATCHED_FULL_REPAIR_FULL_INTEGRATED_SUBSTANTIVE_BODY.md | be1182b5f5a6f8886b3e1b753c2bdf8e264f91caf2298f87b1f52270d2c41d0f | 819555 | 5916 | 2891 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SWOF-F_SWOF-GENIE_All-IW_PD-PKG-15_2026-09-30_r2_HIGH_RETENTION_AUDIT_PATCHED_FULL_REPAIR_FULL_INTEGRATED_SUBSTANTIVE_BODY.md | 297c9120b9f317ac48df0b0cb2bc65b30c68bbf787334078384532663f792e8d | 2566455 | 14109 | 15984 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SWOF-F_SWOF-GENIE_All-IW_PI-PKG-00_2026-09-08_r2_FULL_REPAIR.md | 4cf1420abe34b39a34dc4181198ff13be81cd0901a138197d31db09f3fbf1a87 | 406510 | 2053 | 1720 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SWOF-F_SWOF-GENIE_All-IW_PI-PKG-01_2026-09-09_r2_FULL_REPAIR.md | 46774c8a1697f93375c8045987ed78e45d45fffd14d3996b486fb04b751a5b02 | 249072 | 1386 | 840 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SWOF-F_SWOF-GENIE_All-IW_PI-PKG-02_2026-09-10_r2_FULL_REPAIR.md | 4ca2beb49fbada5d0b305491267774fb487561f0f4317eda357c3ca21f52f5f9 | 1095535 | 3538 | 5584 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SWOF-F_SWOF-GENIE_All-IW_PI-PKG-03_2026-09-12_r2_FULL_REPAIR.md | a79e1574ab8a51c92208ecc93e674e0d38230a488704a744cd2fa57fea2a6960 | 1115620 | 9577 | 3943 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SWOF-F_SWOF-GENIE_All-IW_PI-PKG-04_2026-09-14_r2_FULL_REPAIR.md | 7164277db25600cbe15d1dca61dbdabb636efe9ae2376348c7415aea9d215979 | 830970 | 11513 | 3065 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SWOF-F_SWOF-GENIE_All-IW_PI-PKG-05_2026-09-14_r2_FULL_REPAIR.md | a9d733c7ae0bc2ce6f535c7f9ebab20c50b8c6f8358bebcc9ecc2857b65367d5 | 1259386 | 13871 | 3873 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SWOF-F_SWOF-GENIE_All-IW_PI-PKG-06_2026-09-11_r2_FULL_REPAIR.md | fdd1f2b4b2144889f88579f2a11cd8442419931ea9852073e1f464f32ba1705f | 2309494 | 22948 | 8866 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SWOF-F_SWOF-GENIE_All-IW_PI-PKG-07_2026-09-12_r2_FULL_REPAIR.md | c23bd2f22f1bbf2f11e9b5257ce6d8ab5d50510333f8f13f234bd7a7f7c03ebb | 854923 | 6257 | 5417 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SWOF-F_SWOF-GENIE_All-IW_PI-PKG-08_2026-09-15_r3_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md | 84010d0253f3285984d5d614f7d05a3921ef4bb5c1a46c07582018fa908dc7aa | 481943 | 4755 | 1218 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SWOF-F_SWOF-GENIE_All-IW_PI-PKG-09_2026-09-15_r3_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md | abb037953e03f8dbf0377b7bdf4c1fc05a58348ba1a53361ba7b0ef89a4adbe8 | 610893 | 4075 | 4142 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SWOF-F_SWOF-GENIE_All-IW_PI-PKG-10_2026-09-15_r3_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md | 324e17b30309c6df2d78c7c6f533dc22c3a00849f58c4b9afa3337bad399243b | 311534 | 3253 | 1215 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SWOF-F_SWOF-GENIE_All-IW_PI-PKG-11_2026-09-16_r2_FULL_REPAIR_FULL_SUBSTANTIVE_BODY(1).md | 9b45fc0e5169dc0805c94157fc86007f76d6716522c4942211da6cfee5959751 | 1071302 | 11932 | 3336 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SWOF-F_SWOF-GENIE_All-IW_PI-PKG-12_2026-09-16_r2_FULL_REPAIR_FULL_INTEGRATED_SUBSTANTIVE_BODY.md | 5b18bdbf486f29d0daa7ca29f7daeb76879b5ff53b99c0f57571db0e8e0d356a | 955542 | 11709 | 2930 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SWOF-F_SWOF-GENIE_All-IW_PI-PKG-13_2026-09-14_r2_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md | b94e2beed991bbcbfa25c767463a8ef9d3701f1f1b3b423596744bf4e1bbdfc4 | 1582178 | 17513 | 7732 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SWOF-F_SWOF-GENIE_All-IW_PI-PKG-14_2026-09-14_r2_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md | 8aa4ce0cc7758f2c6db222dfa153a8bb7c6afb8d7edb7227bca6b8ad7ff7671a | 1836648 | 14985 | 9140 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SWOF-F_SWOF-GENIE_All-IW_PI-PKG-15_2026-09-17_r2_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md | 26572e5bafd77a7784b03a6ebf1bdf8e2fdd5ec29e112b04563cfec127d12f91 | 181269 | 854 | 687 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SWOF-F_SWOF-GENIE_All-IW_PI-PKG-16_2026-09-17_r2_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md | 86d93c7ed4036722cffca48fdf198bf22e84ac9dbb56ebc8bc5e8fa4f8efe368 | 282315 | 2074 | 1690 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SWOF-F_SWOF-GENIE_All-IW_PI-PKG-17_2026-09-18_r2_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md | da9b7ec34a5d7803cccf065f7addecfe090eee19d1a4599027b874ad4617a06b | 837645 | 7256 | 4123 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SWOF_ECP_SKILLS_PLUGIN_v2.0.1.md | eddc399cfe9d4490aaf234bbfc4fa9debe57dfdccc7a01e4d13dd5f9198d4d3f | 719549 | 15792 | 2321 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SWOF_HGK_ACA_RBWI.md | b9a26f959233bc63c21bb4ad764ded3efc6ba6b02c2d29c40c92e33b0bb5670d | 3812419 | 7469 | 33705 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SWOF_IMPLEMENTATION_FLYWHEEL_V1_正式介面規格包.md | 20409164b8fa9fc721389a301578d0ab37e1e272a006e53309914416507bf833 | 436493 | 11176 | 1357 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SWOF_PRE-W3_Integration_Readiness_Checkpoint_executor_wave_transition_v3.md | 229f46fa561a0657d1385a50d306f39f515694119305acfd0e32f216c73fba39 | 101247 | 1778 | 339 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SWOF_SQS-THC PIPD-LS-PKG 總藍圖 r2.md | f0eb41ae4593be8cf7b124727090f5e5b22a7a7c3fe7f157f719a5bd87c7fbe4 | 1579164 | 7182 | 5779 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SWOF_SQS-THC_PIPD-LS-PKG_全DOC藍圖.md | 3ddb214e9bc11525b2aaa47b6c18e3012316ef31561073fba08683ad7662b0a4 | 756608 | 6273 | 4475 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SWOF_SQS-THC_PIPD-LS-PKG_整合校正10問_回答.md | 8032d76d6ce36e9917ad4fc86512477516c323ccf60e77f93eeff868b6c23248 | 647953 | 4636 | 2685 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SWOF_TQAEP_SKILLS_PLUGIN_v2.0.1.md | 728b6c6758ff6cb3345ba0dc9e9e8def6c589fd23a164eaabb89bfd1bc12049a | 481954 | 5497 | 1741 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SWOF_指揮_實作_驗收_升級總藍圖.md | 283eac5b5d0bbd8206e1f1b03dad1e3bff87f53f274b8273dbfad43e368a0135 | 118598 | 2648 | 485 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| SWOF_指揮／實作／驗收_升級總討論.md | 32bc3d46023309c62648489d5445996fda1abd7402a116ba4c4f64f58748cb00 | 389467 | 15635 | 1204 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| challenge-review-SKILL.md | 9ecd2366dc2353fc8aaf533161ae1e34abba37a80f345f5f78023325f8d26194 | 7332 | 99 | 31 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| construction-acceptance-prompt-compiler_SKILL.md | 214c7f048f7361fe0bc4a324a0c99aaaf0df4191a430b645b8a97d24620064b6 | 7534 | 97 | 30 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |
| 舊合冊_到_Shared_Core_Commander_Acceptance_三分拆解_Matrix.md | 0742dde1c062314e9b4ae5e3e0cb150cb27876a336ef72fc567d3973f226588a | 266725 | 974 | 903 | UTF8_HASH_READ;CLAUSE_UNVERIFIED |

| Keyword | Full-text occurrences |
|---|---:|
| PIPD | 76490 |
| OpenSpec | 7401 |
| Spec Kit | 3797 |
| gstack | 6185 |
| Superpowers | 5215 |
| mattpocock | 2177 |
| AGENTS.md | 4341 |
| Tool | 62553 |
| Host | 43210 |
| ModeGate | 2158 |
| SPEC | 156933 |
| LEDGER | 23944 |
| DELIVER | 13626 |
| SourceFreeze | 2230 |
| SWOF | 116870 |
| SBL | 69680 |
| Requirement | 48534 |
| Acceptance | 47597 |
| Role | 55603 |
| Oracle | 63793 |

## R01.r3.1｜四份高優先新增來源與物理路徑
本次已使用 R01.r3.2 的現時 1:1 完整實體檔案分母；以下四件為本任務的新增高優先來源，版本身份獨立計數，後續以同 hash 消歧，不得與 `SWOF` 近似檔名混合。現行 `physical_locator` 使用本機真 basename，`display_alias` 只供文字展示，百分比編碼路徑須先解碼再核對 basename 和 SHA，不可將 URL encoded string 直接當檔案路徑。
| Physical basename | SHA-256 | bytes | 用途／Claim |
|---|---|---|---|
| AUDIT_SBL_PIPD-LS-PKG_DOC-00_2026-10-20_FULL_SUBSTANTIVE_DESTRUCTIVE_REVIEW(1).md | c4f2420c2607232f1b422064cabf197b49f365518f05d21d35c362d4aac00eae | 230451 | READABLE_USER_INPUT;NOT_FORMAL_SOURCEFREEZE |
| SWOF_SQS-THC_PIPD-LS-PKG_整合校正10問_回答.md | 8032d76d6ce36e9917ad4fc86512477516c323ccf60e77f93eeff868b6c23248 | 647953 | READABLE_USER_INPUT;NOT_FORMAL_SOURCEFREEZE |
| SWOF_SQS-THC PIPD-LS-PKG 總藍圖 r2.md | f0eb41ae4593be8cf7b124727090f5e5b22a7a7c3fe7f157f719a5bd87c7fbe4 | 1579164 | READABLE_USER_INPUT;NOT_FORMAL_SOURCEFREEZE |
| SWOF_SQS-THC_PIPD-LS-PKG_全DOC藍圖.md | 3ddb214e9bc11525b2aaa47b6c18e3012316ef31561073fba08683ad7662b0a4 | 756608 | READABLE_USER_INPUT;NOT_FORMAL_SOURCEFREEZE |

**SRC-0079 修補規則**：對舊 Inventory 的 URL percent-encoded 或其他 Unicode display alias，建立 `path_alias_resolved_by_sha`，以真正 `Path.name` 實體名為唯一開啟路徑；在生成引用時同時要求 `exists=true` 且 `sha256(expected)==sha256(actual)`。若路徑不存在但 sha 相同只能 `ALIAS_MATCH_HOLD`，先補正物理目錄再允許交接。POS：原始 Unicode 名稱存在並符合 SHA；NEG：只有 percent-encoded 名，開啟失敗→`FILE_LOCATOR_NOT_FOUND`。


# C16｜動態專家職能、角色歷史差異與真正 SoD

## C16.r3.base.1｜本輪最小職能集合及歷史角色分母隔離
角色 Pool 係控制總表中的 **58 個邏輯職能／七專業域**；本輪選擇符合具體 DOC-00 覆蓋需要的最小 sufficient set。`RoleBinding` 的切換是 GPT-6 的檢視維度，並非 25 個真人／不同模型，也不形成獨立 SoD。不得自稱「專業 AI/LLM PROMPT 工程師」是 DOC-00 主責。

| role_id | 領域/職位(來源原名) | 本次具體責任 | 輸入來源→輸出 | 對應 DOC-00 H1 | 不得執行 |
| G01 | G/產品使命與價值架構師 / Product Strategy Lead | 產品/FUO與非目標 | SBL master→ProductTruth | R00,R02 | 非真 Principal/非 Human Token/非 Native Permit/非獨立 Checker |
| G04 | G/系統總架構師 / Chief Systems Architect | One Core + 3SP 主權邊界 | SBL master→ArchitectureReader | C02,C48 | 非真 Principal/非 Human Token/非 Native Permit/非獨立 Checker |
| G05 | G/權威來源與凍結治理師 / Source Authority Architect | 來源同域裁決、Manifest 缺口 | PIPD DOC01/00→ConflictLedger | C02,R01 | 非真 Principal/非 Human Token/非 Native Permit/非獨立 Checker |
| G07 | G/技術選型／OSS 引入治理師 / Technology Admission Lead | Tech Admission 與版本證據 | GitHub tags→TDR | R04,R08 | 非真 Principal/非 Human Token/非 Native Permit/非獨立 Checker |
| G08 | G/標準及規範符合性總監 / Normative Compliance Lead | PIPD 章節與 Writer 法位 | PIPD DOC00-09→OwnerMap | C48,R03 | 非真 Principal/非 Human Token/非 Native Permit/非獨立 Checker |
| P01 | P/PIPD 需求原子化編譯師 / Intent & Requirement Atomizer | Requirement Atom 拆分 | 控制文件→ReqDisposition | C52 | 非真 Principal/非 Human Token/非 Native Permit/非獨立 Checker |
| P02 | P/Profile / 風險裁剪工程師 / Profile Tailor | Safety Veto/Profile 風險 | PIPD DOC06→ProfileReadset | R03 | 非真 Principal/非 Human Token/非 Native Permit/非獨立 Checker |
| P03 | P/PI-PKG 規格編譯師 / Pre-Implementation Compiler Engineer | PI 規範只讀入口 | PIPD DOC02→PI Handoff | R03 | 非真 Principal/非 Human Token/非 Native Permit/非獨立 Checker |
| P04 | P/RepoContext 與晚綁定工程師 / Pre-Dev Binder | RepoContext 真實綁定缺件 | PIPD DOC03→NoBindHold | R06 | 非真 Principal/非 Human Token/非 Native Permit/非獨立 Checker |
| P06 | P/ECP 與權限效果協定工程師 / ECP Engineer | ONE ECP/Token 合規 | PIPD DOC05→EffectExpectation | R05,R07 | 非真 Principal/非 Human Token/非 Native Permit/非獨立 Checker |
| P07 | P/Trace 與 TQAEP 工程師 / Assurance Contract Designer | 逐原子 TQAEP 證據 | PIPD DOC04/07→FixtureSpec | R09 | 非真 Principal/非 Human Token/非 Native Permit/非獨立 Checker |
| P08 | P/PIPD Package Closure Engineer | Bundle Trace/ClaimCeiling | PIPD DOC09→ClosureSummary | C54,R10 | 非真 Principal/非 Human Token/非 Native Permit/非獨立 Checker |
| P09 | P/PIPD ABI／版本相容性協調師 / Canonical ABI Steward | Oracle 衝突/ABI | P4↔DOC07→CR record | C02,R07 | 非真 Principal/非 Human Token/非 Native Permit/非獨立 Checker |
| A02 | A/Fabric / HG-KSEOS 原生控制面架構師 | Native HGK 唯一效果主權 | HGK Groups→NativeBoundary | C02,R07 | 非真 Principal/非 Human Token/非 Native Permit/非獨立 Checker |
| A06 | A/AGENTS.md / Agent Skills 封裝工程師 | AGENTS.md/Skills/Host 交接 | AGENT SPEC→HostRule | R06 | 非真 Principal/非 Human Token/非 Native Permit/非獨立 Checker |
| A10 | A/Prompt Compiler / 指揮官工程師 | Commander-SP 非作用指揮 | SBL master→C0–C9 route | C48 | 非真 Principal/非 Human Token/非 Native Permit/非獨立 Checker |
| A12 | A/SWOF SQS-THC 接口整合架構師 | SWOF Receiver/Primary Kind | SWOF PI/PD→TypedAdapter | R02 | 非真 Principal/非 Human Token/非 Native Permit/非獨立 Checker |
| V01 | V/獨立挑戰審查員 / External Independent Reviewer | Counterevidence/SoD | Challenge skill→NegativeCriteria | R09 | 非真 Principal/非 Human Token/非 Native Permit/非獨立 Checker |
| V02 | V/內部 Oracle / Test Design 工程師 | Oracle/Fixture 獨立性規範 | PIPD DOC07→CheckerCriteria | R09 | 非真 Principal/非 Human Token/非 Native Permit/非獨立 Checker |
| V04 | V/資安／隱私／權利威脅模型師 | Token/finance shadow Veto | HGK/SWOF→Fail-Closed | R07 | 非真 Principal/非 Human Token/非 Native Permit/非獨立 Checker |
| V05 | V/供應鏈／授權／SBOM 工程師 | 供應鏈/License/SBOM | OSS releases→LicenseHold | R08 | 非真 Principal/非 Human Token/非 Native Permit/非獨立 Checker |
| K04 | K/文件生命週期／AIKD 工程師 | 來源精確追溯與不遺失 | all sources→TraceLedger | R01,C52 | 非真 Principal/非 Human Token/非 Native Permit/非獨立 Checker |
| R06 | R/使用者驗收／人因產品研究員 | FUO/Consumer 真使用體驗 | Journeys→ConsumerProbe | R02,R06 | 非真 Principal/非 Human Token/非 Native Permit/非獨立 Checker |
| R07 | R/跨系統交付配置與技術 PMO | 交付/回滾/版本 | DOC12→InstallReadback | R10 | 非真 Principal/非 Human Token/非 Native Permit/非獨立 Checker |
| D01 | D/OpenSpec 工程整合專家 | 方法輪子重疊/退出 | OpenSpec/SpecKit→TDR | R04,R08 | 非真 Principal/非 Human Token/非 Native Permit/非獨立 Checker |


## C16.r3.base.2｜HISTORICAL_vs_CURRENT_ROLE_CROSSWALK
| 來源分母 | 來源法位 | 是否可與 58/7 相加 | 裁決／FirstFail |
|---|---|---|---|
| 舊 DOC-00 r2 的「72 專家」 | 舊規劃/架構槽位 | 否 | 沒有一一對應原件，不重命名為 58；`CR_ROLE_72_58_OPEN` |
| 舊 DOC-00 r2 的「12 Domain Teams」 | 組織與團隊設計維度 | 否 | 需要舊版每 Team Owner/職能映射；`TEAM_CROSSWALK_HOLD` |
| 現行專家總表 58 個角色、七域 | 本輪任務可選的邏輯職能 | 不是同一分母 | 以本輪表內代碼精確掛載；高風險 Veto 由真正 Domain Owner 執行 |
| Maker/External Checker/Human | 權限主體三種，非職能計數 | 否 | Maker=self 無獨立合格身份與 raw receipt → `SOD_VIOLATION` |

## C16.r3.1｜58 職能是職務目錄，不是 58 個實際 Agent
`RoleBinding{role_id,task,source_domain,can_write,principal_id,scope,owner,expiry}`；本任務五個設計職務為 G01 產品、G04 架構、G05 Source Authority、G08 規範、K04 Trace。候選 Writer 為文件作者；Reviewer 建議職能不得被假裝為獨立 Principal，未有身份/執行收據標 `UNBOUND`。若輸入帶歷史 72 角色／12 團隊→`ROLE_CATALOG_ERA_MISMATCH` 並轉 Source Steward；不把 72 自動映射為現行 58。建議子代理只可在明確 readset 上產 proposal，唯一 Owner ratifies，禁止角色切換自簽。


# C48｜SBL DOC-00～13 與 PIPD 官方 DOC-00～09 的責任分冊／一級章節落位

## C48.r3.base.1｜SBL 14 冊真正 Reader Route（最新實體正文）
下游 DOC-01～13 各冊不是 DOC-00 的附錄；保留原作者版本字節身份及真實文檔 Owner，DOC-00 僅傳 `ReaderRoute{required_docs,reason,exact_hash,authority_owner,required_receipts,stop_condition}`。若源自 Skeleton 不等於實質正文，必明示。

| SBL DOC | 實體設計讀取版 | 版本/sha256 | 主責與必交接 | DOC-00 reader rule/FirstFail |
| DOC-00 | SELF: SBL_PIPD-LS-PKG_DOC-00_2026-10-20_rNEXT_FULL_SUBSTANTIVE_FINAL_DESIGN.md | 2026-10-20_rNEXT / SHA computed only after final file save; predecessor r2 SHA=5f82ab6f1a668d088752891caf36f081328aee6d2ce7422fe8d5a60826e23003 | Navigation / Reader Router / Constitutional Handoff | THIS FILE is sole current author-side DOC00 design reader; its own SHA is external deliver readback, not an implicit source digest. |
| DOC-01 | SBL_PIPD-LS-PKG_DOC-01(3).md | 2026-10-19_r3 / 43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f | Product Requirements, Kinds & Human Journeys | Read latest body; do not infer native qualification; missing bytes→SOURCE_MISSING |
| DOC-02 | SBL_PIPD-LS-PKG_DOC-02(3).md | 2026-10-19_r2 / 4ff0cda5ab00ba5f577151e5b004d2167d933e912e302c9e3529b237ccb9e035 | Architecture / Schema / Domain Contracts | Read latest body; do not infer native qualification; missing bytes→SOURCE_MISSING |
| DOC-03 | SBL_PIPD-LS-PKG_DOC-03(4).md | 2026-10-19_r2 / ea69e1d3718ed86aecd74a3ebcc933960eacc30b586ab80fcb9f733037e33476 | Product / Workflow / Coding Stage Contract | Read latest body; do not infer native qualification; missing bytes→SOURCE_MISSING |
| DOC-04 | SBL_PIPD-LS-PKG_DOC-04(3).md | 2026-10-19_r4 / ee90cb1c86f6f7350c11c9c962233a89b035ca41ff82c8968f7968608fc6f6e0 | One Core / Three SP / Six Modules / Orchestration | Read latest body; do not infer native qualification; missing bytes→SOURCE_MISSING |
| DOC-05 | SBL_PIPD-LS-PKG_DOC-05(3).md | 2026-10-19_r4 / 3b47a0b6224b1984a4047cf53aac5ac50615c93a560fea46e1b43d079a5d9f27 | RepoContext / PD Late Binding / Construction / ECP | Read latest body; do not infer native qualification; missing bytes→SOURCE_MISSING |
| DOC-06 | SBL_PIPD-LS-PKG_DOC-06(4).md | 2026-10-19_r3 / 64ea4977dab3093301f82dc7469413cc754998fc53946467842e06d83645102b | Technical Admission / Six Donors / HotSwap | Read latest body; do not infer native qualification; missing bytes→SOURCE_MISSING |
| DOC-07 | SBL_PIPD-LS-PKG_DOC-07(3).md | 2026-10-19_r4 / a366d3783c82089c5593ffabb0704d8507632cce45622684f7a0186f2ae310f8 | Security / Human Approval / Token / Trust Boundaries | Read latest body; do not infer native qualification; missing bytes→SOURCE_MISSING |
| DOC-08 | SBL_PIPD-LS-PKG_DOC-08(2).md | 2026-10-19_r4 / c7029c1ff07abe3135d33d3abf858a5fecedd911b494cd69c16eb1ddb8158288 | Acceptance / Oracle / TQAEP / Independent Challenge | Read latest body; do not infer native qualification; missing bytes→SOURCE_MISSING |
| DOC-09 | SBL_PIPD-LS-PKG_DOC-09.md | 2026-10-19_r4 / 6450f7c15915ec8b304f4e5fd4093ea707434db8bae9d2bb6e66c30ab6eed2e1 | Evidence Trace / Ledger / Deliver | Read latest body; do not infer native qualification; missing bytes→SOURCE_MISSING |
| DOC-10 | SBL_PIPD-LS-PKG_DOC-10(2).md | 2026-10-19_r4 / a64aa21c977334dd74d660a86377ee10c4d329aa5fde0dae25ff81a3e69e8d8f | GENIEMAKER / Host / Skills / Knowledge | Read latest body; do not infer native qualification; missing bytes→SOURCE_MISSING |
| DOC-11 | SBL_PIPD-LS-PKG_DOC-11(2).md | 2026-10-19_r2 / 12f8705d780b76f264457c194a6ff359da8d74b5d6d8c83fa245b74d2a37508e | Native Bridge / Waves / ModeGate | Read latest body; do not infer native qualification; missing bytes→SOURCE_MISSING |
| DOC-12 | SBL_PIPD-LS-PKG_DOC-12.md | 2026-10-20_r2 / d1e470d82ca14319582cb8947aa52007927aa38e726249b1430804cfe8c8ca56 | CI / RUNBOOK / Delivery / Host Readback | Read latest body; do not infer native qualification; missing bytes→SOURCE_MISSING |
| DOC-13 | SBL_PIPD-LS-PKG_DOC-13.md | 2026-10-20_r2 / 7cc0c8b17311130c875910b2548b93c28bd4e1c8ee04d300f85fc33d4c09beb1 | Dogfood / Evolution / Provider Exit | Read latest body; do not infer native qualification; missing bytes→SOURCE_MISSING |

## C48.r3.base.2｜PIPD 官方十冊 Reader Route：相同 DOC ID 不代表同一 Owner
| PIPD 官方 DOC | 正式責任與不可重造行為 | SHA-256 | 讀者輸出 | NACK |
| PIPD_LS_DOC-00 | Navigation / Operator Entry | be3a672ec20aa0e6b5e0e35097fc08de749bfe7f59f827d18e38aef67dd68ea4 | 確認 reader/next Owner，不生成正式物件 | 路由至唯一 Writer |
| PIPD_LS_DOC-01 | Normative Constitution / State / Authority | b753f2e5cdd5598a818f8a113d57b7f815aeb3f1dfa061ce74c76bb3553ac8c7 | 讀狀態/身份/Claim 門檻，禁止越權 | 同域權威衝突 HOLD |
| PIPD_LS_DOC-02 | Pre-Implementation Contract Compiler | a021998dd3b63015e89af1dd40e0b413744a69b872da46c6bf5f4d92f7f23d0b | 每 atom 需來源/Owner/cue/guard；PI 編譯 | 零 atom 拒編 |
| PIPD_LS_DOC-03 | Environment Binding / Execution Preparation | d89d82dcd2c8603ec6b86c5ec8c40845e4594bc181adf5272bd48a3de7c88f0f | 真 RepoContext HEAD/currentness/affected scope | 空/ **/ stale 拒晚綁 |
| PIPD_LS_DOC-04 | Traceability / Assurance Data Contract | fa64d84da3d747b183e4affff62f4d2fb86c80bb5075f5dd933c09b20caeddcf | 每 atom Trace、EvidenceExpectation、fresh hash | 斷鏈、異版 Evidence 拒收 |
| PIPD_LS_DOC-05 | Receiver / Permission / Admission | 7b40584540c162cda6debfd09a4c04321416706acdb03a7a3c2b41383dc585f4 | 真 token、scope、ONE ECP、at-most-once | 無 token 或不明效果拒收 |
| PIPD_LS_DOC-06 | Profile / Applicability / Complexity Governance | 20e44ea4dd8e53c9b0a076ce861136bbea86f52687019307f6e995cd9079d303 | 九 routing 軸、Safety Veto 不可降風險 | Profile 無憑據拒用 |
| PIPD_LS_DOC-07 | Verification / Oracle / Fixture Reference | a68dae1c3670d07bcfa3476a1e37463c534594df5cd65d8dab0dca064b5a9fc1 | 每 atom oracle、POS/NEG、不同 Principal | maker 自驗非 Independent |
| PIPD_LS_DOC-08 | AI Consumption / Adapter Maturity | e46caa7e440392a6cfa7a86421aead5bce8a2a229fec97b133429db6b6748e42 | Host/Schema maturity、No False Ready | host presence 不等於 loaded |
| PIPD_LS_DOC-09 | CI / Release / Supply Chain / Runbook | eaf0aefe2b4711c140fc3274223d88fdc38ad4ec2b7184f756a0f2471f3b0b54 | SBOM/provenance/release owner/rollback | 無 receipt 不得發行 |

## C48.r3.1｜45 個一級章節的來源實體與 Owning DOC 的實質 H1 檢索
下表完整 45 行，**不是**主張 DOC-00 具有 45 個 H1。Locator 以各 Owning DOC 實際 `#` 行建立，採詞彙近似匹配時標 `MAPPED_CANDIDATE`，不能自動視為章節 Owner ratified；當無匹配時明示 `UNMAPPED`。源控制索引和 OwningDoc H1 是兩種定位，不以 index table 充當正文。各 H1 的具體接收條件為主題獨有物件（例如第 24 DELIVER 實裝，第 33 Native token）；`Owner=DOCxx` 只是文件路由，不等於人類核准。
| H1 | 保護語義/專用對象 | Owning DOC | 物理檔 | SHA前16 | 實質H1起行候選 | 實質 H1 文字 | 法位 |
|---|---|---|---|---|---|---|---|
| 00 | 任務憲章、上位藍圖、目的／非目標與讀序 | SBL-DOC-00 | SBL_PIPD-LS-PKG_DOC-00(1).md | 5f82ab6f1a668d08 | 35 | C02｜上位藍圖、設計規劃與文件來源的憲制／裁決優先序 | MAPPED_CANDIDATE_NOT_OWNER_RATIFIED |
| 01 | 產品身份、價值定位、工程血緣與問題範圍 | SBL-DOC-01 | SBL_PIPD-LS-PKG_DOC-01(3).md | 43a0a7ed26d2adf9 | UNMAPPED_SUBSTANTIVE_H1 | OWNER_CONFIRM_REQUIRED | HOLD_EXACT_H1 |
| 02 | 七大使用者痛點與可觀測 First Useful Outcome | SBL-DOC-01 | SBL_PIPD-LS-PKG_DOC-01(3).md | 43a0a7ed26d2adf9 | 1851 | R08｜Reuse-first、六 Donor、NOBJ-001～024 保護槽位與熱插拔 | MAPPED_CANDIDATE_NOT_OWNER_RATIFIED |
| 03 | TPM 用戶意圖、訪談 T0–T5、決策與非目標 | SBL-DOC-01 | SBL_PIPD-LS-PKG_DOC-01(3).md | 43a0a7ed26d2adf9 | UNMAPPED_SUBSTANTIVE_H1 | OWNER_CONFIRM_REQUIRED | HOLD_EXACT_H1 |
| 04 | SWOF 七 Primary Kinds 與 231 Entity/59 Relation/72 MC 主權 | SBL-DOC-01 | SBL_PIPD-LS-PKG_DOC-01(3).md | 43a0a7ed26d2adf9 | UNMAPPED_SUBSTANTIVE_H1 | OWNER_CONFIRM_REQUIRED | HOLD_EXACT_H1 |
| 05 | 八 ProductKind 的獨立產品契約與 v0.1 非目標 | SBL-DOC-01 | SBL_PIPD-LS-PKG_DOC-01(3).md | 43a0a7ed26d2adf9 | UNMAPPED_SUBSTANTIVE_H1 | OWNER_CONFIRM_REQUIRED | HOLD_EXACT_H1 |
| 06 | 十六個 User Moments M00–M15 的獨立行為契約 | SBL-DOC-01 | SBL_PIPD-LS-PKG_DOC-01(3).md | 43a0a7ed26d2adf9 | 1174 | C09｜M00～M15 十六個 User Moments 及跨時刻工作流 | MAPPED_CANDIDATE_NOT_OWNER_RATIFIED |
| 07 | 三 Golden Journeys、真實使用者演練與 MVP 範圍 | SBL-DOC-01 | SBL_PIPD-LS-PKG_DOC-01(3).md | 43a0a7ed26d2adf9 | 1838 | R07｜三條 Golden Journey 的實測設計與退出 | MAPPED_CANDIDATE_NOT_OWNER_RATIFIED |
| 08 | One SBL Core／Three SP／Native HGK 架構主權 | SBL-DOC-04 | SBL_PIPD-LS-PKG_DOC-04(3).md | ee90cb1c86f6f735 | 275 | C12｜One Core／Three SP／Six Logical Modules 與最小可用總體架構 | MAPPED_CANDIDATE_NOT_OWNER_RATIFIED |
| 09 | SBL 六個邏輯模組、事件／狀態／資料流 | SBL-DOC-04 | SBL_PIPD-LS-PKG_DOC-04(3).md | ee90cb1c86f6f735 | UNMAPPED_SUBSTANTIVE_H1 | OWNER_CONFIRM_REQUIRED | HOLD_EXACT_H1 |
| 10 | TPM-SP、Commander-SP、Challenge-SP 三產品與三套 Host 身分 | SBL-DOC-04 | SBL_PIPD-LS-PKG_DOC-04(3).md | ee90cb1c86f6f735 | 669 | C15｜External Challenge-SP：Frozen Readset、H4、十步 Intake 與 | MAPPED_CANDIDATE_NOT_OWNER_RATIFIED |
| 11 | TPM-SP：需求導向的角色 Profile、T0–T5 與使用者操作面 | SBL-DOC-01 | SBL_PIPD-LS-PKG_DOC-01(3).md | 43a0a7ed26d2adf9 | UNMAPPED_SUBSTANTIVE_H1 | OWNER_CONFIRM_REQUIRED | HOLD_EXACT_H1 |
| 12 | Commander-SP：C0–C9、COMMAND.md、H0–H4 與 CAPC | SBL-DOC-04 | SBL_PIPD-LS-PKG_DOC-04(3).md | ee90cb1c86f6f735 | 551 | C14｜Commander-SP／CAPC C0～C9／Thin Prompt 與施工分權 | MAPPED_CANDIDATE_NOT_OWNER_RATIFIED |
| 13 | Acceptance Challenge-SP：H4、反證、Decision Brief 與 SoD | SBL-DOC-08 | SBL_PIPD-LS-PKG_DOC-08(2).md | c7029c1ff07abe31 | 10343 | R08-07｜唯一 E00～E10 Closed-loop：PIPD／Commander／HGK／TQAEP／ | MAPPED_CANDIDATE_NOT_OWNER_RATIFIED |
| 14 | PIPD-LS DOC-00～09 的憲章、責任與正式生命週期 | SBL-DOC-00 | SBL_PIPD-LS-PKG_DOC-00(1).md | 5f82ab6f1a668d08 | 1926 | R03｜PIPD 正式製程、十 DOC 和 P4 八 Skill 的只讀入口 | MAPPED_CANDIDATE_NOT_OWNER_RATIFIED |
| 15 | 來源發現、SourceFreeze、AuthorityBinding 與歷史裁決 | SBL-DOC-02 | SBL_PIPD-LS-PKG_DOC-02(3).md | 4ff0cda5ab00ba5f | 3664 | R02-02｜AuthorityBinding 與 Writer | MAPPED_CANDIDATE_NOT_OWNER_RATIFIED |
| 16 | 需求原子、24 Must-Cover 義務群及複合子項追溯 | SBL-DOC-03 | SBL_PIPD-LS-PKG_DOC-03(4).md | ea69e1d3718ed86a | UNMAPPED_SUBSTANTIVE_H1 | OWNER_CONFIRM_REQUIRED | HOLD_EXACT_H1 |
| 17 | Profile/風險雙軸、Safety Veto 與非降級裁剪 | SBL-DOC-03 | SBL_PIPD-LS-PKG_DOC-03(4).md | ea69e1d3718ed86a | UNMAPPED_SUBSTANTIVE_H1 | OWNER_CONFIRM_REQUIRED | HOLD_EXACT_H1 |
| 18 | 正式 PI-PKG 規格編譯、TechnologyAdmission 與 Semantic Trace | SBL-DOC-03 | SBL_PIPD-LS-PKG_DOC-03(4).md | ea69e1d3718ed86a | 2832 | R05｜Source-to-Prose、TypedRef、ABI、Trace/Source→Atom 無損閉環 | MAPPED_CANDIDATE_NOT_OWNER_RATIFIED |
| 19 | 真 RepoContext、PD-PKG 晚綁定與施工受限範圍 | SBL-DOC-05 | SBL_PIPD-LS-PKG_DOC-05(3).md | 3b47a0b6224b1984 | 869 | R02｜PIRef→RepoContext→PDReadProjection 的 Typed ABI 與對端  | MAPPED_CANDIDATE_NOT_OWNER_RATIFIED |
| 20 | ConstructionContract／ONE ECP／WorkOrder／原生准入效果 | SBL-DOC-05 | SBL_PIPD-LS-PKG_DOC-05(3).md | 3b47a0b6224b1984 | 1309 | R05｜DEV／OPS Effect Lanes、ONE ECP 選擇與 Permission SoD | MAPPED_CANDIDATE_NOT_OWNER_RATIFIED |
| 21 | 驗證 Test/Oracle/TQAEP、破壞性案例與獨立 Checker | SBL-DOC-08 | SBL_PIPD-LS-PKG_DOC-08(2).md | c7029c1ff07abe31 | 10343 | R08-07｜唯一 E00～E10 Closed-loop：PIPD／Commander／HGK／TQAEP／ | MAPPED_CANDIDATE_NOT_OWNER_RATIFIED |
| 22 | SPEC：三種視圖與正式可編譯承諾 | SBL-DOC-03 | SBL_PIPD-LS-PKG_DOC-03(4).md | ea69e1d3718ed86a | 4357 | R09｜SPEC／LEDGER／DELIVER：Single-subject TraceClosure、可機讀 | MAPPED_CANDIDATE_NOT_OWNER_RATIFIED |
| 23 | LEDGER：Trace/Evidence/Decision/Effect／時效與 Claims | SBL-DOC-09 | SBL_PIPD-LS-PKG_DOC-09.md | 6450f7c15915ec8b | 962 | C23｜Trace／EvidenceExpectation／Raw Evidence：雙向圖與證據資格 | MAPPED_CANDIDATE_NOT_OWNER_RATIFIED |
| 24 | DELIVER：安裝、Host 使用、回滾、FUO、Consumer ACK | SBL-DOC-12 | SBL_PIPD-LS-PKG_DOC-12.md | d1e470d82ca14319 | 1764 | D12-05｜InstallReadback／First FUO／跨平台有效安裝／反例 | MAPPED_CANDIDATE_NOT_OWNER_RATIFIED |
| 25 | 六大外部方法輪子×24 Core 能力的選擇與實際融入 | SBL-DOC-06 | SBL_PIPD-LS-PKG_DOC-06(4).md | 64ea4977dab30933 | UNMAPPED_SUBSTANTIVE_H1 | OWNER_CONFIRM_REQUIRED | HOLD_EXACT_H1 |
| 26 | 386 技術 Universe、25 方法及 Search-Before-Build 與准入 | SBL-DOC-06 | SBL_PIPD-LS-PKG_DOC-06(4).md | 64ea4977dab30933 | UNMAPPED_SUBSTANTIVE_H1 | OWNER_CONFIRM_REQUIRED | HOLD_EXACT_H1 |
| 27 | Agent Components、AGENTS.md、Skills、Prompt 與 Host 指令優先序 | SBL-DOC-10 | SBL_PIPD-LS-PKG_DOC-10(2).md | a64aa21c977334dd | 830 | D10-07｜Skills、AGENTS.md、Agent Components、MCP 與權限隔離 | MAPPED_CANDIDATE_NOT_OWNER_RATIFIED |
| 28 | Hermes／Codex／Claude Code／DeepSeek 與多平台 Native ABI | SBL-DOC-10 | SBL_PIPD-LS-PKG_DOC-10(2).md | a64aa21c977334dd | 665 | D10-05｜HostCapabilityRegistry：Hermes、Codex、Claude、DeepS | MAPPED_CANDIDATE_NOT_OWNER_RATIFIED |
| 29 | GPTs GENIEMAKER／ChatGPT、Claude Web、私有 ZIP 與 Web MD | SBL-DOC-10 | SBL_PIPD-LS-PKG_DOC-10(2).md | a64aa21c977334dd | 781 | D10-06｜Web 私人三 SP、檔案投影與證據層級 | MAPPED_CANDIDATE_NOT_OWNER_RATIFIED |
| 30 | 動態 58 專家職能、責任 RACI 與真正獨立 Principal | SBL-DOC-00 | SBL_PIPD-LS-PKG_DOC-00(1).md | 5f82ab6f1a668d08 | UNMAPPED_SUBSTANTIVE_H1 | OWNER_CONFIRM_REQUIRED | HOLD_EXACT_H1 |
| 31 | 多 Agent 管線、FAN-OUT/FAN-IN、可靠 Checkpoint 和有界修復 | SBL-DOC-04 | SBL_PIPD-LS-PKG_DOC-04(3).md | ee90cb1c86f6f735 | 784 | C37｜多工 Agent 流水線、T0～T5／C0～C9、DIRECT/KANBAN/SWARM 與 Join | MAPPED_CANDIDATE_NOT_OWNER_RATIFIED |
| 32 | Context／Memory／RAG／Agent 狀態與知識證據主權 | SBL-DOC-10 | SBL_PIPD-LS-PKG_DOC-10(2).md | a64aa21c977334dd | 874 | C38｜G-KNOW／HLPE／OROCHI／RAG 的來源接地與長工作記憶 | MAPPED_CANDIDATE_NOT_OWNER_RATIFIED |
| 33 | Fabric/HG-KSEOS／Hermes Native Runtime／FDA 效果治理 | SBL-DOC-11 | SBL_PIPD-LS-PKG_DOC-11(2).md | 12f8705d780b76f2 | 121 | C29｜HG-KSEOS／Fabric Native 接線、四跳 Receiver 與 H0～H4（唯一設計規 | MAPPED_CANDIDATE_NOT_OWNER_RATIFIED |
| 34 | SWOF SQS–THC/TW-ICT 金融 Domain 與 PRE-W3／W3 閉環 | SBL-DOC-11 | SBL_PIPD-LS-PKG_DOC-11(2).md | 12f8705d780b76f2 | 271 | C30｜SWOF PRE-W3 Shadow／W3 Formal／W4-W5 接入與零副作用（唯一設計規格 W | MAPPED_CANDIDATE_NOT_OWNER_RATIFIED |
| 35 | 安全／供應鏈／MCP 權限／提示注入／秘密與資料治理 | SBL-DOC-07 | SBL_PIPD-LS-PKG_DOC-07(3).md | a366d3783c82089c | UNMAPPED_SUBSTANTIVE_H1 | OWNER_CONFIRM_REQUIRED | HOLD_EXACT_H1 |
| 36 | 可靠性、成本、性能／SRE、Provider-off 與異常退化 | SBL-DOC-13 | SBL_PIPD-LS-PKG_DOC-13.md | 7cc0c8b17311130c | 444 | C46｜FirstFail／Root Cause／RepairCone／Recovery／Migration／ | MAPPED_CANDIDATE_NOT_OWNER_RATIFIED |
| 37 | 38 Delivery Surfaces、安裝／部署／移除與 Host Compatibility | SBL-DOC-12 | SBL_PIPD-LS-PKG_DOC-12.md | d1e470d82ca14319 | 922 | C36｜Hermes／Codex／Claude／DeepSeek 四 Host × Web 三 SP 的 Na | MAPPED_CANDIDATE_NOT_OWNER_RATIFIED |
| 38 | CI／Release／SBOM／Provenance／Attestation／權利與獨立簽核 | SBL-DOC-12 | SBL_PIPD-LS-PKG_DOC-12.md | d1e470d82ca14319 | 1228 | C43｜GitHub CI／Required Checks／Repo Ruleset、Build Attest | MAPPED_CANDIDATE_NOT_OWNER_RATIFIED |
| 39 | 自舉／DOGFOOD／受控演化、A/B 與 Holdout | SBL-DOC-13 | SBL_PIPD-LS-PKG_DOC-13.md | 7cc0c8b17311130c | 678 | C47｜SBL Self Dogfood／SWOF Cross Dogfood／飛輪 A-B-C／受控自舉 | MAPPED_CANDIDATE_NOT_OWNER_RATIFIED |
| 40 | 施工／RUNBOOK／WI、I0–I10 分段關卡與 rollback | SBL-DOC-12 | SBL_PIPD-LS-PKG_DOC-12.md | d1e470d82ca14319 | 1490 | C49｜RUNBOOK／WI／AGENTS.md 人機操作導航、事故停止、回滾與跨階段交接 | MAPPED_CANDIDATE_NOT_OWNER_RATIFIED |
| 41 | 衝突／TT／CR_OPEN／Supersession 與 Claim Ceiling | SBL-DOC-00 | SBL_PIPD-LS-PKG_DOC-00(1).md | 5f82ab6f1a668d08 | 3524 | C54｜AI Zero-Rediscovery／Receiver Handoff／驗收 Claim Ceili | MAPPED_CANDIDATE_NOT_OWNER_RATIFIED |
| 42 | 全量來源覆蓋、內容保真／不遺失／雙向矩陣 | SBL-DOC-09 | SBL_PIPD-LS-PKG_DOC-09.md | 6450f7c15915ec8b | UNMAPPED_SUBSTANTIVE_H1 | OWNER_CONFIRM_REQUIRED | HOLD_EXACT_H1 |
| 43 | 2026 外部證據、版本現實、技術准入與失效重核 | SBL-DOC-06 | SBL_PIPD-LS-PKG_DOC-06(4).md | 64ea4977dab30933 | UNMAPPED_SUBSTANTIVE_H1 | OWNER_CONFIRM_REQUIRED | HOLD_EXACT_H1 |
| 44 | 最終打包、章節 Conformance、AI 冷啟動與反證總驗收 | SBL-DOC-13 | SBL_PIPD-LS-PKG_DOC-13.md | 7cc0c8b17311130c | UNMAPPED_SUBSTANTIVE_H1 | OWNER_CONFIRM_REQUIRED | HOLD_EXACT_H1 |

**路由實際拒收**：DOC-12 DELIVER `C-037` 不能被 Doc-03 的要求表取代；第 20 ECP 需 token/rollback，不能用 TestPlan 當效果權；第 21 Checker 必真實不同身份。對每個列寫 `GlobalH1Binding{global_id,source_control_clause,owner_doc,owner_h1_exact,authoritative_subject_sha,consumer,positive,negative,firstfail}`，若 `owner_h1_exact` 沒有 Owner 批准則 `H1_UNVERIFIED`，保留候選映射但不得 FULL_PASS。


# R02｜產品類型、Golden Journey、Moments 與 ModeGate 讀者投影

## R02.r3.base.1｜七 Primary Kinds × 八 ProductKind 正交契約
Canonical SWOF 7 Kind 的原始計數為 11/43/82/18/29/18/30 = 231，另有 59 Relation /72 MC；它們屬於 SWOF 來源分母，不可誤記為 SBL 真的新建分子。每個已引用 entity 恰一 `primary_kind`；一個 SBL `ProductKind` 可投影到多種 entity kind，二者永遠維持兩欄。

| Primary Kind | SWOF 源分母 | 本地使用 | 拒收 |
| PRODUCT | 11 | read-only TypedRef; one primary_kind per SWOF canonical entity | zero or multiple primary kinds or SBL rewriting identity |
| CAPABILITY | 43 | read-only TypedRef; one primary_kind per SWOF canonical entity | zero or multiple primary kinds or SBL rewriting identity |
| ARTIFACT | 82 | read-only TypedRef; one primary_kind per SWOF canonical entity | zero or multiple primary kinds or SBL rewriting identity |
| COMPOSITION | 18 | read-only TypedRef; one primary_kind per SWOF canonical entity | zero or multiple primary kinds or SBL rewriting identity |
| LIFECYCLE | 29 | read-only TypedRef; one primary_kind per SWOF canonical entity | zero or multiple primary kinds or SBL rewriting identity |
| PLATFORM | 18 | read-only TypedRef; one primary_kind per SWOF canonical entity | zero or multiple primary kinds or SBL rewriting identity |
| RUNTIME_UNIT | 30 | read-only TypedRef; one primary_kind per SWOF canonical entity | zero or multiple primary kinds or SBL rewriting identity |

| SBL ProductKind | v0.1 scope | 交付/ FUO 準則 | 禁止等同 SWOF kind |
| CLI_TOOL | IMPLEMENTATION_TARGET | 可用安裝與 Consumer probe；未測則 NOT_QUALIFIED | 不得由 product_kind 推出 entity.primary_kind |
| AGENT_SKILL | IMPLEMENTATION_TARGET | 可用安裝與 Consumer probe；未測則 NOT_QUALIFIED | 不得由 product_kind 推出 entity.primary_kind |
| SIMPLE_AGENT | IMPLEMENTATION_TARGET | 可用安裝與 Consumer probe；未測則 NOT_QUALIFIED | 不得由 product_kind 推出 entity.primary_kind |
| PLUGIN | DEFERRED | 可用安裝與 Consumer probe；未測則 NOT_QUALIFIED | 不得由 product_kind 推出 entity.primary_kind |
| PROFILE | DEFERRED | 可用安裝與 Consumer probe；未測則 NOT_QUALIFIED | 不得由 product_kind 推出 entity.primary_kind |
| AGENT_OS | UNSUPPORTED_V0.1/SWOF_OWNER_CONTROLLED | 可用安裝與 Consumer probe；未測則 NOT_QUALIFIED | 不得由 product_kind 推出 entity.primary_kind |
| AI_SYSTEM | UNSUPPORTED_V0.1/SWOF_OWNER_CONTROLLED | 可用安裝與 Consumer probe；未測則 NOT_QUALIFIED | 不得由 product_kind 推出 entity.primary_kind |
| GENIE/GENIE.md | UNSUPPORTED_V0.1/SWOF_OWNER_CONTROLLED | 可用安裝與 Consumer probe；未測則 NOT_QUALIFIED | 不得由 product_kind 推出 entity.primary_kind |

## R02.r3.1｜16 個 Moment 逐個 FUO、錯誤與測量
每 Moment 有獨立 Persona、可觀察輸入／輸出、失敗回復，不得以 16 個名稱代替使用者成功。時間、摩擦與完成率僅有 `UAT_SAMPLE_PENDING`，試算式：`completion_rate=accepted_FUO/eligible_runs`，`time_to_FUO=first_accepted_at-clean_start`；拒以單一次 Maker 模擬作真實 UX。
| Moment | Persona | 輸入 | 具名輸出 | 原行為 POS/NEG | 完成述詞 | UAT 判準候選 | 反例／重試 | Recovery/Next | 門檻狀態 |
|---|---|---|---|---|---|---|---|---|---|
| M00 Understand | 新手產品 Owner | 需求方的原始語句／附件 | SourceInventory→IntentRecord | 需求被精確引用；空來源拒收 | pre: source/version known where required; `consumer_accept=M00` observable | User confirms artifact readable and can name next step; measurable in UAT | NEG: wrong SHA or absent output; retry bounded once | 要求來源定位 | DESIGN_THRESHOLD_PROPOSED;NOT_MEASURED |
| M01 Explore | 需求分析師 | 尚不確定可行性目標 | Explore/DecisionLedger | 有效可行性分歧；無來源不問假問題 | pre: source/version known where required; `consumer_accept=M01` observable | User confirms artifact readable and can name next step; measurable in UAT | NEG: wrong SHA or absent output; retry bounded once | 採提出不同假設 | DESIGN_THRESHOLD_PROPOSED;NOT_MEASURED |
| M02 Define | 產品經理 | 產品願景/JTBD | ProductBrief/FUO/MVP/NonGoal | Owner 確定可量測成果；禁止抽象「做一個系統」當 FUO | pre: source/version known where required; `consumer_accept=M02` observable | User confirms artifact readable and can name next step; measurable in UAT | NEG: wrong SHA or absent output; retry bounded once | 返非目標範圍 | DESIGN_THRESHOLD_PROPOSED;NOT_MEASURED |
| M03 Specify | 領域專家 | 凍結需求/Oracle cues | PI atoms/Acceptance/Verification | 至少一條驗收與非零分母；Provider-off 只輸出候選 | pre: source/version known where required; `consumer_accept=M03` observable | User confirms artifact readable and can name next step; measurable in UAT | NEG: wrong SHA or absent output; retry bounded once | 退回 RequirementAtom Owner | DESIGN_THRESHOLD_PROPOSED;NOT_MEASURED |
| M04 Architect | 架構師 | NFR/RepoContext | Domain/ADR/Threat/Interface | 方案權衡具來源；缺 Native Context 不冒充已綁 PD | pre: source/version known where required; `consumer_accept=M04` observable | User confirms artifact readable and can name next step; measurable in UAT | NEG: wrong SHA or absent output; retry bounded once | 保留 ADR unresolved | DESIGN_THRESHOLD_PROPOSED;NOT_MEASURED |
| M05 Plan | Tech Lead | Task Spec/Dependency | 有向無環 DAG/Owner/Milestone | 有合法 Task；拒孤兒與環 | pre: source/version known where required; `consumer_accept=M05` observable | User confirms artifact readable and can name next step; measurable in UAT | NEG: wrong SHA or absent output; retry bounded once | 重排 Task DAG | DESIGN_THRESHOLD_PROPOSED;NOT_MEASURED |
| M06 Prepare | Repo Maintainer | Repo HEAD/WritableScope/ECP | PD Construction Binding+TQAEP | 準備合法施工；無真 RepoContext BLOCK | pre: source/version known where required; `consumer_accept=M06` observable | User confirms artifact readable and can name next step; measurable in UAT | NEG: wrong SHA or absent output; retry bounded once | 撤銷 prepare，不產出 PD | DESIGN_THRESHOLD_PROPOSED;NOT_MEASURED |
| M07 Build | 受控 Worker | 核准 WorkOrder/Permit | 受控 Worker ChangeSet | 真產物；禁止無許可 Repo 修改 | pre: source/version known where required; `consumer_accept=M07` observable | User confirms artifact readable and can name next step; measurable in UAT | NEG: wrong SHA or absent output; retry bounded once | 停止效應並請 HGK Owner | DESIGN_THRESHOLD_PROPOSED;NOT_MEASURED |
| M08 Test | QA Engineer | 現行候選及 Test Oracle | Raw Logs/Exit/Trace | 可重播 Test；拒假 Exit0/零測試 | pre: source/version known where required; `consumer_accept=M08` observable | User confirms artifact readable and can name next step; measurable in UAT | NEG: wrong SHA or absent output; retry bounded once | 重新執行受影 Test | DESIGN_THRESHOLD_PROPOSED;NOT_MEASURED |
| M09 Review | Reviewer | 正確 Candidate SHA+diff | Reviewer Findings | 品質意見精確定位；自簽不能算獨立 | pre: source/version known where required; `consumer_accept=M09` observable | User confirms artifact readable and can name next step; measurable in UAT | NEG: wrong SHA or absent output; retry bounded once | 隔離評論及簽章 | DESIGN_THRESHOLD_PROPOSED;NOT_MEASURED |
| M10 Verify | 獨立 AO | 同版本/Scope 之實體證據 | Local AO/Acceptance Receipt | 實際功能符合；foreign evidence 拒收 | pre: source/version known where required; `consumer_accept=M10` observable | User confirms artifact readable and can name next step; measurable in UAT | NEG: wrong SHA or absent output; retry bounded once | 獨立反證後重資格化 | DESIGN_THRESHOLD_PROPOSED;NOT_MEASURED |
| M11 Repair | 修復負責人 | FirstFail/RepairScope | RepairCone/Scoped Rerun | 最小改動重測；STOP shotgun repair | pre: source/version known where required; `consumer_accept=M11` observable | User confirms artifact readable and can name next step; measurable in UAT | NEG: wrong SHA or absent output; retry bounded once | 回 RootCause、限制 cone | DESIGN_THRESHOLD_PROPOSED;NOT_MEASURED |
| M12 Ship | Release Manager | ReleaseAuthority/Pin/Rights | GitHub Tag/Assets/Provenance | 新環境實裝使用；無批准不發 | pre: source/version known where required; `consumer_accept=M12` observable | User confirms artifact readable and can name next step; measurable in UAT | NEG: wrong SHA or absent output; retry bounded once | HOLD release / keep previous version | DESIGN_THRESHOLD_PROPOSED;NOT_MEASURED |
| M13 Maintain | SRE | 已發行版本+事故/使用紀錄 | Repair/Migration/Regression | 確實可復原；不可偷換 Oracle | pre: source/version known where required; `consumer_accept=M13` observable | User confirms artifact readable and can name next step; measurable in UAT | NEG: wrong SHA or absent output; retry bounded once | 回 last-known-good | DESIGN_THRESHOLD_PROPOSED;NOT_MEASURED |
| M14 Host Portability | Host User | 4 Host × 各 SP/Full Stack | NativeInstall/EffLoad/Uninstall | 每宿主真作用；無效裝載拒 PASS | pre: source/version known where required; `consumer_accept=M14` observable | User confirms artifact readable and can name next step; measurable in UAT | NEG: wrong SHA or absent output; retry bounded once | 卸載且清查 residue | DESIGN_THRESHOLD_PROPOSED;NOT_MEASURED |
| M15 Private Use | Private Web User | 3 SP × 私人 ZIP/Claude Native/MD | 合法包＋用戶上傳＋調用 | 個別可使用；MD≠工具 Runtime | pre: source/version known where required; `consumer_accept=M15` observable | User confirms artifact readable and can name next step; measurable in UAT | NEG: wrong SHA or absent output; retry bounded once | 回退單一 Web session | DESIGN_THRESHOLD_PROPOSED;NOT_MEASURED |

### Golden Journeys：三條 End-to-end 可重播狀態鏈（設計，不是已運行）
- **GJ01 Greenfield CLI**：GoalCard[source ref] → T0/T5 ProductBrief (拒無 source) → P4 freeze/PI (拒零 atom) → route Spec Kit/Tasks (拒 orphan) → 適格 Repo/PD (拒 guessed head) → ONE ECP/Permit (拒 shadow write) → code + red/green + independent review (拒 maker selfpass) → clean install `todo --json list` 驗 JSON schema/exit/進程 → uninstall/readback → consumer FUO `list=[]` 且不殘留；任何 FirstFail 回其 Owner，禁止 skip gate。
- **GJ02 Brownfield**：帶 HEAD 及 changed request 的 source delta → OpenSpec proposal preserved unaffected clauses → diff-to-atoms→ PIPD PI/PD → `writable_scope=[src/cli/]` → bounded WorkOrder → tests+regression+diff same SHA → user UAT 只變需求子集 → rollback 回原 HEAD；NEG：`writable_scope=**` 或無關檔改寫 → `SCOPE_ESCAPE`。
- **GJ03 Skills / Simple Agent**：TPM 輸出已 pin 的 capability/Host choice → GENIEMAKER host bundle → each Host register → effective-load enumeration→ trigger correct skill on intent，non-trigger on unrelated intent → Owner/independent challenge of permitted path → uninstall + residue check；NEG：只存在 SKILL.md 就聲稱 Hosted PASS → `HOST_LOAD_NOT_PROVEN`。提供 `ProviderOffRoute` 的人工來源處理／PDF-MD 文件輸出，不聲稱已取得原生功能。

### R02.r3.2｜39/39 個 Mode×Gate 的條件、禁止與輸出
`C` 先核對 trigger，未觸發要產 `NOT_TRIGGERED` 而非假的 PASS；`F` 必有零副作用讀回；`N` 說明為何不適用且**不要求 Native RawReceipt**。以下是真正 39 個互不合併的 Cell，形式驗證不能取代 Native gate。
| Gate | Mode | R/C/F/N | Trigger predicate | 進入門檻 | 可觀察正例設計 | 特定負例 | Owner | FirstFail ID |
|---|---|---|---|---|---|---|---|---|
| G00 | STANDALONE | R | source hash/current owner available | REQUIRED | source digest equality vs reader; in STANDALONE return decision object; no receipt fabricated | SOURCE_DRIFT | PIPD/HGK/SWOF Owner by scope | G00_STANDALONE_FIRSTFAIL |
| G00 | PREW3_SHADOW | R | source hash/current owner available | REQUIRED | source digest equality vs reader; in PREW3_SHADOW return decision object; no receipt fabricated | SOURCE_DRIFT | PIPD/HGK/SWOF Owner by scope | G00_PREW3_SHADOW_FIRSTFAIL |
| G00 | SWOF_CONNECTED | R | source hash/current owner available | REQUIRED | source digest equality vs reader; in SWOF_CONNECTED return decision object; no receipt fabricated | SOURCE_DRIFT | PIPD/HGK/SWOF Owner by scope | G00_SWOF_CONNECTED_FIRSTFAIL |
| G01 | STANDALONE | R | formal PI/PD proposed or consumed | REQUIRED | PI nonzero atoms, PD only with real RepoContext; in STANDALONE return decision object; no receipt fabricated | NO_FROZEN_PI_PD | PIPD/HGK/SWOF Owner by scope | G01_STANDALONE_FIRSTFAIL |
| G01 | PREW3_SHADOW | R | formal PI/PD proposed or consumed | REQUIRED | PI nonzero atoms, PD only with real RepoContext; in PREW3_SHADOW return decision object; no receipt fabricated | NO_FROZEN_PI_PD | PIPD/HGK/SWOF Owner by scope | G01_PREW3_SHADOW_FIRSTFAIL |
| G01 | SWOF_CONNECTED | R | formal PI/PD proposed or consumed | REQUIRED | PI nonzero atoms, PD only with real RepoContext; in SWOF_CONNECTED return decision object; no receipt fabricated | NO_FROZEN_PI_PD | PIPD/HGK/SWOF Owner by scope | G01_SWOF_CONNECTED_FIRSTFAIL |
| G02 | STANDALONE | C | claims independently host-installed SP | CONDITIONAL_ONLY_IF claims independently host-installed SP | per Host manifest+loader list+trigger+uninstall; in STANDALONE return decision object; no receipt fabricated | HOST_NOT_EFFECTIVE | PIPD/HGK/SWOF Owner by scope | G02_STANDALONE_FIRSTFAIL |
| G02 | PREW3_SHADOW | C | claims independently host-installed SP | CONDITIONAL_ONLY_IF claims independently host-installed SP | per Host manifest+loader list+trigger+uninstall; in PREW3_SHADOW return decision object; no receipt fabricated | HOST_NOT_EFFECTIVE | PIPD/HGK/SWOF Owner by scope | G02_PREW3_SHADOW_FIRSTFAIL |
| G02 | SWOF_CONNECTED | C | claims independently host-installed SP | CONDITIONAL_ONLY_IF claims independently host-installed SP | per Host manifest+loader list+trigger+uninstall; in SWOF_CONNECTED return decision object; no receipt fabricated | HOST_NOT_EFFECTIVE | PIPD/HGK/SWOF Owner by scope | G02_SWOF_CONNECTED_FIRSTFAIL |
| G03 | STANDALONE | C | Commander C0–C9 compilation used | CONDITIONAL_ONLY_IF Commander C0–C9 compilation used | CAPC parse+decision ref; non-trigger on read-only TPM; in STANDALONE return decision object; no receipt fabricated | CAPC_PARSE_FAIL | PIPD/HGK/SWOF Owner by scope | G03_STANDALONE_FIRSTFAIL |
| G03 | PREW3_SHADOW | C | Commander C0–C9 compilation used | CONDITIONAL_ONLY_IF Commander C0–C9 compilation used | CAPC parse+decision ref; non-trigger on read-only TPM; in PREW3_SHADOW return decision object; no receipt fabricated | CAPC_PARSE_FAIL | PIPD/HGK/SWOF Owner by scope | G03_PREW3_SHADOW_FIRSTFAIL |
| G03 | SWOF_CONNECTED | R | Commander C0–C9 compilation used | REQUIRED | CAPC parse+decision ref; non-trigger on read-only TPM; in SWOF_CONNECTED return decision object; no receipt fabricated | CAPC_PARSE_FAIL | PIPD/HGK/SWOF Owner by scope | G03_SWOF_CONNECTED_FIRSTFAIL |
| G04 | STANDALONE | N | connected mode real Native integration | NOT_APPLICABLE_WITH_REASON | record N/A reason, not request native receipt | N/A treated as PASSED_NATIVE | PIPD/HGK/SWOF Owner by scope | G04_STANDALONE_FIRSTFAIL |
| G04 | PREW3_SHADOW | N | connected mode real Native integration | NOT_APPLICABLE_WITH_REASON | record N/A reason, not request native receipt | N/A treated as PASSED_NATIVE | PIPD/HGK/SWOF Owner by scope | G04_PREW3_SHADOW_FIRSTFAIL |
| G04 | SWOF_CONNECTED | R | connected mode real Native integration | REQUIRED | repo head and effective HGK bind, no simulated receipt; in SWOF_CONNECTED return decision object; no receipt fabricated | REPO_HGK_UNBOUND | PIPD/HGK/SWOF Owner by scope | G04_SWOF_CONNECTED_FIRSTFAIL |
| G05 | STANDALONE | C | independent acceptance claimed | CONDITIONAL_ONLY_IF independent acceptance claimed | distinct principal and execution receipt; in STANDALONE return decision object; no receipt fabricated | SELF_CHECKER | PIPD/HGK/SWOF Owner by scope | G05_STANDALONE_FIRSTFAIL |
| G05 | PREW3_SHADOW | C | independent acceptance claimed | CONDITIONAL_ONLY_IF independent acceptance claimed | distinct principal and execution receipt; in PREW3_SHADOW return decision object; no receipt fabricated | SELF_CHECKER | PIPD/HGK/SWOF Owner by scope | G05_PREW3_SHADOW_FIRSTFAIL |
| G05 | SWOF_CONNECTED | R | independent acceptance claimed | REQUIRED | distinct principal and execution receipt; in SWOF_CONNECTED return decision object; no receipt fabricated | SELF_CHECKER | PIPD/HGK/SWOF Owner by scope | G05_SWOF_CONNECTED_FIRSTFAIL |
| G06 | STANDALONE | R | runtime raw result claimed | REQUIRED | test output+exit+candidate sha; shadow inspect only; in STANDALONE return decision object; no receipt fabricated | RAW_EVIDENCE_MISSING | PIPD/HGK/SWOF Owner by scope | G06_STANDALONE_FIRSTFAIL |
| G06 | PREW3_SHADOW | C | runtime raw result claimed | CONDITIONAL_ONLY_IF runtime raw result claimed | test output+exit+candidate sha; shadow inspect only; in PREW3_SHADOW return decision object; no receipt fabricated | RAW_EVIDENCE_MISSING | PIPD/HGK/SWOF Owner by scope | G06_PREW3_SHADOW_FIRSTFAIL |
| G06 | SWOF_CONNECTED | R | runtime raw result claimed | REQUIRED | test output+exit+candidate sha; shadow inspect only; in SWOF_CONNECTED return decision object; no receipt fabricated | RAW_EVIDENCE_MISSING | PIPD/HGK/SWOF Owner by scope | G06_SWOF_CONNECTED_FIRSTFAIL |
| G07 | STANDALONE | C | target mutation requested | CONDITIONAL_ONLY_IF target mutation requested | scoped permit/token/ECP only outside shadow; in STANDALONE return decision object; no receipt fabricated | SHADOW_MUTATION_FORBIDDEN | PIPD/HGK/SWOF Owner by scope | G07_STANDALONE_FIRSTFAIL |
| G07 | PREW3_SHADOW | F | target mutation requested | DENY_AND_PROVE_NO_SIDE_EFFECT | policy denied and filesystem/target unchanged | forbidden activity observed | PIPD/HGK/SWOF Owner by scope | G07_PREW3_SHADOW_FIRSTFAIL |
| G07 | SWOF_CONNECTED | R | target mutation requested | REQUIRED | scoped permit/token/ECP only outside shadow; in SWOF_CONNECTED return decision object; no receipt fabricated | SHADOW_MUTATION_FORBIDDEN | PIPD/HGK/SWOF Owner by scope | G07_SWOF_CONNECTED_FIRSTFAIL |
| G08 | STANDALONE | C | repair requested after FirstFail | CONDITIONAL_ONLY_IF repair requested after FirstFail | accepted affected-only cone and bounded retry; in STANDALONE return decision object; no receipt fabricated | REPAIR_SCOPE_EXPANSION | PIPD/HGK/SWOF Owner by scope | G08_STANDALONE_FIRSTFAIL |
| G08 | PREW3_SHADOW | F | repair requested after FirstFail | DENY_AND_PROVE_NO_SIDE_EFFECT | policy denied and filesystem/target unchanged | forbidden activity observed | PIPD/HGK/SWOF Owner by scope | G08_PREW3_SHADOW_FIRSTFAIL |
| G08 | SWOF_CONNECTED | C | repair requested after FirstFail | CONDITIONAL_ONLY_IF repair requested after FirstFail | accepted affected-only cone and bounded retry; in SWOF_CONNECTED return decision object; no receipt fabricated | REPAIR_SCOPE_EXPANSION | PIPD/HGK/SWOF Owner by scope | G08_SWOF_CONNECTED_FIRSTFAIL |
| G09 | STANDALONE | N | PREW3 compatibility requested | NOT_APPLICABLE_WITH_REASON | record N/A reason, not request native receipt | N/A treated as PASSED_NATIVE | PIPD/HGK/SWOF Owner by scope | G09_STANDALONE_FIRSTFAIL |
| G09 | PREW3_SHADOW | R | PREW3 compatibility requested | REQUIRED | read-only compatibility list; W3 no auto-promotion; in PREW3_SHADOW return decision object; no receipt fabricated | SHADOW_AS_W3 | PIPD/HGK/SWOF Owner by scope | G09_PREW3_SHADOW_FIRSTFAIL |
| G09 | SWOF_CONNECTED | C | PREW3 compatibility requested | CONDITIONAL_ONLY_IF PREW3 compatibility requested | read-only compatibility list; W3 no auto-promotion; in SWOF_CONNECTED return decision object; no receipt fabricated | SHADOW_AS_W3 | PIPD/HGK/SWOF Owner by scope | G09_SWOF_CONNECTED_FIRSTFAIL |
| G10 | STANDALONE | C | improvement/dogfood claim proposed | CONDITIONAL_ONLY_IF improvement/dogfood claim proposed | baseline vs holdout, independent evaluation; in STANDALONE return decision object; no receipt fabricated | DOGFOOD_SELF_PASS | PIPD/HGK/SWOF Owner by scope | G10_STANDALONE_FIRSTFAIL |
| G10 | PREW3_SHADOW | C | improvement/dogfood claim proposed | CONDITIONAL_ONLY_IF improvement/dogfood claim proposed | baseline vs holdout, independent evaluation; in PREW3_SHADOW return decision object; no receipt fabricated | DOGFOOD_SELF_PASS | PIPD/HGK/SWOF Owner by scope | G10_PREW3_SHADOW_FIRSTFAIL |
| G10 | SWOF_CONNECTED | C | improvement/dogfood claim proposed | CONDITIONAL_ONLY_IF improvement/dogfood claim proposed | baseline vs holdout, independent evaluation; in SWOF_CONNECTED return decision object; no receipt fabricated | DOGFOOD_SELF_PASS | PIPD/HGK/SWOF Owner by scope | G10_SWOF_CONNECTED_FIRSTFAIL |
| G11 | STANDALONE | C | artifact public distribution requested | CONDITIONAL_ONLY_IF artifact public distribution requested | owner release/rights/sign provenance; in STANDALONE return decision object; no receipt fabricated | UNAUTHORIZED_RELEASE | PIPD/HGK/SWOF Owner by scope | G11_STANDALONE_FIRSTFAIL |
| G11 | PREW3_SHADOW | F | artifact public distribution requested | DENY_AND_PROVE_NO_SIDE_EFFECT | policy denied and filesystem/target unchanged | forbidden activity observed | PIPD/HGK/SWOF Owner by scope | G11_PREW3_SHADOW_FIRSTFAIL |
| G11 | SWOF_CONNECTED | C | artifact public distribution requested | CONDITIONAL_ONLY_IF artifact public distribution requested | owner release/rights/sign provenance; in SWOF_CONNECTED return decision object; no receipt fabricated | UNAUTHORIZED_RELEASE | PIPD/HGK/SWOF Owner by scope | G11_SWOF_CONNECTED_FIRSTFAIL |
| G12 | STANDALONE | N | native SWOF W3 entry requested | NOT_APPLICABLE_WITH_REASON | record N/A reason, not request native receipt | N/A treated as PASSED_NATIVE | PIPD/HGK/SWOF Owner by scope | G12_STANDALONE_FIRSTFAIL |
| G12 | PREW3_SHADOW | F | native SWOF W3 entry requested | DENY_AND_PROVE_NO_SIDE_EFFECT | policy denied and filesystem/target unchanged | forbidden activity observed | PIPD/HGK/SWOF Owner by scope | G12_PREW3_SHADOW_FIRSTFAIL |
| G12 | SWOF_CONNECTED | R | native SWOF W3 entry requested | REQUIRED | signed READY_W3 + source-bound WorkOrder; in SWOF_CONNECTED return decision object; no receipt fabricated | W3_GATE_MISSING | PIPD/HGK/SWOF Owner by scope | G12_SWOF_CONNECTED_FIRSTFAIL |


# R03｜PIPD 正式製程、十 DOC 和 P4 八 Skill 的只讀入口

## R03.r3.base.1｜正式製程下游契約，不構成本輪執行收據
`Goal+SourceLocator → IntentCard → AuthorityBinding/SourceFreezeManifest → ProfileBinding → PI-PKG → 真 RepoContext 晚綁定 PD-PKG → ConstructionContract + ONE ECP → TQAEP/Independent Checker → Evidence/TraceClosure/ClaimCeiling → Receiver/Release/Evolution`。每一步的輸入/輸出必符合 PIPD 官方 Schema，SBL 本檔只能顯示讀序及合法 Caller/Owner。

| P4 skill | formal input | output | 拒收 predicate | 本次法位 |
| pipd-route-intake | goal＋≥1 source locator | IntentCard@1, content derived | blank/zero-source/path traversal | method_read_only |
| pipd-authority-source | sha256 manifest per family＋locator | SourceFreezeManifest＋AuthorityBinding | missing digest/conflict/currentness mismatch | formal HOLD |
| pipd-profile-tailor | LITE/STANDARD/ASSURED + 9 axes | ProfileBinding with safety veto | unknown axes, profile, downgrade | method_read_only |
| pipd-pi-compile | frozen IntentCard/ProfileBinding/atoms | PI-PKG TraceLinks + bound acceptance | zero atoms/missing clause/owner/cue/risk_guard | formal HOLD |
| pipd-pd-bind | PI-PKG+root/head/tracked_files/currentness/writable_scope | PD-PKG affected-only late binding | no Repo, ** scope, out-of-root | not executed |
| pipd-execution-contract | bound PD＋PI | ConstructionContract+ONE ECP | no token/no rollback/retry > 1 | not executed |
| pipd-assurance-tqaep | PI/ECP+distinct maker/checker+real receipt | TQAEP POS/NEG+acceptance | same principal or SELF_ATTESTED receipt | not executed |
| pipd-package-project | nonempty bundle+allow claims+producer | EvidenceExpectation+TraceClosure/ClaimCeiling | orphan/hash mismatch/claim above proof | not executed |

正式 profile 的九 Routing Axes 是 `intent,knowledge,verification,release,trust_boundary,preexisting_repo,profile,tech_candidates,host_surface`；不要與 DOC-06 十二個風險軸混為同一套。Safety Veto 只能升級深度，不得縮減高危保護。PI Skill 的 `DOC-03 DOMAIN_ORACLES` 出處不等於已核准 PIPD DOC-07 alias；衝突受影 scope HOLD (`CR-ORACLE-001`)。

## R03.r3.1｜P4 實際八 Skills 與正式門檻（不創第二 PIPD）
| P4 Skill | 合法輸入 | 合法輸出 | 首個負例 |
|---|---|---|---|
| route-intake | goal＋來源路徑 | IntentCard/reqatoms | zero source→INTAKE_INVALID |
| authority-source | families/digests | AuthorityBinding/SourceFreezeManifest | digest malformed→FREEZE_REJECT |
| profile-tailor | LITE/STANDARD/ASSURED＋axes | EffectiveProfile | unknown axis/unsafe downgrade→PROFILE_VETO |
| pi-compile | frozen IntentCard＋nonzero atoms | PI-PKG+TraceLinks | zero atom/sidecar→PI_COMPILE_DENY |
| pd-bind | PIRef＋真 RepoContext | PD-PKG late binding | scope ** or stale assumed→PD_BIND_DENY |
| execution-contract | bound PD＋rollback | ConstructionContract+ONE ECP | no token/rollback→ECP_REJECT |
| assurance-tqaep | PI/ECP＋distinct checker＋receipt | TQAEP+POS/NEG cases | self/checker missing→NOT_INDEPENDENT |
| package-project | nonempty artifacts+claim | ClaimCeiling/TraceClosure | orphan edges / unbound claim→PACK_HOLD |
通道保持 route→authority-source→profile→PI→PD→ECP→TQAEP→package。PIPD 沒有真 SourceFreeze/Repo/Checker 不得以「文檔存在」跳過。SBL 提供 `ReqAtomProposal`、`ReaderRoute` 及 UX，不自行造正式 PI Writer。`pipd-assurance-tqaep` 拒絕 maker=checker 或 self-attested execution receipt；本文只有測試設計，不能主張該功能已執行。


# R04｜NamedCapabilitySlot、HotSwap 與不重造輪子政策

## R04.r3.base.1｜六 Donor × 24 Core 能力的原始行為決策，不另寫第七套 Compiler
下列 24 筆來自上位藍圖的受保護能力 ledger。`OS/SK/MP/GS/GT` 等 donor 的 method 只在適用 TaskKind、Risk、Host 與正式 Owner 條件成立時使用。採 `SEARCH_BEFORE_BUILD → CAPABILITY_BEFORE_BRAND → thin adapter → version/host pin → POS/NEG probe → rollback/exit`，防止六工具重複產生 SPEC/PI Writer。

| Cap ID | Donor | 受保護功能行為 | Oracle/NEG | Owner | source line |
| OS-01 | OpenSpec | Explore、模糊意圖形成決策/可行性 | 模糊需求有決策/來源；不可只產空 Proposal | TPM | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L216 |
| OS-02 | OpenSpec | Brownfield Proposal／Spec Delta | Diff 僅在改動範圍；拒改非 Scope | TPM/PIPD | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L217 |
| OS-03 | OpenSpec | Apply／Verify 一致 | 真 ChangeSet 對照凍結 SPEC；不以摘要代替 | Commander/Checker | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L218 |
| OS-04 | OpenSpec | Sync／Archive／Versioned History | 確切可回溯且未消除未決 TT；拒 stale archive | Evidence | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L219 |
| SK-01 | Spec Kit | Constitution／Product Scope | 約束具有效續接；拒後續 Plan 偷刪 NFR | PIPD | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L220 |
| SK-02 | Spec Kit | Specify／Clarify／Atomic Acceptance | Source/REQ/ACC 非空；拒零分母 PI | PIPD | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L221 |
| SK-03 | Spec Kit | Plan／Tasks／Analyze | DAG 無環、每 Task 有前置和驗收；拒 orphan | TPM/Commander | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L222 |
| SK-04 | Spec Kit | 可組合且版本固定的 Workflow | 對非適用工作流應正確退出；拒未釘住依賴 | Method Resolver | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L223 |
| MP-01 | Matt | Smart Method Routing | 不要求使用者選六工具；錯誤任務不誤啟 Skill | TPM | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L224 |
| MP-02 | Matt | Grill-with-docs／High Info Gain | 不重問已知資料；重要未知生成 TT | TPM | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L225 |
| MP-03 | Matt | Domain／Architecture Model | Glossary、Domain、ADR 一致；拒互斥名詞 | Systems Eng | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L226 |
| MP-04 | Matt | To-spec／To-tickets | 每 Task 對應 SPEC/Acceptance；拒空 Ticket | TPM/PIPD | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L227 |
| GS-01 | GSD | Context Engineering | 來源定位與版本保留；拒記憶假資料 | Context Bridge | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L228 |
| GS-02 | GSD | Phase／Milestone | 每階段 Exit Receipt；拒「時間到即 PASS」 | Commander | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L229 |
| GS-03 | GSD | Checkpoint／Resume | Crash 後不重播世界效果；拒 stale checkpoint | Recovery | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L230 |
| GS-04 | GSD | Verify／Ship Continuity | Verify 憑證與 Release Subject 一致；拒舊 SHA | Evidence/Release | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L231 |
| GT-01 | gstack | CEO/Product/Office Hours Review | 問題價值、JTBD、MVP 非目標；拒空洞建議 | TPM | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L232 |
| GT-02 | gstack | Engineering／DX/Design Review | User Friction、NFR、錯誤路徑；拒無來源 PR 評語 | Reviewer | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L233 |
| GT-03 | gstack | QA／Code Review | Diff/Policy/E2E 鑑定；拒只靠 LLM 語意說 PASS | Checker | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L234 |
| GT-04 | gstack | Ship／Retro | Release Ready + 可採用 Retro Feedback；拒自動 publish | Release Owner | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L235 |
| SP-01 | Superpowers | Brainstorm／Design-first | 關鍵設計決策先於 mutation；拒擅改架構 | TPM | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L236 |
| SP-02 | Superpowers | 真正 Test-first | Red 測試實測→Patch→Green；拒敘述性「有 TDD」 | Worker | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L237 |
| SP-03 | Superpowers | Root Cause／Smallest Repair | 第一失敗 invariant、變更錐、回歸；拒全域掃射 | Commander/Worker | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L238 |
| SP-04 | Superpowers | Plan Execution／Review | 有界 WorkOrder、獨立 Review；拒 Maker 自簽 | Commander/Challenge | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L239 |

## R04.r3.1｜24 個能力槽可執行功能契約（非單純列名）
| Slot | 實質功能 | Trigger/Input | 可讀 Output | 功能 POS | 專用 NEG | Provider-off / Exit | Owner |
|---|---|---|---|---|---|---|---|
| OS-01 | 探索候選可行性並對可逆決策分歧 | OS-01:source_sha+task_kind+mode | SpecDelta(OS-01) | POS: 探索候選可行性並對可逆決策分歧 with linked source/Consumer | NEG: stale delta silently rewrites unrelated clause→SLOT_FUNCTION_MISMATCH | read-only adapter or qualified host only; rollback previous pin | DOC-06/PIPD Owner |
| OS-02 | spec delta 逐 clause 僅受影變更 | OS-02:source_sha+task_kind+mode | SpecDelta(OS-02) | POS: spec delta 逐 clause 僅受影變更 with linked source/Consumer | NEG: stale delta silently rewrites unrelated clause→SLOT_FUNCTION_MISMATCH | read-only adapter or qualified host only; rollback previous pin | DOC-06/PIPD Owner |
| OS-03 | Apply/Verify 結果同步 predicate | OS-03:source_sha+task_kind+mode | SpecDelta(OS-03) | POS: Apply/Verify 結果同步 predicate with linked source/Consumer | NEG: stale delta silently rewrites unrelated clause→SLOT_FUNCTION_MISMATCH | read-only adapter or qualified host only; rollback previous pin | DOC-06/PIPD Owner |
| OS-04 | Archive history 不覆蓋 current SourceFreeze | OS-04:source_sha+task_kind+mode | SpecDelta(OS-04) | POS: Archive history 不覆蓋 current SourceFreeze with linked source/Consumer | NEG: stale delta silently rewrites unrelated clause→SLOT_FUNCTION_MISMATCH | read-only adapter or qualified host only; rollback previous pin | DOC-06/PIPD Owner |
| SK-01 | constitution 保留 NonGoals/NFR | SK-01:source_sha+task_kind+mode | StageArtifact(SK-01) | POS: constitution 保留 NonGoals/NFR with linked source/Consumer | NEG: stage loses NonGoal or downstream tasks orphan→SLOT_FUNCTION_MISMATCH | read-only adapter or qualified host only; rollback previous pin | DOC-06/PIPD Owner |
| SK-02 | specify/clarify 輸出 atoms 原子化 | SK-02:source_sha+task_kind+mode | StageArtifact(SK-02) | POS: specify/clarify 輸出 atoms 原子化 with linked source/Consumer | NEG: stage loses NonGoal or downstream tasks orphan→SLOT_FUNCTION_MISMATCH | read-only adapter or qualified host only; rollback previous pin | DOC-06/PIPD Owner |
| SK-03 | plan/tasks 保留來源及依賴 | SK-03:source_sha+task_kind+mode | StageArtifact(SK-03) | POS: plan/tasks 保留來源及依賴 with linked source/Consumer | NEG: stage loses NonGoal or downstream tasks orphan→SLOT_FUNCTION_MISMATCH | read-only adapter or qualified host only; rollback previous pin | DOC-06/PIPD Owner |
| SK-04 | workflow compose source hash 和版本 | SK-04:source_sha+task_kind+mode | StageArtifact(SK-04) | POS: workflow compose source hash 和版本 with linked source/Consumer | NEG: stage loses NonGoal or downstream tasks orphan→SLOT_FUNCTION_MISMATCH | read-only adapter or qualified host only; rollback previous pin | DOC-06/PIPD Owner |
| MP-01 | 按 task/risk/host 方法選擇+排除 | MP-01:source_sha+task_kind+mode | MethodDecision(MP-01) | POS: 按 task/risk/host 方法選擇+排除 with linked source/Consumer | NEG: chosen method without source/host or duplicate questions→SLOT_FUNCTION_MISMATCH | read-only adapter or qualified host only; rollback previous pin | DOC-06/PIPD Owner |
| MP-02 | grill 已知問答去重 | MP-02:source_sha+task_kind+mode | MethodDecision(MP-02) | POS: grill 已知問答去重 with linked source/Consumer | NEG: chosen method without source/host or duplicate questions→SLOT_FUNCTION_MISMATCH | read-only adapter or qualified host only; rollback previous pin | DOC-06/PIPD Owner |
| MP-03 | domain modelling typed diagram/nfr | MP-03:source_sha+task_kind+mode | MethodDecision(MP-03) | POS: domain modelling typed diagram/nfr with linked source/Consumer | NEG: chosen method without source/host or duplicate questions→SLOT_FUNCTION_MISMATCH | read-only adapter or qualified host only; rollback previous pin | DOC-06/PIPD Owner |
| MP-04 | to-spec/to-tickets 接收無孤兒 | MP-04:source_sha+task_kind+mode | MethodDecision(MP-04) | POS: to-spec/to-tickets 接收無孤兒 with linked source/Consumer | NEG: chosen method without source/host or duplicate questions→SLOT_FUNCTION_MISMATCH | read-only adapter or qualified host only; rollback previous pin | DOC-06/PIPD Owner |
| GS-01 | context bounded source set | GS-01:source_sha+task_kind+mode | Checkpoint(GS-01) | POS: context bounded source set with linked source/Consumer | NEG: resume replays irreversible effect→SLOT_FUNCTION_MISMATCH | read-only adapter or qualified host only; rollback previous pin | DOC-06/PIPD Owner |
| GS-02 | phase milestone 完成述詞 | GS-02:source_sha+task_kind+mode | Checkpoint(GS-02) | POS: phase milestone 完成述詞 with linked source/Consumer | NEG: resume replays irreversible effect→SLOT_FUNCTION_MISMATCH | read-only adapter or qualified host only; rollback previous pin | DOC-06/PIPD Owner |
| GS-03 | checkpoint/resume effect 不重放 | GS-03:source_sha+task_kind+mode | Checkpoint(GS-03) | POS: checkpoint/resume effect 不重放 with linked source/Consumer | NEG: resume replays irreversible effect→SLOT_FUNCTION_MISMATCH | read-only adapter or qualified host only; rollback previous pin | DOC-06/PIPD Owner |
| GS-04 | verification ship gate 可銜接 | GS-04:source_sha+task_kind+mode | Checkpoint(GS-04) | POS: verification ship gate 可銜接 with linked source/Consumer | NEG: resume replays irreversible effect→SLOT_FUNCTION_MISMATCH | read-only adapter or qualified host only; rollback previous pin | DOC-06/PIPD Owner |
| GT-01 | office-hours 具名用戶問題 | GT-01:source_sha+task_kind+mode | ReviewFinding(GT-01) | POS: office-hours 具名用戶問題 with linked source/Consumer | NEG: self-authored role review treated independent→SLOT_FUNCTION_MISMATCH | read-only adapter or qualified host only; rollback previous pin | DOC-06/PIPD Owner |
| GT-02 | engineering/DX 具名阻塞 | GT-02:source_sha+task_kind+mode | ReviewFinding(GT-02) | POS: engineering/DX 具名阻塞 with linked source/Consumer | NEG: self-authored role review treated independent→SLOT_FUNCTION_MISMATCH | read-only adapter or qualified host only; rollback previous pin | DOC-06/PIPD Owner |
| GT-03 | QA review 可復現差異 | GT-03:source_sha+task_kind+mode | ReviewFinding(GT-03) | POS: QA review 可復現差異 with linked source/Consumer | NEG: self-authored role review treated independent→SLOT_FUNCTION_MISMATCH | read-only adapter or qualified host only; rollback previous pin | DOC-06/PIPD Owner |
| GT-04 | retro/ship owner decision | GT-04:source_sha+task_kind+mode | ReviewFinding(GT-04) | POS: retro/ship owner decision with linked source/Consumer | NEG: self-authored role review treated independent→SLOT_FUNCTION_MISMATCH | read-only adapter or qualified host only; rollback previous pin | DOC-06/PIPD Owner |
| SP-01 | brainstorm alternatives before design | SP-01:source_sha+task_kind+mode | RepairEvidence(SP-01) | POS: brainstorm alternatives before design with linked source/Consumer | NEG: test marked green without red log or repair exceeds cone→SLOT_FUNCTION_MISMATCH | read-only adapter or qualified host only; rollback previous pin | DOC-06/PIPD Owner |
| SP-02 | red/green 真 test-first | SP-02:source_sha+task_kind+mode | RepairEvidence(SP-02) | POS: red/green 真 test-first with linked source/Consumer | NEG: test marked green without red log or repair exceeds cone→SLOT_FUNCTION_MISMATCH | read-only adapter or qualified host only; rollback previous pin | DOC-06/PIPD Owner |
| SP-03 | root cause 受影修補 | SP-03:source_sha+task_kind+mode | RepairEvidence(SP-03) | POS: root cause 受影修補 with linked source/Consumer | NEG: test marked green without red log or repair exceeds cone→SLOT_FUNCTION_MISMATCH | read-only adapter or qualified host only; rollback previous pin | DOC-06/PIPD Owner |
| SP-04 | plan execution/review scope | SP-04:source_sha+task_kind+mode | RepairEvidence(SP-04) | POS: plan execution/review scope with linked source/Consumer | NEG: test marked green without red log or repair exceeds cone→SLOT_FUNCTION_MISMATCH | read-only adapter or qualified host only; rollback previous pin | DOC-06/PIPD Owner |

## R04.r3.2｜386/386 Universe 按法位完整拆列；226 技術/協定/研究與 160 歷史規則不混為安裝數
下列表以 rNEXT `R04.2` 的 **全部 386 行**精確抽出 ID、名稱、原上位 disposition（禁止升權）；226 筆不是都可安裝軟體，有研究/協定/方法；160 筆是 rule ledger。`Pin/License` 未有可信可安裝原件與 rights readback，故標 `NOT_VERIFIED` 而不偽造版本。POS/NEG 是每件按所屬功能推導的**待 Owner 驗證 fixture 規格**，不是實測；名稱／功能無法可靠辨識者獨立 `NEEDS_DOMAIN_SPEC` 不可強行補齊。
| Family/ID | Exact name | 原始 Disposition | 類型 | 設計合法狀態 | 個別功能 POS / I/O | 特定 NEG / first failure | Adapter ABI | Owner＋pin＋license＋退出 |
|---|---|---|---|---|---|---|---|---|
| NOBJ24/NOBJ-001 | HLPE Native PLAN/BOOTSTRAP/FACTORY | PORTABLE_REIMPLEMENTATION | NEEDS_DOMAIN_SPEC | DESIGN_CANDIDATE;QUALIFICATION_HOLD | HLPE Native PLAN/BOOTSTRAP/FACTORY:qualified Input→AdmissionFinding; identify documented capability and test [HLPE Native PLAN/BOOTSTRAP/FACTORY] on representative scoped input | HLPE Native PLAN/BOOTSTRAP/FACTORY: HLPE Native PLAN/BOOTSTRAP/FACTORY has no official contract or advertised outcome fails against controlled fixture | NEEDS_DOMAIN_SPEC.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §7` L274 ; SOURCE_DISPOSITION_PRESERVED; SCOPE_BY_OWNER; posi; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| NOBJ24/NOBJ-002 | Matt grill-with-docs | REFERENCE_METHOD_ONLY | Method | NO_AUTO_INSTALL_OR_DEPLOY | Matt grill-with-docs:qualified Input→MethodArtifact; route matching task to method skill and generate inspectable stage artifact | Matt grill-with-docs: inappropriate task triggers method or no source link | Method.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §7` L275 ; SOURCE_DISPOSITION_PRESERVED; SCOPE_BY_OWNER; posi; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| NOBJ24/NOBJ-003 | OpenSpec | TRANSLATE_AND_REUSE | SpecWorkflow | DESIGN_CANDIDATE;QUALIFICATION_HOLD | OpenSpec:qualified Input→SpecProposal; convert requirement change to versioned proposal and preserve non-goals | OpenSpec: unaffected requirement silently overwritten or proposal masquerades PI | SpecWorkflow.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §7` L276 ; SOURCE_DISPOSITION_PRESERVED; SCOPE_BY_OWNER; posi; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| NOBJ24/NOBJ-004 | Spec Kit | WRAP_WITH_ADAPTER | SpecWorkflow | DESIGN_CANDIDATE;QUALIFICATION_HOLD | Spec Kit:qualified Input→SpecProposal; convert requirement change to versioned proposal and preserve non-goals | Spec Kit: unaffected requirement silently overwritten or proposal masquerades PI | SpecWorkflow.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §7` L277 ; SOURCE_DISPOSITION_PRESERVED; SCOPE_BY_OWNER; posi; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| NOBJ24/NOBJ-005 | Superpowers test-driven-development | TRANSLATE_AND_REUSE | Method | DESIGN_CANDIDATE;QUALIFICATION_HOLD | Superpowers test-driven-development:qualified Input→MethodArtifact; route matching task to method skill and generate inspectable stage artifact | Superpowers test-driven-development: inappropriate task triggers method or no source link | Method.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §7` L278 ; SOURCE_DISPOSITION_PRESERVED; SCOPE_BY_OWNER; posi; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| NOBJ24/NOBJ-006 | Superpowers systematic-debugging | TRANSLATE_AND_REUSE | Method | DESIGN_CANDIDATE;QUALIFICATION_HOLD | Superpowers systematic-debugging:qualified Input→MethodArtifact; route matching task to method skill and generate inspectable stage artifact | Superpowers systematic-debugging: inappropriate task triggers method or no source link | Method.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §7` L279 ; SOURCE_DISPOSITION_PRESERVED; SCOPE_BY_OWNER; posi; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| NOBJ24/NOBJ-007 | Superpowers verification-before-completion | TRANSLATE_AND_REUSE | Method | DESIGN_CANDIDATE;QUALIFICATION_HOLD | Superpowers verification-before-completion:qualified Input→MethodArtifact; route matching task to method skill and generate inspectable stage artifact | Superpowers verification-before-completion: inappropriate task triggers method or no source link | Method.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §7` L280 ; SOURCE_DISPOSITION_PRESERVED; SCOPE_BY_OWNER; posi; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| NOBJ24/NOBJ-008 | GStack | REFERENCE_METHOD_ONLY | Method | NO_AUTO_INSTALL_OR_DEPLOY | GStack:qualified Input→MethodArtifact; route matching task to method skill and generate inspectable stage artifact | GStack: inappropriate task triggers method or no source link | Method.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §7` L281 ; SOURCE_DISPOSITION_PRESERVED; SCOPE_BY_OWNER; posi; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| NOBJ24/NOBJ-009 | GSD / planning-with-files | TRANSLATE_AND_REUSE | Method | DESIGN_CANDIDATE;QUALIFICATION_HOLD | GSD / planning-with-files:qualified Input→MethodArtifact; route matching task to method skill and generate inspectable stage artifact | GSD / planning-with-files: inappropriate task triggers method or no source link | Method.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §7` L282 ; SOURCE_DISPOSITION_PRESERVED; SCOPE_BY_OWNER; posi; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| NOBJ24/NOBJ-010 | AGENTS.md | PORTABLE_REIMPLEMENTATION | Instruction | DESIGN_CANDIDATE;QUALIFICATION_HOLD | AGENTS.md:qualified Input→InstructionLoadDecision; load instruction from stated trust scope and trigger only compatible host behavior | AGENTS.md: untrusted repo string grants extra tool permission | Instruction.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §7` L283 ; SOURCE_DISPOSITION_PRESERVED; SCOPE_BY_OWNER; posi; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| NOBJ24/NOBJ-011 | SKILL.md | PORTABLE_REIMPLEMENTATION | Instruction | DESIGN_CANDIDATE;QUALIFICATION_HOLD | SKILL.md:qualified Input→InstructionLoadDecision; load instruction from stated trust scope and trigger only compatible host behavior | SKILL.md: untrusted repo string grants extra tool permission | Instruction.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §7` L284 ; SOURCE_DISPOSITION_PRESERVED; SCOPE_BY_OWNER; posi; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| NOBJ24/NOBJ-012 | DESIGN.md | REFERENCE_METHOD_ONLY | SpecWorkflow | NO_AUTO_INSTALL_OR_DEPLOY | DESIGN.md:qualified Input→SpecProposal; convert requirement change to versioned proposal and preserve non-goals | DESIGN.md: unaffected requirement silently overwritten or proposal masquerades PI | SpecWorkflow.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §7` L285 ; SOURCE_DISPOSITION_PRESERVED; SCOPE_BY_OWNER; posi; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| NOBJ24/NOBJ-013 | Prompt projection | PORTABLE_REIMPLEMENTATION | Instruction | DESIGN_CANDIDATE;QUALIFICATION_HOLD | Prompt projection:qualified Input→InstructionLoadDecision; load instruction from stated trust scope and trigger only compatible host behavior | Prompt projection: untrusted repo string grants extra tool permission | Instruction.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §7` L286 ; SOURCE_DISPOSITION_PRESERVED; SCOPE_BY_OWNER; posi; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| NOBJ24/NOBJ-014 | OpenAI skill-creator | FALLBACK_ONLY | AgentHarness | DESIGN_CANDIDATE;QUALIFICATION_HOLD | OpenAI skill-creator:qualified Input→HarnessEvent; dispatch bounded read-only instruction to host and trace exact tool result | OpenAI skill-creator: unapproved effect or false independent principal | AgentHarness.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §7` L287 ; SOURCE_DISPOSITION_PRESERVED; SCOPE_BY_OWNER; posi; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| NOBJ24/NOBJ-015 | OpenAI plugin-creator | FALLBACK_ONLY | AgentHarness | DESIGN_CANDIDATE;QUALIFICATION_HOLD | OpenAI plugin-creator:qualified Input→HarnessEvent; dispatch bounded read-only instruction to host and trace exact tool result | OpenAI plugin-creator: unapproved effect or false independent principal | AgentHarness.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §7` L288 ; SOURCE_DISPOSITION_PRESERVED; SCOPE_BY_OWNER; posi; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| NOBJ24/NOBJ-016 | Agent Skills specification | REFERENCE_METHOD_ONLY | Instruction | NO_AUTO_INSTALL_OR_DEPLOY | Agent Skills specification:qualified Input→InstructionLoadDecision; load instruction from stated trust scope and trigger only compatible host behavior | Agent Skills specification: untrusted repo string grants extra tool permission | Instruction.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §7` L289 ; SOURCE_DISPOSITION_PRESERVED; SCOPE_BY_OWNER; posi; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| NOBJ24/NOBJ-017 | Agent Plugins 1.0 Working Draft | QUARANTINED | NEEDS_DOMAIN_SPEC | DESIGN_CANDIDATE;QUALIFICATION_HOLD | Agent Plugins 1.0 Working Draft:qualified Input→AdmissionFinding; identify documented capability and test [Agent Plugins 1.0 Working Draft] on representative scoped input | Agent Plugins 1.0 Working Draft: Agent Plugins 1.0 Working Draft has no official contract or advertised outcome fails against controlled fixture | NEEDS_DOMAIN_SPEC.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §7` L290 ; NO_ACTIVATION; OWNER_CR_REQUIRED; positive: source; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| NOBJ24/NOBJ-018 | JSON Schema 2020-12 | TRANSLATE_AND_REUSE | NEEDS_DOMAIN_SPEC | DESIGN_CANDIDATE;QUALIFICATION_HOLD | JSON Schema 2020-12:qualified Input→AdmissionFinding; identify documented capability and test [JSON Schema 2020-12] on representative scoped input | JSON Schema 2020-12: JSON Schema 2020-12 has no official contract or advertised outcome fails against controlled fixture | NEEDS_DOMAIN_SPEC.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §7` L291 ; SOURCE_DISPOSITION_PRESERVED; SCOPE_BY_OWNER; posi; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| NOBJ24/NOBJ-019 | pytest | ADOPT | TestQA | DESIGN_CANDIDATE;QUALIFICATION_HOLD | pytest:qualified Input→TestRun; run pinned positive and deliberately failing fixture with pass/fail counts | pytest: deliberately failing test returns zero evaluated cases or claimed PASS | TestQA.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §7` L292 ; SOURCE_DISPOSITION_PRESERVED; SCOPE_BY_OWNER; posi; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| NOBJ24/NOBJ-020 | GitHub Actions | WRAP_WITH_ADAPTER | CI | DESIGN_CANDIDATE;QUALIFICATION_HOLD | GitHub Actions:qualified Input→CIRun; evaluate repository supply-chain workflow on pinned ref and permissions | GitHub Actions: untrusted PR granted write token or artifact cannot be fetched | CI.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §7` L293 ; SOURCE_DISPOSITION_PRESERVED; SCOPE_BY_OWNER; posi; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| NOBJ24/NOBJ-021 | CycloneDX | WRAP_WITH_ADAPTER | SupplyChain | DESIGN_CANDIDATE;QUALIFICATION_HOLD | CycloneDX:qualified Input→SBOMDocument; generate component list bound to exact build digest | CycloneDX: insert a dependency and compare BOM; missing dep must fail completeness | SupplyChain.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §7` L294 ; SOURCE_DISPOSITION_PRESERVED; SCOPE_BY_OWNER; posi; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| NOBJ24/NOBJ-022 | Gitleaks | WRAP_WITH_ADAPTER | SecurityScan | DESIGN_CANDIDATE;QUALIFICATION_HOLD | Gitleaks:qualified Input→ScannerFinding; scan controlled fixture containing known vuln/secret and emit evidence | Gitleaks: known synthetic secret/CVE fixture silently treated clean | SecurityScan.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §7` L295 ; SOURCE_DISPOSITION_PRESERVED; SCOPE_BY_OWNER; posi; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| NOBJ24/NOBJ-023 | markdownlint | WRAP_WITH_ADAPTER | NEEDS_DOMAIN_SPEC | DESIGN_CANDIDATE;QUALIFICATION_HOLD | markdownlint:qualified Input→AdmissionFinding; identify documented capability and test [markdownlint] on representative scoped input | markdownlint: markdownlint has no official contract or advertised outcome fails against controlled fixture | NEEDS_DOMAIN_SPEC.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §7` L296 ; SOURCE_DISPOSITION_PRESERVED; SCOPE_BY_OWNER; posi; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| NOBJ24/NOBJ-024 | Ruff + type checker | WRAP_WITH_ADAPTER | CodeSecurity | DESIGN_CANDIDATE;QUALIFICATION_HOLD | Ruff + type checker:qualified Input→StaticAnalysisFinding; analyze repo source with configured queries, report finding locations | Ruff + type checker: inject known vulnerable or type-invalid code: expected nonzero finding and no clean label | CodeSecurity.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §7` L297 ; SOURCE_DISPOSITION_PRESERVED; SCOPE_BY_OWNER; posi; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| OSS19/341 | OpenTelemetry GenAI | ADOPT | Observability | DESIGN_CANDIDATE;QUALIFICATION_HOLD | OpenTelemetry GenAI:qualified Input→TelemetryTrace; emit trace/span/metric with subject reference and privacy filters | OpenTelemetry GenAI: missing span linkage or secret attribute exposed | Observability.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §8` L309 ; SOURCE_DISPOSITION_PRESERVED; SCOPE_BY_OWNER; posi; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| OSS19/342 | Spec Kit 1.1 patterns | BORROW_ADAPTER | SpecWorkflow | DESIGN_CANDIDATE;QUALIFICATION_HOLD | Spec Kit 1.1 patterns:qualified Input→SpecProposal; convert requirement change to versioned proposal and preserve non-goals | Spec Kit 1.1 patterns: unaffected requirement silently overwritten or proposal masquerades PI | SpecWorkflow.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §8` L310 ; SOURCE_DISPOSITION_PRESERVED; SCOPE_BY_OWNER; posi; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| OSS19/343 | LangGraph checkpoint tests | TEST_DONOR_ONLY | AgentHarness | DESIGN_CANDIDATE;QUALIFICATION_HOLD | LangGraph checkpoint tests:qualified Input→HarnessEvent; dispatch bounded read-only instruction to host and trace exact tool result | LangGraph checkpoint tests: unapproved effect or false independent principal | AgentHarness.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §8` L311 ; SOURCE_DISPOSITION_PRESERVED; SCOPE_BY_OWNER; posi; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| OSS19/344 | Groundability method | ADOPT_REVIEW_METHOD | NEEDS_DOMAIN_SPEC | DESIGN_CANDIDATE;QUALIFICATION_HOLD | Groundability method:qualified Input→AdmissionFinding; identify documented capability and test [Groundability method] on representative scoped input | Groundability method: Groundability method has no official contract or advertised outcome fails against controlled fixture | NEEDS_DOMAIN_SPEC.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §8` L312 ; SOURCE_DISPOSITION_PRESERVED; SCOPE_BY_OWNER; posi; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| OSS19/345 | Global Coherence | ADOPT_STATE_COMMIT_PRINCIPLE | NEEDS_DOMAIN_SPEC | DESIGN_CANDIDATE;QUALIFICATION_HOLD | Global Coherence:qualified Input→AdmissionFinding; identify documented capability and test [Global Coherence] on representative scoped input | Global Coherence: Global Coherence has no official contract or advertised outcome fails against controlled fixture | NEEDS_DOMAIN_SPEC.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §8` L313 ; SOURCE_DISPOSITION_PRESERVED; SCOPE_BY_OWNER; posi; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| OSS19/346 | Finding-the-Right-Fit | ADOPT_QUALIFICATION_METHOD | NEEDS_DOMAIN_SPEC | DESIGN_CANDIDATE;QUALIFICATION_HOLD | Finding-the-Right-Fit:qualified Input→AdmissionFinding; identify documented capability and test [Finding-the-Right-Fit] on representative scoped input | Finding-the-Right-Fit: Finding-the-Right-Fit has no official contract or advertised outcome fails against controlled fixture | NEEDS_DOMAIN_SPEC.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §8` L314 ; SOURCE_DISPOSITION_PRESERVED; SCOPE_BY_OWNER; posi; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| OSS19/347 | HF 6,204 trajectories | SECONDARY_CORPUS | NEEDS_DOMAIN_SPEC | DESIGN_CANDIDATE;QUALIFICATION_HOLD | HF 6,204 trajectories:qualified Input→AdmissionFinding; identify documented capability and test [HF 6,204 trajectories] on representative scoped input | HF 6,204 trajectories: HF 6,204 trajectories has no official contract or advertised outcome fails against controlled fixture | NEEDS_DOMAIN_SPEC.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §8` L315 ; SOURCE_DISPOSITION_PRESERVED; SCOPE_BY_OWNER; posi; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| OSS19/348 | Promptfoo | OPTIONAL_ATTACK_DONOR | TestQA | DESIGN_CANDIDATE;QUALIFICATION_HOLD | Promptfoo:qualified Input→TestRun; run pinned positive and deliberately failing fixture with pass/fail counts | Promptfoo: deliberately failing test returns zero evaluated cases or claimed PASS | TestQA.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §8` L316 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTALL; positive; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| OSS19/349 | Inspect AI | OPTIONAL_EVAL_RUNNER | TestQA | DESIGN_CANDIDATE;QUALIFICATION_HOLD | Inspect AI:qualified Input→TestRun; run pinned positive and deliberately failing fixture with pass/fail counts | Inspect AI: deliberately failing test returns zero evaluated cases or claimed PASS | TestQA.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §8` L317 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTALL; positive; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| OSS19/350 | Garak | OPTIONAL_SECURITY_PROBE_DONOR | NEEDS_DOMAIN_SPEC | DESIGN_CANDIDATE;QUALIFICATION_HOLD | Garak:qualified Input→AdmissionFinding; identify documented capability and test [Garak] on representative scoped input | Garak: Garak has no official contract or advertised outcome fails against controlled fixture | NEEDS_DOMAIN_SPEC.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §8` L318 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTALL; positive; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| OSS19/351 | Phoenix | OBSERVABILITY_CANDIDATE | Observability | DESIGN_CANDIDATE;QUALIFICATION_HOLD | Phoenix:qualified Input→TelemetryTrace; emit trace/span/metric with subject reference and privacy filters | Phoenix: missing span linkage or secret attribute exposed | Observability.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §8` L319 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTALL; positive; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| OSS19/352 | Langfuse | PHOENIX_COMPARISON_CANDIDATE | Observability | DESIGN_CANDIDATE;QUALIFICATION_HOLD | Langfuse:qualified Input→TelemetryTrace; emit trace/span/metric with subject reference and privacy filters | Langfuse: missing span linkage or secret attribute exposed | Observability.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §8` L320 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTALL; positive; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| OSS19/353 | LangGraph runtime | REJECT | AgentHarness | NO_AUTO_INSTALL_OR_DEPLOY | LangGraph runtime:qualified Input→HarnessEvent; dispatch bounded read-only instruction to host and trace exact tool result | LangGraph runtime: unapproved effect or false independent principal | AgentHarness.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §8` L321 ; NO_ACTIVATION; OWNER_CR_REQUIRED; positive: source; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| OSS19/354 | extra swarm framework | REJECT | NEEDS_DOMAIN_SPEC | NO_AUTO_INSTALL_OR_DEPLOY | extra swarm framework:qualified Input→AdmissionFinding; identify documented capability and test [extra swarm framework] on representative scoped input | extra swarm framework: extra swarm framework has no official contract or advertised outcome fails against controlled fixture | NEEDS_DOMAIN_SPEC.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §8` L322 ; NO_ACTIVATION; OWNER_CR_REQUIRED; positive: source; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| OSS19/355 | reviewer voting cluster | REJECT | NEEDS_DOMAIN_SPEC | NO_AUTO_INSTALL_OR_DEPLOY | reviewer voting cluster:qualified Input→AdmissionFinding; identify documented capability and test [reviewer voting cluster] on representative scoped input | reviewer voting cluster: reviewer voting cluster has no official contract or advertised outcome fails against controlled fixture | NEEDS_DOMAIN_SPEC.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §8` L323 ; NO_ACTIVATION; OWNER_CR_REQUIRED; positive: source; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| OSS19/356 | AutoCompact method | BORROW_METHOD | NEEDS_DOMAIN_SPEC | DESIGN_CANDIDATE;QUALIFICATION_HOLD | AutoCompact method:qualified Input→AdmissionFinding; identify documented capability and test [AutoCompact method] on representative scoped input | AutoCompact method: AutoCompact method has no official contract or advertised outcome fails against controlled fixture | NEEDS_DOMAIN_SPEC.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §8` L324 ; SOURCE_DISPOSITION_PRESERVED; SCOPE_BY_OWNER; posi; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| OSS19/357 | Harness Primitives / STITCH idea | ADOPT_METHOD | AgentHarness | DESIGN_CANDIDATE;QUALIFICATION_HOLD | Harness Primitives / STITCH idea:qualified Input→HarnessEvent; dispatch bounded read-only instruction to host and trace exact tool result | Harness Primitives / STITCH idea: unapproved effect or false independent principal | AgentHarness.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §8` L325 ; SOURCE_DISPOSITION_PRESERVED; SCOPE_BY_OWNER; posi; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| OSS19/358 | RuleEvolve | DEFER_SANDBOX | NEEDS_DOMAIN_SPEC | NO_AUTO_INSTALL_OR_DEPLOY | RuleEvolve:qualified Input→AdmissionFinding; identify documented capability and test [RuleEvolve] on representative scoped input | RuleEvolve: RuleEvolve has no official contract or advertised outcome fails against controlled fixture | NEEDS_DOMAIN_SPEC.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §8` L326 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTALL; positive; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| OSS19/359 | A2A for local subagents | DEFER | Protocol | NO_AUTO_INSTALL_OR_DEPLOY | A2A for local subagents:qualified Input→TransportEnvelope; schema-validate typed request/response with source-bound principal | A2A for local subagents: malformed payload or forged permission accepted | Protocol.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §8` L327 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTALL; positive; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| PD06_31/PD06-01 | Mem0 | OWNER_SOURCE_DISPOSITION_PENDING (r1 scan field MISSING_LITERAL) | DataKnowledge | DESIGN_CANDIDATE;QUALIFICATION_HOLD | Mem0:qualified Input→RetrievalRecord; upsert source-qualified record and retrieve correct version with provenance | Mem0: stale/source-unauthorized record returned as current | DataKnowledge.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §9` L341 ; OWNER_SELECT_AND_QUALIFY; UNVERIFIED; positive: so; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| PD06_31/PD06-02 | Letta | OWNER_SOURCE_DISPOSITION_PENDING (r1 scan field MISSING_LITERAL) | DataKnowledge | DESIGN_CANDIDATE;QUALIFICATION_HOLD | Letta:qualified Input→RetrievalRecord; upsert source-qualified record and retrieve correct version with provenance | Letta: stale/source-unauthorized record returned as current | DataKnowledge.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §9` L342 ; OWNER_SELECT_AND_QUALIFY; UNVERIFIED; positive: so; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| PD06_31/PD06-03 | LangGraph | OWNER_SOURCE_DISPOSITION_PENDING (r1 scan field MISSING_LITERAL) | AgentHarness | DESIGN_CANDIDATE;QUALIFICATION_HOLD | LangGraph:qualified Input→HarnessEvent; dispatch bounded read-only instruction to host and trace exact tool result | LangGraph: unapproved effect or false independent principal | AgentHarness.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §9` L343 ; OWNER_SELECT_AND_QUALIFY; UNVERIFIED; positive: so; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| PD06_31/PD06-04 | LlamaIndex | OWNER_SOURCE_DISPOSITION_PENDING (r1 scan field MISSING_LITERAL) | DataKnowledge | DESIGN_CANDIDATE;QUALIFICATION_HOLD | LlamaIndex:qualified Input→RetrievalRecord; upsert source-qualified record and retrieve correct version with provenance | LlamaIndex: stale/source-unauthorized record returned as current | DataKnowledge.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §9` L344 ; OWNER_SELECT_AND_QUALIFY; UNVERIFIED; positive: so; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| PD06_31/PD06-05 | Hermes Agent OS | OWNER_SOURCE_DISPOSITION_PENDING (r1 scan field MISSING_LITERAL) | AgentHarness | DESIGN_CANDIDATE;QUALIFICATION_HOLD | Hermes Agent OS:qualified Input→HarnessEvent; dispatch bounded read-only instruction to host and trace exact tool result | Hermes Agent OS: unapproved effect or false independent principal | AgentHarness.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §9` L345 ; OWNER_SELECT_AND_QUALIFY; UNVERIFIED; positive: so; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| PD06_31/PD06-06 | DeepSeek Harness | OWNER_SOURCE_DISPOSITION_PENDING (r1 scan field MISSING_LITERAL) | AgentHarness | DESIGN_CANDIDATE;QUALIFICATION_HOLD | DeepSeek Harness:qualified Input→HarnessEvent; dispatch bounded read-only instruction to host and trace exact tool result | DeepSeek Harness: unapproved effect or false independent principal | AgentHarness.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §9` L346 ; OWNER_SELECT_AND_QUALIFY; UNVERIFIED; positive: so; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| PD06_31/PD06-07 | Codex Harness / OpenAI Agents API | OWNER_SOURCE_DISPOSITION_PENDING (r1 scan field MISSING_LITERAL) | AgentHarness | DESIGN_CANDIDATE;QUALIFICATION_HOLD | Codex Harness / OpenAI Agents API:qualified Input→HarnessEvent; dispatch bounded read-only instruction to host and trace exact tool result | Codex Harness / OpenAI Agents API: unapproved effect or false independent principal | AgentHarness.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §9` L347 ; OWNER_SELECT_AND_QUALIFY; UNVERIFIED; positive: so; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| PD06_31/PD06-08 | Pi Agent Harness | OWNER_SOURCE_DISPOSITION_PENDING (r1 scan field MISSING_LITERAL) | AgentHarness | DESIGN_CANDIDATE;QUALIFICATION_HOLD | Pi Agent Harness:qualified Input→HarnessEvent; dispatch bounded read-only instruction to host and trace exact tool result | Pi Agent Harness: unapproved effect or false independent principal | AgentHarness.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §9` L348 ; OWNER_SELECT_AND_QUALIFY; UNVERIFIED; positive: so; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| PD06_31/PD06-09 | MCP | OWNER_SOURCE_DISPOSITION_PENDING (r1 scan field MISSING_LITERAL) | Protocol | DESIGN_CANDIDATE;QUALIFICATION_HOLD | MCP:qualified Input→TransportEnvelope; schema-validate typed request/response with source-bound principal | MCP: malformed payload or forged permission accepted | Protocol.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §9` L349 ; OWNER_SELECT_AND_QUALIFY; UNVERIFIED; positive: so; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| PD06_31/PD06-10 | A2A | OWNER_SOURCE_DISPOSITION_PENDING (r1 scan field FOUND_LITERAL) | Protocol | DESIGN_CANDIDATE;QUALIFICATION_HOLD | A2A:qualified Input→TransportEnvelope; schema-validate typed request/response with source-bound principal | A2A: malformed payload or forged permission accepted | Protocol.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §9` L350 ; OWNER_SELECT_AND_QUALIFY; UNVERIFIED; positive: so; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| PD06_31/PD06-11 | Agent Skills | OWNER_SOURCE_DISPOSITION_PENDING (r1 scan field MISSING_LITERAL) | Instruction | DESIGN_CANDIDATE;QUALIFICATION_HOLD | Agent Skills:qualified Input→InstructionLoadDecision; load instruction from stated trust scope and trigger only compatible host behavior | Agent Skills: untrusted repo string grants extra tool permission | Instruction.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §9` L351 ; OWNER_SELECT_AND_QUALIFY; UNVERIFIED; positive: so; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| PD06_31/PD06-12 | OpenTelemetry Semantic Conventions | OWNER_SOURCE_DISPOSITION_PENDING (r1 scan field MISSING_LITERAL) | Observability | DESIGN_CANDIDATE;QUALIFICATION_HOLD | OpenTelemetry Semantic Conventions:qualified Input→TelemetryTrace; emit trace/span/metric with subject reference and privacy filters | OpenTelemetry Semantic Conventions: missing span linkage or secret attribute exposed | Observability.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §9` L352 ; OWNER_SELECT_AND_QUALIFY; UNVERIFIED; positive: so; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| PD06_31/PD06-13 | OpenSpec | OWNER_SOURCE_DISPOSITION_PENDING (r1 scan field FOUND_LITERAL) | SpecWorkflow | DESIGN_CANDIDATE;QUALIFICATION_HOLD | OpenSpec:qualified Input→SpecProposal; convert requirement change to versioned proposal and preserve non-goals | OpenSpec: unaffected requirement silently overwritten or proposal masquerades PI | SpecWorkflow.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §9` L353 ; OWNER_SELECT_AND_QUALIFY; UNVERIFIED; positive: so; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| PD06_31/PD06-14 | GitHub Spec Kit | OWNER_SOURCE_DISPOSITION_PENDING (r1 scan field MISSING_LITERAL) | SpecWorkflow | DESIGN_CANDIDATE;QUALIFICATION_HOLD | GitHub Spec Kit:qualified Input→SpecProposal; convert requirement change to versioned proposal and preserve non-goals | GitHub Spec Kit: unaffected requirement silently overwritten or proposal masquerades PI | SpecWorkflow.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §9` L354 ; OWNER_SELECT_AND_QUALIFY; UNVERIFIED; positive: so; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| PD06_31/PD06-15 | gstack | OWNER_SOURCE_DISPOSITION_PENDING (r1 scan field MISSING_LITERAL) | Method | DESIGN_CANDIDATE;QUALIFICATION_HOLD | gstack:qualified Input→MethodArtifact; route matching task to method skill and generate inspectable stage artifact | gstack: inappropriate task triggers method or no source link | Method.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §9` L355 ; OWNER_SELECT_AND_QUALIFY; UNVERIFIED; positive: so; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| PD06_31/PD06-16 | GSD | OWNER_SOURCE_DISPOSITION_PENDING (r1 scan field MISSING_LITERAL) | Method | DESIGN_CANDIDATE;QUALIFICATION_HOLD | GSD:qualified Input→MethodArtifact; route matching task to method skill and generate inspectable stage artifact | GSD: inappropriate task triggers method or no source link | Method.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §9` L356 ; OWNER_SELECT_AND_QUALIFY; UNVERIFIED; positive: so; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| PD06_31/PD06-17 | Superpowers | OWNER_SOURCE_DISPOSITION_PENDING (r1 scan field MISSING_LITERAL) | Method | DESIGN_CANDIDATE;QUALIFICATION_HOLD | Superpowers:qualified Input→MethodArtifact; route matching task to method skill and generate inspectable stage artifact | Superpowers: inappropriate task triggers method or no source link | Method.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §9` L357 ; OWNER_SELECT_AND_QUALIFY; UNVERIFIED; positive: so; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| PD06_31/PD06-18 | mattpocock-skills | OWNER_SOURCE_DISPOSITION_PENDING (r1 scan field MISSING_LITERAL) | Method | DESIGN_CANDIDATE;QUALIFICATION_HOLD | mattpocock-skills:qualified Input→MethodArtifact; route matching task to method skill and generate inspectable stage artifact | mattpocock-skills: inappropriate task triggers method or no source link | Method.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §9` L358 ; OWNER_SELECT_AND_QUALIFY; UNVERIFIED; positive: so; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| PD06_31/PD06-19 | PostgreSQL | OWNER_SOURCE_DISPOSITION_PENDING (r1 scan field MISSING_LITERAL) | DataKnowledge | DESIGN_CANDIDATE;QUALIFICATION_HOLD | PostgreSQL:qualified Input→RetrievalRecord; upsert source-qualified record and retrieve correct version with provenance | PostgreSQL: stale/source-unauthorized record returned as current | DataKnowledge.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §9` L359 ; OWNER_SELECT_AND_QUALIFY; UNVERIFIED; positive: so; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| PD06_31/PD06-20 | SQLite | OWNER_SOURCE_DISPOSITION_PENDING (r1 scan field MISSING_LITERAL) | DataKnowledge | DESIGN_CANDIDATE;QUALIFICATION_HOLD | SQLite:qualified Input→RetrievalRecord; upsert source-qualified record and retrieve correct version with provenance | SQLite: stale/source-unauthorized record returned as current | DataKnowledge.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §9` L360 ; OWNER_SELECT_AND_QUALIFY; UNVERIFIED; positive: so; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| PD06_31/PD06-21 | Qdrant | OWNER_SOURCE_DISPOSITION_PENDING (r1 scan field MISSING_LITERAL) | DataKnowledge | DESIGN_CANDIDATE;QUALIFICATION_HOLD | Qdrant:qualified Input→RetrievalRecord; upsert source-qualified record and retrieve correct version with provenance | Qdrant: stale/source-unauthorized record returned as current | DataKnowledge.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §9` L361 ; OWNER_SELECT_AND_QUALIFY; UNVERIFIED; positive: so; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| PD06_31/PD06-22 | Neo4j | OWNER_SOURCE_DISPOSITION_PENDING (r1 scan field MISSING_LITERAL) | DataKnowledge | DESIGN_CANDIDATE;QUALIFICATION_HOLD | Neo4j:qualified Input→RetrievalRecord; upsert source-qualified record and retrieve correct version with provenance | Neo4j: stale/source-unauthorized record returned as current | DataKnowledge.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §9` L362 ; OWNER_SELECT_AND_QUALIFY; UNVERIFIED; positive: so; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| PD06_31/PD06-23 | Weaviate | OWNER_SOURCE_DISPOSITION_PENDING (r1 scan field MISSING_LITERAL) | DataKnowledge | DESIGN_CANDIDATE;QUALIFICATION_HOLD | Weaviate:qualified Input→RetrievalRecord; upsert source-qualified record and retrieve correct version with provenance | Weaviate: stale/source-unauthorized record returned as current | DataKnowledge.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §9` L363 ; OWNER_SELECT_AND_QUALIFY; UNVERIFIED; positive: so; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| PD06_31/PD06-24 | pgvector | OWNER_SOURCE_DISPOSITION_PENDING (r1 scan field MISSING_LITERAL) | DataKnowledge | DESIGN_CANDIDATE;QUALIFICATION_HOLD | pgvector:qualified Input→RetrievalRecord; upsert source-qualified record and retrieve correct version with provenance | pgvector: stale/source-unauthorized record returned as current | DataKnowledge.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §9` L364 ; OWNER_SELECT_AND_QUALIFY; UNVERIFIED; positive: so; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| PD06_31/PD06-25 | Redis | OWNER_SOURCE_DISPOSITION_PENDING (r1 scan field MISSING_LITERAL) | DataKnowledge | DESIGN_CANDIDATE;QUALIFICATION_HOLD | Redis:qualified Input→RetrievalRecord; upsert source-qualified record and retrieve correct version with provenance | Redis: stale/source-unauthorized record returned as current | DataKnowledge.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §9` L365 ; OWNER_SELECT_AND_QUALIFY; UNVERIFIED; positive: so; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| PD06_31/PD06-26 | Chroma | OWNER_SOURCE_DISPOSITION_PENDING (r1 scan field MISSING_LITERAL) | DataKnowledge | DESIGN_CANDIDATE;QUALIFICATION_HOLD | Chroma:qualified Input→RetrievalRecord; upsert source-qualified record and retrieve correct version with provenance | Chroma: stale/source-unauthorized record returned as current | DataKnowledge.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §9` L366 ; OWNER_SELECT_AND_QUALIFY; UNVERIFIED; positive: so; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| PD06_31/PD06-27 | Milvus | OWNER_SOURCE_DISPOSITION_PENDING (r1 scan field MISSING_LITERAL) | DataKnowledge | DESIGN_CANDIDATE;QUALIFICATION_HOLD | Milvus:qualified Input→RetrievalRecord; upsert source-qualified record and retrieve correct version with provenance | Milvus: stale/source-unauthorized record returned as current | DataKnowledge.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §9` L367 ; OWNER_SELECT_AND_QUALIFY; UNVERIFIED; positive: so; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| PD06_31/PD06-28 | Ragas | OWNER_SOURCE_DISPOSITION_PENDING (r1 scan field MISSING_LITERAL) | TestQA | DESIGN_CANDIDATE;QUALIFICATION_HOLD | Ragas:qualified Input→TestRun; run pinned positive and deliberately failing fixture with pass/fail counts | Ragas: deliberately failing test returns zero evaluated cases or claimed PASS | TestQA.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §9` L368 ; OWNER_SELECT_AND_QUALIFY; UNVERIFIED; positive: so; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| PD06_31/PD06-29 | DeepEval | OWNER_SOURCE_DISPOSITION_PENDING (r1 scan field MISSING_LITERAL) | TestQA | DESIGN_CANDIDATE;QUALIFICATION_HOLD | DeepEval:qualified Input→TestRun; run pinned positive and deliberately failing fixture with pass/fail counts | DeepEval: deliberately failing test returns zero evaluated cases or claimed PASS | TestQA.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §9` L369 ; OWNER_SELECT_AND_QUALIFY; UNVERIFIED; positive: so; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| PD06_31/PD06-30 | Arize Phoenix | OWNER_SOURCE_DISPOSITION_PENDING (r1 scan field MISSING_LITERAL) | Observability | DESIGN_CANDIDATE;QUALIFICATION_HOLD | Arize Phoenix:qualified Input→TelemetryTrace; emit trace/span/metric with subject reference and privacy filters | Arize Phoenix: missing span linkage or secret attribute exposed | Observability.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §9` L370 ; OWNER_SELECT_AND_QUALIFY; UNVERIFIED; positive: so; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| PD06_31/PD06-31 | Hindsight (DEFER_W4 unless exact mandatory W3 gap). | OWNER_SOURCE_DISPOSITION_PENDING (r1 scan field MISSING_LITERAL) | NEEDS_DOMAIN_SPEC | DESIGN_CANDIDATE;QUALIFICATION_HOLD | Hindsight (DEFER_W4 unless exact mandatory W3 gap).:qualified Input→AdmissionFinding; identify documented capability and test [Hindsight (DEFER_W4 unless exact mandatory W3 gap).] on representative scoped input | Hindsight (DEFER_W4 unless exact mandatory W3 gap).: Hindsight (DEFER_W4 unless exact mandatory W3 gap). has no official contract or advertised outcome fails against controlled fixture | NEEDS_DOMAIN_SPEC.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §9` L371 ; OWNER_SELECT_AND_QUALIFY; UNVERIFIED; positive: so; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| W3_TECH17/TECH-01 | TECH-01 Windows App SDK | OWNER_SOURCE_DISPOSITION_PENDING (r1 scan field MISSING_LITERAL) | Protocol | DESIGN_CANDIDATE;QUALIFICATION_HOLD | TECH-01 Windows App SDK:qualified Input→TransportEnvelope; schema-validate typed request/response with source-bound principal | TECH-01 Windows App SDK: malformed payload or forged permission accepted | Protocol.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §10` L381 ; OWNER_SELECT_AND_QUALIFY; UNVERIFIED; positive: s; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| W3_TECH17/TECH-02 | TECH-02 AppLifecycle + AppInstance | OWNER_SOURCE_DISPOSITION_PENDING (r1 scan field MISSING_LITERAL) | NEEDS_DOMAIN_SPEC | DESIGN_CANDIDATE;QUALIFICATION_HOLD | TECH-02 AppLifecycle + AppInstance:qualified Input→AdmissionFinding; identify documented capability and test [TECH-02 AppLifecycle + AppInstance] on representative scoped input | TECH-02 AppLifecycle + AppInstance: TECH-02 AppLifecycle + AppInstance has no official contract or advertised outcome fails against controlled fixture | NEEDS_DOMAIN_SPEC.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §10` L382 ; OWNER_SELECT_AND_QUALIFY; UNVERIFIED; positive: s; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| W3_TECH17/TECH-03 | TECH-03 IExplorerCommand / shell seam | OWNER_SOURCE_DISPOSITION_PENDING (r1 scan field MISSING_LITERAL) | NEEDS_DOMAIN_SPEC | DESIGN_CANDIDATE;QUALIFICATION_HOLD | TECH-03 IExplorerCommand / shell seam:qualified Input→AdmissionFinding; identify documented capability and test [TECH-03 IExplorerCommand / shell seam] on representative scoped input | TECH-03 IExplorerCommand / shell seam: TECH-03 IExplorerCommand / shell seam has no official contract or advertised outcome fails against controlled fixture | NEEDS_DOMAIN_SPEC.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §10` L383 ; OWNER_SELECT_AND_QUALIFY; UNVERIFIED; positive: s; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| W3_TECH17/TECH-04 | TECH-04 external-location / sparse package identity | OWNER_SOURCE_DISPOSITION_PENDING (r1 scan field MISSING_LITERAL) | NEEDS_DOMAIN_SPEC | DESIGN_CANDIDATE;QUALIFICATION_HOLD | TECH-04 external-location / sparse package identity:qualified Input→AdmissionFinding; identify documented capability and test [TECH-04 external-location / sparse package identity] on representative scoped input | TECH-04 external-location / sparse package identity: TECH-04 external-location / sparse package identity has no official contract or advertised outcome fails against controlled fixture | NEEDS_DOMAIN_SPEC.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §10` L384 ; OWNER_SELECT_AND_QUALIFY; UNVERIFIED; positive: s; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| W3_TECH17/TECH-05 | TECH-05 Full MSIX | OWNER_SOURCE_DISPOSITION_PENDING (r1 scan field MISSING_LITERAL) | Deployment | DESIGN_CANDIDATE;QUALIFICATION_HOLD | TECH-05 Full MSIX:qualified Input→InstallSession; install pinned dependency in isolated target and verify clean uninstall | TECH-05 Full MSIX: wrong OS/arch or residues treated healthy | Deployment.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §10` L385 ; OWNER_SELECT_AND_QUALIFY; UNVERIFIED; positive: s; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| W3_TECH17/TECH-06 | TECH-06 WinUI 3 | OWNER_SOURCE_DISPOSITION_PENDING (r1 scan field MISSING_LITERAL) | Deployment | DESIGN_CANDIDATE;QUALIFICATION_HOLD | TECH-06 WinUI 3:qualified Input→InstallSession; install pinned dependency in isolated target and verify clean uninstall | TECH-06 WinUI 3: wrong OS/arch or residues treated healthy | Deployment.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §10` L386 ; OWNER_SELECT_AND_QUALIFY; UNVERIFIED; positive: s; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| W3_TECH17/TECH-07 | TECH-07 Microsoft UI Automation | OWNER_SOURCE_DISPOSITION_PENDING (r1 scan field MISSING_LITERAL) | NEEDS_DOMAIN_SPEC | DESIGN_CANDIDATE;QUALIFICATION_HOLD | TECH-07 Microsoft UI Automation:qualified Input→AdmissionFinding; identify documented capability and test [TECH-07 Microsoft UI Automation] on representative scoped input | TECH-07 Microsoft UI Automation: TECH-07 Microsoft UI Automation has no official contract or advertised outcome fails against controlled fixture | NEEDS_DOMAIN_SPEC.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §10` L387 ; OWNER_SELECT_AND_QUALIFY; UNVERIFIED; positive: s; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| W3_TECH17/TECH-08 | TECH-08 AG-UI | OWNER_SOURCE_DISPOSITION_PENDING (r1 scan field MISSING_LITERAL) | Protocol | DESIGN_CANDIDATE;QUALIFICATION_HOLD | TECH-08 AG-UI:qualified Input→TransportEnvelope; schema-validate typed request/response with source-bound principal | TECH-08 AG-UI: malformed payload or forged permission accepted | Protocol.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §10` L388 ; OWNER_SELECT_AND_QUALIFY; UNVERIFIED; positive: s; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| W3_TECH17/TECH-09 | TECH-09 A2UI current production line | OWNER_SOURCE_DISPOSITION_PENDING (r1 scan field MISSING_LITERAL) | Protocol | DESIGN_CANDIDATE;QUALIFICATION_HOLD | TECH-09 A2UI current production line:qualified Input→TransportEnvelope; schema-validate typed request/response with source-bound principal | TECH-09 A2UI current production line: malformed payload or forged permission accepted | Protocol.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §10` L389 ; OWNER_SELECT_AND_QUALIFY; UNVERIFIED; positive: s; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| W3_TECH17/TECH-10 | TECH-10 A2UI next/candidate line | OWNER_SOURCE_DISPOSITION_PENDING (r1 scan field MISSING_LITERAL) | Protocol | DESIGN_CANDIDATE;QUALIFICATION_HOLD | TECH-10 A2UI next/candidate line:qualified Input→TransportEnvelope; schema-validate typed request/response with source-bound principal | TECH-10 A2UI next/candidate line: malformed payload or forged permission accepted | Protocol.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §10` L390 ; OWNER_SELECT_AND_QUALIFY; UNVERIFIED; positive: s; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| W3_TECH17/TECH-11 | TECH-11 OpenTelemetry Semantic Conventions | OWNER_SOURCE_DISPOSITION_PENDING (r1 scan field MISSING_LITERAL) | Observability | DESIGN_CANDIDATE;QUALIFICATION_HOLD | TECH-11 OpenTelemetry Semantic Conventions:qualified Input→TelemetryTrace; emit trace/span/metric with subject reference and privacy filters | TECH-11 OpenTelemetry Semantic Conventions: missing span linkage or secret attribute exposed | Observability.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §10` L391 ; OWNER_SELECT_AND_QUALIFY; UNVERIFIED; positive: s; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| W3_TECH17/TECH-12 | TECH-12 OpenTelemetry Session Semantics | OWNER_SOURCE_DISPOSITION_PENDING (r1 scan field MISSING_LITERAL) | Observability | DESIGN_CANDIDATE;QUALIFICATION_HOLD | TECH-12 OpenTelemetry Session Semantics:qualified Input→TelemetryTrace; emit trace/span/metric with subject reference and privacy filters | TECH-12 OpenTelemetry Session Semantics: missing span linkage or secret attribute exposed | Observability.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §10` L392 ; OWNER_SELECT_AND_QUALIFY; UNVERIFIED; positive: s; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| W3_TECH17/TECH-13 | TECH-13 MCP | OWNER_SOURCE_DISPOSITION_PENDING (r1 scan field MISSING_LITERAL) | Protocol | DESIGN_CANDIDATE;QUALIFICATION_HOLD | TECH-13 MCP:qualified Input→TransportEnvelope; schema-validate typed request/response with source-bound principal | TECH-13 MCP: malformed payload or forged permission accepted | Protocol.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §10` L393 ; OWNER_SELECT_AND_QUALIFY; UNVERIFIED; positive: s; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| W3_TECH17/TECH-14 | TECH-14 A2A | OWNER_SOURCE_DISPOSITION_PENDING (r1 scan field MISSING_LITERAL) | Protocol | DESIGN_CANDIDATE;QUALIFICATION_HOLD | TECH-14 A2A:qualified Input→TransportEnvelope; schema-validate typed request/response with source-bound principal | TECH-14 A2A: malformed payload or forged permission accepted | Protocol.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §10` L394 ; OWNER_SELECT_AND_QUALIFY; UNVERIFIED; positive: s; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| W3_TECH17/TECH-15 | TECH-15 OpenAI Agents SDK HITL / resumable-state donor pattern | OWNER_SOURCE_DISPOSITION_PENDING (r1 scan field MISSING_LITERAL) | Protocol | DESIGN_CANDIDATE;QUALIFICATION_HOLD | TECH-15 OpenAI Agents SDK HITL / resumable-state donor pattern:qualified Input→TransportEnvelope; schema-validate typed request/response with source-bound principal | TECH-15 OpenAI Agents SDK HITL / resumable-state donor pattern: malformed payload or forged permission accepted | Protocol.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §10` L395 ; OWNER_SELECT_AND_QUALIFY; UNVERIFIED; positive: s; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| W3_TECH17/TECH-16 | TECH-16 Windows named pipe | OWNER_SOURCE_DISPOSITION_PENDING (r1 scan field MISSING_LITERAL) | Protocol | DESIGN_CANDIDATE;QUALIFICATION_HOLD | TECH-16 Windows named pipe:qualified Input→TransportEnvelope; schema-validate typed request/response with source-bound principal | TECH-16 Windows named pipe: malformed payload or forged permission accepted | Protocol.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §10` L396 ; OWNER_SELECT_AND_QUALIFY; UNVERIFIED; positive: s; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| W3_TECH17/TECH-17 | TECH-17 Electron / Tauri alternate host (DEFER_BY_BLOCKER). | OWNER_SOURCE_DISPOSITION_PENDING (r1 scan field MISSING_LITERAL) | Deployment | DESIGN_CANDIDATE;QUALIFICATION_HOLD | TECH-17 Electron / Tauri alternate host (DEFER_BY_BLOCKER).:qualified Input→InstallSession; install pinned dependency in isolated target and verify clean uninstall | TECH-17 Electron / Tauri alternate host (DEFER_BY_BLOCKER).: wrong OS/arch or residues treated healthy | Deployment.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §10` L397 ; OWNER_SELECT_AND_QUALIFY; UNVERIFIED; positive: s; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| SUPPLY17/SUPPLY-01 | Syft | OWNER_SOURCE_DISPOSITION_PENDING (r1 scan field MISSING_LITERAL) | SupplyChain | DESIGN_CANDIDATE;QUALIFICATION_HOLD | Syft:qualified Input→SBOMDocument; generate component list bound to exact build digest | Syft: insert a dependency and compare BOM; missing dep must fail completeness | SupplyChain.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §10` L403 ; OWNER_SELECT_AND_QUALIFY; UNVERIFIED; positive: s; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| SUPPLY17/SUPPLY-02 | Trivy | OWNER_SOURCE_DISPOSITION_PENDING (r1 scan field MISSING_LITERAL) | SecurityScan | DESIGN_CANDIDATE;QUALIFICATION_HOLD | Trivy:qualified Input→ScannerFinding; scan controlled fixture containing known vuln/secret and emit evidence | Trivy: known synthetic secret/CVE fixture silently treated clean | SecurityScan.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §10` L404 ; OWNER_SELECT_AND_QUALIFY; UNVERIFIED; positive: s; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| SUPPLY17/SUPPLY-03 | Grype | OWNER_SOURCE_DISPOSITION_PENDING (r1 scan field MISSING_LITERAL) | SecurityScan | DESIGN_CANDIDATE;QUALIFICATION_HOLD | Grype:qualified Input→ScannerFinding; scan controlled fixture containing known vuln/secret and emit evidence | Grype: known synthetic secret/CVE fixture silently treated clean | SecurityScan.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §10` L405 ; OWNER_SELECT_AND_QUALIFY; UNVERIFIED; positive: s; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| SUPPLY17/SUPPLY-04 | OSV-Scanner | OWNER_SOURCE_DISPOSITION_PENDING (r1 scan field MISSING_LITERAL) | SecurityScan | DESIGN_CANDIDATE;QUALIFICATION_HOLD | OSV-Scanner:qualified Input→ScannerFinding; scan controlled fixture containing known vuln/secret and emit evidence | OSV-Scanner: known synthetic secret/CVE fixture silently treated clean | SecurityScan.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §10` L406 ; OWNER_SELECT_AND_QUALIFY; UNVERIFIED; positive: s; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| SUPPLY17/SUPPLY-05 | Cosign | OWNER_SOURCE_DISPOSITION_PENDING (r1 scan field MISSING_LITERAL) | SupplyChain | DESIGN_CANDIDATE;QUALIFICATION_HOLD | Cosign:qualified Input→AttestationDecision; verify subject digest, signer/trust root and provenance before publishing | Cosign: tampered blob or mismatched signer: must reject verification | SupplyChain.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §10` L407 ; OWNER_SELECT_AND_QUALIFY; UNVERIFIED; positive: s; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| SUPPLY17/SUPPLY-06 | Semgrep | OWNER_SOURCE_DISPOSITION_PENDING (r1 scan field MISSING_LITERAL) | CodeSecurity | DESIGN_CANDIDATE;QUALIFICATION_HOLD | Semgrep:qualified Input→StaticAnalysisFinding; analyze repo source with configured queries, report finding locations | Semgrep: inject known vulnerable or type-invalid code: expected nonzero finding and no clean label | CodeSecurity.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §10` L408 ; OWNER_SELECT_AND_QUALIFY; UNVERIFIED; positive: s; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| SUPPLY17/SUPPLY-07 | Gitleaks | OWNER_SOURCE_DISPOSITION_PENDING (r1 scan field MISSING_LITERAL) | SecurityScan | DESIGN_CANDIDATE;QUALIFICATION_HOLD | Gitleaks:qualified Input→ScannerFinding; scan controlled fixture containing known vuln/secret and emit evidence | Gitleaks: known synthetic secret/CVE fixture silently treated clean | SecurityScan.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §10` L409 ; OWNER_SELECT_AND_QUALIFY; UNVERIFIED; positive: s; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| SUPPLY17/SUPPLY-08 | OPA/Rego | OWNER_SOURCE_DISPOSITION_PENDING (r1 scan field MISSING_LITERAL) | NEEDS_DOMAIN_SPEC | DESIGN_CANDIDATE;QUALIFICATION_HOLD | OPA/Rego:qualified Input→AdmissionFinding; identify documented capability and test [OPA/Rego] on representative scoped input | OPA/Rego: OPA/Rego has no official contract or advertised outcome fails against controlled fixture | NEEDS_DOMAIN_SPEC.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §10` L410 ; OWNER_SELECT_AND_QUALIFY; UNVERIFIED; positive: s; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| SUPPLY17/SUPPLY-09 | OpenTelemetry Collector | OWNER_SOURCE_DISPOSITION_PENDING (r1 scan field MISSING_LITERAL) | Observability | DESIGN_CANDIDATE;QUALIFICATION_HOLD | OpenTelemetry Collector:qualified Input→TelemetryTrace; emit trace/span/metric with subject reference and privacy filters | OpenTelemetry Collector: missing span linkage or secret attribute exposed | Observability.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §10` L411 ; OWNER_SELECT_AND_QUALIFY; UNVERIFIED; positive: s; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| SUPPLY17/SUPPLY-10 | SPDX | OWNER_SOURCE_DISPOSITION_PENDING (r1 scan field MISSING_LITERAL) | SupplyChain | DESIGN_CANDIDATE;QUALIFICATION_HOLD | SPDX:qualified Input→SBOMDocument; generate component list bound to exact build digest | SPDX: insert a dependency and compare BOM; missing dep must fail completeness | SupplyChain.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §10` L412 ; OWNER_SELECT_AND_QUALIFY; UNVERIFIED; positive: s; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| SUPPLY17/SUPPLY-11 | CycloneDX | OWNER_SOURCE_DISPOSITION_PENDING (r1 scan field MISSING_LITERAL) | SupplyChain | DESIGN_CANDIDATE;QUALIFICATION_HOLD | CycloneDX:qualified Input→SBOMDocument; generate component list bound to exact build digest | CycloneDX: insert a dependency and compare BOM; missing dep must fail completeness | SupplyChain.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §10` L413 ; OWNER_SELECT_AND_QUALIFY; UNVERIFIED; positive: s; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| SUPPLY17/SUPPLY-12 | TUF | OWNER_SOURCE_DISPOSITION_PENDING (r1 scan field MISSING_LITERAL) | SupplyChain | DESIGN_CANDIDATE;QUALIFICATION_HOLD | TUF:qualified Input→AttestationDecision; verify subject digest, signer/trust root and provenance before publishing | TUF: tampered blob or mismatched signer: must reject verification | SupplyChain.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §10` L414 ; OWNER_SELECT_AND_QUALIFY; UNVERIFIED; positive: s; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| SUPPLY17/SUPPLY-13 | OpenSSF Scorecard | OWNER_SOURCE_DISPOSITION_PENDING (r1 scan field FOUND_LITERAL) | CI | DESIGN_CANDIDATE;QUALIFICATION_HOLD | OpenSSF Scorecard:qualified Input→CIRun; evaluate repository supply-chain workflow on pinned ref and permissions | OpenSSF Scorecard: untrusted PR granted write token or artifact cannot be fetched | CI.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §10` L415 ; OWNER_SELECT_AND_QUALIFY; UNVERIFIED; positive: s; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| SUPPLY17/SUPPLY-14 | GitHub Artifact Attestations | OWNER_SOURCE_DISPOSITION_PENDING (r1 scan field FOUND_LITERAL) | SupplyChain | DESIGN_CANDIDATE;QUALIFICATION_HOLD | GitHub Artifact Attestations:qualified Input→AttestationDecision; verify subject digest, signer/trust root and provenance before publishing | GitHub Artifact Attestations: tampered blob or mismatched signer: must reject verification | SupplyChain.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §10` L416 ; OWNER_SELECT_AND_QUALIFY; UNVERIFIED; positive: s; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| SUPPLY17/SUPPLY-15 | ORAS | OWNER_SOURCE_DISPOSITION_PENDING (r1 scan field MISSING_LITERAL) | CI | DESIGN_CANDIDATE;QUALIFICATION_HOLD | ORAS:qualified Input→CIRun; evaluate repository supply-chain workflow on pinned ref and permissions | ORAS: untrusted PR granted write token or artifact cannot be fetched | CI.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §10` L417 ; OWNER_SELECT_AND_QUALIFY; UNVERIFIED; positive: s; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| SUPPLY17/SUPPLY-16 | Harbor | OWNER_SOURCE_DISPOSITION_PENDING (r1 scan field MISSING_LITERAL) | CI | DESIGN_CANDIDATE;QUALIFICATION_HOLD | Harbor:qualified Input→CIRun; evaluate repository supply-chain workflow on pinned ref and permissions | Harbor: untrusted PR granted write token or artifact cannot be fetched | CI.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §10` L418 ; OWNER_SELECT_AND_QUALIFY; UNVERIFIED; positive: s; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| SUPPLY17/SUPPLY-17 | GitHub Actions/OIDC. | OWNER_SOURCE_DISPOSITION_PENDING (r1 scan field MISSING_LITERAL) | CI | DESIGN_CANDIDATE;QUALIFICATION_HOLD | GitHub Actions/OIDC.:qualified Input→CIRun; evaluate repository supply-chain workflow on pinned ref and permissions | GitHub Actions/OIDC.: untrusted PR granted write token or artifact cannot be fetched | CI.Adapter@design-v1; no new Canonical Writer | Owner scope=`R2 §10` L419 ; OWNER_SELECT_AND_QUALIFY; UNVERIFIED; positive: s; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-001 | Hermes Agent | upstream=CORE` / `global_orchestration; disposition=DEFAULT_ENABLED_AFTER_QUALIFICATION; observed=TARGET_CONTRACT_DEFINED / OBSERVED_NOT_INSTALLED; runtime=NOT_EXECUTED | AgentHarness | DESIGN_CANDIDATE;QUALIFICATION_HOLD | Hermes Agent:qualified Input→HarnessEvent; dispatch bounded read-only instruction to host and trace exact tool result | Hermes Agent: unapproved effect or false independent principal | AgentHarness.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L799 ; SOURCE_DISPOSITION_PRESERVED; SCOPE_BY_; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-002 | SDLC_PRW | upstream=CORE` / `shared_spine; disposition=DEFAULT_ENABLED_AFTER_QUALIFICATION; observed=TARGET_CONTRACT_DEFINED / OBSERVED_NOT_INSTALLED; runtime=NOT_EXECUTED | NEEDS_DOMAIN_SPEC | DESIGN_CANDIDATE;QUALIFICATION_HOLD | SDLC_PRW:qualified Input→AdmissionFinding; identify documented capability and test [SDLC_PRW] on representative scoped input | SDLC_PRW: SDLC_PRW has no official contract or advertised outcome fails against controlled fixture | NEEDS_DOMAIN_SPEC.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L800 ; SOURCE_DISPOSITION_PRESERVED; SCOPE_BY_; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-003 | SRU Kernel | upstream=CORE` / `shared_spine; disposition=DEFAULT_ENABLED_AFTER_QUALIFICATION; observed=TARGET_CONTRACT_DEFINED / OBSERVED_NOT_INSTALLED; runtime=NOT_EXECUTED | NEEDS_DOMAIN_SPEC | DESIGN_CANDIDATE;QUALIFICATION_HOLD | SRU Kernel:qualified Input→AdmissionFinding; identify documented capability and test [SRU Kernel] on representative scoped input | SRU Kernel: SRU Kernel has no official contract or advertised outcome fails against controlled fixture | NEEDS_DOMAIN_SPEC.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L801 ; SOURCE_DISPOSITION_PRESERVED; SCOPE_BY_; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-004 | DocETL | upstream=PRIMARY_ADAPTER` / `knowledge.K05-K08; disposition=DEFAULT_ENABLED_AFTER_QUALIFICATION; observed=TARGET_CONTRACT_DEFINED / OBSERVED_NOT_INSTALLED; runtime=NOT_EXECUTED | NEEDS_DOMAIN_SPEC | DESIGN_CANDIDATE;QUALIFICATION_HOLD | DocETL:qualified Input→AdmissionFinding; identify documented capability and test [DocETL] on representative scoped input | DocETL: DocETL has no official contract or advertised outcome fails against controlled fixture | NEEDS_DOMAIN_SPEC.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L802 ; SOURCE_DISPOSITION_PRESERVED; SCOPE_BY_; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-005 | Codex | upstream=CORE` / `coding.primary; disposition=DEFAULT_ENABLED_AFTER_QUALIFICATION; observed=TARGET_CONTRACT_DEFINED / OBSERVED_NOT_INSTALLED; runtime=NOT_EXECUTED | AgentHarness | DESIGN_CANDIDATE;QUALIFICATION_HOLD | Codex:qualified Input→HarnessEvent; dispatch bounded read-only instruction to host and trace exact tool result | Codex: unapproved effect or false independent principal | AgentHarness.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L803 ; SOURCE_DISPOSITION_PRESERVED; SCOPE_BY_; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-006 | OpenCode | upstream=PRIMARY_ADAPTER` / `coding.fallback_or_independent_review; disposition=DEFAULT_ENABLED_AFTER_QUALIFICATION; observed=TARGET_CONTRACT_DEFINED / OBSERVED_NOT_INSTALLED; runtime=NOT_EXECUTED | NEEDS_DOMAIN_SPEC | DESIGN_CANDIDATE;QUALIFICATION_HOLD | OpenCode:qualified Input→AdmissionFinding; identify documented capability and test [OpenCode] on representative scoped input | OpenCode: OpenCode has no official contract or advertised outcome fails against controlled fixture | NEEDS_DOMAIN_SPEC.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L804 ; SOURCE_DISPOSITION_PRESERVED; SCOPE_BY_; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-007 | Obsidian | upstream=OPTIONAL` / `knowledge.human_ui; disposition=MERGED_ALIAS_WITH_CANONICAL_ID; observed=ADMISSION_BLOCKED_IDENTITY_UNRESOLVED; runtime=NOT_EXECUTED | NEEDS_DOMAIN_SPEC | DESIGN_CANDIDATE;QUALIFICATION_HOLD | Obsidian:qualified Input→AdmissionFinding; identify documented capability and test [Obsidian] on representative scoped input | Obsidian: Obsidian has no official contract or advertised outcome fails against controlled fixture | NEEDS_DOMAIN_SPEC.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L805 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTAL; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-008 | LLM Wiki | upstream=PRIMARY_ADAPTER` / `knowledge.K09.wiki_compiler; disposition=DEFAULT_ENABLED_AFTER_QUALIFICATION; observed=TARGET_CONTRACT_DEFINED / OBSERVED_NOT_INSTALLED; runtime=NOT_EXECUTED | NEEDS_DOMAIN_SPEC | DESIGN_CANDIDATE;QUALIFICATION_HOLD | LLM Wiki:qualified Input→AdmissionFinding; identify documented capability and test [LLM Wiki] on representative scoped input | LLM Wiki: LLM Wiki has no official contract or advertised outcome fails against controlled fixture | NEEDS_DOMAIN_SPEC.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L806 ; SOURCE_DISPOSITION_PRESERVED; SCOPE_BY_; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-009 | Typed Knowledge Graph | upstream=PILOT` / `knowledge.K09.graph_candidate; disposition=ADAPTED; observed=TARGET_CONTRACT_DEFINED / OBSERVED_NOT_INSTALLED; runtime=NOT_EXECUTED | NEEDS_DOMAIN_SPEC | DESIGN_CANDIDATE;QUALIFICATION_HOLD | Typed Knowledge Graph:qualified Input→AdmissionFinding; identify documented capability and test [Typed Knowledge Graph] on representative scoped input | Typed Knowledge Graph: Typed Knowledge Graph has no official contract or advertised outcome fails against controlled fixture | NEEDS_DOMAIN_SPEC.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L807 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTAL; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-010 | Spec Kit | upstream=PRIMARY_ADAPTER` / `engineering_definition.greenfield; disposition=DEFAULT_ENABLED_AFTER_QUALIFICATION; observed=TARGET_CONTRACT_DEFINED / OBSERVED_NOT_INSTALLED; runtime=NOT_EXECUTED | SpecWorkflow | DESIGN_CANDIDATE;QUALIFICATION_HOLD | Spec Kit:qualified Input→SpecProposal; convert requirement change to versioned proposal and preserve non-goals | Spec Kit: unaffected requirement silently overwritten or proposal masquerades PI | SpecWorkflow.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L808 ; SOURCE_DISPOSITION_PRESERVED; SCOPE_BY_; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-011 | OpenSpec | upstream=PRIMARY_ADAPTER` / `engineering_definition.brownfield; disposition=DEFAULT_ENABLED_AFTER_QUALIFICATION; observed=TARGET_CONTRACT_DEFINED / OBSERVED_NOT_INSTALLED; runtime=NOT_EXECUTED | SpecWorkflow | DESIGN_CANDIDATE;QUALIFICATION_HOLD | OpenSpec:qualified Input→SpecProposal; convert requirement change to versioned proposal and preserve non-goals | OpenSpec: unaffected requirement silently overwritten or proposal masquerades PI | SpecWorkflow.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L809 ; SOURCE_DISPOSITION_PRESERVED; SCOPE_BY_; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-012 | GSD Core | upstream=OPTIONAL` / `coding.long_loop_optional; disposition=DEFERRED_BY_EVIDENCE; observed=ADMISSION_BLOCKED_IDENTITY_UNRESOLVED; runtime=NOT_EXECUTED | Method | NO_AUTO_INSTALL_OR_DEPLOY | GSD Core:qualified Input→MethodArtifact; route matching task to method skill and generate inspectable stage artifact | GSD Core: inappropriate task triggers method or no source link | Method.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L810 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTAL; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-013 | GSD Pi | upstream=BENCHMARK` / `harness.benchmark; disposition=DEFERRED_BY_EVIDENCE; observed=BLOCKED_OR_REFERENCE_ONLY; runtime=NOT_EXECUTED | Method | NO_AUTO_INSTALL_OR_DEPLOY | GSD Pi:qualified Input→MethodArtifact; route matching task to method skill and generate inspectable stage artifact | GSD Pi: inappropriate task triggers method or no source link | Method.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L811 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTAL; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-014 | get-shit-done | upstream=LEGACY` / `blocked_legacy; disposition=DEFERRED_BY_EVIDENCE; observed=BLOCKED_OR_REFERENCE_ONLY; runtime=NOT_EXECUTED | NEEDS_DOMAIN_SPEC | NO_AUTO_INSTALL_OR_DEPLOY | get-shit-done:qualified Input→AdmissionFinding; identify documented capability and test [get-shit-done] on representative scoped input | get-shit-done: get-shit-done has no official contract or advertised outcome fails against controlled fixture | NEEDS_DOMAIN_SPEC.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L812 ; NO_ACTIVATION; OWNER_CR_REQUIRED; posit; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-015 | gsd-2 | upstream=LEGACY` / `blocked_legacy; disposition=DEFERRED_BY_EVIDENCE; observed=BLOCKED_OR_REFERENCE_ONLY; runtime=NOT_EXECUTED | Method | NO_AUTO_INSTALL_OR_DEPLOY | gsd-2:qualified Input→MethodArtifact; route matching task to method skill and generate inspectable stage artifact | gsd-2: inappropriate task triggers method or no source link | Method.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L813 ; NO_ACTIVATION; OWNER_CR_REQUIRED; posit; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-016 | mattpocock-skills v1.1 | upstream=PRIMARY_ADAPTER` / `engineering_definition.interview_spec_handoff; disposition=DEFAULT_ENABLED_AFTER_QUALIFICATION; observed=TARGET_CONTRACT_DEFINED / OBSERVED_NOT_INSTALLED; runtime=NOT_EXECUTED | Method | DESIGN_CANDIDATE;QUALIFICATION_HOLD | mattpocock-skills v1.1:qualified Input→MethodArtifact; route matching task to method skill and generate inspectable stage artifact | mattpocock-skills v1.1: inappropriate task triggers method or no source link | Method.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L814 ; SOURCE_DISPOSITION_PRESERVED; SCOPE_BY_; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-017 | Grill Me | upstream=PRIMARY_ADAPTER` / `engineering_definition.interview; disposition=DEFAULT_ENABLED_AFTER_QUALIFICATION; observed=TARGET_CONTRACT_DEFINED / OBSERVED_NOT_INSTALLED; runtime=NOT_EXECUTED | Method | DESIGN_CANDIDATE;QUALIFICATION_HOLD | Grill Me:qualified Input→MethodArtifact; route matching task to method skill and generate inspectable stage artifact | Grill Me: inappropriate task triggers method or no source link | Method.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L815 ; SOURCE_DISPOSITION_PRESERVED; SCOPE_BY_; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-018 | grill-with-docs | upstream=OPTIONAL` / `engineering_definition.interview_candidate_write; disposition=MERGED_ALIAS_WITH_CANONICAL_ID; observed=ADMISSION_BLOCKED_IDENTITY_UNRESOLVED; runtime=NOT_EXECUTED | Method | DESIGN_CANDIDATE;QUALIFICATION_HOLD | grill-with-docs:qualified Input→MethodArtifact; route matching task to method skill and generate inspectable stage artifact | grill-with-docs: inappropriate task triggers method or no source link | Method.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L816 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTAL; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-019 | planning-with-files | upstream=OPTIONAL` / `engineering_definition.ephemeral_progress; disposition=DEFERRED_BY_EVIDENCE; observed=ADMISSION_BLOCKED_IDENTITY_UNRESOLVED; runtime=NOT_EXECUTED | Method | NO_AUTO_INSTALL_OR_DEPLOY | planning-with-files:qualified Input→MethodArtifact; route matching task to method skill and generate inspectable stage artifact | planning-with-files: inappropriate task triggers method or no source link | Method.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L817 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTAL; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-020 | Superpowers | upstream=PRIMARY_ADAPTER` / `coding.implementation_discipline; disposition=DEFAULT_ENABLED_AFTER_QUALIFICATION; observed=TARGET_CONTRACT_DEFINED / OBSERVED_NOT_INSTALLED; runtime=NOT_EXECUTED | Method | DESIGN_CANDIDATE;QUALIFICATION_HOLD | Superpowers:qualified Input→MethodArtifact; route matching task to method skill and generate inspectable stage artifact | Superpowers: inappropriate task triggers method or no source link | Method.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L818 ; SOURCE_DISPOSITION_PRESERVED; SCOPE_BY_; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-021 | gstack | upstream=OPTIONAL` / `coding.quality_method_donor; disposition=MERGED_ALIAS_WITH_CANONICAL_ID; observed=ADMISSION_BLOCKED_IDENTITY_UNRESOLVED; runtime=NOT_EXECUTED | Method | DESIGN_CANDIDATE;QUALIFICATION_HOLD | gstack:qualified Input→MethodArtifact; route matching task to method skill and generate inspectable stage artifact | gstack: inappropriate task triggers method or no source link | Method.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L819 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTAL; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-022 | Nature Skills | upstream=OPTIONAL` / `research.optional; disposition=DEFERRED_BY_EVIDENCE; observed=ADMISSION_BLOCKED_IDENTITY_UNRESOLVED; runtime=NOT_EXECUTED | NEEDS_DOMAIN_SPEC | NO_AUTO_INSTALL_OR_DEPLOY | Nature Skills:qualified Input→AdmissionFinding; identify documented capability and test [Nature Skills] on representative scoped input | Nature Skills: Nature Skills has no official contract or advertised outcome fails against controlled fixture | NEEDS_DOMAIN_SPEC.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L820 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTAL; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-023 | Zotero | upstream=OPTIONAL` / `research.optional; disposition=DEFERRED_BY_EVIDENCE; observed=ADMISSION_BLOCKED_IDENTITY_UNRESOLVED; runtime=NOT_EXECUTED | NEEDS_DOMAIN_SPEC | NO_AUTO_INSTALL_OR_DEPLOY | Zotero:qualified Input→AdmissionFinding; identify documented capability and test [Zotero] on representative scoped input | Zotero: Zotero has no official contract or advertised outcome fails against controlled fixture | NEEDS_DOMAIN_SPEC.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L821 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTAL; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-024 | Agent Skills | upstream=CORE` / `components.skill_package; disposition=DEFAULT_ENABLED_AFTER_QUALIFICATION; observed=TARGET_CONTRACT_DEFINED / OBSERVED_NOT_INSTALLED; runtime=NOT_EXECUTED | Instruction | DESIGN_CANDIDATE;QUALIFICATION_HOLD | Agent Skills:qualified Input→InstructionLoadDecision; load instruction from stated trust scope and trigger only compatible host behavior | Agent Skills: untrusted repo string grants extra tool permission | Instruction.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L822 ; SOURCE_DISPOSITION_PRESERVED; SCOPE_BY_; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-025 | Model Context Protocol | upstream=PRIMARY_ADAPTER` / `components.tool_gateway; disposition=DEFAULT_ENABLED_AFTER_QUALIFICATION; observed=TARGET_CONTRACT_DEFINED / OBSERVED_NOT_INSTALLED; runtime=NOT_EXECUTED | Protocol | DESIGN_CANDIDATE;QUALIFICATION_HOLD | Model Context Protocol:qualified Input→TransportEnvelope; schema-validate typed request/response with source-bound principal | Model Context Protocol: malformed payload or forged permission accepted | Protocol.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L823 ; SOURCE_DISPOSITION_PRESERVED; SCOPE_BY_; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-026 | AGENTS.md | upstream=CORE` / `components.codex_surface; disposition=DEFAULT_ENABLED_AFTER_QUALIFICATION; observed=TARGET_CONTRACT_DEFINED / OBSERVED_NOT_INSTALLED; runtime=NOT_EXECUTED | Instruction | DESIGN_CANDIDATE;QUALIFICATION_HOLD | AGENTS.md:qualified Input→InstructionLoadDecision; load instruction from stated trust scope and trigger only compatible host behavior | AGENTS.md: untrusted repo string grants extra tool permission | Instruction.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L824 ; SOURCE_DISPOSITION_PRESERVED; SCOPE_BY_; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-027 | CLAUDE.md | upstream=OPTIONAL` / `components.compat_surface; disposition=DEFERRED_BY_EVIDENCE; observed=TARGET_CONTRACT_DEFINED / OBSERVED_NOT_INSTALLED; runtime=NOT_EXECUTED | Instruction | NO_AUTO_INSTALL_OR_DEPLOY | CLAUDE.md:qualified Input→InstructionLoadDecision; load instruction from stated trust scope and trigger only compatible host behavior | CLAUDE.md: untrusted repo string grants extra tool permission | Instruction.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L825 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTAL; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-028 | DESIGN.md | upstream=CORE` / `components.design_view; disposition=DEFAULT_ENABLED_AFTER_QUALIFICATION; observed=TARGET_CONTRACT_DEFINED / OBSERVED_NOT_INSTALLED; runtime=NOT_EXECUTED | SpecWorkflow | DESIGN_CANDIDATE;QUALIFICATION_HOLD | DESIGN.md:qualified Input→SpecProposal; convert requirement change to versioned proposal and preserve non-goals | DESIGN.md: unaffected requirement silently overwritten or proposal masquerades PI | SpecWorkflow.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L826 ; SOURCE_DISPOSITION_PRESERVED; SCOPE_BY_; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-029 | AutoResearch | upstream=OPTIONAL` / `evolution.experiment_loop; disposition=DEFERRED_BY_EVIDENCE; observed=ADMISSION_BLOCKED_IDENTITY_UNRESOLVED; runtime=NOT_EXECUTED | NEEDS_DOMAIN_SPEC | NO_AUTO_INSTALL_OR_DEPLOY | AutoResearch:qualified Input→AdmissionFinding; identify documented capability and test [AutoResearch] on representative scoped input | AutoResearch: AutoResearch has no official contract or advertised outcome fails against controlled fixture | NEEDS_DOMAIN_SPEC.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L827 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTAL; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-030 | Loop Engineering | upstream=CORE` / `control.loop; disposition=DEFAULT_ENABLED_AFTER_QUALIFICATION; observed=TARGET_CONTRACT_DEFINED / OBSERVED_NOT_INSTALLED; runtime=NOT_EXECUTED | NEEDS_DOMAIN_SPEC | DESIGN_CANDIDATE;QUALIFICATION_HOLD | Loop Engineering:qualified Input→AdmissionFinding; identify documented capability and test [Loop Engineering] on representative scoped input | Loop Engineering: Loop Engineering has no official contract or advertised outcome fails against controlled fixture | NEEDS_DOMAIN_SPEC.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L828 ; SOURCE_DISPOSITION_PRESERVED; SCOPE_BY_; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-031 | Harness Engineering | upstream=CORE` / `control.harness; disposition=DEFAULT_ENABLED_AFTER_QUALIFICATION; observed=TARGET_CONTRACT_DEFINED / OBSERVED_NOT_INSTALLED; runtime=NOT_EXECUTED | AgentHarness | DESIGN_CANDIDATE;QUALIFICATION_HOLD | Harness Engineering:qualified Input→HarnessEvent; dispatch bounded read-only instruction to host and trace exact tool result | Harness Engineering: unapproved effect or false independent principal | AgentHarness.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L829 ; SOURCE_DISPOSITION_PRESERVED; SCOPE_BY_; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-032 | Multi-Agent | upstream=CORE` / `control.topology; disposition=DEFAULT_ENABLED_AFTER_QUALIFICATION; observed=TARGET_CONTRACT_DEFINED / OBSERVED_NOT_INSTALLED; runtime=NOT_EXECUTED | NEEDS_DOMAIN_SPEC | DESIGN_CANDIDATE;QUALIFICATION_HOLD | Multi-Agent:qualified Input→AdmissionFinding; identify documented capability and test [Multi-Agent] on representative scoped input | Multi-Agent: Multi-Agent has no official contract or advertised outcome fails against controlled fixture | NEEDS_DOMAIN_SPEC.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L830 ; SOURCE_DISPOSITION_PRESERVED; SCOPE_BY_; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-033 | Agent Swarm | upstream=OPTIONAL` / `control.optional_bounded_swarm; disposition=MERGED_ALIAS_WITH_CANONICAL_ID; observed=ADMISSION_BLOCKED_IDENTITY_UNRESOLVED; runtime=NOT_EXECUTED | NEEDS_DOMAIN_SPEC | DESIGN_CANDIDATE;QUALIFICATION_HOLD | Agent Swarm:qualified Input→AdmissionFinding; identify documented capability and test [Agent Swarm] on representative scoped input | Agent Swarm: Agent Swarm has no official contract or advertised outcome fails against controlled fixture | NEEDS_DOMAIN_SPEC.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L831 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTAL; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-034 | Sub-Agent | upstream=CORE` / `control.scoped_child; disposition=DEFAULT_ENABLED_AFTER_QUALIFICATION; observed=TARGET_CONTRACT_DEFINED / OBSERVED_NOT_INSTALLED; runtime=NOT_EXECUTED | NEEDS_DOMAIN_SPEC | DESIGN_CANDIDATE;QUALIFICATION_HOLD | Sub-Agent:qualified Input→AdmissionFinding; identify documented capability and test [Sub-Agent] on representative scoped input | Sub-Agent: Sub-Agent has no official contract or advertised outcome fails against controlled fixture | NEEDS_DOMAIN_SPEC.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L832 ; SOURCE_DISPOSITION_PRESERVED; SCOPE_BY_; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-035 | OpenHands / Agent Canvas | upstream=BENCHMARK` / `benchmark.agent_server; disposition=DEFERRED_BY_EVIDENCE; observed=BLOCKED_OR_REFERENCE_ONLY; runtime=NOT_EXECUTED | NEEDS_DOMAIN_SPEC | NO_AUTO_INSTALL_OR_DEPLOY | OpenHands / Agent Canvas:qualified Input→AdmissionFinding; identify documented capability and test [OpenHands / Agent Canvas] on representative scoped input | OpenHands / Agent Canvas: OpenHands / Agent Canvas has no official contract or advertised outcome fails against controlled fixture | NEEDS_DOMAIN_SPEC.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L833 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTAL; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-036 | Microsoft Agent Framework | upstream=BENCHMARK` / `benchmark.durable_agent; disposition=DEFERRED_BY_EVIDENCE; observed=BLOCKED_OR_REFERENCE_ONLY; runtime=NOT_EXECUTED | AgentHarness | NO_AUTO_INSTALL_OR_DEPLOY | Microsoft Agent Framework:qualified Input→HarnessEvent; dispatch bounded read-only instruction to host and trace exact tool result | Microsoft Agent Framework: unapproved effect or false independent principal | AgentHarness.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L834 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTAL; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-037 | AutoGen | upstream=LEGACY` / `blocked_legacy; disposition=MERGED_ALIAS_WITH_CANONICAL_ID; observed=BLOCKED_OR_REFERENCE_ONLY; runtime=NOT_EXECUTED | AgentHarness | DESIGN_CANDIDATE;QUALIFICATION_HOLD | AutoGen:qualified Input→HarnessEvent; dispatch bounded read-only instruction to host and trace exact tool result | AutoGen: unapproved effect or false independent principal | AgentHarness.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L835 ; NO_ACTIVATION; OWNER_CR_REQUIRED; posit; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-038 | Semantic Kernel | upstream=LEGACY` / `blocked_legacy; disposition=MERGED_ALIAS_WITH_CANONICAL_ID; observed=BLOCKED_OR_REFERENCE_ONLY; runtime=NOT_EXECUTED | NEEDS_DOMAIN_SPEC | DESIGN_CANDIDATE;QUALIFICATION_HOLD | Semantic Kernel:qualified Input→AdmissionFinding; identify documented capability and test [Semantic Kernel] on representative scoped input | Semantic Kernel: Semantic Kernel has no official contract or advertised outcome fails against controlled fixture | NEEDS_DOMAIN_SPEC.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L836 ; NO_ACTIVATION; OWNER_CR_REQUIRED; posit; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-039 | LangGraph | upstream=REJECTED` / `blocked_second_orchestrator; disposition=MERGED_ALIAS_WITH_CANONICAL_ID; observed=BLOCKED_OR_REFERENCE_ONLY; runtime=NOT_EXECUTED | AgentHarness | DESIGN_CANDIDATE;QUALIFICATION_HOLD | LangGraph:qualified Input→HarnessEvent; dispatch bounded read-only instruction to host and trace exact tool result | LangGraph: unapproved effect or false independent principal | AgentHarness.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L837 ; NO_ACTIVATION; OWNER_CR_REQUIRED; posit; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-040 | CrewAI | upstream=REJECTED` / `blocked_second_orchestrator; disposition=MERGED_ALIAS_WITH_CANONICAL_ID; observed=BLOCKED_OR_REFERENCE_ONLY; runtime=NOT_EXECUTED | AgentHarness | DESIGN_CANDIDATE;QUALIFICATION_HOLD | CrewAI:qualified Input→HarnessEvent; dispatch bounded read-only instruction to host and trace exact tool result | CrewAI: unapproved effect or false independent principal | AgentHarness.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L838 ; NO_ACTIVATION; OWNER_CR_REQUIRED; posit; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-041 | n8n | upstream=OPTIONAL` / `external_integration.optional; disposition=DEFERRED_BY_EVIDENCE; observed=ADMISSION_BLOCKED_IDENTITY_UNRESOLVED; runtime=NOT_EXECUTED | AgentHarness | NO_AUTO_INSTALL_OR_DEPLOY | n8n:qualified Input→HarnessEvent; dispatch bounded read-only instruction to host and trace exact tool result | n8n: unapproved effect or false independent principal | AgentHarness.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L839 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTAL; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-042 | Dify | upstream=DEFERRED` / `deferred_external_platform; disposition=DEFERRED_BY_EVIDENCE; observed=BLOCKED_OR_REFERENCE_ONLY; runtime=NOT_EXECUTED | AgentHarness | NO_AUTO_INSTALL_OR_DEPLOY | Dify:qualified Input→HarnessEvent; dispatch bounded read-only instruction to host and trace exact tool result | Dify: unapproved effect or false independent principal | AgentHarness.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L840 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTAL; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-043 | RAGFlow | upstream=BENCHMARK` / `benchmark_rag; disposition=DEFERRED_BY_EVIDENCE; observed=BLOCKED_OR_REFERENCE_ONLY; runtime=NOT_EXECUTED | DataKnowledge | NO_AUTO_INSTALL_OR_DEPLOY | RAGFlow:qualified Input→RetrievalRecord; upsert source-qualified record and retrieve correct version with provenance | RAGFlow: stale/source-unauthorized record returned as current | DataKnowledge.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L841 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTAL; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-044 | WeKnora | upstream=BENCHMARK` / `benchmark_wiki_rag; disposition=DEFERRED_BY_EVIDENCE; observed=BLOCKED_OR_REFERENCE_ONLY; runtime=NOT_EXECUTED | NEEDS_DOMAIN_SPEC | NO_AUTO_INSTALL_OR_DEPLOY | WeKnora:qualified Input→AdmissionFinding; identify documented capability and test [WeKnora] on representative scoped input | WeKnora: WeKnora has no official contract or advertised outcome fails against controlled fixture | NEEDS_DOMAIN_SPEC.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L842 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTAL; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-045 | LightRAG | upstream=BENCHMARK` / `benchmark_graph_rag; disposition=DEFERRED_BY_EVIDENCE; observed=BLOCKED_OR_REFERENCE_ONLY; runtime=NOT_EXECUTED | DataKnowledge | NO_AUTO_INSTALL_OR_DEPLOY | LightRAG:qualified Input→RetrievalRecord; upsert source-qualified record and retrieve correct version with provenance | LightRAG: stale/source-unauthorized record returned as current | DataKnowledge.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L843 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTAL; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-046 | GraphRAG | upstream=DEFERRED` / `deferred_method; disposition=MERGED_ALIAS_WITH_CANONICAL_ID; observed=BLOCKED_OR_REFERENCE_ONLY; runtime=NOT_EXECUTED | DataKnowledge | NO_AUTO_INSTALL_OR_DEPLOY | GraphRAG:qualified Input→RetrievalRecord; upsert source-qualified record and retrieve correct version with provenance | GraphRAG: stale/source-unauthorized record returned as current | DataKnowledge.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L844 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTAL; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-047 | Qdrant | upstream=OPTIONAL` / `retrieval.vector_slot; disposition=MERGED_ALIAS_WITH_CANONICAL_ID; observed=ADMISSION_BLOCKED_IDENTITY_UNRESOLVED; runtime=NOT_EXECUTED | DataKnowledge | DESIGN_CANDIDATE;QUALIFICATION_HOLD | Qdrant:qualified Input→RetrievalRecord; upsert source-qualified record and retrieve correct version with provenance | Qdrant: stale/source-unauthorized record returned as current | DataKnowledge.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L845 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTAL; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-048 | pgvector | upstream=OPTIONAL` / `retrieval.vector_slot; disposition=MERGED_ALIAS_WITH_CANONICAL_ID; observed=ADMISSION_BLOCKED_IDENTITY_UNRESOLVED; runtime=NOT_EXECUTED | DataKnowledge | DESIGN_CANDIDATE;QUALIFICATION_HOLD | pgvector:qualified Input→RetrievalRecord; upsert source-qualified record and retrieve correct version with provenance | pgvector: stale/source-unauthorized record returned as current | DataKnowledge.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L846 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTAL; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-049 | Milvus | upstream=DEFERRED` / `deferred_vector_scale; disposition=DEFERRED_BY_EVIDENCE; observed=BLOCKED_OR_REFERENCE_ONLY; runtime=NOT_EXECUTED | DataKnowledge | NO_AUTO_INSTALL_OR_DEPLOY | Milvus:qualified Input→RetrievalRecord; upsert source-qualified record and retrieve correct version with provenance | Milvus: stale/source-unauthorized record returned as current | DataKnowledge.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L847 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTAL; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-050 | Chroma | upstream=REJECTED` / `rejected_vector_core; disposition=MERGED_ALIAS_WITH_CANONICAL_ID; observed=BLOCKED_OR_REFERENCE_ONLY; runtime=NOT_EXECUTED | DataKnowledge | DESIGN_CANDIDATE;QUALIFICATION_HOLD | Chroma:qualified Input→RetrievalRecord; upsert source-qualified record and retrieve correct version with provenance | Chroma: stale/source-unauthorized record returned as current | DataKnowledge.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L848 ; NO_ACTIVATION; OWNER_CR_REQUIRED; posit; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-051 | Neo4j | upstream=DEFERRED` / `deferred_graph_store; disposition=MERGED_ALIAS_WITH_CANONICAL_ID; observed=BLOCKED_OR_REFERENCE_ONLY; runtime=NOT_EXECUTED | DataKnowledge | NO_AUTO_INSTALL_OR_DEPLOY | Neo4j:qualified Input→RetrievalRecord; upsert source-qualified record and retrieve correct version with provenance | Neo4j: stale/source-unauthorized record returned as current | DataKnowledge.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L849 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTAL; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-052 | Temporal | upstream=DEFERRED` / `deferred_durable_workflow; disposition=DEFERRED_BY_EVIDENCE; observed=BLOCKED_OR_REFERENCE_ONLY; runtime=NOT_EXECUTED | NEEDS_DOMAIN_SPEC | NO_AUTO_INSTALL_OR_DEPLOY | Temporal:qualified Input→AdmissionFinding; identify documented capability and test [Temporal] on representative scoped input | Temporal: Temporal has no official contract or advertised outcome fails against controlled fixture | NEEDS_DOMAIN_SPEC.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L850 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTAL; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-053 | OpenTelemetry | upstream=PRIMARY_ADAPTER` / `observability.trace_standard; disposition=DEFAULT_ENABLED_AFTER_QUALIFICATION; observed=TARGET_CONTRACT_DEFINED / OBSERVED_NOT_INSTALLED; runtime=NOT_EXECUTED | Observability | DESIGN_CANDIDATE;QUALIFICATION_HOLD | OpenTelemetry:qualified Input→TelemetryTrace; emit trace/span/metric with subject reference and privacy filters | OpenTelemetry: missing span linkage or secret attribute exposed | Observability.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L851 ; SOURCE_DISPOSITION_PRESERVED; SCOPE_BY_; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-054 | Sentry | upstream=OPTIONAL` / `observability.optional_backend; disposition=MERGED_ALIAS_WITH_CANONICAL_ID; observed=ADMISSION_BLOCKED_IDENTITY_UNRESOLVED; runtime=NOT_EXECUTED | Observability | DESIGN_CANDIDATE;QUALIFICATION_HOLD | Sentry:qualified Input→TelemetryTrace; emit trace/span/metric with subject reference and privacy filters | Sentry: missing span linkage or secret attribute exposed | Observability.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L852 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTAL; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-055 | SWE-bench | upstream=BENCHMARK` / `eval.coding_benchmark; disposition=DEFERRED_BY_EVIDENCE; observed=BLOCKED_OR_REFERENCE_ONLY; runtime=NOT_EXECUTED | TestQA | NO_AUTO_INSTALL_OR_DEPLOY | SWE-bench:qualified Input→TestRun; run pinned positive and deliberately failing fixture with pass/fail counts | SWE-bench: deliberately failing test returns zero evaluated cases or claimed PASS | TestQA.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L853 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTAL; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-056 | OSWorld | upstream=BENCHMARK` / `eval.gui_benchmark; disposition=DEFERRED_BY_EVIDENCE; observed=BLOCKED_OR_REFERENCE_ONLY; runtime=NOT_EXECUTED | TestQA | NO_AUTO_INSTALL_OR_DEPLOY | OSWorld:qualified Input→TestRun; run pinned positive and deliberately failing fixture with pass/fail counts | OSWorld: deliberately failing test returns zero evaluated cases or claimed PASS | TestQA.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L854 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTAL; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-057 | Terminal-Bench | upstream=BENCHMARK` / `eval.terminal_benchmark; disposition=DEFERRED_BY_EVIDENCE; observed=BLOCKED_OR_REFERENCE_ONLY; runtime=NOT_EXECUTED | TestQA | NO_AUTO_INSTALL_OR_DEPLOY | Terminal-Bench:qualified Input→TestRun; run pinned positive and deliberately failing fixture with pass/fail counts | Terminal-Bench: deliberately failing test returns zero evaluated cases or claimed PASS | TestQA.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L855 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTAL; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-058 | Promptfoo | upstream=OPTIONAL` / `eval.optional_runner; disposition=DEFERRED_BY_EVIDENCE; observed=ADMISSION_BLOCKED_IDENTITY_UNRESOLVED; runtime=NOT_EXECUTED | TestQA | NO_AUTO_INSTALL_OR_DEPLOY | Promptfoo:qualified Input→TestRun; run pinned positive and deliberately failing fixture with pass/fail counts | Promptfoo: deliberately failing test returns zero evaluated cases or claimed PASS | TestQA.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L856 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTAL; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-059 | Semgrep | upstream=PRIMARY_ADAPTER` / `security.static_analysis; disposition=DEFAULT_ENABLED_AFTER_QUALIFICATION; observed=TARGET_CONTRACT_DEFINED / OBSERVED_NOT_INSTALLED; runtime=NOT_EXECUTED | CodeSecurity | DESIGN_CANDIDATE;QUALIFICATION_HOLD | Semgrep:qualified Input→StaticAnalysisFinding; analyze repo source with configured queries, report finding locations | Semgrep: inject known vulnerable or type-invalid code: expected nonzero finding and no clean label | CodeSecurity.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L857 ; SOURCE_DISPOSITION_PRESERVED; SCOPE_BY_; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-060 | CodeQL | upstream=PRIMARY_ADAPTER` / `security.semantic_analysis; disposition=DEFAULT_ENABLED_AFTER_QUALIFICATION; observed=TARGET_CONTRACT_DEFINED / OBSERVED_NOT_INSTALLED; runtime=NOT_EXECUTED | CodeSecurity | DESIGN_CANDIDATE;QUALIFICATION_HOLD | CodeQL:qualified Input→StaticAnalysisFinding; analyze repo source with configured queries, report finding locations | CodeQL: inject known vulnerable or type-invalid code: expected nonzero finding and no clean label | CodeSecurity.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L858 ; SOURCE_DISPOSITION_PRESERVED; SCOPE_BY_; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-061 | Trivy | upstream=PRIMARY_ADAPTER` / `security.fs_dependency_scan; disposition=DEFAULT_ENABLED_AFTER_QUALIFICATION; observed=TARGET_CONTRACT_DEFINED / OBSERVED_NOT_INSTALLED; runtime=NOT_EXECUTED | SecurityScan | DESIGN_CANDIDATE;QUALIFICATION_HOLD | Trivy:qualified Input→ScannerFinding; scan controlled fixture containing known vuln/secret and emit evidence | Trivy: known synthetic secret/CVE fixture silently treated clean | SecurityScan.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L859 ; SOURCE_DISPOSITION_PRESERVED; SCOPE_BY_; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-062 | GitHub Actions | upstream=PRIMARY_ADAPTER` / `ci.evidence_producer; disposition=DEFAULT_ENABLED_AFTER_QUALIFICATION; observed=TARGET_CONTRACT_DEFINED / OBSERVED_NOT_INSTALLED; runtime=NOT_EXECUTED | CI | DESIGN_CANDIDATE;QUALIFICATION_HOLD | GitHub Actions:qualified Input→CIRun; evaluate repository supply-chain workflow on pinned ref and permissions | GitHub Actions: untrusted PR granted write token or artifact cannot be fetched | CI.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L860 ; SOURCE_DISPOSITION_PRESERVED; SCOPE_BY_; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-063 | OpenSSF Scorecard | upstream=PRIMARY_ADAPTER` / `supply_chain.repo_posture; disposition=DEFAULT_ENABLED_AFTER_QUALIFICATION; observed=TARGET_CONTRACT_DEFINED / OBSERVED_NOT_INSTALLED; runtime=NOT_EXECUTED | CI | DESIGN_CANDIDATE;QUALIFICATION_HOLD | OpenSSF Scorecard:qualified Input→CIRun; evaluate repository supply-chain workflow on pinned ref and permissions | OpenSSF Scorecard: untrusted PR granted write token or artifact cannot be fetched | CI.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L861 ; SOURCE_DISPOSITION_PRESERVED; SCOPE_BY_; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-064 | SBOM | upstream=CORE` / `supply_chain.artifact; disposition=DEFAULT_ENABLED_AFTER_QUALIFICATION; observed=TARGET_CONTRACT_DEFINED / OBSERVED_NOT_INSTALLED; runtime=NOT_EXECUTED | SupplyChain | DESIGN_CANDIDATE;QUALIFICATION_HOLD | SBOM:qualified Input→SBOMDocument; generate component list bound to exact build digest | SBOM: insert a dependency and compare BOM; missing dep must fail completeness | SupplyChain.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L862 ; SOURCE_DISPOSITION_PRESERVED; SCOPE_BY_; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-065 | Artifact Attestation | upstream=CORE` / `supply_chain.artifact; disposition=DEFAULT_ENABLED_AFTER_QUALIFICATION; observed=TARGET_CONTRACT_DEFINED / OBSERVED_NOT_INSTALLED; runtime=NOT_EXECUTED | SupplyChain | DESIGN_CANDIDATE;QUALIFICATION_HOLD | Artifact Attestation:qualified Input→AttestationDecision; verify subject digest, signer/trust root and provenance before publishing | Artifact Attestation: tampered blob or mismatched signer: must reject verification | SupplyChain.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L863 ; SOURCE_DISPOSITION_PRESERVED; SCOPE_BY_; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-066 | SLSA | upstream=OPTIONAL` / `supply_chain.optional_target; disposition=MERGED_ALIAS_WITH_CANONICAL_ID; observed=ADMISSION_BLOCKED_IDENTITY_UNRESOLVED; runtime=NOT_EXECUTED | SupplyChain | DESIGN_CANDIDATE;QUALIFICATION_HOLD | SLSA:qualified Input→AttestationDecision; verify subject digest, signer/trust root and provenance before publishing | SLSA: tampered blob or mismatched signer: must reject verification | SupplyChain.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L864 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTAL; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-067 | Sigstore | upstream=OPTIONAL` / `supply_chain.optional_signing; disposition=DEFERRED_BY_EVIDENCE; observed=ADMISSION_BLOCKED_IDENTITY_UNRESOLVED; runtime=NOT_EXECUTED | SupplyChain | NO_AUTO_INSTALL_OR_DEPLOY | Sigstore:qualified Input→AttestationDecision; verify subject digest, signer/trust root and provenance before publishing | Sigstore: tampered blob or mismatched signer: must reject verification | SupplyChain.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L865 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTAL; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-068 | OSV | upstream=PRIMARY_ADAPTER` / `security.vulnerability_db; disposition=DEFAULT_ENABLED_AFTER_QUALIFICATION; observed=TARGET_CONTRACT_DEFINED / OBSERVED_NOT_INSTALLED; runtime=NOT_EXECUTED | SecurityScan | DESIGN_CANDIDATE;QUALIFICATION_HOLD | OSV:qualified Input→ScannerFinding; scan controlled fixture containing known vuln/secret and emit evidence | OSV: known synthetic secret/CVE fixture silently treated clean | SecurityScan.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L866 ; SOURCE_DISPOSITION_PRESERVED; SCOPE_BY_; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-069 | Docker | upstream=OPTIONAL` / `isolation.optional_worker; disposition=MERGED_ALIAS_WITH_CANONICAL_ID; observed=ADMISSION_BLOCKED_IDENTITY_UNRESOLVED; runtime=NOT_EXECUTED | Deployment | DESIGN_CANDIDATE;QUALIFICATION_HOLD | Docker:qualified Input→InstallSession; install pinned dependency in isolated target and verify clean uninstall | Docker: wrong OS/arch or residues treated healthy | Deployment.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L867 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTAL; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-070 | Kubernetes | upstream=DEFERRED` / `deferred_distributed_runtime; disposition=DEFERRED_BY_EVIDENCE; observed=BLOCKED_OR_REFERENCE_ONLY; runtime=NOT_EXECUTED | Deployment | NO_AUTO_INSTALL_OR_DEPLOY | Kubernetes:qualified Input→InstallSession; install pinned dependency in isolated target and verify clean uninstall | Kubernetes: wrong OS/arch or residues treated healthy | Deployment.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L868 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTAL; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-071 | Nix | upstream=OPTIONAL` / `environment.optional_reproducibility; disposition=DEFERRED_BY_EVIDENCE; observed=ADMISSION_BLOCKED_IDENTITY_UNRESOLVED; runtime=NOT_EXECUTED | Deployment | NO_AUTO_INSTALL_OR_DEPLOY | Nix:qualified Input→InstallSession; install pinned dependency in isolated target and verify clean uninstall | Nix: wrong OS/arch or residues treated healthy | Deployment.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L869 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTAL; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-072 | SQLite | upstream=CORE` / `state_and_lexical_core; disposition=DEFAULT_ENABLED_AFTER_QUALIFICATION; observed=TARGET_CONTRACT_DEFINED / OBSERVED_NOT_INSTALLED; runtime=NOT_EXECUTED | DataKnowledge | DESIGN_CANDIDATE;QUALIFICATION_HOLD | SQLite:qualified Input→RetrievalRecord; upsert source-qualified record and retrieve correct version with provenance | SQLite: stale/source-unauthorized record returned as current | DataKnowledge.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L870 ; SOURCE_DISPOSITION_PRESERVED; SCOPE_BY_; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-073 | PostgreSQL | upstream=DEFERRED` / `deferred_scale_state; disposition=MERGED_ALIAS_WITH_CANONICAL_ID; observed=BLOCKED_OR_REFERENCE_ONLY; runtime=NOT_EXECUTED | DataKnowledge | NO_AUTO_INSTALL_OR_DEPLOY | PostgreSQL:qualified Input→RetrievalRecord; upsert source-qualified record and retrieve correct version with provenance | PostgreSQL: stale/source-unauthorized record returned as current | DataKnowledge.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L871 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTAL; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-074 | gbrain | upstream=P1 CANDIDATE` / `semantic retrieval/index; disposition=DEFERRED_BY_EVIDENCE; observed=ADMISSION_BLOCKED_IDENTITY_UNRESOLVED; runtime=NOT_EXECUTED | NEEDS_DOMAIN_SPEC | NO_AUTO_INSTALL_OR_DEPLOY | gbrain:qualified Input→AdmissionFinding; identify documented capability and test [gbrain] on representative scoped input | gbrain: gbrain has no official contract or advertised outcome fails against controlled fixture | NEEDS_DOMAIN_SPEC.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L872 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTAL; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-075 | hindsight | upstream=P1 PILOT` / `persistent memory; disposition=DEFERRED_BY_EVIDENCE; observed=ADMISSION_BLOCKED_IDENTITY_UNRESOLVED; runtime=NOT_EXECUTED | NEEDS_DOMAIN_SPEC | NO_AUTO_INSTALL_OR_DEPLOY | hindsight:qualified Input→AdmissionFinding; identify documented capability and test [hindsight] on representative scoped input | hindsight: hindsight has no official contract or advertised outcome fails against controlled fixture | NEEDS_DOMAIN_SPEC.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L873 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTAL; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-076 | graphiti | upstream=P1 PILOT` / `temporal KG; disposition=DEFERRED_BY_EVIDENCE; observed=ADMISSION_BLOCKED_IDENTITY_UNRESOLVED; runtime=NOT_EXECUTED | DataKnowledge | NO_AUTO_INSTALL_OR_DEPLOY | graphiti:qualified Input→RetrievalRecord; upsert source-qualified record and retrieve correct version with provenance | graphiti: stale/source-unauthorized record returned as current | DataKnowledge.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L874 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTAL; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-077 | cognee | upstream=BENCHMARK` / `memory/KG replacement; disposition=DEFERRED_BY_EVIDENCE; observed=BLOCKED_OR_REFERENCE_ONLY; runtime=NOT_EXECUTED | DataKnowledge | NO_AUTO_INSTALL_OR_DEPLOY | cognee:qualified Input→RetrievalRecord; upsert source-qualified record and retrieve correct version with provenance | cognee: stale/source-unauthorized record returned as current | DataKnowledge.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L875 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTAL; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| P0_TOOL78/P0-TOOL-078 | codegraph_exact_provider | upstream=P1 PILOT` / `code intelligence; disposition=MERGED_ALIAS_WITH_CANONICAL_ID; observed=ADMISSION_BLOCKED_IDENTITY_UNRESOLVED; runtime=NOT_EXECUTED | NEEDS_DOMAIN_SPEC | DESIGN_CANDIDATE;QUALIFICATION_HOLD | codegraph_exact_provider:qualified Input→AdmissionFinding; identify documented capability and test [codegraph_exact_provider] on representative scoped input | codegraph_exact_provider: codegraph_exact_provider has no official contract or advertised outcome fails against controlled fixture | NEEDS_DOMAIN_SPEC.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11.1` L876 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTAL; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| NTD40/NTD-001 | Obsidian | policy=DEFERRED_BY_EVIDENCE; runtime=NOT_INSPECTED; owner=F09-01 | NEEDS_DOMAIN_SPEC | NO_AUTO_INSTALL_OR_DEPLOY | Obsidian:qualified Input→AdmissionFinding; identify documented capability and test [Obsidian] on representative scoped input | Obsidian: Obsidian has no official contract or advertised outcome fails against controlled fixture | NEEDS_DOMAIN_SPEC.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11` L752 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTALL;; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| NTD40/NTD-002 | Tree-sitter | policy=DEFERRED_BY_EVIDENCE; runtime=NOT_INSPECTED; owner=F13-02 | NEEDS_DOMAIN_SPEC | NO_AUTO_INSTALL_OR_DEPLOY | Tree-sitter:qualified Input→AdmissionFinding; identify documented capability and test [Tree-sitter] on representative scoped input | Tree-sitter: Tree-sitter has no official contract or advertised outcome fails against controlled fixture | NEEDS_DOMAIN_SPEC.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11` L753 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTALL;; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| NTD40/NTD-003 | Language Server Protocol | policy=DEFERRED_BY_EVIDENCE; runtime=NOT_INSPECTED; owner=F13-03 | Protocol | NO_AUTO_INSTALL_OR_DEPLOY | Language Server Protocol:qualified Input→TransportEnvelope; schema-validate typed request/response with source-bound principal | Language Server Protocol: malformed payload or forged permission accepted | Protocol.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11` L754 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTALL;; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| NTD40/NTD-004 | CodeGraph | policy=DEFERRED_BY_EVIDENCE; runtime=NOT_INSPECTED; owner=F13-04 | NEEDS_DOMAIN_SPEC | NO_AUTO_INSTALL_OR_DEPLOY | CodeGraph:qualified Input→AdmissionFinding; identify documented capability and test [CodeGraph] on representative scoped input | CodeGraph: CodeGraph has no official contract or advertised outcome fails against controlled fixture | NEEDS_DOMAIN_SPEC.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11` L755 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTALL;; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| NTD40/NTD-005 | Typer | policy=DEFERRED_BY_EVIDENCE; runtime=NOT_INSPECTED; owner=F10-06 | NEEDS_DOMAIN_SPEC | NO_AUTO_INSTALL_OR_DEPLOY | Typer:qualified Input→AdmissionFinding; identify documented capability and test [Typer] on representative scoped input | Typer: Typer has no official contract or advertised outcome fails against controlled fixture | NEEDS_DOMAIN_SPEC.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11` L756 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTALL;; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| NTD40/NTD-006 | Rich | policy=DEFERRED_BY_EVIDENCE; runtime=NOT_INSPECTED; owner=F10-06 | NEEDS_DOMAIN_SPEC | NO_AUTO_INSTALL_OR_DEPLOY | Rich:qualified Input→AdmissionFinding; identify documented capability and test [Rich] on representative scoped input | Rich: Rich has no official contract or advertised outcome fails against controlled fixture | NEEDS_DOMAIN_SPEC.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11` L757 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTALL;; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| NTD40/NTD-007 | yq | policy=DEFERRED_BY_EVIDENCE; runtime=NOT_INSPECTED; owner=F06-03 | NEEDS_DOMAIN_SPEC | NO_AUTO_INSTALL_OR_DEPLOY | yq:qualified Input→AdmissionFinding; identify documented capability and test [yq] on representative scoped input | yq: yq has no official contract or advertised outcome fails against controlled fixture | NEEDS_DOMAIN_SPEC.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11` L758 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTALL;; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| NTD40/NTD-008 | Docker Desktop | policy=DEFERRED_BY_EVIDENCE; runtime=NOT_INSPECTED; owner=F06-04 | Deployment | NO_AUTO_INSTALL_OR_DEPLOY | Docker Desktop:qualified Input→InstallSession; install pinned dependency in isolated target and verify clean uninstall | Docker Desktop: wrong OS/arch or residues treated healthy | Deployment.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11` L759 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTALL;; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| NTD40/NTD-009 | WSL 2 | policy=DEFERRED_BY_EVIDENCE; runtime=NOT_INSPECTED; owner=F06-05 | Deployment | NO_AUTO_INSTALL_OR_DEPLOY | WSL 2:qualified Input→InstallSession; install pinned dependency in isolated target and verify clean uninstall | WSL 2: wrong OS/arch or residues treated healthy | Deployment.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11` L760 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTALL;; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| NTD40/NTD-010 | Spec Kit | policy=DONOR_PATTERN_ONLY; runtime=NOT_INSPECTED; owner=F11-02 | SpecWorkflow | DESIGN_CANDIDATE;QUALIFICATION_HOLD | Spec Kit:qualified Input→SpecProposal; convert requirement change to versioned proposal and preserve non-goals | Spec Kit: unaffected requirement silently overwritten or proposal masquerades PI | SpecWorkflow.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11` L761 ; SOURCE_DISPOSITION_PRESERVED; SCOPE_BY_OW; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| NTD40/NTD-011 | Grill Me | policy=DONOR_PATTERN_ONLY; runtime=NOT_INSPECTED; owner=F11-03 | Method | DESIGN_CANDIDATE;QUALIFICATION_HOLD | Grill Me:qualified Input→MethodArtifact; route matching task to method skill and generate inspectable stage artifact | Grill Me: inappropriate task triggers method or no source link | Method.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11` L762 ; SOURCE_DISPOSITION_PRESERVED; SCOPE_BY_OW; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| NTD40/NTD-012 | Grill with Docs | policy=DONOR_PATTERN_ONLY; runtime=NOT_INSPECTED; owner=F11-03 | Method | DESIGN_CANDIDATE;QUALIFICATION_HOLD | Grill with Docs:qualified Input→MethodArtifact; route matching task to method skill and generate inspectable stage artifact | Grill with Docs: inappropriate task triggers method or no source link | Method.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11` L763 ; SOURCE_DISPOSITION_PRESERVED; SCOPE_BY_OW; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| NTD40/NTD-013 | Skill Creator | policy=DONOR_PATTERN_ONLY; runtime=NOT_INSPECTED; owner=F11-04 | NEEDS_DOMAIN_SPEC | DESIGN_CANDIDATE;QUALIFICATION_HOLD | Skill Creator:qualified Input→AdmissionFinding; identify documented capability and test [Skill Creator] on representative scoped input | Skill Creator: Skill Creator has no official contract or advertised outcome fails against controlled fixture | NEEDS_DOMAIN_SPEC.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11` L764 ; SOURCE_DISPOSITION_PRESERVED; SCOPE_BY_OW; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| NTD40/NTD-014 | LangGraph | policy=DEFERRED_BY_EVIDENCE; runtime=NOT_INSPECTED; owner=F07-02 | AgentHarness | NO_AUTO_INSTALL_OR_DEPLOY | LangGraph:qualified Input→HarnessEvent; dispatch bounded read-only instruction to host and trace exact tool result | LangGraph: unapproved effect or false independent principal | AgentHarness.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11` L765 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTALL;; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| NTD40/NTD-015 | CrewAI | policy=DEFERRED_BY_EVIDENCE; runtime=NOT_INSPECTED; owner=F07-03 | AgentHarness | NO_AUTO_INSTALL_OR_DEPLOY | CrewAI:qualified Input→HarnessEvent; dispatch bounded read-only instruction to host and trace exact tool result | CrewAI: unapproved effect or false independent principal | AgentHarness.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11` L766 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTALL;; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| NTD40/NTD-016 | AutoGen | policy=DEFERRED_BY_EVIDENCE; runtime=NOT_INSPECTED; owner=F07-04 | AgentHarness | NO_AUTO_INSTALL_OR_DEPLOY | AutoGen:qualified Input→HarnessEvent; dispatch bounded read-only instruction to host and trace exact tool result | AutoGen: unapproved effect or false independent principal | AgentHarness.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11` L767 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTALL;; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| NTD40/NTD-017 | Semantic Kernel | policy=DEFERRED_BY_EVIDENCE; runtime=NOT_INSPECTED; owner=F07-05 | NEEDS_DOMAIN_SPEC | NO_AUTO_INSTALL_OR_DEPLOY | Semantic Kernel:qualified Input→AdmissionFinding; identify documented capability and test [Semantic Kernel] on representative scoped input | Semantic Kernel: Semantic Kernel has no official contract or advertised outcome fails against controlled fixture | NEEDS_DOMAIN_SPEC.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11` L768 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTALL;; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| NTD40/NTD-018 | Open Policy Agent | policy=DEFERRED_BY_EVIDENCE; runtime=NOT_INSPECTED; owner=F16-03 | NEEDS_DOMAIN_SPEC | NO_AUTO_INSTALL_OR_DEPLOY | Open Policy Agent:qualified Input→AdmissionFinding; identify documented capability and test [Open Policy Agent] on representative scoped input | Open Policy Agent: Open Policy Agent has no official contract or advertised outcome fails against controlled fixture | NEEDS_DOMAIN_SPEC.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11` L769 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTALL;; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| NTD40/NTD-019 | Rego | policy=DEFERRED_BY_EVIDENCE; runtime=NOT_INSPECTED; owner=F16-03 | NEEDS_DOMAIN_SPEC | NO_AUTO_INSTALL_OR_DEPLOY | Rego:qualified Input→AdmissionFinding; identify documented capability and test [Rego] on representative scoped input | Rego: Rego has no official contract or advertised outcome fails against controlled fixture | NEEDS_DOMAIN_SPEC.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11` L770 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTALL;; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| NTD40/NTD-020 | Grype | policy=DEFERRED_BY_EVIDENCE; runtime=NOT_INSPECTED; owner=F17-05 | SecurityScan | NO_AUTO_INSTALL_OR_DEPLOY | Grype:qualified Input→ScannerFinding; scan controlled fixture containing known vuln/secret and emit evidence | Grype: known synthetic secret/CVE fixture silently treated clean | SecurityScan.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11` L771 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTALL;; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| NTD40/NTD-021 | Cosign | policy=DEFERRED_BY_EVIDENCE; runtime=NOT_INSPECTED; owner=F17-05 | SupplyChain | NO_AUTO_INSTALL_OR_DEPLOY | Cosign:qualified Input→AttestationDecision; verify subject digest, signer/trust root and provenance before publishing | Cosign: tampered blob or mismatched signer: must reject verification | SupplyChain.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11` L772 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTALL;; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| NTD40/NTD-022 | SLSA | policy=DONOR_PATTERN_ONLY; runtime=NOT_INSPECTED; owner=F17-05 | SupplyChain | DESIGN_CANDIDATE;QUALIFICATION_HOLD | SLSA:qualified Input→AttestationDecision; verify subject digest, signer/trust root and provenance before publishing | SLSA: tampered blob or mismatched signer: must reject verification | SupplyChain.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11` L773 ; SOURCE_DISPOSITION_PRESERVED; SCOPE_BY_OW; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| NTD40/NTD-023 | OpenSSF Scorecard | policy=DEFERRED_BY_EVIDENCE; runtime=NOT_INSPECTED; owner=F17-05 | CI | NO_AUTO_INSTALL_OR_DEPLOY | OpenSSF Scorecard:qualified Input→CIRun; evaluate repository supply-chain workflow on pinned ref and permissions | OpenSSF Scorecard: untrusted PR granted write token or artifact cannot be fetched | CI.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11` L774 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTALL;; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| NTD40/NTD-024 | Grafana Tempo | policy=DEFERRED_BY_EVIDENCE; runtime=NOT_INSPECTED; owner=F17-02 | Observability | NO_AUTO_INSTALL_OR_DEPLOY | Grafana Tempo:qualified Input→TelemetryTrace; emit trace/span/metric with subject reference and privacy filters | Grafana Tempo: missing span linkage or secret attribute exposed | Observability.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11` L775 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTALL;; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| NTD40/NTD-025 | Jaeger | policy=DEFERRED_BY_EVIDENCE; runtime=NOT_INSPECTED; owner=F17-02 | Observability | NO_AUTO_INSTALL_OR_DEPLOY | Jaeger:qualified Input→TelemetryTrace; emit trace/span/metric with subject reference and privacy filters | Jaeger: missing span linkage or secret attribute exposed | Observability.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11` L776 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTALL;; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| NTD40/NTD-026 | Prometheus | policy=DEFERRED_BY_EVIDENCE; runtime=NOT_INSPECTED; owner=F17-02 | Observability | NO_AUTO_INSTALL_OR_DEPLOY | Prometheus:qualified Input→TelemetryTrace; emit trace/span/metric with subject reference and privacy filters | Prometheus: missing span linkage or secret attribute exposed | Observability.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11` L777 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTALL;; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| NTD40/NTD-027 | Grafana | policy=DEFERRED_BY_EVIDENCE; runtime=NOT_INSPECTED; owner=F17-02 | Observability | NO_AUTO_INSTALL_OR_DEPLOY | Grafana:qualified Input→TelemetryTrace; emit trace/span/metric with subject reference and privacy filters | Grafana: missing span linkage or secret attribute exposed | Observability.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11` L778 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTALL;; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| NTD40/NTD-028 | Loki | policy=DEFERRED_BY_EVIDENCE; runtime=NOT_INSPECTED; owner=F17-02 | Observability | NO_AUTO_INSTALL_OR_DEPLOY | Loki:qualified Input→TelemetryTrace; emit trace/span/metric with subject reference and privacy filters | Loki: missing span linkage or secret attribute exposed | Observability.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11` L779 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTALL;; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| NTD40/NTD-029 | Sentry | policy=DEFERRED_BY_EVIDENCE; runtime=NOT_INSPECTED; owner=F17-02 | Observability | NO_AUTO_INSTALL_OR_DEPLOY | Sentry:qualified Input→TelemetryTrace; emit trace/span/metric with subject reference and privacy filters | Sentry: missing span linkage or secret attribute exposed | Observability.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11` L780 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTALL;; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| NTD40/NTD-030 | OpenAI API/Models | policy=DEFERRED_BY_EVIDENCE; runtime=NOT_INSPECTED; owner=F14-02 | AgentHarness | NO_AUTO_INSTALL_OR_DEPLOY | OpenAI API/Models:qualified Input→HarnessEvent; dispatch bounded read-only instruction to host and trace exact tool result | OpenAI API/Models: unapproved effect or false independent principal | AgentHarness.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11` L781 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTALL;; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| NTD40/NTD-031 | Anthropic API/Models | policy=DEFERRED_BY_EVIDENCE; runtime=NOT_INSPECTED; owner=F14-02 | AgentHarness | NO_AUTO_INSTALL_OR_DEPLOY | Anthropic API/Models:qualified Input→HarnessEvent; dispatch bounded read-only instruction to host and trace exact tool result | Anthropic API/Models: unapproved effect or false independent principal | AgentHarness.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11` L782 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTALL;; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| NTD40/NTD-032 | Browser/CUA runtime | policy=DEFERRED_BY_EVIDENCE; runtime=NOT_INSPECTED; owner=F16-06 | NEEDS_DOMAIN_SPEC | NO_AUTO_INSTALL_OR_DEPLOY | Browser/CUA runtime:qualified Input→AdmissionFinding; identify documented capability and test [Browser/CUA runtime] on representative scoped input | Browser/CUA runtime: Browser/CUA runtime has no official contract or advertised outcome fails against controlled fixture | NEEDS_DOMAIN_SPEC.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11` L783 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTALL;; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| NTD40/NTD-033 | OpenClaw-like orchestration | policy=REJECTED; runtime=NOT_INSPECTED; owner=F16-06 | AgentHarness | DESIGN_CANDIDATE;QUALIFICATION_HOLD | OpenClaw-like orchestration:qualified Input→HarnessEvent; dispatch bounded read-only instruction to host and trace exact tool result | OpenClaw-like orchestration: unapproved effect or false independent principal | AgentHarness.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11` L784 ; NO_ACTIVATION; OWNER_CR_REQUIRED; positiv; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| NTD40/NTD-034 | Chroma | policy=DEFERRED_BY_EVIDENCE; runtime=NOT_INSPECTED; owner=F09-04 | DataKnowledge | NO_AUTO_INSTALL_OR_DEPLOY | Chroma:qualified Input→RetrievalRecord; upsert source-qualified record and retrieve correct version with provenance | Chroma: stale/source-unauthorized record returned as current | DataKnowledge.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11` L785 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTALL;; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| NTD40/NTD-035 | pgvector | policy=DEFERRED_BY_EVIDENCE; runtime=NOT_INSPECTED; owner=F09-04 | DataKnowledge | NO_AUTO_INSTALL_OR_DEPLOY | pgvector:qualified Input→RetrievalRecord; upsert source-qualified record and retrieve correct version with provenance | pgvector: stale/source-unauthorized record returned as current | DataKnowledge.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11` L786 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTALL;; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| NTD40/NTD-036 | GraphRAG | policy=DONOR_PATTERN_ONLY; runtime=NOT_INSPECTED; owner=F09-05 | DataKnowledge | DESIGN_CANDIDATE;QUALIFICATION_HOLD | GraphRAG:qualified Input→RetrievalRecord; upsert source-qualified record and retrieve correct version with provenance | GraphRAG: stale/source-unauthorized record returned as current | DataKnowledge.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11` L787 ; SOURCE_DISPOSITION_PRESERVED; SCOPE_BY_OW; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| NTD40/NTD-037 | TypeScript compiler | policy=DEFERRED_BY_EVIDENCE; runtime=NOT_INSPECTED; owner=F12-03 | CodeSecurity | NO_AUTO_INSTALL_OR_DEPLOY | TypeScript compiler:qualified Input→StaticAnalysisFinding; analyze repo source with configured queries, report finding locations | TypeScript compiler: inject known vulnerable or type-invalid code: expected nonzero finding and no clean label | CodeSecurity.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11` L788 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTALL;; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| NTD40/NTD-038 | Vitest | policy=DEFERRED_BY_EVIDENCE; runtime=NOT_INSPECTED; owner=F12-03 | TestQA | NO_AUTO_INSTALL_OR_DEPLOY | Vitest:qualified Input→TestRun; run pinned positive and deliberately failing fixture with pass/fail counts | Vitest: deliberately failing test returns zero evaluated cases or claimed PASS | TestQA.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11` L789 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTALL;; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| NTD40/NTD-039 | CodeQL | policy=DEFERRED_BY_EVIDENCE; runtime=NOT_INSPECTED; owner=F16-04 | CodeSecurity | NO_AUTO_INSTALL_OR_DEPLOY | CodeQL:qualified Input→StaticAnalysisFinding; analyze repo source with configured queries, report finding locations | CodeQL: inject known vulnerable or type-invalid code: expected nonzero finding and no clean label | CodeSecurity.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11` L790 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTALL;; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |
| NTD40/NTD-040 | cdxgen | policy=DEFERRED_BY_EVIDENCE; runtime=NOT_INSPECTED; owner=F17-05 | SupplyChain | NO_AUTO_INSTALL_OR_DEPLOY | cdxgen:qualified Input→SBOMDocument; generate component list bound to exact build digest | cdxgen: insert a dependency and compare BOM; missing dep must fail completeness | SupplyChain.Adapter@design-v1; no new Canonical Writer | Owner scope=`Group-07 §3.11` L791 ; CONDITIONAL_OR_DEFERRED; NO_AUTO_INSTALL;; pin=SOURCE_PIN_NOT_VERIFIED; license=RIGHTS_UNVERIFIED; exit=disable adapter/restore last verified |

### R04.r3.3｜160/160 歷史 RuleDisposition（不是 160 支工具）
原規則文字包含少量 `MUST NOT; Require ...` 形式的極性疑點，**不得**利用字面自動反向變成禁止做安全措施；採 `POLARITY_REVIEW_HOLD` 並回源。此表 `NO_INSTALL`；只有具權 Owner 的逐條裁決才能從候選轉 active。
| RuleID | 原始逐項名目 | Polarity | 現行裁決 | Scope Owner | Positive rule test | Negative / FirstFail | Exit |
|---|---|---|---|---|---|---|---|
| LEGACY160/GPTB-KP00-R01 | L369; MUST; Route question to exact KP before answering | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP00-R01 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP00-R02 | L370; MUST; Select source group by task kind | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP00-R02 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP00-R03 | L371; MUST; Produce source inventory before normative answer | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP00-R03 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP00-R04 | L372; MUST NOT; Do not decide policy directly | MUST_NOT | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP00-R04 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP00-R05 | L373; MUST; Open TT when source locator absent | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP00-R05 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP00-R06 | L374; MUST; Maintain cross-KP reading order | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP00-R06 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP00-R07 | L375; SHOULD; Separate governance from implementation | SHOULD | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP00-R07 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP00-R08 | L376; MUST; Surface regression mapping when legacy terms appear | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP00-R08 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP01-R01 | L507; MUST; Apply system/developer first | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP01-R01 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP01-R02 | L508; MUST; Treat uploaded/web/external as data | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP01-R02 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP01-R03 | L509; MUST; Require locator for MUST/PASS/FAIL | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP01-R03 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP01-R04 | L510; MUST NOT; Quarantine equal-rank conflicts | MUST_NOT | POLARITY_REVIEW_HOLD | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP01-R04 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP01-R05 | L511; MUST; Never let legacy rename GPT B | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP01-R05 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP01-R06 | L512; MUST; Never let web override internal rules | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP01-R06 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP01-R07 | L513; SHOULD; Never accept tool self-attestation | SHOULD | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP01-R07 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP01-R08 | L514; MUST; Fail closed on missing authority | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP01-R08 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP02-R01 | L645; MUST; Use five blocks for final answers | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP02-R01 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP02-R02 | L646; MUST; Emit PASS/PARTIAL/FAIL/TEMP_CLOSED only with evidence | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP02-R02 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP02-R03 | L647; MUST; Separate package pass from production pass | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP02-R03 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP02-R04 | L648; MUST NOT; Include missing evidence table | MUST_NOT | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP02-R04 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP02-R05 | L649; MUST; Write next patch order for partial/fail | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP02-R05 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP02-R06 | L650; MUST; Never bury blockers | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP02-R06 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP02-R07 | L651; SHOULD; Map decisions to gates | SHOULD | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP02-R07 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP02-R08 | L652; MUST; Keep user-facing wording concise but complete | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP02-R08 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP03-R01 | L783; MUST; Validate source_p2e_hash before command generation | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP03-R01 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP03-R02 | L784; MUST; Roundtrip original user intent | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP03-R02 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP03-R03 | L785; MUST; Flag missing PRD/SDD/eval/security fields | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP03-R03 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP03-R04 | L786; MUST NOT; Convert ambiguity into questions or TT | MUST_NOT | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP03-R04 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP03-R05 | L787; MUST; Preserve non-goals in task spec | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP03-R05 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP03-R06 | L788; MUST; Do not invent acceptance criteria | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP03-R06 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP03-R07 | L789; SHOULD; Bind every downstream task to handoff item | SHOULD | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP03-R07 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP03-R08 | L790; MUST; Return gap feedback to GPT A | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP03-R08 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP04-R01 | L924; MUST; Tie every gate to product objective | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP04-R01 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP04-R02 | L925; MUST; Calibrate strictness by risk tier | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP04-R02 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP04-R03 | L926; MUST; Include negative/adversarial acceptance | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP04-R03 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP04-R04 | L927; MUST NOT; Detect metric overfitting | MUST_NOT | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP04-R04 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP04-R05 | L928; MUST; Keep business value separate from implementation convenience | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP04-R05 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP04-R06 | L929; MUST; Block release on objective mismatch | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP04-R06 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP04-R07 | L930; SHOULD; Require HITL for high-risk claims | SHOULD | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP04-R07 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP04-R08 | L931; MUST; Record TT for ambiguous risk appetite | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP04-R08 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP05-R01 | L1064; MUST; Turn design intent into ADRs before tasks | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP05-R01 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP05-R02 | L1065; MUST; Decompose by interface and risk | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP05-R02 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP05-R03 | L1066; MUST; Bind every task to evidence requirement | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP05-R03 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP05-R04 | L1067; MUST NOT; Produce reversible PR plan | MUST_NOT | POLARITY_REVIEW_HOLD | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP05-R04 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP05-R05 | L1068; MUST; Include rollback note per PR | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP05-R05 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP05-R06 | L1069; MUST; Avoid repo execution claims | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP05-R06 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP05-R07 | L1070; SHOULD; Separate human approval from tool command | SHOULD | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP05-R07 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP05-R08 | L1071; MUST; Link OROCHI order to TaskSpec IDs | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP05-R08 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP06-R01 | L1203; MUST; Use exact GPT name | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP06-R01 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP06-R02 | L1204; MUST; Keep description conservative | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP06-R02 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP06-R03 | L1205; MUST; Provide exactly five starters | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP06-R03 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP06-R04 | L1206; MUST NOT; Default Apps/Actions OFF | MUST_NOT | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP06-R04 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP06-R05 | L1207; MUST; Enable file analysis/data analysis | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP06-R05 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP06-R06 | L1208; MUST; Web only for drift probe | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP06-R06 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP06-R07 | L1209; SHOULD; Do not enable image generation by default | SHOULD | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP06-R07 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP06-R08 | L1210; MUST; Run preview tests before release | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP06-R08 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP07-R01 | L1344; MUST; Keep core paste compact | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP07-R01 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP07-R02 | L1345; MUST; Put expanded rules in Knowledge | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP07-R02 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP07-R03 | L1346; MUST; Route tasks deterministically | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP07-R03 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP07-R04 | L1347; MUST NOT; Never ask unnecessary clarification when best-effort is possible | MUST_NOT | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP07-R04 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP07-R05 | L1348; MUST; Cite sources for normative claims | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP07-R05 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP07-R06 | L1349; MUST; Fail closed on missing evidence | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP07-R06 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP07-R07 | L1350; SHOULD; Route out external execution | SHOULD | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP07-R07 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP07-R08 | L1351; MUST; Preserve exactly five starters | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP07-R08 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP08-R01 | L1481; MUST; Retrieve by anchor before synthesis | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP08-R01 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP08-R02 | L1482; MUST; Prefer heading-rich chunks | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP08-R02 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP08-R03 | L1483; MUST; Separate source recall from answer quality | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP08-R03 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP08-R04 | L1484; MUST NOT; Never cite unavailable anchors | MUST_NOT | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP08-R04 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP08-R05 | L1485; MUST; Use NRTV to stop return-to-vol regressions | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP08-R05 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP08-R06 | L1486; MUST; Test each KP with probes | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP08-R06 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP08-R07 | L1487; SHOULD; Keep raw sources out of Knowledge | SHOULD | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP08-R07 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP08-R08 | L1488; MUST; Open TT on retrieval ambiguity | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP08-R08 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP09-R01 | L1619; MUST; Emit full OROCHI_FACTORY_ORDER before route-out | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP09-R01 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP09-R02 | L1620; MUST; Include required fields and validation rules | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP09-R02 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP09-R03 | L1621; MUST; Separate desired change from execution evidence | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP09-R03 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP09-R04 | L1622; MUST NOT; Require evidence_return_pack | MUST_NOT | POLARITY_REVIEW_HOLD | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP09-R04 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP09-R05 | L1623; MUST; Block self-pass | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP09-R05 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP09-R06 | L1624; MUST; Include rollback plan | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP09-R06 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP09-R07 | L1625; SHOULD; Map commands to TaskSpec IDs | SHOULD | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP09-R07 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP09-R08 | L1626; MUST; Include safety and permission scope | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP09-R08 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP10-R01 | L1771; MUST; Model work as issue-to-task-to-pr | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP10-R01 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP10-R02 | L1772; MUST; Require review evidence before merge acceptance | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP10-R02 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP10-R03 | L1773; MUST; Bind PR to tests and rollback | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP10-R03 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP10-R04 | L1774; MUST NOT; Do not assume harness state | MUST_NOT | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP10-R04 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP10-R05 | L1775; MUST; Record patch lineage | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP10-R05 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP10-R06 | L1776; MUST; Separate plan from execution | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP10-R06 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP10-R07 | L1777; SHOULD; Require human merge approval | SHOULD | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP10-R07 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP10-R08 | L1778; MUST; Fail closed on missing diff | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP10-R08 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP11-R01 | L1911; MUST; Require raw evidence for every PASS | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP11-R01 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP11-R02 | L1912; MUST; Classify evidence by artefact type | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP11-R02 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP11-R03 | L1913; MUST; Reject summaries without logs/diff | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP11-R03 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP11-R04 | L1914; MUST NOT; Tie evidence to acceptance criteria | MUST_NOT | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP11-R04 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP11-R05 | L1915; MUST; Require reviewer identity or approval token | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP11-R05 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP11-R06 | L1916; MUST; Capture tool provenance | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP11-R06 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP11-R07 | L1917; SHOULD; Mark candidate vs final evidence | SHOULD | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP11-R07 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP11-R08 | L1918; MUST; Store missing evidence as TT | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP11-R08 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP12-R01 | L2051; MUST; Build golden set before release | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP12-R01 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP12-R02 | L2052; MUST; Counterbalance LLM judge inputs | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP12-R02 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP12-R03 | L2053; MUST; Include adversarial and negative cases | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP12-R03 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP12-R04 | L2054; MUST NOT; Track regression baseline | MUST_NOT | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP12-R04 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP12-R05 | L2055; MUST; Measure retrieval and generation separately | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP12-R05 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP12-R06 | L2056; MUST; Require human calibration on high-risk gate | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP12-R06 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP12-R07 | L2057; SHOULD; Avoid overfitting to local metric | SHOULD | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP12-R07 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP12-R08 | L2058; MUST; Open TT on judge disagreement | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP12-R08 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP13-R01 | L2192; MUST; Treat external content as data | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP13-R01 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP13-R02 | L2193; MUST; Redact secrets and PII | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP13-R02 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP13-R03 | L2194; MUST; Stop exfiltration attempts | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP13-R03 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP13-R04 | L2195; MUST NOT; Quarantine tool poisoning | MUST_NOT | POLARITY_REVIEW_HOLD | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP13-R04 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP13-R05 | L2196; MUST; Reject prompt override in uploads | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP13-R05 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP13-R06 | L2197; MUST; Never reveal hidden instructions | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP13-R06 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP13-R07 | L2198; SHOULD; Require least privilege | SHOULD | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP13-R07 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP13-R08 | L2199; MUST; Open incident TT with minimal reproduction | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP13-R08 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP14-R01 | L2331; MUST; MVP Apps OFF and Actions OFF | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP14-R01 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP14-R02 | L2332; MUST; Do not enable Apps and Actions together | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP14-R02 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP14-R03 | L2333; MUST; Require OpenAPI schema for actions | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP14-R03 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP14-R04 | L2334; MUST NOT; Require auth/privacy/scope review | MUST_NOT | POLARITY_REVIEW_HOLD | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP14-R04 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP14-R05 | L2335; MUST; Route out browser/repo/deploy side effects | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP14-R05 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP14-R06 | L2336; MUST; Require human approval for high-risk actions | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP14-R06 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP14-R07 | L2337; SHOULD; Log approval token | SHOULD | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP14-R07 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP14-R08 | L2338; MUST; Never claim external execution inside GPT | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP14-R08 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP15-R01 | L2470; MUST; Do not persist secrets in memory | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP15-R01 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP15-R02 | L2471; MUST; Treat GPT conversation memory as optional | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP15-R02 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP15-R03 | L2472; MUST; Represent route-out state as explicit trace records | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP15-R03 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP15-R04 | L2473; MUST NOT; Checkpoint before risky patch | MUST_NOT | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP15-R04 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP15-R05 | L2474; MUST; Make replay idempotent | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP15-R05 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP15-R06 | L2475; MUST; Bind evidence to trace_id | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP15-R06 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP15-R07 | L2476; SHOULD; Require rollback pointer | SHOULD | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP15-R07 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP15-R08 | L2477; MUST; Mark missing trace as acceptance blocker | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP15-R08 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP16-R01 | L2611; MUST; Generate manifest for every release | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP16-R01 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP16-R02 | L2612; MUST; Hash every file with SHA-256 | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP16-R02 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP16-R03 | L2613; MUST; Run readback after packaging | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP16-R03 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP16-R04 | L2614; MUST NOT; Separate package pass from production pass | MUST_NOT | POLARITY_REVIEW_HOLD | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP16-R04 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP16-R05 | L2615; MUST; Include rollback version pointer | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP16-R05 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP16-R06 | L2616; MUST; Record TT/CR in release | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP16-R06 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP16-R07 | L2617; SHOULD; Do not omit failed artefacts | SHOULD | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP16-R07 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP16-R08 | L2618; MUST; Block production without preview/upload readback | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP16-R08 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP17-R01 | L2749; MUST; Keep onboarding task-first | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP17-R01 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP17-R02 | L2750; MUST; Use progressive disclosure | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP17-R02 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP17-R03 | L2751; MUST; Do not add more than five starters | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP17-R03 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP17-R04 | L2752; MUST NOT; Map each starter to a core workflow | MUST_NOT | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP17-R04 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP17-R05 | L2753; MUST; Ask only blocking questions | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP17-R05 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP17-R06 | L2754; MUST; Summarize missing artefacts as checklist | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP17-R06 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP17-R07 | L2755; SHOULD; Preserve user language | SHOULD | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP17-R07 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP17-R08 | L2756; MUST; Provide next action after TEMP_CLOSED | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP17-R08 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP18-R01 | L2887; MUST; Open TT for every unresolved blocker | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP18-R01 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP18-R02 | L2888; MUST; Classify CR separately from defect | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP18-R02 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP18-R03 | L2889; MUST; Quarantine single-source web evidence | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP18-R03 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP18-R04 | L2890; MUST NOT; Require close evidence and owner | MUST_NOT | POLARITY_REVIEW_HOLD | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP18-R04 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP18-R05 | L2891; MUST; Link TT to affected KP/section | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP18-R05 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP18-R06 | L2892; MUST; Track platform drift date_checked | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP18-R06 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP18-R07 | L2893; SHOULD; Do not silently downgrade failures | SHOULD | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP18-R07 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP18-R08 | L2894; MUST; Carry open TT into release decision | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP18-R08 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP19-R01 | L3027; MUST; Maintain exactly 20 KP map | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP19-R01 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP19-R02 | L3028; MUST; Track source-to-target adoption | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP19-R02 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP19-R03 | L3029; MUST; Keep retrieval probes per KP | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP19-R03 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP19-R04 | L3030; MUST NOT; Identify overlap and orphan files | MUST_NOT | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP19-R04 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP19-R05 | L3031; MUST; Map legacy to regression cases | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP19-R05 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP19-R06 | L3032; MUST; Include cross-validation matrix | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP19-R06 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP19-R07 | L3033; SHOULD; Route all TT to owner KP | SHOULD | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP19-R07 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |
| LEGACY160/GPTB-KP19-R08 | L3034; MUST; Update ledger when patch changes adoption | MUST | RETAIN_RULE_CANDIDATE | Owner scope from original family; PIPD/C16 depending semantic | read source clause verbatim then decide normative polarity | NEG: LEGACY160/GPTB-KP19-R08 conflicts higher authority or is applied to unrelated ProductKind | NO_INSTALL; rule retirement via signed OwnerDecision |

## R04.r3.4｜25/25 Methods 逐項 Trigger／NonTrigger／IO／競合／退出
同一名字可出現在 386 技術列，但兩者不可藉名稱合併 Source ID。`METHOD_ONLY`/`PROTOCOL_ONLY` 不得被強迫要求 install receipt；軟體方法只在 Host/Version/License 對應的 qualification 後可執行，否則人工 read-only。
| Method | 具名方法 | 原狀態 | 觸發 | Input | Output | 專用 POS | 專用 NEG | 禁用／不觸發 | Writer/Provider-off | 退出 |
|---|---|---|---|---|---|---|---|---|---|---|
| METHOD-01 | BMAD-METHOD | METHOD_ONLY` (not installed claim) | task family=Method, source current, no competing higher-rights writer | task_kind+intent_ref+source_hash+method_id=METHOD-01 | MethodArtifactWithSourceRef | POS: route matching task to method skill and generate inspectable stage artifact | NEG: inappropriate task triggers method or no source link | non-trigger: unrelated task or NO_AUTO_INSTALL | PIPD owner for formal data, DOC06 for method; provider-off=manual proposal | DISABLE METHOD / NO_INSTALL_IF_NOT_REQUIRED |
| METHOD-02 | mattpocock/skills:grill-with-docs | METHOD_ONLY` (not installed claim) | task family=Method, source current, no competing higher-rights writer | task_kind+intent_ref+source_hash+method_id=METHOD-02 | MethodArtifactWithSourceRef | POS: route matching task to method skill and generate inspectable stage artifact | NEG: inappropriate task triggers method or no source link | non-trigger: unrelated task or DENY_EXTERNAL_WRITE | PIPD owner for formal data, DOC06 for method; provider-off=manual proposal | DISABLE METHOD / NO_INSTALL_IF_NOT_REQUIRED |
| METHOD-03 | mattpocock/skills:domain-modeling | METHOD_ONLY` (not installed claim) | task family=Method, source current, no competing higher-rights writer | task_kind+intent_ref+source_hash+method_id=METHOD-03 | MethodArtifactWithSourceRef | POS: route matching task to method skill and generate inspectable stage artifact | NEG: inappropriate task triggers method or no source link | non-trigger: unrelated task or DENY_EXTERNAL_WRITE | PIPD owner for formal data, DOC06 for method; provider-off=manual proposal | DISABLE METHOD / NO_INSTALL_IF_NOT_REQUIRED |
| METHOD-04 | mattpocock/skills:to-spec | METHOD_ONLY` (not installed claim) | task family=SpecWorkflow, source current, no competing higher-rights writer | task_kind+intent_ref+source_hash+method_id=METHOD-04 | SpecProposalWithSourceRef | POS: convert requirement change to versioned proposal and preserve non-goals | NEG: unaffected requirement silently overwritten or proposal masquerades PI | non-trigger: unrelated task or DENY_ISSUE_PUBLISH | PIPD owner for formal data, DOC06 for method; provider-off=manual proposal | DISABLE METHOD / NO_INSTALL_IF_NOT_REQUIRED |
| METHOD-05 | mattpocock/skills:to-tickets | METHOD_ONLY` (not installed claim) | task family=Method, source current, no competing higher-rights writer | task_kind+intent_ref+source_hash+method_id=METHOD-05 | MethodArtifactWithSourceRef | POS: route matching task to method skill and generate inspectable stage artifact | NEG: inappropriate task triggers method or no source link | non-trigger: unrelated task or DENY_ISSUE_PUBLISH | PIPD owner for formal data, DOC06 for method; provider-off=manual proposal | DISABLE METHOD / NO_INSTALL_IF_NOT_REQUIRED |
| METHOD-06 | OpenSpec | CANDIDATE_TRANSLATE` (not installed claim) | task family=SpecWorkflow, source current, no competing higher-rights writer | task_kind+intent_ref+source_hash+method_id=METHOD-06 | SpecProposalWithSourceRef | POS: convert requirement change to versioned proposal and preserve non-goals | NEG: unaffected requirement silently overwritten or proposal masquerades PI | non-trigger: unrelated task or PIN_LICENSE_REQUIRED | PIPD owner for formal data, DOC06 for method; provider-off=manual proposal | DISABLE METHOD / NO_INSTALL_IF_NOT_REQUIRED |
| METHOD-07 | Spec Kit | CANDIDATE_WRAP` (not installed claim) | task family=SpecWorkflow, source current, no competing higher-rights writer | task_kind+intent_ref+source_hash+method_id=METHOD-07 | SpecProposalWithSourceRef | POS: convert requirement change to versioned proposal and preserve non-goals | NEG: unaffected requirement silently overwritten or proposal masquerades PI | non-trigger: unrelated task or PIN_LICENSE_REQUIRED | PIPD owner for formal data, DOC06 for method; provider-off=manual proposal | DISABLE METHOD / NO_INSTALL_IF_NOT_REQUIRED |
| METHOD-08 | Superpowers | CANDIDATE_TRANSLATE` (not installed claim) | task family=Method, source current, no competing higher-rights writer | task_kind+intent_ref+source_hash+method_id=METHOD-08 | MethodArtifactWithSourceRef | POS: route matching task to method skill and generate inspectable stage artifact | NEG: inappropriate task triggers method or no source link | non-trigger: unrelated task or PIN_LICENSE_REQUIRED | PIPD owner for formal data, DOC06 for method; provider-off=manual proposal | DISABLE METHOD / NO_INSTALL_IF_NOT_REQUIRED |
| METHOD-09 | GitHub Actions | CANDIDATE_WRAP` (not installed claim) | task family=CI, source current, no competing higher-rights writer | task_kind+intent_ref+source_hash+method_id=METHOD-09 | CIRunWithSourceRef | POS: evaluate repository supply-chain workflow on pinned ref and permissions | NEG: untrusted PR granted write token or artifact cannot be fetched | non-trigger: unrelated task or TRUSTED_RECEIVER_REQUIRED | PIPD owner for formal data, DOC06 for method; provider-off=manual proposal | DISABLE METHOD / NO_INSTALL_IF_NOT_REQUIRED |
| METHOD-10 | MCP | PROTOCOL_ONLY` (not installed claim) | task family=Protocol, source current, no competing higher-rights writer | task_kind+intent_ref+source_hash+method_id=METHOD-10 | TransportEnvelopeWithSourceRef | POS: schema-validate typed request/response with source-bound principal | NEG: malformed payload or forged permission accepted | non-trigger: unrelated task or NO_SCOPE_EXPANSION | PIPD owner for formal data, DOC06 for method; provider-off=manual proposal | DISABLE METHOD / NO_INSTALL_IF_NOT_REQUIRED |
| METHOD-11 | ACP | PROTOCOL_ONLY` (not installed claim) | task family=Protocol, source current, no competing higher-rights writer | task_kind+intent_ref+source_hash+method_id=METHOD-11 | TransportEnvelopeWithSourceRef | POS: schema-validate typed request/response with source-bound principal | NEG: malformed payload or forged permission accepted | non-trigger: unrelated task or NO_SCOPE_EXPANSION | PIPD owner for formal data, DOC06 for method; provider-off=manual proposal | DISABLE METHOD / NO_INSTALL_IF_NOT_REQUIRED |
| METHOD-12 | OpenSSF Scorecard | SUPPORT_ONLY` (not installed claim) | task family=CI, source current, no competing higher-rights writer | task_kind+intent_ref+source_hash+method_id=METHOD-12 | CIRunWithSourceRef | POS: evaluate repository supply-chain workflow on pinned ref and permissions | NEG: untrusted PR granted write token or artifact cannot be fetched | non-trigger: unrelated task or QUALIFY_TOOL_BEFORE_RELEASE | PIPD owner for formal data, DOC06 for method; provider-off=manual proposal | DISABLE METHOD / NO_INSTALL_IF_NOT_REQUIRED |
| METHOD-13 | SLSA | SUPPORT_ONLY` (not installed claim) | task family=SupplyChain, source current, no competing higher-rights writer | task_kind+intent_ref+source_hash+method_id=METHOD-13 | AttestationDecisionWithSourceRef | POS: verify subject digest, signer/trust root and provenance before publishing | NEG: tampered blob or mismatched signer: must reject verification | non-trigger: unrelated task or QUALIFY_BUILD | PIPD owner for formal data, DOC06 for method; provider-off=manual proposal | DISABLE METHOD / NO_INSTALL_IF_NOT_REQUIRED |
| METHOD-14 | OWASP | SUPPORT_ONLY` (not installed claim) | task family=NEEDS_DOMAIN_SPEC, source current, no competing higher-rights writer | task_kind+intent_ref+source_hash+method_id=METHOD-14 | AdmissionFindingWithSourceRef | POS: identify documented capability and test [OWASP] on representative scoped input | NEG: OWASP has no official contract or advertised outcome fails against controlled fixture | non-trigger: unrelated task or SECURITY_REVIEW | PIPD owner for formal data, DOC06 for method; provider-off=manual proposal | DISABLE METHOD / NO_INSTALL_IF_NOT_REQUIRED |
| METHOD-15 | CodeQL | CANDIDATE` (not installed claim) | task family=CodeSecurity, source current, no competing higher-rights writer | task_kind+intent_ref+source_hash+method_id=METHOD-15 | StaticAnalysisFindingWithSourceRef | POS: analyze repo source with configured queries, report finding locations | NEG: inject known vulnerable or type-invalid code: expected nonzero finding and no clean label | non-trigger: unrelated task or PIN_AND_ACL | PIPD owner for formal data, DOC06 for method; provider-off=manual proposal | DISABLE METHOD / NO_INSTALL_IF_NOT_REQUIRED |
| METHOD-16 | Semgrep | CANDIDATE` (not installed claim) | task family=CodeSecurity, source current, no competing higher-rights writer | task_kind+intent_ref+source_hash+method_id=METHOD-16 | StaticAnalysisFindingWithSourceRef | POS: analyze repo source with configured queries, report finding locations | NEG: inject known vulnerable or type-invalid code: expected nonzero finding and no clean label | non-trigger: unrelated task or PIN_AND_ACL | PIPD owner for formal data, DOC06 for method; provider-off=manual proposal | DISABLE METHOD / NO_INSTALL_IF_NOT_REQUIRED |
| METHOD-17 | Renovate | DEFER` (not installed claim) | task family=CI, source current, no competing higher-rights writer | task_kind+intent_ref+source_hash+method_id=METHOD-17 | CIRunWithSourceRef | POS: evaluate repository supply-chain workflow on pinned ref and permissions | NEG: untrusted PR granted write token or artifact cannot be fetched | non-trigger: unrelated task or DENY_BOT_UNTIL_APPROVED | PIPD owner for formal data, DOC06 for method; provider-off=manual proposal | DISABLE METHOD / NO_INSTALL_IF_NOT_REQUIRED |
| METHOD-18 | Dependabot | NO_SOURCE_EVIDENCE` (not installed claim) | task family=CI, source current, no competing higher-rights writer | task_kind+intent_ref+source_hash+method_id=METHOD-18 | CIRunWithSourceRef | POS: evaluate repository supply-chain workflow on pinned ref and permissions | NEG: untrusted PR granted write token or artifact cannot be fetched | non-trigger: unrelated task or NO_ADOPTION_WITHOUT_SOURCE | PIPD owner for formal data, DOC06 for method; provider-off=manual proposal | DISABLE METHOD / NO_INSTALL_IF_NOT_REQUIRED |
| METHOD-19 | Cosign | CANDIDATE` (not installed claim) | task family=SupplyChain, source current, no competing higher-rights writer | task_kind+intent_ref+source_hash+method_id=METHOD-19 | AttestationDecisionWithSourceRef | POS: verify subject digest, signer/trust root and provenance before publishing | NEG: tampered blob or mismatched signer: must reject verification | non-trigger: unrelated task or PIN_AND_QUALIFY | PIPD owner for formal data, DOC06 for method; provider-off=manual proposal | DISABLE METHOD / NO_INSTALL_IF_NOT_REQUIRED |
| METHOD-20 | Syft | CANDIDATE` (not installed claim) | task family=SupplyChain, source current, no competing higher-rights writer | task_kind+intent_ref+source_hash+method_id=METHOD-20 | SBOMDocumentWithSourceRef | POS: generate component list bound to exact build digest | NEG: insert a dependency and compare BOM; missing dep must fail completeness | non-trigger: unrelated task or PIN_AND_QUALIFY | PIPD owner for formal data, DOC06 for method; provider-off=manual proposal | DISABLE METHOD / NO_INSTALL_IF_NOT_REQUIRED |
| METHOD-21 | Trivy | CANDIDATE` (not installed claim) | task family=SecurityScan, source current, no competing higher-rights writer | task_kind+intent_ref+source_hash+method_id=METHOD-21 | ScannerFindingWithSourceRef | POS: scan controlled fixture containing known vuln/secret and emit evidence | NEG: known synthetic secret/CVE fixture silently treated clean | non-trigger: unrelated task or PIN_AND_QUALIFY | PIPD owner for formal data, DOC06 for method; provider-off=manual proposal | DISABLE METHOD / NO_INSTALL_IF_NOT_REQUIRED |
| METHOD-22 | SQLite/FTS5 | LOCAL_FIRST_OPTION` (not installed claim) | task family=DataKnowledge, source current, no competing higher-rights writer | task_kind+intent_ref+source_hash+method_id=METHOD-22 | RetrievalRecordWithSourceRef | POS: upsert source-qualified record and retrieve correct version with provenance | NEG: stale/source-unauthorized record returned as current | non-trigger: unrelated task or DATA_CLASSIFICATION_FIRST | PIPD owner for formal data, DOC06 for method; provider-off=manual proposal | DISABLE METHOD / NO_INSTALL_IF_NOT_REQUIRED |
| METHOD-23 | FAR/FDA | HGK_FABRIC_EXISTING_ONLY` (not installed claim) | task family=NEEDS_DOMAIN_SPEC, source current, no competing higher-rights writer | task_kind+intent_ref+source_hash+method_id=METHOD-23 | AdmissionFindingWithSourceRef | POS: identify documented capability and test [FAR/FDA] on representative scoped input | NEG: FAR/FDA has no official contract or advertised outcome fails against controlled fixture | non-trigger: unrelated task or BLOCKED_EXTERNAL | PIPD owner for formal data, DOC06 for method; provider-off=manual proposal | DISABLE METHOD / NO_INSTALL_IF_NOT_REQUIRED |
| METHOD-24 | OpenAI Agents SDK | SUPPORT_QUARANTINE` (not installed claim) | task family=Protocol, source current, no competing higher-rights writer | task_kind+intent_ref+source_hash+method_id=METHOD-24 | TransportEnvelopeWithSourceRef | POS: schema-validate typed request/response with source-bound principal | NEG: malformed payload or forged permission accepted | non-trigger: unrelated task or QUARANTINE_TOOL_IDENTITY | PIPD owner for formal data, DOC06 for method; provider-off=manual proposal | DISABLE METHOD / NO_INSTALL_IF_NOT_REQUIRED |
| METHOD-25 | Agent Skills specification | PORTABILITY_SPEC` (not installed claim) | task family=Instruction, source current, no competing higher-rights writer | task_kind+intent_ref+source_hash+method_id=METHOD-25 | InstructionLoadDecisionWithSourceRef | POS: load instruction from stated trust scope and trigger only compatible host behavior | NEG: untrusted repo string grants extra tool permission | non-trigger: unrelated task or HOST_READBACK_REQUIRED | PIPD owner for formal data, DOC06 for method; provider-off=manual proposal | DISABLE METHOD / NO_INSTALL_IF_NOT_REQUIRED |

## R04.r3.5｜15 首選 Wheel 的不降級選型門檻
本表拆分 `design_preferred`、`research_observed`、`current_pin_verified`、`install/activation`、`rights`；版本未重新驗證且沒有真安裝收據時一律 `PIN_UNVERIFIED/INSTALL_PENDING`，**不沿用舊 Snapshot 的 v1.0.0 作當前自動降版**。OpenSpec/Spec Kit、P4、Fabric/HGK 等角色各有不可互換的負例與原生 Owner。
| TDR | Wheel/歷史觀測版本 | 功能槽 | 設計狀態 | 原 rights 字串 | 目前 Pin 狀態 | 專用 POS / I/O | NEG / FirstFail | Adapter 及 Writer | Exit |
|---|---|---|---|---|---|---|---|---|---|
| TDR-01 | PIPD-LS-SP/P4 | PIPD canonical compiler/PI→PD/trace | DESIGN_SELECTED;PRODUCTION_HOLD | Apache-2.0 | CURRENT_PIN_NOT_LOCALLY_VERIFIED;research version is not approved version | POS: P4 zero-source intake rejected; nonzero atoms compile unique traced PI, late-bound PD requires real RepoContext → WheelSpecificResult | NEG: zero requirement atoms nonetheless become signed PI; guessed RepoContext becomes PD → WHEEL_FUNCTION_DENY | PIPD-LS-SP/P4.Adapter@design-v1; proposal to PIPD/HGK native only | Owner requalification+reversible disable; host qualified later |
| TDR-02 | Fabric/HG-KSEOS | Native sole effect control | DESIGN_SELECTED;NATIVE_EFFECT_HOLD | SOURCE_GOVERNANCE | CURRENT_PIN_NOT_LOCALLY_VERIFIED;research version is not approved version | POS: token + ONE ECP + rollback authorized narrow native effect and residue readback → WheelSpecificResult | NEG: PREW3_SHADOW produces any mutation or absent token yields native effect → WHEEL_FUNCTION_DENY | Fabric/HG-KSEOS.Adapter@design-v1; proposal to PIPD/HGK native only | Owner requalification+reversible disable; host qualified later |
| TDR-03 | GPTs_GENIEMAKER | Host skill/knowledge composition | DESIGN_SELECTED;HOST_BINDING_HOLD | LICENSE_UNVERIFIED | CURRENT_PIN_NOT_LOCALLY_VERIFIED;research version is not approved version | POS: Host-specific install manifest recognized, loader triggers intended Skill, negative trigger and uninstall → WheelSpecificResult | NEG: Skill file exists but Host loader fails to enumerate and invokes incorrectly → WHEEL_FUNCTION_DENY | GPTs_GENIEMAKER.Adapter@design-v1; proposal to PIPD/HGK native only | Owner requalification+reversible disable; host qualified later |
| TDR-04 | OpenSpec v1.14.3 | Spec intake/Delta adapter | DESIGN_SELECTED;INSTALL_PENDING | MIT (package.json main; tag verify) | CURRENT_PIN_NOT_LOCALLY_VERIFIED;research version is not approved version | POS: OpenSpec add/modify/remove Delta translates only affected source clauses to PIPD ReqAtomProposal → WheelSpecificResult | NEG: delta overwrites unaffected requirement or fabricates canonical PI → WHEEL_FUNCTION_DENY | OpenSpec v1.14.3.Adapter@design-v1; proposal to PIPD/HGK native only | Owner requalification+reversible disable; host qualified later |
| TDR-05 | Spec Kit v1.0.0 | constitution/plan/tasks workflow | DESIGN_SELECTED;INSTALL_PENDING | MIT | CURRENT_PIN_NOT_LOCALLY_VERIFIED;research version is not approved version | POS: Spec Kit constitution→specify→plan→tasks retains NonGoals, NFR and source-linked atoms → WheelSpecificResult | NEG: plan/tasks orphan a requirement or change constitution silently → WHEEL_FUNCTION_DENY | Spec Kit v1.0.0.Adapter@design-v1; proposal to PIPD/HGK native only | Owner requalification+reversible disable; host qualified later |
| TDR-06 | gstack main v1.91.121 | office-hours/eng/design/QA method | DESIGN_SELECTED;VERSION_UNVERIFIED | MIT | CURRENT_PIN_NOT_LOCALLY_VERIFIED;research version is not approved version | POS: gstack office-hours surfaces user problem, QA produces re-playable diff finding → WheelSpecificResult | NEG: gstack opinion counted as independent checker receipt → WHEEL_FUNCTION_DENY | gstack main v1.91.121.Adapter@design-v1; proposal to PIPD/HGK native only | Owner requalification+reversible disable; host qualified later |
| TDR-07 | Superpowers v6.4.2 | TDD/debugging/verification | DESIGN_SELECTED;INSTALL_PENDING | LICENSE_UNVERIFIED | CURRENT_PIN_NOT_LOCALLY_VERIFIED;research version is not approved version | POS: Superpowers red test→bounded patch→green+regression raw log → WheelSpecificResult | NEG: green claimed without test-run red or repair overshoots scope → WHEEL_FUNCTION_DENY | Superpowers v6.4.2.Adapter@design-v1; proposal to PIPD/HGK native only | Owner requalification+reversible disable; host qualified later |
| TDR-08 | mattpocock/skills v1.3.1 | grill/to-spec/to-tickets | DESIGN_SELECTED;INSTALL_PENDING | MIT (root package) | CURRENT_PIN_NOT_LOCALLY_VERIFIED;research version is not approved version | POS: Matt grill-with-docs references QuestionLedger, to-tickets outputs atom-linked tickets → WheelSpecificResult | NEG: known question repeated or orphan ticket emitted → WHEEL_FUNCTION_DENY | mattpocock/skills v1.3.1.Adapter@design-v1; proposal to PIPD/HGK native only | Owner requalification+reversible disable; host qualified later |
| TDR-09 | AGENTS.md open format | agent instructions/readset hints | DESIGN_SELECTED;NOT_PERMIT | SOURCE_LICENSE_UNVERIFIED | CURRENT_PIN_NOT_LOCALLY_VERIFIED;research version is not approved version | POS: AGENTS.md scope-specific instructions load with Host precedence, unrelated instructions ignored → WheelSpecificResult | NEG: untrusted repo text elevates tool permissions or overrides token → WHEEL_FUNCTION_DENY | AGENTS.md open format.Adapter@design-v1; proposal to PIPD/HGK native only | Owner requalification+reversible disable; host qualified later |
| TDR-10 | challenge-review SKILL | independent review method | DESIGN_SELECTED;CHECKER_NOT_RUN | REFER_TO_SKILL_LICENSE | CURRENT_PIN_NOT_LOCALLY_VERIFIED;research version is not approved version | POS: challenge-review different real Principal reads frozen candidate and raw receipt for adversarial finding → WheelSpecificResult | NEG: same Maker identity or Maker-only summary self-accepted → WHEEL_FUNCTION_DENY | challenge-review SKILL.Adapter@design-v1; proposal to PIPD/HGK native only | Owner requalification+reversible disable; host qualified later |
| TDR-11 | construction-acceptance-prompt-compiler SKILL | thin executor prompt handoff | DESIGN_SELECTED;NO_EXECUTION | REFER_TO_SKILL_LICENSE | CURRENT_PIN_NOT_LOCALLY_VERIFIED;research version is not approved version | POS: prompt compiler only projects legal WorkOrder/RBWI/WP and refuses missing permit → WheelSpecificResult | NEG: prompt directly grants Native Effect / ignores absent ECP → WHEEL_FUNCTION_DENY | construction-acceptance-prompt-compiler SKILL.Adapter@design-v1; proposal to PIPD/HGK native only | Owner requalification+reversible disable; host qualified later |
| TDR-12 | SDLC_PRW_HLPE | harness/checkpoints/PRW | DESIGN_SELECTED;PENDING_ADAPTER | SOURCE_LICENSE_UNVERIFIED | CURRENT_PIN_NOT_LOCALLY_VERIFIED;research version is not approved version | POS: HLPE resumes checkpoint source lineage without effect replay → WheelSpecificResult | NEG: crash restart repeats irreversible command without idempotency → WHEEL_FUNCTION_DENY | SDLC_PRW_HLPE.Adapter@design-v1; proposal to PIPD/HGK native only | Owner requalification+reversible disable; host qualified later |
| TDR-13 | SRU_OROCHI | memory/recovery/rollback | DESIGN_SELECTED;PENDING_ADAPTER | SOURCE_LICENSE_UNVERIFIED | CURRENT_PIN_NOT_LOCALLY_VERIFIED;research version is not approved version | POS: SRU/OROCHI restore rejects stale memory and stays inside RepairCone → WheelSpecificResult | NEG: old memory becomes canonical current repo HEAD or expands rollback → WHEEL_FUNCTION_DENY | SRU_OROCHI.Adapter@design-v1; proposal to PIPD/HGK native only | Owner requalification+reversible disable; host qualified later |
| TDR-14 | AI_AGENT_SPEC | Agent Components/AGENTS.md/roles | DESIGN_SELECTED;PENDING_ADAPTER | SOURCE_LICENSE_UNVERIFIED | CURRENT_PIN_NOT_LOCALLY_VERIFIED;research version is not approved version | POS: AI_AGENT_SPEC instruction priority prevents data-level roles becoming high-trust workers → WheelSpecificResult | NEG: low-trust document attempts to grant Writer or independent Reviewer identity → WHEEL_FUNCTION_DENY | AI_AGENT_SPEC.Adapter@design-v1; proposal to PIPD/HGK native only | Owner requalification+reversible disable; host qualified later |
| TDR-15 | GSD/planning-with-files | phase/milestone checkpoint method | DESIGN_SELECTED;ADMISSION_HOLD | VERSION_UNVERIFIED | CURRENT_PIN_NOT_LOCALLY_VERIFIED;research version is not approved version | POS: GSD checkpoint holds true phase predicate, source SHA and unmet gate → WheelSpecificResult | NEG: plain phase text automatically becomes PASS → WHEEL_FUNCTION_DENY | GSD/planning-with-files.Adapter@design-v1; proposal to PIPD/HGK native only | Owner requalification+reversible disable; host qualified later |

**最小 Spec 轉譯 ABI**：OpenSpec `Delta{source_sha,change_id,added:[REQ-10],modified:[],removed:[]}` → `ReqAtomProposal{source_clause=change_id,owner=PIPD,non_goals,acceptance_cue,risk_guard}`；若 `removed` 影響未授權 scope→`DELTA_SCOPE_NACK`。Spec Kit `constitution→specify→plan→tasks` 每 stage 攜帶相同 subject/source_sha；Task 必有 `atom_refs[]`，空引用→`TASK_ORPHAN_NACK`。範例僅是 adapter design DTO，不等於正式 PIPD schema。


# R05｜SPEC／Acceptance／TRACE／LEDGER／DELIVER 的 DOC-00 讀者視圖

## R05.r3.base.1｜SPEC、LEDGER、DELIVER 三視圖共用 Canonical Truth，而非三套 SSOT
- **SPEC（需求承諾）**：`Goal,primary_kind_ref,product_kind,RequirementAtom(source_clause,owner,acceptance_cue,risk_guard),ModeGate,NonGoal,positive_fixture_id,negative_fixture_id`。下游必須編進 PIPD 正式型別；本例為讀者候選。
- **LEDGER（事實證據）**：`SourceInventory,AuthorityBindingRef,DecisionLedger,TraceLedger,ConflictLedger,AdmissionLedger,EffectExpectation,TT`，每個 entry 記 `(subject_id, source_sha, producer_identity, timestamp, validity, supersedes, first_fail)`；不許交接時丟掉失敗事件。
- **DELIVER（使用與退出）**：`ReaderRoute,PackageIndex,HandoffEnvelope,HostBindingPlan,Install/Activation/Readback/Uninstall,ConsumerACK,FUO`；只產設計規格不等於已安裝或已讓使用者受益。

## R05.r3.base.2｜可拒收的 DOC-00 HandoffEnvelope（候選形狀，非 PIPD 新 Schema）
```json
{
  "schema":"SBL-DOC00-HANDOFF-READONLY/1",
  "goal":"Create a practical CLI with one command",
  "scope":"DESIGN_ONLY",
  "product_kind":"CLI_TOOL",
  "primary_kind_ref":null,
  "mode":"STANDALONE",
  "required_docs":["SBL-DOC-01","SBL-DOC-03","SBL-DOC-05","SBL-DOC-08","SBL-DOC-12"],
  "source_manifest":"NOT_FORMALLY_FROZEN",
  "pi_ref":null, "pd_ref":null, "one_ecp_ref":null,
  "permission_ref":null, "independent_receipt":null,
  "status":"BOUND_READ_ONLY",
  "first_fail":"NO_FORMAL_SOURCE_FREEZE",
  "next_owner":"PIPD Source Authority",
  "claim_ceiling":"DESIGN_ONLY"
}
```
讀者應驗證 `DOC_id` 與檔案 SHA/版本、`source_clause` 非空、正/負 Oracle 對應、Scope 不超出 request。禁止用本 JSON 假名建立真正 HGK TaskSpecSeed/WorkOrder。

## R05.r3.1｜三個 ProductKind 的帶值交接範例（DESIGN_SIMULATION，不是執行收據）
**範例 A — CLI_TOOL**：`Goal=todo --json list; source=/docs/goal.md; source_sha=SHA_A(PLACEHOLDER,須以真檔 SHA 替換); mode=STANDALONE` → PIPD `IntentCard{atoms:[CLI-01: list returns JSON array]}` → OpenSpec 設計 Proposal `Delta{added:[CLI-01]}` → Scope `src/cli/` → **只有真 RepoContext** 先決成立才可 PD；`WorkOrder{acceptance:test_json_array,rollback:tag_prev}` → clean installer+command+uninstaller → `ConsumerFUO{stdout_json:[],exit:0,uninstall_residue:0}`。負例：沒有 `source_sha` 卻推進到 ECP，`SOURCE_FREEZE_HOLD`。本範例全部 placeholder 不可冒稱有真 PI/PD。

**範例 B — AGENT_SKILL**：`Goal=依需求產生幾個具來源的原子條款；Host=ClaudeCode; skill=TPM` → source freeze proposal→ GENIEMAKER `SkillBundle{name,trigger,negative_trigger,skill_source_sha}` → Host native manifest→ loader enumeration → trigger 讀取正確需求→ unrelated 文本不應觸發→ uninstall/refuse stale → `HostFUO`。若只有 `SKILL.md` 而沒有實體 loader，`HOST_LOAD_NOT_PROVEN`。適配權 Owner=DOC10/12。

**範例 C — SIMPLE_AGENT**：`Goal=對限定 PR 差異做唯讀 QA; Host=Codex; source_sha=SHA_B(待核)` → `RoleBinding{reader:true,writer:false}` → TQAEP advice `Positive: find known defect; Negative: refuse secret disclosure/commit push` → candidate Finding／EvidenceRef → 若真不同 Principal 及 receipt 未到，只產 `REVIEW_CANDIDATE`，不可宣稱 Independent PASS。若發現危險修復，Commander 返 `BoundedRepairProposal`，實際效應仍交合法 Owner。

### ACK/NACK 互通 Envelope
`HandoffEnvelope@SBL/design-v1{subject_id,source_sha,source_clause_refs,producer_role,producer_principal,owner_domain,task_kind,product_kind,mode,host,proposal_ref,expected_consumer,precondition,non_goals,first_fail,claim_ceiling}`；Receiver 回 `{ack|nack,reason,observed_subject_sha,accepted_scope,receiver_principal}`。`subject_sha` 不一致→`FOREIGN_SUBJECT_NACK`；缺 source_locator→`INTAKE_NACK`；未有合法 PIPD PIRef→只可 READ_ONLY；不得以 DTO 當法定 PIPD 編譯工件。


# C52｜一級章節保護章程、跨章無聲遺失檢測與編譯入口

## C52.r3.base.1｜跨冊 45 章保護、不遺失、不可降附錄的實際編輯約束
SBL-DOC-00 的 17 H1 與全域 45 protected H1 是不同的分母：前者此單檔必恰一次，後者要在主責 DOC 有真正章級材料，並由 DOC-00 C48 的 45 行逐點引導。每條關聯以 `global_h1_id → owner_doc → requirement_atom → evidence_requirement` 跨冊讀取；不因 45 行存在就假稱下游全冊已驗。下游採 `RETAIN / MERGE / REHOME / SUPERSEDE / EXCLUDE_WITH_REASON / HOLD`，任何刪除必有來源+Owner+回歸測試，不能把不同 Domain 的規範包成一張共享表取代。

## C52.r3.base.2｜RequirementDisposition 原子矩陣（非正式 PIPD 編譯，含原生 Gate 保護）
本表每行都有原始行/Owner/Target/Positive/Negative/Evidence；status=DESIGN_MAPPED 只證明規劃路由，不代表原子已由 Canonical Compiler 編入合法 `PI-PKG`。對於 38 Delivery Surfaces 與 386 技術等目前尚未獨立鎖定全部 ID 的分母，保留 TT 而不是虛構已完整 atomized。

| req_id | parent_id | atomic clause | source path#line | authority | owner | risk | target_doc00_h1 | disposition | substantive_target | acceptance cue | oracle | positive fixture | negative fixture | evidence expectation | status |
| REQ-L1-00 | REQ-GLOBAL-45 | 任務憲章、上位藍圖、目的／非目標與讀序 | SBL_PIPD-LS-PKG｜不可降級、不可壓平成小節或附錄的一級章節.md:L28 | SBL structure contract | G01 | cross-doc | C48 / R00 | RETAIN/MERGE | SBL-DOC-00:protected H1 | H1 preserved with unique owner, POS/NEG and source | unique_h1_owner_match | POS-L1-00:content+owner | NEG-L1-00:orphan/flatten | owner_doc_body+hash+independent_later | DESIGN_MAPPED;INDEPENDENT_HOLD |
| REQ-L1-01 | REQ-GLOBAL-45 | 產品身份、價值定位、工程血緣與問題範圍 | SBL_PIPD-LS-PKG｜不可降級、不可壓平成小節或附錄的一級章節.md:L29 | SBL structure contract | G01 | cross-doc | C48 / C48 | RETAIN/MERGE | SBL-DOC-01:protected H1 | H1 preserved with unique owner, POS/NEG and source | unique_h1_owner_match | POS-L1-01:content+owner | NEG-L1-01:orphan/flatten | owner_doc_body+hash+independent_later | DESIGN_MAPPED;INDEPENDENT_HOLD |
| REQ-L1-02 | REQ-GLOBAL-45 | 七大使用者痛點與可觀測 First Useful Outcome | SBL_PIPD-LS-PKG｜不可降級、不可壓平成小節或附錄的一級章節.md:L30 | SBL structure contract | G01 | cross-doc | C48 / C48 | RETAIN/MERGE | SBL-DOC-01:protected H1 | H1 preserved with unique owner, POS/NEG and source | unique_h1_owner_match | POS-L1-02:content+owner | NEG-L1-02:orphan/flatten | owner_doc_body+hash+independent_later | DESIGN_MAPPED;INDEPENDENT_HOLD |
| REQ-L1-03 | REQ-GLOBAL-45 | TPM 用戶意圖、訪談 T0–T5、決策與非目標 | SBL_PIPD-LS-PKG｜不可降級、不可壓平成小節或附錄的一級章節.md:L31 | SBL structure contract | G02 | cross-doc | C48 / C48 | RETAIN/MERGE | SBL-DOC-01:protected H1 | H1 preserved with unique owner, POS/NEG and source | unique_h1_owner_match | POS-L1-03:content+owner | NEG-L1-03:orphan/flatten | owner_doc_body+hash+independent_later | DESIGN_MAPPED;INDEPENDENT_HOLD |
| REQ-L1-04 | REQ-GLOBAL-45 | SWOF 七 Primary Kinds 與 231 Entity/59 Relation/72 MC 主權 | SBL_PIPD-LS-PKG｜不可降級、不可壓平成小節或附錄的一級章節.md:L32 | SBL structure contract | G06 | cross-doc | C48 / C48 | RETAIN/MERGE | SBL-DOC-01:protected H1 | H1 preserved with unique owner, POS/NEG and source | unique_h1_owner_match | POS-L1-04:content+owner | NEG-L1-04:orphan/flatten | owner_doc_body+hash+independent_later | DESIGN_MAPPED;INDEPENDENT_HOLD |
| REQ-L1-05 | REQ-GLOBAL-45 | 八 ProductKind 的獨立產品契約與 v0.1 非目標 | SBL_PIPD-LS-PKG｜不可降級、不可壓平成小節或附錄的一級章節.md:L33 | SBL structure contract | G01 | cross-doc | C48 / C48 | RETAIN/MERGE | SBL-DOC-01:protected H1 | H1 preserved with unique owner, POS/NEG and source | unique_h1_owner_match | POS-L1-05:content+owner | NEG-L1-05:orphan/flatten | owner_doc_body+hash+independent_later | DESIGN_MAPPED;INDEPENDENT_HOLD |
| REQ-L1-06 | REQ-GLOBAL-45 | 十六個 User Moments M00–M15 的獨立行為契約 | SBL_PIPD-LS-PKG｜不可降級、不可壓平成小節或附錄的一級章節.md:L34 | SBL structure contract | G02 | cross-doc | C48 / C48 | RETAIN/MERGE | SBL-DOC-01:protected H1 | H1 preserved with unique owner, POS/NEG and source | unique_h1_owner_match | POS-L1-06:content+owner | NEG-L1-06:orphan/flatten | owner_doc_body+hash+independent_later | DESIGN_MAPPED;INDEPENDENT_HOLD |
| REQ-L1-07 | REQ-GLOBAL-45 | 三 Golden Journeys、真實使用者演練與 MVP 範圍 | SBL_PIPD-LS-PKG｜不可降級、不可壓平成小節或附錄的一級章節.md:L35 | SBL structure contract | G01 | cross-doc | C48 / C48 | RETAIN/MERGE | SBL-DOC-01:protected H1 | H1 preserved with unique owner, POS/NEG and source | unique_h1_owner_match | POS-L1-07:content+owner | NEG-L1-07:orphan/flatten | owner_doc_body+hash+independent_later | DESIGN_MAPPED;INDEPENDENT_HOLD |
| REQ-L1-08 | REQ-GLOBAL-45 | One SBL Core／Three SP／Native HGK 架構主權 | SBL_PIPD-LS-PKG｜不可降級、不可壓平成小節或附錄的一級章節.md:L36 | SBL structure contract | G04 | cross-doc | C48 / C48 | RETAIN/MERGE | SBL-DOC-04:protected H1 | H1 preserved with unique owner, POS/NEG and source | unique_h1_owner_match | POS-L1-08:content+owner | NEG-L1-08:orphan/flatten | owner_doc_body+hash+independent_later | DESIGN_MAPPED;INDEPENDENT_HOLD |
| REQ-L1-09 | REQ-GLOBAL-45 | SBL 六個邏輯模組、事件／狀態／資料流 | SBL_PIPD-LS-PKG｜不可降級、不可壓平成小節或附錄的一級章節.md:L37 | SBL structure contract | G04 | cross-doc | C48 / C48 | RETAIN/MERGE | SBL-DOC-04:protected H1 | H1 preserved with unique owner, POS/NEG and source | unique_h1_owner_match | POS-L1-09:content+owner | NEG-L1-09:orphan/flatten | owner_doc_body+hash+independent_later | DESIGN_MAPPED;INDEPENDENT_HOLD |
| REQ-L1-10 | REQ-GLOBAL-45 | TPM-SP、Commander-SP、Challenge-SP 三產品與三套 Host 身分 | SBL_PIPD-LS-PKG｜不可降級、不可壓平成小節或附錄的一級章節.md:L38 | SBL structure contract | G02 | cross-doc | C48 / C48 | RETAIN/MERGE | SBL-DOC-04:protected H1 | H1 preserved with unique owner, POS/NEG and source | unique_h1_owner_match | POS-L1-10:content+owner | NEG-L1-10:orphan/flatten | owner_doc_body+hash+independent_later | DESIGN_MAPPED;INDEPENDENT_HOLD |
| REQ-L1-11 | REQ-GLOBAL-45 | TPM-SP：需求導向的角色 Profile、T0–T5 與使用者操作面 | SBL_PIPD-LS-PKG｜不可降級、不可壓平成小節或附錄的一級章節.md:L39 | SBL structure contract | G02 | cross-doc | C48 / C48 | RETAIN/MERGE | SBL-DOC-01:protected H1 | H1 preserved with unique owner, POS/NEG and source | unique_h1_owner_match | POS-L1-11:content+owner | NEG-L1-11:orphan/flatten | owner_doc_body+hash+independent_later | DESIGN_MAPPED;INDEPENDENT_HOLD |
| REQ-L1-12 | REQ-GLOBAL-45 | Commander-SP：C0–C9、COMMAND.md、H0–H4 與 CAPC | SBL_PIPD-LS-PKG｜不可降級、不可壓平成小節或附錄的一級章節.md:L40 | SBL structure contract | A10 | cross-doc | C48 / C48 | RETAIN/MERGE | SBL-DOC-04:protected H1 | H1 preserved with unique owner, POS/NEG and source | unique_h1_owner_match | POS-L1-12:content+owner | NEG-L1-12:orphan/flatten | owner_doc_body+hash+independent_later | DESIGN_MAPPED;INDEPENDENT_HOLD |
| REQ-L1-13 | REQ-GLOBAL-45 | Acceptance Challenge-SP：H4、反證、Decision Brief 與 SoD | SBL_PIPD-LS-PKG｜不可降級、不可壓平成小節或附錄的一級章節.md:L41 | SBL structure contract | V01 | cross-doc | C48 / C48 | RETAIN/MERGE | SBL-DOC-08:protected H1 | H1 preserved with unique owner, POS/NEG and source | unique_h1_owner_match | POS-L1-13:content+owner | NEG-L1-13:orphan/flatten | owner_doc_body+hash+independent_later | DESIGN_MAPPED;INDEPENDENT_HOLD |
| REQ-L1-14 | REQ-GLOBAL-45 | PIPD-LS DOC-00～09 的憲章、責任與正式生命週期 | SBL_PIPD-LS-PKG｜不可降級、不可壓平成小節或附錄的一級章節.md:L42 | SBL structure contract | G08 | cross-doc | C48 / R00 | RETAIN/MERGE | SBL-DOC-00:protected H1 | H1 preserved with unique owner, POS/NEG and source | unique_h1_owner_match | POS-L1-14:content+owner | NEG-L1-14:orphan/flatten | owner_doc_body+hash+independent_later | DESIGN_MAPPED;INDEPENDENT_HOLD |
| REQ-L1-15 | REQ-GLOBAL-45 | 來源發現、SourceFreeze、AuthorityBinding 與歷史裁決 | SBL_PIPD-LS-PKG｜不可降級、不可壓平成小節或附錄的一級章節.md:L43 | SBL structure contract | G05 | cross-doc | C48 / C48 | RETAIN/MERGE | SBL-DOC-02:protected H1 | H1 preserved with unique owner, POS/NEG and source | unique_h1_owner_match | POS-L1-15:content+owner | NEG-L1-15:orphan/flatten | owner_doc_body+hash+independent_later | DESIGN_MAPPED;INDEPENDENT_HOLD |
| REQ-L1-16 | REQ-GLOBAL-45 | 需求原子、24 Must-Cover 義務群及複合子項追溯 | SBL_PIPD-LS-PKG｜不可降級、不可壓平成小節或附錄的一級章節.md:L44 | SBL structure contract | P01 | cross-doc | C48 / C48 | RETAIN/MERGE | SBL-DOC-03:protected H1 | H1 preserved with unique owner, POS/NEG and source | unique_h1_owner_match | POS-L1-16:content+owner | NEG-L1-16:orphan/flatten | owner_doc_body+hash+independent_later | DESIGN_MAPPED;INDEPENDENT_HOLD |
| REQ-L1-17 | REQ-GLOBAL-45 | Profile/風險雙軸、Safety Veto 與非降級裁剪 | SBL_PIPD-LS-PKG｜不可降級、不可壓平成小節或附錄的一級章節.md:L45 | SBL structure contract | P02 | cross-doc | C48 / C48 | RETAIN/MERGE | SBL-DOC-03:protected H1 | H1 preserved with unique owner, POS/NEG and source | unique_h1_owner_match | POS-L1-17:content+owner | NEG-L1-17:orphan/flatten | owner_doc_body+hash+independent_later | DESIGN_MAPPED;INDEPENDENT_HOLD |
| REQ-L1-18 | REQ-GLOBAL-45 | 正式 PI-PKG 規格編譯、TechnologyAdmission 與 Semantic Trace | SBL_PIPD-LS-PKG｜不可降級、不可壓平成小節或附錄的一級章節.md:L46 | SBL structure contract | P03 | cross-doc | C48 / C48 | RETAIN/MERGE | SBL-DOC-03:protected H1 | H1 preserved with unique owner, POS/NEG and source | unique_h1_owner_match | POS-L1-18:content+owner | NEG-L1-18:orphan/flatten | owner_doc_body+hash+independent_later | DESIGN_MAPPED;INDEPENDENT_HOLD |
| REQ-L1-19 | REQ-GLOBAL-45 | 真 RepoContext、PD-PKG 晚綁定與施工受限範圍 | SBL_PIPD-LS-PKG｜不可降級、不可壓平成小節或附錄的一級章節.md:L47 | SBL structure contract | P04 | cross-doc | C48 / C48 | RETAIN/MERGE | SBL-DOC-05:protected H1 | H1 preserved with unique owner, POS/NEG and source | unique_h1_owner_match | POS-L1-19:content+owner | NEG-L1-19:orphan/flatten | owner_doc_body+hash+independent_later | DESIGN_MAPPED;INDEPENDENT_HOLD |
| REQ-L1-20 | REQ-GLOBAL-45 | ConstructionContract／ONE ECP／WorkOrder／原生准入效果 | SBL_PIPD-LS-PKG｜不可降級、不可壓平成小節或附錄的一級章節.md:L48 | SBL structure contract | P06 | cross-doc | C48 / C48 | RETAIN/MERGE | SBL-DOC-05:protected H1 | H1 preserved with unique owner, POS/NEG and source | unique_h1_owner_match | POS-L1-20:content+owner | NEG-L1-20:orphan/flatten | owner_doc_body+hash+independent_later | DESIGN_MAPPED;INDEPENDENT_HOLD |
| REQ-L1-21 | REQ-GLOBAL-45 | 驗證 Test/Oracle/TQAEP、破壞性案例與獨立 Checker | SBL_PIPD-LS-PKG｜不可降級、不可壓平成小節或附錄的一級章節.md:L49 | SBL structure contract | V01 | cross-doc | C48 / C48 | RETAIN/MERGE | SBL-DOC-08:protected H1 | H1 preserved with unique owner, POS/NEG and source | unique_h1_owner_match | POS-L1-21:content+owner | NEG-L1-21:orphan/flatten | owner_doc_body+hash+independent_later | DESIGN_MAPPED;INDEPENDENT_HOLD |
| REQ-L1-22 | REQ-GLOBAL-45 | SPEC：三種視圖與正式可編譯承諾 | SBL_PIPD-LS-PKG｜不可降級、不可壓平成小節或附錄的一級章節.md:L50 | SBL structure contract | P03 | cross-doc | C48 / C48 | RETAIN/MERGE | SBL-DOC-03:protected H1 | H1 preserved with unique owner, POS/NEG and source | unique_h1_owner_match | POS-L1-22:content+owner | NEG-L1-22:orphan/flatten | owner_doc_body+hash+independent_later | DESIGN_MAPPED;INDEPENDENT_HOLD |
| REQ-L1-23 | REQ-GLOBAL-45 | LEDGER：Trace/Evidence/Decision/Effect／時效與 Claims | SBL_PIPD-LS-PKG｜不可降級、不可壓平成小節或附錄的一級章節.md:L51 | SBL structure contract | P07 | cross-doc | C48 / C48 | RETAIN/MERGE | SBL-DOC-09:protected H1 | H1 preserved with unique owner, POS/NEG and source | unique_h1_owner_match | POS-L1-23:content+owner | NEG-L1-23:orphan/flatten | owner_doc_body+hash+independent_later | DESIGN_MAPPED;INDEPENDENT_HOLD |
| REQ-L1-24 | REQ-GLOBAL-45 | DELIVER：安裝、Host 使用、回滾、FUO、Consumer ACK | SBL_PIPD-LS-PKG｜不可降級、不可壓平成小節或附錄的一級章節.md:L52 | SBL structure contract | R06 | cross-doc | C48 / C48 | RETAIN/MERGE | SBL-DOC-12:protected H1 | H1 preserved with unique owner, POS/NEG and source | unique_h1_owner_match | POS-L1-24:content+owner | NEG-L1-24:orphan/flatten | owner_doc_body+hash+independent_later | DESIGN_MAPPED;INDEPENDENT_HOLD |
| REQ-L1-25 | REQ-GLOBAL-45 | 六大外部方法輪子×24 Core 能力的選擇與實際融入 | SBL_PIPD-LS-PKG｜不可降級、不可壓平成小節或附錄的一級章節.md:L53 | SBL structure contract | D01 | cross-doc | C48 / C48 | RETAIN/MERGE | SBL-DOC-06:protected H1 | H1 preserved with unique owner, POS/NEG and source | unique_h1_owner_match | POS-L1-25:content+owner | NEG-L1-25:orphan/flatten | owner_doc_body+hash+independent_later | DESIGN_MAPPED;INDEPENDENT_HOLD |
| REQ-L1-26 | REQ-GLOBAL-45 | 386 技術 Universe、25 方法及 Search-Before-Build 與准入 | SBL_PIPD-LS-PKG｜不可降級、不可壓平成小節或附錄的一級章節.md:L54 | SBL structure contract | G07 | cross-doc | C48 / C48 | RETAIN/MERGE | SBL-DOC-06:protected H1 | H1 preserved with unique owner, POS/NEG and source | unique_h1_owner_match | POS-L1-26:content+owner | NEG-L1-26:orphan/flatten | owner_doc_body+hash+independent_later | DESIGN_MAPPED;INDEPENDENT_HOLD |
| REQ-L1-27 | REQ-GLOBAL-45 | Agent Components、AGENTS.md、Skills、Prompt 與 Host 指令優先序 | SBL_PIPD-LS-PKG｜不可降級、不可壓平成小節或附錄的一級章節.md:L55 | SBL structure contract | A01 | cross-doc | C48 / C48 | RETAIN/MERGE | SBL-DOC-10:protected H1 | H1 preserved with unique owner, POS/NEG and source | unique_h1_owner_match | POS-L1-27:content+owner | NEG-L1-27:orphan/flatten | owner_doc_body+hash+independent_later | DESIGN_MAPPED;INDEPENDENT_HOLD |
| REQ-L1-28 | REQ-GLOBAL-45 | Hermes／Codex／Claude Code／DeepSeek 與多平台 Native ABI | SBL_PIPD-LS-PKG｜不可降級、不可壓平成小節或附錄的一級章節.md:L56 | SBL structure contract | A03 | cross-doc | C48 / C48 | RETAIN/MERGE | SBL-DOC-10:protected H1 | H1 preserved with unique owner, POS/NEG and source | unique_h1_owner_match | POS-L1-28:content+owner | NEG-L1-28:orphan/flatten | owner_doc_body+hash+independent_later | DESIGN_MAPPED;INDEPENDENT_HOLD |
| REQ-L1-29 | REQ-GLOBAL-45 | GPTs GENIEMAKER／ChatGPT、Claude Web、私有 ZIP 與 Web MD | SBL_PIPD-LS-PKG｜不可降級、不可壓平成小節或附錄的一級章節.md:L57 | SBL structure contract | A11 | cross-doc | C48 / C48 | RETAIN/MERGE | SBL-DOC-10:protected H1 | H1 preserved with unique owner, POS/NEG and source | unique_h1_owner_match | POS-L1-29:content+owner | NEG-L1-29:orphan/flatten | owner_doc_body+hash+independent_later | DESIGN_MAPPED;INDEPENDENT_HOLD |
| REQ-L1-30 | REQ-GLOBAL-45 | 動態 58 專家職能、責任 RACI 與真正獨立 Principal | SBL_PIPD-LS-PKG｜不可降級、不可壓平成小節或附錄的一級章節.md:L58 | SBL structure contract | G04 | cross-doc | C48 / R00 | RETAIN/MERGE | SBL-DOC-00:protected H1 | H1 preserved with unique owner, POS/NEG and source | unique_h1_owner_match | POS-L1-30:content+owner | NEG-L1-30:orphan/flatten | owner_doc_body+hash+independent_later | DESIGN_MAPPED;INDEPENDENT_HOLD |
| REQ-L1-31 | REQ-GLOBAL-45 | 多 Agent 管線、FAN-OUT/FAN-IN、可靠 Checkpoint 和有界修復 | SBL_PIPD-LS-PKG｜不可降級、不可壓平成小節或附錄的一級章節.md:L59 | SBL structure contract | A07 | cross-doc | C48 / C48 | RETAIN/MERGE | SBL-DOC-04:protected H1 | H1 preserved with unique owner, POS/NEG and source | unique_h1_owner_match | POS-L1-31:content+owner | NEG-L1-31:orphan/flatten | owner_doc_body+hash+independent_later | DESIGN_MAPPED;INDEPENDENT_HOLD |
| REQ-L1-32 | REQ-GLOBAL-45 | Context／Memory／RAG／Agent 狀態與知識證據主權 | SBL_PIPD-LS-PKG｜不可降級、不可壓平成小節或附錄的一級章節.md:L60 | SBL structure contract | K01 | cross-doc | C48 / C48 | RETAIN/MERGE | SBL-DOC-10:protected H1 | H1 preserved with unique owner, POS/NEG and source | unique_h1_owner_match | POS-L1-32:content+owner | NEG-L1-32:orphan/flatten | owner_doc_body+hash+independent_later | DESIGN_MAPPED;INDEPENDENT_HOLD |
| REQ-L1-33 | REQ-GLOBAL-45 | Fabric/HG-KSEOS／Hermes Native Runtime／FDA 效果治理 | SBL_PIPD-LS-PKG｜不可降級、不可壓平成小節或附錄的一級章節.md:L61 | SBL structure contract | A02 | cross-doc | C48 / C48 | RETAIN/MERGE | SBL-DOC-11:protected H1 | H1 preserved with unique owner, POS/NEG and source | unique_h1_owner_match | POS-L1-33:content+owner | NEG-L1-33:orphan/flatten | owner_doc_body+hash+independent_later | DESIGN_MAPPED;INDEPENDENT_HOLD |
| REQ-L1-34 | REQ-GLOBAL-45 | SWOF SQS–THC/TW-ICT 金融 Domain 與 PRE-W3／W3 閉環 | SBL_PIPD-LS-PKG｜不可降級、不可壓平成小節或附錄的一級章節.md:L62 | SBL structure contract | A12 | cross-doc | C48 / C48 | RETAIN/MERGE | SBL-DOC-11:protected H1 | H1 preserved with unique owner, POS/NEG and source | unique_h1_owner_match | POS-L1-34:content+owner | NEG-L1-34:orphan/flatten | owner_doc_body+hash+independent_later | DESIGN_MAPPED;INDEPENDENT_HOLD |
| REQ-L1-35 | REQ-GLOBAL-45 | 安全／供應鏈／MCP 權限／提示注入／秘密與資料治理 | SBL_PIPD-LS-PKG｜不可降級、不可壓平成小節或附錄的一級章節.md:L63 | SBL structure contract | V04 | cross-doc | C48 / C48 | RETAIN/MERGE | SBL-DOC-07:protected H1 | H1 preserved with unique owner, POS/NEG and source | unique_h1_owner_match | POS-L1-35:content+owner | NEG-L1-35:orphan/flatten | owner_doc_body+hash+independent_later | DESIGN_MAPPED;INDEPENDENT_HOLD |
| REQ-L1-36 | REQ-GLOBAL-45 | 可靠性、成本、性能／SRE、Provider-off 與異常退化 | SBL_PIPD-LS-PKG｜不可降級、不可壓平成小節或附錄的一級章節.md:L64 | SBL structure contract | V06 | cross-doc | C48 / C48 | RETAIN/MERGE | SBL-DOC-13:protected H1 | H1 preserved with unique owner, POS/NEG and source | unique_h1_owner_match | POS-L1-36:content+owner | NEG-L1-36:orphan/flatten | owner_doc_body+hash+independent_later | DESIGN_MAPPED;INDEPENDENT_HOLD |
| REQ-L1-37 | REQ-GLOBAL-45 | 38 Delivery Surfaces、安裝／部署／移除與 Host Compatibility | SBL_PIPD-LS-PKG｜不可降級、不可壓平成小節或附錄的一級章節.md:L65 | SBL structure contract | R01 | cross-doc | C48 / C48 | RETAIN/MERGE | SBL-DOC-12:protected H1 | H1 preserved with unique owner, POS/NEG and source | unique_h1_owner_match | POS-L1-37:content+owner | NEG-L1-37:orphan/flatten | owner_doc_body+hash+independent_later | DESIGN_MAPPED;INDEPENDENT_HOLD |
| REQ-L1-38 | REQ-GLOBAL-45 | CI／Release／SBOM／Provenance／Attestation／權利與獨立簽核 | SBL_PIPD-LS-PKG｜不可降級、不可壓平成小節或附錄的一級章節.md:L66 | SBL structure contract | V05 | cross-doc | C48 / C48 | RETAIN/MERGE | SBL-DOC-12:protected H1 | H1 preserved with unique owner, POS/NEG and source | unique_h1_owner_match | POS-L1-38:content+owner | NEG-L1-38:orphan/flatten | owner_doc_body+hash+independent_later | DESIGN_MAPPED;INDEPENDENT_HOLD |
| REQ-L1-39 | REQ-GLOBAL-45 | 自舉／DOGFOOD／受控演化、A/B 與 Holdout | SBL_PIPD-LS-PKG｜不可降級、不可壓平成小節或附錄的一級章節.md:L67 | SBL structure contract | R05 | cross-doc | C48 / C48 | RETAIN/MERGE | SBL-DOC-13:protected H1 | H1 preserved with unique owner, POS/NEG and source | unique_h1_owner_match | POS-L1-39:content+owner | NEG-L1-39:orphan/flatten | owner_doc_body+hash+independent_later | DESIGN_MAPPED;INDEPENDENT_HOLD |
| REQ-L1-40 | REQ-GLOBAL-45 | 施工／RUNBOOK／WI、I0–I10 分段關卡與 rollback | SBL_PIPD-LS-PKG｜不可降級、不可壓平成小節或附錄的一級章節.md:L68 | SBL structure contract | G03 | cross-doc | C48 / C48 | RETAIN/MERGE | SBL-DOC-12:protected H1 | H1 preserved with unique owner, POS/NEG and source | unique_h1_owner_match | POS-L1-40:content+owner | NEG-L1-40:orphan/flatten | owner_doc_body+hash+independent_later | DESIGN_MAPPED;INDEPENDENT_HOLD |
| REQ-L1-41 | REQ-GLOBAL-45 | 衝突／TT／CR_OPEN／Supersession 與 Claim Ceiling | SBL_PIPD-LS-PKG｜不可降級、不可壓平成小節或附錄的一級章節.md:L69 | SBL structure contract | G05 | cross-doc | C48 / C52 | RETAIN/MERGE | SBL-DOC-00:protected H1 | H1 preserved with unique owner, POS/NEG and source | unique_h1_owner_match | POS-L1-41:content+owner | NEG-L1-41:orphan/flatten | owner_doc_body+hash+independent_later | DESIGN_MAPPED;INDEPENDENT_HOLD |
| REQ-L1-42 | REQ-GLOBAL-45 | 全量來源覆蓋、內容保真／不遺失／雙向矩陣 | SBL_PIPD-LS-PKG｜不可降級、不可壓平成小節或附錄的一級章節.md:L70 | SBL structure contract | K04 | cross-doc | C48 / C48 | RETAIN/MERGE | SBL-DOC-09:protected H1 | H1 preserved with unique owner, POS/NEG and source | unique_h1_owner_match | POS-L1-42:content+owner | NEG-L1-42:orphan/flatten | owner_doc_body+hash+independent_later | DESIGN_MAPPED;INDEPENDENT_HOLD |
| REQ-L1-43 | REQ-GLOBAL-45 | 2026 外部證據、版本現實、技術准入與失效重核 | SBL_PIPD-LS-PKG｜不可降級、不可壓平成小節或附錄的一級章節.md:L71 | SBL structure contract | G07 | cross-doc | C48 / C48 | RETAIN/MERGE | SBL-DOC-06:protected H1 | H1 preserved with unique owner, POS/NEG and source | unique_h1_owner_match | POS-L1-43:content+owner | NEG-L1-43:orphan/flatten | owner_doc_body+hash+independent_later | DESIGN_MAPPED;INDEPENDENT_HOLD |
| REQ-L1-44 | REQ-GLOBAL-45 | 最終打包、章節 Conformance、AI 冷啟動與反證總驗收 | SBL_PIPD-LS-PKG｜不可降級、不可壓平成小節或附錄的一級章節.md:L72 | SBL structure contract | G08 | cross-doc | C48 / C48 | RETAIN/MERGE | SBL-DOC-13:protected H1 | H1 preserved with unique owner, POS/NEG and source | unique_h1_owner_match | POS-L1-44:content+owner | NEG-L1-44:orphan/flatten | owner_doc_body+hash+independent_later | DESIGN_MAPPED;INDEPENDENT_HOLD |
| REQ-CAP-OS-01 | REQ-CAP-24 | Explore、模糊意圖形成決策/可行性 | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L216 | SBL master | TPM | method-runtime | R04 | RETAIN/THIN_ADAPTER | R04.NEXT.1 | source bound capability and NEG | capability_contract_reader | POS-OS-01 | NEG-OS-01 | source+pin+host+repo+test expected | DESIGN_MAPPED;RUNTIME_HOLD |
| REQ-CAP-OS-02 | REQ-CAP-24 | Brownfield Proposal／Spec Delta | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L217 | SBL master | TPM/PIPD | method-runtime | R04 | RETAIN/THIN_ADAPTER | R04.NEXT.1 | source bound capability and NEG | capability_contract_reader | POS-OS-02 | NEG-OS-02 | source+pin+host+repo+test expected | DESIGN_MAPPED;RUNTIME_HOLD |
| REQ-CAP-OS-03 | REQ-CAP-24 | Apply／Verify 一致 | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L218 | SBL master | Commander/Checker | method-runtime | R04 | RETAIN/THIN_ADAPTER | R04.NEXT.1 | source bound capability and NEG | capability_contract_reader | POS-OS-03 | NEG-OS-03 | source+pin+host+repo+test expected | DESIGN_MAPPED;RUNTIME_HOLD |
| REQ-CAP-OS-04 | REQ-CAP-24 | Sync／Archive／Versioned History | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L219 | SBL master | Evidence | method-runtime | R04 | RETAIN/THIN_ADAPTER | R04.NEXT.1 | source bound capability and NEG | capability_contract_reader | POS-OS-04 | NEG-OS-04 | source+pin+host+repo+test expected | DESIGN_MAPPED;RUNTIME_HOLD |
| REQ-CAP-SK-01 | REQ-CAP-24 | Constitution／Product Scope | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L220 | SBL master | PIPD | method-runtime | R04 | RETAIN/THIN_ADAPTER | R04.NEXT.1 | source bound capability and NEG | capability_contract_reader | POS-SK-01 | NEG-SK-01 | source+pin+host+repo+test expected | DESIGN_MAPPED;RUNTIME_HOLD |
| REQ-CAP-SK-02 | REQ-CAP-24 | Specify／Clarify／Atomic Acceptance | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L221 | SBL master | PIPD | method-runtime | R04 | RETAIN/THIN_ADAPTER | R04.NEXT.1 | source bound capability and NEG | capability_contract_reader | POS-SK-02 | NEG-SK-02 | source+pin+host+repo+test expected | DESIGN_MAPPED;RUNTIME_HOLD |
| REQ-CAP-SK-03 | REQ-CAP-24 | Plan／Tasks／Analyze | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L222 | SBL master | TPM/Commander | method-runtime | R04 | RETAIN/THIN_ADAPTER | R04.NEXT.1 | source bound capability and NEG | capability_contract_reader | POS-SK-03 | NEG-SK-03 | source+pin+host+repo+test expected | DESIGN_MAPPED;RUNTIME_HOLD |
| REQ-CAP-SK-04 | REQ-CAP-24 | 可組合且版本固定的 Workflow | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L223 | SBL master | Method Resolver | method-runtime | R04 | RETAIN/THIN_ADAPTER | R04.NEXT.1 | source bound capability and NEG | capability_contract_reader | POS-SK-04 | NEG-SK-04 | source+pin+host+repo+test expected | DESIGN_MAPPED;RUNTIME_HOLD |
| REQ-CAP-MP-01 | REQ-CAP-24 | Smart Method Routing | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L224 | SBL master | TPM | method-runtime | R04 | RETAIN/THIN_ADAPTER | R04.NEXT.1 | source bound capability and NEG | capability_contract_reader | POS-MP-01 | NEG-MP-01 | source+pin+host+repo+test expected | DESIGN_MAPPED;RUNTIME_HOLD |
| REQ-CAP-MP-02 | REQ-CAP-24 | Grill-with-docs／High Info Gain | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L225 | SBL master | TPM | method-runtime | R04 | RETAIN/THIN_ADAPTER | R04.NEXT.1 | source bound capability and NEG | capability_contract_reader | POS-MP-02 | NEG-MP-02 | source+pin+host+repo+test expected | DESIGN_MAPPED;RUNTIME_HOLD |
| REQ-CAP-MP-03 | REQ-CAP-24 | Domain／Architecture Model | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L226 | SBL master | Systems Eng | method-runtime | R04 | RETAIN/THIN_ADAPTER | R04.NEXT.1 | source bound capability and NEG | capability_contract_reader | POS-MP-03 | NEG-MP-03 | source+pin+host+repo+test expected | DESIGN_MAPPED;RUNTIME_HOLD |
| REQ-CAP-MP-04 | REQ-CAP-24 | To-spec／To-tickets | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L227 | SBL master | TPM/PIPD | method-runtime | R04 | RETAIN/THIN_ADAPTER | R04.NEXT.1 | source bound capability and NEG | capability_contract_reader | POS-MP-04 | NEG-MP-04 | source+pin+host+repo+test expected | DESIGN_MAPPED;RUNTIME_HOLD |
| REQ-CAP-GS-01 | REQ-CAP-24 | Context Engineering | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L228 | SBL master | Context Bridge | method-runtime | R04 | RETAIN/THIN_ADAPTER | R04.NEXT.1 | source bound capability and NEG | capability_contract_reader | POS-GS-01 | NEG-GS-01 | source+pin+host+repo+test expected | DESIGN_MAPPED;RUNTIME_HOLD |
| REQ-CAP-GS-02 | REQ-CAP-24 | Phase／Milestone | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L229 | SBL master | Commander | method-runtime | R04 | RETAIN/THIN_ADAPTER | R04.NEXT.1 | source bound capability and NEG | capability_contract_reader | POS-GS-02 | NEG-GS-02 | source+pin+host+repo+test expected | DESIGN_MAPPED;RUNTIME_HOLD |
| REQ-CAP-GS-03 | REQ-CAP-24 | Checkpoint／Resume | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L230 | SBL master | Recovery | method-runtime | R04 | RETAIN/THIN_ADAPTER | R04.NEXT.1 | source bound capability and NEG | capability_contract_reader | POS-GS-03 | NEG-GS-03 | source+pin+host+repo+test expected | DESIGN_MAPPED;RUNTIME_HOLD |
| REQ-CAP-GS-04 | REQ-CAP-24 | Verify／Ship Continuity | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L231 | SBL master | Evidence/Release | method-runtime | R04 | RETAIN/THIN_ADAPTER | R04.NEXT.1 | source bound capability and NEG | capability_contract_reader | POS-GS-04 | NEG-GS-04 | source+pin+host+repo+test expected | DESIGN_MAPPED;RUNTIME_HOLD |
| REQ-CAP-GT-01 | REQ-CAP-24 | CEO/Product/Office Hours Review | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L232 | SBL master | TPM | method-runtime | R04 | RETAIN/THIN_ADAPTER | R04.NEXT.1 | source bound capability and NEG | capability_contract_reader | POS-GT-01 | NEG-GT-01 | source+pin+host+repo+test expected | DESIGN_MAPPED;RUNTIME_HOLD |
| REQ-CAP-GT-02 | REQ-CAP-24 | Engineering／DX/Design Review | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L233 | SBL master | Reviewer | method-runtime | R04 | RETAIN/THIN_ADAPTER | R04.NEXT.1 | source bound capability and NEG | capability_contract_reader | POS-GT-02 | NEG-GT-02 | source+pin+host+repo+test expected | DESIGN_MAPPED;RUNTIME_HOLD |
| REQ-CAP-GT-03 | REQ-CAP-24 | QA／Code Review | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L234 | SBL master | Checker | method-runtime | R04 | RETAIN/THIN_ADAPTER | R04.NEXT.1 | source bound capability and NEG | capability_contract_reader | POS-GT-03 | NEG-GT-03 | source+pin+host+repo+test expected | DESIGN_MAPPED;RUNTIME_HOLD |
| REQ-CAP-GT-04 | REQ-CAP-24 | Ship／Retro | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L235 | SBL master | Release Owner | method-runtime | R04 | RETAIN/THIN_ADAPTER | R04.NEXT.1 | source bound capability and NEG | capability_contract_reader | POS-GT-04 | NEG-GT-04 | source+pin+host+repo+test expected | DESIGN_MAPPED;RUNTIME_HOLD |
| REQ-CAP-SP-01 | REQ-CAP-24 | Brainstorm／Design-first | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L236 | SBL master | TPM | method-runtime | R04 | RETAIN/THIN_ADAPTER | R04.NEXT.1 | source bound capability and NEG | capability_contract_reader | POS-SP-01 | NEG-SP-01 | source+pin+host+repo+test expected | DESIGN_MAPPED;RUNTIME_HOLD |
| REQ-CAP-SP-02 | REQ-CAP-24 | 真正 Test-first | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L237 | SBL master | Worker | method-runtime | R04 | RETAIN/THIN_ADAPTER | R04.NEXT.1 | source bound capability and NEG | capability_contract_reader | POS-SP-02 | NEG-SP-02 | source+pin+host+repo+test expected | DESIGN_MAPPED;RUNTIME_HOLD |
| REQ-CAP-SP-03 | REQ-CAP-24 | Root Cause／Smallest Repair | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L238 | SBL master | Commander/Worker | method-runtime | R04 | RETAIN/THIN_ADAPTER | R04.NEXT.1 | source bound capability and NEG | capability_contract_reader | POS-SP-03 | NEG-SP-03 | source+pin+host+repo+test expected | DESIGN_MAPPED;RUNTIME_HOLD |
| REQ-CAP-SP-04 | REQ-CAP-24 | Plan Execution／Review | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L239 | SBL master | Commander/Challenge | method-runtime | R04 | RETAIN/THIN_ADAPTER | R04.NEXT.1 | source bound capability and NEG | capability_contract_reader | POS-SP-04 | NEG-SP-04 | source+pin+host+repo+test expected | DESIGN_MAPPED;RUNTIME_HOLD |
| REQ-MOMENT-M00 | REQ-MOMENT-16 | M00 Understand SourceInventory→IntentRecord | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L919 | SBL master | G02 | human_fuo | R02 | RETAIN | R02.NEXT.2 | personal FUO verified | consumer_journey_probe | POS-M00 | NEG-M00 | consumer_raw_UAT | DESIGN_MAPPED;FUO_NOT_RUN |
| REQ-MOMENT-M01 | REQ-MOMENT-16 | M01 Explore Explore/DecisionLedger | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L920 | SBL master | G02 | human_fuo | R02 | RETAIN | R02.NEXT.2 | personal FUO verified | consumer_journey_probe | POS-M01 | NEG-M01 | consumer_raw_UAT | DESIGN_MAPPED;FUO_NOT_RUN |
| REQ-MOMENT-M02 | REQ-MOMENT-16 | M02 Define ProductBrief/FUO/MVP/NonGoal | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L921 | SBL master | G02 | human_fuo | R02 | RETAIN | R02.NEXT.2 | personal FUO verified | consumer_journey_probe | POS-M02 | NEG-M02 | consumer_raw_UAT | DESIGN_MAPPED;FUO_NOT_RUN |
| REQ-MOMENT-M03 | REQ-MOMENT-16 | M03 Specify PI atoms/Acceptance/Verification | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L922 | SBL master | G02 | human_fuo | R02 | RETAIN | R02.NEXT.2 | personal FUO verified | consumer_journey_probe | POS-M03 | NEG-M03 | consumer_raw_UAT | DESIGN_MAPPED;FUO_NOT_RUN |
| REQ-MOMENT-M04 | REQ-MOMENT-16 | M04 Architect Domain/ADR/Threat/Interface | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L923 | SBL master | G02 | human_fuo | R02 | RETAIN | R02.NEXT.2 | personal FUO verified | consumer_journey_probe | POS-M04 | NEG-M04 | consumer_raw_UAT | DESIGN_MAPPED;FUO_NOT_RUN |
| REQ-MOMENT-M05 | REQ-MOMENT-16 | M05 Plan 有向無環 DAG/Owner/Milestone | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L924 | SBL master | G02 | human_fuo | R02 | RETAIN | R02.NEXT.2 | personal FUO verified | consumer_journey_probe | POS-M05 | NEG-M05 | consumer_raw_UAT | DESIGN_MAPPED;FUO_NOT_RUN |
| REQ-MOMENT-M06 | REQ-MOMENT-16 | M06 Prepare PD Construction Binding+TQAEP | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L925 | SBL master | G02 | human_fuo | R02 | RETAIN | R02.NEXT.2 | personal FUO verified | consumer_journey_probe | POS-M06 | NEG-M06 | consumer_raw_UAT | DESIGN_MAPPED;FUO_NOT_RUN |
| REQ-MOMENT-M07 | REQ-MOMENT-16 | M07 Build 受控 Worker ChangeSet | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L926 | SBL master | G02 | human_fuo | R02 | RETAIN | R02.NEXT.2 | personal FUO verified | consumer_journey_probe | POS-M07 | NEG-M07 | consumer_raw_UAT | DESIGN_MAPPED;FUO_NOT_RUN |
| REQ-MOMENT-M08 | REQ-MOMENT-16 | M08 Test Raw Logs/Exit/Trace | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L927 | SBL master | G02 | human_fuo | R02 | RETAIN | R02.NEXT.2 | personal FUO verified | consumer_journey_probe | POS-M08 | NEG-M08 | consumer_raw_UAT | DESIGN_MAPPED;FUO_NOT_RUN |
| REQ-MOMENT-M09 | REQ-MOMENT-16 | M09 Review Reviewer Findings | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L928 | SBL master | G02 | human_fuo | R02 | RETAIN | R02.NEXT.2 | personal FUO verified | consumer_journey_probe | POS-M09 | NEG-M09 | consumer_raw_UAT | DESIGN_MAPPED;FUO_NOT_RUN |
| REQ-MOMENT-M10 | REQ-MOMENT-16 | M10 Verify Local AO/Acceptance Receipt | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L929 | SBL master | G02 | human_fuo | R02 | RETAIN | R02.NEXT.2 | personal FUO verified | consumer_journey_probe | POS-M10 | NEG-M10 | consumer_raw_UAT | DESIGN_MAPPED;FUO_NOT_RUN |
| REQ-MOMENT-M11 | REQ-MOMENT-16 | M11 Repair RepairCone/Scoped Rerun | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L930 | SBL master | G02 | human_fuo | R02 | RETAIN | R02.NEXT.2 | personal FUO verified | consumer_journey_probe | POS-M11 | NEG-M11 | consumer_raw_UAT | DESIGN_MAPPED;FUO_NOT_RUN |
| REQ-MOMENT-M12 | REQ-MOMENT-16 | M12 Ship GitHub Tag/Assets/Provenance | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L931 | SBL master | G02 | human_fuo | R02 | RETAIN | R02.NEXT.2 | personal FUO verified | consumer_journey_probe | POS-M12 | NEG-M12 | consumer_raw_UAT | DESIGN_MAPPED;FUO_NOT_RUN |
| REQ-MOMENT-M13 | REQ-MOMENT-16 | M13 Maintain Repair/Migration/Regression | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L932 | SBL master | G02 | human_fuo | R02 | RETAIN | R02.NEXT.2 | personal FUO verified | consumer_journey_probe | POS-M13 | NEG-M13 | consumer_raw_UAT | DESIGN_MAPPED;FUO_NOT_RUN |
| REQ-MOMENT-M14 | REQ-MOMENT-16 | M14 Host Portability NativeInstall/EffLoad/Uninstall | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L933 | SBL master | G02 | human_fuo | R02 | RETAIN | R02.NEXT.2 | personal FUO verified | consumer_journey_probe | POS-M14 | NEG-M14 | consumer_raw_UAT | DESIGN_MAPPED;FUO_NOT_RUN |
| REQ-MOMENT-M15 | REQ-MOMENT-16 | M15 Private Use 合法包＋用戶上傳＋調用 | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L934 | SBL master | G02 | human_fuo | R02 | RETAIN | R02.NEXT.2 | personal FUO verified | consumer_journey_probe | POS-M15 | NEG-M15 | consumer_raw_UAT | DESIGN_MAPPED;FUO_NOT_RUN |
| REQ-PRODUCT-CLI_TOOL | REQ-PRODUCT-8 | ProductKind=CLI_TOOL | SBL_PIPD-LS-PKG｜必須涵蓋的設計規劃、設計原意、用戶需求、預期成果、7 Primary Kinds 與 8 ProductKind(1).md:L104 | SBL product | G01 | product_truth | R02 | RETAIN | R02.NEXT.1 | distinct from SWOF Primary Kind | taxonomy_orthogonality | POS-PK-CLI_TOOL | NEG-PK-CLI_TOOL | typed product schema | DESIGN_MAPPED |
| REQ-PRODUCT-AGENT_SKILL | REQ-PRODUCT-8 | ProductKind=AGENT_SKILL | SBL_PIPD-LS-PKG｜必須涵蓋的設計規劃、設計原意、用戶需求、預期成果、7 Primary Kinds 與 8 ProductKind(1).md:L105 | SBL product | G01 | product_truth | R02 | RETAIN | R02.NEXT.1 | distinct from SWOF Primary Kind | taxonomy_orthogonality | POS-PK-AGENT_SKILL | NEG-PK-AGENT_SKILL | typed product schema | DESIGN_MAPPED |
| REQ-PRODUCT-SIMPLE_AGENT | REQ-PRODUCT-8 | ProductKind=SIMPLE_AGENT | SBL_PIPD-LS-PKG｜必須涵蓋的設計規劃、設計原意、用戶需求、預期成果、7 Primary Kinds 與 8 ProductKind(1).md:L106 | SBL product | G01 | product_truth | R02 | RETAIN | R02.NEXT.1 | distinct from SWOF Primary Kind | taxonomy_orthogonality | POS-PK-SIMPLE_AGENT | NEG-PK-SIMPLE_AGENT | typed product schema | DESIGN_MAPPED |
| REQ-PRODUCT-PLUGIN | REQ-PRODUCT-8 | ProductKind=PLUGIN | SBL_PIPD-LS-PKG｜必須涵蓋的設計規劃、設計原意、用戶需求、預期成果、7 Primary Kinds 與 8 ProductKind(1).md:L107 | SBL product | G01 | product_truth | R02 | RETAIN | R02.NEXT.1 | distinct from SWOF Primary Kind | taxonomy_orthogonality | POS-PK-PLUGIN | NEG-PK-PLUGIN | typed product schema | DESIGN_MAPPED |
| REQ-PRODUCT-PROFILE | REQ-PRODUCT-8 | ProductKind=PROFILE | SBL_PIPD-LS-PKG｜必須涵蓋的設計規劃、設計原意、用戶需求、預期成果、7 Primary Kinds 與 8 ProductKind(1).md:L108 | SBL product | G01 | product_truth | R02 | RETAIN | R02.NEXT.1 | distinct from SWOF Primary Kind | taxonomy_orthogonality | POS-PK-PROFILE | NEG-PK-PROFILE | typed product schema | DESIGN_MAPPED |
| REQ-PRODUCT-AGENT_OS | REQ-PRODUCT-8 | ProductKind=AGENT_OS | SBL_PIPD-LS-PKG｜必須涵蓋的設計規劃、設計原意、用戶需求、預期成果、7 Primary Kinds 與 8 ProductKind(1).md:L109 | SBL product | G01 | product_truth | R02 | RETAIN | R02.NEXT.1 | distinct from SWOF Primary Kind | taxonomy_orthogonality | POS-PK-AGENT_OS | NEG-PK-AGENT_OS | typed product schema | DESIGN_MAPPED |
| REQ-PRODUCT-AI_SYSTEM | REQ-PRODUCT-8 | ProductKind=AI_SYSTEM | SBL_PIPD-LS-PKG｜必須涵蓋的設計規劃、設計原意、用戶需求、預期成果、7 Primary Kinds 與 8 ProductKind(1).md:L110 | SBL product | G01 | product_truth | R02 | RETAIN | R02.NEXT.1 | distinct from SWOF Primary Kind | taxonomy_orthogonality | POS-PK-AI_SYSTEM | NEG-PK-AI_SYSTEM | typed product schema | DESIGN_MAPPED |
| REQ-PRODUCT-GENIE-GENIE.md | REQ-PRODUCT-8 | ProductKind=GENIE/GENIE.md | SBL_PIPD-LS-PKG｜必須涵蓋的設計規劃、設計原意、用戶需求、預期成果、7 Primary Kinds 與 8 ProductKind(1).md:L111 | SBL product | G01 | product_truth | R02 | RETAIN | R02.NEXT.1 | distinct from SWOF Primary Kind | taxonomy_orthogonality | POS-PK-GENIE/GENIE.md | NEG-PK-GENIE/GENIE.md | typed product schema | DESIGN_MAPPED |
| REQ-GATE-STANDALONE-G00 | REQ-GATE-39 | STANDALONE×G00 Authority/Hash=R | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L2171 | SBL master + HGK native | A02 | native_permission | R02 | RETAIN | R02.NEXT.4 | cell retains R/C/F/N and correct rule | cell_rule_no_promotion | POS-STANDALONE-G00 | NEG-STANDALONE-G00 | HGK signed original receipt required beyond design | DESIGN_MAPPED;NATIVE_HOLD |
| REQ-GATE-PREW3_SHADOW-G00 | REQ-GATE-39 | PREW3_SHADOW×G00 Authority/Hash=R | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L2171 | SBL master + HGK native | A02 | native_permission | R02 | RETAIN | R02.NEXT.4 | cell retains R/C/F/N and correct rule | cell_rule_no_promotion | POS-PREW3_SHADOW-G00 | NEG-PREW3_SHADOW-G00 | HGK signed original receipt required beyond design | DESIGN_MAPPED;NATIVE_HOLD |
| REQ-GATE-SWOF_CONNECTED-G00 | REQ-GATE-39 | SWOF_CONNECTED×G00 Authority/Hash=R | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L2171 | SBL master + HGK native | A02 | native_permission | R02 | RETAIN | R02.NEXT.4 | cell retains R/C/F/N and correct rule | cell_rule_no_promotion | POS-SWOF_CONNECTED-G00 | NEG-SWOF_CONNECTED-G00 | HGK signed original receipt required beyond design | DESIGN_MAPPED;NATIVE_HOLD |
| REQ-GATE-STANDALONE-G01 | REQ-GATE-39 | STANDALONE×G01 PIPD PI/PD=R | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L2172 | SBL master + HGK native | A02 | native_permission | R02 | RETAIN | R02.NEXT.4 | cell retains R/C/F/N and correct rule | cell_rule_no_promotion | POS-STANDALONE-G01 | NEG-STANDALONE-G01 | HGK signed original receipt required beyond design | DESIGN_MAPPED;NATIVE_HOLD |
| REQ-GATE-PREW3_SHADOW-G01 | REQ-GATE-39 | PREW3_SHADOW×G01 PIPD PI/PD=R | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L2172 | SBL master + HGK native | A02 | native_permission | R02 | RETAIN | R02.NEXT.4 | cell retains R/C/F/N and correct rule | cell_rule_no_promotion | POS-PREW3_SHADOW-G01 | NEG-PREW3_SHADOW-G01 | HGK signed original receipt required beyond design | DESIGN_MAPPED;NATIVE_HOLD |
| REQ-GATE-SWOF_CONNECTED-G01 | REQ-GATE-39 | SWOF_CONNECTED×G01 PIPD PI/PD=R | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L2172 | SBL master + HGK native | A02 | native_permission | R02 | RETAIN | R02.NEXT.4 | cell retains R/C/F/N and correct rule | cell_rule_no_promotion | POS-SWOF_CONNECTED-G01 | NEG-SWOF_CONNECTED-G01 | HGK signed original receipt required beyond design | DESIGN_MAPPED;NATIVE_HOLD |
| REQ-GATE-STANDALONE-G02 | REQ-GATE-39 | STANDALONE×G02 3 SP Host Qualified=C | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L2173 | SBL master + HGK native | A02 | native_permission | R02 | RETAIN | R02.NEXT.4 | cell retains R/C/F/N and correct rule | cell_rule_no_promotion | POS-STANDALONE-G02 | NEG-STANDALONE-G02 | HGK signed original receipt required beyond design | DESIGN_MAPPED;NATIVE_HOLD |
| REQ-GATE-PREW3_SHADOW-G02 | REQ-GATE-39 | PREW3_SHADOW×G02 3 SP Host Qualified=C | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L2173 | SBL master + HGK native | A02 | native_permission | R02 | RETAIN | R02.NEXT.4 | cell retains R/C/F/N and correct rule | cell_rule_no_promotion | POS-PREW3_SHADOW-G02 | NEG-PREW3_SHADOW-G02 | HGK signed original receipt required beyond design | DESIGN_MAPPED;NATIVE_HOLD |
| REQ-GATE-SWOF_CONNECTED-G02 | REQ-GATE-39 | SWOF_CONNECTED×G02 3 SP Host Qualified=C | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L2173 | SBL master + HGK native | A02 | native_permission | R02 | RETAIN | R02.NEXT.4 | cell retains R/C/F/N and correct rule | cell_rule_no_promotion | POS-SWOF_CONNECTED-G02 | NEG-SWOF_CONNECTED-G02 | HGK signed original receipt required beyond design | DESIGN_MAPPED;NATIVE_HOLD |
| REQ-GATE-STANDALONE-G03 | REQ-GATE-39 | STANDALONE×G03 CAPC Compiler=C | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L2174 | SBL master + HGK native | A02 | native_permission | R02 | RETAIN | R02.NEXT.4 | cell retains R/C/F/N and correct rule | cell_rule_no_promotion | POS-STANDALONE-G03 | NEG-STANDALONE-G03 | HGK signed original receipt required beyond design | DESIGN_MAPPED;NATIVE_HOLD |
| REQ-GATE-PREW3_SHADOW-G03 | REQ-GATE-39 | PREW3_SHADOW×G03 CAPC Compiler=C | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L2174 | SBL master + HGK native | A02 | native_permission | R02 | RETAIN | R02.NEXT.4 | cell retains R/C/F/N and correct rule | cell_rule_no_promotion | POS-PREW3_SHADOW-G03 | NEG-PREW3_SHADOW-G03 | HGK signed original receipt required beyond design | DESIGN_MAPPED;NATIVE_HOLD |
| REQ-GATE-SWOF_CONNECTED-G03 | REQ-GATE-39 | SWOF_CONNECTED×G03 CAPC Compiler=R | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L2174 | SBL master + HGK native | A02 | native_permission | R02 | RETAIN | R02.NEXT.4 | cell retains R/C/F/N and correct rule | cell_rule_no_promotion | POS-SWOF_CONNECTED-G03 | NEG-SWOF_CONNECTED-G03 | HGK signed original receipt required beyond design | DESIGN_MAPPED;NATIVE_HOLD |
| REQ-GATE-STANDALONE-G04 | REQ-GATE-39 | STANDALONE×G04 RepoContext/HGK effective load=N | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L2175 | SBL master + HGK native | A02 | native_permission | R02 | RETAIN | R02.NEXT.4 | cell retains R/C/F/N and correct rule | cell_rule_no_promotion | POS-STANDALONE-G04 | NEG-STANDALONE-G04 | HGK signed original receipt required beyond design | DESIGN_MAPPED;NATIVE_HOLD |
| REQ-GATE-PREW3_SHADOW-G04 | REQ-GATE-39 | PREW3_SHADOW×G04 RepoContext/HGK effective load=N | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L2175 | SBL master + HGK native | A02 | native_permission | R02 | RETAIN | R02.NEXT.4 | cell retains R/C/F/N and correct rule | cell_rule_no_promotion | POS-PREW3_SHADOW-G04 | NEG-PREW3_SHADOW-G04 | HGK signed original receipt required beyond design | DESIGN_MAPPED;NATIVE_HOLD |
| REQ-GATE-SWOF_CONNECTED-G04 | REQ-GATE-39 | SWOF_CONNECTED×G04 RepoContext/HGK effective load=R | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L2175 | SBL master + HGK native | A02 | native_permission | R02 | RETAIN | R02.NEXT.4 | cell retains R/C/F/N and correct rule | cell_rule_no_promotion | POS-SWOF_CONNECTED-G04 | NEG-SWOF_CONNECTED-G04 | HGK signed original receipt required beyond design | DESIGN_MAPPED;NATIVE_HOLD |
| REQ-GATE-STANDALONE-G05 | REQ-GATE-39 | STANDALONE×G05 SoD/Independent Reviewer=C | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L2176 | SBL master + HGK native | A02 | native_permission | R02 | RETAIN | R02.NEXT.4 | cell retains R/C/F/N and correct rule | cell_rule_no_promotion | POS-STANDALONE-G05 | NEG-STANDALONE-G05 | HGK signed original receipt required beyond design | DESIGN_MAPPED;NATIVE_HOLD |
| REQ-GATE-PREW3_SHADOW-G05 | REQ-GATE-39 | PREW3_SHADOW×G05 SoD/Independent Reviewer=C | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L2176 | SBL master + HGK native | A02 | native_permission | R02 | RETAIN | R02.NEXT.4 | cell retains R/C/F/N and correct rule | cell_rule_no_promotion | POS-PREW3_SHADOW-G05 | NEG-PREW3_SHADOW-G05 | HGK signed original receipt required beyond design | DESIGN_MAPPED;NATIVE_HOLD |
| REQ-GATE-SWOF_CONNECTED-G05 | REQ-GATE-39 | SWOF_CONNECTED×G05 SoD/Independent Reviewer=R | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L2176 | SBL master + HGK native | A02 | native_permission | R02 | RETAIN | R02.NEXT.4 | cell retains R/C/F/N and correct rule | cell_rule_no_promotion | POS-SWOF_CONNECTED-G05 | NEG-SWOF_CONNECTED-G05 | HGK signed original receipt required beyond design | DESIGN_MAPPED;NATIVE_HOLD |
| REQ-GATE-STANDALONE-G06 | REQ-GATE-39 | STANDALONE×G06 Runner/Test/Raw Evidence=R | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L2177 | SBL master + HGK native | A02 | native_permission | R02 | RETAIN | R02.NEXT.4 | cell retains R/C/F/N and correct rule | cell_rule_no_promotion | POS-STANDALONE-G06 | NEG-STANDALONE-G06 | HGK signed original receipt required beyond design | DESIGN_MAPPED;NATIVE_HOLD |
| REQ-GATE-PREW3_SHADOW-G06 | REQ-GATE-39 | PREW3_SHADOW×G06 Runner/Test/Raw Evidence=C | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L2177 | SBL master + HGK native | A02 | native_permission | R02 | RETAIN | R02.NEXT.4 | cell retains R/C/F/N and correct rule | cell_rule_no_promotion | POS-PREW3_SHADOW-G06 | NEG-PREW3_SHADOW-G06 | HGK signed original receipt required beyond design | DESIGN_MAPPED;NATIVE_HOLD |
| REQ-GATE-SWOF_CONNECTED-G06 | REQ-GATE-39 | SWOF_CONNECTED×G06 Runner/Test/Raw Evidence=R | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L2177 | SBL master + HGK native | A02 | native_permission | R02 | RETAIN | R02.NEXT.4 | cell retains R/C/F/N and correct rule | cell_rule_no_promotion | POS-SWOF_CONNECTED-G06 | NEG-SWOF_CONNECTED-G06 | HGK signed original receipt required beyond design | DESIGN_MAPPED;NATIVE_HOLD |
| REQ-GATE-STANDALONE-G07 | REQ-GATE-39 | STANDALONE×G07 Target mutation/Permit=C | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L2178 | SBL master + HGK native | A02 | native_permission | R02 | RETAIN | R02.NEXT.4 | cell retains R/C/F/N and correct rule | cell_rule_no_promotion | POS-STANDALONE-G07 | NEG-STANDALONE-G07 | HGK signed original receipt required beyond design | DESIGN_MAPPED;NATIVE_HOLD |
| REQ-GATE-PREW3_SHADOW-G07 | REQ-GATE-39 | PREW3_SHADOW×G07 Target mutation/Permit=F | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L2178 | SBL master + HGK native | A02 | native_permission | R02 | RETAIN | R02.NEXT.4 | cell retains R/C/F/N and correct rule | cell_rule_no_promotion | POS-PREW3_SHADOW-G07 | NEG-PREW3_SHADOW-G07 | HGK signed original receipt required beyond design | DESIGN_MAPPED;NATIVE_HOLD |
| REQ-GATE-SWOF_CONNECTED-G07 | REQ-GATE-39 | SWOF_CONNECTED×G07 Target mutation/Permit=R | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L2178 | SBL master + HGK native | A02 | native_permission | R02 | RETAIN | R02.NEXT.4 | cell retains R/C/F/N and correct rule | cell_rule_no_promotion | POS-SWOF_CONNECTED-G07 | NEG-SWOF_CONNECTED-G07 | HGK signed original receipt required beyond design | DESIGN_MAPPED;NATIVE_HOLD |
| REQ-GATE-STANDALONE-G08 | REQ-GATE-39 | STANDALONE×G08 Bounded Repair=C | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L2179 | SBL master + HGK native | A02 | native_permission | R02 | RETAIN | R02.NEXT.4 | cell retains R/C/F/N and correct rule | cell_rule_no_promotion | POS-STANDALONE-G08 | NEG-STANDALONE-G08 | HGK signed original receipt required beyond design | DESIGN_MAPPED;NATIVE_HOLD |
| REQ-GATE-PREW3_SHADOW-G08 | REQ-GATE-39 | PREW3_SHADOW×G08 Bounded Repair=F | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L2179 | SBL master + HGK native | A02 | native_permission | R02 | RETAIN | R02.NEXT.4 | cell retains R/C/F/N and correct rule | cell_rule_no_promotion | POS-PREW3_SHADOW-G08 | NEG-PREW3_SHADOW-G08 | HGK signed original receipt required beyond design | DESIGN_MAPPED;NATIVE_HOLD |
| REQ-GATE-SWOF_CONNECTED-G08 | REQ-GATE-39 | SWOF_CONNECTED×G08 Bounded Repair=C | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L2179 | SBL master + HGK native | A02 | native_permission | R02 | RETAIN | R02.NEXT.4 | cell retains R/C/F/N and correct rule | cell_rule_no_promotion | POS-SWOF_CONNECTED-G08 | NEG-SWOF_CONNECTED-G08 | HGK signed original receipt required beyond design | DESIGN_MAPPED;NATIVE_HOLD |
| REQ-GATE-STANDALONE-G09 | REQ-GATE-39 | STANDALONE×G09 PRE-W3 Shadow Compatibility=N | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L2180 | SBL master + HGK native | A02 | native_permission | R02 | RETAIN | R02.NEXT.4 | cell retains R/C/F/N and correct rule | cell_rule_no_promotion | POS-STANDALONE-G09 | NEG-STANDALONE-G09 | HGK signed original receipt required beyond design | DESIGN_MAPPED;NATIVE_HOLD |
| REQ-GATE-PREW3_SHADOW-G09 | REQ-GATE-39 | PREW3_SHADOW×G09 PRE-W3 Shadow Compatibility=R | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L2180 | SBL master + HGK native | A02 | native_permission | R02 | RETAIN | R02.NEXT.4 | cell retains R/C/F/N and correct rule | cell_rule_no_promotion | POS-PREW3_SHADOW-G09 | NEG-PREW3_SHADOW-G09 | HGK signed original receipt required beyond design | DESIGN_MAPPED;NATIVE_HOLD |
| REQ-GATE-SWOF_CONNECTED-G09 | REQ-GATE-39 | SWOF_CONNECTED×G09 PRE-W3 Shadow Compatibility=C | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L2180 | SBL master + HGK native | A02 | native_permission | R02 | RETAIN | R02.NEXT.4 | cell retains R/C/F/N and correct rule | cell_rule_no_promotion | POS-SWOF_CONNECTED-G09 | NEG-SWOF_CONNECTED-G09 | HGK signed original receipt required beyond design | DESIGN_MAPPED;NATIVE_HOLD |
| REQ-GATE-STANDALONE-G10 | REQ-GATE-39 | STANDALONE×G10 Dogfood/Evolution=C | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L2181 | SBL master + HGK native | A02 | native_permission | R02 | RETAIN | R02.NEXT.4 | cell retains R/C/F/N and correct rule | cell_rule_no_promotion | POS-STANDALONE-G10 | NEG-STANDALONE-G10 | HGK signed original receipt required beyond design | DESIGN_MAPPED;NATIVE_HOLD |
| REQ-GATE-PREW3_SHADOW-G10 | REQ-GATE-39 | PREW3_SHADOW×G10 Dogfood/Evolution=C | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L2181 | SBL master + HGK native | A02 | native_permission | R02 | RETAIN | R02.NEXT.4 | cell retains R/C/F/N and correct rule | cell_rule_no_promotion | POS-PREW3_SHADOW-G10 | NEG-PREW3_SHADOW-G10 | HGK signed original receipt required beyond design | DESIGN_MAPPED;NATIVE_HOLD |
| REQ-GATE-SWOF_CONNECTED-G10 | REQ-GATE-39 | SWOF_CONNECTED×G10 Dogfood/Evolution=C | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L2181 | SBL master + HGK native | A02 | native_permission | R02 | RETAIN | R02.NEXT.4 | cell retains R/C/F/N and correct rule | cell_rule_no_promotion | POS-SWOF_CONNECTED-G10 | NEG-SWOF_CONNECTED-G10 | HGK signed original receipt required beyond design | DESIGN_MAPPED;NATIVE_HOLD |
| REQ-GATE-STANDALONE-G11 | REQ-GATE-39 | STANDALONE×G11 OSS Release=C | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L2182 | SBL master + HGK native | A02 | native_permission | R02 | RETAIN | R02.NEXT.4 | cell retains R/C/F/N and correct rule | cell_rule_no_promotion | POS-STANDALONE-G11 | NEG-STANDALONE-G11 | HGK signed original receipt required beyond design | DESIGN_MAPPED;NATIVE_HOLD |
| REQ-GATE-PREW3_SHADOW-G11 | REQ-GATE-39 | PREW3_SHADOW×G11 OSS Release=F | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L2182 | SBL master + HGK native | A02 | native_permission | R02 | RETAIN | R02.NEXT.4 | cell retains R/C/F/N and correct rule | cell_rule_no_promotion | POS-PREW3_SHADOW-G11 | NEG-PREW3_SHADOW-G11 | HGK signed original receipt required beyond design | DESIGN_MAPPED;NATIVE_HOLD |
| REQ-GATE-SWOF_CONNECTED-G11 | REQ-GATE-39 | SWOF_CONNECTED×G11 OSS Release=C | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L2182 | SBL master + HGK native | A02 | native_permission | R02 | RETAIN | R02.NEXT.4 | cell retains R/C/F/N and correct rule | cell_rule_no_promotion | POS-SWOF_CONNECTED-G11 | NEG-SWOF_CONNECTED-G11 | HGK signed original receipt required beyond design | DESIGN_MAPPED;NATIVE_HOLD |
| REQ-GATE-STANDALONE-G12 | REQ-GATE-39 | STANDALONE×G12 W3 ENTRY Formal Gate=N | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L2183 | SBL master + HGK native | A02 | native_permission | R02 | RETAIN | R02.NEXT.4 | cell retains R/C/F/N and correct rule | cell_rule_no_promotion | POS-STANDALONE-G12 | NEG-STANDALONE-G12 | HGK signed original receipt required beyond design | DESIGN_MAPPED;NATIVE_HOLD |
| REQ-GATE-PREW3_SHADOW-G12 | REQ-GATE-39 | PREW3_SHADOW×G12 W3 ENTRY Formal Gate=F | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L2183 | SBL master + HGK native | A02 | native_permission | R02 | RETAIN | R02.NEXT.4 | cell retains R/C/F/N and correct rule | cell_rule_no_promotion | POS-PREW3_SHADOW-G12 | NEG-PREW3_SHADOW-G12 | HGK signed original receipt required beyond design | DESIGN_MAPPED;NATIVE_HOLD |
| REQ-GATE-SWOF_CONNECTED-G12 | REQ-GATE-39 | SWOF_CONNECTED×G12 W3 ENTRY Formal Gate=R | SBL｜SpecBuild Loop：整合工程總藍圖_v2.0r1(1).md:L2183 | SBL master + HGK native | A02 | native_permission | R02 | RETAIN | R02.NEXT.4 | cell retains R/C/F/N and correct rule | cell_rule_no_promotion | POS-SWOF_CONNECTED-G12 | NEG-SWOF_CONNECTED-G12 | HGK signed original receipt required beyond design | DESIGN_MAPPED;NATIVE_HOLD |

## C52.r3.1｜AUDIT F-001～F-020 分別的正文落點與可否證出口
每項已新增不同的實質 DTO/產品行為及首次失敗；以下是作者端修補索引**非**審計結果或獨立 PASS。特別 F-001 原 SBL 十問/藍圖缺原件時仍 `SOURCE_GAP`，不藉 SWOF 十問替代。
| Finding | Severity | 正文 H1 | 主體功能修補 | POS 檢查 | NEG 反證 | Owner | 證據級別 |
|---|---|---|---|---|---|---|---|
| F-001 | BLOCKER | C02 | 來源 subject 消歧與 10 問準確原句 | POS: 讀取 C02 的對應具名 record 並以已述來源、輸入、輸出與失敗碼驗證 | NEG: 移除 F-001 專用物件/模擬錯來源→ F-001_SUBSTANTIVE_MISSING | Owner by controlling DOC; author local check only | BODY_REPAIRED_CANDIDATE;NOT_INDEPENDENTLY_VERIFIED |
| F-002 | BLOCKER | R00 | 單一現行正文/歷史分離 | POS: 讀取 R00 的對應具名 record 並以已述來源、輸入、輸出與失敗碼驗證 | NEG: 移除 F-002 專用物件/模擬錯來源→ F-002_SUBSTANTIVE_MISSING | Owner by controlling DOC; author local check only | BODY_REPAIRED_CANDIDATE;NOT_INDEPENDENTLY_VERIFIED |
| F-003 | BLOCKER | R04 | 386 法位分類和技術逐項 | POS: 讀取 R04 的對應具名 record 並以已述來源、輸入、輸出與失敗碼驗證 | NEG: 移除 F-003 專用物件/模擬錯來源→ F-003_SUBSTANTIVE_MISSING | Owner by controlling DOC; author local check only | BODY_REPAIRED_CANDIDATE;NOT_INDEPENDENTLY_VERIFIED |
| F-004 | HIGH | R04 | 226 專用 pos-neg | POS: 讀取 R04 的對應具名 record 並以已述來源、輸入、輸出與失敗碼驗證 | NEG: 移除 F-004 專用物件/模擬錯來源→ F-004_SUBSTANTIVE_MISSING | Owner by controlling DOC; author local check only | BODY_REPAIRED_CANDIDATE;NOT_INDEPENDENTLY_VERIFIED |
| F-005 | HIGH | C48 | 45 owner H1 實質 locator | POS: 讀取 C48 的對應具名 record 並以已述來源、輸入、輸出與失敗碼驗證 | NEG: 移除 F-005 專用物件/模擬錯來源→ F-005_SUBSTANTIVE_MISSING | Owner by controlling DOC; author local check only | BODY_REPAIRED_CANDIDATE;NOT_INDEPENDENTLY_VERIFIED |
| F-006 | HIGH | R06 | 38 個 Surface | POS: 讀取 R06 的對應具名 record 並以已述來源、輸入、輸出與失敗碼驗證 | NEG: 移除 F-006 專用物件/模擬錯來源→ F-006_SUBSTANTIVE_MISSING | Owner by controlling DOC; author local check only | BODY_REPAIRED_CANDIDATE;NOT_INDEPENDENTLY_VERIFIED |
| F-007 | HIGH | R04 | 15 Wheel TDR | POS: 讀取 R04 的對應具名 record 並以已述來源、輸入、輸出與失敗碼驗證 | NEG: 移除 F-007 專用物件/模擬錯來源→ F-007_SUBSTANTIVE_MISSING | Owner by controlling DOC; author local check only | BODY_REPAIRED_CANDIDATE;NOT_INDEPENDENTLY_VERIFIED |
| F-008 | HIGH | R04 | 25 Methods | POS: 讀取 R04 的對應具名 record 並以已述來源、輸入、輸出與失敗碼驗證 | NEG: 移除 F-008 專用物件/模擬錯來源→ F-008_SUBSTANTIVE_MISSING | Owner by controlling DOC; author local check only | BODY_REPAIRED_CANDIDATE;NOT_INDEPENDENTLY_VERIFIED |
| F-009 | HIGH | R02 | 16 Moments／3 Golden Journeys | POS: 讀取 R02 的對應具名 record 並以已述來源、輸入、輸出與失敗碼驗證 | NEG: 移除 F-009 專用物件/模擬錯來源→ F-009_SUBSTANTIVE_MISSING | Owner by controlling DOC; author local check only | BODY_REPAIRED_CANDIDATE;NOT_INDEPENDENTLY_VERIFIED |
| F-010 | HIGH | R00 | 七痛點產品化 | POS: 讀取 R00 的對應具名 record 並以已述來源、輸入、輸出與失敗碼驗證 | NEG: 移除 F-010 專用物件/模擬錯來源→ F-010_SUBSTANTIVE_MISSING | Owner by controlling DOC; author local check only | BODY_REPAIRED_CANDIDATE;NOT_INDEPENDENTLY_VERIFIED |
| F-011 | HIGH | R06 | Three SP／六模組 | POS: 讀取 R06 的對應具名 record 並以已述來源、輸入、輸出與失敗碼驗證 | NEG: 移除 F-011 專用物件/模擬錯來源→ F-011_SUBSTANTIVE_MISSING | Owner by controlling DOC; author local check only | BODY_REPAIRED_CANDIDATE;NOT_INDEPENDENTLY_VERIFIED |
| F-012 | HIGH | C54 | Dogfood & SWOF feedback | POS: 讀取 C54 的對應具名 record 並以已述來源、輸入、輸出與失敗碼驗證 | NEG: 移除 F-012 專用物件/模擬錯來源→ F-012_SUBSTANTIVE_MISSING | Owner by controlling DOC; author local check only | BODY_REPAIRED_CANDIDATE;NOT_INDEPENDENTLY_VERIFIED |
| F-013 | HIGH | C02 | N11/N14/26/28/58/72 先讀路由 | POS: 讀取 C02 的對應具名 record 並以已述來源、輸入、輸出與失敗碼驗證 | NEG: 移除 F-013 專用物件/模擬錯來源→ F-013_SUBSTANTIVE_MISSING | Owner by controlling DOC; author local check only | BODY_REPAIRED_CANDIDATE;NOT_INDEPENDENTLY_VERIFIED |
| F-014 | HIGH | C02 | Oracle Crosswalk | POS: 讀取 C02 的對應具名 record 並以已述來源、輸入、輸出與失敗碼驗證 | NEG: 移除 F-014 專用物件/模擬錯來源→ F-014_SUBSTANTIVE_MISSING | Owner by controlling DOC; author local check only | BODY_REPAIRED_CANDIDATE;NOT_INDEPENDENTLY_VERIFIED |
| F-015 | MEDIUM | R01 | 精確物理檔名 | POS: 讀取 R01 的對應具名 record 並以已述來源、輸入、輸出與失敗碼驗證 | NEG: 移除 F-015 專用物件/模擬錯來源→ F-015_SUBSTANTIVE_MISSING | Owner by controlling DOC; author local check only | BODY_REPAIRED_CANDIDATE;NOT_INDEPENDENTLY_VERIFIED |
| F-016 | HIGH | R02 | 39 Cell predicate | POS: 讀取 R02 的對應具名 record 並以已述來源、輸入、輸出與失敗碼驗證 | NEG: 移除 F-016 專用物件/模擬錯來源→ F-016_SUBSTANTIVE_MISSING | Owner by controlling DOC; author local check only | BODY_REPAIRED_CANDIDATE;NOT_INDEPENDENTLY_VERIFIED |
| F-017 | HIGH | R10 | history disposition 不平行正文 | POS: 讀取 R10 的對應具名 record 並以已述來源、輸入、輸出與失敗碼驗證 | NEG: 移除 F-017 專用物件/模擬錯來源→ F-017_SUBSTANTIVE_MISSING | Owner by controlling DOC; author local check only | BODY_REPAIRED_CANDIDATE;NOT_INDEPENDENTLY_VERIFIED |
| F-018 | HIGH | R04 | Spec-to-Atom 轉譯 | POS: 讀取 R04 的對應具名 record 並以已述來源、輸入、輸出與失敗碼驗證 | NEG: 移除 F-018 專用物件/模擬錯來源→ F-018_SUBSTANTIVE_MISSING | Owner by controlling DOC; author local check only | BODY_REPAIRED_CANDIDATE;NOT_INDEPENDENTLY_VERIFIED |
| F-019 | MEDIUM | R08 | research pin vs selected pin | POS: 讀取 R08 的對應具名 record 並以已述來源、輸入、輸出與失敗碼驗證 | NEG: 移除 F-019 專用物件/模擬錯來源→ F-019_SUBSTANTIVE_MISSING | Owner by controlling DOC; author local check only | BODY_REPAIRED_CANDIDATE;NOT_INDEPENDENTLY_VERIFIED |
| F-020 | HIGH | R05 | 3 類具值端到端例 | POS: 讀取 R05 的對應具名 record 並以已述來源、輸入、輸出與失敗碼驗證 | NEG: 移除 F-020 專用物件/模擬錯來源→ F-020_SUBSTANTIVE_MISSING | Owner by controlling DOC; author local check only | BODY_REPAIRED_CANDIDATE;NOT_INDEPENDENTLY_VERIFIED |

### Compound 要求原子化
來源出現「各有／分別／對應／逐項／每一／所有」時，自動拆出 `parent_req_id,child_req_id,quantifier_target,source_sha,source_clause,scope,acceptance_predicate,negative_fixture,consumer`；禁止讓 `各有 POS+NEG` 保留為父條一條。範例「三 SP 各有 Host 安裝」→三個 `SP` ×指定 Host 的十二項獨立測試；`38 surfaces 各有 uninstall`→38 個 uninstall checks；`39 Gate` 每 cell R/C/F/N 獨立條件和禁止測試。解析器數量核對不等於語義閉合。


# C53｜可重算來源清冊、來源家族與覆蓋分母

## C53.r3.base.1｜Source family disposition、完整性分母與正式 Freeze 缺口
歷史 DOC00 r2 的 186 個物理來源清冊已保留在各 `HISTORICAL_R2_SUBSTANCE` 區塊供回歸；本節的 *本輪* 分母在 R01 機器原始清冊。每個 family 的 bytes/hash 仍應由當輪來源重算，不能用老 r2 的 SHA 代替新附件的 SHA。FamilyCount 僅目前上傳實體數，不代表原資料庫全冊。

| family | physical files | source range | use / retained semantics | native owner / excluded authority | source gaps / qualification |
| AI_AGENT_SPEC_DONOR | 11 | SRC-0002..SRC-0012 | read-only donor: typed interface and failure constraints | AI AGENT SPEC author; NOT_SECOND_WRITER | LOCAL_FILES_HASHED;NO_NATIVE_ADOPTION |
| FABRIC_HGK_DONOR | 9 | SRC-0036..SRC-0044 | read-only donor: typed interface and failure constraints | HGK native effect owner; NOT_SECOND_WRITER | LOCAL_READ_OK;FULL_UPSTREAM_CORPUS_NOT_PROVEN |
| GENIEMAKER_DESIGN_DONOR | 10 | SRC-0026..SRC-0035 | read-only donor: typed interface and failure constraints | GENIEMAKER host owner; NOT_SECOND_WRITER | LOCAL_FILES_HASHED;NO_NATIVE_ADOPTION |
| GENIEMAKER_DOC_DONOR | 13 | SRC-0013..SRC-0025 | read-only donor: typed interface and failure constraints | GENIEMAKER host owner; NOT_SECOND_WRITER | LOCAL_FILES_HASHED;NO_NATIVE_ADOPTION |
| OROCHI_DONOR | 5 | SRC-0149..SRC-0153 | read-only donor: typed interface and failure constraints | OROCHI donor; NOT_SECOND_WRITER | LOCAL_FILES_HASHED;NO_NATIVE_ADOPTION |
| OTHER_REFERENCE | 12 | SRC-0001..SRC-0197 | read-only donor: typed interface and failure constraints | original author / pending classification; NOT_SECOND_WRITER | LOCAL_READ_OK;FULL_UPSTREAM_CORPUS_NOT_PROVEN |
| PIPD_NATIVE | 10 | SRC-0057..SRC-0066 | read-only donor: typed interface and failure constraints | PIPD canonical writer; NOT_SECOND_WRITER | LOCAL_FILES_HASHED;NO_NATIVE_ADOPTION |
| PIPD_PACKAGE_DONOR | 11 | SRC-0045..SRC-0055 | read-only donor: typed interface and failure constraints | PIPD source author; NOT_SECOND_WRITER | LOCAL_FILES_HASHED;NO_NATIVE_ADOPTION |
| PROMPT_HISTORY | 10 | SRC-0068..SRC-0077 | read-only donor: typed interface and failure constraints | Historical low-trust provenance; NOT_SECOND_WRITER | LOCAL_FILES_HASHED;NO_NATIVE_ADOPTION |
| SBL_BLUEPRINT_HISTORY | 5 | SRC-0113..SRC-0127 | SBL design and trace | SBL product blueprint; NOT_SECOND_WRITER | LOCAL_FILES_HASHED;NO_NATIVE_ADOPTION |
| SBL_CONTROL | 6 | SRC-0107..SRC-0112 | SBL design and trace | SBL Product Owner (design scope); NOT_SECOND_WRITER | LOCAL_FILES_HASHED;NO_NATIVE_ADOPTION |
| SBL_DESIGN | 10 | SRC-0115..SRC-0124 | SBL design and trace | SBL source provenance; NOT_SECOND_WRITER | LOCAL_FILES_HASHED;NO_NATIVE_ADOPTION |
| SBL_DOCUMENT_FAMILY | 29 | SRC-0078..SRC-0106 | SBL design and trace | SBL document editor (design-only); NOT_SECOND_WRITER | LOCAL_READ_OK;FULL_UPSTREAM_CORPUS_NOT_PROVEN |
| SDLC_HLPE_DONOR | 20 | SRC-0129..SRC-0148 | read-only donor: typed interface and failure constraints | HLPE donor; NOT_SECOND_WRITER | LOCAL_FILES_HASHED;NO_NATIVE_ADOPTION |
| SKILL_REFERENCE | 2 | SRC-0195..SRC-0196 | read-only donor: typed interface and failure constraints | Independent/method reference; NOT_SECOND_WRITER | LOCAL_FILES_HASHED;NO_NATIVE_ADOPTION |
| SWOF_PD_DONOR | 16 | SRC-0154..SRC-0169 | read-only donor: typed interface and failure constraints | SWOF canonical domain owner; NOT_SECOND_WRITER | LOCAL_FILES_HASHED;NO_NATIVE_ADOPTION |
| SWOF_PI_DONOR | 18 | SRC-0170..SRC-0187 | read-only donor: typed interface and failure constraints | SWOF canonical domain owner; NOT_SECOND_WRITER | LOCAL_FILES_HASHED;NO_NATIVE_ADOPTION |

**MissingSources / Scope Gaps**：`PORTABLE_MOUNT_PROFILE.md` 及 `GRP-01～09` 目前不在本輪 sandbox（只見歷史文件內的預期 hash，非實體）；`SBL_PIPD-LS-PKG_總藍圖`、`SBL_PIPD-LS-PKG_全DOC藍圖`、`SBL_PIPD-LS-PKG_整合校正10問_回答` 本輪無獨立原件；Fabric_HG-KSEOS 原資料庫的每個原生文件未全作獨立實體；DOC-12/13 r1 與 AUDIT 原件未取得。以上全部保留 `SOURCE_MISSING / FULL_REQUESTED_CORPUS_COVERAGE_NOT_PROVEN`，對受影正式 Freeze/PI/Candidate-accepted Claim 一律 HOLD。

**逆向可查**：R01 `source_id → file+SHA`；C48 `global H1 → owner DOC`；C52 `REQ-ID→source line,target H1`；C54 `handoff→next_owner`。Native 授權需使用真正 Owner 提供的 Schema/Receipt，不是這些設計追溯表自行生效。

## C53.r3.1｜本輪精確可得來源與缺口
三份新 SWOF 原件本輪物理讀取且 SHA 如 R01.r3.1；其 `subject_id=SWOF_SQS-THC`、上位 r4 和交易 R09/R00 主權可作 **SWOF_CONNECTED 接收契約資料**。它們不改寫 SBL Owner 的 `SBL_PIPD-LS-PKG_總藍圖`、`SBL_PIPD-LS-PKG_全DOC藍圖` 或 SBL 十問。原 DOC-00 與 2026-10-20 Audit 即使已可得，仍有 Core Profile/GRP 等 session source gap，未補時 `FREEZE_REJECTED`。讀者應先查真 physical path/hash，再以 title/citation 作 display，禁止回復到 rNEXT 197 分母宣稱涵蓋新增來源。


# R06｜ReaderProfiles、Host／Brownfield／CLI／Skill 冷啟動入口

## R06.r3.base.1｜五條可直接消費的端到端 ReaderRoute（不虛構真執行）
每個 profile 只在本輪設計上呈現完整讀序、必要外部證據與拒收，不表示這些案例已實際運行。`ReaderRequest` 必有 goal/task/product_kind/mode/host/locator if given；`ReaderRoute` 提供 next DOC、正/負驗證及缺證；`HandoffEnvelope` 必提供 Owner、Claim、Readset Hash 與 return/NACK。

| profile | input | exact reader order | expected outcome | first fail / gate | human vs AI vs native owner | recovery |
| goal-only CLI | goal=todo --json list; source=none; product_kind CLI_TOOL; STANDALONE | R00→R02→DOC-01→DOC-03→DOC-05→DOC-08→DOC-12 | GoalCard + source locator candidate; later clean CLI FUO | INTAKE_INVALID until locator admitted; no source freeze/PI; do not run code | Human supplies source and approves; AI routes; PIPD compiles only on real input; HGK owner effects after token | Ask for only missing source locator then hold |
| brownfield repo | approved desired delta + observed Repo HEAD/currentness/tracked/scope; no ** | R00→DOC-01→DOC-02→DOC-05→DOC-07→DOC-08→DOC-09→DOC-12 | Bounded PR Diff & regression evidence (not DOC-00 output) | PD_BIND_DENY if root/head/writable scope invalid; no out-of-scope files | Human/Repo Owner provides real context; AI proposes PI/PD route; distinct checker tests diff | Rebind changed HEAD and rerun affected-only |
| standalone skill/host | goal + host family/version + skill target, AGENT_SKILL | R00→DOC-01→DOC-06→DOC-07→DOC-10→DOC-12 | versioned skill bundle + Host effective load/UAT/Uninstall | EFFECTIVE_LOAD_UNPROVEN if only SKILL.md, no success from ZIP presence | Human consents install; Host owner enforces loader; checker independent | Disable adapter/uninstall with readback |
| PREW3_SHADOW | mode=PREW3_SHADOW; read-only SWOF/Wave source manifest | R00→DOC-01→DOC-05→DOC-07→DOC-08→DOC-11→DOC-12 | Compatibility findings and blocker list ONLY | G07/F, G08/F, G11/F, G12/F forbid mutation/repair/release/W3 | Human/Owner observes shadow, AI produces report; Native effect not allowed | Stop on attempted effect; quarantine and escalate |
| SWOF_CONNECTED | signed READY_W3 (G12), workorder, verified receiver, genuine ECP/token | R00→DOC-01→DOC-03→DOC-05→DOC-07→DOC-08→DOC-09→DOC-11→DOC-12→DOC-13 | SBL consumed as governed SWOF receiver with ACK and independent evidence | NO_W3_RECEIPT / NO_TOKEN / FOREIGN_RECEIPT; financial LOCAL/PAPER/NO-LIVE-WRITE | Human Release Owner signs, HGK alone effects, checker independently validates | Stop at rejected ACK, scope repair cone and rollback |

## R06.r3.base.2｜跨 Host 正交限定
Host Family 是 Hermes / Codex / Claude Code / DeepSeek Harness，另有 ChatGPT Web / Claude Web 私有體驗；每個 Host 必須有 install/translate/activate/use/negative probe/uninstall/readback 個別結果，不能用 Markdown 檔案或 GitHub 上的下載包假稱有效載入。`SBL Core + TPM-SP/Commander-SP/Acceptance-SP` 的同一 Canonical Truth 在 Host 端只作 projection，Host-specific 裝載差異由 DOC-10/12 Owner 裁決。

## R06.r3.1｜38/38 個 Delivery Surfaces 逐 Surface 可施工設計
從 DOC-12 的 `C-001..C-038` 原表恢復唯一原名稱及 Owner，逐列賦予 `install/translate/activate/effective-load/negative/uninstall/rollback`；`NOT_ADMITTED` 不得硬升 `HOLD_NATIVE`，四 Host loader 與 Web 私人文件非同一資格。此為**設計的驗收語義**，下游需真 Host receipt/Pin/rights。
| Surface | 來源原名稱 | ProductKind 投影 | Owning DOC | Host | Applicability | Install/Translate/Activate | 專用 FUO POS | 專用 NEG | Uninstall/Rollback | 現有 Owner 與限制 |
|---|---|---|---|---|---|---|---|---|---|---|
| `C-001` | TPM-SP 獨立 Skill | AGENT_SKILL | DOC12+owning DOC | Local/Host-dependent | HOLD_NATIVE | discover pin→check rights→register/install→translate→activate | effective-load/trigger+non-trigger+consumer FUO | NEG: SKILL_PACKET_NOT_EFFECTIVE; no receipt→HOLD | uninstall→residue readback→restore LKG | D03/TPM+DOC12 packaging; `HOLD_NATIVE` |
| `C-002` | Commander-SP 獨立 Skill | AGENT_SKILL | DOC12+owning DOC | Local/Host-dependent | HOLD_NATIVE | discover pin→check rights→register/install→translate→activate | effective-load/trigger+non-trigger+consumer FUO | NEG: SKILL_PACKET_NOT_EFFECTIVE; no receipt→HOLD | uninstall→residue readback→restore LKG | D10/CAPC+DOC12 package; `HOLD_NATIVE` |
| `C-003` | Acceptance Challenge-SP 獨立 Skill | AGENT_SKILL | DOC12+owning DOC | Local/Host-dependent | HOLD_NATIVE | discover pin→check rights→register/install→translate→activate | effective-load/trigger+non-trigger+consumer FUO | NEG: SKILL_PACKET_NOT_EFFECTIVE; no receipt→HOLD | uninstall→residue readback→restore LKG | DOC08/V01+DOC12 Challenge packaging; `HOLD_NATIVE` |
| `C-004` | TPM-SP / Hermes Agent | AGENT_SKILL | DOC12+owning DOC | Hermes | HOLD_NATIVE | discover pin→check rights→register/install→translate→activate | effective-load/trigger+non-trigger+consumer FUO | NEG: HOST_EFFECTIVE_LOAD_MISSING; no receipt→HOLD | uninstall→residue readback→restore LKG | A03/A04 Host Native ABI; DOC12 reader; `HOLD_NATIVE` |
| `C-005` | TPM-SP / Codex | AGENT_SKILL | DOC12+owning DOC | Codex | HOLD_NATIVE | discover pin→check rights→register/install→translate→activate | effective-load/trigger+non-trigger+consumer FUO | NEG: HOST_EFFECTIVE_LOAD_MISSING; no receipt→HOLD | uninstall→residue readback→restore LKG | A03/A04 Host Native ABI; DOC12 reader; `HOLD_NATIVE` |
| `C-006` | TPM-SP / Claude Code | AGENT_SKILL | DOC12+owning DOC | Claude Code | HOLD_NATIVE | discover pin→check rights→register/install→translate→activate | effective-load/trigger+non-trigger+consumer FUO | NEG: HOST_EFFECTIVE_LOAD_MISSING; no receipt→HOLD | uninstall→residue readback→restore LKG | A03/A04 Host Native ABI; DOC12 reader; `HOLD_NATIVE` |
| `C-007` | TPM-SP / DeepSeek Harness | AGENT_SKILL | DOC12+owning DOC | DeepSeek | NOT_ADMITTED | discover pin→check rights→register/install→translate→activate | effective-load/trigger+non-trigger+consumer FUO | NEG: NO_VERIFIED_NATIVE_LOADER; no receipt→HOLD | uninstall→residue readback→restore LKG | A03/A04 Host Native ABI; DOC12 reader; `NOT_ADMITTED` |
| `C-008` | Commander-SP / Hermes Agent | AGENT_SKILL | DOC12+owning DOC | Hermes | HOLD_NATIVE | discover pin→check rights→register/install→translate→activate | effective-load/trigger+non-trigger+consumer FUO | NEG: HOST_EFFECTIVE_LOAD_MISSING; no receipt→HOLD | uninstall→residue readback→restore LKG | A03/A04 Host Native ABI; DOC12 reader; `HOLD_NATIVE` |
| `C-009` | Commander-SP / Codex | AGENT_SKILL | DOC12+owning DOC | Codex | HOLD_NATIVE | discover pin→check rights→register/install→translate→activate | effective-load/trigger+non-trigger+consumer FUO | NEG: HOST_EFFECTIVE_LOAD_MISSING; no receipt→HOLD | uninstall→residue readback→restore LKG | A03/A04 Host Native ABI; DOC12 reader; `HOLD_NATIVE` |
| `C-010` | Commander-SP / Claude Code | AGENT_SKILL | DOC12+owning DOC | Claude Code | HOLD_NATIVE | discover pin→check rights→register/install→translate→activate | effective-load/trigger+non-trigger+consumer FUO | NEG: HOST_EFFECTIVE_LOAD_MISSING; no receipt→HOLD | uninstall→residue readback→restore LKG | A03/A04 Host Native ABI; DOC12 reader; `HOLD_NATIVE` |
| `C-011` | Commander-SP / DeepSeek Harness | AGENT_SKILL | DOC12+owning DOC | DeepSeek | NOT_ADMITTED | discover pin→check rights→register/install→translate→activate | effective-load/trigger+non-trigger+consumer FUO | NEG: NO_VERIFIED_NATIVE_LOADER; no receipt→HOLD | uninstall→residue readback→restore LKG | A03/A04 Host Native ABI; DOC12 reader; `NOT_ADMITTED` |
| `C-012` | Acceptance Challenge-SP / Hermes | AGENT_SKILL | DOC12+owning DOC | Hermes | HOLD_NATIVE | discover pin→check rights→register/install→translate→activate | effective-load/trigger+non-trigger+consumer FUO | NEG: HOST_EFFECTIVE_LOAD_MISSING; no receipt→HOLD | uninstall→residue readback→restore LKG | A03/A04 Host Native ABI; DOC12 reader; `HOLD_NATIVE` |
| `C-013` | Acceptance Challenge-SP / Codex | AGENT_SKILL | DOC12+owning DOC | Codex | HOLD_NATIVE | discover pin→check rights→register/install→translate→activate | effective-load/trigger+non-trigger+consumer FUO | NEG: HOST_EFFECTIVE_LOAD_MISSING; no receipt→HOLD | uninstall→residue readback→restore LKG | A03/A04 Host Native ABI; DOC12 reader; `HOLD_NATIVE` |
| `C-014` | Acceptance Challenge-SP / Claude Code | AGENT_SKILL | DOC12+owning DOC | Claude Code | HOLD_NATIVE | discover pin→check rights→register/install→translate→activate | effective-load/trigger+non-trigger+consumer FUO | NEG: HOST_EFFECTIVE_LOAD_MISSING; no receipt→HOLD | uninstall→residue readback→restore LKG | A03/A04 Host Native ABI; DOC12 reader; `HOLD_NATIVE` |
| `C-015` | Acceptance Challenge-SP / DeepSeek Harness | AGENT_SKILL | DOC12+owning DOC | DeepSeek | NOT_ADMITTED | discover pin→check rights→register/install→translate→activate | effective-load/trigger+non-trigger+consumer FUO | NEG: NO_VERIFIED_NATIVE_LOADER; no receipt→HOLD | uninstall→residue readback→restore LKG | A03/A04 Host Native ABI; DOC12 reader; `NOT_ADMITTED` |
| `C-016` | TPM-SP ChatGPT private ZIP | AGENT_SKILL | DOC12+owning DOC | Web private | HOLD_NATIVE | discover pin→check rights→register/install→translate→activate | effective-load/trigger+non-trigger+consumer FUO | NEG: WEB_UPLOAD_NOT_EFFECTIVE; no receipt→HOLD | uninstall→residue readback→restore LKG | D10 Web/private host owner; DOC12 projection; `HOLD_NATIVE` |
| `C-017` | Commander-SP ChatGPT private ZIP | AGENT_SKILL | DOC12+owning DOC | Web private | HOLD_NATIVE | discover pin→check rights→register/install→translate→activate | effective-load/trigger+non-trigger+consumer FUO | NEG: WEB_UPLOAD_NOT_EFFECTIVE; no receipt→HOLD | uninstall→residue readback→restore LKG | D10 Web/private host owner; DOC12 projection; `HOLD_NATIVE` |
| `C-018` | Challenge-SP ChatGPT private ZIP | AGENT_SKILL | DOC12+owning DOC | Web private | HOLD_NATIVE | discover pin→check rights→register/install→translate→activate | effective-load/trigger+non-trigger+consumer FUO | NEG: WEB_UPLOAD_NOT_EFFECTIVE; no receipt→HOLD | uninstall→residue readback→restore LKG | D10 Web/private host owner; DOC12 projection; `HOLD_NATIVE` |
| `C-019` | TPM-SP ChatGPT Web MD | AGENT_SKILL | DOC12+owning DOC | Web private | HOLD_NATIVE | discover pin→check rights→register/install→translate→activate | effective-load/trigger+non-trigger+consumer FUO | NEG: WEB_UPLOAD_NOT_EFFECTIVE; no receipt→HOLD | uninstall→residue readback→restore LKG | D10 Web/private host owner; DOC12 projection; `HOLD_NATIVE` |
| `C-020` | Commander-SP ChatGPT Web MD | AGENT_SKILL | DOC12+owning DOC | Web private | HOLD_NATIVE | discover pin→check rights→register/install→translate→activate | effective-load/trigger+non-trigger+consumer FUO | NEG: WEB_UPLOAD_NOT_EFFECTIVE; no receipt→HOLD | uninstall→residue readback→restore LKG | D10 Web/private host owner; DOC12 projection; `HOLD_NATIVE` |
| `C-021` | Challenge-SP ChatGPT Web MD | AGENT_SKILL | DOC12+owning DOC | Web private | HOLD_NATIVE | discover pin→check rights→register/install→translate→activate | effective-load/trigger+non-trigger+consumer FUO | NEG: WEB_UPLOAD_NOT_EFFECTIVE; no receipt→HOLD | uninstall→residue readback→restore LKG | D10 Web/private host owner; DOC12 projection; `HOLD_NATIVE` |
| `C-022` | TPM-SP Claude Web MD | AGENT_SKILL | DOC12+owning DOC | Web private | HOLD_NATIVE | discover pin→check rights→register/install→translate→activate | effective-load/trigger+non-trigger+consumer FUO | NEG: WEB_UPLOAD_NOT_EFFECTIVE; no receipt→HOLD | uninstall→residue readback→restore LKG | D10 Web/private host owner; DOC12 projection; `HOLD_NATIVE` |
| `C-023` | Commander-SP Claude Web MD | AGENT_SKILL | DOC12+owning DOC | Web private | HOLD_NATIVE | discover pin→check rights→register/install→translate→activate | effective-load/trigger+non-trigger+consumer FUO | NEG: WEB_UPLOAD_NOT_EFFECTIVE; no receipt→HOLD | uninstall→residue readback→restore LKG | D10 Web/private host owner; DOC12 projection; `HOLD_NATIVE` |
| `C-024` | Challenge-SP Claude Web MD | AGENT_SKILL | DOC12+owning DOC | Web private | HOLD_NATIVE | discover pin→check rights→register/install→translate→activate | effective-load/trigger+non-trigger+consumer FUO | NEG: WEB_UPLOAD_NOT_EFFECTIVE; no receipt→HOLD | uninstall→residue readback→restore LKG | D10 Web/private host owner; DOC12 projection; `HOLD_NATIVE` |
| `C-025` | TPM-SP Claude Web Native Skill ZIP | AGENT_SKILL | DOC12+owning DOC | Web private | HOLD_NATIVE | discover pin→check rights→register/install→translate→activate | effective-load/trigger+non-trigger+consumer FUO | NEG: WEB_UPLOAD_NOT_EFFECTIVE; no receipt→HOLD | uninstall→residue readback→restore LKG | D10 Web/private host owner; DOC12 projection; `HOLD_NATIVE` |
| `C-026` | Commander-SP Claude Web Native Skill ZIP | AGENT_SKILL | DOC12+owning DOC | Web private | HOLD_NATIVE | discover pin→check rights→register/install→translate→activate | effective-load/trigger+non-trigger+consumer FUO | NEG: WEB_UPLOAD_NOT_EFFECTIVE; no receipt→HOLD | uninstall→residue readback→restore LKG | D10 Web/private host owner; DOC12 projection; `HOLD_NATIVE` |
| `C-027` | Challenge-SP Claude Web Native Skill ZIP | AGENT_SKILL | DOC12+owning DOC | Web private | HOLD_NATIVE | discover pin→check rights→register/install→translate→activate | effective-load/trigger+non-trigger+consumer FUO | NEG: WEB_UPLOAD_NOT_EFFECTIVE; no receipt→HOLD | uninstall→residue readback→restore LKG | D10 Web/private host owner; DOC12 projection; `HOLD_NATIVE` |
| `C-028` | TPM-SP 重用 `PIPD-LS-SP` | AGENT_SKILL | DOC12+owning DOC | Local/Host-dependent | HOLD_NATIVE | discover pin→check rights→register/install→translate→activate | effective-load/trigger+non-trigger+consumer FUO | NEG: SKILL_PACKET_NOT_EFFECTIVE; no receipt→HOLD | uninstall→residue readback→restore LKG | PIPD Public Skills Owner; DOC12 adapter; `HOLD_NATIVE` |
| `C-029` | FABRIC_HG-KSEOS 獨立 Stack / Hermes | SIMPLE_AGENT | DOC12+owning DOC | Hermes | HOLD_NATIVE | discover pin→check rights→register/install→translate→activate | effective-load/trigger+non-trigger+consumer FUO | NEG: NATIVE_OWNER_PERMIT_MISSING; no receipt→HOLD | uninstall→residue readback→restore LKG | HGK/Fabric Native Owner; DOC12 readonly bridge; `HOLD_NATIVE` |
| `C-030` | FABRIC_HG-KSEOS Stack / Codex | SIMPLE_AGENT | DOC12+owning DOC | Codex | HOLD_NATIVE | discover pin→check rights→register/install→translate→activate | effective-load/trigger+non-trigger+consumer FUO | NEG: NATIVE_OWNER_PERMIT_MISSING; no receipt→HOLD | uninstall→residue readback→restore LKG | HGK/Fabric Native Owner; DOC12 readonly bridge; `HOLD_NATIVE` |
| `C-031` | FABRIC_HG-KSEOS Stack / Claude Code | SIMPLE_AGENT | DOC12+owning DOC | Claude Code | HOLD_NATIVE | discover pin→check rights→register/install→translate→activate | effective-load/trigger+non-trigger+consumer FUO | NEG: NATIVE_OWNER_PERMIT_MISSING; no receipt→HOLD | uninstall→residue readback→restore LKG | HGK/Fabric Native Owner; DOC12 readonly bridge; `HOLD_NATIVE` |
| `C-032` | FABRIC_HG-KSEOS Stack / DeepSeek | SIMPLE_AGENT | DOC12+owning DOC | DeepSeek | NOT_ADMITTED | discover pin→check rights→register/install→translate→activate | effective-load/trigger+non-trigger+consumer FUO | NEG: NATIVE_OWNER_PERMIT_MISSING; no receipt→HOLD | uninstall→residue readback→restore LKG | HGK/Fabric Native Owner; DOC12 readonly bridge; `NOT_ADMITTED` |
| `C-033` | SBL Full Stack / Hermes | SIMPLE_AGENT | DOC12+owning DOC | Hermes | HOLD_NATIVE | discover pin→check rights→register/install→translate→activate | effective-load/trigger+non-trigger+consumer FUO | NEG: NATIVE_OWNER_PERMIT_MISSING; no receipt→HOLD | uninstall→residue readback→restore LKG | D04/Host Native+DOC12 full-stack packager; `HOLD_NATIVE` |
| `C-034` | SBL Full Stack / Codex | SIMPLE_AGENT | DOC12+owning DOC | Codex | HOLD_NATIVE | discover pin→check rights→register/install→translate→activate | effective-load/trigger+non-trigger+consumer FUO | NEG: NATIVE_OWNER_PERMIT_MISSING; no receipt→HOLD | uninstall→residue readback→restore LKG | D04/Host Native+DOC12 full-stack packager; `HOLD_NATIVE` |
| `C-035` | SBL Full Stack / Claude Code | SIMPLE_AGENT | DOC12+owning DOC | Claude Code | HOLD_NATIVE | discover pin→check rights→register/install→translate→activate | effective-load/trigger+non-trigger+consumer FUO | NEG: NATIVE_OWNER_PERMIT_MISSING; no receipt→HOLD | uninstall→residue readback→restore LKG | D04/Host Native+DOC12 full-stack packager; `HOLD_NATIVE` |
| `C-036` | SBL Full Stack / DeepSeek | SIMPLE_AGENT | DOC12+owning DOC | DeepSeek | NOT_ADMITTED | discover pin→check rights→register/install→translate→activate | effective-load/trigger+non-trigger+consumer FUO | NEG: NATIVE_OWNER_PERMIT_MISSING; no receipt→HOLD | uninstall→residue readback→restore LKG | D04/Host Native+DOC12 full-stack packager; `NOT_ADMITTED` |
| `C-037` | Selective Install/Upgrade/Rollback | SIMPLE_AGENT | DOC12+owning DOC | Local/Host-dependent | HOLD_NATIVE | discover pin→check rights→register/install→translate→activate | effective-load/trigger+non-trigger+consumer FUO | NEG: DEPENDENCY_CYCLE_OR_RESIDUE; no receipt→HOLD | uninstall→residue readback→restore LKG | D12 M1..M6 installer/Local Product Owner; `HOLD_NATIVE` |
| `C-038` | SBL 自身 CLI (`install/doctor/validate`) | CLI_TOOL | DOC12+owning DOC | Local/Host-dependent | HOLD_NATIVE | discover pin→check rights→register/install→translate→activate | effective-load/trigger+non-trigger+consumer FUO | NEG: ENTRYPOINT_NOT_FOUND; no receipt→HOLD | uninstall→residue readback→restore LKG | D12 M1..M6 installer/Local Product Owner; `HOLD_NATIVE` |

## R06.r3.3｜六個穩定 SBL ModuleRegistry ID 的主責接線修補（優先於先前概略名稱）
以 `SBL_PIPD-LS-PKG_DOC-01(3).md` 的 `C01.3A` 為六模組產品層原始有型別契約；DOC-04 `C12.2 M1-M6` 為另一個實作 FlowModules 投影，兩者不能按相同序號靜默等號。下表的 `SBLM01..06` 是**產品層穩定 ID**，該 ID 保留，任何改名須由 DOC-01/04 Owner 的 ADR 裁決；SBLM04 不做自身的 Native Executor。

| SBL stable ID | 原正式產品功能 | Typed input | Typed output | Native/Canonical Writer | 專用 POS | 專用 NEG → FirstFail |
|---|---|---|---|---|---|---|
| SBLM01 | Goal Intake | GoalText＋SourceLocator＋Consent | IntentCandidate＋SourceRouteCandidate | TPM Reader，PIPD 負責正式 Freeze | 有效來源產候選、空來源保留 HOLD | 空 goal／root traversal 卻繼續 → INTAKE_HOLD |
| SBLM02 | Guided Specification | IntentCandidate＋KnownAnswerRef | ProductIntent＋QuestionLedger | TPM design；PI 正式 Writer=PIPD | 同 SHA 問題去重且 ProductIntent 有 NonGoal | 重問已答問題／簽出正式 PI → SECOND_PI_WRITER |
| SBLM03 | Governed Routing | ProductIntent＋ProfileBindingRef＋HostProbe | RouteDecision{eligible,blocked,reason} | DOC04/06/07 提案，PIPD/HGK 准入 | 合法 Host/TaskKind 得 MethodRoute/NoFit | 未有 Host effective-load 還標 READY → HOST_UNVERIFIED |
| SBLM04 | Governed Build Bridge | BoundPD＋ONE_ECP＋Permit＋RepoSnapshot | NativeWorkOrderRef＋ChangeSetRef | HGK/Fabric Native；SBL 僅 request | token 真合法且 scope 有限時轉外部 Owner | scope=**／PREW3_SHADOW 寫入 → SCOPE_ESCAPE／SHADOW_MUTATION_FORBIDDEN |
| SBLM05 | Evidence-based Verification | CandidateSHA＋RawEvidence＋OracleRef＋DistinctChecker | JourneyAcceptanceCandidate | PIPD/TQAEP＋真正不同 Checker | raw evidence、POS/NEG 同版本可對齊 | 同 principal、自簽、0 tests → NOT_INDEPENDENT |
| SBLM06 | Bounded Repair/Evolution | FirstFail＋RepairCone＋PreviousSHA | RepairProposal＋ExitReceiptExpectation | Native 受影 Owner；DOC13 橫切；DOC12 交付 | 範圍受限修復及可撤銷交付有 readback | rollback 缺失／掃射修改 → REPAIR_SCOPE_EXPANSION |

DOC-04 `M1=Intake,M2=Authority,M3=SPEC,M4=Reuse Resolver,M5=Execution Handoff,M6=Evidence Closure` 是 FlowModule 投影名稱，不與上述 `SBLMxx` ID 一對一視為同一來源真相；例如 `DOC04.M2 Authority` 調用 PIPD 官方 SourceFreeze（不以 SBLM02 內的規格草稿代行），`DOC04.M5 Execution Handoff` 需真正 BoundPD/ECP。凡兩份來源對同一 Port 的 schema_version、Owner 不一致時 `MODULE_PORT_CROSSWALK_HOLD`，不准直接 activate。這個 Crosswalk 是設計候選，仍待 DOC01／DOC04 的權威批准。

## R06.r3.2｜三 SP × 六模組的可讀狀態與事件時序
三個彼此分立 SP：TPM-SP 吸收用戶意圖並只輸出 ProductBrief/ReqAtomProposal，Commander-SP 在已 PIPD/HGK 權威下編排 bounded WorkOrder，Acceptance Challenge-SP 唯讀尋反證且要求真正異 Principal。前述 Goal Intake、Specification、Routing/Planning、Governed Execution Interface、Evidence/Acceptance、Delivery/Recovery 僅為產品階段的**非規範舊簡稱**；正式穩定 ID 和兩種投影以本章 `R06.r3.3` 的 `SBLM01..06`／DOC04 FlowModules Crosswalk 為準；這是 **SBL 產品分組** 而非六個新授權平面，不構成新的 PI Compiler 或 Native Effect Kernel。

`UserGoal(source ref) → Goal Intake [M1] → Specification [M2] → PIPD canonical Intake/Freeze/PI [external Owner] → Routing/Planning [M3] → RepoContext+PD+ONE ECP [PIPD] → Governed Execution Interface [M4, HGK only effects] → Evidence/Acceptance [M5, independent Checker] → Delivery/Recovery [M6, Host UAT, Reader Receiver] → FeedbackCandidate`。

**真負面時序**：假設 Commander 於 PREW3_SHADOW 要求 `write_file()`，M4 先查 ModeGate G07=F→`SHADOW_MUTATION_FORBIDDEN`，不發 permit；觀測 unchanged-tree 才可稱 `DENIED_NO_EFFECT`。若 Checker 與 Maker 相同 Principal，M5 回 `NOT_INDEPENDENT`，不讓 M6 發布。若 `RepoContext.head` 過期，PIPD PD binder 回 NACK，TPM 儲存既有問答但要求重新 source freeze。


# R07｜NACK／FirstFail／Recovery／Rollback 目錄

## R07.r3.base.1｜ConflictRecord 與 NACK/FirstFail 規則表
`ConflictRecord{conflict_id,sources,competing_claims,affected_atoms,current_disposition,owner_to_adjudicate,safe_default,next_action}` 必跟 source SHA 與實體 locator；本節尚未取得 Owner Ratification 的都為 OPEN，不能以新文件的日期或新版作者自稱取代簽章。衝突僅 hold 受影鏈；非作用域的來源導覽/靜態閱讀不必全面停止。

| conflict_id | source A | source B / competing claim | current disposition/safe default | owner_to_adjudicate | next_action |
| CR-ORACLE-001 | P4 PI skill: DOC-03 DOMAIN_ORACLES | PIPD DOC07: Verification/Oracle/Fixture | affected acceptance bindings HOLD; no invented alias | PIPD Canonical+Skill Owner | DOC03/07 exact source predicate compare, ratify signed mapping |
| CR-N11-N14 | N11/N14 design book ownership | later document splitter claims | classification and new H1 renumbering HOLD | SBL Product/Doc Owner | ratify chapters/version in Owner-specific ADR |
| CR-26-28 | historical 26 artifacts | new 28 artifacts or grouped packs | frozen enumeration impossible; no count-based PASS | SBL Package Owner | enumerate ids/hash and approve source set |
| CR-ROLE-72-58 | 72 experts +12 teams old DOC00 | 58 logical jobs/7 domains current table | keep denominators separate; role crosswalk OPEN | SBL Doc Owner + Team Owner | provide 72↔58 mapping or explicit supersession |
| CR-PROFILE-GRP | profile sha only in old docs | profile and nine GRP actual file absent | FORMAL_SOURCE_FREEZE_HOLD | Source Authority Owner | supply exact bytes and verify expected digests |
| CR-DOC12-13-R1 | latest r2 claims r1 repair | r1 AUDIT source files absent | cannot certify repair no-silent-loss | SBL respective DOC Owner | restore r1 + Audit controller for diff |
| CR-FULLCORPUS | 197 local physically readable files | desired all upstream families greater/unknown | FULL_REQUESTED_CORPUS_COVERAGE_NOT_PROVEN | SBL Provenance Steward | freeze complete origin manifests |
| CR-38SURF | 38 delivery surfaces declared | full independent source ID registry not independently closed | 38/38 host install qualification HOLD | DOC-12/Host Owner | enumerate Surface IDs & fixtures in signed BOM |
| CR-386UNIVERSE | 386 technology rows claimed across 8 buckets | currently partially enumerated in current master excerpt | do not claim all 386 individually qualified | G07 + Domain Native Owners | reconcile donor legacy and 8 bucket registries |

| 失敗情境 | FirstFail | 明確恢復方式 / 不得做 |
|---|---|---|
| `goal=''` 或零 locator | `INTAKE_INVALID` | 請補 goal/受允 source，絕不從 chat 臆測源 |
| manifest family 無 sha256 或源未解出 | `AUTHORITY_UNKNOWN` | 更新來源 bytes/manifest；絕不補默認 digest |
| req atom 只有名字無 source_clause | `PI_SCHEMA` | 返 PIPD DOC02/Owner，逐原子補欄位 |
| Repo root/head 不明或 writable_scope=`**` | `PD_BIND_DENY` | 取得真 RepoContext，無通用全域寫權 |
| ECP 無 token / rollback / scope | `NATIVE_PERMIT_MISSING` | HGK/Permission Owner 才能簽，設計不可補合成 |
| PREW3_SHADOW 嘗試寫入或發行 | `SHADOW_EFFECT_FORBIDDEN` | 立即停，不可升 READY_W3 |
| Maker==Checker 或 self-attested receipt | `SOD_VIOLATION` | 使用不同真 Principal/真獨立執行 receipt |
| tool success only without live host readback | `EFFECTIVE_LOAD_UNPROVEN` | 真 Host positive/negative/uninstall probe |
| foreign candidate hash or stale acceptance | `EVIDENCE_SUBJECT_MISMATCH` | 作 affected-only rerun，以同 Candidate 的 raw receipt |
| Release requested without owner/rights/SBOM | `RELEASE_HOLD` | 原 Release Owner 審核完整包；DOC00 不發布 |

## R07.r3.1｜具名 FirstFail→bounded repair 實際處理表
| FirstFail | 首次可觀測觸發 | 可允許的恢復 | 禁止替代 |
|---|---|---|---|
| DELTA_SCOPE_NACK | OpenSpec delta removes unrelated clause | return to proposal writer; keep existing PI unaffected | broad rewrite |
| TASK_ORPHAN_NACK | Spec Kit task without atom_refs | map one original requirement per task then requalify | invent child requirement |
| SELF_CHECKER | Maker==Checker or no original execution receipt | keep NOT_INDEPENDENT; assign different actual principal | role switch claiming independence |
| HOST_NOT_EFFECTIVE | skill file present but loader cannot invoke | reinstall verified package; readback and uninstall | ZIP existence = PASS |
| SHADOW_MUTATION_FORBIDDEN | native write planned in PREW3_SHADOW | deny dispatch; verify no changed bytes | retry with broader token |
| SCOPE_ESCAPE | PD scope=** or root traversal | reject and request bounded writable_scope from repo owner | silently narrow without Owner |
| UNAUTHORIZED_RELEASE | public artifact requested with unverified license/owner | hold publication and keep private design candidate | ignore rights |
| ORACLE_BINDING_CONFLICT | two Oracle references disagree | open CR-ORACLE-001; Owner crosswalk | pick one by name |


# R08｜2026 外部研究、版本鎖定與 Admission Snapshot

## R08.r3.base.1｜2026-08-01～2026-10-20 具名 ResearchEvidence 與技術裁決
實際於 2026-10-20 進行線上查證；`observed_at=2026-10-20 Asia/Taipei`。官方 GitHub Tag 與 Release page 可證發布參照，不能單憑這些資料推導版本安裝成功、Host ABI、安全審計或適用性已達 PASS。`PIPD/Fabric README` 經 GitHub Connector 唯讀讀到 blob SHA，這是內容 blob 而非整個 repository main HEAD 的證據；本輪未在使用者 Repo 上安裝。

| ID | 問題/定位 | publisher/date | 原始 URL | 具體證據/限度 | current decision | source class |
| WEB01 | GPT-6 lean instructions/skill choice | OpenAI / 2026-09-11 | https://developers.openai.com/blog/rethinking-skills-and-prompts-for-gpt-6-astra | Official guidance: shorter skill descriptions, progressive disclosure, contextual AGENTS.md | GUIDANCE_ADOPT | OFFICIAL_SINGLE_SOURCE |
| WEB02 | Current GPT-6 API prompting guidance | OpenAI / 2026-10-20 observed | https://developers.openai.com/api/docs/guides/latest-model | GPT-6 latest-model guidance; do not infer host ABI/permission from model guide | GUIDANCE_ADOPT | OFFICIAL_SINGLE_SOURCE |
| WEB03 | Spec Kit release | GitHub spec-kit / 2026-08-21 | https://github.com/github/spec-kit/releases/tag/v1.0.0 | v1.0.0 tag bca6790; SDD workflow primitives | DESIGN_SELECTED | OFFICIAL_GITHUB |
| WEB04 | OpenSpec current tagged release | Fission-AI / 2026-10-17 | https://github.com/Fission-AI/OpenSpec/releases/tag/v1.14.3 | v1.14.3, abbreviated commit c794978; linked specs, safer globs | DESIGN_SELECTED | OFFICIAL_GITHUB |
| WEB05 | Superpowers method release | obra / 2026-09-25 | https://github.com/obra/superpowers/releases/tag/v6.4.2 | v6.4.2, abbreviated commit 8ca22db; leaner writing plans | DESIGN_SELECTED | OFFICIAL_GITHUB |
| WEB06 | gstack engineering-review donor | garrytan / 2026-10-20 observed | https://github.com/garrytan/gstack | README & package main 1.91.121, no GitHub releases; tag not proved | DESIGN_SELECTED;VERSION_UNVERIFIED | OFFICIAL_MAIN_MOVING |
| WEB07 | mattpocock skills methods | mattpocock / 2026-10-20 observed | https://github.com/mattpocock/skills/releases | v1.3.1 release listed; lock to a specific path/commit after validation | DESIGN_SELECTED;PIN_PENDING | OFFICIAL_GITHUB |
| WEB08 | AGENTS.md open format | agentsmd / 2026-10-20 observed | https://github.com/agentsmd/agents.md | A project instruction format, not permission grant | DESIGN_SELECTED;HOST_PRECEDENCE_HOLD | OFFICIAL_GITHUB |
| WEB09 | PIPD-LS-SP Preview/Beta repo | shw097-team / 2026-10-20 readback | https://github.com/shw097-team/PIPD-LS-SP/blob/main/README.md | README blob 3811f71bc54c65f2a0f794c24e33aebf4091ddf7; Apache-2.0 preview/beta, NOT production | DESIGN_SELECTED;PRODUCTION_HOLD | GITHUB_CONNECTOR |
| WEB10 | Fabric HGK authority mirror | shw097-team / 2026-10-20 readback | https://github.com/shw097-team/Fabric/blob/main/README.md | README blob 9dd1946c3a7c9c76089c814b7ec75c46ab1210b2; governance mirror NOT runtime | DESIGN_SELECTED;NATIVE_EFFECT_HOLD | GITHUB_CONNECTOR |
| WEB11 | Agent evaluation methodology | HF Community / phranzia / 2026-08-27 | https://huggingface.co/blog/phranzia/how-to-evaluate-ai-agents | Representative tasks, controlled harness, observables and repeated trials | INFORMATIVE | COMMUNITY_SINGLE_SOURCE |
| WEB12 | Agent tool use evaluation | HF Community / phranzia / 2026-09-24 | https://huggingface.co/blog/phranzia/evaluating-ai-agent-tool-use | Tool discover/select/use behaviour separate from final completion | INFORMATIVE | COMMUNITY_SINGLE_SOURCE |
| WEB13 | Official prompt engineering | OpenAI / 2026-10-20 observed | https://developers.openai.com/api/docs/guides/prompt-engineering | Pinned prompts, typed constraints and representative evaluations | GUIDANCE_ADOPT | OFFICIAL_SINGLE_SOURCE |

## R08.r3.base.2｜研究強度與系統准入的明確拆層
- `OFFICIAL_RELEASE_VERIFIED` 可用於設計 tag 決定，並不等於 `OSS_SUPPLY_CHAIN_QUALIFIED`；OpenSpec `v1.14.3` 的發布說明補上 globs 安全檢查，但真正安全須對 SBL Host 做負例。
- Spec Kit `v1.0.0` 的 workflow 能力適合作 plan/tasks；不得把 `/specify` 文本變成第二 PIPD Canonical Writer。
- Superpowers 只選 `writing-plans / systematic-debugging / test-driven-development / verification-before-completion` 需求吻合的命名技能，而非盲裝全部；v6.4.2 的精簡計畫仍需本地 POS/NEG。
- gstack release endpoint 未列 tag，所見 main package `1.91.121` 不是不可變 pin；承諾選用角色化方法，但 `VERSION_UNVERIFIED;ACTIVATION_HOLD`。
- mattpocock/skills 目前可見 `v1.3.1` 與 repo 配置規範，正式啟用必 pin 到單個 skill 的對應 commit/path，並驗證 repo-specific config；Beta/in-progress 子技能不能預設已穩定。
- GPT-6 官方指南支持精簡任務/按需 Skills/不複製冗長 prompts；不能把它當 PIPD/Host/Native 的權限授權。
- Hugging Face 2026-08-27、09-24 評估文章是**Community** 信息來源，用於設計可觀測 tool/trace/eval，而非獨立安全證明。
- 每個研究項若沒有另一不同 Owner 的實質互證，強度標記 `UNVERIFIED_SINGLE_SOURCE`；下游 admission 術語需做 `compare_release/tag/commit/license/host_support/CVEs/POS_NEG/rollback`。

### R08.r3.2｜2026-10-20 官方公開版本觀測（研究證據，不等於 Install Pin）
研究讀回官方 Release/Commit 頁：OpenSpec [GitHub releases](https://github.com/Fission-AI/OpenSpec/releases) 顯示 `v1.14.3`（2026-10-17 發布，具 linked specs/safe glob 修復）；Spec Kit [GitHub releases](https://github.com/github/spec-kit/releases) 的歷史 `v1.0.6` 不是可無條件聲稱的現行鎖版，官方九月 newsletter [版本概覽](https://github.com/github/spec-kit/blob/main/newsletters/2026-September.md) 已提 1.0.3～1.0.13 釋出；Superpowers [GitHub commit](https://github.com/obra/superpowers/commit/main) 與 [Issue #2513](https://github.com/obra/superpowers/issues/2513) 指向 2026-10-10 的 `v7.0.0`，不能將 rNEXT `v6.4.2` 直接視為 2026-10-20 最高相容候選。每個實際來源需再由 Owner 固定 `tag+full commit SHA+signed release+license+Host` 並完成兼容驗證。未取得上述確認時 `current_selected_version=UNRATIFIED`、`install=BLOCKED`，不藉外部公開發布奪去既有原上位 disposition，亦不得因版本更新而無聲升級。

## R08.r3.1｜技術版本雙欄不得回歸
原 TDR `research_observed`（例如 Spec Kit v1.0.0、OpenSpec v1.14.3）只是 rNEXT 當時閱讀值；若後續來源列 v1.0.6，**不表示本 DOC-00 已批准升級、降版或真正 Pin**。WheelReadiness 四獨立欄：`design_selection=SELECTED_CANDIDATE; research_observed_version=(source exact); current_selected_version=UNRATIFIED; install_receipt=NONE`，對差異建立 `VersionADR` 的 compatibility diff、license、CVE、Host ABI、migration/rollback。Owner 未簽 ADR 時只能在本地 read-only 模擬，不能將歷史版本推為 current pin。


# R09｜Operator Fixtures、Acceptance 與作者端檢測方案

## R09.r3.base.1｜作者端靜態驗證與高風險 POS/NEG Fixture 契約
作者端只允許本地無副作用：strict UTF-8 讀回、code-fence-aware H1 計數、來源 hash、矩陣 cardinality、唯一 ID、SHA 可重算、正/負輸入的*文件層預期*；不得用這些測試冒稱真 HGK Worker、Host、外部 Checker 或 Consumer 已通過。真正 `RUN` 需由主責 Owner 在授權環境產生 raw logs。

| test_id | scenario / input | expected first fail / accept | oracle | evidence | status |
| NEG-A01 | 同一文本聲稱 PIPD SourceFreeze PASS，但 manifest 缺家族 digest | AUTHORITY_UNKNOWN | manifest sha256 and each family file locator resolved | source inventory+manifest rejection | DESIGNED_NOT_EXECUTED |
| NEG-A02 | PREW3_SHADOW 以 simulated token 呼叫目標寫入 | SHADOW_EFFECT_FORBIDDEN | G07=F and G12=F; no effect | denial/no write receipt | DESIGNED_NOT_EXECUTED |
| NEG-A03 | Maker 改用另一角色提示詞扮演 Independent Checker | SOD_VIOLATION | different true principal + non-self-attested receipt | checker identity and independent raw log | DESIGNED_NOT_EXECUTED |
| NEG-A04 | Host 回報檔案已 copy 但 trigger 不啟動 | EFFECTIVE_LOAD_UNPROVEN | positive Host invocation and negative action | Host version/install/activation/UAT output | DESIGNED_NOT_EXECUTED |
| NEG-A05 | PI atoms=[] 或 source_clause 缺 | PI_SCHEMA/PI_SEMANTIC | nonzero atom count, each with cue+guard | schema failure field | DESIGNED_NOT_EXECUTED |
| NEG-A06 | PD writable_scope=** 或 guessed root | PD_BIND_DENY | tracked FRESH HEAD and bounded path | binder typed refusal | DESIGNED_NOT_EXECUTED |
| NEG-A07 | SWOF_CONNECTED 缺 G12 READY_W3 就宣稱 W3-ready | NO_W3_RECEIPT | G12=R with signed approval | Native owner signed receipt | DESIGNED_NOT_EXECUTED |
| POS-A01 | SBL read-only GoalCard with verifiable source sha | DESIGN_ROUTE_ONLY | DOC-00 route matches owners, no side effects | source bytes+reader route | DESIGNED_NOT_EXECUTED |
| POS-A02 | SBL ProductKind ≠ SWOF Primary Kind distinct | DESIGN_TAXONOMY_OK | two typed columns, no identity remint | source clause+test table | DESIGNED_NOT_EXECUTED |

## R09.r3.base.2｜十二個確定性作者端檢查及 Claim 梯級
檢查順序：1.UTF8/LF/readback；2.17 真 H1 一次；3.六受保護 H1 真 H1；4.45 crosswalk；5.PIPD 十冊/P4 八 Skill 狀態；6.三旅程/16 moments/八 ProductKind；7.39 gate；8.24 cap/386 universe/25 methods/38 surfaces 的 source 分母 honesty；9.Conflicts/TT；10.NEG fixtures；11.OldBlockLedger vs r2；12.claim ceiling。可通過的只是作者端 `AUTHOR_SIDE_STATIC_READBACK`，後三層 `FORMAL_FREEZE/PI_PD`, `NATIVE_EFFECT`, `INDEPENDENT/RELEASE` 均 HOLD/NOT_EXECUTED。


## R09.r3.1｜作者端 7 步全量掃描的明確不同分母
1. **索引**：17 H1、20 Audit findings、45 H1 routes、386 universe、25 methods、24 capability slots、16 moments、39 cells、38 surfaces 各自唯一 ID。
2. **實質定位**：DOC-00 H1 的本章文字與 OwningDoc 實體 H1 分開，不能用索引 table 當正文。
3. **全文核心名詞**：逐來源文件 UTF-8 讀取與 Unicode 保真，檢索 `PIPD/Spec/Writer/Token/Repo/Host/SWOF/Pain` 等家族且列出定位；文字命中不等於內容成功。
4. **交叉**：`subject_id,source_hash,scope,owner,version` 五元組對齊；SWOF 金融十問只投影接收端，不代 SBL 十問。
5. **子要求**：`各有/分別/對應` 每一個父句拆 subatom 並按 39/38/45 等分母檢查。
6. **實質**：章內要有 `trigger→input→algorithm→output→negative→owner→exit`；若只看到 ID 名稱算 `NAMED_ONLY`。
7. **輪子**：具名物件按類型給專用 POS/NEG/Version/License/Install/N/A，防被升為不適格採用。

**作者端回讀**只檢字元、結構、來源路徑、數量及資料一致性；Native tests 和 Independent checker 本任務不可成立。具名失敗仍保留 HOLD，不能把 100% 物理行列宣稱 100% 語義 PASS。


# C54｜AI Zero-Rediscovery／Receiver Handoff／Claim Ceiling／未決工作出口

## C54.r3.base.1｜AI Zero-Rediscovery / Receiver HandoffEnvelope 無隱性補齊
冷啟動讀者的完整 contract：`product_what=SBL governed specification-to-delivery workflow; desired_FUO; product_kind; primary_kind_ref_if_swof; system_mode; input_source+sha; current_SBL_owners; approved_PIPD_owners; chosen_DESIGN_SELECTED_wheels+pin_state; target_doc; missing_evidence; first_fail; stop_condition; next_receiver; exact_candidate_sha; required_consumer_ack`。任何未觀察的欄位保持 null 或 HOLD，不用模型生成虛構的 Repo/Token/Checker。

**Receiver NACK 例**：Consumer 收到 `HostBindingPlan` 卻無 `effective_load`，輸出 `NACK_EFFECTIVE_LOAD_UNPROVEN`；收到 `PREW3_SHADOW` 的 WRITE 請求 → `NACK_SHADOW_EFFECT_FORBIDDEN`；收到 SWOF Canonical Kind 無來源 ID/hash/Owner → `NACK_CANONICAL_UNKNOWN`；收到 Release 宣告缺 Rights/Checksum/Reader UAT → `NACK_RELEASE_EVIDENCE`。發生任何 NACK，回到最小 `RepairCone{affected_refs,first_fail,required_owner,fixable_scope,rerun_oracle}`，不展開無限修補。

## C54.r3.base.3｜正式 Open TT 與安全退出
| TT ID | blocker | affected scope / owner | resolution condition | current state |
|---|---|---|---|---|
| TT-001 | `PORTABLE_MOUNT_PROFILE.md`＋GRP01～09 物理缺件 | full SourceFreeze / Source Authority | restore exact bytes+sha+manifest | OPEN |
| TT-002 | `CR-ORACLE-001` unresolved source/write ownership | PIPD official OracleBinding | signed ABI/predicate reconciliation + fixture | OPEN |
| TT-003 | `N11/N14` 文件分冊 Owner 裁決 | SBL Doc Owner | signed ChapterRegistry/supersession | OPEN |
| TT-004 | `26 vs 28` artefact denominator | SBL packager | unambiguous canonical id+hash list | OPEN |
| TT-005 | historic `72/12` vs current `58/7` crosswalk | doc/role owner | explicit verified mapping | OPEN |
| TT-006 | r1 DOC12/13 audit controllers not present | body retention assurance | original r1 + audit raw verified | OPEN |
| TT-007 | 386 technology identities, 25 methods and 38 Delivery Surfaces not all locally independently proven | Technical/Host Owner | source bound all IDs and positive/negative fixtures | OPEN |
| TT-008 | no real RepoContext/head/writable_scope | PIPD PD Binder | FRESH RepoContext and formal PI ref | OPEN |
| TT-009 | no token/ONE ECP/effect receipt | HGK Native Owner | approved effects and bounded readback | OPEN |
| TT-010 | no distinct Checker principal/receipt | Independent Acceptance Owner | fresh same candidate signed check | OPEN |
| TT-011 | no Product Owner ratification/Release evidence | Human Release Owner | owner token+SBOM/rights+consumer ACK | OPEN |
| TT-012 | missing standalone `SBL_PIPD-LS-PKG_總藍圖/全DOC藍圖/整合校正10問` | source provenance | restore and cross-check sha | OPEN |

本單檔完成≠整體 SBL 全 DOC 編譯；`FORMAL_SOURCE_FREEZE=HOLD`, `PI/PD=NOT_COMPILED`, `NATIVE_EFFECT=NOT_RUN`, `INDEPENDENT_CHECKER=NOT_PERFORMED`, `RELEASE=NOT_PERFORMED`。所有衝突保持 Open 直到指定合法 Owner 裁決。

## C54.r3.1｜SWOF 十問十條逐項與 SBL 功能的受限連接
本輪新 SWOF `整合校正10問_回答.md` **原件已可得**，來源身份已驗；先前 DOC-00 聲稱「十問原件全缺」現在需要區分：**SWOF** 十問已可直接讀取；**SBL** 同名十問的正式原件是否到位仍保持來源缺口。下表是接收端約束而不是 SBL 十問的逐題答覆。
| SWOF 題 | 來源設計答案 | Subject | SBL 合法消費 | 拒絕越權 | 法位 |
|---|---|---|---|---|---|
| Q01 | A 優先 | SWOF_SQS-THC ONLY | SBL-connected typed read-only projection | SWOF Owner domain, no SBL overwrite | SWOF_ONLY_DESIGN_NOT_SBL_Q10 |
| Q02 | A 雙主權平行凍結與 scope-bound ConflictLedger | SWOF_SQS-THC ONLY | SBL-connected typed read-only projection | SWOF Owner domain, no SBL overwrite | SWOF_ONLY_DESIGN_NOT_SBL_Q10 |
| Q03 | A 全量語義保留且設計/工程分期 | SWOF_SQS-THC ONLY | SBL-connected typed read-only projection | SWOF Owner domain, no SBL overwrite | SWOF_ONLY_DESIGN_NOT_SBL_Q10 |
| Q04 | A typed predicates + replay + independent veto | SWOF_SQS-THC ONLY | SBL-connected typed read-only projection | SWOF Owner domain, no SBL overwrite | SWOF_ONLY_DESIGN_NOT_SBL_Q10 |
| Q05 | A 分級資料與穩健 OOS/cost/capacity | SWOF_SQS-THC ONLY | SBL-connected typed read-only projection | SWOF Owner domain, no SBL overwrite | SWOF_ONLY_DESIGN_NOT_SBL_Q10 |
| Q06 | A 全保留五 Kernel 的契約入口並只增量適配 | SWOF_SQS-THC ONLY | SBL-connected typed read-only projection | SWOF Owner domain, no SBL overwrite | SWOF_ONLY_DESIGN_NOT_SBL_Q10 |
| Q07 | A 唯讀 sensor + effect fence | SWOF_SQS-THC ONLY | SBL-connected typed read-only projection | SWOF Owner domain, no SBL overwrite | SWOF_ONLY_DESIGN_NOT_SBL_Q10 |
| Q08 | A 控制面與七 plane 共享 typed Port | SWOF_SQS-THC ONLY | SBL-connected typed read-only projection | SWOF Owner domain, no SBL overwrite | SWOF_ONLY_DESIGN_NOT_SBL_Q10 |
| Q09 | A PIPD 主寫、外工具翻譯 | SWOF_SQS-THC ONLY | SBL-connected typed read-only projection | SWOF Owner domain, no SBL overwrite | SWOF_ONLY_DESIGN_NOT_SBL_Q10 |
| Q10 | A SYSTEM/ASSURED 設計目標並依 Gate 實作 | SWOF_SQS-THC ONLY | SBL-connected typed read-only projection | SWOF Owner domain, no SBL overwrite | SWOF_ONLY_DESIGN_NOT_SBL_Q10 |

## C54.r3.2｜受控雙 Dogfood、A/B/C 飛輪與重資格化
**Loop A（SBL self-dogfood）**：從自身 GJ01-03 的 `FailedUAT/TT` 收集訊號→去識別 `FeedbackSignal{candidate_sha,owner,sample_count,impact}` → 產 `RequirementProposal` → 以源文件 hash 綁追溯→重新走 PIPD Freeze/PI/PD→有限施工/獨立測試→綠色 Host readback → Owner 決定 cutover；未取得正式批准不得 Self-PASS。

**Loop B（SWOF cross-dogfood）**：只在 `PREW3_SHADOW` 下接收 SWOF read-only sensor，對有界 `Proposal` 做相容與負例比對；`SWOF_CONNECTED` 需獨立簽署 G12 READY_W3、ONE ECP/token/rollback、真 Receiver ACK。若 SQS 金融資料 `NoTrade` 合法則回 `NO_ACTION_VALID`，不得被模型解讀成系統失敗而自行下單。

**Loop C（Improvement A/B with Holdout）**：固定 `baseline_sha`, `candidate_sha`, `holdout_set_sha`, success predicates；基線/候選在相同 Consumer+source/mode 觀測，若只靠同一 Maker judge、未記失敗樣本或不具統計設計則 `EVAL_INCONCLUSIVE`；任何採納需 Owner 重新資格化。**停損**：源變更、PR 越權、Open TT、checker 不獨立、供應鏈無權、Broker/Effect 牽涉高風險時 `HALT_AND_ROLLBACK_LAST_KNOWN_GOOD`。

### 固定衝突讀取決策
`N11/N14` 分冊若未經 Owner 裁決：涉及兩冊責任變動的消費者輸出 `DOC_ROUTE_HOLD`，仍可讀現有來源但不得 promotion。`26 vs 28` 工件數量保留 `ARTIFACT_COUNT_CONFLICT`；Reader 應引用文件實際 `DeliverBOM` 而不猜缺項。`58 vs 72` 角色僅 58/7 現行設計；收到 72/12 需回 `HISTORICAL_ERA`。`CR-ORACLE-001`、Owner/Pin/Host/Repo/Checker 缺件皆保留獨立 TT，必要時只停止受影響子流程，不用放寬 Gate。


# R10｜Single-MD DELIVER、Machine Readback 與術語表

## R10.r3.1｜單一現行正文的版本取代與歷史退場
**本版 r3 工程性取代 rNEXT**：已將其 17 個 `NEXT` 主段吸收為各章直屬現行條款，歷史 `*.LEGACY` 區塊不再與現行主文並行；在保留的重要舊主資料（386 items）上，以本版獨立表格規範其合法身份、過往處置、逐項 POS/NEG 與退出，而非重印過期版本的發表狀態。`rNEXT` 位元不修改，SourceHistory 僅可在引用其 SHA 時閲讀，不因存在舊文而更動本版規則。

**正式 Release HOLD**：所有 r3 POS/NEG 為工程設計 fixture，除了作者本地靜態檢查外未真正運行；來源物理可讀不等於 SemanticClosure，PIPD 正式 bundle／Checker／Owner／Native/Host 真收據皆未達。合法聲稱僅 `AUTHOR_SIDE_SUBSTANTIVE_DESIGN_REPAIR`；User/Downstream Reader 遇到未驗證物件應顯示明確的 `HOLD` 與下一個合法 Owner，不容越級宣稱 `FULL_ACCEPTED`。
~~~~~~~~~~
