The first work must accept an ordinary nonempty Goal from its caller.
The source reader must validate the exact set of fourteen SBL documents plus ten PIPD documents.
The source reader must compare every admitted corpus file against its frozen SHA256.
The source reader must reject a locator escaping its admitted corpus root.
The question reader must reuse a live KnownAnswer for the same subject scope source hash plus question key.
The ProductSPEC must identify the actual first work persona.
The ProductSPEC must state the user job to obtain three source bound specifications from an ordinary Goal.
The ProductSPEC must define a readable three SPEC output as the first useful outcome.
The ProductSPEC must retain dedicated positive plus negative acceptance cases for each first work requirement.
The ArchitectureSPEC must name one original writer for every interface seam.
The ArchitectureSPEC must pin the original PIPD schema version for its receiver payload.
The ProgramSPEC must retain an acyclic dependency closure for the first work.
The ProgramSPEC must bind each prerequisite to its original owner.
The first work must write its three SPEC drafts only inside the admitted isolated draft directory.
The receiver must invalidate only the outputs dependent on a changed source hash.
The first work must start source reading plus local drafting without a future execution receipt.
The first work must complete its deterministic source reading plus draft materialization with provider access disabled.
The PIPD compiler must bind every first work functional atom to its own source clause plus original consumer acceptance cases.
The receiver must derive the actual RepoContext immediately before any PD construction binding.
The receiver must obtain the matching original effect admission before a repository or host or user or remote or release mutation.
The worker receiver must reject an expired lease before continuing a governed effect.
The resume receiver must reconcile an unknown world effect before any retry.
The handoff must retain the original Hermes WorkID queue lease plus journal ownership.
The delivery receiver must request the original protected checker after world readback.
