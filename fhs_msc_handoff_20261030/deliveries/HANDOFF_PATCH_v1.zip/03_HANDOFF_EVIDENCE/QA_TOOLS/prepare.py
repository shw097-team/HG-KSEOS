from pathlib import Path
import json,hashlib,shutil,sys,os,subprocess,ast
BASE=Path(r'C:\Users\user\Documents\Codex\2026-10-30\codex-fhs-msc-pipd-ls-pkg\outputs\FHS-MSC_STATIC_REPAIR_2026-10-30_v1')
DEST=BASE.parent/'FHS-MSC_HANDOFF_PATCH_2026-10-30_v1'
PLUGIN=Path(r'C:\Users\user\.codex\plugins\cache\created-by-me-remote\sbl-tpm-sp\0.2.0rc1')
ROOT=Path(r'C:\Projects\Agent_Workspace')
def long(p):
 s=str(p.resolve());return Path(s if s.startswith('\\\\?\\') else '\\\\?\\'+s)
BASE=long(BASE);DEST=long(DEST)
E=DEST/'03_HANDOFF_EVIDENCE';A=DEST/'02_FIRST_WORK'
def sha(b):return hashlib.sha256(b).hexdigest()
def write(p,obj):
 p=long(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
def textfile(p,t):p=long(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(t.strip()+'\n',encoding='utf-8',newline='\n')
def read(p):return json.loads(long(p).read_text(encoding='utf-8'))
def plain(p):return str(p).removeprefix('\\\\?\\')
def command(args):
 r=subprocess.run(args,capture_output=True,env=dict(os.environ,GIT_OPTIONAL_LOCKS='0',GIT_TERMINAL_PROMPT='0'),timeout=60)
 return {'argv':args,'exit_code':r.returncode,'stdout':r.stdout.decode('utf-8','replace'),'stderr':r.stderr.decode('utf-8','replace')}
def main():
 if DEST.exists():raise ValueError('NEW_VERSION_DIRECTORY_ALREADY_EXISTS')
 DEST.mkdir(parents=True)
 # Preserve the existing full books and evidence without repackaging old ZIPs.
 shutil.copytree(BASE/'01_SUBSTANTIVE_BODY',DEST/'01_SUBSTANTIVE_BODY')
 shutil.copytree(BASE/'02_EVIDENCE_AUDIT_APPENDICES',DEST/'02_EVIDENCE_AUDIT_APPENDICES')
 for name in ['INDEX.md','COVERAGE_REPORT.md','REPAIR_CLOSURE_REPORT.md','VERSION_AND_DELIVERY.md','SHA256_PAYLOAD_MANIFEST.json','PACKAGE_READBACK.json']:
  target=E/'BASELINE_ENTRANCES'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(BASE/name,target)
 baseline=[]
 for p in (BASE/'01_SUBSTANTIVE_BODY').rglob('*.md'):baseline.append({'path':p.relative_to(BASE).as_posix(),'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size})
 write(E/'BASELINE_BOOKS.json',baseline)
 # Verify the prior formal delivery before trusting its extracted books.
 old=read(BASE/'PACKAGE_READBACK.json')
 write(E/'BASELINE_ZIP_RECHECK.json',[{'file':r['path'],'recorded':r['sha256'],'actual':sha(Path(r['path']).read_bytes()),'match':sha(Path(r['path']).read_bytes())==r['sha256']} for r in old['zips']])
 pin=[]
 for name,folder in [('PIPD','PIPD'),('HG-KSEOS','HG-KSEOS'),('SBL','SBL'),('Fabric','Fabric')]:
  root=ROOT/folder;pre=['git','-c','core.quotePath=false','-C',str(root)]
  state={k:command(pre+v) for k,v in {'head':['rev-parse','HEAD'],'status':['status','--porcelain=v2','--branch','--untracked-files=all'],'index':['ls-files','--stage'],'cached':['diff','--cached','--name-status']}.items()}
  write(E/'REPO_BEFORE'/f'{name}.json',state)
 # Only the touched interfaces and original static readers are snapshotted.
 selected={
  'PIPD':['src','schemas','tests/test_atomic_requirements.py','tests/test_negative_and_rollback.py','tests/test_s1_lite_slice.py','tests/test_oracle_compat.py','tests/__init__.py','docs/S0_CONTRACT_SPEC.md','skills/pipd-pi-compile/schemas/output.schema.json','skills/pipd-pi-compile/references/examples.md'],
  'HG-KSEOS':['src/hg_kseos','config/hermes.json','config/lane-routing-registry.yaml','tests/test_c14_checkpoint_resume_no_repeat_effect.py','AGENTS.md'],
  'Fabric':['FABRIC/fabric/consumers/hgk_policy_consumer.py','FABRIC/rp002/RP002_CHANGE_CLASS_ROUTER.yaml','FABRIC/AGENTS.md']}
 for repo,items in selected.items():
  root=ROOT/repo
  for rel in items:
   src=long(root/rel);files=list(src.rglob('*')) if src.is_dir() else [src]
   for p in files:
    if not p.is_file() or '__pycache__' in p.parts or p.suffix=='.pyc':continue
    rp=p.relative_to(long(root));b=p.read_bytes();target=E/'READERS'/repo/rp;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b);pin.append({'domain':repo,'source':plain(p),'snapshot':target.relative_to(DEST).as_posix(),'sha256':sha(b)})
 # Original portable adapters and the already shipped corpus are copied as static test data.
 mf=read(PLUGIN/'references/corpus/SourceManifest.json');needed=['scripts/core.py','scripts/read_corpus.py','references/corpus/SourceManifest.json','references/contracts/stage-contracts.json','schemas/sbl-tpm/PlannedTQAEP.schema.json']+[r['path'] for r in mf['files']]
 for rel in needed:
  p=long(PLUGIN/rel);b=p.read_bytes();target=E/'READERS/sbl-tpm-sp'/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b);pin.append({'domain':'sbl-tpm-sp','source':plain(p),'snapshot':target.relative_to(DEST).as_posix(),'sha256':sha(b)})
 write(E/'TOUCHED_SOURCE_PINS.json',pin)
 oldmap=read(BASE/'02_EVIDENCE_AUDIT_APPENDICES/STATIC_REPAIR_v1/CURRENT_READER_LOCATORS_2221.json');write(E/'CURRENT_READER_MAP.json',oldmap)
 # A bounded contract snapshot is the normative input to this first-work compile, not all17 prose.
 graph=read(BASE/'02_EVIDENCE_AUDIT_APPENDICES/STATIC_REPAIR_v1/WORKPACKAGE_22_CONSTRUCTION_CONTRACTS.json')
 write(A/'ORIGINAL_22_WP_DAG.json',{'nodes':graph,'first_work':'WP-FHS-15','dependency_closure':['WP-FHS-00','WP-FHS-01','WP-FHS-15'],'compiler_service':'WP-FHS-05.prepare','rule':'compiler service consumes present draft SPEC; no dependency on future WP15 native receipt'})
 print(json.dumps({'delivery':plain(DEST),'baseline_books':len(baseline),'touched_source_files':len(pin),'repo_readback':{r:read(E/'REPO_BEFORE'/f'{r}.json')['head']['stdout'].strip() for r in ['PIPD','HG-KSEOS','SBL','Fabric']}},ensure_ascii=False))
if __name__=='__main__':main()
