from prepare import *
from first_work import module
from markdown_it import MarkdownIt
from urllib.parse import urlsplit,unquote
from collections import Counter
import re,time,platform
def main():
 tick=time.perf_counter();checks=[];cache={}
 def need(ok,msg):
  if not ok:raise AssertionError(msg)
 def test(name,fn):
  try:d=fn();checks.append({'case':name,'status':'PASS','actual':d})
  except Exception as exc:checks.append({'case':name,'status':'FAIL','actual':str(exc)})
 def books():
  baseline=read(E/'BASELINE_BOOKS.json');patched={x['book'] for x in read(E/'AFFECTED_PATCH_LOG.json')};changed=[];unchanged=[]
  for r in baseline:
   old=(BASE/r['path']).read_bytes();new=(DEST/r['path']).read_bytes();need(sha(old)==r['sha256'],'BASELINE_DRIFT:'+r['path'])
   if Path(r['path']).name not in patched:need(old==new,'UNTOUCHED_CHANGED:'+r['path']);unchanged.append(r['path'])
   else:
    i=0
    while i<min(len(old),len(new)) and old[i]==new[i]:i+=1
    need(new[:i]==old[:i] and new.endswith(old[i:]),'PRIOR_BYTES_DELETED_OR_REPLACED:'+r['path']);changed.append(r['path'])
  need(len(list((DEST/'01_SUBSTANTIVE_BODY').glob('*.md')))==17,'BODY17');need(len(baseline)==31,'SBL14')
  return {'full_main_books':17,'SBL_upgrade_books':14,'affected':len(changed),'unchanged_byte_exact':len(unchanged),'all_prior_book_content_preserved':True}
 test('FULL_BOOKS_AND_ALL_PRIOR_CONTENT_NEGATIVES_PRESERVED',books)
 def ids():
  rows=read(E/'CURRENT_READER_MAP.json');old=read(BASE/'02_EVIDENCE_AUDIT_APPENDICES/STATIC_REPAIR_v1/CURRENT_READER_LOCATORS_2221.json');need({(r['group'],r['id']) for r in rows}=={(r['group'],r['id']) for r in old},'ORIGINAL_ID_CHANGED');need(len(rows)==2221 and len({r['anchor'] for r in rows})==2221,'LOCATOR_DUPLICATE')
  for r in rows:
   if r['path'] not in cache:
    b=(DEST/r['path']).read_bytes();cache[r['path']]=(b.decode('utf-8').splitlines(),sha(b))
   ls,dg=cache[r['path']];need(dg==r['sha256'],'LOCATOR_SHA');need(ls[r['line']-1]==f'<a id="{r["anchor"]}"></a>','LOCATOR_LINE');need(ls[r['line']].startswith('#'),'LOCATOR_NOT_HEADER')
  return {'original_identities':2221,'current_locators':2221,'per_group':dict(Counter(r['group'] for r in rows))}
 test('ORIGINAL_IDS_CURRENT_LOCATORS_SHA',ids)
 def sourcepins():
  pins=read(E/'TOUCHED_SOURCE_PINS.json')
  for r in pins:
   need(sha(long(Path(r['source'])).read_bytes())==r['sha256'],'ORIGINAL_SOURCE_CHANGED:'+r['source']);need(sha((DEST/r['snapshot']).read_bytes())==r['sha256'],'READER_SNAPSHOT_CHANGED:'+r['snapshot'])
  return {'necessary_source_files_verified':len(pins),'original_mutations':0}
 test('NECESSARY_SOURCE_AND_ORIGINAL_READER_PINS',sourcepins)
 def bindings():
  traces=read(A/'FUNCTIONAL_ATOMS_CONSUMERS_POS_NEG.json');need(len(traces)==24,'FUNCTIONAL24')
  for r in traces:
   need(all(r.get(k) for k in ['consumer','POS','NEG','source_locator','source_bindings']),'FUNCTIONAL_SUBITEM_GAP')
   for s in r['source_bindings']:
    p=DEST/s['path'];b=p.read_bytes();need(sha(b)==s['sha256'],'SOURCE_BINDING_SHA');need(1<=s['line_from']<=s['line_to']<=len(b.decode('utf-8-sig').splitlines()),'SOURCE_LINE_RANGE')
  return '24 functional clauses have real original source file/SHA/line + Consumer + dedicated POS/NEG'
 test('ALL_FIRST_WORK_FUNCTIONAL_SOURCE_COORDINATES',bindings)
 sys.path.insert(0,plain(E/'READERS/PIPD/src'));from pipd_ls_sp import pipeline,validate
 core=module('handoff_global_core',E/'READERS/sbl-tpm-sp/scripts/core.py');pi=read(A/'PI-PKG.json')
 def compilation():
  actual=pipeline.compile_pi(read(A/'IntentCard.json'),'STANDARD');need(pipeline.strip_sidecar(actual)==pi,'COMPILER_REPLAY_CHANGED');ack=pipeline.validate_pi(actual,E/'READERS/PIPD/schemas');need(ack['verdict']=='PASS','FULL_MEMBER_PI_READER_NACK');need(len(pipeline.atoms_of(actual))==24,'FUNCTIONAL_ATOM_COUNT');return {'reader':ack,'functional_atoms':24,'replay_identical':True}
 test('ORIGINAL_COMPILER_REPLAY_AND_FULL_MEMBER_READER',compilation)
 def profilelock():
  profile=read(A/'ProfileBinding.json');need(profile==pi['stable_semantic_contract']['profile_binding'],'PROFILE_FORK');fr=read(A/'SourceFreezeInput.json')['families']
  for key,v in fr.items():
   manifest=A/'SOURCE_FAMILIES'/f'{key}.json';need(sha(manifest.read_bytes())==v['manifest_sha256'],'SOURCE_MANIFEST_SHA')
   for f in v['files']:need(sha(long(Path(v['root'])/f['rel']).read_bytes())==f['sha256'],'SOURCE_FAMILY_BYTE_DRIFT')
  need(pipeline.freeze_authority({'families':fr})==read(A/'SourceAuthority.json'),'AUTHORITY_REPLAY_DRIFT');return 'SourceAuthority actual family-manifest digests + effective Profile exactly equal compiler binding'
 test('SOURCE_AUTHORITY_PROFILE_COMPILE_LOCK_JOIN',profilelock)
 def handoff():
  bundle={'PI-PKG':pi,'TaskSpecSeed':read(A/'TaskSpecSeed.json'),'WorkOrderCandidate':read(A/'WorkOrderCandidate.json'),'ExecutionHandoff':read(A/'ExecutionHandoff.json'),'ProfileBinding':read(A/'ProfileBinding.json')};ack=validate.validate_bundle(bundle,E/'READERS/PIPD/schemas',pipeline.frozen_validation_context(pi));need(ack['verdict']=='PASS','STRICT_HANDOFF_NACK');need(bundle['WorkOrderCandidate']['candidate_only'] is True,'FALSE_NATIVE_WORKORDER');need(read(E/'HGK_PURE_REQUEST_CONSTRUCTOR_READBACK.json')['admission_invoked'] is False,'NATIVE_CALLED');return ack
 test('TASKSPEC_STRICT_HANDOFF_AND_NO_CANONICAL_NATIVE_MUTATION',handoff)
 def dags():
  original=read(A/'ORIGINAL_22_WP_DAG.json');graph={r['id']:r['depends_on'] for r in original['nodes']};r=core.affected_work(graph,[]);need(len(r['order'])==22,'ORIGINAL_DAG');r2=core.affected_work(read(A/'RECEIVER_ARTIFACT_DEPENDENCY_GRAPH.json')['graph'],[]);need(len(r2['order'])==5,'ARTIFACT_DAG');park=core.affected_work(graph,['WP-FHS-02']);need(all(k in park['ready'] for k in ['WP-FHS-00','WP-FHS-01','WP-FHS-05','WP-FHS-15']),'UNRELATED_GLOBAL_HOLD');return {'original_WP_nodes':22,'artifact_prepare_nodes':5,'future_live_receipt_predecessors':0,'OPS_affected_only':True}
 test('MINIMAL_CLOSURE_DAG_AND_NO_FUTURE_RECEIPT_INVERSION',dags)
 def ready():
  need(read(E/'MINIMAL_STATIC_TESTS.json')['fail']==0,'MINIMAL_TEST_FAILURE');gaps=read(E/'GAPS_CLASSIFICATION_AND_RESUME.json');need(all(not r.get('blocks_first_work',False) for r in gaps),'AUTHOR_HANDOFF_BLOCK');need(all(r['state'].startswith(('RESOLVED','BOUND')) for r in gaps if r['classification'] in ['SOURCE_RESOLVABLE','REPO_BINDABLE']),'UNRESOLVED_AUTHOR_SCOPE')
  for r in gaps:
   if r['classification'] in ['OWNER_DECISION_REQUIRED','NATIVE_EVIDENCE_REQUIRED']:need(all(r.get(k) for k in ['owner','reader','first_fail','affected','next_legal_action','resume']),'EXTERNAL_HOLD_NOT_RESUMABLE')
  return {'minimal_checks':35,'reused_original_tests':5,'unresolved_author_handoff_blockers':0,'external_gaps':'named, affected-only, resumable'}
 test('MINIMAL_TESTS_AND_CLASSIFIED_RECOVERABLE_GAPS',ready)
 def fuo():
  x=read(A/'RUN/FUO.json');keys={'persona','clean_start','source_sha','selected_path','first_useful_output','elapsed_ms','questions_reasked','error_count','provider_off','consumer_acceptance'};need(set(x)==keys,'FUO_TEN_FIELDS');need(x['questions_reasked']==0 and x['provider_off'] is True,'KNOWNANSWER_PROVIDER');need((A/x['first_useful_output']).exists(),'FIRST_USEFUL_OUTPUT_MISSING');return 'FUO all ten source-required fields actual; three SPEC present; zero known-answer reask'
 test('FIRST_USEFUL_OUTPUT_AND_KNOWNANSWER',fuo)
 def links():
  active=list((DEST/'01_SUBSTANTIVE_BODY').rglob('*.md'))+list(DEST.glob('*.md'))+list(E.glob('E0*.md'));n=0
  for p in active:
   for token in MarkdownIt().parse(p.read_text(encoding='utf-8')):
    for c in token.children or []:
     if c.type!='link_open':continue
     target=c.attrGet('href')
     if not target or re.match(r'^[A-Za-z][A-Za-z0-9+.-]*:',target):continue
     u=urlsplit(target);d=(p.parent/unquote(u.path)).resolve() if u.path else p.resolve();need(d.exists(),'LINK_MISSING:'+str(p)+':'+target);n+=1
  return {'current_relative_links':n,'missing':0}
 test('CURRENT_READER_RELATIVE_LINKS',links)
 def repo():
  names=['PIPD','HG-KSEOS','SBL','Fabric'];after={}
  for name in names:
   before=read(E/'REPO_BEFORE'/f'{name}.json');pre=['git','-c','core.quotePath=false','-C',str(ROOT/name)];out={k:command(pre+v) for k,v in {'head':['rev-parse','HEAD'],'status':['status','--porcelain=v2','--branch','--untracked-files=all'],'index':['ls-files','--stage'],'cached':['diff','--cached','--name-status']}.items()};write(E/'REPO_AFTER'/f'{name}.json',out)
   for k in before:need(before[k]['exit_code']==0 and out[k]['exit_code']==0,'GIT_READ_ERROR:'+name);need(before[k]['stdout']==out[k]['stdout'],'REPO_STATE_CHANGED:'+name+':'+k)
   after[name]=out['head']['stdout'].strip()
  return {'four_source_worktrees_unchanged':True,'heads':after}
 test('FOUR_WORKTREES_HEAD_INDEX_DIRTY_UNTRACKED_UNCHANGED',repo)
 report={'scope':'ONCE_LIGHTWEIGHT_GLOBAL_HANDOFF_CONSISTENCY','command':[sys.executable,'-B',str(Path(__file__).resolve())],'python':sys.version,'checks':checks,'passed':sum(x['status']=='PASS' for x in checks),'failed':sum(x['status']=='FAIL' for x in checks),'handoff_status':'PIPD_CONSTRUCTION_HANDOFF_READY' if all(x['status']=='PASS' for x in checks) else 'HANDOFF_PARTIAL','Native':'NATIVE_NOT_RUN','independent_checker':'NOT_RUN','release':'NOT_RUN','elapsed_seconds':time.perf_counter()-tick}
 write(E/'LIGHT_GLOBAL_REGRESSION.json',report);print(json.dumps({'passed':report['passed'],'failed':report['failed'],'failures':[x for x in checks if x['status']=='FAIL'],'status':report['handoff_status']},ensure_ascii=False));return 1 if report['failed'] else 0
if __name__=='__main__':sys.exit(main())
