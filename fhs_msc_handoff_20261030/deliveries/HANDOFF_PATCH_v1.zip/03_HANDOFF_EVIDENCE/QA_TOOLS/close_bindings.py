from prepare import *
def main():
 traces=read(A/'FUNCTIONAL_SOURCE_TRACE.json');pins=read(E/'TOUCHED_SOURCE_PINS.json');copied={}
 for tr in traces:
  for b in tr['source_bindings']:
   if b['path'].startswith('BASELINE_STATIC-REPAIR-v1/01_SUBSTANTIVE_BODY/'):
    name=b['path'].split('/')[-1];src=BASE/'01_SUBSTANTIVE_BODY'/name;dest=E/'BASELINE_USED_CURRENT_READERS'/name
    if name not in copied:
     dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(src.read_bytes());copied[name]=dest;pins.append({'domain':'unchanged STATIC-REPAIR-v1 current reader source','source':plain(src),'snapshot':dest.relative_to(DEST).as_posix(),'sha256':sha(src.read_bytes())})
    b['path']=dest.relative_to(DEST).as_posix()
   elif b['path'].startswith('references/corpus/'):
    b['path']='03_HANDOFF_EVIDENCE/READERS/sbl-tpm-sp/'+b['path']
 write(A/'FUNCTIONAL_SOURCE_TRACE.json',traces)
 atoms=read(A/'FUNCTIONAL_ATOMS_CONSUMERS_POS_NEG.json')
 for r in atoms:r['source_bindings']=next(t['source_bindings'] for t in traces if t['local_clause']==r['local_clause'])
 write(A/'FUNCTIONAL_ATOMS_CONSUMERS_POS_NEG.json',atoms);write(E/'TOUCHED_SOURCE_PINS.json',pins)
 # Original compile_pi derives its axes internally. Its actual ProfileBinding is the sole effective one.
 old=read(A/'ProfileBinding.json');write(E/'PROFILE_REQUESTED_PRECOMPILE_READBACK.json',old)
 pi=read(A/'PI-PKG.json');effective=pi['stable_semantic_contract']['profile_binding'];write(A/'ProfileBinding.json',effective)
 sys.path.insert(0,plain(E/'READERS/PIPD/src'));from pipd_ls_sp import pipeline,validate
 record,decision=pipeline.profile_record('STANDARD',effective['axes'])
 if record!=effective:raise ValueError('EFFECTIVE_PROFILE_COMPILER_DRIFT')
 write(A/'ProfileDecision.json',decision);write(E/'PROFILE_EFFECTIVE_JOIN_ACK.json',{'result':'PASS','effective_profile_subject':effective['subject_id'],'source':'original compile_pi internal axis derivation and original profile_record re-read','requested':'STANDARD','original_requested_axes_stored_as_history':'PROFILE_REQUESTED_PRECOMPILE_READBACK.json','profile_veto_downgrade':False})
 bundle={'PI-PKG':pi,'TaskSpecSeed':read(A/'TaskSpecSeed.json'),'WorkOrderCandidate':read(A/'WorkOrderCandidate.json'),'ExecutionHandoff':read(A/'ExecutionHandoff.json'),'ProfileBinding':effective}
 ack=validate.validate_bundle(bundle,E/'READERS/PIPD/schemas',pipeline.frozen_validation_context(pi));write(E/'PIPD_HANDOFF_RECORDS_READER_ACK.json',ack)
 if ack['verdict']!='PASS':raise ValueError('EFFECTIVE_PROFILE_STRICT_ACK_FAIL')
 print(json.dumps({'functional_source_bindings_resolved':len(atoms),'baseline_source_books_copied':len(copied),'effective_profile_join':'PASS','strict_handoff_reader':ack['verdict']},ensure_ascii=False))
if __name__=='__main__':main()
