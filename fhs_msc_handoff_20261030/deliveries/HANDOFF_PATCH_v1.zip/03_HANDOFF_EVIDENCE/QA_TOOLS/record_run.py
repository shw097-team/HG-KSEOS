from prepare import *
import time,platform
def main():
 name=sys.argv[1];script=sys.argv[2];args=[sys.executable,'-X','utf8','-B',script,*sys.argv[3:]];now=time.perf_counter();env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONIOENCODING='utf-8',PYTHONUTF8='1',GIT_OPTIONAL_LOCKS='0',TEMP=plain(E/'TEST_FIXTURES/tmp'),TMP=plain(E/'TEST_FIXTURES/tmp'))
 long(E/'TEST_FIXTURES/tmp').mkdir(parents=True,exist_ok=True)
 r=subprocess.run(args,capture_output=True,env=env,timeout=180);p=E/'RAW';p.mkdir(exist_ok=True);(p/(name+'.stdout.txt')).write_bytes(r.stdout);(p/(name+'.stderr.txt')).write_bytes(r.stderr)
 write(p/(name+'.receipt.json'),{'command':args,'cwd':str(Path.cwd()),'python':sys.version,'platform':platform.platform(),'environment':{k:env[k] for k in ['PYTHONDONTWRITEBYTECODE','PYTHONIOENCODING','PYTHONUTF8','GIT_OPTIONAL_LOCKS','TEMP','TMP']},'exit_code':r.returncode,'elapsed_seconds':time.perf_counter()-now,'stdout_sha256':sha(r.stdout),'stderr_sha256':sha(r.stderr),'claim':'AUTHOR_STATIC_ONLY_NO_NATIVE_EFFECT'})
 print(r.stdout.decode('utf-8','replace')[-4000:]);print(r.stderr.decode('utf-8','replace')[-1000:]);return r.returncode
if __name__=='__main__':sys.exit(main())
