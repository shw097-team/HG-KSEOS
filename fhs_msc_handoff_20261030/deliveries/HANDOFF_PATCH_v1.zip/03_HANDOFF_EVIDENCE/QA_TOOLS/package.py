from prepare import *
import zipfile,platform,re
from markdown_it import MarkdownIt
from urllib.parse import urlsplit,unquote
def main():
 global_report=read(E/'LIGHT_GLOBAL_REGRESSION.json');minimal=read(E/'MINIMAL_STATIC_TESTS.json')
 if global_report['failed'] or minimal['fail']:raise ValueError('HANDOFF_PARTIAL_STATIC_BLOCK')
 status='PIPD_CONSTRUCTION_HANDOFF_READY'
 textfile(E/'E04_FINAL_STATIC_VERDICT.md',f'''# 最終作者端施工交接裁決

**{status}**。

- 首工作：原WP-FHS-15；24個真功能源句→24個原PIPD RequirementAtom，不是ID投影。
- 原PIPD full-member validate_pi與strict TaskSpecSeed/ExecutionHandoff Reader：PASS。
- 最小受影檢查：35 PASS，0 FAIL；其中重用5項原測試。
- 交付前一次輕量全局一致性回歸：12 PASS，0 FAIL；原31冊內容/負例保留，17主冊與14SBL升級冊完整；8冊原位插入、23冊bytes不變；2221原身份與唯一Locator相同。
- 四庫 HEAD/index/dirty/untracked before/after原樣；必要source/Reader pin驗證無漂移。
- SOURCE_RESOLVABLE/REPO_BINDABLE已在本輪合法範圍實際綁定；Owner/Native缺口只影響各自live Scope，具名可恢復，不阻斷首工作。

Native=NATIVE_NOT_RUN；Canonical WorkOrder未建立；Permit未簽；Independent Checker=NOT_RUN；Release=NOT_RUN。此判定不提升上述Claim。原7649量詞與其他產品義務保留原WP；沒有宣稱全產品完成。

封包CRC/UTF8/SHA與每entry bytes驗證將保存在交付根PACKAGE_READBACK.json。原前版/本輪初次測試錯誤與受影修正raw均保留，不抹失敗。不執行Native E2E。
''')
 # Final scripts are evidence only, never installed as a Skill or receiver service.
 q=E/'QA_TOOLS';q.mkdir(exist_ok=True)
 for p in Path('work/handoff_v1').glob('*.py'):(q/p.name).write_bytes(p.read_bytes())
 # Final packaging-time relative-link and UTF8 readback, not another semantic/global test run.
 active=list((DEST/'01_SUBSTANTIVE_BODY').rglob('*.md'))+list(DEST.glob('*.md'))+list(E.glob('E0*.md'));link_count=0
 for p in active:
  for tok in MarkdownIt().parse(p.read_text(encoding='utf-8')):
   for c in tok.children or []:
    if c.type!='link_open':continue
    target=c.attrGet('href')
    if not target or re.match(r'^[A-Za-z][A-Za-z0-9+.-]*:',target):continue
    u=urlsplit(target);d=(p.parent/unquote(u.path)).resolve() if u.path else p.resolve()
    if not d.exists():raise ValueError('PACKAGE_LINK_MISSING:'+target)
    link_count+=1
 exclude={'SHA256_PAYLOAD_MANIFEST.json','SHA256_DELIVERY_MANIFEST.md','PACKAGE_READBACK.json'};payload=[]
 for p in sorted(DEST.rglob('*')):
  if not p.is_file() or p.suffix=='.zip' or p.name in exclude or '__pycache__' in p.parts:continue
  b=p.read_bytes();b.decode('utf-8','strict');payload.append({'path':p.relative_to(DEST).as_posix(),'bytes':len(b),'sha256':sha(b)})
 write(DEST/'SHA256_PAYLOAD_MANIFEST.json',{'kind':'AUTHOR_PAYLOAD_SHA256','scope':'combined body and evidence extracted root','status':status,'self_excluded_by_construction':True,'files':payload})
 body=[x['path'] for x in payload if x['path'].startswith(('01_SUBSTANTIVE_BODY/','02_FIRST_WORK/')) or '/' not in x['path']]
 evidence=[x['path'] for x in payload if x['path'].startswith(('02_EVIDENCE_AUDIT_APPENDICES/','03_HANDOFF_EVIDENCE/')) or x['path'] in ['HANDOFF_README.md','FIRST_WORK_RECEIVER_CONTRACT.md','VERSION_AND_DELIVERY.md','CURRENT_READER_SCOPE.json']]
 body.append('SHA256_PAYLOAD_MANIFEST.json');evidence.append('SHA256_PAYLOAD_MANIFEST.json');zips=[]
 for kind,names in [('BODY',body),('EVIDENCE',evidence)]:
  filename=f'FHS-MSC_{kind}_2026-10-30_HANDOFF-PATCH-v1.zip';p=DEST/filename
  with zipfile.ZipFile(p,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
   for rel in sorted(names):
    info=zipfile.ZipInfo(rel,date_time=(2026,10,30,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;archive.writestr(info,(DEST/rel).read_bytes())
  with zipfile.ZipFile(p) as archive:
   if archive.testzip() is not None:raise ValueError('ZIP_CRC_FAIL')
   if len(archive.namelist())!=len(set(archive.namelist())) or set(archive.namelist())!=set(names):raise ValueError('ZIP_ENTRY_SET_FAIL')
   for rel in names:
    b=archive.read(rel);b.decode('utf-8','strict')
    if b!=(DEST/rel).read_bytes():raise ValueError('ZIP_BYTE_READBACK_FAIL:'+rel)
  zips.append({'kind':kind,'filename':filename,'path':plain(p.resolve()),'entries':len(names),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'CRC':'PASS','UTF8':'PASS','entry_SHA_and_exact_bytes':'PASS','packaged_count':1})
 result={'handoff_status':status,'first_work':'WP-FHS-15','functional_atoms':24,'minimal_static':{'pass':minimal['pass'],'fail':minimal['fail']},'one_light_global':{'pass':global_report['passed'],'fail':global_report['failed']},'current_relative_links_verified':link_count,'zips':zips,'payload_files':len(payload),'Native':'NATIVE_NOT_RUN','canonical_workorder_created':False,'permit_issued':False,'independent_checker':'NOT_RUN','release':'NOT_RUN','original_four_worktrees_modified':False,'delivery_root':plain(DEST.resolve()),'python':sys.version,'platform':platform.platform()}
 write(DEST/'PACKAGE_READBACK.json',result)
 records=[DEST/z['filename'] for z in zips]+[DEST/n for n in ['HANDOFF_README.md','FIRST_WORK_RECEIVER_CONTRACT.md','INDEX.md','VERSION_AND_DELIVERY.md','CURRENT_READER_SCOPE.json','SHA256_PAYLOAD_MANIFEST.json','PACKAGE_READBACK.json']]
 textfile(DEST/'SHA256_DELIVERY_MANIFEST.md','# HANDOFF-PATCH-v1 SHA-256\n\n狀態：'+status+'；Native/Independent/Release未執行。\n\n| File | Bytes | SHA-256 |\n|---|---:|---|\n'+'\n'.join(f'| {p.name} | {p.stat().st_size} | `{sha(p.read_bytes())}` |' for p in records)+'\n\n此表不列自身。Payload manifest亦依構造排除自身。兩ZIP各封裝一次、所有entry逐bytes/CRC/UTF8/SHA讀回通過。')
 print(json.dumps(result,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
