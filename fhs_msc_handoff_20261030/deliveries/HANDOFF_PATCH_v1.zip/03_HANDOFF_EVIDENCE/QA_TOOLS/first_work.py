from prepare import *
import importlib.util,time,copy,sqlite3,socket,platform
def module(name,path):
 spec=importlib.util.spec_from_file_location(name,plain(path));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def main():
 tick=time.perf_counter();core=module('handoff_tpm_core',E/'READERS/sbl-tpm-sp/scripts/core.py')
 sys.path.insert(0,plain(E/'READERS/PIPD/src'))
 from pipd_ls_sp import pipeline,validate,profiles,requirements
 schemas=E/'READERS/PIPD/schemas';pplug=E/'READERS/sbl-tpm-sp'
 mf=core.corpus_manifest(pplug)
 source_refs=[]
 for sid,lo,hi in [('SBL-04',500,527),('SBL-00',60,78)]:
  rec=core.read_clause(pplug,sid,lo,hi);write(E/'SOURCE_CLAUSES'/f'{sid}_{lo}_{hi}.json',rec);source_refs.append({'source_id':sid,'sha256':rec['sha256'],'line_from':lo,'line_to':hi})
 wp=read(A/'ORIGINAL_22_WP_DAG.json');node=next(n for n in wp['nodes'] if n['id']=='WP-FHS-15');write(E/'FIRST_WORK_SOURCE_WP15.json',node)
 # Each line is one real functional obligation, with exact source/Consumer/POS/NEG below.
 definitions=[
 ('Goal intake','The first work must accept an ordinary nonempty Goal from its caller','SBL-04:PM:T0','TPM intake','nonempty goal preserved','empty goal refused'),
 ('Corpus identities','The source reader must validate the exact set of fourteen SBL documents plus ten PIPD documents','SBL-04:K0','core.corpus_manifest','24 source identities read','missing source identity refused'),
 ('Source integrity','The source reader must compare every admitted corpus file against its frozen SHA256','SBL-04:K0','core.read_clause','same bytes admitted','modified source bytes refused'),
 ('Bounded source read','The source reader must reject a locator escaping its admitted corpus root','SBL-04:K3','core.read_contained','admitted relative path read','parent traversal refused'),
 ('Known answers','The question reader must reuse a live KnownAnswer for the same subject scope source hash plus question key','SBL-04:PM:T0','core.QuestionLedger.inspect','same key returns ask false','changed source hash requires a fresh answer'),
 ('Product persona','The ProductSPEC must identify the actual first work persona','SBL-04:PM:T3','core.plan_spec Product','persona in emitted draft','missing persona refused'),
 ('Product job','The ProductSPEC must state the user job to obtain three source bound specifications from an ordinary Goal','SBL-04:PM:T3','core.plan_spec Product','jtbd in emitted draft','missing jtbd refused'),
 ('Useful output','The ProductSPEC must define a readable three SPEC output as the first useful outcome','SBL-04:PM:T2','core.plan_spec Product','three output references present','abstract outcome without output refused'),
 ('Product acceptance','The ProductSPEC must retain dedicated positive plus negative acceptance cases for each first work requirement','SBL-04:PM:T4','core.plan_spec Product','each acceptance has own POS NEG','acceptance without negative refused'),
 ('Architecture authority','The ArchitectureSPEC must name one original writer for every interface seam','SBL-04:SE:T3','core.plan_spec Architecture','one writer per seam','two writers for a seam refused'),
 ('Architecture interface','The ArchitectureSPEC must pin the original PIPD schema version for its receiver payload','SBL-04:SE:T3','PIPD validate_pi','schema version pinned','unknown extra record key refused'),
 ('Program dependencies','The ProgramSPEC must retain an acyclic dependency closure for the first work','SBL-04:TPgM:T2','core.affected_work','WP00 WP01 WP15 closure sorted','cycle refused'),
 ('Program ownership','The ProgramSPEC must bind each prerequisite to its original owner','SBL-04:TPgM:T3','core.plan_spec Program','owner for every node','missing node owner refused'),
 ('Local draft scope','The first work must write its three SPEC drafts only inside the admitted isolated draft directory','WP-FHS-15','TaskSpecSeed receiver adapter','three paths inside draft scope','path outside admitted draft root refused'),
 ('Source drift recovery','The receiver must invalidate only the outputs dependent on a changed source hash','WP-FHS-00','core.affected_work','affected descendants blocked','unrelated ready source reader remains available'),
 ('No receipt inversion','The first work must start source reading plus local drafting without a future execution receipt','WP-FHS-15','ProgramSPEC reader','no live receipt predecessor','future receipt as prerequisite refused'),
 ('Provider off','The first work must complete its deterministic source reading plus draft materialization with provider access disabled','WP-FHS-15 and BODY09B','offline adapter','zero network calls during positive run','provider connection attempt refused'),
 ('PI trace','The PIPD compiler must bind every first work functional atom to its own source clause plus original consumer acceptance cases','PIPD RequirementAtom','pipeline.validate_pi','all atom traces resolve','tampered atom or trace refused'),
 ('Late bound PD','The receiver must derive the actual RepoContext immediately before any PD construction binding','PIPD PD-PKG','pipeline.bind_pd','real measured context','missing root or spoofed freshness refused'),
 ('Effect permissions','The receiver must obtain the matching original effect admission before a repository or host or user or remote or release mutation','BODY03 R2-03-EFFECT','original HGK native admission','read and draft continue','missing OPS permission parks only affected host effect'),
 ('Lease fence','The worker receiver must reject an expired lease before continuing a governed effect','HGK SharedSpine','SharedSpine._assert_lease','current lease accepted in memory fixture','expired lease refused'),
 ('Unknown effect','The resume receiver must reconcile an unknown world effect before any retry','BODY06','core.effect_route and original Hermes receiver','UNKNOWN routes to reconcile','blind retry of UNKNOWN is not dispatched'),
 ('No second queue','The handoff must retain the original Hermes WorkID queue lease plus journal ownership','BODY06','original Hermes runtime','existing WorkID reused on resume','new queue or replacement issuer forbidden'),
 ('Distinct checker','The delivery receiver must request the original protected checker after world readback','BODY07','original protected checker','request names original checker','maker output never becomes independent acceptance')]
 source=A/'FIRST_WORK_FUNCTIONAL_SOURCE.md';textfile(source,'\n'.join(row[1]+'.' for row in definitions))
 lines=source.read_text(encoding='utf-8').splitlines();srcsha=sha(source.read_bytes());trace=[]
 for i,(need,statement,origin,consumer,pos,neg) in enumerate(definitions,1):trace.append({'local_clause':i,'source_text':statement,'source_sha256':srcsha,'original_locator':origin,'consumer':consumer,'POS':pos,'NEG':neg,'requirement_kind':'FUNCTIONAL_OBLIGATION_NOT_ID_PROJECTION'})
 write(A/'FUNCTIONAL_SOURCE_TRACE.json',trace)
 # Actual portable skill invocation uses its original three draft builders.
 accept=[{'requirement':d[0],'positive':d[4],'negative':d[5],'oracle_ref':d[2]} for d in definitions]
 goal='為普通 Goal 產生有來源與可判 POS/NEG 的 Product、Architecture、Program SPEC，交原 PIPD，再交 Hermes 於原權限下續工'
 common={'source_sha256':srcsha,'source_refs':source_refs+[{'wp':'WP-FHS-15','source_sha256':sha((E/'FIRST_WORK_SOURCE_WP15.json').read_bytes())}],'goal':goal,'non_goals':['Native admission','install/build','world effect','independent acceptance','release'],'acceptance':accept}
 product=core.plan_spec('Product',{**common,'persona':'持有普通工程 Goal 的單人 Owner','jtbd':'從已知答案與內建來源取得可由原 PIPD 消費的三 SPEC','fuo':'02_FIRST_WORK/RUN/ProductSPEC.json、ArchitectureSPEC.json、ProgramSPEC.json 三份可讀來源約束規格'})
 architecture=core.plan_spec('Architecture',{**common,'adr':['PI Writer=PIPD；原 Canonical admission=HGK；policy=Fabric；queue/lease/journal=Hermes','source read及local draft不索 Native Permit；Canonical WorkOrder建立由原 HGK 自行准入','ProviderOff由本輪明確 true 決定，不從 legacy ON/OFF 猜映射'],'ownership_seams':[{'name':'source and PI','writers':['PIPD original compiler']},{'name':'policy','writers':['Fabric original policy owner']},{'name':'Canonical WorkOrder','writers':['HGK SharedSpine']},{'name':'queue lease journal','writers':['original Hermes runtime']},{'name':'acceptance','writers':['original Protected Checker']}],'abi_version':'PIPD S0 19-contract Registry/1','risk':['Runtime owner and permission required only at actual effect','DOC07 oracle meaning versus serialized legacy DOC03 remains isolated to live ratification']})
 closure={'WP-FHS-00':[],'WP-FHS-01':['WP-FHS-00'],'WP-FHS-15':['WP-FHS-00']}
 program=core.plan_spec('Program',{**common,'dag':closure,'owners':{'WP-FHS-00':'original SourceReader','WP-FHS-01':'original Source/Profile Owner','WP-FHS-15':'original TPM/PIPD Reader'},'work_packages':{k:next(n for n in wp['nodes'] if n['id']==k) for k in closure},'resume_predicate':'同 SourceSHA 與 KnownAnswer key 則重用；source漂移只失效受影輸出；效果 UNKNOWN 先原 Reconcile，不新建 WorkID'})
 for name,obj in [('ProductSPEC',product),('ArchitectureSPEC',architecture),('ProgramSPEC',program)]:write(A/'RUN'/f'{name}.json',obj)
 core_source_sha=sha((pplug/'references/corpus/SourceManifest.json').read_bytes())
 # Source families are pinned independently; rank is confined to this compile, not cross-domain override.
 families={'F1_FIRST_WORK':{'root':plain(A),'manifest_sha256':srcsha,'files':[{'rel':source.name}]},'F2_ORIGINAL_CORPUS':{'root':plain(pplug),'manifest_sha256':core_source_sha,'files':[{'rel':'references/corpus/SourceManifest.json'}]}}
 authority=pipeline.freeze_authority({'families':families});write(A/'SourceAuthority.json',authority)
 card=pipeline.intake(goal,sources=[plain(source)],constraints=['SOURCE_READ then LOCAL_DRAFT','provider_off=true','exact isolated draft outputs'],non_goals=common['non_goals']);write(A/'IntentCard.json',card)
 profile,profilemeta=pipeline.profile_record('STANDARD',['intent','knowledge','verification','trust_boundary','profile']);write(A/'ProfileBinding.json',profile);write(A/'ProfileDecision.json',profilemeta)
 rawpi=pipeline.compile_pi(card,'STANDARD');pi=pipeline.strip_sidecar(rawpi);write(A/'PI-PKG.json',pi);write(A/'ProfileCompilerSidecar.json',rawpi.get('_profile_meta',{}))
 ack=pipeline.validate_pi(rawpi,schemas);write(E/'PIPD_FUNCTIONAL_PI_READER_ACK.json',ack)
 if ack['verdict']!='PASS':raise ValueError('FIRST_FUNCTIONAL_PI_REJECTED:'+json.dumps(ack,ensure_ascii=False))
 atoms=pipeline.atoms_of(rawpi)
 # Map actual emitted atoms, including any original compiler split, back to complete feature clauses.
 by_cl={}
 for atom in atoms:
  locator=requirements.resolve_source_clause(atom,rawpi['stable_semantic_contract']['sources']);matches=[r for r in trace if r['source_text']==locator['source_text']]
  if len(matches)!=1:raise ValueError('FUNCTIONAL_ATOM_SOURCE_JOIN')
  by_cl[atom['req_id']]={**matches[0],'req_id':atom['req_id'],'source_locator':atom['source_clause'],'oracle':atom['risk_guard']['oracle']}
 if len({r['local_clause'] for r in by_cl.values()})!=len(definitions):raise ValueError('FUNCTIONAL_CLAUSE_LOSS')
 write(A/'FUNCTIONAL_ATOMS_CONSUMERS_POS_NEG.json',list(by_cl.values()))
 # Original strict TaskSpecSeed is a static handoff candidate; never a Canonical HGK TaskSpec.
 outputs=['ProductSPEC.json','ArchitectureSPEC.json','ProgramSPEC.json','SourceReadback.json','FUO.json']
 ts=pipeline._rec('TaskSpecSeed','TSS',None,goal=goal,inputs={'goal':'ordinary caller Goal','KnownAnswer':'same subject/source/scope/question key','source_manifest':{'sha256':core_source_sha,'documents':24},'PI':{'subject_id':pi['subject_id'],'content_hash':pi['content_hash']}},outputs=outputs,constraints={'effects':['SOURCE_READ','LOCAL_DRAFT'],'provider_off':True,'source_roots_read_only':True,'canonical_native_permission':'NONE_GRANTED_BY_THIS_RECORD','write_scope':'RECEIVER_AUTHORIZED_DRAFT_ROOT plus five exact output basenames'},dependencies=['WP-FHS-00 source bytes present','WP-FHS-01 author profile/source decision present'],tests=[{'requirement':r['req_id'],'consumer':r['consumer'],'POS':r['POS'],'NEG':r['NEG']} for r in by_cl.values()],rollback='撤銷本 WorkID 本輪五個 draft preimages；不修改 source、既有 journal 或他人檔案',evidence={'source_sha256':srcsha,'PI_reader_ACK':'03_HANDOFF_EVIDENCE/PIPD_FUNCTIONAL_PI_READER_ACK.json','Native':'NATIVE_NOT_RUN','checker':'NOT_RUN'})
 wo=pipeline._rec('WorkOrderCandidate','WOC',None,candidate_only=True)
 handoff=pipeline._rec('ExecutionHandoff','EH',None,receiver='original HGK SharedSpine TaskSpec/WorkOrder admission then original Hermes',abi_version='PIPD-S0-CONTRACT-REGISTRY/1',payload_refs=[{'contract':'PI-PKG','subject_id':pi['subject_id'],'content_hash':pi['content_hash']},{'contract':'TaskSpecSeed','subject_id':ts['subject_id'],'content_hash':ts['content_hash']},{'contract':'WorkOrderCandidate','subject_id':wo['subject_id'],'content_hash':wo['content_hash']}],ack_nack_state='AUTHOR_STATIC_READER_ACCEPTED_NOT_NATIVE_SUBMITTED')
 write(A/'TaskSpecSeed.json',ts);write(A/'WorkOrderCandidate.json',wo);write(A/'ExecutionHandoff.json',handoff)
 bundle={'PI-PKG':pi,'TaskSpecSeed':ts,'WorkOrderCandidate':wo,'ExecutionHandoff':handoff,'ProfileBinding':profile}
 ack2=validate.validate_bundle(bundle,schemas,pipeline.frozen_validation_context(rawpi));write(E/'PIPD_HANDOFF_RECORDS_READER_ACK.json',ack2)
 if ack2['verdict']!='PASS':raise ValueError('TASKSPEC_HANDOFF_READER_NACK:'+json.dumps(ack2,ensure_ascii=False))
 # Reuse original receipt-free TQAEP planning with dedicated feature fixtures.
 planatoms=[]
 for rid,r in by_cl.items():
  pos=f'fixtures/{rid}_POS.json';neg=f'fixtures/{rid}_NEG.json';write(A/pos,{'req_id':rid,'consumer':r['consumer'],'expected':r['POS'],'execution':'PLANNED_NOT_NATIVE_RUN'});write(A/neg,{'req_id':rid,'consumer':r['consumer'],'mutation':r['NEG'],'execution':'PLANNED_NOT_NATIVE_RUN'});planatoms.append({'req_id':rid,'source_ref':r['source_locator']['source_ref'],'oracle_ref':r['oracle']['id'],'positive_fixture':pos,'negative_fixture':neg})
 plan=core.planned_tqaep(pi['content_hash'],planatoms);write(A/'PlannedTQAEP.json',plan)
 # The first-work UX report explicitly fills every required field from this actual author run.
 ledger=core.QuestionLedger();ledger.record('ordinary_goal',pi['subject_id'],'WP-FHS-15',srcsha,answer=goal);known=ledger.inspect('ordinary_goal',pi['subject_id'],'WP-FHS-15',srcsha);write(A/'KnownAnswerReadback.json',known)
 fuo={'persona':product['persona'],'clean_start':False,'source_sha':srcsha,'selected_path':'WP-FHS-00→WP-FHS-01 / WP-FHS-15→original PIPD compile','first_useful_output':'RUN/ProductSPEC.json','elapsed_ms':round((time.perf_counter()-tick)*1000,3),'questions_reasked':int(known['ask']),'error_count':0,'provider_off':True,'consumer_acceptance':{'reader':'original PIPD pipeline.validate_pi + validate_bundle','verdict':ack2['verdict'],'native':'NATIVE_NOT_RUN'}}
 write(A/'RUN/FUO.json',fuo);write(A/'RUN/SourceReadback.json',{'corpus_source_sha':core_source_sha,'documents':len(mf['files']),'bound_clauses':source_refs,'source_files_mutated':0})
 write(E/'TPM_PLUGIN_USAGE.json',{'plugin':'sbl-tpm-sp','source':str(PLUGIN),'copied_readers':'03_HANDOFF_EVIDENCE/READERS/sbl-tpm-sp','invoked':['corpus_manifest','read_clause','plan_spec Product','plan_spec Architecture','plan_spec Program','QuestionLedger','planned_tqaep'],'verified':'AUTHOR_STATIC_FUNCTIONAL_READER_ONLY','host_loaded':'NOT_CLAIMED','ghp01':'LOCAL_ONLY per user scope; remote read/release not requested'})
 write(A/'PD_LATE_BIND_RECEIVER_CONTRACT.json',{'kind':'AUTHOR_RECEIVER_INSTRUCTIONS_NOT_A_NEW_NATIVE_SCHEMA','first_work':'WP-FHS-15','PI':{'subject_id':pi['subject_id'],'content_hash':pi['content_hash']},'taskspec_seed':ts['subject_id'],'producer':'PIPD original pipeline.bind_pd','consumer':'original PIPD PD Reader then HGK SharedSpine adapter','actual_input_signature':'bind_pd(pi, repo_context={root,writable_scope,...observed claims})','receiver_actions':['Resolve the actual receiver-authorized isolated draft root; no source-root mutation','Probe actual HEAD/index/untracked/root identity immediately before PD binding; compare actual source pins','Choose finite five-output WriteSet contained in the authorized root; never pass ** or a foreign root','Bind actual source/profile/PI identity; call original bind_pd; validate actual PD-PKG using pinned registry','Translate TaskSpecSeed to native_admission.taskspec_request without creating Canonical state in this author run','Original HGK resolves requirement frozen identity then create_taskspec/create_workorder under its own protected admission','Use returned real WorkID in original Hermes Queue/Lease/Journal; never substitute candidate subject ID as real WorkID'],'optional_PD_now':False,'why_PD_not_live_now':'Real executor worktree/root/principal/HEAD are measured by the receiver at construction; no fake live RepoContext is serialized here','SOURCE_READ_LOCAL_DRAFT':'No live effect Permit predecessor; original Canonical admission is separate when actually creating native TaskSpec/WorkOrder','effect_split':{'REPO_WRITE':'DEV ECP + exact root/write set + original HGK admission before mutation','HOST_OP':'independent OPS ECP + original Host Owner/Issuer','USER_OP':'user consent scope + original User receiver','REMOTE_WRITE':'original remote principal and remote ECP','RELEASE':'original Publisher + protected checker'} ,'resume_key':['real WorkID','subject','source_sha','scope','policy_epoch','operation_id','lease_generation'],'UNKNOWN':'PARK affected operation; original World Reconcile; no blind resend','ProviderOff':'Explicit true for this first-work deterministic path; raw legacy ON/OFF never mapped to call permission'})
 write(E/'FIRST_WORK_BUILD_RESULT.json',{'first_work':'WP-FHS-15','functional_source_clauses':len(definitions),'compiled_atoms':len(atoms),'PI_reader':ack['verdict'],'strict_handoff_records_reader':ack2['verdict'],'three_SPEC_files':3,'KnownAnswer_reasked':int(known['ask']),'Native':'NATIVE_NOT_RUN','Release':'NOT_RUN','native_workorder_created':False})
 print(json.dumps(read(E/'FIRST_WORK_BUILD_RESULT.json'),ensure_ascii=False))
if __name__=='__main__':main()
