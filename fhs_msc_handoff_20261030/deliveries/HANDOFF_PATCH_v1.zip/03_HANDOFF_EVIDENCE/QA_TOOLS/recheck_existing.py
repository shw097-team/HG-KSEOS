from prepare import *
import unittest,io,time,platform
def main():
 old=read(E/'MINIMAL_STATIC_TESTS.json');write(E/'MINIMAL_STATIC_TESTS_INITIAL.json',old)
 shutil.copy2(E/'EXISTING_AFFECTED_TESTS_RAW.txt',E/'EXISTING_AFFECTED_TESTS_INITIAL_RAW.txt')
 pins=read(E/'TOUCHED_SOURCE_PINS.json')
 for name in ['REQ-COMPOUND','REQ-NEGATION','REQ-SAME-KEYWORD','REQ-NO-KEYWORD','REQ-COLLAPSED-KEYWORD']:
  p=ROOT/'PIPD/fixtures'/name/'source.txt';target=E/'READERS/PIPD/fixtures'/name/'source.txt';target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(p.read_bytes());pins.append({'domain':'PIPD','source':str(p),'snapshot':target.relative_to(DEST).as_posix(),'sha256':sha(p.read_bytes())})
 write(E/'TOUCHED_SOURCE_PINS.json',pins)
 sys.path.insert(0,plain(E/'READERS/PIPD'));sys.path.insert(0,plain(E/'READERS/PIPD/src'))
 names=['tests.test_atomic_requirements.ClauseBoundCompiler.test_every_atom_traces_orphan_free','tests.test_atomic_requirements.ClauseBoundCompiler.test_normative_claim_without_source_is_refused','tests.test_atomic_requirements.ClauseBoundCompiler.test_semantic_collapse_is_refused','tests.test_negative_and_rollback.TestNegative.test_workorder_candidate_must_be_candidate_only','tests.test_negative_and_rollback.TestNegative.test_execution_binding_ack_requires_receiver_binding']
 buf=io.StringIO();result=unittest.TextTestRunner(stream=buf,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromNames(names));textfile(E/'EXISTING_AFFECTED_TESTS_RAW.txt',buf.getvalue())
 for r in old['tests']:
  if r['case']=='EXISTING_5_AFFECTED_TESTS':r.update(status='PASS' if result.wasSuccessful() else 'FAIL',actual=result.wasSuccessful(),repair='test import search path fixed; five exact original fixture source files copied without edits; no original test changed')
 old['pass']=sum(r['status']=='PASS' for r in old['tests']);old['fail']=sum(r['status']=='FAIL' for r in old['tests']);old['affected_recheck']='EXISTING_AFFECTED_TESTS_RAW.txt';write(E/'MINIMAL_STATIC_TESTS.json',old)
 print(json.dumps({'original_tests':result.testsRun,'pass':result.wasSuccessful(),'current_static_pass':old['pass'],'current_static_fail':old['fail']},ensure_ascii=False));return 0 if result.wasSuccessful() else 1
if __name__=='__main__':sys.exit(main())
