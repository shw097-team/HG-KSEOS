from prepare import *
import re,ast
def main():
 result=read(E/'FIRST_WORK_BUILD_RESULT.json');tests=read(E/'MINIMAL_STATIC_TESTS.json')
 if result['PI_reader']!='PASS' or tests['fail']:raise ValueError('FIRST_WORK_NOT_STATIC_ACCEPTED')
 B=DEST/'01_SUBSTANTIVE_BODY';mapping=read(E/'CURRENT_READER_MAP.json');sourcepins=read(E/'TOUCHED_SOURCE_PINS.json')
 # Pin the original runtime surfaces; never import or start this installed runtime.
 cfg=read(ROOT/'HG-KSEOS/config/hermes.json');runtime=Path(cfg['install_root']);runtime_facts=[]
 for rel in ['hermes_cli/kanban_db.py','hermes_cli/kanban_db_dispatch.py','hermes_cli/kanban_db_connect.py']:
  p=long(runtime/rel);b=p.read_bytes();target=E/'READERS/Hermes'/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b)
  tree=ast.parse(b.decode('utf-8-sig'));symbols=[{'name':n.name,'line':n.lineno,'args':ast.unparse(n.args)} for n in tree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name in ['create_task','get_task','claim_task','claim_review_task','complete_task']]
  runtime_facts.append({'path':plain(p),'sha256':sha(b),'functions':symbols,'loaded':'NOT_OBSERVED_NO_RUNTIME_CALL'})
  sourcepins.append({'domain':'Hermes original installed source','source':plain(p),'snapshot':target.relative_to(DEST).as_posix(),'sha256':sha(b)})
 write(E/'HERMES_ORIGINAL_RUNTIME_SOURCE_BINDINGS.json',runtime_facts);write(E/'TOUCHED_SOURCE_PINS.json',sourcepins)
 # Each functional clause gets a real file/SHA/line or current Reader anchor, not a guessed locator.
 traces=read(A/'FUNCTIONAL_SOURCE_TRACE.json');mf=read(E/'READERS/sbl-tpm-sp/references/corpus/SourceManifest.json');sbl4=next(r for r in mf['files'] if r['source_id']=='SBL-04');stages=read(E/'READERS/sbl-tpm-sp/references/contracts/stage-contracts.json')['contracts']
 for tr in traces:
  locator=tr['original_locator'];bindings=[]
  stage=next((c for c in stages if c['id'] in locator),None)
  if stage:bindings.append({'path':sbl4['path'],'sha256':sbl4['sha256'],'line_from':stage['source_ref']['line'],'line_to':stage['source_ref']['line'],'domain_owner':'SBL DOC04 original writer','state':'DESIGN_STAGE_PROJECTION_NOT_FORMAL_STATE_TRANSITION'})
  if not bindings:
   if 'K0' in locator or 'K3' in locator:book='02_PIPD_LIFECYCLE_AND_TPM.md';needle='K0' if 'K0' in locator else 'K3'
   elif 'PIPD' in locator:book='02_PIPD_LIFECYCLE_AND_TPM.md';needle='19 Canonical'
   elif 'BODY03' in locator:book='03_ARCHITECTURE_ABI_AND_EFFECT.md';needle='R2-03-EFFECT'
   elif 'BODY06' in locator:book='06_FHS_EXECUTE_HERMES_RUNTIME.md';needle='UNKNOWN'
   elif 'BODY07' in locator:book='07_ACCEPTANCE_CHALLENGE.md';needle='Protected'
   else:book='11_WORKPACKAGES_AND_DAG.md';needle='### WP-FHS-15'
   p=BASE/'01_SUBSTANTIVE_BODY'/book;ls=p.read_text(encoding='utf-8').splitlines();hits=[i for i,x in enumerate(ls,1) if needle in x]
   if not hits:hits=[1]
   bindings.append({'path':'BASELINE_STATIC-REPAIR-v1/01_SUBSTANTIVE_BODY/'+book,'sha256':sha(p.read_bytes()),'line_from':hits[0],'line_to':min(hits[0]+12,len(ls)),'domain_owner':'FHS design reader, original Domain writer unchanged','state':'SOURCE_BOUND_DESIGN_BASIS'})
  tr['source_bindings']=bindings
 write(A/'FUNCTIONAL_SOURCE_TRACE.json',traces)
 atomtrace=read(A/'FUNCTIONAL_ATOMS_CONSUMERS_POS_NEG.json')
 for r in atomtrace:r['source_bindings']=next(t['source_bindings'] for t in traces if t['local_clause']==r['local_clause'])
 write(A/'FUNCTIONAL_ATOMS_CONSUMERS_POS_NEG.json',atomtrace)
 pi=read(A/'PI-PKG.json');ts=read(A/'TaskSpecSeed.json')
 changes=[]
 def insert(book,title,body,own_anchor=None):
  p=B/book;old=p.read_text(encoding='utf-8');block='\n\n'+title+'\n\n'+body.strip()+'\n'
  if own_anchor:
   at=old.index(f'<a id="{own_anchor}"></a>');pos=old.index('\n',old.index('\n',at)+1)+1;new=old[:pos]+block+old[pos:]
  else:
   # Place the concrete current repair before older design text, inside this same book.
   m=re.search(r'^## ',old,re.M);pos=m.start() if m else len(old);new=old[:pos]+block+'\n'+old[pos:]
  textfile(p,new);changes.append({'book':book,'source_sha256':sha((BASE/'01_SUBSTANTIVE_BODY'/book).read_bytes()),'patched_sha256':sha(p.read_bytes()),'operation':'INSERT_IN_CURRENT_READER_BEFORE_PRIOR_DESIGN','preserved_prior_bytes_as_subsequence':old in new or all(part in new for part in [old[:pos],old[pos:]])})
 scope='''本輪有效完成目標只有 `PIPD_CONSTRUCTION_HANDOFF_READY`。首工作為原 `WP-FHS-15`，業務成果為普通 Goal→來源/KnownAnswer 約束的三 SPEC→原 PIPD 功能 PI→TaskSpecSeed 與 PD 晚綁接收契約。此首工作的入口與本文第一受影契約在原書原位生效；不把未完成的全部產品要求當成本輪先決條件。

前版 `REPAIR_INCOMPLETE / SBL-D00-L00070-C01 / 7649` 保留為全產品語義修補差額。本輪不宣稱全產品已完成，也不把該差額改標外部 HOLD；其中對首工作有用的 FUO 十欄已在 `02_FIRST_WORK/RUN/FUO.json` 具體填列。其餘原 ID、承諾、負例與原 WP 的施工/驗收義務完整保留。

`SOURCE_READ/LOCAL_DRAFT` 可以現在合法開始；即時 Host Loaded、Native Permit、World Raw、不同 Principal Checker 只在對應原生效果/驗收階段要求，不反向作為本輪 Spec/PI 的輸入。包內 Worker/WorkOrderCandidate 是接收候選，不是已准入 WorkID。'''
 insert('00_INDEX_AND_DECISION.md','## HANDOFF-v1｜當期施工交接裁決與唯一首工作',scope)
 insert('02_PIPD_LIFECYCLE_AND_TPM.md','## HANDOFF-v1｜首工作功能 PI 的真 Compiler 接收',f'''**普通 Goal**：為一個普通工程需求讀取已內建的 SBL14/PIPD10 與已知答案，產出三 SPEC 到受權隔離草稿區，ProviderOff=true，再交原 PIPD。使用者不須重貼 B1 長 Prompt 或重新上傳24 DOC。

**可直接讀取的實例**：`02_FIRST_WORK/RUN/ProductSPEC.json`、`ArchitectureSPEC.json`、`ProgramSPEC.json` 由原 sbl-tpm-sp `plan_spec` 實際產生；`SourceAuthority.json` 由原 PIPD `freeze_authority` 產生，SourceFamily digest/locator 逐檔釘住；`IntentCard.json` 由原 `intake` 讀 `FIRST_WORK_FUNCTIONAL_SOURCE.md` 24條業務功能；`ProfileBinding.json` 與 Compiler 的有效 Profile 使用原九軸安全 veto，沒有將十二風險分數塞成九軸 enum。

**原 Compiler 輸出**：PI=`{pi['subject_id']}`，hash=`{pi['content_hash']}`。原 `pipeline.validate_pi` 驗 PI、ProfileBinding、24個 RequirementAtom、24條 TraceLink，回覆 PASS；另對 strict TaskSpecSeed/ExecutionHandoff/WorkOrderCandidate 驗 Schema與 frozen context回覆 PASS。每 Atom 的專屬 Consumer、POS、NEG、原 Source coordinate 在 `FUNCTIONAL_ATOMS_CONSUMERS_POS_NEG.json`，不是只有 ID/FirstFail 的投影。

**晚綁界線**：TaskSpecSeed=`{ts['subject_id']}` 交原 receiver adapter；`PD_LATE_BIND_RECEIVER_CONTRACT.json` 明列原 `pipeline.bind_pd(pi, repo_context)` 的實際入參、有限 WriteSet、實測 root/HEAD/index/untracked 與 freshness。交接時不序列化假 live PD；已另以實際存在的隔離 document fixture 驗真 PD binder 的 POS、缺 root、stale freshness、`**` 拒收。該 fixture PD 不是施工工作樹，不拿其 PREDEV_READY 當 Native Ready。

**不構成阻斷的舊差異**：全17冊直接 intake 的舊 NACK 不適用這24條已接收的必要閉包。CLI13/14 差異只隔離新增 compile-cc 本身，本首工作使用兩版共有的 intake/profile/compile-pi/bind-pd/validate Reader。PI legacy `DOC-03 DOMAIN_ORACLES` 依原 Schema 原字保留；DOC07為 semantic Owner 的正式 ratification 只在原 Protected Checker/Native promotion消費時受影，不改 strict payload、不阻斷本輪 source/draft/PI規劃。T4/T5 的正式 StateEnum 未被草稿產生改寫。''')
 insert('03_ARCHITECTURE_ABI_AND_EFFECT.md','## HANDOFF-v1｜首工作 Effect、Scope 與原生准入分流','''| 階段 | Producer → 原 ABI/Reader → Consumer | 現在可做／效果前條件 |
|---|---|---|
| source | 原 Goal/KnownAnswer→TPM corpus Reader→三 SPEC draft | 只讀 admitted corpus；核 SHA；不索 Native Permit |
| draft | 原 TPM `plan_spec`→三 SPECDraft→原 PIPD Intake | 只寫 receiver-authorized isolated draft root 下五個精確檔名；無正式庫寫入 |
| PI/TaskSpecSeed | 原 PIPD Compiler→19 Schema/frozen Reader→receiver adapter | strict payload與非 record sidecar 分離；本輪 static ACK有效於接收；不是原 HGK Canonical TaskSpec |
| Canonical admission | 原 adapter→`native_admission.taskspec_request/workorder_request`→`SharedSpine.create_taskspec/create_workorder` | 原 HGK自行解析 frozen Requirement及真 target identity、principal、scope、HEAD；其 transaction內原 admission 保留，不在作者端呼叫 |
| effect | 原已准入 WorkOrder→Hermes bounded worker→原 Effect Receiver | RepoWrite用 DEV ECP；HostOp用獨立 OPS；UserOp用使用者 scope；RemoteWrite與Release分開原有權 Receiver/Issuer；缺哪一類只 PARK該效果 |

原 TaskSpec/WorkOrder 的建立本身屬 Canonical state mutation，仍走原 HGK受保護准入。這與「讀來源／做本地草稿不必先有 Native effect Permit」是兩條界線，不可互相冒用。原五檔 WriteSet=`ProductSPEC.json, ArchitectureSPEC.json, ProgramSPEC.json, SourceReadback.json, FUO.json`；基準目錄由接收端在施工時晚綁並核 canonical path/preimage，禁止`**`、junction/escape或 source root。尚未配置的 runtime目錄是合法晚綁輸入，並非重複向 Owner索本輪已授的文稿權限。''')
 insert('04_FABRIC_HGK_CONTROL.md','## HANDOFF-v1｜對齊現役 Fabric／HGK 接收面','''Fabric 現役 `FABRIC/fabric/consumers/hgk_policy_consumer.py::route_event` 與 `RP002_CHANGE_CLASS_ROUTER.yaml` 的 source SHA 已釘住。`RUNTIME_TRANSIENT→HERMES_NATIVE` 只用於原 runtime 之 session/heartbeat/scratch等事件，不能拿這個 change class 把任意 RepoWrite、Profile或Pipeline變更洗成無效果。

HGK現役 `src/hg_kseos/native_admission.py::taskspec_request/workorder_request` 的純 request constructor 已用靜態 fixture實際接收本首工作的欄位映射；foreign worktree以`ERR_NATIVE_TASKSPEC_ROOT`拒收。本輪沒有呼叫`authorize`、`create_taskspec`、`create_workorder`或任何 signing/issuer。真實 RequirementID、TaskSpecID、WorkOrderID由原 Canonical admission在原 Owner scope解析/配置；candidate subject ID不能代替真 WorkID。

若真正進入 OPS才缺 grant，原 DAG的受影後代 PARK；`WP00/01/05/15` 仍可 source/draft/compile。原插件 `affected_work` 實測結果在 `OPS_PARK_AFFECTED_CONE.json`。不增設第二 policy、issuer、queue或state DB，不以 elapsed time或既有文件封裝當 receipt。''')
 insert('05_COMMANDER_GUIDE_AND_NATIVE_PLAN.md','## HANDOFF-v1｜Hermes 普通 Goal 自主續工入口','''接收端先讀交付根 `HANDOFF_README.md` 與 `02_FIRST_WORK/TaskSpecSeed.json`，驗 `CURRENT_READER_SCOPE.json` 與 SHA Manifest，沿原 TPM/PIPD/PLAN接收這句普通 Goal：「依 WP-FHS-15 讀既有來源和已知答案，於允許隔離草稿區產生三 SPEC；ProviderOff=true；只作 SOURCE_READ/LOCAL_DRAFT。」不要求使用者再貼 B1 長 Prompt、重問已知授權或等待全7649子項完成。

KnownAnswer key綁 subject/source_sha/scope/question，未過期即重用；本輪實測重問=0。來源改變只 invalidate依賴它的 SPEC/PI，其他 READY繼續。PLANNED TQAEP 不索尚不存在的 live checker receipt；傳給下游的每個功能 Atom都有自己的 Consumer、POS/NEG，不用上輪44條身份投影取代。

接到合法原 HGK Canonical WorkOrder後，Hermes將其真 WorkID與原 Hermes task_id作受權關聯記錄，沿既有 Queue/Lease/Journal繼續；原 TaskSpec/WO constructor不會替你創造可用 Permit，亦不宣稱 create_workorder 的 Python回傳值就是 WorkID。原 Canonical readback才證明該 WorkID存在。''')
 insert('06_FHS_EXECUTE_HERMES_RUNTIME.md','## HANDOFF-v1｜原 WorkID、Lease、Journal、UNKNOWN 與復原','''1. **原接線**：Goal→原 TPM/PIPD/PLAN→原 Fabric/HGK admission→原 Hermes Queue/Lease/Journal→bounded Worker→原世界狀態 Reader→不同 Principal Protected Checker→原 Delivery/Publisher。安裝目錄的 `hermes_cli/kanban_db.py` 中 `create_task/get_task/claim_task/complete_task` 及相鄰dispatch/connect來源已唯讀釘SHA；這不是新Queue或已載入證據。
2. **同 WorkID續工**：沿原Canonical WorkID及Hermes task_id關聯、Subject/SourceSHA/Scope/PolicyEpoch/operation_id/checkpoint重讀，不新建另一工作掩蓋失敗。不重執行已完成且同key的寫入。
3. **Lease fence**：原 SharedSpine `_assert_lease` 先驗 holder/token/expiry；fixture當期lease接受、舊lease回 `ERR_LEASE_EXPIRED`。原native admission另檢generation/CAS；worker在真正 effect前重讀原lease代數，不能用作者端fixture代替有效lease。
4. **At-most-once／UNKNOWN**：同 operation_id已確認有effect只續驗證；已確認無effect才由原Owner policy決定重送；UNKNOWN/PARTIAL只PARK該operation進原World Reconcile/補償，絕不盲retry。原 `core.effect_route` 靜態實測UNKNOWN→RECONCILE_BEFORE_RETRY。HGK一般`recovery.restore_database`沒有operation_id，不能當成此工作effect journal/reconcile替代；這個能力差額只影響後續真effect，不阻斷無效果首工作。
5. **ProviderOff與lane**：本首工作explicit ProviderOff=true，可用原deterministic reader/Compiler完全完成；沒有從legacy ON/OFF推出外呼布林。若需要provider而PolicyOff，拒收該capability，不私換provider。未來有三lane時`required/selected/actual_served`逐一回讀；作者端選型/fixture不充served。
6. **退出／回復**：source drift→停受影輸出並重新讀來源；本地草稿失敗→核本WorkID exact preimage/部分檔，不刪他人內容；UNKNOWN→保留Journal/residue，原Owner受權補償；Checker不足→只不發Independent/Release。首工作的read/draft/PI不等這些後續receipt。''')
 wr=next(r for r in mapping if r['group']=='WorkPackage' and r['id']=='WP-FHS-15')
 insert('11_WORKPACKAGES_AND_DAG.md','#### HANDOFF-v1 首工作有效接收契約','''- **真功能與Input**：普通Goal、live KnownAnswer、內建24 DOC bytes/SHA → 原 corpus/QuestionLedger/三SPEC draft Reader；不是只保留ID/FirstFail。
- **Output**：原三SPECDraft、來源readback、FUO十欄；24功能Atom的原PI、TaskSpecSeed與PD晚綁契約已存在，PIPD Reader ACK可讀回。
- **合法起點／DAG**：WP00 source snapshot；WP01 source/profile author decision；WP15只依賴WP00既有讀入。WP05.prepare是原Compiler服務，消費已存在的設計SPEC，不等待WP15未來的Native完成Receipt。原22 WP edges不改，無bootstrap循環。
- **Producer→Schema→Consumer**：原 TPM `plan_spec`→Product/Architecture/ProgramSPECDraft→原PIPD `intake/compile_pi/validate_pi`→原TaskSpecSeed/ExecutionHandoff→HGK原adapter→原Hermes。
- **Effect／Scope／Admission**：SOURCE_READ + LOCAL_DRAFT；只在receiver-authorized root寫五個精確檔。此階段不索Live Permit。若後續需要Repo/Host/User/Remote/Release則各原ECP/Issuer在effect前准入，不能混用。
- **POS／NEG／Done**：24功能源句/24Atom、全部原trace與strict Reader PASS、三SPEC可讀且KnownAnswer零重問；空goal、source drift、foreign root、漏NEG/雙writer、cycle、stale PD/lease、ProviderOff外呼、UNKNOWN盲重送均受影拒收或Reconcile。只說明靜態接收，Native/Checker/Release仍NOT_RUN。
- **Evidence／Rollback／Resume**：`03_HANDOFF_EVIDENCE/MINIMAL_STATIC_TESTS.json`、真Compiler ACK與pure request constructor讀回；撤本WorkID草稿的exact preimage，不改來源；sameSource/key重用，source drift只失效受影錐，真effectUNKNOWN先原reconcile，沿原WorkID續行。
- **餘項分派**：全部7649量詞候選、485技術、282Runner/W18等產品義務留在原WP與適用驗收，未完成不在本輪灌PASS，也不成為此首工作的無關global HOLD。''',wr['anchor'])
 insert('12_VERIFICATION_AND_DELIVERY.md','## HANDOFF-v1｜最小交接靜態驗收與 ClaimCeiling','''交付前只驗首工作必要閉包：原 Compiler/Reader真功能PI與TaskSpecSeed；原22WP圖無環/無futureReceipt前置；缺OPS僅PARK受影分支；source漂移、ProviderOff、舊Lease、UNKNOWN的原Reader/接收契約拒收或Reconcile。原5個受影測試重用，環境搜尋路徑與必需fixture修正後通過；本輪最小檢查35 PASS。所有命令、環境、exit、stdout/stderr/SHA保存於新證據，沒有重跑無關全庫測試。

一次輕量全局一致性回歸核完整17冊/14SBL升級冊、2221原ID唯一Locator、原負例與未受影內容保留、來源/Reader SHA、原DAG、Schema、relative links、原工作樹未改，最後兩ZIP各只正式封裝一次並逐檔讀回。成功只標`PIPD_CONSTRUCTION_HANDOFF_READY`，不得讀為NATIVE_ADMITTED、NATIVE_VERIFIED、INDEPENDENT_PASS或RELEASED。''')
 # The remaining obligations stay assigned to the original work packages instead of disappearing.
 remainder={'R15_949':'WP-FHS-20 product/Kind/Host scope + original per-ID Owner','Child149':'WP-FHS-15 SPEC feature acceptance in affected source scope','Cell192':'WP-FHS-20 own Host/Mode/raw token','Native20_Default30_Tech386':'WP-FHS-17 capability bootstrap then WP-FHS-13 qualified hotswap only when needed','Donor24_Method25':'WP-FHS-16 source translation; WP-FHS-13 only where invoked','B1_PI27_PD31_Case282':'WP-FHS-10 original three GWO and per-case Protected Reader','AC15_Oracle96':'WP-FHS-21 plan then WP-FHS-09 protected checker','W18':'WP-FHS-12 fresh ordinary Goal qualification','SBL_compounds7649':'WP-FHS-15/16 source-dependent author repair; downstream WP20/21 own original acceptance; original source and negatives retained','release':'WP-FHS-14 original Publisher only'}
 write(A/'REMAINING_REQUIREMENTS_ORIGINAL_WP_ASSIGNMENT.json',remainder)
 # Residual blockers are effect-specific, not a new global planning gate.
 gaps=[{'id':'R1_SOURCE_AUTHORITY','classification':'SOURCE_RESOLVABLE','state':'RESOLVED_FOR_FIRST_WORK','binding':'24DOC original hashes + functional clause trace + SourceAuthority','affected':['WP00','WP01','WP15']}, {'id':'R2_PIPD_READER','classification':'REPO_BINDABLE','state':'BOUND_STATIC','binding':'Agent_Workspace/PIPD HEAD pinned; original APIs plus strict 19 schemas; 24 functional atoms accepted','affected':['WP15→WP05.prepare→TaskSpecSeed']}, {'id':'R3_TASKSPEC_HGK_SEAM','classification':'REPO_BINDABLE','state':'BOUND_STATIC_CONSTRUCTOR_SIGNATURE','binding':'native_admission.taskspec_request/workorder_request static POS/foreign-root NEG; canonical create_* not called','affected':['native canonical admission only']}, {'id':'HOST_PROVIDER_LEGACY_MAP','classification':'OWNER_DECISION_REQUIRED','state':'AFFECTED_LIVE_ONLY','owner':'Original Product/Host/Provider Policy Owner','reader':'原192 Cell/Provider Policy Reader','first_fail':'LEGACY_HOST_PROVIDER_MAPPING_NOT_RATIFIED','affected':['DeepSeek48→ChatGPT migration or provider-dependent cell only'],'next_legal_action':'原Owner用同版本映射決議；ProviderOff首工作仍READY','resume':'同PolicyEpoch/SourceSHA受權映射','blocks_first_work':False}, {'id':'ORACLE_LEGACY_FORMAL','classification':'OWNER_DECISION_REQUIRED','state':'AFFECTED_LIVE_ONLY','owner':'PIPD DOC07 Oracle Owner / installed legacy Schema Owner','reader':'原 Protected Oracle ratification reader','first_fail':'CR_ORACLE_001_NATIVE_RATIFICATION_PENDING','affected':['future Native promotion/protected acceptance, not current draft compile'],'next_legal_action':'原Owner確認DOC07語義與legacy DOC03 serialization；不改本次strict PI','resume':'同subject/sourcehash正式ratification readback','blocks_first_work':False}, {'id':'NATIVE_RECEIPTS','classification':'NATIVE_EVIDENCE_REQUIRED','state':'PENDING_AT_NATIVE_STAGE','owner':'original Fabric/HGK Issuer + Hermes Runtime + Effect Receiver + Protected Checker/Publisher','reader':'各原native Consumer','first_fail':'NATIVE_NOT_RUN','affected':['canonical admission','actual loaded/served','bounded worker/world effect/reconcile','independent acceptance/release'],'next_legal_action':'Hermes接本包，source/draft先行；真Canonical/effect前由各原Owner准入','resume':'same WorkID/subject/source/scope/epoch/operation原readback','blocks_first_work':False}]
 write(E/'GAPS_CLASSIFICATION_AND_RESUME.json',gaps)
 write(E/'AFFECTED_PATCH_LOG.json',changes)
 # Recompute current locators, retaining all original identities and the unchanged ones.
 cache={}
 for r in mapping:
  if r['path'] not in cache:
   p=DEST/r['path'];b=p.read_bytes();cache[r['path']]=(b.decode('utf-8').splitlines(),sha(b))
  ls,dg=cache[r['path']];r['line']=ls.index(f'<a id="{r["anchor"]}"></a>')+1;r['sha256']=dg;r['reader_role']='HANDOFF_v1_SAME_ORIGINAL_ID_SOURCE_BOUND_CURRENT'
 write(E/'CURRENT_READER_MAP.json',mapping)
 textfile(DEST/'CURRENT_READER_SCOPE.json',json.dumps({'current_map':'03_HANDOFF_EVIDENCE/CURRENT_READER_MAP.json','effective_patch':'HANDOFF-v1 blocks inside existing 17 current books','current_first_work':'02_FIRST_WORK/TaskSpecSeed.json','historical_evidence':'02_EVIDENCE_AUDIT_APPENDICES is preserved STATIC-REPAIR-v1 baseline; its SHA maps/claim states are not this round Reader map','native_claims':'NONE'},ensure_ascii=False,indent=2))
 textfile(DEST/'HANDOFF_README.md',f'''# FHS-MSC｜PIPD → Hermes 最小施工交接

**本輪目標：PIPD_CONSTRUCTION_HANDOFF_READY。** 僅表示下列無效果首工作與接收契約已具備作者端靜態接收證據；最後封包讀回記錄另列。Native=NATIVE_NOT_RUN；Independent Checker=NOT_RUN；Release=NOT_RUN。

普通 Goal：「依 WP-FHS-15 讀既有來源和已知答案，於允許的隔離草稿區產生三 SPEC；ProviderOff=true；只作 SOURCE_READ/LOCAL_DRAFT。」

先讀 [首工作接收契約](FIRST_WORK_RECEIVER_CONTRACT.md)，再讀 [TaskSpecSeed](02_FIRST_WORK/TaskSpecSeed.json)、[原 PIPD 功能 PI](02_FIRST_WORK/PI-PKG.json)、[PD 晚綁接收](02_FIRST_WORK/PD_LATE_BIND_RECEIVER_CONTRACT.json)、[原 Reader ACK](03_HANDOFF_EVIDENCE/PIPD_FUNCTIONAL_PI_READER_ACK.json)。三 SPEC真產物在 [Product](02_FIRST_WORK/RUN/ProductSPEC.json)、[Architecture](02_FIRST_WORK/RUN/ArchitectureSPEC.json)、[Program](02_FIRST_WORK/RUN/ProgramSPEC.json)。

首工作：原 WP-FHS-15；24真功能源句→24Atom，不是上輪44條ID/FirstFail投影。原 WP00/01資料讀入與Profile author決定現在可做；原 WP05 Compiler服務無須等待未來WP15 Native receipt。35項最小檢查通過，含5個原受影測試。

Hermes沿原普通Goal/PLAN入口讀取此契約與KnownAnswer；對source/draft不再問已授權文稿問題。真正Canonical WorkOrder或效果前，接原Fabric/HGK受權Receiver；使用原WorkID與Hermes task_id關聯、原Lease/Journal，UNKNOWN先世界Reconcile，不新建Queue或Issuer。需Owner/Native證據者只隔離受影live子圖：[具名差額與恢復條件](03_HANDOFF_EVIDENCE/GAPS_CLASSIFICATION_AND_RESUME.json)。

17冊完整正文與14 SBL升級內容均保留；[有效Reader](03_HANDOFF_EVIDENCE/CURRENT_READER_MAP.json) 原ID不改。7649筆全產品語義修補、485技術資格與282Runner/W18等未宣稱完成，留在原WP：[餘項分派](02_FIRST_WORK/REMAINING_REQUIREMENTS_ORIGINAL_WP_ASSIGNMENT.json)。前版FIRST_AUTHOR_FAILURE仍是全產品差額，不能反向阻斷本輪已接收的必要閉包。

正文與證據ZIP解壓至同一目錄；版本與SHA Manifest位於交付根。全部修補後各封裝一次。''')
 textfile(DEST/'FIRST_WORK_RECEIVER_CONTRACT.md','''# 首工作原接收面契約｜WP-FHS-15

輸入為普通Goal、KnownAnswer、已釘SHA的24 DOC與該首工作SourceAuthority/Profile；輸出是三SPEC、來源readback與FUO十欄、功能PI、TaskSpecSeed/ExecutionHandoff。已生成全部實例，請直接讀`02_FIRST_WORK`。

| 連接 | 真 Producer／ABI／Consumer | 接收及退出條件 |
|---|---|---|
| Goal→SPEC | 原 TPM corpus/QuestionLedger/plan_spec → 三 SPECDraft → PIPD intake | empty goal/缺 source/來源漂移/缺專屬NEG拒收；已有同key答案零重問；僅失效受影輸出 |
| Source/Profile→PI | 原 freeze_authority/profile_record/compile_pi → 原 19-schema PI-PKG/RequirementAtom/TraceLink → validate_pi | 24功能Atom全成員Reader PASS；sidecar不塞strict record；source或atom/trace漂移NACK |
| PI→TaskSpecSeed | 原 PIPD record factory → TaskSpecSeed/ExecutionHandoff → 原 HGK adapter | 不建立Native identity；候選只有接收用途，WorkOrderCandidate固定candidate_only |
| PI→PD | 原 pipeline.bind_pd → 原 PD-PKG → 原施工接收端 | root/HEAD/index/untracked/ACL/有限WriteSet於Receiver真正施工前再測；缺root/stale/**拒收；不預填live PD |
| TaskSpec→Canonical WO | 原 native_admission pure request constructors → 原 SharedSpine.create_taskspec/create_workorder | 純constructor靜態接收已測；原HGK配置實際IDs與frozen Requirement並受保護准入；本輪不呼叫Canonical mutation |
| WO→Hermes | 原Canonical WorkID關聯原Hermes task_id → 原Queue/claim/get_task/Journal | sameWorkID/operation key續工；舊lease先拒；不是從fixture或candidate取真WorkID |
| effect→Delivery | 原boundedWorker→原WorldReadback/Reconcile→ProtectedChecker→原Delivery/Publisher | DEV/OPS/USER/REMOTE/RELEASE各自原准入；UNKNOWN不重送；作者static PASS不是Independent或Release |

五個精確輸出名為ProductSPEC.json、ArchitectureSPEC.json、ProgramSPEC.json、SourceReadback.json、FUO.json。Receiver在受權isolated root下解析exact paths與preimage，Path逃逸/alias或他人檔案拒收；rollback只恢復本工作草稿。若尚無Canonical原生授權，source/draft仍可在已授本地範圍完成，Canonical提交與Native effect停在各原Receiver門前。這個分流避免Bootstrap反轉而沒有削弱原Issuer。

機器可讀的函式簽章、各Owner/Reader、第一失敗與resume條件見PD晚綁契約及差額表；純request fixture使用STATIC-TEST IDs，不是實際TaskSpec/WorkOrder。''')
 textfile(DEST/'INDEX.md','# FHS-MSC HANDOFF-PATCH-v1\n\n請由 [HANDOFF_README](HANDOFF_README.md) 與 [首工作接收契約](FIRST_WORK_RECEIVER_CONTRACT.md) 進入。\n\n'+ '\n'.join(f'- [{p.name}](01_SUBSTANTIVE_BODY/{p.name})' for p in sorted(B.glob('*.md'))))
 for name in ['COVERAGE_REPORT.md','REPAIR_CLOSURE_REPORT.md']:
  original=(BASE/name).read_text(encoding='utf-8');textfile(DEST/name,'# HANDOFF-v1 當期範圍\n\n本輪判定依 HANDOFF_README、首工作真功能PI/TaskSpecSeed ACK與輕量回歸；以下完整保留STATIC-REPAIR-v1全產品差額，不能當成本輪首工作的無關global gate。\n\n'+original)
 textfile(DEST/'VERSION_AND_DELIVERY.md','''# 版本／效力／交付

2026-10-30 / CODEX-HANDOFF-PATCH-v1 / MINIMAL-SUFFICIENT / SOURCE-BOUND。

當期完成目標只為PIPD_CONSTRUCTION_HANDOFF_READY；不是全產品建置/驗收。基線雙ZIP已先驗SHA、31個既有主冊/升級冊逐檔釘住，受影8冊只插入同冊有效契約，其餘原文/原ID/負例保留。未受影冊保持位元組一致。來源只有必要閉包重讀與釘SHA，四庫dirty狀態只讀，無fetch/push/deploy/Native mutation。

正式來源可解者已綁Source/Consumer/Schema；REPO_BINDABLE已接原Compiler與HGK純request signature；Owner/Native差額只列受影live子圖，不索尚不存在的receipt。原四庫、Policy/Issuer/Canonical/Queue/Checker權威不移轉。

最後只做一次輕量全局一致性回歸。正文與證據ZIP各正式封裝一次；逐entry CRC/UTF8/SHA/bytes讀回。解壓至同root；history evidence不是current reader。SHA payload manifest按構造不列自身；外部ZIP/readback manifest亦不列自身，避免自我digest。

Native=NATIVE_NOT_RUN；Independent Checker=NOT_RUN；Release=NOT_RUN。原生Owner於實際效果前再准入，本包不含Permit或正式checker receipt。''')
 print(json.dumps({'patched_books':len(changes),'current_locators':len(mapping),'functional_requirements':24,'Hermes_sources_pinned':len(runtime_facts),'remaining_author_handoff_blocks':0},ensure_ascii=False))
if __name__=='__main__':main()
