from prepare import *
def main():
 sys.path.insert(0,plain(E/'READERS/PIPD/src'));from pipd_ls_sp import pipeline,validate
 pplug=E/'READERS/sbl-tpm-sp';mf=read(pplug/'references/corpus/SourceManifest.json')
 f1={'kind':'AUTHOR_SOURCE_FILE_LIST','domain_writer':'first-work source-bound design; original PIPD Compiler unchanged','root':plain(A),'files':[{'rel':'FIRST_WORK_FUNCTIONAL_SOURCE.md','sha256':sha((A/'FIRST_WORK_FUNCTIONAL_SOURCE.md').read_bytes())}]}
 f2={'kind':'AUTHOR_SOURCE_FILE_LIST','domain_writer':'each original SBL/PIPD DOC Writer','root':plain(pplug),'files':[{'rel':r['path'],'sha256':r['sha256']} for r in mf['files']]}
 families={}
 for key,table in [('F1_FIRST_WORK',f1),('F2_ORIGINAL_CORPUS',f2)]:
  p=A/'SOURCE_FAMILIES'/f'{key}.json';write(p,table);families[key]={'root':table['root'],'manifest_sha256':sha(p.read_bytes()),'files':table['files']}
 authority=pipeline.freeze_authority({'families':families});write(A/'SourceAuthority.json',authority);write(A/'SourceFreezeInput.json',{'families':families})
 pi=read(A/'PI-PKG.json');card=read(A/'IntentCard.json');profile=read(A/'ProfileBinding.json')
 lock={'kind':'AUTHOR_COMPILE_LOCK_NOT_A_NATIVE_AUTHORITY','first_work':'WP-FHS-15','source_families':{k:{'manifest':'SOURCE_FAMILIES/'+k+'.json','manifest_sha256':v['manifest_sha256']} for k,v in families.items()},'intent':{'subject_id':card['subject_id'],'content_hash':card['content_hash']},'source_authority':{'subject_id':authority['freeze']['subject_id'],'content_hash':authority['freeze']['content_hash']},'effective_profile':{'subject_id':profile['subject_id'],'content_hash':profile['content_hash']},'PI':{'subject_id':pi['subject_id'],'content_hash':pi['content_hash']},'source_path_relocation':'Do not hand-edit hashed PI or Source locators. If relocated, rerun the original intake/compile on the same pinned source bytes and preserve original WP15 lineage; receiver revalidates actual Source/RepoContext.','native':'NATIVE_NOT_RUN'}
 write(A/'FIRST_WORK_COMPILE_LOCK.json',lock)
 graph={'WP-FHS-00.read':[],'WP-FHS-01.bind':['WP-FHS-00.read'],'WP-FHS-15.spec-draft':['WP-FHS-00.read'],'WP-FHS-05.prepare':['WP-FHS-01.bind','WP-FHS-15.spec-draft'],'TaskSpecSeed/PD-late-bind':['WP-FHS-05.prepare']}
 write(A/'RECEIVER_ARTIFACT_DEPENDENCY_GRAPH.json',{'graph':graph,'plane':'artifact preparation and receipt-free local draft; not a second task DAG/scheduler','original22WP':'ORIGINAL_22_WP_DAG.json','no_future_execution_receipt_predecessor':True})
 ack={'authority_bindings':[{'source_id':r['source_id'],'findings':validate.validate_record('AuthorityBinding',r,E/'READERS/PIPD/schemas')} for r in authority['bindings']],'effective_profile_equals_PI':profile==pi['stable_semantic_contract']['profile_binding'],'all_family_bytes_verified':all(sha(long(Path(v['root'])/f['rel']).read_bytes())==f['sha256'] for v in families.values() for f in v['files'])}
 write(E/'SOURCE_PROFILE_LOCK_READER_ACK.json',ack)
 if not ack['all_family_bytes_verified'] or not ack['effective_profile_equals_PI'] or any(r['findings'] for r in ack['authority_bindings']):raise ValueError('COMPILE_LOCK_JOIN_FAILED')
 textfile(E/'E01_HANDOFF_SOURCE_AND_READER.md','''# 來源／有效 Reader／續工基線

前版雙ZIP SHA已重算一致；17主冊與14 SBL冊起始 SHA見BASELINE_BOOKS.json。原31冊保留；當期只讀03_HANDOFF_EVIDENCE/CURRENT_READER_MAP.json，舊STATIC-REPAIR-v1各current map只作原版本追溯。

本輪僅重讀首工作所需24 DOC corpus、原Stage clauses、WP15與原8冊接口，及原PIPD/HGK/Fabric/Hermes必要Reader。TOUCHED_SOURCE_PINS.json逐檔列原實際路徑/SourceSHA與交付快照。Functional Source Trace的每條原座標在交付包內有真文件、SHA與行號；未以僅文字別名冒Source locator。F1/F2每家族都另有實體file-list manifest，SourceAuthority使用其實際manifest SHA；rank只供此編譯，不跨Domain取代Writer。

Profile使用原compile_pi內部實際推導的有效Binding；外部ProfileBinding.json與PI內部binding相同，原先precompile axes讀回以歷史候選保留。舊CLI13/14與DOC03/DOC07來源差異不被藏起或強改；只在真正消費新增verb／原生oracle promotion時由原Owner處理，不全域阻擋source/draft。
''')
 textfile(E/'E02_HANDOFF_FUNCTIONAL_COMPILE_AND_TESTS.md','''# 首工作 Compiler／接收鏈與受影測試

WP-FHS-15的24條功能源句經原intake/compile_pi產生24個RequirementAtom；pipeline.validate_pi檢PI、內嵌Profile、全部Atom、全部TraceLink。strict TaskSpecSeed/ExecutionHandoff/WorkOrderCandidate與同一有效Profile再由原validate_bundle及frozen context檢查PASS。這是原Reader的實際靜態接收，非人工改PI身份或Canonical Native ACK。

三SPEC由sbl-tpm-sp原plan_spec實際產生。每功能有獨立Consumer/POS/NEG及PlanFixture；不是上輪44條只保ID的投影。PlannedTQAEP用原receipt-free schema，不捏checker receipt。十欄FUO已具體填列並記KnownAnswer零重問。

最小靜態35 PASS：來源/Schema/Goal/KnownAnswer/三SPEC要求、DAG、OPS受影PARK、Profile安全veto、ProviderOff無外呼、PD晚綁POS/NEG、原HGK純request constructor POS/foreign-root NEG、原SharedSpine舊Lease拒收（僅記憶體fixture）、UNKNOWN先Reconcile及禁止Maker自驗。另重用5個原受影測試；第一次test import path未配置的raw保留，補正隔離測試search path與5個原fixture後通過，未改原測試/Oracle，也沒重跑其他庫測試。

source/draft的NoLiveReceipt與Canonical admission的原受保護條件分開，沒有跳過原Issuer。原Hermes runtime source只有唯讀SHA/函式簽章，沒有載入、queue enqueue或worker。所有fixture/static request ID與PD測試root明列非live。最後另做一次輕量全局一致性回歸，結果見LIGHT_GLOBAL_REGRESSION.json。
''')
 textfile(E/'E03_HANDOFF_PATCHES_HOLDS_AND_CLAIMS.md','''# 受影修補／缺口分類／ClaimCeiling

當期8冊原位插入首工作實際契約與原接收面，沒有縮寫或移除未受影原文。來源可解部分與Repo可綁接面已實際落成：24功能Atom、同一Profile、SourceFreeze、TaskSpecSeed strict Reader、HGK純constructor、Hermes source函式簽章、PD合法晚綁入參/拒收。修補表見AFFECTED_PATCH_LOG.json。

GAPS_CLASSIFICATION_AND_RESUME.json分SOURCE_RESOLVABLE、REPO_BINDABLE、OWNER_DECISION_REQUIRED、NATIVE_EVIDENCE_REQUIRED。前兩類對首工作已Resolved/Bound；後兩類逐項有原Owner/Reader、first fail、受影依賴、next legal action、resume，只影響live promotion/effect/acceptance，不阻斷本首工作。

7649量詞子項等未驗產品要求完整保留、已分派原WP，絕不改稱完成；先前FIRST_AUTHOR_FAILURE是全產品差額，不是本輪已可用24條首工作功能的阻斷。交接就緒不等於Native Admitted/Verified、Independent PASS或Released。真effect/Permit/Host/World/Checker/Publisher均未執行；收據須由各原生Owner於施工時提供。
''')
 print(json.dumps({'source_families':len(families),'family_file_count':sum(len(v['files']) for v in families.values()),'effective_profile_join':ack['effective_profile_equals_PI'],'source_bytes_join':ack['all_family_bytes_verified']},ensure_ascii=False))
if __name__=='__main__':main()
