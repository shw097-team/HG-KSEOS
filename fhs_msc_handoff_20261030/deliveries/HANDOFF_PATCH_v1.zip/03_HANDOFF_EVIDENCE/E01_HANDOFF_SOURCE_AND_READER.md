# 來源／有效 Reader／續工基線

前版雙ZIP SHA已重算一致；17主冊與14 SBL冊起始 SHA見BASELINE_BOOKS.json。原31冊保留；當期只讀03_HANDOFF_EVIDENCE/CURRENT_READER_MAP.json，舊STATIC-REPAIR-v1各current map只作原版本追溯。

本輪僅重讀首工作所需24 DOC corpus、原Stage clauses、WP15與原8冊接口，及原PIPD/HGK/Fabric/Hermes必要Reader。TOUCHED_SOURCE_PINS.json逐檔列原實際路徑/SourceSHA與交付快照。Functional Source Trace的每條原座標在交付包內有真文件、SHA與行號；未以僅文字別名冒Source locator。F1/F2每家族都另有實體file-list manifest，SourceAuthority使用其實際manifest SHA；rank只供此編譯，不跨Domain取代Writer。

Profile使用原compile_pi內部實際推導的有效Binding；外部ProfileBinding.json與PI內部binding相同，原先precompile axes讀回以歷史候選保留。舊CLI13/14與DOC03/DOC07來源差異不被藏起或強改；只在真正消費新增verb／原生oracle promotion時由原Owner處理，不全域阻擋source/draft。
