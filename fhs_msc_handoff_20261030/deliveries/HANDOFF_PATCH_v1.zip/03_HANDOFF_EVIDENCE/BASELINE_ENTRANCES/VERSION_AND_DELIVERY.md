# 版本與交付說明

版本：2026-10-30 / CODEX-STATIC-REPAIR-v1.0 / SOURCE_BOUND / HIGH_RETENTION。

文件任務狀態：**REPAIR_INCOMPLETE**。第一作者端失敗：`AUTHOR_COMPOUND_SUBITEM_CONTRACT_INCOMPLETE / SBL-D00-L00070-C01`。7649筆 SBL 量詞候選仍未全部完成專屬子項施工契約，不能冒全量語義修補完成或把它們改標外部 HOLD。原 full17 Compiler intake NACK 保留；44條有限投影的編譯成功只在該範圍有效。

本輪已修補17主冊候選、保留14 SBL升級冊；恢復29個未受影條文、解析69個來源處置、校正18 Stage及22 WP完整施工欄位、建立2221個原身份的唯一 Current Reader，保留2403個原負例文字欄位。三種SPEC與PlannedTQAEP由已選用 sbl-tpm-sp adapter實際產生；Host仍是HOST_PENDING。

全局回歸執行一次，發現後僅重驗 Locator namespace、原負例位置與strict PI sidecar受影錐；最終13項物理／結構／原Reader檢查PASS，語義完成項FAIL。初始全局失敗與受影重查原始資料均保留。既有原測試：R2 10/10；另一個本地PIPD108/108；Agent_Workspace版本71項中1項CLI13/14失敗。Revision2來源路徑初驗1項失敗，26件以exact SHA定位搬移，3件仍缺；不可宣稱所有來源完全可得。

正文ZIP與證據ZIP全部修補後各正式封裝一次。解壓至同一資料夾；兩ZIP共有的SHA256_PAYLOAD_MANIFEST.json應同bytes。正文ZIP含Index及17+14正文；證據ZIP含獨立Markdown附錄、Raw、原來源追溯及作者端工具。歷史保留原bytes，舊連結/指令不作當期Reader；當期相對連結全部檢查。

SHA256_PAYLOAD_MANIFEST.json列本次封裝前payload，依構造不列自身。SHA256_DELIVERY_MANIFEST.md列兩ZIP及外部readback/入口檔，不列自身。PACKAGE_READBACK.json在封裝後產生，故不置於ZIP中，避免自我指涉。

Native=NATIVE_NOT_RUN；Protected Checker=NOT_RUN；Release=NOT_RUN。沒有修改正式四庫、部署Skill、執行Native Effect、簽Permit或發布Release。使用者指定GitHub憑證只用於四庫唯讀main下載，未記錄值或置入交付物。按REPAIR_INCOMPLETE及封裝讀回完成條件停止。
