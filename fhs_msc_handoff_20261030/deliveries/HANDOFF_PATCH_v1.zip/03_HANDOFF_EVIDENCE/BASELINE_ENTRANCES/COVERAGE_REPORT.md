# 原身份、分母與語義覆蓋

| 集合 | 原資料重算數 |
|---|---|
| Native20 | 20 |
| Default30 | 30 |
| Donor24 | 24 |
| Method25 | 25 |
| TECH386 | 386 |
| R15 | 949 |
| Child | 149 |
| Cell | 192 |
| B1_PI | 27 |
| B1_PD_Edge | 31 |
| B1_Case | 282 |
| AC_Edge | 15 |
| Oracle | 96 |
| WP | 22 |
| MASTER_R15_ROWS | 949 |
| MASTER_R15_ORDINAL_UNIQUE | 949 |

以上集合正交，不能相加成驗收百分比。17 主冊與14 SBL 升級冊現存；[2221 唯一 Current Reader](02_EVIDENCE_AUDIT_APPENDICES/STATIC_REPAIR_v1/CURRENT_READER_LOCATORS_2221.json) 由真實標題與 anchor 重建。保留原八 Kind、三 Mode、四 Host，DeepSeek48 不改名。三 SPEC 已由插件實際 materialize，但僅設計候選。

R2 的 7649 筆量詞候選中，量測 7649 筆 POS 使用同類通用文字，尚未完成全部專屬子項施工契約；第一作者端失敗為 `SBL-D00-L00070-C01`，詳 [第一失敗](02_EVIDENCE_AUDIT_APPENDICES/STATIC_REPAIR_v1/FIRST_AUTHOR_FAILURE.json)。本輪不能宣稱全量語義覆蓋或全量 PI 編譯。原 Negative、原原文與既有可用卡保留，不因未驗收而刪除。
