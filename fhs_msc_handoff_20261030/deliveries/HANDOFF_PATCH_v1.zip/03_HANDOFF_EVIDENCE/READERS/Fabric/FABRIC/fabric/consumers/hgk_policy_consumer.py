# -*- coding: utf-8 -*-
"""
Fabric policy consumer — binds RP-002 governance contracts into the existing
HGK APL (hg_kseos.assurance) as a thin wrapper. Fabric is NOT an actor; this
module is the owning-stack-orchestrator wrapper that CONSUMES the contracts.

Route truth: rp002/RP002_CHANGE_CLASS_ROUTER.yaml (canonical).
Event canaries required by r3 §16 F0:
  RUNTIME_TRANSIENT     -> HERMES_NATIVE
  CONFIG_PREAPPROVED    -> OWNING_STACK_ORCHESTRATOR_APPLY_SMOKE_READBACK
  PROFILE/SKILL/PIPELINE/STACK/PROVIDER -> ORACLE_TO_HGK
  DOMAIN_CHANGE         -> DOMAIN_AUTHORITY_TO_ORACLE_TO_HGK (+domain checker)
  CONSTITUTIONAL_CHANGE -> HUMAN_META_ORACLE
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path

ROUTER_RELPATH = Path("rp002") / "RP002_CHANGE_CLASS_ROUTER.yaml"


def _fabric_root(start: Path | None = None) -> Path:
    """Locate the Fabric root that actually contains ``rp002/RP002_CHANGE_CLASS_ROUTER.yaml``.

    REC07: the previous constant was ``Path(r"C:\\Projects\\Agent_Workspace\\Fabric")``, one level above
    the real root, so ``load_router()`` raised FileNotFoundError on this host and the consumer could
    not read the active policy at all.  A hardcoded absolute path also cannot survive a different
    checkout location.  Walk up from this file, then honour FABRIC_ROOT if an operator overrides it.
    """
    override = os.environ.get("FABRIC_ROOT")
    if override:
        # An explicit override is AUTHORITATIVE: if it does not hold the route file, that is an
        # operator error and must fail closed. Falling through to an ancestor would silently read a
        # different Fabric tree than the one the operator named.
        chosen = Path(override)
        if not (chosen / ROUTER_RELPATH).is_file():
            raise FileNotFoundError(
                f"FABRIC_ROOT={override} does not contain {ROUTER_RELPATH.as_posix()}"
            )
        return chosen
    here = Path(start or __file__).resolve()
    candidates = [here.parent, *here.parents]
    for candidate in candidates:
        if (candidate / ROUTER_RELPATH).is_file():
            return candidate
    raise FileNotFoundError(
        "Fabric root not found: no ancestor of "
        f"{here} (and no FABRIC_ROOT) contains {ROUTER_RELPATH.as_posix()}"
    )


FAB = _fabric_root()


def load_router() -> dict:
    import yaml
    router = yaml.safe_load((FAB / "rp002" / "RP002_CHANGE_CLASS_ROUTER.yaml").read_text(encoding="utf-8"))
    return router["classes"]


def route_event(change_class: str) -> dict:
    """Deterministic routing decision consumed by the owning Stack orchestrator wrapper."""
    router = load_router()
    if change_class not in router:
        return {"verdict": "FAIL_CLOSED", "reason": f"UNKNOWN_CHANGE_CLASS:{change_class}"}
    entry = router[change_class]
    route = entry["route"]
    if route == "HERMES_NATIVE":
        return {"verdict": "ROUTE_OK", "route": route, "consumer": "hermes-native", "oracle_required": False}
    if route in ("ORACLE_TO_HGK", "ORACLE_TO_HGK_QUALIFICATION_ONLY"):
        return {"verdict": "ROUTE_OK", "route": route,
                "consumer": "oracle-commander->hgk", "oracle_required": True,
                "pack": entry.get("pack", "")}
    if route == "OWNING_STACK_ORCHESTRATOR_APPLY_SMOKE_READBACK":
        return {"verdict": "ROUTE_OK", "route": route,
                "consumer": "owning-stack-orchestrator", "precondition": entry.get("precondition", "")}
    if route == "DOMAIN_AUTHORITY_TO_ORACLE_TO_HGK":
        return {"verdict": "ROUTE_OK", "route": route,
                "consumer": "domain-owner->oracle->hgk", "domain_checker_required": entry.get("requires_domain_checker", False)}
    if route == "HUMAN_META_ORACLE":
        return {"verdict": "ROUTE_OK", "route": route, "consumer": "human/meta-oracle", "auto_promotion": False}
    return {"verdict": "FAIL_CLOSED", "reason": f"UNROUTED:{route}"}


def apply_preapproved(config_path) -> dict:
    """Inspect a configuration snapshot. This function performs no apply/load.

    A real owning-stack activation and consumer ACK require their native route;
    a local hash must never satisfy that effectful acceptance condition.
    """
    import yaml
    config_path = config_path if isinstance(config_path, Path) else Path(config_path)
    raw = config_path.read_bytes()
    class UniqueLoader(yaml.SafeLoader):
        def construct_mapping(self, node, deep=False):
            mapping = {}
            for key_node, value_node in node.value:
                key = self.construct_object(key_node, deep=deep)
                if key in mapping:
                    raise ValueError('DUPLICATE_CONFIG_KEY')
                mapping[key] = self.construct_object(value_node, deep=deep)
            return mapping
    try:
        config = yaml.load(raw.decode('utf-8'), Loader=UniqueLoader)
    except (yaml.YAMLError, UnicodeError, TypeError) as error:
        raise ValueError('CONFIG_PARSE_REFUSED') from error
    if not isinstance(config, dict) or not config:
        raise ValueError('CONFIG_NONEMPTY_MAPPING_REQUIRED')
    sha = __import__("hashlib").sha256(raw).hexdigest()
    return {"applied": False, "loaded": False, "consumer_ack": False,
            "native_acceptance": False, "status": "INSPECTED_NOT_APPLIED",
            "path": str(config_path), "bytes": len(raw), "sha256": sha,
            "smoke": "config parsed", "readback": "SNAPSHOT_HASH_ONLY"}


if __name__ == "__main__":
    mode = sys.argv[1] if len(sys.argv) > 1 else "selfcheck"
    if mode == "selfcheck":
        import hashlib
        results = {}
        for cls in ("RUNTIME_TRANSIENT", "CONFIG_PREAPPROVED", "PROFILE_CHANGE", "SKILL_CHANGE",
                    "PIPELINE_CHANGE", "STACK_CHANGE", "PROVIDER_UPGRADE", "DOMAIN_CHANGE",
                    "CONSTITUTIONAL_CHANGE", "UNKNOWN_X"):
            results[cls] = route_event(cls)
        # negative: unknown class must fail closed
        neg_ok = results["UNKNOWN_X"]["verdict"] == "FAIL_CLOSED"
        dom_ok = results["DOMAIN_CHANGE"]["domain_checker_required"] is True
        con_ok = results["CONSTITUTIONAL_CHANGE"]["auto_promotion"] is False
        ok = all(r["verdict"] == "ROUTE_OK" for k, r in results.items() if k != "UNKNOWN_X") and neg_ok and dom_ok and con_ok
        print("CONSUMER_OK" if ok else "CONSUMER_FAIL", json.dumps(results, ensure_ascii=False))
        sys.exit(0 if ok else 1)
