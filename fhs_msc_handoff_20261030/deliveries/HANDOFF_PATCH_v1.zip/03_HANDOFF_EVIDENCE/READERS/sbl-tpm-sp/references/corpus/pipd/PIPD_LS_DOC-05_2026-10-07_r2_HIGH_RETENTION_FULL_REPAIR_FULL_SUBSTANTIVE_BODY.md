---
artifact_id: "PIPD_LS_DOC-05"
external_formal_name: "Pre-Implementation & Pre-Dev Lifecycle Specification — DOC-05 Receiver / Permission / Admission Contract"
internal_short_name: "PIPD_LS_DOC-05"
artifact_type: "FULL_SUBSTANTIVE_BODY_HIGH_RETENTION_FULL_REPAIR"
document_archetype: "ADMISSION"
standard_id: "PIPD-LIFECYCLE-SPEC"
standard_version: "1.1.0"
blueprint_id: "PIPD-LIFECYCLE-BLUEPRINT"
blueprint_version: "1.1.0-r2_FULL_REPAIR"
skeleton_id: "PIPD_LS_SKELETON"
skeleton_version: "1.1.0-SKELETON-r2_FULL_REPAIR"
version: "2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY"
generated_at: "2026-10-07T12:04:00+08:00"
timezone: "Asia/Taipei"
supersedes: "PIPD_LS_DOC-05_2026-10-07_r1_FULL_SUBSTANTIVE_BODY"
supersedes_sha256: "6463444fc6b47c945b9dd2ee2c8f4f07a3a0f7b4fad0a4a3484f16bd7b86967c"
repair_controller: "AUDIT_PIPD_LS_DOC-05_R1"
repair_strategy: "HIGH_RETENTION_FULL_REPAIR_NO_ARCHITECTURE_RESET"
canonical_owner: "PIPD_LS_DOC-05"
materialization_state: "DOC05_R2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY_MATERIALIZED"
claim_ceiling: "DOC05_R2_HIGH_RETENTION_FULL_REPAIR_MATERIALIZED__INDEPENDENT_REAUDIT_REQUIRED__NOT_EXECUTED_NOT_PROVIDER_BOUND_NOT_VERIFIED_NOT_QUALIFIED_NOT_INDEPENDENT_PASS_NOT_HUMAN_RATIFIED_NOT_RELEASED_NOT_PRODUCTION_VERIFIED"
root_task_kind: "DESIGN"
source_scan: "FULL_NO_SAMPLING"
blocking_findings_author_side: 0
open_TT_author_side: []
independent_reaudit: "REQUIRED"
runtime_execution: "NOT_EXECUTED"
provider_binding: "NOT_BOUND"
independent_pass: "NOT_CLAIMED"
human_ratification: "NOT_CLAIMED"
release_candidate: "NOT_CLAIMED"
production_pass: "NOT_CLAIMED"
---

# PIPD_LS_DOC-05 — Receiver / Permission / Admission Contract
## High-Retention Full Repair Full Substantive Body — 2026-10-07 r2

> **Legal role.** This document is the r2 high-retention repaired DOC-05 substantive body for the receiver, permission, execution-admission, effect-intent, world-effect observation/readback/reconciliation, rollback/compensation, and evidence-return boundary of `PIPD-LIFECYCLE-SPEC@1.1.0`.
>
> **Hard boundary.** A completed document is not execution. `PREDEV_READY` is not `EXECUTION_ADMITTED`. An accepted handoff is not an admitted mutation. An ECP constrains execution but does not authorize it. Tool/provider success is not world-effect truth.
>
> **Authority preservation.** P0 blueprint controls document topology; P1 canonical standard controls normative lifecycle semantics and schemas; P2 skeleton controls DOC-family decomposition/materialization; P3 discussion is intent/history support; P4 DOC-00 is navigation/readback only. DOC-05 does not become a second TechnologyAdmission SSOT and does not override DOC-01..04 or DOC-06..09 ownership.

# H1-00｜Artifact Identity / Version / Lineage / Claim Boundary

## 00.1 Identity card

| Field | Value |
|---|---|
| Artifact ID | `PIPD_LS_DOC-05` |
| External formal name | `Pre-Implementation & Pre-Dev Lifecycle Specification — DOC-05 Receiver / Permission / Admission Contract` |
| Internal short name | `PIPD_LS_DOC-05` |
| Archetype | `Admission` |
| Standard | `PIPD-LIFECYCLE-SPEC@1.1.0` |
| Blueprint | `PIPD-LIFECYCLE-BLUEPRINT@1.1.0-r2_FULL_REPAIR` |
| Skeleton | `PIPD_LS_skeleton@1.1.0-SKELETON-r2_FULL_REPAIR` |
| Document version | `2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY` |
| Canonical writer | `PIPD_LS_DOC-05` |
| Primary entry state | `PREDEV_READY` |
| Primary exit gate | `EXECUTION_ADMITTED` only after valid `ExecutionAdmission.decision=ADMIT` |
| Primary decisions | Receiver `ACCEPT_HANDOFF/NACK/HOLD/DENY`; admission `ADMIT/HOLD/DENY` |
| Materialization truth | prose + machine-contract projection materialized locally |
| Runtime truth | not executed |
| Verification/qualification truth | not executed / not claimed |
| Human/release/production truth | not ratified / not released / not production verified |

## 00.2 Initial revision decision

r1 exists and was independently audited as `FAIL_REPAIR_REQUIRED`; this r2 preserves the accepted core architecture and surgically closes all reported S1–S4 document findings. The repair lineage is:

```text
2026-10-07_r1_FULL_SUBSTANTIVE_BODY
```

It **does** claim `HIGH_RETENTION_FULL_REPAIR` as an author-side document-repair class because it supersedes the hashed r1 predecessor. This label does not imply runtime, Independent, Human, release, or production acceptance.

## 00.3 Content identity rule

The artifact identity is `(artifact_id, version, content_hash)`. Filename equality is insufficient. Any byte change creates a new content identity. A later revision MUST record `supersedes` and the predecessor hash; it MUST NOT overwrite this revision in place.

## 00.4 Honest claim ceiling

The highest honest claim of this artifact is:

```text
DOC05_R2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY_MATERIALIZED
```

with explicit exclusions:

```text
NOT_EXECUTED
NOT_PROVIDER_BOUND
NOT_VERIFIED
NOT_QUALIFIED
NOT_INDEPENDENT_PASS
NOT_HUMAN_RATIFIED
NOT_RELEASED
NOT_PRODUCTION_VERIFIED
```

No schema validity, author-side review, web currentness check, or file completion can promote those runtime claims.

# H1-01｜Mission / Purpose / Scope / Non-Goals

DOC-05 exists to prevent a specific class of pre-execution failures: a sender believes a package is ready, but the actual receiver lacks a valid subject-bound handoff, current permission facts, scoped approval, rollback path, evidence-return contract, or independently issued execution admission.

Its engineering mission is to convert `PREDEV_READY` into a **rejectable receiver boundary** and, only when all predicates are satisfied, an **exact, scoped, time/currentness-bound execution authorization**.

## 01.1 Problems solved

DOC-05 closes these failure modes:

1. sender readiness being treated as receiver acceptance;
2. WorkOrder/ECP/TQAEP being treated as self-authorizing;
3. stale or foreign subject evidence being reused;
4. permission scope being widened during handoff;
5. human approval being implied rather than represented as a token;
6. tool/API/SDK success being promoted to world-effect truth;
7. rollback being declared without checkpoint/procedure/residue closure;
8. high-risk maker self-approval;
9. replay of expired or already-consumed approvals/admissions;
10. global waterfall blocking safe independent vertical slices;
11. brownfield cutover without incumbent rollback and residue proof;
12. external frameworks or adapters silently becoming lifecycle authority.

## 01.2 Upstream boundary

DOC-05 reads, but does not rewrite:

- `PREDEV_READY` package state;
- receiver/environment facts from DOC-03;
- WorkOrder, DEV ECP, OPS ECP, TQAEP and currentness refs from DOC-03;
- evidence/trace refs from DOC-04;
- TechnologyAdmission decisions from DOC-02;
- Constitution/state/authority from DOC-01;
- profile obligations from DOC-06;
- tests/oracles from DOC-07.

## 01.3 Downstream consumers

Primary consumers are execution receiver, implementation agent, operation receiver, human approver, checker/acceptor, and the downstream execution plane.

## 01.4 When DOC-05 opens

Open DOC-05 when all of the following are true for the target slice:

```text
PI subject is current
PREDEV_READY is true for the target slice
receiver can be identified and can validate the packet
WorkOrder/ECP/TQAEP/currentness refs exist
permission/effect class can be evaluated
rollback/evidence-return obligations can be evaluated
```

## 01.5 When DOC-05 must not open as an admission path

DOC-05 must not issue or imply admission when:

- the target is still only `PI_READY`;
- receiver identity is unresolved;
- required subject/version/hash is missing;
- WorkOrder or ECP identity is ambiguous;
- high-risk approval is missing/expired/mismatched;
- required currentness is stale;
- required rollback/compensation cannot be represented;
- the operation exceeds upstream scope;
- canonical ownership conflict is unresolved.

## 01.6 Non-goals

DOC-05 does not:

- grant authority to ECP, TQAEP, skills, plugins, prompts, AGENTS.md, MCP, A2A, or provider callbacks;
- select technology independently of DOC-02 TechnologyAdmission;
- redefine Product Truth, architecture, acceptance semantics, or release authority;
- claim execution, verification, qualification, release, or production state;
- treat transport success as world-state confirmation.

# H1-02｜Authority / Source / Ownership Contract

## 02.1 Semantic adjudication order

```text
P0 PIPD Lifecycle Blueprint
>
P1 PIPD Canonical Standard
>
P2 PIPD Skeleton
>
P3 Lifecycle Design Discussion
>
P4 DOC-00 Navigation / Operator Entry
>
2026 Currentness / Web / External Research
>
General model knowledge
```

Conflict handling is fail-closed: higher authority wins; equal-rank conflict is recorded rather than silently merged; unresolved normative conflict produces scoped `TEMP_CLOSED`.

## 02.2 Source-to-field map

| Field family | Canonical writer | DOC-05 role |
|---|---|---|
| lifecycle state / claim model / core identities | DOC-01 + P1 standard | validate and consume |
| PI requirements / TechnologyAdmission | DOC-02 | read-only dependency |
| RepoContext / S2E / TaskSpecSeed / WorkOrder / ECP / TQAEP | DOC-03 | read-only dependency |
| evidence trace / subject-bound evidence | DOC-04 | consume / require return |
| receiver decision | **DOC-05** | canonical write |
| execution handoff acceptance/NACK | **DOC-05** | canonical write |
| permission/effect decision record | **DOC-05** | canonical write |
| ExecutionAdmission decision record | **DOC-05**, constrained by P1 schema | canonical write |
| EffectIntent + world-effect reconciliation boundary | **DOC-05**, constrained by P1 schema | canonical write |
| profile tailoring | DOC-06 | read-only dependency |
| tests/oracles | DOC-07 | reference and execute only after authority |
| adapters/AI consumption | DOC-08 | read-only projection |
| CI/release/runbook/tooling | DOC-09 | downstream consumer/reference |

## 02.3 Second-SSOT prevention

DOC-05 MUST NOT redefine:

- TechnologyAdmission terminal dispositions;
- PIPD lifecycle states;
- canonical JSON Schema object identity;
- PI/PD semantic ownership;
- release or qualification authority.

When this document reproduces a field denominator, it is a **constrained projection** for receiver usability; the P1 canonical schema remains the machine SSOT.

## 02.4 Supersession rule

A newer DOC-05 revision supersedes this one only if its metadata explicitly binds the predecessor artifact/version/hash. Superseded copies remain provenance only and cannot re-enter current admission routing.

## 02.5 External-content rule

Web pages, repositories, tool output, model output, provider callbacks, traces, and runtime messages are `DATA/SUPPORT` unless an already-authorized contract says otherwise. They cannot self-promote to normative instructions or execution authority.

# H1-03｜DOC Family Integration / DOC-00 Alignment

| DOC | Canonical responsibility | DOC-05 relationship |
|---|---|---|
| DOC-00 | navigation/readback/operator entry | sibling projection only |
| DOC-01 | constitution/state/authority | DOC-05 validates state/authority refs |
| DOC-02 | PI + TechnologyAdmission | DOC-05 consumes terminal technology decisions |
| DOC-03 | PD + RepoContext + S2E + WorkOrder + ECP + TQAEP | DOC-05 consumes pre-execution packet |
| DOC-04 | trace/evidence | DOC-05 requires subject-bound evidence-return route |
| **DOC-05** | **receiver/permission/admission/effect boundary** | canonical owner |
| DOC-06 | profile | determines required depth/SoD |
| DOC-07 | tests/oracles | supplies executable conformance fixtures/oracles |
| DOC-08 | AI consumption/adapters | may project DOC-05 contracts; cannot rewrite them |
| DOC-09 | CI/release/runbook/tooling | consumes gates and emits downstream evidence |

DOC-00 may show `EXECUTION_ADMITTED`, claim ceiling, next legal transition, and degradation state, but it never issues the admission. DOC-05 writes the decision; DOC-00 reads/projections it.

# H1-04｜Core Vocabulary / Identity Model

| Term | DOC-05 meaning | Execution authority |
|---|---|---|
| sender | producer that packages the subject/handoff | none |
| receiver | named endpoint responsible for validating and accepting/rejecting the handoff | none merely by identity |
| maker | creates/changes the candidate/subject | none by role alone |
| checker | independently challenges a subject where required | none by role alone |
| acceptor | owns technical/business acceptance where applicable | does not replace ExecutionAdmission |
| approver | authorized human/policy authority that may issue ApprovalToken | scoped approval input only |
| execution receiver | receiver that would perform admitted mutation/effect | only after matching ADMIT |
| ExecutionHandoff | subject-bound rejectable delivery envelope | none |
| ApprovalToken | scoped, expiring, nonce-bound approval artifact | approval input only |
| ExecutionAdmission | separate `ADMIT/HOLD/DENY` decision | `ADMIT` authorizes only exact scope/time/currentness |
| EffectIntent | desired world mutation bound to admitted authority/readback plan | cannot exist as "authorized" without matching ADMIT |
| EffectObservation | observed post-attempt state with observer/time/method | evidence input, not acceptance |
| EffectReconciliationReceipt | oracle-backed reconciliation of intended vs actual state | may promote effect evidence, not release authority |
| WorkOrder | exact receiver-bound execution contract | cannot self-authorize |
| ECP | mutation/effect control package | constrains only |
| TQAEP | test/qualification/acceptance/evidence plan | plan only; cannot self-qualify |
| evidence-return | required subject-bound packet returned after attempt/test/effect | evidence only |
| rollback | reverse to prior checkpoint/state using a defined procedure | effectful; may itself require admission |
| compensation | forward corrective action when exact rollback is impossible | effectful; requires bounded authority |
| residue | remaining state/credential/config/artifact/effect after rollback/disable/uninstall | must be observed and closed/accepted |
| provider-off | disable/remove provider binding and prove no unintended dependency remains | effectful if it changes external/runtime state |

## 04.1 Identity firewall

These are distinct and must never alias:

```text
S2E
TaskSpecSeed
WorkOrder
DEV_ECP
OPS_ECP
TQAEP
ExecutionHandoff
ApprovalToken
ExecutionAdmission
EffectIntent
EffectObservation
EffectReconciliationReceipt
```

A serializer, UI, workflow, prompt, skill, or provider adapter MUST preserve those identities.

# H1-05｜Receiver Contract

## 05.1 Receiver identity

A receiver record is valid only when it resolves to a named role/principal/agent surface and a target scope. A generic label such as `"implementation team"` is insufficient when multiple receivers could act on different repositories, providers, accounts, or environments.

Minimum receiver facts:

```yaml
receiver_id: stable-principal-or-role-id
receiver_class: IMPLEMENTATION_AGENT | OPERATIONS_RECEIVER | HUMAN_OPERATOR | AUTOMATED_EXECUTION_PLANE
target_scope_refs: [non-empty]
trust_boundary: local | repository | provider | production | physical | financial | identity
capability_refs: [non-empty]
instruction_surface_refs: [non-empty-or-none_reason]
currentness_checked_at: ISO-8601
```

## 05.2 Receiver capability and trust boundary

Receiver capability MUST cover the requested operation, environment, and evidence-return obligations. Possessing a tool or credential does not imply authorization to use it.

The receiver validates:

1. own identity matches `handoff.receiver`;
2. subject ID/version/hash match current bytes/state;
3. required refs resolve;
4. late-bound refs are current;
5. applicable repo/environment instructions were discovered read-only;
6. requested permission/effect class is allowed to be evaluated;
7. rollback/compensation/readback path is executable in principle;
8. evidence-return destination is resolvable;
9. required approval can be validated;
10. no newer supersession/invalidation applies.

## 05.3 Receiver obligations

The receiver MUST:

- reject widened scope;
- stop on the first blocking invariant;
- preserve `sender-ready != receiver-accepted`;
- return structured NACK/HOLD/DENY reasons;
- re-check currentness immediately before first mutation for volatile facts;
- execute only actions enumerated by matching ADMIT;
- return subject-bound evidence after attempt;
- observe/read back world effects rather than infer them from provider success.

## 05.4 NACK rights and sender repair

Receiver may NACK a packet for missing, stale, wrong-subject, wrong-version/hash, wrong-receiver, wrong-permission, insufficient rollback, unresolved required refs, or missing evidence-return contract.

Sender MUST repair and reissue. Receiver MUST NOT "fix" semantic scope locally if the repair changes product/architecture/acceptance/TechnologyAdmission ownership.

## 05.5 Receiver cannot widen upstream scope

The receiver may narrow execution for safety. It cannot widen operation, target, path, network, secret, data class, provider, environment, or effect class beyond the admitted contract.

# H1-06｜Execution Handoff Contract

The canonical `ExecutionHandoff` remains owned by P1 `handoff.schema.json` (`urn:pipd:canonical-standard:1.1:schema:handoff`). r2 does **not** mutate that schema. It repairs receiver self-sufficiency by pairing the canonical object with a DOC-05-owned sidecar, `ReceiverHandoffBundle`.

## 06.1 Canonical ExecutionHandoff field contract

A finalized handoff MUST satisfy the P1 schema exactly:

| Field | Finalized-instance rule | Producer | Consumer/validator | Failure / invalidation |
|---|---|---|---|---|
| `handoff_id` | nonempty, unique for this handoff identity | DOC-03 handoff producer | DOC-05 structural validator | collision → NACK |
| `receiver` | exact intended receiver identity | sender | receiver registry + DOC-05 | mismatch/stale receiver → NACK |
| `subject_ref.id/version/hash` | exact current subject tuple | sender | subject registry | wrong/stale tuple → DENY |
| `required_refs` | **minItems=1**; every required ref resolvable/current | sender | reference/currentness registry | missing/stale → NACK/HOLD |
| `late_bound_refs` | only fields legally late-bound by PD | sender/PD | receiver | unresolved blocker → HOLD |
| `permission_required` | **minItems=1** and maps to P0 permission policy | sender | permission-policy registry | unknown/missing permission → DENY |
| `entry_gate` | normally `PREDEV_READY`; exact gate must be current | sender | lifecycle registry | wrong gate → DENY |
| `allowed_scope` | **minItems=1**; admission scope must be subset | sender | semantic validator | widening → DENY |
| `forbidden_scope` | **minItems=1**; admission scope must not intersect | sender | semantic validator | intersection → DENY |
| `rollback.reversibility_class/checkpoint_ref/procedure_ref` | canonical rollback object; no scalar alias in finalized instance | sender | rollback registry | insufficient rollback → HOLD/DENY |
| `expected_evidence_return` | **minItems=1**; resolves to H1-14A contract | sender | evidence registry | missing/unresolvable → NACK |
| `human_approval_ref` | token-store reference or null as policy permits | sender | token store | mismatch/expired/revoked → DENY |
| `none_reason` | may explain optional absence only; **cannot legalize empty required arrays** | sender | validator | misuse → schema/semantic FAIL |

## 06.2 H1-06A｜ReceiverHandoffBundle / self-sufficient receiver payload

A receiver MUST answer `WHY / WHAT / WHERE / HOW / ALLOWED / FORBIDDEN / ENTRY / STOP / ROLLBACK / EVIDENCE RETURN` without reopening historical corpus. The sidecar carries receiver-facing data that P1 prose requires but the canonical handoff schema does not own.

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "urn:pipd:doc05:1.1.0-r2:schema:receiver-handoff-bundle",
  "title": "ReceiverHandoffBundle",
  "type": "object",
  "additionalProperties": false,
  "required": [
    "bundle_id",
    "canonical_handoff_ref",
    "producer",
    "subject_ref",
    "payload_refs",
    "pi_refs",
    "pd_refs",
    "work_order_refs",
    "ecp_refs",
    "tqaep_refs",
    "currentness_refs",
    "why",
    "what",
    "where",
    "how",
    "stop_conditions",
    "nack_reason_vocabulary",
    "invalidation_triggers",
    "evidence_return_contract_ref",
    "created_at"
  ],
  "properties": {
    "bundle_id": {
      "type": "string",
      "minLength": 1
    },
    "canonical_handoff_ref": {
      "type": "string",
      "minLength": 1
    },
    "producer": {
      "type": "string",
      "minLength": 1
    },
    "subject_ref": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "id",
        "version",
        "hash"
      ],
      "properties": {
        "id": {
          "type": "string",
          "minLength": 1
        },
        "version": {
          "type": "string",
          "minLength": 1
        },
        "hash": {
          "type": "string",
          "pattern": "^[A-Fa-f0-9]{64}$"
        }
      }
    },
    "payload_refs": {
      "type": "array",
      "minItems": 1,
      "items": {
        "type": "string",
        "minLength": 1
      }
    },
    "pi_refs": {
      "type": "array",
      "minItems": 1,
      "items": {
        "type": "string",
        "minLength": 1
      }
    },
    "pd_refs": {
      "type": "array",
      "minItems": 1,
      "items": {
        "type": "string",
        "minLength": 1
      }
    },
    "work_order_refs": {
      "type": "array",
      "minItems": 1,
      "items": {
        "type": "string",
        "minLength": 1
      }
    },
    "ecp_refs": {
      "type": "array",
      "minItems": 1,
      "items": {
        "type": "string",
        "minLength": 1
      }
    },
    "tqaep_refs": {
      "type": "array",
      "minItems": 1,
      "items": {
        "type": "string",
        "minLength": 1
      }
    },
    "currentness_refs": {
      "type": "array",
      "minItems": 1,
      "items": {
        "type": "string",
        "minLength": 1
      }
    },
    "stop_conditions": {
      "type": "array",
      "minItems": 1,
      "items": {
        "type": "string",
        "minLength": 1
      }
    },
    "nack_reason_vocabulary": {
      "type": "array",
      "minItems": 1,
      "items": {
        "type": "string",
        "minLength": 1
      }
    },
    "invalidation_triggers": {
      "type": "array",
      "minItems": 1,
      "items": {
        "type": "string",
        "minLength": 1
      }
    },
    "why": {
      "type": "string",
      "minLength": 1
    },
    "what": {
      "type": "string",
      "minLength": 1
    },
    "where": {
      "type": "string",
      "minLength": 1
    },
    "how": {
      "type": "string",
      "minLength": 1
    },
    "evidence_return_contract_ref": {
      "type": "string",
      "minLength": 1
    },
    "created_at": {
      "type": "string",
      "format": "date-time"
    }
  }
}
```

Required semantics:

- `producer` is the concrete package/person/agent that assembled the bundle; producer is not the receiver or admission authority by implication.
- `payload_refs` enumerate the execution-facing payload, while `pi_refs`, `pd_refs`, `work_order_refs`, `ecp_refs`, and `tqaep_refs` preserve typed identity separation.
- `currentness_refs` bind repo/environment/provider/security/license/adapter facts used by admission.
- `why/what/where/how` are bounded receiver instructions, not permission grants.
- `stop_conditions` are operation-specific and MUST contain at least one fail-closed condition.
- `nack_reason_vocabulary` is explicit so sender repair is deterministic.
- `invalidation_triggers` include subject/version/hash drift, receiver drift, permission-policy change, token expiry/revocation, WorkOrder/ECP drift, currentness expiry, and shared-resource conflict.
- `evidence_return_contract_ref` MUST resolve to H1-14A.

## 06.3 H1-06B｜Stop Conditions / NACK Reason / Invalidation Contract

Canonical NACK reason vocabulary:

```text
NACK_MISSING_REF
NACK_STALE_REF
NACK_WRONG_SUBJECT
NACK_WRONG_VERSION
NACK_WRONG_HASH
NACK_WRONG_RECEIVER
NACK_PERMISSION_MISMATCH
NACK_SCOPE_MISMATCH
NACK_ROLLBACK_INSUFFICIENT
NACK_EVIDENCE_RETURN_MISSING
NACK_CURRENTNESS_STALE
NACK_STOP_CONDITION_UNRESOLVED
NACK_UNKNOWN_RESOURCE
NACK_APPROVAL_INVALID
```

Minimum stop conditions by operation class:

| Operation class | Mandatory STOP CONDITION |
|---|---|
| repo/local mutation | target path escapes `allowed_scope`; repo hash/branch changes; checkpoint unavailable |
| network/API effect | target/resource identity differs; response cannot be independently read back; network target not policy-scoped |
| secret-bearing operation | `SECRET_READ` not explicitly policy-scoped/approved; secret handle resolves outside receiver boundary; raw secret would enter evidence |
| provider bind/install | currentness/license/security/pin invalid; uninstall/provider-off path not proven |
| migration/cutover | parity oracle fails; incumbent rollback window unavailable; residue cannot be bounded |
| high-impact/irreversible | approval token invalid/revoked; compensation/containment precondition fails; checker unavailable where required |

A STOP condition blocks the affected operation/slice; it never silently widens to unrelated slices.

## 06.4 Same-rank P1 prose/schema compatibility adjudication — `CR-DOC05-001`

P1 contains an authoring YAML template with empty arrays and `stop_conditions`, while finalized `handoff.schema.json` requires several arrays to have `minItems:1` and does not include `stop_conditions`. r2 resolves this deterministically without altering P1:

1. **finalized canonical object:** `handoff.schema.json` wins for structural validity;
2. **§38 empty arrays:** drafting placeholders only; they MUST be populated before a handoff can be admission-ready;
3. **§38 `stop_conditions` and receiver prose fields:** live in `ReceiverHandoffBundle`, not injected into canonical `ExecutionHandoff`;
4. **§38 scalar rollback shorthand:** expanded to the canonical rollback object before validation;
5. `none_reason` never bypasses required-array `minItems`.

`CR-DOC05-001` status: `LOCAL_COMPATIBILITY_ADJUDICATION_CLOSED`; upstream editorial harmonization is desirable but is not a blocker for this r2 representation.

# H1-07｜Receiver Acceptance / NACK / HOLD / DENY

## 07.1 DOC-05-owned ReceiverDecision

```yaml
receiver_decision_id: "RD-<stable-id>"
handoff_ref: "<handoff-id>"
subject_ref:
  id: "<subject>"
  version: "<version>"
  hash: "<sha256>"
receiver: "<receiver-id>"
decision: "ACCEPT_HANDOFF | NACK | HOLD | DENY"
reason_codes: ["<typed reason>"]
currentness_refs: ["<currentness record>"]
repair_required: true
reissue_required: true
evaluated_at: "<ISO-8601>"
checker: "<principal>"
```

`ACCEPT_HANDOFF` means only: *the receiver accepts the packet as the correct packet to evaluate*. It is not `ADMIT`.

## 07.2 Decision taxonomy

| Receiver decision | Meaning | Typical causes | Next legal action |
|---|---|---|---|
| `ACCEPT_HANDOFF` | packet identity/scope is accepted for admission evaluation | all receiver checks current | evaluate permission/approval/admission |
| `NACK` | sender-correctable packet defect | missing field/ref, wrong version, wrong receiver, bad hash | sender repairs and reissues new handoff |
| `HOLD` | potentially valid but temporarily blocked | currentness expired, receiver unavailable, dependency/provider uncertainty | refresh facts / resolve blocker / re-evaluate |
| `DENY` | request is unauthorized, unsafe, or contradicts authority | scope escalation, forged token/evidence, forbidden target, invalid self-approval | stop; new upstream decision/CR required |

## 07.3 Replay safety

A handoff or token already consumed by an admitted execution scope cannot be replayed against a new subject/version/hash, new target, or widened operation. A retry after partial failure requires an explicit retry/rollback/compensation route and a current admission decision; old success/failure receipts do not silently authorize a new attempt.

## 07.4 Sender override prohibition

Sender cannot convert NACK/HOLD/DENY into acceptance. Only the receiver/admission authority can reevaluate after corrected/current facts are provided.

# H1-08｜Permission & Effect Classification

DOC-05 maps the human-facing five-class permission/effect model to the P0/P1 machine policies. The five classes remain explanatory; machine enforcement uses P0 permission classes and P1 `risk_class/effect_class`.

| Human-facing class | P0 permission examples | P1 effect/risk mapping | Minimum approval | Rollback/readback/evidence |
|---|---|---|---|---|
| `READ_ONLY` | `READ_ONLY` | `READ_ONLY`, LOW/MEDIUM | none unless policy elevates | no world mutation; provenance evidence |
| `LOCAL_REVERSIBLE_WRITE` | `LOCAL_ARTIFACT_WRITE`, `REPO_WRITE` | `REVERSIBLE_WRITE` | `REPO_WRITE` requires current ADMIT; policy may require approval | checkpoint + diff/readback + evidence |
| `EXTERNAL_REVERSIBLE_EFFECT` | `NETWORK`, `PROVIDER_BIND`, `DEPLOY`, `MIGRATE`, `ROLLBACK` | `EXTERNAL_EFFECT` | scoped policy; HIGH/CRITICAL requires token | observation/readback/reconciliation + compensation/rollback |
| `PRIVILEGED_SECURITY_SENSITIVE` | `SECRET_READ`, privileged network/tool action | at least policy-elevated; often HIGH | **approval required for SECRET_READ regardless nominal risk label** | secret-safe evidence + revoke/containment |
| `IRREVERSIBLE_OR_HIGH_IMPACT` | `PRODUCTION_CHANGE` or non-compensatable action | `HIGH_RISK_EFFECT`, HIGH/CRITICAL | subject-bound Human/policy token mandatory | containment/compensation plan + independent checker/readback |

## 08.1 H1-08A｜P0 Permission Policy Machine Binding

DOC-05 MUST resolve `urn:pipd:blueprint:1.1.0-r2:schema:permission-policy` before issuing `ADMIT`.

```text
default_decision = DENY
adapter_can_grant_permissions = false
pre_admission_forbidden includes REPO_WRITE, INSTALL, SECRET_READ, PROVIDER_BIND, DEPLOY, MIGRATE, ROLLBACK, PRODUCTION_CHANGE
high_risk_requires_approval = true
secret_policy ∈ {DENY, HANDLE_REFS_ONLY, SCOPED}
network_policy ∈ {DENY, SCOPED}
```

Deterministic unknown-resource rules:

| Unknown fact | Decision |
|---|---|
| unknown tool | `DENY` until registered + scoped |
| unknown command | `DENY` until WorkOrder/ECP binds exact command/action |
| unknown path | `DENY` until receiver resolves path inside allowed scope |
| unknown network target | `DENY` until `network_policy=SCOPED` and exact target bound |
| unknown secret/secret path | `DENY`; raw secret never enters PI/PD canonical artifacts |
| `SECRET_READ` | pre-admission forbidden; requires current ADMIT **and** scoped Human/policy approval; secret handle only; evidence redacted |

A `PermissionEffectDecision` is policy evaluation input to admission, never execution authority by itself.

# H1-09｜ApprovalToken / Human Approval Contract

The canonical P1 `ApprovalToken` remains structurally authoritative. A token is a scoped approval input, not an admission and not evidence of execution.

## 09.1 Canonical matching predicates

A token is valid only when all are true:

```text
token.subject == admission.subject_ref.id
token.subject_hash == admission.subject_ref.hash
token.operation == admission.operation
token.target_system == admission.target_system
token.scope exactly authorizes admission.scope
token.data_class == admission.data_class
approver authorized for operation/data/risk class
issued_at <= now < expiry
nonce exists and is ISSUED, not CONSUMED/REVOKED/EXPIRED
rollback binding matches the admitted rollback contract
maker/checker/approver SoD satisfies profile/policy
```

## 09.2 H1-09A｜Approval identity store / digest join / nonce / revocation

`human_approval_ref`, the token embedded in canonical `ExecutionAdmission`, and token-store truth MUST resolve to one identity. DOC-05 adds a binding record without redefining ApprovalToken:

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "urn:pipd:doc05:1.1.0-r2:schema:approval-token-binding-record",
  "title": "ApprovalTokenBindingRecord",
  "type": "object",
  "additionalProperties": false,
  "required": [
    "binding_id",
    "token_ref",
    "token_digest",
    "handoff_ref",
    "admission_ref",
    "nonce",
    "nonce_state",
    "store_ref",
    "subject_hash",
    "operation",
    "target_system",
    "scope_digest",
    "issued_at",
    "expiry",
    "consumed_at",
    "revoked_at",
    "revocation_reason"
  ],
  "properties": {
    "binding_id": {
      "type": "string",
      "minLength": 1
    },
    "token_ref": {
      "type": "string",
      "minLength": 1
    },
    "token_digest": {
      "type": "string",
      "pattern": "^[A-Fa-f0-9]{64}$"
    },
    "handoff_ref": {
      "type": "string",
      "minLength": 1
    },
    "admission_ref": {
      "type": "string",
      "minLength": 1
    },
    "nonce": {
      "type": "string",
      "minLength": 1
    },
    "nonce_state": {
      "enum": [
        "ISSUED",
        "CONSUMED",
        "REVOKED",
        "EXPIRED"
      ]
    },
    "store_ref": {
      "type": "string",
      "minLength": 1
    },
    "subject_hash": {
      "type": "string",
      "pattern": "^[A-Fa-f0-9]{64}$"
    },
    "operation": {
      "type": "string",
      "minLength": 1
    },
    "target_system": {
      "type": "string",
      "minLength": 1
    },
    "scope_digest": {
      "type": "string",
      "pattern": "^[A-Fa-f0-9]{64}$"
    },
    "issued_at": {
      "type": "string",
      "format": "date-time"
    },
    "expiry": {
      "type": "string",
      "format": "date-time"
    },
    "consumed_at": {
      "type": [
        "string",
        "null"
      ],
      "format": "date-time"
    },
    "revoked_at": {
      "type": [
        "string",
        "null"
      ],
      "format": "date-time"
    },
    "revocation_reason": {
      "type": [
        "string",
        "null"
      ]
    }
  }
}
```

Join rules:

1. `human_approval_ref` resolves to one canonical token-store record.
2. Canonicalized embedded token bytes hash to `token_digest`; mismatch is `DENY/TOKEN_DIGEST_MISMATCH`.
3. `scope_digest` is computed from canonical sorted scope; a widened/reordered semantic scope cannot evade comparison.
4. Nonce consumption is an **atomic compare-and-set** from `ISSUED → CONSUMED` when an `ADMIT` is issued. Failure to consume is `DENY/NONCE_ALREADY_USED`.
5. Revocation or expiry propagates through reverse dependencies to `AdmissionValidityRecord.status=INVALIDATED/STALE` for affected admissions only.
6. A token cannot be copied into a second admission after consumption; a new operation/scope/hash requires a new token.
7. Maker self-approval is rejected for ASSURED/high-risk and whenever policy requires SoD.

This closes reference/embed ambiguity and makes replay/revocation machine-decidable.

# H1-10｜ExecutionAdmission Contract

The P1 canonical `ExecutionAdmission` is the only object that can authorize the **exact admitted** first mutation/effect when `decision=ADMIT` and its sidecar validity is current. WorkOrder, ECP, TQAEP, handoff acceptance, approval token, CI/schema PASS, and provider success are insufficient.

## 10.1 Canonical required denominator

```text
admission_id
subject_ref.id/version/hash
decision = ADMIT | HOLD | DENY
receiver
work_order_refs
ecp_refs
operation
target_system
scope
data_class
risk_class
effect_class
rollback_ref
evidence_return_refs
approver
evaluated_at
approval_token
```

A structurally valid but semantically hollow `ADMIT` is rejected.

## 10.2 Admission predicate

`ADMIT` requires, in first-failing order: current subject → accepted handoff → exact receiver → resolvable WorkOrder/ECP/TQAEP/currentness → P0 permission-policy allow candidate → scope subset/no forbidden intersection → rollback/evidence-return resolvable → token/SoD if required → admission validity window → effect-chain readiness when effectful.

## 10.3 H1-10A｜Admission Validity / Time Window / Currentness Binding

Every `ADMIT`, including LOW/MEDIUM without a Human token, MUST have a machine-bound validity sidecar:

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "urn:pipd:doc05:1.1.0-r2:schema:admission-validity-record",
  "title": "AdmissionValidityRecord",
  "type": "object",
  "additionalProperties": false,
  "required": [
    "validity_id",
    "admission_ref",
    "subject_ref",
    "valid_from",
    "expires_at",
    "currentness_record_refs",
    "invalidation_triggers",
    "status",
    "evaluated_at",
    "checker"
  ],
  "properties": {
    "validity_id": {
      "type": "string",
      "minLength": 1
    },
    "admission_ref": {
      "type": "string",
      "minLength": 1
    },
    "subject_ref": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "id",
        "version",
        "hash"
      ],
      "properties": {
        "id": {
          "type": "string",
          "minLength": 1
        },
        "version": {
          "type": "string",
          "minLength": 1
        },
        "hash": {
          "type": "string",
          "pattern": "^[A-Fa-f0-9]{64}$"
        }
      }
    },
    "valid_from": {
      "type": "string",
      "format": "date-time"
    },
    "expires_at": {
      "type": "string",
      "format": "date-time"
    },
    "currentness_record_refs": {
      "type": "array",
      "minItems": 1,
      "items": {
        "type": "string",
        "minLength": 1
      }
    },
    "invalidation_triggers": {
      "type": "array",
      "minItems": 1,
      "items": {
        "type": "string",
        "minLength": 1
      }
    },
    "status": {
      "enum": [
        "CURRENT",
        "STALE",
        "INVALIDATED"
      ]
    },
    "evaluated_at": {
      "type": "string",
      "format": "date-time"
    },
    "checker": {
      "type": "string",
      "minLength": 1
    }
  }
}
```

Semantic rules:

```text
valid_from <= evaluated_at < expires_at
status must be CURRENT at first mutation
expires_at = earliest authoritative bound among project admission TTL, approval-token expiry (if any), and bound currentness TTLs
if no authoritative time/currentness bound can be resolved -> HOLD/TEMP_CLOSE; never issue timeless ADMIT
any invalidation_trigger firing -> STALE or INVALIDATED before further mutation
```

Required invalidation triggers include subject/version/hash drift, permission-policy change, receiver capability/currentness change, WorkOrder/ECP/TQAEP drift, token expiry/revocation, provider/security/license drift, repo/runtime binding drift, shared-writer/resource conflict, and evidence-route invalidation.

# H1-11｜ADMIT / HOLD / DENY Decision Semantics

| Dimension | `ADMIT` | `HOLD` | `DENY` |
|---|---|---|---|
| subject/version/hash | exact current match | potentially resolvable stale/unknown | mismatch/forgery/forbidden |
| receiver | exact current receiver | temporarily unavailable/unconfirmed | wrong/unauthorized receiver |
| WorkOrder/ECP | current and scoped | unresolved/stale | contradictory/unauthorized |
| permission | fully covered | needs additional current fact/approval | exceeds allowed scope |
| rollback | sufficient for class | refresh/repair needed | impossible where policy requires reversibility |
| evidence return | resolvable | temporarily blocked | absent for required effect |
| approval | valid if required | awaiting valid approval | invalid/expired/replayed/unauthorized |
| next lifecycle state | `EXECUTION_ADMITTED` | no promotion | no promotion; may require CR/reissue |
| first mutation | allowed only within exact contract | forbidden | forbidden |

## 11.1 Non-equivalence

```text
ADMIT ≠ PASS
ADMIT ≠ VERIFIED
ADMIT ≠ QUALIFIED
ADMIT ≠ RELEASED
ADMIT ≠ PRODUCTION_VERIFIED
```

ADMIT means only `AUTHORIZED_TO_BEGIN_BOUNDED_EXECUTION` for the exact admitted subject/operation/target/scope/currentness window.

## 11.2 Re-evaluation paths

- `HOLD` → refresh currentness / resolve receiver / repair rollback / obtain approval → re-evaluate.
- `DENY` caused by scope/authority contradiction → new upstream WorkOrder/ECP/TechnologyAdmission/CR as applicable.
- Any change to subject/hash/operation/target/scope/data class/risk/effect/approval/rollback invalidates the admission and requires reevaluation.

# H1-12｜EffectIntent Contract

The canonical machine SSOT is P1 `urn:pipd:canonical-standard:1.1:schema:effect-intent`.

```yaml
effect_intent_id: "<stable id>"
subject_ref:
  id: "<subject>"
  version: "<version>"
  hash: "<sha256>"
operation: "<exact admitted operation>"
target: "<exact world target>"
desired_state: "<observable intended state>"
effect_class: "REVERSIBLE_WRITE | EXTERNAL_EFFECT | HIGH_RISK_EFFECT"
authorized_by_ref: "<ExecutionAdmission with decision=ADMIT>"
readback_plan_ref: "<readback/oracle plan>"
```

Semantic requirements:

1. `authorized_by_ref` MUST resolve to a current matching ADMIT.
2. operation/target/effect class MUST be a subset/equal of the admission.
3. desired state MUST be observable enough for reconciliation.
4. readback plan MUST identify an observation path independent enough for the risk profile.
5. changing desired state requires new/revised admission, not a local edit of the intent.
6. EffectIntent never claims that the effect occurred.

# H1-13｜World Effect Observation / Readback / Reconciliation

## 13.1 Canonical flow

```text
EffectIntent
→ ExecutionAdmission
→ AuthorizedAttempt
→ Provider/Tool Response
→ EffectObservation
→ independent/appropriate Readback
→ EffectReconciliationReceipt
→ WorldEffectState
→ Promote Evidence | Reobserve | Reconcile | Compensate | Rollback | Fail Closed
```

## 13.2 World-effect states

| State | Meaning | Claim rule |
|---|---|---|
| `UNKNOWN_EFFECT` | provider/tool response exists but world state is not established | block claims dependent on successful effect |
| `PARTIAL_EFFECT` | only part of intended state observed | reconcile/compensate/rollback |
| `CONFLICTING_EFFECT` | observations/readbacks conflict | fail closed until resolved |
| `CONFIRMED_EFFECT` | oracle confirms intended world state | effect evidence may be promoted |
| `FAILED_EFFECT` | intended state not achieved | no success claim; recover/rollback/close |
| `COMPENSATED_EFFECT` | compensating action returned target to accepted bounded state | original intended effect not treated as success |

## 13.3 EffectObservation projection

```yaml
observation_id: "<stable id>"
effect_intent_ref: "<intent>"
provider_response_ref: "<raw response/action receipt>"
observation_method: "<independent/appropriate method>"
observed_state: "<actual observed state>"
observed_at: "<ISO-8601>"
observer: "<principal/tool>"
```

## 13.4 Reconciliation receipt projection

```yaml
receipt_id: "<stable id>"
effect_intent_ref: "<intent>"
observation_refs: ["<one or more>"]
readback_refs: ["<one or more>"]
state: "UNKNOWN_EFFECT | PARTIAL_EFFECT | CONFLICTING_EFFECT | CONFIRMED_EFFECT | FAILED_EFFECT | COMPENSATED_EFFECT"
oracle: "<oracle id/ref>"
actual: "<reconciled actual>"
next_action: "PROMOTE_EVIDENCE | REOBSERVE | RECONCILE | COMPENSATE | ROLLBACK | FAIL_CLOSED"
checker: "<checker>"
timestamp: "<ISO-8601>"
```

## 13.5 Tool-success firewall

These are provider-response facts only:

```text
HTTP 2xx
CLI exit 0
SDK "success"
provider callback "done"
tool result "ok"
CI green
```

None is `CONFIRMED_EFFECT` without observation/readback/reconciliation.

# H1-14｜Rollback / Compensation / Residue Closure

Rollback is not a single boolean. DOC-05 distinguishes:

- **rollback** — restore a prior checkpoint when reversible;
- **compensation** — perform an accepted counter-operation when exact reversal is impossible;
- **provider-off / disable / uninstall** — remove optional integration/runtime dependency;
- **credential/secret revoke** — terminate authorization material;
- **residue detection/cleanup** — find and remove persistent state, bindings, jobs, tokens, files, callbacks, indexes, caches, remote objects;
- **post-rollback readback** — prove the bounded state after recovery;
- **irreversible handling** — requires Human/policy gate, bounded blast radius, containment and explicit residual-risk acceptance.

`rollback = none` cannot pass where canonical or project policy requires reversible/compensatable behavior. Provider-off is not equivalent to rollback unless the target world state is independently read back and reconciled.

## 14.1 Recovery decision table

| Observed state | Required next action | Evidence needed |
|---|---|---|
| `UNKNOWN_EFFECT` | REOBSERVE; do not blind-retry | observation/readback attempts + idempotency/replay analysis |
| `PARTIAL_EFFECT` | RECONCILE or COMPENSATE | partial-state inventory + compensation receipt |
| `CONFLICTING_EFFECT` | HOLD + independent readback; then RECONCILE/ROLLBACK | conflicting observations + checker decision |
| `FAILED_EFFECT` | rollback/compensate if any mutation occurred | failure result + residue readback |
| `COMPENSATED_EFFECT` | verify bounded accepted state | compensation + post-compensation readback |
| `CONFIRMED_EFFECT` | promote effect evidence only | reconciliation oracle PASS |

## 14.2 H1-14A｜Execution Evidence Return Contract

P1 §25 requires the receiver to return a subject-bound evidence packet. DOC-05 binds that denominator to DOC-04 evidence ownership through a sidecar schema; this schema does not replace DOC-04 `evidence.schema.json`.

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "urn:pipd:doc05:1.1.0-r2:schema:evidence-return-packet",
  "title": "ExecutionEvidenceReturnPacket",
  "type": "object",
  "additionalProperties": false,
  "required": [
    "packet_id",
    "subject_ref",
    "changed_artifacts",
    "actions",
    "raw_results",
    "oracle_verdicts",
    "environment",
    "producer",
    "checker",
    "started_at",
    "ended_at",
    "checksums",
    "approval_ref",
    "rollback_residue_result",
    "redaction_record",
    "retention",
    "replay_freshness"
  ],
  "properties": {
    "packet_id": {
      "type": "string",
      "minLength": 1
    },
    "subject_ref": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "id",
        "version",
        "hash"
      ],
      "properties": {
        "id": {
          "type": "string",
          "minLength": 1
        },
        "version": {
          "type": "string",
          "minLength": 1
        },
        "hash": {
          "type": "string",
          "pattern": "^[A-Fa-f0-9]{64}$"
        }
      }
    },
    "changed_artifacts": {
      "type": "array",
      "items": {
        "type": "object",
        "required": [
          "ref",
          "sha256"
        ],
        "properties": {
          "ref": {
            "type": "string",
            "minLength": 1
          },
          "sha256": {
            "type": "string",
            "pattern": "^[A-Fa-f0-9]{64}$"
          }
        },
        "additionalProperties": false
      }
    },
    "actions": {
      "type": "array",
      "minItems": 1,
      "items": {
        "type": "string",
        "minLength": 1
      }
    },
    "raw_results": {
      "type": "array",
      "minItems": 1,
      "items": {
        "type": "object",
        "required": [
          "action_ref",
          "result_ref",
          "exit_equivalent"
        ],
        "properties": {
          "action_ref": {
            "type": "string"
          },
          "result_ref": {
            "type": "string"
          },
          "exit_equivalent": {
            "type": [
              "string",
              "integer"
            ]
          }
        },
        "additionalProperties": false
      }
    },
    "oracle_verdicts": {
      "type": "array",
      "minItems": 1,
      "items": {
        "type": "object",
        "required": [
          "test_ref",
          "oracle_ref",
          "verdict"
        ],
        "properties": {
          "test_ref": {
            "type": "string"
          },
          "oracle_ref": {
            "type": "string"
          },
          "verdict": {
            "enum": [
              "PASS",
              "FAIL",
              "HOLD",
              "UNKNOWN"
            ]
          }
        },
        "additionalProperties": false
      }
    },
    "environment": {
      "type": "object",
      "minProperties": 1
    },
    "producer": {
      "type": "string",
      "minLength": 1
    },
    "checker": {
      "type": "string",
      "minLength": 1
    },
    "started_at": {
      "type": "string",
      "format": "date-time"
    },
    "ended_at": {
      "type": "string",
      "format": "date-time"
    },
    "checksums": {
      "type": "array",
      "minItems": 1,
      "items": {
        "type": "string",
        "pattern": "^[A-Fa-f0-9]{64}$"
      }
    },
    "approval_ref": {
      "type": [
        "string",
        "null"
      ]
    },
    "rollback_residue_result": {
      "type": "string",
      "minLength": 1
    },
    "redaction_record": {
      "type": "object",
      "required": [
        "secrets_redacted",
        "redaction_policy_ref"
      ],
      "properties": {
        "secrets_redacted": {
          "type": "boolean"
        },
        "redaction_policy_ref": {
          "type": "string",
          "minLength": 1
        }
      },
      "additionalProperties": false
    },
    "retention": {
      "type": "object",
      "required": [
        "retention_class",
        "expires_at"
      ],
      "properties": {
        "retention_class": {
          "type": "string",
          "minLength": 1
        },
        "expires_at": {
          "type": "string",
          "format": "date-time"
        }
      },
      "additionalProperties": false
    },
    "replay_freshness": {
      "type": "object",
      "required": [
        "generated_at",
        "fresh_until",
        "replay_key"
      ],
      "properties": {
        "generated_at": {
          "type": "string",
          "format": "date-time"
        },
        "fresh_until": {
          "type": "string",
          "format": "date-time"
        },
        "replay_key": {
          "type": "string",
          "minLength": 1
        }
      },
      "additionalProperties": false
    }
  }
}
```

Minimum return denominator therefore includes, explicitly and machine-addressably:

```text
subject/version/hash
changed artifacts + checksums
commands/actions
stdout/stderr/exit-equivalent or raw action-result refs
verification/test/oracle verdicts
environment
producer/checker
start/end timestamp
approval reference
rollback/compensation/residue result
redaction record
retention metadata
freshness/replay key
```

Secret handling: raw secrets MUST be redacted before evidence persistence; evidence stores secret handles/identifiers and redaction receipts, not secret values. Summary-only evidence cannot replace raw/verifiable references. First failing oracle/invariant is preserved in the packet rather than overwritten by later successes.

# H1-15｜Currentness / Drift / Invalidation / Replay

Currentness is subject-bound. Any evidence/admission/token/ref from a different subject/version/hash or expired currentness window is ineligible for reuse. Invalidation is **affected-only** through reverse dependencies; unrelated current artifacts remain current.

## 15.1 Drift sources

- subject/version/hash drift;
- repo HEAD/branch/worktree/environment drift;
- receiver capability/trust/currentness drift;
- permission-policy or approval authority drift;
- token expiry/revocation/replay;
- WorkOrder/ECP/TQAEP drift;
- provider/protocol/security/license pin drift;
- stale evidence or changed oracle;
- shared-writer/resource conflict;
- adapter/instruction surface drift.

## 15.2 H1-15A｜P0 six-class change taxonomy + affected-only reaction

| Change class | Canonical trigger family | DOC-05 reaction | Admission effect |
|---|---|---|---|
| `EDITORIAL` | typo/non-semantic prose | regenerate projections; prove no semantic delta | no semantic invalidation |
| `NON_BREAKING_CONTRACT` | additive compatible contract / tests / provider success event | recompile direct consumers; retest affected | affected admission recheck only if predicate touched |
| `BREAKING_CONTRACT` | requirement/acceptance/architecture/interface semantic change | reopen PI; reverse-dependency invalidation | invalidate affected admissions/handoffs |
| `SECURITY_CURRENTNESS` | advisory/license/tool/provider/protocol trust drift | HOLD affected TechnologyAdmission/currentness/evidence | mark validity `STALE`; re-adjudicate before ADMIT/use |
| `RUNTIME_BINDING_DRIFT` | repo HEAD/provider/version/env/adapter/token binding drift | rebind PD / rediscover scoped instructions / refresh token | invalidate exact affected admission/WorkOrder/ECP refs |
| `EMERGENCY_CHANGE` | incident/partial/conflicting effect requiring bounded mutation | emergency authority path + post-change readback/reconciliation | separate emergency ADMIT; no reuse of stale normal admission |

Replay rule: a consumed approval nonce, expired `AdmissionValidityRecord`, or admission whose subject/currentness refs changed MUST fail closed. New evidence cannot retroactively validate a past attempt against a different subject tuple.

# H1-16｜Vertical Slice / Concurrency / Brownfield Admission

## 16.1 Independent vertical-slice admission

A slice may be admitted without waiting for all PI/PD packages when:

1. all dependencies of that slice are closed/current;
2. its PI contract is current;
3. its PD binding is `PREDEV_READY`;
4. shared writers/resources have no unresolved collision;
5. its receiver accepts the handoff;
6. its WorkOrder/ECP/TQAEP/currentness/rollback/evidence route are complete;
7. its own ApprovalToken is valid if required;
8. separate admission authority issues `ADMIT`.

Unrelated slices may remain in PI/PD.

## 16.2 Concurrency controls

| Conflict | Rule |
|---|---|
| same canonical writer/path | serialize or partition explicitly; concurrent write without partition → HOLD |
| shared provider/account quota | bind quota/resource lock; unresolved contention → HOLD |
| shared migration state | use wave/cutover lock; no overlapping cutover |
| shared permission/token | token must explicitly cover each subject/scope; never infer transitive authority |
| cross-slice dependency changed | invalidate only dependent admissions |

## 16.3 Brownfield admission sequence

```text
incumbent inventory + behavior freeze
→ semantic/contract diff
→ adapter/seam
→ read-only/shadow
→ bounded pilot
→ parity + negative + security oracles
→ promotion decision
→ affected-only cutover
→ rollback window
→ decommission
→ residue/readback proof
```

Incumbent rollback remains until parity/admission closure. "New path looks healthy" is insufficient for decommission.

Each wave requires its own receiver acceptance and, for effectful cutover, its own current admission.

# H1-17｜Machine Schema / Semantic Validator / Prose-Machine Equivalence

## 17.1 P1 canonical schema references — consumed, not redefined

| Schema | Canonical ID | DOC-05 use |
|---|---|---|
| `approval-token.schema.json` | `urn:pipd:canonical-standard:1.1:schema:approval-token` | approval structure |
| `handoff.schema.json` | `urn:pipd:canonical-standard:1.1:schema:handoff` | canonical ExecutionHandoff |
| `execution-admission.schema.json` | `urn:pipd:canonical-standard:1.1:schema:execution-admission` | canonical admission |
| `effect-intent.schema.json` | `urn:pipd:canonical-standard:1.1:schema:effect-intent` | declared effect intent |
| `effect-observation.schema.json` | `urn:pipd:canonical-standard:1.1:schema:effect-observation` | observed effect facts |
| `effect-reconciliation.schema.json` | `urn:pipd:canonical-standard:1.1:schema:effect-reconciliation` | world-effect reconciliation |

## 17.2 H1-17A｜P0 Project-Control Machine Bindings

DOC-05 admission MUST resolve these P0 schemas rather than restating their truth:

| P0 schema | Canonical `$id` | Admission dependency |
|---|---|---|
| project-manifest.schema.json | urn:pipd:blueprint:1.1.0-r2:schema:project-manifest | profile/claim/project control facts; admission reads only exact project binding |
| permission-policy.schema.json | urn:pipd:blueprint:1.1.0-r2:schema:permission-policy | default DENY, pre-admission forbidden, secret/network/high-risk policy |
| change-policy.schema.json | urn:pipd:blueprint:1.1.0-r2:schema:change-policy | six change classes + reverse-dependency affected-only algorithm |
| degrade-policy.schema.json | urn:pipd:blueprint:1.1.0-r2:schema:degrade-policy | lifecycle/degrade/decision/claim namespace separation |
| currentness-record.schema.json | urn:pipd:blueprint:1.1.0-r2:schema:currentness-record | TTL/security/license/provider currentness bound to admission validity |
| adapter-profile.schema.json | urn:pipd:blueprint:1.1.0-r2:schema:adapter-profile | trigger/non-trigger/permission/effect/currentness/exit facts for adapters |
| package-index.schema.json | urn:pipd:blueprint:1.1.0-r2:schema:package-index | package identity/dependency/state refs used by receiver and invalidation |

At minimum `permission-policy`, `currentness-record`, `change-policy`, and `package-index` are mandatory admission dependencies. `project-manifest`, `adapter-profile`, and `degrade-policy` are mandatory whenever the corresponding project/profile/adapter/degrade fact participates in the decision.

## 17.3 H1-17B｜DOC-05 extension schemas — versioned and enforceable

These schemas are DOC-05-owned sidecars. They may bind canonical objects but cannot weaken or mutate P0/P1 schemas.

### 17.3.1 ReceiverDecision
```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "urn:pipd:doc05:1.1.0-r2:schema:receiver-decision",
  "title": "ReceiverDecision",
  "type": "object",
  "additionalProperties": false,
  "required": [
    "receiver_decision_id",
    "handoff_bundle_ref",
    "canonical_handoff_ref",
    "subject_ref",
    "receiver",
    "decision",
    "reason_codes",
    "evaluated_at",
    "checker"
  ],
  "properties": {
    "receiver_decision_id": {
      "type": "string",
      "minLength": 1
    },
    "handoff_bundle_ref": {
      "type": "string",
      "minLength": 1
    },
    "canonical_handoff_ref": {
      "type": "string",
      "minLength": 1
    },
    "subject_ref": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "id",
        "version",
        "hash"
      ],
      "properties": {
        "id": {
          "type": "string",
          "minLength": 1
        },
        "version": {
          "type": "string",
          "minLength": 1
        },
        "hash": {
          "type": "string",
          "pattern": "^[A-Fa-f0-9]{64}$"
        }
      }
    },
    "receiver": {
      "type": "string",
      "minLength": 1
    },
    "decision": {
      "enum": [
        "ACCEPT_HANDOFF",
        "NACK",
        "HOLD",
        "DENY"
      ]
    },
    "reason_codes": {
      "type": "array",
      "minItems": 1,
      "uniqueItems": true,
      "items": {
        "type": "string",
        "minLength": 1
      }
    },
    "evaluated_at": {
      "type": "string",
      "format": "date-time"
    },
    "checker": {
      "type": "string",
      "minLength": 1
    }
  }
}
```

### 17.3.2 PermissionEffectDecision
```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "urn:pipd:doc05:1.1.0-r2:schema:permission-effect-decision",
  "title": "PermissionEffectDecision",
  "type": "object",
  "additionalProperties": false,
  "required": [
    "decision_id",
    "subject_ref",
    "permission_class",
    "policy_result",
    "risk_class",
    "effect_class",
    "approval_required",
    "rollback_required",
    "readback_required",
    "evidence_depth",
    "policy_ref",
    "currentness_refs",
    "evaluated_at"
  ],
  "properties": {
    "decision_id": {
      "type": "string",
      "minLength": 1
    },
    "subject_ref": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "id",
        "version",
        "hash"
      ],
      "properties": {
        "id": {
          "type": "string",
          "minLength": 1
        },
        "version": {
          "type": "string",
          "minLength": 1
        },
        "hash": {
          "type": "string",
          "pattern": "^[A-Fa-f0-9]{64}$"
        }
      }
    },
    "permission_class": {
      "enum": [
        "READ_ONLY",
        "LOCAL_ARTIFACT_WRITE",
        "REPO_WRITE",
        "NETWORK",
        "INSTALL",
        "SECRET_READ",
        "PROVIDER_BIND",
        "DEPLOY",
        "MIGRATE",
        "ROLLBACK",
        "PRODUCTION_CHANGE"
      ]
    },
    "policy_result": {
      "enum": [
        "ALLOW_CANDIDATE",
        "HOLD",
        "DENY"
      ]
    },
    "risk_class": {
      "enum": [
        "LOW",
        "MEDIUM",
        "HIGH",
        "CRITICAL"
      ]
    },
    "effect_class": {
      "enum": [
        "NONE",
        "READ_ONLY",
        "REVERSIBLE_WRITE",
        "EXTERNAL_EFFECT",
        "HIGH_RISK_EFFECT"
      ]
    },
    "approval_required": {
      "type": "boolean"
    },
    "rollback_required": {
      "type": "boolean"
    },
    "readback_required": {
      "type": "boolean"
    },
    "evidence_depth": {
      "enum": [
        "MINIMAL",
        "STANDARD",
        "ASSURED"
      ]
    },
    "policy_ref": {
      "type": "string",
      "minLength": 1
    },
    "currentness_refs": {
      "type": "array",
      "minItems": 1,
      "items": {
        "type": "string",
        "minLength": 1
      }
    },
    "evaluated_at": {
      "type": "string",
      "format": "date-time"
    }
  }
}
```

### 17.3.3 AdmissionInvalidationRecord
```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "urn:pipd:doc05:1.1.0-r2:schema:admission-invalidation-record",
  "title": "AdmissionInvalidationRecord",
  "type": "object",
  "additionalProperties": false,
  "required": [
    "record_id",
    "admission_ref",
    "change_class",
    "trigger",
    "affected_refs",
    "previous_status",
    "new_status",
    "invalidated_at",
    "owner",
    "required_recheck"
  ],
  "properties": {
    "record_id": {
      "type": "string",
      "minLength": 1
    },
    "admission_ref": {
      "type": "string",
      "minLength": 1
    },
    "change_class": {
      "enum": [
        "EDITORIAL",
        "NON_BREAKING_CONTRACT",
        "BREAKING_CONTRACT",
        "SECURITY_CURRENTNESS",
        "RUNTIME_BINDING_DRIFT",
        "EMERGENCY_CHANGE"
      ]
    },
    "trigger": {
      "type": "string",
      "minLength": 1
    },
    "affected_refs": {
      "type": "array",
      "minItems": 1,
      "items": {
        "type": "string",
        "minLength": 1
      }
    },
    "previous_status": {
      "enum": [
        "CURRENT",
        "STALE",
        "INVALIDATED"
      ]
    },
    "new_status": {
      "enum": [
        "STALE",
        "INVALIDATED"
      ]
    },
    "invalidated_at": {
      "type": "string",
      "format": "date-time"
    },
    "owner": {
      "type": "string",
      "minLength": 1
    },
    "required_recheck": {
      "type": "array",
      "minItems": 1,
      "items": {
        "type": "string",
        "minLength": 1
      }
    }
  }
}
```

### 17.3.4 ReceiverHandoffBundle
```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "urn:pipd:doc05:1.1.0-r2:schema:receiver-handoff-bundle",
  "title": "ReceiverHandoffBundle",
  "type": "object",
  "additionalProperties": false,
  "required": [
    "bundle_id",
    "canonical_handoff_ref",
    "producer",
    "subject_ref",
    "payload_refs",
    "pi_refs",
    "pd_refs",
    "work_order_refs",
    "ecp_refs",
    "tqaep_refs",
    "currentness_refs",
    "why",
    "what",
    "where",
    "how",
    "stop_conditions",
    "nack_reason_vocabulary",
    "invalidation_triggers",
    "evidence_return_contract_ref",
    "created_at"
  ],
  "properties": {
    "bundle_id": {
      "type": "string",
      "minLength": 1
    },
    "canonical_handoff_ref": {
      "type": "string",
      "minLength": 1
    },
    "producer": {
      "type": "string",
      "minLength": 1
    },
    "subject_ref": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "id",
        "version",
        "hash"
      ],
      "properties": {
        "id": {
          "type": "string",
          "minLength": 1
        },
        "version": {
          "type": "string",
          "minLength": 1
        },
        "hash": {
          "type": "string",
          "pattern": "^[A-Fa-f0-9]{64}$"
        }
      }
    },
    "payload_refs": {
      "type": "array",
      "minItems": 1,
      "items": {
        "type": "string",
        "minLength": 1
      }
    },
    "pi_refs": {
      "type": "array",
      "minItems": 1,
      "items": {
        "type": "string",
        "minLength": 1
      }
    },
    "pd_refs": {
      "type": "array",
      "minItems": 1,
      "items": {
        "type": "string",
        "minLength": 1
      }
    },
    "work_order_refs": {
      "type": "array",
      "minItems": 1,
      "items": {
        "type": "string",
        "minLength": 1
      }
    },
    "ecp_refs": {
      "type": "array",
      "minItems": 1,
      "items": {
        "type": "string",
        "minLength": 1
      }
    },
    "tqaep_refs": {
      "type": "array",
      "minItems": 1,
      "items": {
        "type": "string",
        "minLength": 1
      }
    },
    "currentness_refs": {
      "type": "array",
      "minItems": 1,
      "items": {
        "type": "string",
        "minLength": 1
      }
    },
    "stop_conditions": {
      "type": "array",
      "minItems": 1,
      "items": {
        "type": "string",
        "minLength": 1
      }
    },
    "nack_reason_vocabulary": {
      "type": "array",
      "minItems": 1,
      "items": {
        "type": "string",
        "minLength": 1
      }
    },
    "invalidation_triggers": {
      "type": "array",
      "minItems": 1,
      "items": {
        "type": "string",
        "minLength": 1
      }
    },
    "why": {
      "type": "string",
      "minLength": 1
    },
    "what": {
      "type": "string",
      "minLength": 1
    },
    "where": {
      "type": "string",
      "minLength": 1
    },
    "how": {
      "type": "string",
      "minLength": 1
    },
    "evidence_return_contract_ref": {
      "type": "string",
      "minLength": 1
    },
    "created_at": {
      "type": "string",
      "format": "date-time"
    }
  }
}
```

### 17.3.5 ExecutionEvidenceReturnPacket
```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "urn:pipd:doc05:1.1.0-r2:schema:evidence-return-packet",
  "title": "ExecutionEvidenceReturnPacket",
  "type": "object",
  "additionalProperties": false,
  "required": [
    "packet_id",
    "subject_ref",
    "changed_artifacts",
    "actions",
    "raw_results",
    "oracle_verdicts",
    "environment",
    "producer",
    "checker",
    "started_at",
    "ended_at",
    "checksums",
    "approval_ref",
    "rollback_residue_result",
    "redaction_record",
    "retention",
    "replay_freshness"
  ],
  "properties": {
    "packet_id": {
      "type": "string",
      "minLength": 1
    },
    "subject_ref": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "id",
        "version",
        "hash"
      ],
      "properties": {
        "id": {
          "type": "string",
          "minLength": 1
        },
        "version": {
          "type": "string",
          "minLength": 1
        },
        "hash": {
          "type": "string",
          "pattern": "^[A-Fa-f0-9]{64}$"
        }
      }
    },
    "changed_artifacts": {
      "type": "array",
      "items": {
        "type": "object",
        "required": [
          "ref",
          "sha256"
        ],
        "properties": {
          "ref": {
            "type": "string",
            "minLength": 1
          },
          "sha256": {
            "type": "string",
            "pattern": "^[A-Fa-f0-9]{64}$"
          }
        },
        "additionalProperties": false
      }
    },
    "actions": {
      "type": "array",
      "minItems": 1,
      "items": {
        "type": "string",
        "minLength": 1
      }
    },
    "raw_results": {
      "type": "array",
      "minItems": 1,
      "items": {
        "type": "object",
        "required": [
          "action_ref",
          "result_ref",
          "exit_equivalent"
        ],
        "properties": {
          "action_ref": {
            "type": "string"
          },
          "result_ref": {
            "type": "string"
          },
          "exit_equivalent": {
            "type": [
              "string",
              "integer"
            ]
          }
        },
        "additionalProperties": false
      }
    },
    "oracle_verdicts": {
      "type": "array",
      "minItems": 1,
      "items": {
        "type": "object",
        "required": [
          "test_ref",
          "oracle_ref",
          "verdict"
        ],
        "properties": {
          "test_ref": {
            "type": "string"
          },
          "oracle_ref": {
            "type": "string"
          },
          "verdict": {
            "enum": [
              "PASS",
              "FAIL",
              "HOLD",
              "UNKNOWN"
            ]
          }
        },
        "additionalProperties": false
      }
    },
    "environment": {
      "type": "object",
      "minProperties": 1
    },
    "producer": {
      "type": "string",
      "minLength": 1
    },
    "checker": {
      "type": "string",
      "minLength": 1
    },
    "started_at": {
      "type": "string",
      "format": "date-time"
    },
    "ended_at": {
      "type": "string",
      "format": "date-time"
    },
    "checksums": {
      "type": "array",
      "minItems": 1,
      "items": {
        "type": "string",
        "pattern": "^[A-Fa-f0-9]{64}$"
      }
    },
    "approval_ref": {
      "type": [
        "string",
        "null"
      ]
    },
    "rollback_residue_result": {
      "type": "string",
      "minLength": 1
    },
    "redaction_record": {
      "type": "object",
      "required": [
        "secrets_redacted",
        "redaction_policy_ref"
      ],
      "properties": {
        "secrets_redacted": {
          "type": "boolean"
        },
        "redaction_policy_ref": {
          "type": "string",
          "minLength": 1
        }
      },
      "additionalProperties": false
    },
    "retention": {
      "type": "object",
      "required": [
        "retention_class",
        "expires_at"
      ],
      "properties": {
        "retention_class": {
          "type": "string",
          "minLength": 1
        },
        "expires_at": {
          "type": "string",
          "format": "date-time"
        }
      },
      "additionalProperties": false
    },
    "replay_freshness": {
      "type": "object",
      "required": [
        "generated_at",
        "fresh_until",
        "replay_key"
      ],
      "properties": {
        "generated_at": {
          "type": "string",
          "format": "date-time"
        },
        "fresh_until": {
          "type": "string",
          "format": "date-time"
        },
        "replay_key": {
          "type": "string",
          "minLength": 1
        }
      },
      "additionalProperties": false
    }
  }
}
```

### 17.3.6 AdmissionValidityRecord
```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "urn:pipd:doc05:1.1.0-r2:schema:admission-validity-record",
  "title": "AdmissionValidityRecord",
  "type": "object",
  "additionalProperties": false,
  "required": [
    "validity_id",
    "admission_ref",
    "subject_ref",
    "valid_from",
    "expires_at",
    "currentness_record_refs",
    "invalidation_triggers",
    "status",
    "evaluated_at",
    "checker"
  ],
  "properties": {
    "validity_id": {
      "type": "string",
      "minLength": 1
    },
    "admission_ref": {
      "type": "string",
      "minLength": 1
    },
    "subject_ref": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "id",
        "version",
        "hash"
      ],
      "properties": {
        "id": {
          "type": "string",
          "minLength": 1
        },
        "version": {
          "type": "string",
          "minLength": 1
        },
        "hash": {
          "type": "string",
          "pattern": "^[A-Fa-f0-9]{64}$"
        }
      }
    },
    "valid_from": {
      "type": "string",
      "format": "date-time"
    },
    "expires_at": {
      "type": "string",
      "format": "date-time"
    },
    "currentness_record_refs": {
      "type": "array",
      "minItems": 1,
      "items": {
        "type": "string",
        "minLength": 1
      }
    },
    "invalidation_triggers": {
      "type": "array",
      "minItems": 1,
      "items": {
        "type": "string",
        "minLength": 1
      }
    },
    "status": {
      "enum": [
        "CURRENT",
        "STALE",
        "INVALIDATED"
      ]
    },
    "evaluated_at": {
      "type": "string",
      "format": "date-time"
    },
    "checker": {
      "type": "string",
      "minLength": 1
    }
  }
}
```

### 17.3.7 ApprovalTokenBindingRecord
```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "urn:pipd:doc05:1.1.0-r2:schema:approval-token-binding-record",
  "title": "ApprovalTokenBindingRecord",
  "type": "object",
  "additionalProperties": false,
  "required": [
    "binding_id",
    "token_ref",
    "token_digest",
    "handoff_ref",
    "admission_ref",
    "nonce",
    "nonce_state",
    "store_ref",
    "subject_hash",
    "operation",
    "target_system",
    "scope_digest",
    "issued_at",
    "expiry",
    "consumed_at",
    "revoked_at",
    "revocation_reason"
  ],
  "properties": {
    "binding_id": {
      "type": "string",
      "minLength": 1
    },
    "token_ref": {
      "type": "string",
      "minLength": 1
    },
    "token_digest": {
      "type": "string",
      "pattern": "^[A-Fa-f0-9]{64}$"
    },
    "handoff_ref": {
      "type": "string",
      "minLength": 1
    },
    "admission_ref": {
      "type": "string",
      "minLength": 1
    },
    "nonce": {
      "type": "string",
      "minLength": 1
    },
    "nonce_state": {
      "enum": [
        "ISSUED",
        "CONSUMED",
        "REVOKED",
        "EXPIRED"
      ]
    },
    "store_ref": {
      "type": "string",
      "minLength": 1
    },
    "subject_hash": {
      "type": "string",
      "pattern": "^[A-Fa-f0-9]{64}$"
    },
    "operation": {
      "type": "string",
      "minLength": 1
    },
    "target_system": {
      "type": "string",
      "minLength": 1
    },
    "scope_digest": {
      "type": "string",
      "pattern": "^[A-Fa-f0-9]{64}$"
    },
    "issued_at": {
      "type": "string",
      "format": "date-time"
    },
    "expiry": {
      "type": "string",
      "format": "date-time"
    },
    "consumed_at": {
      "type": [
        "string",
        "null"
      ],
      "format": "date-time"
    },
    "revoked_at": {
      "type": [
        "string",
        "null"
      ],
      "format": "date-time"
    },
    "revocation_reason": {
      "type": [
        "string",
        "null"
      ]
    }
  }
}
```

### 17.3.8 AgentHarnessAdmissionProfile
```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "urn:pipd:doc05:1.1.0-r2:schema:agent-harness-admission-profile",
  "title": "AgentHarnessAdmissionProfile",
  "type": "object",
  "additionalProperties": false,
  "required": [
    "profile_id",
    "subject_ref",
    "harness_ref",
    "tool_registry_ref",
    "state_memory_ref",
    "handoff_redaction_ref",
    "human_escalation_ref",
    "threat_model_ref",
    "effect_reconciliation_ref",
    "adversarial_fixture_refs",
    "currentness_refs"
  ],
  "properties": {
    "profile_id": {
      "type": "string",
      "minLength": 1
    },
    "subject_ref": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "id",
        "version",
        "hash"
      ],
      "properties": {
        "id": {
          "type": "string",
          "minLength": 1
        },
        "version": {
          "type": "string",
          "minLength": 1
        },
        "hash": {
          "type": "string",
          "pattern": "^[A-Fa-f0-9]{64}$"
        }
      }
    },
    "harness_ref": {
      "type": "string",
      "minLength": 1
    },
    "tool_registry_ref": {
      "type": "string",
      "minLength": 1
    },
    "state_memory_ref": {
      "type": "string",
      "minLength": 1
    },
    "handoff_redaction_ref": {
      "type": "string",
      "minLength": 1
    },
    "human_escalation_ref": {
      "type": "string",
      "minLength": 1
    },
    "threat_model_ref": {
      "type": "string",
      "minLength": 1
    },
    "effect_reconciliation_ref": {
      "type": "string",
      "minLength": 1
    },
    "adversarial_fixture_refs": {
      "type": "array",
      "minItems": 8,
      "maxItems": 8,
      "uniqueItems": true,
      "items": {
        "type": "string",
        "pattern": "^TEST-AH-ADV-00[1-8]$"
      }
    },
    "currentness_refs": {
      "type": "array",
      "minItems": 1,
      "items": {
        "type": "string",
        "minLength": 1
      }
    }
  }
}
```

## 17.4 Schema version / migration / supersession rule

All extension `$id`s are pinned to `1.1.0-r2`. A field/enum semantic change requires a new schema revision and `BREAKING_CONTRACT` invalidation of affected consumers; additive compatible fields require `NON_BREAKING_CONTRACT`. An old extension instance is not silently upgraded. Migration emits old/new schema IDs, subject hash, changed fields, migration checker and reverse-dependent invalidation result.

## 17.5 H1-17C｜Semantic Validator Registry ABI

Critical registries are typed interfaces, not an unspecified `registries` bag:

| Registry | Lookup key | Minimum return | Persistence / atomicity | Blocking failure codes |
|---|---|---|---|---|
| `SubjectRegistry` | subject id | version, hash, lifecycle state, invalidated_by | durable, versioned | `SUBJECT_NOT_FOUND`, `SUBJECT_HASH_MISMATCH`, `SUBJECT_INVALIDATED` |
| `ReceiverRegistry` | receiver id | capability set, trust/profile, currentness, owner | durable; currentness timestamped | `RECEIVER_UNKNOWN`, `RECEIVER_STALE`, `RECEIVER_CAPABILITY_MISSING` |
| `PermissionPolicyRegistry` | policy id | validated P0 permission-policy instance | immutable by content hash | `POLICY_MISSING`, `PERMISSION_DENY`, `UNKNOWN_RESOURCE` |
| `ApprovalTokenStore` | token id | canonical token bytes, digest, nonce state, revoked flag | durable; nonce CAS atomic | `TOKEN_NOT_FOUND`, `TOKEN_DIGEST_MISMATCH`, `NONCE_ALREADY_USED`, `TOKEN_REVOKED`, `TOKEN_EXPIRED` |
| `ApproverAuthorityRegistry` | approver + operation/data/risk | allowed authority + SoD constraints | durable; versioned | `APPROVER_UNAUTHORIZED`, `SOD_VIOLATION` |
| `CurrentnessRegistry` | currentness ref | subject, checked_at, expires_at, security/license/provider state | durable; TTL authoritative | `CURRENTNESS_MISSING`, `CURRENTNESS_EXPIRED`, `SECURITY_CURRENTNESS_STALE` |
| `DependencyGraph` | artifact/ref | direct + reverse dependents | durable; atomic update with invalidation record | `DEPENDENCY_UNKNOWN`, `REVERSE_INVALIDATION_FAILED` |
| `EvidenceRegistry` | evidence ref | subject tuple, checker, oracle, checksums, freshness | durable + immutable receipt | `EVIDENCE_MISSING`, `EVIDENCE_FOREIGN_SUBJECT`, `EVIDENCE_STALE` |
| `TimeAuthority` | `now()` | UTC instant + source | monotonic/controlled | `TIME_UNTRUSTED` |

## 17.6 Deterministic first-failing-invariant ABI

```text
01 SOURCE_IDENTITY_CURRENT
02 HANDOFF_SCHEMA_VALID
03 HANDOFF_BUNDLE_COMPLETE
04 RECEIVER_MATCH_CURRENT_CAPABLE
05 REQUIRED_REFS_RESOLVE
06 PERMISSION_POLICY_RESOLVED
07 UNKNOWN_RESOURCE_DEFAULT_DENY
08 SCOPE_PERMISSION_MATCH
09 ROLLBACK_EVIDENCE_ROUTE_COMPLETE
10 APPROVAL_TOKEN_JOIN_VALID_IF_REQUIRED
11 NONCE_ATOMIC_CONSUMPTION
12 SOD_VALID
13 ADMISSION_NON_HOLLOW
14 ADMISSION_VALIDITY_CURRENT
15 AGENT_HARNESS_PROFILE_COMPLETE_IF_APPLICABLE
16 EFFECT_CHAIN_READY_IF_EFFECTFUL
```

The validator returns `{failure_class, failure_code, first_failing_invariant, subject_ref, affected_refs, recovery}` and stops on the first blocker. Later checks cannot mask an earlier failure.

## 17.7 Agent Harness typed admission closure

For `PROFILE-AGENT-HARNESS`, STANDARD/ASSURED admission requires one `AgentHarnessAdmissionProfile` with typed refs for tool registry, state/memory trust+expiry, handoff/redaction, Human escalation, threat model, effect reconciliation, and exactly eight adversarial fixtures `TEST-AH-ADV-001..008`. Missing any one is `HOLD/AGENT_HARNESS_ASSURANCE_INCOMPLETE`.

## 17.8 Author-side schema meta-validation receipt

| Schema | Result |
|---|---|
| ReceiverDecision | SCHEMA_META_VALID |
| PermissionEffectDecision | SCHEMA_META_VALID |
| AdmissionInvalidationRecord | SCHEMA_META_VALID |
| ReceiverHandoffBundle | SCHEMA_META_VALID |
| ExecutionEvidenceReturnPacket | SCHEMA_META_VALID |
| AdmissionValidityRecord | SCHEMA_META_VALID |
| ApprovalTokenBindingRecord | SCHEMA_META_VALID |
| AgentHarnessAdmissionProfile | SCHEMA_META_VALID |

This receipt proves only that the embedded extension schemas are syntactically valid Draft 2020-12 schemas in the authoring environment. It does not prove target-repo installation or runtime execution.

# H1-18｜Technology / Capability / Workflow Landing & 2026 Currentness

Technology admission remains owned by DOC-02. DOC-05 performs a receiver/permission/admission/effect landing only. Presence in this section is **not** installation, binding, enablement, execution, verification, acceptance, or production adoption.

## 18.1 Anti-overpromotion rule

`anti-downgrade` means no named capability or source disposition may be silently lost or softened. It does **not** mean every donor must be materialized. For every Layer-A candidate:

```text
canonical_disposition = P0/P1 authority
project_design_treatment = lower-order P2 materialization treatment, never a replacement disposition
applicability = trigger/non-trigger + project need
portable_core_dependency = false
project runtime materialization = only after applicable + DOC-02 project TechnologyAdmission terminal selection + currentness/license/security + host binding
```

## 18.2 H1-18A｜Layer-A 22/22 authority-correct disposition crosswalk

Nine r1 drifts are repaired by restoring the P0/P1 disposition while retaining P2 `SELECTED_*` only as `project_design_treatment`.

| ID | Candidate | Canonical disposition (P0/P1) | P2 design treatment | Trigger | Non-trigger | Portable core dep | DOC-05 permission/effect delta | Unique validation fixture | Provider-off/exit | Project instance state |
|---|---|---|---|---|---|---|---|---|---|---|
| CAND-01 | GPT-5.6 Sol | `ADOPT` | `ADOPT` | Need requires high-quality synthesis/review | Deterministic/local-only task | false | READ_ONLY + LOCAL_ARTIFACT_WRITE only | TEST-PRT-001/OR-PRT-001: alternate model/human parity | provider-off leaves canonical artifacts readable | UNBOUND_PROJECT_INSTANCE |
| CAND-02 | OpenAI Codex / Agents SDK harness patterns | `ADOPT_WITH_WRAPPER` | `ADOPT_WITH_WRAPPER` | Admitted WorkOrder needs coding/execution harness | Planning-only or no repo/runtime action | false | REPO_WRITE only after current ADMIT | TEST-BND-001/OR-BND-001: pre-ADMIT mutation denied | route out harness; preserve repo state + evidence | UNBOUND_PROJECT_INSTANCE |
| CAND-03 | AGENTS.md | `ADOPT_WITH_TRANSLATION` | `ADOPT_WITH_TRANSLATION` | Repository agent needs scoped read/navigation rules | No repository agent surface | false | READ_ONLY by default; adapter grants nothing | TEST-PRT-002/OR-PRT-002: conflicting adapter cannot override canonical | delete projection; direct canonical package read | UNBOUND_PROJECT_INSTANCE |
| CAND-04 | OpenSpec | `ADOPT_WITH_WRAPPER` | `SELECTED_TRANSLATE` | Team already uses proposal/spec/design/tasks flow | Would create a second lifecycle SSOT | false | LOCAL_ARTIFACT_WRITE only | TEST-CMP-001/OR-CMP-001: proposal/spec/design/tasks mapping | uninstall adapter; retain PIPD truth | UNBOUND_PROJECT_INSTANCE |
| CAND-05 | GitHub Spec Kit | `ADOPT_WITH_WRAPPER` | `SELECTED_WRAP` | Team wants Constitution/Specify/Plan/Tasks ergonomics | PIPD already sufficient and donor adds duplicate truth | false | LOCAL_ARTIFACT_WRITE only | TEST-CMP-001/OR-CMP-001: Specify/Plan/Tasks translation | remove workflow files; retain PIPD artifacts | UNBOUND_PROJECT_INSTANCE |
| CAND-06 | Model Context Protocol (MCP) | `ADOPT_WITH_TRANSLATION` | `SELECTED_TRANSLATE` | Agent needs standardized tool/context connection | No cross-process tool/context requirement | false | NETWORK/tool scope exact; unknown target DENY | TEST-BND-003/OR-BND-003: protocol success cannot widen permission/effect truth | provider-off + adapter removal | UNBOUND_PROJECT_INSTANCE |
| CAND-07 | A2A Protocol | `ADOPT_WITH_TRANSLATION` | `SELECTED_TRANSLATE` | Cross-agent delegation/interoperability required | Single-agent/local workflow | false | NETWORK scoped; remote receiver inherits no local authority | TEST-BND-003/OR-BND-003: remote agent cannot self-admit | remove remote agent; local queue fallback | UNBOUND_PROJECT_INSTANCE |
| CAND-08 | OpenTelemetry GenAI semantic conventions | `ADOPT_WITH_TRANSLATION` | `SELECTED_TRANSLATE` | Agent/System profile needs interoperable traces | No telemetry consumer or LITE no-op | false | OBSERVE only; telemetry has no mutation authority | TEST-PRT-001/OR-PRT-001: telemetry is observation, not acceptance | switch/off backend without losing canonical evidence | UNBOUND_PROJECT_INSTANCE |
| CAND-09 | Pi Coding Agent / pi-mono | `EVAL_ONLY` | `EVAL_ONLY` | Evaluate multi-provider coding harness semantics | Production adoption without parity/security review | false | SANDBOX_READ/WRITE only | TEST-PRT-001/OR-PRT-001: parity/security evaluation | discard sandbox/provider-off | UNBOUND_PROJECT_INSTANCE |
| CAND-10 | Superpowers | `ADOPT_WITH_TRANSLATION` | `SELECTED_TRANSLATE` | Selected skill procedure closes a named capability need | Whole methodology would override lifecycle authority | false | per-skill LOCAL_ARTIFACT_WRITE; no methodology-wide authority | TEST-CMP-002/OR-CMP-002: one skill cannot override lifecycle gates | remove selected skill independently | UNBOUND_PROJECT_INSTANCE |
| CAND-11 | gstack | `REFERENCE` | `REFERENCE` | Need comparative review/sequencing patterns | Direct runtime authority | false | READ_ONLY | TEST-RET-001/OR-RET-001: reference remains non-authoritative | no runtime dependency | UNBOUND_PROJECT_INSTANCE |
| CAND-12 | DeepSeek Harness | `EVAL_ONLY` | `EVAL_ONLY` | Compare plugin/service/event model | Production adoption from preview without admission | false | SANDBOX_READ/WRITE only | TEST-PRT-001/OR-PRT-001: preview cannot self-promote | discard sandbox | UNBOUND_PROJECT_INSTANCE |
| CAND-13 | Open GSD / gsd-core | `REFERENCE` | `REFERENCE` | Need fresh-context/planning reference | Would create second PI/PD lifecycle | false | READ_ONLY | TEST-RET-001/OR-RET-001: no second lifecycle | no runtime dependency | UNBOUND_PROJECT_INSTANCE |
| CAND-14 | legacy gsd-build/get-shit-done | `REJECT` | `REJECT` | Regression/history comparison only | Any new-adoption path | false | READ_ONLY provenance only | TEST-E6580324/OR-E6580324: new_adoption=false | no runtime path | UNBOUND_PROJECT_INSTANCE |
| CAND-15 | mattpocock/skills | `ADOPT_WITH_TRANSLATION` | `SELECTED_TRANSLATE` | Specific skill has fit and passes rights/security review | Bulk install without per-skill admission | false | per-skill scoped; effectful permission derives from admitted skill contract | TEST-BND-003/OR-BND-003: Trigger/Compliance/Boundary | uninstall selected skill + residue check | UNBOUND_PROJECT_INSTANCE |
| CAND-16 | Hugging Face Agent Skills | `ADOPT_WITH_TRANSLATION` | `SELECTED_TRANSLATE` | Portable SKILL.md capability matches need | Host/network/package assumptions unresolved | false | per-skill scoped; model/data rights and host permissions explicit | TEST-PRT-001/OR-PRT-001: host compatibility + permission | host-specific uninstall/residue | UNBOUND_PROJECT_INSTANCE |
| CAND-17 | AG-UI | `ADOPT_WITH_TRANSLATION` | `SELECTED_TRANSLATE` | Frontend needs agent event interoperability | No agent UI surface | false | NETWORK scoped + USER_VISIBLE_EFFECT | TEST-PRT-001/OR-PRT-001: UI projection != authority/effect truth | replace protocol adapter | UNBOUND_PROJECT_INSTANCE |
| CAND-18 | NousResearch Hermes Agent | `QUARANTINE` | `QUARANTINE` | Sandbox comparison explicitly approved | Implicit production/repo/secret access | false | SANDBOX_ONLY | TEST-BND-003/OR-BND-003: no repo/secret/prod by default | destroy sandbox/provider-off | UNBOUND_PROJECT_INSTANCE |
| CAND-19 | Cordis | `REFERENCE` | `REFERENCE` | Study revertible/reactive effect semantics | Core dependency on unstable API | false | READ_ONLY | TEST-RET-001/OR-RET-001: reactive effect semantics comparison | no runtime dependency | UNBOUND_PROJECT_INSTANCE |
| CAND-20 | LongHorizon-Harness research | `REFERENCE` | `REFERENCE` | Long-horizon task state/auditor design research | Treat research result as runtime proof | false | READ_ONLY | TEST-PRT-001/OR-PRT-001: hypothesis→local fixture | discard experiment | UNBOUND_PROJECT_INSTANCE |
| CAND-21 | Skill-Use benchmark | `REFERENCE` | `REFERENCE` | Need Trigger/Compliance/Boundary taxonomy | Treat benchmark as product authority | false | READ_ONLY | TEST-TRG-001/OR-TRG-001: Trigger/Compliance/Boundary local fixtures | remove benchmark dependency | UNBOUND_PROJECT_INSTANCE |
| CAND-22 | HarnessRisk benchmark | `REFERENCE` | `REFERENCE` | Need harness lifecycle safety scenarios | Treat benchmark score as release authority | false | READ_ONLY | TEST-BND-003/OR-BND-003: lifecycle attack fixture | remove benchmark dependency | UNBOUND_PROJECT_INSTANCE |

## 18.3 Single machine-loadable Layer-A registry

The 22 entries are serialized once as one registry; there are no 22 independent boilerplate snippets.

```json
{
  "registry_id": "PIPD-DOC05-LAYER-A-22-R2",
  "owner": "DOC-02 TechnologyAdmission; DOC-05 consumes project terminal/currentness refs",
  "defaults": {
    "portable_core_dependency": false,
    "applicability": "CONDITIONAL_BY_TRIGGER_AND_PROJECT_TECHNOLOGY_ADMISSION",
    "project_technology_admission_state": "UNBOUND_PROJECT_INSTANCE",
    "materialization_rule": "ONLY_IF_TRIGGER_APPLIES_AND_DOC02_PROJECT_TECHNOLOGY_ADMISSION_TERMINALLY_SELECTS_USE"
  },
  "entries": [
    {
      "id": "CAND-01",
      "candidate": "GPT-5.6 Sol",
      "source_owner_or_project": "OpenAI",
      "canonical_disposition": "ADOPT",
      "project_design_treatment": "ADOPT",
      "trigger": "Need requires high-quality synthesis/review",
      "non_trigger": "Deterministic/local-only task",
      "inputs": "source bundle; task contract",
      "outputs": "bounded design/research artifact",
      "source_permission": "READ_ONLY, LOCAL_ARTIFACT_WRITE",
      "source_effect": "NO_EXTERNAL_EFFECT",
      "adapter_seam": "Model provider behind package ABI",
      "canonical_test_oracle": "TEST-PRT-001 / OR-PRT-001",
      "canonical_fallback": "alternate admitted model or human",
      "canonical_exit_provider_off": "provider-off keeps canonical artifacts readable",
      "currentness_support": "OpenAI official model page: gpt-5.6 alias → GPT-5.6 Sol; checked 2026-10-06",
      "doc05_permission_effect_rule": "READ_ONLY + LOCAL_ARTIFACT_WRITE only",
      "host_binding_condition": "provider/model alias + task contract bound",
      "doc05_validation_fixture": "TEST-PRT-001/OR-PRT-001: alternate model/human parity",
      "doc05_provider_off_exit": "provider-off leaves canonical artifacts readable",
      "doc05_failure_mode": "provider/model drift or ungrounded provider-only claim"
    },
    {
      "id": "CAND-02",
      "candidate": "OpenAI Codex / Agents SDK harness patterns",
      "source_owner_or_project": "OpenAI",
      "canonical_disposition": "ADOPT_WITH_WRAPPER",
      "project_design_treatment": "ADOPT_WITH_WRAPPER",
      "trigger": "Admitted WorkOrder needs coding/execution harness",
      "non_trigger": "Planning-only or no repo/runtime action",
      "inputs": "WorkOrder; ECP; permission scope",
      "outputs": "changes/evidence through receiver ABI",
      "source_permission": "REPO_WRITE only after ADMIT",
      "source_effect": "REPO_OR_EXTERNAL_EFFECT",
      "adapter_seam": "WorkOrder/ECP/evidence wrapper",
      "canonical_test_oracle": "TEST-BND-001 / OR-BND-001",
      "canonical_fallback": "human/other admitted coding harness",
      "canonical_exit_provider_off": "route-out removable; no semantic lock-in",
      "currentness_support": "OpenAI/Codex + Agents SDK: pin stable tested release/snapshot at PD; alpha lines must not auto-promote; checked 2026-10-06",
      "doc05_permission_effect_rule": "REPO_WRITE only after current ADMIT",
      "host_binding_condition": "exact repo/WorkOrder/ECP/receiver ABI",
      "doc05_validation_fixture": "TEST-BND-001/OR-BND-001: pre-ADMIT mutation denied",
      "doc05_provider_off_exit": "route out harness; preserve repo state + evidence",
      "doc05_failure_mode": "harness attempts repo/secret/network scope beyond admission"
    },
    {
      "id": "CAND-03",
      "candidate": "AGENTS.md",
      "source_owner_or_project": "AGENTS.md project",
      "canonical_disposition": "ADOPT_WITH_TRANSLATION",
      "project_design_treatment": "ADOPT_WITH_TRANSLATION",
      "trigger": "Repository agent needs scoped read/navigation rules",
      "non_trigger": "No repository agent surface",
      "inputs": "Constitution; manifest; PI/PD refs",
      "outputs": "thin nearest-scope instruction projection",
      "source_permission": "READ_ONLY by default",
      "source_effect": "NO_EFFECT",
      "adapter_seam": "generated from canonical AGENTS template",
      "canonical_test_oracle": "TEST-PRT-002 / OR-PRT-002",
      "canonical_fallback": "canonical package direct read",
      "canonical_exit_provider_off": "delete adapter without losing truth",
      "currentness_support": "AGENTS.md is versionless projection; pin generated digest + discovered incumbent hashes at PD",
      "doc05_permission_effect_rule": "READ_ONLY by default; adapter grants nothing",
      "host_binding_condition": "nearest-scope generated digest + incumbent instruction hashes",
      "doc05_validation_fixture": "TEST-PRT-002/OR-PRT-002: conflicting adapter cannot override canonical",
      "doc05_provider_off_exit": "delete projection; direct canonical package read",
      "doc05_failure_mode": "instruction injection or stale nearest-scope projection"
    },
    {
      "id": "CAND-04",
      "candidate": "OpenSpec",
      "source_owner_or_project": "OpenSpec project",
      "canonical_disposition": "ADOPT_WITH_WRAPPER",
      "project_design_treatment": "SELECTED_TRANSLATE",
      "trigger": "Team already uses proposal/spec/design/tasks flow",
      "non_trigger": "Would create a second lifecycle SSOT",
      "inputs": "need/spec/task artifacts",
      "outputs": "translated PIPD refs",
      "source_permission": "LOCAL_ARTIFACT_WRITE",
      "source_effect": "LOCAL_EFFECT",
      "adapter_seam": "proposal/spec/design/tasks→PI/PD translation",
      "canonical_test_oracle": "TEST-CMP-001 / OR-CMP-001",
      "canonical_fallback": "native PIPD templates",
      "canonical_exit_provider_off": "uninstall adapter; preserve canonical packages",
      "currentness_support": "OpenSpec latest observed v1.14.0 (2026-09-30); exact tag/commit at PD",
      "doc05_permission_effect_rule": "LOCAL_ARTIFACT_WRITE only",
      "host_binding_condition": "OpenSpec adapter enabled only when project already uses donor workflow",
      "doc05_validation_fixture": "TEST-CMP-001/OR-CMP-001: proposal/spec/design/tasks mapping",
      "doc05_provider_off_exit": "uninstall adapter; retain PIPD truth",
      "doc05_failure_mode": "donor lifecycle becomes second SSOT or source semantics drift"
    },
    {
      "id": "CAND-05",
      "candidate": "GitHub Spec Kit",
      "source_owner_or_project": "GitHub",
      "canonical_disposition": "ADOPT_WITH_WRAPPER",
      "project_design_treatment": "SELECTED_WRAP",
      "trigger": "Team wants Constitution/Specify/Plan/Tasks ergonomics",
      "non_trigger": "PIPD already sufficient and donor adds duplicate truth",
      "inputs": "feature intent; Constitution constraints",
      "outputs": "mapped PI/PD/task seed artifacts",
      "source_permission": "LOCAL_ARTIFACT_WRITE",
      "source_effect": "LOCAL_EFFECT",
      "adapter_seam": "Spec Kit workflow→PIPD narrow waist",
      "canonical_test_oracle": "TEST-CMP-001 / OR-CMP-001",
      "canonical_fallback": "native PIPD workflow",
      "canonical_exit_provider_off": "remove workflow files; retain PIPD truth",
      "currentness_support": "GitHub Spec Kit latest observed v1.0.6 (2026-09-10); exact tag at PD",
      "doc05_permission_effect_rule": "LOCAL_ARTIFACT_WRITE only",
      "host_binding_condition": "Spec Kit workflow bound to project artifact mapping",
      "doc05_validation_fixture": "TEST-CMP-001/OR-CMP-001: Specify/Plan/Tasks translation",
      "doc05_provider_off_exit": "remove workflow files; retain PIPD artifacts",
      "doc05_failure_mode": "duplicate truth or task flow bypasses admission"
    },
    {
      "id": "CAND-06",
      "candidate": "Model Context Protocol (MCP)",
      "source_owner_or_project": "Model Context Protocol project",
      "canonical_disposition": "ADOPT_WITH_TRANSLATION",
      "project_design_treatment": "SELECTED_TRANSLATE",
      "trigger": "Agent needs standardized tool/context connection",
      "non_trigger": "No cross-process tool/context requirement",
      "inputs": "capability contract; permission policy",
      "outputs": "versioned tool/resource interaction",
      "source_permission": "NETWORK/TOOL scoped",
      "source_effect": "EXTERNAL_EFFECT_POSSIBLE",
      "adapter_seam": "MCP profile→tool registry/permission/effect contracts",
      "canonical_test_oracle": "TEST-BND-003 / OR-BND-003",
      "canonical_fallback": "direct provider adapter",
      "canonical_exit_provider_off": "provider-off + protocol adapter removal",
      "currentness_support": "MCP spec 2026-07-28; explicit protocol revision opt-in/current SDK compatibility check required",
      "doc05_permission_effect_rule": "NETWORK/tool scope exact; unknown target DENY",
      "host_binding_condition": "protocol revision + SDK profile + tool registry + permission policy",
      "doc05_validation_fixture": "TEST-BND-003/OR-BND-003: protocol success cannot widen permission/effect truth",
      "doc05_provider_off_exit": "provider-off + adapter removal",
      "doc05_failure_mode": "protocol revision mismatch, auth downgrade, unregistered tool/resource"
    },
    {
      "id": "CAND-07",
      "candidate": "A2A Protocol",
      "source_owner_or_project": "A2A Project",
      "canonical_disposition": "ADOPT_WITH_TRANSLATION",
      "project_design_treatment": "SELECTED_TRANSLATE",
      "trigger": "Cross-agent delegation/interoperability required",
      "non_trigger": "Single-agent/local workflow",
      "inputs": "bounded delegation; receiver contract",
      "outputs": "Task/Message/Artifact handoff",
      "source_permission": "NETWORK scoped",
      "source_effect": "EXTERNAL_EFFECT_POSSIBLE",
      "adapter_seam": "A2A task/artifact→handoff/evidence ABI",
      "canonical_test_oracle": "TEST-BND-003 / OR-BND-003",
      "canonical_fallback": "local receiver/work queue",
      "canonical_exit_provider_off": "remote agent removal without local authority loss",
      "currentness_support": "A2A Protocol v1.0 stable/production-ready; pin protocol + SDK profile at PD",
      "doc05_permission_effect_rule": "NETWORK scoped; remote receiver inherits no local authority",
      "host_binding_condition": "protocol+SDK profile, receiver identity/trust, bounded delegation",
      "doc05_validation_fixture": "TEST-BND-003/OR-BND-003: remote agent cannot self-admit",
      "doc05_provider_off_exit": "remove remote agent; local queue fallback",
      "doc05_failure_mode": "cross-agent trust leakage or delegated scope widening"
    },
    {
      "id": "CAND-08",
      "candidate": "OpenTelemetry GenAI semantic conventions",
      "source_owner_or_project": "OpenTelemetry project",
      "canonical_disposition": "ADOPT_WITH_TRANSLATION",
      "project_design_treatment": "SELECTED_TRANSLATE",
      "trigger": "Agent/System profile needs interoperable traces",
      "non_trigger": "No telemetry consumer or LITE no-op",
      "inputs": "runtime spans/events",
      "outputs": "telemetry only",
      "source_permission": "OBSERVE",
      "source_effect": "NO_EFFECT",
      "adapter_seam": "OTel attributes→observation records",
      "canonical_test_oracle": "TEST-PRT-001 / OR-PRT-001",
      "canonical_fallback": "provider-native/local logs",
      "canonical_exit_provider_off": "telemetry backend can be switched/off",
      "currentness_support": "OpenTelemetry Semantic Conventions 1.44.0; GenAI conventions moved to dedicated repo",
      "doc05_permission_effect_rule": "OBSERVE only; telemetry has no mutation authority",
      "host_binding_condition": "semconv version + backend mapping + redaction policy",
      "doc05_validation_fixture": "TEST-PRT-001/OR-PRT-001: telemetry is observation, not acceptance",
      "doc05_provider_off_exit": "switch/off backend without losing canonical evidence",
      "doc05_failure_mode": "sensitive context leakage or telemetry treated as effect truth"
    },
    {
      "id": "CAND-09",
      "candidate": "Pi Coding Agent / pi-mono",
      "source_owner_or_project": "pi-mono project",
      "canonical_disposition": "EVAL_ONLY",
      "project_design_treatment": "EVAL_ONLY",
      "trigger": "Evaluate multi-provider coding harness semantics",
      "non_trigger": "Production adoption without parity/security review",
      "inputs": "evaluation fixture",
      "outputs": "evaluation report",
      "source_permission": "SANDBOX_READ/WRITE",
      "source_effect": "SANDBOX_EFFECT",
      "adapter_seam": "evaluation-only seam",
      "canonical_test_oracle": "TEST-PRT-001 / OR-PRT-001",
      "canonical_fallback": "other harness benchmark",
      "canonical_exit_provider_off": "no production dependency",
      "currentness_support": "Pi/pi-mono moved namespace; exact release/commit recheck at PD",
      "doc05_permission_effect_rule": "SANDBOX_READ/WRITE only",
      "host_binding_condition": "isolated evaluation fixture and no production binding",
      "doc05_validation_fixture": "TEST-PRT-001/OR-PRT-001: parity/security evaluation",
      "doc05_provider_off_exit": "discard sandbox/provider-off",
      "doc05_failure_mode": "evaluation artifact promoted to production authority"
    },
    {
      "id": "CAND-10",
      "candidate": "Superpowers",
      "source_owner_or_project": "Superpowers project",
      "canonical_disposition": "ADOPT_WITH_TRANSLATION",
      "project_design_treatment": "SELECTED_TRANSLATE",
      "trigger": "Selected skill procedure closes a named capability need",
      "non_trigger": "Whole methodology would override lifecycle authority",
      "inputs": "bounded work instruction",
      "outputs": "translated procedure/test step",
      "source_permission": "LOCAL_ARTIFACT_WRITE",
      "source_effect": "LOCAL_EFFECT",
      "adapter_seam": "individual skill→PIPD Skill adapter",
      "canonical_test_oracle": "TEST-CMP-002 / OR-CMP-002",
      "canonical_fallback": "native runbook",
      "canonical_exit_provider_off": "remove selected skill independently",
      "currentness_support": "Superpowers latest observed v6.4.2 (2026-09-25); pin repo commit + selected skill digests",
      "doc05_permission_effect_rule": "per-skill LOCAL_ARTIFACT_WRITE; no methodology-wide authority",
      "host_binding_condition": "selected skill digest + trigger/non-trigger + host instructions",
      "doc05_validation_fixture": "TEST-CMP-002/OR-CMP-002: one skill cannot override lifecycle gates",
      "doc05_provider_off_exit": "remove selected skill independently",
      "doc05_failure_mode": "whole-methodology takeover or hidden scope expansion"
    },
    {
      "id": "CAND-11",
      "candidate": "gstack",
      "source_owner_or_project": "gstack project",
      "canonical_disposition": "REFERENCE",
      "project_design_treatment": "REFERENCE",
      "trigger": "Need comparative review/sequencing patterns",
      "non_trigger": "Direct runtime authority",
      "inputs": "reference workflow",
      "outputs": "design notes only",
      "source_permission": "READ_ONLY",
      "source_effect": "NO_EFFECT",
      "adapter_seam": "reference extraction only",
      "canonical_test_oracle": "TEST-RET-001 / OR-RET-001",
      "canonical_fallback": "other review references",
      "canonical_exit_provider_off": "no runtime lock-in",
      "currentness_support": "gstack rolling; observed 1.68.0.0 changelog line; exact commit/version at PD",
      "doc05_permission_effect_rule": "READ_ONLY",
      "host_binding_condition": "reference-only extraction; no runtime binding",
      "doc05_validation_fixture": "TEST-RET-001/OR-RET-001: reference remains non-authoritative",
      "doc05_provider_off_exit": "no runtime dependency",
      "doc05_failure_mode": "review sequence treated as canonical gate"
    },
    {
      "id": "CAND-12",
      "candidate": "DeepSeek Harness",
      "source_owner_or_project": "DeepSeek Harness project",
      "canonical_disposition": "EVAL_ONLY",
      "project_design_treatment": "EVAL_ONLY",
      "trigger": "Compare plugin/service/event model",
      "non_trigger": "Production adoption from preview without admission",
      "inputs": "sandbox scenario",
      "outputs": "evaluation findings",
      "source_permission": "SANDBOX_READ/WRITE",
      "source_effect": "SANDBOX_EFFECT",
      "adapter_seam": "evaluation profile only",
      "canonical_test_oracle": "TEST-PRT-001 / OR-PRT-001",
      "canonical_fallback": "other harness donor",
      "canonical_exit_provider_off": "no production dependency",
      "currentness_support": "DeepSeek Harness developer preview; breaking compatibility changes expected; shadow/eval only unless re-admitted",
      "doc05_permission_effect_rule": "SANDBOX_READ/WRITE only",
      "host_binding_condition": "preview harness pinned in isolated eval environment",
      "doc05_validation_fixture": "TEST-PRT-001/OR-PRT-001: preview cannot self-promote",
      "doc05_provider_off_exit": "discard sandbox",
      "doc05_failure_mode": "breaking preview behavior or plugin/service event mismatch"
    },
    {
      "id": "CAND-13",
      "candidate": "Open GSD / gsd-core",
      "source_owner_or_project": "Open GSD / gsd-core project",
      "canonical_disposition": "REFERENCE",
      "project_design_treatment": "REFERENCE",
      "trigger": "Need fresh-context/planning reference",
      "non_trigger": "Would create second PI/PD lifecycle",
      "inputs": "reference docs",
      "outputs": "bounded design pattern",
      "source_permission": "READ_ONLY",
      "source_effect": "NO_EFFECT",
      "adapter_seam": "reference mapping only",
      "canonical_test_oracle": "TEST-RET-001 / OR-RET-001",
      "canonical_fallback": "native PIPD procedure",
      "canonical_exit_provider_off": "no runtime dependency",
      "currentness_support": "Open GSD/gsd-core observed v1.15.0; exact tag at PD",
      "doc05_permission_effect_rule": "READ_ONLY",
      "host_binding_condition": "reference mapping only",
      "doc05_validation_fixture": "TEST-RET-001/OR-RET-001: no second lifecycle",
      "doc05_provider_off_exit": "no runtime dependency",
      "doc05_failure_mode": "fresh-context workflow becomes parallel PI/PD truth"
    },
    {
      "id": "CAND-14",
      "candidate": "legacy gsd-build/get-shit-done",
      "source_owner_or_project": "legacy gsd-build project",
      "canonical_disposition": "REJECT",
      "project_design_treatment": "REJECT",
      "trigger": "Regression/history comparison only",
      "non_trigger": "Any new-adoption path",
      "inputs": "historical reference",
      "outputs": "rejection rationale",
      "source_permission": "READ_ONLY",
      "source_effect": "NO_EFFECT",
      "adapter_seam": "none; historical evidence only",
      "canonical_test_oracle": "TEST-E6580324 / OR-E6580324",
      "canonical_fallback": "current admitted workflow",
      "canonical_exit_provider_off": "new_adoption=false; no runtime path",
      "currentness_support": "legacy gsd-build/get-shit-done archived/read-only; provenance only",
      "doc05_permission_effect_rule": "READ_ONLY provenance only",
      "host_binding_condition": "no new-adoption binding allowed",
      "doc05_validation_fixture": "TEST-E6580324/OR-E6580324: new_adoption=false",
      "doc05_provider_off_exit": "no runtime path",
      "doc05_failure_mode": "archived donor reintroduced as dependency"
    },
    {
      "id": "CAND-15",
      "candidate": "mattpocock/skills",
      "source_owner_or_project": "mattpocock/skills upstream",
      "canonical_disposition": "ADOPT_WITH_TRANSLATION",
      "project_design_treatment": "SELECTED_TRANSLATE",
      "trigger": "Specific skill has fit and passes rights/security review",
      "non_trigger": "Bulk install without per-skill admission",
      "inputs": "selected skill",
      "outputs": "translated Skill adapter",
      "source_permission": "per-skill scoped",
      "source_effect": "DEPENDS_ON_SKILL",
      "adapter_seam": "per-skill wrapper",
      "canonical_test_oracle": "TEST-BND-003 / OR-BND-003",
      "canonical_fallback": "native first-party skill",
      "canonical_exit_provider_off": "uninstall selected skill; residue check",
      "currentness_support": "mattpocock/skills observed v1.2.3; pin repo commit + skill digest",
      "doc05_permission_effect_rule": "per-skill scoped; effectful permission derives from admitted skill contract",
      "host_binding_condition": "specific skill digest + rights/security/trigger qualification",
      "doc05_validation_fixture": "TEST-BND-003/OR-BND-003: Trigger/Compliance/Boundary",
      "doc05_provider_off_exit": "uninstall selected skill + residue check",
      "doc05_failure_mode": "bulk install, hidden tool, or unqualified skill permission"
    },
    {
      "id": "CAND-16",
      "candidate": "Hugging Face Agent Skills",
      "source_owner_or_project": "Hugging Face",
      "canonical_disposition": "ADOPT_WITH_TRANSLATION",
      "project_design_treatment": "SELECTED_TRANSLATE",
      "trigger": "Portable SKILL.md capability matches need",
      "non_trigger": "Host/network/package assumptions unresolved",
      "inputs": "skill package",
      "outputs": "portable skill projection",
      "source_permission": "per-skill scoped",
      "source_effect": "DEPENDS_ON_SKILL",
      "adapter_seam": "Agent Skills-compatible directory",
      "canonical_test_oracle": "TEST-PRT-001 / OR-PRT-001",
      "canonical_fallback": "first-party Skill template",
      "canonical_exit_provider_off": "host-specific uninstall/residue",
      "currentness_support": "Hugging Face Skills rolling repo; per-skill commit/digest + license/right check",
      "doc05_permission_effect_rule": "per-skill scoped; model/data rights and host permissions explicit",
      "host_binding_condition": "host/runtime package profile + skill digest + rights refs",
      "doc05_validation_fixture": "TEST-PRT-001/OR-PRT-001: host compatibility + permission",
      "doc05_provider_off_exit": "host-specific uninstall/residue",
      "doc05_failure_mode": "host/network/model assumption unresolved"
    },
    {
      "id": "CAND-17",
      "candidate": "AG-UI",
      "source_owner_or_project": "AG-UI project",
      "canonical_disposition": "ADOPT_WITH_TRANSLATION",
      "project_design_treatment": "SELECTED_TRANSLATE",
      "trigger": "Frontend needs agent event interoperability",
      "non_trigger": "No agent UI surface",
      "inputs": "UI event contract",
      "outputs": "versioned frontend events",
      "source_permission": "NETWORK scoped",
      "source_effect": "USER_VISIBLE_EFFECT",
      "adapter_seam": "AG-UI events→UI/effect contracts",
      "canonical_test_oracle": "TEST-PRT-001 / OR-PRT-001",
      "canonical_fallback": "project-native event adapter",
      "canonical_exit_provider_off": "protocol adapter replaceable",
      "currentness_support": "AG-UI packages core/client/encoder/proto observed 1.0.2 (2026-10-05)",
      "doc05_permission_effect_rule": "NETWORK scoped + USER_VISIBLE_EFFECT",
      "host_binding_condition": "UI event protocol version + frontend/client state mapping",
      "doc05_validation_fixture": "TEST-PRT-001/OR-PRT-001: UI projection != authority/effect truth",
      "doc05_provider_off_exit": "replace protocol adapter",
      "doc05_failure_mode": "shared/client state promoted to canonical truth"
    },
    {
      "id": "CAND-18",
      "candidate": "NousResearch Hermes Agent",
      "source_owner_or_project": "NousResearch",
      "canonical_disposition": "QUARANTINE",
      "project_design_treatment": "QUARANTINE",
      "trigger": "Sandbox comparison explicitly approved",
      "non_trigger": "Implicit production/repo/secret access",
      "inputs": "quarantined fixture",
      "outputs": "sandbox-only report",
      "source_permission": "SANDBOX_ONLY",
      "source_effect": "SANDBOX_EFFECT",
      "adapter_seam": "quarantine boundary; no default production seam",
      "canonical_test_oracle": "TEST-BND-003 / OR-BND-003",
      "canonical_fallback": "other admitted agent runtime",
      "canonical_exit_provider_off": "default_quarantine=true; explicit admission required",
      "currentness_support": "Hermes Agent observed v0.21.3 / 2026.9.14 line; remains source-controlled quarantine/reference per canonical decision",
      "doc05_permission_effect_rule": "SANDBOX_ONLY",
      "host_binding_condition": "explicit quarantine approval + isolated provenance fixture",
      "doc05_validation_fixture": "TEST-BND-003/OR-BND-003: no repo/secret/prod by default",
      "doc05_provider_off_exit": "destroy sandbox/provider-off",
      "doc05_failure_mode": "provenance unresolved or implicit production access"
    },
    {
      "id": "CAND-19",
      "candidate": "Cordis",
      "source_owner_or_project": "Cordis project",
      "canonical_disposition": "REFERENCE",
      "project_design_treatment": "REFERENCE",
      "trigger": "Study revertible/reactive effect semantics",
      "non_trigger": "Core dependency on unstable API",
      "inputs": "reference docs",
      "outputs": "design comparison",
      "source_permission": "READ_ONLY",
      "source_effect": "NO_EFFECT",
      "adapter_seam": "reference translation",
      "canonical_test_oracle": "TEST-RET-001 / OR-RET-001",
      "canonical_fallback": "native effect model",
      "canonical_exit_provider_off": "no runtime dependency",
      "currentness_support": "Cordis rolling/unstable API research donor; exact commit if evaluated",
      "doc05_permission_effect_rule": "READ_ONLY",
      "host_binding_condition": "reference translation only",
      "doc05_validation_fixture": "TEST-RET-001/OR-RET-001: reactive effect semantics comparison",
      "doc05_provider_off_exit": "no runtime dependency",
      "doc05_failure_mode": "unstable API becomes core runtime dependency"
    },
    {
      "id": "CAND-20",
      "candidate": "LongHorizon-Harness research",
      "source_owner_or_project": "LongHorizon-Harness research artifact",
      "canonical_disposition": "REFERENCE",
      "project_design_treatment": "REFERENCE",
      "trigger": "Long-horizon task state/auditor design research",
      "non_trigger": "Treat research result as runtime proof",
      "inputs": "paper/fixtures",
      "outputs": "design/eval hypotheses",
      "source_permission": "READ_ONLY",
      "source_effect": "NO_EFFECT",
      "adapter_seam": "research→test design",
      "canonical_test_oracle": "TEST-PRT-001 / OR-PRT-001",
      "canonical_fallback": "local experiment",
      "canonical_exit_provider_off": "no runtime dependency",
      "currentness_support": "LongHorizon-Harness research (2026-08); research provenance only",
      "doc05_permission_effect_rule": "READ_ONLY",
      "host_binding_condition": "research fixture only; no production binding",
      "doc05_validation_fixture": "TEST-PRT-001/OR-PRT-001: hypothesis→local fixture",
      "doc05_provider_off_exit": "discard experiment",
      "doc05_failure_mode": "research result treated as production proof"
    },
    {
      "id": "CAND-21",
      "candidate": "Skill-Use benchmark",
      "source_owner_or_project": "Skill-Use research artifact",
      "canonical_disposition": "REFERENCE",
      "project_design_treatment": "REFERENCE",
      "trigger": "Need Trigger/Compliance/Boundary taxonomy",
      "non_trigger": "Treat benchmark as product authority",
      "inputs": "benchmark taxonomy",
      "outputs": "conformance test design",
      "source_permission": "READ_ONLY",
      "source_effect": "NO_EFFECT",
      "adapter_seam": "benchmark→test categories",
      "canonical_test_oracle": "TEST-TRG-001 / OR-TRG-001",
      "canonical_fallback": "local skill fixture suite",
      "canonical_exit_provider_off": "no runtime dependency",
      "currentness_support": "Skill-Use benchmark (2026-08); research benchmark only",
      "doc05_permission_effect_rule": "READ_ONLY",
      "host_binding_condition": "benchmark taxonomy mapped to local test IDs",
      "doc05_validation_fixture": "TEST-TRG-001/OR-TRG-001: Trigger/Compliance/Boundary local fixtures",
      "doc05_provider_off_exit": "remove benchmark dependency",
      "doc05_failure_mode": "benchmark score replaces local conformance"
    },
    {
      "id": "CAND-22",
      "candidate": "HarnessRisk benchmark",
      "source_owner_or_project": "HarnessRisk research artifact",
      "canonical_disposition": "REFERENCE",
      "project_design_treatment": "REFERENCE",
      "trigger": "Need harness lifecycle safety scenarios",
      "non_trigger": "Treat benchmark score as release authority",
      "inputs": "benchmark scenarios",
      "outputs": "threat/eval test design",
      "source_permission": "READ_ONLY",
      "source_effect": "NO_EFFECT",
      "adapter_seam": "benchmark→adversarial fixtures",
      "canonical_test_oracle": "TEST-BND-003 / OR-BND-003",
      "canonical_fallback": "local threat model fixtures",
      "canonical_exit_provider_off": "no runtime dependency",
      "currentness_support": "HarnessRisk benchmark (2026-08); research benchmark only",
      "doc05_permission_effect_rule": "READ_ONLY",
      "host_binding_condition": "benchmark scenarios mapped into local threat model",
      "doc05_validation_fixture": "TEST-BND-003/OR-BND-003: lifecycle attack fixture",
      "doc05_provider_off_exit": "remove benchmark dependency",
      "doc05_failure_mode": "benchmark transferability assumed without local threat model"
    }
  ]
}
```

## 18.4 Source identity vs recheck policy

`source_owner_or_project` records the upstream source/project identity. `currentness_support` records source-observed currentness. `project_technology_admission_state=UNBOUND_PROJECT_INSTANCE` prevents source/version observations from being mistaken for local installation/binding. Recheck policy is separate: exact version/tag/commit/license/security/currentness is resolved at PD/project TechnologyAdmission before use.

## 18.5 H1-18B｜Layer-B 130/130 identity-preserving relevance crosswalk

Denominator is exact: `24 NOBJ + 52 ECP/ADD + 15 MSC-TECH + 31 TQ-TECH + 8 named workflows = 130`.

Every source row retains its stable ID, source truth/disposition, PIPD treatment and canonical home. DOC-05 adds only `DIRECT` or `INDIRECT` relevance. No row is promoted by being listed; no quarantine state is softened. In particular `NOBJ-019 pytest`, `NOBJ-020 GitHub Actions`, `NOBJ-021 CycloneDX`, and `NOBJ-022 Gitleaks` remain `QUARANTINE_WEB_EVIDENCE_NOT_INSTALLED / QUARANTINE` until separately re-admitted.

### 20.1 R1 NOBJ-001..024 — 24/24
| Donor ID | Name | Source slot | Source disposition/truth | PIPD treatment | Canonical home | Downstream landing obligation | Anti-downgrade / exit rule | DOC-05 relevance | DOC-05 rationale |
|---|---|---|---|---|---|---|---|---|---|
| NOBJ-001 | HLPE Native PLAN/BOOTSTRAP/FACTORY | SLOT-PLAN-KERNEL | LOCAL_TRANSLATION_ASSET_MATERIALIZED_NOT_HOST_BOUND | REFERENCE | DOC-02 TechnologyAdmission / project-specific binding | preserve donor identity; translate only named capability; project adoption requires terminal TechnologyAdmission/currentness/tests | cannot silently drop or promote; removal/replacement requires crosswalk rationale + CR if already selected/materialized | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| NOBJ-002 | Matt grill-with-docs | SLOT-REQUIREMENT-CHALLENGE | METHOD_TRANSLATED_LOCAL_EXTERNAL_ADOPTION_NOT_CLAIMED | TRANSLATE | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | preserve donor identity; translate only named capability; project adoption requires terminal TechnologyAdmission/currentness/tests | cannot silently drop or promote; removal/replacement requires crosswalk rationale + CR if already selected/materialized | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| NOBJ-003 | OpenSpec | SLOT-SPEC-WORKFLOW | SUPPORT_ONLY_NOT_INSTALLED | REFERENCE | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | preserve donor identity; translate only named capability; project adoption requires terminal TechnologyAdmission/currentness/tests | cannot silently drop or promote; removal/replacement requires crosswalk rationale + CR if already selected/materialized | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| NOBJ-004 | Spec Kit | SLOT-SPEC-CLI | SUPPORT_ONLY_NOT_INSTALLED | REFERENCE | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | preserve donor identity; translate only named capability; project adoption requires terminal TechnologyAdmission/currentness/tests | cannot silently drop or promote; removal/replacement requires crosswalk rationale + CR if already selected/materialized | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| NOBJ-005 | Superpowers test-driven-development | SLOT-TDD | SUPPORT_ONLY_NOT_INSTALLED | REFERENCE | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | preserve donor identity; translate only named capability; project adoption requires terminal TechnologyAdmission/currentness/tests | cannot silently drop or promote; removal/replacement requires crosswalk rationale + CR if already selected/materialized | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| NOBJ-006 | Superpowers systematic-debugging | SLOT-DEBUG | SUPPORT_ONLY_NOT_INSTALLED | REFERENCE | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | preserve donor identity; translate only named capability; project adoption requires terminal TechnologyAdmission/currentness/tests | cannot silently drop or promote; removal/replacement requires crosswalk rationale + CR if already selected/materialized | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| NOBJ-007 | Superpowers verification-before-completion | SLOT-VERIFY | SUPPORT_ONLY_NOT_INSTALLED | REFERENCE | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | preserve donor identity; translate only named capability; project adoption requires terminal TechnologyAdmission/currentness/tests | cannot silently drop or promote; removal/replacement requires crosswalk rationale + CR if already selected/materialized | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| NOBJ-008 | GStack | SLOT-REVIEW-PATTERN | QUARANTINE_IDENTITY_UNTIL_PIN | QUARANTINE | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | preserve donor identity; translate only named capability; project adoption requires terminal TechnologyAdmission/currentness/tests | cannot silently drop or promote; removal/replacement requires crosswalk rationale + CR if already selected/materialized | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| NOBJ-009 | GSD / planning-with-files | SLOT-PLANNING-FILES | QUARANTINE_IDENTITY_CONFLICT | QUARANTINE | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | preserve donor identity; translate only named capability; project adoption requires terminal TechnologyAdmission/currentness/tests | cannot silently drop or promote; removal/replacement requires crosswalk rationale + CR if already selected/materialized | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| NOBJ-010 | AGENTS.md | SLOT-REPO-STEERING | PORTABLE_LOCAL_PROFILE | REFERENCE | DOC-02 TechnologyAdmission / project-specific binding | preserve donor identity; translate only named capability; project adoption requires terminal TechnologyAdmission/currentness/tests | cannot silently drop or promote; removal/replacement requires crosswalk rationale + CR if already selected/materialized | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| NOBJ-011 | SKILL.md | SLOT-SKILL-CONTRACT | LOCAL_TRANSLATION_ASSET_MATERIALIZED_NOT_HOST_BOUND | REFERENCE | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | preserve donor identity; translate only named capability; project adoption requires terminal TechnologyAdmission/currentness/tests | cannot silently drop or promote; removal/replacement requires crosswalk rationale + CR if already selected/materialized | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| NOBJ-012 | DESIGN.md | SLOT-DESIGN-RATIONALE | LOCAL_TRANSLATION_ASSET_MATERIALIZED_NOT_HOST_BOUND | REFERENCE | DOC-02 TechnologyAdmission / project-specific binding | preserve donor identity; translate only named capability; project adoption requires terminal TechnologyAdmission/currentness/tests | cannot silently drop or promote; removal/replacement requires crosswalk rationale + CR if already selected/materialized | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| NOBJ-013 | Prompt projection | SLOT-PROMPT-PROJECTION | LOCAL_TRANSLATION_ASSET_MATERIALIZED_NOT_HOST_BOUND | TRANSLATE | DOC-02 TechnologyAdmission / project-specific binding | preserve donor identity; translate only named capability; project adoption requires terminal TechnologyAdmission/currentness/tests | cannot silently drop or promote; removal/replacement requires crosswalk rationale + CR if already selected/materialized | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| NOBJ-014 | OpenAI skill-creator | SLOT-SKILL-CREATOR | QUARANTINE_WEB_EVIDENCE_NOT_INSTALLED | QUARANTINE | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | preserve donor identity; translate only named capability; project adoption requires terminal TechnologyAdmission/currentness/tests | cannot silently drop or promote; removal/replacement requires crosswalk rationale + CR if already selected/materialized | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| NOBJ-015 | OpenAI plugin-creator | SLOT-PLUGIN-CREATOR | QUARANTINE_WEB_EVIDENCE_NOT_INSTALLED | QUARANTINE | DOC-02 TechnologyAdmission / project-specific binding | preserve donor identity; translate only named capability; project adoption requires terminal TechnologyAdmission/currentness/tests | cannot silently drop or promote; removal/replacement requires crosswalk rationale + CR if already selected/materialized | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| NOBJ-016 | Agent Skills specification | SLOT-AGENT-SKILLS-SPEC | SUPPORT_ONLY_BLOCKED_EXTERNAL | REFERENCE | DOC-09 CI Adapter | preserve donor identity; translate only named capability; project adoption requires terminal TechnologyAdmission/currentness/tests | cannot silently drop or promote; removal/replacement requires crosswalk rationale + CR if already selected/materialized | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| NOBJ-017 | Agent Plugins 1.0 Working Draft | SLOT-PLUGIN-DRAFT-SPEC | SUPPORT_ONLY_BLOCKED_EXTERNAL | REFERENCE | DOC-02 TechnologyAdmission / project-specific binding | preserve donor identity; translate only named capability; project adoption requires terminal TechnologyAdmission/currentness/tests | cannot silently drop or promote; removal/replacement requires crosswalk rationale + CR if already selected/materialized | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| NOBJ-018 | JSON Schema 2020-12 | SLOT-SCHEMA-VALIDATOR | LOCAL_TRANSLATION_ASSET_MATERIALIZED_NOT_HOST_BOUND | REFERENCE | DOC-02 TechnologyAdmission / project-specific binding | preserve donor identity; translate only named capability; project adoption requires terminal TechnologyAdmission/currentness/tests | cannot silently drop or promote; removal/replacement requires crosswalk rationale + CR if already selected/materialized | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| NOBJ-019 | pytest | SLOT-TEST-RUNNER | QUARANTINE_WEB_EVIDENCE_NOT_INSTALLED | QUARANTINE | DOC-02 TechnologyAdmission / project-specific binding | preserve donor identity; translate only named capability; project adoption requires terminal TechnologyAdmission/currentness/tests | cannot silently drop or promote; removal/replacement requires crosswalk rationale + CR if already selected/materialized | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| NOBJ-020 | GitHub Actions | SLOT-CI | QUARANTINE_WEB_EVIDENCE_NOT_INSTALLED | QUARANTINE | DOC-09 CI Adapter | preserve donor identity; translate only named capability; project adoption requires terminal TechnologyAdmission/currentness/tests | cannot silently drop or promote; removal/replacement requires crosswalk rationale + CR if already selected/materialized | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| NOBJ-021 | CycloneDX | SLOT-SBOM | QUARANTINE_WEB_EVIDENCE_NOT_INSTALLED | QUARANTINE | DOC-09 Release/Supply-Chain | preserve donor identity; translate only named capability; project adoption requires terminal TechnologyAdmission/currentness/tests | cannot silently drop or promote; removal/replacement requires crosswalk rationale + CR if already selected/materialized | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| NOBJ-022 | Gitleaks | SLOT-SECRET-SCAN | QUARANTINE_WEB_EVIDENCE_NOT_INSTALLED | QUARANTINE | DOC-07 TQAEP/Security | preserve donor identity; translate only named capability; project adoption requires terminal TechnologyAdmission/currentness/tests | cannot silently drop or promote; removal/replacement requires crosswalk rationale + CR if already selected/materialized | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| NOBJ-023 | markdownlint | SLOT-MARKDOWN-LINT | QUARANTINE_WEB_EVIDENCE_NOT_INSTALLED | QUARANTINE | DOC-02 TechnologyAdmission / project-specific binding | preserve donor identity; translate only named capability; project adoption requires terminal TechnologyAdmission/currentness/tests | cannot silently drop or promote; removal/replacement requires crosswalk rationale + CR if already selected/materialized | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| NOBJ-024 | Ruff + type checker | SLOT-PYTHON-LINT | QUARANTINE_WEB_EVIDENCE_NOT_INSTALLED | QUARANTINE | DOC-02 TechnologyAdmission / project-specific binding | preserve donor identity; translate only named capability; project adoption requires terminal TechnologyAdmission/currentness/tests | cannot silently drop or promote; removal/replacement requires crosswalk rationale + CR if already selected/materialized | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |

### 20.2 R2 ECP exact 48 + ADD-01..04 — 52/52
| Donor ID | Name | Category/slot | Source disposition | PIPD treatment | Canonical home | Imported capability boundary | Excluded semantics / exit | DOC-05 relevance | DOC-05 rationale |
|---|---|---|---|---|---|---|---|---|---|
| ECP-01 | Spec Kit | method/spec-provider / S2E L2 specification adapter | ADOPT+QUALIFY | EVAL | DOC-09 CI Adapter | capability pattern/adapter for method/spec-provider / S2E L2 specification adapter; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| ECP-02 | OpenSpec | method/spec-provider / S2E L2 brownfield change adapter | ADOPT+QUALIFY | EVAL | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | capability pattern/adapter for method/spec-provider / S2E L2 brownfield change adapter; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| ECP-03 | Matt Skills / mattpocock-skills | skill/workflow / requirement challenge/slicing/implementation discipline | QUALIFY | EVAL | DOC-09 CI Adapter | capability pattern/adapter for skill/workflow / requirement challenge/slicing/implementation discipline; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| ECP-04 | Superpowers | skill/workflow / TDD/debug/verification discipline | QUALIFY | EVAL | DOC-09 CI Adapter | capability pattern/adapter for skill/workflow / TDD/debug/verification discipline; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| ECP-05 | gstack | skill/workflow / engineering review/QA/ship donor | QUALIFY | EVAL | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | capability pattern/adapter for skill/workflow / engineering review/QA/ship donor; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| ECP-06 | GSD | workflow donor / long-task planning/checkpoint pattern | QUALIFY | EVAL | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | capability pattern/adapter for workflow donor / long-task planning/checkpoint pattern; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| ECP-07 | OROCHI / SRU | legacy execution lineage / Execution Factory bounded route-out donor | ROUTE_OUT+ADOPT_BOUNDED_DONOR | ROUTE_OUT | DOC-03 Provider/Harness Binding + ECP/TQAEP | capability pattern/adapter for legacy execution lineage / Execution Factory bounded route-out donor; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| ECP-08 | Codex App Server | provider / MHPL primary coding candidate | QUALIFY_PRIMARY | EVAL | DOC-03 Provider/Harness Binding + ECP/TQAEP | capability pattern/adapter for provider / MHPL primary coding candidate; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| ECP-09 | codex app-server-client | provider seam / MHPL in-process client seam | CONDITIONAL | REFERENCE | DOC-03 Provider/Harness Binding + ECP/TQAEP | capability pattern/adapter for provider seam / MHPL in-process client seam; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| ECP-10 | Hermes | provider/session UI / GENIE session/orchestration surface | ADOPT+QUALIFY | EVAL | DOC-03 Provider/Harness Binding + ECP/TQAEP | capability pattern/adapter for provider/session UI / GENIE session/orchestration surface; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| ECP-11 | OpenCode | provider / MHPL coding alternate | QUALIFY | EVAL | DOC-03 Provider/Harness Binding + ECP/TQAEP | capability pattern/adapter for provider / MHPL coding alternate; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| ECP-12 | Pi | provider / MHPL embedded alternate | QUALIFY | EVAL | DOC-03 Provider/Harness Binding + ECP/TQAEP | capability pattern/adapter for provider / MHPL embedded alternate; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| ECP-13 | DeepSeek Harness | harness / MHPL shadow/runtime donor | SHADOW | EVAL | DOC-03 Provider/Harness Binding + ECP/TQAEP | capability pattern/adapter for harness / MHPL shadow/runtime donor; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| ECP-14 | UHP | protocol / MHPL compatibility projection | PILOT_COMPATIBILITY_ONLY | EVAL | DOC-03 Interop Binding + DOC-07 Conformance | capability pattern/adapter for protocol / MHPL compatibility projection; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| ECP-15 | A2A | protocol / cross-Agent/Fabric interop | ADOPT_BOUNDARY | KEEP | DOC-03 Interop Binding + DOC-07 Conformance | capability pattern/adapter for protocol / cross-Agent/Fabric interop; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| ECP-16 | Temporal | orchestrator / durable workflow primary pilot | PILOT_PRIMARY | EVAL | DOC-03 Provider/Harness Binding + ECP/TQAEP | capability pattern/adapter for orchestrator / durable workflow primary pilot; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| ECP-17 | OpenAI Agents SDK | orchestration runtime donor / manager/handoff/guardrail pattern/provider | ADOPT_PATTERN+QUALIFY | EVAL | DOC-02 TechnologyAdmission / project-specific binding | capability pattern/adapter for orchestration runtime donor / manager/handoff/guardrail pattern/provider; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| ECP-18 | Dapr | orchestrator / durable alternate | QUALIFY_ALTERNATE | EVAL | DOC-03 Provider/Harness Binding + ECP/TQAEP | capability pattern/adapter for orchestrator / durable alternate; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| ECP-19 | Restate | orchestrator / lightweight durable alternate | QUALIFY_ALTERNATE | EVAL | DOC-03 Provider/Harness Binding + ECP/TQAEP | capability pattern/adapter for orchestrator / lightweight durable alternate; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| ECP-20 | LongHorizon-Harness | research pattern / manager/execute/audit long-horizon donor | ADOPT_PATTERN | TRANSLATE | DOC-03 Provider/Harness Binding + ECP/TQAEP | capability pattern/adapter for research pattern / manager/execute/audit long-horizon donor; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| ECP-21 | HELIX | research pattern / harness evolution/trajectory donor | ADOPT_PATTERN | TRANSLATE | DOC-03 Provider/Harness Binding + ECP/TQAEP | capability pattern/adapter for research pattern / harness evolution/trajectory donor; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| ECP-22 | HarnessRisk | research/benchmark / harness lifecycle safety donor | ADOPT_PATTERN | TRANSLATE | DOC-03 Provider/Harness Binding + ECP/TQAEP | capability pattern/adapter for research/benchmark / harness lifecycle safety donor; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| ECP-23 | MCP Inspector v2 | conformance tool / MCP qualification runner | QUALIFY | EVAL | DOC-03 Interop Binding + DOC-07 Conformance | capability pattern/adapter for conformance tool / MCP qualification runner; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| ECP-24 | Trivy | security scanner / vuln/misconfig/secret/SBOM/license evidence | QUALIFY | EVAL | DOC-09 Release/Supply-Chain | capability pattern/adapter for security scanner / vuln/misconfig/secret/SBOM/license evidence; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| ECP-25 | GitHub Agentic Workflows Safe Outputs | side-effect pattern / GitHub bounded mutation donor | ADOPT_PATTERN | TRANSLATE | DOC-09 CI Adapter | capability pattern/adapter for side-effect pattern / GitHub bounded mutation donor; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| ECP-26 | GitHub Actions | CI/CD / deterministic build/test/release gates | ADOPT | KEEP | DOC-09 CI Adapter | capability pattern/adapter for CI/CD / deterministic build/test/release gates; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| ECP-27 | OpenTelemetry | observability / telemetry vocabulary/correlation | ADOPT | KEEP | DOC-02 TechnologyAdmission / project-specific binding | capability pattern/adapter for observability / telemetry vocabulary/correlation; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| ECP-28 | SLSA v1.2 | standard / supply-chain provenance expectations | ADOPT_STANDARD | TRANSLATE | DOC-09 Release/Supply-Chain | capability pattern/adapter for standard / supply-chain provenance expectations; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| ECP-29 | Sigstore / Cosign | provenance verifier / signature/attestation verification | ADOPT | KEEP | DOC-09 Release/Supply-Chain | capability pattern/adapter for provenance verifier / signature/attestation verification; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| ECP-30 | GitHub Artifact Attestations | provenance provider / GitHub release provenance | ADOPT | KEEP | DOC-09 Release/Supply-Chain | capability pattern/adapter for provenance provider / GitHub release provenance; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| ECP-31 | Plane | PM provider / ProjectManagementProviderSlot | PILOT_PROJECTION_ONLY | EVAL | DOC-08 Projection Adapter | capability pattern/adapter for PM provider / ProjectManagementProviderSlot; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| ECP-32 | Linear | PM provider / ProjectManagementProviderSlot | PILOT_PROJECTION_ONLY | EVAL | DOC-08 Projection Adapter | capability pattern/adapter for PM provider / ProjectManagementProviderSlot; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| ECP-33 | OpenProject | PM provider / ProjectManagementProviderSlot | PILOT_ENTERPRISE_PROJECTION_ONLY | EVAL | DOC-08 Projection Adapter | capability pattern/adapter for PM provider / ProjectManagementProviderSlot; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| ECP-34 | ProjectManagementProviderSlot | internal abstraction / Delivery projection boundary | PROPOSED_CONTRACT | REFERENCE | DOC-08 Projection Adapter | capability pattern/adapter for internal abstraction / Delivery projection boundary; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| ECP-35 | Tree-sitter | code intelligence / Semantic Context baseline parser | ADOPT | KEEP | DOC-03 RepoContext/Semantic Context | capability pattern/adapter for code intelligence / Semantic Context baseline parser; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| ECP-36 | LSP | code intelligence / Semantic Context baseline symbol/reference provider | ADOPT | KEEP | DOC-03 RepoContext/Semantic Context | capability pattern/adapter for code intelligence / Semantic Context baseline symbol/reference provider; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| ECP-37 | SCIP | code intelligence / optional compiler-grade index | ADOPT_OPTIONAL | REFERENCE | DOC-09 CI Adapter | capability pattern/adapter for code intelligence / optional compiler-grade index; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| ECP-38 | Git | source control / source/history canonical baseline | ADOPT | KEEP | DOC-02 TechnologyAdmission / project-specific binding | capability pattern/adapter for source control / source/history canonical baseline; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| ECP-39 | ripgrep | search / lexical fallback/baseline | ADOPT | KEEP | DOC-03 RepoContext/Semantic Context | capability pattern/adapter for search / lexical fallback/baseline; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| ECP-40 | MCP | protocol / agent→tool capability surface | ADOPT | KEEP | DOC-03 Interop Binding + DOC-07 Conformance | capability pattern/adapter for protocol / agent→tool capability surface; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| ECP-41 | AGENTS.md | instruction projection / repo/agent instruction interop | ADOPT_PROJECTION | TRANSLATE | DOC-02 TechnologyAdmission / project-specific binding | capability pattern/adapter for instruction projection / repo/agent instruction interop; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| ECP-42 | SKILL.md | skill projection / Agent Skills reusable workflow interop | ADOPT_PROJECTION | TRANSLATE | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | capability pattern/adapter for skill projection / Agent Skills reusable workflow interop; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| ECP-43 | Claude Code | architecture donor / public harness engineering patterns | ADOPT_PUBLIC_PATTERN_ONLY / REJECT_LEAK_CODE | REJECT | DOC-03 Provider/Harness Binding + ECP/TQAEP | capability pattern/adapter for architecture donor / public harness engineering patterns; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| ECP-44 | Codanna | code intelligence candidate / Semantic Context shadow | SHADOW_EVAL | EVAL | DOC-03 RepoContext/Semantic Context | capability pattern/adapter for code intelligence candidate / Semantic Context shadow; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| ECP-45 | CodeGraph | code intelligence candidate / Semantic Context shadow | SHADOW_EVAL | EVAL | DOC-03 RepoContext/Semantic Context | capability pattern/adapter for code intelligence candidate / Semantic Context shadow; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| ECP-46 | rag-rat | code intelligence candidate / Semantic Context shadow/retrieval-memory | SHADOW_EVAL | EVAL | DOC-03 RepoContext/Semantic Context | capability pattern/adapter for code intelligence candidate / Semantic Context shadow/retrieval-memory; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| ECP-47 | OpenHands | harness/provider / MHPL alternate/reference donor | QUALIFY_REFERENCE | EVAL | DOC-03 Provider/Harness Binding + ECP/TQAEP | capability pattern/adapter for harness/provider / MHPL alternate/reference donor; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| ECP-48 | MoRSE | research pattern / role-subtask specialization donor | ADOPT_PATTERN | TRANSLATE | DOC-09 CI Adapter | capability pattern/adapter for research pattern / role-subtask specialization donor; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| ADD-01 | Agent Skills open standard | portable capability format / Skills packaging/interoperability | ADOPT_CANONICAL_PORTABLE_FORMAT | TRANSLATE | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | preserve additive donor capability and source pin/qualification boundary | no second authority; CR/TechnologyAdmission before runtime dependency | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| ADD-02 | OpenAI Skills | host capability surface / reusable workflow host projection | PRIMARY_HOST_TARGET | REFERENCE | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | preserve additive donor capability and source pin/qualification boundary | no second authority; CR/TechnologyAdmission before runtime dependency | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| ADD-03 | OpenAI Plugin | host packaging surface / multi-Skill container; Apps optional | HOST_PACKAGING | REFERENCE | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | preserve additive donor capability and source pin/qualification boundary | no second authority; CR/TechnologyAdmission before runtime dependency | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| ADD-04 | StateM | research/runtime pattern donor / durable state/checked transition/recoverable runbook | ADOPT_PATTERN + PILOT_DONOR | EVAL | DOC-02 TechnologyAdmission / project-specific binding | preserve additive donor capability and source pin/qualification boundary | no second authority; CR/TechnologyAdmission before runtime dependency | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |

### 20.3 R2 MSC-TECH-001..015 — 15/15
| Donor ID | Name | Capability role | Source disposition | PIPD treatment | Canonical home | Landing rule | DOC-05 relevance | DOC-05 rationale |
|---|---|---|---|---|---|---|---|---|
| MSC-TECH-001 | Spec Kit Presets/Bundles | SKELETON_COMPOSITION | P1_PATTERN_REUSE_STAGE0 | TRANSLATE | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | preserve role/disposition; Stage-0/currentness/qualification as source requires; no silent core dependency | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| MSC-TECH-002 | OpenSpec Project Config/Custom Schema | SCHEMA_WORKFLOW | P1_REUSE_STAGE0 | TRANSLATE | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | preserve role/disposition; Stage-0/currentness/qualification as source requires; no silent core dependency | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| MSC-TECH-003 | Agent Skills / skills-ref | CAPABILITY_PACKAGING | P1_REUSE | TRANSLATE | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | preserve role/disposition; Stage-0/currentness/qualification as source requires; no silent core dependency | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| MSC-TECH-004 | Hugging Face Skills | CAPABILITY_ECOSYSTEM | CONDITIONAL_REUSE | TRANSLATE | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | preserve role/disposition; Stage-0/currentness/qualification as source requires; no silent core dependency | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| MSC-TECH-005 | CUE | CONSTRAINT_COMPOSITION | P2_ONLY_IF_NATIVE_GAP | REFERENCE | DOC-02 TechnologyAdmission / project-specific binding | preserve role/disposition; Stage-0/currentness/qualification as source requires; no silent core dependency | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| MSC-TECH-006 | OPA/Rego | POLICY | CONDITIONAL_HIGH_RISK | REFERENCE | DOC-02 TechnologyAdmission / project-specific binding | preserve role/disposition; Stage-0/currentness/qualification as source requires; no silent core dependency | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| MSC-TECH-007 | Backstage Scaffolder | SCAFFOLDER | P2_SCALE_TRIGGERED | REFERENCE | DOC-02 TechnologyAdmission / project-specific binding | preserve role/disposition; Stage-0/currentness/qualification as source requires; no silent core dependency | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| MSC-TECH-008 | Kustomize | DEPLOYMENT_OVERLAY | K8S_ONLY | REFERENCE | DOC-02 TechnologyAdmission / project-specific binding | preserve role/disposition; Stage-0/currentness/qualification as source requires; no silent core dependency | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| MSC-TECH-009 | DeepSeek Harness profiles/bundles | RUNTIME_COMPOSITION_DONOR | SUPPORT_PILOT_EARLY_PREVIEW | EVAL | DOC-03 Provider/Harness Binding + ECP/TQAEP | preserve role/disposition; Stage-0/currentness/qualification as source requires; no silent core dependency | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| MSC-TECH-010 | Task-Aware Harness Provisioning | RESEARCH_METHOD | METHOD_DONOR | TRANSLATE | DOC-03 Provider/Harness Binding + ECP/TQAEP | preserve role/disposition; Stage-0/currentness/qualification as source requires; no silent core dependency | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| MSC-TECH-011 | HarnessRisk | EVALUATION_FIXTURE_DONOR | EVAL_DONOR | EVAL | DOC-03 Provider/Harness Binding + ECP/TQAEP | preserve role/disposition; Stage-0/currentness/qualification as source requires; no silent core dependency | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| MSC-TECH-012 | SkillGate | SELECTOR_RESEARCH_DONOR | RESEARCH_DONOR | REFERENCE | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | preserve role/disposition; Stage-0/currentness/qualification as source requires; no silent core dependency | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| MSC-TECH-013 | Demystifying Agent Skills | SELECTOR_RESEARCH_DONOR | RESEARCH_DONOR | REFERENCE | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | preserve role/disposition; Stage-0/currentness/qualification as source requires; no silent core dependency | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| MSC-TECH-014 | StateM | LONG_HORIZON_DONOR | RESEARCH_PILOT_DONOR | EVAL | DOC-02 TechnologyAdmission / project-specific binding | preserve role/disposition; Stage-0/currentness/qualification as source requires; no silent core dependency | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| MSC-TECH-015 | Hermes Agent | COMMUNITY_RUNTIME_RISK_DONOR | SUPPORT_ONLY | REFERENCE | DOC-03 Provider/Harness Binding + ECP/TQAEP | preserve role/disposition; Stage-0/currentness/qualification as source requires; no silent core dependency | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |

### 20.4 R3 TQ-TECH-001..031 — 31/31
| Donor ID | Name | Qualification role | Source disposition | PIPD treatment | Canonical home | Qualification/exit rule | DOC-05 relevance | DOC-05 rationale |
|---|---|---|---|---|---|---|---|---|
| TQ-TECH-001 | NVIDIA SkillEvaluator | SKILL_PLUGIN_EVAL | P1_PILOT | EVAL | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | source test/provider slot semantics preserved; runtime use requires exact candidate currentness/rights/host qualification; provider-off/alternate defined | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| TQ-TECH-002 | ACES methodology | SKILL_PLUGIN_EVAL_METHOD | P1_METHOD_ADOPT | TRANSLATE | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | source test/provider slot semantics preserved; runtime use requires exact candidate currentness/rights/host qualification; provider-off/alternate defined | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| TQ-TECH-003 | Harbor | RUNTIME_EVAL_RUNNER | P1_ADOPT_CANDIDATE | EVAL | DOC-02 TechnologyAdmission / project-specific binding | source test/provider slot semantics preserved; runtime use requires exact candidate currentness/rights/host qualification; provider-off/alternate defined | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| TQ-TECH-004 | Agent Skills / skills-ref | PACKAGING_STANDARD | P1_FORMAT_VALIDATOR | TRANSLATE | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | source test/provider slot semantics preserved; runtime use requires exact candidate currentness/rights/host qualification; provider-off/alternate defined | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| TQ-TECH-005 | MCP Inspector v2 | PROTOCOL_CONFORMANCE | REQUIRED_WHERE_MCP | REFERENCE | DOC-03 Interop Binding + DOC-07 Conformance | source test/provider slot semantics preserved; runtime use requires exact candidate currentness/rights/host qualification; provider-off/alternate defined | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| TQ-TECH-006 | Spec Kit /speckit.converge | SPEC_GAP | P1_REUSE_SOFTWARE | TRANSLATE | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | source test/provider slot semantics preserved; runtime use requires exact candidate currentness/rights/host qualification; provider-off/alternate defined | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| TQ-TECH-007 | OpenSpec /opsx:verify | SPEC_VERIFY | P1_REUSE_SOFTWARE | TRANSLATE | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | source test/provider slot semantics preserved; runtime use requires exact candidate currentness/rights/host qualification; provider-off/alternate defined | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| TQ-TECH-008 | Superpowers | METHOD_DONOR | P1_METHOD_DONOR | TRANSLATE | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | source test/provider slot semantics preserved; runtime use requires exact candidate currentness/rights/host qualification; provider-off/alternate defined | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| TQ-TECH-009 | mattpocock-skills | SPEC_REVIEW_DONOR | P2_DONOR | REFERENCE | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | source test/provider slot semantics preserved; runtime use requires exact candidate currentness/rights/host qualification; provider-off/alternate defined | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| TQ-TECH-010 | grill-with-docs | METHOD_DONOR | P2_DONOR_ONLY | REFERENCE | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | source test/provider slot semantics preserved; runtime use requires exact candidate currentness/rights/host qualification; provider-off/alternate defined | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| TQ-TECH-011 | to-spec | METHOD_DONOR | P2_DONOR_ONLY | REFERENCE | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | source test/provider slot semantics preserved; runtime use requires exact candidate currentness/rights/host qualification; provider-off/alternate defined | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| TQ-TECH-012 | code-review (mattpocock-skills) | REVIEW_PROVIDER_METHOD | P2_DONOR_ONLY | REFERENCE | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | source test/provider slot semantics preserved; runtime use requires exact candidate currentness/rights/host qualification; provider-off/alternate defined | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| TQ-TECH-013 | gstack | REVIEW_PROVIDER | P2_BUDGETED | REFERENCE | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | source test/provider slot semantics preserved; runtime use requires exact candidate currentness/rights/host qualification; provider-off/alternate defined | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| TQ-TECH-014 | Trivy | SECURITY_SCANNER | P1 | REFERENCE | DOC-07 TQAEP/Security | source test/provider slot semantics preserved; runtime use requires exact candidate currentness/rights/host qualification; provider-off/alternate defined | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| TQ-TECH-015 | SLSA v1.2 | PROVENANCE_STANDARD | P1 | REFERENCE | DOC-09 Release/Supply-Chain | source test/provider slot semantics preserved; runtime use requires exact candidate currentness/rights/host qualification; provider-off/alternate defined | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| TQ-TECH-016 | GitHub Artifact Attestations | PROVENANCE_VERIFIER | P1_WHERE_GITHUB | REFERENCE | DOC-09 Release/Supply-Chain | source test/provider slot semantics preserved; runtime use requires exact candidate currentness/rights/host qualification; provider-off/alternate defined | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| TQ-TECH-017 | Sigstore / Cosign | PROVENANCE_VERIFIER | P1_ALTERNATE | REFERENCE | DOC-09 Release/Supply-Chain | source test/provider slot semantics preserved; runtime use requires exact candidate currentness/rights/host qualification; provider-off/alternate defined | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| TQ-TECH-018 | OpenTelemetry GenAI | OBSERVABILITY_PROVIDER | P2_OBSERVATION_ONLY | REFERENCE | DOC-02 TechnologyAdmission / project-specific binding | source test/provider slot semantics preserved; runtime use requires exact candidate currentness/rights/host qualification; provider-off/alternate defined | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| TQ-TECH-019 | StateM | RESEARCH_DONOR | P3_PATTERN_PILOT | EVAL | DOC-02 TechnologyAdmission / project-specific binding | source test/provider slot semantics preserved; runtime use requires exact candidate currentness/rights/host qualification; provider-off/alternate defined | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| TQ-TECH-020 | HarnessRisk | RESEARCH_DONOR | P3_FIXTURE_DONOR | REFERENCE | DOC-03 Provider/Harness Binding + ECP/TQAEP | source test/provider slot semantics preserved; runtime use requires exact candidate currentness/rights/host qualification; provider-off/alternate defined | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| TQ-TECH-021 | SkillGate | RESEARCH_DONOR | P3_ROUTING_DONOR | REFERENCE | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | source test/provider slot semantics preserved; runtime use requires exact candidate currentness/rights/host qualification; provider-off/alternate defined | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| TQ-TECH-022 | Demystifying Agent Skills | RESEARCH_DONOR | P3_ROUTING_DONOR | REFERENCE | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | source test/provider slot semantics preserved; runtime use requires exact candidate currentness/rights/host qualification; provider-off/alternate defined | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| TQ-TECH-023 | OpenAI Skills / Plugin | HOST_PACKAGING | P1_HOST_SURFACE | REFERENCE | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | source test/provider slot semantics preserved; runtime use requires exact candidate currentness/rights/host qualification; provider-off/alternate defined | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| TQ-TECH-024 | OpenAI Apps / App Templates | HOST_EXTERNAL_ACTION | V2_OPTIONAL | REFERENCE | DOC-02 TechnologyAdmission / project-specific binding | source test/provider slot semantics preserved; runtime use requires exact candidate currentness/rights/host qualification; provider-off/alternate defined | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| TQ-TECH-025 | Semgrep | TRANSITIVE_SECURITY_SCANNER | OPTIONAL_TRANSITIVE | REFERENCE | DOC-07 TQAEP/Security | source test/provider slot semantics preserved; runtime use requires exact candidate currentness/rights/host qualification; provider-off/alternate defined | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| TQ-TECH-026 | SkillSpector | TRANSITIVE_SKILL_SCANNER | OPTIONAL_TRANSITIVE | REFERENCE | DOC-03 RepoContext/Semantic Context | source test/provider slot semantics preserved; runtime use requires exact candidate currentness/rights/host qualification; provider-off/alternate defined | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| TQ-TECH-027 | Gitleaks | TRANSITIVE_SECRET_SCANNER | OPTIONAL_TRANSITIVE | REFERENCE | DOC-07 TQAEP/Security | source test/provider slot semantics preserved; runtime use requires exact candidate currentness/rights/host qualification; provider-off/alternate defined | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| TQ-TECH-028 | GitHub Actions | CI_EXECUTOR | P1_WHERE_GITHUB | REFERENCE | DOC-09 CI Adapter | source test/provider slot semantics preserved; runtime use requires exact candidate currentness/rights/host qualification; provider-off/alternate defined | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| TQ-TECH-029 | OpenSSF Scorecard | OSS_POSTURE_SIGNAL | SUPPORT_CANDIDATE | EVAL | DOC-07 TQAEP/Security | source test/provider slot semantics preserved; runtime use requires exact candidate currentness/rights/host qualification; provider-off/alternate defined | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| TQ-TECH-030 | Hugging Face Skills | ECOSYSTEM_INTEROP | SUPPORT_CANDIDATE | EVAL | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | source test/provider slot semantics preserved; runtime use requires exact candidate currentness/rights/host qualification; provider-off/alternate defined | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| TQ-TECH-031 | Agent Safety Should Be a Runtime Contract | RESEARCH_DONOR | P3_RESEARCH_DONOR | REFERENCE | DOC-02 TechnologyAdmission / project-specific binding | source test/provider slot semantics preserved; runtime use requires exact candidate currentness/rights/host qualification; provider-off/alternate defined | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |

### 20.5 R2 Named Donor Workflows — 8/8
| Workflow ID | Capability role | PIPD canonical home | Treatment | Imported steps | Excluded semantics | Required test/exit | DOC-05 relevance | DOC-05 rationale |
|---|---|---|---|---|---|---|---|---|
| MISSION_TO_EXECUTION | mission→bounded execution orchestration | DOC-02 PI → DOC-03 S2E/WO/ECP → DOC-05 admission | TRANSLATE | mission decomposition, bounded work, evidence return | donor cannot grant PIPD lifecycle authority | trace continuity + no-execution-before-ADMIT; remove adapter cleanly | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| PHASES_RB00_RB15 | phase/runbook progression | DOC-09 Adoption Waves/Runbook | TRANSLATE | phase entry/exit/checkpoint/readback | donor phase labels not canonical lifecycle states | phase-to-canonical-state mapping; rollback/resume | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| WORKORDER_ADMISSION | WO→admission control | DOC-03/05 | KEEP_PATTERN | WO identity, permission, admission separation | WO/ECP never self-authorize | negative ECP-only/WO-only first mutation | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| CROSS_SESSION_PIPELINE | resume/handoff continuity | DOC-03/04 | TRANSLATE | subject/version/hash, checkpoint, context/evidence handoff | memory/session state not semantic authority | resume wrong-subject/stale-hash negative; purge/expiry | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| PROVIDER_ADMISSION | provider qualification/binding | DOC-02 TechnologyAdmission + DOC-03 currentness | TRANSLATE | pin/license/security/capability/exit | provider cannot own canonical semantics | provider-off/parity/currentness TTL | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| LONG_RUNNING_CONTROL | long-horizon checkpoint/recovery | DOC-03 ECP / DOC-09 runbook | TRANSLATE | checkpoint, stop/retry, recovery, evidence | no autonomous authority expansion | timeout/restart/recovery + scope containment | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |
| SELF_ITERATION_LOOP | bounded repair/iteration | DOC-07 rework/requalification | REFERENCE | repair loop under stable oracle | no self-issued PASS or requirement rewrite | mutation/rework stop + human/acceptor boundary | INDIRECT | Identity is preserved for anti-downgrade; DOC-05 consumes only terminal/currentness/qualification refs when the canonical owner makes it relevant, and does not adopt or materialize it by presence alone. |
| RELEASE_RECOVERY | release/rollback/recovery | DOC-09 Release Lane | TRANSLATE | artifact identity, recovery, rollback, evidence | release workflow cannot replace acceptance/qualification | digest/attestation/rollback/residue tests | DIRECT | Directly constrains or supplies a receiver/permission/admission/currentness/effect/rollback/evidence predicate; canonical ownership remains at the named home. |


## 18.6 H1-18C｜Layer-B denominator guard

Machine/audit invariant:

```text
layer_b_expected = 130
layer_b_present = 130
stable_id_unique = true
missing_ids = []
quarantine_softening = forbidden
presence_implies_adoption = false
```

Any future build missing one stable ID fails `TEST-TECH-OMIT-001 / OR-TECH-OMIT-001`. Any build changing a source quarantine state without an authority-supported TechnologyAdmission/CR fails `TEST-TECH-QUAR-001 / OR-TECH-QUAR-001`.

## 18.7 External currentness — support only, checked 2026-10-07

Currentness does not override P0/P1/P2 semantics. r2 preserves the independent audit's currentness conclusions and performed a fresh official-source support recheck for the most admission-relevant fast-moving items: MCP protocol revision 2026-07-28 explicit opt-in behavior; A2A latest released specification 1.0.0; OpenTelemetry semantic conventions 1.44.0 with GenAI conventions in the dedicated repository; GitHub Spec Kit 1.0.6; AG-UI 1.0.2 packages released 2026-10-05; Superpowers v6.4.2 dated 2026-09-25. These are support facts only; project pins remain PD/currentness facts.

# H1-19｜Mandatory Tests / Oracles / Destructive Fixtures

Blocking tests are stable contracts; a heading or self-PASS cannot substitute for the oracle. Every blocking case records `TEST_ID`, `ORACLE_ID`, expected result, first failing invariant, failure class, and recovery.

## 19.1 Core + mutation + authority/currentness matrix

| TEST_ID | ORACLE_ID | Class | Fixture | Expected | First failing invariant | Recovery |
|---|---|---|---|---|---|---|
| TEST-DOC05-POS-001 | OR-DOC05-POS-001 | Positive | valid PREDEV_READY + canonical handoff + bundle + policy + current validity | ADMIT | INV-03 | issue bounded admission |
| TEST-DOC05-NEG-001 | OR-DOC05-NEG-001 | Negative | canonical handoff missing required ref | NACK/HOLD | INV-01 | repair/reissue |
| TEST-DOC05-NEG-002 | OR-DOC05-NEG-002 | Negative | wrong receiver or subject/version/hash | DENY | INV-01/INV-05 | rebind/reissue |
| TEST-DOC05-NEG-003 | OR-DOC05-NEG-003 | Negative | ECP-only or WorkOrder self-authorization | DENY | INV-02/INV-03 | obtain independent ADMIT |
| TEST-DOC05-NEG-004 | OR-DOC05-NEG-004 | Negative | expired/replayed/revoked ApprovalToken | DENY | INV-05/INV-06 | new authorized token |
| TEST-DOC05-NEG-005 | OR-DOC05-NEG-005 | Negative | missing rollback or evidence-return contract | HOLD/DENY | INV-01/INV-07 | materialize missing contract |
| TEST-DOC05-EDGE-001 | OR-DOC05-EDGE-001 | Edge | currentness expires during admission | STALE/HOLD | INV-05 | refresh + reevaluate |
| TEST-DOC05-EDGE-002 | OR-DOC05-EDGE-002 | Edge | provider unavailable after evaluation | HOLD/rollback/provider-off | INV-05 | fallback/reissue |
| TEST-DOC05-ADV-001 | OR-DOC05-ADV-001 | Adversarial | prompt/tool injection widens scope | DENY | INV-05/INV-07 | quarantine external data + original scope |
| TEST-DOC05-APP-001 | OR-DOC05-APP-001 | Apparent-pass | provider/API success but no confirming readback | UNKNOWN_EFFECT | INV-04 | reobserve/reconcile |
| TEST-DOC05-APP-002 | OR-DOC05-APP-002 | Apparent-pass | schema PASS but semantic ADMIT hollow | FAIL | INV-07 | repair semantic refs/predicates |
| TEST-MUT-DOC05-001 | OR-MUT-DOC05-001 | Mutation | preserve headings but remove one `stop_conditions` item | FAIL/HANDOFF_BUNDLE_INCOMPLETE | INV-01/INV-07 | restore operation-specific stop condition |
| TEST-MUT-DOC05-002 | OR-MUT-DOC05-002 | Mutation | delete evidence-return raw result/checksum while keeping summary | FAIL/EVIDENCE_RETURN_INCOMPLETE | INV-07 | restore verifiable evidence field |
| TEST-MUT-DOC05-003 | OR-MUT-DOC05-003 | Mutation | replace CAND-04 P0/P1 `ADOPT_WITH_WRAPPER` with P2 `SELECTED_TRANSLATE` as canonical | FAIL/AUTHORITY_DRIFT | Authority order | restore canonical_disposition; retain P2 only as treatment |
| TEST-TECH-OMIT-001 | OR-TECH-OMIT-001 | Mutation | delete one of 130 Layer-B stable IDs | FAIL/LAYER_B_DENOMINATOR | Anti-downgrade | restore missing identity or explicit source-backed supersession |
| TEST-TECH-QUAR-001 | OR-TECH-QUAR-001 | Mutation | soften NOBJ-019/020/021/022 quarantine to ordinary support | FAIL/QUARANTINE_SOFTENING | Security anti-downgrade | restore source state; separate admission required |
| TEST-WRONG-AUTH-001 | OR-WRONG-AUTH-001 | Mutation | lower authority silently overrides higher authority | FAIL/AUTHORITY_DRIFT | Authority order | TEMP_CLOSE affected claim + adjudicate |
| TEST-STALE-EVD-001 | OR-STALE-EVD-001 | Mutation | reuse evidence from old subject hash/currentness window | FAIL/EVIDENCE_STALE | INV-05 | regenerate evidence for current subject |
| TEST-SELECTED-OMIT-001 | OR-SELECTED-OMIT-001 | Mutation | project TechnologyAdmission selects applicable capability but DOC-05 landing ref omitted | FAIL/SELECTED_TECH_LANDING_MISSING | INV-07 | materialize/reference exact dependency or CR |
| TEST-AH-ADV-001 | OR-AH-ADV-001 | Adversarial | goal hijack attempts to rewrite mission/scope | DENY | AGENT_HARNESS_GOAL_INTEGRITY | reject external instruction; preserve canonical mission |
| TEST-AH-ADV-002 | OR-AH-ADV-002 | Adversarial | tool misuse calls unadmitted tool/operation | DENY | AGENT_HARNESS_TOOL_POLICY | unknown tool default deny |
| TEST-AH-ADV-003 | OR-AH-ADV-003 | Adversarial | identity/privilege abuse elevates role | DENY | AGENT_HARNESS_IDENTITY | re-auth/rebind receiver |
| TEST-AH-ADV-004 | OR-AH-ADV-004 | Adversarial | memory/context poisoning injects false authority/currentness | HOLD/DENY | AGENT_HARNESS_MEMORY_TRUST | invalidate poisoned state; rebuild from trusted refs |
| TEST-AH-ADV-005 | OR-AH-ADV-005 | Adversarial | inter-agent trust abuse forwards authority not owned by sender | DENY | AGENT_HARNESS_HANDOFF_TRUST | re-establish receiver-bound delegation |
| TEST-AH-ADV-006 | OR-AH-ADV-006 | Adversarial | cascading failure propagates across shared resource | HOLD affected dependents | AGENT_HARNESS_CASCADE | contain + reverse-dependency invalidation |
| TEST-AH-ADV-007 | OR-AH-ADV-007 | Adversarial | rogue/unauthorized action occurs outside admission | FAIL_CLOSED | AGENT_HARNESS_ROGUE_ACTION | stop/contain/revoke/incident evidence |
| TEST-AH-ADV-008 | OR-AH-ADV-008 | Adversarial | sensitive context leaks in handoff/tracing | DENY/REDACT | AGENT_HARNESS_REDACTION | redact + rotate/revoke if exposed |

## 19.2 H1-19A｜Agent Harness eight-class mandatory denominator

`PROFILE-AGENT-HARNESS` STANDARD/ASSURED MUST reference exactly the eight `TEST-AH-ADV-001..008` fixtures in `AgentHarnessAdmissionProfile.adversarial_fixture_refs`. Omission of any class is `HOLD/AGENT_HARNESS_ASSURANCE_INCOMPLETE`.

## 19.3 Selected-technology omission / authority mutation semantics

- `TEST-SELECTED-OMIT-001` fires only when an applicable project TechnologyAdmission has a terminal selected/adopted state but the receiver/admission dependency is missing; a Layer-A registry row alone does not require installation.
- `TEST-MUT-DOC05-003` ensures lower-order P2 design treatment never overwrites P0/P1 canonical disposition.
- `TEST-TECH-OMIT-001` protects the Layer-B 130 identity denominator even for INDIRECT rows.
- `TEST-TECH-QUAR-001` prevents quarantine softening.

## 19.4 Destructive fixture execution policy

Fixtures should mutate serialized instances/registries while preserving superficial headings/counts so the oracle tests semantics, not formatting. Mutation output is rejected at the first failing invariant and records the exact changed property, subject hash, validator version and recovery path.

# H1-20｜Worked Engineering Scenarios

The scenarios below are concrete decision traces. They are examples of contract semantics, not claims that these actions were executed.

## SCN-01 Standard software change

| Field | Concrete value |
|---|---|
| Input state | PREDEV_READY; repo-local file edit |
| Handoff | valid handoff to implementation agent |
| Permission/effect class | `LOCAL_REVERSIBLE_WRITE` |
| Receiver checks | receiver verifies hash/instructions/path/checkpoint |
| Approval | not required unless repo policy elevates |
| Admission decision | ADMIT |
| Allowed/forbidden action | only exact files/commands; no other paths |
| Readback | git/readback + tests |
| Evidence | changed-file evidence + rollback receipt |
| Rollback/reconciliation | checkpoint rollback |
| Final legal state / claim ceiling | EXECUTION_ADMITTED before mutation; later state depends on evidence |

## SCN-02 Skill/Plugin effectful action

| Field | Concrete value |
|---|---|
| Input state | PREDEV_READY; skill can call external API |
| Handoff | handoff binds skill/host/provider refs |
| Permission/effect class | `EXTERNAL_REVERSIBLE_EFFECT` |
| Receiver checks | trigger/non-trigger/tool schema/network/secret/currentness |
| Approval | policy/human token if HIGH |
| Admission decision | ADMIT only for named API operation |
| Allowed/forbidden action | no extra endpoint/scope |
| Readback | API response + independent resource readback |
| Evidence | tool trace + reconciliation receipt |
| Rollback/reconciliation | compensating API / revoke |
| Final legal state / claim ceiling | CONFIRMED_EFFECT only after reconciliation |

## SCN-03 ASSURED agent harness

| Field | Concrete value |
|---|---|
| Input state | ASSURED profile; agent tools/handoffs |
| Handoff | handoff binds harness version/tool registry/guardrails |
| Permission/effect class | `PRIVILEGED_SECURITY_SENSITIVE` |
| Receiver checks | SoD, tool permissions, memory/context trust, currentness |
| Approval | required for high-risk tools |
| Admission decision | ADMIT per bounded tool/effect class |
| Allowed/forbidden action | no autonomous scope expansion |
| Readback | trace + tool result + independent readback |
| Evidence | checker evidence + effect receipt |
| Rollback/reconciliation | checkpoint/provider-off/revoke |
| Final legal state / claim ceiling | maker self-approval forbidden |

## SCN-04 Brownfield provider migration

| Field | Concrete value |
|---|---|
| Input state | incumbent live; shadow target prepared |
| Handoff | wave-specific handoff |
| Permission/effect class | `EXTERNAL_REVERSIBLE_EFFECT` |
| Receiver checks | parity/security/currentness/rollback window |
| Approval | required if material impact |
| Admission decision | ADMIT wave only |
| Allowed/forbidden action | cannot decommission incumbent early |
| Readback | shadow/readback/parity oracle |
| Evidence | wave evidence + residue proof |
| Rollback/reconciliation | cut back to incumbent |
| Final legal state / claim ceiling | next wave requires new receiver acceptance |

## SCN-05 External API mutation

| Field | Concrete value |
|---|---|
| Input state | current WorkOrder/ECP for remote update |
| Handoff | handoff binds target account/resource |
| Permission/effect class | `EXTERNAL_REVERSIBLE_EFFECT` |
| Receiver checks | target/scope/data class/readback plan |
| Approval | conditional by risk/policy |
| Admission decision | ADMIT exact request |
| Allowed/forbidden action | no neighboring resources |
| Readback | GET/readback or independent query |
| Evidence | provider response + observation + reconciliation |
| Rollback/reconciliation | reverse/compensate |
| Final legal state / claim ceiling | 2xx alone remains UNKNOWN_EFFECT |

## SCN-06 High-risk Human approval

| Field | Concrete value |
|---|---|
| Input state | production/identity/financial/physical-like effect |
| Handoff | handoff references approval requirement |
| Permission/effect class | `IRREVERSIBLE_OR_HIGH_IMPACT` |
| Receiver checks | high/critical risk, SoD, compensation |
| Approval | valid subject-bound token mandatory |
| Admission decision | ADMIT only after token validation |
| Allowed/forbidden action | no widened scope or reused nonce |
| Readback | post-effect observation |
| Evidence | human token ref + checker receipt |
| Rollback/reconciliation | contain/compensate if possible |
| Final legal state / claim ceiling | authorized bounded attempt only |

## SCN-07 Expired token

| Field | Concrete value |
|---|---|
| Input state | otherwise valid PREDEV_READY |
| Handoff | handoff has expired token ref |
| Permission/effect class | `PRIVILEGED_SECURITY_SENSITIVE` |
| Receiver checks | receiver checks expiry before admission |
| Approval | expired → invalid |
| Admission decision | DENY |
| Allowed/forbidden action | no action |
| Readback | none |
| Evidence | denial evidence |
| Rollback/reconciliation | issue new token |
| Final legal state / claim ceiling | remains PREDEV_READY/HOLD or DENY, not EXECUTION_ADMITTED |

## SCN-08 Wrong subject/hash

| Field | Concrete value |
|---|---|
| Input state | handoff ref differs from current bytes |
| Handoff | packet received |
| Permission/effect class | `any` |
| Receiver checks | hash compare fails first |
| Approval | irrelevant until corrected |
| Admission decision | NACK/DENY |
| Allowed/forbidden action | no action |
| Readback | none |
| Evidence | identity mismatch evidence |
| Rollback/reconciliation | reissue handoff |
| Final legal state / claim ceiling | no promotion |

## SCN-09 UNKNOWN_EFFECT

| Field | Concrete value |
|---|---|
| Input state | provider returned success; no confirming readback |
| Handoff | valid admitted attempt |
| Permission/effect class | `EXTERNAL_REVERSIBLE_EFFECT` |
| Receiver checks | effect chain checked |
| Approval | already satisfied for attempt |
| Admission decision | admission existed, but success claim blocked |
| Allowed/forbidden action | no duplicate blind retry |
| Readback | reobserve/readback |
| Evidence | UNKNOWN_EFFECT receipt |
| Rollback/reconciliation | reconcile/rollback based on oracle |
| Final legal state / claim ceiling | claim remains unresolved effect |

## SCN-10 Partial effect + compensation

| Field | Concrete value |
|---|---|
| Input state | multi-step external mutation partially applied |
| Handoff | valid handoff/admission |
| Permission/effect class | `EXTERNAL_REVERSIBLE_EFFECT` |
| Receiver checks | partial state observed |
| Approval | as required |
| Admission decision | attempt legal; next action COMPENSATE |
| Allowed/forbidden action | no success promotion |
| Readback | readback shows subset |
| Evidence | PARTIAL_EFFECT receipt |
| Rollback/reconciliation | compensation + residue readback |
| Final legal state / claim ceiling | COMPENSATED_EFFECT if bounded state restored |

## SCN-11 Receiver NACK

| Field | Concrete value |
|---|---|
| Input state | sender says ready; required ref missing |
| Handoff | handoff received |
| Permission/effect class | `any` |
| Receiver checks | receiver checklist finds missing ref |
| Approval | not evaluated |
| Admission decision | no admission |
| Allowed/forbidden action | no mutation |
| Readback | none |
| Evidence | NACK reason code |
| Rollback/reconciliation | sender repair/reissue |
| Final legal state / claim ceiling | sender-ready does not change receiver state |

## SCN-12 Independent vertical slice

| Field | Concrete value |
|---|---|
| Input state | slice A closed; slice B still PI/PD |
| Handoff | slice-A-specific handoff |
| Permission/effect class | `as slice A requires` |
| Receiver checks | shared dependencies/writers conflict-free |
| Approval | as required |
| Admission decision | ADMIT slice A |
| Allowed/forbidden action | slice B resources forbidden |
| Readback | slice A readback only |
| Evidence | slice A evidence only |
| Rollback/reconciliation | slice A rollback |
| Final legal state / claim ceiling | slice A may execute; slice B remains pre-execution |

## SCN-13 Technology selected not installed

| Field | Concrete value |
|---|---|
| Input state | DOC-02 project TechnologyAdmission has an applicable terminal selection; P0/P1 design disposition remains separately preserved |
| Handoff | handoff has no materialized runtime dependency yet |
| Permission/effect class | `READ_ONLY preflight` |
| Receiver checks | receiver reads TechnologyAdmission/currentness |
| Approval | none for inspection |
| Admission decision | HOLD effectful use until materialized/bound/current |
| Allowed/forbidden action | cannot infer install from design selection |
| Readback | installation/binding readback when later performed |
| Evidence | materialization evidence when available |
| Rollback/reconciliation | uninstall/provider-off contract predeclared |
| Final legal state / claim ceiling | DESIGN_SELECTED only |

## SCN-14 Tool success world diverged

| Field | Concrete value |
|---|---|
| Input state | CLI/API returned success but readback differs |
| Handoff | valid admitted attempt |
| Permission/effect class | `EXTERNAL_REVERSIBLE_EFFECT` |
| Receiver checks | receiver invokes reconciliation oracle |
| Approval | already satisfied for attempt |
| Admission decision | attempt admitted, effect not confirmed |
| Allowed/forbidden action | no success claim |
| Readback | conflicting readback |
| Evidence | CONFLICTING_EFFECT receipt |
| Rollback/reconciliation | reconcile/rollback/compensate |
| Final legal state / claim ceiling | world-effect claim remains blocked |

## 20.15 H1-20A｜End-to-end typed object chains

The following are **machine-shape examples**, not execution claims. Hashes are fixture values.

### EX-CHAIN-01 — standard reversible repository write

```yaml
subject_ref: {id: SLICE-A, version: v3, hash: "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"}
handoff:
  handoff_id: HOFF-A
  receiver: impl-agent-A
  required_refs: [WO-A, ECP-A, TQAEP-A, CURR-A]
  permission_required: [REPO_WRITE]
  entry_gate: PREDEV_READY
  allowed_scope: [repo://src/a.py]
  forbidden_scope: [repo://.github/workflows, secret://*]
  rollback: {reversibility_class: REVERSIBLE, checkpoint_ref: CKPT-A, procedure_ref: RB-A}
  expected_evidence_return: [EVD-CONTRACT-A]
receiver_bundle:
  why: implement accepted requirement REQ-A
  what: edit one file and run exact tests
  where: repo://src/a.py
  how: WO-A procedure only
  stop_conditions: [repo hash drift, target path escapes scope, checkpoint missing]
receiver_decision: ACCEPT_HANDOFF
permission_effect_decision: {permission_class: REPO_WRITE, policy_result: ALLOW_CANDIDATE, risk_class: MEDIUM, effect_class: REVERSIBLE_WRITE}
approval_token: null
admission: {admission_id: ADM-A, decision: ADMIT, operation: edit, target_system: repo-A, scope: [repo://src/a.py]}
admission_validity: {status: CURRENT, valid_from: "2026-10-07T12:00:00+08:00", expires_at: "2026-10-07T13:00:00+08:00"}
effect: local reversible write
readback: [git diff, test oracle]
evidence_return: changed artifact checksum + command result + oracle + environment + producer/checker
rollback: CKPT-A + RB-A
final_legal_state: execution attempt may proceed only while validity CURRENT
claim_ceiling: EXECUTION_ADMITTED_ONLY
```

### EX-CHAIN-02 — high-risk external effect with approval

```yaml
subject_ref: {id: PROD-RESOURCE-7, version: v9, hash: "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb"}
handoff_ref: HOFF-P7
receiver_decision: ACCEPT_HANDOFF
permission_effect_decision:
  permission_class: PRODUCTION_CHANGE
  policy_result: ALLOW_CANDIDATE
  risk_class: CRITICAL
  effect_class: HIGH_RISK_EFFECT
approval_token_binding:
  token_ref: TOK-P7
  nonce_state_before: ISSUED
  embedded_token_digest_matches_store: true
  approver_authorized_and_not_maker: true
admission: {admission_id: ADM-P7, decision: ADMIT, operation: bounded-prod-change, target_system: prod-7}
nonce_transition: ISSUED -> CONSUMED atomically on ADM-P7 issuance
admission_validity: {status: CURRENT, expires_at: earliest(token expiry, currentness TTL, project admission TTL)}
authorized_attempt: exact admitted scope only
provider_response: success-is-not-effect-truth
observation: OBS-P7
readback: RBK-P7 independent target query
reconciliation: CONFIRMED_EFFECT only if oracle passes; otherwise UNKNOWN/PARTIAL/CONFLICTING + compensate/rollback
evidence_return: includes approval ref, raw result refs, checker, checksums, rollback/residue result
claim_ceiling: AUTHORIZED_BOUNDED_ATTEMPT_UNTIL_RECONCILIATION
```

### EX-CHAIN-03 — brownfield cutover wave

```yaml
input_state: incumbent provider live; target in shadow parity
subject_ref: {id: MIG-WAVE-2, version: v2, hash: "cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc"}
handoff: wave-specific; incumbent rollback window bound
receiver_checks: [parity oracle, provider currentness, security/license, shared resources, residue plan]
permission_effect_decision: {permission_class: MIGRATE, risk_class: HIGH, effect_class: EXTERNAL_EFFECT, approval_required: true}
approval: scoped token for wave-2 only
admission: ADMIT wave-2 scope; wave-3 and decommission explicitly forbidden
readback: target health + incumbent availability + parity
failure_path: HOLD -> cut back to incumbent -> residue cleanup -> evidence return
success_path: keep rollback window until next wave independently accepted/admitted
claim_ceiling: wave-2 effect only; no global migration completion claim
```

### EX-CHAIN-04 — failing unknown secret/network resource

```yaml
input_state: PREDEV_READY
requested_action: tool requests SECRET_READ and network call to previously unknown endpoint
handoff: structurally valid but endpoint/secret scope absent
permission_policy:
  default_decision: DENY
  secret_policy: SCOPED
  network_policy: SCOPED
receiver_decision: HOLD or NACK_UNKNOWN_RESOURCE
permission_effect_decision: DENY
approval_token: not evaluated as a bypass; approval cannot legalize an unknown target
admission: DENY / not issued
allowed_action: none
recovery: bind exact secret handle + endpoint in PD/WorkOrder/ECP/policy; obtain scoped approval; reissue handoff; reevaluate
final_legal_state: PREDEV_READY/HOLD
claim_ceiling: NO_EXECUTION_AUTHORITY
```

# H1-21｜Failure / Degrade / TT / CR

DOC-05 keeps four namespaces distinct. UI wording may project them, but machine records use exact P0 values.

## 21.1 Exact namespace separation

```text
lifecycle_state = canonical lifecycle truth or null
degrade_status  = NONE | DEGRADED_OBSERVABILITY | LOCAL_OUTPUT_WITH_SCOPED_TT | BLOCKED_EXTERNAL | SECURITY_QUARANTINE | CURRENTNESS_STALE | SOURCE_MISSING
decision        = CONTINUE_LOCAL | HOLD | DENY | TEMP_CLOSE | BLOCK_EXTERNAL
claim_ceiling   = maximum honest claim
```

`TEMP_CLOSED` is a lifecycle/side-state label elsewhere in PIPD; it is **not** substituted for P0 `decision=TEMP_CLOSE`. `BLOCKED_EXTERNAL` is a `degrade_status`; `decision=BLOCK_EXTERNAL` is the decision token. They MUST NOT alias.

## 21.2 Receiver decision vs lifecycle/projection state mapping

| Namespace | Token | Meaning |
|---|---|---|
| ReceiverDecision | `ACCEPT_HANDOFF` | receiver accepts handoff payload for admission evaluation only |
| ReceiverDecision | `NACK/HOLD/DENY` | receiver rejects/pauses/denies handoff evaluation |
| projection substate | `HANDOFF_ACCEPTED` | derived display/state projection after a valid `ACCEPT_HANDOFF` receipt |
| lifecycle gate | `EXECUTION_ADMITTED` | only after canonical `ExecutionAdmission.decision=ADMIT` and current validity |

`ACCEPT_HANDOFF != HANDOFF_ACCEPTED != EXECUTION_ADMITTED` as object/state namespaces even when a projection is derived from the receiver receipt.

## 21.3 TT/CR register after r2 repair

| ID | Type | Source conflict/finding | r2 disposition | Blocking? |
|---|---|---|---|---|
| `CR-DOC05-001` | compatibility adjudication | P1 §38 drafting template vs canonical handoff schema | canonical schema for finalized object + ReceiverHandoffBundle sidecar; locally closed | NO |
| `CR-DOC05-002` | authority repair | P2 `SELECTED_*` vs P0/P1 canonical dispositions | P0/P1 restored as `canonical_disposition`; P2 retained as `project_design_treatment` | NO |
| `CR-DOC05-003` | extension schema repair | r1 pseudo-schemas | versioned Draft 2020-12 sidecar schemas + validator ABI | NO |

`open_TT_author_side=[]`. Independent re-audit remains required before any claim of independent acceptance; that is a claim boundary, not an unresolved DOC-05 engineering TT.

# H1-22｜Source Coverage / Traceability / Atomic Requirement Closure

## 22.1 Full-Scan Receipt — physical bytes, no sampling

Counting convention: `physical_lines = len(UTF-8 text.splitlines())`; `headings = ^#{1,6}\s`. This fixes the r1 off-by-one receipt issue.

| ID | Physical source | Bytes | Physical lines | H1-H6 headings | SHA-256 | Scan |
|---|---|---|---|---|---|---|
| P0 | Pre-Implementation_and_Pre-Dev_Lifecycle_Specification_總藍圖.md | 149077 | 2996 | 112 | 9a8323e5237c1555a76d9a75f706e3552d79c192915cc782b76b211c7f27d527 | FULL_UTF8_READ_NO_SAMPLING |
| P1 | Pre-Implementation_and_Pre-Dev_Lifecycle_Specification_canonical_standard.md | 209157 | 7176 | 261 | 6f6aafece90b34e33786647e14fee840f5424893995b3164cbb52953a5c4f14a | FULL_UTF8_READ_NO_SAMPLING |
| P2 | PIPD_LS_skeleton_2026-10-06_r2_FULL_REPAIR(1).md | 376599 | 2668 | 143 | 03bb3609dc67f85fa4b683a93736cf162e9047b6b253182aa3fdba11ba40cb28 | FULL_UTF8_READ_NO_SAMPLING |
| P3 | Pre-Implementation-PKG  Pre-Dev-PKG 生命週期規格_總討論(1).md | 77326 | 2559 | 92 | be1858e860092fb1751bf0524cd22b6939138b6835ce8f452bfc30894f945a95 | FULL_UTF8_READ_NO_SAMPLING |
| P4 | PIPD_LS_DOC-00_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY(1).md | 251982 | 2292 | 92 | be3a672ec20aa0e6b5e0e35097fc08de749bfe7f59f827d18e38aef67dd68ea4 | FULL_UTF8_READ_NO_SAMPLING |
| INSTRUCTION | 《PIPD_LS_DOC-05》全量正文產出指令 / 貼上的文字 (1)(7).txt | 39292 | 1892 | 86 | 460d60d57345fac438d373ece1f43ca359c935f71c8e231cfe152118317cb82f | FULL_UTF8_READ_NO_SAMPLING |
| AUDIT | AUDIT_PIPD_LS_DOC-05_2026-10-07_r1_FULL_SUBSTANTIVE_BODY_FULL_AUDIT(1).md | 39519 | 554 | 35 | dce8efd06d892385198e78d07aecdbe5fa4046dda71e03ce452c3fd157fef415 | FULL_UTF8_READ_NO_SAMPLING |
| PREDECESSOR | PIPD_LS_DOC-05_2026-10-07_r1_FULL_SUBSTANTIVE_BODY.md | 154251 | 2711 | 140 | 6463444fc6b47c945b9dd2ee2c8f4f07a3a0f7b4fad0a4a3484f16bd7b86967c | FULL_UTF8_READ_NO_SAMPLING |

## 22.2 Clause-level exact-anchor coverage ledger

| Source | Exact substantive anchor | Atomic requirement | Mapped DOC-05 anchor | Status |
|---|---|---|---|---|
| P0 | # 12. Permission / Admission Model | effectful pre-admission default DENY; high risk approval; secret handles only | H1-08A / H1-09A | CLOSED |
| P0 | # 14. Degrade Namespace Separation | four distinct namespaces and exact enums | H1-21.1 | CLOSED |
| P0 | # 15. Tool / Technology / Workflow / OSS — 22/22 Blueprint-Depth Registry | 22 authoritative dispositions + trigger/non-trigger + exit | H1-18A | CLOSED |
| P0 | # 11. Change Taxonomy & Affected-Only Invalidation | six exact change classes | H1-15A | CLOSED |
| P0 | §7.2–7.9 project-control schemas | manifest/permission/change/degrade/currentness/adapter/package machine bindings | H1-17A | CLOSED |
| P0 | # 18. Agent Harness / Agentic Runtime Target Profile — Complete | eight agentic adversarial classes | H1-17.7 / H1-19A | CLOSED |
| P1 | # 24. Receiver Handoff Contract | WHY/WHAT/WHERE/HOW/STOP receiver self-sufficiency | H1-06A/B | CLOSED |
| P1 | # 25. Evidence Return Contract | subject-bound evidence return field denominator | H1-14A | CLOSED |
| P1 | # 26. Security & Permission Rules | unknown resource default deny + secret/human approval | H1-08A | CLOSED |
| P1 | # 23. Target Profile — Agent Harness / Agentic Runtime | typed state/memory/handoff/redaction/escalation/threat refs | H1-17.7 | CLOSED |
| P1 | 18.2 `handoff.schema.json` | final canonical ExecutionHandoff structure | H1-06.1 | CLOSED |
| P1 | # 38. Execution Handoff YAML Template | draft placeholders/stop_conditions compatibility | H1-06.4 | CLOSED_LOCAL_ADJUDICATION |
| P2 | # 12 DOC-05 Handoff / Permission / Effect / Execution Boundary Skeleton | DOC-05 topology/ownership | H1-05..H1-17 | CLOSED |
| P2 | ## 19.3 P0/P1 Canonical 22 Technology Baseline | P2 design treatment preserved but non-authoritative vs P0/P1 | H1-18A | CLOSED |
| P2 | # 20 Carrier Named Capability / Technology / Workflow Identity-Preserving Crosswalks | 130 stable Layer-B identities | H1-18B/C | CLOSED |
| P3 | Execution Handoff Manifest discussion | thin receiver manifest + evidence return | H1-06A / H1-14A | CLOSED |
| P4 | DOC-05 family row / QS-08 change-drift re-entry | navigation/readback only; exact sibling responsibilities | H1-03 / H1-15A | CLOSED |
| INSTRUCTION | # 7 invariants | rejectable handoff, identity separation, first mutation, world effect, subject-bound authority, SoD, prose/machine equivalence | H1-05..H1-19 | CLOSED |
| INSTRUCTION | # 9 technology integration | DOC-02 remains TechnologyAdmission owner; named landing and anti-downgrade | H1-18 | CLOSED |
| INSTRUCTION | # 13 Mandatory Test / Oracle / Destructive Fixture Set | positive/negative/edge/adversarial/apparent-pass + blocking metadata | H1-19 | CLOSED |
| INSTRUCTION | # 14 Worked Examples | 14 required scenarios | H1-20 + H1-20A | CLOSED |
| AUDIT | # 4 Findings Register | 7 S1 + 10 S2 + 5 S3 + 2 S4 | H1-23.1 repair closure ledger | CLOSED_AUTHOR_SIDE |

## 22.3 Audit finding closure ledger — 24/24

| Finding | Requirement/problem | Exact repaired anchor | Author-side state |
|---|---|---|---|
| F-S1-001 | Technology disposition authority drift | H1-18A / H1-18C | CLOSED_AUTHOR_SIDE |
| F-S1-002 | Anti-downgrade over-promotion | H1-18.1 / H1-18A | CLOSED_AUTHOR_SIDE |
| F-S1-003 | Handoff/receiver self-sufficiency incomplete | H1-06A / H1-06B | CLOSED_AUTHOR_SIDE |
| F-S1-004 | Evidence Return absent | H1-14A | CLOSED_AUTHOR_SIDE |
| F-S1-005 | P0 machine control bindings absent | H1-17A | CLOSED_AUTHOR_SIDE |
| F-S1-006 | DOC-05 pseudo-schemas | H1-17B/H1-17C | CLOSED_AUTHOR_SIDE |
| F-S1-007 | Layer-B 130/130 missing/quarantine softening | H1-18B/H1-18C | CLOSED_AUTHOR_SIDE |
| F-S2-001 | ADMIT validity/time window unbound | H1-10A | CLOSED_AUTHOR_SIDE |
| F-S2-002 | degrade namespace regression | H1-21.1 | CLOSED_AUTHOR_SIDE |
| F-S2-003 | six-class change taxonomy absent | H1-15A | CLOSED_AUTHOR_SIDE |
| F-S2-004 | Agent Harness assurance incomplete | H1-17.7/H1-19A | CLOSED_AUTHOR_SIDE |
| F-S2-005 | P1 prose/schema conflict | H1-06.4 CR-DOC05-001 | CLOSED_LOCAL_ADJUDICATION |
| F-S2-006 | mutation denominator incomplete | H1-19.1/H1-19.3 | CLOSED_AUTHOR_SIDE |
| F-S2-007 | technology landing template-homogeneous | H1-18A machine registry | CLOSED_AUTHOR_SIDE |
| F-S2-008 | validator registries unspecified | H1-17C | CLOSED_AUTHOR_SIDE |
| F-S2-009 | approval/handoff/admission join incomplete | H1-09A | CLOSED_AUTHOR_SIDE |
| F-S2-010 | SECRET_READ/unknown resource not deterministic | H1-08A | CLOSED_AUTHOR_SIDE |
| F-S3-001 | worked scenarios shallow | H1-20A typed chains | CLOSED_AUTHOR_SIDE |
| F-S3-002 | receiver token/projection state mapping absent | H1-21.2 | CLOSED_AUTHOR_SIDE |
| F-S3-003 | source line counts off-by-one | H1-22.1 physical `splitlines()` receipt | CLOSED_AUTHOR_SIDE |
| F-S3-004 | atomic mappings inaccurate | H1-22.2 exact anchor ledger | CLOSED_AUTHOR_SIDE |
| F-S3-005 | open_TT/blocking_findings self-claim too strong | H1-21.3 + H1-23 claim separation | CLOSED_AUTHOR_SIDE |
| F-S4-001 | source_publisher misuse | H1-18.3/18.4 source_owner_or_project separated from recheck policy | CLOSED_AUTHOR_SIDE |
| F-S4-002 | 22 independent YAML snippets | H1-18.3 single registry | CLOSED_AUTHOR_SIDE |

## 22.4 Atomic composite-demand decomposition

Composite terms such as “each / separately / corresponding / all tools/technology/workflow/OSS” are closed as independent denominators rather than one aggregate assertion:

| Composite demand | Atomic denominator | r2 closure |
|---|---:|---|
| Layer-A technology candidates | 22 | `22/22` authority-correct rows + one machine registry |
| Layer-B named identities | 130 | `130/130` stable-ID relevance crosswalk |
| Agent Harness adversarial classes | 8 | `8/8` stable TEST/ORACLE fixtures |
| P0 change classes | 6 | `6/6` exact enum + reaction matrix |
| P0 degrade namespaces | 4 fields | exact lifecycle/degrade/decision/claim separation |
| Receiver self-sufficient questions | 10 (`WHY/WHAT/WHERE/HOW/ALLOWED/FORBIDDEN/ENTRY/STOP/ROLLBACK/EVIDENCE`) | ReceiverHandoffBundle + canonical handoff |
| P1 Evidence Return minimum fields | 11 core groups + redaction/retention/freshness extensions | H1-14A machine schema |
| Mandatory worked scenarios | 14 | retained 14 + 4 full typed chains |
| Audit findings | 24 | 24 exact closure rows |

No heading/count alone is considered substantive closure; every denominator above has body-level fields/rules/tests.

## 22.5 Final-source mutation guard

A future patch fails source coverage if any stable source anchor, Layer-A ID, Layer-B ID, audit finding ID, mandatory test class, or schema `$id` disappears without an authority-supported supersession/CR and an explicit replacement mapping.

# H1-23｜Post-Body Destructive Review / Final Self-Conformance

This section is an **author-side repair verification**, not an Independent PASS. The independent audit that triggered r2 remains external evidence; a new independent re-audit is required before `accept_as_final_canonical_DOC05=true` can be claimed externally.

## 23.1 Audit acceptance gate replay

| Gate from AUDIT §11 | r2 author-side result | Evidence anchor |
|---|---|---|
| 9 disposition drifts removed | PASS_AUTHOR_SIDE | H1-18A canonical vs P2 treatment columns |
| Layer-A trigger/non-trigger/applicability restored | PASS_AUTHOR_SIDE | H1-18A machine registry |
| self-sufficient WHY/WHAT/WHERE/HOW/STOP | PASS_AUTHOR_SIDE | H1-06A/B |
| evidence-return denominator machine-bound | PASS_AUTHOR_SIDE | H1-14A |
| P0 permission/currentness/change/package controls referenced | PASS_AUTHOR_SIDE | H1-17A |
| DOC-05 records real schemas + semantic validator | PASS_AUTHOR_SIDE | H1-17B/C |
| all ADMIT cases time/currentness-bound | PASS_AUTHOR_SIDE | H1-10A |
| Layer-B denominator 130/130 | PASS_AUTHOR_SIDE | H1-18B/C |
| pytest/GitHub Actions/CycloneDX/Gitleaks quarantine preserved | PASS_AUTHOR_SIDE | H1-18B exact source rows |
| exact P0 degrade namespaces restored | PASS_AUTHOR_SIDE | H1-21.1 |
| exact P0 change classes restored | PASS_AUTHOR_SIDE | H1-15A |
| Agent Harness eight adversarial classes | PASS_AUTHOR_SIDE | H1-19A |
| mutation + selected-tech omission fixtures | PASS_AUTHOR_SIDE | H1-19.1/19.3 |
| token ref/embed/nonce/revocation deterministic | PASS_AUTHOR_SIDE | H1-09A |
| 22 entries no universal test/rollback boilerplate | PASS_AUTHOR_SIDE | H1-18A single registry using unique P0 + per-item deltas |
| atomic trace exact corrected anchors | PASS_AUTHOR_SIDE | H1-22.2/22.3 |
| source line/hash receipt recomputed | PASS_AUTHOR_SIDE | H1-22.1 |
| independent audit zero S1/S2 | **NOT_CLAIMED / RE-AUDIT REQUIRED** | external checker must execute |

## 23.2 Destructive self-check answers

```text
Can sender readiness authorize execution? NO.
Can ECP/WorkOrder/TQAEP authorize execution? NO.
Can ACCEPT_HANDOFF alone authorize execution? NO.
Can ADMIT be timeless? NO — AdmissionValidityRecord required.
Can lower-order P2 SELECTED_* replace P0/P1 canonical disposition? NO.
Can a Layer-A row imply installation/materialization? NO.
Can a Layer-B identity disappear without disposition? NO.
Can quarantined pytest/GitHub Actions/CycloneDX/Gitleaks be softened by wording? NO.
Can unknown tool/command/path/network/secret be implicitly allowed? NO.
Can SECRET_READ proceed solely because risk was labeled MEDIUM? NO.
Can an approval ref point to different bytes than embedded token? NO.
Can a consumed/revoked nonce issue another ADMIT? NO.
Can API/CLI/provider success produce CONFIRMED_EFFECT? NO.
Can summary-only evidence satisfy evidence return? NO.
Can Agent Harness ASSURED omit one of eight adversarial classes? NO.
Can P0 degrade_status and decision tokens be mixed? NO.
Can an unrelated slice be invalidated merely because another slice changed? NO.
```

## 23.3 Honest r2 claim ceiling

```yaml
materialization: DOC05_R2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY_MATERIALIZED
author_side_repair_findings_open: 0
open_TT_author_side: []
independent_reaudit: REQUIRED
runtime_execution: NOT_EXECUTED
provider_binding: NOT_BOUND
validator_installed_in_target_repo: NOT_CLAIMED
verification: NOT_CLAIMED
qualification: NOT_CLAIMED
independent_pass: NOT_CLAIMED
human_ratification: NOT_CLAIMED
release_candidate: NOT_CLAIMED
production_pass: NOT_CLAIMED
```

The artifact therefore repairs the document/source findings without converting author-side materialization into runtime, independent, Human, release, or production truth.

# Packaging Receipt

```yaml
artifact_id: PIPD_LS_DOC-05
version: 2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY
supersedes: PIPD_LS_DOC-05_2026-10-07_r1_FULL_SUBSTANTIVE_BODY
supersedes_sha256: 6463444fc6b47c945b9dd2ee2c8f4f07a3a0f7b4fad0a4a3484f16bd7b86967c
repair_strategy: HIGH_RETENTION_FULL_REPAIR_NO_ARCHITECTURE_RESET
source_scan: FULL_NO_SAMPLING
layer_a_candidates: 22
layer_b_stable_id_denominator: 130
audit_findings_addressed_author_side: 24
author_side_blocking_findings_open: 0
open_TT_author_side: []
independent_reaudit: REQUIRED
self_hash_policy: "Final SHA-256/bytes/physical_lines are external packaging receipt properties to avoid recursive self-hash; reported by delivery wrapper after serialization."
claim_ceiling: DOC05_R2_HIGH_RETENTION_FULL_REPAIR_MATERIALIZED__INDEPENDENT_REAUDIT_REQUIRED__NOT_EXECUTED_NOT_PROVIDER_BOUND_NOT_VERIFIED_NOT_QUALIFIED_NOT_INDEPENDENT_PASS_NOT_HUMAN_RATIFIED_NOT_RELEASED_NOT_PRODUCTION_VERIFIED
```

**END OF `PIPD_LS_DOC-05_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY`**
