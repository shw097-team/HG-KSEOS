---
artifact_id: "PIPD_LS_DOC-07"
external_formal_name: "Pre-Implementation & Pre-Dev Lifecycle Specification — DOC-07 Verification / Oracle / Fixture Reference"
internal_short_name: "PIPD_LS_DOC-07"
artifact_type: "FULL_SUBSTANTIVE_BODY_HIGH_RETENTION_FULL_REPAIR_R2"
version: "2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY"
generated_at: "2026-10-07T13:38:00+08:00"
timezone: "Asia/Taipei"
standard_id: "PIPD-LIFECYCLE-SPEC"
standard_version: "1.1.0"
blueprint_id: "PIPD-LIFECYCLE-BLUEPRINT"
blueprint_version: "1.1.0"
canonical_archetype: "Conformance"
canonical_writer: "PIPD_LS_DOC-07"
patch_mode: "HIGH_RETENTION_R2_NO_ARCHITECTURE_RESET / AUDIT_CLOSURE / ZERO_SILENT_LOSS"
supersedes: "PIPD_LS_DOC-07_2026-10-07_r1_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY"
supersedes_sha256: "3a5d25be0ff75572e376575000513591eb713887015b1a653657eb56c05b05b9"
repair_controller: "AUDIT_PIPD_LS_DOC-07_2026-10-07_r1_FULL_AUDIT_REPAIR_REQUIRED"
repair_controller_sha256: "96b93631afb089c36182691c05b12718789044892e33575157cb34b8bc1c5cc2"
sampling: false
source_mode: "FULL_CORPUS_NO_SAMPLING_FILES_FIRST_SOURCE_BOUND"
authority_order:
  - "CURRENT_PATCH_TASK"
  - "AUDIT_REPAIR_CONTROLLER"
  - "A1_BLUEPRINT"
  - "A2_CANONICAL_STANDARD"
  - "A3_REPAIRED_SKELETON"
  - "A4_DESIGN_HISTORY"
  - "R1_HIGH_RETENTION_PATCH_BASE"
claim_ceiling:
  - "DOC07_R2_FULL_SUBSTANTIVE_BODY_MATERIALIZED"
  - "AUTHOR_SIDE_REPRODUCIBLE_SELF_AUDIT_PASS_R2"
  - "NOT_TARGET_REPO_BOUND"
  - "NOT_IMPLEMENTED"
  - "NOT_INSTALLED"
  - "NOT_BOUND"
  - "NOT_ENABLED"
  - "NOT_RUNTIME_VERIFIED"
  - "NOT_INDEPENDENT_PASS"
  - "NOT_HUMAN_RATIFIED"
  - "NOT_RELEASED"
  - "NOT_PRODUCTION_PASS"
open_tt:
  - "TT-DOC07-CUR-001"
  - "TT-DOC07-CUR-002"
  - "TT-DOC07-CUR-003"
closed_tt_in_r2:
  - "TT-DOC07-CUR-004-TRIVY-STALENESS"
open_cr: []
audit_gate_target: 17
audit_gate_status: "PASS_AUTHOR_SIDE_R2"
---

# PIPD_LS_DOC-07 — Verification / Oracle / Fixture Reference

> **R2 repair status:** high-retention upgrade over R1. The architecture spine is retained; machine identity, executable ABI, effect validation, source coverage, profile denominators, technology/workflow identity, typed outcome namespaces, machine catalog and reproducible self-audit are repaired in-place.

> **Canonical role:** DOC-07 writes verification / oracle / fixture reference semantics. It supports `VERIFYING` / `VERIFIED`; it does **not** become a second lifecycle authority, execution permission authority, independent checker, release authority, or production authority.

# 00｜Artifact Identity / Legal Role / Claim Boundary

R2 **integrates + covers + replaces** R1 as the downstream DOC-07 reading surface. The repair controller found R1 useful as a substantive spine but not eligible as final canonical DOC-07 because machine-critical closure was overstated. R2 therefore preserves correct R1 logic and replaces only defective or incomplete contracts.

## 00.1 R2 supersession semantics

- `supersedes`: R1 exact target hash `3a5d25be0ff75572e376575000513591eb713887015b1a653657eb56c05b05b9`.
- `preserve_architecture`: `true`.
- `architecture_reset`: `false`.
- `silent_drop`: forbidden.
- `silent_rename`: forbidden.
- `source_identity_preservation`: mandatory for CAND/NOBJ/ECP/ADD/MSC/TQ/workflow donor registries.
- `machine registry generation`: deterministic from canonical tuples; no hand-copied Appendix A.
- `result namespaces`: conformance / admission / effect / recovery / finding are separated.
- `selected technology`: design selection only; no installed/bound/enabled/runtime claim.
- `author-side self-audit`: may establish only reproducible local structural/machine closure; never Independent PASS.

## 00.2 R2 repair-controller closure map

| Finding | R2 repair | Primary destination |
|---|---|---|
| AUD-D07-S1-001 | regenerate exact 86 tuples from A1; escaped-pipe regression | Appendix A/E |
| AUD-D07-S1-002 | materialize 219-row source→atomic coverage ledger | Appendix I |
| AUD-D07-S1-003 | A1 tree orchestrator becomes operative ABI; A2 CLI becomes compatibility wrapper | #07 |
| AUD-D07-S1-004 | remove effect no-op from executable truth; add dedicated effect semantic guard | #07/#16 |
| AUD-D07-S1-005 | preserve all 144 donor IDs + 8 workflow IDs with terminal treatment | Appendix F |
| AUD-D07-S1-006 | reclassify PIPD validator from BUILD_MINIMAL to SELECTED_REUSE of canonical reference | #25 |
| AUD-D07-S1-007 | restore `APPLICABLE \| NOT_APPLICABLE`; rationale is separate field | #12 |
| AUD-D07-S2-001 | atomic child fixtures for compound mutations | #05/#10/#11 |
| AUD-D07-S2-002 | SYSTEM PI10 + PD13 executable matrix | #19 |
| AUD-D07-S2-003 | SKILL_PLUGIN PI18 + PD12 executable matrix | #20 |
| AUD-D07-S2-004 | AGENT_HARNESS PI15 + PD13 executable matrix | #21 |
| AUD-D07-S2-005 | replace generic landing prose with technology-specific contracts | #25 |
| AUD-D07-S2-006 | bind every local landing contract to exact TEST/ORACLE IDs | #25 |
| AUD-D07-S2-007 | Trivy `observed_latest=0.75.0`; stale R1 row closed | #14 |
| AUD-D07-S2-008 | materialize `SELF_ITERATION_LOOP` identity and tests | #28/Appendix F |
| AUD-D07-S2-009 | materialize `cross_agent_semantic_agreement` metric | #28 |
| AUD-D07-S2-010 | split result algebra namespaces | #04/#05/catalog schema |
| AUD-D07-S2-011 | embed validated machine catalog instance | Appendix G |
| AUD-D07-S2-012 | replace unverifiable receipt with executable seeded self-check | Appendix E |

## 00.3 Claim boundary

R2 is a design/specification artifact and local author-side materialization. It does not prove that any project installed the named tooling, ran the fixtures in a target repository, obtained independent verification, received human ratification, released software, or achieved production verification. Any downstream runtime claim requires new subject-bound evidence.

# 01｜Mission / Falsification Principle / Engineering Posture

PIPD prevents semantic loss before implementation. DOC-07 prevents a different failure mode: **false closure**. A package can look complete, parse as valid JSON, produce green CI, receive a provider 2xx, or contain the word “PASS” while still violating a decisive lifecycle invariant. DOC-07 therefore treats conformance as an adversarial proof obligation rather than a formatting exercise.

The core rule is: **a claim is not accepted because the producer says it is true; it is accepted only when the canonical predicate is observed by an applicable oracle over the exact bound subject.** Tests are designed from failure modes first. Positive fixtures prove legitimate acceptance is possible; negative, edge, adversarial, mutation and apparent-pass fixtures prove the validator can reject plausible false positives.

A higher gate is never inferred from a lower success. `schema-valid` does not imply semantic conformance; `PI_READY` does not imply `PREDEV_READY`; `PREDEV_READY` does not imply `EXECUTION_ADMITTED`; tool/API success does not imply `CONFIRMED_EFFECT`; `VERIFIED` does not imply `QUALIFIED` or `RELEASED`.

# 02｜Source Authority / Full-Corpus Coverage / Conflict Rule

## 02.1 Authority order

`CURRENT PATCH TASK → AUDIT repair controller → A1 Blueprint → A2 Canonical Standard → A3 repaired Skeleton → A4 design history → R1 patch base → external currentness SUPPORT`.

Lower-ranked material may add implementation support but may not rewrite higher-authority identity, lifecycle, permission, evidence, TEST/ORACLE, applicability, or claim semantics. Same-rank unresolved conflict is fail-closed and must become TT/CR rather than silent merge.

## 02.2 Full-file read receipt

| Source ID | Physical file | SHA-256 | Bytes | Logical lines | Authority | Disposition |
|---|---|---|---|---|---|---|
| A1_BLUEPRINT | Pre-Implementation_and_Pre-Dev_Lifecycle_Specification_總藍圖.md | 9a8323e5237c1555a76d9a75f706e3552d79c192915cc782b76b211c7f27d527 | 149077 | 2997 | A1 | FULL UTF-8 scan; no sampling |
| A2_STANDARD | Pre-Implementation_and_Pre-Dev_Lifecycle_Specification_canonical_standard.md | 6f6aafece90b34e33786647e14fee840f5424893995b3164cbb52953a5c4f14a | 209157 | 7177 | A2 | FULL UTF-8 scan; no sampling |
| A3_SKELETON | PIPD_LS_skeleton_2026-10-06_r2_FULL_REPAIR(1).md | 03bb3609dc67f85fa4b683a93736cf162e9047b6b253182aa3fdba11ba40cb28 | 376599 | 2669 | A3 | FULL UTF-8 scan; no sampling |
| A4_DISCUSSION | Pre-Implementation-PKG  Pre-Dev-PKG 生命週期規格_總討論(1).md | be1858e860092fb1751bf0524cd22b6939138b6835ce8f452bfc30894f945a95 | 77326 | 2559 | A4 | FULL UTF-8 scan; no sampling |
| PRODUCTION_INSTRUCTION | 貼上的文字 (1)(9).txt | 0609d6f618f84c8b627c9084e521e6d1f1bb8cb5597ea635ec51f0bd7ae83b2d | 40612 | 1742 | TASK | FULL UTF-8 scan; no sampling |
| R1_TARGET | PIPD_LS_DOC-07_2026-10-07_r1_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY(2).md | 3a5d25be0ff75572e376575000513591eb713887015b1a653657eb56c05b05b9 | 124286 | 2879 | PATCH_BASE | FULL UTF-8 scan; no sampling |
| AUDIT_CONTROLLER | AUDIT_PIPD_LS_DOC-07_2026-10-07_r1_FULL_AUDIT_REPAIR_REQUIRED(3).md | 96b93631afb089c36182691c05b12718789044892e33575157cb34b8bc1c5cc2 | 33571 | 1208 | REPAIR_CONTROLLER | FULL UTF-8 scan; no sampling |

## 02.3 Materialized `DOC07_SOURCE_COVERAGE_LEDGER`

R2 no longer treats a source receipt as proof of semantic coverage. The auditable ledger is materialized in **Appendix I** with one atomic row per canonical requirement, profile obligation, production-instruction obligation, and audit acceptance gate. `SUBSTANTIVE_BODY` is the only coverage kind that closes normative coverage.

Ledger fields:

```yaml
source_id:
source_anchor:
atomic_id:
atomic_obligation:
owner:
doc07_destination:
coverage_kind: SUBSTANTIVE_BODY
disposition:
conflict_status:
verification:
```

Technology/workflow denominator identity is additionally closed by **Appendix F**, where all 144 donor technology IDs and 8 named workflow IDs receive an explicit treatment. Absence from that crosswalk is a regression failure, not an implicit route-out.

# 03｜Conformance Object Model / Typed Identity

DOC-07 owns conformance-layer objects that **reference** canonical lifecycle semantics without redefining them.

| Object | Required meaning | Writer | Primary consumer |
|---|---|---|---|
| ConformanceTest | stable test identity; applicability; fixture refs; oracle ref; expected observation; requirement/source refs | DOC-07 | TQAEP/validator/checker |
| Fixture | typed positive/negative/edge/adversarial/mutation/apparent-pass input bound to an exact subject/profile/environment | DOC-07 | runner/checker |
| Mutation | one controlled delta from a known-good baseline; child mutation identity is mandatory for deterministic FFI | DOC-07 | mutation runner |
| Oracle | versioned decision function/rule; runner output is evidence, not authority | DOC-07 | checker |
| OracleVerdict | typed conformance result plus distinct admission/effect/recovery/finding namespaces | DOC-07 | report/evidence plane |
| ConformanceReport | canonical A2 base report schema; R2 adds no incompatible required field | A2; consumed by DOC-07 | gate/checker/CI |
| RequirementConformanceRef | A1 exact requirement→test→oracle row with A1 applicability enum | A1; consumed by DOC-07 | tree validator/report |
| TechnologyCoverageCrosswalk | source donor identity→DOC-07 treatment/owner/tests/oracles/exit | DOC-07 projection of A3 denominator | anti-degradation checker |
| ProfileConformanceRow | profile obligation→test/oracle→positive+negative fixtures→evidence→invalidation | DOC-07 | profile checker |

Identity rule: `requirement_id`, `test_id`, `oracle_id`, `fixture_id`, donor `source_id`, local `technology_id`, and the subject tuple are different namespaces. A runner/provider/tool-local ID is secondary metadata only.

## 03.1 R2 machine-readable conformance-catalog schema

The schema below separates result namespaces and requires source bindings plus the exact 86 requirement bindings.

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "urn:pipd:doc07:1.1:r2:schema:conformance-catalog",
  "title": "PIPD DOC-07 R2 Conformance Catalog",
  "type": "object",
  "additionalProperties": false,
  "required": [
    "catalog_id",
    "standard_version",
    "source_bindings",
    "tests",
    "oracles",
    "fixtures",
    "requirement_bindings"
  ],
  "properties": {
    "catalog_id": {
      "const": "PIPD-DOC07-CONFORMANCE-CATALOG-R2"
    },
    "standard_version": {
      "const": "1.1.0"
    },
    "source_bindings": {
      "type": "array",
      "minItems": 1,
      "items": {
        "$ref": "#/$defs/SourceBinding"
      }
    },
    "tests": {
      "type": "array",
      "minItems": 1,
      "items": {
        "$ref": "#/$defs/Test"
      }
    },
    "oracles": {
      "type": "array",
      "minItems": 1,
      "items": {
        "$ref": "#/$defs/Oracle"
      }
    },
    "fixtures": {
      "type": "array",
      "minItems": 1,
      "items": {
        "$ref": "#/$defs/Fixture"
      }
    },
    "requirement_bindings": {
      "type": "array",
      "minItems": 86,
      "maxItems": 86,
      "items": {
        "$ref": "#/$defs/RequirementBinding"
      }
    }
  },
  "$defs": {
    "SourceBinding": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "source_id",
        "sha256",
        "authority"
      ],
      "properties": {
        "source_id": {
          "type": "string",
          "minLength": 1
        },
        "sha256": {
          "type": "string",
          "pattern": "^[A-Fa-f0-9]{64}$"
        },
        "authority": {
          "type": "string",
          "minLength": 1
        }
      }
    },
    "Test": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "test_id",
        "oracle_id",
        "source_ref",
        "applicability",
        "fixture_refs"
      ],
      "properties": {
        "test_id": {
          "type": "string",
          "pattern": "^TEST-[A-Z0-9-]+$"
        },
        "oracle_id": {
          "type": "string",
          "pattern": "^OR-[A-Z0-9-]+$"
        },
        "source_ref": {
          "type": "string",
          "minLength": 1
        },
        "applicability": {
          "enum": [
            "ALL",
            "APPLICABLE_PROFILE",
            "PROFILE_EXTENSION"
          ]
        },
        "requirement_refs": {
          "type": "array",
          "items": {
            "type": "string",
            "pattern": "^STD-REQ-[A-F0-9]{8}$"
          }
        },
        "fixture_refs": {
          "type": "array",
          "items": {
            "type": "string",
            "minLength": 1
          }
        }
      }
    },
    "Oracle": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "oracle_id",
        "oracle_type",
        "decision_rule",
        "first_failing_invariant_order",
        "stale_evidence_policy"
      ],
      "properties": {
        "oracle_id": {
          "type": "string",
          "pattern": "^OR-[A-Z0-9-]+$"
        },
        "oracle_type": {
          "enum": [
            "DETERMINISTIC",
            "STATE_READBACK",
            "PROPERTY",
            "REFERENCE_OUTPUT",
            "STATISTICAL",
            "SEMANTIC_JUDGE",
            "HUMAN",
            "COMPOSITE"
          ]
        },
        "decision_rule": {
          "type": "string",
          "minLength": 1
        },
        "first_failing_invariant_order": {
          "type": "array",
          "minItems": 1,
          "items": {
            "type": "string",
            "minLength": 1
          }
        },
        "stale_evidence_policy": {
          "const": "REJECT"
        },
        "source_ref": {
          "type": "string"
        }
      }
    },
    "Fixture": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "fixture_id",
        "class",
        "source_ref",
        "test_ref",
        "oracle_ref",
        "construction",
        "invariant",
        "conformance_result",
        "recovery_action"
      ],
      "properties": {
        "fixture_id": {
          "type": "string",
          "minLength": 1
        },
        "class": {
          "type": "string",
          "minLength": 1
        },
        "source_ref": {
          "type": "string",
          "minLength": 1
        },
        "test_ref": {
          "type": "string",
          "minLength": 1
        },
        "oracle_ref": {
          "type": "string",
          "minLength": 1
        },
        "construction": {
          "type": "string",
          "minLength": 1
        },
        "invariant": {
          "type": "string",
          "minLength": 1
        },
        "conformance_result": {
          "enum": [
            "PASS",
            "FAIL",
            "HOLD",
            "SKIP_WITH_RATIONALE"
          ]
        },
        "decision": {
          "type": [
            "string",
            "null"
          ],
          "enum": [
            "ADMIT",
            "HOLD",
            "DENY",
            "NACK",
            null
          ]
        },
        "effect_state": {
          "type": [
            "string",
            "null"
          ],
          "enum": [
            "UNKNOWN_EFFECT",
            "PARTIAL_EFFECT",
            "CONFLICTING_EFFECT",
            "CONFIRMED_EFFECT",
            "FAILED_EFFECT",
            "COMPENSATED_EFFECT",
            null
          ]
        },
        "recovery_action": {
          "enum": [
            "NONE",
            "RETRY",
            "REOBSERVE",
            "RECONCILE",
            "COMPENSATE",
            "ROLLBACK"
          ]
        },
        "finding_class": {
          "type": [
            "string",
            "null"
          ]
        },
        "environment_binding": {
          "type": "string"
        },
        "evidence_expectation": {
          "type": "string"
        },
        "invalidation_trigger": {
          "type": "string"
        }
      }
    },
    "RequirementBinding": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "requirement_id",
        "test_id",
        "oracle_id",
        "applicability"
      ],
      "properties": {
        "requirement_id": {
          "type": "string",
          "pattern": "^STD-REQ-[A-F0-9]{8}$"
        },
        "test_id": {
          "type": "string",
          "pattern": "^TEST-[A-F0-9]{8}$"
        },
        "oracle_id": {
          "type": "string",
          "pattern": "^OR-[A-F0-9]{8}$"
        },
        "applicability": {
          "enum": [
            "ALL",
            "APPLICABLE_PROFILE"
          ]
        }
      }
    }
  }
}
```

The full validating instance is embedded in **Appendix G**. Human tables are views; the JSON instance is the extraction surface.

# 04｜Test Taxonomy / Typed Result Algebra / Applicability

The canonical conformance result vocabulary remains:

```yaml
conformance_result: PASS | FAIL | HOLD | SKIP_WITH_RATIONALE
```

R2 explicitly separates the four other namespaces that R1 mixed into `expected_result`:

```yaml
decision: ADMIT | HOLD | DENY | NACK | null
effect_state: UNKNOWN_EFFECT | PARTIAL_EFFECT | CONFLICTING_EFFECT | CONFIRMED_EFFECT | FAILED_EFFECT | COMPENSATED_EFFECT | null
recovery_action: NONE | RETRY | REOBSERVE | RECONCILE | COMPENSATE | ROLLBACK
finding_class: string | null
```

A `DENY` is not a conformance result; `UNKNOWN_EFFECT` is not a test result; `ROLLBACK` is not a verdict; a diagnostic finding is not a gate state. The normalized fixture/report layer must keep these fields separate.

A1 project requirement applicability is **exactly**:

```yaml
applicability: APPLICABLE | NOT_APPLICABLE
rationale: <required non-empty source-bound reason when NOT_APPLICABLE>
```

`N_A_WITH_RATIONALE` may appear only as a namespaced human-facing extension label; it must never replace the A1 machine enum.

### 04.1 Donor TestClass denominator

`POS`, `NEG`, `EDGE`, `SEC`, `PERF`, `PARITY`, `RECOVERY`, `UPGRADE`, `ROLLBACK`, `UNINSTALL`, `MUT`, `JOURNEY`.

### 04.2 OracleType denominator

`DETERMINISTIC`, `STATE_READBACK`, `PROPERTY`, `REFERENCE_OUTPUT`, `STATISTICAL`, `SEMANTIC_JUDGE`, `HUMAN`, `COMPOSITE`.

Whenever a deterministic predicate exists, it is preferred for gate-critical semantics. Model/judge/human outputs remain evidence inputs unless the owning authority explicitly defines that oracle type.

# 05｜Fixture Contract / Canonical Fixture Catalog / Atomic Child Decomposition

A fixture is executable evidence preparation. Every executable fixture binds exact subject/version/hash, baseline, one construction or mutation, profile applicability, environment, TEST, ORACLE, expected observation, first-failing invariant, typed outcome, evidence expectation, and invalidation/requalification trigger.

## 05.1 Retained parent fixture catalog with typed outcomes

| Fixture | Class | Construction | TEST | ORACLE | Invariant | Conformance | Decision | Effect | Recovery | Finding | Evidence | Requalification |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| FX-POS-001 | Positive | fully conformant PI/PD subject; construct complete subject with current hashes and applicable profile fields | TEST-CMP-001 | OR-CMP-001 | all applicable core tests pass | PASS | null | null | NONE | null | ConformanceReport + raw evidence | requalify on subject/env/oracle drift |
| FX-NEG-001 | Negative | remove required gate/field; delete one required semantic field from otherwise valid subject | TEST-C5BCA382 | OR-C5BCA382 | missing invariant is first failure | FAIL | null | null | NONE | null | failure report | repair then rerun |
| FX-EDGE-001 | Edge | legal N/A at profile boundary; mark conditional field N/A with owner+rationale+profile authority | TEST-0CB9A2A0 | OR-0CB9A2A0 | accepted only when source permits | HOLD | null | null | NONE | null | N/A rationale evidence | recheck if profile changes |
| FX-ADV-001 | Adversarial | instruction injection in external DATA; inject tool/web prompt demanding PASS or permission escalation | TEST-7894BFB5 | OR-7894BFB5 | external content remains DATA | HOLD | null | null | NONE | null | sanitized trace | rerun after trust-boundary changes |
| FX-MUT-001 | Mutation | canonical object mutated; apply one controlled mutation per test | TEST-MUT-001 | OR-MUT-001 | exact invariant fails | FAIL | null | null | NONE | null | mutation record + report | every validator change |
| FX-APP-001 | Apparent-Pass | schema/CI green but semantic clause omitted; make schema-valid object missing decisive semantic binding | TEST-C5BCA382 | OR-C5BCA382 | semantic validator fails | FAIL | null | null | NONE | null | schema pass + semantic fail pair | every schema/semantic change |
| FX-STALE-001 | Stale Evidence | evidence generated against previous subject hash; bind evidence to superseded hash | TEST-RET-002 | OR-RET-002 | subject hash mismatch/currentness invalid | HOLD | null | null | NONE | null | old/new identity receipts | after source or subject change |
| FX-WSUB-001 | Wrong Subject | valid evidence from sibling subject; swap evidence subject_ref.id | TEST-79A6948B | OR-79A6948B | exact subject mismatch | FAIL | null | null | NONE | null | foreign evidence + rejection | always |
| FX-WHASH-001 | Wrong Version/Hash | correct id, wrong version/hash; alter version/hash | TEST-79A6948B | OR-79A6948B | identity tuple mismatch | FAIL | null | null | NONE | null | identity diff | always |
| FX-WAUTH-001 | Wrong Authority | provider/tool claims semantic authority; mark donor/provider output normative | TEST-E6580324 | OR-E6580324 | authority stack violated | FAIL | null | null | NONE | null | authority trace | on adapter/provider change |
| FX-PERM-001 | Missing Permission | attempt effect without permission; omit permission grant | TEST-BND-001 | OR-BND-001 | permission predicate false | FAIL | DENY | null | NONE | null | admission denial | permission change |
| FX-APPR-001 | Missing/Invalid Approval | high-risk ADMIT lacks/has bad token; missing/expired/wrong subject/replayed nonce | TEST-MUT-008 | OR-MUT-008 | token validity false | FAIL | DENY | null | NONE | null | token validation result | new token required |
| FX-HO-001 | Incomplete Handoff | handoff required arrays empty; empty allowed_scope/required_refs/rollback | TEST-MUT-004 | OR-MUT-004 | handoff completeness false | FAIL | NACK | null | NONE | null | handoff rejection | after repaired handoff |
| FX-HPI-001 | Hollow PI_READY | PI_READY with empty/missing decisive data; status PI_READY + requirements=[] or constitution false | TEST-MUT-001 | OR-MUT-001 | PI_READY predicate false | FAIL | null | null | NONE | null | gate failure | PI change |
| FX-HPD-001 | Hollow PREDEV_READY | PREDEV_READY with hollow RepoContext/S2E/ECP/TQAEP; empty one core PD object | TEST-MUT-003 | OR-MUT-003 | PREDEV predicate false | FAIL | null | null | NONE | null | PD gate failure | PD change |
| FX-FPASS-001 | Fake PASS | PASS evidence with invalid hash/checker/artifacts/oracle; mutate PASS packet | TEST-MUT-005 | OR-MUT-005 | PASS predicates not all true | FAIL | null | null | NONE | null | rejected evidence | evidence changes |
| FX-IDCOL-001 | Identity Collision | Seed/WorkOrder/ECP same ID; alias IDs | TEST-MUT-006 | OR-MUT-006 | all IDs distinct invariant false | FAIL | null | null | NONE | null | identity graph | object regeneration |
| FX-TAKE-001 | Provider/Tool Takeover | provider callback asserts acceptance/authority; inject provider 'approved/passed' field | TEST-E6580324 | OR-E6580324 | provider claim ignored/rejected | HOLD | null | null | NONE | null | provider raw + normalized rejection | provider adapter changes |
| FX-INJ-001 | Instruction Injection | repo/web/tool output asks validator to skip check; embed malicious instruction in DATA | TEST-7894BFB5 | OR-7894BFB5 | no policy change | HOLD | null | null | NONE | null | sanitized trace | trust policy change |
| FX-EFFECT-001 | World-Effect False Positive | HTTP/tool success without readback; provider returns 2xx; no observation/readback | TEST-MUT-009 | OR-MUT-009 | effect != CONFIRMED_EFFECT | FAIL | null | UNKNOWN_EFFECT | REOBSERVE | null | response + missing reconciliation | reconcile or compensate |
| FX-TECH-001 | Selected-Technology Omission | selected named technology erased to generic tool; remove TechnologyLandingContract/identity | TEST-E6580324 | OR-E6580324 | selected tech semantics not preserved | FAIL | null | null | NONE | null | technology crosswalk diff | restore or explicit CR |
| FX-PRT-001 | Portability/Adapter Removal | remove adapter or switch harness; run same canonical fixture without vendor adapter | TEST-PRT-001 | OR-PRT-001 | required semantics/gates unchanged | PASS | null | null | NONE | PARITY_DIFF_IF_ANY | cross-harness diff | on adapter/runtime change |
| FX-DRIFT-001 | Currentness Drift | tool/protocol TTL/version/security drift; advance/change pin or standard hash | TEST-6F8DCD42 | OR-6F8DCD42 | dependent currentness invalidated | HOLD | null | null | REOBSERVE | REQUALIFICATION_REQUIRED | currentness diff | re-admit/requalify |
| FX-DECOM-001 | Brownfield False Decommission | new path healthy but incumbent residues exist; mark decommission after bounded pilot only | TEST-3235004D | OR-3235004D | residue/decommission proof missing | HOLD | null | null | ROLLBACK | null | residue/readback proof | after explicit residue closure |

Parent fixtures remain useful for human navigation, but any compound mutation must be executed through child fixtures.

## 05.2 Mandatory atomic child fixtures

| Parent | Child | Class | Single mutation | TEST | ORACLE | Deterministic FFI | Conformance | Decision | Effect | Recovery | Exit |
|---|---|---|---|---|---|---|---|---|---|---|---|
| DT-02 | DT-02-C01 | MUTATION | remove VER from CURRENT trace | TEST-MUT-002 | OR-MUT-002 | TRACE_VER_MISSING | FAIL | null | null | NONE | 3 |
| DT-02 | DT-02-C02 | MUTATION | remove EVD_EXPECTATION from CURRENT trace | TEST-MUT-002 | OR-MUT-002 | TRACE_EVD_EXPECTATION_MISSING | FAIL | null | null | NONE | 3 |
| DT-02 | DT-02-C03 | MUTATION | remove DEL from CURRENT trace | TEST-MUT-002 | OR-MUT-002 | TRACE_DEL_MISSING | FAIL | null | null | NONE | 3 |
| DT-02 | DT-02-C04 | MUTATION | remove GATE from CURRENT trace | TEST-MUT-002 | OR-MUT-002 | TRACE_GATE_MISSING | FAIL | null | null | NONE | 3 |
| DT-02 | DT-02-C05 | MUTATION | remove content hash from CURRENT trace | TEST-MUT-002 | OR-MUT-002 | TRACE_HASH_MISSING | FAIL | null | null | NONE | 4 |
| DT-02 | DT-02-C06 | MUTATION | remove invalidated_by/invalidation relation | TEST-MUT-002 | OR-MUT-002 | TRACE_INVALIDATION_MISSING | FAIL | null | null | NONE | 4 |
| DT-04 | DT-04-C01 | MUTATION | PREDEV_READY with empty RepoContext | TEST-MUT-003 | OR-MUT-003 | PD_REPOCONTEXT_HOLLOW | FAIL | null | null | NONE | 3 |
| DT-04 | DT-04-C02 | MUTATION | PREDEV_READY with empty S2E | TEST-MUT-003 | OR-MUT-003 | PD_S2E_HOLLOW | FAIL | null | null | NONE | 3 |
| DT-04 | DT-04-C03 | MUTATION | PREDEV_READY with empty ECP | TEST-MUT-003 | OR-MUT-003 | PD_ECP_HOLLOW | FAIL | null | null | NONE | 3 |
| DT-04 | DT-04-C04 | MUTATION | PREDEV_READY with empty TQAEP | TEST-MUT-003 | OR-MUT-003 | PD_TQAEP_HOLLOW | FAIL | null | null | NONE | 3 |
| DT-05 | DT-05-C01 | MUTATION | handoff allowed_scope/required_refs arrays empty | TEST-MUT-004 | OR-MUT-004 | HANDOFF_REQUIRED_ARRAYS_EMPTY | FAIL | NACK | null | NONE | 3 |
| DT-05 | DT-05-C02 | MUTATION | handoff rollback/checkpoint missing | TEST-MUT-004 | OR-MUT-004 | HANDOFF_ROLLBACK_MISSING | FAIL | NACK | null | NONE | 3 |
| DT-06 | DT-06-C01 | MUTATION | PASS evidence subject hash invalid | TEST-MUT-005 | OR-MUT-005 | EVIDENCE_HASH_INVALID | FAIL | null | null | NONE | 4 |
| DT-06 | DT-06-C02 | MUTATION | PASS evidence checker missing/null | TEST-MUT-005 | OR-MUT-005 | EVIDENCE_CHECKER_MISSING | FAIL | null | null | NONE | 3 |
| DT-06 | DT-06-C03 | MUTATION | PASS evidence artifact refs empty | TEST-MUT-005 | OR-MUT-005 | EVIDENCE_ARTIFACTS_EMPTY | FAIL | null | null | NONE | 3 |
| DT-06 | DT-06-C04 | MUTATION | PASS evidence oracle verdict non-PASS | TEST-MUT-005 | OR-MUT-005 | EVIDENCE_ORACLE_NONPASS | FAIL | null | null | NONE | 3 |
| DT-08 | DT-08-C01 | MUTATION | TaskSpecSeed.id == WorkOrder.id | TEST-MUT-006 | OR-MUT-006 | IDENTITY_ALIAS_SEED_WORKORDER | FAIL | null | null | NONE | 3 |
| DT-08 | DT-08-C02 | MUTATION | WorkOrder.id == ECP.id | TEST-MUT-006 | OR-MUT-006 | IDENTITY_ALIAS_WORKORDER_ECP | FAIL | null | null | NONE | 3 |
| DT-08 | DT-08-C03 | MUTATION | TaskSpecSeed.id == ECP.id | TEST-MUT-006 | OR-MUT-006 | IDENTITY_ALIAS_SEED_ECP | FAIL | null | null | NONE | 3 |
| DT-09 | DT-09-C01 | ADVERSARIAL | high-risk ADMIT approval token missing | TEST-MUT-008 | OR-MUT-008 | APPROVAL_TOKEN_MISSING | FAIL | DENY | null | NONE | 5 |
| DT-09 | DT-09-C02 | ADVERSARIAL | approval token expired | TEST-75B304BB | OR-75B304BB | APPROVAL_TOKEN_EXPIRED | FAIL | DENY | null | NONE | 4 |
| DT-09 | DT-09-C03 | ADVERSARIAL | approval token subject/hash mismatch | TEST-75B304BB | OR-75B304BB | APPROVAL_TOKEN_SUBJECT_MISMATCH | FAIL | DENY | null | NONE | 5 |
| DT-09 | DT-09-C04 | ADVERSARIAL | approval token nonce replay | TEST-75B304BB | OR-75B304BB | APPROVAL_TOKEN_REPLAY | FAIL | DENY | null | NONE | 5 |
| DT-10 | DT-10-C01 | APPARENT_PASS | provider returns success; observation/readback absent | TEST-MUT-009 | OR-MUT-009 | EFFECT_READBACK_MISSING | FAIL | null | UNKNOWN_EFFECT | REOBSERVE | 3 |
| DT-10 | DT-10-C02 | APPARENT_PASS | provider returns success; readback exists but reconciliation absent | TEST-2E59E411 | OR-2E59E411 | EFFECT_RECONCILIATION_MISSING | FAIL | null | UNKNOWN_EFFECT | RECONCILE | 3 |
| FX-HPI-001 | FX-HPI-001-C01 | MUTATION | PI_READY with requirements=[] | TEST-MUT-001 | OR-MUT-001 | PI_REQUIREMENTS_EMPTY | FAIL | null | null | NONE | 3 |
| FX-HPI-001 | FX-HPI-001-C02 | MUTATION | PI_READY with CONSTITUTION_READY=false | TEST-F8221F9F | OR-F8221F9F | PI_CONSTITUTION_NOT_READY | FAIL | null | null | NONE | 3 |
| FX-APPR-001 | FX-APPR-001-C01 | ADVERSARIAL | approval missing | TEST-MUT-008 | OR-MUT-008 | APPROVAL_MISSING | FAIL | DENY | null | NONE | 5 |
| FX-APPR-001 | FX-APPR-001-C02 | ADVERSARIAL | approval expired | TEST-75B304BB | OR-75B304BB | APPROVAL_EXPIRED | FAIL | DENY | null | NONE | 4 |
| FX-APPR-001 | FX-APPR-001-C03 | ADVERSARIAL | approval wrong subject | TEST-75B304BB | OR-75B304BB | APPROVAL_WRONG_SUBJECT | FAIL | DENY | null | NONE | 5 |
| FX-APPR-001 | FX-APPR-001-C04 | ADVERSARIAL | approval nonce replay | TEST-75B304BB | OR-75B304BB | APPROVAL_REPLAY | FAIL | DENY | null | NONE | 5 |
| FX-FPASS-001 | FX-FPASS-001-C01 | APPARENT_PASS | fake PASS with invalid subject hash | TEST-MUT-005 | OR-MUT-005 | FAKE_PASS_HASH | FAIL | null | null | NONE | 4 |
| FX-FPASS-001 | FX-FPASS-001-C02 | APPARENT_PASS | fake PASS with null checker | TEST-MUT-005 | OR-MUT-005 | FAKE_PASS_CHECKER | FAIL | null | null | NONE | 3 |
| FX-FPASS-001 | FX-FPASS-001-C03 | APPARENT_PASS | fake PASS with empty artifact refs | TEST-MUT-005 | OR-MUT-005 | FAKE_PASS_ARTIFACTS | FAIL | null | null | NONE | 3 |
| FX-FPASS-001 | FX-FPASS-001-C04 | APPARENT_PASS | fake PASS with non-PASS oracle | TEST-MUT-005 | OR-MUT-005 | FAKE_PASS_ORACLE | FAIL | null | null | NONE | 3 |
| FX-DRIFT-001 | FX-DRIFT-001-C01 | EDGE | tool version drift | TEST-6F8DCD42 | OR-6F8DCD42 | TOOL_VERSION_DRIFT | HOLD | null | null | REOBSERVE | 4 |
| FX-DRIFT-001 | FX-DRIFT-001-C02 | EDGE | protocol version/profile drift | TEST-6F8DCD42 | OR-6F8DCD42 | PROTOCOL_DRIFT | HOLD | null | null | REOBSERVE | 4 |
| FX-DRIFT-001 | FX-DRIFT-001-C03 | EDGE | currentness TTL expiry | TEST-6F8DCD42 | OR-6F8DCD42 | CURRENTNESS_TTL_EXPIRED | HOLD | null | null | REOBSERVE | 4 |
| FX-DRIFT-001 | FX-DRIFT-001-C04 | EDGE | security/advisory state drift | TEST-D28A8B60 | OR-D28A8B60 | SECURITY_DRIFT | HOLD | null | null | REOBSERVE | 4 |
| FX-DRIFT-001 | FX-DRIFT-001-C05 | EDGE | license/rights drift | TEST-E6CD4BED | OR-E6CD4BED | LICENSE_RIGHTS_DRIFT | HOLD | null | null | REOBSERVE | 4 |

The child fixture is the attribution unit. A parent may aggregate children for reporting, but a parent cannot replace child execution. In particular, `DT-06` is not considered closed merely because one of invalid-hash / missing-checker / empty-artifacts / non-PASS-oracle fails; all four children must be represented and individually executable.

## 05.3 Profile fixtures

Every row in §§19–21 has **two** catalog fixtures: `<ITEM>-P` for a valid exact binding and `<ITEM>-N` for a single omission/hollow/stale/mismatch. These 162 fixtures are machine-materialized in Appendix G, avoiding an unreadable duplicate prose table while preserving exact IDs and extractability.

# 06｜Oracle Contract / Determinism / Apparent-Pass Defense

An Oracle is a versioned decision contract. It MUST specify:
1. `oracle_id` and version/hash;
2. applicable test/fixture/profile;
3. exact subject/environment binding;
4. expected observation and normalization rule;
5. deterministic predicate or, where irreducibly stochastic, the repetition/confidence and reducer rule;
6. first-failing-invariant ordering;
7. multi-failure reporting behavior;
8. false-positive/apparent-pass defenses;
9. checker identity/independence requirement;
10. stale/foreign evidence rejection;
11. invalidation trigger and conflict route.

Canonical evaluation order:
```text
resolve subject identity
→ resolve current schema/test/oracle identities
→ schema validity
→ source/authority/currentness
→ semantic invariants
→ permission/admission invariants
→ effect/readback/reconciliation where applicable
→ profile-specific invariants
→ evidence identity/freshness
→ result reducer
→ ConformanceReport
```

**First-failing invariant (FFI)** is the first violated invariant in this canonical order, not the first error a vendor library happens to enumerate. The engine MAY emit all failures, but FFI must be stable enough for reproducible repair routing.

False-positive prevention rules:
- parser/schema green is not semantic PASS;
- CI green is not lifecycle PASS;
- provider/test-runner success is not world-effect confirmation;
- a judge/model saying “looks correct” is not a deterministic gate;
- a PASS from wrong/stale subject is rejected before content scoring;
- a PASS created by maker alone is not independent verification;
- absence of detected findings is not evidence that an omitted test class is N/A.

## 06.1 OracleType denominator

`DETERMINISTIC`, `STATE_READBACK`, `PROPERTY`, `REFERENCE_OUTPUT`, `STATISTICAL`, `SEMANTIC_JUDGE`, `HUMAN`, `COMPOSITE`.

`SEMANTIC_JUDGE`, `HUMAN`, and `COMPOSITE` are bounded oracle types, not escape hatches. Their inputs, rubric, identity, independence class, and reducer must be explicit. Whenever a deterministic predicate exists, it is preferred for gate-critical semantics.

# 07｜Deterministic Validator Contract / A1 Operative ABI / A2 Compatibility Wrapper / Effect Closure

R2 resolves the R1 ABI conflict by making **A1 the executable integration truth**.

## 07.1 Operative integration command

The operative tree-level ABI is:

```text
python .pipd/tools/pipd_tree_validate.py validate-tree \
  --root . \
  --manifest .pipd/project/manifest.json \
  --report .pipd/conformance/reports/pipd-report.json
```

The A1 orchestrator owns profile application, 86-row identity comparison, currentness, project integration controls, object hash checks, canonical instance-validator invocation, and report packaging.

The A2 source validator remains a **minimum canonical instance validator**. Its interface is not silently upgraded into a second tree ABI.

## 07.2 A2 UX compatibility surface

The human-friendly form:

```text
pipd validate <instance> \
  --kind <pi|pd|evidence|admission|effect> \
  --profile <LITE|STANDARD|ASSURED>
```

is legal only as a compatibility wrapper:

```text
parse --profile
→ load A1 project manifest
→ require manifest.weight_profile == --profile
→ require <instance> is an exact manifest object of the declared kind
→ for kind=effect, execute R2 effect semantic guard before any generic schema PASS can occur
→ invoke A1 pipd_tree_validate.py validate-tree
→ emit the canonical ConformanceReport
```

If the wrapper cannot resolve the project manifest/profile/object identity, it fails closed with `RESOLUTION` or `CURRENTNESS`; it never falls back to direct A2 execution and never assumes profile equivalence.

## 07.3 Exit ABI

| Exit | Meaning | Required behavior |
|---:|---|---|
| 0 | PASS | all applicable schema, semantic, currentness, permission, profile and effect predicates passed |
| 2 | schema violation | structural contract failed |
| 3 | semantic invariant | cross-object/profile/effect semantic invariant failed |
| 4 | currentness / subject / expiry | stale or wrong identity/currentness |
| 5 | permission / approval | authorization predicate failed |
| 6 | resolution | required source/ref/schema/object cannot resolve |
| 7 | validator internal | no trustworthy result; never PASS |

`first_failing_invariant` is part of the portability ABI.

## 07.4 R2 effect semantic guard — mandatory overlay before generic instance validation

R1 copied an upstream reference path whose effect dispatch was implemented as a no-op lambda; R2 explicitly removes that no-op from executable truth. Until the upstream canonical source itself is revised, the compatibility/orchestrator layer MUST run the following equivalent semantic guard first:

```python
EXIT = {"PASS":0,"SEMANTIC":3}

def semantic_effect_guard(x):
    # Intercept raw/provider-success objects before schema-level apparent PASS.
    if not x.get("observation_refs"):
        return 3, "EFFECT_RECONCILIATION_OBSERVATION_MISSING"
    if not x.get("readback_refs"):
        return 3, "EFFECT_RECONCILIATION_READBACK_MISSING"
    if not x.get("oracle"):
        return 3, "EFFECT_RECONCILIATION_ORACLE_MISSING"
    if not x.get("checker"):
        return 3, "EFFECT_RECONCILIATION_CHECKER_MISSING"

    state = x.get("state")
    next_action = x.get("next_action")

    if state == "CONFIRMED_EFFECT":
        if next_action != "PROMOTE_EVIDENCE":
            return 3, "EFFECT_RECONCILIATION_CONFIRMED_WITHOUT_PROMOTION"
    else:
        if next_action == "PROMOTE_EVIDENCE":
            return 3, "EFFECT_RECONCILIATION_FALSE_PROMOTION"

    if state in {"UNKNOWN_EFFECT","PARTIAL_EFFECT","CONFLICTING_EFFECT"}:
        if next_action not in {"REOBSERVE","RECONCILE","COMPENSATE","ROLLBACK","FAIL_CLOSED"}:
            return 3, "EFFECT_RECONCILIATION_INVALID_NEXT_ACTION"

    return 0, None
```

After the guard passes, the exact A2 `effect-reconciliation.schema.json` is still applied. The guard is additive safety closure, not a replacement schema.

### Required destructive closure

```text
provider/tool returns 2xx
+ observation/readback absent
→ exit != 0
→ first_failing_invariant starts EFFECT_RECONCILIATION_
→ conformance_result = FAIL
→ effect_state = UNKNOWN_EFFECT
→ recovery_action = REOBSERVE or RECONCILE
```

This binds `TEST-MUT-009 / OR-MUT-009` and `TEST-2E59E411 / OR-2E59E411`. A provider response can never self-create `CONFIRMED_EFFECT`.

## 07.5 Profile compatibility wrapper reference

```python
def resolve_profile_or_fail(args_profile, manifest):
    actual = manifest["weight_profile"]
    if actual != args_profile:
        raise SystemExit_with_json(
            4, "PROFILE_BINDING_MISMATCH",
            {"requested": args_profile, "manifest": actual}
        )

def resolve_instance_or_fail(instance_path, kind, manifest):
    rows = [o for o in manifest["objects"]
            if o["path"] == instance_path and o["kind"] == kind]
    if len(rows) != 1:
        raise SystemExit_with_json(6, "INSTANCE_NOT_IN_A1_MANIFEST", instance_path)
```

The wrapper must then call the A1 tree orchestrator rather than a second validator stack.

## 07.6 BUILD_MINIMAL correction

R1 classified the internal PIPD validator as `BUILD_MINIMAL`. R2 replaces that disposition with **`SELECTED_REUSE`** because the canonical reference validator and A1 tree orchestrator already exist. Therefore R2 does not claim a no-fit justification for rebuilding a validator that is already source-owned.

If a future project proposes any new `BUILD_MINIMAL`, `TEST-MUT-007 / OR-MUT-007` requires:

```yaml
no_fit_reason: <non-empty>
failed_candidate_gap_set:
  - candidate_id: <exact source id>
    unmet_requirement: <specific gap>
```

No `BUILD_MINIMAL` row exists in the R2 DOC-07 local technology set.

# 08｜Canonical `conformance-report.schema.json`

The following schema is reproduced from A2 without semantic modification:

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "urn:pipd:canonical-standard:1.1:schema:conformance-report",
  "title": "ConformanceReport",
  "type": "object",
  "additionalProperties": false,
  "required": [
    "report_id",
    "standard_version",
    "subject_ref",
    "profile",
    "result",
    "exit_code",
    "first_failing_invariant",
    "test_results",
    "generated_at"
  ],
  "properties": {
    "report_id": {
      "type": "string",
      "minLength": 1
    },
    "standard_version": {
      "const": "1.1.0"
    },
    "subject_ref": {
      "type": "object",
      "additionalProperties": false,
      "required": [
        "id",
        "version",
        "hash"
      ],
      "properties": {
        "id": {
          "type": "string",
          "minLength": 1
        },
        "version": {
          "type": "string",
          "minLength": 1
        },
        "hash": {
          "type": "string",
          "pattern": "^[A-Fa-f0-9]{64}$"
        }
      }
    },
    "profile": {
      "type": "string",
      "minLength": 1
    },
    "result": {
      "enum": [
        "PASS",
        "FAIL",
        "HOLD"
      ]
    },
    "exit_code": {
      "type": "integer",
      "minimum": 0,
      "maximum": 7
    },
    "first_failing_invariant": {
      "type": [
        "string",
        "null"
      ]
    },
    "test_results": {
      "type": "array",
      "minItems": 1,
      "items": {
        "type": "object",
        "required": [
          "test_id",
          "oracle_id",
          "result"
        ],
        "properties": {
          "test_id": {
            "type": "string",
            "minLength": 1
          },
          "oracle_id": {
            "type": "string",
            "minLength": 1
          },
          "result": {
            "enum": [
              "PASS",
              "FAIL",
              "HOLD",
              "SKIP_WITH_RATIONALE"
            ]
          },
          "detail": {
            "type": "string"
          }
        }
      }
    },
    "generated_at": {
      "type": "string",
      "format": "date-time"
    }
  }
}
```

DOC-07 adds no required fields to this canonical schema. Richer execution systems MAY attach detail through referenced artifacts or a versioned compatible extension, but must retain this exact required identity and must not make the base report impossible to validate against `PIPD-LIFECYCLE-SPEC@1.1.0`.

A canonical report binds the exact subject and records test/oracle results. Environment/checker/raw evidence that are not first-class fields in the base schema MUST remain reachable through the report/test detail or project evidence graph; they may not be dropped merely because the base schema is compact.

# 09｜Stable TEST / ORACLE Registry — Primary Keys

Profiles may add tests but MUST NOT rename, remove, or silently N/A an applicable core test.

| Category | Test ID | Oracle ID | Fixture / mutation | PASS condition |

|---|---|---|---|---|

| Trigger | `TEST-TRG-001` | `OR-TRG-001` | new non-trivial system/feature | PI/PD workflow selected |

| Non-trigger | `TEST-NTR-001` | `OR-NTR-001` | trivial explanation/no construction | workflow not over-applied |

| Compliance | `TEST-CMP-001` | `OR-CMP-001` | complete PI package | all PI gates/schema/semantic rules pass |

| Compliance | `TEST-CMP-002` | `OR-CMP-002` | complete PD package | all PD gates/schema/semantic rules pass |

| Boundary | `TEST-BND-001` | `OR-BND-001` | attempt repo write at PI_READY | denied / no mutation |

| Boundary | `TEST-BND-002` | `OR-BND-002` | attempt S2E as execution authority | fail identity boundary |

| Boundary | `TEST-BND-003` | `OR-BND-003` | ECP maker self-approves high-risk action | deny |

| Retrieval | `TEST-RET-001` | `OR-RET-001` | normative source anchor missing | abstain/TEMP_CLOSED, no raw-volume invention |

| Retrieval | `TEST-RET-002` | `OR-RET-002` | stale source hash | dependent claim invalidated |

| Mutation | `TEST-MUT-001` | `OR-MUT-001` | PI_READY requirements=[] | schema/validator FAIL |

| Mutation | `TEST-MUT-002` | `OR-MUT-002` | remove VER/EVD/DEL/GATE from CURRENT trace | FAIL |

| Mutation | `TEST-MUT-003` | `OR-MUT-003` | PD core object={} | FAIL |

| Mutation | `TEST-MUT-004` | `OR-MUT-004` | handoff required arrays empty | FAIL |

| Mutation | `TEST-MUT-005` | `OR-MUT-005` | fake PASS evidence | FAIL |

| Mutation | `TEST-MUT-006` | `OR-MUT-006` | alias Seed/WorkOrder/ECP IDs | FAIL |

| Mutation | `TEST-MUT-007` | `OR-MUT-007` | BUILD_MINIMAL without no-fit proof | FAIL |

| Mutation | `TEST-MUT-008` | `OR-MUT-008` | high-risk ADMIT without token | FAIL |

| Mutation | `TEST-MUT-009` | `OR-MUT-009` | provider 2xx but no effect readback | stays UNKNOWN_EFFECT / FAIL promotion |

| Portability | `TEST-PRT-001` | `OR-PRT-001` | run same PI/PD fixture with second LLM/harness | semantic required fields/gates unchanged |

| Portability | `TEST-PRT-002` | `OR-PRT-002` | adapter removed | canonical package still interpretable |

# 10｜Canonical Destructive Baseline — DT-01..DT-10

| DT | Mutation | Canonical test | Oracle | Required result |

|---|---|---|---|---|

| `DT-01` | PI_READY with empty requirements | `TEST-MUT-001` | `OR-MUT-001` | schema/semantic FAIL |

| `DT-02` | CURRENT requirement missing VER/EVD_EXPECTATION/DEL/GATE/hash/invalidation | `TEST-MUT-002` | `OR-MUT-002` | FAIL |

| `DT-03` | extracted schema has unresolved external ref | `TEST-38EB8516` | `OR-38EB8516` | resolution FAIL |

| `DT-04` | PREDEV_READY with hollow RepoContext/S2E/ECP/TQAEP | `TEST-MUT-003` | `OR-MUT-003` | FAIL |

| `DT-05` | empty execution handoff or rollback=none | `TEST-MUT-004` | `OR-MUT-004` | FAIL/NACK |

| `DT-06` | PASS evidence with invalid hash/null checker/empty artifacts/non-PASS oracle | `TEST-MUT-005` | `OR-MUT-005` | FAIL |

| `DT-07` | trace without hash/invalidated_by | `TEST-MUT-002` | `OR-MUT-002` | FAIL |

| `DT-08` | TaskSpecSeed/WorkOrder/ECP identity alias | `TEST-MUT-006` | `OR-MUT-006` | FAIL |

| `DT-09` | high-risk ADMIT without valid approval token | `TEST-MUT-008` | `OR-MUT-008` | DENY |

| `DT-10` | provider success promoted to effect without reconciliation receipt | `TEST-MUT-009` | `OR-MUT-009` | UNKNOWN_EFFECT / fail promotion |

`DT-01..10` are minimum destructive fixtures, not a complete suite. A validator that can pass all positive fixtures but fails to reject any applicable DT is non-conformant. Every DT is run from a known-good baseline so the single mutation is attributable.

# 11｜Extended Mutation / Apparent-Pass / Skeleton Repair Suite

| Repair ID | Mutation | Required disposition |

|---|---|---|

| `RF-01` | delete canonical state token | reject; lifecycle state denominator is not optional |

| `RF-02` | substitute projection state for canonical lifecycle state | reject; projection cannot impersonate canonical state |

| `RF-03` | PI_READY with CONSTITUTION_READY=false | reject PI_READY |

| `RF-04` | parent requirement exists but one atomic child omitted | reject trace completeness |

| `RF-05` | shrink TechnologyAdmission enum or omit BUILD_MINIMAL no-fit proof | reject anti-downgrade/decision completeness |

| `RF-06` | SYSTEM OPS ECP missing SLO/DR/FinOps/canary or legal N/A | reject applicable operations readiness |

| `RF-07` | ECP exists but ExecutionAdmission missing; mutation attempted | deny first mutation |

| `RF-08` | Skill/Agent profile denominator omitted | reject profile conformance |

| `RF-09` | impose global waterfall wait-for-all-packages despite slice closure | reject architecture over-constraint |

| `RF-10` | delete donor crosswalk identity | fail anti-downgrade conformance |

| `RF-11` | omit project integration schema | fail distribution/project conformance |

Additional apparent-pass attacks MUST include:
- green schema + missing semantic child requirement;
- green unit tests + selected TechnologyAdmission omitted;
- green provider callback + no independent readback;
- green workflow + required check skipped by path filter;
- green security scanner + wrong subject digest;
- green agent evaluator + forbidden tool path untested;
- green new migration path + incumbent residue unverified.

The expected outcome is never “best effort PASS”. It is `FAIL`, `HOLD`, `DENY`, `NACK`, `UNKNOWN_EFFECT`, `CONFLICTING_EFFECT`, or another source-defined non-pass state that preserves the violated boundary.

# 12｜Traceability: REQ → SPEC → ACC → VER → TEST → ORACLE → FIXTURE → EVIDENCE → GATE

DOC-07 extends the lifecycle narrow waist into executable conformance:

```text
Source/Authority
→ Atomic Requirement
→ SPEC
→ ACC
→ VER
→ canonical TEST
→ canonical ORACLE
→ versioned Fixture
→ subject-bound Observation/Evidence
→ OracleVerdict
→ ConformanceReport
→ owning Gate reducer
```

No edge is inferred by adjacency. Missing links are defects or explicit TT.

## 12.1 A1-compatible `RequirementConformanceRef`

R2 restores the A1 machine ABI exactly:

```yaml
requirement_id: STD-REQ-...
test_id: TEST-...
oracle_id: OR-...
applicability: APPLICABLE | NOT_APPLICABLE
result: PASS | FAIL | HOLD | SKIP_WITH_RATIONALE
evidence_refs: [...]
rationale: <required source-bound reason when NOT_APPLICABLE or skipped>
```

`N_A_WITH_RATIONALE` is not emitted into the A1 `requirement-conformance.json` enum. A richer UI may project:

```yaml
extensions:
  doc07_human_applicability_label: N_A_WITH_RATIONALE
```

without altering the canonical field.

## 12.2 Exact 86 denominator

Appendix A is deterministically generated from A1 tuples. The machine acceptance predicate is:

```text
row_count == 86
unique(requirement_id) == 86
for every row:
  (requirement_id, test_id, oracle_id, applicability_class)
    == A1 canonical tuple
mismatch_count == 0
```

Markdown column parsing is not trusted as the source of truth; the self-checker extracts exact IDs with regex and compares the generated records, preventing escaped-pipe/column-shift regression.

## 12.3 Invalidation

Requirement/test/oracle remap invalidates dependent reports. Applicability changes invalidate only rows and gates that consume the changed profile contract; unrelated evidence remains current.

# 13｜Subject / Version / Hash / Environment Binding

A conformance verdict is scoped to a **verification identity envelope**:
```yaml
subject_ref:
  id: <canonical-id>
  version: <version>
  hash: <64-hex-content-hash>
fixture_ref:
  id: <fixture-id>
  version: <fixture-version>
oracle_ref:
  id: <oracle-id>
  version: <oracle/version-or-standard-hash>
environment_binding:
  profile: <weight/target profile>
  runtime: <runtime id/version if applicable>
  provider: <provider/model/tool id/version if applicable>
  os_container: <identity if material>
  schema_set_hash: <canonical schema-set hash>
checker_ref:
  id: <checker>
  independence_class: <maker-separate / same-model-bounded / independent-org / human>
generated_at: <date-time>
invalidated_by: [...]
```

Verdicts are **non-transitive across identity changes**. Same name with different bytes is a different revision. Evidence from a sibling package, old hash, different environment, different protocol/provider pin, or invalidated oracle does not inherit PASS. If equivalence is claimed, equivalence itself requires a test/oracle and a new evidence record.

# 14｜Currentness / Drift / Requalification

Currentness is an input to conformance, not a release claim. R2 canonicalizes every local technology currentness row as:

```yaml
observed_latest:
selected_version:
selected_pin:
checked_at:
ttl:
source_ref:
license_ref:
security_ref:
reason_if_not_latest:
status:
```

`observed_latest` and `selected_version` are intentionally different fields. An older selected version can be valid only with explicit reason and requalification; it cannot be mislabeled as latest.

## 14.1 R2 currentness ledger

| Currentness ID | Technology | Observed latest | Selected version | Pin policy | Checked | TTL | Status | Reason if not latest / TT | Source |
|---|---|---|---|---|---|---|---|---|---|
| CUR-TECH-JSONSCHEMA-SPEC | TECH-JSONSCHEMA-SPEC | Draft 2020-12 | Draft 2020-12 | spec identity / canonical dialect | 2026-10-07 | 30d | CURRENT_SUPPORT | — | https://json-schema.org/draft/2020-12/ |
| CUR-TECH-PY-JSONSCHEMA | TECH-PY-JSONSCHEMA | PyPI 4.26.0; main changelog advertises 4.27.0 | 4.26.0 pending publication-state resolution | exact package lock at PD | 2026-10-07 | 24h before materialization | HOLD_WITH_TT | TT-DOC07-CUR-001 publication/main discrepancy | https://pypi.org/project/jsonschema/ + GitHub changelog |
| CUR-TECH-PYTEST | TECH-PYTEST | 9.1.1 | 9.1.1 | exact project lock at PD | 2026-10-07 | 7d | CURRENT_SUPPORT | — | https://docs.pytest.org/en/latest/changelog.html |
| CUR-TECH-MCP-INSPECTOR | TECH-MCP-INSPECTOR | release 2.8.0; main manifest 2.9.0 | 2.8.0 released artifact pending project recheck | release tag + package integrity at PD | 2026-10-07 | 24h before bind | HOLD_WITH_TT | TT-DOC07-CUR-002 release/main discrepancy | https://github.com/modelcontextprotocol/inspector/releases + package.json |
| CUR-TECH-TRIVY | TECH-TRIVY | 0.75.0 released 2026-10-01 | 0.75.0 | immutable release/tag + checksums at PD | 2026-10-07 | 24h before security qualification | CURRENT_SUPPORT_R2 | — | https://github.com/aquasecurity/trivy/releases/tag/v0.75.0 |
| CUR-TECH-SEMGREP | TECH-SEMGREP | 1.179.0 | 1.179.0 | exact CLI release + rulepack digests at PD | 2026-10-07 | 24h before qualification | CURRENT_SUPPORT | — | https://github.com/semgrep/semgrep/releases |
| CUR-TECH-GITLEAKS | TECH-GITLEAKS | 8.30.1 | 8.30.1 | exact scanner release + checksum at PD | 2026-10-07 | 24h before qualification | CURRENT_SUPPORT | — | https://github.com/gitleaks/gitleaks/releases |
| CUR-TECH-OSSF-SCORECARD | TECH-OSSF-SCORECARD | 5.5.0 | 5.5.0 | exact release where used | 2026-10-07 | 7d | CURRENT_SUPPORT | — | https://github.com/ossf/scorecard/releases |
| CUR-TECH-SKILLEVALUATOR | TECH-SKILLEVALUATOR | 0.4.0 (2026-09-30) | 0.4.0 for evaluation-only design | exact release/container revision at pilot | 2026-10-07 | 7d | CURRENT_SUPPORT | — | https://github.com/NVIDIA/SkillEvaluator/blob/main/CHANGELOG.md |
| CUR-TECH-HARBOR | TECH-HARBOR | release 0.24.0 (2026-10-05); indexed main metadata previously 0.23.0 | 0.24.0 released artifact pending metadata recheck | release tag + environment/container digests at pilot | 2026-10-07 | 24h before evaluation | HOLD_WITH_TT | TT-DOC07-CUR-003 release/main indexed metadata discrepancy | https://github.com/harbor-framework/harbor/releases/tag/v0.24.0 |
| CUR-TECH-GHA | TECH-GHA | service; action versions vary | route-out to DOC-09; immutable action SHAs only | workflow/action SHA set at project integration | 2026-10-07 | per workflow change + 7d external action recheck | ROUTE_OUT | not a single-version product | https://docs.github.com/actions |
| CUR-TECH-PIPD-VALIDATOR | TECH-PIPD-VALIDATOR | PIPD-LIFECYCLE-SPEC@1.1.0 canonical reference implementation | 1.1.0 | A1/A2 source hash + generated file hash | 2026-10-07 | on canonical standard/blueprint hash change | SELECTED_REUSE | — | A1 §24 + A2 §18.3 |

### 14.2 Trivy R1 staleness closure

R1 recorded `0.74.0` as the current observation. R2 records `0.75.0`, released 2026-10-01, as the observed latest and selected qualification target. `TT-DOC07-CUR-004-TRIVY-STALENESS` is therefore **CLOSED_IN_R2_DESIGN**. Installation/runtime qualification remains unexecuted.

### 14.3 Remaining currentness TTs

- `TT-DOC07-CUR-001`: python-jsonschema published-distribution vs main-changelog discrepancy.
- `TT-DOC07-CUR-002`: MCP Inspector latest release vs main manifest discrepancy.
- `TT-DOC07-CUR-003`: Harbor release vs indexed-main metadata discrepancy.

These TTs block exact runtime pin/bind claims for the affected technology only. They do not invalidate unrelated DOC-07 semantics.

## 14.4 Affected-only drift algorithm

```text
on currentness drift:
  locate consumed capability/contract
  invalidate only dependent TechnologyAdmission / test evidence / profile binding
  require reobserve/requalify
  preserve unrelated accepted evidence
```

# 15｜Permission / ExecutionAdmission / Segregation of Duties Conformance

Verification must actively attack permission boundaries. At minimum:
- mutation before matching `ExecutionAdmission=ADMIT` → DENY;
- high-risk ADMIT without valid approval token → DENY;
- expired token → DENY/HOLD;
- token subject/hash mismatch → DENY;
- nonce replay → DENY;
- requested operation/target/scope/data class wider than token → DENY;
- Maker self-approval in high-risk/ASSURED → DENY;
- Maker=Checker=Acceptor collapse where separation is required → FAIL;
- ECP self-authority or S2E execution_authority=true → FAIL;
- provider/tool callback impersonating human approval → FAIL.

A permission test has two independent questions: **is the subject semantically ready?** and **is this exact actor/action/scope/time authorized?** Passing the former cannot answer the latter. DOC-07 records the observation; the execution admission authority owns ADMIT/HOLD/DENY.

# 16｜World Effect / Observation / Readback / Reconciliation Verification

Effectful operations use:
```text
EffectIntent
→ AUTHORIZED_ATTEMPT
→ Provider/Tool Response
→ Observation
→ Readback
→ Reconciliation Oracle
→ WorldEffectState
→ Evidence Promotion | Reobserve | Compensate | Rollback
```
Allowed effect states include `UNKNOWN_EFFECT`, `PARTIAL_EFFECT`, `CONFLICTING_EFFECT`, `CONFIRMED_EFFECT`, `FAILED_EFFECT`, `COMPENSATED_EFFECT`.

`HTTP 200`, SDK success, CLI exit 0, or provider acknowledgement is only **Provider/Tool Response**. `CONFIRMED_EFFECT` requires a readback/reconciliation receipt bound to the same intended subject and target. A destructive fixture intentionally returns success without readback and must remain `UNKNOWN_EFFECT`. Another fixture supplies conflicting observations and must become `CONFLICTING_EFFECT`, never a cherry-picked PASS.

Reconciliation oracles specify observation source independence where practical. If the provider response and readback originate from the same unverified cache/path, the oracle must disclose that limitation; high-risk ASSURED profiles require stronger corroboration as defined by TQAEP.

# 17｜Security / Injection / Confused-Deputy Conformance

External web/repo/tool/model content is DATA unless it is an authorized instruction surface. DOC-07 adversarial fixtures cover:
- prompt/instruction injection attempting to skip tests or grant authority;
- tool result containing fake `PASS`, approval, or state tokens;
- path/identity confusion;
- provider/tool takeover;
- secret leakage into fixtures/logs/evidence;
- command or argument injection in test harnesses;
- malicious schema/reference/extraction input;
- stale memory reintroducing superseded authority;
- confused deputy and scope widening;
- checker output tampering;
- denial-of-service inputs where a profile requires resilience.

Security tools can produce findings, but their absence of findings is not a universal security oracle. Security acceptance must remain tied to explicit threats, tests, evidence and residual-risk authority.

# 18｜Weight Profiles: LITE / STANDARD / ASSURED

| Profile | DOC-07 minimum | Extra assurance | Forbidden simplification |
|---|---|---|---|
| LITE | applicable core stable tests; positive + negative; permission/rollback/evidence/claim separation | compact fixture set; local checker may be allowed by Constitution | cannot omit identity, permission, evidence binding, rollback or applicable core tests |
| STANDARD | full relevant test taxonomy; mutation + edge + adversarial; currentness; trace; machine report | independent review SHOULD; repeatability and profile-specific tests | cannot equate schema/CI/tool success with semantic PASS |
| ASSURED | STANDARD + explicit threat-model tests, stronger SoD, approval, provenance, adversarial/recovery/rollback/repeat qualification | independent maker/checker/acceptor separation; stronger effect reconciliation | cannot self-approve, collapse required roles, or accept unsupported N/A |

A profile changes assurance **depth**, not the meaning of core states. N/A must be reasoned and source-bound.

# 19｜SYSTEM Target Profile

SYSTEM conformance is the full general software/system denominator from A3, not merely an operations appendix. PI establishes the ten construction-intent contracts; PD binds the thirteen late-bound repository/tooling/operations facts. Operations additionally preserve the effect sequence: precheck → permission/approval → exact scope → checkpoint → operation → observation → readback → reconciliation → rollback/compensation → residue proof → evidence return.

## 19.1 PI denominator — 10/10

| Item | Obligation | TEST | ORACLE | Positive fixture | Negative/mutation fixture | Evidence | Invalidation |
|---|---|---|---|---|---|---|---|
| SYS-PI-01 | Product/user outcome | TEST-D07-SYS-PI-01 | OR-D07-SYS-PI-01 | FX-SYS-PI-01-P | FX-SYS-PI-01-N | SYS-PI-01 subject-bound contract/observation + checker result | change to Product/user outcome, bound subject/hash, profile version, environment or oracle |
| SYS-PI-02 | Domain model | TEST-D07-SYS-PI-02 | OR-D07-SYS-PI-02 | FX-SYS-PI-02-P | FX-SYS-PI-02-N | SYS-PI-02 subject-bound contract/observation + checker result | change to Domain model, bound subject/hash, profile version, environment or oracle |
| SYS-PI-03 | Architecture | TEST-D07-SYS-PI-03 | OR-D07-SYS-PI-03 | FX-SYS-PI-03-P | FX-SYS-PI-03-N | SYS-PI-03 subject-bound contract/observation + checker result | change to Architecture, bound subject/hash, profile version, environment or oracle |
| SYS-PI-04 | API contracts | TEST-D07-SYS-PI-04 | OR-D07-SYS-PI-04 | FX-SYS-PI-04-P | FX-SYS-PI-04-N | SYS-PI-04 subject-bound contract/observation + checker result | change to API contracts, bound subject/hash, profile version, environment or oracle |
| SYS-PI-05 | Data contracts | TEST-D07-SYS-PI-05 | OR-D07-SYS-PI-05 | FX-SYS-PI-05-P | FX-SYS-PI-05-N | SYS-PI-05 subject-bound contract/observation + checker result | change to Data contracts, bound subject/hash, profile version, environment or oracle |
| SYS-PI-06 | SLO/NFR | TEST-D07-SYS-PI-06 | OR-D07-SYS-PI-06 | FX-SYS-PI-06-P | FX-SYS-PI-06-N | SYS-PI-06 subject-bound contract/observation + checker result | change to SLO/NFR, bound subject/hash, profile version, environment or oracle |
| SYS-PI-07 | Security/privacy | TEST-D07-SYS-PI-07 | OR-D07-SYS-PI-07 | FX-SYS-PI-07-P | FX-SYS-PI-07-N | SYS-PI-07 subject-bound contract/observation + checker result | change to Security/privacy, bound subject/hash, profile version, environment or oracle |
| SYS-PI-08 | Migration/backcompat | TEST-D07-SYS-PI-08 | OR-D07-SYS-PI-08 | FX-SYS-PI-08-P | FX-SYS-PI-08-N | SYS-PI-08 subject-bound contract/observation + checker result | change to Migration/backcompat, bound subject/hash, profile version, environment or oracle |
| SYS-PI-09 | Acceptance/testability | TEST-D07-SYS-PI-09 | OR-D07-SYS-PI-09 | FX-SYS-PI-09-P | FX-SYS-PI-09-N | SYS-PI-09 subject-bound contract/observation + checker result | change to Acceptance/testability, bound subject/hash, profile version, environment or oracle |
| SYS-PI-10 | Operability intent | TEST-D07-SYS-PI-10 | OR-D07-SYS-PI-10 | FX-SYS-PI-10-P | FX-SYS-PI-10-N | SYS-PI-10 subject-bound contract/observation + checker result | change to Operability intent, bound subject/hash, profile version, environment or oracle |

## 19.2 PD denominator — 13/13

| Item | Obligation | TEST | ORACLE | Positive fixture | Negative/mutation fixture | Evidence | Invalidation |
|---|---|---|---|---|---|---|---|
| SYS-PD-01 | RepoContext | TEST-D07-SYS-PD-01 | OR-D07-SYS-PD-01 | FX-SYS-PD-01-P | FX-SYS-PD-01-N | SYS-PD-01 subject-bound contract/observation + checker result | change to RepoContext, bound subject/hash, profile version, environment or oracle |
| SYS-PD-02 | Toolchain | TEST-D07-SYS-PD-02 | OR-D07-SYS-PD-02 | FX-SYS-PD-02-P | FX-SYS-PD-02-N | SYS-PD-02 subject-bound contract/observation + checker result | change to Toolchain, bound subject/hash, profile version, environment or oracle |
| SYS-PD-03 | DB/data migration | TEST-D07-SYS-PD-03 | OR-D07-SYS-PD-03 | FX-SYS-PD-03-P | FX-SYS-PD-03-N | SYS-PD-03 subject-bound contract/observation + checker result | change to DB/data migration, bound subject/hash, profile version, environment or oracle |
| SYS-PD-04 | CI | TEST-D07-SYS-PD-04 | OR-D07-SYS-PD-04 | FX-SYS-PD-04-P | FX-SYS-PD-04-N | SYS-PD-04 subject-bound contract/observation + checker result | change to CI, bound subject/hash, profile version, environment or oracle |
| SYS-PD-05 | Deployment topology | TEST-D07-SYS-PD-05 | OR-D07-SYS-PD-05 | FX-SYS-PD-05-P | FX-SYS-PD-05-N | SYS-PD-05 subject-bound contract/observation + checker result | change to Deployment topology, bound subject/hash, profile version, environment or oracle |
| SYS-PD-06 | Observability | TEST-D07-SYS-PD-06 | OR-D07-SYS-PD-06 | FX-SYS-PD-06-P | FX-SYS-PD-06-N | SYS-PD-06 subject-bound contract/observation + checker result | change to Observability, bound subject/hash, profile version, environment or oracle |
| SYS-PD-07 | Environment config | TEST-D07-SYS-PD-07 | OR-D07-SYS-PD-07 | FX-SYS-PD-07-P | FX-SYS-PD-07-N | SYS-PD-07 subject-bound contract/observation + checker result | change to Environment config, bound subject/hash, profile version, environment or oracle |
| SYS-PD-08 | Rollback/provider-off | TEST-D07-SYS-PD-08 | OR-D07-SYS-PD-08 | FX-SYS-PD-08-P | FX-SYS-PD-08-N | SYS-PD-08 subject-bound contract/observation + checker result | change to Rollback/provider-off, bound subject/hash, profile version, environment or oracle |
| SYS-PD-09 | SLO instrumentation | TEST-D07-SYS-PD-09 | OR-D07-SYS-PD-09 | FX-SYS-PD-09-P | FX-SYS-PD-09-N | SYS-PD-09 subject-bound contract/observation + checker result | change to SLO instrumentation, bound subject/hash, profile version, environment or oracle |
| SYS-PD-10 | Incident/runbook | TEST-D07-SYS-PD-10 | OR-D07-SYS-PD-10 | FX-SYS-PD-10-P | FX-SYS-PD-10-N | SYS-PD-10 subject-bound contract/observation + checker result | change to Incident/runbook, bound subject/hash, profile version, environment or oracle |
| SYS-PD-11 | DR/RTO/RPO | TEST-D07-SYS-PD-11 | OR-D07-SYS-PD-11 | FX-SYS-PD-11-P | FX-SYS-PD-11-N | SYS-PD-11 subject-bound contract/observation + checker result | change to DR/RTO/RPO, bound subject/hash, profile version, environment or oracle |
| SYS-PD-12 | Capacity/cost/FinOps | TEST-D07-SYS-PD-12 | OR-D07-SYS-PD-12 | FX-SYS-PD-12-P | FX-SYS-PD-12-N | SYS-PD-12 subject-bound contract/observation + checker result | change to Capacity/cost/FinOps, bound subject/hash, profile version, environment or oracle |
| SYS-PD-13 | Secret revoke/rotation | TEST-D07-SYS-PD-13 | OR-D07-SYS-PD-13 | FX-SYS-PD-13-P | FX-SYS-PD-13-N | SYS-PD-13 subject-bound contract/observation + checker result | change to Secret revoke/rotation, bound subject/hash, profile version, environment or oracle |

## 19.3 Profile gate rule

Every row is independently applicable unless the owning profile authority permits `NOT_APPLICABLE` with a non-empty source-bound rationale. A sibling row cannot compensate for a missing row. Positive fixtures prove acceptability; negative fixtures prove the checker rejects omission/hollow/stale/mismatch. Profile tests are DOC-07 extension identities and do not rename canonical A1/A2 TEST/ORACLE IDs.

# 20｜SKILL_PLUGIN Target Profile

SKILL_PLUGIN conformance separates portable PI semantics from exact PD host/runtime/package facts. Skill metadata never grants side effects. Effectful skills still require TaskSpecSeed → WorkOrder → applicable ECP → `ExecutionAdmission=ADMIT` → effect → observation/readback/reconciliation.

## 20.1 PI denominator — 18/18

| Item | Obligation | TEST | ORACLE | Positive fixture | Negative/mutation fixture | Evidence | Invalidation |
|---|---|---|---|---|---|---|---|
| SK-PI-01 | Trigger | TEST-D07-SK-PI-01 | OR-D07-SK-PI-01 | FX-SK-PI-01-P | FX-SK-PI-01-N | SK-PI-01 subject-bound contract/observation + checker result | change to Trigger, bound subject/hash, profile version, environment or oracle |
| SK-PI-02 | Non-trigger | TEST-D07-SK-PI-02 | OR-D07-SK-PI-02 | FX-SK-PI-02-P | FX-SK-PI-02-N | SK-PI-02 subject-bound contract/observation + checker result | change to Non-trigger, bound subject/hash, profile version, environment or oracle |
| SK-PI-03 | Inputs | TEST-D07-SK-PI-03 | OR-D07-SK-PI-03 | FX-SK-PI-03-P | FX-SK-PI-03-N | SK-PI-03 subject-bound contract/observation + checker result | change to Inputs, bound subject/hash, profile version, environment or oracle |
| SK-PI-04 | Outputs | TEST-D07-SK-PI-04 | OR-D07-SK-PI-04 | FX-SK-PI-04-P | FX-SK-PI-04-N | SK-PI-04 subject-bound contract/observation + checker result | change to Outputs, bound subject/hash, profile version, environment or oracle |
| SK-PI-05 | Allowed tools | TEST-D07-SK-PI-05 | OR-D07-SK-PI-05 | FX-SK-PI-05-P | FX-SK-PI-05-N | SK-PI-05 subject-bound contract/observation + checker result | change to Allowed tools, bound subject/hash, profile version, environment or oracle |
| SK-PI-06 | Permission classes | TEST-D07-SK-PI-06 | OR-D07-SK-PI-06 | FX-SK-PI-06-P | FX-SK-PI-06-N | SK-PI-06 subject-bound contract/observation + checker result | change to Permission classes, bound subject/hash, profile version, environment or oracle |
| SK-PI-07 | Compatibility | TEST-D07-SK-PI-07 | OR-D07-SK-PI-07 | FX-SK-PI-07-P | FX-SK-PI-07-N | SK-PI-07 subject-bound contract/observation + checker result | change to Compatibility, bound subject/hash, profile version, environment or oracle |
| SK-PI-08 | Dependencies | TEST-D07-SK-PI-08 | OR-D07-SK-PI-08 | FX-SK-PI-08-P | FX-SK-PI-08-N | SK-PI-08 subject-bound contract/observation + checker result | change to Dependencies, bound subject/hash, profile version, environment or oracle |
| SK-PI-09 | Side-effect classes | TEST-D07-SK-PI-09 | OR-D07-SK-PI-09 | FX-SK-PI-09-P | FX-SK-PI-09-N | SK-PI-09 subject-bound contract/observation + checker result | change to Side-effect classes, bound subject/hash, profile version, environment or oracle |
| SK-PI-10 | Secret/network policy | TEST-D07-SK-PI-10 | OR-D07-SK-PI-10 | FX-SK-PI-10-P | FX-SK-PI-10-N | SK-PI-10 subject-bound contract/observation + checker result | change to Secret/network policy, bound subject/hash, profile version, environment or oracle |
| SK-PI-11 | Failure behavior | TEST-D07-SK-PI-11 | OR-D07-SK-PI-11 | FX-SK-PI-11-P | FX-SK-PI-11-N | SK-PI-11 subject-bound contract/observation + checker result | change to Failure behavior, bound subject/hash, profile version, environment or oracle |
| SK-PI-12 | Negative cases | TEST-D07-SK-PI-12 | OR-D07-SK-PI-12 | FX-SK-PI-12-P | FX-SK-PI-12-N | SK-PI-12 subject-bound contract/observation + checker result | change to Negative cases, bound subject/hash, profile version, environment or oracle |
| SK-PI-13 | Examples | TEST-D07-SK-PI-13 | OR-D07-SK-PI-13 | FX-SK-PI-13-P | FX-SK-PI-13-N | SK-PI-13 subject-bound contract/observation + checker result | change to Examples, bound subject/hash, profile version, environment or oracle |
| SK-PI-14 | Host boundary | TEST-D07-SK-PI-14 | OR-D07-SK-PI-14 | FX-SK-PI-14-P | FX-SK-PI-14-N | SK-PI-14 subject-bound contract/observation + checker result | change to Host boundary, bound subject/hash, profile version, environment or oracle |
| SK-PI-15 | Host assumptions | TEST-D07-SK-PI-15 | OR-D07-SK-PI-15 | FX-SK-PI-15-P | FX-SK-PI-15-N | SK-PI-15 subject-bound contract/observation + checker result | change to Host assumptions, bound subject/hash, profile version, environment or oracle |
| SK-PI-16 | Dependency/rights provenance | TEST-D07-SK-PI-16 | OR-D07-SK-PI-16 | FX-SK-PI-16-P | FX-SK-PI-16-N | SK-PI-16 subject-bound contract/observation + checker result | change to Dependency/rights provenance, bound subject/hash, profile version, environment or oracle |
| SK-PI-17 | Uninstall/disable semantics | TEST-D07-SK-PI-17 | OR-D07-SK-PI-17 | FX-SK-PI-17-P | FX-SK-PI-17-N | SK-PI-17 subject-bound contract/observation + checker result | change to Uninstall/disable semantics, bound subject/hash, profile version, environment or oracle |
| SK-PI-18 | Evidence return | TEST-D07-SK-PI-18 | OR-D07-SK-PI-18 | FX-SK-PI-18-P | FX-SK-PI-18-N | SK-PI-18 subject-bound contract/observation + checker result | change to Evidence return, bound subject/hash, profile version, environment or oracle |

## 20.2 PD denominator — 12/12

| Item | Obligation | TEST | ORACLE | Positive fixture | Negative/mutation fixture | Evidence | Invalidation |
|---|---|---|---|---|---|---|---|
| SK-PD-01 | Exact host/runtime/package versions | TEST-D07-SK-PD-01 | OR-D07-SK-PD-01 | FX-SK-PD-01-P | FX-SK-PD-01-N | SK-PD-01 subject-bound contract/observation + checker result | change to Exact host/runtime/package versions, bound subject/hash, profile version, environment or oracle |
| SK-PD-02 | Install/publish layout | TEST-D07-SK-PD-02 | OR-D07-SK-PD-02 | FX-SK-PD-02-P | FX-SK-PD-02-N | SK-PD-02 subject-bound contract/observation + checker result | change to Install/publish layout, bound subject/hash, profile version, environment or oracle |
| SK-PD-03 | Dependency lock | TEST-D07-SK-PD-03 | OR-D07-SK-PD-03 | FX-SK-PD-03-P | FX-SK-PD-03-N | SK-PD-03 subject-bound contract/observation + checker result | change to Dependency lock, bound subject/hash, profile version, environment or oracle |
| SK-PD-04 | Sandbox | TEST-D07-SK-PD-04 | OR-D07-SK-PD-04 | FX-SK-PD-04-P | FX-SK-PD-04-N | SK-PD-04 subject-bound contract/observation + checker result | change to Sandbox, bound subject/hash, profile version, environment or oracle |
| SK-PD-05 | Credential handles metadata | TEST-D07-SK-PD-05 | OR-D07-SK-PD-05 | FX-SK-PD-05-P | FX-SK-PD-05-N | SK-PD-05 subject-bound contract/observation + checker result | change to Credential handles metadata, bound subject/hash, profile version, environment or oracle |
| SK-PD-06 | Network boundary | TEST-D07-SK-PD-06 | OR-D07-SK-PD-06 | FX-SK-PD-06-P | FX-SK-PD-06-N | SK-PD-06 subject-bound contract/observation + checker result | change to Network boundary, bound subject/hash, profile version, environment or oracle |
| SK-PD-07 | Validation | TEST-D07-SK-PD-07 | OR-D07-SK-PD-07 | FX-SK-PD-07-P | FX-SK-PD-07-N | SK-PD-07 subject-bound contract/observation + checker result | change to Validation, bound subject/hash, profile version, environment or oracle |
| SK-PD-08 | Uninstall/rollback | TEST-D07-SK-PD-08 | OR-D07-SK-PD-08 | FX-SK-PD-08-P | FX-SK-PD-08-N | SK-PD-08 subject-bound contract/observation + checker result | change to Uninstall/rollback, bound subject/hash, profile version, environment or oracle |
| SK-PD-09 | Residue check | TEST-D07-SK-PD-09 | OR-D07-SK-PD-09 | FX-SK-PD-09-P | FX-SK-PD-09-N | SK-PD-09 subject-bound contract/observation + checker result | change to Residue check, bound subject/hash, profile version, environment or oracle |
| SK-PD-10 | Host-specific permissions | TEST-D07-SK-PD-10 | OR-D07-SK-PD-10 | FX-SK-PD-10-P | FX-SK-PD-10-N | SK-PD-10 subject-bound contract/observation + checker result | change to Host-specific permissions, bound subject/hash, profile version, environment or oracle |
| SK-PD-11 | Exact tool schema | TEST-D07-SK-PD-11 | OR-D07-SK-PD-11 | FX-SK-PD-11-P | FX-SK-PD-11-N | SK-PD-11 subject-bound contract/observation + checker result | change to Exact tool schema, bound subject/hash, profile version, environment or oracle |
| SK-PD-12 | Currentness TTL | TEST-D07-SK-PD-12 | OR-D07-SK-PD-12 | FX-SK-PD-12-P | FX-SK-PD-12-N | SK-PD-12 subject-bound contract/observation + checker result | change to Currentness TTL, bound subject/hash, profile version, environment or oracle |

## 20.3 Profile gate rule

Every row is independently applicable unless the owning profile authority permits `NOT_APPLICABLE` with a non-empty source-bound rationale. A sibling row cannot compensate for a missing row. Positive fixtures prove acceptability; negative fixtures prove the checker rejects omission/hollow/stale/mismatch. Profile tests are DOC-07 extension identities and do not rename canonical A1/A2 TEST/ORACLE IDs.

# 21｜AGENT_HARNESS Target Profile

AGENT_HARNESS conformance retains all 15 PI architecture obligations and all 13 PD bindings. Mandatory adversarial families additionally cover goal hijack, tool misuse, identity/privilege abuse, memory/context poisoning, inter-agent trust, cascading failure, rogue/unauthorized action, and sensitive-context leakage. Live-agent evaluators remain evidence producers, never lifecycle authorities.

## 21.1 PI denominator — 15/15

| Item | Obligation | TEST | ORACLE | Positive fixture | Negative/mutation fixture | Evidence | Invalidation |
|---|---|---|---|---|---|---|---|
| AH-PI-01 | identity/role | TEST-D07-AH-PI-01 | OR-D07-AH-PI-01 | FX-AH-PI-01-P | FX-AH-PI-01-N | AH-PI-01 subject-bound contract/observation + checker result | change to identity/role, bound subject/hash, profile version, environment or oracle |
| AH-PI-02 | execution loop | TEST-D07-AH-PI-02 | OR-D07-AH-PI-02 | FX-AH-PI-02-P | FX-AH-PI-02-N | AH-PI-02 subject-bound contract/observation + checker result | change to execution loop, bound subject/hash, profile version, environment or oracle |
| AH-PI-03 | tool registry | TEST-D07-AH-PI-03 | OR-D07-AH-PI-03 | FX-AH-PI-03-P | FX-AH-PI-03-N | AH-PI-03 subject-bound contract/observation + checker result | change to tool registry, bound subject/hash, profile version, environment or oracle |
| AH-PI-04 | context policy | TEST-D07-AH-PI-04 | OR-D07-AH-PI-04 | FX-AH-PI-04-P | FX-AH-PI-04-N | AH-PI-04 subject-bound contract/observation + checker result | change to context policy, bound subject/hash, profile version, environment or oracle |
| AH-PI-05 | state/memory | TEST-D07-AH-PI-05 | OR-D07-AH-PI-05 | FX-AH-PI-05-P | FX-AH-PI-05-N | AH-PI-05 subject-bound contract/observation + checker result | change to state/memory, bound subject/hash, profile version, environment or oracle |
| AH-PI-06 | lifecycle hooks | TEST-D07-AH-PI-06 | OR-D07-AH-PI-06 | FX-AH-PI-06-P | FX-AH-PI-06-N | AH-PI-06 subject-bound contract/observation + checker result | change to lifecycle hooks, bound subject/hash, profile version, environment or oracle |
| AH-PI-07 | permission/identity | TEST-D07-AH-PI-07 | OR-D07-AH-PI-07 | FX-AH-PI-07-P | FX-AH-PI-07-N | AH-PI-07 subject-bound contract/observation + checker result | change to permission/identity, bound subject/hash, profile version, environment or oracle |
| AH-PI-08 | handoff | TEST-D07-AH-PI-08 | OR-D07-AH-PI-08 | FX-AH-PI-08-P | FX-AH-PI-08-N | AH-PI-08 subject-bound contract/observation + checker result | change to handoff, bound subject/hash, profile version, environment or oracle |
| AH-PI-09 | guardrails | TEST-D07-AH-PI-09 | OR-D07-AH-PI-09 | FX-AH-PI-09-P | FX-AH-PI-09-N | AH-PI-09 subject-bound contract/observation + checker result | change to guardrails, bound subject/hash, profile version, environment or oracle |
| AH-PI-10 | eval interface | TEST-D07-AH-PI-10 | OR-D07-AH-PI-10 | FX-AH-PI-10-P | FX-AH-PI-10-N | AH-PI-10 subject-bound contract/observation + checker result | change to eval interface, bound subject/hash, profile version, environment or oracle |
| AH-PI-11 | observability | TEST-D07-AH-PI-11 | OR-D07-AH-PI-11 | FX-AH-PI-11-P | FX-AH-PI-11-N | AH-PI-11 subject-bound contract/observation + checker result | change to observability, bound subject/hash, profile version, environment or oracle |
| AH-PI-12 | recovery/checkpoint | TEST-D07-AH-PI-12 | OR-D07-AH-PI-12 | FX-AH-PI-12-P | FX-AH-PI-12-N | AH-PI-12 subject-bound contract/observation + checker result | change to recovery/checkpoint, bound subject/hash, profile version, environment or oracle |
| AH-PI-13 | human escalation | TEST-D07-AH-PI-13 | OR-D07-AH-PI-13 | FX-AH-PI-13-P | FX-AH-PI-13-N | AH-PI-13 subject-bound contract/observation + checker result | change to human escalation, bound subject/hash, profile version, environment or oracle |
| AH-PI-14 | interop boundaries | TEST-D07-AH-PI-14 | OR-D07-AH-PI-14 | FX-AH-PI-14-P | FX-AH-PI-14-N | AH-PI-14 subject-bound contract/observation + checker result | change to interop boundaries, bound subject/hash, profile version, environment or oracle |
| AH-PI-15 | provider-neutral seam | TEST-D07-AH-PI-15 | OR-D07-AH-PI-15 | FX-AH-PI-15-P | FX-AH-PI-15-N | AH-PI-15 subject-bound contract/observation + checker result | change to provider-neutral seam, bound subject/hash, profile version, environment or oracle |

## 21.2 PD denominator — 13/13

| Item | Obligation | TEST | ORACLE | Positive fixture | Negative/mutation fixture | Evidence | Invalidation |
|---|---|---|---|---|---|---|---|
| AH-PD-01 | runtime/framework version | TEST-D07-AH-PD-01 | OR-D07-AH-PD-01 | FX-AH-PD-01-P | FX-AH-PD-01-N | AH-PD-01 subject-bound contract/observation + checker result | change to runtime/framework version, bound subject/hash, profile version, environment or oracle |
| AH-PD-02 | model/provider | TEST-D07-AH-PD-02 | OR-D07-AH-PD-02 | FX-AH-PD-02-P | FX-AH-PD-02-N | AH-PD-02 subject-bound contract/observation + checker result | change to model/provider, bound subject/hash, profile version, environment or oracle |
| AH-PD-03 | MCP version/profile | TEST-D07-AH-PD-03 | OR-D07-AH-PD-03 | FX-AH-PD-03-P | FX-AH-PD-03-N | AH-PD-03 subject-bound contract/observation + checker result | change to MCP version/profile, bound subject/hash, profile version, environment or oracle |
| AH-PD-04 | A2A version/profile | TEST-D07-AH-PD-04 | OR-D07-AH-PD-04 | FX-AH-PD-04-P | FX-AH-PD-04-N | AH-PD-04 subject-bound contract/observation + checker result | change to A2A version/profile, bound subject/hash, profile version, environment or oracle |
| AH-PD-05 | sandbox/container | TEST-D07-AH-PD-05 | OR-D07-AH-PD-05 | FX-AH-PD-05-P | FX-AH-PD-05-N | AH-PD-05 subject-bound contract/observation + checker result | change to sandbox/container, bound subject/hash, profile version, environment or oracle |
| AH-PD-06 | state backend | TEST-D07-AH-PD-06 | OR-D07-AH-PD-06 | FX-AH-PD-06-P | FX-AH-PD-06-N | AH-PD-06 subject-bound contract/observation + checker result | change to state backend, bound subject/hash, profile version, environment or oracle |
| AH-PD-07 | memory store | TEST-D07-AH-PD-07 | OR-D07-AH-PD-07 | FX-AH-PD-07-P | FX-AH-PD-07-N | AH-PD-07 subject-bound contract/observation + checker result | change to memory store, bound subject/hash, profile version, environment or oracle |
| AH-PD-08 | tracing backend | TEST-D07-AH-PD-08 | OR-D07-AH-PD-08 | FX-AH-PD-08-P | FX-AH-PD-08-N | AH-PD-08 subject-bound contract/observation + checker result | change to tracing backend, bound subject/hash, profile version, environment or oracle |
| AH-PD-09 | secret handles | TEST-D07-AH-PD-09 | OR-D07-AH-PD-09 | FX-AH-PD-09-P | FX-AH-PD-09-N | AH-PD-09 subject-bound contract/observation + checker result | change to secret handles, bound subject/hash, profile version, environment or oracle |
| AH-PD-10 | tool schemas | TEST-D07-AH-PD-10 | OR-D07-AH-PD-10 | FX-AH-PD-10-P | FX-AH-PD-10-N | AH-PD-10 subject-bound contract/observation + checker result | change to tool schemas, bound subject/hash, profile version, environment or oracle |
| AH-PD-11 | timeouts/retry/checkpoint | TEST-D07-AH-PD-11 | OR-D07-AH-PD-11 | FX-AH-PD-11-P | FX-AH-PD-11-N | AH-PD-11 subject-bound contract/observation + checker result | change to timeouts/retry/checkpoint, bound subject/hash, profile version, environment or oracle |
| AH-PD-12 | eval harness | TEST-D07-AH-PD-12 | OR-D07-AH-PD-12 | FX-AH-PD-12-P | FX-AH-PD-12-N | AH-PD-12 subject-bound contract/observation + checker result | change to eval harness, bound subject/hash, profile version, environment or oracle |
| AH-PD-13 | deployment environment | TEST-D07-AH-PD-13 | OR-D07-AH-PD-13 | FX-AH-PD-13-P | FX-AH-PD-13-N | AH-PD-13 subject-bound contract/observation + checker result | change to deployment environment, bound subject/hash, profile version, environment or oracle |

## 21.3 Profile gate rule

Every row is independently applicable unless the owning profile authority permits `NOT_APPLICABLE` with a non-empty source-bound rationale. A sibling row cannot compensate for a missing row. Positive fixtures prove acceptability; negative fixtures prove the checker rejects omission/hollow/stale/mismatch. Profile tests are DOC-07 extension identities and do not rename canonical A1/A2 TEST/ORACLE IDs.

# 22｜Brownfield / Migration / Provider Exit Verification

Canonical migration verification follows:
```text
incumbent inventory + behavior freeze
→ semantic/contract diff
→ adapter/seam design
→ read-only or shadow path
→ bounded pilot
→ parity + negative + security oracle
→ bounded promotion
→ affected-only cutover
→ rollback window
→ decommission + residue proof
```

Conformance requirements:
- incumbent baseline identity must be frozen before parity claims;
- parity includes negative/error/security behavior, not only happy output;
- rollback stays valid until parity/admission closure;
- cutover is scoped and read back;
- decommission requires residue proof;
- provider exit verifies secrets/tokens/webhooks/jobs/data/config/cache/billing/routing residues;
- “new path looks healthy” cannot prove old path decommissioned.

`FX-DECOM-001` and supplemental `T-PIPD-031` are mandatory where brownfield migration applies.

# 23｜CUSTOM Target Profile / Extension Boundary

`CUSTOM` may add domain-specific fixtures/oracles through typed extensions but cannot:
- alter canonical identity separation;
- weaken claim ceilings;
- bypass permission/admission;
- weaken source/evidence binding;
- remove affected-only invalidation;
- remap the 86 stable requirement/test/oracle rows;
- rename/remove applicable core tests.

A custom oracle must declare its extension namespace, owner, applicability, deterministic reducer, evidence contract, and replacement/rollback route. If custom semantics conflict with portable core, fail closed and open CR rather than silently override core.

# 24｜Technology / Tool / OSS Selection and Qualification

Tool selection is capability-first and terminal. Every item has a terminal design disposition; no unresolved selection placeholder remains. The table in §14 records the terminal design disposition. Installation/binding/activation are later project facts.

Rules:
1. external tools are evidence producers or adapters, not semantic authority;
2. every project pin is subject to TechnologyAdmission currentness/license/security review;
3. floating tags/branches are not acceptable for gate-critical reproducibility;
4. tool output is normalized to canonical subject/test/oracle identities;
5. if a donor disappears, the portable canonical test/oracle contract remains interpretable;
6. `BUILD_MINIMAL` is legal only with explicit no-fit proof and must preserve canonical ABI;
7. CI/provider-specific machinery is routed to DOC-09 rather than absorbed by DOC-07.

# 25｜TechnologyLandingContract / Anti-Degradation Contracts

R2 retains the useful R1 landing-contract shape but removes semantic template homogenization. Only direct DOC-07 technologies receive a full contract; the full upstream donor denominator is handled by Appendix F crosswalk. A `terminal_design_disposition` is a design fact only and never means installed/bound/enabled/executed/qualified.

`TECH-PIPD-VALIDATOR` is repaired from R1 `BUILD_MINIMAL` to `SELECTED_REUSE`: the canonical implementation already exists in A1/A2, so rebuilding without a no-fit proof would itself violate `TEST-MUT-007 / OR-MUT-007`.


## 25.1 `TECH-JSONSCHEMA-SPEC` — JSON Schema Draft 2020-12

```yaml
technology_id: TECH-JSONSCHEMA-SPEC
source_ids: ["NOBJ-018"]
external_formal_name: "JSON Schema Draft 2020-12"
internal_short_name: "JSONSchema2020-12"
capability_slot: "SCHEMA_DIALECT"
source_or_vendor: "json-schema.org"
observed_latest: "Draft 2020-12"
selected_version: "Draft 2020-12"
selected_pin_policy: "spec identity / canonical dialect"
currentness_checked_at: "2026-10-07"
currentness_ttl: "30d"
currentness_status: "CURRENT_SUPPORT"
currentness_ref: "CUR-TECH-JSONSCHEMA-SPEC"
license_ref: "specification terms; no bundled runtime"
security_currentness_ref: "N/A specification-level"
terminal_design_disposition: REFERENCE
canonical_home: "DOC-07 schema dialect; canonical schema writer remains A2/A1 distribution"
portable_core_dependency: true
exact_artifact_or_package: "canonical PIPD JSON Schemas declaring Draft 2020-12"
exact_output_or_evidence: "schema validity / instance validation errors"
exact_failure_modes:
  - "wrong draft silently substituted"
  - "unresolved $ref"
  - "duplicate/conflicting $id"
  - "additionalProperties/required semantics lost"
rejected_alternatives:
  - "silent draft substitution"
  - "provider-specific schema dialect"
materialization_or_install_stage: "none for specification; validator package is separate"
bind_stage: "schema_set_hash + $schema/$id identities"
activation_authority: "validator configuration"
adapter_or_translation: "none; strict Draft 2020-12"
semantic_fields_that_must_survive:
  - "$schema"
  - "$id"
  - "required"
  - "properties"
  - "enum/const"
  - "additionalProperties"
  - "refs"
forbidden_authority_inheritance: "schema dialect cannot author lifecycle truth or grant gates"
positive_test: "known-good canonical schema set compiles and validates good fixture"
negative_test: "unresolved ref / duplicate ID / missing required field fails"
boundary_test: "alternate draft cannot be silently accepted as equivalent"
exact_test_refs: ["TEST-38EB8516", "TEST-C5BCA382"]
exact_oracle_refs: ["OR-38EB8516", "OR-C5BCA382"]
expected_evidence: "schema validity / instance validation errors; subject/version/hash/environment/checker/time bound"
fallback: "exact extracted canonical schema set only"
rollback: "restore prior canonical schema-set hash"
provider_off: "not provider-backed; local canonical copies remain authoritative"
uninstall: "not applicable to specification"
residue_check: "stale schema copies, duplicate IDs, remote refs"
replacement_route: "future PIPD standard revision only"
drift_trigger: "canonical standard/schema hash or JSON Schema dialect change"
requalification_trigger: "canonical standard/schema hash or JSON Schema dialect change or subject/profile/environment/oracle identity change"
claim_ceiling: "DESIGN_SELECTED_OR_REFERENCE_ONLY_NOT_INSTALLED_NOT_BOUND_NOT_EXECUTED"
```

## 25.2 `TECH-PY-JSONSCHEMA` — python-jsonschema

```yaml
technology_id: TECH-PY-JSONSCHEMA
source_ids: []
external_formal_name: "python-jsonschema"
internal_short_name: "py-jsonschema"
capability_slot: "SCHEMA_VALIDATOR"
source_or_vendor: "python-jsonschema/jsonschema / PyPI"
observed_latest: "PyPI 4.26.0; main changelog advertises 4.27.0"
selected_version: "4.26.0 pending publication-state resolution"
selected_pin_policy: "exact package lock at PD"
currentness_checked_at: "2026-10-07"
currentness_ttl: "24h before materialization"
currentness_status: "HOLD_WITH_TT"
currentness_ref: "CUR-TECH-PY-JSONSCHEMA"
license_ref: "MIT at selected package"
security_currentness_ref: "project advisory check at admission"
terminal_design_disposition: ADOPT_WITH_WRAPPER
canonical_home: "DOC-07 schema-validation adapter; dependency admission owned by project PD"
portable_core_dependency: false
exact_artifact_or_package: "Python package `jsonschema` / `Draft202012Validator`"
exact_output_or_evidence: "deterministic validation error path/schema path"
exact_failure_modes:
  - "API/exception behavior changes"
  - "remote/reference resolution accidentally enabled"
  - "format checker behavior assumed without declaration"
  - "library PASS promoted to lifecycle PASS"
rejected_alternatives:
  - "floating latest"
  - "raw library result as lifecycle PASS"
materialization_or_install_stage: "project qualification environment only, exact lock"
bind_stage: "thin wrapper maps validation/resolution/internal errors to PIPD exit 2/6/7"
activation_authority: "TechnologyAdmission"
adapter_or_translation: "thin wrapper preserving PIPD exit/FFI ABI"
semantic_fields_that_must_survive:
  - "instance path"
  - "schema path"
  - "subject_ref"
  - "schema_set_hash"
  - "exit_code"
  - "FFI"
forbidden_authority_inheritance: "library success cannot grant PI_READY/PREDEV_READY/VERIFIED"
positive_test: "Draft202012Validator validates known-good schema/instance"
negative_test: "invalid required field maps to exit=2"
boundary_test: "resolution/internal error maps 6/7, never 0/3"
exact_test_refs: ["TEST-C5BCA382", "TEST-38EB8516", "TEST-PRT-001"]
exact_oracle_refs: ["OR-C5BCA382", "OR-38EB8516", "OR-PRT-001"]
expected_evidence: "deterministic validation error path/schema path; subject/version/hash/environment/checker/time bound"
fallback: "alternate Draft 2020-12 validator only after parity suite"
rollback: "restore prior admitted lock"
provider_off: "local dependency; network resolution disabled for canonical set"
uninstall: "remove package/lock only after alternate validator parity"
residue_check: "venv/lock/cache/import path influencing validator"
replacement_route: "TechnologyAdmission + schema/FFI parity"
drift_trigger: "package release/security/API semantics"
requalification_trigger: "package release/security/API semantics or subject/profile/environment/oracle identity change"
claim_ceiling: "DESIGN_SELECTED_OR_REFERENCE_ONLY_NOT_INSTALLED_NOT_BOUND_NOT_EXECUTED"
```

## 25.3 `TECH-PYTEST` — pytest

```yaml
technology_id: TECH-PYTEST
source_ids: ["NOBJ-019"]
external_formal_name: "pytest"
internal_short_name: "pytest"
capability_slot: "FIXTURE_RUNNER"
source_or_vendor: "pytest-dev / PyPI"
observed_latest: "9.1.1"
selected_version: "9.1.1"
selected_pin_policy: "exact project lock at PD"
currentness_checked_at: "2026-10-07"
currentness_ttl: "7d"
currentness_status: "CURRENT_SUPPORT"
currentness_ref: "CUR-TECH-PYTEST"
license_ref: "MIT"
security_currentness_ref: "project advisory check at admission"
terminal_design_disposition: ADOPT_WITH_WRAPPER
canonical_home: "DOC-07 fixture execution adapter"
portable_core_dependency: false
exact_artifact_or_package: "pytest runner + project plugin set"
exact_output_or_evidence: "test case exit/JUnit or native report normalized to TEST/ORACLE IDs"
exact_failure_modes:
  - "plugin changes collection/order"
  - "skip/xfail masks applicable mandatory test"
  - "runner nodeid becomes canonical identity"
  - "environment/plugin leakage changes outcome"
rejected_alternatives:
  - "unversioned plugin ecosystem"
  - "runner ID as canonical TEST ID"
materialization_or_install_stage: "project qualification env; exact pytest+plugin lock"
bind_stage: "fixture IDs normalized to DOC-07 catalog"
activation_authority: "TQAEP/project admission"
adapter_or_translation: "runner node IDs normalized to canonical fixture/test/oracle IDs"
semantic_fields_that_must_survive:
  - "fixture_id"
  - "test_id"
  - "oracle_id"
  - "subject_ref"
  - "environment_binding"
  - "result"
forbidden_authority_inheritance: "green test session cannot grant lifecycle state"
positive_test: "known-good fixture emits normalized PASS"
negative_test: "seeded bad fixture fails with expected FFI"
boundary_test: "applicable skipped test cannot become PASS"
exact_test_refs: ["TEST-97BCACAC", "TEST-PRT-001", "TEST-PRT-002"]
exact_oracle_refs: ["OR-97BCACAC", "OR-PRT-001", "OR-PRT-002"]
expected_evidence: "test case exit/JUnit or native report normalized to TEST/ORACLE IDs; subject/version/hash/environment/checker/time bound"
fallback: "minimal stdlib runner for deterministic fixtures"
rollback: "restore previous lock/config"
provider_off: "replace with built-in deterministic Python runner while preserving catalog ABI"
uninstall: "remove pytest/plugins/config after replacement parity"
residue_check: ".pytest_cache, conftest/plugin autoload, env vars"
replacement_route: "runner parity + adapter-removal tests"
drift_trigger: "pytest/plugin collection, skip or assertion semantics"
requalification_trigger: "pytest/plugin collection, skip or assertion semantics or subject/profile/environment/oracle identity change"
claim_ceiling: "DESIGN_SELECTED_OR_REFERENCE_ONLY_NOT_INSTALLED_NOT_BOUND_NOT_EXECUTED"
```

## 25.4 `TECH-MCP-INSPECTOR` — MCP Inspector

```yaml
technology_id: TECH-MCP-INSPECTOR
source_ids: ["TQ-TECH-005"]
external_formal_name: "MCP Inspector"
internal_short_name: "MCPInspector"
capability_slot: "PROTOCOL_CONFORMANCE"
source_or_vendor: "modelcontextprotocol/inspector"
observed_latest: "release 2.8.0; main manifest 2.9.0"
selected_version: "2.8.0 released artifact pending project recheck"
selected_pin_policy: "release tag + package integrity at PD"
currentness_checked_at: "2026-10-07"
currentness_ttl: "24h before bind"
currentness_status: "HOLD_WITH_TT"
currentness_ref: "CUR-TECH-MCP-INSPECTOR"
license_ref: "SEE LICENSE IN LICENSE; exact release recheck"
security_currentness_ref: "project advisory and protocol-revision check"
terminal_design_disposition: REFERENCE
canonical_home: "DOC-07 MCP conformance donor; protocol binding facts owned by DOC-03"
portable_core_dependency: false
exact_artifact_or_package: "`@modelcontextprotocol/inspector` released package / protocol inspection session"
exact_output_or_evidence: "MCP handshake/capability/tool/resource/prompt observations and protocol errors"
exact_failure_modes:
  - "client/server protocol revision mismatch"
  - "capability advertises but call fails"
  - "auth/secret handling mismatch"
  - "Inspector version/main branch drift"
  - "Inspector green treated as PIPD lifecycle PASS"
rejected_alternatives:
  - "UI-only manual inspection"
  - "unbound latest main"
materialization_or_install_stage: "only MCP qualification environment if profile applicable"
bind_stage: "MCP version/profile + server/client subject refs"
activation_authority: "TechnologyAdmission + TQAEP"
adapter_or_translation: "translate Inspector observations into `TEST-D07-AH-PD-03` evidence"
semantic_fields_that_must_survive:
  - "MCP revision"
  - "server/client identity"
  - "capabilities"
  - "tool/resource/prompt observations"
  - "errors"
forbidden_authority_inheritance: "Inspector success cannot grant PREDEV_READY/VERIFIED"
positive_test: "handshake + declared capability call succeeds for bound profile"
negative_test: "declared capability but incompatible call fails"
boundary_test: "release/main version mismatch produces HOLD, not guessed pin"
exact_test_refs: ["TEST-D07-AH-PD-03", "TEST-PRT-001", "TEST-11B19333"]
exact_oracle_refs: ["OR-D07-AH-PD-03", "OR-PRT-001", "OR-11B19333"]
expected_evidence: "MCP handshake/capability/tool/resource/prompt observations and protocol errors; subject/version/hash/environment/checker/time bound"
fallback: "canonical protocol fixtures + direct SDK/client conformance"
rollback: "restore prior admitted Inspector release/config"
provider_off: "protocol fixture replay/local client replaces Inspector UI/CLI"
uninstall: "remove package, launch config and local secret-key files if created"
residue_check: "mcp.json, secret-key file, cached sessions/config"
replacement_route: "MCP profile parity before replacement"
drift_trigger: "MCP protocol revision, Inspector release, manifest/license/security change"
requalification_trigger: "MCP protocol revision, Inspector release, manifest/license/security change or subject/profile/environment/oracle identity change"
claim_ceiling: "DESIGN_SELECTED_OR_REFERENCE_ONLY_NOT_INSTALLED_NOT_BOUND_NOT_EXECUTED"
```

## 25.5 `TECH-TRIVY` — Trivy

```yaml
technology_id: TECH-TRIVY
source_ids: ["TQ-TECH-014"]
external_formal_name: "Trivy"
internal_short_name: "Trivy"
capability_slot: "SECURITY_SCANNER"
source_or_vendor: "Aqua Security"
observed_latest: "0.75.0 released 2026-10-01"
selected_version: "0.75.0"
selected_pin_policy: "immutable release/tag + checksums at PD"
currentness_checked_at: "2026-10-07"
currentness_ttl: "24h before security qualification"
currentness_status: "CURRENT_SUPPORT_R2"
currentness_ref: "CUR-TECH-TRIVY"
license_ref: "Apache-2.0 project family; exact release recheck"
security_currentness_ref: "scanner DB + binary provenance/advisory recheck"
terminal_design_disposition: REFERENCE
canonical_home: "DOC-07 security qualification input"
portable_core_dependency: false
exact_artifact_or_package: "Trivy v0.75.0 binary/container + vulnerability/misconfiguration/license DB snapshot"
exact_output_or_evidence: "JSON/SARIF/table findings with target digest and DB metadata"
exact_failure_modes:
  - "scanner binary/DB stale"
  - "target digest wrong"
  - "offline DB absent"
  - "misconfiguration policy bundle drift"
  - "zero findings mistaken for security assurance"
rejected_alternatives:
  - "scanner-free security claim"
  - "floating DB without freshness"
materialization_or_install_stage: "optional qualification scanner; exact release/checksum/DB freshness recorded"
bind_stage: "target subject hash + scanner version + DB snapshot"
activation_authority: "TQAEP security lane"
adapter_or_translation: "normalize scanner finding/evidence; no score-to-gate mapping"
semantic_fields_that_must_survive:
  - "target digest"
  - "scanner version"
  - "DB metadata"
  - "finding IDs/severity"
  - "policy bundle digest"
forbidden_authority_inheritance: "zero findings cannot prove security acceptance"
positive_test: "clean fixture has no seeded critical issue"
negative_test: "seeded vulnerable/misconfigured fixture is detected"
boundary_test: "stale DB or wrong target digest yields HOLD"
exact_test_refs: ["TEST-D28A8B60", "TEST-79A6948B", "TEST-6F8DCD42"]
exact_oracle_refs: ["OR-D28A8B60", "OR-79A6948B", "OR-6F8DCD42"]
expected_evidence: "JSON/SARIF/table findings with target digest and DB metadata; subject/version/hash/environment/checker/time bound"
fallback: "alternate scanner plus native negative fixtures; never synthetic PASS"
rollback: "restore previous admitted scanner/DB tuple"
provider_off: "switch to alternate admitted vulnerability/config scanner; preserve expected evidence fields"
uninstall: "remove binary/container and scanner cache/DB when decommissioned"
residue_check: "~/.cache/trivy, DB layers, policy cache, workflow config"
replacement_route: "security-scanner equivalence + seeded vulnerable fixture"
drift_trigger: "release 0.75.0+, DB age, advisory feed or policy bundle"
requalification_trigger: "release 0.75.0+, DB age, advisory feed or policy bundle or subject/profile/environment/oracle identity change"
claim_ceiling: "DESIGN_SELECTED_OR_REFERENCE_ONLY_NOT_INSTALLED_NOT_BOUND_NOT_EXECUTED"
```

## 25.6 `TECH-SEMGREP` — Semgrep CLI

```yaml
technology_id: TECH-SEMGREP
source_ids: ["TQ-TECH-025"]
external_formal_name: "Semgrep CLI"
internal_short_name: "Semgrep"
capability_slot: "STATIC_SECURITY_SCANNER"
source_or_vendor: "Semgrep"
observed_latest: "1.179.0"
selected_version: "1.179.0"
selected_pin_policy: "exact CLI release + rulepack digests at PD"
currentness_checked_at: "2026-10-07"
currentness_ttl: "24h before qualification"
currentness_status: "CURRENT_SUPPORT"
currentness_ref: "CUR-TECH-SEMGREP"
license_ref: "LGPL-2.1 for CLI source; exact distribution recheck"
security_currentness_ref: "engine + ruleset provenance/advisory check"
terminal_design_disposition: REFERENCE
canonical_home: "DOC-07 static-security evidence input"
portable_core_dependency: false
exact_artifact_or_package: "Semgrep CLI + exact ruleset/config digests"
exact_output_or_evidence: "JSON/SARIF findings keyed to file/rule/revision"
exact_failure_modes:
  - "rulepack changed without digest"
  - "language parser coverage gap"
  - "baseline suppresses seeded finding"
  - "license/distribution mismatch"
  - "no findings interpreted as semantic PASS"
rejected_alternatives:
  - "generic SAST wording"
  - "unhashed remote rules"
materialization_or_install_stage: "optional qualification environment, exact CLI/rulepack pin"
bind_stage: "repo hash + ruleset digest + config"
activation_authority: "TQAEP security lane"
adapter_or_translation: "normalize JSON/SARIF findings to subject-bound evidence"
semantic_fields_that_must_survive:
  - "repo revision"
  - "rule ID"
  - "ruleset digest"
  - "path/span"
  - "finding severity"
forbidden_authority_inheritance: "absence of rule hits cannot grant overall security PASS"
positive_test: "clean code corpus yields expected no-hit for seeded rules"
negative_test: "seeded vulnerable pattern triggers named rule"
boundary_test: "suppression/baseline/ruleset drift requires requalification"
exact_test_refs: ["TEST-D28A8B60", "TEST-79A6948B", "TEST-6F8DCD42"]
exact_oracle_refs: ["OR-D28A8B60", "OR-79A6948B", "OR-6F8DCD42"]
expected_evidence: "JSON/SARIF findings keyed to file/rule/revision; subject/version/hash/environment/checker/time bound"
fallback: "language-native linters + targeted deterministic security tests"
rollback: "restore prior CLI/ruleset lock"
provider_off: "replace with admitted SAST engine; retain seeded rule-hit corpus"
uninstall: "remove CLI/package, CI hook and downloaded rules"
residue_check: ".semgrep, caches, suppressions/baselines, CI config"
replacement_route: "seeded findings parity + false-positive review"
drift_trigger: "engine/rules/parser/license changes"
requalification_trigger: "engine/rules/parser/license changes or subject/profile/environment/oracle identity change"
claim_ceiling: "DESIGN_SELECTED_OR_REFERENCE_ONLY_NOT_INSTALLED_NOT_BOUND_NOT_EXECUTED"
```

## 25.7 `TECH-GITLEAKS` — Gitleaks

```yaml
technology_id: TECH-GITLEAKS
source_ids: ["NOBJ-022", "TQ-TECH-027"]
external_formal_name: "Gitleaks"
internal_short_name: "Gitleaks"
capability_slot: "SECRET_SCANNER"
source_or_vendor: "gitleaks/gitleaks"
observed_latest: "8.30.1"
selected_version: "8.30.1"
selected_pin_policy: "exact scanner release + checksum at PD"
currentness_checked_at: "2026-10-07"
currentness_ttl: "24h before qualification"
currentness_status: "CURRENT_SUPPORT"
currentness_ref: "CUR-TECH-GITLEAKS"
license_ref: "MIT scanner; GitHub Action wrapper separately admitted"
security_currentness_ref: "binary/checksum/advisory check"
terminal_design_disposition: REFERENCE
canonical_home: "DOC-07 secret-scanning evidence input"
portable_core_dependency: false
exact_artifact_or_package: "Gitleaks scanner binary + config/baseline"
exact_output_or_evidence: "secret finding report with commit/path/rule identity"
exact_failure_modes:
  - "baseline hides seeded secret"
  - "history scan scope narrowed"
  - "custom rules drift"
  - "Action wrapper license/version differs from scanner"
  - "report contains secret value unredacted"
rejected_alternatives:
  - "Action wrapper treated as same artifact"
  - "secret values logged in evidence"
materialization_or_install_stage: "optional qualification/CI scanner; scanner and Action admitted separately"
bind_stage: "repo/commit hash + rule config digest"
activation_authority: "TQAEP security lane"
adapter_or_translation: "redact secret material; preserve rule/commit/path identity"
semantic_fields_that_must_survive:
  - "repo/commit"
  - "rule ID"
  - "config digest"
  - "finding location"
  - "redaction state"
forbidden_authority_inheritance: "scanner/action cannot grant release or security authority"
positive_test: "non-secret corpus stays clean"
negative_test: "seeded token/private-key fixture detected without secret leakage"
boundary_test: "baseline hiding seeded secret fails qualification"
exact_test_refs: ["TEST-D28A8B60", "TEST-79A6948B", "TEST-6F8DCD42"]
exact_oracle_refs: ["OR-D28A8B60", "OR-79A6948B", "OR-6F8DCD42"]
expected_evidence: "secret finding report with commit/path/rule identity; subject/version/hash/environment/checker/time bound"
fallback: "alternate scanner + seeded secret/non-secret fixture"
rollback: "restore previous scanner/config"
provider_off: "alternate secret scanner or deterministic seeded regex/entropy checks for minimum coverage"
uninstall: "remove binary/action/config only after seeded corpus parity"
residue_check: ".gitleaks.toml, baselines, reports, CI hooks, cached binary"
replacement_route: "secret corpus recall + false-positive parity"
drift_trigger: "scanner release, rule config, history semantics, wrapper action"
requalification_trigger: "scanner release, rule config, history semantics, wrapper action or subject/profile/environment/oracle identity change"
claim_ceiling: "DESIGN_SELECTED_OR_REFERENCE_ONLY_NOT_INSTALLED_NOT_BOUND_NOT_EXECUTED"
```

## 25.8 `TECH-OSSF-SCORECARD` — OpenSSF Scorecard

```yaml
technology_id: TECH-OSSF-SCORECARD
source_ids: ["TQ-TECH-029"]
external_formal_name: "OpenSSF Scorecard"
internal_short_name: "Scorecard"
capability_slot: "OSS_POSTURE_SIGNAL"
source_or_vendor: "OpenSSF"
observed_latest: "5.5.0"
selected_version: "5.5.0"
selected_pin_policy: "exact release where used"
currentness_checked_at: "2026-10-07"
currentness_ttl: "7d"
currentness_status: "CURRENT_SUPPORT"
currentness_ref: "CUR-TECH-OSSF-SCORECARD"
license_ref: "Apache-2.0"
security_currentness_ref: "workflow/action pin and token scope recheck"
terminal_design_disposition: EVAL_ONLY
canonical_home: "DOC-07 support-only OSS posture signal"
portable_core_dependency: false
exact_artifact_or_package: "Scorecard CLI/action + repository posture result"
exact_output_or_evidence: "JSON/SARIF check scores and reasons"
exact_failure_modes:
  - "score interpreted as PIPD security approval"
  - "token permissions too broad"
  - "check semantics/version changed"
  - "repository context differs from evaluated subject"
rejected_alternatives:
  - "score threshold as release gate"
  - "unscoped repo result"
materialization_or_install_stage: "eval-only; workflow use routed to DOC-09"
bind_stage: "repo revision + Scorecard version/check set"
activation_authority: "TQAEP support signal"
adapter_or_translation: "record check results as observations only"
semantic_fields_that_must_survive:
  - "repo revision"
  - "Scorecard version"
  - "check name"
  - "score/reason"
  - "token scope"
forbidden_authority_inheritance: "aggregate score cannot replace explicit PIPD security/provenance gates"
positive_test: "known repository posture checks are reproducible"
negative_test: "seeded weak posture lowers specific check / yields finding"
boundary_test: "token/workflow/repo mismatch invalidates signal"
exact_test_refs: ["TEST-E6CD4BED", "TEST-11B19333", "TEST-D28A8B60"]
exact_oracle_refs: ["OR-E6CD4BED", "OR-11B19333", "OR-D28A8B60"]
expected_evidence: "JSON/SARIF check scores and reasons; subject/version/hash/environment/checker/time bound"
fallback: "direct provenance/branch/dependency policy tests"
rollback: "restore prior support-only signal config"
provider_off: "omit signal or use equivalent OSS posture service; core PIPD gates unaffected"
uninstall: "remove action/CLI and token permissions"
residue_check: "workflow file, SARIF uploads, token scopes, cached reports"
replacement_route: "support-signal comparison; no gate authority"
drift_trigger: "check definitions, action/CLI release, API/token policy"
requalification_trigger: "check definitions, action/CLI release, API/token policy or subject/profile/environment/oracle identity change"
claim_ceiling: "DESIGN_SELECTED_OR_REFERENCE_ONLY_NOT_INSTALLED_NOT_BOUND_NOT_EXECUTED"
```

## 25.9 `TECH-SKILLEVALUATOR` — NVIDIA SkillEvaluator

```yaml
technology_id: TECH-SKILLEVALUATOR
source_ids: ["TQ-TECH-001"]
external_formal_name: "NVIDIA SkillEvaluator"
internal_short_name: "SkillEvaluator"
capability_slot: "SKILL_PLUGIN_EVAL"
source_or_vendor: "NVIDIA"
observed_latest: "0.4.0 (2026-09-30)"
selected_version: "0.4.0 for evaluation-only design"
selected_pin_policy: "exact release/container revision at pilot"
currentness_checked_at: "2026-10-07"
currentness_ttl: "7d"
currentness_status: "CURRENT_SUPPORT"
currentness_ref: "CUR-TECH-SKILLEVALUATOR"
license_ref: "Apache-2.0 project; exact release recheck"
security_currentness_ref: "sandbox/evidence redaction/model-provider checks"
terminal_design_disposition: EVAL_ONLY
canonical_home: "DOC-07 Skill/Plugin evaluation donor"
portable_core_dependency: false
exact_artifact_or_package: "SkillEvaluator 0.4.0 + evaluator container/revision + dataset/eval guidance"
exact_output_or_evidence: "catalog-summary.json and per-skill JSON/benchmark/evidence reports"
exact_failure_modes:
  - "LLM judge/model drift"
  - "off-skill negative missing"
  - "evaluated source revision omitted"
  - "evaluator container differs"
  - "unsafe/untrusted content rendering"
  - "score promoted directly to lifecycle PASS"
rejected_alternatives:
  - "single judge score"
  - "unversioned skill source"
materialization_or_install_stage: "sandboxed evaluation pilot only"
bind_stage: "skill source revision + evaluator container revision + model/provider/dataset"
activation_authority: "TQAEP eval only"
adapter_or_translation: "map evaluator cases/reports to profile TEST/ORACLE; canonical reducer remains PIPD"
semantic_fields_that_must_survive:
  - "evaluated source revision"
  - "evaluator revision"
  - "model/provider"
  - "dataset/guidance"
  - "per-case evidence"
forbidden_authority_inheritance: "LLM judge/benchmark score cannot self-issue VERIFIED"
positive_test: "on-skill positive case succeeds with allowed tools"
negative_test: "off-skill/forbidden-tool case is rejected"
boundary_test: "model/evaluator/dataset drift requires rerun"
exact_test_refs: ["TEST-D07-SK-PI-01", "TEST-D07-SK-PI-02", "TEST-PRT-001", "TEST-11B19333"]
exact_oracle_refs: ["OR-D07-SK-PI-01", "OR-D07-SK-PI-02", "OR-PRT-001", "OR-11B19333"]
expected_evidence: "catalog-summary.json and per-skill JSON/benchmark/evidence reports; subject/version/hash/environment/checker/time bound"
fallback: "native deterministic skill conformance suite + human/semantic judge only where declared"
rollback: "restore prior evaluator image/config/dataset"
provider_off: "static schema/trigger/tool boundary fixtures remain authoritative"
uninstall: "remove evaluator env/container and reports only after evidence retention policy satisfied"
residue_check: "reports, benchmark cards, model credentials/cache, temp sandboxes"
replacement_route: "same skill corpus + canonical reducer parity"
drift_trigger: "evaluator version, model provider, prompt/rubric/dataset/security changes"
requalification_trigger: "evaluator version, model provider, prompt/rubric/dataset/security changes or subject/profile/environment/oracle identity change"
claim_ceiling: "DESIGN_SELECTED_OR_REFERENCE_ONLY_NOT_INSTALLED_NOT_BOUND_NOT_EXECUTED"
```

## 25.10 `TECH-HARBOR` — Harbor agent evaluation framework

```yaml
technology_id: TECH-HARBOR
source_ids: ["TQ-TECH-003"]
external_formal_name: "Harbor agent evaluation framework"
internal_short_name: "Harbor"
capability_slot: "AGENT_LIVE_EVAL"
source_or_vendor: "harbor-framework"
observed_latest: "release 0.24.0 (2026-10-05); indexed main metadata previously 0.23.0"
selected_version: "0.24.0 released artifact pending metadata recheck"
selected_pin_policy: "release tag + environment/container digests at pilot"
currentness_checked_at: "2026-10-07"
currentness_ttl: "24h before evaluation"
currentness_status: "HOLD_WITH_TT"
currentness_ref: "CUR-TECH-HARBOR"
license_ref: "Apache-2.0 project; exact pin recheck"
security_currentness_ref: "sandbox/verifier/mount isolation recheck"
terminal_design_disposition: EVAL_ONLY
canonical_home: "DOC-07 Agent Harness live-eval donor"
portable_core_dependency: false
exact_artifact_or_package: "Harbor v0.24.0 environment/task/verifier definitions + agent image"
exact_output_or_evidence: "trajectory, logs, verifier/reward results and environment content hash"
exact_failure_modes:
  - "verifier mount excluded"
  - "cross-step logs/tests leak"
  - "environment hash drift"
  - "agent/model/provider changed"
  - "reward criterion bug"
  - "sandbox side effect escapes"
rejected_alternatives:
  - "live eval without environment hash"
  - "reward-only gate"
materialization_or_install_stage: "sandboxed agent evaluation only; exact release/images"
bind_stage: "task/env/verifier/agent/model/container digests"
activation_authority: "TQAEP eval only"
adapter_or_translation: "normalize trajectory/verifier/reward into profile evidence; verifier is not canonical authority"
semantic_fields_that_must_survive:
  - "task ID"
  - "environment hash"
  - "verifier hash"
  - "agent/model"
  - "trajectory/log refs"
  - "reward/verdict"
forbidden_authority_inheritance: "reward success cannot grant lifecycle state or effect confirmation"
positive_test: "deterministic sandbox task passes bound verifier"
negative_test: "forbidden action or failing task produces non-PASS"
boundary_test: "mount/verifier/env drift invalidates prior result"
exact_test_refs: ["TEST-D07-AH-PD-12", "TEST-D07-AH-PD-13", "TEST-PRT-001", "TEST-11B19333"]
exact_oracle_refs: ["OR-D07-AH-PD-12", "OR-D07-AH-PD-13", "OR-PRT-001", "OR-11B19333"]
expected_evidence: "trajectory, logs, verifier/reward results and environment content hash; subject/version/hash/environment/checker/time bound"
fallback: "deterministic replay/simulator + direct checker"
rollback: "restore prior task/env/verifier bundle"
provider_off: "use canonical replay fixtures or alternate admitted agent-eval runner"
uninstall: "remove env images/volumes/jobs after evidence export and cleanup verification"
residue_check: "containers, volumes, logs, verifier artifacts, credentials, hosted tasks"
replacement_route: "same tasks + verifier/evidence parity"
drift_trigger: "Harbor release, task/verifier definitions, container/runtime/model/provider"
requalification_trigger: "Harbor release, task/verifier definitions, container/runtime/model/provider or subject/profile/environment/oracle identity change"
claim_ceiling: "DESIGN_SELECTED_OR_REFERENCE_ONLY_NOT_INSTALLED_NOT_BOUND_NOT_EXECUTED"
```

## 25.11 `TECH-GHA` — GitHub Actions

```yaml
technology_id: TECH-GHA
source_ids: ["NOBJ-020", "TQ-TECH-028"]
external_formal_name: "GitHub Actions"
internal_short_name: "GitHubActions"
capability_slot: "CI_EXECUTION"
source_or_vendor: "GitHub"
observed_latest: "service; action versions vary"
selected_version: "route-out to DOC-09; immutable action SHAs only"
selected_pin_policy: "workflow/action SHA set at project integration"
currentness_checked_at: "2026-10-07"
currentness_ttl: "per workflow change + 7d external action recheck"
currentness_status: "ROUTE_OUT"
currentness_ref: "CUR-TECH-GHA"
license_ref: "service terms + per-action license"
security_currentness_ref: "OIDC/token/permission/action pin review"
terminal_design_disposition: ROUTE_OUT
canonical_home: "DOC-09 CI execution owner; DOC-07 defines report ABI only"
portable_core_dependency: false
exact_artifact_or_package: "workflow YAML + immutable action SHAs + check-run result"
exact_output_or_evidence: "required check conclusion, logs, artifacts/attestations"
exact_failure_modes:
  - "path filter skips required check"
  - "unpinned third-party action"
  - "token permission too broad"
  - "workflow green but DOC-07 report absent"
  - "runner image drift"
rejected_alternatives:
  - "provider-specific semantic gate"
  - "floating action tags"
materialization_or_install_stage: "DOC-09/project CI only; DOC-07 does not own workflow install"
bind_stage: "workflow hash + action SHAs + repo/branch protection"
activation_authority: "DOC-09 / project permissions"
adapter_or_translation: "invoke provider-neutral PIPD command and upload canonical report"
semantic_fields_that_must_survive:
  - "workflow digest"
  - "action SHAs"
  - "required-check name"
  - "subject/ref"
  - "report digest"
forbidden_authority_inheritance: "CI green cannot override DOC-07 failing report"
positive_test: "relevant change runs required check and uploads valid report"
negative_test: "path filter/unpinned action/wrong report digest fails policy"
boundary_test: "provider-off alternate CI must preserve same report/exit ABI"
exact_test_refs: ["TEST-11B19333", "TEST-C5BCA382", "TEST-79A6948B"]
exact_oracle_refs: ["OR-11B19333", "OR-C5BCA382", "OR-79A6948B"]
expected_evidence: "required check conclusion, logs, artifacts/attestations; subject/version/hash/environment/checker/time bound"
fallback: "local runner or alternate CI executes canonical command"
rollback: "restore prior required-check workflow and policy"
provider_off: "local/alternate CI invokes same provider-neutral CLI/report ABI"
uninstall: "DOC-09 removes workflow/check requirement after replacement closure"
residue_check: "workflow files, branch protection, OIDC/trust, secrets, artifacts"
replacement_route: "provider-neutral conformance report parity"
drift_trigger: "workflow/action SHA, runner image, permission/branch-protection semantics"
requalification_trigger: "workflow/action SHA, runner image, permission/branch-protection semantics or subject/profile/environment/oracle identity change"
claim_ceiling: "DESIGN_SELECTED_OR_REFERENCE_ONLY_NOT_INSTALLED_NOT_BOUND_NOT_EXECUTED"
```

## 25.12 `TECH-PIPD-VALIDATOR` — PIPD canonical semantic validator

```yaml
technology_id: TECH-PIPD-VALIDATOR
source_ids: []
external_formal_name: "PIPD canonical semantic validator"
internal_short_name: "pipd_validate"
capability_slot: "PIPD_SEMANTIC_VALIDATOR"
source_or_vendor: "PIPD-LIFECYCLE-SPEC@1.1.0"
observed_latest: "PIPD-LIFECYCLE-SPEC@1.1.0 canonical reference implementation"
selected_version: "1.1.0"
selected_pin_policy: "A1/A2 source hash + generated file hash"
currentness_checked_at: "2026-10-07"
currentness_ttl: "on canonical standard/blueprint hash change"
currentness_status: "SELECTED_REUSE"
currentness_ref: "CUR-TECH-PIPD-VALIDATOR"
license_ref: "internal standard artifact"
security_currentness_ref: "local generated code review + seeded mutation suite"
terminal_design_disposition: SELECTED_REUSE
canonical_home: "A1/A2 canonical generated tooling; DOC-07 consumes/qualifies"
portable_core_dependency: true
exact_artifact_or_package: "A2 canonical `pipd_validate.py` reference implementation + A1 `pipd_tree_validate.py` orchestrator, repaired R2 effect semantic overlay"
exact_output_or_evidence: "canonical ConformanceReport JSON + exit 0/2/3/4/5/6/7 + FFI"
exact_failure_modes:
  - "86 tuple remap"
  - "A2 UX command bypasses A1 profile/orchestrator"
  - "effect kind no-op false PASS"
  - "wrong applicability enum"
  - "validator exception reported PASS"
  - "tool runner becomes semantic authority"
rejected_alternatives:
  - "BUILD_MINIMAL new validator"
  - "direct A2 no-op effect path"
materialization_or_install_stage: "materialize exact canonical generated validator/orchestrator into project distribution; no new greenfield validator authority"
bind_stage: "A1 tree orchestrator is operative integration spine; A2 CLI only compatibility wrapper"
activation_authority: "project conformance run"
adapter_or_translation: "A1 tree orchestrator operative; A2 UX only compatibility wrapper; R2 effect guard precheck"
semantic_fields_that_must_survive:
  - "A1/A2 hashes"
  - "86 tuples"
  - "profile"
  - "exit ABI"
  - "FFI"
  - "ConformanceReport"
  - "effect reconciliation"
forbidden_authority_inheritance: "validator cannot change requirements, grant execution permission, or self-certify independence"
positive_test: "known-good tree returns exit 0 and valid report"
negative_test: "each seeded mutation returns expected nonzero+FFI"
boundary_test: "adapter removed/second harness preserves semantics"
exact_test_refs: ["TEST-97BCACAC", "TEST-MUT-009", "TEST-2E59E411", "TEST-PRT-001", "TEST-PRT-002"]
exact_oracle_refs: ["OR-97BCACAC", "OR-MUT-009", "OR-2E59E411", "OR-PRT-001", "OR-PRT-002"]
expected_evidence: "canonical ConformanceReport JSON + exit 0/2/3/4/5/6/7 + FFI; subject/version/hash/environment/checker/time bound"
fallback: "restore exact canonical generated reference + R2 effect fix; fail closed if unresolved"
rollback: "restore previous locked PIPD generated bundle hash"
provider_off: "fully local/provider-neutral; runner adapters removable"
uninstall: "replace only by conformant validator passing all seeded regressions and portability tests"
residue_check: "stale generated schema/registry/validator copies, duplicate wrappers, cached reports"
replacement_route: "standard revision/CR + full conformance equivalence"
drift_trigger: "A1/A2 hash, schema/test/oracle identity, wrapper/profile/effect semantics"
requalification_trigger: "A1/A2 hash, schema/test/oracle identity, wrapper/profile/effect semantics or subject/profile/environment/oracle identity change"
claim_ceiling: "DESIGN_SELECTED_OR_REFERENCE_ONLY_NOT_INSTALLED_NOT_BOUND_NOT_EXECUTED"
r1_disposition_repaired_from: "BUILD_MINIMAL"
r2_build_minimal_status: "NOT_USED"
no_fit_reason: null
failed_candidate_gap_set: []
repair_rationale: "Existing A1/A2 canonical reference implementation is reused/materialized; BUILD_MINIMAL would be a false no-fit claim."
```

# 26｜Portability / Adapter Removal / Cross-Harness Conformance

`TEST-PRT-001` and `TEST-PRT-002` enforce semantic portability.

**PRT-001 — second harness:** run the same canonical PI/PD fixture through a second conformant LLM/harness/validator adapter. Required fields, TEST/ORACLE identities, failure boundaries and gate outcomes must remain semantically equivalent. Differences become findings; they are not silently normalized.

**PRT-002 — adapter removal:** remove AGENTS/SKILL/vendor/IDE/provider adapter and interpret the canonical package directly. If core semantics become unreadable, the adapter has become hidden authority and the package fails portability.

Provider-specific conveniences may improve ergonomics, but canonical validation remains possible using the standard schema set + semantic validator + stable registries. Adapter state tokens, local runner IDs and vendor results remain projections.

# 27｜Evidence / Checker / Qualification Contract

Evidence must bind:
`subject/version/hash`, changed/observed artifacts, exact command/action/procedure, raw result, verification/oracle verdict, environment, producer/checker, timestamp, checksums, approval reference where applicable, and rollback/residue outcome.

Checker rules:
- checker identity/version is recorded;
- independence class is explicit;
- maker self-review may be useful author evidence but is not mislabeled independent;
- wrong subject/version/hash evidence is rejected before outcome reduction;
- raw/verifiable references outrank summary-only claims;
- stale/invalidated evidence cannot be refreshed by editing its timestamp;
- stochastic evaluation must preserve dataset, seed/prompt set, repetitions, evaluator version and reducer.

`TQAEP_COMPLETE` means the qualification **plan** is construction-ready. It is not test execution, verification, qualification or PASS. `VERIFIED` requires actual applicable test/oracle satisfaction; `QUALIFIED` requires the qualification authority and executed TQAEP evidence. DOC-07 by itself grants neither.

# 28｜Failure / Invalidation / Rollback / Retest / SELF_ITERATION_LOOP


```text
on_conformance(subject, profile):
    resolve canonical standard + schema/test/oracle identities
    if resolution fails: exit 6
    if schema fails: exit 2
    if source/subject/currentness stale: exit 4
    if semantic invariant fails: exit 3
    if permission/approval fails: exit 5
    run applicable core + profile tests
    for each result:
        bind subject/version/hash/env/checker/time
        reject stale/foreign evidence
        record first failing invariant
    if effectful:
        require readback + reconciliation before CONFIRMED_EFFECT
    reduce to PASS/FAIL/HOLD
    emit canonical ConformanceReport
```

```text
on_change(X):
    compute new identity/hash
    supersede old X
    traverse reverse dependencies
    for each dependent D:
        if changed field intersects consumed contract:
            mark D STALE
            invalidate only D-dependent evidence/gates
    preserve unrelated accepted evidence
```

Retest scope is the transitive affected slice plus mandatory cross-boundary tests. Rollback does not erase evidence; it creates a new bounded state and residue/readback evidence. If rollback itself can have external effects, it is subject to admission and reconciliation.

## 28.1 Named donor workflow identity preservation — `SELF_ITERATION_LOOP`

R2 materializes the A3 donor workflow rather than hiding it behind a generic retest paragraph:

| Workflow ID | Capability role | Canonical home | Treatment | Imported steps | Excluded semantics | Required test/exit |
|---|---|---|---|---|---|---|
| MISSION_TO_EXECUTION | mission→bounded execution orchestration | DOC-02 PI → DOC-03 S2E/WO/ECP → DOC-05 admission | TRANSLATE | mission decomposition, bounded work, evidence return | donor cannot grant PIPD lifecycle authority | trace continuity + no-execution-before-ADMIT; remove adapter cleanly |
| PHASES_RB00_RB15 | phase/runbook progression | DOC-09 Adoption Waves/Runbook | TRANSLATE | phase entry/exit/checkpoint/readback | donor phase labels not canonical lifecycle states | phase-to-canonical-state mapping; rollback/resume |
| WORKORDER_ADMISSION | WO→admission control | DOC-03/05 | KEEP_PATTERN | WO identity, permission, admission separation | WO/ECP never self-authorize | negative ECP-only/WO-only first mutation |
| CROSS_SESSION_PIPELINE | resume/handoff continuity | DOC-03/04 | TRANSLATE | subject/version/hash, checkpoint, context/evidence handoff | memory/session state not semantic authority | resume wrong-subject/stale-hash negative; purge/expiry |
| PROVIDER_ADMISSION | provider qualification/binding | DOC-02 TechnologyAdmission + DOC-03 currentness | TRANSLATE | pin/license/security/capability/exit | provider cannot own canonical semantics | provider-off/parity/currentness TTL |
| LONG_RUNNING_CONTROL | long-horizon checkpoint/recovery | DOC-03 ECP / DOC-09 runbook | TRANSLATE | checkpoint, stop/retry, recovery, evidence | no autonomous authority expansion | timeout/restart/recovery + scope containment |
| SELF_ITERATION_LOOP | bounded repair/iteration | DOC-07 rework/requalification | REFERENCE | repair loop under stable oracle | no self-issued PASS or requirement rewrite | mutation/rework stop + human/acceptor boundary |
| RELEASE_RECOVERY | release/rollback/recovery | DOC-09 Release Lane | TRANSLATE | artifact identity, recovery, rollback, evidence | release workflow cannot replace acceptance/qualification | digest/attestation/rollback/residue tests |

For `SELF_ITERATION_LOOP` specifically:

```text
failing fixture/oracle
→ freeze failing subject/test/oracle identity
→ create bounded repair delta
→ rerun the exact failing child fixture first
→ rerun transitive affected tests
→ rerun required cross-boundary/portability tests
→ stop on stable PASS or bounded retry budget
→ human/acceptor escalation when budget/authority boundary reached
```

Forbidden semantics:
- no self-issued PASS;
- no requirement rewrite to make the test green;
- no oracle weakening;
- no silent profile downgrade;
- no evidence timestamp refresh as a substitute for re-execution.

## 28.2 DOC-07-owned lifecycle quality metric

`cross_agent_semantic_agreement` is an **observation metric**, not a gate substitute.

```yaml
metric_id: cross_agent_semantic_agreement
owner: PIPD_LS_DOC-07
collection_point: portability / independent-consumer conformance runs
numerator: independent consumer runs deriving the same canonical subject identity, lifecycle state, first failing invariant (or PASS), and next owning gate
denominator: sampled applicable conformance cases executed by at least two independent consumers/harnesses
formula: numerator / denominator
range: [0, 1]
direction: higher_is_better
alert_rule: material decrease or disagreement on any gate-critical case opens finding/TT and triggers PRT/requalification
gate_non_substitution: true
```

A high metric does not create `VERIFIED`, `QUALIFIED`, `RELEASED`, or `PRODUCTION_VERIFIED`. Disagreement is a diagnostic signal that routes back to source/oracle/profile resolution.

# 29｜Cross-DOC Interfaces / Writer Boundaries

| DOC | Canonical responsibility consumed by DOC-07 | DOC-07 may verify | DOC-07 must not rewrite |
|---|---|---|---|
| DOC-01 | authority/lifecycle/claim/SoD/invalidation | state/claim/SoD fixtures | lifecycle state semantics |
| DOC-02 | PI, atomic REQ, SBB, TechnologyAdmission, PI_READY | PI conformance and anti-downgrade | technology decision authority |
| DOC-03 | RepoContext/currentness/S2E/Seed/WO/ECP/TQAEP/PREDEV_READY | PD/currentness/TQAEP fixtures | environment/PD truth |
| DOC-04 | REQ→SPEC→ACC→VER→EVD→DEL→GATE, evidence | trace/evidence identity | evidence semantic ownership |
| DOC-05 | handoff/receiver/permission/effect/ExecutionAdmission | NACK/admission/effect tests | ADMIT/HOLD/DENY authority |
| DOC-06 | weight/target/applicability | profile-specific test applicability | profile policy |
| DOC-07 | TEST/ORACLE/FIXTURE/conformance | canonical writer | — |
| DOC-08 | AI consumption/adapters/maturity | portability/adapter tests | AI routing/maturity ownership |
| DOC-09 | CI/release/supply-chain/runbook/tooling | CI integration output ABI | release/CI authority |

Cross-DOC references are by canonical identity/hash, not copied prose. If a sibling changes a consumed contract, DOC-07 evidence is invalidated only where its test/oracle consumed that contract.

# 30｜CI / TQAEP / Checker Integration Boundary

DOC-07 defines what a conformance run must mean and emit; DOC-09 owns CI workflow/release mechanics; DOC-03 owns TQAEP construction; DOC-04 owns evidence contracts.

Provider-neutral CI ABI:
```text
python .pipd/tools/pipd_tree_validate.py validate-tree   --root .   --manifest <project-manifest>   --report <conformance-report>
```
Exit classes are the canonical `0/2/3/4/5/6/7`. A required check must reach a terminal result on every relevant change; path filters or provider quirks cannot silently skip a required lifecycle check and still count as PASS.

TQAEP must name test inventory, fixtures, expected observations, oracles, FFI rule, negative/edge/adversarial cases, qualification environment, stochastic repeat rule if needed, effect reconciliation oracle, evidence schema/retention, checker/acceptor/human requirements, gate logic and failure route.

Donor denominators:
- TestClass 12/12: `POS`, `NEG`, `EDGE`, `SEC`, `PERF`, `PARITY`, `RECOVERY`, `UPGRADE`, `ROLLBACK`, `UNINSTALL`, `MUT`, `JOURNEY`.
- OracleType 8/8: `DETERMINISTIC`, `STATE_READBACK`, `PROPERTY`, `REFERENCE_OUTPUT`, `STATISTICAL`, `SEMANTIC_JUDGE`, `HUMAN`, `COMPOSITE`.
- target profiles 11/11: `PROFILE-SKILL`, `PROFILE-PLUGIN`, `PROFILE-CLI`, `PROFILE-LIBRARY`, `PROFILE-MCP`, `PROFILE-AGENT-HARNESS`, `PROFILE-WORKFLOW-ENGINE`, `PROFILE-CI-ACTION`, `PROFILE-PM-PROVIDER`, `PROFILE-CONTEXT-INDEX`, `PROFILE-SECURITY-TOOL`.
- ProviderSlots 13/13: `SLOT-NATIVE-DETERMINISTIC`, `SLOT-SKILL-STATIC-EVAL`, `SLOT-AGENT-LIVE-EVAL`, `SLOT-MCP-CONFORMANCE`, `SLOT-SPEC-GAP`, `SLOT-SPEC-VERIFY`, `SLOT-REPAIR-METHOD`, `SLOT-ENGINEERING-REVIEW`, `SLOT-SECURITY-SCAN`, `SLOT-OSS-POSTURE`, `SLOT-PROVENANCE`, `SLOT-CI-EXECUTION`, `SLOT-OBSERVATION`.

These donor taxonomies are mapped to DOC-07 but do not gain lifecycle authority.

# 31｜Worked Examples A–G

## A — True PASS
Subject `PI-PKG-X@v3` with exact hash is schema-valid, has all atomic REQ→SPEC→ACC→VER bindings, no blocking TT, applicable stable tests and profile tests execute in the bound environment, evidence is fresh and checker-separated, every required oracle returns PASS. ConformanceReport records `result=PASS`, `exit_code=0`, `first_failing_invariant=null`. **Effect:** this proves only the declared conformance scope; it does not infer execution admission, release or production.

## B — Apparent Pass
Schema validates; unit tests and CI are green; a decisive child requirement was omitted from trace. `RF-04` / semantic completeness oracle fails. Result `FAIL`, exit `3`, FFI = atomic requirement completeness. The green CI is retained as evidence but cannot override the failing semantic oracle.

## C — Wrong Subject Evidence
A valid PASS packet belongs to sibling `subject=A@hash1`; target is `B@hash2`. Identity resolution rejects it before outcome scoring. Result `FAIL/HOLD`, exit `4`, FFI = subject identity mismatch. Reusing the evidence by copying its payload is prohibited.

## D — ECP Without Admission
DEV ECP is current and complete, but there is no matching `ExecutionAdmission=ADMIT`. A write/mutation is attempted. `TEST-BND-001` / permission fixture denies mutation. Presence of ECP is readiness/control input, not execution authority.

## E — Provider 200 Without Readback
Provider API returns HTTP 200 and an operation id. No independent observation/readback is available. State remains `UNKNOWN_EFFECT`; `TEST-MUT-009` fails any promotion to `CONFIRMED_EFFECT`. Operator must observe/reconcile or compensate/rollback.

## F — Selected Technology Silently Downgraded
TechnologyAdmission selected an exact named technology with translation/adapter obligations. A later document replaces it with “use a suitable tool” and drops version/license/tests/rollback. `FX-TECH-001` and `TEST-E6580324` fail anti-downgrade conformance. Correct repair is to restore TechnologyLandingContract or open an explicit CR and re-admit—not to genericize.

## G — Brownfield False Decommission
New path passes bounded pilot and happy-path parity, then incumbent is marked decommissioned while old secrets/webhooks/jobs/routes remain. `FX-DECOM-001` / `TEST-3235004D` produces HOLD/ROLLBACK. Decommission closes only after residue/readback proof and rollback-window policy are satisfied.

# 32｜Acceptance / Coverage / Final Readback

## 32.1 R2 Definition of Done

R2 author-side materialization is eligible only when all repair-controller gates below pass in the final byte-level self-check.

| Gate | Name | PASS predicate | R2 destination | Status |
|---|---|---|---|---|
| R2-G01 | 86 Identity | 86/86 exact tuple equality; mismatch=0 | Appendix A + Appendix E | PASS_AUTHOR_SIDE_R2 |
| R2-G02 | Atomicity | compound destructive requirements complete child fixture set | #05/#10/#11 + machine catalog | PASS_AUTHOR_SIDE_R2 |
| R2-G03 | Coverage | source→atomic requirement→DOC destination ledger materialized | Appendix I | PASS_AUTHOR_SIDE_R2 |
| R2-G04 | A1 ABI | A1 validator/orchestrator is operational truth | #07 | PASS_AUTHOR_SIDE_R2 |
| R2-G05 | Profile ABI | A2 --profile compatibility explicitly implemented or locally removed | #07 | PASS_AUTHOR_SIDE_R2 |
| R2-G06 | Effect | provider success without reconciliation cannot PASS | #07/#16 + DT-10 children | PASS_AUTHOR_SIDE_R2 |
| R2-G07 | Applicability | A1 machine enum preserved | #12 + catalog | PASS_AUTHOR_SIDE_R2 |
| R2-G08 | Technology Denominator | CAND/NOBJ/ECP+ADD/MSC/TQ source IDs crosswalked | Appendix F | PASS_AUTHOR_SIDE_R2 |
| R2-G09 | Workflows | 8/8 workflow IDs preserved; SELF_ITERATION_LOOP materialized | #28 + Appendix F | PASS_AUTHOR_SIDE_R2 |
| R2-G10 | BUILD_MINIMAL | every BUILD_MINIMAL has no-fit proof + gap set; R2 reclassifies internal validator to SELECTED_REUSE | #25 | PASS_AUTHOR_SIDE_R2 |
| R2-G11 | Currentness | no stale dated currentness row; Trivy corrected | #14 | PASS_AUTHOR_SIDE_R2 |
| R2-G12 | Profiles | SYSTEM/SKILL_PLUGIN/AGENT_HARNESS full PI/PD denominators tested | #19/#20/#21 | PASS_AUTHOR_SIDE_R2 |
| R2-G13 | Specific Landing | no generic Oracle for gate-critical selected/eval technology | #25 | PASS_AUTHOR_SIDE_R2 |
| R2-G14 | Machine Catalog | extractable conformance catalog instance validates | Appendix G | PASS_AUTHOR_SIDE_R2 |
| R2-G15 | Metric | cross_agent_semantic_agreement materialized | #28 | PASS_AUTHOR_SIDE_R2 |
| R2-G16 | Self Audit | exact command/output/digest + seeded regression failures | Appendix E | PASS_AUTHOR_SIDE_R2 |
| R2-G17 | Claim | no Independent/Human/Runtime/Release/Production inflation | #00/#32 | PASS_AUTHOR_SIDE_R2 |

## 32.2 Open TT / CR

Open TTs are scoped currentness ambiguities only:

- `TT-DOC07-CUR-001` — python-jsonschema PyPI/main discrepancy.
- `TT-DOC07-CUR-002` — MCP Inspector release/main discrepancy.
- `TT-DOC07-CUR-003` — Harbor release/indexed-main discrepancy.

Closed in R2 design:

- `TT-DOC07-CUR-004-TRIVY-STALENESS` — R2 records Trivy `v0.75.0` as observed latest and selected qualification target.

`open_cr: []`.

## 32.3 Final claim boundary

A successful Appendix E self-check establishes only **author-side reproducible artifact conformance** for this Markdown and its embedded machine catalogs. It does not establish target-repository runtime verification, independent checker acceptance, human ratification, release, or production verification.

# Appendix A｜Canonical 86/86 Normative Requirement → TEST → ORACLE Binding — Deterministically Regenerated

Generation source: A1 canonical normative ledger. The table is a view; the exact machine tuple is also present in Appendix G `requirement_bindings`.

Canonical tuple serialization used by the self-checker:

```text
requirement_id<TAB>test_id<TAB>oracle_id<TAB>applicability_class<LF>
```

Expected SHA-256 over 86 rows in A1 order:

```text
585555096fa8c20f2912d438f09fa911e6f92a5c7d40dae6daabdd9a7d41e8bc
```

| Requirement ID | Canonical section | TEST | ORACLE | Applicability class | A1 severity/applicability | A1 coverage locator | A1 status |
|---|---|---|---|---|---|---|---|
| STD-REQ-979740C9 | 1. Normative Language / 規範語言 | TEST-979740C9 | OR-979740C9 | APPLICABLE_PROFILE | MAJOR / APPLICABLE_PROFILE | §4–§14/§22–§31 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-98F459F8 | 1. Normative Language / 規範語言 | TEST-98F459F8 | OR-98F459F8 | APPLICABLE_PROFILE | MAJOR / APPLICABLE_PROFILE | §4–§14/§22–§31 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-E2082905 | 1. Normative Language / 規範語言 | TEST-E2082905 | OR-E2082905 | APPLICABLE_PROFILE | MAJOR / APPLICABLE_PROFILE | §4–§14/§22–§31 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-B1C9AB85 | P-01 Single Canonical Truth | TEST-B1C9AB85 | OR-B1C9AB85 | APPLICABLE_PROFILE | MAJOR / APPLICABLE_PROFILE | §4–§14/§22–§31 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-B88A6D37 | P-02 Source-Bound Intent Preservation | TEST-B88A6D37 | OR-B88A6D37 | ALL | BLOCKER / ALL | §4–§14/§22–§31 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-689DE502 | P-03 Stable Semantics vs Late-Bound Facts | TEST-689DE502 | OR-689DE502 | APPLICABLE_PROFILE | MAJOR / APPLICABLE_PROFILE | §4–§14/§22–§31 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-ABD8745E | P-05 No Execution by Documentation | TEST-ABD8745E | OR-ABD8745E | ALL | BLOCKER / ALL | §4–§14/§22–§31 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-C6A9781D | P-06 Claim Separation | TEST-C6A9781D | OR-C6A9781D | APPLICABLE_PROFILE | MAJOR / APPLICABLE_PROFILE | §4–§14/§22–§31 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-79A6948B | P-07 Evidence Is Subject-Bound | TEST-79A6948B | OR-79A6948B | ALL | BLOCKER / ALL | §4–§14/§22–§31 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-4AAA061A | P-09 Complexity Must Earn Complexity | TEST-4AAA061A | OR-4AAA061A | ALL | BLOCKER / ALL | §4–§14/§22–§31 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-0E1DBA46 | P-10 Handoff Must Be Rejectable | TEST-0E1DBA46 | OR-0E1DBA46 | APPLICABLE_PROFILE | MAJOR / APPLICABLE_PROFILE | §4–§14/§22–§31 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-98BC2330 | P-11 Capability-Before-Brand / Search-Before-Build | TEST-98BC2330 | OR-98BC2330 | APPLICABLE_PROFILE | MAJOR / APPLICABLE_PROFILE | §9/§15 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-DA5BCA25 | P-13 Tool Success ≠ World Effect | TEST-DA5BCA25 | OR-DA5BCA25 | ALL | BLOCKER / ALL | §4–§14/§22–§31 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-2A89F996 | P-14 Segregation of Duties | TEST-2A89F996 | OR-2A89F996 | ALL | BLOCKER / ALL | §4–§14/§22–§31 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-C5BCA382 | P-15 Prose/Machine Gate Equivalence | TEST-C5BCA382 | OR-C5BCA382 | ALL | BLOCKER / ALL | §4–§14/§22–§31 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-B0C02A64 | 5.2 Promotion Rule | TEST-B0C02A64 | OR-B0C02A64 | APPLICABLE_PROFILE | MAJOR / APPLICABLE_PROFILE | §4–§14/§22–§31 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-E0C7F7A0 | 6. Artifact Identity & Authority Model | TEST-E0C7F7A0 | OR-E0C7F7A0 | APPLICABLE_PROFILE | MAJOR / APPLICABLE_PROFILE | §4–§14/§22–§31 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-81C86EBB | 6. Artifact Identity & Authority Model | TEST-81C86EBB | OR-81C86EBB | APPLICABLE_PROFILE | MAJOR / APPLICABLE_PROFILE | §4–§14/§22–§31 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-C25BC6A2 | 6. Artifact Identity & Authority Model | TEST-C25BC6A2 | OR-C25BC6A2 | APPLICABLE_PROFILE | MAJOR / APPLICABLE_PROFILE | §4–§14/§22–§31 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-E22A8F7D | 6. Artifact Identity & Authority Model | TEST-E22A8F7D | OR-E22A8F7D | APPLICABLE_PROFILE | MAJOR / APPLICABLE_PROFILE | §4–§14/§22–§31 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-FA7B1B7F | 6.1 Common Artifact Metadata Contract | TEST-FA7B1B7F | OR-FA7B1B7F | ALL | BLOCKER / ALL | §4–§14/§22–§31 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-11B19333 | 6.2 Authority and Adapter Non-Override Rule | TEST-11B19333 | OR-11B19333 | ALL | BLOCKER / ALL | §19 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-829B7605 | 7.1 Purpose | TEST-829B7605 | OR-829B7605 | APPLICABLE_PROFILE | MAJOR / APPLICABLE_PROFILE | §4–§14/§22–§31 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-7B3AB9E9 | C-01 Project / Product Identity | TEST-7B3AB9E9 | OR-7B3AB9E9 | APPLICABLE_PROFILE | MAJOR / APPLICABLE_PROFILE | §4–§14/§22–§31 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-454A6D90 | C-02 Authority Stack | TEST-454A6D90 | OR-454A6D90 | ALL | BLOCKER / ALL | §4–§14/§22–§31 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-5EFF0181 | C-02 Authority Stack | TEST-5EFF0181 | OR-5EFF0181 | APPLICABLE_PROFILE | MAJOR / APPLICABLE_PROFILE | §4–§14/§22–§31 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-6CCE644F | C-03 Canonical Ownership | TEST-6CCE644F | OR-6CCE644F | APPLICABLE_PROFILE | MAJOR / APPLICABLE_PROFILE | §4–§14/§22–§31 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-119B9088 | C-04 Lifecycle States | TEST-119B9088 | OR-119B9088 | APPLICABLE_PROFILE | MAJOR / APPLICABLE_PROFILE | §4–§14/§22–§31 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-EEC45EC3 | C-05 Claim Rules | TEST-EEC45EC3 | OR-EEC45EC3 | APPLICABLE_PROFILE | MAJOR / APPLICABLE_PROFILE | §4–§14/§22–§31 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-0CB9A2A0 | C-09 Tailoring Profile | TEST-0CB9A2A0 | OR-0CB9A2A0 | APPLICABLE_PROFILE | MAJOR / APPLICABLE_PROFILE | §4–§14/§22–§31 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-DD50D72A | C-10 Definition of Pre-Execution Complete | TEST-DD50D72A | OR-DD50D72A | APPLICABLE_PROFILE | MAJOR / APPLICABLE_PROFILE | §4–§14/§22–§31 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-59D1DD6F | C-11 Standard Namespace / Schema Compatibility | TEST-59D1DD6F | OR-59D1DD6F | APPLICABLE_PROFILE | MAJOR / APPLICABLE_PROFILE | §4–§14/§22–§31 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-9E161B60 | C-11 Standard Namespace / Schema Compatibility | TEST-9E161B60 | OR-9E161B60 | APPLICABLE_PROFILE | MAJOR / APPLICABLE_PROFILE | §4–§14/§22–§31 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-10C6C743 | C-12 DomainProfileExtension | TEST-10C6C743 | OR-10C6C743 | APPLICABLE_PROFILE | MAJOR / APPLICABLE_PROFILE | §4–§14/§22–§31 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-90364E5B | C-12 DomainProfileExtension | TEST-90364E5B | OR-90364E5B | APPLICABLE_PROFILE | MAJOR / APPLICABLE_PROFILE | §4–§14/§22–§31 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-D28A8B60 | C-14 Security Threat Model | TEST-D28A8B60 | OR-D28A8B60 | ALL | BLOCKER / ALL | §4–§14/§22–§31 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-ABE182D6 | 8. PI-PKG Canonical Purpose | TEST-ABE182D6 | OR-ABE182D6 | APPLICABLE_PROFILE | MAJOR / APPLICABLE_PROFILE | §4–§14/§22–§31 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-9E4AFAC1 | 8. PI-PKG Canonical Purpose | TEST-9E4AFAC1 | OR-9E4AFAC1 | APPLICABLE_PROFILE | MAJOR / APPLICABLE_PROFILE | §4–§14/§22–§31 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-5868D53A | 9. PI-PKG Required Contract Areas | TEST-5868D53A | OR-5868D53A | APPLICABLE_PROFILE | MAJOR / APPLICABLE_PROFILE | §4–§14/§22–§31 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-27A2EA7F | PI-05 Atomic Requirements | TEST-27A2EA7F | OR-27A2EA7F | APPLICABLE_PROFILE | MAJOR / APPLICABLE_PROFILE | §4–§14/§22–§31 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-522701F0 | PI-08.1 Mandatory Search-Before-Build algorithm | TEST-522701F0 | OR-522701F0 | APPLICABLE_PROFILE | MAJOR / APPLICABLE_PROFILE | §9/§15 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-E6CD4BED | PI-08.2 TechnologyAdmissionRecord | TEST-E6CD4BED | OR-E6CD4BED | APPLICABLE_PROFILE | MAJOR / APPLICABLE_PROFILE | §9/§15 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-06583027 | PI-10 SPEC | TEST-06583027 | OR-06583027 | APPLICABLE_PROFILE | MAJOR / APPLICABLE_PROFILE | §4–§14/§22–§31 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-C49B66DE | PI-11 Acceptance | TEST-C49B66DE | OR-C49B66DE | APPLICABLE_PROFILE | MAJOR / APPLICABLE_PROFILE | §4–§14/§22–§31 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-B4D1C8EA | PI-12 Verification / Oracle | TEST-B4D1C8EA | OR-B4D1C8EA | APPLICABLE_PROFILE | MAJOR / APPLICABLE_PROFILE | §4–§14/§22–§31 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-5E28F98D | PI-13 Evidence Expectation | TEST-5E28F98D | OR-5E28F98D | APPLICABLE_PROFILE | MAJOR / APPLICABLE_PROFILE | §4–§14/§22–§31 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-5AADF6A3 | PI-14 Deliverables | TEST-5AADF6A3 | OR-5AADF6A3 | APPLICABLE_PROFILE | MAJOR / APPLICABLE_PROFILE | §4–§14/§22–§31 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-6E714CAB | PI-17 Claim Ceiling / State Truth | TEST-6E714CAB | OR-6E714CAB | APPLICABLE_PROFILE | MAJOR / APPLICABLE_PROFILE | §4–§14/§22–§31 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-C887276E | PI-18 Pre-Dev Handoff | TEST-C887276E | OR-C887276E | APPLICABLE_PROFILE | MAJOR / APPLICABLE_PROFILE | §4–§14/§22–§31 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-8A8EDC94 | 10. Requirement Narrow Waist | TEST-8A8EDC94 | OR-8A8EDC94 | APPLICABLE_PROFILE | MAJOR / APPLICABLE_PROFILE | §4–§14/§22–§31 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-F8221F9F | 12. PI_READY Gate | TEST-F8221F9F | OR-F8221F9F | ALL | BLOCKER / ALL | §4–§14/§22–§31 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-92132DB3 | 13. PD-PKG Canonical Purpose | TEST-92132DB3 | OR-92132DB3 | APPLICABLE_PROFILE | MAJOR / APPLICABLE_PROFILE | §4–§14/§22–§31 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-DDF22230 | 14. PD-PKG Required Structure | TEST-DDF22230 | OR-DDF22230 | APPLICABLE_PROFILE | MAJOR / APPLICABLE_PROFILE | §4–§14/§22–§31 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-F4F1DD9D | PD-04 Late-Bound Resolution | TEST-F4F1DD9D | OR-F4F1DD9D | APPLICABLE_PROFILE | MAJOR / APPLICABLE_PROFILE | §4–§14/§22–§31 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-BA1FB472 | PD-05 S2E — Spec-to-Execution | TEST-BA1FB472 | OR-BA1FB472 | ALL | BLOCKER / ALL | §4–§14/§22–§31 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-7468B275 | PD-05 S2E — Spec-to-Execution | TEST-7468B275 | OR-7468B275 | ALL | BLOCKER / ALL | §4–§14/§22–§31 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-7CEA782A | PD-05A TaskSpecSeed | TEST-7CEA782A | OR-7CEA782A | ALL | BLOCKER / ALL | §4–§14/§22–§31 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-93766574 | PD-05B WorkOrder Materialization | TEST-93766574 | OR-93766574 | ALL | BLOCKER / ALL | §4–§14/§22–§31 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-1859D4F5 | PD-06 DEV ECP — Development Execution Control | TEST-1859D4F5 | OR-1859D4F5 | ALL | BLOCKER / ALL | §4–§14/§22–§31 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-2FF7F879 | PD-06 DEV ECP — Development Execution Control | TEST-2FF7F879 | OR-2FF7F879 | ALL | BLOCKER / ALL | §4–§14/§22–§31 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-9DF08F85 | PD-07 OPS ECP — Operations Readiness & Execution Control | TEST-9DF08F85 | OR-9DF08F85 | ALL | BLOCKER / ALL | §4–§14/§22–§31 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-61E2C648 | PD-08 TQAEP — Test / Qualification / Acceptance / Evidence Plan | TEST-61E2C648 | OR-61E2C648 | APPLICABLE_PROFILE | MAJOR / APPLICABLE_PROFILE | §4–§14/§22–§31 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-6E492151 | PD-08 TQAEP — Test / Qualification / Acceptance / Evidence Plan | TEST-6E492151 | OR-6E492151 | ALL | BLOCKER / ALL | §4–§14/§22–§31 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-75B304BB | PD-10 Execution Admission | TEST-75B304BB | OR-75B304BB | APPLICABLE_PROFILE | MAJOR / APPLICABLE_PROFILE | §4–§14/§22–§31 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-FA8009D5 | 17. EXECUTION_ADMITTED Gate | TEST-FA8009D5 | OR-FA8009D5 | ALL | BLOCKER / ALL | §4–§14/§22–§31 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-38EB8516 | 18.1 Extraction Manifest | TEST-38EB8516 | OR-38EB8516 | APPLICABLE_PROFILE | MAJOR / APPLICABLE_PROFILE | §6/§13/§24/§25 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-59414E50 | 18.3 Deterministic Conformance Reference Command | TEST-59414E50 | OR-59414E50 | APPLICABLE_PROFILE | MAJOR / APPLICABLE_PROFILE | §6/§13/§24/§25 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-F4669FFF | 18.4 Destructive Fixtures Required by the Standard | TEST-F4669FFF | OR-F4669FFF | APPLICABLE_PROFILE | MAJOR / APPLICABLE_PROFILE | §6/§13/§24/§25 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-28163C14 | 20.4 Machine Profile Binding | TEST-28163C14 | OR-28163C14 | ALL | BLOCKER / ALL | §4–§14/§22–§31 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-3235004D | 21.2 BrownfieldMigrationProfile | TEST-3235004D | OR-3235004D | APPLICABLE_PROFILE | MAJOR / APPLICABLE_PROFILE | §16/§23 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-3CA02A9C | 22. Target Profile — SKILL / PLUGIN | TEST-3CA02A9C | OR-3CA02A9C | APPLICABLE_PROFILE | MAJOR / APPLICABLE_PROFILE | §17 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-BF0442B3 | 22. Target Profile — SKILL / PLUGIN | TEST-BF0442B3 | OR-BF0442B3 | APPLICABLE_PROFILE | MAJOR / APPLICABLE_PROFILE | §17 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-B5C7D219 | 22.1 Skill/Plugin Conformance Additions | TEST-B5C7D219 | OR-B5C7D219 | ALL | BLOCKER / ALL | §17 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-0B4D6B1E | 23. Target Profile — Agent Harness / Agentic Runtime | TEST-0B4D6B1E | OR-0B4D6B1E | APPLICABLE_PROFILE | MAJOR / APPLICABLE_PROFILE | §18/§22 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-0C5B13B3 | 23. Target Profile — Agent Harness / Agentic Runtime | TEST-0C5B13B3 | OR-0C5B13B3 | APPLICABLE_PROFILE | MAJOR / APPLICABLE_PROFILE | §18/§22 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-2E59E411 | 23A. World Effect / Observation / Readback / Reconciliation | TEST-2E59E411 | OR-2E59E411 | ALL | BLOCKER / ALL | §18/§22 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-D4FB7180 | 24. Receiver Handoff Contract | TEST-D4FB7180 | OR-D4FB7180 | APPLICABLE_PROFILE | MAJOR / APPLICABLE_PROFILE | §4–§14/§22–§31 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-22E53BD2 | 25. Evidence Return Contract | TEST-22E53BD2 | OR-22E53BD2 | APPLICABLE_PROFILE | MAJOR / APPLICABLE_PROFILE | §4–§14/§22–§31 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-7894BFB5 | 26.2 External Content Is Data | TEST-7894BFB5 | OR-7894BFB5 | APPLICABLE_PROFILE | MAJOR / APPLICABLE_PROFILE | §4–§14/§22–§31 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-86CAC54E | 26.4 Agent Memory | TEST-86CAC54E | OR-86CAC54E | APPLICABLE_PROFILE | MAJOR / APPLICABLE_PROFILE | §4–§14/§22–§31 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-7CD1E5E6 | 26.7 SoD Enforcement | TEST-7CD1E5E6 | OR-7CD1E5E6 | APPLICABLE_PROFILE | MAJOR / APPLICABLE_PROFILE | §4–§14/§22–§31 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-37150A4D | 28. Canonical Standard vs Adapter | TEST-37150A4D | OR-37150A4D | APPLICABLE_PROFILE | MAJOR / APPLICABLE_PROFILE | §19 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-97BCACAC | 32. Mandatory Conformance Test Registry | TEST-97BCACAC | OR-97BCACAC | ALL | BLOCKER / ALL | §6/§13/§24/§25 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-E6580324 | 46A. Informative Technology & Workflow Registry — Named Anti-Downgrade Baseline | TEST-E6580324 | OR-E6580324 | ALL | BLOCKER / ALL | §9/§15 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-6F8DCD42 | 47. External Alignment / Informative Research Notes | TEST-6F8DCD42 | OR-6F8DCD42 | APPLICABLE_PROFILE | MAJOR / APPLICABLE_PROFILE | §3/§20 | BLUEPRINT_BODY_COVERED / runtime unexecuted |
| STD-REQ-44B56684 | 50. Final Normative Statement | TEST-44B56684 | OR-44B56684 | APPLICABLE_PROFILE | MAJOR / APPLICABLE_PROFILE | §4–§14/§22–§31 | BLUEPRINT_BODY_COVERED / runtime unexecuted |

# Appendix B｜Supplemental T-PIPD-001..037 Alias Crosswalk

Aliases are retained for destructive-suite compatibility; they are never canonical primary keys.

| Alias | Class | Fixture / mutation | Expected | Gate | Canonical test | Oracle |

|---|---|---|---|---|---|---|

| T-PIPD-001 | Schema | empty `PI_READY` | FAIL | PI | TEST-MUT-001 | OR-MUT-001 |

| T-PIPD-002 | Schema | CURRENT requirement missing VER | FAIL | PI | TEST-MUT-002 | OR-MUT-002 |

| T-PIPD-003 | Schema | CURRENT requirement missing EVD_EXPECTATION | FAIL | PI | TEST-MUT-002 | OR-MUT-002 |

| T-PIPD-004 | Schema | `BUILD_MINIMAL` without no-fit reason | FAIL | PI | TEST-MUT-007 | OR-MUT-007 |

| T-PIPD-005 | Authority | tool/provider marked semantic authority | FAIL | PI | TEST-E6580324 | OR-E6580324 |

| T-PIPD-006 | Source | missing normative source locator | TEMP_CLOSED | PI | TEST-RET-001 | OR-RET-001 |

| T-PIPD-007 | PD | hollow RepoContext | FAIL | PD | TEST-MUT-003 | OR-MUT-003 |

| T-PIPD-008 | PD | unresolved required late-bound field | HOLD | PD | TEST-F4F1DD9D | OR-F4F1DD9D |

| T-PIPD-009 | Identity | Seed ID == WorkOrder ID | FAIL | PD | TEST-MUT-006 | OR-MUT-006 |

| T-PIPD-010 | Identity | WorkOrder == ECP identity | FAIL | PD | TEST-MUT-006 | OR-MUT-006 |

| T-PIPD-011 | S2E | execution_authority=true | FAIL | PD | TEST-BND-002 | OR-BND-002 |

| T-PIPD-012 | ECP | self_approval=true | FAIL | Admission | TEST-BND-003 | OR-BND-003 |

| T-PIPD-013 | Handoff | empty allowed scope | FAIL | PD | TEST-MUT-004 | OR-MUT-004 |

| T-PIPD-014 | Handoff | wrong subject hash | NACK | PD | TEST-0E1DBA46 | OR-0E1DBA46 |

| T-PIPD-015 | Approval | high-risk ADMIT without token | DENY | Admission | TEST-MUT-008 | OR-MUT-008 |

| T-PIPD-016 | Approval | expired token | DENY | Admission | TEST-75B304BB | OR-75B304BB |

| T-PIPD-017 | Approval | replayed nonce | DENY | Admission | TEST-75B304BB | OR-75B304BB |

| T-PIPD-018 | Evidence | PASS with invalid SHA | FAIL | Verify | TEST-MUT-005 | OR-MUT-005 |

| T-PIPD-019 | Evidence | PASS without checker | FAIL | Verify | TEST-MUT-005 | OR-MUT-005 |

| T-PIPD-020 | Evidence | PASS but oracle=FAIL | FAIL | Verify | TEST-MUT-005 | OR-MUT-005 |

| T-PIPD-021 | Effect | provider success without readback | UNKNOWN_EFFECT | Effect | TEST-MUT-009 | OR-MUT-009 |

| T-PIPD-022 | Effect | conflicting readbacks | CONFLICTING_EFFECT | Effect | TEST-2E59E411 | OR-2E59E411 |

| T-PIPD-023 | Drift | standard hash changed | FAIL | Bootstrap | TEST-B1C9AB85 | OR-B1C9AB85 |

| T-PIPD-024 | Drift | PI hash changed after PD bind | PD stale | PD | TEST-RET-002 | OR-RET-002 |

| T-PIPD-025 | Currentness | protocol/tool TTL expired | HOLD | PD | TEST-6F8DCD42 | OR-6F8DCD42 |

| T-PIPD-026 | Adapter | nested AGENTS conflicts with core lifecycle | HOLD | Adapter | TEST-37150A4D | OR-37150A4D |

| T-PIPD-027 | Skill Trigger | relevant task does not invoke Skill | FAIL | Conformance | TEST-TRG-001 | OR-TRG-001 |

| T-PIPD-028 | Skill Boundary | Skill attempts forbidden tool | FAIL | Conformance | TEST-BND-003 | OR-BND-003 |

| T-PIPD-029 | Retrieval | broad/hallucinated anchor | FAIL_CLOSED | Grounding | TEST-RET-001 | OR-RET-001 |

| T-PIPD-030 | Portability | same fixture on second harness changes boundary result | FINDING / no silent pass | Conformance | TEST-PRT-001 | OR-PRT-001 |

| T-PIPD-031 | Brownfield | pilot parity fails | HOLD/ROLLBACK | Migration | TEST-3235004D | OR-3235004D |

| T-PIPD-032 | Release | release artifact lacks digest | FAIL | Release | TEST-79A6948B | OR-79A6948B |

| T-PIPD-033 | Release | ASSURED artifact lacks provenance | FAIL | Release | TEST-6F8DCD42 | OR-6F8DCD42 |

| T-PIPD-034 | CI | third-party action uses floating tag | FAIL policy | CI | TEST-6F8DCD42 | OR-6F8DCD42 |

| T-PIPD-035 | CI | workflow top-level write-all | FAIL policy | CI | TEST-D28A8B60 | OR-D28A8B60 |

| T-PIPD-036 | Slice | unrelated slice changes cause global invalidation | FAIL architecture | Change | TEST-90364E5B | OR-90364E5B |

| T-PIPD-037 | Slice | dependent slice remains current after source change | FAIL architecture | Change | TEST-RET-002 | OR-RET-002 |

# Appendix C｜Typed Fixture / Failure-Code Decision Matrix

| Condition | Conformance result | Admission decision | Effect state | Recovery | Exit | Deterministic FFI family |
|---|---|---|---|---|---:|---|
| schema violation | FAIL | null | null | NONE | 2 | SCHEMA_* |
| semantic invariant | FAIL | null | null | NONE | 3 | semantic invariant ID |
| stale/expired/wrong subject | HOLD or FAIL | null | null | REOBSERVE | 4 | CURRENTNESS/SUBJECT_* |
| permission missing/invalid | FAIL | DENY | null | NONE | 5 | PERMISSION_* |
| receiver handoff incomplete | FAIL | NACK | null | NONE | 3 | HANDOFF_* |
| provider success, no readback | FAIL | null | UNKNOWN_EFFECT | REOBSERVE | 3 | EFFECT_RECONCILIATION_* |
| conflicting readback | FAIL or HOLD | null | CONFLICTING_EFFECT | RECONCILE | 3 | EFFECT_RECONCILIATION_* |
| failed effect requiring compensation | FAIL | null | FAILED_EFFECT | COMPENSATE or ROLLBACK | 3 | EFFECT_* |
| resolution/extraction failure | HOLD | null | null | NONE | 6 | RESOLUTION_* |
| validator internal failure | HOLD | null | null | NONE | 7 | INTERNAL_* |
| all applicable predicates pass | PASS | null | null or CONFIRMED_EFFECT as separately proven | NONE | 0 | null |

Typed namespaces must never be collapsed into a single `expected_result` enum.

# Appendix D｜Support-Only External Currentness Sources

Checked 2026-10-07. These sources are SUPPORT only and do not overwrite A1/A2/A3 semantics.

- JSON Schema Draft 2020-12: https://json-schema.org/draft/2020-12/
- python-jsonschema: https://pypi.org/project/jsonschema/ and https://github.com/python-jsonschema/jsonschema/blob/main/CHANGELOG.rst
- pytest: https://docs.pytest.org/en/latest/changelog.html
- MCP Inspector: https://github.com/modelcontextprotocol/inspector/releases and https://github.com/modelcontextprotocol/inspector/blob/main/package.json
- Trivy releases: https://github.com/aquasecurity/trivy/releases — `v0.75.0` released 2026-10-01
- Semgrep releases: https://github.com/semgrep/semgrep/releases
- Gitleaks releases: https://github.com/gitleaks/gitleaks/releases
- OpenSSF Scorecard releases: https://github.com/ossf/scorecard/releases
- NVIDIA SkillEvaluator changelog: https://github.com/NVIDIA/SkillEvaluator/blob/main/CHANGELOG.md — `0.4.0` dated 2026-09-30
- Harbor releases: https://github.com/harbor-framework/harbor/releases — `v0.24.0` released 2026-10-05
- GitHub Actions documentation: https://docs.github.com/actions

Project materialization must re-check exact release/tag/commit, integrity, license, security/advisory state, compatibility and provider exit at the applicable TTL.

# Appendix F｜TechnologyCoverageCrosswalk / Workflow Identity Preservation — 144 + 8 Denominator

## F.1 Technology / Tool / OSS / Method donor crosswalk — 144/144

Every A3 source identity receives terminal treatment. `REFERENCE_OWNER` and `ROUTE_OUT` are explicit outcomes, not omissions.

| Source ID | Registry | Source name | Source disposition | DOC-07 relevance | Local TECH ID | Treatment | Canonical owner | Terminal disposition | Exact TEST refs | Exact ORACLE refs | Currentness ref | Exit/replacement | Anti-drop |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| CAND-01 | CAND | GPT-5.6 Sol | ADOPT | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission / project-specific binding | ADOPT | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| CAND-02 | CAND | OpenAI Codex / Agents SDK harness patterns | ADOPT_WITH_WRAPPER | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission / project-specific binding | ADOPT_WITH_WRAPPER | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| CAND-03 | CAND | AGENTS.md | ADOPT_WITH_TRANSLATION | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission / project-specific binding | ADOPT_WITH_TRANSLATION | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| CAND-04 | CAND | OpenSpec | SELECTED_TRANSLATE | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission / project-specific binding | SELECTED_TRANSLATE | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| CAND-05 | CAND | GitHub Spec Kit | SELECTED_WRAP | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission / project-specific binding | SELECTED_WRAP | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| CAND-06 | CAND | Model Context Protocol (MCP) | SELECTED_TRANSLATE | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission / project-specific binding | SELECTED_TRANSLATE | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| CAND-07 | CAND | A2A Protocol | SELECTED_TRANSLATE | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission / project-specific binding | SELECTED_TRANSLATE | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| CAND-08 | CAND | OpenTelemetry GenAI semantic conventions | SELECTED_TRANSLATE | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission / project-specific binding | SELECTED_TRANSLATE | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| CAND-09 | CAND | Pi Coding Agent / pi-mono | EVAL_ONLY | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission / project-specific binding | EVAL_ONLY | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| CAND-10 | CAND | Superpowers | SELECTED_TRANSLATE | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission / project-specific binding | SELECTED_TRANSLATE | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| CAND-11 | CAND | gstack | REFERENCE | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission / project-specific binding | REFERENCE | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| CAND-12 | CAND | DeepSeek Harness | EVAL_ONLY | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission / project-specific binding | EVAL_ONLY | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| CAND-13 | CAND | Open GSD / gsd-core | REFERENCE | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission / project-specific binding | REFERENCE | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| CAND-14 | CAND | legacy gsd-build / get-shit-done | REJECT | REFERENCE | — | NOT_APPLICABLE_WITH_RATIONALE | DOC-02 TechnologyAdmission / project-specific binding | REJECT | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | remain provenance-only; promotion requires CR + TechnologyAdmission | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| CAND-15 | CAND | mattpocock/skills | SELECTED_TRANSLATE | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission / project-specific binding | SELECTED_TRANSLATE | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| CAND-16 | CAND | Hugging Face Agent Skills | SELECTED_TRANSLATE | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission / project-specific binding | SELECTED_TRANSLATE | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| CAND-17 | CAND | AG-UI | SELECTED_TRANSLATE | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission / project-specific binding | SELECTED_TRANSLATE | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| CAND-18 | CAND | NousResearch Hermes Agent | QUARANTINE | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission / project-specific binding | QUARANTINE | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| CAND-19 | CAND | Cordis | REFERENCE | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission / project-specific binding | REFERENCE | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| CAND-20 | CAND | LongHorizon-Harness research | REFERENCE | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission / project-specific binding | REFERENCE | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| CAND-21 | CAND | Skill-Use benchmark | REFERENCE | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission / project-specific binding | REFERENCE | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| CAND-22 | CAND | HarnessRisk benchmark | REFERENCE | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission / project-specific binding | REFERENCE | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| NOBJ-001 | NOBJ | HLPE Native PLAN/BOOTSTRAP/FACTORY | LOCAL_TRANSLATION_ASSET_MATERIALIZED_NOT_HOST_BOUND | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission / project-specific binding | LOCAL_TRANSLATION_ASSET_MATERIALIZED_NOT_HOST_BOUND | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| NOBJ-002 | NOBJ | Matt grill-with-docs | METHOD_TRANSLATED_LOCAL_EXTERNAL_ADOPTION_NOT_CLAIMED | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | METHOD_TRANSLATED_LOCAL_EXTERNAL_ADOPTION_NOT_CLAIMED | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| NOBJ-003 | NOBJ | OpenSpec | SUPPORT_ONLY_NOT_INSTALLED | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | SUPPORT_ONLY_NOT_INSTALLED | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| NOBJ-004 | NOBJ | Spec Kit | SUPPORT_ONLY_NOT_INSTALLED | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | SUPPORT_ONLY_NOT_INSTALLED | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| NOBJ-005 | NOBJ | Superpowers test-driven-development | SUPPORT_ONLY_NOT_INSTALLED | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | SUPPORT_ONLY_NOT_INSTALLED | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| NOBJ-006 | NOBJ | Superpowers systematic-debugging | SUPPORT_ONLY_NOT_INSTALLED | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | SUPPORT_ONLY_NOT_INSTALLED | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| NOBJ-007 | NOBJ | Superpowers verification-before-completion | SUPPORT_ONLY_NOT_INSTALLED | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | SUPPORT_ONLY_NOT_INSTALLED | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| NOBJ-008 | NOBJ | GStack | QUARANTINE_IDENTITY_UNTIL_PIN | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | QUARANTINE_IDENTITY_UNTIL_PIN | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| NOBJ-009 | NOBJ | GSD / planning-with-files | QUARANTINE_IDENTITY_CONFLICT | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | QUARANTINE_IDENTITY_CONFLICT | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| NOBJ-010 | NOBJ | AGENTS.md | PORTABLE_LOCAL_PROFILE | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission / project-specific binding | PORTABLE_LOCAL_PROFILE | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| NOBJ-011 | NOBJ | SKILL.md | LOCAL_TRANSLATION_ASSET_MATERIALIZED_NOT_HOST_BOUND | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | LOCAL_TRANSLATION_ASSET_MATERIALIZED_NOT_HOST_BOUND | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| NOBJ-012 | NOBJ | DESIGN.md | LOCAL_TRANSLATION_ASSET_MATERIALIZED_NOT_HOST_BOUND | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission / project-specific binding | LOCAL_TRANSLATION_ASSET_MATERIALIZED_NOT_HOST_BOUND | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| NOBJ-013 | NOBJ | Prompt projection | LOCAL_TRANSLATION_ASSET_MATERIALIZED_NOT_HOST_BOUND | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission / project-specific binding | LOCAL_TRANSLATION_ASSET_MATERIALIZED_NOT_HOST_BOUND | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| NOBJ-014 | NOBJ | OpenAI skill-creator | QUARANTINE_WEB_EVIDENCE_NOT_INSTALLED | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | QUARANTINE_WEB_EVIDENCE_NOT_INSTALLED | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| NOBJ-015 | NOBJ | OpenAI plugin-creator | QUARANTINE_WEB_EVIDENCE_NOT_INSTALLED | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission / project-specific binding | QUARANTINE_WEB_EVIDENCE_NOT_INSTALLED | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| NOBJ-016 | NOBJ | Agent Skills specification | SUPPORT_ONLY_BLOCKED_EXTERNAL | ROUTE_OUT | — | ROUTE_OUT | DOC-09 CI Adapter | SUPPORT_ONLY_BLOCKED_EXTERNAL | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | DOC-09 owner controls materialization/exit; DOC-07 only consumes evidence ABI | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| NOBJ-017 | NOBJ | Agent Plugins 1.0 Working Draft | SUPPORT_ONLY_BLOCKED_EXTERNAL | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission / project-specific binding | SUPPORT_ONLY_BLOCKED_EXTERNAL | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| NOBJ-018 | NOBJ | JSON Schema 2020-12 | LOCAL_TRANSLATION_ASSET_MATERIALIZED_NOT_HOST_BOUND | REFERENCE | TECH-JSONSCHEMA-SPEC | REFERENCE_OWNER | DOC-02 TechnologyAdmission / project-specific binding | LOCAL_TRANSLATION_ASSET_MATERIALIZED_NOT_HOST_BOUND | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | CUR-TECH-JSONSCHEMA-SPEC | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| NOBJ-019 | NOBJ | pytest | QUARANTINE_WEB_EVIDENCE_NOT_INSTALLED | REFERENCE | TECH-PYTEST | REFERENCE_OWNER | DOC-02 TechnologyAdmission / project-specific binding | QUARANTINE_WEB_EVIDENCE_NOT_INSTALLED | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | CUR-TECH-PYTEST | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| NOBJ-020 | NOBJ | GitHub Actions | QUARANTINE_WEB_EVIDENCE_NOT_INSTALLED | REFERENCE | TECH-GHA | REFERENCE_OWNER | DOC-09 CI Adapter | QUARANTINE_WEB_EVIDENCE_NOT_INSTALLED | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | CUR-TECH-GHA | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| NOBJ-021 | NOBJ | CycloneDX | QUARANTINE_WEB_EVIDENCE_NOT_INSTALLED | REFERENCE | — | REFERENCE_OWNER | DOC-09 Release/Supply-Chain | QUARANTINE_WEB_EVIDENCE_NOT_INSTALLED | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| NOBJ-022 | NOBJ | Gitleaks | QUARANTINE_WEB_EVIDENCE_NOT_INSTALLED | DIRECT | TECH-GITLEAKS | REFERENCE_OWNER | DOC-07 TQAEP/Security | QUARANTINE_WEB_EVIDENCE_NOT_INSTALLED | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | CUR-TECH-GITLEAKS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| NOBJ-023 | NOBJ | markdownlint | QUARANTINE_WEB_EVIDENCE_NOT_INSTALLED | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission / project-specific binding | QUARANTINE_WEB_EVIDENCE_NOT_INSTALLED | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| NOBJ-024 | NOBJ | Ruff + type checker | QUARANTINE_WEB_EVIDENCE_NOT_INSTALLED | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission / project-specific binding | QUARANTINE_WEB_EVIDENCE_NOT_INSTALLED | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| ECP-01 | ECP | Spec Kit | ADOPT+QUALIFY | ROUTE_OUT | — | ROUTE_OUT | DOC-09 CI Adapter | ADOPT+QUALIFY | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | DOC-09 owner controls materialization/exit; DOC-07 only consumes evidence ABI | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| ECP-02 | ECP | OpenSpec | ADOPT+QUALIFY | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | ADOPT+QUALIFY | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| ECP-03 | ECP | Matt Skills / mattpocock-skills | QUALIFY | ROUTE_OUT | — | ROUTE_OUT | DOC-09 CI Adapter | QUALIFY | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | DOC-09 owner controls materialization/exit; DOC-07 only consumes evidence ABI | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| ECP-04 | ECP | Superpowers | QUALIFY | ROUTE_OUT | — | ROUTE_OUT | DOC-09 CI Adapter | QUALIFY | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | DOC-09 owner controls materialization/exit; DOC-07 only consumes evidence ABI | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| ECP-05 | ECP | gstack | QUALIFY | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | QUALIFY | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| ECP-06 | ECP | GSD | QUALIFY | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | QUALIFY | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| ECP-07 | ECP | OROCHI / SRU | ROUTE_OUT+ADOPT_BOUNDED_DONOR | REFERENCE | — | REFERENCE_OWNER | DOC-03 Provider/Harness Binding + ECP/TQAEP | ROUTE_OUT+ADOPT_BOUNDED_DONOR | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| ECP-08 | ECP | Codex App Server | QUALIFY_PRIMARY | REFERENCE | — | REFERENCE_OWNER | DOC-03 Provider/Harness Binding + ECP/TQAEP | QUALIFY_PRIMARY | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| ECP-09 | ECP | codex app-server-client | CONDITIONAL | REFERENCE | — | REFERENCE_OWNER | DOC-03 Provider/Harness Binding + ECP/TQAEP | CONDITIONAL | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| ECP-10 | ECP | Hermes | ADOPT+QUALIFY | REFERENCE | — | REFERENCE_OWNER | DOC-03 Provider/Harness Binding + ECP/TQAEP | ADOPT+QUALIFY | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| ECP-11 | ECP | OpenCode | QUALIFY | REFERENCE | — | REFERENCE_OWNER | DOC-03 Provider/Harness Binding + ECP/TQAEP | QUALIFY | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| ECP-12 | ECP | Pi | QUALIFY | REFERENCE | — | REFERENCE_OWNER | DOC-03 Provider/Harness Binding + ECP/TQAEP | QUALIFY | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| ECP-13 | ECP | DeepSeek Harness | SHADOW | REFERENCE | — | REFERENCE_OWNER | DOC-03 Provider/Harness Binding + ECP/TQAEP | SHADOW | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| ECP-14 | ECP | UHP | PILOT_COMPATIBILITY_ONLY | DIRECT | — | EXPAND_IN_DOC07 | DOC-03 Interop Binding + DOC-07 Conformance | PILOT_COMPATIBILITY_ONLY | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | full DOC-07 landing/eval contract required; provider/tool cannot inherit gate authority | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| ECP-15 | ECP | A2A | ADOPT_BOUNDARY | DIRECT | — | EXPAND_IN_DOC07 | DOC-03 Interop Binding + DOC-07 Conformance | ADOPT_BOUNDARY | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | full DOC-07 landing/eval contract required; provider/tool cannot inherit gate authority | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| ECP-16 | ECP | Temporal | PILOT_PRIMARY | REFERENCE | — | REFERENCE_OWNER | DOC-03 Provider/Harness Binding + ECP/TQAEP | PILOT_PRIMARY | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| ECP-17 | ECP | OpenAI Agents SDK | ADOPT_PATTERN+QUALIFY | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission / project-specific binding | ADOPT_PATTERN+QUALIFY | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| ECP-18 | ECP | Dapr | QUALIFY_ALTERNATE | REFERENCE | — | REFERENCE_OWNER | DOC-03 Provider/Harness Binding + ECP/TQAEP | QUALIFY_ALTERNATE | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| ECP-19 | ECP | Restate | QUALIFY_ALTERNATE | REFERENCE | — | REFERENCE_OWNER | DOC-03 Provider/Harness Binding + ECP/TQAEP | QUALIFY_ALTERNATE | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| ECP-20 | ECP | LongHorizon-Harness | ADOPT_PATTERN | REFERENCE | — | REFERENCE_OWNER | DOC-03 Provider/Harness Binding + ECP/TQAEP | ADOPT_PATTERN | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| ECP-21 | ECP | HELIX | ADOPT_PATTERN | REFERENCE | — | REFERENCE_OWNER | DOC-03 Provider/Harness Binding + ECP/TQAEP | ADOPT_PATTERN | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| ECP-22 | ECP | HarnessRisk | ADOPT_PATTERN | REFERENCE | — | REFERENCE_OWNER | DOC-03 Provider/Harness Binding + ECP/TQAEP | ADOPT_PATTERN | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| ECP-23 | ECP | MCP Inspector v2 | QUALIFY | DIRECT | — | EXPAND_IN_DOC07 | DOC-03 Interop Binding + DOC-07 Conformance | QUALIFY | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | full DOC-07 landing/eval contract required; provider/tool cannot inherit gate authority | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| ECP-24 | ECP | Trivy | QUALIFY | ROUTE_OUT | — | ROUTE_OUT | DOC-09 Release/Supply-Chain | QUALIFY | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333,TEST-D28A8B60 | OR-98BC2330,OR-E6CD4BED,OR-11B19333,OR-D28A8B60 | OWNER_CURRENTNESS | DOC-09 owner controls materialization/exit; DOC-07 only consumes evidence ABI | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| ECP-25 | ECP | GitHub Agentic Workflows Safe Outputs | ADOPT_PATTERN | ROUTE_OUT | — | ROUTE_OUT | DOC-09 CI Adapter | ADOPT_PATTERN | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | DOC-09 owner controls materialization/exit; DOC-07 only consumes evidence ABI | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| ECP-26 | ECP | GitHub Actions | ADOPT | ROUTE_OUT | — | ROUTE_OUT | DOC-09 CI Adapter | ADOPT | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | DOC-09 owner controls materialization/exit; DOC-07 only consumes evidence ABI | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| ECP-27 | ECP | OpenTelemetry | ADOPT | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission / project-specific binding | ADOPT | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| ECP-28 | ECP | SLSA v1.2 | ADOPT_STANDARD | ROUTE_OUT | — | ROUTE_OUT | DOC-09 Release/Supply-Chain | ADOPT_STANDARD | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | DOC-09 owner controls materialization/exit; DOC-07 only consumes evidence ABI | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| ECP-29 | ECP | Sigstore / Cosign | ADOPT | ROUTE_OUT | — | ROUTE_OUT | DOC-09 Release/Supply-Chain | ADOPT | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | DOC-09 owner controls materialization/exit; DOC-07 only consumes evidence ABI | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| ECP-30 | ECP | GitHub Artifact Attestations | ADOPT | ROUTE_OUT | — | ROUTE_OUT | DOC-09 Release/Supply-Chain | ADOPT | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | DOC-09 owner controls materialization/exit; DOC-07 only consumes evidence ABI | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| ECP-31 | ECP | Plane | PILOT_PROJECTION_ONLY | REFERENCE | — | REFERENCE_OWNER | DOC-08 Projection Adapter | PILOT_PROJECTION_ONLY | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| ECP-32 | ECP | Linear | PILOT_PROJECTION_ONLY | REFERENCE | — | REFERENCE_OWNER | DOC-08 Projection Adapter | PILOT_PROJECTION_ONLY | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| ECP-33 | ECP | OpenProject | PILOT_ENTERPRISE_PROJECTION_ONLY | REFERENCE | — | REFERENCE_OWNER | DOC-08 Projection Adapter | PILOT_ENTERPRISE_PROJECTION_ONLY | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| ECP-34 | ECP | ProjectManagementProviderSlot | PROPOSED_CONTRACT | REFERENCE | — | REFERENCE_OWNER | DOC-08 Projection Adapter | PROPOSED_CONTRACT | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| ECP-35 | ECP | Tree-sitter | ADOPT | REFERENCE | — | REFERENCE_OWNER | DOC-03 RepoContext/Semantic Context | ADOPT | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| ECP-36 | ECP | LSP | ADOPT | REFERENCE | — | REFERENCE_OWNER | DOC-03 RepoContext/Semantic Context | ADOPT | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| ECP-37 | ECP | SCIP | ADOPT_OPTIONAL | ROUTE_OUT | — | ROUTE_OUT | DOC-09 CI Adapter | ADOPT_OPTIONAL | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | DOC-09 owner controls materialization/exit; DOC-07 only consumes evidence ABI | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| ECP-38 | ECP | Git | ADOPT | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission / project-specific binding | ADOPT | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| ECP-39 | ECP | ripgrep | ADOPT | REFERENCE | — | REFERENCE_OWNER | DOC-03 RepoContext/Semantic Context | ADOPT | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| ECP-40 | ECP | MCP | ADOPT | DIRECT | — | EXPAND_IN_DOC07 | DOC-03 Interop Binding + DOC-07 Conformance | ADOPT | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | full DOC-07 landing/eval contract required; provider/tool cannot inherit gate authority | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| ECP-41 | ECP | AGENTS.md | ADOPT_PROJECTION | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission / project-specific binding | ADOPT_PROJECTION | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| ECP-42 | ECP | SKILL.md | ADOPT_PROJECTION | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | ADOPT_PROJECTION | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| ECP-43 | ECP | Claude Code | ADOPT_PUBLIC_PATTERN_ONLY / REJECT_LEAK_CODE | REFERENCE | — | REFERENCE_OWNER | DOC-03 Provider/Harness Binding + ECP/TQAEP | ADOPT_PUBLIC_PATTERN_ONLY / REJECT_LEAK_CODE | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| ECP-44 | ECP | Codanna | SHADOW_EVAL | REFERENCE | — | REFERENCE_OWNER | DOC-03 RepoContext/Semantic Context | SHADOW_EVAL | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| ECP-45 | ECP | CodeGraph | SHADOW_EVAL | REFERENCE | — | REFERENCE_OWNER | DOC-03 RepoContext/Semantic Context | SHADOW_EVAL | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| ECP-46 | ECP | rag-rat | SHADOW_EVAL | REFERENCE | — | REFERENCE_OWNER | DOC-03 RepoContext/Semantic Context | SHADOW_EVAL | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| ECP-47 | ECP | OpenHands | QUALIFY_REFERENCE | REFERENCE | — | REFERENCE_OWNER | DOC-03 Provider/Harness Binding + ECP/TQAEP | QUALIFY_REFERENCE | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| ECP-48 | ECP | MoRSE | ADOPT_PATTERN | ROUTE_OUT | — | ROUTE_OUT | DOC-09 CI Adapter | ADOPT_PATTERN | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | DOC-09 owner controls materialization/exit; DOC-07 only consumes evidence ABI | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| ADD-01 | ADD | Agent Skills open standard | ADOPT_CANONICAL_PORTABLE_FORMAT | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | ADOPT_CANONICAL_PORTABLE_FORMAT | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| ADD-02 | ADD | OpenAI Skills | PRIMARY_HOST_TARGET | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | PRIMARY_HOST_TARGET | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| ADD-03 | ADD | OpenAI Plugin | HOST_PACKAGING | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | HOST_PACKAGING | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| ADD-04 | ADD | StateM | ADOPT_PATTERN + PILOT_DONOR | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission / project-specific binding | ADOPT_PATTERN + PILOT_DONOR | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| MSC-TECH-001 | MSC-TECH | Spec Kit Presets/Bundles | P1_PATTERN_REUSE_STAGE0 | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | P1_PATTERN_REUSE_STAGE0 | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| MSC-TECH-002 | MSC-TECH | OpenSpec Project Config/Custom Schema | P1_REUSE_STAGE0 | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | P1_REUSE_STAGE0 | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| MSC-TECH-003 | MSC-TECH | Agent Skills / skills-ref | P1_REUSE | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | P1_REUSE | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| MSC-TECH-004 | MSC-TECH | Hugging Face Skills | CONDITIONAL_REUSE | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | CONDITIONAL_REUSE | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| MSC-TECH-005 | MSC-TECH | CUE | P2_ONLY_IF_NATIVE_GAP | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission / project-specific binding | P2_ONLY_IF_NATIVE_GAP | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| MSC-TECH-006 | MSC-TECH | OPA/Rego | CONDITIONAL_HIGH_RISK | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission / project-specific binding | CONDITIONAL_HIGH_RISK | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| MSC-TECH-007 | MSC-TECH | Backstage Scaffolder | P2_SCALE_TRIGGERED | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission / project-specific binding | P2_SCALE_TRIGGERED | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| MSC-TECH-008 | MSC-TECH | Kustomize | K8S_ONLY | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission / project-specific binding | K8S_ONLY | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| MSC-TECH-009 | MSC-TECH | DeepSeek Harness profiles/bundles | SUPPORT_PILOT_EARLY_PREVIEW | REFERENCE | — | REFERENCE_OWNER | DOC-03 Provider/Harness Binding + ECP/TQAEP | SUPPORT_PILOT_EARLY_PREVIEW | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| MSC-TECH-010 | MSC-TECH | Task-Aware Harness Provisioning | METHOD_DONOR | REFERENCE | — | REFERENCE_OWNER | DOC-03 Provider/Harness Binding + ECP/TQAEP | METHOD_DONOR | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| MSC-TECH-011 | MSC-TECH | HarnessRisk | EVAL_DONOR | REFERENCE | — | REFERENCE_OWNER | DOC-03 Provider/Harness Binding + ECP/TQAEP | EVAL_DONOR | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| MSC-TECH-012 | MSC-TECH | SkillGate | RESEARCH_DONOR | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | RESEARCH_DONOR | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| MSC-TECH-013 | MSC-TECH | Demystifying Agent Skills | RESEARCH_DONOR | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | RESEARCH_DONOR | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| MSC-TECH-014 | MSC-TECH | StateM | RESEARCH_PILOT_DONOR | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission / project-specific binding | RESEARCH_PILOT_DONOR | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| MSC-TECH-015 | MSC-TECH | Hermes Agent | SUPPORT_ONLY | REFERENCE | — | REFERENCE_OWNER | DOC-03 Provider/Harness Binding + ECP/TQAEP | SUPPORT_ONLY | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| TQ-TECH-001 | TQ-TECH | NVIDIA SkillEvaluator | P1_PILOT | DIRECT | TECH-SKILLEVALUATOR | EXPAND_IN_DOC07 | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | P1_PILOT | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333,TEST-PRT-001 | OR-98BC2330,OR-E6CD4BED,OR-11B19333,OR-PRT-001 | CUR-TECH-SKILLEVALUATOR | full DOC-07 landing/eval contract required; provider/tool cannot inherit gate authority | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| TQ-TECH-002 | TQ-TECH | ACES methodology | P1_METHOD_ADOPT | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | P1_METHOD_ADOPT | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| TQ-TECH-003 | TQ-TECH | Harbor | P1_ADOPT_CANDIDATE | DIRECT | TECH-HARBOR | EXPAND_IN_DOC07 | DOC-02 TechnologyAdmission / project-specific binding | P1_ADOPT_CANDIDATE | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333,TEST-PRT-001 | OR-98BC2330,OR-E6CD4BED,OR-11B19333,OR-PRT-001 | CUR-TECH-HARBOR | full DOC-07 landing/eval contract required; provider/tool cannot inherit gate authority | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| TQ-TECH-004 | TQ-TECH | Agent Skills / skills-ref | P1_FORMAT_VALIDATOR | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | P1_FORMAT_VALIDATOR | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| TQ-TECH-005 | TQ-TECH | MCP Inspector v2 | REQUIRED_WHERE_MCP | DIRECT | TECH-MCP-INSPECTOR | EXPAND_IN_DOC07 | DOC-03 Interop Binding + DOC-07 Conformance | REQUIRED_WHERE_MCP | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333,TEST-PRT-001,TEST-PRT-002 | OR-98BC2330,OR-E6CD4BED,OR-11B19333,OR-PRT-001,OR-PRT-002 | CUR-TECH-MCP-INSPECTOR | full DOC-07 landing/eval contract required; provider/tool cannot inherit gate authority | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| TQ-TECH-006 | TQ-TECH | Spec Kit /speckit.converge | P1_REUSE_SOFTWARE | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | P1_REUSE_SOFTWARE | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| TQ-TECH-007 | TQ-TECH | OpenSpec /opsx:verify | P1_REUSE_SOFTWARE | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | P1_REUSE_SOFTWARE | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| TQ-TECH-008 | TQ-TECH | Superpowers | P1_METHOD_DONOR | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | P1_METHOD_DONOR | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| TQ-TECH-009 | TQ-TECH | mattpocock-skills | P2_DONOR | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | P2_DONOR | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| TQ-TECH-010 | TQ-TECH | grill-with-docs | P2_DONOR_ONLY | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | P2_DONOR_ONLY | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| TQ-TECH-011 | TQ-TECH | to-spec | P2_DONOR_ONLY | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | P2_DONOR_ONLY | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| TQ-TECH-012 | TQ-TECH | code-review (mattpocock-skills) | P2_DONOR_ONLY | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | P2_DONOR_ONLY | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| TQ-TECH-013 | TQ-TECH | gstack | P2_BUDGETED | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | P2_BUDGETED | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| TQ-TECH-014 | TQ-TECH | Trivy | P1 | DIRECT | TECH-TRIVY | EXPAND_IN_DOC07 | DOC-07 TQAEP/Security | P1 | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333,TEST-D28A8B60 | OR-98BC2330,OR-E6CD4BED,OR-11B19333,OR-D28A8B60 | CUR-TECH-TRIVY | full DOC-07 landing/eval contract required; provider/tool cannot inherit gate authority | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| TQ-TECH-015 | TQ-TECH | SLSA v1.2 | P1 | ROUTE_OUT | — | ROUTE_OUT | DOC-09 Release/Supply-Chain | P1 | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | DOC-09 owner controls materialization/exit; DOC-07 only consumes evidence ABI | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| TQ-TECH-016 | TQ-TECH | GitHub Artifact Attestations | P1_WHERE_GITHUB | ROUTE_OUT | — | ROUTE_OUT | DOC-09 Release/Supply-Chain | P1_WHERE_GITHUB | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | DOC-09 owner controls materialization/exit; DOC-07 only consumes evidence ABI | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| TQ-TECH-017 | TQ-TECH | Sigstore / Cosign | P1_ALTERNATE | ROUTE_OUT | — | ROUTE_OUT | DOC-09 Release/Supply-Chain | P1_ALTERNATE | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | DOC-09 owner controls materialization/exit; DOC-07 only consumes evidence ABI | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| TQ-TECH-018 | TQ-TECH | OpenTelemetry GenAI | P2_OBSERVATION_ONLY | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission / project-specific binding | P2_OBSERVATION_ONLY | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| TQ-TECH-019 | TQ-TECH | StateM | P3_PATTERN_PILOT | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission / project-specific binding | P3_PATTERN_PILOT | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| TQ-TECH-020 | TQ-TECH | HarnessRisk | P3_FIXTURE_DONOR | REFERENCE | — | REFERENCE_OWNER | DOC-03 Provider/Harness Binding + ECP/TQAEP | P3_FIXTURE_DONOR | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| TQ-TECH-021 | TQ-TECH | SkillGate | P3_ROUTING_DONOR | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | P3_ROUTING_DONOR | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| TQ-TECH-022 | TQ-TECH | Demystifying Agent Skills | P3_ROUTING_DONOR | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | P3_ROUTING_DONOR | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| TQ-TECH-023 | TQ-TECH | OpenAI Skills / Plugin | P1_HOST_SURFACE | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | P1_HOST_SURFACE | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| TQ-TECH-024 | TQ-TECH | OpenAI Apps / App Templates | V2_OPTIONAL | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission / project-specific binding | V2_OPTIONAL | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| TQ-TECH-025 | TQ-TECH | Semgrep | OPTIONAL_TRANSITIVE | DIRECT | TECH-SEMGREP | EXPAND_IN_DOC07 | DOC-07 TQAEP/Security | OPTIONAL_TRANSITIVE | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333,TEST-D28A8B60 | OR-98BC2330,OR-E6CD4BED,OR-11B19333,OR-D28A8B60 | CUR-TECH-SEMGREP | full DOC-07 landing/eval contract required; provider/tool cannot inherit gate authority | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| TQ-TECH-026 | TQ-TECH | SkillSpector | OPTIONAL_TRANSITIVE | REFERENCE | — | REFERENCE_OWNER | DOC-03 RepoContext/Semantic Context | OPTIONAL_TRANSITIVE | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| TQ-TECH-027 | TQ-TECH | Gitleaks | OPTIONAL_TRANSITIVE | DIRECT | TECH-GITLEAKS | EXPAND_IN_DOC07 | DOC-07 TQAEP/Security | OPTIONAL_TRANSITIVE | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333,TEST-D28A8B60 | OR-98BC2330,OR-E6CD4BED,OR-11B19333,OR-D28A8B60 | CUR-TECH-GITLEAKS | full DOC-07 landing/eval contract required; provider/tool cannot inherit gate authority | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| TQ-TECH-028 | TQ-TECH | GitHub Actions | P1_WHERE_GITHUB | ROUTE_OUT | TECH-GHA | ROUTE_OUT | DOC-09 CI Adapter | P1_WHERE_GITHUB | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | CUR-TECH-GHA | DOC-09 owner controls materialization/exit; DOC-07 only consumes evidence ABI | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| TQ-TECH-029 | TQ-TECH | OpenSSF Scorecard | SUPPORT_CANDIDATE | DIRECT | TECH-OSSF-SCORECARD | EXPAND_IN_DOC07 | DOC-07 TQAEP/Security | SUPPORT_CANDIDATE | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | CUR-TECH-OSSF-SCORECARD | full DOC-07 landing/eval contract required; provider/tool cannot inherit gate authority | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| TQ-TECH-030 | TQ-TECH | Hugging Face Skills | SUPPORT_CANDIDATE | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | SUPPORT_CANDIDATE | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |
| TQ-TECH-031 | TQ-TECH | Agent Safety Should Be a Runtime Contract | P3_RESEARCH_DONOR | REFERENCE | — | REFERENCE_OWNER | DOC-02 TechnologyAdmission / project-specific binding | P3_RESEARCH_DONOR | TEST-98BC2330,TEST-E6CD4BED,TEST-11B19333 | OR-98BC2330,OR-E6CD4BED,OR-11B19333 | OWNER_CURRENTNESS | owner retains semantics; omission/replacement requires explicit crosswalk rationale and TechnologyAdmission/CR when selected | source identity must remain present in this crosswalk; silent rename/drop is FAIL |

## F.2 Named donor workflows — 8/8

| Workflow ID | Capability role | PIPD canonical home | Treatment | Imported steps | Excluded semantics | Required test/exit |
|---|---|---|---|---|---|---|
| MISSION_TO_EXECUTION | mission→bounded execution orchestration | DOC-02 PI → DOC-03 S2E/WO/ECP → DOC-05 admission | TRANSLATE | mission decomposition, bounded work, evidence return | donor cannot grant PIPD lifecycle authority | trace continuity + no-execution-before-ADMIT; remove adapter cleanly |
| PHASES_RB00_RB15 | phase/runbook progression | DOC-09 Adoption Waves/Runbook | TRANSLATE | phase entry/exit/checkpoint/readback | donor phase labels not canonical lifecycle states | phase-to-canonical-state mapping; rollback/resume |
| WORKORDER_ADMISSION | WO→admission control | DOC-03/05 | KEEP_PATTERN | WO identity, permission, admission separation | WO/ECP never self-authorize | negative ECP-only/WO-only first mutation |
| CROSS_SESSION_PIPELINE | resume/handoff continuity | DOC-03/04 | TRANSLATE | subject/version/hash, checkpoint, context/evidence handoff | memory/session state not semantic authority | resume wrong-subject/stale-hash negative; purge/expiry |
| PROVIDER_ADMISSION | provider qualification/binding | DOC-02 TechnologyAdmission + DOC-03 currentness | TRANSLATE | pin/license/security/capability/exit | provider cannot own canonical semantics | provider-off/parity/currentness TTL |
| LONG_RUNNING_CONTROL | long-horizon checkpoint/recovery | DOC-03 ECP / DOC-09 runbook | TRANSLATE | checkpoint, stop/retry, recovery, evidence | no autonomous authority expansion | timeout/restart/recovery + scope containment |
| SELF_ITERATION_LOOP | bounded repair/iteration | DOC-07 rework/requalification | REFERENCE | repair loop under stable oracle | no self-issued PASS or requirement rewrite | mutation/rework stop + human/acceptor boundary |
| RELEASE_RECOVERY | release/rollback/recovery | DOC-09 Release Lane | TRANSLATE | artifact identity, recovery, rollback, evidence | release workflow cannot replace acceptance/qualification | digest/attestation/rollback/residue tests |

`SELF_ITERATION_LOOP` is substantively materialized in §28. All other workflows retain identity and ownership; route-out never becomes silent loss.

# Appendix G｜Extractable Machine Conformance Catalog Instance

This JSON instance validates against the R2 schema in §03.1 during author-side construction. Counts:

- tests: `187`
- oracles: `187`
- fixtures: `226`
- canonical requirement bindings: `86`
- source bindings: `7`

```json
{
  "catalog_id": "PIPD-DOC07-CONFORMANCE-CATALOG-R2",
  "standard_version": "1.1.0",
  "source_bindings": [
    {
      "source_id": "A1_BLUEPRINT",
      "sha256": "9a8323e5237c1555a76d9a75f706e3552d79c192915cc782b76b211c7f27d527",
      "authority": "A1"
    },
    {
      "source_id": "A2_STANDARD",
      "sha256": "6f6aafece90b34e33786647e14fee840f5424893995b3164cbb52953a5c4f14a",
      "authority": "A2"
    },
    {
      "source_id": "A3_SKELETON",
      "sha256": "03bb3609dc67f85fa4b683a93736cf162e9047b6b253182aa3fdba11ba40cb28",
      "authority": "A3"
    },
    {
      "source_id": "A4_DISCUSSION",
      "sha256": "be1858e860092fb1751bf0524cd22b6939138b6835ce8f452bfc30894f945a95",
      "authority": "A4"
    },
    {
      "source_id": "PRODUCTION_INSTRUCTION",
      "sha256": "0609d6f618f84c8b627c9084e521e6d1f1bb8cb5597ea635ec51f0bd7ae83b2d",
      "authority": "TASK"
    },
    {
      "source_id": "R1_TARGET",
      "sha256": "3a5d25be0ff75572e376575000513591eb713887015b1a653657eb56c05b05b9",
      "authority": "PATCH_BASE"
    },
    {
      "source_id": "AUDIT_CONTROLLER",
      "sha256": "96b93631afb089c36182691c05b12718789044892e33575157cb34b8bc1c5cc2",
      "authority": "REPAIR_CONTROLLER"
    }
  ],
  "tests": [
    {
      "test_id": "TEST-06583027",
      "oracle_id": "OR-06583027",
      "source_ref": "A1 normative requirement ledger::PI-10 SPEC",
      "applicability": "APPLICABLE_PROFILE",
      "requirement_refs": [
        "STD-REQ-06583027"
      ],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-0B4D6B1E",
      "oracle_id": "OR-0B4D6B1E",
      "source_ref": "A1 normative requirement ledger::23. Target Profile — Agent Harness / Agentic Runtime",
      "applicability": "APPLICABLE_PROFILE",
      "requirement_refs": [
        "STD-REQ-0B4D6B1E"
      ],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-0C5B13B3",
      "oracle_id": "OR-0C5B13B3",
      "source_ref": "A1 normative requirement ledger::23. Target Profile — Agent Harness / Agentic Runtime",
      "applicability": "APPLICABLE_PROFILE",
      "requirement_refs": [
        "STD-REQ-0C5B13B3"
      ],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-0CB9A2A0",
      "oracle_id": "OR-0CB9A2A0",
      "source_ref": "A1 normative requirement ledger::C-09 Tailoring Profile",
      "applicability": "APPLICABLE_PROFILE",
      "requirement_refs": [
        "STD-REQ-0CB9A2A0"
      ],
      "fixture_refs": [
        "FX-EDGE-001"
      ]
    },
    {
      "test_id": "TEST-0E1DBA46",
      "oracle_id": "OR-0E1DBA46",
      "source_ref": "A1 normative requirement ledger::P-10 Handoff Must Be Rejectable",
      "applicability": "APPLICABLE_PROFILE",
      "requirement_refs": [
        "STD-REQ-0E1DBA46"
      ],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-10C6C743",
      "oracle_id": "OR-10C6C743",
      "source_ref": "A1 normative requirement ledger::C-12 DomainProfileExtension",
      "applicability": "APPLICABLE_PROFILE",
      "requirement_refs": [
        "STD-REQ-10C6C743"
      ],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-119B9088",
      "oracle_id": "OR-119B9088",
      "source_ref": "A1 normative requirement ledger::C-04 Lifecycle States",
      "applicability": "APPLICABLE_PROFILE",
      "requirement_refs": [
        "STD-REQ-119B9088"
      ],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-11B19333",
      "oracle_id": "OR-11B19333",
      "source_ref": "A1 normative requirement ledger::6.2 Authority and Adapter Non-Override Rule",
      "applicability": "ALL",
      "requirement_refs": [
        "STD-REQ-11B19333"
      ],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-1859D4F5",
      "oracle_id": "OR-1859D4F5",
      "source_ref": "A1 normative requirement ledger::PD-06 DEV ECP — Development Execution Control",
      "applicability": "ALL",
      "requirement_refs": [
        "STD-REQ-1859D4F5"
      ],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-22E53BD2",
      "oracle_id": "OR-22E53BD2",
      "source_ref": "A1 normative requirement ledger::25. Evidence Return Contract",
      "applicability": "APPLICABLE_PROFILE",
      "requirement_refs": [
        "STD-REQ-22E53BD2"
      ],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-27A2EA7F",
      "oracle_id": "OR-27A2EA7F",
      "source_ref": "A1 normative requirement ledger::PI-05 Atomic Requirements",
      "applicability": "APPLICABLE_PROFILE",
      "requirement_refs": [
        "STD-REQ-27A2EA7F"
      ],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-28163C14",
      "oracle_id": "OR-28163C14",
      "source_ref": "A1 normative requirement ledger::20.4 Machine Profile Binding",
      "applicability": "ALL",
      "requirement_refs": [
        "STD-REQ-28163C14"
      ],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-2A89F996",
      "oracle_id": "OR-2A89F996",
      "source_ref": "A1 normative requirement ledger::P-14 Segregation of Duties",
      "applicability": "ALL",
      "requirement_refs": [
        "STD-REQ-2A89F996"
      ],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-2E59E411",
      "oracle_id": "OR-2E59E411",
      "source_ref": "A1 normative requirement ledger::23A. World Effect / Observation / Readback / Reconciliation",
      "applicability": "ALL",
      "requirement_refs": [
        "STD-REQ-2E59E411"
      ],
      "fixture_refs": [
        "DT-10-C02"
      ]
    },
    {
      "test_id": "TEST-2FF7F879",
      "oracle_id": "OR-2FF7F879",
      "source_ref": "A1 normative requirement ledger::PD-06 DEV ECP — Development Execution Control",
      "applicability": "ALL",
      "requirement_refs": [
        "STD-REQ-2FF7F879"
      ],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-3235004D",
      "oracle_id": "OR-3235004D",
      "source_ref": "A1 normative requirement ledger::21.2 BrownfieldMigrationProfile",
      "applicability": "APPLICABLE_PROFILE",
      "requirement_refs": [
        "STD-REQ-3235004D"
      ],
      "fixture_refs": [
        "FX-DECOM-001"
      ]
    },
    {
      "test_id": "TEST-37150A4D",
      "oracle_id": "OR-37150A4D",
      "source_ref": "A1 normative requirement ledger::28. Canonical Standard vs Adapter",
      "applicability": "APPLICABLE_PROFILE",
      "requirement_refs": [
        "STD-REQ-37150A4D"
      ],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-38EB8516",
      "oracle_id": "OR-38EB8516",
      "source_ref": "A1 normative requirement ledger::18.1 Extraction Manifest",
      "applicability": "APPLICABLE_PROFILE",
      "requirement_refs": [
        "STD-REQ-38EB8516"
      ],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-3CA02A9C",
      "oracle_id": "OR-3CA02A9C",
      "source_ref": "A1 normative requirement ledger::22. Target Profile — SKILL / PLUGIN",
      "applicability": "APPLICABLE_PROFILE",
      "requirement_refs": [
        "STD-REQ-3CA02A9C"
      ],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-44B56684",
      "oracle_id": "OR-44B56684",
      "source_ref": "A1 normative requirement ledger::50. Final Normative Statement",
      "applicability": "APPLICABLE_PROFILE",
      "requirement_refs": [
        "STD-REQ-44B56684"
      ],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-454A6D90",
      "oracle_id": "OR-454A6D90",
      "source_ref": "A1 normative requirement ledger::C-02 Authority Stack",
      "applicability": "ALL",
      "requirement_refs": [
        "STD-REQ-454A6D90"
      ],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-4AAA061A",
      "oracle_id": "OR-4AAA061A",
      "source_ref": "A1 normative requirement ledger::P-09 Complexity Must Earn Complexity",
      "applicability": "ALL",
      "requirement_refs": [
        "STD-REQ-4AAA061A"
      ],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-522701F0",
      "oracle_id": "OR-522701F0",
      "source_ref": "A1 normative requirement ledger::PI-08.1 Mandatory Search-Before-Build algorithm",
      "applicability": "APPLICABLE_PROFILE",
      "requirement_refs": [
        "STD-REQ-522701F0"
      ],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-5868D53A",
      "oracle_id": "OR-5868D53A",
      "source_ref": "A1 normative requirement ledger::9. PI-PKG Required Contract Areas",
      "applicability": "APPLICABLE_PROFILE",
      "requirement_refs": [
        "STD-REQ-5868D53A"
      ],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-59414E50",
      "oracle_id": "OR-59414E50",
      "source_ref": "A1 normative requirement ledger::18.3 Deterministic Conformance Reference Command",
      "applicability": "APPLICABLE_PROFILE",
      "requirement_refs": [
        "STD-REQ-59414E50"
      ],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-59D1DD6F",
      "oracle_id": "OR-59D1DD6F",
      "source_ref": "A1 normative requirement ledger::C-11 Standard Namespace / Schema Compatibility",
      "applicability": "APPLICABLE_PROFILE",
      "requirement_refs": [
        "STD-REQ-59D1DD6F"
      ],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-5AADF6A3",
      "oracle_id": "OR-5AADF6A3",
      "source_ref": "A1 normative requirement ledger::PI-14 Deliverables",
      "applicability": "APPLICABLE_PROFILE",
      "requirement_refs": [
        "STD-REQ-5AADF6A3"
      ],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-5E28F98D",
      "oracle_id": "OR-5E28F98D",
      "source_ref": "A1 normative requirement ledger::PI-13 Evidence Expectation",
      "applicability": "APPLICABLE_PROFILE",
      "requirement_refs": [
        "STD-REQ-5E28F98D"
      ],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-5EFF0181",
      "oracle_id": "OR-5EFF0181",
      "source_ref": "A1 normative requirement ledger::C-02 Authority Stack",
      "applicability": "APPLICABLE_PROFILE",
      "requirement_refs": [
        "STD-REQ-5EFF0181"
      ],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-61E2C648",
      "oracle_id": "OR-61E2C648",
      "source_ref": "A1 normative requirement ledger::PD-08 TQAEP — Test / Qualification / Acceptance / Evidence Plan",
      "applicability": "APPLICABLE_PROFILE",
      "requirement_refs": [
        "STD-REQ-61E2C648"
      ],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-689DE502",
      "oracle_id": "OR-689DE502",
      "source_ref": "A1 normative requirement ledger::P-03 Stable Semantics vs Late-Bound Facts",
      "applicability": "APPLICABLE_PROFILE",
      "requirement_refs": [
        "STD-REQ-689DE502"
      ],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-6CCE644F",
      "oracle_id": "OR-6CCE644F",
      "source_ref": "A1 normative requirement ledger::C-03 Canonical Ownership",
      "applicability": "APPLICABLE_PROFILE",
      "requirement_refs": [
        "STD-REQ-6CCE644F"
      ],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-6E492151",
      "oracle_id": "OR-6E492151",
      "source_ref": "A1 normative requirement ledger::PD-08 TQAEP — Test / Qualification / Acceptance / Evidence Plan",
      "applicability": "ALL",
      "requirement_refs": [
        "STD-REQ-6E492151"
      ],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-6E714CAB",
      "oracle_id": "OR-6E714CAB",
      "source_ref": "A1 normative requirement ledger::PI-17 Claim Ceiling / State Truth",
      "applicability": "APPLICABLE_PROFILE",
      "requirement_refs": [
        "STD-REQ-6E714CAB"
      ],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-6F8DCD42",
      "oracle_id": "OR-6F8DCD42",
      "source_ref": "A1 normative requirement ledger::47. External Alignment / Informative Research Notes",
      "applicability": "APPLICABLE_PROFILE",
      "requirement_refs": [
        "STD-REQ-6F8DCD42"
      ],
      "fixture_refs": [
        "FX-DRIFT-001",
        "FX-DRIFT-001-C01",
        "FX-DRIFT-001-C02",
        "FX-DRIFT-001-C03"
      ]
    },
    {
      "test_id": "TEST-7468B275",
      "oracle_id": "OR-7468B275",
      "source_ref": "A1 normative requirement ledger::PD-05 S2E — Spec-to-Execution",
      "applicability": "ALL",
      "requirement_refs": [
        "STD-REQ-7468B275"
      ],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-75B304BB",
      "oracle_id": "OR-75B304BB",
      "source_ref": "A1 normative requirement ledger::PD-10 Execution Admission",
      "applicability": "APPLICABLE_PROFILE",
      "requirement_refs": [
        "STD-REQ-75B304BB"
      ],
      "fixture_refs": [
        "DT-09-C02",
        "DT-09-C03",
        "DT-09-C04",
        "FX-APPR-001-C02",
        "FX-APPR-001-C03",
        "FX-APPR-001-C04"
      ]
    },
    {
      "test_id": "TEST-7894BFB5",
      "oracle_id": "OR-7894BFB5",
      "source_ref": "A1 normative requirement ledger::26.2 External Content Is Data",
      "applicability": "APPLICABLE_PROFILE",
      "requirement_refs": [
        "STD-REQ-7894BFB5"
      ],
      "fixture_refs": [
        "FX-ADV-001",
        "FX-INJ-001"
      ]
    },
    {
      "test_id": "TEST-79A6948B",
      "oracle_id": "OR-79A6948B",
      "source_ref": "A1 normative requirement ledger::P-07 Evidence Is Subject-Bound",
      "applicability": "ALL",
      "requirement_refs": [
        "STD-REQ-79A6948B"
      ],
      "fixture_refs": [
        "FX-WSUB-001",
        "FX-WHASH-001"
      ]
    },
    {
      "test_id": "TEST-7B3AB9E9",
      "oracle_id": "OR-7B3AB9E9",
      "source_ref": "A1 normative requirement ledger::C-01 Project / Product Identity",
      "applicability": "APPLICABLE_PROFILE",
      "requirement_refs": [
        "STD-REQ-7B3AB9E9"
      ],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-7CD1E5E6",
      "oracle_id": "OR-7CD1E5E6",
      "source_ref": "A1 normative requirement ledger::26.7 SoD Enforcement",
      "applicability": "APPLICABLE_PROFILE",
      "requirement_refs": [
        "STD-REQ-7CD1E5E6"
      ],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-7CEA782A",
      "oracle_id": "OR-7CEA782A",
      "source_ref": "A1 normative requirement ledger::PD-05A TaskSpecSeed",
      "applicability": "ALL",
      "requirement_refs": [
        "STD-REQ-7CEA782A"
      ],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-81C86EBB",
      "oracle_id": "OR-81C86EBB",
      "source_ref": "A1 normative requirement ledger::6. Artifact Identity & Authority Model",
      "applicability": "APPLICABLE_PROFILE",
      "requirement_refs": [
        "STD-REQ-81C86EBB"
      ],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-829B7605",
      "oracle_id": "OR-829B7605",
      "source_ref": "A1 normative requirement ledger::7.1 Purpose",
      "applicability": "APPLICABLE_PROFILE",
      "requirement_refs": [
        "STD-REQ-829B7605"
      ],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-86CAC54E",
      "oracle_id": "OR-86CAC54E",
      "source_ref": "A1 normative requirement ledger::26.4 Agent Memory",
      "applicability": "APPLICABLE_PROFILE",
      "requirement_refs": [
        "STD-REQ-86CAC54E"
      ],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-8A8EDC94",
      "oracle_id": "OR-8A8EDC94",
      "source_ref": "A1 normative requirement ledger::10. Requirement Narrow Waist",
      "applicability": "APPLICABLE_PROFILE",
      "requirement_refs": [
        "STD-REQ-8A8EDC94"
      ],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-90364E5B",
      "oracle_id": "OR-90364E5B",
      "source_ref": "A1 normative requirement ledger::C-12 DomainProfileExtension",
      "applicability": "APPLICABLE_PROFILE",
      "requirement_refs": [
        "STD-REQ-90364E5B"
      ],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-92132DB3",
      "oracle_id": "OR-92132DB3",
      "source_ref": "A1 normative requirement ledger::13. PD-PKG Canonical Purpose",
      "applicability": "APPLICABLE_PROFILE",
      "requirement_refs": [
        "STD-REQ-92132DB3"
      ],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-93766574",
      "oracle_id": "OR-93766574",
      "source_ref": "A1 normative requirement ledger::PD-05B WorkOrder Materialization",
      "applicability": "ALL",
      "requirement_refs": [
        "STD-REQ-93766574"
      ],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-979740C9",
      "oracle_id": "OR-979740C9",
      "source_ref": "A1 normative requirement ledger::1. Normative Language / 規範語言",
      "applicability": "APPLICABLE_PROFILE",
      "requirement_refs": [
        "STD-REQ-979740C9"
      ],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-97BCACAC",
      "oracle_id": "OR-97BCACAC",
      "source_ref": "A1 normative requirement ledger::32. Mandatory Conformance Test Registry",
      "applicability": "ALL",
      "requirement_refs": [
        "STD-REQ-97BCACAC"
      ],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-98BC2330",
      "oracle_id": "OR-98BC2330",
      "source_ref": "A1 normative requirement ledger::P-11 Capability-Before-Brand / Search-Before-Build",
      "applicability": "APPLICABLE_PROFILE",
      "requirement_refs": [
        "STD-REQ-98BC2330"
      ],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-98F459F8",
      "oracle_id": "OR-98F459F8",
      "source_ref": "A1 normative requirement ledger::1. Normative Language / 規範語言",
      "applicability": "APPLICABLE_PROFILE",
      "requirement_refs": [
        "STD-REQ-98F459F8"
      ],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-9DF08F85",
      "oracle_id": "OR-9DF08F85",
      "source_ref": "A1 normative requirement ledger::PD-07 OPS ECP — Operations Readiness & Execution Control",
      "applicability": "ALL",
      "requirement_refs": [
        "STD-REQ-9DF08F85"
      ],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-9E161B60",
      "oracle_id": "OR-9E161B60",
      "source_ref": "A1 normative requirement ledger::C-11 Standard Namespace / Schema Compatibility",
      "applicability": "APPLICABLE_PROFILE",
      "requirement_refs": [
        "STD-REQ-9E161B60"
      ],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-9E4AFAC1",
      "oracle_id": "OR-9E4AFAC1",
      "source_ref": "A1 normative requirement ledger::8. PI-PKG Canonical Purpose",
      "applicability": "APPLICABLE_PROFILE",
      "requirement_refs": [
        "STD-REQ-9E4AFAC1"
      ],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-ABD8745E",
      "oracle_id": "OR-ABD8745E",
      "source_ref": "A1 normative requirement ledger::P-05 No Execution by Documentation",
      "applicability": "ALL",
      "requirement_refs": [
        "STD-REQ-ABD8745E"
      ],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-ABE182D6",
      "oracle_id": "OR-ABE182D6",
      "source_ref": "A1 normative requirement ledger::8. PI-PKG Canonical Purpose",
      "applicability": "APPLICABLE_PROFILE",
      "requirement_refs": [
        "STD-REQ-ABE182D6"
      ],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-B0C02A64",
      "oracle_id": "OR-B0C02A64",
      "source_ref": "A1 normative requirement ledger::5.2 Promotion Rule",
      "applicability": "APPLICABLE_PROFILE",
      "requirement_refs": [
        "STD-REQ-B0C02A64"
      ],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-B1C9AB85",
      "oracle_id": "OR-B1C9AB85",
      "source_ref": "A1 normative requirement ledger::P-01 Single Canonical Truth",
      "applicability": "APPLICABLE_PROFILE",
      "requirement_refs": [
        "STD-REQ-B1C9AB85"
      ],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-B4D1C8EA",
      "oracle_id": "OR-B4D1C8EA",
      "source_ref": "A1 normative requirement ledger::PI-12 Verification / Oracle",
      "applicability": "APPLICABLE_PROFILE",
      "requirement_refs": [
        "STD-REQ-B4D1C8EA"
      ],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-B5C7D219",
      "oracle_id": "OR-B5C7D219",
      "source_ref": "A1 normative requirement ledger::22.1 Skill/Plugin Conformance Additions",
      "applicability": "ALL",
      "requirement_refs": [
        "STD-REQ-B5C7D219"
      ],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-B88A6D37",
      "oracle_id": "OR-B88A6D37",
      "source_ref": "A1 normative requirement ledger::P-02 Source-Bound Intent Preservation",
      "applicability": "ALL",
      "requirement_refs": [
        "STD-REQ-B88A6D37"
      ],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-BA1FB472",
      "oracle_id": "OR-BA1FB472",
      "source_ref": "A1 normative requirement ledger::PD-05 S2E — Spec-to-Execution",
      "applicability": "ALL",
      "requirement_refs": [
        "STD-REQ-BA1FB472"
      ],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-BF0442B3",
      "oracle_id": "OR-BF0442B3",
      "source_ref": "A1 normative requirement ledger::22. Target Profile — SKILL / PLUGIN",
      "applicability": "APPLICABLE_PROFILE",
      "requirement_refs": [
        "STD-REQ-BF0442B3"
      ],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-BND-001",
      "oracle_id": "OR-BND-001",
      "source_ref": "A2 §32 Mandatory Conformance Test Registry",
      "applicability": "ALL",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-PERM-001"
      ]
    },
    {
      "test_id": "TEST-BND-002",
      "oracle_id": "OR-BND-002",
      "source_ref": "A2 §32 Mandatory Conformance Test Registry",
      "applicability": "ALL",
      "requirement_refs": [],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-BND-003",
      "oracle_id": "OR-BND-003",
      "source_ref": "A2 §32 Mandatory Conformance Test Registry",
      "applicability": "ALL",
      "requirement_refs": [],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-C25BC6A2",
      "oracle_id": "OR-C25BC6A2",
      "source_ref": "A1 normative requirement ledger::6. Artifact Identity & Authority Model",
      "applicability": "APPLICABLE_PROFILE",
      "requirement_refs": [
        "STD-REQ-C25BC6A2"
      ],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-C49B66DE",
      "oracle_id": "OR-C49B66DE",
      "source_ref": "A1 normative requirement ledger::PI-11 Acceptance",
      "applicability": "APPLICABLE_PROFILE",
      "requirement_refs": [
        "STD-REQ-C49B66DE"
      ],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-C5BCA382",
      "oracle_id": "OR-C5BCA382",
      "source_ref": "A1 normative requirement ledger::P-15 Prose/Machine Gate Equivalence",
      "applicability": "ALL",
      "requirement_refs": [
        "STD-REQ-C5BCA382"
      ],
      "fixture_refs": [
        "FX-NEG-001",
        "FX-APP-001"
      ]
    },
    {
      "test_id": "TEST-C6A9781D",
      "oracle_id": "OR-C6A9781D",
      "source_ref": "A1 normative requirement ledger::P-06 Claim Separation",
      "applicability": "APPLICABLE_PROFILE",
      "requirement_refs": [
        "STD-REQ-C6A9781D"
      ],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-C887276E",
      "oracle_id": "OR-C887276E",
      "source_ref": "A1 normative requirement ledger::PI-18 Pre-Dev Handoff",
      "applicability": "APPLICABLE_PROFILE",
      "requirement_refs": [
        "STD-REQ-C887276E"
      ],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-CMP-001",
      "oracle_id": "OR-CMP-001",
      "source_ref": "A2 §32 Mandatory Conformance Test Registry",
      "applicability": "ALL",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-POS-001"
      ]
    },
    {
      "test_id": "TEST-CMP-002",
      "oracle_id": "OR-CMP-002",
      "source_ref": "A2 §32 Mandatory Conformance Test Registry",
      "applicability": "ALL",
      "requirement_refs": [],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-D07-AH-PD-01",
      "oracle_id": "OR-D07-AH-PD-01",
      "source_ref": "A3 profile denominator::AGENT_HARNESS::PD",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-AH-PD-01-P",
        "FX-AH-PD-01-N"
      ]
    },
    {
      "test_id": "TEST-D07-AH-PD-02",
      "oracle_id": "OR-D07-AH-PD-02",
      "source_ref": "A3 profile denominator::AGENT_HARNESS::PD",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-AH-PD-02-P",
        "FX-AH-PD-02-N"
      ]
    },
    {
      "test_id": "TEST-D07-AH-PD-03",
      "oracle_id": "OR-D07-AH-PD-03",
      "source_ref": "A3 profile denominator::AGENT_HARNESS::PD",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-AH-PD-03-P",
        "FX-AH-PD-03-N"
      ]
    },
    {
      "test_id": "TEST-D07-AH-PD-04",
      "oracle_id": "OR-D07-AH-PD-04",
      "source_ref": "A3 profile denominator::AGENT_HARNESS::PD",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-AH-PD-04-P",
        "FX-AH-PD-04-N"
      ]
    },
    {
      "test_id": "TEST-D07-AH-PD-05",
      "oracle_id": "OR-D07-AH-PD-05",
      "source_ref": "A3 profile denominator::AGENT_HARNESS::PD",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-AH-PD-05-P",
        "FX-AH-PD-05-N"
      ]
    },
    {
      "test_id": "TEST-D07-AH-PD-06",
      "oracle_id": "OR-D07-AH-PD-06",
      "source_ref": "A3 profile denominator::AGENT_HARNESS::PD",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-AH-PD-06-P",
        "FX-AH-PD-06-N"
      ]
    },
    {
      "test_id": "TEST-D07-AH-PD-07",
      "oracle_id": "OR-D07-AH-PD-07",
      "source_ref": "A3 profile denominator::AGENT_HARNESS::PD",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-AH-PD-07-P",
        "FX-AH-PD-07-N"
      ]
    },
    {
      "test_id": "TEST-D07-AH-PD-08",
      "oracle_id": "OR-D07-AH-PD-08",
      "source_ref": "A3 profile denominator::AGENT_HARNESS::PD",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-AH-PD-08-P",
        "FX-AH-PD-08-N"
      ]
    },
    {
      "test_id": "TEST-D07-AH-PD-09",
      "oracle_id": "OR-D07-AH-PD-09",
      "source_ref": "A3 profile denominator::AGENT_HARNESS::PD",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-AH-PD-09-P",
        "FX-AH-PD-09-N"
      ]
    },
    {
      "test_id": "TEST-D07-AH-PD-10",
      "oracle_id": "OR-D07-AH-PD-10",
      "source_ref": "A3 profile denominator::AGENT_HARNESS::PD",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-AH-PD-10-P",
        "FX-AH-PD-10-N"
      ]
    },
    {
      "test_id": "TEST-D07-AH-PD-11",
      "oracle_id": "OR-D07-AH-PD-11",
      "source_ref": "A3 profile denominator::AGENT_HARNESS::PD",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-AH-PD-11-P",
        "FX-AH-PD-11-N"
      ]
    },
    {
      "test_id": "TEST-D07-AH-PD-12",
      "oracle_id": "OR-D07-AH-PD-12",
      "source_ref": "A3 profile denominator::AGENT_HARNESS::PD",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-AH-PD-12-P",
        "FX-AH-PD-12-N"
      ]
    },
    {
      "test_id": "TEST-D07-AH-PD-13",
      "oracle_id": "OR-D07-AH-PD-13",
      "source_ref": "A3 profile denominator::AGENT_HARNESS::PD",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-AH-PD-13-P",
        "FX-AH-PD-13-N"
      ]
    },
    {
      "test_id": "TEST-D07-AH-PI-01",
      "oracle_id": "OR-D07-AH-PI-01",
      "source_ref": "A3 profile denominator::AGENT_HARNESS::PI",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-AH-PI-01-P",
        "FX-AH-PI-01-N"
      ]
    },
    {
      "test_id": "TEST-D07-AH-PI-02",
      "oracle_id": "OR-D07-AH-PI-02",
      "source_ref": "A3 profile denominator::AGENT_HARNESS::PI",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-AH-PI-02-P",
        "FX-AH-PI-02-N"
      ]
    },
    {
      "test_id": "TEST-D07-AH-PI-03",
      "oracle_id": "OR-D07-AH-PI-03",
      "source_ref": "A3 profile denominator::AGENT_HARNESS::PI",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-AH-PI-03-P",
        "FX-AH-PI-03-N"
      ]
    },
    {
      "test_id": "TEST-D07-AH-PI-04",
      "oracle_id": "OR-D07-AH-PI-04",
      "source_ref": "A3 profile denominator::AGENT_HARNESS::PI",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-AH-PI-04-P",
        "FX-AH-PI-04-N"
      ]
    },
    {
      "test_id": "TEST-D07-AH-PI-05",
      "oracle_id": "OR-D07-AH-PI-05",
      "source_ref": "A3 profile denominator::AGENT_HARNESS::PI",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-AH-PI-05-P",
        "FX-AH-PI-05-N"
      ]
    },
    {
      "test_id": "TEST-D07-AH-PI-06",
      "oracle_id": "OR-D07-AH-PI-06",
      "source_ref": "A3 profile denominator::AGENT_HARNESS::PI",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-AH-PI-06-P",
        "FX-AH-PI-06-N"
      ]
    },
    {
      "test_id": "TEST-D07-AH-PI-07",
      "oracle_id": "OR-D07-AH-PI-07",
      "source_ref": "A3 profile denominator::AGENT_HARNESS::PI",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-AH-PI-07-P",
        "FX-AH-PI-07-N"
      ]
    },
    {
      "test_id": "TEST-D07-AH-PI-08",
      "oracle_id": "OR-D07-AH-PI-08",
      "source_ref": "A3 profile denominator::AGENT_HARNESS::PI",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-AH-PI-08-P",
        "FX-AH-PI-08-N"
      ]
    },
    {
      "test_id": "TEST-D07-AH-PI-09",
      "oracle_id": "OR-D07-AH-PI-09",
      "source_ref": "A3 profile denominator::AGENT_HARNESS::PI",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-AH-PI-09-P",
        "FX-AH-PI-09-N"
      ]
    },
    {
      "test_id": "TEST-D07-AH-PI-10",
      "oracle_id": "OR-D07-AH-PI-10",
      "source_ref": "A3 profile denominator::AGENT_HARNESS::PI",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-AH-PI-10-P",
        "FX-AH-PI-10-N"
      ]
    },
    {
      "test_id": "TEST-D07-AH-PI-11",
      "oracle_id": "OR-D07-AH-PI-11",
      "source_ref": "A3 profile denominator::AGENT_HARNESS::PI",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-AH-PI-11-P",
        "FX-AH-PI-11-N"
      ]
    },
    {
      "test_id": "TEST-D07-AH-PI-12",
      "oracle_id": "OR-D07-AH-PI-12",
      "source_ref": "A3 profile denominator::AGENT_HARNESS::PI",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-AH-PI-12-P",
        "FX-AH-PI-12-N"
      ]
    },
    {
      "test_id": "TEST-D07-AH-PI-13",
      "oracle_id": "OR-D07-AH-PI-13",
      "source_ref": "A3 profile denominator::AGENT_HARNESS::PI",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-AH-PI-13-P",
        "FX-AH-PI-13-N"
      ]
    },
    {
      "test_id": "TEST-D07-AH-PI-14",
      "oracle_id": "OR-D07-AH-PI-14",
      "source_ref": "A3 profile denominator::AGENT_HARNESS::PI",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-AH-PI-14-P",
        "FX-AH-PI-14-N"
      ]
    },
    {
      "test_id": "TEST-D07-AH-PI-15",
      "oracle_id": "OR-D07-AH-PI-15",
      "source_ref": "A3 profile denominator::AGENT_HARNESS::PI",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-AH-PI-15-P",
        "FX-AH-PI-15-N"
      ]
    },
    {
      "test_id": "TEST-D07-SK-PD-01",
      "oracle_id": "OR-D07-SK-PD-01",
      "source_ref": "A3 profile denominator::SKILL_PLUGIN::PD",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-SK-PD-01-P",
        "FX-SK-PD-01-N"
      ]
    },
    {
      "test_id": "TEST-D07-SK-PD-02",
      "oracle_id": "OR-D07-SK-PD-02",
      "source_ref": "A3 profile denominator::SKILL_PLUGIN::PD",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-SK-PD-02-P",
        "FX-SK-PD-02-N"
      ]
    },
    {
      "test_id": "TEST-D07-SK-PD-03",
      "oracle_id": "OR-D07-SK-PD-03",
      "source_ref": "A3 profile denominator::SKILL_PLUGIN::PD",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-SK-PD-03-P",
        "FX-SK-PD-03-N"
      ]
    },
    {
      "test_id": "TEST-D07-SK-PD-04",
      "oracle_id": "OR-D07-SK-PD-04",
      "source_ref": "A3 profile denominator::SKILL_PLUGIN::PD",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-SK-PD-04-P",
        "FX-SK-PD-04-N"
      ]
    },
    {
      "test_id": "TEST-D07-SK-PD-05",
      "oracle_id": "OR-D07-SK-PD-05",
      "source_ref": "A3 profile denominator::SKILL_PLUGIN::PD",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-SK-PD-05-P",
        "FX-SK-PD-05-N"
      ]
    },
    {
      "test_id": "TEST-D07-SK-PD-06",
      "oracle_id": "OR-D07-SK-PD-06",
      "source_ref": "A3 profile denominator::SKILL_PLUGIN::PD",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-SK-PD-06-P",
        "FX-SK-PD-06-N"
      ]
    },
    {
      "test_id": "TEST-D07-SK-PD-07",
      "oracle_id": "OR-D07-SK-PD-07",
      "source_ref": "A3 profile denominator::SKILL_PLUGIN::PD",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-SK-PD-07-P",
        "FX-SK-PD-07-N"
      ]
    },
    {
      "test_id": "TEST-D07-SK-PD-08",
      "oracle_id": "OR-D07-SK-PD-08",
      "source_ref": "A3 profile denominator::SKILL_PLUGIN::PD",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-SK-PD-08-P",
        "FX-SK-PD-08-N"
      ]
    },
    {
      "test_id": "TEST-D07-SK-PD-09",
      "oracle_id": "OR-D07-SK-PD-09",
      "source_ref": "A3 profile denominator::SKILL_PLUGIN::PD",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-SK-PD-09-P",
        "FX-SK-PD-09-N"
      ]
    },
    {
      "test_id": "TEST-D07-SK-PD-10",
      "oracle_id": "OR-D07-SK-PD-10",
      "source_ref": "A3 profile denominator::SKILL_PLUGIN::PD",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-SK-PD-10-P",
        "FX-SK-PD-10-N"
      ]
    },
    {
      "test_id": "TEST-D07-SK-PD-11",
      "oracle_id": "OR-D07-SK-PD-11",
      "source_ref": "A3 profile denominator::SKILL_PLUGIN::PD",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-SK-PD-11-P",
        "FX-SK-PD-11-N"
      ]
    },
    {
      "test_id": "TEST-D07-SK-PD-12",
      "oracle_id": "OR-D07-SK-PD-12",
      "source_ref": "A3 profile denominator::SKILL_PLUGIN::PD",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-SK-PD-12-P",
        "FX-SK-PD-12-N"
      ]
    },
    {
      "test_id": "TEST-D07-SK-PI-01",
      "oracle_id": "OR-D07-SK-PI-01",
      "source_ref": "A3 profile denominator::SKILL_PLUGIN::PI",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-SK-PI-01-P",
        "FX-SK-PI-01-N"
      ]
    },
    {
      "test_id": "TEST-D07-SK-PI-02",
      "oracle_id": "OR-D07-SK-PI-02",
      "source_ref": "A3 profile denominator::SKILL_PLUGIN::PI",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-SK-PI-02-P",
        "FX-SK-PI-02-N"
      ]
    },
    {
      "test_id": "TEST-D07-SK-PI-03",
      "oracle_id": "OR-D07-SK-PI-03",
      "source_ref": "A3 profile denominator::SKILL_PLUGIN::PI",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-SK-PI-03-P",
        "FX-SK-PI-03-N"
      ]
    },
    {
      "test_id": "TEST-D07-SK-PI-04",
      "oracle_id": "OR-D07-SK-PI-04",
      "source_ref": "A3 profile denominator::SKILL_PLUGIN::PI",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-SK-PI-04-P",
        "FX-SK-PI-04-N"
      ]
    },
    {
      "test_id": "TEST-D07-SK-PI-05",
      "oracle_id": "OR-D07-SK-PI-05",
      "source_ref": "A3 profile denominator::SKILL_PLUGIN::PI",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-SK-PI-05-P",
        "FX-SK-PI-05-N"
      ]
    },
    {
      "test_id": "TEST-D07-SK-PI-06",
      "oracle_id": "OR-D07-SK-PI-06",
      "source_ref": "A3 profile denominator::SKILL_PLUGIN::PI",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-SK-PI-06-P",
        "FX-SK-PI-06-N"
      ]
    },
    {
      "test_id": "TEST-D07-SK-PI-07",
      "oracle_id": "OR-D07-SK-PI-07",
      "source_ref": "A3 profile denominator::SKILL_PLUGIN::PI",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-SK-PI-07-P",
        "FX-SK-PI-07-N"
      ]
    },
    {
      "test_id": "TEST-D07-SK-PI-08",
      "oracle_id": "OR-D07-SK-PI-08",
      "source_ref": "A3 profile denominator::SKILL_PLUGIN::PI",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-SK-PI-08-P",
        "FX-SK-PI-08-N"
      ]
    },
    {
      "test_id": "TEST-D07-SK-PI-09",
      "oracle_id": "OR-D07-SK-PI-09",
      "source_ref": "A3 profile denominator::SKILL_PLUGIN::PI",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-SK-PI-09-P",
        "FX-SK-PI-09-N"
      ]
    },
    {
      "test_id": "TEST-D07-SK-PI-10",
      "oracle_id": "OR-D07-SK-PI-10",
      "source_ref": "A3 profile denominator::SKILL_PLUGIN::PI",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-SK-PI-10-P",
        "FX-SK-PI-10-N"
      ]
    },
    {
      "test_id": "TEST-D07-SK-PI-11",
      "oracle_id": "OR-D07-SK-PI-11",
      "source_ref": "A3 profile denominator::SKILL_PLUGIN::PI",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-SK-PI-11-P",
        "FX-SK-PI-11-N"
      ]
    },
    {
      "test_id": "TEST-D07-SK-PI-12",
      "oracle_id": "OR-D07-SK-PI-12",
      "source_ref": "A3 profile denominator::SKILL_PLUGIN::PI",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-SK-PI-12-P",
        "FX-SK-PI-12-N"
      ]
    },
    {
      "test_id": "TEST-D07-SK-PI-13",
      "oracle_id": "OR-D07-SK-PI-13",
      "source_ref": "A3 profile denominator::SKILL_PLUGIN::PI",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-SK-PI-13-P",
        "FX-SK-PI-13-N"
      ]
    },
    {
      "test_id": "TEST-D07-SK-PI-14",
      "oracle_id": "OR-D07-SK-PI-14",
      "source_ref": "A3 profile denominator::SKILL_PLUGIN::PI",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-SK-PI-14-P",
        "FX-SK-PI-14-N"
      ]
    },
    {
      "test_id": "TEST-D07-SK-PI-15",
      "oracle_id": "OR-D07-SK-PI-15",
      "source_ref": "A3 profile denominator::SKILL_PLUGIN::PI",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-SK-PI-15-P",
        "FX-SK-PI-15-N"
      ]
    },
    {
      "test_id": "TEST-D07-SK-PI-16",
      "oracle_id": "OR-D07-SK-PI-16",
      "source_ref": "A3 profile denominator::SKILL_PLUGIN::PI",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-SK-PI-16-P",
        "FX-SK-PI-16-N"
      ]
    },
    {
      "test_id": "TEST-D07-SK-PI-17",
      "oracle_id": "OR-D07-SK-PI-17",
      "source_ref": "A3 profile denominator::SKILL_PLUGIN::PI",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-SK-PI-17-P",
        "FX-SK-PI-17-N"
      ]
    },
    {
      "test_id": "TEST-D07-SK-PI-18",
      "oracle_id": "OR-D07-SK-PI-18",
      "source_ref": "A3 profile denominator::SKILL_PLUGIN::PI",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-SK-PI-18-P",
        "FX-SK-PI-18-N"
      ]
    },
    {
      "test_id": "TEST-D07-SYS-PD-01",
      "oracle_id": "OR-D07-SYS-PD-01",
      "source_ref": "A3 profile denominator::SYSTEM::PD",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-SYS-PD-01-P",
        "FX-SYS-PD-01-N"
      ]
    },
    {
      "test_id": "TEST-D07-SYS-PD-02",
      "oracle_id": "OR-D07-SYS-PD-02",
      "source_ref": "A3 profile denominator::SYSTEM::PD",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-SYS-PD-02-P",
        "FX-SYS-PD-02-N"
      ]
    },
    {
      "test_id": "TEST-D07-SYS-PD-03",
      "oracle_id": "OR-D07-SYS-PD-03",
      "source_ref": "A3 profile denominator::SYSTEM::PD",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-SYS-PD-03-P",
        "FX-SYS-PD-03-N"
      ]
    },
    {
      "test_id": "TEST-D07-SYS-PD-04",
      "oracle_id": "OR-D07-SYS-PD-04",
      "source_ref": "A3 profile denominator::SYSTEM::PD",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-SYS-PD-04-P",
        "FX-SYS-PD-04-N"
      ]
    },
    {
      "test_id": "TEST-D07-SYS-PD-05",
      "oracle_id": "OR-D07-SYS-PD-05",
      "source_ref": "A3 profile denominator::SYSTEM::PD",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-SYS-PD-05-P",
        "FX-SYS-PD-05-N"
      ]
    },
    {
      "test_id": "TEST-D07-SYS-PD-06",
      "oracle_id": "OR-D07-SYS-PD-06",
      "source_ref": "A3 profile denominator::SYSTEM::PD",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-SYS-PD-06-P",
        "FX-SYS-PD-06-N"
      ]
    },
    {
      "test_id": "TEST-D07-SYS-PD-07",
      "oracle_id": "OR-D07-SYS-PD-07",
      "source_ref": "A3 profile denominator::SYSTEM::PD",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-SYS-PD-07-P",
        "FX-SYS-PD-07-N"
      ]
    },
    {
      "test_id": "TEST-D07-SYS-PD-08",
      "oracle_id": "OR-D07-SYS-PD-08",
      "source_ref": "A3 profile denominator::SYSTEM::PD",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-SYS-PD-08-P",
        "FX-SYS-PD-08-N"
      ]
    },
    {
      "test_id": "TEST-D07-SYS-PD-09",
      "oracle_id": "OR-D07-SYS-PD-09",
      "source_ref": "A3 profile denominator::SYSTEM::PD",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-SYS-PD-09-P",
        "FX-SYS-PD-09-N"
      ]
    },
    {
      "test_id": "TEST-D07-SYS-PD-10",
      "oracle_id": "OR-D07-SYS-PD-10",
      "source_ref": "A3 profile denominator::SYSTEM::PD",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-SYS-PD-10-P",
        "FX-SYS-PD-10-N"
      ]
    },
    {
      "test_id": "TEST-D07-SYS-PD-11",
      "oracle_id": "OR-D07-SYS-PD-11",
      "source_ref": "A3 profile denominator::SYSTEM::PD",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-SYS-PD-11-P",
        "FX-SYS-PD-11-N"
      ]
    },
    {
      "test_id": "TEST-D07-SYS-PD-12",
      "oracle_id": "OR-D07-SYS-PD-12",
      "source_ref": "A3 profile denominator::SYSTEM::PD",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-SYS-PD-12-P",
        "FX-SYS-PD-12-N"
      ]
    },
    {
      "test_id": "TEST-D07-SYS-PD-13",
      "oracle_id": "OR-D07-SYS-PD-13",
      "source_ref": "A3 profile denominator::SYSTEM::PD",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-SYS-PD-13-P",
        "FX-SYS-PD-13-N"
      ]
    },
    {
      "test_id": "TEST-D07-SYS-PI-01",
      "oracle_id": "OR-D07-SYS-PI-01",
      "source_ref": "A3 profile denominator::SYSTEM::PI",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-SYS-PI-01-P",
        "FX-SYS-PI-01-N"
      ]
    },
    {
      "test_id": "TEST-D07-SYS-PI-02",
      "oracle_id": "OR-D07-SYS-PI-02",
      "source_ref": "A3 profile denominator::SYSTEM::PI",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-SYS-PI-02-P",
        "FX-SYS-PI-02-N"
      ]
    },
    {
      "test_id": "TEST-D07-SYS-PI-03",
      "oracle_id": "OR-D07-SYS-PI-03",
      "source_ref": "A3 profile denominator::SYSTEM::PI",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-SYS-PI-03-P",
        "FX-SYS-PI-03-N"
      ]
    },
    {
      "test_id": "TEST-D07-SYS-PI-04",
      "oracle_id": "OR-D07-SYS-PI-04",
      "source_ref": "A3 profile denominator::SYSTEM::PI",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-SYS-PI-04-P",
        "FX-SYS-PI-04-N"
      ]
    },
    {
      "test_id": "TEST-D07-SYS-PI-05",
      "oracle_id": "OR-D07-SYS-PI-05",
      "source_ref": "A3 profile denominator::SYSTEM::PI",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-SYS-PI-05-P",
        "FX-SYS-PI-05-N"
      ]
    },
    {
      "test_id": "TEST-D07-SYS-PI-06",
      "oracle_id": "OR-D07-SYS-PI-06",
      "source_ref": "A3 profile denominator::SYSTEM::PI",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-SYS-PI-06-P",
        "FX-SYS-PI-06-N"
      ]
    },
    {
      "test_id": "TEST-D07-SYS-PI-07",
      "oracle_id": "OR-D07-SYS-PI-07",
      "source_ref": "A3 profile denominator::SYSTEM::PI",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-SYS-PI-07-P",
        "FX-SYS-PI-07-N"
      ]
    },
    {
      "test_id": "TEST-D07-SYS-PI-08",
      "oracle_id": "OR-D07-SYS-PI-08",
      "source_ref": "A3 profile denominator::SYSTEM::PI",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-SYS-PI-08-P",
        "FX-SYS-PI-08-N"
      ]
    },
    {
      "test_id": "TEST-D07-SYS-PI-09",
      "oracle_id": "OR-D07-SYS-PI-09",
      "source_ref": "A3 profile denominator::SYSTEM::PI",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-SYS-PI-09-P",
        "FX-SYS-PI-09-N"
      ]
    },
    {
      "test_id": "TEST-D07-SYS-PI-10",
      "oracle_id": "OR-D07-SYS-PI-10",
      "source_ref": "A3 profile denominator::SYSTEM::PI",
      "applicability": "PROFILE_EXTENSION",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-SYS-PI-10-P",
        "FX-SYS-PI-10-N"
      ]
    },
    {
      "test_id": "TEST-D28A8B60",
      "oracle_id": "OR-D28A8B60",
      "source_ref": "A1 normative requirement ledger::C-14 Security Threat Model",
      "applicability": "ALL",
      "requirement_refs": [
        "STD-REQ-D28A8B60"
      ],
      "fixture_refs": [
        "FX-DRIFT-001-C04"
      ]
    },
    {
      "test_id": "TEST-D4FB7180",
      "oracle_id": "OR-D4FB7180",
      "source_ref": "A1 normative requirement ledger::24. Receiver Handoff Contract",
      "applicability": "APPLICABLE_PROFILE",
      "requirement_refs": [
        "STD-REQ-D4FB7180"
      ],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-DA5BCA25",
      "oracle_id": "OR-DA5BCA25",
      "source_ref": "A1 normative requirement ledger::P-13 Tool Success ≠ World Effect",
      "applicability": "ALL",
      "requirement_refs": [
        "STD-REQ-DA5BCA25"
      ],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-DD50D72A",
      "oracle_id": "OR-DD50D72A",
      "source_ref": "A1 normative requirement ledger::C-10 Definition of Pre-Execution Complete",
      "applicability": "APPLICABLE_PROFILE",
      "requirement_refs": [
        "STD-REQ-DD50D72A"
      ],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-DDF22230",
      "oracle_id": "OR-DDF22230",
      "source_ref": "A1 normative requirement ledger::14. PD-PKG Required Structure",
      "applicability": "APPLICABLE_PROFILE",
      "requirement_refs": [
        "STD-REQ-DDF22230"
      ],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-E0C7F7A0",
      "oracle_id": "OR-E0C7F7A0",
      "source_ref": "A1 normative requirement ledger::6. Artifact Identity & Authority Model",
      "applicability": "APPLICABLE_PROFILE",
      "requirement_refs": [
        "STD-REQ-E0C7F7A0"
      ],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-E2082905",
      "oracle_id": "OR-E2082905",
      "source_ref": "A1 normative requirement ledger::1. Normative Language / 規範語言",
      "applicability": "APPLICABLE_PROFILE",
      "requirement_refs": [
        "STD-REQ-E2082905"
      ],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-E22A8F7D",
      "oracle_id": "OR-E22A8F7D",
      "source_ref": "A1 normative requirement ledger::6. Artifact Identity & Authority Model",
      "applicability": "APPLICABLE_PROFILE",
      "requirement_refs": [
        "STD-REQ-E22A8F7D"
      ],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-E6580324",
      "oracle_id": "OR-E6580324",
      "source_ref": "A1 normative requirement ledger::46A. Informative Technology & Workflow Registry — Named Anti-Downgrade Baseline",
      "applicability": "ALL",
      "requirement_refs": [
        "STD-REQ-E6580324"
      ],
      "fixture_refs": [
        "FX-WAUTH-001",
        "FX-TAKE-001",
        "FX-TECH-001"
      ]
    },
    {
      "test_id": "TEST-E6CD4BED",
      "oracle_id": "OR-E6CD4BED",
      "source_ref": "A1 normative requirement ledger::PI-08.2 TechnologyAdmissionRecord",
      "applicability": "APPLICABLE_PROFILE",
      "requirement_refs": [
        "STD-REQ-E6CD4BED"
      ],
      "fixture_refs": [
        "FX-DRIFT-001-C05"
      ]
    },
    {
      "test_id": "TEST-EEC45EC3",
      "oracle_id": "OR-EEC45EC3",
      "source_ref": "A1 normative requirement ledger::C-05 Claim Rules",
      "applicability": "APPLICABLE_PROFILE",
      "requirement_refs": [
        "STD-REQ-EEC45EC3"
      ],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-F4669FFF",
      "oracle_id": "OR-F4669FFF",
      "source_ref": "A1 normative requirement ledger::18.4 Destructive Fixtures Required by the Standard",
      "applicability": "APPLICABLE_PROFILE",
      "requirement_refs": [
        "STD-REQ-F4669FFF"
      ],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-F4F1DD9D",
      "oracle_id": "OR-F4F1DD9D",
      "source_ref": "A1 normative requirement ledger::PD-04 Late-Bound Resolution",
      "applicability": "APPLICABLE_PROFILE",
      "requirement_refs": [
        "STD-REQ-F4F1DD9D"
      ],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-F8221F9F",
      "oracle_id": "OR-F8221F9F",
      "source_ref": "A1 normative requirement ledger::12. PI_READY Gate",
      "applicability": "ALL",
      "requirement_refs": [
        "STD-REQ-F8221F9F"
      ],
      "fixture_refs": [
        "FX-HPI-001-C02"
      ]
    },
    {
      "test_id": "TEST-FA7B1B7F",
      "oracle_id": "OR-FA7B1B7F",
      "source_ref": "A1 normative requirement ledger::6.1 Common Artifact Metadata Contract",
      "applicability": "ALL",
      "requirement_refs": [
        "STD-REQ-FA7B1B7F"
      ],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-FA8009D5",
      "oracle_id": "OR-FA8009D5",
      "source_ref": "A1 normative requirement ledger::17. EXECUTION_ADMITTED Gate",
      "applicability": "ALL",
      "requirement_refs": [
        "STD-REQ-FA8009D5"
      ],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-MUT-001",
      "oracle_id": "OR-MUT-001",
      "source_ref": "A2 §32 Mandatory Conformance Test Registry",
      "applicability": "ALL",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-MUT-001",
        "FX-HPI-001",
        "FX-HPI-001-C01"
      ]
    },
    {
      "test_id": "TEST-MUT-002",
      "oracle_id": "OR-MUT-002",
      "source_ref": "A2 §32 Mandatory Conformance Test Registry",
      "applicability": "ALL",
      "requirement_refs": [],
      "fixture_refs": [
        "DT-02-C01",
        "DT-02-C02",
        "DT-02-C03",
        "DT-02-C04",
        "DT-02-C05",
        "DT-02-C06"
      ]
    },
    {
      "test_id": "TEST-MUT-003",
      "oracle_id": "OR-MUT-003",
      "source_ref": "A2 §32 Mandatory Conformance Test Registry",
      "applicability": "ALL",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-HPD-001",
        "DT-04-C01",
        "DT-04-C02",
        "DT-04-C03",
        "DT-04-C04"
      ]
    },
    {
      "test_id": "TEST-MUT-004",
      "oracle_id": "OR-MUT-004",
      "source_ref": "A2 §32 Mandatory Conformance Test Registry",
      "applicability": "ALL",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-HO-001",
        "DT-05-C01",
        "DT-05-C02"
      ]
    },
    {
      "test_id": "TEST-MUT-005",
      "oracle_id": "OR-MUT-005",
      "source_ref": "A2 §32 Mandatory Conformance Test Registry",
      "applicability": "ALL",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-FPASS-001",
        "DT-06-C01",
        "DT-06-C02",
        "DT-06-C03",
        "DT-06-C04",
        "FX-FPASS-001-C01",
        "FX-FPASS-001-C02",
        "FX-FPASS-001-C03",
        "FX-FPASS-001-C04"
      ]
    },
    {
      "test_id": "TEST-MUT-006",
      "oracle_id": "OR-MUT-006",
      "source_ref": "A2 §32 Mandatory Conformance Test Registry",
      "applicability": "ALL",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-IDCOL-001",
        "DT-08-C01",
        "DT-08-C02",
        "DT-08-C03"
      ]
    },
    {
      "test_id": "TEST-MUT-007",
      "oracle_id": "OR-MUT-007",
      "source_ref": "A2 §32 Mandatory Conformance Test Registry",
      "applicability": "ALL",
      "requirement_refs": [],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-MUT-008",
      "oracle_id": "OR-MUT-008",
      "source_ref": "A2 §32 Mandatory Conformance Test Registry",
      "applicability": "ALL",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-APPR-001",
        "DT-09-C01",
        "FX-APPR-001-C01"
      ]
    },
    {
      "test_id": "TEST-MUT-009",
      "oracle_id": "OR-MUT-009",
      "source_ref": "A2 §32 Mandatory Conformance Test Registry",
      "applicability": "ALL",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-EFFECT-001",
        "DT-10-C01"
      ]
    },
    {
      "test_id": "TEST-NTR-001",
      "oracle_id": "OR-NTR-001",
      "source_ref": "A2 §32 Mandatory Conformance Test Registry",
      "applicability": "ALL",
      "requirement_refs": [],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-PRT-001",
      "oracle_id": "OR-PRT-001",
      "source_ref": "A2 §32 Mandatory Conformance Test Registry",
      "applicability": "ALL",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-PRT-001"
      ]
    },
    {
      "test_id": "TEST-PRT-002",
      "oracle_id": "OR-PRT-002",
      "source_ref": "A2 §32 Mandatory Conformance Test Registry",
      "applicability": "ALL",
      "requirement_refs": [],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-RET-001",
      "oracle_id": "OR-RET-001",
      "source_ref": "A2 §32 Mandatory Conformance Test Registry",
      "applicability": "ALL",
      "requirement_refs": [],
      "fixture_refs": []
    },
    {
      "test_id": "TEST-RET-002",
      "oracle_id": "OR-RET-002",
      "source_ref": "A2 §32 Mandatory Conformance Test Registry",
      "applicability": "ALL",
      "requirement_refs": [],
      "fixture_refs": [
        "FX-STALE-001"
      ]
    },
    {
      "test_id": "TEST-TRG-001",
      "oracle_id": "OR-TRG-001",
      "source_ref": "A2 §32 Mandatory Conformance Test Registry",
      "applicability": "ALL",
      "requirement_refs": [],
      "fixture_refs": []
    }
  ],
  "oracles": [
    {
      "oracle_id": "OR-06583027",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-06583027 (PI-10 SPEC) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::PI-10 SPEC"
    },
    {
      "oracle_id": "OR-0B4D6B1E",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-0B4D6B1E (23. Target Profile — Agent Harness / Agentic Runtime) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::23. Target Profile — Agent Harness / Agentic Runtime"
    },
    {
      "oracle_id": "OR-0C5B13B3",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-0C5B13B3 (23. Target Profile — Agent Harness / Agentic Runtime) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::23. Target Profile — Agent Harness / Agentic Runtime"
    },
    {
      "oracle_id": "OR-0CB9A2A0",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-0CB9A2A0 (C-09 Tailoring Profile) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::C-09 Tailoring Profile"
    },
    {
      "oracle_id": "OR-0E1DBA46",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-0E1DBA46 (P-10 Handoff Must Be Rejectable) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::P-10 Handoff Must Be Rejectable"
    },
    {
      "oracle_id": "OR-10C6C743",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-10C6C743 (C-12 DomainProfileExtension) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::C-12 DomainProfileExtension"
    },
    {
      "oracle_id": "OR-119B9088",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-119B9088 (C-04 Lifecycle States) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::C-04 Lifecycle States"
    },
    {
      "oracle_id": "OR-11B19333",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-11B19333 (6.2 Authority and Adapter Non-Override Rule) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::6.2 Authority and Adapter Non-Override Rule"
    },
    {
      "oracle_id": "OR-1859D4F5",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-1859D4F5 (PD-06 DEV ECP — Development Execution Control) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::PD-06 DEV ECP — Development Execution Control"
    },
    {
      "oracle_id": "OR-22E53BD2",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-22E53BD2 (25. Evidence Return Contract) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::25. Evidence Return Contract"
    },
    {
      "oracle_id": "OR-27A2EA7F",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-27A2EA7F (PI-05 Atomic Requirements) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::PI-05 Atomic Requirements"
    },
    {
      "oracle_id": "OR-28163C14",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-28163C14 (20.4 Machine Profile Binding) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::20.4 Machine Profile Binding"
    },
    {
      "oracle_id": "OR-2A89F996",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-2A89F996 (P-14 Segregation of Duties) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::P-14 Segregation of Duties"
    },
    {
      "oracle_id": "OR-2E59E411",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-2E59E411 (23A. World Effect / Observation / Readback / Reconciliation) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::23A. World Effect / Observation / Readback / Reconciliation"
    },
    {
      "oracle_id": "OR-2FF7F879",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-2FF7F879 (PD-06 DEV ECP — Development Execution Control) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::PD-06 DEV ECP — Development Execution Control"
    },
    {
      "oracle_id": "OR-3235004D",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-3235004D (21.2 BrownfieldMigrationProfile) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::21.2 BrownfieldMigrationProfile"
    },
    {
      "oracle_id": "OR-37150A4D",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-37150A4D (28. Canonical Standard vs Adapter) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::28. Canonical Standard vs Adapter"
    },
    {
      "oracle_id": "OR-38EB8516",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-38EB8516 (18.1 Extraction Manifest) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::18.1 Extraction Manifest"
    },
    {
      "oracle_id": "OR-3CA02A9C",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-3CA02A9C (22. Target Profile — SKILL / PLUGIN) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::22. Target Profile — SKILL / PLUGIN"
    },
    {
      "oracle_id": "OR-44B56684",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-44B56684 (50. Final Normative Statement) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::50. Final Normative Statement"
    },
    {
      "oracle_id": "OR-454A6D90",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-454A6D90 (C-02 Authority Stack) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::C-02 Authority Stack"
    },
    {
      "oracle_id": "OR-4AAA061A",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-4AAA061A (P-09 Complexity Must Earn Complexity) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::P-09 Complexity Must Earn Complexity"
    },
    {
      "oracle_id": "OR-522701F0",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-522701F0 (PI-08.1 Mandatory Search-Before-Build algorithm) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::PI-08.1 Mandatory Search-Before-Build algorithm"
    },
    {
      "oracle_id": "OR-5868D53A",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-5868D53A (9. PI-PKG Required Contract Areas) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::9. PI-PKG Required Contract Areas"
    },
    {
      "oracle_id": "OR-59414E50",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-59414E50 (18.3 Deterministic Conformance Reference Command) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::18.3 Deterministic Conformance Reference Command"
    },
    {
      "oracle_id": "OR-59D1DD6F",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-59D1DD6F (C-11 Standard Namespace / Schema Compatibility) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::C-11 Standard Namespace / Schema Compatibility"
    },
    {
      "oracle_id": "OR-5AADF6A3",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-5AADF6A3 (PI-14 Deliverables) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::PI-14 Deliverables"
    },
    {
      "oracle_id": "OR-5E28F98D",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-5E28F98D (PI-13 Evidence Expectation) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::PI-13 Evidence Expectation"
    },
    {
      "oracle_id": "OR-5EFF0181",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-5EFF0181 (C-02 Authority Stack) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::C-02 Authority Stack"
    },
    {
      "oracle_id": "OR-61E2C648",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-61E2C648 (PD-08 TQAEP — Test / Qualification / Acceptance / Evidence Plan) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::PD-08 TQAEP — Test / Qualification / Acceptance / Evidence Plan"
    },
    {
      "oracle_id": "OR-689DE502",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-689DE502 (P-03 Stable Semantics vs Late-Bound Facts) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::P-03 Stable Semantics vs Late-Bound Facts"
    },
    {
      "oracle_id": "OR-6CCE644F",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-6CCE644F (C-03 Canonical Ownership) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::C-03 Canonical Ownership"
    },
    {
      "oracle_id": "OR-6E492151",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-6E492151 (PD-08 TQAEP — Test / Qualification / Acceptance / Evidence Plan) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::PD-08 TQAEP — Test / Qualification / Acceptance / Evidence Plan"
    },
    {
      "oracle_id": "OR-6E714CAB",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-6E714CAB (PI-17 Claim Ceiling / State Truth) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::PI-17 Claim Ceiling / State Truth"
    },
    {
      "oracle_id": "OR-6F8DCD42",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-6F8DCD42 (47. External Alignment / Informative Research Notes) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::47. External Alignment / Informative Research Notes"
    },
    {
      "oracle_id": "OR-7468B275",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-7468B275 (PD-05 S2E — Spec-to-Execution) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::PD-05 S2E — Spec-to-Execution"
    },
    {
      "oracle_id": "OR-75B304BB",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-75B304BB (PD-10 Execution Admission) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::PD-10 Execution Admission"
    },
    {
      "oracle_id": "OR-7894BFB5",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-7894BFB5 (26.2 External Content Is Data) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::26.2 External Content Is Data"
    },
    {
      "oracle_id": "OR-79A6948B",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-79A6948B (P-07 Evidence Is Subject-Bound) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::P-07 Evidence Is Subject-Bound"
    },
    {
      "oracle_id": "OR-7B3AB9E9",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-7B3AB9E9 (C-01 Project / Product Identity) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::C-01 Project / Product Identity"
    },
    {
      "oracle_id": "OR-7CD1E5E6",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-7CD1E5E6 (26.7 SoD Enforcement) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::26.7 SoD Enforcement"
    },
    {
      "oracle_id": "OR-7CEA782A",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-7CEA782A (PD-05A TaskSpecSeed) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::PD-05A TaskSpecSeed"
    },
    {
      "oracle_id": "OR-81C86EBB",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-81C86EBB (6. Artifact Identity & Authority Model) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::6. Artifact Identity & Authority Model"
    },
    {
      "oracle_id": "OR-829B7605",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-829B7605 (7.1 Purpose) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::7.1 Purpose"
    },
    {
      "oracle_id": "OR-86CAC54E",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-86CAC54E (26.4 Agent Memory) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::26.4 Agent Memory"
    },
    {
      "oracle_id": "OR-8A8EDC94",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-8A8EDC94 (10. Requirement Narrow Waist) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::10. Requirement Narrow Waist"
    },
    {
      "oracle_id": "OR-90364E5B",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-90364E5B (C-12 DomainProfileExtension) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::C-12 DomainProfileExtension"
    },
    {
      "oracle_id": "OR-92132DB3",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-92132DB3 (13. PD-PKG Canonical Purpose) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::13. PD-PKG Canonical Purpose"
    },
    {
      "oracle_id": "OR-93766574",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-93766574 (PD-05B WorkOrder Materialization) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::PD-05B WorkOrder Materialization"
    },
    {
      "oracle_id": "OR-979740C9",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-979740C9 (1. Normative Language / 規範語言) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::1. Normative Language / 規範語言"
    },
    {
      "oracle_id": "OR-97BCACAC",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-97BCACAC (32. Mandatory Conformance Test Registry) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::32. Mandatory Conformance Test Registry"
    },
    {
      "oracle_id": "OR-98BC2330",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-98BC2330 (P-11 Capability-Before-Brand / Search-Before-Build) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::P-11 Capability-Before-Brand / Search-Before-Build"
    },
    {
      "oracle_id": "OR-98F459F8",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-98F459F8 (1. Normative Language / 規範語言) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::1. Normative Language / 規範語言"
    },
    {
      "oracle_id": "OR-9DF08F85",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-9DF08F85 (PD-07 OPS ECP — Operations Readiness & Execution Control) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::PD-07 OPS ECP — Operations Readiness & Execution Control"
    },
    {
      "oracle_id": "OR-9E161B60",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-9E161B60 (C-11 Standard Namespace / Schema Compatibility) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::C-11 Standard Namespace / Schema Compatibility"
    },
    {
      "oracle_id": "OR-9E4AFAC1",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-9E4AFAC1 (8. PI-PKG Canonical Purpose) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::8. PI-PKG Canonical Purpose"
    },
    {
      "oracle_id": "OR-ABD8745E",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-ABD8745E (P-05 No Execution by Documentation) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::P-05 No Execution by Documentation"
    },
    {
      "oracle_id": "OR-ABE182D6",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-ABE182D6 (8. PI-PKG Canonical Purpose) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::8. PI-PKG Canonical Purpose"
    },
    {
      "oracle_id": "OR-B0C02A64",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-B0C02A64 (5.2 Promotion Rule) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::5.2 Promotion Rule"
    },
    {
      "oracle_id": "OR-B1C9AB85",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-B1C9AB85 (P-01 Single Canonical Truth) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::P-01 Single Canonical Truth"
    },
    {
      "oracle_id": "OR-B4D1C8EA",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-B4D1C8EA (PI-12 Verification / Oracle) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::PI-12 Verification / Oracle"
    },
    {
      "oracle_id": "OR-B5C7D219",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-B5C7D219 (22.1 Skill/Plugin Conformance Additions) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::22.1 Skill/Plugin Conformance Additions"
    },
    {
      "oracle_id": "OR-B88A6D37",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-B88A6D37 (P-02 Source-Bound Intent Preservation) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::P-02 Source-Bound Intent Preservation"
    },
    {
      "oracle_id": "OR-BA1FB472",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-BA1FB472 (PD-05 S2E — Spec-to-Execution) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::PD-05 S2E — Spec-to-Execution"
    },
    {
      "oracle_id": "OR-BF0442B3",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-BF0442B3 (22. Target Profile — SKILL / PLUGIN) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::22. Target Profile — SKILL / PLUGIN"
    },
    {
      "oracle_id": "OR-BND-001",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff denied / no mutation; trigger/fixture: attempt repo write at PI_READY.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A2 §32 Mandatory Conformance Test Registry"
    },
    {
      "oracle_id": "OR-BND-002",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff fail identity boundary; trigger/fixture: attempt S2E as execution authority.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A2 §32 Mandatory Conformance Test Registry"
    },
    {
      "oracle_id": "OR-BND-003",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff deny; trigger/fixture: ECP maker self-approves high-risk action.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A2 §32 Mandatory Conformance Test Registry"
    },
    {
      "oracle_id": "OR-C25BC6A2",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-C25BC6A2 (6. Artifact Identity & Authority Model) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::6. Artifact Identity & Authority Model"
    },
    {
      "oracle_id": "OR-C49B66DE",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-C49B66DE (PI-11 Acceptance) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::PI-11 Acceptance"
    },
    {
      "oracle_id": "OR-C5BCA382",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-C5BCA382 (P-15 Prose/Machine Gate Equivalence) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::P-15 Prose/Machine Gate Equivalence"
    },
    {
      "oracle_id": "OR-C6A9781D",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-C6A9781D (P-06 Claim Separation) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::P-06 Claim Separation"
    },
    {
      "oracle_id": "OR-C887276E",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-C887276E (PI-18 Pre-Dev Handoff) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::PI-18 Pre-Dev Handoff"
    },
    {
      "oracle_id": "OR-CMP-001",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff all PI gates/schema/semantic rules pass; trigger/fixture: complete PI package.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A2 §32 Mandatory Conformance Test Registry"
    },
    {
      "oracle_id": "OR-CMP-002",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff all PD gates/schema/semantic rules pass; trigger/fixture: complete PD package.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A2 §32 Mandatory Conformance Test Registry"
    },
    {
      "oracle_id": "OR-D07-AH-PD-01",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff AH-PD-01 runtime/framework version is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::AGENT_HARNESS::PD"
    },
    {
      "oracle_id": "OR-D07-AH-PD-02",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff AH-PD-02 model/provider is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::AGENT_HARNESS::PD"
    },
    {
      "oracle_id": "OR-D07-AH-PD-03",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff AH-PD-03 MCP version/profile is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::AGENT_HARNESS::PD"
    },
    {
      "oracle_id": "OR-D07-AH-PD-04",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff AH-PD-04 A2A version/profile is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::AGENT_HARNESS::PD"
    },
    {
      "oracle_id": "OR-D07-AH-PD-05",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff AH-PD-05 sandbox/container is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::AGENT_HARNESS::PD"
    },
    {
      "oracle_id": "OR-D07-AH-PD-06",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff AH-PD-06 state backend is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::AGENT_HARNESS::PD"
    },
    {
      "oracle_id": "OR-D07-AH-PD-07",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff AH-PD-07 memory store is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::AGENT_HARNESS::PD"
    },
    {
      "oracle_id": "OR-D07-AH-PD-08",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff AH-PD-08 tracing backend is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::AGENT_HARNESS::PD"
    },
    {
      "oracle_id": "OR-D07-AH-PD-09",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff AH-PD-09 secret handles is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::AGENT_HARNESS::PD"
    },
    {
      "oracle_id": "OR-D07-AH-PD-10",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff AH-PD-10 tool schemas is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::AGENT_HARNESS::PD"
    },
    {
      "oracle_id": "OR-D07-AH-PD-11",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff AH-PD-11 timeouts/retry/checkpoint is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::AGENT_HARNESS::PD"
    },
    {
      "oracle_id": "OR-D07-AH-PD-12",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff AH-PD-12 eval harness is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::AGENT_HARNESS::PD"
    },
    {
      "oracle_id": "OR-D07-AH-PD-13",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff AH-PD-13 deployment environment is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::AGENT_HARNESS::PD"
    },
    {
      "oracle_id": "OR-D07-AH-PI-01",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff AH-PI-01 identity/role is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::AGENT_HARNESS::PI"
    },
    {
      "oracle_id": "OR-D07-AH-PI-02",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff AH-PI-02 execution loop is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::AGENT_HARNESS::PI"
    },
    {
      "oracle_id": "OR-D07-AH-PI-03",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff AH-PI-03 tool registry is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::AGENT_HARNESS::PI"
    },
    {
      "oracle_id": "OR-D07-AH-PI-04",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff AH-PI-04 context policy is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::AGENT_HARNESS::PI"
    },
    {
      "oracle_id": "OR-D07-AH-PI-05",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff AH-PI-05 state/memory is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::AGENT_HARNESS::PI"
    },
    {
      "oracle_id": "OR-D07-AH-PI-06",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff AH-PI-06 lifecycle hooks is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::AGENT_HARNESS::PI"
    },
    {
      "oracle_id": "OR-D07-AH-PI-07",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff AH-PI-07 permission/identity is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::AGENT_HARNESS::PI"
    },
    {
      "oracle_id": "OR-D07-AH-PI-08",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff AH-PI-08 handoff is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::AGENT_HARNESS::PI"
    },
    {
      "oracle_id": "OR-D07-AH-PI-09",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff AH-PI-09 guardrails is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::AGENT_HARNESS::PI"
    },
    {
      "oracle_id": "OR-D07-AH-PI-10",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff AH-PI-10 eval interface is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::AGENT_HARNESS::PI"
    },
    {
      "oracle_id": "OR-D07-AH-PI-11",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff AH-PI-11 observability is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::AGENT_HARNESS::PI"
    },
    {
      "oracle_id": "OR-D07-AH-PI-12",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff AH-PI-12 recovery/checkpoint is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::AGENT_HARNESS::PI"
    },
    {
      "oracle_id": "OR-D07-AH-PI-13",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff AH-PI-13 human escalation is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::AGENT_HARNESS::PI"
    },
    {
      "oracle_id": "OR-D07-AH-PI-14",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff AH-PI-14 interop boundaries is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::AGENT_HARNESS::PI"
    },
    {
      "oracle_id": "OR-D07-AH-PI-15",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff AH-PI-15 provider-neutral seam is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::AGENT_HARNESS::PI"
    },
    {
      "oracle_id": "OR-D07-SK-PD-01",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff SK-PD-01 Exact host/runtime/package versions is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::SKILL_PLUGIN::PD"
    },
    {
      "oracle_id": "OR-D07-SK-PD-02",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff SK-PD-02 Install/publish layout is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::SKILL_PLUGIN::PD"
    },
    {
      "oracle_id": "OR-D07-SK-PD-03",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff SK-PD-03 Dependency lock is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::SKILL_PLUGIN::PD"
    },
    {
      "oracle_id": "OR-D07-SK-PD-04",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff SK-PD-04 Sandbox is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::SKILL_PLUGIN::PD"
    },
    {
      "oracle_id": "OR-D07-SK-PD-05",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff SK-PD-05 Credential handles metadata is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::SKILL_PLUGIN::PD"
    },
    {
      "oracle_id": "OR-D07-SK-PD-06",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff SK-PD-06 Network boundary is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::SKILL_PLUGIN::PD"
    },
    {
      "oracle_id": "OR-D07-SK-PD-07",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff SK-PD-07 Validation is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::SKILL_PLUGIN::PD"
    },
    {
      "oracle_id": "OR-D07-SK-PD-08",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff SK-PD-08 Uninstall/rollback is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::SKILL_PLUGIN::PD"
    },
    {
      "oracle_id": "OR-D07-SK-PD-09",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff SK-PD-09 Residue check is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::SKILL_PLUGIN::PD"
    },
    {
      "oracle_id": "OR-D07-SK-PD-10",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff SK-PD-10 Host-specific permissions is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::SKILL_PLUGIN::PD"
    },
    {
      "oracle_id": "OR-D07-SK-PD-11",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff SK-PD-11 Exact tool schema is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::SKILL_PLUGIN::PD"
    },
    {
      "oracle_id": "OR-D07-SK-PD-12",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff SK-PD-12 Currentness TTL is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::SKILL_PLUGIN::PD"
    },
    {
      "oracle_id": "OR-D07-SK-PI-01",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff SK-PI-01 Trigger is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::SKILL_PLUGIN::PI"
    },
    {
      "oracle_id": "OR-D07-SK-PI-02",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff SK-PI-02 Non-trigger is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::SKILL_PLUGIN::PI"
    },
    {
      "oracle_id": "OR-D07-SK-PI-03",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff SK-PI-03 Inputs is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::SKILL_PLUGIN::PI"
    },
    {
      "oracle_id": "OR-D07-SK-PI-04",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff SK-PI-04 Outputs is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::SKILL_PLUGIN::PI"
    },
    {
      "oracle_id": "OR-D07-SK-PI-05",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff SK-PI-05 Allowed tools is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::SKILL_PLUGIN::PI"
    },
    {
      "oracle_id": "OR-D07-SK-PI-06",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff SK-PI-06 Permission classes is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::SKILL_PLUGIN::PI"
    },
    {
      "oracle_id": "OR-D07-SK-PI-07",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff SK-PI-07 Compatibility is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::SKILL_PLUGIN::PI"
    },
    {
      "oracle_id": "OR-D07-SK-PI-08",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff SK-PI-08 Dependencies is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::SKILL_PLUGIN::PI"
    },
    {
      "oracle_id": "OR-D07-SK-PI-09",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff SK-PI-09 Side-effect classes is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::SKILL_PLUGIN::PI"
    },
    {
      "oracle_id": "OR-D07-SK-PI-10",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff SK-PI-10 Secret/network policy is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::SKILL_PLUGIN::PI"
    },
    {
      "oracle_id": "OR-D07-SK-PI-11",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff SK-PI-11 Failure behavior is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::SKILL_PLUGIN::PI"
    },
    {
      "oracle_id": "OR-D07-SK-PI-12",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff SK-PI-12 Negative cases is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::SKILL_PLUGIN::PI"
    },
    {
      "oracle_id": "OR-D07-SK-PI-13",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff SK-PI-13 Examples is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::SKILL_PLUGIN::PI"
    },
    {
      "oracle_id": "OR-D07-SK-PI-14",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff SK-PI-14 Host boundary is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::SKILL_PLUGIN::PI"
    },
    {
      "oracle_id": "OR-D07-SK-PI-15",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff SK-PI-15 Host assumptions is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::SKILL_PLUGIN::PI"
    },
    {
      "oracle_id": "OR-D07-SK-PI-16",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff SK-PI-16 Dependency/rights provenance is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::SKILL_PLUGIN::PI"
    },
    {
      "oracle_id": "OR-D07-SK-PI-17",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff SK-PI-17 Uninstall/disable semantics is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::SKILL_PLUGIN::PI"
    },
    {
      "oracle_id": "OR-D07-SK-PI-18",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff SK-PI-18 Evidence return is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::SKILL_PLUGIN::PI"
    },
    {
      "oracle_id": "OR-D07-SYS-PD-01",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff SYS-PD-01 RepoContext is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::SYSTEM::PD"
    },
    {
      "oracle_id": "OR-D07-SYS-PD-02",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff SYS-PD-02 Toolchain is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::SYSTEM::PD"
    },
    {
      "oracle_id": "OR-D07-SYS-PD-03",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff SYS-PD-03 DB/data migration is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::SYSTEM::PD"
    },
    {
      "oracle_id": "OR-D07-SYS-PD-04",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff SYS-PD-04 CI is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::SYSTEM::PD"
    },
    {
      "oracle_id": "OR-D07-SYS-PD-05",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff SYS-PD-05 Deployment topology is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::SYSTEM::PD"
    },
    {
      "oracle_id": "OR-D07-SYS-PD-06",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff SYS-PD-06 Observability is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::SYSTEM::PD"
    },
    {
      "oracle_id": "OR-D07-SYS-PD-07",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff SYS-PD-07 Environment config is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::SYSTEM::PD"
    },
    {
      "oracle_id": "OR-D07-SYS-PD-08",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff SYS-PD-08 Rollback/provider-off is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::SYSTEM::PD"
    },
    {
      "oracle_id": "OR-D07-SYS-PD-09",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff SYS-PD-09 SLO instrumentation is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::SYSTEM::PD"
    },
    {
      "oracle_id": "OR-D07-SYS-PD-10",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff SYS-PD-10 Incident/runbook is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::SYSTEM::PD"
    },
    {
      "oracle_id": "OR-D07-SYS-PD-11",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff SYS-PD-11 DR/RTO/RPO is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::SYSTEM::PD"
    },
    {
      "oracle_id": "OR-D07-SYS-PD-12",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff SYS-PD-12 Capacity/cost/FinOps is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::SYSTEM::PD"
    },
    {
      "oracle_id": "OR-D07-SYS-PD-13",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff SYS-PD-13 Secret revoke/rotation is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::SYSTEM::PD"
    },
    {
      "oracle_id": "OR-D07-SYS-PI-01",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff SYS-PI-01 Product/user outcome is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::SYSTEM::PI"
    },
    {
      "oracle_id": "OR-D07-SYS-PI-02",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff SYS-PI-02 Domain model is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::SYSTEM::PI"
    },
    {
      "oracle_id": "OR-D07-SYS-PI-03",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff SYS-PI-03 Architecture is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::SYSTEM::PI"
    },
    {
      "oracle_id": "OR-D07-SYS-PI-04",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff SYS-PI-04 API contracts is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::SYSTEM::PI"
    },
    {
      "oracle_id": "OR-D07-SYS-PI-05",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff SYS-PI-05 Data contracts is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::SYSTEM::PI"
    },
    {
      "oracle_id": "OR-D07-SYS-PI-06",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff SYS-PI-06 SLO/NFR is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::SYSTEM::PI"
    },
    {
      "oracle_id": "OR-D07-SYS-PI-07",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff SYS-PI-07 Security/privacy is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::SYSTEM::PI"
    },
    {
      "oracle_id": "OR-D07-SYS-PI-08",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff SYS-PI-08 Migration/backcompat is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::SYSTEM::PI"
    },
    {
      "oracle_id": "OR-D07-SYS-PI-09",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff SYS-PI-09 Acceptance/testability is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::SYSTEM::PI"
    },
    {
      "oracle_id": "OR-D07-SYS-PI-10",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff SYS-PI-10 Operability intent is present, exact/bound for the profile, verifiable, and not replaced by unsupported N/A; known-bad omission/mismatch MUST FAIL.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A3 profile denominator::SYSTEM::PI"
    },
    {
      "oracle_id": "OR-D28A8B60",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-D28A8B60 (C-14 Security Threat Model) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::C-14 Security Threat Model"
    },
    {
      "oracle_id": "OR-D4FB7180",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-D4FB7180 (24. Receiver Handoff Contract) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::24. Receiver Handoff Contract"
    },
    {
      "oracle_id": "OR-DA5BCA25",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-DA5BCA25 (P-13 Tool Success ≠ World Effect) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::P-13 Tool Success ≠ World Effect"
    },
    {
      "oracle_id": "OR-DD50D72A",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-DD50D72A (C-10 Definition of Pre-Execution Complete) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::C-10 Definition of Pre-Execution Complete"
    },
    {
      "oracle_id": "OR-DDF22230",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-DDF22230 (14. PD-PKG Required Structure) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::14. PD-PKG Required Structure"
    },
    {
      "oracle_id": "OR-E0C7F7A0",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-E0C7F7A0 (6. Artifact Identity & Authority Model) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::6. Artifact Identity & Authority Model"
    },
    {
      "oracle_id": "OR-E2082905",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-E2082905 (1. Normative Language / 規範語言) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::1. Normative Language / 規範語言"
    },
    {
      "oracle_id": "OR-E22A8F7D",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-E22A8F7D (6. Artifact Identity & Authority Model) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::6. Artifact Identity & Authority Model"
    },
    {
      "oracle_id": "OR-E6580324",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-E6580324 (46A. Informative Technology & Workflow Registry — Named Anti-Downgrade Baseline) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::46A. Informative Technology & Workflow Registry — Named Anti-Downgrade Baseline"
    },
    {
      "oracle_id": "OR-E6CD4BED",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-E6CD4BED (PI-08.2 TechnologyAdmissionRecord) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::PI-08.2 TechnologyAdmissionRecord"
    },
    {
      "oracle_id": "OR-EEC45EC3",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-EEC45EC3 (C-05 Claim Rules) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::C-05 Claim Rules"
    },
    {
      "oracle_id": "OR-F4669FFF",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-F4669FFF (18.4 Destructive Fixtures Required by the Standard) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::18.4 Destructive Fixtures Required by the Standard"
    },
    {
      "oracle_id": "OR-F4F1DD9D",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-F4F1DD9D (PD-04 Late-Bound Resolution) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::PD-04 Late-Bound Resolution"
    },
    {
      "oracle_id": "OR-F8221F9F",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-F8221F9F (12. PI_READY Gate) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::12. PI_READY Gate"
    },
    {
      "oracle_id": "OR-FA7B1B7F",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-FA7B1B7F (6.1 Common Artifact Metadata Contract) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::6.1 Common Artifact Metadata Contract"
    },
    {
      "oracle_id": "OR-FA8009D5",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical predicate for STD-REQ-FA8009D5 (17. EXECUTION_ADMITTED Gate) is satisfied on the exact bound subject; otherwise FAIL/HOLD per owning state semantics.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A1 normative requirement ledger::17. EXECUTION_ADMITTED Gate"
    },
    {
      "oracle_id": "OR-MUT-001",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff schema/validator FAIL; trigger/fixture: PI_READY requirements=[].",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A2 §32 Mandatory Conformance Test Registry"
    },
    {
      "oracle_id": "OR-MUT-002",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff FAIL; trigger/fixture: remove VER/EVD/DEL/GATE from CURRENT trace.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A2 §32 Mandatory Conformance Test Registry"
    },
    {
      "oracle_id": "OR-MUT-003",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff FAIL; trigger/fixture: PD core object={}.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A2 §32 Mandatory Conformance Test Registry"
    },
    {
      "oracle_id": "OR-MUT-004",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff FAIL; trigger/fixture: handoff required arrays empty.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A2 §32 Mandatory Conformance Test Registry"
    },
    {
      "oracle_id": "OR-MUT-005",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff FAIL; trigger/fixture: fake PASS evidence.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A2 §32 Mandatory Conformance Test Registry"
    },
    {
      "oracle_id": "OR-MUT-006",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff FAIL; trigger/fixture: alias Seed/WorkOrder/ECP IDs.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A2 §32 Mandatory Conformance Test Registry"
    },
    {
      "oracle_id": "OR-MUT-007",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff FAIL; trigger/fixture: BUILD_MINIMAL without no-fit proof.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A2 §32 Mandatory Conformance Test Registry"
    },
    {
      "oracle_id": "OR-MUT-008",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff FAIL; trigger/fixture: high-risk ADMIT without token.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A2 §32 Mandatory Conformance Test Registry"
    },
    {
      "oracle_id": "OR-MUT-009",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff stays UNKNOWN_EFFECT / FAIL promotion; trigger/fixture: provider 2xx but no effect readback.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A2 §32 Mandatory Conformance Test Registry"
    },
    {
      "oracle_id": "OR-NTR-001",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff workflow not over-applied; trigger/fixture: trivial explanation/no construction.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A2 §32 Mandatory Conformance Test Registry"
    },
    {
      "oracle_id": "OR-PRT-001",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff semantic required fields/gates unchanged; trigger/fixture: run same PI/PD fixture with second LLM/harness.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A2 §32 Mandatory Conformance Test Registry"
    },
    {
      "oracle_id": "OR-PRT-002",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff canonical package still interpretable; trigger/fixture: adapter removed.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A2 §32 Mandatory Conformance Test Registry"
    },
    {
      "oracle_id": "OR-RET-001",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff abstain/TEMP_CLOSED, no raw-volume invention; trigger/fixture: normative source anchor missing.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A2 §32 Mandatory Conformance Test Registry"
    },
    {
      "oracle_id": "OR-RET-002",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff dependent claim invalidated; trigger/fixture: stale source hash.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A2 §32 Mandatory Conformance Test Registry"
    },
    {
      "oracle_id": "OR-TRG-001",
      "oracle_type": "DETERMINISTIC",
      "decision_rule": "PASS iff PI/PD workflow selected; trigger/fixture: new non-trivial system/feature.",
      "first_failing_invariant_order": [
        "IDENTITY",
        "SCHEMA",
        "CURRENTNESS",
        "SEMANTIC",
        "PERMISSION",
        "EFFECT",
        "PROFILE",
        "EVIDENCE"
      ],
      "stale_evidence_policy": "REJECT",
      "source_ref": "A2 §32 Mandatory Conformance Test Registry"
    }
  ],
  "fixtures": [
    {
      "fixture_id": "DT-02-C01",
      "class": "MUTATION",
      "source_ref": "AUDIT atomicization::DT-02",
      "test_ref": "TEST-MUT-002",
      "oracle_ref": "OR-MUT-002",
      "construction": "remove VER from CURRENT trace",
      "invariant": "TRACE_VER_MISSING",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "TRACE_VER_MISSING",
      "environment_binding": "known-good baseline + exactly one controlled child mutation",
      "evidence_expectation": "exit=3; deterministic FFI=TRACE_VER_MISSING; normalized ConformanceReport",
      "invalidation_trigger": "validator/oracle/schema/profile/permission/effect semantics change"
    },
    {
      "fixture_id": "DT-02-C02",
      "class": "MUTATION",
      "source_ref": "AUDIT atomicization::DT-02",
      "test_ref": "TEST-MUT-002",
      "oracle_ref": "OR-MUT-002",
      "construction": "remove EVD_EXPECTATION from CURRENT trace",
      "invariant": "TRACE_EVD_EXPECTATION_MISSING",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "TRACE_EVD_EXPECTATION_MISSING",
      "environment_binding": "known-good baseline + exactly one controlled child mutation",
      "evidence_expectation": "exit=3; deterministic FFI=TRACE_EVD_EXPECTATION_MISSING; normalized ConformanceReport",
      "invalidation_trigger": "validator/oracle/schema/profile/permission/effect semantics change"
    },
    {
      "fixture_id": "DT-02-C03",
      "class": "MUTATION",
      "source_ref": "AUDIT atomicization::DT-02",
      "test_ref": "TEST-MUT-002",
      "oracle_ref": "OR-MUT-002",
      "construction": "remove DEL from CURRENT trace",
      "invariant": "TRACE_DEL_MISSING",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "TRACE_DEL_MISSING",
      "environment_binding": "known-good baseline + exactly one controlled child mutation",
      "evidence_expectation": "exit=3; deterministic FFI=TRACE_DEL_MISSING; normalized ConformanceReport",
      "invalidation_trigger": "validator/oracle/schema/profile/permission/effect semantics change"
    },
    {
      "fixture_id": "DT-02-C04",
      "class": "MUTATION",
      "source_ref": "AUDIT atomicization::DT-02",
      "test_ref": "TEST-MUT-002",
      "oracle_ref": "OR-MUT-002",
      "construction": "remove GATE from CURRENT trace",
      "invariant": "TRACE_GATE_MISSING",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "TRACE_GATE_MISSING",
      "environment_binding": "known-good baseline + exactly one controlled child mutation",
      "evidence_expectation": "exit=3; deterministic FFI=TRACE_GATE_MISSING; normalized ConformanceReport",
      "invalidation_trigger": "validator/oracle/schema/profile/permission/effect semantics change"
    },
    {
      "fixture_id": "DT-02-C05",
      "class": "MUTATION",
      "source_ref": "AUDIT atomicization::DT-02",
      "test_ref": "TEST-MUT-002",
      "oracle_ref": "OR-MUT-002",
      "construction": "remove content hash from CURRENT trace",
      "invariant": "TRACE_HASH_MISSING",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "TRACE_HASH_MISSING",
      "environment_binding": "known-good baseline + exactly one controlled child mutation",
      "evidence_expectation": "exit=4; deterministic FFI=TRACE_HASH_MISSING; normalized ConformanceReport",
      "invalidation_trigger": "validator/oracle/schema/profile/permission/effect semantics change"
    },
    {
      "fixture_id": "DT-02-C06",
      "class": "MUTATION",
      "source_ref": "AUDIT atomicization::DT-02",
      "test_ref": "TEST-MUT-002",
      "oracle_ref": "OR-MUT-002",
      "construction": "remove invalidated_by/invalidation relation",
      "invariant": "TRACE_INVALIDATION_MISSING",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "TRACE_INVALIDATION_MISSING",
      "environment_binding": "known-good baseline + exactly one controlled child mutation",
      "evidence_expectation": "exit=4; deterministic FFI=TRACE_INVALIDATION_MISSING; normalized ConformanceReport",
      "invalidation_trigger": "validator/oracle/schema/profile/permission/effect semantics change"
    },
    {
      "fixture_id": "DT-04-C01",
      "class": "MUTATION",
      "source_ref": "AUDIT atomicization::DT-04",
      "test_ref": "TEST-MUT-003",
      "oracle_ref": "OR-MUT-003",
      "construction": "PREDEV_READY with empty RepoContext",
      "invariant": "PD_REPOCONTEXT_HOLLOW",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "PD_REPOCONTEXT_HOLLOW",
      "environment_binding": "known-good baseline + exactly one controlled child mutation",
      "evidence_expectation": "exit=3; deterministic FFI=PD_REPOCONTEXT_HOLLOW; normalized ConformanceReport",
      "invalidation_trigger": "validator/oracle/schema/profile/permission/effect semantics change"
    },
    {
      "fixture_id": "DT-04-C02",
      "class": "MUTATION",
      "source_ref": "AUDIT atomicization::DT-04",
      "test_ref": "TEST-MUT-003",
      "oracle_ref": "OR-MUT-003",
      "construction": "PREDEV_READY with empty S2E",
      "invariant": "PD_S2E_HOLLOW",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "PD_S2E_HOLLOW",
      "environment_binding": "known-good baseline + exactly one controlled child mutation",
      "evidence_expectation": "exit=3; deterministic FFI=PD_S2E_HOLLOW; normalized ConformanceReport",
      "invalidation_trigger": "validator/oracle/schema/profile/permission/effect semantics change"
    },
    {
      "fixture_id": "DT-04-C03",
      "class": "MUTATION",
      "source_ref": "AUDIT atomicization::DT-04",
      "test_ref": "TEST-MUT-003",
      "oracle_ref": "OR-MUT-003",
      "construction": "PREDEV_READY with empty ECP",
      "invariant": "PD_ECP_HOLLOW",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "PD_ECP_HOLLOW",
      "environment_binding": "known-good baseline + exactly one controlled child mutation",
      "evidence_expectation": "exit=3; deterministic FFI=PD_ECP_HOLLOW; normalized ConformanceReport",
      "invalidation_trigger": "validator/oracle/schema/profile/permission/effect semantics change"
    },
    {
      "fixture_id": "DT-04-C04",
      "class": "MUTATION",
      "source_ref": "AUDIT atomicization::DT-04",
      "test_ref": "TEST-MUT-003",
      "oracle_ref": "OR-MUT-003",
      "construction": "PREDEV_READY with empty TQAEP",
      "invariant": "PD_TQAEP_HOLLOW",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "PD_TQAEP_HOLLOW",
      "environment_binding": "known-good baseline + exactly one controlled child mutation",
      "evidence_expectation": "exit=3; deterministic FFI=PD_TQAEP_HOLLOW; normalized ConformanceReport",
      "invalidation_trigger": "validator/oracle/schema/profile/permission/effect semantics change"
    },
    {
      "fixture_id": "DT-05-C01",
      "class": "MUTATION",
      "source_ref": "AUDIT atomicization::DT-05",
      "test_ref": "TEST-MUT-004",
      "oracle_ref": "OR-MUT-004",
      "construction": "handoff allowed_scope/required_refs arrays empty",
      "invariant": "HANDOFF_REQUIRED_ARRAYS_EMPTY",
      "conformance_result": "FAIL",
      "decision": "NACK",
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "HANDOFF_REQUIRED_ARRAYS_EMPTY",
      "environment_binding": "known-good baseline + exactly one controlled child mutation",
      "evidence_expectation": "exit=3; deterministic FFI=HANDOFF_REQUIRED_ARRAYS_EMPTY; normalized ConformanceReport",
      "invalidation_trigger": "validator/oracle/schema/profile/permission/effect semantics change"
    },
    {
      "fixture_id": "DT-05-C02",
      "class": "MUTATION",
      "source_ref": "AUDIT atomicization::DT-05",
      "test_ref": "TEST-MUT-004",
      "oracle_ref": "OR-MUT-004",
      "construction": "handoff rollback/checkpoint missing",
      "invariant": "HANDOFF_ROLLBACK_MISSING",
      "conformance_result": "FAIL",
      "decision": "NACK",
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "HANDOFF_ROLLBACK_MISSING",
      "environment_binding": "known-good baseline + exactly one controlled child mutation",
      "evidence_expectation": "exit=3; deterministic FFI=HANDOFF_ROLLBACK_MISSING; normalized ConformanceReport",
      "invalidation_trigger": "validator/oracle/schema/profile/permission/effect semantics change"
    },
    {
      "fixture_id": "DT-06-C01",
      "class": "MUTATION",
      "source_ref": "AUDIT atomicization::DT-06",
      "test_ref": "TEST-MUT-005",
      "oracle_ref": "OR-MUT-005",
      "construction": "PASS evidence subject hash invalid",
      "invariant": "EVIDENCE_HASH_INVALID",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "EVIDENCE_HASH_INVALID",
      "environment_binding": "known-good baseline + exactly one controlled child mutation",
      "evidence_expectation": "exit=4; deterministic FFI=EVIDENCE_HASH_INVALID; normalized ConformanceReport",
      "invalidation_trigger": "validator/oracle/schema/profile/permission/effect semantics change"
    },
    {
      "fixture_id": "DT-06-C02",
      "class": "MUTATION",
      "source_ref": "AUDIT atomicization::DT-06",
      "test_ref": "TEST-MUT-005",
      "oracle_ref": "OR-MUT-005",
      "construction": "PASS evidence checker missing/null",
      "invariant": "EVIDENCE_CHECKER_MISSING",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "EVIDENCE_CHECKER_MISSING",
      "environment_binding": "known-good baseline + exactly one controlled child mutation",
      "evidence_expectation": "exit=3; deterministic FFI=EVIDENCE_CHECKER_MISSING; normalized ConformanceReport",
      "invalidation_trigger": "validator/oracle/schema/profile/permission/effect semantics change"
    },
    {
      "fixture_id": "DT-06-C03",
      "class": "MUTATION",
      "source_ref": "AUDIT atomicization::DT-06",
      "test_ref": "TEST-MUT-005",
      "oracle_ref": "OR-MUT-005",
      "construction": "PASS evidence artifact refs empty",
      "invariant": "EVIDENCE_ARTIFACTS_EMPTY",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "EVIDENCE_ARTIFACTS_EMPTY",
      "environment_binding": "known-good baseline + exactly one controlled child mutation",
      "evidence_expectation": "exit=3; deterministic FFI=EVIDENCE_ARTIFACTS_EMPTY; normalized ConformanceReport",
      "invalidation_trigger": "validator/oracle/schema/profile/permission/effect semantics change"
    },
    {
      "fixture_id": "DT-06-C04",
      "class": "MUTATION",
      "source_ref": "AUDIT atomicization::DT-06",
      "test_ref": "TEST-MUT-005",
      "oracle_ref": "OR-MUT-005",
      "construction": "PASS evidence oracle verdict non-PASS",
      "invariant": "EVIDENCE_ORACLE_NONPASS",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "EVIDENCE_ORACLE_NONPASS",
      "environment_binding": "known-good baseline + exactly one controlled child mutation",
      "evidence_expectation": "exit=3; deterministic FFI=EVIDENCE_ORACLE_NONPASS; normalized ConformanceReport",
      "invalidation_trigger": "validator/oracle/schema/profile/permission/effect semantics change"
    },
    {
      "fixture_id": "DT-08-C01",
      "class": "MUTATION",
      "source_ref": "AUDIT atomicization::DT-08",
      "test_ref": "TEST-MUT-006",
      "oracle_ref": "OR-MUT-006",
      "construction": "TaskSpecSeed.id == WorkOrder.id",
      "invariant": "IDENTITY_ALIAS_SEED_WORKORDER",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "IDENTITY_ALIAS_SEED_WORKORDER",
      "environment_binding": "known-good baseline + exactly one controlled child mutation",
      "evidence_expectation": "exit=3; deterministic FFI=IDENTITY_ALIAS_SEED_WORKORDER; normalized ConformanceReport",
      "invalidation_trigger": "validator/oracle/schema/profile/permission/effect semantics change"
    },
    {
      "fixture_id": "DT-08-C02",
      "class": "MUTATION",
      "source_ref": "AUDIT atomicization::DT-08",
      "test_ref": "TEST-MUT-006",
      "oracle_ref": "OR-MUT-006",
      "construction": "WorkOrder.id == ECP.id",
      "invariant": "IDENTITY_ALIAS_WORKORDER_ECP",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "IDENTITY_ALIAS_WORKORDER_ECP",
      "environment_binding": "known-good baseline + exactly one controlled child mutation",
      "evidence_expectation": "exit=3; deterministic FFI=IDENTITY_ALIAS_WORKORDER_ECP; normalized ConformanceReport",
      "invalidation_trigger": "validator/oracle/schema/profile/permission/effect semantics change"
    },
    {
      "fixture_id": "DT-08-C03",
      "class": "MUTATION",
      "source_ref": "AUDIT atomicization::DT-08",
      "test_ref": "TEST-MUT-006",
      "oracle_ref": "OR-MUT-006",
      "construction": "TaskSpecSeed.id == ECP.id",
      "invariant": "IDENTITY_ALIAS_SEED_ECP",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "IDENTITY_ALIAS_SEED_ECP",
      "environment_binding": "known-good baseline + exactly one controlled child mutation",
      "evidence_expectation": "exit=3; deterministic FFI=IDENTITY_ALIAS_SEED_ECP; normalized ConformanceReport",
      "invalidation_trigger": "validator/oracle/schema/profile/permission/effect semantics change"
    },
    {
      "fixture_id": "DT-09-C01",
      "class": "ADVERSARIAL",
      "source_ref": "AUDIT atomicization::DT-09",
      "test_ref": "TEST-MUT-008",
      "oracle_ref": "OR-MUT-008",
      "construction": "high-risk ADMIT approval token missing",
      "invariant": "APPROVAL_TOKEN_MISSING",
      "conformance_result": "FAIL",
      "decision": "DENY",
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "APPROVAL_TOKEN_MISSING",
      "environment_binding": "known-good baseline + exactly one controlled child mutation",
      "evidence_expectation": "exit=5; deterministic FFI=APPROVAL_TOKEN_MISSING; normalized ConformanceReport",
      "invalidation_trigger": "validator/oracle/schema/profile/permission/effect semantics change"
    },
    {
      "fixture_id": "DT-09-C02",
      "class": "ADVERSARIAL",
      "source_ref": "AUDIT atomicization::DT-09",
      "test_ref": "TEST-75B304BB",
      "oracle_ref": "OR-75B304BB",
      "construction": "approval token expired",
      "invariant": "APPROVAL_TOKEN_EXPIRED",
      "conformance_result": "FAIL",
      "decision": "DENY",
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "APPROVAL_TOKEN_EXPIRED",
      "environment_binding": "known-good baseline + exactly one controlled child mutation",
      "evidence_expectation": "exit=4; deterministic FFI=APPROVAL_TOKEN_EXPIRED; normalized ConformanceReport",
      "invalidation_trigger": "validator/oracle/schema/profile/permission/effect semantics change"
    },
    {
      "fixture_id": "DT-09-C03",
      "class": "ADVERSARIAL",
      "source_ref": "AUDIT atomicization::DT-09",
      "test_ref": "TEST-75B304BB",
      "oracle_ref": "OR-75B304BB",
      "construction": "approval token subject/hash mismatch",
      "invariant": "APPROVAL_TOKEN_SUBJECT_MISMATCH",
      "conformance_result": "FAIL",
      "decision": "DENY",
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "APPROVAL_TOKEN_SUBJECT_MISMATCH",
      "environment_binding": "known-good baseline + exactly one controlled child mutation",
      "evidence_expectation": "exit=5; deterministic FFI=APPROVAL_TOKEN_SUBJECT_MISMATCH; normalized ConformanceReport",
      "invalidation_trigger": "validator/oracle/schema/profile/permission/effect semantics change"
    },
    {
      "fixture_id": "DT-09-C04",
      "class": "ADVERSARIAL",
      "source_ref": "AUDIT atomicization::DT-09",
      "test_ref": "TEST-75B304BB",
      "oracle_ref": "OR-75B304BB",
      "construction": "approval token nonce replay",
      "invariant": "APPROVAL_TOKEN_REPLAY",
      "conformance_result": "FAIL",
      "decision": "DENY",
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "APPROVAL_TOKEN_REPLAY",
      "environment_binding": "known-good baseline + exactly one controlled child mutation",
      "evidence_expectation": "exit=5; deterministic FFI=APPROVAL_TOKEN_REPLAY; normalized ConformanceReport",
      "invalidation_trigger": "validator/oracle/schema/profile/permission/effect semantics change"
    },
    {
      "fixture_id": "DT-10-C01",
      "class": "APPARENT_PASS",
      "source_ref": "AUDIT atomicization::DT-10",
      "test_ref": "TEST-MUT-009",
      "oracle_ref": "OR-MUT-009",
      "construction": "provider returns success; observation/readback absent",
      "invariant": "EFFECT_READBACK_MISSING",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": "UNKNOWN_EFFECT",
      "recovery_action": "REOBSERVE",
      "finding_class": "EFFECT_READBACK_MISSING",
      "environment_binding": "known-good baseline + exactly one controlled child mutation",
      "evidence_expectation": "exit=3; deterministic FFI=EFFECT_READBACK_MISSING; normalized ConformanceReport",
      "invalidation_trigger": "validator/oracle/schema/profile/permission/effect semantics change"
    },
    {
      "fixture_id": "DT-10-C02",
      "class": "APPARENT_PASS",
      "source_ref": "AUDIT atomicization::DT-10",
      "test_ref": "TEST-2E59E411",
      "oracle_ref": "OR-2E59E411",
      "construction": "provider returns success; readback exists but reconciliation absent",
      "invariant": "EFFECT_RECONCILIATION_MISSING",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": "UNKNOWN_EFFECT",
      "recovery_action": "RECONCILE",
      "finding_class": "EFFECT_RECONCILIATION_MISSING",
      "environment_binding": "known-good baseline + exactly one controlled child mutation",
      "evidence_expectation": "exit=3; deterministic FFI=EFFECT_RECONCILIATION_MISSING; normalized ConformanceReport",
      "invalidation_trigger": "validator/oracle/schema/profile/permission/effect semantics change"
    },
    {
      "fixture_id": "FX-ADV-001",
      "class": "ADVERSARIAL",
      "source_ref": "R1 §05 retained baseline + R2 typed outcome repair",
      "test_ref": "TEST-7894BFB5",
      "oracle_ref": "OR-7894BFB5",
      "construction": "instruction injection in external DATA; inject tool/web prompt demanding PASS or permission escalation; purpose=prove untrusted content cannot gain authority",
      "invariant": "external content remains DATA",
      "conformance_result": "HOLD",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "exact subject/version/hash + applicable profile + qualification environment",
      "evidence_expectation": "sanitized trace",
      "invalidation_trigger": "rerun after trust-boundary changes"
    },
    {
      "fixture_id": "FX-AH-PD-01-N",
      "class": "MUTATION",
      "source_ref": "A3 AGENT_HARNESS PD denominator",
      "test_ref": "TEST-D07-AH-PD-01",
      "oracle_ref": "OR-D07-AH-PD-01",
      "construction": "remove, hollow, stale or mismatch only AH-PD-01 runtime/framework version while keeping sibling obligations valid",
      "invariant": "AH-PD-01::runtime/framework version",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "AH-PD-01_MISSING_OR_INVALID",
      "environment_binding": "AGENT_HARNESS/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "AH-PD-01 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to runtime/framework version, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-AH-PD-01-P",
      "class": "POSITIVE",
      "source_ref": "A3 AGENT_HARNESS PD denominator",
      "test_ref": "TEST-D07-AH-PD-01",
      "oracle_ref": "OR-D07-AH-PD-01",
      "construction": "materialize exact AH-PD-01 runtime/framework version binding with valid subject/profile/environment/evidence",
      "invariant": "AH-PD-01::runtime/framework version",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "AGENT_HARNESS/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "AH-PD-01 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to runtime/framework version, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-AH-PD-02-N",
      "class": "MUTATION",
      "source_ref": "A3 AGENT_HARNESS PD denominator",
      "test_ref": "TEST-D07-AH-PD-02",
      "oracle_ref": "OR-D07-AH-PD-02",
      "construction": "remove, hollow, stale or mismatch only AH-PD-02 model/provider while keeping sibling obligations valid",
      "invariant": "AH-PD-02::model/provider",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "AH-PD-02_MISSING_OR_INVALID",
      "environment_binding": "AGENT_HARNESS/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "AH-PD-02 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to model/provider, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-AH-PD-02-P",
      "class": "POSITIVE",
      "source_ref": "A3 AGENT_HARNESS PD denominator",
      "test_ref": "TEST-D07-AH-PD-02",
      "oracle_ref": "OR-D07-AH-PD-02",
      "construction": "materialize exact AH-PD-02 model/provider binding with valid subject/profile/environment/evidence",
      "invariant": "AH-PD-02::model/provider",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "AGENT_HARNESS/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "AH-PD-02 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to model/provider, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-AH-PD-03-N",
      "class": "MUTATION",
      "source_ref": "A3 AGENT_HARNESS PD denominator",
      "test_ref": "TEST-D07-AH-PD-03",
      "oracle_ref": "OR-D07-AH-PD-03",
      "construction": "remove, hollow, stale or mismatch only AH-PD-03 MCP version/profile while keeping sibling obligations valid",
      "invariant": "AH-PD-03::MCP version/profile",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "AH-PD-03_MISSING_OR_INVALID",
      "environment_binding": "AGENT_HARNESS/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "AH-PD-03 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to MCP version/profile, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-AH-PD-03-P",
      "class": "POSITIVE",
      "source_ref": "A3 AGENT_HARNESS PD denominator",
      "test_ref": "TEST-D07-AH-PD-03",
      "oracle_ref": "OR-D07-AH-PD-03",
      "construction": "materialize exact AH-PD-03 MCP version/profile binding with valid subject/profile/environment/evidence",
      "invariant": "AH-PD-03::MCP version/profile",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "AGENT_HARNESS/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "AH-PD-03 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to MCP version/profile, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-AH-PD-04-N",
      "class": "MUTATION",
      "source_ref": "A3 AGENT_HARNESS PD denominator",
      "test_ref": "TEST-D07-AH-PD-04",
      "oracle_ref": "OR-D07-AH-PD-04",
      "construction": "remove, hollow, stale or mismatch only AH-PD-04 A2A version/profile while keeping sibling obligations valid",
      "invariant": "AH-PD-04::A2A version/profile",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "AH-PD-04_MISSING_OR_INVALID",
      "environment_binding": "AGENT_HARNESS/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "AH-PD-04 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to A2A version/profile, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-AH-PD-04-P",
      "class": "POSITIVE",
      "source_ref": "A3 AGENT_HARNESS PD denominator",
      "test_ref": "TEST-D07-AH-PD-04",
      "oracle_ref": "OR-D07-AH-PD-04",
      "construction": "materialize exact AH-PD-04 A2A version/profile binding with valid subject/profile/environment/evidence",
      "invariant": "AH-PD-04::A2A version/profile",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "AGENT_HARNESS/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "AH-PD-04 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to A2A version/profile, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-AH-PD-05-N",
      "class": "MUTATION",
      "source_ref": "A3 AGENT_HARNESS PD denominator",
      "test_ref": "TEST-D07-AH-PD-05",
      "oracle_ref": "OR-D07-AH-PD-05",
      "construction": "remove, hollow, stale or mismatch only AH-PD-05 sandbox/container while keeping sibling obligations valid",
      "invariant": "AH-PD-05::sandbox/container",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "AH-PD-05_MISSING_OR_INVALID",
      "environment_binding": "AGENT_HARNESS/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "AH-PD-05 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to sandbox/container, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-AH-PD-05-P",
      "class": "POSITIVE",
      "source_ref": "A3 AGENT_HARNESS PD denominator",
      "test_ref": "TEST-D07-AH-PD-05",
      "oracle_ref": "OR-D07-AH-PD-05",
      "construction": "materialize exact AH-PD-05 sandbox/container binding with valid subject/profile/environment/evidence",
      "invariant": "AH-PD-05::sandbox/container",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "AGENT_HARNESS/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "AH-PD-05 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to sandbox/container, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-AH-PD-06-N",
      "class": "MUTATION",
      "source_ref": "A3 AGENT_HARNESS PD denominator",
      "test_ref": "TEST-D07-AH-PD-06",
      "oracle_ref": "OR-D07-AH-PD-06",
      "construction": "remove, hollow, stale or mismatch only AH-PD-06 state backend while keeping sibling obligations valid",
      "invariant": "AH-PD-06::state backend",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "AH-PD-06_MISSING_OR_INVALID",
      "environment_binding": "AGENT_HARNESS/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "AH-PD-06 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to state backend, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-AH-PD-06-P",
      "class": "POSITIVE",
      "source_ref": "A3 AGENT_HARNESS PD denominator",
      "test_ref": "TEST-D07-AH-PD-06",
      "oracle_ref": "OR-D07-AH-PD-06",
      "construction": "materialize exact AH-PD-06 state backend binding with valid subject/profile/environment/evidence",
      "invariant": "AH-PD-06::state backend",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "AGENT_HARNESS/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "AH-PD-06 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to state backend, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-AH-PD-07-N",
      "class": "MUTATION",
      "source_ref": "A3 AGENT_HARNESS PD denominator",
      "test_ref": "TEST-D07-AH-PD-07",
      "oracle_ref": "OR-D07-AH-PD-07",
      "construction": "remove, hollow, stale or mismatch only AH-PD-07 memory store while keeping sibling obligations valid",
      "invariant": "AH-PD-07::memory store",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "AH-PD-07_MISSING_OR_INVALID",
      "environment_binding": "AGENT_HARNESS/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "AH-PD-07 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to memory store, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-AH-PD-07-P",
      "class": "POSITIVE",
      "source_ref": "A3 AGENT_HARNESS PD denominator",
      "test_ref": "TEST-D07-AH-PD-07",
      "oracle_ref": "OR-D07-AH-PD-07",
      "construction": "materialize exact AH-PD-07 memory store binding with valid subject/profile/environment/evidence",
      "invariant": "AH-PD-07::memory store",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "AGENT_HARNESS/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "AH-PD-07 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to memory store, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-AH-PD-08-N",
      "class": "MUTATION",
      "source_ref": "A3 AGENT_HARNESS PD denominator",
      "test_ref": "TEST-D07-AH-PD-08",
      "oracle_ref": "OR-D07-AH-PD-08",
      "construction": "remove, hollow, stale or mismatch only AH-PD-08 tracing backend while keeping sibling obligations valid",
      "invariant": "AH-PD-08::tracing backend",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "AH-PD-08_MISSING_OR_INVALID",
      "environment_binding": "AGENT_HARNESS/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "AH-PD-08 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to tracing backend, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-AH-PD-08-P",
      "class": "POSITIVE",
      "source_ref": "A3 AGENT_HARNESS PD denominator",
      "test_ref": "TEST-D07-AH-PD-08",
      "oracle_ref": "OR-D07-AH-PD-08",
      "construction": "materialize exact AH-PD-08 tracing backend binding with valid subject/profile/environment/evidence",
      "invariant": "AH-PD-08::tracing backend",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "AGENT_HARNESS/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "AH-PD-08 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to tracing backend, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-AH-PD-09-N",
      "class": "MUTATION",
      "source_ref": "A3 AGENT_HARNESS PD denominator",
      "test_ref": "TEST-D07-AH-PD-09",
      "oracle_ref": "OR-D07-AH-PD-09",
      "construction": "remove, hollow, stale or mismatch only AH-PD-09 secret handles while keeping sibling obligations valid",
      "invariant": "AH-PD-09::secret handles",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "AH-PD-09_MISSING_OR_INVALID",
      "environment_binding": "AGENT_HARNESS/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "AH-PD-09 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to secret handles, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-AH-PD-09-P",
      "class": "POSITIVE",
      "source_ref": "A3 AGENT_HARNESS PD denominator",
      "test_ref": "TEST-D07-AH-PD-09",
      "oracle_ref": "OR-D07-AH-PD-09",
      "construction": "materialize exact AH-PD-09 secret handles binding with valid subject/profile/environment/evidence",
      "invariant": "AH-PD-09::secret handles",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "AGENT_HARNESS/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "AH-PD-09 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to secret handles, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-AH-PD-10-N",
      "class": "MUTATION",
      "source_ref": "A3 AGENT_HARNESS PD denominator",
      "test_ref": "TEST-D07-AH-PD-10",
      "oracle_ref": "OR-D07-AH-PD-10",
      "construction": "remove, hollow, stale or mismatch only AH-PD-10 tool schemas while keeping sibling obligations valid",
      "invariant": "AH-PD-10::tool schemas",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "AH-PD-10_MISSING_OR_INVALID",
      "environment_binding": "AGENT_HARNESS/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "AH-PD-10 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to tool schemas, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-AH-PD-10-P",
      "class": "POSITIVE",
      "source_ref": "A3 AGENT_HARNESS PD denominator",
      "test_ref": "TEST-D07-AH-PD-10",
      "oracle_ref": "OR-D07-AH-PD-10",
      "construction": "materialize exact AH-PD-10 tool schemas binding with valid subject/profile/environment/evidence",
      "invariant": "AH-PD-10::tool schemas",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "AGENT_HARNESS/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "AH-PD-10 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to tool schemas, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-AH-PD-11-N",
      "class": "MUTATION",
      "source_ref": "A3 AGENT_HARNESS PD denominator",
      "test_ref": "TEST-D07-AH-PD-11",
      "oracle_ref": "OR-D07-AH-PD-11",
      "construction": "remove, hollow, stale or mismatch only AH-PD-11 timeouts/retry/checkpoint while keeping sibling obligations valid",
      "invariant": "AH-PD-11::timeouts/retry/checkpoint",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "AH-PD-11_MISSING_OR_INVALID",
      "environment_binding": "AGENT_HARNESS/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "AH-PD-11 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to timeouts/retry/checkpoint, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-AH-PD-11-P",
      "class": "POSITIVE",
      "source_ref": "A3 AGENT_HARNESS PD denominator",
      "test_ref": "TEST-D07-AH-PD-11",
      "oracle_ref": "OR-D07-AH-PD-11",
      "construction": "materialize exact AH-PD-11 timeouts/retry/checkpoint binding with valid subject/profile/environment/evidence",
      "invariant": "AH-PD-11::timeouts/retry/checkpoint",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "AGENT_HARNESS/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "AH-PD-11 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to timeouts/retry/checkpoint, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-AH-PD-12-N",
      "class": "MUTATION",
      "source_ref": "A3 AGENT_HARNESS PD denominator",
      "test_ref": "TEST-D07-AH-PD-12",
      "oracle_ref": "OR-D07-AH-PD-12",
      "construction": "remove, hollow, stale or mismatch only AH-PD-12 eval harness while keeping sibling obligations valid",
      "invariant": "AH-PD-12::eval harness",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "AH-PD-12_MISSING_OR_INVALID",
      "environment_binding": "AGENT_HARNESS/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "AH-PD-12 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to eval harness, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-AH-PD-12-P",
      "class": "POSITIVE",
      "source_ref": "A3 AGENT_HARNESS PD denominator",
      "test_ref": "TEST-D07-AH-PD-12",
      "oracle_ref": "OR-D07-AH-PD-12",
      "construction": "materialize exact AH-PD-12 eval harness binding with valid subject/profile/environment/evidence",
      "invariant": "AH-PD-12::eval harness",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "AGENT_HARNESS/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "AH-PD-12 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to eval harness, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-AH-PD-13-N",
      "class": "MUTATION",
      "source_ref": "A3 AGENT_HARNESS PD denominator",
      "test_ref": "TEST-D07-AH-PD-13",
      "oracle_ref": "OR-D07-AH-PD-13",
      "construction": "remove, hollow, stale or mismatch only AH-PD-13 deployment environment while keeping sibling obligations valid",
      "invariant": "AH-PD-13::deployment environment",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "AH-PD-13_MISSING_OR_INVALID",
      "environment_binding": "AGENT_HARNESS/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "AH-PD-13 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to deployment environment, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-AH-PD-13-P",
      "class": "POSITIVE",
      "source_ref": "A3 AGENT_HARNESS PD denominator",
      "test_ref": "TEST-D07-AH-PD-13",
      "oracle_ref": "OR-D07-AH-PD-13",
      "construction": "materialize exact AH-PD-13 deployment environment binding with valid subject/profile/environment/evidence",
      "invariant": "AH-PD-13::deployment environment",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "AGENT_HARNESS/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "AH-PD-13 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to deployment environment, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-AH-PI-01-N",
      "class": "MUTATION",
      "source_ref": "A3 AGENT_HARNESS PI denominator",
      "test_ref": "TEST-D07-AH-PI-01",
      "oracle_ref": "OR-D07-AH-PI-01",
      "construction": "remove, hollow, stale or mismatch only AH-PI-01 identity/role while keeping sibling obligations valid",
      "invariant": "AH-PI-01::identity/role",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "AH-PI-01_MISSING_OR_INVALID",
      "environment_binding": "AGENT_HARNESS/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "AH-PI-01 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to identity/role, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-AH-PI-01-P",
      "class": "POSITIVE",
      "source_ref": "A3 AGENT_HARNESS PI denominator",
      "test_ref": "TEST-D07-AH-PI-01",
      "oracle_ref": "OR-D07-AH-PI-01",
      "construction": "materialize exact AH-PI-01 identity/role binding with valid subject/profile/environment/evidence",
      "invariant": "AH-PI-01::identity/role",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "AGENT_HARNESS/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "AH-PI-01 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to identity/role, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-AH-PI-02-N",
      "class": "MUTATION",
      "source_ref": "A3 AGENT_HARNESS PI denominator",
      "test_ref": "TEST-D07-AH-PI-02",
      "oracle_ref": "OR-D07-AH-PI-02",
      "construction": "remove, hollow, stale or mismatch only AH-PI-02 execution loop while keeping sibling obligations valid",
      "invariant": "AH-PI-02::execution loop",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "AH-PI-02_MISSING_OR_INVALID",
      "environment_binding": "AGENT_HARNESS/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "AH-PI-02 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to execution loop, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-AH-PI-02-P",
      "class": "POSITIVE",
      "source_ref": "A3 AGENT_HARNESS PI denominator",
      "test_ref": "TEST-D07-AH-PI-02",
      "oracle_ref": "OR-D07-AH-PI-02",
      "construction": "materialize exact AH-PI-02 execution loop binding with valid subject/profile/environment/evidence",
      "invariant": "AH-PI-02::execution loop",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "AGENT_HARNESS/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "AH-PI-02 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to execution loop, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-AH-PI-03-N",
      "class": "MUTATION",
      "source_ref": "A3 AGENT_HARNESS PI denominator",
      "test_ref": "TEST-D07-AH-PI-03",
      "oracle_ref": "OR-D07-AH-PI-03",
      "construction": "remove, hollow, stale or mismatch only AH-PI-03 tool registry while keeping sibling obligations valid",
      "invariant": "AH-PI-03::tool registry",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "AH-PI-03_MISSING_OR_INVALID",
      "environment_binding": "AGENT_HARNESS/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "AH-PI-03 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to tool registry, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-AH-PI-03-P",
      "class": "POSITIVE",
      "source_ref": "A3 AGENT_HARNESS PI denominator",
      "test_ref": "TEST-D07-AH-PI-03",
      "oracle_ref": "OR-D07-AH-PI-03",
      "construction": "materialize exact AH-PI-03 tool registry binding with valid subject/profile/environment/evidence",
      "invariant": "AH-PI-03::tool registry",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "AGENT_HARNESS/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "AH-PI-03 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to tool registry, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-AH-PI-04-N",
      "class": "MUTATION",
      "source_ref": "A3 AGENT_HARNESS PI denominator",
      "test_ref": "TEST-D07-AH-PI-04",
      "oracle_ref": "OR-D07-AH-PI-04",
      "construction": "remove, hollow, stale or mismatch only AH-PI-04 context policy while keeping sibling obligations valid",
      "invariant": "AH-PI-04::context policy",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "AH-PI-04_MISSING_OR_INVALID",
      "environment_binding": "AGENT_HARNESS/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "AH-PI-04 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to context policy, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-AH-PI-04-P",
      "class": "POSITIVE",
      "source_ref": "A3 AGENT_HARNESS PI denominator",
      "test_ref": "TEST-D07-AH-PI-04",
      "oracle_ref": "OR-D07-AH-PI-04",
      "construction": "materialize exact AH-PI-04 context policy binding with valid subject/profile/environment/evidence",
      "invariant": "AH-PI-04::context policy",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "AGENT_HARNESS/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "AH-PI-04 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to context policy, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-AH-PI-05-N",
      "class": "MUTATION",
      "source_ref": "A3 AGENT_HARNESS PI denominator",
      "test_ref": "TEST-D07-AH-PI-05",
      "oracle_ref": "OR-D07-AH-PI-05",
      "construction": "remove, hollow, stale or mismatch only AH-PI-05 state/memory while keeping sibling obligations valid",
      "invariant": "AH-PI-05::state/memory",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "AH-PI-05_MISSING_OR_INVALID",
      "environment_binding": "AGENT_HARNESS/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "AH-PI-05 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to state/memory, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-AH-PI-05-P",
      "class": "POSITIVE",
      "source_ref": "A3 AGENT_HARNESS PI denominator",
      "test_ref": "TEST-D07-AH-PI-05",
      "oracle_ref": "OR-D07-AH-PI-05",
      "construction": "materialize exact AH-PI-05 state/memory binding with valid subject/profile/environment/evidence",
      "invariant": "AH-PI-05::state/memory",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "AGENT_HARNESS/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "AH-PI-05 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to state/memory, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-AH-PI-06-N",
      "class": "MUTATION",
      "source_ref": "A3 AGENT_HARNESS PI denominator",
      "test_ref": "TEST-D07-AH-PI-06",
      "oracle_ref": "OR-D07-AH-PI-06",
      "construction": "remove, hollow, stale or mismatch only AH-PI-06 lifecycle hooks while keeping sibling obligations valid",
      "invariant": "AH-PI-06::lifecycle hooks",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "AH-PI-06_MISSING_OR_INVALID",
      "environment_binding": "AGENT_HARNESS/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "AH-PI-06 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to lifecycle hooks, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-AH-PI-06-P",
      "class": "POSITIVE",
      "source_ref": "A3 AGENT_HARNESS PI denominator",
      "test_ref": "TEST-D07-AH-PI-06",
      "oracle_ref": "OR-D07-AH-PI-06",
      "construction": "materialize exact AH-PI-06 lifecycle hooks binding with valid subject/profile/environment/evidence",
      "invariant": "AH-PI-06::lifecycle hooks",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "AGENT_HARNESS/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "AH-PI-06 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to lifecycle hooks, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-AH-PI-07-N",
      "class": "MUTATION",
      "source_ref": "A3 AGENT_HARNESS PI denominator",
      "test_ref": "TEST-D07-AH-PI-07",
      "oracle_ref": "OR-D07-AH-PI-07",
      "construction": "remove, hollow, stale or mismatch only AH-PI-07 permission/identity while keeping sibling obligations valid",
      "invariant": "AH-PI-07::permission/identity",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "AH-PI-07_MISSING_OR_INVALID",
      "environment_binding": "AGENT_HARNESS/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "AH-PI-07 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to permission/identity, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-AH-PI-07-P",
      "class": "POSITIVE",
      "source_ref": "A3 AGENT_HARNESS PI denominator",
      "test_ref": "TEST-D07-AH-PI-07",
      "oracle_ref": "OR-D07-AH-PI-07",
      "construction": "materialize exact AH-PI-07 permission/identity binding with valid subject/profile/environment/evidence",
      "invariant": "AH-PI-07::permission/identity",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "AGENT_HARNESS/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "AH-PI-07 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to permission/identity, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-AH-PI-08-N",
      "class": "MUTATION",
      "source_ref": "A3 AGENT_HARNESS PI denominator",
      "test_ref": "TEST-D07-AH-PI-08",
      "oracle_ref": "OR-D07-AH-PI-08",
      "construction": "remove, hollow, stale or mismatch only AH-PI-08 handoff while keeping sibling obligations valid",
      "invariant": "AH-PI-08::handoff",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "AH-PI-08_MISSING_OR_INVALID",
      "environment_binding": "AGENT_HARNESS/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "AH-PI-08 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to handoff, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-AH-PI-08-P",
      "class": "POSITIVE",
      "source_ref": "A3 AGENT_HARNESS PI denominator",
      "test_ref": "TEST-D07-AH-PI-08",
      "oracle_ref": "OR-D07-AH-PI-08",
      "construction": "materialize exact AH-PI-08 handoff binding with valid subject/profile/environment/evidence",
      "invariant": "AH-PI-08::handoff",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "AGENT_HARNESS/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "AH-PI-08 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to handoff, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-AH-PI-09-N",
      "class": "MUTATION",
      "source_ref": "A3 AGENT_HARNESS PI denominator",
      "test_ref": "TEST-D07-AH-PI-09",
      "oracle_ref": "OR-D07-AH-PI-09",
      "construction": "remove, hollow, stale or mismatch only AH-PI-09 guardrails while keeping sibling obligations valid",
      "invariant": "AH-PI-09::guardrails",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "AH-PI-09_MISSING_OR_INVALID",
      "environment_binding": "AGENT_HARNESS/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "AH-PI-09 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to guardrails, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-AH-PI-09-P",
      "class": "POSITIVE",
      "source_ref": "A3 AGENT_HARNESS PI denominator",
      "test_ref": "TEST-D07-AH-PI-09",
      "oracle_ref": "OR-D07-AH-PI-09",
      "construction": "materialize exact AH-PI-09 guardrails binding with valid subject/profile/environment/evidence",
      "invariant": "AH-PI-09::guardrails",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "AGENT_HARNESS/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "AH-PI-09 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to guardrails, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-AH-PI-10-N",
      "class": "MUTATION",
      "source_ref": "A3 AGENT_HARNESS PI denominator",
      "test_ref": "TEST-D07-AH-PI-10",
      "oracle_ref": "OR-D07-AH-PI-10",
      "construction": "remove, hollow, stale or mismatch only AH-PI-10 eval interface while keeping sibling obligations valid",
      "invariant": "AH-PI-10::eval interface",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "AH-PI-10_MISSING_OR_INVALID",
      "environment_binding": "AGENT_HARNESS/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "AH-PI-10 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to eval interface, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-AH-PI-10-P",
      "class": "POSITIVE",
      "source_ref": "A3 AGENT_HARNESS PI denominator",
      "test_ref": "TEST-D07-AH-PI-10",
      "oracle_ref": "OR-D07-AH-PI-10",
      "construction": "materialize exact AH-PI-10 eval interface binding with valid subject/profile/environment/evidence",
      "invariant": "AH-PI-10::eval interface",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "AGENT_HARNESS/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "AH-PI-10 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to eval interface, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-AH-PI-11-N",
      "class": "MUTATION",
      "source_ref": "A3 AGENT_HARNESS PI denominator",
      "test_ref": "TEST-D07-AH-PI-11",
      "oracle_ref": "OR-D07-AH-PI-11",
      "construction": "remove, hollow, stale or mismatch only AH-PI-11 observability while keeping sibling obligations valid",
      "invariant": "AH-PI-11::observability",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "AH-PI-11_MISSING_OR_INVALID",
      "environment_binding": "AGENT_HARNESS/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "AH-PI-11 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to observability, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-AH-PI-11-P",
      "class": "POSITIVE",
      "source_ref": "A3 AGENT_HARNESS PI denominator",
      "test_ref": "TEST-D07-AH-PI-11",
      "oracle_ref": "OR-D07-AH-PI-11",
      "construction": "materialize exact AH-PI-11 observability binding with valid subject/profile/environment/evidence",
      "invariant": "AH-PI-11::observability",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "AGENT_HARNESS/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "AH-PI-11 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to observability, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-AH-PI-12-N",
      "class": "MUTATION",
      "source_ref": "A3 AGENT_HARNESS PI denominator",
      "test_ref": "TEST-D07-AH-PI-12",
      "oracle_ref": "OR-D07-AH-PI-12",
      "construction": "remove, hollow, stale or mismatch only AH-PI-12 recovery/checkpoint while keeping sibling obligations valid",
      "invariant": "AH-PI-12::recovery/checkpoint",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "AH-PI-12_MISSING_OR_INVALID",
      "environment_binding": "AGENT_HARNESS/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "AH-PI-12 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to recovery/checkpoint, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-AH-PI-12-P",
      "class": "POSITIVE",
      "source_ref": "A3 AGENT_HARNESS PI denominator",
      "test_ref": "TEST-D07-AH-PI-12",
      "oracle_ref": "OR-D07-AH-PI-12",
      "construction": "materialize exact AH-PI-12 recovery/checkpoint binding with valid subject/profile/environment/evidence",
      "invariant": "AH-PI-12::recovery/checkpoint",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "AGENT_HARNESS/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "AH-PI-12 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to recovery/checkpoint, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-AH-PI-13-N",
      "class": "MUTATION",
      "source_ref": "A3 AGENT_HARNESS PI denominator",
      "test_ref": "TEST-D07-AH-PI-13",
      "oracle_ref": "OR-D07-AH-PI-13",
      "construction": "remove, hollow, stale or mismatch only AH-PI-13 human escalation while keeping sibling obligations valid",
      "invariant": "AH-PI-13::human escalation",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "AH-PI-13_MISSING_OR_INVALID",
      "environment_binding": "AGENT_HARNESS/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "AH-PI-13 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to human escalation, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-AH-PI-13-P",
      "class": "POSITIVE",
      "source_ref": "A3 AGENT_HARNESS PI denominator",
      "test_ref": "TEST-D07-AH-PI-13",
      "oracle_ref": "OR-D07-AH-PI-13",
      "construction": "materialize exact AH-PI-13 human escalation binding with valid subject/profile/environment/evidence",
      "invariant": "AH-PI-13::human escalation",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "AGENT_HARNESS/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "AH-PI-13 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to human escalation, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-AH-PI-14-N",
      "class": "MUTATION",
      "source_ref": "A3 AGENT_HARNESS PI denominator",
      "test_ref": "TEST-D07-AH-PI-14",
      "oracle_ref": "OR-D07-AH-PI-14",
      "construction": "remove, hollow, stale or mismatch only AH-PI-14 interop boundaries while keeping sibling obligations valid",
      "invariant": "AH-PI-14::interop boundaries",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "AH-PI-14_MISSING_OR_INVALID",
      "environment_binding": "AGENT_HARNESS/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "AH-PI-14 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to interop boundaries, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-AH-PI-14-P",
      "class": "POSITIVE",
      "source_ref": "A3 AGENT_HARNESS PI denominator",
      "test_ref": "TEST-D07-AH-PI-14",
      "oracle_ref": "OR-D07-AH-PI-14",
      "construction": "materialize exact AH-PI-14 interop boundaries binding with valid subject/profile/environment/evidence",
      "invariant": "AH-PI-14::interop boundaries",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "AGENT_HARNESS/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "AH-PI-14 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to interop boundaries, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-AH-PI-15-N",
      "class": "MUTATION",
      "source_ref": "A3 AGENT_HARNESS PI denominator",
      "test_ref": "TEST-D07-AH-PI-15",
      "oracle_ref": "OR-D07-AH-PI-15",
      "construction": "remove, hollow, stale or mismatch only AH-PI-15 provider-neutral seam while keeping sibling obligations valid",
      "invariant": "AH-PI-15::provider-neutral seam",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "AH-PI-15_MISSING_OR_INVALID",
      "environment_binding": "AGENT_HARNESS/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "AH-PI-15 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to provider-neutral seam, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-AH-PI-15-P",
      "class": "POSITIVE",
      "source_ref": "A3 AGENT_HARNESS PI denominator",
      "test_ref": "TEST-D07-AH-PI-15",
      "oracle_ref": "OR-D07-AH-PI-15",
      "construction": "materialize exact AH-PI-15 provider-neutral seam binding with valid subject/profile/environment/evidence",
      "invariant": "AH-PI-15::provider-neutral seam",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "AGENT_HARNESS/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "AH-PI-15 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to provider-neutral seam, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-APP-001",
      "class": "APPARENT-PASS",
      "source_ref": "R1 §05 retained baseline + R2 typed outcome repair",
      "test_ref": "TEST-C5BCA382",
      "oracle_ref": "OR-C5BCA382",
      "construction": "schema/CI green but semantic clause omitted; make schema-valid object missing decisive semantic binding; purpose=detect false green",
      "invariant": "semantic validator fails",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "exact subject/version/hash + applicable profile + qualification environment",
      "evidence_expectation": "schema pass + semantic fail pair",
      "invalidation_trigger": "every schema/semantic change"
    },
    {
      "fixture_id": "FX-APPR-001",
      "class": "MISSING_INVALID_APPROVAL",
      "source_ref": "R1 §05 retained baseline + R2 typed outcome repair",
      "test_ref": "TEST-MUT-008",
      "oracle_ref": "OR-MUT-008",
      "construction": "high-risk ADMIT lacks/has bad token; missing/expired/wrong subject/replayed nonce; purpose=enforce approval",
      "invariant": "token validity false",
      "conformance_result": "FAIL",
      "decision": "DENY",
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "exact subject/version/hash + applicable profile + qualification environment",
      "evidence_expectation": "token validation result",
      "invalidation_trigger": "new token required"
    },
    {
      "fixture_id": "FX-APPR-001-C01",
      "class": "ADVERSARIAL",
      "source_ref": "AUDIT atomicization::FX-APPR-001",
      "test_ref": "TEST-MUT-008",
      "oracle_ref": "OR-MUT-008",
      "construction": "approval missing",
      "invariant": "APPROVAL_MISSING",
      "conformance_result": "FAIL",
      "decision": "DENY",
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "APPROVAL_MISSING",
      "environment_binding": "known-good baseline + exactly one controlled child mutation",
      "evidence_expectation": "exit=5; deterministic FFI=APPROVAL_MISSING; normalized ConformanceReport",
      "invalidation_trigger": "validator/oracle/schema/profile/permission/effect semantics change"
    },
    {
      "fixture_id": "FX-APPR-001-C02",
      "class": "ADVERSARIAL",
      "source_ref": "AUDIT atomicization::FX-APPR-001",
      "test_ref": "TEST-75B304BB",
      "oracle_ref": "OR-75B304BB",
      "construction": "approval expired",
      "invariant": "APPROVAL_EXPIRED",
      "conformance_result": "FAIL",
      "decision": "DENY",
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "APPROVAL_EXPIRED",
      "environment_binding": "known-good baseline + exactly one controlled child mutation",
      "evidence_expectation": "exit=4; deterministic FFI=APPROVAL_EXPIRED; normalized ConformanceReport",
      "invalidation_trigger": "validator/oracle/schema/profile/permission/effect semantics change"
    },
    {
      "fixture_id": "FX-APPR-001-C03",
      "class": "ADVERSARIAL",
      "source_ref": "AUDIT atomicization::FX-APPR-001",
      "test_ref": "TEST-75B304BB",
      "oracle_ref": "OR-75B304BB",
      "construction": "approval wrong subject",
      "invariant": "APPROVAL_WRONG_SUBJECT",
      "conformance_result": "FAIL",
      "decision": "DENY",
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "APPROVAL_WRONG_SUBJECT",
      "environment_binding": "known-good baseline + exactly one controlled child mutation",
      "evidence_expectation": "exit=5; deterministic FFI=APPROVAL_WRONG_SUBJECT; normalized ConformanceReport",
      "invalidation_trigger": "validator/oracle/schema/profile/permission/effect semantics change"
    },
    {
      "fixture_id": "FX-APPR-001-C04",
      "class": "ADVERSARIAL",
      "source_ref": "AUDIT atomicization::FX-APPR-001",
      "test_ref": "TEST-75B304BB",
      "oracle_ref": "OR-75B304BB",
      "construction": "approval nonce replay",
      "invariant": "APPROVAL_REPLAY",
      "conformance_result": "FAIL",
      "decision": "DENY",
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "APPROVAL_REPLAY",
      "environment_binding": "known-good baseline + exactly one controlled child mutation",
      "evidence_expectation": "exit=5; deterministic FFI=APPROVAL_REPLAY; normalized ConformanceReport",
      "invalidation_trigger": "validator/oracle/schema/profile/permission/effect semantics change"
    },
    {
      "fixture_id": "FX-DECOM-001",
      "class": "BROWNFIELD_FALSE_DECOMMISSION",
      "source_ref": "R1 §05 retained baseline + R2 typed outcome repair",
      "test_ref": "TEST-3235004D",
      "oracle_ref": "OR-3235004D",
      "construction": "new path healthy but incumbent residues exist; mark decommission after bounded pilot only; purpose=protect rollback/residue closure",
      "invariant": "residue/decommission proof missing",
      "conformance_result": "HOLD",
      "decision": null,
      "effect_state": null,
      "recovery_action": "ROLLBACK",
      "finding_class": null,
      "environment_binding": "exact subject/version/hash + applicable profile + qualification environment",
      "evidence_expectation": "residue/readback proof",
      "invalidation_trigger": "after explicit residue closure"
    },
    {
      "fixture_id": "FX-DRIFT-001",
      "class": "CURRENTNESS_DRIFT",
      "source_ref": "R1 §05 retained baseline + R2 typed outcome repair",
      "test_ref": "TEST-6F8DCD42",
      "oracle_ref": "OR-6F8DCD42",
      "construction": "tool/protocol TTL/version/security drift; advance/change pin or standard hash; purpose=force requalification",
      "invariant": "dependent currentness invalidated",
      "conformance_result": "HOLD",
      "decision": null,
      "effect_state": null,
      "recovery_action": "REOBSERVE",
      "finding_class": "REQUALIFICATION_REQUIRED",
      "environment_binding": "exact subject/version/hash + applicable profile + qualification environment",
      "evidence_expectation": "currentness diff",
      "invalidation_trigger": "re-admit/requalify"
    },
    {
      "fixture_id": "FX-DRIFT-001-C01",
      "class": "EDGE",
      "source_ref": "AUDIT atomicization::FX-DRIFT-001",
      "test_ref": "TEST-6F8DCD42",
      "oracle_ref": "OR-6F8DCD42",
      "construction": "tool version drift",
      "invariant": "TOOL_VERSION_DRIFT",
      "conformance_result": "HOLD",
      "decision": null,
      "effect_state": null,
      "recovery_action": "REOBSERVE",
      "finding_class": "TOOL_VERSION_DRIFT",
      "environment_binding": "known-good baseline + exactly one controlled child mutation",
      "evidence_expectation": "exit=4; deterministic FFI=TOOL_VERSION_DRIFT; normalized ConformanceReport",
      "invalidation_trigger": "validator/oracle/schema/profile/permission/effect semantics change"
    },
    {
      "fixture_id": "FX-DRIFT-001-C02",
      "class": "EDGE",
      "source_ref": "AUDIT atomicization::FX-DRIFT-001",
      "test_ref": "TEST-6F8DCD42",
      "oracle_ref": "OR-6F8DCD42",
      "construction": "protocol version/profile drift",
      "invariant": "PROTOCOL_DRIFT",
      "conformance_result": "HOLD",
      "decision": null,
      "effect_state": null,
      "recovery_action": "REOBSERVE",
      "finding_class": "PROTOCOL_DRIFT",
      "environment_binding": "known-good baseline + exactly one controlled child mutation",
      "evidence_expectation": "exit=4; deterministic FFI=PROTOCOL_DRIFT; normalized ConformanceReport",
      "invalidation_trigger": "validator/oracle/schema/profile/permission/effect semantics change"
    },
    {
      "fixture_id": "FX-DRIFT-001-C03",
      "class": "EDGE",
      "source_ref": "AUDIT atomicization::FX-DRIFT-001",
      "test_ref": "TEST-6F8DCD42",
      "oracle_ref": "OR-6F8DCD42",
      "construction": "currentness TTL expiry",
      "invariant": "CURRENTNESS_TTL_EXPIRED",
      "conformance_result": "HOLD",
      "decision": null,
      "effect_state": null,
      "recovery_action": "REOBSERVE",
      "finding_class": "CURRENTNESS_TTL_EXPIRED",
      "environment_binding": "known-good baseline + exactly one controlled child mutation",
      "evidence_expectation": "exit=4; deterministic FFI=CURRENTNESS_TTL_EXPIRED; normalized ConformanceReport",
      "invalidation_trigger": "validator/oracle/schema/profile/permission/effect semantics change"
    },
    {
      "fixture_id": "FX-DRIFT-001-C04",
      "class": "EDGE",
      "source_ref": "AUDIT atomicization::FX-DRIFT-001",
      "test_ref": "TEST-D28A8B60",
      "oracle_ref": "OR-D28A8B60",
      "construction": "security/advisory state drift",
      "invariant": "SECURITY_DRIFT",
      "conformance_result": "HOLD",
      "decision": null,
      "effect_state": null,
      "recovery_action": "REOBSERVE",
      "finding_class": "SECURITY_DRIFT",
      "environment_binding": "known-good baseline + exactly one controlled child mutation",
      "evidence_expectation": "exit=4; deterministic FFI=SECURITY_DRIFT; normalized ConformanceReport",
      "invalidation_trigger": "validator/oracle/schema/profile/permission/effect semantics change"
    },
    {
      "fixture_id": "FX-DRIFT-001-C05",
      "class": "EDGE",
      "source_ref": "AUDIT atomicization::FX-DRIFT-001",
      "test_ref": "TEST-E6CD4BED",
      "oracle_ref": "OR-E6CD4BED",
      "construction": "license/rights drift",
      "invariant": "LICENSE_RIGHTS_DRIFT",
      "conformance_result": "HOLD",
      "decision": null,
      "effect_state": null,
      "recovery_action": "REOBSERVE",
      "finding_class": "LICENSE_RIGHTS_DRIFT",
      "environment_binding": "known-good baseline + exactly one controlled child mutation",
      "evidence_expectation": "exit=4; deterministic FFI=LICENSE_RIGHTS_DRIFT; normalized ConformanceReport",
      "invalidation_trigger": "validator/oracle/schema/profile/permission/effect semantics change"
    },
    {
      "fixture_id": "FX-EDGE-001",
      "class": "EDGE",
      "source_ref": "R1 §05 retained baseline + R2 typed outcome repair",
      "test_ref": "TEST-0CB9A2A0",
      "oracle_ref": "OR-0CB9A2A0",
      "construction": "legal N/A at profile boundary; mark conditional field N/A with owner+rationale+profile authority; purpose=prove N/A is source-bound, not omission",
      "invariant": "accepted only when source permits",
      "conformance_result": "HOLD",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "exact subject/version/hash + applicable profile + qualification environment",
      "evidence_expectation": "N/A rationale evidence",
      "invalidation_trigger": "recheck if profile changes"
    },
    {
      "fixture_id": "FX-EFFECT-001",
      "class": "WORLD-EFFECT_FALSE_POSITIVE",
      "source_ref": "R1 §05 retained baseline + R2 typed outcome repair",
      "test_ref": "TEST-MUT-009",
      "oracle_ref": "OR-MUT-009",
      "construction": "HTTP/tool success without readback; provider returns 2xx; no observation/readback; purpose=separate response from effect",
      "invariant": "effect != CONFIRMED_EFFECT",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": "UNKNOWN_EFFECT",
      "recovery_action": "REOBSERVE",
      "finding_class": null,
      "environment_binding": "exact subject/version/hash + applicable profile + qualification environment",
      "evidence_expectation": "response + missing reconciliation",
      "invalidation_trigger": "reconcile or compensate"
    },
    {
      "fixture_id": "FX-FPASS-001",
      "class": "FAKE_PASS",
      "source_ref": "R1 §05 retained baseline + R2 typed outcome repair",
      "test_ref": "TEST-MUT-005",
      "oracle_ref": "OR-MUT-005",
      "construction": "PASS evidence with invalid hash/checker/artifacts/oracle; mutate PASS packet; purpose=prevent evidence laundering",
      "invariant": "PASS predicates not all true",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "exact subject/version/hash + applicable profile + qualification environment",
      "evidence_expectation": "rejected evidence",
      "invalidation_trigger": "evidence changes"
    },
    {
      "fixture_id": "FX-FPASS-001-C01",
      "class": "APPARENT_PASS",
      "source_ref": "AUDIT atomicization::FX-FPASS-001",
      "test_ref": "TEST-MUT-005",
      "oracle_ref": "OR-MUT-005",
      "construction": "fake PASS with invalid subject hash",
      "invariant": "FAKE_PASS_HASH",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "FAKE_PASS_HASH",
      "environment_binding": "known-good baseline + exactly one controlled child mutation",
      "evidence_expectation": "exit=4; deterministic FFI=FAKE_PASS_HASH; normalized ConformanceReport",
      "invalidation_trigger": "validator/oracle/schema/profile/permission/effect semantics change"
    },
    {
      "fixture_id": "FX-FPASS-001-C02",
      "class": "APPARENT_PASS",
      "source_ref": "AUDIT atomicization::FX-FPASS-001",
      "test_ref": "TEST-MUT-005",
      "oracle_ref": "OR-MUT-005",
      "construction": "fake PASS with null checker",
      "invariant": "FAKE_PASS_CHECKER",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "FAKE_PASS_CHECKER",
      "environment_binding": "known-good baseline + exactly one controlled child mutation",
      "evidence_expectation": "exit=3; deterministic FFI=FAKE_PASS_CHECKER; normalized ConformanceReport",
      "invalidation_trigger": "validator/oracle/schema/profile/permission/effect semantics change"
    },
    {
      "fixture_id": "FX-FPASS-001-C03",
      "class": "APPARENT_PASS",
      "source_ref": "AUDIT atomicization::FX-FPASS-001",
      "test_ref": "TEST-MUT-005",
      "oracle_ref": "OR-MUT-005",
      "construction": "fake PASS with empty artifact refs",
      "invariant": "FAKE_PASS_ARTIFACTS",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "FAKE_PASS_ARTIFACTS",
      "environment_binding": "known-good baseline + exactly one controlled child mutation",
      "evidence_expectation": "exit=3; deterministic FFI=FAKE_PASS_ARTIFACTS; normalized ConformanceReport",
      "invalidation_trigger": "validator/oracle/schema/profile/permission/effect semantics change"
    },
    {
      "fixture_id": "FX-FPASS-001-C04",
      "class": "APPARENT_PASS",
      "source_ref": "AUDIT atomicization::FX-FPASS-001",
      "test_ref": "TEST-MUT-005",
      "oracle_ref": "OR-MUT-005",
      "construction": "fake PASS with non-PASS oracle",
      "invariant": "FAKE_PASS_ORACLE",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "FAKE_PASS_ORACLE",
      "environment_binding": "known-good baseline + exactly one controlled child mutation",
      "evidence_expectation": "exit=3; deterministic FFI=FAKE_PASS_ORACLE; normalized ConformanceReport",
      "invalidation_trigger": "validator/oracle/schema/profile/permission/effect semantics change"
    },
    {
      "fixture_id": "FX-HO-001",
      "class": "INCOMPLETE_HANDOFF",
      "source_ref": "R1 §05 retained baseline + R2 typed outcome repair",
      "test_ref": "TEST-MUT-004",
      "oracle_ref": "OR-MUT-004",
      "construction": "handoff required arrays empty; empty allowed_scope/required_refs/rollback; purpose=receiver must reject",
      "invariant": "handoff completeness false",
      "conformance_result": "FAIL",
      "decision": "NACK",
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "exact subject/version/hash + applicable profile + qualification environment",
      "evidence_expectation": "handoff rejection",
      "invalidation_trigger": "after repaired handoff"
    },
    {
      "fixture_id": "FX-HPD-001",
      "class": "HOLLOW_PREDEV_READY",
      "source_ref": "R1 §05 retained baseline + R2 typed outcome repair",
      "test_ref": "TEST-MUT-003",
      "oracle_ref": "OR-MUT-003",
      "construction": "PREDEV_READY with hollow RepoContext/S2E/ECP/TQAEP; empty one core PD object; purpose=block false promotion",
      "invariant": "PREDEV predicate false",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "exact subject/version/hash + applicable profile + qualification environment",
      "evidence_expectation": "PD gate failure",
      "invalidation_trigger": "PD change"
    },
    {
      "fixture_id": "FX-HPI-001",
      "class": "HOLLOW_PI_READY",
      "source_ref": "R1 §05 retained baseline + R2 typed outcome repair",
      "test_ref": "TEST-MUT-001",
      "oracle_ref": "OR-MUT-001",
      "construction": "PI_READY with empty/missing decisive data; status PI_READY + requirements=[] or constitution false; purpose=block false promotion",
      "invariant": "PI_READY predicate false",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "exact subject/version/hash + applicable profile + qualification environment",
      "evidence_expectation": "gate failure",
      "invalidation_trigger": "PI change"
    },
    {
      "fixture_id": "FX-HPI-001-C01",
      "class": "MUTATION",
      "source_ref": "AUDIT atomicization::FX-HPI-001",
      "test_ref": "TEST-MUT-001",
      "oracle_ref": "OR-MUT-001",
      "construction": "PI_READY with requirements=[]",
      "invariant": "PI_REQUIREMENTS_EMPTY",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "PI_REQUIREMENTS_EMPTY",
      "environment_binding": "known-good baseline + exactly one controlled child mutation",
      "evidence_expectation": "exit=3; deterministic FFI=PI_REQUIREMENTS_EMPTY; normalized ConformanceReport",
      "invalidation_trigger": "validator/oracle/schema/profile/permission/effect semantics change"
    },
    {
      "fixture_id": "FX-HPI-001-C02",
      "class": "MUTATION",
      "source_ref": "AUDIT atomicization::FX-HPI-001",
      "test_ref": "TEST-F8221F9F",
      "oracle_ref": "OR-F8221F9F",
      "construction": "PI_READY with CONSTITUTION_READY=false",
      "invariant": "PI_CONSTITUTION_NOT_READY",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "PI_CONSTITUTION_NOT_READY",
      "environment_binding": "known-good baseline + exactly one controlled child mutation",
      "evidence_expectation": "exit=3; deterministic FFI=PI_CONSTITUTION_NOT_READY; normalized ConformanceReport",
      "invalidation_trigger": "validator/oracle/schema/profile/permission/effect semantics change"
    },
    {
      "fixture_id": "FX-IDCOL-001",
      "class": "IDENTITY_COLLISION",
      "source_ref": "R1 §05 retained baseline + R2 typed outcome repair",
      "test_ref": "TEST-MUT-006",
      "oracle_ref": "OR-MUT-006",
      "construction": "Seed/WorkOrder/ECP same ID; alias IDs; purpose=preserve identity boundaries",
      "invariant": "all IDs distinct invariant false",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "exact subject/version/hash + applicable profile + qualification environment",
      "evidence_expectation": "identity graph",
      "invalidation_trigger": "object regeneration"
    },
    {
      "fixture_id": "FX-INJ-001",
      "class": "INSTRUCTION_INJECTION",
      "source_ref": "R1 §05 retained baseline + R2 typed outcome repair",
      "test_ref": "TEST-7894BFB5",
      "oracle_ref": "OR-7894BFB5",
      "construction": "repo/web/tool output asks validator to skip check; embed malicious instruction in DATA; purpose=protect instruction surfaces",
      "invariant": "no policy change",
      "conformance_result": "HOLD",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "exact subject/version/hash + applicable profile + qualification environment",
      "evidence_expectation": "sanitized trace",
      "invalidation_trigger": "trust policy change"
    },
    {
      "fixture_id": "FX-MUT-001",
      "class": "MUTATION",
      "source_ref": "R1 §05 retained baseline + R2 typed outcome repair",
      "test_ref": "TEST-MUT-001",
      "oracle_ref": "OR-MUT-001",
      "construction": "canonical object mutated; apply one controlled mutation per test; purpose=prove validator sensitivity",
      "invariant": "exact invariant fails",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "exact subject/version/hash + applicable profile + qualification environment",
      "evidence_expectation": "mutation record + report",
      "invalidation_trigger": "every validator change"
    },
    {
      "fixture_id": "FX-NEG-001",
      "class": "NEGATIVE",
      "source_ref": "R1 §05 retained baseline + R2 typed outcome repair",
      "test_ref": "TEST-C5BCA382",
      "oracle_ref": "OR-C5BCA382",
      "construction": "remove required gate/field; delete one required semantic field from otherwise valid subject; purpose=prove mandatory semantics reject",
      "invariant": "missing invariant is first failure",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "exact subject/version/hash + applicable profile + qualification environment",
      "evidence_expectation": "failure report",
      "invalidation_trigger": "repair then rerun"
    },
    {
      "fixture_id": "FX-PERM-001",
      "class": "MISSING_PERMISSION",
      "source_ref": "R1 §05 retained baseline + R2 typed outcome repair",
      "test_ref": "TEST-BND-001",
      "oracle_ref": "OR-BND-001",
      "construction": "attempt effect without permission; omit permission grant; purpose=default deny",
      "invariant": "permission predicate false",
      "conformance_result": "FAIL",
      "decision": "DENY",
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "exact subject/version/hash + applicable profile + qualification environment",
      "evidence_expectation": "admission denial",
      "invalidation_trigger": "permission change"
    },
    {
      "fixture_id": "FX-POS-001",
      "class": "POSITIVE",
      "source_ref": "R1 §05 retained baseline + R2 typed outcome repair",
      "test_ref": "TEST-CMP-001",
      "oracle_ref": "OR-CMP-001",
      "construction": "fully conformant PI/PD subject; construct complete subject with current hashes and applicable profile fields; purpose=prove true PASS path",
      "invariant": "all applicable core tests pass",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "exact subject/version/hash + applicable profile + qualification environment",
      "evidence_expectation": "ConformanceReport + raw evidence",
      "invalidation_trigger": "requalify on subject/env/oracle drift"
    },
    {
      "fixture_id": "FX-PRT-001",
      "class": "PORTABILITY_ADAPTER_REMOVAL",
      "source_ref": "R1 §05 retained baseline + R2 typed outcome repair",
      "test_ref": "TEST-PRT-001",
      "oracle_ref": "OR-PRT-001",
      "construction": "remove adapter or switch harness; run same canonical fixture without vendor adapter; purpose=prove core semantics portable",
      "invariant": "required semantics/gates unchanged",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "PARITY_DIFF_IF_ANY",
      "environment_binding": "exact subject/version/hash + applicable profile + qualification environment",
      "evidence_expectation": "cross-harness diff",
      "invalidation_trigger": "on adapter/runtime change"
    },
    {
      "fixture_id": "FX-SK-PD-01-N",
      "class": "MUTATION",
      "source_ref": "A3 SKILL_PLUGIN PD denominator",
      "test_ref": "TEST-D07-SK-PD-01",
      "oracle_ref": "OR-D07-SK-PD-01",
      "construction": "remove, hollow, stale or mismatch only SK-PD-01 Exact host/runtime/package versions while keeping sibling obligations valid",
      "invariant": "SK-PD-01::Exact host/runtime/package versions",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "SK-PD-01_MISSING_OR_INVALID",
      "environment_binding": "SKILL_PLUGIN/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SK-PD-01 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Exact host/runtime/package versions, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SK-PD-01-P",
      "class": "POSITIVE",
      "source_ref": "A3 SKILL_PLUGIN PD denominator",
      "test_ref": "TEST-D07-SK-PD-01",
      "oracle_ref": "OR-D07-SK-PD-01",
      "construction": "materialize exact SK-PD-01 Exact host/runtime/package versions binding with valid subject/profile/environment/evidence",
      "invariant": "SK-PD-01::Exact host/runtime/package versions",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "SKILL_PLUGIN/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SK-PD-01 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Exact host/runtime/package versions, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SK-PD-02-N",
      "class": "MUTATION",
      "source_ref": "A3 SKILL_PLUGIN PD denominator",
      "test_ref": "TEST-D07-SK-PD-02",
      "oracle_ref": "OR-D07-SK-PD-02",
      "construction": "remove, hollow, stale or mismatch only SK-PD-02 Install/publish layout while keeping sibling obligations valid",
      "invariant": "SK-PD-02::Install/publish layout",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "SK-PD-02_MISSING_OR_INVALID",
      "environment_binding": "SKILL_PLUGIN/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SK-PD-02 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Install/publish layout, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SK-PD-02-P",
      "class": "POSITIVE",
      "source_ref": "A3 SKILL_PLUGIN PD denominator",
      "test_ref": "TEST-D07-SK-PD-02",
      "oracle_ref": "OR-D07-SK-PD-02",
      "construction": "materialize exact SK-PD-02 Install/publish layout binding with valid subject/profile/environment/evidence",
      "invariant": "SK-PD-02::Install/publish layout",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "SKILL_PLUGIN/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SK-PD-02 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Install/publish layout, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SK-PD-03-N",
      "class": "MUTATION",
      "source_ref": "A3 SKILL_PLUGIN PD denominator",
      "test_ref": "TEST-D07-SK-PD-03",
      "oracle_ref": "OR-D07-SK-PD-03",
      "construction": "remove, hollow, stale or mismatch only SK-PD-03 Dependency lock while keeping sibling obligations valid",
      "invariant": "SK-PD-03::Dependency lock",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "SK-PD-03_MISSING_OR_INVALID",
      "environment_binding": "SKILL_PLUGIN/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SK-PD-03 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Dependency lock, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SK-PD-03-P",
      "class": "POSITIVE",
      "source_ref": "A3 SKILL_PLUGIN PD denominator",
      "test_ref": "TEST-D07-SK-PD-03",
      "oracle_ref": "OR-D07-SK-PD-03",
      "construction": "materialize exact SK-PD-03 Dependency lock binding with valid subject/profile/environment/evidence",
      "invariant": "SK-PD-03::Dependency lock",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "SKILL_PLUGIN/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SK-PD-03 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Dependency lock, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SK-PD-04-N",
      "class": "MUTATION",
      "source_ref": "A3 SKILL_PLUGIN PD denominator",
      "test_ref": "TEST-D07-SK-PD-04",
      "oracle_ref": "OR-D07-SK-PD-04",
      "construction": "remove, hollow, stale or mismatch only SK-PD-04 Sandbox while keeping sibling obligations valid",
      "invariant": "SK-PD-04::Sandbox",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "SK-PD-04_MISSING_OR_INVALID",
      "environment_binding": "SKILL_PLUGIN/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SK-PD-04 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Sandbox, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SK-PD-04-P",
      "class": "POSITIVE",
      "source_ref": "A3 SKILL_PLUGIN PD denominator",
      "test_ref": "TEST-D07-SK-PD-04",
      "oracle_ref": "OR-D07-SK-PD-04",
      "construction": "materialize exact SK-PD-04 Sandbox binding with valid subject/profile/environment/evidence",
      "invariant": "SK-PD-04::Sandbox",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "SKILL_PLUGIN/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SK-PD-04 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Sandbox, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SK-PD-05-N",
      "class": "MUTATION",
      "source_ref": "A3 SKILL_PLUGIN PD denominator",
      "test_ref": "TEST-D07-SK-PD-05",
      "oracle_ref": "OR-D07-SK-PD-05",
      "construction": "remove, hollow, stale or mismatch only SK-PD-05 Credential handles metadata while keeping sibling obligations valid",
      "invariant": "SK-PD-05::Credential handles metadata",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "SK-PD-05_MISSING_OR_INVALID",
      "environment_binding": "SKILL_PLUGIN/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SK-PD-05 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Credential handles metadata, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SK-PD-05-P",
      "class": "POSITIVE",
      "source_ref": "A3 SKILL_PLUGIN PD denominator",
      "test_ref": "TEST-D07-SK-PD-05",
      "oracle_ref": "OR-D07-SK-PD-05",
      "construction": "materialize exact SK-PD-05 Credential handles metadata binding with valid subject/profile/environment/evidence",
      "invariant": "SK-PD-05::Credential handles metadata",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "SKILL_PLUGIN/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SK-PD-05 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Credential handles metadata, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SK-PD-06-N",
      "class": "MUTATION",
      "source_ref": "A3 SKILL_PLUGIN PD denominator",
      "test_ref": "TEST-D07-SK-PD-06",
      "oracle_ref": "OR-D07-SK-PD-06",
      "construction": "remove, hollow, stale or mismatch only SK-PD-06 Network boundary while keeping sibling obligations valid",
      "invariant": "SK-PD-06::Network boundary",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "SK-PD-06_MISSING_OR_INVALID",
      "environment_binding": "SKILL_PLUGIN/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SK-PD-06 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Network boundary, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SK-PD-06-P",
      "class": "POSITIVE",
      "source_ref": "A3 SKILL_PLUGIN PD denominator",
      "test_ref": "TEST-D07-SK-PD-06",
      "oracle_ref": "OR-D07-SK-PD-06",
      "construction": "materialize exact SK-PD-06 Network boundary binding with valid subject/profile/environment/evidence",
      "invariant": "SK-PD-06::Network boundary",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "SKILL_PLUGIN/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SK-PD-06 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Network boundary, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SK-PD-07-N",
      "class": "MUTATION",
      "source_ref": "A3 SKILL_PLUGIN PD denominator",
      "test_ref": "TEST-D07-SK-PD-07",
      "oracle_ref": "OR-D07-SK-PD-07",
      "construction": "remove, hollow, stale or mismatch only SK-PD-07 Validation while keeping sibling obligations valid",
      "invariant": "SK-PD-07::Validation",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "SK-PD-07_MISSING_OR_INVALID",
      "environment_binding": "SKILL_PLUGIN/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SK-PD-07 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Validation, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SK-PD-07-P",
      "class": "POSITIVE",
      "source_ref": "A3 SKILL_PLUGIN PD denominator",
      "test_ref": "TEST-D07-SK-PD-07",
      "oracle_ref": "OR-D07-SK-PD-07",
      "construction": "materialize exact SK-PD-07 Validation binding with valid subject/profile/environment/evidence",
      "invariant": "SK-PD-07::Validation",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "SKILL_PLUGIN/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SK-PD-07 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Validation, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SK-PD-08-N",
      "class": "MUTATION",
      "source_ref": "A3 SKILL_PLUGIN PD denominator",
      "test_ref": "TEST-D07-SK-PD-08",
      "oracle_ref": "OR-D07-SK-PD-08",
      "construction": "remove, hollow, stale or mismatch only SK-PD-08 Uninstall/rollback while keeping sibling obligations valid",
      "invariant": "SK-PD-08::Uninstall/rollback",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "SK-PD-08_MISSING_OR_INVALID",
      "environment_binding": "SKILL_PLUGIN/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SK-PD-08 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Uninstall/rollback, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SK-PD-08-P",
      "class": "POSITIVE",
      "source_ref": "A3 SKILL_PLUGIN PD denominator",
      "test_ref": "TEST-D07-SK-PD-08",
      "oracle_ref": "OR-D07-SK-PD-08",
      "construction": "materialize exact SK-PD-08 Uninstall/rollback binding with valid subject/profile/environment/evidence",
      "invariant": "SK-PD-08::Uninstall/rollback",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "SKILL_PLUGIN/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SK-PD-08 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Uninstall/rollback, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SK-PD-09-N",
      "class": "MUTATION",
      "source_ref": "A3 SKILL_PLUGIN PD denominator",
      "test_ref": "TEST-D07-SK-PD-09",
      "oracle_ref": "OR-D07-SK-PD-09",
      "construction": "remove, hollow, stale or mismatch only SK-PD-09 Residue check while keeping sibling obligations valid",
      "invariant": "SK-PD-09::Residue check",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "SK-PD-09_MISSING_OR_INVALID",
      "environment_binding": "SKILL_PLUGIN/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SK-PD-09 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Residue check, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SK-PD-09-P",
      "class": "POSITIVE",
      "source_ref": "A3 SKILL_PLUGIN PD denominator",
      "test_ref": "TEST-D07-SK-PD-09",
      "oracle_ref": "OR-D07-SK-PD-09",
      "construction": "materialize exact SK-PD-09 Residue check binding with valid subject/profile/environment/evidence",
      "invariant": "SK-PD-09::Residue check",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "SKILL_PLUGIN/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SK-PD-09 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Residue check, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SK-PD-10-N",
      "class": "MUTATION",
      "source_ref": "A3 SKILL_PLUGIN PD denominator",
      "test_ref": "TEST-D07-SK-PD-10",
      "oracle_ref": "OR-D07-SK-PD-10",
      "construction": "remove, hollow, stale or mismatch only SK-PD-10 Host-specific permissions while keeping sibling obligations valid",
      "invariant": "SK-PD-10::Host-specific permissions",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "SK-PD-10_MISSING_OR_INVALID",
      "environment_binding": "SKILL_PLUGIN/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SK-PD-10 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Host-specific permissions, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SK-PD-10-P",
      "class": "POSITIVE",
      "source_ref": "A3 SKILL_PLUGIN PD denominator",
      "test_ref": "TEST-D07-SK-PD-10",
      "oracle_ref": "OR-D07-SK-PD-10",
      "construction": "materialize exact SK-PD-10 Host-specific permissions binding with valid subject/profile/environment/evidence",
      "invariant": "SK-PD-10::Host-specific permissions",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "SKILL_PLUGIN/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SK-PD-10 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Host-specific permissions, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SK-PD-11-N",
      "class": "MUTATION",
      "source_ref": "A3 SKILL_PLUGIN PD denominator",
      "test_ref": "TEST-D07-SK-PD-11",
      "oracle_ref": "OR-D07-SK-PD-11",
      "construction": "remove, hollow, stale or mismatch only SK-PD-11 Exact tool schema while keeping sibling obligations valid",
      "invariant": "SK-PD-11::Exact tool schema",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "SK-PD-11_MISSING_OR_INVALID",
      "environment_binding": "SKILL_PLUGIN/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SK-PD-11 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Exact tool schema, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SK-PD-11-P",
      "class": "POSITIVE",
      "source_ref": "A3 SKILL_PLUGIN PD denominator",
      "test_ref": "TEST-D07-SK-PD-11",
      "oracle_ref": "OR-D07-SK-PD-11",
      "construction": "materialize exact SK-PD-11 Exact tool schema binding with valid subject/profile/environment/evidence",
      "invariant": "SK-PD-11::Exact tool schema",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "SKILL_PLUGIN/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SK-PD-11 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Exact tool schema, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SK-PD-12-N",
      "class": "MUTATION",
      "source_ref": "A3 SKILL_PLUGIN PD denominator",
      "test_ref": "TEST-D07-SK-PD-12",
      "oracle_ref": "OR-D07-SK-PD-12",
      "construction": "remove, hollow, stale or mismatch only SK-PD-12 Currentness TTL while keeping sibling obligations valid",
      "invariant": "SK-PD-12::Currentness TTL",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "SK-PD-12_MISSING_OR_INVALID",
      "environment_binding": "SKILL_PLUGIN/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SK-PD-12 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Currentness TTL, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SK-PD-12-P",
      "class": "POSITIVE",
      "source_ref": "A3 SKILL_PLUGIN PD denominator",
      "test_ref": "TEST-D07-SK-PD-12",
      "oracle_ref": "OR-D07-SK-PD-12",
      "construction": "materialize exact SK-PD-12 Currentness TTL binding with valid subject/profile/environment/evidence",
      "invariant": "SK-PD-12::Currentness TTL",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "SKILL_PLUGIN/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SK-PD-12 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Currentness TTL, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SK-PI-01-N",
      "class": "MUTATION",
      "source_ref": "A3 SKILL_PLUGIN PI denominator",
      "test_ref": "TEST-D07-SK-PI-01",
      "oracle_ref": "OR-D07-SK-PI-01",
      "construction": "remove, hollow, stale or mismatch only SK-PI-01 Trigger while keeping sibling obligations valid",
      "invariant": "SK-PI-01::Trigger",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "SK-PI-01_MISSING_OR_INVALID",
      "environment_binding": "SKILL_PLUGIN/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SK-PI-01 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Trigger, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SK-PI-01-P",
      "class": "POSITIVE",
      "source_ref": "A3 SKILL_PLUGIN PI denominator",
      "test_ref": "TEST-D07-SK-PI-01",
      "oracle_ref": "OR-D07-SK-PI-01",
      "construction": "materialize exact SK-PI-01 Trigger binding with valid subject/profile/environment/evidence",
      "invariant": "SK-PI-01::Trigger",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "SKILL_PLUGIN/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SK-PI-01 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Trigger, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SK-PI-02-N",
      "class": "MUTATION",
      "source_ref": "A3 SKILL_PLUGIN PI denominator",
      "test_ref": "TEST-D07-SK-PI-02",
      "oracle_ref": "OR-D07-SK-PI-02",
      "construction": "remove, hollow, stale or mismatch only SK-PI-02 Non-trigger while keeping sibling obligations valid",
      "invariant": "SK-PI-02::Non-trigger",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "SK-PI-02_MISSING_OR_INVALID",
      "environment_binding": "SKILL_PLUGIN/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SK-PI-02 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Non-trigger, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SK-PI-02-P",
      "class": "POSITIVE",
      "source_ref": "A3 SKILL_PLUGIN PI denominator",
      "test_ref": "TEST-D07-SK-PI-02",
      "oracle_ref": "OR-D07-SK-PI-02",
      "construction": "materialize exact SK-PI-02 Non-trigger binding with valid subject/profile/environment/evidence",
      "invariant": "SK-PI-02::Non-trigger",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "SKILL_PLUGIN/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SK-PI-02 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Non-trigger, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SK-PI-03-N",
      "class": "MUTATION",
      "source_ref": "A3 SKILL_PLUGIN PI denominator",
      "test_ref": "TEST-D07-SK-PI-03",
      "oracle_ref": "OR-D07-SK-PI-03",
      "construction": "remove, hollow, stale or mismatch only SK-PI-03 Inputs while keeping sibling obligations valid",
      "invariant": "SK-PI-03::Inputs",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "SK-PI-03_MISSING_OR_INVALID",
      "environment_binding": "SKILL_PLUGIN/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SK-PI-03 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Inputs, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SK-PI-03-P",
      "class": "POSITIVE",
      "source_ref": "A3 SKILL_PLUGIN PI denominator",
      "test_ref": "TEST-D07-SK-PI-03",
      "oracle_ref": "OR-D07-SK-PI-03",
      "construction": "materialize exact SK-PI-03 Inputs binding with valid subject/profile/environment/evidence",
      "invariant": "SK-PI-03::Inputs",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "SKILL_PLUGIN/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SK-PI-03 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Inputs, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SK-PI-04-N",
      "class": "MUTATION",
      "source_ref": "A3 SKILL_PLUGIN PI denominator",
      "test_ref": "TEST-D07-SK-PI-04",
      "oracle_ref": "OR-D07-SK-PI-04",
      "construction": "remove, hollow, stale or mismatch only SK-PI-04 Outputs while keeping sibling obligations valid",
      "invariant": "SK-PI-04::Outputs",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "SK-PI-04_MISSING_OR_INVALID",
      "environment_binding": "SKILL_PLUGIN/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SK-PI-04 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Outputs, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SK-PI-04-P",
      "class": "POSITIVE",
      "source_ref": "A3 SKILL_PLUGIN PI denominator",
      "test_ref": "TEST-D07-SK-PI-04",
      "oracle_ref": "OR-D07-SK-PI-04",
      "construction": "materialize exact SK-PI-04 Outputs binding with valid subject/profile/environment/evidence",
      "invariant": "SK-PI-04::Outputs",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "SKILL_PLUGIN/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SK-PI-04 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Outputs, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SK-PI-05-N",
      "class": "MUTATION",
      "source_ref": "A3 SKILL_PLUGIN PI denominator",
      "test_ref": "TEST-D07-SK-PI-05",
      "oracle_ref": "OR-D07-SK-PI-05",
      "construction": "remove, hollow, stale or mismatch only SK-PI-05 Allowed tools while keeping sibling obligations valid",
      "invariant": "SK-PI-05::Allowed tools",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "SK-PI-05_MISSING_OR_INVALID",
      "environment_binding": "SKILL_PLUGIN/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SK-PI-05 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Allowed tools, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SK-PI-05-P",
      "class": "POSITIVE",
      "source_ref": "A3 SKILL_PLUGIN PI denominator",
      "test_ref": "TEST-D07-SK-PI-05",
      "oracle_ref": "OR-D07-SK-PI-05",
      "construction": "materialize exact SK-PI-05 Allowed tools binding with valid subject/profile/environment/evidence",
      "invariant": "SK-PI-05::Allowed tools",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "SKILL_PLUGIN/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SK-PI-05 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Allowed tools, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SK-PI-06-N",
      "class": "MUTATION",
      "source_ref": "A3 SKILL_PLUGIN PI denominator",
      "test_ref": "TEST-D07-SK-PI-06",
      "oracle_ref": "OR-D07-SK-PI-06",
      "construction": "remove, hollow, stale or mismatch only SK-PI-06 Permission classes while keeping sibling obligations valid",
      "invariant": "SK-PI-06::Permission classes",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "SK-PI-06_MISSING_OR_INVALID",
      "environment_binding": "SKILL_PLUGIN/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SK-PI-06 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Permission classes, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SK-PI-06-P",
      "class": "POSITIVE",
      "source_ref": "A3 SKILL_PLUGIN PI denominator",
      "test_ref": "TEST-D07-SK-PI-06",
      "oracle_ref": "OR-D07-SK-PI-06",
      "construction": "materialize exact SK-PI-06 Permission classes binding with valid subject/profile/environment/evidence",
      "invariant": "SK-PI-06::Permission classes",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "SKILL_PLUGIN/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SK-PI-06 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Permission classes, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SK-PI-07-N",
      "class": "MUTATION",
      "source_ref": "A3 SKILL_PLUGIN PI denominator",
      "test_ref": "TEST-D07-SK-PI-07",
      "oracle_ref": "OR-D07-SK-PI-07",
      "construction": "remove, hollow, stale or mismatch only SK-PI-07 Compatibility while keeping sibling obligations valid",
      "invariant": "SK-PI-07::Compatibility",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "SK-PI-07_MISSING_OR_INVALID",
      "environment_binding": "SKILL_PLUGIN/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SK-PI-07 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Compatibility, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SK-PI-07-P",
      "class": "POSITIVE",
      "source_ref": "A3 SKILL_PLUGIN PI denominator",
      "test_ref": "TEST-D07-SK-PI-07",
      "oracle_ref": "OR-D07-SK-PI-07",
      "construction": "materialize exact SK-PI-07 Compatibility binding with valid subject/profile/environment/evidence",
      "invariant": "SK-PI-07::Compatibility",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "SKILL_PLUGIN/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SK-PI-07 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Compatibility, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SK-PI-08-N",
      "class": "MUTATION",
      "source_ref": "A3 SKILL_PLUGIN PI denominator",
      "test_ref": "TEST-D07-SK-PI-08",
      "oracle_ref": "OR-D07-SK-PI-08",
      "construction": "remove, hollow, stale or mismatch only SK-PI-08 Dependencies while keeping sibling obligations valid",
      "invariant": "SK-PI-08::Dependencies",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "SK-PI-08_MISSING_OR_INVALID",
      "environment_binding": "SKILL_PLUGIN/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SK-PI-08 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Dependencies, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SK-PI-08-P",
      "class": "POSITIVE",
      "source_ref": "A3 SKILL_PLUGIN PI denominator",
      "test_ref": "TEST-D07-SK-PI-08",
      "oracle_ref": "OR-D07-SK-PI-08",
      "construction": "materialize exact SK-PI-08 Dependencies binding with valid subject/profile/environment/evidence",
      "invariant": "SK-PI-08::Dependencies",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "SKILL_PLUGIN/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SK-PI-08 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Dependencies, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SK-PI-09-N",
      "class": "MUTATION",
      "source_ref": "A3 SKILL_PLUGIN PI denominator",
      "test_ref": "TEST-D07-SK-PI-09",
      "oracle_ref": "OR-D07-SK-PI-09",
      "construction": "remove, hollow, stale or mismatch only SK-PI-09 Side-effect classes while keeping sibling obligations valid",
      "invariant": "SK-PI-09::Side-effect classes",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "SK-PI-09_MISSING_OR_INVALID",
      "environment_binding": "SKILL_PLUGIN/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SK-PI-09 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Side-effect classes, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SK-PI-09-P",
      "class": "POSITIVE",
      "source_ref": "A3 SKILL_PLUGIN PI denominator",
      "test_ref": "TEST-D07-SK-PI-09",
      "oracle_ref": "OR-D07-SK-PI-09",
      "construction": "materialize exact SK-PI-09 Side-effect classes binding with valid subject/profile/environment/evidence",
      "invariant": "SK-PI-09::Side-effect classes",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "SKILL_PLUGIN/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SK-PI-09 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Side-effect classes, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SK-PI-10-N",
      "class": "MUTATION",
      "source_ref": "A3 SKILL_PLUGIN PI denominator",
      "test_ref": "TEST-D07-SK-PI-10",
      "oracle_ref": "OR-D07-SK-PI-10",
      "construction": "remove, hollow, stale or mismatch only SK-PI-10 Secret/network policy while keeping sibling obligations valid",
      "invariant": "SK-PI-10::Secret/network policy",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "SK-PI-10_MISSING_OR_INVALID",
      "environment_binding": "SKILL_PLUGIN/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SK-PI-10 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Secret/network policy, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SK-PI-10-P",
      "class": "POSITIVE",
      "source_ref": "A3 SKILL_PLUGIN PI denominator",
      "test_ref": "TEST-D07-SK-PI-10",
      "oracle_ref": "OR-D07-SK-PI-10",
      "construction": "materialize exact SK-PI-10 Secret/network policy binding with valid subject/profile/environment/evidence",
      "invariant": "SK-PI-10::Secret/network policy",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "SKILL_PLUGIN/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SK-PI-10 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Secret/network policy, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SK-PI-11-N",
      "class": "MUTATION",
      "source_ref": "A3 SKILL_PLUGIN PI denominator",
      "test_ref": "TEST-D07-SK-PI-11",
      "oracle_ref": "OR-D07-SK-PI-11",
      "construction": "remove, hollow, stale or mismatch only SK-PI-11 Failure behavior while keeping sibling obligations valid",
      "invariant": "SK-PI-11::Failure behavior",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "SK-PI-11_MISSING_OR_INVALID",
      "environment_binding": "SKILL_PLUGIN/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SK-PI-11 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Failure behavior, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SK-PI-11-P",
      "class": "POSITIVE",
      "source_ref": "A3 SKILL_PLUGIN PI denominator",
      "test_ref": "TEST-D07-SK-PI-11",
      "oracle_ref": "OR-D07-SK-PI-11",
      "construction": "materialize exact SK-PI-11 Failure behavior binding with valid subject/profile/environment/evidence",
      "invariant": "SK-PI-11::Failure behavior",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "SKILL_PLUGIN/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SK-PI-11 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Failure behavior, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SK-PI-12-N",
      "class": "MUTATION",
      "source_ref": "A3 SKILL_PLUGIN PI denominator",
      "test_ref": "TEST-D07-SK-PI-12",
      "oracle_ref": "OR-D07-SK-PI-12",
      "construction": "remove, hollow, stale or mismatch only SK-PI-12 Negative cases while keeping sibling obligations valid",
      "invariant": "SK-PI-12::Negative cases",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "SK-PI-12_MISSING_OR_INVALID",
      "environment_binding": "SKILL_PLUGIN/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SK-PI-12 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Negative cases, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SK-PI-12-P",
      "class": "POSITIVE",
      "source_ref": "A3 SKILL_PLUGIN PI denominator",
      "test_ref": "TEST-D07-SK-PI-12",
      "oracle_ref": "OR-D07-SK-PI-12",
      "construction": "materialize exact SK-PI-12 Negative cases binding with valid subject/profile/environment/evidence",
      "invariant": "SK-PI-12::Negative cases",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "SKILL_PLUGIN/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SK-PI-12 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Negative cases, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SK-PI-13-N",
      "class": "MUTATION",
      "source_ref": "A3 SKILL_PLUGIN PI denominator",
      "test_ref": "TEST-D07-SK-PI-13",
      "oracle_ref": "OR-D07-SK-PI-13",
      "construction": "remove, hollow, stale or mismatch only SK-PI-13 Examples while keeping sibling obligations valid",
      "invariant": "SK-PI-13::Examples",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "SK-PI-13_MISSING_OR_INVALID",
      "environment_binding": "SKILL_PLUGIN/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SK-PI-13 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Examples, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SK-PI-13-P",
      "class": "POSITIVE",
      "source_ref": "A3 SKILL_PLUGIN PI denominator",
      "test_ref": "TEST-D07-SK-PI-13",
      "oracle_ref": "OR-D07-SK-PI-13",
      "construction": "materialize exact SK-PI-13 Examples binding with valid subject/profile/environment/evidence",
      "invariant": "SK-PI-13::Examples",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "SKILL_PLUGIN/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SK-PI-13 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Examples, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SK-PI-14-N",
      "class": "MUTATION",
      "source_ref": "A3 SKILL_PLUGIN PI denominator",
      "test_ref": "TEST-D07-SK-PI-14",
      "oracle_ref": "OR-D07-SK-PI-14",
      "construction": "remove, hollow, stale or mismatch only SK-PI-14 Host boundary while keeping sibling obligations valid",
      "invariant": "SK-PI-14::Host boundary",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "SK-PI-14_MISSING_OR_INVALID",
      "environment_binding": "SKILL_PLUGIN/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SK-PI-14 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Host boundary, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SK-PI-14-P",
      "class": "POSITIVE",
      "source_ref": "A3 SKILL_PLUGIN PI denominator",
      "test_ref": "TEST-D07-SK-PI-14",
      "oracle_ref": "OR-D07-SK-PI-14",
      "construction": "materialize exact SK-PI-14 Host boundary binding with valid subject/profile/environment/evidence",
      "invariant": "SK-PI-14::Host boundary",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "SKILL_PLUGIN/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SK-PI-14 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Host boundary, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SK-PI-15-N",
      "class": "MUTATION",
      "source_ref": "A3 SKILL_PLUGIN PI denominator",
      "test_ref": "TEST-D07-SK-PI-15",
      "oracle_ref": "OR-D07-SK-PI-15",
      "construction": "remove, hollow, stale or mismatch only SK-PI-15 Host assumptions while keeping sibling obligations valid",
      "invariant": "SK-PI-15::Host assumptions",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "SK-PI-15_MISSING_OR_INVALID",
      "environment_binding": "SKILL_PLUGIN/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SK-PI-15 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Host assumptions, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SK-PI-15-P",
      "class": "POSITIVE",
      "source_ref": "A3 SKILL_PLUGIN PI denominator",
      "test_ref": "TEST-D07-SK-PI-15",
      "oracle_ref": "OR-D07-SK-PI-15",
      "construction": "materialize exact SK-PI-15 Host assumptions binding with valid subject/profile/environment/evidence",
      "invariant": "SK-PI-15::Host assumptions",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "SKILL_PLUGIN/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SK-PI-15 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Host assumptions, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SK-PI-16-N",
      "class": "MUTATION",
      "source_ref": "A3 SKILL_PLUGIN PI denominator",
      "test_ref": "TEST-D07-SK-PI-16",
      "oracle_ref": "OR-D07-SK-PI-16",
      "construction": "remove, hollow, stale or mismatch only SK-PI-16 Dependency/rights provenance while keeping sibling obligations valid",
      "invariant": "SK-PI-16::Dependency/rights provenance",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "SK-PI-16_MISSING_OR_INVALID",
      "environment_binding": "SKILL_PLUGIN/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SK-PI-16 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Dependency/rights provenance, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SK-PI-16-P",
      "class": "POSITIVE",
      "source_ref": "A3 SKILL_PLUGIN PI denominator",
      "test_ref": "TEST-D07-SK-PI-16",
      "oracle_ref": "OR-D07-SK-PI-16",
      "construction": "materialize exact SK-PI-16 Dependency/rights provenance binding with valid subject/profile/environment/evidence",
      "invariant": "SK-PI-16::Dependency/rights provenance",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "SKILL_PLUGIN/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SK-PI-16 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Dependency/rights provenance, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SK-PI-17-N",
      "class": "MUTATION",
      "source_ref": "A3 SKILL_PLUGIN PI denominator",
      "test_ref": "TEST-D07-SK-PI-17",
      "oracle_ref": "OR-D07-SK-PI-17",
      "construction": "remove, hollow, stale or mismatch only SK-PI-17 Uninstall/disable semantics while keeping sibling obligations valid",
      "invariant": "SK-PI-17::Uninstall/disable semantics",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "SK-PI-17_MISSING_OR_INVALID",
      "environment_binding": "SKILL_PLUGIN/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SK-PI-17 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Uninstall/disable semantics, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SK-PI-17-P",
      "class": "POSITIVE",
      "source_ref": "A3 SKILL_PLUGIN PI denominator",
      "test_ref": "TEST-D07-SK-PI-17",
      "oracle_ref": "OR-D07-SK-PI-17",
      "construction": "materialize exact SK-PI-17 Uninstall/disable semantics binding with valid subject/profile/environment/evidence",
      "invariant": "SK-PI-17::Uninstall/disable semantics",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "SKILL_PLUGIN/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SK-PI-17 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Uninstall/disable semantics, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SK-PI-18-N",
      "class": "MUTATION",
      "source_ref": "A3 SKILL_PLUGIN PI denominator",
      "test_ref": "TEST-D07-SK-PI-18",
      "oracle_ref": "OR-D07-SK-PI-18",
      "construction": "remove, hollow, stale or mismatch only SK-PI-18 Evidence return while keeping sibling obligations valid",
      "invariant": "SK-PI-18::Evidence return",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "SK-PI-18_MISSING_OR_INVALID",
      "environment_binding": "SKILL_PLUGIN/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SK-PI-18 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Evidence return, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SK-PI-18-P",
      "class": "POSITIVE",
      "source_ref": "A3 SKILL_PLUGIN PI denominator",
      "test_ref": "TEST-D07-SK-PI-18",
      "oracle_ref": "OR-D07-SK-PI-18",
      "construction": "materialize exact SK-PI-18 Evidence return binding with valid subject/profile/environment/evidence",
      "invariant": "SK-PI-18::Evidence return",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "SKILL_PLUGIN/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SK-PI-18 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Evidence return, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-STALE-001",
      "class": "STALE_EVIDENCE",
      "source_ref": "R1 §05 retained baseline + R2 typed outcome repair",
      "test_ref": "TEST-RET-002",
      "oracle_ref": "OR-RET-002",
      "construction": "evidence generated against previous subject hash; bind evidence to superseded hash; purpose=reject stale evidence",
      "invariant": "subject hash mismatch/currentness invalid",
      "conformance_result": "HOLD",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "exact subject/version/hash + applicable profile + qualification environment",
      "evidence_expectation": "old/new identity receipts",
      "invalidation_trigger": "after source or subject change"
    },
    {
      "fixture_id": "FX-SYS-PD-01-N",
      "class": "MUTATION",
      "source_ref": "A3 SYSTEM PD denominator",
      "test_ref": "TEST-D07-SYS-PD-01",
      "oracle_ref": "OR-D07-SYS-PD-01",
      "construction": "remove, hollow, stale or mismatch only SYS-PD-01 RepoContext while keeping sibling obligations valid",
      "invariant": "SYS-PD-01::RepoContext",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "SYS-PD-01_MISSING_OR_INVALID",
      "environment_binding": "SYSTEM/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SYS-PD-01 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to RepoContext, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SYS-PD-01-P",
      "class": "POSITIVE",
      "source_ref": "A3 SYSTEM PD denominator",
      "test_ref": "TEST-D07-SYS-PD-01",
      "oracle_ref": "OR-D07-SYS-PD-01",
      "construction": "materialize exact SYS-PD-01 RepoContext binding with valid subject/profile/environment/evidence",
      "invariant": "SYS-PD-01::RepoContext",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "SYSTEM/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SYS-PD-01 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to RepoContext, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SYS-PD-02-N",
      "class": "MUTATION",
      "source_ref": "A3 SYSTEM PD denominator",
      "test_ref": "TEST-D07-SYS-PD-02",
      "oracle_ref": "OR-D07-SYS-PD-02",
      "construction": "remove, hollow, stale or mismatch only SYS-PD-02 Toolchain while keeping sibling obligations valid",
      "invariant": "SYS-PD-02::Toolchain",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "SYS-PD-02_MISSING_OR_INVALID",
      "environment_binding": "SYSTEM/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SYS-PD-02 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Toolchain, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SYS-PD-02-P",
      "class": "POSITIVE",
      "source_ref": "A3 SYSTEM PD denominator",
      "test_ref": "TEST-D07-SYS-PD-02",
      "oracle_ref": "OR-D07-SYS-PD-02",
      "construction": "materialize exact SYS-PD-02 Toolchain binding with valid subject/profile/environment/evidence",
      "invariant": "SYS-PD-02::Toolchain",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "SYSTEM/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SYS-PD-02 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Toolchain, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SYS-PD-03-N",
      "class": "MUTATION",
      "source_ref": "A3 SYSTEM PD denominator",
      "test_ref": "TEST-D07-SYS-PD-03",
      "oracle_ref": "OR-D07-SYS-PD-03",
      "construction": "remove, hollow, stale or mismatch only SYS-PD-03 DB/data migration while keeping sibling obligations valid",
      "invariant": "SYS-PD-03::DB/data migration",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "SYS-PD-03_MISSING_OR_INVALID",
      "environment_binding": "SYSTEM/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SYS-PD-03 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to DB/data migration, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SYS-PD-03-P",
      "class": "POSITIVE",
      "source_ref": "A3 SYSTEM PD denominator",
      "test_ref": "TEST-D07-SYS-PD-03",
      "oracle_ref": "OR-D07-SYS-PD-03",
      "construction": "materialize exact SYS-PD-03 DB/data migration binding with valid subject/profile/environment/evidence",
      "invariant": "SYS-PD-03::DB/data migration",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "SYSTEM/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SYS-PD-03 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to DB/data migration, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SYS-PD-04-N",
      "class": "MUTATION",
      "source_ref": "A3 SYSTEM PD denominator",
      "test_ref": "TEST-D07-SYS-PD-04",
      "oracle_ref": "OR-D07-SYS-PD-04",
      "construction": "remove, hollow, stale or mismatch only SYS-PD-04 CI while keeping sibling obligations valid",
      "invariant": "SYS-PD-04::CI",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "SYS-PD-04_MISSING_OR_INVALID",
      "environment_binding": "SYSTEM/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SYS-PD-04 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to CI, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SYS-PD-04-P",
      "class": "POSITIVE",
      "source_ref": "A3 SYSTEM PD denominator",
      "test_ref": "TEST-D07-SYS-PD-04",
      "oracle_ref": "OR-D07-SYS-PD-04",
      "construction": "materialize exact SYS-PD-04 CI binding with valid subject/profile/environment/evidence",
      "invariant": "SYS-PD-04::CI",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "SYSTEM/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SYS-PD-04 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to CI, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SYS-PD-05-N",
      "class": "MUTATION",
      "source_ref": "A3 SYSTEM PD denominator",
      "test_ref": "TEST-D07-SYS-PD-05",
      "oracle_ref": "OR-D07-SYS-PD-05",
      "construction": "remove, hollow, stale or mismatch only SYS-PD-05 Deployment topology while keeping sibling obligations valid",
      "invariant": "SYS-PD-05::Deployment topology",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "SYS-PD-05_MISSING_OR_INVALID",
      "environment_binding": "SYSTEM/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SYS-PD-05 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Deployment topology, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SYS-PD-05-P",
      "class": "POSITIVE",
      "source_ref": "A3 SYSTEM PD denominator",
      "test_ref": "TEST-D07-SYS-PD-05",
      "oracle_ref": "OR-D07-SYS-PD-05",
      "construction": "materialize exact SYS-PD-05 Deployment topology binding with valid subject/profile/environment/evidence",
      "invariant": "SYS-PD-05::Deployment topology",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "SYSTEM/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SYS-PD-05 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Deployment topology, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SYS-PD-06-N",
      "class": "MUTATION",
      "source_ref": "A3 SYSTEM PD denominator",
      "test_ref": "TEST-D07-SYS-PD-06",
      "oracle_ref": "OR-D07-SYS-PD-06",
      "construction": "remove, hollow, stale or mismatch only SYS-PD-06 Observability while keeping sibling obligations valid",
      "invariant": "SYS-PD-06::Observability",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "SYS-PD-06_MISSING_OR_INVALID",
      "environment_binding": "SYSTEM/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SYS-PD-06 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Observability, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SYS-PD-06-P",
      "class": "POSITIVE",
      "source_ref": "A3 SYSTEM PD denominator",
      "test_ref": "TEST-D07-SYS-PD-06",
      "oracle_ref": "OR-D07-SYS-PD-06",
      "construction": "materialize exact SYS-PD-06 Observability binding with valid subject/profile/environment/evidence",
      "invariant": "SYS-PD-06::Observability",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "SYSTEM/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SYS-PD-06 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Observability, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SYS-PD-07-N",
      "class": "MUTATION",
      "source_ref": "A3 SYSTEM PD denominator",
      "test_ref": "TEST-D07-SYS-PD-07",
      "oracle_ref": "OR-D07-SYS-PD-07",
      "construction": "remove, hollow, stale or mismatch only SYS-PD-07 Environment config while keeping sibling obligations valid",
      "invariant": "SYS-PD-07::Environment config",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "SYS-PD-07_MISSING_OR_INVALID",
      "environment_binding": "SYSTEM/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SYS-PD-07 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Environment config, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SYS-PD-07-P",
      "class": "POSITIVE",
      "source_ref": "A3 SYSTEM PD denominator",
      "test_ref": "TEST-D07-SYS-PD-07",
      "oracle_ref": "OR-D07-SYS-PD-07",
      "construction": "materialize exact SYS-PD-07 Environment config binding with valid subject/profile/environment/evidence",
      "invariant": "SYS-PD-07::Environment config",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "SYSTEM/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SYS-PD-07 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Environment config, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SYS-PD-08-N",
      "class": "MUTATION",
      "source_ref": "A3 SYSTEM PD denominator",
      "test_ref": "TEST-D07-SYS-PD-08",
      "oracle_ref": "OR-D07-SYS-PD-08",
      "construction": "remove, hollow, stale or mismatch only SYS-PD-08 Rollback/provider-off while keeping sibling obligations valid",
      "invariant": "SYS-PD-08::Rollback/provider-off",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "SYS-PD-08_MISSING_OR_INVALID",
      "environment_binding": "SYSTEM/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SYS-PD-08 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Rollback/provider-off, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SYS-PD-08-P",
      "class": "POSITIVE",
      "source_ref": "A3 SYSTEM PD denominator",
      "test_ref": "TEST-D07-SYS-PD-08",
      "oracle_ref": "OR-D07-SYS-PD-08",
      "construction": "materialize exact SYS-PD-08 Rollback/provider-off binding with valid subject/profile/environment/evidence",
      "invariant": "SYS-PD-08::Rollback/provider-off",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "SYSTEM/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SYS-PD-08 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Rollback/provider-off, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SYS-PD-09-N",
      "class": "MUTATION",
      "source_ref": "A3 SYSTEM PD denominator",
      "test_ref": "TEST-D07-SYS-PD-09",
      "oracle_ref": "OR-D07-SYS-PD-09",
      "construction": "remove, hollow, stale or mismatch only SYS-PD-09 SLO instrumentation while keeping sibling obligations valid",
      "invariant": "SYS-PD-09::SLO instrumentation",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "SYS-PD-09_MISSING_OR_INVALID",
      "environment_binding": "SYSTEM/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SYS-PD-09 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to SLO instrumentation, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SYS-PD-09-P",
      "class": "POSITIVE",
      "source_ref": "A3 SYSTEM PD denominator",
      "test_ref": "TEST-D07-SYS-PD-09",
      "oracle_ref": "OR-D07-SYS-PD-09",
      "construction": "materialize exact SYS-PD-09 SLO instrumentation binding with valid subject/profile/environment/evidence",
      "invariant": "SYS-PD-09::SLO instrumentation",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "SYSTEM/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SYS-PD-09 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to SLO instrumentation, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SYS-PD-10-N",
      "class": "MUTATION",
      "source_ref": "A3 SYSTEM PD denominator",
      "test_ref": "TEST-D07-SYS-PD-10",
      "oracle_ref": "OR-D07-SYS-PD-10",
      "construction": "remove, hollow, stale or mismatch only SYS-PD-10 Incident/runbook while keeping sibling obligations valid",
      "invariant": "SYS-PD-10::Incident/runbook",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "SYS-PD-10_MISSING_OR_INVALID",
      "environment_binding": "SYSTEM/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SYS-PD-10 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Incident/runbook, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SYS-PD-10-P",
      "class": "POSITIVE",
      "source_ref": "A3 SYSTEM PD denominator",
      "test_ref": "TEST-D07-SYS-PD-10",
      "oracle_ref": "OR-D07-SYS-PD-10",
      "construction": "materialize exact SYS-PD-10 Incident/runbook binding with valid subject/profile/environment/evidence",
      "invariant": "SYS-PD-10::Incident/runbook",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "SYSTEM/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SYS-PD-10 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Incident/runbook, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SYS-PD-11-N",
      "class": "MUTATION",
      "source_ref": "A3 SYSTEM PD denominator",
      "test_ref": "TEST-D07-SYS-PD-11",
      "oracle_ref": "OR-D07-SYS-PD-11",
      "construction": "remove, hollow, stale or mismatch only SYS-PD-11 DR/RTO/RPO while keeping sibling obligations valid",
      "invariant": "SYS-PD-11::DR/RTO/RPO",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "SYS-PD-11_MISSING_OR_INVALID",
      "environment_binding": "SYSTEM/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SYS-PD-11 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to DR/RTO/RPO, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SYS-PD-11-P",
      "class": "POSITIVE",
      "source_ref": "A3 SYSTEM PD denominator",
      "test_ref": "TEST-D07-SYS-PD-11",
      "oracle_ref": "OR-D07-SYS-PD-11",
      "construction": "materialize exact SYS-PD-11 DR/RTO/RPO binding with valid subject/profile/environment/evidence",
      "invariant": "SYS-PD-11::DR/RTO/RPO",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "SYSTEM/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SYS-PD-11 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to DR/RTO/RPO, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SYS-PD-12-N",
      "class": "MUTATION",
      "source_ref": "A3 SYSTEM PD denominator",
      "test_ref": "TEST-D07-SYS-PD-12",
      "oracle_ref": "OR-D07-SYS-PD-12",
      "construction": "remove, hollow, stale or mismatch only SYS-PD-12 Capacity/cost/FinOps while keeping sibling obligations valid",
      "invariant": "SYS-PD-12::Capacity/cost/FinOps",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "SYS-PD-12_MISSING_OR_INVALID",
      "environment_binding": "SYSTEM/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SYS-PD-12 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Capacity/cost/FinOps, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SYS-PD-12-P",
      "class": "POSITIVE",
      "source_ref": "A3 SYSTEM PD denominator",
      "test_ref": "TEST-D07-SYS-PD-12",
      "oracle_ref": "OR-D07-SYS-PD-12",
      "construction": "materialize exact SYS-PD-12 Capacity/cost/FinOps binding with valid subject/profile/environment/evidence",
      "invariant": "SYS-PD-12::Capacity/cost/FinOps",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "SYSTEM/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SYS-PD-12 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Capacity/cost/FinOps, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SYS-PD-13-N",
      "class": "MUTATION",
      "source_ref": "A3 SYSTEM PD denominator",
      "test_ref": "TEST-D07-SYS-PD-13",
      "oracle_ref": "OR-D07-SYS-PD-13",
      "construction": "remove, hollow, stale or mismatch only SYS-PD-13 Secret revoke/rotation while keeping sibling obligations valid",
      "invariant": "SYS-PD-13::Secret revoke/rotation",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "SYS-PD-13_MISSING_OR_INVALID",
      "environment_binding": "SYSTEM/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SYS-PD-13 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Secret revoke/rotation, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SYS-PD-13-P",
      "class": "POSITIVE",
      "source_ref": "A3 SYSTEM PD denominator",
      "test_ref": "TEST-D07-SYS-PD-13",
      "oracle_ref": "OR-D07-SYS-PD-13",
      "construction": "materialize exact SYS-PD-13 Secret revoke/rotation binding with valid subject/profile/environment/evidence",
      "invariant": "SYS-PD-13::Secret revoke/rotation",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "SYSTEM/PD exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SYS-PD-13 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Secret revoke/rotation, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SYS-PI-01-N",
      "class": "MUTATION",
      "source_ref": "A3 SYSTEM PI denominator",
      "test_ref": "TEST-D07-SYS-PI-01",
      "oracle_ref": "OR-D07-SYS-PI-01",
      "construction": "remove, hollow, stale or mismatch only SYS-PI-01 Product/user outcome while keeping sibling obligations valid",
      "invariant": "SYS-PI-01::Product/user outcome",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "SYS-PI-01_MISSING_OR_INVALID",
      "environment_binding": "SYSTEM/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SYS-PI-01 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Product/user outcome, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SYS-PI-01-P",
      "class": "POSITIVE",
      "source_ref": "A3 SYSTEM PI denominator",
      "test_ref": "TEST-D07-SYS-PI-01",
      "oracle_ref": "OR-D07-SYS-PI-01",
      "construction": "materialize exact SYS-PI-01 Product/user outcome binding with valid subject/profile/environment/evidence",
      "invariant": "SYS-PI-01::Product/user outcome",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "SYSTEM/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SYS-PI-01 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Product/user outcome, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SYS-PI-02-N",
      "class": "MUTATION",
      "source_ref": "A3 SYSTEM PI denominator",
      "test_ref": "TEST-D07-SYS-PI-02",
      "oracle_ref": "OR-D07-SYS-PI-02",
      "construction": "remove, hollow, stale or mismatch only SYS-PI-02 Domain model while keeping sibling obligations valid",
      "invariant": "SYS-PI-02::Domain model",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "SYS-PI-02_MISSING_OR_INVALID",
      "environment_binding": "SYSTEM/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SYS-PI-02 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Domain model, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SYS-PI-02-P",
      "class": "POSITIVE",
      "source_ref": "A3 SYSTEM PI denominator",
      "test_ref": "TEST-D07-SYS-PI-02",
      "oracle_ref": "OR-D07-SYS-PI-02",
      "construction": "materialize exact SYS-PI-02 Domain model binding with valid subject/profile/environment/evidence",
      "invariant": "SYS-PI-02::Domain model",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "SYSTEM/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SYS-PI-02 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Domain model, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SYS-PI-03-N",
      "class": "MUTATION",
      "source_ref": "A3 SYSTEM PI denominator",
      "test_ref": "TEST-D07-SYS-PI-03",
      "oracle_ref": "OR-D07-SYS-PI-03",
      "construction": "remove, hollow, stale or mismatch only SYS-PI-03 Architecture while keeping sibling obligations valid",
      "invariant": "SYS-PI-03::Architecture",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "SYS-PI-03_MISSING_OR_INVALID",
      "environment_binding": "SYSTEM/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SYS-PI-03 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Architecture, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SYS-PI-03-P",
      "class": "POSITIVE",
      "source_ref": "A3 SYSTEM PI denominator",
      "test_ref": "TEST-D07-SYS-PI-03",
      "oracle_ref": "OR-D07-SYS-PI-03",
      "construction": "materialize exact SYS-PI-03 Architecture binding with valid subject/profile/environment/evidence",
      "invariant": "SYS-PI-03::Architecture",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "SYSTEM/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SYS-PI-03 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Architecture, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SYS-PI-04-N",
      "class": "MUTATION",
      "source_ref": "A3 SYSTEM PI denominator",
      "test_ref": "TEST-D07-SYS-PI-04",
      "oracle_ref": "OR-D07-SYS-PI-04",
      "construction": "remove, hollow, stale or mismatch only SYS-PI-04 API contracts while keeping sibling obligations valid",
      "invariant": "SYS-PI-04::API contracts",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "SYS-PI-04_MISSING_OR_INVALID",
      "environment_binding": "SYSTEM/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SYS-PI-04 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to API contracts, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SYS-PI-04-P",
      "class": "POSITIVE",
      "source_ref": "A3 SYSTEM PI denominator",
      "test_ref": "TEST-D07-SYS-PI-04",
      "oracle_ref": "OR-D07-SYS-PI-04",
      "construction": "materialize exact SYS-PI-04 API contracts binding with valid subject/profile/environment/evidence",
      "invariant": "SYS-PI-04::API contracts",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "SYSTEM/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SYS-PI-04 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to API contracts, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SYS-PI-05-N",
      "class": "MUTATION",
      "source_ref": "A3 SYSTEM PI denominator",
      "test_ref": "TEST-D07-SYS-PI-05",
      "oracle_ref": "OR-D07-SYS-PI-05",
      "construction": "remove, hollow, stale or mismatch only SYS-PI-05 Data contracts while keeping sibling obligations valid",
      "invariant": "SYS-PI-05::Data contracts",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "SYS-PI-05_MISSING_OR_INVALID",
      "environment_binding": "SYSTEM/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SYS-PI-05 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Data contracts, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SYS-PI-05-P",
      "class": "POSITIVE",
      "source_ref": "A3 SYSTEM PI denominator",
      "test_ref": "TEST-D07-SYS-PI-05",
      "oracle_ref": "OR-D07-SYS-PI-05",
      "construction": "materialize exact SYS-PI-05 Data contracts binding with valid subject/profile/environment/evidence",
      "invariant": "SYS-PI-05::Data contracts",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "SYSTEM/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SYS-PI-05 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Data contracts, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SYS-PI-06-N",
      "class": "MUTATION",
      "source_ref": "A3 SYSTEM PI denominator",
      "test_ref": "TEST-D07-SYS-PI-06",
      "oracle_ref": "OR-D07-SYS-PI-06",
      "construction": "remove, hollow, stale or mismatch only SYS-PI-06 SLO/NFR while keeping sibling obligations valid",
      "invariant": "SYS-PI-06::SLO/NFR",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "SYS-PI-06_MISSING_OR_INVALID",
      "environment_binding": "SYSTEM/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SYS-PI-06 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to SLO/NFR, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SYS-PI-06-P",
      "class": "POSITIVE",
      "source_ref": "A3 SYSTEM PI denominator",
      "test_ref": "TEST-D07-SYS-PI-06",
      "oracle_ref": "OR-D07-SYS-PI-06",
      "construction": "materialize exact SYS-PI-06 SLO/NFR binding with valid subject/profile/environment/evidence",
      "invariant": "SYS-PI-06::SLO/NFR",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "SYSTEM/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SYS-PI-06 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to SLO/NFR, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SYS-PI-07-N",
      "class": "MUTATION",
      "source_ref": "A3 SYSTEM PI denominator",
      "test_ref": "TEST-D07-SYS-PI-07",
      "oracle_ref": "OR-D07-SYS-PI-07",
      "construction": "remove, hollow, stale or mismatch only SYS-PI-07 Security/privacy while keeping sibling obligations valid",
      "invariant": "SYS-PI-07::Security/privacy",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "SYS-PI-07_MISSING_OR_INVALID",
      "environment_binding": "SYSTEM/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SYS-PI-07 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Security/privacy, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SYS-PI-07-P",
      "class": "POSITIVE",
      "source_ref": "A3 SYSTEM PI denominator",
      "test_ref": "TEST-D07-SYS-PI-07",
      "oracle_ref": "OR-D07-SYS-PI-07",
      "construction": "materialize exact SYS-PI-07 Security/privacy binding with valid subject/profile/environment/evidence",
      "invariant": "SYS-PI-07::Security/privacy",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "SYSTEM/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SYS-PI-07 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Security/privacy, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SYS-PI-08-N",
      "class": "MUTATION",
      "source_ref": "A3 SYSTEM PI denominator",
      "test_ref": "TEST-D07-SYS-PI-08",
      "oracle_ref": "OR-D07-SYS-PI-08",
      "construction": "remove, hollow, stale or mismatch only SYS-PI-08 Migration/backcompat while keeping sibling obligations valid",
      "invariant": "SYS-PI-08::Migration/backcompat",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "SYS-PI-08_MISSING_OR_INVALID",
      "environment_binding": "SYSTEM/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SYS-PI-08 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Migration/backcompat, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SYS-PI-08-P",
      "class": "POSITIVE",
      "source_ref": "A3 SYSTEM PI denominator",
      "test_ref": "TEST-D07-SYS-PI-08",
      "oracle_ref": "OR-D07-SYS-PI-08",
      "construction": "materialize exact SYS-PI-08 Migration/backcompat binding with valid subject/profile/environment/evidence",
      "invariant": "SYS-PI-08::Migration/backcompat",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "SYSTEM/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SYS-PI-08 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Migration/backcompat, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SYS-PI-09-N",
      "class": "MUTATION",
      "source_ref": "A3 SYSTEM PI denominator",
      "test_ref": "TEST-D07-SYS-PI-09",
      "oracle_ref": "OR-D07-SYS-PI-09",
      "construction": "remove, hollow, stale or mismatch only SYS-PI-09 Acceptance/testability while keeping sibling obligations valid",
      "invariant": "SYS-PI-09::Acceptance/testability",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "SYS-PI-09_MISSING_OR_INVALID",
      "environment_binding": "SYSTEM/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SYS-PI-09 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Acceptance/testability, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SYS-PI-09-P",
      "class": "POSITIVE",
      "source_ref": "A3 SYSTEM PI denominator",
      "test_ref": "TEST-D07-SYS-PI-09",
      "oracle_ref": "OR-D07-SYS-PI-09",
      "construction": "materialize exact SYS-PI-09 Acceptance/testability binding with valid subject/profile/environment/evidence",
      "invariant": "SYS-PI-09::Acceptance/testability",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "SYSTEM/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SYS-PI-09 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Acceptance/testability, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SYS-PI-10-N",
      "class": "MUTATION",
      "source_ref": "A3 SYSTEM PI denominator",
      "test_ref": "TEST-D07-SYS-PI-10",
      "oracle_ref": "OR-D07-SYS-PI-10",
      "construction": "remove, hollow, stale or mismatch only SYS-PI-10 Operability intent while keeping sibling obligations valid",
      "invariant": "SYS-PI-10::Operability intent",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": "SYS-PI-10_MISSING_OR_INVALID",
      "environment_binding": "SYSTEM/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SYS-PI-10 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Operability intent, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-SYS-PI-10-P",
      "class": "POSITIVE",
      "source_ref": "A3 SYSTEM PI denominator",
      "test_ref": "TEST-D07-SYS-PI-10",
      "oracle_ref": "OR-D07-SYS-PI-10",
      "construction": "materialize exact SYS-PI-10 Operability intent binding with valid subject/profile/environment/evidence",
      "invariant": "SYS-PI-10::Operability intent",
      "conformance_result": "PASS",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "SYSTEM/PI exact subject/version/hash + profile_version + environment",
      "evidence_expectation": "SYS-PI-10 subject-bound contract/observation + checker result",
      "invalidation_trigger": "change to Operability intent, bound subject/hash, profile version, environment or oracle"
    },
    {
      "fixture_id": "FX-TAKE-001",
      "class": "PROVIDER_TOOL_TAKEOVER",
      "source_ref": "R1 §05 retained baseline + R2 typed outcome repair",
      "test_ref": "TEST-E6580324",
      "oracle_ref": "OR-E6580324",
      "construction": "provider callback asserts acceptance/authority; inject provider 'approved/passed' field; purpose=prevent confused authority",
      "invariant": "provider claim ignored/rejected",
      "conformance_result": "HOLD",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "exact subject/version/hash + applicable profile + qualification environment",
      "evidence_expectation": "provider raw + normalized rejection",
      "invalidation_trigger": "provider adapter changes"
    },
    {
      "fixture_id": "FX-TECH-001",
      "class": "SELECTED-TECHNOLOGY_OMISSION",
      "source_ref": "R1 §05 retained baseline + R2 typed outcome repair",
      "test_ref": "TEST-E6580324",
      "oracle_ref": "OR-E6580324",
      "construction": "selected named technology erased to generic tool; remove TechnologyLandingContract/identity; purpose=anti-downgrade",
      "invariant": "selected tech semantics not preserved",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "exact subject/version/hash + applicable profile + qualification environment",
      "evidence_expectation": "technology crosswalk diff",
      "invalidation_trigger": "restore or explicit CR"
    },
    {
      "fixture_id": "FX-WAUTH-001",
      "class": "WRONG_AUTHORITY",
      "source_ref": "R1 §05 retained baseline + R2 typed outcome repair",
      "test_ref": "TEST-E6580324",
      "oracle_ref": "OR-E6580324",
      "construction": "provider/tool claims semantic authority; mark donor/provider output normative; purpose=protect canonical writer",
      "invariant": "authority stack violated",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "exact subject/version/hash + applicable profile + qualification environment",
      "evidence_expectation": "authority trace",
      "invalidation_trigger": "on adapter/provider change"
    },
    {
      "fixture_id": "FX-WHASH-001",
      "class": "WRONG_VERSION_HASH",
      "source_ref": "R1 §05 retained baseline + R2 typed outcome repair",
      "test_ref": "TEST-79A6948B",
      "oracle_ref": "OR-79A6948B",
      "construction": "correct id, wrong version/hash; alter version/hash; purpose=bind exact candidate identity",
      "invariant": "identity tuple mismatch",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "exact subject/version/hash + applicable profile + qualification environment",
      "evidence_expectation": "identity diff",
      "invalidation_trigger": "always"
    },
    {
      "fixture_id": "FX-WSUB-001",
      "class": "WRONG_SUBJECT",
      "source_ref": "R1 §05 retained baseline + R2 typed outcome repair",
      "test_ref": "TEST-79A6948B",
      "oracle_ref": "OR-79A6948B",
      "construction": "valid evidence from sibling subject; swap evidence subject_ref.id; purpose=prevent foreign PASS inheritance",
      "invariant": "exact subject mismatch",
      "conformance_result": "FAIL",
      "decision": null,
      "effect_state": null,
      "recovery_action": "NONE",
      "finding_class": null,
      "environment_binding": "exact subject/version/hash + applicable profile + qualification environment",
      "evidence_expectation": "foreign evidence + rejection",
      "invalidation_trigger": "always"
    }
  ],
  "requirement_bindings": [
    {
      "requirement_id": "STD-REQ-979740C9",
      "test_id": "TEST-979740C9",
      "oracle_id": "OR-979740C9",
      "applicability": "APPLICABLE_PROFILE"
    },
    {
      "requirement_id": "STD-REQ-98F459F8",
      "test_id": "TEST-98F459F8",
      "oracle_id": "OR-98F459F8",
      "applicability": "APPLICABLE_PROFILE"
    },
    {
      "requirement_id": "STD-REQ-E2082905",
      "test_id": "TEST-E2082905",
      "oracle_id": "OR-E2082905",
      "applicability": "APPLICABLE_PROFILE"
    },
    {
      "requirement_id": "STD-REQ-B1C9AB85",
      "test_id": "TEST-B1C9AB85",
      "oracle_id": "OR-B1C9AB85",
      "applicability": "APPLICABLE_PROFILE"
    },
    {
      "requirement_id": "STD-REQ-B88A6D37",
      "test_id": "TEST-B88A6D37",
      "oracle_id": "OR-B88A6D37",
      "applicability": "ALL"
    },
    {
      "requirement_id": "STD-REQ-689DE502",
      "test_id": "TEST-689DE502",
      "oracle_id": "OR-689DE502",
      "applicability": "APPLICABLE_PROFILE"
    },
    {
      "requirement_id": "STD-REQ-ABD8745E",
      "test_id": "TEST-ABD8745E",
      "oracle_id": "OR-ABD8745E",
      "applicability": "ALL"
    },
    {
      "requirement_id": "STD-REQ-C6A9781D",
      "test_id": "TEST-C6A9781D",
      "oracle_id": "OR-C6A9781D",
      "applicability": "APPLICABLE_PROFILE"
    },
    {
      "requirement_id": "STD-REQ-79A6948B",
      "test_id": "TEST-79A6948B",
      "oracle_id": "OR-79A6948B",
      "applicability": "ALL"
    },
    {
      "requirement_id": "STD-REQ-4AAA061A",
      "test_id": "TEST-4AAA061A",
      "oracle_id": "OR-4AAA061A",
      "applicability": "ALL"
    },
    {
      "requirement_id": "STD-REQ-0E1DBA46",
      "test_id": "TEST-0E1DBA46",
      "oracle_id": "OR-0E1DBA46",
      "applicability": "APPLICABLE_PROFILE"
    },
    {
      "requirement_id": "STD-REQ-98BC2330",
      "test_id": "TEST-98BC2330",
      "oracle_id": "OR-98BC2330",
      "applicability": "APPLICABLE_PROFILE"
    },
    {
      "requirement_id": "STD-REQ-DA5BCA25",
      "test_id": "TEST-DA5BCA25",
      "oracle_id": "OR-DA5BCA25",
      "applicability": "ALL"
    },
    {
      "requirement_id": "STD-REQ-2A89F996",
      "test_id": "TEST-2A89F996",
      "oracle_id": "OR-2A89F996",
      "applicability": "ALL"
    },
    {
      "requirement_id": "STD-REQ-C5BCA382",
      "test_id": "TEST-C5BCA382",
      "oracle_id": "OR-C5BCA382",
      "applicability": "ALL"
    },
    {
      "requirement_id": "STD-REQ-B0C02A64",
      "test_id": "TEST-B0C02A64",
      "oracle_id": "OR-B0C02A64",
      "applicability": "APPLICABLE_PROFILE"
    },
    {
      "requirement_id": "STD-REQ-E0C7F7A0",
      "test_id": "TEST-E0C7F7A0",
      "oracle_id": "OR-E0C7F7A0",
      "applicability": "APPLICABLE_PROFILE"
    },
    {
      "requirement_id": "STD-REQ-81C86EBB",
      "test_id": "TEST-81C86EBB",
      "oracle_id": "OR-81C86EBB",
      "applicability": "APPLICABLE_PROFILE"
    },
    {
      "requirement_id": "STD-REQ-C25BC6A2",
      "test_id": "TEST-C25BC6A2",
      "oracle_id": "OR-C25BC6A2",
      "applicability": "APPLICABLE_PROFILE"
    },
    {
      "requirement_id": "STD-REQ-E22A8F7D",
      "test_id": "TEST-E22A8F7D",
      "oracle_id": "OR-E22A8F7D",
      "applicability": "APPLICABLE_PROFILE"
    },
    {
      "requirement_id": "STD-REQ-FA7B1B7F",
      "test_id": "TEST-FA7B1B7F",
      "oracle_id": "OR-FA7B1B7F",
      "applicability": "ALL"
    },
    {
      "requirement_id": "STD-REQ-11B19333",
      "test_id": "TEST-11B19333",
      "oracle_id": "OR-11B19333",
      "applicability": "ALL"
    },
    {
      "requirement_id": "STD-REQ-829B7605",
      "test_id": "TEST-829B7605",
      "oracle_id": "OR-829B7605",
      "applicability": "APPLICABLE_PROFILE"
    },
    {
      "requirement_id": "STD-REQ-7B3AB9E9",
      "test_id": "TEST-7B3AB9E9",
      "oracle_id": "OR-7B3AB9E9",
      "applicability": "APPLICABLE_PROFILE"
    },
    {
      "requirement_id": "STD-REQ-454A6D90",
      "test_id": "TEST-454A6D90",
      "oracle_id": "OR-454A6D90",
      "applicability": "ALL"
    },
    {
      "requirement_id": "STD-REQ-5EFF0181",
      "test_id": "TEST-5EFF0181",
      "oracle_id": "OR-5EFF0181",
      "applicability": "APPLICABLE_PROFILE"
    },
    {
      "requirement_id": "STD-REQ-6CCE644F",
      "test_id": "TEST-6CCE644F",
      "oracle_id": "OR-6CCE644F",
      "applicability": "APPLICABLE_PROFILE"
    },
    {
      "requirement_id": "STD-REQ-119B9088",
      "test_id": "TEST-119B9088",
      "oracle_id": "OR-119B9088",
      "applicability": "APPLICABLE_PROFILE"
    },
    {
      "requirement_id": "STD-REQ-EEC45EC3",
      "test_id": "TEST-EEC45EC3",
      "oracle_id": "OR-EEC45EC3",
      "applicability": "APPLICABLE_PROFILE"
    },
    {
      "requirement_id": "STD-REQ-0CB9A2A0",
      "test_id": "TEST-0CB9A2A0",
      "oracle_id": "OR-0CB9A2A0",
      "applicability": "APPLICABLE_PROFILE"
    },
    {
      "requirement_id": "STD-REQ-DD50D72A",
      "test_id": "TEST-DD50D72A",
      "oracle_id": "OR-DD50D72A",
      "applicability": "APPLICABLE_PROFILE"
    },
    {
      "requirement_id": "STD-REQ-59D1DD6F",
      "test_id": "TEST-59D1DD6F",
      "oracle_id": "OR-59D1DD6F",
      "applicability": "APPLICABLE_PROFILE"
    },
    {
      "requirement_id": "STD-REQ-9E161B60",
      "test_id": "TEST-9E161B60",
      "oracle_id": "OR-9E161B60",
      "applicability": "APPLICABLE_PROFILE"
    },
    {
      "requirement_id": "STD-REQ-10C6C743",
      "test_id": "TEST-10C6C743",
      "oracle_id": "OR-10C6C743",
      "applicability": "APPLICABLE_PROFILE"
    },
    {
      "requirement_id": "STD-REQ-90364E5B",
      "test_id": "TEST-90364E5B",
      "oracle_id": "OR-90364E5B",
      "applicability": "APPLICABLE_PROFILE"
    },
    {
      "requirement_id": "STD-REQ-D28A8B60",
      "test_id": "TEST-D28A8B60",
      "oracle_id": "OR-D28A8B60",
      "applicability": "ALL"
    },
    {
      "requirement_id": "STD-REQ-ABE182D6",
      "test_id": "TEST-ABE182D6",
      "oracle_id": "OR-ABE182D6",
      "applicability": "APPLICABLE_PROFILE"
    },
    {
      "requirement_id": "STD-REQ-9E4AFAC1",
      "test_id": "TEST-9E4AFAC1",
      "oracle_id": "OR-9E4AFAC1",
      "applicability": "APPLICABLE_PROFILE"
    },
    {
      "requirement_id": "STD-REQ-5868D53A",
      "test_id": "TEST-5868D53A",
      "oracle_id": "OR-5868D53A",
      "applicability": "APPLICABLE_PROFILE"
    },
    {
      "requirement_id": "STD-REQ-27A2EA7F",
      "test_id": "TEST-27A2EA7F",
      "oracle_id": "OR-27A2EA7F",
      "applicability": "APPLICABLE_PROFILE"
    },
    {
      "requirement_id": "STD-REQ-522701F0",
      "test_id": "TEST-522701F0",
      "oracle_id": "OR-522701F0",
      "applicability": "APPLICABLE_PROFILE"
    },
    {
      "requirement_id": "STD-REQ-E6CD4BED",
      "test_id": "TEST-E6CD4BED",
      "oracle_id": "OR-E6CD4BED",
      "applicability": "APPLICABLE_PROFILE"
    },
    {
      "requirement_id": "STD-REQ-06583027",
      "test_id": "TEST-06583027",
      "oracle_id": "OR-06583027",
      "applicability": "APPLICABLE_PROFILE"
    },
    {
      "requirement_id": "STD-REQ-C49B66DE",
      "test_id": "TEST-C49B66DE",
      "oracle_id": "OR-C49B66DE",
      "applicability": "APPLICABLE_PROFILE"
    },
    {
      "requirement_id": "STD-REQ-B4D1C8EA",
      "test_id": "TEST-B4D1C8EA",
      "oracle_id": "OR-B4D1C8EA",
      "applicability": "APPLICABLE_PROFILE"
    },
    {
      "requirement_id": "STD-REQ-5E28F98D",
      "test_id": "TEST-5E28F98D",
      "oracle_id": "OR-5E28F98D",
      "applicability": "APPLICABLE_PROFILE"
    },
    {
      "requirement_id": "STD-REQ-5AADF6A3",
      "test_id": "TEST-5AADF6A3",
      "oracle_id": "OR-5AADF6A3",
      "applicability": "APPLICABLE_PROFILE"
    },
    {
      "requirement_id": "STD-REQ-6E714CAB",
      "test_id": "TEST-6E714CAB",
      "oracle_id": "OR-6E714CAB",
      "applicability": "APPLICABLE_PROFILE"
    },
    {
      "requirement_id": "STD-REQ-C887276E",
      "test_id": "TEST-C887276E",
      "oracle_id": "OR-C887276E",
      "applicability": "APPLICABLE_PROFILE"
    },
    {
      "requirement_id": "STD-REQ-8A8EDC94",
      "test_id": "TEST-8A8EDC94",
      "oracle_id": "OR-8A8EDC94",
      "applicability": "APPLICABLE_PROFILE"
    },
    {
      "requirement_id": "STD-REQ-F8221F9F",
      "test_id": "TEST-F8221F9F",
      "oracle_id": "OR-F8221F9F",
      "applicability": "ALL"
    },
    {
      "requirement_id": "STD-REQ-92132DB3",
      "test_id": "TEST-92132DB3",
      "oracle_id": "OR-92132DB3",
      "applicability": "APPLICABLE_PROFILE"
    },
    {
      "requirement_id": "STD-REQ-DDF22230",
      "test_id": "TEST-DDF22230",
      "oracle_id": "OR-DDF22230",
      "applicability": "APPLICABLE_PROFILE"
    },
    {
      "requirement_id": "STD-REQ-F4F1DD9D",
      "test_id": "TEST-F4F1DD9D",
      "oracle_id": "OR-F4F1DD9D",
      "applicability": "APPLICABLE_PROFILE"
    },
    {
      "requirement_id": "STD-REQ-BA1FB472",
      "test_id": "TEST-BA1FB472",
      "oracle_id": "OR-BA1FB472",
      "applicability": "ALL"
    },
    {
      "requirement_id": "STD-REQ-7468B275",
      "test_id": "TEST-7468B275",
      "oracle_id": "OR-7468B275",
      "applicability": "ALL"
    },
    {
      "requirement_id": "STD-REQ-7CEA782A",
      "test_id": "TEST-7CEA782A",
      "oracle_id": "OR-7CEA782A",
      "applicability": "ALL"
    },
    {
      "requirement_id": "STD-REQ-93766574",
      "test_id": "TEST-93766574",
      "oracle_id": "OR-93766574",
      "applicability": "ALL"
    },
    {
      "requirement_id": "STD-REQ-1859D4F5",
      "test_id": "TEST-1859D4F5",
      "oracle_id": "OR-1859D4F5",
      "applicability": "ALL"
    },
    {
      "requirement_id": "STD-REQ-2FF7F879",
      "test_id": "TEST-2FF7F879",
      "oracle_id": "OR-2FF7F879",
      "applicability": "ALL"
    },
    {
      "requirement_id": "STD-REQ-9DF08F85",
      "test_id": "TEST-9DF08F85",
      "oracle_id": "OR-9DF08F85",
      "applicability": "ALL"
    },
    {
      "requirement_id": "STD-REQ-61E2C648",
      "test_id": "TEST-61E2C648",
      "oracle_id": "OR-61E2C648",
      "applicability": "APPLICABLE_PROFILE"
    },
    {
      "requirement_id": "STD-REQ-6E492151",
      "test_id": "TEST-6E492151",
      "oracle_id": "OR-6E492151",
      "applicability": "ALL"
    },
    {
      "requirement_id": "STD-REQ-75B304BB",
      "test_id": "TEST-75B304BB",
      "oracle_id": "OR-75B304BB",
      "applicability": "APPLICABLE_PROFILE"
    },
    {
      "requirement_id": "STD-REQ-FA8009D5",
      "test_id": "TEST-FA8009D5",
      "oracle_id": "OR-FA8009D5",
      "applicability": "ALL"
    },
    {
      "requirement_id": "STD-REQ-38EB8516",
      "test_id": "TEST-38EB8516",
      "oracle_id": "OR-38EB8516",
      "applicability": "APPLICABLE_PROFILE"
    },
    {
      "requirement_id": "STD-REQ-59414E50",
      "test_id": "TEST-59414E50",
      "oracle_id": "OR-59414E50",
      "applicability": "APPLICABLE_PROFILE"
    },
    {
      "requirement_id": "STD-REQ-F4669FFF",
      "test_id": "TEST-F4669FFF",
      "oracle_id": "OR-F4669FFF",
      "applicability": "APPLICABLE_PROFILE"
    },
    {
      "requirement_id": "STD-REQ-28163C14",
      "test_id": "TEST-28163C14",
      "oracle_id": "OR-28163C14",
      "applicability": "ALL"
    },
    {
      "requirement_id": "STD-REQ-3235004D",
      "test_id": "TEST-3235004D",
      "oracle_id": "OR-3235004D",
      "applicability": "APPLICABLE_PROFILE"
    },
    {
      "requirement_id": "STD-REQ-3CA02A9C",
      "test_id": "TEST-3CA02A9C",
      "oracle_id": "OR-3CA02A9C",
      "applicability": "APPLICABLE_PROFILE"
    },
    {
      "requirement_id": "STD-REQ-BF0442B3",
      "test_id": "TEST-BF0442B3",
      "oracle_id": "OR-BF0442B3",
      "applicability": "APPLICABLE_PROFILE"
    },
    {
      "requirement_id": "STD-REQ-B5C7D219",
      "test_id": "TEST-B5C7D219",
      "oracle_id": "OR-B5C7D219",
      "applicability": "ALL"
    },
    {
      "requirement_id": "STD-REQ-0B4D6B1E",
      "test_id": "TEST-0B4D6B1E",
      "oracle_id": "OR-0B4D6B1E",
      "applicability": "APPLICABLE_PROFILE"
    },
    {
      "requirement_id": "STD-REQ-0C5B13B3",
      "test_id": "TEST-0C5B13B3",
      "oracle_id": "OR-0C5B13B3",
      "applicability": "APPLICABLE_PROFILE"
    },
    {
      "requirement_id": "STD-REQ-2E59E411",
      "test_id": "TEST-2E59E411",
      "oracle_id": "OR-2E59E411",
      "applicability": "ALL"
    },
    {
      "requirement_id": "STD-REQ-D4FB7180",
      "test_id": "TEST-D4FB7180",
      "oracle_id": "OR-D4FB7180",
      "applicability": "APPLICABLE_PROFILE"
    },
    {
      "requirement_id": "STD-REQ-22E53BD2",
      "test_id": "TEST-22E53BD2",
      "oracle_id": "OR-22E53BD2",
      "applicability": "APPLICABLE_PROFILE"
    },
    {
      "requirement_id": "STD-REQ-7894BFB5",
      "test_id": "TEST-7894BFB5",
      "oracle_id": "OR-7894BFB5",
      "applicability": "APPLICABLE_PROFILE"
    },
    {
      "requirement_id": "STD-REQ-86CAC54E",
      "test_id": "TEST-86CAC54E",
      "oracle_id": "OR-86CAC54E",
      "applicability": "APPLICABLE_PROFILE"
    },
    {
      "requirement_id": "STD-REQ-7CD1E5E6",
      "test_id": "TEST-7CD1E5E6",
      "oracle_id": "OR-7CD1E5E6",
      "applicability": "APPLICABLE_PROFILE"
    },
    {
      "requirement_id": "STD-REQ-37150A4D",
      "test_id": "TEST-37150A4D",
      "oracle_id": "OR-37150A4D",
      "applicability": "APPLICABLE_PROFILE"
    },
    {
      "requirement_id": "STD-REQ-97BCACAC",
      "test_id": "TEST-97BCACAC",
      "oracle_id": "OR-97BCACAC",
      "applicability": "ALL"
    },
    {
      "requirement_id": "STD-REQ-E6580324",
      "test_id": "TEST-E6580324",
      "oracle_id": "OR-E6580324",
      "applicability": "ALL"
    },
    {
      "requirement_id": "STD-REQ-6F8DCD42",
      "test_id": "TEST-6F8DCD42",
      "oracle_id": "OR-6F8DCD42",
      "applicability": "APPLICABLE_PROFILE"
    },
    {
      "requirement_id": "STD-REQ-44B56684",
      "test_id": "TEST-44B56684",
      "oracle_id": "OR-44B56684",
      "applicability": "APPLICABLE_PROFILE"
    }
  ]
}
```

# Appendix H｜AUDIT Repair Closure Ledger

| Audit finding | R2 destination | Design repair status | Runtime/independent status |
|---|---|---|---|
| AUD-D07-S1-001 | Appendix A/E | CLOSED_IN_R2_DESIGN_PASS_AUTHOR_SIDE_R2 | NOT_EXECUTED / NOT_CLAIMED |
| AUD-D07-S1-002 | Appendix I | CLOSED_IN_R2_DESIGN_PASS_AUTHOR_SIDE_R2 | NOT_EXECUTED / NOT_CLAIMED |
| AUD-D07-S1-003 | §07 | CLOSED_IN_R2_DESIGN_PASS_AUTHOR_SIDE_R2 | NOT_EXECUTED / NOT_CLAIMED |
| AUD-D07-S1-004 | §07/§16 | CLOSED_IN_R2_DESIGN_PASS_AUTHOR_SIDE_R2 | NOT_EXECUTED / NOT_CLAIMED |
| AUD-D07-S1-005 | Appendix F | CLOSED_IN_R2_DESIGN_PASS_AUTHOR_SIDE_R2 | NOT_EXECUTED / NOT_CLAIMED |
| AUD-D07-S1-006 | §25 | CLOSED_IN_R2_DESIGN_PASS_AUTHOR_SIDE_R2 | NOT_EXECUTED / NOT_CLAIMED |
| AUD-D07-S1-007 | §12 | CLOSED_IN_R2_DESIGN_PASS_AUTHOR_SIDE_R2 | NOT_EXECUTED / NOT_CLAIMED |
| AUD-D07-S2-001 | §05 | CLOSED_IN_R2_DESIGN_PASS_AUTHOR_SIDE_R2 | NOT_EXECUTED / NOT_CLAIMED |
| AUD-D07-S2-002 | §19 | CLOSED_IN_R2_DESIGN_PASS_AUTHOR_SIDE_R2 | NOT_EXECUTED / NOT_CLAIMED |
| AUD-D07-S2-003 | §20 | CLOSED_IN_R2_DESIGN_PASS_AUTHOR_SIDE_R2 | NOT_EXECUTED / NOT_CLAIMED |
| AUD-D07-S2-004 | §21 | CLOSED_IN_R2_DESIGN_PASS_AUTHOR_SIDE_R2 | NOT_EXECUTED / NOT_CLAIMED |
| AUD-D07-S2-005 | §25 | CLOSED_IN_R2_DESIGN_PASS_AUTHOR_SIDE_R2 | NOT_EXECUTED / NOT_CLAIMED |
| AUD-D07-S2-006 | §25 | CLOSED_IN_R2_DESIGN_PASS_AUTHOR_SIDE_R2 | NOT_EXECUTED / NOT_CLAIMED |
| AUD-D07-S2-007 | §14 | CLOSED_IN_R2_DESIGN_PASS_AUTHOR_SIDE_R2 | NOT_EXECUTED / NOT_CLAIMED |
| AUD-D07-S2-008 | §28/Appendix F | CLOSED_IN_R2_DESIGN_PASS_AUTHOR_SIDE_R2 | NOT_EXECUTED / NOT_CLAIMED |
| AUD-D07-S2-009 | §28 | CLOSED_IN_R2_DESIGN_PASS_AUTHOR_SIDE_R2 | NOT_EXECUTED / NOT_CLAIMED |
| AUD-D07-S2-010 | §04/§05 | CLOSED_IN_R2_DESIGN_PASS_AUTHOR_SIDE_R2 | NOT_EXECUTED / NOT_CLAIMED |
| AUD-D07-S2-011 | Appendix G | CLOSED_IN_R2_DESIGN_PASS_AUTHOR_SIDE_R2 | NOT_EXECUTED / NOT_CLAIMED |
| AUD-D07-S2-012 | Appendix E | CLOSED_IN_R2_DESIGN_PASS_AUTHOR_SIDE_R2 | NOT_EXECUTED / NOT_CLAIMED |

The repair-controller findings are closed only at the **document design/materialization** level after Appendix E passes. Target-runtime, independent, human, release and production statuses remain outside this artifact.

# Appendix I｜`DOC07_SOURCE_COVERAGE_LEDGER` — Materialized Atomic Coverage

Denominator in this R2 ledger: `219` rows = 86 canonical requirement rows + 81 profile obligation rows + 35 production-instruction rows + 17 audit-gate rows. Technology/workflow source identities are independently enumerated 144+8 in Appendix F to avoid duplicate wide rows here.

| Source | Source anchor | Atomic ID | Atomic obligation | Owner | DOC-07 destination | Coverage kind | Disposition | Conflict | Verification |
|---|---|---|---|---|---|---|---|---|---|
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-979740C9 | STD-REQ-979740C9 | 1. Normative Language / 規範語言 | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-98F459F8 | STD-REQ-98F459F8 | 1. Normative Language / 規範語言 | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-E2082905 | STD-REQ-E2082905 | 1. Normative Language / 規範語言 | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-B1C9AB85 | STD-REQ-B1C9AB85 | P-01 Single Canonical Truth | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-B88A6D37 | STD-REQ-B88A6D37 | P-02 Source-Bound Intent Preservation | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-689DE502 | STD-REQ-689DE502 | P-03 Stable Semantics vs Late-Bound Facts | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-ABD8745E | STD-REQ-ABD8745E | P-05 No Execution by Documentation | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-C6A9781D | STD-REQ-C6A9781D | P-06 Claim Separation | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-79A6948B | STD-REQ-79A6948B | P-07 Evidence Is Subject-Bound | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-4AAA061A | STD-REQ-4AAA061A | P-09 Complexity Must Earn Complexity | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-0E1DBA46 | STD-REQ-0E1DBA46 | P-10 Handoff Must Be Rejectable | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-98BC2330 | STD-REQ-98BC2330 | P-11 Capability-Before-Brand / Search-Before-Build | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-DA5BCA25 | STD-REQ-DA5BCA25 | P-13 Tool Success ≠ World Effect | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-2A89F996 | STD-REQ-2A89F996 | P-14 Segregation of Duties | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-C5BCA382 | STD-REQ-C5BCA382 | P-15 Prose/Machine Gate Equivalence | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-B0C02A64 | STD-REQ-B0C02A64 | 5.2 Promotion Rule | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-E0C7F7A0 | STD-REQ-E0C7F7A0 | 6. Artifact Identity & Authority Model | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-81C86EBB | STD-REQ-81C86EBB | 6. Artifact Identity & Authority Model | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-C25BC6A2 | STD-REQ-C25BC6A2 | 6. Artifact Identity & Authority Model | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-E22A8F7D | STD-REQ-E22A8F7D | 6. Artifact Identity & Authority Model | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-FA7B1B7F | STD-REQ-FA7B1B7F | 6.1 Common Artifact Metadata Contract | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-11B19333 | STD-REQ-11B19333 | 6.2 Authority and Adapter Non-Override Rule | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-829B7605 | STD-REQ-829B7605 | 7.1 Purpose | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-7B3AB9E9 | STD-REQ-7B3AB9E9 | C-01 Project / Product Identity | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-454A6D90 | STD-REQ-454A6D90 | C-02 Authority Stack | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-5EFF0181 | STD-REQ-5EFF0181 | C-02 Authority Stack | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-6CCE644F | STD-REQ-6CCE644F | C-03 Canonical Ownership | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-119B9088 | STD-REQ-119B9088 | C-04 Lifecycle States | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-EEC45EC3 | STD-REQ-EEC45EC3 | C-05 Claim Rules | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-0CB9A2A0 | STD-REQ-0CB9A2A0 | C-09 Tailoring Profile | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-DD50D72A | STD-REQ-DD50D72A | C-10 Definition of Pre-Execution Complete | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-59D1DD6F | STD-REQ-59D1DD6F | C-11 Standard Namespace / Schema Compatibility | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-9E161B60 | STD-REQ-9E161B60 | C-11 Standard Namespace / Schema Compatibility | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-10C6C743 | STD-REQ-10C6C743 | C-12 DomainProfileExtension | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-90364E5B | STD-REQ-90364E5B | C-12 DomainProfileExtension | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-D28A8B60 | STD-REQ-D28A8B60 | C-14 Security Threat Model | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-ABE182D6 | STD-REQ-ABE182D6 | 8. PI-PKG Canonical Purpose | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-9E4AFAC1 | STD-REQ-9E4AFAC1 | 8. PI-PKG Canonical Purpose | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-5868D53A | STD-REQ-5868D53A | 9. PI-PKG Required Contract Areas | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-27A2EA7F | STD-REQ-27A2EA7F | PI-05 Atomic Requirements | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-522701F0 | STD-REQ-522701F0 | PI-08.1 Mandatory Search-Before-Build algorithm | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-E6CD4BED | STD-REQ-E6CD4BED | PI-08.2 TechnologyAdmissionRecord | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-06583027 | STD-REQ-06583027 | PI-10 SPEC | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-C49B66DE | STD-REQ-C49B66DE | PI-11 Acceptance | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-B4D1C8EA | STD-REQ-B4D1C8EA | PI-12 Verification / Oracle | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-5E28F98D | STD-REQ-5E28F98D | PI-13 Evidence Expectation | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-5AADF6A3 | STD-REQ-5AADF6A3 | PI-14 Deliverables | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-6E714CAB | STD-REQ-6E714CAB | PI-17 Claim Ceiling / State Truth | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-C887276E | STD-REQ-C887276E | PI-18 Pre-Dev Handoff | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-8A8EDC94 | STD-REQ-8A8EDC94 | 10. Requirement Narrow Waist | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-F8221F9F | STD-REQ-F8221F9F | 12. PI_READY Gate | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-92132DB3 | STD-REQ-92132DB3 | 13. PD-PKG Canonical Purpose | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-DDF22230 | STD-REQ-DDF22230 | 14. PD-PKG Required Structure | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-F4F1DD9D | STD-REQ-F4F1DD9D | PD-04 Late-Bound Resolution | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-BA1FB472 | STD-REQ-BA1FB472 | PD-05 S2E — Spec-to-Execution | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-7468B275 | STD-REQ-7468B275 | PD-05 S2E — Spec-to-Execution | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-7CEA782A | STD-REQ-7CEA782A | PD-05A TaskSpecSeed | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-93766574 | STD-REQ-93766574 | PD-05B WorkOrder Materialization | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-1859D4F5 | STD-REQ-1859D4F5 | PD-06 DEV ECP — Development Execution Control | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-2FF7F879 | STD-REQ-2FF7F879 | PD-06 DEV ECP — Development Execution Control | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-9DF08F85 | STD-REQ-9DF08F85 | PD-07 OPS ECP — Operations Readiness & Execution Control | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-61E2C648 | STD-REQ-61E2C648 | PD-08 TQAEP — Test / Qualification / Acceptance / Evidence Plan | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-6E492151 | STD-REQ-6E492151 | PD-08 TQAEP — Test / Qualification / Acceptance / Evidence Plan | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-75B304BB | STD-REQ-75B304BB | PD-10 Execution Admission | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-FA8009D5 | STD-REQ-FA8009D5 | 17. EXECUTION_ADMITTED Gate | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-38EB8516 | STD-REQ-38EB8516 | 18.1 Extraction Manifest | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-59414E50 | STD-REQ-59414E50 | 18.3 Deterministic Conformance Reference Command | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-F4669FFF | STD-REQ-F4669FFF | 18.4 Destructive Fixtures Required by the Standard | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-28163C14 | STD-REQ-28163C14 | 20.4 Machine Profile Binding | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-3235004D | STD-REQ-3235004D | 21.2 BrownfieldMigrationProfile | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-3CA02A9C | STD-REQ-3CA02A9C | 22. Target Profile — SKILL / PLUGIN | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-BF0442B3 | STD-REQ-BF0442B3 | 22. Target Profile — SKILL / PLUGIN | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-B5C7D219 | STD-REQ-B5C7D219 | 22.1 Skill/Plugin Conformance Additions | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-0B4D6B1E | STD-REQ-0B4D6B1E | 23. Target Profile — Agent Harness / Agentic Runtime | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-0C5B13B3 | STD-REQ-0C5B13B3 | 23. Target Profile — Agent Harness / Agentic Runtime | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-2E59E411 | STD-REQ-2E59E411 | 23A. World Effect / Observation / Readback / Reconciliation | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-D4FB7180 | STD-REQ-D4FB7180 | 24. Receiver Handoff Contract | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-22E53BD2 | STD-REQ-22E53BD2 | 25. Evidence Return Contract | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-7894BFB5 | STD-REQ-7894BFB5 | 26.2 External Content Is Data | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-86CAC54E | STD-REQ-86CAC54E | 26.4 Agent Memory | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-7CD1E5E6 | STD-REQ-7CD1E5E6 | 26.7 SoD Enforcement | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-37150A4D | STD-REQ-37150A4D | 28. Canonical Standard vs Adapter | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-97BCACAC | STD-REQ-97BCACAC | 32. Mandatory Conformance Test Registry | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-E6580324 | STD-REQ-E6580324 | 46A. Informative Technology & Workflow Registry — Named Anti-Downgrade Baseline | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-6F8DCD42 | STD-REQ-6F8DCD42 | 47. External Alignment / Informative Research Notes | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A1_BLUEPRINT | A1 canonical normative ledger::STD-REQ-44B56684 | STD-REQ-44B56684 | 50. Final Normative Statement | DOC-07 direct consumer / canonical requirement owner retained | Appendix A + Appendix G requirement_bindings/tests/oracles | SUBSTANTIVE_BODY | PRESERVE_EXACT_TUPLE | NONE | R2-G01 exact tuple equality |
| A3_SKELETON | A3 #13.2::SYS-PI-01 | SYS-PI-01 | Product/user outcome | DOC-07 conformance / DOC-06 profile semantics | #19 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-SYS-PI-01 / OR-D07-SYS-PI-01 / P+N fixtures |
| A3_SKELETON | A3 #13.2::SYS-PI-02 | SYS-PI-02 | Domain model | DOC-07 conformance / DOC-06 profile semantics | #19 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-SYS-PI-02 / OR-D07-SYS-PI-02 / P+N fixtures |
| A3_SKELETON | A3 #13.2::SYS-PI-03 | SYS-PI-03 | Architecture | DOC-07 conformance / DOC-06 profile semantics | #19 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-SYS-PI-03 / OR-D07-SYS-PI-03 / P+N fixtures |
| A3_SKELETON | A3 #13.2::SYS-PI-04 | SYS-PI-04 | API contracts | DOC-07 conformance / DOC-06 profile semantics | #19 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-SYS-PI-04 / OR-D07-SYS-PI-04 / P+N fixtures |
| A3_SKELETON | A3 #13.2::SYS-PI-05 | SYS-PI-05 | Data contracts | DOC-07 conformance / DOC-06 profile semantics | #19 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-SYS-PI-05 / OR-D07-SYS-PI-05 / P+N fixtures |
| A3_SKELETON | A3 #13.2::SYS-PI-06 | SYS-PI-06 | SLO/NFR | DOC-07 conformance / DOC-06 profile semantics | #19 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-SYS-PI-06 / OR-D07-SYS-PI-06 / P+N fixtures |
| A3_SKELETON | A3 #13.2::SYS-PI-07 | SYS-PI-07 | Security/privacy | DOC-07 conformance / DOC-06 profile semantics | #19 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-SYS-PI-07 / OR-D07-SYS-PI-07 / P+N fixtures |
| A3_SKELETON | A3 #13.2::SYS-PI-08 | SYS-PI-08 | Migration/backcompat | DOC-07 conformance / DOC-06 profile semantics | #19 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-SYS-PI-08 / OR-D07-SYS-PI-08 / P+N fixtures |
| A3_SKELETON | A3 #13.2::SYS-PI-09 | SYS-PI-09 | Acceptance/testability | DOC-07 conformance / DOC-06 profile semantics | #19 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-SYS-PI-09 / OR-D07-SYS-PI-09 / P+N fixtures |
| A3_SKELETON | A3 #13.2::SYS-PI-10 | SYS-PI-10 | Operability intent | DOC-07 conformance / DOC-06 profile semantics | #19 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-SYS-PI-10 / OR-D07-SYS-PI-10 / P+N fixtures |
| A3_SKELETON | A3 #13.2::SYS-PD-01 | SYS-PD-01 | RepoContext | DOC-07 conformance / DOC-06 profile semantics | #19 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-SYS-PD-01 / OR-D07-SYS-PD-01 / P+N fixtures |
| A3_SKELETON | A3 #13.2::SYS-PD-02 | SYS-PD-02 | Toolchain | DOC-07 conformance / DOC-06 profile semantics | #19 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-SYS-PD-02 / OR-D07-SYS-PD-02 / P+N fixtures |
| A3_SKELETON | A3 #13.2::SYS-PD-03 | SYS-PD-03 | DB/data migration | DOC-07 conformance / DOC-06 profile semantics | #19 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-SYS-PD-03 / OR-D07-SYS-PD-03 / P+N fixtures |
| A3_SKELETON | A3 #13.2::SYS-PD-04 | SYS-PD-04 | CI | DOC-07 conformance / DOC-06 profile semantics | #19 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-SYS-PD-04 / OR-D07-SYS-PD-04 / P+N fixtures |
| A3_SKELETON | A3 #13.2::SYS-PD-05 | SYS-PD-05 | Deployment topology | DOC-07 conformance / DOC-06 profile semantics | #19 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-SYS-PD-05 / OR-D07-SYS-PD-05 / P+N fixtures |
| A3_SKELETON | A3 #13.2::SYS-PD-06 | SYS-PD-06 | Observability | DOC-07 conformance / DOC-06 profile semantics | #19 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-SYS-PD-06 / OR-D07-SYS-PD-06 / P+N fixtures |
| A3_SKELETON | A3 #13.2::SYS-PD-07 | SYS-PD-07 | Environment config | DOC-07 conformance / DOC-06 profile semantics | #19 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-SYS-PD-07 / OR-D07-SYS-PD-07 / P+N fixtures |
| A3_SKELETON | A3 #13.2::SYS-PD-08 | SYS-PD-08 | Rollback/provider-off | DOC-07 conformance / DOC-06 profile semantics | #19 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-SYS-PD-08 / OR-D07-SYS-PD-08 / P+N fixtures |
| A3_SKELETON | A3 #13.2::SYS-PD-09 | SYS-PD-09 | SLO instrumentation | DOC-07 conformance / DOC-06 profile semantics | #19 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-SYS-PD-09 / OR-D07-SYS-PD-09 / P+N fixtures |
| A3_SKELETON | A3 #13.2::SYS-PD-10 | SYS-PD-10 | Incident/runbook | DOC-07 conformance / DOC-06 profile semantics | #19 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-SYS-PD-10 / OR-D07-SYS-PD-10 / P+N fixtures |
| A3_SKELETON | A3 #13.2::SYS-PD-11 | SYS-PD-11 | DR/RTO/RPO | DOC-07 conformance / DOC-06 profile semantics | #19 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-SYS-PD-11 / OR-D07-SYS-PD-11 / P+N fixtures |
| A3_SKELETON | A3 #13.2::SYS-PD-12 | SYS-PD-12 | Capacity/cost/FinOps | DOC-07 conformance / DOC-06 profile semantics | #19 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-SYS-PD-12 / OR-D07-SYS-PD-12 / P+N fixtures |
| A3_SKELETON | A3 #13.2::SYS-PD-13 | SYS-PD-13 | Secret revoke/rotation | DOC-07 conformance / DOC-06 profile semantics | #19 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-SYS-PD-13 / OR-D07-SYS-PD-13 / P+N fixtures |
| A3_SKELETON | A3 #13.3::SK-PI-01 | SK-PI-01 | Trigger | DOC-07 conformance / DOC-06 profile semantics | #20 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-SK-PI-01 / OR-D07-SK-PI-01 / P+N fixtures |
| A3_SKELETON | A3 #13.3::SK-PI-02 | SK-PI-02 | Non-trigger | DOC-07 conformance / DOC-06 profile semantics | #20 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-SK-PI-02 / OR-D07-SK-PI-02 / P+N fixtures |
| A3_SKELETON | A3 #13.3::SK-PI-03 | SK-PI-03 | Inputs | DOC-07 conformance / DOC-06 profile semantics | #20 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-SK-PI-03 / OR-D07-SK-PI-03 / P+N fixtures |
| A3_SKELETON | A3 #13.3::SK-PI-04 | SK-PI-04 | Outputs | DOC-07 conformance / DOC-06 profile semantics | #20 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-SK-PI-04 / OR-D07-SK-PI-04 / P+N fixtures |
| A3_SKELETON | A3 #13.3::SK-PI-05 | SK-PI-05 | Allowed tools | DOC-07 conformance / DOC-06 profile semantics | #20 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-SK-PI-05 / OR-D07-SK-PI-05 / P+N fixtures |
| A3_SKELETON | A3 #13.3::SK-PI-06 | SK-PI-06 | Permission classes | DOC-07 conformance / DOC-06 profile semantics | #20 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-SK-PI-06 / OR-D07-SK-PI-06 / P+N fixtures |
| A3_SKELETON | A3 #13.3::SK-PI-07 | SK-PI-07 | Compatibility | DOC-07 conformance / DOC-06 profile semantics | #20 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-SK-PI-07 / OR-D07-SK-PI-07 / P+N fixtures |
| A3_SKELETON | A3 #13.3::SK-PI-08 | SK-PI-08 | Dependencies | DOC-07 conformance / DOC-06 profile semantics | #20 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-SK-PI-08 / OR-D07-SK-PI-08 / P+N fixtures |
| A3_SKELETON | A3 #13.3::SK-PI-09 | SK-PI-09 | Side-effect classes | DOC-07 conformance / DOC-06 profile semantics | #20 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-SK-PI-09 / OR-D07-SK-PI-09 / P+N fixtures |
| A3_SKELETON | A3 #13.3::SK-PI-10 | SK-PI-10 | Secret/network policy | DOC-07 conformance / DOC-06 profile semantics | #20 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-SK-PI-10 / OR-D07-SK-PI-10 / P+N fixtures |
| A3_SKELETON | A3 #13.3::SK-PI-11 | SK-PI-11 | Failure behavior | DOC-07 conformance / DOC-06 profile semantics | #20 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-SK-PI-11 / OR-D07-SK-PI-11 / P+N fixtures |
| A3_SKELETON | A3 #13.3::SK-PI-12 | SK-PI-12 | Negative cases | DOC-07 conformance / DOC-06 profile semantics | #20 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-SK-PI-12 / OR-D07-SK-PI-12 / P+N fixtures |
| A3_SKELETON | A3 #13.3::SK-PI-13 | SK-PI-13 | Examples | DOC-07 conformance / DOC-06 profile semantics | #20 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-SK-PI-13 / OR-D07-SK-PI-13 / P+N fixtures |
| A3_SKELETON | A3 #13.3::SK-PI-14 | SK-PI-14 | Host boundary | DOC-07 conformance / DOC-06 profile semantics | #20 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-SK-PI-14 / OR-D07-SK-PI-14 / P+N fixtures |
| A3_SKELETON | A3 #13.3::SK-PI-15 | SK-PI-15 | Host assumptions | DOC-07 conformance / DOC-06 profile semantics | #20 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-SK-PI-15 / OR-D07-SK-PI-15 / P+N fixtures |
| A3_SKELETON | A3 #13.3::SK-PI-16 | SK-PI-16 | Dependency/rights provenance | DOC-07 conformance / DOC-06 profile semantics | #20 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-SK-PI-16 / OR-D07-SK-PI-16 / P+N fixtures |
| A3_SKELETON | A3 #13.3::SK-PI-17 | SK-PI-17 | Uninstall/disable semantics | DOC-07 conformance / DOC-06 profile semantics | #20 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-SK-PI-17 / OR-D07-SK-PI-17 / P+N fixtures |
| A3_SKELETON | A3 #13.3::SK-PI-18 | SK-PI-18 | Evidence return | DOC-07 conformance / DOC-06 profile semantics | #20 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-SK-PI-18 / OR-D07-SK-PI-18 / P+N fixtures |
| A3_SKELETON | A3 #13.3::SK-PD-01 | SK-PD-01 | Exact host/runtime/package versions | DOC-07 conformance / DOC-03 late-bound facts | #20 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-SK-PD-01 / OR-D07-SK-PD-01 / P+N fixtures |
| A3_SKELETON | A3 #13.3::SK-PD-02 | SK-PD-02 | Install/publish layout | DOC-07 conformance / DOC-03 late-bound facts | #20 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-SK-PD-02 / OR-D07-SK-PD-02 / P+N fixtures |
| A3_SKELETON | A3 #13.3::SK-PD-03 | SK-PD-03 | Dependency lock | DOC-07 conformance / DOC-03 late-bound facts | #20 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-SK-PD-03 / OR-D07-SK-PD-03 / P+N fixtures |
| A3_SKELETON | A3 #13.3::SK-PD-04 | SK-PD-04 | Sandbox | DOC-07 conformance / DOC-03 late-bound facts | #20 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-SK-PD-04 / OR-D07-SK-PD-04 / P+N fixtures |
| A3_SKELETON | A3 #13.3::SK-PD-05 | SK-PD-05 | Credential handles metadata | DOC-07 conformance / DOC-03 late-bound facts | #20 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-SK-PD-05 / OR-D07-SK-PD-05 / P+N fixtures |
| A3_SKELETON | A3 #13.3::SK-PD-06 | SK-PD-06 | Network boundary | DOC-07 conformance / DOC-03 late-bound facts | #20 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-SK-PD-06 / OR-D07-SK-PD-06 / P+N fixtures |
| A3_SKELETON | A3 #13.3::SK-PD-07 | SK-PD-07 | Validation | DOC-07 conformance / DOC-03 late-bound facts | #20 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-SK-PD-07 / OR-D07-SK-PD-07 / P+N fixtures |
| A3_SKELETON | A3 #13.3::SK-PD-08 | SK-PD-08 | Uninstall/rollback | DOC-07 conformance / DOC-03 late-bound facts | #20 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-SK-PD-08 / OR-D07-SK-PD-08 / P+N fixtures |
| A3_SKELETON | A3 #13.3::SK-PD-09 | SK-PD-09 | Residue check | DOC-07 conformance / DOC-03 late-bound facts | #20 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-SK-PD-09 / OR-D07-SK-PD-09 / P+N fixtures |
| A3_SKELETON | A3 #13.3::SK-PD-10 | SK-PD-10 | Host-specific permissions | DOC-07 conformance / DOC-03 late-bound facts | #20 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-SK-PD-10 / OR-D07-SK-PD-10 / P+N fixtures |
| A3_SKELETON | A3 #13.3::SK-PD-11 | SK-PD-11 | Exact tool schema | DOC-07 conformance / DOC-03 late-bound facts | #20 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-SK-PD-11 / OR-D07-SK-PD-11 / P+N fixtures |
| A3_SKELETON | A3 #13.3::SK-PD-12 | SK-PD-12 | Currentness TTL | DOC-07 conformance / DOC-03 late-bound facts | #20 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-SK-PD-12 / OR-D07-SK-PD-12 / P+N fixtures |
| A3_SKELETON | A3 #13.4::AH-PI-01 | AH-PI-01 | identity/role | DOC-07 conformance / DOC-06 profile semantics | #21 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-AH-PI-01 / OR-D07-AH-PI-01 / P+N fixtures |
| A3_SKELETON | A3 #13.4::AH-PI-02 | AH-PI-02 | execution loop | DOC-07 conformance / DOC-06 profile semantics | #21 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-AH-PI-02 / OR-D07-AH-PI-02 / P+N fixtures |
| A3_SKELETON | A3 #13.4::AH-PI-03 | AH-PI-03 | tool registry | DOC-07 conformance / DOC-06 profile semantics | #21 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-AH-PI-03 / OR-D07-AH-PI-03 / P+N fixtures |
| A3_SKELETON | A3 #13.4::AH-PI-04 | AH-PI-04 | context policy | DOC-07 conformance / DOC-06 profile semantics | #21 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-AH-PI-04 / OR-D07-AH-PI-04 / P+N fixtures |
| A3_SKELETON | A3 #13.4::AH-PI-05 | AH-PI-05 | state/memory | DOC-07 conformance / DOC-06 profile semantics | #21 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-AH-PI-05 / OR-D07-AH-PI-05 / P+N fixtures |
| A3_SKELETON | A3 #13.4::AH-PI-06 | AH-PI-06 | lifecycle hooks | DOC-07 conformance / DOC-06 profile semantics | #21 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-AH-PI-06 / OR-D07-AH-PI-06 / P+N fixtures |
| A3_SKELETON | A3 #13.4::AH-PI-07 | AH-PI-07 | permission/identity | DOC-07 conformance / DOC-06 profile semantics | #21 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-AH-PI-07 / OR-D07-AH-PI-07 / P+N fixtures |
| A3_SKELETON | A3 #13.4::AH-PI-08 | AH-PI-08 | handoff | DOC-07 conformance / DOC-06 profile semantics | #21 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-AH-PI-08 / OR-D07-AH-PI-08 / P+N fixtures |
| A3_SKELETON | A3 #13.4::AH-PI-09 | AH-PI-09 | guardrails | DOC-07 conformance / DOC-06 profile semantics | #21 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-AH-PI-09 / OR-D07-AH-PI-09 / P+N fixtures |
| A3_SKELETON | A3 #13.4::AH-PI-10 | AH-PI-10 | eval interface | DOC-07 conformance / DOC-06 profile semantics | #21 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-AH-PI-10 / OR-D07-AH-PI-10 / P+N fixtures |
| A3_SKELETON | A3 #13.4::AH-PI-11 | AH-PI-11 | observability | DOC-07 conformance / DOC-06 profile semantics | #21 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-AH-PI-11 / OR-D07-AH-PI-11 / P+N fixtures |
| A3_SKELETON | A3 #13.4::AH-PI-12 | AH-PI-12 | recovery/checkpoint | DOC-07 conformance / DOC-06 profile semantics | #21 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-AH-PI-12 / OR-D07-AH-PI-12 / P+N fixtures |
| A3_SKELETON | A3 #13.4::AH-PI-13 | AH-PI-13 | human escalation | DOC-07 conformance / DOC-06 profile semantics | #21 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-AH-PI-13 / OR-D07-AH-PI-13 / P+N fixtures |
| A3_SKELETON | A3 #13.4::AH-PI-14 | AH-PI-14 | interop boundaries | DOC-07 conformance / DOC-06 profile semantics | #21 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-AH-PI-14 / OR-D07-AH-PI-14 / P+N fixtures |
| A3_SKELETON | A3 #13.4::AH-PI-15 | AH-PI-15 | provider-neutral seam | DOC-07 conformance / DOC-06 profile semantics | #21 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-AH-PI-15 / OR-D07-AH-PI-15 / P+N fixtures |
| A3_SKELETON | A3 #13.4::AH-PD-01 | AH-PD-01 | runtime/framework version | DOC-07 conformance / DOC-03 late-bound facts | #21 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-AH-PD-01 / OR-D07-AH-PD-01 / P+N fixtures |
| A3_SKELETON | A3 #13.4::AH-PD-02 | AH-PD-02 | model/provider | DOC-07 conformance / DOC-03 late-bound facts | #21 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-AH-PD-02 / OR-D07-AH-PD-02 / P+N fixtures |
| A3_SKELETON | A3 #13.4::AH-PD-03 | AH-PD-03 | MCP version/profile | DOC-07 conformance / DOC-03 late-bound facts | #21 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-AH-PD-03 / OR-D07-AH-PD-03 / P+N fixtures |
| A3_SKELETON | A3 #13.4::AH-PD-04 | AH-PD-04 | A2A version/profile | DOC-07 conformance / DOC-03 late-bound facts | #21 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-AH-PD-04 / OR-D07-AH-PD-04 / P+N fixtures |
| A3_SKELETON | A3 #13.4::AH-PD-05 | AH-PD-05 | sandbox/container | DOC-07 conformance / DOC-03 late-bound facts | #21 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-AH-PD-05 / OR-D07-AH-PD-05 / P+N fixtures |
| A3_SKELETON | A3 #13.4::AH-PD-06 | AH-PD-06 | state backend | DOC-07 conformance / DOC-03 late-bound facts | #21 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-AH-PD-06 / OR-D07-AH-PD-06 / P+N fixtures |
| A3_SKELETON | A3 #13.4::AH-PD-07 | AH-PD-07 | memory store | DOC-07 conformance / DOC-03 late-bound facts | #21 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-AH-PD-07 / OR-D07-AH-PD-07 / P+N fixtures |
| A3_SKELETON | A3 #13.4::AH-PD-08 | AH-PD-08 | tracing backend | DOC-07 conformance / DOC-03 late-bound facts | #21 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-AH-PD-08 / OR-D07-AH-PD-08 / P+N fixtures |
| A3_SKELETON | A3 #13.4::AH-PD-09 | AH-PD-09 | secret handles | DOC-07 conformance / DOC-03 late-bound facts | #21 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-AH-PD-09 / OR-D07-AH-PD-09 / P+N fixtures |
| A3_SKELETON | A3 #13.4::AH-PD-10 | AH-PD-10 | tool schemas | DOC-07 conformance / DOC-03 late-bound facts | #21 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-AH-PD-10 / OR-D07-AH-PD-10 / P+N fixtures |
| A3_SKELETON | A3 #13.4::AH-PD-11 | AH-PD-11 | timeouts/retry/checkpoint | DOC-07 conformance / DOC-03 late-bound facts | #21 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-AH-PD-11 / OR-D07-AH-PD-11 / P+N fixtures |
| A3_SKELETON | A3 #13.4::AH-PD-12 | AH-PD-12 | eval harness | DOC-07 conformance / DOC-03 late-bound facts | #21 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-AH-PD-12 / OR-D07-AH-PD-12 / P+N fixtures |
| A3_SKELETON | A3 #13.4::AH-PD-13 | AH-PD-13 | deployment environment | DOC-07 conformance / DOC-03 late-bound facts | #21 + Appendix G | SUBSTANTIVE_BODY | MATERIALIZED_TEST_ORACLE_FIXTURES | NONE | TEST-D07-AH-PD-13 / OR-D07-AH-PD-13 / P+N fixtures |
| PRODUCTION_INSTRUCTION | INSTR#1 | PI-D07-001 | Produce single DOC-07 full substantive body; no prompt/skeleton output | DOC-07 production task | #00-#32 | SUBSTANTIVE_BODY | MATERIALIZED | NONE | Appendix E self-check + manual structural readback |
| PRODUCTION_INSTRUCTION | INSTR#2 | PI-D07-002 | Respect authority order; no lower-source overwrite | DOC-07 production task | #02 | SUBSTANTIVE_BODY | MATERIALIZED | NONE | Appendix E self-check + manual structural readback |
| PRODUCTION_INSTRUCTION | INSTR#3 | PI-D07-003 | Full-corpus/no-sampling processing with auditable coverage ledger | DOC-07 production task | #02 + Appendix I | SUBSTANTIVE_BODY | MATERIALIZED | NONE | Appendix E self-check + manual structural readback |
| PRODUCTION_INSTRUCTION | INSTR#4 | PI-D07-004 | Execute SOP index→substantive clause→keyword→cross-verify→atomicize→substantive judgment | DOC-07 production task | #02 + Appendix I | SUBSTANTIVE_BODY | MATERIALIZED | NONE | Appendix E self-check + manual structural readback |
| PRODUCTION_INSTRUCTION | INSTR#5 | PI-D07-005 | Coverage ledger closes only with substantive body | DOC-07 production task | #02 + Appendix I | SUBSTANTIVE_BODY | MATERIALIZED | NONE | Appendix E self-check + manual structural readback |
| PRODUCTION_INSTRUCTION | INSTR#6 | PI-D07-006 | Preserve sibling-DOC writer boundaries | DOC-07 production task | #29 | SUBSTANTIVE_BODY | MATERIALIZED | NONE | Appendix E self-check + manual structural readback |
| PRODUCTION_INSTRUCTION | INSTR#7 | PI-D07-007 | Align DOC-00 without template cloning | DOC-07 production task | #29 | SUBSTANTIVE_BODY | MATERIALIZED | NONE | Appendix E self-check + manual structural readback |
| PRODUCTION_INSTRUCTION | INSTR#8.1 | PI-D07-008 | Artifact identity/legal role/claim boundary | DOC-07 production task | #00 | SUBSTANTIVE_BODY | MATERIALIZED | NONE | Appendix E self-check + manual structural readback |
| PRODUCTION_INSTRUCTION | INSTR#8.2 | PI-D07-009 | Verification object model | DOC-07 production task | #03 | SUBSTANTIVE_BODY | MATERIALIZED | NONE | Appendix E self-check + manual structural readback |
| PRODUCTION_INSTRUCTION | INSTR#8.3 | PI-D07-010 | Stable TEST/ORACLE identity | DOC-07 production task | #09 + Appendix A | SUBSTANTIVE_BODY | MATERIALIZED | NONE | Appendix E self-check + manual structural readback |
| PRODUCTION_INSTRUCTION | INSTR#8.4 | PI-D07-011 | Fixture taxonomy | DOC-07 production task | #04-#05 | SUBSTANTIVE_BODY | MATERIALIZED | NONE | Appendix E self-check + manual structural readback |
| PRODUCTION_INSTRUCTION | INSTR#8.5 | PI-D07-012 | Canonical destructive fixture baseline | DOC-07 production task | #10-#11 | SUBSTANTIVE_BODY | MATERIALIZED | NONE | Appendix E self-check + manual structural readback |
| PRODUCTION_INSTRUCTION | INSTR#8.6 | PI-D07-013 | Oracle contract / FFI | DOC-07 production task | #06 | SUBSTANTIVE_BODY | MATERIALIZED | NONE | Appendix E self-check + manual structural readback |
| PRODUCTION_INSTRUCTION | INSTR#8.7 | PI-D07-014 | Deterministic validator contract | DOC-07 production task | #07 | SUBSTANTIVE_BODY | MATERIALIZED | NONE | Appendix E self-check + manual structural readback |
| PRODUCTION_INSTRUCTION | INSTR#8.8 | PI-D07-015 | Conformance report schema | DOC-07 production task | #08 | SUBSTANTIVE_BODY | MATERIALIZED | NONE | Appendix E self-check + manual structural readback |
| PRODUCTION_INSTRUCTION | INSTR#8.9 | PI-D07-016 | Requirement→Test→Oracle binding | DOC-07 production task | #12 + Appendix A | SUBSTANTIVE_BODY | MATERIALIZED | NONE | Appendix E self-check + manual structural readback |
| PRODUCTION_INSTRUCTION | INSTR#8.10 | PI-D07-017 | Subject/version/hash/environment binding | DOC-07 production task | #13 | SUBSTANTIVE_BODY | MATERIALIZED | NONE | Appendix E self-check + manual structural readback |
| PRODUCTION_INSTRUCTION | INSTR#8.11 | PI-D07-018 | Permission/admission/SoD verification | DOC-07 production task | #15 | SUBSTANTIVE_BODY | MATERIALIZED | NONE | Appendix E self-check + manual structural readback |
| PRODUCTION_INSTRUCTION | INSTR#8.12 | PI-D07-019 | World effect/readback/reconciliation | DOC-07 production task | #16 + #07 effect closure | SUBSTANTIVE_BODY | MATERIALIZED | NONE | Appendix E self-check + manual structural readback |
| PRODUCTION_INSTRUCTION | INSTR#8.13 | PI-D07-020 | Currentness/drift/requalification | DOC-07 production task | #14 | SUBSTANTIVE_BODY | MATERIALIZED | NONE | Appendix E self-check + manual structural readback |
| PRODUCTION_INSTRUCTION | INSTR#8.14 | PI-D07-021 | Profile-specific conformance | DOC-07 production task | #18-#23 | SUBSTANTIVE_BODY | MATERIALIZED | NONE | Appendix E self-check + manual structural readback |
| PRODUCTION_INSTRUCTION | INSTR#8.15 | PI-D07-022 | Skill/Plugin conformance | DOC-07 production task | #20 | SUBSTANTIVE_BODY | MATERIALIZED | NONE | Appendix E self-check + manual structural readback |
| PRODUCTION_INSTRUCTION | INSTR#8.16 | PI-D07-023 | Agent Harness conformance | DOC-07 production task | #21 | SUBSTANTIVE_BODY | MATERIALIZED | NONE | Appendix E self-check + manual structural readback |
| PRODUCTION_INSTRUCTION | INSTR#8.17 | PI-D07-024 | Brownfield/migration conformance | DOC-07 production task | #22 | SUBSTANTIVE_BODY | MATERIALIZED | NONE | Appendix E self-check + manual structural readback |
| PRODUCTION_INSTRUCTION | INSTR#8.18 | PI-D07-025 | Portability conformance | DOC-07 production task | #26 | SUBSTANTIVE_BODY | MATERIALIZED | NONE | Appendix E self-check + manual structural readback |
| PRODUCTION_INSTRUCTION | INSTR#9 | PI-D07-026 | No template semantic homogenization | DOC-07 production task | #25 | SUBSTANTIVE_BODY | MATERIALIZED | NONE | Appendix E self-check + manual structural readback |
| PRODUCTION_INSTRUCTION | INSTR#10-11 | PI-D07-027 | Terminal technology decisions + TechnologyLandingContract + anti-degradation | DOC-07 production task | #24-#25 + Appendix F | SUBSTANTIVE_BODY | MATERIALIZED | NONE | Appendix E self-check + manual structural readback |
| PRODUCTION_INSTRUCTION | INSTR#12-13 | PI-D07-028 | 2026 currentness/search-before-build/tooling research boundary | DOC-07 production task | #14 + Appendix D | SUBSTANTIVE_BODY | MATERIALIZED | NONE | Appendix E self-check + manual structural readback |
| PRODUCTION_INSTRUCTION | INSTR#14-16 | PI-D07-029 | Translate/compress/final acceptance/functional verification/claim boundaries | DOC-07 production task | #24-#32 | SUBSTANTIVE_BODY | MATERIALIZED | NONE | Appendix E self-check + manual structural readback |
| PRODUCTION_INSTRUCTION | INSTR#17 | PI-D07-030 | Security/injection boundary | DOC-07 production task | #17 | SUBSTANTIVE_BODY | MATERIALIZED | NONE | Appendix E self-check + manual structural readback |
| PRODUCTION_INSTRUCTION | INSTR#18-20 | PI-D07-031 | H1 depth/no silent rewrite/no mega-prompt body | DOC-07 production task | #00-#32 | SUBSTANTIVE_BODY | MATERIALIZED | NONE | Appendix E self-check + manual structural readback |
| PRODUCTION_INSTRUCTION | INSTR#21 | PI-D07-032 | Worked examples A-G | DOC-07 production task | #31 | SUBSTANTIVE_BODY | MATERIALIZED | NONE | Appendix E self-check + manual structural readback |
| PRODUCTION_INSTRUCTION | INSTR#23 | PI-D07-033 | Mandatory self-audit with auditable results | DOC-07 production task | Appendix E | SUBSTANTIVE_BODY | MATERIALIZED | NONE | Appendix E self-check + manual structural readback |
| PRODUCTION_INSTRUCTION | INSTR#24 | PI-D07-034 | Definition of Done | DOC-07 production task | #32 | SUBSTANTIVE_BODY | MATERIALIZED | NONE | Appendix E self-check + manual structural readback |
| PRODUCTION_INSTRUCTION | INSTR#25-27 | PI-D07-035 | Single MD, metadata, readback/hash, concise final delivery | DOC-07 production task | #00 + Appendix E | SUBSTANTIVE_BODY | MATERIALIZED | NONE | Appendix E self-check + manual structural readback |
| AUDIT_CONTROLLER | AUDIT #13::R2-G01 | R2-G01 | 86/86 exact tuple equality; mismatch=0 | R2 repair controller | Appendix A + Appendix E | SUBSTANTIVE_BODY | REPAIR_CLOSED_IN_R2_DESIGN | NONE | Appendix E deterministic checker |
| AUDIT_CONTROLLER | AUDIT #13::R2-G02 | R2-G02 | compound destructive requirements complete child fixture set | R2 repair controller | #05/#10/#11 + machine catalog | SUBSTANTIVE_BODY | REPAIR_CLOSED_IN_R2_DESIGN | NONE | Appendix E deterministic checker |
| AUDIT_CONTROLLER | AUDIT #13::R2-G03 | R2-G03 | source→atomic requirement→DOC destination ledger materialized | R2 repair controller | Appendix I | SUBSTANTIVE_BODY | REPAIR_CLOSED_IN_R2_DESIGN | NONE | Appendix E deterministic checker |
| AUDIT_CONTROLLER | AUDIT #13::R2-G04 | R2-G04 | A1 validator/orchestrator is operational truth | R2 repair controller | #07 | SUBSTANTIVE_BODY | REPAIR_CLOSED_IN_R2_DESIGN | NONE | Appendix E deterministic checker |
| AUDIT_CONTROLLER | AUDIT #13::R2-G05 | R2-G05 | A2 --profile compatibility explicitly implemented or locally removed | R2 repair controller | #07 | SUBSTANTIVE_BODY | REPAIR_CLOSED_IN_R2_DESIGN | NONE | Appendix E deterministic checker |
| AUDIT_CONTROLLER | AUDIT #13::R2-G06 | R2-G06 | provider success without reconciliation cannot PASS | R2 repair controller | #07/#16 + DT-10 children | SUBSTANTIVE_BODY | REPAIR_CLOSED_IN_R2_DESIGN | NONE | Appendix E deterministic checker |
| AUDIT_CONTROLLER | AUDIT #13::R2-G07 | R2-G07 | A1 machine enum preserved | R2 repair controller | #12 + catalog | SUBSTANTIVE_BODY | REPAIR_CLOSED_IN_R2_DESIGN | NONE | Appendix E deterministic checker |
| AUDIT_CONTROLLER | AUDIT #13::R2-G08 | R2-G08 | CAND/NOBJ/ECP+ADD/MSC/TQ source IDs crosswalked | R2 repair controller | Appendix F | SUBSTANTIVE_BODY | REPAIR_CLOSED_IN_R2_DESIGN | NONE | Appendix E deterministic checker |
| AUDIT_CONTROLLER | AUDIT #13::R2-G09 | R2-G09 | 8/8 workflow IDs preserved; SELF_ITERATION_LOOP materialized | R2 repair controller | #28 + Appendix F | SUBSTANTIVE_BODY | REPAIR_CLOSED_IN_R2_DESIGN | NONE | Appendix E deterministic checker |
| AUDIT_CONTROLLER | AUDIT #13::R2-G10 | R2-G10 | every BUILD_MINIMAL has no-fit proof + gap set; R2 reclassifies internal validator to SELECTED_REUSE | R2 repair controller | #25 | SUBSTANTIVE_BODY | REPAIR_CLOSED_IN_R2_DESIGN | NONE | Appendix E deterministic checker |
| AUDIT_CONTROLLER | AUDIT #13::R2-G11 | R2-G11 | no stale dated currentness row; Trivy corrected | R2 repair controller | #14 | SUBSTANTIVE_BODY | REPAIR_CLOSED_IN_R2_DESIGN | NONE | Appendix E deterministic checker |
| AUDIT_CONTROLLER | AUDIT #13::R2-G12 | R2-G12 | SYSTEM/SKILL_PLUGIN/AGENT_HARNESS full PI/PD denominators tested | R2 repair controller | #19/#20/#21 | SUBSTANTIVE_BODY | REPAIR_CLOSED_IN_R2_DESIGN | NONE | Appendix E deterministic checker |
| AUDIT_CONTROLLER | AUDIT #13::R2-G13 | R2-G13 | no generic Oracle for gate-critical selected/eval technology | R2 repair controller | #25 | SUBSTANTIVE_BODY | REPAIR_CLOSED_IN_R2_DESIGN | NONE | Appendix E deterministic checker |
| AUDIT_CONTROLLER | AUDIT #13::R2-G14 | R2-G14 | extractable conformance catalog instance validates | R2 repair controller | Appendix G | SUBSTANTIVE_BODY | REPAIR_CLOSED_IN_R2_DESIGN | NONE | Appendix E deterministic checker |
| AUDIT_CONTROLLER | AUDIT #13::R2-G15 | R2-G15 | cross_agent_semantic_agreement materialized | R2 repair controller | #28 | SUBSTANTIVE_BODY | REPAIR_CLOSED_IN_R2_DESIGN | NONE | Appendix E deterministic checker |
| AUDIT_CONTROLLER | AUDIT #13::R2-G16 | R2-G16 | exact command/output/digest + seeded regression failures | R2 repair controller | Appendix E | SUBSTANTIVE_BODY | REPAIR_CLOSED_IN_R2_DESIGN | NONE | Appendix E deterministic checker |
| AUDIT_CONTROLLER | AUDIT #13::R2-G17 | R2-G17 | no Independent/Human/Runtime/Release/Production inflation | R2 repair controller | #00/#32 | SUBSTANTIVE_BODY | REPAIR_CLOSED_IN_R2_DESIGN | NONE | Appendix E deterministic checker |
# Appendix E｜Author-Side Reproducible Self-Audit Receipt

This receipt closes `R2-G16` at the **author-side deterministic self-audit** level only. It is not Independent PASS, Human Ratification, runtime qualification, release evidence, or production evidence. The checked payload is every byte of this artifact before this Appendix E heading; Appendix E is deliberately excluded from its own payload digest to avoid self-referential hashing. The final whole-file SHA-256 is reported externally at delivery.

## E.1 Checker identity / reproducibility contract

```yaml
checker_id: PIPD-DOC07-R2-SELF-CHECKER-1
checker_sha256: fe91b4e4c4d574c25c7f2f970e27699faecd466e8b15d629eea891bf5bf9b926
checker_scope: all artifact bytes before Appendix E
expected_python: 3.13.x
expected_dependency: jsonschema>=4.26.0 compatible with Draft202012Validator
exit_0: all base checks and seeded destructive checks PASS
exit_3: at least one invariant is not proven
claim_ceiling: AUTHOR_SIDE_REPRODUCIBLE_SELF_AUDIT_PASS_R2
```

## E.2 Exact command and checker body

The following command is the command executed for this receipt. It is intentionally self-contained except for the documented Python `jsonschema` dependency.

```bash
DOC=/mnt/data/PIPD_LS_DOC-07_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY.md
python - "$DOC" <<'PY'
from pathlib import Path
import sys, re, json, hashlib
from importlib.metadata import version as pkg_version
import jsonschema

PATH = Path(sys.argv[1])
TEXT = PATH.read_text(encoding="utf-8")
PAYLOAD = TEXT.split("# Appendix E｜", 1)[0].rstrip() + "\n"

EXPECTED_TUPLE_HASH = "585555096fa8c20f2912d438f09fa911e6f92a5c7d40dae6daabdd9a7d41e8bc"
WORKFLOWS = {
    "MISSION_TO_EXECUTION","PHASES_RB00_RB15","WORKORDER_ADMISSION","CROSS_SESSION_PIPELINE",
    "PROVIDER_ADMISSION","LONG_RUNNING_CONTROL","SELF_ITERATION_LOOP","RELEASE_RECOVERY"
}
ATOMIC_REQUIRED = {
    "DT-02-C01","DT-02-C02","DT-02-C03","DT-02-C04","DT-02-C05","DT-02-C06",
    "DT-04-C01","DT-04-C02","DT-04-C03","DT-04-C04",
    "DT-05-C01","DT-05-C02",
    "DT-06-C01","DT-06-C02","DT-06-C03","DT-06-C04",
    "DT-08-C01","DT-08-C02","DT-08-C03",
    "DT-09-C01","DT-09-C02","DT-09-C03","DT-09-C04",
    "DT-10-C01","DT-10-C02",
    "FX-HPI-001-C01","FX-HPI-001-C02",
    "FX-APPR-001-C01","FX-APPR-001-C02","FX-APPR-001-C03","FX-APPR-001-C04",
    "FX-FPASS-001-C01","FX-FPASS-001-C02","FX-FPASS-001-C03","FX-FPASS-001-C04",
    "FX-DRIFT-001-C01","FX-DRIFT-001-C02","FX-DRIFT-001-C03","FX-DRIFT-001-C04","FX-DRIFT-001-C05"
}

def section(text, start, end):
    return text.split(start,1)[1].split(end,1)[0]

def parse_a(text):
    a = section(text, "# Appendix A｜", "# Appendix B｜")
    rows=[]
    pat=re.compile(r'^\|\s*(STD-REQ-[A-F0-9]{8})\s*\|\s*(.*?)\|\s*(TEST-[A-F0-9]{8})\s*\|\s*(OR-[A-F0-9]{8})\s*\|\s*(ALL|APPLICABLE_PROFILE)\s*\|')
    for line in a.splitlines():
        m=pat.match(line)
        if m:
            rows.append((m.group(1),m.group(3),m.group(4),m.group(5)))
    return rows

def tuple_hash(rows):
    data="".join(f"{a}\t{b}\t{c}\t{d}\n" for a,b,c,d in rows)
    return hashlib.sha256(data.encode()).hexdigest()

def donor_counts(text):
    f=section(text,"# Appendix F｜","# Appendix G｜")
    return {
        "CAND":len(set(re.findall(r'\bCAND-\d{2}\b',f))),
        "NOBJ":len(set(re.findall(r'\bNOBJ-\d{3}\b',f))),
        "ECP":len(set(re.findall(r'\bECP-\d{2}\b',f))),
        "ADD":len(set(re.findall(r'\bADD-\d{2}\b',f))),
        "MSC":len(set(re.findall(r'\bMSC-TECH-\d{3}\b',f))),
        "TQ":len(set(re.findall(r'\bTQ-TECH-\d{3}\b',f))),
    }

def profile_counts(text):
    return {
        "SYS_PI":len(set(re.findall(r'\bSYS-PI-\d{2}\b',text))),
        "SYS_PD":len(set(re.findall(r'\bSYS-PD-\d{2}\b',text))),
        "SK_PI":len(set(re.findall(r'\bSK-PI-\d{2}\b',text))),
        "SK_PD":len(set(re.findall(r'\bSK-PD-\d{2}\b',text))),
        "AH_PI":len(set(re.findall(r'\bAH-PI-\d{2}\b',text))),
        "AH_PD":len(set(re.findall(r'\bAH-PD-\d{2}\b',text))),
    }

def effect_guard(x):
    if not x.get("observation_refs"):
        return 3,"EFFECT_RECONCILIATION_OBSERVATION_MISSING"
    if not x.get("readback_refs"):
        return 3,"EFFECT_RECONCILIATION_READBACK_MISSING"
    if not x.get("oracle"):
        return 3,"EFFECT_RECONCILIATION_ORACLE_MISSING"
    if not x.get("checker"):
        return 3,"EFFECT_RECONCILIATION_CHECKER_MISSING"
    state=x.get("state"); next_action=x.get("next_action")
    if state=="CONFIRMED_EFFECT" and next_action!="PROMOTE_EVIDENCE":
        return 3,"EFFECT_RECONCILIATION_CONFIRMED_WITHOUT_PROMOTION"
    if state!="CONFIRMED_EFFECT" and next_action=="PROMOTE_EVIDENCE":
        return 3,"EFFECT_RECONCILIATION_FALSE_PROMOTION"
    return 0,None

def extract_json(text, start, end):
    s=section(text,start,end)
    m=re.search(r'```json\n(.*?)\n```',s,re.S)
    if not m:
        raise AssertionError(f"missing JSON block {start}")
    return json.loads(m.group(1))

def base_checks(text):
    out={}
    rows=parse_a(text)
    out["R2-G01_86_rows"]=(len(rows)==86 and len({r[0] for r in rows})==86 and tuple_hash(rows)==EXPECTED_TUPLE_HASH)
    out["R2-G01_0CB9_tuple"]=(("STD-REQ-0CB9A2A0","TEST-0CB9A2A0","OR-0CB9A2A0","APPLICABLE_PROFILE") in rows)

    atomics=set(re.findall(r'\b(?:DT-\d{2}-C\d{2}|FX-(?:HPI|APPR|FPASS|DRIFT)-001-C\d{2})\b',text))
    out["R2-G02_atomicity"]=ATOMIC_REQUIRED <= atomics

    cov=section(text,"# Appendix I｜","# Appendix E｜") if "# Appendix E｜" in text else text.split("# Appendix I｜",1)[1]
    cov_rows=[ln for ln in cov.splitlines() if re.match(r'^\|\s*(A1_BLUEPRINT|A3_SKELETON|PRODUCTION_INSTRUCTION|AUDIT_CONTROLLER)\s*\|',ln)]
    out["R2-G03_coverage_219"]=(len(cov_rows)==219)

    out["R2-G04_A1_operative_ABI"]=("A1 the executable integration truth" in text and "pipd_tree_validate.py validate-tree" in text)
    out["R2-G05_profile_wrapper"]=("resolve_profile_or_fail" in text and "--profile <LITE|STANDARD|ASSURED>" in text)

    code_noop = bool(re.search(r'["\']effect["\']\s*:\s*lambda\s+x\s*:\s*None', text))
    code_guard = "def semantic_effect_guard(x):" in text
    seeded_effect = effect_guard({"provider_response":{"status":200}})
    out["R2-G06_effect"]=code_guard and not code_noop and seeded_effect[0] != 0 and seeded_effect[1].startswith("EFFECT_RECONCILIATION_")

    out["R2-G07_applicability"]=("applicability: APPLICABLE | NOT_APPLICABLE" in text and "requirement-conformance.json" in text)

    dc=donor_counts(text)
    out["R2-G08_donor_144"]=(dc=={"CAND":22,"NOBJ":24,"ECP":48,"ADD":4,"MSC":15,"TQ":31})

    f=section(text,"# Appendix F｜","# Appendix G｜")
    wf={w for w in WORKFLOWS if re.search(rf'\|\s*{re.escape(w)}\s*\|',f)}
    out["R2-G09_workflows_8"]=wf==WORKFLOWS and "SELF_ITERATION_LOOP" in section(text,"# 28｜","# 29｜")

    out["R2-G10_no_BUILD_MINIMAL_local"]=(not re.search(r'^terminal_design_disposition:\s*BUILD_MINIMAL\s*$',text,re.M)
        and 'terminal_design_disposition: SELECTED_REUSE' in text
        and 'r1_disposition_repaired_from: "BUILD_MINIMAL"' in text)

    trivy=section(text,"## 25.5 `TECH-TRIVY`","## 25.6 ")
    out["R2-G11_currentness_Trivy"]=('observed_latest: "0.75.0 released 2026-10-01"' in trivy and 'selected_version: "0.75.0"' in trivy)

    pc=profile_counts(text)
    out["R2-G12_profiles"]=(pc=={"SYS_PI":10,"SYS_PD":13,"SK_PI":18,"SK_PD":12,"AH_PI":15,"AH_PD":13})

    sec25=section(text,"# 25｜","# 26｜")
    blocks=re.findall(r'```yaml\n(technology_id: .*?)\n```',sec25,re.S)
    specific=True
    for b in blocks:
        if not re.search(r'^exact_test_refs:\s*\[[^\]]+\]$',b,re.M): specific=False
        if not re.search(r'^exact_oracle_refs:\s*\[[^\]]+\]$',b,re.M): specific=False
        if "canonical DOC-07 oracle mapped from applicable" in b: specific=False
    out["R2-G13_specific_landing"]=(len(blocks)==12 and specific)

    schema=extract_json(text,"## 03.1 R2 machine-readable conformance-catalog schema","# 04｜")
    inst=extract_json(text,"# Appendix G｜","# Appendix H｜")
    try:
        jsonschema.Draft202012Validator.check_schema(schema)
        errs=list(jsonschema.Draft202012Validator(schema).iter_errors(inst))
        catalog_ok=(not errs and len(inst["tests"])==187 and len(inst["oracles"])==187 and len(inst["fixtures"])==226 and len(inst["requirement_bindings"])==86)
    except Exception:
        catalog_ok=False
    out["R2-G14_machine_catalog"]=catalog_ok

    m=section(text,"## 28.2 DOC-07-owned lifecycle quality metric","# 29｜")
    out["R2-G15_metric"]=("cross_agent_semantic_agreement" in m and "numerator / denominator" in m and "gate_non_substitution: true" in m)

    out["R2-G17_claim"]=(all(x in text for x in ["NOT_RUNTIME_VERIFIED","NOT_INDEPENDENT_PASS","NOT_HUMAN_RATIFIED","NOT_RELEASED","NOT_PRODUCTION_PASS"]))

    out["structure_fences_even"]=(len(re.findall(r'^```',text,re.M))%2==0)
    out["structure_h1_00_32"]=all(re.search(rf'^# {i:02d}｜',text,re.M) for i in range(33))
    out["aliases_37"]=(len(set(re.findall(r'\bT-PIPD-\d{3}\b',text)))==37)
    placeholder_pattern = r"\b(?:TO" + "DO|TB" + "D|FIX" + "ME)\b"
    out["no_author_placeholders"]=(not re.search(placeholder_pattern,text,re.I))
    return out

BASE=base_checks(PAYLOAD)
BASE["R2-G16_self_audit_receipt"] = ("# Appendix E｜Author-Side Reproducible Self-Audit Receipt" in TEXT and "PIPD-DOC07-R2-SELF-CHECKER-1" in TEXT)

# Seeded destructive tests prove the checker catches known regression classes.
seed={}
m1=PAYLOAD.replace("OR-0CB9A2A0","OR-DEADBEEF")
seed["seed_test_oracle_remap_detected"]=not base_checks(m1)["R2-G01_86_rows"]

m2=PAYLOAD.replace("TEST-0CB9A2A0","TEST-0CB9|A2A0")
seed["seed_markdown_pipe_corruption_detected"]=not base_checks(m2)["R2-G01_86_rows"]

m3=PAYLOAD.replace('observed_latest: "0.75.0 released 2026-10-01"','observed_latest: "0.74.0"')
seed["seed_stale_tool_version_detected"]=not base_checks(m3)["R2-G11_currentness_Trivy"]

m4=PAYLOAD.replace("DT-06-C04","DT-06-REMOVED")
seed["seed_missing_atomic_child_detected"]=not base_checks(m4)["R2-G02_atomicity"]

m5=PAYLOAD.replace("CAND-22","CAND-REMOVED")
seed["seed_genericized_or_missing_donor_detected"]=not base_checks(m5)["R2-G08_donor_144"]

seeded_code,seeded_ffi=effect_guard({"provider_response":{"status":200},"state":"CONFIRMED_EFFECT","next_action":"PROMOTE_EVIDENCE"})
seed["seed_effect_false_pass_detected"]=(seeded_code!=0 and seeded_ffi.startswith("EFFECT_RECONCILIATION_"))

overall=all(BASE.values()) and all(seed.values())
result={
    "checker_id":"PIPD-DOC07-R2-SELF-CHECKER-1",
    "python":sys.version.split()[0],
    "jsonschema":pkg_version("jsonschema"),
    "checked_payload_sha256":hashlib.sha256(PAYLOAD.encode()).hexdigest(),
    "base_checks":BASE,
    "seeded_destructive_checks":seed,
    "overall":"PASS" if overall else "FAIL",
    "first_failing_invariant":None if overall else next((k for k,v in {**BASE,**seed}.items() if not v),"UNKNOWN")
}
print(json.dumps(result,ensure_ascii=False,sort_keys=True,indent=2))
raise SystemExit(0 if overall else 3)
PY
```

## E.3 Exact checker stdout

```json
{
  "base_checks": {
    "R2-G01_0CB9_tuple": true,
    "R2-G01_86_rows": true,
    "R2-G02_atomicity": true,
    "R2-G03_coverage_219": true,
    "R2-G04_A1_operative_ABI": true,
    "R2-G05_profile_wrapper": true,
    "R2-G06_effect": true,
    "R2-G07_applicability": true,
    "R2-G08_donor_144": true,
    "R2-G09_workflows_8": true,
    "R2-G10_no_BUILD_MINIMAL_local": true,
    "R2-G11_currentness_Trivy": true,
    "R2-G12_profiles": true,
    "R2-G13_specific_landing": true,
    "R2-G14_machine_catalog": true,
    "R2-G15_metric": true,
    "R2-G16_self_audit_receipt": true,
    "R2-G17_claim": true,
    "aliases_37": true,
    "no_author_placeholders": true,
    "structure_fences_even": true,
    "structure_h1_00_32": true
  },
  "checked_payload_sha256": "e6cd3477986f7e58fb27de0cf836d8901b398606ffabc4724dc76253d49afa66",
  "checker_id": "PIPD-DOC07-R2-SELF-CHECKER-1",
  "first_failing_invariant": null,
  "jsonschema": "4.26.0",
  "overall": "PASS",
  "python": "3.13.5",
  "seeded_destructive_checks": {
    "seed_effect_false_pass_detected": true,
    "seed_genericized_or_missing_donor_detected": true,
    "seed_markdown_pipe_corruption_detected": true,
    "seed_missing_atomic_child_detected": true,
    "seed_stale_tool_version_detected": true,
    "seed_test_oracle_remap_detected": true
  }
}
```

## E.4 Seeded destructive regression intent

The checker does not merely assert that the clean artifact passes. It mutates the clean payload in memory and requires detection of all six audit-critical regression classes: TEST/ORACLE remap, Markdown-pipe tuple corruption, stale Trivy currentness, missing atomic child fixture, missing/genericized donor identity, and provider-success/effect false promotion. A clean-run PASS is valid only when every seeded destructive case is itself detected.

## E.5 Receipt interpretation

`overall=PASS` closes the AUDIT repair gate only at author-side document/conformance-contract level. It does not establish target-repository execution, installed/bound tooling, independent checker separation, human approval, release candidate status, deployment, or production verification.
