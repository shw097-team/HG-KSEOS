---
artifact_id: "PIPD_LS_DOC-01"
external_formal_name: "Pre-Implementation & Pre-Dev Lifecycle Specification — DOC-01 Normative Constitution / State & Authority"
internal_short_name: "PIPD_LS_DOC-01"
artifact_type: "NORMATIVE_CONSTITUTION_STATE_AUTHORITY_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY"
version: "2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY"
subject_id: "PIPD-LIFECYCLE-SPEC"
subject_version: "1.1.0"
status: "DOC01_R2_HIGH_RETENTION_FULL_REPAIR_MATERIALIZED"
lifecycle_state: null
owner: "DOC-01"
canonical_owner: "DOC-01"
source_refs:
  - "A0:PIPD_LS_DOC-01 production instruction"
  - "A1:PIPD-LIFECYCLE-BLUEPRINT@1.1.0-r2_FULL_REPAIR"
  - "A2:PIPD-LIFECYCLE-SPEC@1.1.0"
  - "A3:PIPD_LS_skeleton@1.1.0-SKELETON-r2_FULL_REPAIR"
  - "A4:PIPD_LS_DOC-00@2026-10-07_r2"
  - "A5:Pre-Implementation/Pre-Dev lifecycle discussion"
  - "A5b:PIPD canonical authority/lifecycle engineering adjudication"
  - "AUDIT:AUDIT_PIPD_LS_DOC-01_2026-10-07_R1_FULL_AUDIT"
authority_refs:
  - "A0 > A1 > A2 > A3 > A4 > A5 > A5b > external-support"
dependencies:
  - "PIPD-LIFECYCLE-SPEC@1.1.0"
  - "PIPD-LIFECYCLE-BLUEPRINT@1.1.0-r2_FULL_REPAIR"
consumers: ["DOC-00","DOC-02","DOC-03","DOC-04","DOC-05","DOC-06","DOC-07","DOC-08","DOC-09","project adapters"]
supersedes:
  - artifact: "PIPD_LS_DOC-01_2026-10-07_r1_FULL_SUBSTANTIVE_BODY"
    sha256: "989211f533d31ca595f935d0979f4aec99a609b4f263b55fa6f9bf0098aa7344"
created_at: "2026-10-07T13:36:00+08:00"
observed_at: "2026-10-07T13:36:00+08:00"
content_hash: null
detached_content_hash_ref: "FINAL_READBACK_RECEIPT.sha256"
weight_profile: "STANDARD"
target_profile: "SYSTEM"
profile_version: "1.1.0"
extensions: []
maker: "GPT-5.6 Sol / author-side materializer"
checker: null
checker_kind: "AUTHOR_SELF_REVIEW_ONLY"
checker_independent: false
acceptor: null
release_authority: null
human_approver: null
artifact_materialization_claim: "DOC01_R2_FULL_SUBSTANTIVE_BODY_MATERIALIZED"
governed_subject_claim_ceiling: null
claim_ceiling: null
target_repo_bound: false
runtime_execution: false
independent_pass: false
human_ratification: false
release: false
production_pass: false
open_tt: []
open_cr: []
repair_basis: "AUDIT FAIL_REPAIR_REQUIRED; HIGH_RETENTION_PATCH_NO_ARCHITECTURE_RESET"
authoring_mode: "FULL_SCAN_NO_SAMPLING_SOURCE_BOUND_HIGH_RETENTION_FAIL_CLOSED_CLAIM_HONEST_SINGLE_MD"
---

# PIPD_LS_DOC-01 — Normative Constitution / State & Authority — r2 High-Retention Full Repair

> **Normative role.** 本文件是 `PIPD-LIFECYCLE-SPEC@1.1.0` 的 DOC-01 standalone substantive body。它以 r1 成立的 constitution spine 為 retained baseline，工程性整合、覆蓋並取代 r1 中被 AUDIT 判定為 false closure、metadata drift、machine-enforcement downgrade、C-family compression、event/threat/package/fixture/TLC field loss 的部分。
>
> **Claim boundary.** `artifact_materialization_claim` 只描述本文件已物化；`governed_subject_lifecycle_state` 與 `governed_subject_claim_ceiling` 仍為 `null`。因此本文件 **不得** 被解讀為任何專案已 `PI_READY`、`PREDEV_READY`、`EXECUTION_ADMITTED`、implemented、verified、qualified、released 或 production-verified。
>
> **Repair invariant.** r2 禁止 architecture reset：14-state lifecycle、claim separation、permission classes、affected-only invalidation、split/merge semantic predicates、vertical-slice governance與 cross-DOC ownership全部保留；修補只對 AUDIT 指認的 missing/partial/downgraded surfaces 做 canonical recosure。

本文件中的 **MUST / MUST NOT / SHALL / SHALL NOT / SHOULD / SHOULD NOT / MAY** 依 BCP 14（RFC 2119 + RFC 8174）的規範語意使用；只有大寫關鍵字具有 BCP 14 特殊規範意義。外部網站、repo、tool/model output一律先視為 DATA/SUPPORT，不能自行取得 PIPD authority。

# 1｜Authority、來源、FULL-SCAN Receipt 與 Repair Adjudication
## 1.1 Authority Stack
本次 PATCH 的唯一裁決順位固定為：`A0 目前 PATCH + 原產出指令 → A1 總藍圖 → A2 canonical standard → A3 skeleton/atomic registry → A4 DOC-00 navigation → A5 總討論 → A5b 工程裁決 → external current official evidence (SUPPORT only)`。同 rank 衝突 MUST `TEMP_CLOSED`，不得 silent merge。A4 不能反向修改 A1/A2/A3 canonical truth。
## 1.2 Physical Full-Scan Receipt
|ID|File|Bytes|Split lines|SHA-256|Scan|
|---|---|---:|---:|---|---|
|A0|`貼上的文字 (1)(3).txt`|43131|1903|`5fcbe5d464f88fd9ebed330c2f287567f4994db2a3302d389b54747a0b2dac39`|FULL UTF-8 / NO SAMPLING|
|A1|`Pre-Implementation_and_Pre-Dev_Lifecycle_Specification_總藍圖.md`|149077|2996|`9a8323e5237c1555a76d9a75f706e3552d79c192915cc782b76b211c7f27d527`|FULL UTF-8 / NO SAMPLING|
|A2|`Pre-Implementation_and_Pre-Dev_Lifecycle_Specification_canonical_standard.md`|209157|7176|`6f6aafece90b34e33786647e14fee840f5424893995b3164cbb52953a5c4f14a`|FULL UTF-8 / NO SAMPLING|
|A3|`PIPD_LS_skeleton_2026-10-06_r2_FULL_REPAIR(1).md`|376599|2668|`03bb3609dc67f85fa4b683a93736cf162e9047b6b253182aa3fdba11ba40cb28`|FULL UTF-8 / NO SAMPLING|
|A4|`PIPD_LS_DOC-00_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY(1).md`|251982|2292|`be3a672ec20aa0e6b5e0e35097fc08de749bfe7f59f827d18e38aef67dd68ea4`|FULL UTF-8 / NO SAMPLING|
|A5|`Pre-Implementation-PKG  Pre-Dev-PKG 生命週期規格_總討論(1).md`|77326|2559|`be1858e860092fb1751bf0524cd22b6939138b6835ce8f452bfc30894f945a95`|FULL UTF-8 / NO SAMPLING|
|A5b|`PIPD 「canonical authority／生命週期」工程裁決.md`|17766|611|`4ae876f856850e4f657cfb1df9cb926b08bdc353af040c3ecdd92faa651a7dc8`|FULL UTF-8 / NO SAMPLING|
|R1|`PIPD_LS_DOC-01_2026-10-07_r1_FULL_SUBSTANTIVE_BODY.md`|125431|1667|`989211f533d31ca595f935d0979f4aec99a609b4f263b55fa6f9bf0098aa7344`|FULL UTF-8 / NO SAMPLING|
|AUDIT|`AUDIT_PIPD_LS_DOC-01_2026-10-07_r1_FULL_SUBSTANTIVE_BODY_FULL_AUDIT_2026-10-07_r1(2).md`|41759|1202|`6de5ab51d2fc5e7a3d232193ad9ed2dc99a8e0e5365294dd69fe3ccaecfc2f38`|FULL UTF-8 / NO SAMPLING|

所有來源均 strict UTF-8 讀取；`U+FFFD=0`。r1 hash 與 AUDIT target hash 一致，line-count 差異若出現只接受 `splitlines()` vs `newline_count+1` 的計數法差異。
## 1.3 Audit Repair Contract
AUDIT verdict=`FAIL_REPAIR_REQUIRED`。r2 必須關閉 4 BLOCKER、11 MAJOR、4 MODERATE，且不得以「標題存在」「JSON 可 parse」「本地自創 ID 數量較多」替代 canonical closure。A3 `Primary Owner = DOC-01` 的 **140 stable atomics** 是本版 coverage denominator；本地 alias 僅可作 secondary authoring convenience。
## 1.4 External Currentness Boundary
2026-10-07 current official evidence只允許更新外部格式／安全／currentness facts，不得改 lifecycle semantics、owner、claim ceiling、gate 或 authority。每個 currentness record MUST 記 `observed_at`、source、status、trigger。

# 2｜Mission、Position、Non-Goals 與 Cross-DOC Boundary

## 2.1 Why a Constitution Exists

PIPD 的核心風險不是「文件不夠多」，而是 **semantic drift、authority ambiguity、claim inflation、premature execution、stale evidence reuse、adapter/provider authority inversion**。DOC-01 因此存在，用來把「什麼是真的、誰能寫、何時能升狀態、現在最多能宣稱什麼、變更後哪些東西失效」固定成可機器驗證的 constitution。

DOC-01 **SHALL** 成為 project/organization Constitution instance 的 semantic anchor；但它不是 runtime orchestrator，也不是 execution admission service。它解決的是「合法狀態與合法宣稱」而不是「替執行者做實作」。

## 2.2 Canonical Responsibility

DOC-01 owns:

- authority and conflict resolution;
- artifact / subject identity invariants;
- canonical lifecycle states and transition legality;
- projection/substate separation;
- base PromotionPredicate;
- claim / claim ceiling;
- canonical ownership and SoD;
- Constitution/profile binding;
- constitutional permission/side-effect categories;
- change, supersession and affected-only invalidation;
- package derivation, split/merge and vertical-slice rules;
- the machine-readable state/authority/change records that express those semantics.

## 2.3 Non-Goals

DOC-01 **MUST NOT**:

- encode target-repository implementation details;
- create a second `TechnologyAdmission` SSOT;
- issue `ExecutionAdmission`;
- self-approve evidence or qualification;
- turn ECP/TQAEP into permission or PASS;
- create a second CI/release authority;
- claim tool/provider/API success is world-effect truth;
- silently fall back to superseded sources;
- require all unrelated packages to complete before an independently eligible vertical slice can execute.

## 2.4 Cross-Document Responsibility Matrix

|DOC|Canonical owner of|DOC-01 reads / writes|DOC-01 may reference|DOC-01 may not duplicate|Invalidation trigger|
|---|---|---|---|---|---|
|DOC-00|Navigation / router / package index / operator readback|Reads DOC-01 state/claim/authority truth; DOC-01 may reference routing vocabulary. Document Responsibility Matrix and front-door navigation.|State projection only.|DOC-01 MUST NOT rewrite DOC-00 routing/index ownership.|DOC-00 readback token or routing version changes.|
|DOC-01|Authority / lifecycle / claim / SoD / constitution / change / package derivation|Owns this document's normative semantics. This document.|Canonical state/authority/change records.|N/A|Any canonical Constitution change or supersession.|
|DOC-02|PI contract areas / atomic requirements / TechnologyAdmission / PI_READY compilation|DOC-01 reads PI_READY facts and technology admission pointers. PI requirement/admission records.|Constitution predicates and lifecycle transition contract.|DOC-01 MUST NOT create a second TechnologyAdmission SSOT.|PI requirement/TechnologyAdmission meaning change.|
|DOC-03|RepoContext / currentness / late binding / S2E / TaskSpecSeed / WorkOrder / ECP / TQAEP / PREDEV_READY|DOC-01 reads PREDEV_READY and binding facts. PD binding/currentness/execution-prep records.|Lifecycle/profile/permission category invariants.|DOC-01 MUST NOT own repo details or ECP/TQAEP content.|PD binding/currentness contract change.|
|DOC-04|Trace / evidence identity / freshness / evidence contract|DOC-01 reads subject-bound evidence sufficiency. Evidence envelope, trace, freshness.|State/claim evidence requirement semantics.|DOC-01 MUST NOT self-qualify evidence.|Evidence identity/freshness schema change.|
|DOC-05|Rejectable handoff / permission decision / effect boundary / ExecutionAdmission|DOC-01 reads admission decision and defines only constitutional categories. ExecutionAdmission and effect/permission decision records.|Permission class taxonomy and lifecycle admission boundary.|DOC-01 MUST NOT issue ADMIT.|Admission schema or authority change.|
|DOC-06|Tailoring / target-profile detailed contracts|DOC-01 reads selected profile/version/extensions. Detailed LITE/STANDARD/ASSURED and target-profile contracts.|Core profile-binding invariants.|DOC-01 MUST NOT duplicate profile detail.|Profile semantics/version change.|
|DOC-07|Conformance fixtures / tests / oracles|DOC-01 defines what must be testable; reads conformance results. Stable test/oracle fixtures and reports.|Normative invariants and first-failing-invariant requirements.|DOC-01 MUST NOT self-approve conformance.|Oracle semantics/test registry change.|
|DOC-08|AI consumption / nearest-scope read order / adapter maturity|DOC-01 defines adapter non-override; reads adapter maturity where needed. AI read-order/projection contracts.|Authority/SSOT protection invariants.|DOC-01 MUST NOT own host adapter implementation.|Adapter maturity/read-order change.|
|DOC-09|CI / release / supply-chain / runbook / tooling projections|DOC-01 reads release authority/result and CI/release refs. CI/release/runbook/tooling contracts.|State/claim/release authority invariants.|DOC-01 MUST NOT create second release authority.|Release/supply-chain contract change.|

## 2.5 Project Non-Goals Atomic Closure
DOC-01 MUST NOT 成為 TechnologyAdmission、RepoContext、ExecutionAdmission、TQAEP execution、CI/release、runtime provider pin 的第二 SSOT；但 Constitution 必須具名 required interface、owner 與 route-out，避免「ownership 正確但 integration 消失」。任何 project-specific runtime fact 都 MUST late-bind 到其 canonical sibling owner。

# 3｜CommonArtifactMetadata Compatibility Superset / Identity & SoD Narrow Waist

## 3.1 Purpose and Design Intent
本節修補 r1 將 A2/A3 metadata 縮窄的 authority drift。所有 canonical/project artifacts MUST 使用 **compatibility superset**：不得在 `owner` 與 `canonical_owner`、`version` 與 `subject_version` 之間二選一丟欄；不得讓 `checker` presence 自動等同 Independent PASS。

## 3.2 Required Fields and Normalization
|Field|Semantics / invariant|
|---|---|
|`artifact_id`|stable artifact identity；filename不得作唯一 identity|
|`artifact_type`|machine-readable typed enum/profile|
|`subject_id`|governed subject identity|
|`version`|artifact revision/version|
|`subject_version`|subject version；若與 artifact version相同 MAY mirror，否則 MUST 明確區分|
|`status`|artifact-local materialization/status，不得偷渡 lifecycle claim|
|`lifecycle_state`|canonical subject state or `null`；不得填 operational/degrade label|
|`owner`|artifact operational owner；MUST normalize to canonical owner relationship|
|`canonical_owner`|single canonical writer/semantic owner|
|`source_refs` / `authority_refs`|source provenance 與 authority lineage 分離|
|`dependencies` / `consumers`|affected-only invalidation graph edges|
|`content_hash`|materialized bytes hash；self-contained file若採 detached hash MUST用 `detached_content_hash_ref`|
|`maker/checker/acceptor`|distinct SoD slots；`checker=null` 不代表失敗，代表未有 canonical checker claim|
|`release_authority`|release decision slot；不可由 acceptor隱含|
|`human_approver`|high-risk permission slot；不可由 release authority隱含|
|`weight_profile`|`LITE / STANDARD / ASSURED`（Markdown 中不用 raw pipe 作 cell separator）|
|`target_profile`|`SYSTEM / SKILL_PLUGIN / AGENT_HARNESS / CUSTOM`|
|`profile_version` / `extensions`|profile binding + typed extensions|
|`claim_ceiling`|governed subject claim only；artifact materialization claim MUST separate|
|`supersedes`|revision lineage；superseded bytes可保留 provenance 但不可 silent-current|
|`created_at` / `observed_at`|artifact creation vs observation/currentness timestamp|

## 3.3 Alias / Conflict Rules
1. `owner != canonical_owner` 時 MUST 有 delegation/operation rationale；不得讓 delegate取得 semantic overwrite authority。  
2. `version != subject_version` 時 MUST 記兩者各自作用域。  
3. self-file `content_hash` 不能遞迴自嵌；本版使用 `detached_content_hash_ref`，最終 readback receipt 才給實際 SHA-256。  
4. same-model self-review MUST 寫入 `checker_kind=AUTHOR_SELF_REVIEW_ONLY`, `checker_independent=false`，且 canonical `checker` slot保持 `null`，除非真的有獨立 checker。  
5. `release_authority` 與 `human_approver` 為獨立 slots；ASSURED/high-risk 不得以 Maker/Checker/Acceptor 任一欄隱含替代。

## 3.4 Machine Representation
```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "urn:pipd:doc01:1.1:schema:common-artifact-metadata-superset",
  "title": "CommonArtifactMetadataSuperset",
  "type": "object",
  "additionalProperties": true,
  "required": [
    "artifact_id",
    "artifact_type",
    "subject_id",
    "version",
    "status",
    "owner",
    "canonical_owner",
    "source_refs",
    "authority_refs",
    "dependencies",
    "consumers",
    "maker",
    "checker",
    "acceptor",
    "release_authority",
    "human_approver",
    "weight_profile",
    "target_profile",
    "profile_version",
    "extensions",
    "claim_ceiling",
    "supersedes",
    "created_at"
  ],
  "properties": {
    "artifact_id": {
      "type": "string",
      "minLength": 1
    },
    "artifact_type": {
      "type": "string",
      "minLength": 1
    },
    "subject_id": {
      "type": "string",
      "minLength": 1
    },
    "version": {
      "type": "string",
      "minLength": 1
    },
    "subject_version": {
      "type": [
        "string",
        "null"
      ]
    },
    "status": {
      "type": "string",
      "minLength": 1
    },
    "lifecycle_state": {
      "type": [
        "string",
        "null"
      ]
    },
    "owner": {
      "type": "string",
      "minLength": 1
    },
    "canonical_owner": {
      "type": "string",
      "minLength": 1
    },
    "source_refs": {
      "type": "array"
    },
    "authority_refs": {
      "type": "array"
    },
    "dependencies": {
      "type": "array"
    },
    "consumers": {
      "type": "array"
    },
    "content_hash": {
      "type": [
        "string",
        "null"
      ],
      "pattern": "^[A-Fa-f0-9]{64}$"
    },
    "detached_content_hash_ref": {
      "type": [
        "string",
        "null"
      ]
    },
    "maker": {
      "type": [
        "string",
        "null"
      ]
    },
    "checker": {
      "type": [
        "string",
        "null"
      ]
    },
    "checker_kind": {
      "type": [
        "string",
        "null"
      ]
    },
    "checker_independent": {
      "type": "boolean"
    },
    "acceptor": {
      "type": [
        "string",
        "null"
      ]
    },
    "release_authority": {
      "type": [
        "string",
        "null"
      ]
    },
    "human_approver": {
      "type": [
        "string",
        "null"
      ]
    },
    "weight_profile": {
      "enum": [
        "LITE",
        "STANDARD",
        "ASSURED"
      ]
    },
    "target_profile": {
      "enum": [
        "SYSTEM",
        "SKILL_PLUGIN",
        "AGENT_HARNESS",
        "CUSTOM"
      ]
    },
    "profile_version": {
      "type": "string"
    },
    "extensions": {
      "type": "array"
    },
    "claim_ceiling": {
      "type": [
        "string",
        "null"
      ]
    },
    "supersedes": {
      "type": "array"
    },
    "created_at": {
      "type": "string",
      "format": "date-time"
    },
    "observed_at": {
      "type": [
        "string",
        "null"
      ],
      "format": "date-time"
    }
  }
}
```
## 3.5 Acceptance / Verification / Failure
- **Acceptance:** A2+A3 required metadata全為 superset、不縮減；自身 front matter遵守同一 envelope 或明示 detached self-hash rule。  
- **Verification:** `TEST-E0C7F7A0`, `TEST-FA7B1B7F`, `TEST-2A89F996` + semantic rules `DOC01-META-001..008`。  
- **Failure:** missing identity/authority/SoD field → `TEMP_CLOSED`; wrong subject/version/hash → reject evidence; superseded source silently current → `INVALIDATED` dependent claim。  
- **Positive:** STANDARD design artifact可有 maker與 author-self-review marker，但不得聲稱 independent checker。  
- **Negative:** `checker="GPT-5.6 Sol"` 且沒有 `checker_independent=false` → fail `DOC01-META-006`。  
- **Cross-DOC:** DOC-04 consumes evidence identity；DOC-05 consumes permission/approval identities；DOC-09 consumes release authority，不取得本節 writer authority。

# 4｜Canonical Lifecycle State Machine — 14× Full State Contract
本節不創造第二 lifecycle；tokens 與 A2 完全一致。Promotion仍受 §6 的 10-condition conjunction控制。
## 4.1 State Contract Table
|State|Meaning|Required predecessor|Allowed next|Allowed claim ceiling|Required evidence class|Rollback/re-entry|Invalidation|Forbidden shortcut / apparent-pass|
|---|---|---|---|---|---|---|---|---|
|`DRAFT`|authoring begun; canonical contract incomplete|`NONE`|`PI_COMPILING`|`NO_COMPLETION_CLAIM`|source/intent refs + draft identity|remain/restart DRAFT after scoped correction|affected-only: stale consumed dependency blocks this state-dependent gate; unrelated states preserved|skip directly from none to a later state; document declaration as evidence substitute|
|`PI_COMPILING`|PI source-to-contract compilation in progress|`DRAFT`|`PI_READY`|`DESIGN_IN_PROGRESS`|trace/requirements/constitution work records|re-enter last valid predecessor after scoped repair; preserve provenance|affected-only: stale consumed dependency blocks this state-dependent gate; unrelated states preserved|skip directly from DRAFT to a later state; document declaration as evidence substitute|
|`PI_READY`|PI contract closure reached; not executable|`PI_COMPILING`|`PREDEV_BINDING`|`DESIGN_CONTRACT_COMPLETE`|PI gate report + constitution + trace closure|re-enter last valid predecessor after scoped repair; preserve provenance|affected-only: stale consumed dependency blocks this state-dependent gate; unrelated states preserved|file/blueprint exists → PI_READY; PI_READY → executable|
|`PREDEV_BINDING`|runtime/repo/provider facts are being late-bound|`PI_READY`|`PREDEV_READY`|`PREDEV_BINDING_IN_PROGRESS`|RepoContext/binding inputs routed to DOC-03|re-enter last valid predecessor after scoped repair; preserve provenance|affected-only: stale consumed dependency blocks this state-dependent gate; unrelated states preserved|skip directly from PI_READY to a later state; document declaration as evidence substitute|
|`PREDEV_READY`|pre-execution engineering complete; still not admitted|`PREDEV_BINDING`|`EXECUTION_ADMISSION_PENDING`|`PRE_EXECUTION_ENGINEERING_COMPLETE`|PD binding + slice TQAEP plan; no execution evidence|re-enter last valid predecessor after scoped repair; preserve provenance|affected-only: stale consumed dependency blocks this state-dependent gate; unrelated states preserved|PD files exist → PREDEV_READY; PREDEV_READY → ADMIT|
|`EXECUTION_ADMISSION_PENDING`|bounded execution decision pending|`PREDEV_READY`|`EXECUTION_ADMITTED`|`AWAITING_ADMISSION`|WorkOrder/ECP/admission inputs; no side-effect grant|re-enter last valid predecessor after scoped repair; preserve provenance|affected-only: stale consumed dependency blocks this state-dependent gate; unrelated states preserved|skip directly from PREDEV_READY to a later state; document declaration as evidence substitute|
|`EXECUTION_ADMITTED`|separate admission object authorizes bounded execution|`EXECUTION_ADMISSION_PENDING`|`IMPLEMENTING`|`AUTHORIZED_TO_BEGIN_BOUNDED_EXECUTION`|subject-bound ADMIT decision|re-enter last valid predecessor after scoped repair; preserve provenance|affected-only: stale consumed dependency blocks this state-dependent gate; unrelated states preserved|ECP/WorkOrder exists → ADMIT without decision object|
|`IMPLEMENTING`|authorized mutation/effect execution active|`EXECUTION_ADMITTED`|`IMPLEMENTED`|`IMPLEMENTATION_IN_PROGRESS`|checkpoint/execution records|re-enter last valid predecessor after scoped repair; preserve provenance|affected-only: stale consumed dependency blocks this state-dependent gate; unrelated states preserved|skip directly from EXECUTION_ADMITTED to a later state; document declaration as evidence substitute|
|`IMPLEMENTED`|declared implementation materialized; not verified|`IMPLEMENTING`|`VERIFYING`|`IMPLEMENTATION_MATERIALIZED`|implementation artifact + readbackable changes|re-enter last valid predecessor after scoped repair; preserve provenance|affected-only: stale consumed dependency blocks this state-dependent gate; unrelated states preserved|skip directly from IMPLEMENTING to a later state; document declaration as evidence substitute|
|`VERIFYING`|verification procedures running|`IMPLEMENTED`|`VERIFIED`|`VERIFICATION_IN_PROGRESS`|fixture/env/oracle/actual/checker records|re-enter last valid predecessor after scoped repair; preserve provenance|affected-only: stale consumed dependency blocks this state-dependent gate; unrelated states preserved|skip directly from IMPLEMENTED to a later state; document declaration as evidence substitute|
|`VERIFIED`|declared verification passed; not qualification|`VERIFYING`|`QUALIFIED`|`DECLARED_VERIFICATION_PASSED`|subject/version/hash-bound verification evidence|re-enter last valid predecessor after scoped repair; preserve provenance|affected-only: stale consumed dependency blocks this state-dependent gate; unrelated states preserved|CI/tool success → VERIFIED without subject-bound oracle evidence|
|`QUALIFIED`|TQAEP qualification authority has accepted qualified evidence|`VERIFIED`|`RELEASED`|`QUALIFICATION_PASSED`|TQAEP execution evidence + qualified roles/authority|re-enter last valid predecessor after scoped repair; preserve provenance|affected-only: stale consumed dependency blocks this state-dependent gate; unrelated states preserved|TQAEP plan exists → QUALIFIED without execution/authority|
|`RELEASED`|release authority has issued release decision|`QUALIFIED`|`PRODUCTION_VERIFIED`|`RELEASED`|release artifact digest/provenance + release authority|re-enter last valid predecessor after scoped repair; preserve provenance|affected-only: stale consumed dependency blocks this state-dependent gate; unrelated states preserved|release artifact exists → RELEASED without authority|
|`PRODUCTION_VERIFIED`|production state/effect independently observed as required|`RELEASED`|`NONE_TERMINAL`|`PRODUCTION_VERIFIED`|production evidence/readback/reconciliation|re-enter last valid predecessor after scoped repair; preserve provenance|affected-only: stale consumed dependency blocks this state-dependent gate; unrelated states preserved|provider success → production verified without readback|

## 4.2 Legal Entry / Exit Predicate
每一 state `S` 的 legal entry MUST satisfy `PromotionPredicate(previous,S)`；terminal or side-state handling不得 bypass canonical predecessor。`QUALIFIED` 另 MUST 具備 **TQAEP execution + qualified evidence + qualification authority**，不是 TQAEP planning completeness。
## 4.3 State-Specific Re-entry and Rollback
- semantic requirement/authority change：回到受影響最早 PI state；不得 global reset。
- repo/provider/env drift：回到受影響 PD binding state；PI semantics若未變保持 current。
- admission/token mismatch：回到 `EXECUTION_ADMISSION_PENDING`；不得改寫 `PREDEV_READY` truth。
- verification/qualification failure：`REWORK_REQUIRED/HOLD` 作 side-state；修復後回到 canonical parent context，而不是另造 lifecycle token。
- release/production drift：依 authority/effect evidence scoped invalidation，保留 prior provenance。
## 4.4 Per-State Positive / Negative Oracle Rule
每列的 positive case = predecessor合法 + §6十條全 true + required evidence appropriate；negative/apparent-pass = 任一 required evidence由文件宣告、tool success、stale/wrong-subject evidence取代。Stable test family=`TEST-B0C02A64`，state-specific semantic rules=`DOC01-STATE-001..014`。

# 5｜Side / Degrade States 與 Projection/Substate Mapping

## 5.1 Side / Degrade States

|State|Meaning|Canonical lifecycle effect|Exit path|Claim-ceiling effect|
|---|---|---|---|---|
|`HOLD`|Progression is intentionally paused pending a resolvable condition.|Unchanged canonical lifecycle state|Clear the blocking condition and rerun the affected gate.|No promotion; retain last honest claim ceiling.|
|`TEMP_CLOSED`|Normative claim/action is fail-closed because required source/fact/anchor is missing or unresolved.|Unchanged canonical lifecycle state|Restore authoritative source/fact, re-ground, then rerun owner decision.|No inference from lower authority or memory.|
|`REWORK_REQUIRED`|A bound validation/verification/admission condition failed and needs correction.|Current honest lifecycle state remains until repaired|Correct affected artifact/implementation; rerun affected tests/gates.|No threshold-lowering or stale PASS reuse.|
|`REJECTED`|An object/decision was explicitly rejected by its authority.|Current honest lifecycle state or terminal decision context|New revision/CR/alternative path with fresh identity.|Rejected object cannot be silently revived.|
|`SUPERSEDED`|A revision is no longer current because a newer valid revision replaced it.|Current lifecycle uses successor only|Preserve provenance; consumers rebind to successor.|Superseded content is forbidden as silent normative fallback.|
|`INVALIDATED`|Previously valid result is no longer reusable for affected scope due to identity/dependency drift.|Last honest lifecycle state for unaffected scope; affected scope blocks|Compute impact graph, recompile/rebind/reverify affected dependents.|Affected evidence/admission/claim cannot be reused.|

These six values **MUST NOT** be injected into `lifecycle_state`. A subject may be, for example, `lifecycle_state=PREDEV_READY` while `degrade_status=TEMP_CLOSED` for one unresolved admission dependency.

## 5.2 Projection / Substate Mapping

|Projection/substate|Canonical parent/context|Allowed use|Forbidden use|Validation|
|---|---|---|---|---|
|`SOURCE_BOUND`|`DRAFT / PI_COMPILING`|Source set and exact identity are bound for compilation.|May guide routing and grounding only.|Projection registry + parent-state compatibility check|
|`CONSTITUTION_READY`|`PI_COMPILING gate flag`|Eight Constitution predicates are true.|Required first prerequisite for PI_READY.|Projection registry + parent-state compatibility check|
|`PD_BOUND`|`PREDEV_BINDING`|Current PI is bound to current PD context.|May indicate binding substate.|Projection registry + parent-state compatibility check|
|`HANDOFF_ACCEPTED`|`EXECUTION_ADMISSION_PENDING`|Receiver acknowledged handoff integrity.|May support admission workflow.|Projection registry + parent-state compatibility check|
|`EVIDENCE_RETURNED`|`IMPLEMENTING / VERIFYING context`|Expected evidence envelope returned.|May trigger oracle evaluation.|Projection registry + parent-state compatibility check|
|`WORLD_RECONCILED`|`Execution/verification context`|Observed world effect is reconciled with intended subject/effect.|May support effect truth.|Projection registry + parent-state compatibility check|

```json
{
  "contract_ref": "PIPD-LIFECYCLE-SPEC@1.1.0#ProjectionStateMapping",
  "projection_state": "CONSTITUTION_READY",
  "canonical_parent": "PI_COMPILING",
  "kind": "GATE_FLAG",
  "may_replace_lifecycle_state": false
}
```

# 6｜Base PromotionPredicate — Prose/Machine Equivalent
Promotion is a conjunction, not a score. 任一 condition false/unknown → promotion FAIL；validator MUST return first failing invariant and MUST NOT infer PASS from previous document claims.
|ID|Predicate|Required input|False behavior|Stable TEST/ORACLE/MUTATION|Transition impact|
|---|---|---|---|---|---|
|`C01`|`required_artifacts_exist=true`|required artifact manifest|missing artifact → false|`TEST-B0C02A64 / OR-B0C02A64 / MUT-2A64-01`|block target state; remain/re-enter prior valid context|
|`C02`|`required_fields_non_placeholder=true`|artifact instances|placeholder/null where required → false|`TEST-B0C02A64 / OR-B0C02A64 / MUT-2A64-02`|block target state; remain/re-enter prior valid context|
|`C03`|`references_resolve=true`|ref resolver|unresolvable ref → false|`TEST-B0C02A64 / OR-B0C02A64 / MUT-2A64-03`|block target state; remain/re-enter prior valid context|
|`C04`|`identities_correct=true`|owner/checker/receiver identities|wrong/ambiguous identity → false|`TEST-B0C02A64 / OR-B0C02A64 / MUT-2A64-04`|block target state; remain/re-enter prior valid context|
|`C05`|`target_gate_true=true`|target gate record|gate false/unknown → false|`TEST-B0C02A64 / OR-B0C02A64 / MUT-2A64-05`|block target state; remain/re-enter prior valid context|
|`C06`|`blocking_tt_zero=true`|TT registry|blocking TT >0 → false|`TEST-B0C02A64 / OR-B0C02A64 / MUT-2A64-06`|block target state; remain/re-enter prior valid context|
|`C07`|`stale_dependency_zero=true`|dependency/currentness graph|stale count >0 → false|`TEST-B0C02A64 / OR-B0C02A64 / MUT-2A64-07`|block target state; remain/re-enter prior valid context|
|`C08`|`permission_admission_satisfied=true`|permission/admission refs|missing/expired/wrong-scope → false|`TEST-B0C02A64 / OR-B0C02A64 / MUT-2A64-08`|block target state; remain/re-enter prior valid context|
|`C09`|`target_state_evidence_subject_bound=true`|evidence set|wrong subject/version/hash/env/procedure → false|`TEST-B0C02A64 / OR-B0C02A64 / MUT-2A64-09`|block target state; remain/re-enter prior valid context|
|`C10`|`no_document_evidence_substitution=true`|claim/evidence classification|plan/document claim used as runtime evidence → false|`TEST-B0C02A64 / OR-B0C02A64 / MUT-2A64-10`|block target state; remain/re-enter prior valid context|

## 6.1 Machine Schema
```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "urn:pipd:doc01:1.1:schema:promotion-evaluation",
  "type": "object",
  "additionalProperties": false,
  "required": [
    "subject_id",
    "from_state",
    "to_state",
    "conditions",
    "result",
    "first_failing_invariant"
  ],
  "properties": {
    "subject_id": {
      "type": "string"
    },
    "from_state": {
      "type": "string"
    },
    "to_state": {
      "type": "string"
    },
    "conditions": {
      "type": "object",
      "required": [
        "required_artifacts_exist",
        "required_fields_non_placeholder",
        "references_resolve",
        "identities_correct",
        "target_gate_true",
        "blocking_tt_zero",
        "stale_dependency_zero",
        "permission_admission_satisfied",
        "target_state_evidence_subject_bound",
        "no_document_evidence_substitution"
      ],
      "properties": {
        "required_artifacts_exist": {
          "type": "boolean"
        },
        "required_fields_non_placeholder": {
          "type": "boolean"
        },
        "references_resolve": {
          "type": "boolean"
        },
        "identities_correct": {
          "type": "boolean"
        },
        "target_gate_true": {
          "type": "boolean"
        },
        "blocking_tt_zero": {
          "type": "boolean"
        },
        "stale_dependency_zero": {
          "type": "boolean"
        },
        "permission_admission_satisfied": {
          "type": "boolean"
        },
        "target_state_evidence_subject_bound": {
          "type": "boolean"
        },
        "no_document_evidence_substitution": {
          "type": "boolean"
        }
      },
      "additionalProperties": false
    },
    "result": {
      "enum": [
        "PASS",
        "FAIL"
      ]
    },
    "first_failing_invariant": {
      "type": [
        "string",
        "null"
      ]
    }
  }
}
```

## 6.2 Deterministic Semantic Rules
`DOC01-PROMO-001`: all 10 booleans MUST be true.  
`DOC01-PROMO-002`: `result=PASS` iff conjunction=true and `first_failing_invariant=null`.  
`DOC01-PROMO-003`: hollow `PI_READY/PREDEV_READY/PASS/ADMIT` strings are never evidence.  
`DOC01-PROMO-004`: projection/degrade labels cannot populate lifecycle state.  
`DOC01-PROMO-005`: claim ceiling cannot exceed destination state table.
## 6.3 Validator Route
Canonical route is `pipd_validate.py <instance> --kind <pi|pd|evidence|admission|effect> --schema-dir ...` from A1. Reference implementation relies on Python `jsonschema` / `Draft202012Validator`; **target exact Python/package pin is PD-late-bound**, not invented here. DOC-01 owns semantic rule identity/interface, not runtime installation.

# 7｜Lifecycle Constitution C-01～C-14 — Full Substantive Contracts
每個 C-xx 本節都具備 A0 要求的 Purpose / Design intent / Required fields / invariants / Owner / Inputs / Outputs / Consumers / MUST/MUST NOT / Acceptance / Verification / Failure / Cross-DOC / Machine / Positive / Negative dimensions；不得以「另節有」取代本節 boundary/interface。
## C-01｜Project / Product Identity

**Purpose.** 凍結 governed subject 是誰、為誰、在什麼 lifecycle scope 施工。

**Design intent.** 避免同名產品、分支、skill/plugin/harness 或 migration target 被混成同一 subject。

**Required fields.** `system_product_name`, `subject_id`, target actors/users, mission/JTBD, lifecycle scope, target type, greenfield/brownfield/migration mode, explicit non-goals.

**Required invariants.** subject identity stable；同名不同 bytes/revision不等同同一 revision；non-goals不可被 implicit scope expansion 覆寫。

**Owner.** `DOC-01`.

**Inputs.** accepted product/domain truth + scoped task

**Outputs.** ProjectIdentityRecord + non-goal set

**Consumers.** all DOCs, package derivation, evidence binding

**Normative MUST / MUST NOT.** MUST freeze identity before `CONSTITUTION_READY`; MUST NOT infer project identity from filename/brand only.

**Acceptance.** all 5 A3 C-01 atomics materially represented；identity collision test passes。

**Verification.** `TEST-C01-ID`, canonical atomics + wrong-subject mutation.

**Failure behavior.** identity ambiguity → `TEMP_CLOSED`; wrong subject evidence rejected.

**Cross-document reference.** DOC-02 consumes identity for TechnologyAdmission; DOC-03 binds RepoContext; neither rewrites identity.

**Machine representation.** `CommonArtifactMetadata.subject_id` + ProjectIdentityRecord profile.

**Positive case.** system A with migration scope + explicit actors/non-goals binds all artifacts to same stable subject.

**Negative / edge / adversarial case.** same display name but different subject hash/version silently reused → FAIL.

## C-02｜Authority Stack

**Purpose.** 定義誰能改變哪一層 truth，以及 conflict 如何 fail closed。

**Design intent.** 將 current scoped task、product/domain truth、accepted baseline、PI/PD、repo-local mechanics、external support分層，避免 provider/adapter/tool自我升權。

**Required fields.** authority_id/rank/scope/subject/version/hash/owner/effective interval/supersedes.

**Required invariants.** higher-rank wins only within scope；same-rank unresolved conflict=`TEMP_CLOSED`; external support never self-promotes.

**Owner.** `DOC-01`.

**Inputs.** A0→A5b authority sources

**Outputs.** AuthorityRecord / conflict decision

**Consumers.** all normative compilers/adapters

**Normative MUST / MUST NOT.** MUST preserve seven A3 authority children；MUST NOT silent merge conflicts or let tool output become authority.

**Acceptance.** rank table + scope + conflict route machine-resolvable.

**Verification.** `TEST-AUTHORITY`, `OR-AUTHORITY`, conflict mutations for same-rank and provider takeover.

**Failure behavior.** unresolved conflict blocks affected claim/gate only.

**Cross-document reference.** DOC-00 navigation projects authority; adapters only route.

**Machine representation.** AuthorityRecord schema/profile + `DOC01-AUTH-001..007`.

**Positive case.** scoped approved change supersedes older same-subject baseline with explicit lineage.

**Negative / edge / adversarial case.** vendor README conflicts with accepted product truth and is silently merged → FAIL.

## C-03｜Canonical Ownership

**Purpose.** 為每個重要 object/decision指定唯一 writer與受治理 consumers/checkers。

**Design intent.** 避免多 writer、mutation authority leak、projection變第二 SSOT。

**Required fields.** object_id, canonical_writer, readers, checker requirement, human authority, change_route, invalidation_trigger.

**Required invariants.** one semantic object→one canonical writer；delegate/projection cannot mutate canonical semantics；ownership change is explicit breaking change.

**Owner.** `DOC-01`.

**Inputs.** object registry + authority model

**Outputs.** CanonicalOwnershipRecord

**Consumers.** all DOCs/adapters

**Normative MUST / MUST NOT.** MUST materialize writer/readers/checker/human/change route + per-object invalidation trigger；MUST NOT collapse semantic ownership into runtime operator.

**Acceptance.** 5 A3 C-03 atomics + ownership mutation tests close.

**Verification.** `TEST-OWNERSHIP` / duplicate writer / unauthorized mutation.

**Failure behavior.** duplicate canonical writers → HOLD/TEMP_CLOSED; unauthorized mutation rejected.

**Cross-document reference.** DOC-04 owns evidence objects; DOC-05 admission; DOC-09 release.

**Machine representation.** CanonicalOwnershipRecord + reverse-dependency graph.

**Positive case.** DOC-01 owns state semantics; DOC-05 merely consumes them for admission.

**Negative / edge / adversarial case.** SKILL adapter rewrites claim ceiling → FAIL.

## C-04｜Lifecycle States

**Purpose.** 固定 14 canonical states 與 legal transition/re-entry contract。

**Design intent.** 避免 operational/provider labels取代 lifecycle truth。

**Required fields.** state token, meaning, predecessor, entry/exit predicate, evidence class, claim ceiling, next states, re-entry/invalidation behavior.

**Required invariants.** exact 14 tokens；side/projection namespaces分離；no shortcut.

**Owner.** `DOC-01`.

**Inputs.** §4 state contract + §6 PromotionPredicate

**Outputs.** CanonicalLifecycleState + transition evaluation

**Consumers.** all DOCs/gates

**Normative MUST / MUST NOT.** MUST use §4 14× contract；MUST NOT invent alternate happy-path lifecycle.

**Acceptance.** all 14 have entry/claim/reentry/invalidation/fixture semantics.

**Verification.** `DOC01-STATE-001..014` + TEST-B0C02A64.

**Failure behavior.** unknown/illegal state → reject/temporary close affected projection.

**Cross-document reference.** DOC-03 binds PD context; DOC-05 admission; DOC-07 conformance consumes state truth.

**Machine representation.** §4 machine state + promotion schemas.

**Positive case.** PI_READY followed by PREDEV_BINDING after legal gate.

**Negative / edge / adversarial case.** PREDEV_READY directly to IMPLEMENTING → FAIL.

## C-05｜Claim Rules

**Purpose.** 限制每個 state/證據能誠實聲稱的最高 truth。

**Design intent.** 阻止 document materialization、tool success、CI green、release artifact existence被誤升級。

**Required fields.** artifact_materialization_claim, governed_subject_state, governed_subject_claim_ceiling, evidence refs, forbidden claims.

**Required invariants.** artifact claim namespace != lifecycle claim namespace；claim ≤ state ceiling；evidence subject-bound.

**Owner.** `DOC-01`.

**Inputs.** state + evidence identity

**Outputs.** ClaimCeilingRecord

**Consumers.** all downstream/release surfaces

**Normative MUST / MUST NOT.** MUST preserve 9 claim-separation atomics；MUST NOT infer runtime state from docs/plans.

**Acceptance.** claim lint passes and no namespace inflation.

**Verification.** `TEST-C6A9781D` + 9 mutations.

**Failure behavior.** inflated claim → FAIL + invalidate dependent acceptance.

**Cross-document reference.** DOC-04 evidence; DOC-09 release decision.

**Machine representation.** ClaimCeilingRecord + linter rules.

**Positive case.** r2 file exists → only artifact materialized; subject state remains null.

**Negative / edge / adversarial case.** TQAEP_COMPLETE string → QUALIFIED → FAIL.

## C-06｜Permission / Side-Effect Policy

**Purpose.** 定義 effect classes與 admission interface，但不奪取 DOC-05 execution-admission ownership。

**Design intent.** 文件存在不得授權 side effect。

**Required fields.** 11 permission classes, risk level, approval requirement, policy token ref, scope, expiry, rollback requirement.

**Required invariants.** before EXECUTION_ADMITTED effectful classes default DENY；high-risk scope requires subject-bound approval where applicable.

**Owner.** `DOC-01 constitution / DOC-05 runtime admission owner`.

**Inputs.** state/permission policy + approval metadata

**Outputs.** PermissionPolicyRecord interface

**Consumers.** DOC-05, executors, auditors

**Normative MUST / MUST NOT.** MUST keep 11 classes; MUST NOT let adapter/ECP/WorkOrder self-authorize.

**Acceptance.** policy interface complete + route-out to DOC-05.

**Verification.** negative fixtures: execution-before-ADMIT, expired token, wrong scope.

**Failure behavior.** missing/invalid approval → DENY/BLOCK_EXTERNAL; no lifecycle promotion.

**Cross-document reference.** DOC-05 owns ExecutionAdmission decision object.

**Machine representation.** PermissionClassPolicy; canonical admission schema referenced, not redefined.

**Positive case.** READ_ONLY allowed before admission where policy permits.

**Negative / edge / adversarial case.** DEPLOY because WorkOrder exists → FAIL.

## C-07｜Security / Trust Boundary

**Purpose.** 定義 untrusted input、secrets、identity/tool/memory/inter-agent boundaries。

**Design intent.** 讓 security semantics進入 Constitution而不是後補 checklist。

**Required fields.** trust_boundary_id, asset, input trust label, identity/auth, tool permissions, secret policy, memory policy, handoff boundary, rollback/revocation, evidence sensitivity.

**Required invariants.** external content is DATA；secrets not embedded in PI；memory cannot auto-elevate authority.

**Owner.** `DOC-01 constitution; detailed security/evidence owners consume`.

**Inputs.** source/tool/agent/context boundaries

**Outputs.** SecurityBoundaryContract + threat rows

**Consumers.** DOC-03/04/05/06/07

**Normative MUST / MUST NOT.** MUST define prevention/detection/response interfaces; MUST NOT interpret untrusted content as instruction absent authorized surface.

**Acceptance.** C-14 rows schema-valid + ContextTrustRecord complete.

**Verification.** threat-model schema + prompt/tool/memory poisoning fixtures.

**Failure behavior.** material unresolved high-risk threat → HOLD/TEMP_CLOSED.

**Cross-document reference.** DOC-04 assurance evidence; DOC-05 permission enforcement.

**Machine representation.** canonical threat-model `$id` + ContextTrustRecord.

**Positive case.** external web text stored as DATA with trust label and source.

**Negative / edge / adversarial case.** memory replays external instruction as authority → FAIL.

## C-08｜Change / Supersession

**Purpose.** 讓 semantic/currentness/runtime drift只 invalidate受影響依賴。

**Design intent.** 禁止 global reset，也禁止 stale reuse。

**Required fields.** change_id,class,event_id,changed_node,prior/new hash,affected scope, first invalidated object, gate, recovery, supersedes/rollback target.

**Required invariants.** six change classes + retained 18-event matrix + reverse dependency algorithm.

**Owner.** `DOC-01`.

**Inputs.** change event + dependency graph

**Outputs.** ChangeRecord + InvalidationRecord

**Consumers.** all compilers/gates

**Normative MUST / MUST NOT.** MUST record emergency route and consumer-specific invalidation；MUST NOT global-reset unrelated artifacts.

**Acceptance.** 18/18 event routing and affected-only tests pass.

**Verification.** §18 event matrix + dependency mutation.

**Failure behavior.** unknown material change impact → HOLD affected gate.

**Cross-document reference.** DOC-03 handles repo drift; DOC-02 technology re-adjudication; DOC-09 release drift.

**Machine representation.** ChangeRecord / InvalidationRecord.

**Positive case.** provider version drift reopens PD only if PI semantics unchanged.

**Negative / edge / adversarial case.** typo triggers global PI rebuild → FAIL.

## C-09｜Tailoring Profile

**Purpose.** 選擇適當 LITE/STANDARD/ASSURED 與 target profile。

**Design intent.** 避免所有工作同一重量或風險不足。

**Required fields.** weight_profile,target_profile,profile_version,applicability,extensions,exceptions,authority.

**Required invariants.** profile may add tests/contracts; cannot remove applicable core without accepted N/A rationale.

**Owner.** `DOC-01`.

**Inputs.** ComplexityBudgetDecision + risk/authority context

**Outputs.** ProfileBindingRecord

**Consumers.** all DOCs

**Normative MUST / MUST NOT.** MUST select profile before CONSTITUTION_READY；MUST NOT use profile to weaken core identity/claim/permission/evidence rules.

**Acceptance.** 4 A3 C-09 atomics + profile binding tests.

**Verification.** profile schema + complexity decision.

**Failure behavior.** missing profile → gate false.

**Cross-document reference.** DOC-06 may own domain profile details; core remains DOC-01.

**Machine representation.** ProfileBindingRecord.

**Positive case.** LITE selected for bounded reversible low-risk slice with rationale.

**Negative / edge / adversarial case.** ASSURED-required physical action downgraded to LITE without authority → FAIL.

## C-10｜Definition of Pre-Execution Complete

**Purpose.** 把 project-specific PRE_EXECUTION_ENGINEERING_COMPLETE變成可執行 predicate，而非敘述。

**Design intent.** PREDEV_READY 不等於 execution admitted。

**Required fields.** predicate_id, required PI closure, PD bindings, TQAEP-ready refs, rollback/evidence plan, blocking TT/stale counts, result.

**Required invariants.** all prerequisites true; no runtime action implied.

**Owner.** `DOC-01 defines constitutional shape; DOC-03/05 provide bindings/admission`.

**Inputs.** PI/PD closure + slice plan

**Outputs.** PreExecutionCompleteEvaluation

**Consumers.** DOC-03/05

**Normative MUST / MUST NOT.** MUST machine-evaluate; MUST NOT treat ECP/TQAEP plan existence as execution/qualification.

**Acceptance.** negative hollow PREDEV_READY mutation fails.

**Verification.** `TEST-PREEXEC-COMPLETE`, semantic validator.

**Failure behavior.** false → remain PREDEV_BINDING/PREDEV_READY not claimable.

**Cross-document reference.** DOC-03 binds exact runtime facts; DOC-05 later admits execution.

**Machine representation.** DOC01 extension schema + canonical refs.

**Positive case.** all bindings + no stale deps + no TT → PREDEV_READY eligible.

**Negative / edge / adversarial case.** PD doc title says ready but rollback missing → FAIL.

## C-11｜Standard Namespace / Schema Compatibility

**Purpose.** 固定 `urn:pipd:canonical-standard:1.1` 與 schema evolution policy。

**Design intent.** 避免 duplicate `$id`、example.org final IDs、silent incompatible schema migration。

**Required fields.** namespace, schema `$id`, version, supersedes, compatibility class, migration note, validator dialect.

**Required invariants.** Draft 2020-12 canonical；patch/minor/major semantics明确；duplicate `$id` rejected.

**Owner.** `DOC-01`.

**Inputs.** canonical schema registry/extraction manifest

**Outputs.** NamespaceCompatibilityRecord

**Consumers.** validators/adapters

**Normative MUST / MUST NOT.** MUST validate extraction manifest and duplicate IDs；MUST NOT create competing canonical `$id`.

**Acceptance.** A3 extraction atomic + C-11 atomics pass.

**Verification.** schema extraction + duplicate `$id` destructive test.

**Failure behavior.** duplicate/conflicting schema IDs → TEMP_CLOSED.

**Cross-document reference.** DOC-07 conformance oracle consumes schemas; DOC-09 CI routes validator.

**Machine representation.** canonical schema IDs + extraction manifest.

**Positive case.** project extension uses organization-owned URN and core_override=false.

**Negative / edge / adversarial case.** final canonical schema uses example.org → FAIL.

## C-12｜DomainProfileExtension

**Purpose.** 允許 domain-specific增量，不污染 portable core。

**Design intent.** 擴充只能加嚴／增加，不得覆寫核心。

**Required fields.** profile_id,inherits_core,additional_contracts,additional_risks,additional_gates,schema_refs,core_override.

**Required invariants.** `core_override=false`; cannot weaken identity/claims/permissions/source/evidence/invalidation.

**Owner.** `DOC-01 core constitution; domain owner extends`.

**Inputs.** domain requirements + core profile

**Outputs.** typed DomainProfileExtension

**Consumers.** DOC-06/domain consumers

**Normative MUST / MUST NOT.** MUST namespaced extension；MUST NOT redefine core lifecycle.

**Acceptance.** extension validates and compatibility test passes.

**Verification.** negative mutation `core_override=true`.

**Failure behavior.** invalid extension → reject extension, preserve core.

**Cross-document reference.** DOC-06 owns domain-specific profile materialization.

**Machine representation.** A2 extension record + namespace policy.

**Positive case.** robotics extension adds physical-action gate without altering core states.

**Negative / edge / adversarial case.** plugin extension removes evidence binding → FAIL.

## C-13｜Documentation Grounding Profile

**Purpose.** 讓 AI/LLM-assisted normative claims可定位、可失效、可 abstain。

**Design intent.** 防止找不到 exact source時回退到模糊歷史 volume。

**Required fields.** grounding_id,source_id/version/hash,exact_locator,grounded_claim,retrieval_method,state,stale_invalidation_trigger.

**Required invariants.** missing required source/anchor→claim TEMP_CLOSED；retrieval output remains DATA until admitted.

**Owner.** `DOC-01`.

**Inputs.** source-bound claims

**Outputs.** DocumentationGroundingRecord

**Consumers.** all authoring/review surfaces

**Normative MUST / MUST NOT.** MUST preserve exact locator and source version/hash；MUST NOT infer absent normative content.

**Acceptance.** canonical schema validates + stale-source fixture.

**Verification.** `urn:pipd:canonical-standard:1.1:schema:documentation-grounding`.

**Failure behavior.** missing locator → affected claim abstains.

**Cross-document reference.** DOC-04 evidence may record verification; grounding itself not verification.

**Machine representation.** canonical documentation-grounding schema.

**Positive case.** claim cites A2 exact section/hash and invalidates on hash drift.

**Negative / edge / adversarial case.** semantic search hit without exact source used as normative authority → FAIL.

## C-14｜Security Threat Model

**Purpose.** 將 STANDARD/ASSURED 風險以 canonical ThreatModelRow closure。

**Design intent.** 讓 asset/boundary/abuse/prevention/detection/response/owner/residual risk都可 machine consume。

**Required fields.** `threat_id, threat, asset, trust_boundary, abuse_case, prevention[], detection[], response[], test_oracle_ref, owner, residual_risk, evidence_expectation_ref`; human gate where applicable.

**Required invariants.** ASSURED/high-risk rows mandatory；absence of mitigation != no risk；agent profile covers goal hijack/tool misuse/identity abuse/memory poisoning/inter-agent abuse/cascade/rogue action/sensitive leakage.

**Owner.** `DOC-01 constitution-level threat contract; security owner populates project rows`.

**Inputs.** trust boundaries + target profile + permissions

**Outputs.** schema-valid ThreatModelRow set

**Consumers.** DOC-04/05/06/07

**Normative MUST / MUST NOT.** MUST use canonical `$id`; MUST NOT compress to 5-column summary.

**Acceptance.** all required rows validate and agent threats independently represented.

**Verification.** canonical `threat-model.schema.json` + TEST-D28A8B60.

**Failure behavior.** missing owner/residual/test oracle → invalid row and high-risk gate HOLD.

**Cross-document reference.** DOC-04 checks evidence; DOC-05 enforces permissions.

**Machine representation.** `urn:pipd:canonical-standard:1.1:schema:threat-model`.

**Positive case.** goal hijack row names owner, controls, oracle, residual risk.

**Negative / edge / adversarial case.** generic “prompt injection” row used to imply all agent threats covered → FAIL.

## 7.15｜P-09 Complexity Must Earn Complexity — 8/8
The decision MUST independently account for: package count, chapter count, gate count, assurance depth, side-effect risk, integration count, reversibility, assurance need. Complexity is justified only where correctness/risk/authority warrants it; simplification is required otherwise.
|Atomic|Obligation|Closure|
|---|---|---|
|`STD-REQ-4AAA061A-C01`|package count earned by complexity|`ComplexityBudgetDecision` + `TEST-4AAA061A/OR-4AAA061A/MUT-061A-01`|
|`STD-REQ-4AAA061A-C02`|chapter count earned by complexity|`ComplexityBudgetDecision` + `TEST-4AAA061A/OR-4AAA061A/MUT-061A-02`|
|`STD-REQ-4AAA061A-C03`|gate count earned by risk/assurance|`ComplexityBudgetDecision` + `TEST-4AAA061A/OR-4AAA061A/MUT-061A-03`|
|`STD-REQ-4AAA061A-C04`|assurance depth earned by authority complexity|`ComplexityBudgetDecision` + `TEST-4AAA061A/OR-4AAA061A/MUT-061A-04`|
|`STD-REQ-4AAA061A-C05`|side-effect risk included|`ComplexityBudgetDecision` + `TEST-4AAA061A/OR-4AAA061A/MUT-061A-05`|
|`STD-REQ-4AAA061A-C06`|integration count included|`ComplexityBudgetDecision` + `TEST-4AAA061A/OR-4AAA061A/MUT-061A-06`|
|`STD-REQ-4AAA061A-C07`|reversibility included|`ComplexityBudgetDecision` + `TEST-4AAA061A/OR-4AAA061A/MUT-061A-07`|
|`STD-REQ-4AAA061A-C08`|assurance need included|`ComplexityBudgetDecision` + `TEST-4AAA061A/OR-4AAA061A/MUT-061A-08`|
```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "urn:pipd:doc01:1.1:schema:complexity-budget-decision",
  "type": "object",
  "additionalProperties": false,
  "required": [
    "decision_id",
    "side_effect_risk",
    "integration_count",
    "reversibility",
    "authority_complexity",
    "assurance_need",
    "package_count_justified",
    "chapter_count_justified",
    "gate_depth_justified",
    "assurance_depth_justified",
    "weight_profile",
    "rationale"
  ],
  "properties": {
    "decision_id": {
      "type": "string"
    },
    "side_effect_risk": {
      "enum": [
        "LOW",
        "MEDIUM",
        "HIGH",
        "CRITICAL"
      ]
    },
    "integration_count": {
      "type": "integer",
      "minimum": 0
    },
    "reversibility": {
      "enum": [
        "EASY",
        "BOUNDED",
        "HARD",
        "IRREVERSIBLE"
      ]
    },
    "authority_complexity": {
      "enum": [
        "LOW",
        "MEDIUM",
        "HIGH"
      ]
    },
    "assurance_need": {
      "enum": [
        "LITE",
        "STANDARD",
        "ASSURED"
      ]
    },
    "package_count_justified": {
      "type": "boolean"
    },
    "chapter_count_justified": {
      "type": "boolean"
    },
    "gate_depth_justified": {
      "type": "boolean"
    },
    "assurance_depth_justified": {
      "type": "boolean"
    },
    "weight_profile": {
      "enum": [
        "LITE",
        "STANDARD",
        "ASSURED"
      ]
    },
    "rationale": {
      "type": "string",
      "minLength": 1
    }
  }
}
```

**Failure:** package/chapter/gate/assurance depth added without earned rationale → reject derivation or reduce profile; high-risk complexity omitted → raise profile/gate depth.
## 7.16｜P-11 Capability-Before-Brand / Search-Before-Build — Constitution-Level 10/10
DOC-01 owns the invariant/order; DOC-02 owns project TechnologyAdmission terminal adjudication. Required order: need before brand → internal reuse → external scout → normalize → fit/gap → security/license/maturity/maintenance/supply-chain → portability/testability/brownfield/exit → terminal disposition → version/currentness policy → `BUILD_MINIMAL` only with demonstrated `NO_FIT`.
|Atomic|Obligation|Closure|
|---|---|---|
|`STD-REQ-98BC2330-C01`|express need/capability before brand|`CapabilityBeforeBrandDecision` + `TEST-98BC2330/OR-98BC2330/MUT-2330-01`|
|`STD-REQ-98BC2330-C02`|check internal reuse first|`CapabilityBeforeBrandDecision` + `TEST-98BC2330/OR-98BC2330/MUT-2330-02`|
|`STD-REQ-98BC2330-C03`|scout external candidates second|`CapabilityBeforeBrandDecision` + `TEST-98BC2330/OR-98BC2330/MUT-2330-03`|
|`STD-REQ-98BC2330-C04`|normalize candidate identity|`CapabilityBeforeBrandDecision` + `TEST-98BC2330/OR-98BC2330/MUT-2330-04`|
|`STD-REQ-98BC2330-C05`|gap/fit comparison|`CapabilityBeforeBrandDecision` + `TEST-98BC2330/OR-98BC2330/MUT-2330-05`|
|`STD-REQ-98BC2330-C06`|security/license/maturity/maintenance/supply-chain evaluation|`CapabilityBeforeBrandDecision` + `TEST-98BC2330/OR-98BC2330/MUT-2330-06`|
|`STD-REQ-98BC2330-C07`|portability/testability/brownfield/exit evaluation|`CapabilityBeforeBrandDecision` + `TEST-98BC2330/OR-98BC2330/MUT-2330-07`|
|`STD-REQ-98BC2330-C08`|terminal disposition required|`CapabilityBeforeBrandDecision` + `TEST-98BC2330/OR-98BC2330/MUT-2330-08`|
|`STD-REQ-98BC2330-C09`|version/currentness pin required|`CapabilityBeforeBrandDecision` + `TEST-98BC2330/OR-98BC2330/MUT-2330-09`|
|`STD-REQ-98BC2330-C11`|BUILD_MINIMAL only after demonstrated no-fit|`CapabilityBeforeBrandDecision` + `TEST-98BC2330/OR-98BC2330/MUT-2330-11`|
```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "urn:pipd:doc01:1.1:schema:capability-before-brand-decision",
  "type": "object",
  "additionalProperties": false,
  "required": [
    "need_id",
    "capability_before_brand",
    "internal_reuse_checked",
    "external_scout_checked",
    "candidates_normalized",
    "fit_compared",
    "security_license_maturity_checked",
    "portability_testability_exit_checked",
    "terminal_disposition",
    "currentness_policy",
    "build_minimal_no_fit_proof"
  ],
  "properties": {
    "need_id": {
      "type": "string"
    },
    "capability_before_brand": {
      "type": "boolean"
    },
    "internal_reuse_checked": {
      "type": "boolean"
    },
    "external_scout_checked": {
      "type": "boolean"
    },
    "candidates_normalized": {
      "type": "boolean"
    },
    "fit_compared": {
      "type": "boolean"
    },
    "security_license_maturity_checked": {
      "type": "boolean"
    },
    "portability_testability_exit_checked": {
      "type": "boolean"
    },
    "terminal_disposition": {
      "type": "string"
    },
    "currentness_policy": {
      "type": "string"
    },
    "build_minimal_no_fit_proof": {
      "type": [
        "string",
        "null"
      ]
    }
  }
}
```

`BUILD_MINIMAL` without explicit no-fit evidence is non-conformant. Brand-first, popularity-first, README-first, tool-output-self-admission are forbidden.
## 7.17｜Persistent Memory / Context Trust Contract
Persistent memory/context MUST carry `source`, `scope`, `expiry/invalidation`, `trust_label`; external content MUST NOT auto-elevate authority through memory or retrieval.

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "urn:pipd:doc01:1.1:schema:context-trust-record",
  "type": "object",
  "additionalProperties": false,
  "required": [
    "context_id",
    "source",
    "scope",
    "expiry_or_invalidation",
    "trust_label",
    "authority_effect"
  ],
  "properties": {
    "context_id": {
      "type": "string"
    },
    "source": {
      "type": "string"
    },
    "scope": {
      "type": "string"
    },
    "expiry_or_invalidation": {
      "type": "string"
    },
    "trust_label": {
      "enum": [
        "CANONICAL",
        "ACCEPTED_SUPPORT",
        "UNTRUSTED_DATA",
        "QUARANTINED"
      ]
    },
    "authority_effect": {
      "const": "NO_AUTOMATIC_ELEVATION"
    }
  }
}
```

`STD-REQ-86CAC54E-C01` closes only when all four trust dimensions are present.
## 7.18｜Stable Semantics vs Late-Bound Facts
PI freezes stable semantic decisions; PD late-binds repo HEAD, provider/version/environment/currentness. Missing runtime facts MUST NOT postpone all design, and PI MUST NOT fabricate runtime facts. `STD-REQ-689DE502-C01` is closed by explicit route-out: DOC-03 owns runtime binding; DOC-01 owns the separation invariant.

# 8｜CONSTITUTION_READY Gate

`CONSTITUTION_READY` is a gate flag under `PI_COMPILING`, not a canonical lifecycle state. `PI_READY` requires it as the first prerequisite.

|ID|Predicate|TRUE iff|FALSE route|
|---|---|---|---|
|`CRDY-01`|`identity_frozen`|Project/product/subject identity, scope and artifact identity are unambiguous and versioned.|`PI_COMPILING` remains; fail closed with scoped diagnosis|
|`CRDY-02`|`authority_resolved`|Authority stack is materialized; no unresolved blocking same-rank conflict remains.|`PI_COMPILING` remains; fail closed with scoped diagnosis|
|`CRDY-03`|`owner_model_resolved`|Canonical writers/readers/checkers/acceptors and change routes are assigned.|`PI_COMPILING` remains; fail closed with scoped diagnosis|
|`CRDY-04`|`permission_model_resolved`|Constitution-level permission/side-effect categories, default-deny and approval boundaries are declared.|`PI_COMPILING` remains; fail closed with scoped diagnosis|
|`CRDY-05`|`lifecycle_states_declared`|The canonical 14-state lifecycle plus side/degrade/projection separation is declared without substitution.|`PI_COMPILING` remains; fail closed with scoped diagnosis|
|`CRDY-06`|`claim_rules_declared`|State/evidence/claim/claim-ceiling rules and forbidden inference rules are materialized.|`PI_COMPILING` remains; fail closed with scoped diagnosis|
|`CRDY-07`|`change_rules_declared`|Versioning, supersession, change classes and affected-only invalidation rules are materialized.|`PI_COMPILING` remains; fail closed with scoped diagnosis|
|`CRDY-08`|`tailoring_profile_selected`|Weight profile and target profile are selected; extensions cannot weaken core invariants.|`PI_COMPILING` remains; fail closed with scoped diagnosis|

Boolean rule:

`CONSTITUTION_READY = identity_frozen ∧ authority_resolved ∧ owner_model_resolved ∧ permission_model_resolved ∧ lifecycle_states_declared ∧ claim_rules_declared ∧ change_rules_declared ∧ tailoring_profile_selected`

### Failure / apparent-pass matrix

|Case|Expected result|Reason|
|---|---|---|
|Seven predicates true, one false|FALSE|Gate is conjunction; no partial pass.|
|Eight booleans true but ownership refs unresolved|FALSE|Predicate evidence is invalid; PP-03/PP-04 fail.|
|DOC-00 displays `CONSTITUTION_READY` from stale projection|FALSE for promotion|Canonical source must be current and subject-bound.|
|A generated text says “constitution complete” without machine record|FALSE|Document assertion is not gate evidence.|
|All eight current and validated|TRUE|May satisfy the first prerequisite for PI_READY; PI_READY still has additional requirements.|

```json
{
  "contract_ref": "PIPD-LIFECYCLE-SPEC@1.1.0#CONSTITUTION_READY",
  "gate": "CONSTITUTION_READY",
  "predicates": [
    "identity_frozen",
    "authority_resolved",
    "owner_model_resolved",
    "permission_model_resolved",
    "lifecycle_states_declared",
    "claim_rules_declared",
    "change_rules_declared",
    "tailoring_profile_selected"
  ],
  "truth_rule": "ALL_TRUE",
  "canonical_lifecycle_state": false
}
```

## 8.4 Machine Enforcement Upgrade
`CONSTITUTION_READY` is validated by `DOC01-CONST-READY-001`: exactly eight predicates MUST be true; a bare `CONSTITUTION_READY=true` without predicate evidence is a hollow pass and MUST fail `MUT-CONST-HOLLOW-01`. It is a projection/gate flag, never a lifecycle state.

# 9｜Claim Model / Claim Ceiling

|Canonical context|Minimum evidence class|Allowed claim|Forbidden higher inference|Claim ceiling|
|---|---|---|---|---|
|`DRAFT / PI_COMPILING`|Identity/source/compilation records|`WORK_IN_PROGRESS / no readiness claim`|PI_READY, PRE_EXECUTION_ENGINEERING_COMPLETE, execution claims|`NO_READINESS`|
|`PI_READY`|Constitution + PI gate closure|`DESIGN_CONTRACT_COMPLETE`|Executable/admitted/implemented/verified/qualified/released/production claims|`DESIGN_CONTRACT_COMPLETE`|
|`PREDEV_READY`|Current PD binding + ECP/TQAEP/handoff preparation|`PRE_EXECUTION_ENGINEERING_COMPLETE`|Execution admitted or later runtime claims|`PRE_EXECUTION_ENGINEERING_COMPLETE`|
|`EXECUTION_ADMITTED`|Current subject-bound admission decision|`AUTHORIZED_TO_BEGIN_BOUNDED_EXECUTION`|Implemented/verified/qualified/released/production|`AUTHORIZED_TO_BEGIN_BOUNDED_EXECUTION`|
|`IMPLEMENTED`|Materialized implementation/effect artifacts|`IMPLEMENTATION_MATERIALIZED`|Verification/qualification/release/production|`IMPLEMENTATION_MATERIALIZED`|
|`VERIFIED`|Current subject-bound verification PASS|`DECLARED_VERIFICATION_PASSED`|Qualification/release/production|`DECLARED_VERIFICATION_PASSED`|
|`QUALIFIED`|Qualification authority decision + evidence|`QUALIFICATION_PASSED`|Release/production|`QUALIFICATION_PASSED`|
|`RELEASED`|Release authority + release evidence|`RELEASED`|Production verified|`RELEASED`|
|`PRODUCTION_VERIFIED`|Production observation/readback/reconciliation evidence|`PRODUCTION_VERIFIED`|Claims outside exact subject/scope/evidence|`PRODUCTION_VERIFIED`|

Claim evaluation **MUST** be subject/version/hash aware. A PASS for another revision, environment, provider binding or slice does not lift the current subject's claim ceiling.

```json
{
  "contract_ref": "PIPD-LIFECYCLE-SPEC@1.1.0#ClaimCeiling",
  "state": "PREDEV_READY",
  "allowed_claim": "PRE_EXECUTION_ENGINEERING_COMPLETE",
  "forbidden_claims": [
    "EXECUTION_ADMITTED",
    "IMPLEMENTED",
    "VERIFIED",
    "QUALIFIED",
    "RELEASED",
    "PRODUCTION_VERIFIED"
  ],
  "evidence_subject_binding_required": true
}
```

# 10｜Four Typed Namespaces — Forbidden Mixing

|Namespace|Canonical/allowed values|Writer class|Meaning|Forbidden mixing|
|---|---|---|---|---|
|`lifecycle_state`|14 canonical states in §4|DOC-01 semantic model; stage fact writers by ownership|Where the subject is in the lifecycle|`TEMP_CLOSED`, `DENY`, `BLOCKED_EXTERNAL`, projection labels|
|`degrade_status`|`NORMAL`, `HOLD`, `TEMP_CLOSED`, `REWORK_REQUIRED`, `REJECTED`, `SUPERSEDED`, `INVALIDATED` plus namespaced operational statuses|Owning failure/degrade process|Why progression/reuse is limited|Cannot replace lifecycle state|
|`decision`|`CONTINUE_LOCAL`, `HOLD`, `DENY`, `TEMP_CLOSE`, `BLOCK_EXTERNAL`, plus owner-specific decisions such as `ADMIT` in DOC-05|Canonical decision owner|What action is currently authorized/blocked|Cannot be treated as lifecycle state or claim|
|`claim_ceiling`|`NO_READINESS`, `DESIGN_CONTRACT_COMPLETE`, `PRE_EXECUTION_ENGINEERING_COMPLETE`, `AUTHORIZED_TO_BEGIN_BOUNDED_EXECUTION`, `IMPLEMENTATION_MATERIALIZED`, `DECLARED_VERIFICATION_PASSED`, `QUALIFICATION_PASSED`, `RELEASED`, `PRODUCTION_VERIFIED`|Derived from canonical state + current evidence/authority|Highest honest statement|Cannot be raised by projection, adapter, provider success or plan existence|

Conversion is one-way and rule-bound: facts may contribute to a state gate; state + evidence may derive a claim ceiling; a decision may authorize an action. None of these namespaces may be assigned by string resemblance.

# 11｜Authority Stack / Conflict Resolution

## 11.1 Authority Record

```json
{
  "contract_ref": "PIPD-LIFECYCLE-SPEC@1.1.0#Authority",
  "authority_id": "AUTH-PIPD-DOC01",
  "ranks": [
    "CURRENT_SCOPED_TASK",
    "PRODUCT_DOMAIN_TRUTH",
    "ACCEPTED_ARCH_REQUIREMENT_BASELINE",
    "CURRENT_PI_PD",
    "REPO_LOCAL_MECHANICS",
    "EXTERNAL_SUPPORT"
  ],
  "same_rank_conflict": "TEMP_CLOSED",
  "adapter_override_allowed": false
}
```

## 11.2 Conflict Matrix

|Conflict class|Detection|Normative action|Forbidden behavior|
|---|---|---|---|
|Cross-rank conflict|Two clauses disagree and ranks differ|Higher rank wins within scope; record displaced lower claim|Average/merge semantics|
|Same-rank conflict|Two current same-rank authorities disagree|`HOLD/TEMP_CLOSED`; route to canonical owner/approver|Choose the one that “looks reasonable”|
|Authority inversion|Lower source attempts to rewrite higher source|Reject rewrite; preserve higher source|Repo/vendor/Web overriding product truth|
|Projection override|DOC-00/adapter projection differs from canonical record|Canonical owner record wins; projection marked stale|Change canonical truth to match UI/router|
|Adapter override|AGENTS/SKILL/IDE/provider config grants or changes lifecycle semantics|Reject and quarantine affected instruction|Treat adapter as SSOT|
|Provider/tool self-promotion|Tool says success/PASS/authorized|Treat as data; evaluate PIPD oracle/admission/effect reconciliation|Provider success = acceptance/world truth|
|External-content injection|External text instructs authority/secret/permission change|STOP affected action, QUARANTINE content, REDACT secrets/PII, TT if needed|Execute embedded instructions|

# 12｜Canonical Ownership / Segregation of Duties

## 12.1 Ownership Model

```json
{
  "contract_ref": "PIPD-LIFECYCLE-SPEC@1.1.0#CanonicalOwnership",
  "object_id": "LifecycleState",
  "writer": "DOC-01_SEMANTIC_OWNER",
  "readers": [
    "DOC-00",
    "DOC-02",
    "DOC-03",
    "DOC-04",
    "DOC-05",
    "DOC-06",
    "DOC-07",
    "DOC-08",
    "DOC-09"
  ],
  "maker": "PROJECT_CONSTITUTION_MAKER",
  "checker": "PROFILE_REQUIRED_CHECKER",
  "acceptor": "PROFILE_REQUIRED_ACCEPTOR",
  "human_authority": "WHEN_REQUIRED_BY_RISK_PROFILE",
  "change_route": "CR_OR_AFFECTED_ONLY_INVALIDATION"
}
```

## 12.2 DOC-01 Owned Objects

|Object|Canonical writer|Instance maker|Checker|Acceptor / human authority|Primary consumers|Change route|
|---|---|---|---|---|---|---|
|Authority stack|DOC-01 Constitution owner|Project Constitution maker|Profile-required checker|Human/project authority where scoped|all DOCs/adapters|CR + supersession|
|Canonical lifecycle state vocabulary|DOC-01|N/A semantic definition|Conformance checker|Standard owner|all|major standard change|
|State transition legality|DOC-01|Stage fact producers|DOC-07/conformance checker|Stage authority|DOC-00..09|affected-only invalidation|
|Claim ceilings|DOC-01|Derived from current evidence|Evidence/claim checker|Stage/release/production authority as applicable|all readers|evidence/state invalidation|
|Ownership/SoD registry|DOC-01|Project Constitution maker|Independent checker for ASSURED/high-risk|Human authority where required|all|CR|
|Permission categories|DOC-01|Project policy maker|Security checker|DOC-05 admission/human authority for actual permission|DOC-03/05/06|policy change|
|Change/supersession taxonomy|DOC-01|Change owner|Impact checker|Canonical owner|all|CR / emergency route|
|Package derivation rules|DOC-01|Package compiler|Architecture/ownership checker|Project Constitution authority|DOC-02/03/06/09|CR|
|Vertical-slice eligibility constitution|DOC-01|Slice compiler|Dependency/admission checker|DOC-05 for actual ADMIT|DOC-02/03/05/09|affected slice invalidation|

### 12.3 SoD Rules

For `ASSURED`/high-risk scope:
1. `maker == checker == acceptor` is non-conformant by default.
2. Same-model bounded self-review is quality control only, **not Independent PASS**.
3. Sender readiness cannot equal receiver acceptance.
4. Evidence producer cannot unilaterally confer qualification/release authority.
5. Exception requires a scoped Constitution rule plus independent approval; exception scope, expiry and affected objects must be explicit.

# 13｜Permission / Side-Effect Constitution

|Class|Meaning|Required constitutional boundary|Explicitly not granted|
|---|---|---|---|
|`READ_ONLY`|Observe/read/search without mutation.|Normally no mutation approval; still subject to data/security policy.|Writing, installing, binding, deploying or changing external state.|
|`LOCAL_ARTIFACT_WRITE`|Write local non-repo artifacts in an authorized workspace.|Local artifact scope and overwrite rules.|Repo mutation or external side effects.|
|`REPO_WRITE`|Modify version-controlled repository content.|Exact repo/branch/path/change surface and admission.|Implicit network/install/deploy authority.|
|`NETWORK`|Initiate outbound/inbound network interaction beyond already-authorized read context.|Endpoint/purpose/data class/policy; admission where effectful.|Secret use, provider binding or deployment unless separately allowed.|
|`INSTALL`|Install packages/tools/extensions or alter executable environment.|Package/source/version/integrity/license/rollback and admission.|Persistent provider binding or production change.|
|`SECRET_READ`|Read credential/secret material.|Least privilege, explicit subject/scope, approved handling, no exfiltration.|Secret write/rotation/use outside scope.|
|`PROVIDER_BIND`|Bind configuration/credentials/resources to a provider/service.|Exact provider/account/resource/config/rollback and admission.|Deployment or migration unless separately admitted.|
|`DEPLOY`|Create/update deployed service/resource.|Exact target/environment/artifact/rollback/observation and admission.|Migration or production verification by implication.|
|`MIGRATE`|Move data/state/traffic/provider/architecture across boundaries.|Migration plan, parity, rollback window, data/security boundary and admission.|Decommission old path before closure.|
|`ROLLBACK`|Revert an admitted change to a known target.|Known rollback target, authority, evidence/readback.|Unscoped destructive reset.|
|`PRODUCTION_CHANGE`|Any mutation of production/user-visible/world-coupled state.|Highest applicable approval/admission, observability, rollback, effect reconciliation.|Self-approval, inferred permission or claim inflation.|

Three invariants are non-negotiable:

- `permission category definition != authorization issuance`;
- `ECP != ExecutionAdmission`;
- `document/plan/adapter/tool output != permission`.

```json
{
  "contract_ref": "PIPD-LIFECYCLE-SPEC@1.1.0#PermissionClassPolicy",
  "default_decision": "DENY_EFFECTFUL_UNLESS_ADMITTED",
  "classes": [
    "READ_ONLY",
    "LOCAL_ARTIFACT_WRITE",
    "REPO_WRITE",
    "NETWORK",
    "INSTALL",
    "SECRET_READ",
    "PROVIDER_BIND",
    "DEPLOY",
    "MIGRATE",
    "ROLLBACK",
    "PRODUCTION_CHANGE"
  ],
  "adapter_can_grant_permissions": false,
  "document_can_grant_permissions": false,
  "ecp_equals_execution_admission": false
}
```

# 14｜Security / Trust Boundary / Canonical ThreatModelRow Closure
## 14.1 Canonical Schema Contract
Schema identity MUST remain `urn:pipd:canonical-standard:1.1:schema:threat-model`; DOC-01 does not mint a competing schema. Required fields are exactly the canonical row fields; `evidence_expectation_ref` remains optional in A2 schema but is REQUIRED by this DOC-01 profile for STANDARD/ASSURED material threats.
## 14.2 Schema-Valid Row Surface
|threat_id|threat|asset|trust_boundary|abuse_case|prevention|detection|response|test_oracle_ref|owner|residual_risk|evidence_expectation_ref|human gate|
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|`THR-AG-01`|Agent goal hijack|mission/goal state|untrusted content→planner|retrieved/tool content injects new goals|authorized instruction surfaces; goal provenance binding|goal-diff telemetry; policy violation oracle|halt affected plan; rebind source/goal|`OR-D28A8B60`|DOC-01 security owner|MEDIUM after controls|`EVID-THR-AG-01`|human gate for high-impact goal change|
|`THR-AG-02`|Tool misuse|tool/action capability|agent→tool boundary|valid tool used beyond intended scope|least privilege; permission class gate; bounded WorkOrder|tool-call scope oracle; side-effect telemetry|DENY/HOLD; rollback/compensate|`OR-D28A8B60`|DOC-05 admission owner / DOC-01 policy|MEDIUM|`EVID-THR-AG-02`|human approval for high-risk effect|
|`THR-AG-03`|Identity/privilege abuse|identity/entitlement|agent/user/provider identity boundary|impersonation or privilege escalation|identity binding; scoped tokens; SoD|identity mismatch oracle; token replay detection|DENY; revoke token; incident route|`OR-D28A8B60`|security owner|MEDIUM|`EVID-THR-AG-03`|human approval when privilege escalates|
|`THR-AG-04`|Memory/context poisoning|persistent context|external data→memory|untrusted content stored as trusted instruction|ContextTrustRecord; source/scope/expiry/trust label|trust-label lint; source/hash drift check|quarantine/invalidate memory; rebuild context|`OR-D28A8B60`|DOC-01 constitution owner|LOW-MEDIUM|`EVID-THR-AG-04`|not normally|
|`THR-AG-05`|Inter-agent trust abuse|handoff payload/authority|agent A→agent B|sender claims authority/permission not held|typed handoff; receiver NACK; authority refs|handoff schema/oracle; permission comparison|reject handoff; TEMP_CLOSED|`OR-D28A8B60`|handoff owner|MEDIUM|`EVID-THR-AG-05`|when handoff triggers high-risk action|
|`THR-AG-06`|Cascading failure|multi-agent/workflow graph|component→dependent chain|local error propagates into multiple actions|bounded slices; affected-only invalidation; circuit stop|dependency health/oracle; anomaly telemetry|HOLD affected frontier; rollback scoped|`OR-D28A8B60`|workflow owner|MEDIUM|`EVID-THR-AG-06`|for material cascade recovery|
|`THR-AG-07`|Rogue/unauthorized action|world effect surface|agent→external world|action occurs without ADMIT or outside scope|execution admission; permission deny-by-default; scope binding|effect readback; admission/effect correlation|stop/revoke; rollback/reconcile|`OR-D28A8B60`|DOC-05 execution owner|HIGH|`EVID-THR-AG-07`|required|
|`THR-AG-08`|Sensitive-context leakage|secrets/PII/context|memory/tool/provider boundary|sensitive data emitted to unauthorized consumer|secret handles; redaction; egress policy|DLP/egress checks; evidence redaction oracle|revoke/quarantine; incident response|`OR-D28A8B60`|security/privacy owner|HIGH|`EVID-THR-AG-08`|required for material leakage|
|`THR-AG-09`|Supply-chain substitution|tool/plugin/schema dependency|external package→local binding|malicious/stale substitute is treated as selected dependency|hash/version/currentness; SBB/admission; provider-exit|hash/license/advisory checks|HOLD technology; re-adjudicate|`OR-D28A8B60`|DOC-02 technology owner|MEDIUM|`EVID-THR-AG-09`|if high-risk package|
|`THR-AG-10`|Unsafe world effect / false success|external world state|provider report→effect truth|tool reports success but world differs|WorldEffectState separation; readback/reconciliation|effect observation oracle|UNKNOWN_EFFECT/HOLD; compensate/rollback|`OR-D28A8B60`|effect/reconciliation owner|HIGH|`EVID-THR-AG-10`|for irreversible effect|

## 14.3 Machine-Extractable ThreatModelRow Instances
The following array is an authoring carrier; **each element individually** MUST validate `urn:pipd:canonical-standard:1.1:schema:threat-model`.
```json
[
  {
    "threat_id": "THR-AG-01",
    "threat": "Agent goal hijack",
    "asset": "mission/goal state",
    "trust_boundary": "untrusted content→planner",
    "abuse_case": "retrieved/tool content injects new goals",
    "prevention": [
      "authorized instruction surfaces",
      "goal provenance binding"
    ],
    "detection": [
      "goal-diff telemetry",
      "policy violation oracle"
    ],
    "response": [
      "halt affected plan",
      "rebind source/goal"
    ],
    "test_oracle_ref": "OR-D28A8B60",
    "owner": "DOC-01 security owner",
    "residual_risk": "MEDIUM after controls",
    "evidence_expectation_ref": "EVID-THR-AG-01"
  },
  {
    "threat_id": "THR-AG-02",
    "threat": "Tool misuse",
    "asset": "tool/action capability",
    "trust_boundary": "agent→tool boundary",
    "abuse_case": "valid tool used beyond intended scope",
    "prevention": [
      "least privilege",
      "permission class gate",
      "bounded WorkOrder"
    ],
    "detection": [
      "tool-call scope oracle",
      "side-effect telemetry"
    ],
    "response": [
      "DENY/HOLD",
      "rollback/compensate"
    ],
    "test_oracle_ref": "OR-D28A8B60",
    "owner": "DOC-05 admission owner / DOC-01 policy",
    "residual_risk": "MEDIUM",
    "evidence_expectation_ref": "EVID-THR-AG-02"
  },
  {
    "threat_id": "THR-AG-03",
    "threat": "Identity/privilege abuse",
    "asset": "identity/entitlement",
    "trust_boundary": "agent/user/provider identity boundary",
    "abuse_case": "impersonation or privilege escalation",
    "prevention": [
      "identity binding",
      "scoped tokens",
      "SoD"
    ],
    "detection": [
      "identity mismatch oracle",
      "token replay detection"
    ],
    "response": [
      "DENY",
      "revoke token",
      "incident route"
    ],
    "test_oracle_ref": "OR-D28A8B60",
    "owner": "security owner",
    "residual_risk": "MEDIUM",
    "evidence_expectation_ref": "EVID-THR-AG-03"
  },
  {
    "threat_id": "THR-AG-04",
    "threat": "Memory/context poisoning",
    "asset": "persistent context",
    "trust_boundary": "external data→memory",
    "abuse_case": "untrusted content stored as trusted instruction",
    "prevention": [
      "ContextTrustRecord",
      "source/scope/expiry/trust label"
    ],
    "detection": [
      "trust-label lint",
      "source/hash drift check"
    ],
    "response": [
      "quarantine/invalidate memory",
      "rebuild context"
    ],
    "test_oracle_ref": "OR-D28A8B60",
    "owner": "DOC-01 constitution owner",
    "residual_risk": "LOW-MEDIUM",
    "evidence_expectation_ref": "EVID-THR-AG-04"
  },
  {
    "threat_id": "THR-AG-05",
    "threat": "Inter-agent trust abuse",
    "asset": "handoff payload/authority",
    "trust_boundary": "agent A→agent B",
    "abuse_case": "sender claims authority/permission not held",
    "prevention": [
      "typed handoff",
      "receiver NACK",
      "authority refs"
    ],
    "detection": [
      "handoff schema/oracle",
      "permission comparison"
    ],
    "response": [
      "reject handoff",
      "TEMP_CLOSED"
    ],
    "test_oracle_ref": "OR-D28A8B60",
    "owner": "handoff owner",
    "residual_risk": "MEDIUM",
    "evidence_expectation_ref": "EVID-THR-AG-05"
  },
  {
    "threat_id": "THR-AG-06",
    "threat": "Cascading failure",
    "asset": "multi-agent/workflow graph",
    "trust_boundary": "component→dependent chain",
    "abuse_case": "local error propagates into multiple actions",
    "prevention": [
      "bounded slices",
      "affected-only invalidation",
      "circuit stop"
    ],
    "detection": [
      "dependency health/oracle",
      "anomaly telemetry"
    ],
    "response": [
      "HOLD affected frontier",
      "rollback scoped"
    ],
    "test_oracle_ref": "OR-D28A8B60",
    "owner": "workflow owner",
    "residual_risk": "MEDIUM",
    "evidence_expectation_ref": "EVID-THR-AG-06"
  },
  {
    "threat_id": "THR-AG-07",
    "threat": "Rogue/unauthorized action",
    "asset": "world effect surface",
    "trust_boundary": "agent→external world",
    "abuse_case": "action occurs without ADMIT or outside scope",
    "prevention": [
      "execution admission",
      "permission deny-by-default",
      "scope binding"
    ],
    "detection": [
      "effect readback",
      "admission/effect correlation"
    ],
    "response": [
      "stop/revoke",
      "rollback/reconcile"
    ],
    "test_oracle_ref": "OR-D28A8B60",
    "owner": "DOC-05 execution owner",
    "residual_risk": "HIGH",
    "evidence_expectation_ref": "EVID-THR-AG-07"
  },
  {
    "threat_id": "THR-AG-08",
    "threat": "Sensitive-context leakage",
    "asset": "secrets/PII/context",
    "trust_boundary": "memory/tool/provider boundary",
    "abuse_case": "sensitive data emitted to unauthorized consumer",
    "prevention": [
      "secret handles",
      "redaction",
      "egress policy"
    ],
    "detection": [
      "DLP/egress checks",
      "evidence redaction oracle"
    ],
    "response": [
      "revoke/quarantine",
      "incident response"
    ],
    "test_oracle_ref": "OR-D28A8B60",
    "owner": "security/privacy owner",
    "residual_risk": "HIGH",
    "evidence_expectation_ref": "EVID-THR-AG-08"
  },
  {
    "threat_id": "THR-AG-09",
    "threat": "Supply-chain substitution",
    "asset": "tool/plugin/schema dependency",
    "trust_boundary": "external package→local binding",
    "abuse_case": "malicious/stale substitute is treated as selected dependency",
    "prevention": [
      "hash/version/currentness",
      "SBB/admission",
      "provider-exit"
    ],
    "detection": [
      "hash/license/advisory checks"
    ],
    "response": [
      "HOLD technology",
      "re-adjudicate"
    ],
    "test_oracle_ref": "OR-D28A8B60",
    "owner": "DOC-02 technology owner",
    "residual_risk": "MEDIUM",
    "evidence_expectation_ref": "EVID-THR-AG-09"
  },
  {
    "threat_id": "THR-AG-10",
    "threat": "Unsafe world effect / false success",
    "asset": "external world state",
    "trust_boundary": "provider report→effect truth",
    "abuse_case": "tool reports success but world differs",
    "prevention": [
      "WorldEffectState separation",
      "readback/reconciliation"
    ],
    "detection": [
      "effect observation oracle"
    ],
    "response": [
      "UNKNOWN_EFFECT/HOLD",
      "compensate/rollback"
    ],
    "test_oracle_ref": "OR-D28A8B60",
    "owner": "effect/reconciliation owner",
    "residual_risk": "HIGH",
    "evidence_expectation_ref": "EVID-THR-AG-10"
  }
]
```

## 14.4 Applicability
- `LITE`: threat rows MAY be reduced only with recorded low-risk rationale.  
- `STANDARD`: material threat model SHOULD be maintained; this DOC-01 profile requires it for agentic/tooling surfaces.  
- `ASSURED` / high-risk Skill/Plugin / Agent Harness: threat rows are mandatory.
## 14.5 Acceptance / Failure
Each row MUST validate canonical schema and have independent threat identity where semantics differ. A generic “prompt injection” row cannot close goal hijack, tool misuse, identity abuse, memory poisoning, inter-agent abuse, cascade, rogue action, and sensitive leakage simultaneously. Missing owner/residual risk/oracle ⇒ row invalid; material high-risk gap ⇒ HOLD/TEMP_CLOSED.

# 15｜Profile Binding Constitution

## 15.1 Weight Profiles

- `LITE`: lower-risk bounded work; may reduce process weight but **MUST NOT** weaken core identity, source/evidence binding, claim ceilings, or permission boundaries.
- `STANDARD`: default substantial engineering profile; security/threat modeling is expected for applicable risk.
- `ASSURED`: high-assurance/high-risk; stronger SoD, threat model, evidence and acceptance authority are mandatory.

## 15.2 Target Profiles

- `SYSTEM`: software/system implementation target.
- `SKILL_PLUGIN`: packaged skill/plugin capability with host/permission/supply-chain boundaries.
- `AGENT_HARNESS`: agentic runtime/harness with tool/handoff/guardrail/state/trace obligations.
- `CUSTOM`: extension via typed `DomainProfileExtension`, never core override.

## 15.3 Binding Invariants

1. `weight_profile`, `target_profile`, `profile_version` and `extensions[]` **MUST** exist on canonical/project artifacts where applicable.
2. Materialized profile references **MUST** be subject/version/hash bound.
3. Profile change **MUST** trigger affected-only impact analysis.
4. `core_override=false` is mandatory for domain extensions.
5. DOC-06 owns detailed tailoring contracts; DOC-01 owns only these invariants.

```json
{
  "contract_ref": "PIPD-LIFECYCLE-SPEC@1.1.0#ProfileBinding",
  "weight_profile": "STANDARD",
  "target_profile": "SYSTEM",
  "profile_version": "1.1.0",
  "profile_hash": null,
  "extensions": [],
  "core_override": false,
  "binding_status": "DESIGN_EXAMPLE_UNMATERIALIZED"
}
```

# 16｜Namespace / Schema Compatibility

The canonical standard is `PIPD-LIFECYCLE-SPEC@1.1.0` with canonical namespace `urn:pipd:canonical-standard:1.1`. Canonical schemas are evaluated against JSON Schema Draft 2020-12 unless a future approved standard revision explicitly migrates them.

|Change level|Allowed semantic effect|Migration requirement|Compatibility claim|
|---|---|---|---|
|Patch|Clarification/bug fix; MUST NOT weaken validation|Document exact change and supersession|Backward compatible unless explicitly narrower with justified validation fix|
|Minor|May add optional fields or intentionally tighten invalid states|Migration note + affected consumer review|Compatibility declared per changed field|
|Major|May change canonical identity/topology/state semantics|Explicit migration plan, supersession and revalidation|No implicit backward/forward compatibility|

Project extensions MAY use organization-owned HTTPS URIs or valid URNs. Final canonical identities **MUST NOT** use placeholder domains. A superseding schema **MUST** state `supersedes`, migration path and backward/forward compatibility. Unknown extension keywords/unsupported schema dialects **MUST** fail closed rather than be silently ignored when they affect validity.

# 17｜Documentation Grounding

A normative authoring record contains:

`source_id`, `source_version`, `source_hash`, `exact_locator`, `grounded_claim`, `retrieval_method`, `state`, `stale_invalidation_trigger`.

For this DOC-01, A0–A5 source bytes and hashes are frozen in §1. When a source revision changes, any claim that consumes changed clauses becomes stale until re-grounded. Search hits alone are not coverage proof; only substantive clauses close a requirement.

**No-Source-No-Norm rule:** missing authoritative source/anchor → `ABSTAIN` for that claim + `TEMP_CLOSED`; no fallback to unbounded historical volumes, model memory, or Web support.

Canonical schema reference: `urn:pipd:canonical-standard:1.1:schema:documentation-grounding`.

# 18｜Change / Supersession / Affected-Only Invalidation — 18/18 Event Retention
## 18.1 Six Canonical Change Classes
`EDITORIAL`, `NON_BREAKING_CONTRACT`, `BREAKING_CONTRACT`, `SECURITY_CURRENTNESS`, `RUNTIME_BINDING_DRIFT`, `EMERGENCY_CHANGE`. `change_class` selects recompile/rebind/retest algorithm；actual invalidation仍由 dependency graph決定。
## 18.2 Affected-Only Algorithm
```text
changed_nodes = exact changed canonical/source/currentness nodes
frontier = reverse_dependencies(changed_nodes)
for each dependent D:
  if changed field intersects D.consumed_contract:
    invalidate D with prior hash + reason + invalidated_by
preserve unrelated nodes
recompute affected gates only
```
**MUST NOT global-reset; MUST NOT stale-reuse.**
## 18.3 Retained 18/18 Event Matrix
|EVT|Event|Surface|change_class|Required action|First invalidation scope|Gate|
|---|---|---|---|---|---|---|
|EVT-001|source / Product Truth 變更|PI|BREAKING_CONTRACT|reopen affected requirements; recompute trace/hash|reverse dependents|PI_READY|
|EVT-002|requirement / acceptance / oracle 變更|PI→PD|BREAKING_CONTRACT|invalidate dependent PD / WorkOrder / TQAEP|affected slice only|PREDEV_READY|
|EVT-003|architecture/interface semantic 變更|PI|BREAKING_CONTRACT|CR to PI owner; PD must not self-patch|affected consumers|PI_READY|
|EVT-004|repo HEAD / branch 變更|PD|RUNTIME_BINDING_DRIFT|recapture RepoContext; semantic diff|relevant PD slice|PREDEV_READY|
|EVT-005|dependency/provider/protocol version stale|PD|SECURITY_CURRENTNESS|currentness check / re-pin / compatibility|relevant ECP / TQAEP|PREDEV_READY|
|EVT-006|repo-local AGENTS/instruction 變更|PD|RUNTIME_BINDING_DRIFT|rediscover nearest instructions read-only|path-scoped WorkOrders|PREDEV_READY|
|EVT-007|tool security advisory / license drift|PI+PD|SECURITY_CURRENTNESS|technology record re-adjudication; HOLD if material|candidate consumers|PI/PD|
|EVT-008|approval token expired/replayed|Admission|RUNTIME_BINDING_DRIFT|DENY; new token only from authority|exact operation/scope|EXECUTION_ADMITTED|
|EVT-009|WorkOrder/ECP subject hash mismatch|Admission|RUNTIME_BINDING_DRIFT|DENY/TEMP_CLOSED|exact execution slice|EXECUTION_ADMITTED|
|EVT-010|first mutation begins|DEV|NON_BREAKING_CONTRACT|emit checkpoint + execution evidence|exact WorkOrder|IMPLEMENTING|
|EVT-011|tool/provider reports success|Effect|NON_BREAKING_CONTRACT|do not promote; trigger observation/readback|exact effect intent|Effect Gate|
|EVT-012|readback confirms desired state|Effect|NON_BREAKING_CONTRACT|reconcile → CONFIRMED_EFFECT|exact effect|Evidence|
|EVT-013|readback partial/conflicting|Effect|EMERGENCY_CHANGE|reobserve/reconcile/compensate/rollback|exact effect|HOLD|
|EVT-014|tests run|TQAEP|NON_BREAKING_CONTRACT|bind fixture/env/oracle/actual/checker|subject version/hash|VERIFIED|
|EVT-015|release artifact built|Release|NON_BREAKING_CONTRACT|digest + SBOM + provenance/attestation|artifact|RELEASED|
|EVT-016|CR changes only local implementation detail|DEV|NON_BREAKING_CONTRACT|keep PI if semantic contract unchanged|local WorkOrder|implementation|
|EVT-017|external web evidence changes|SUPPORT|SECURITY_CURRENTNESS|update currentness record; no auto normative promotion|candidate decision|technology gate|
|EVT-018|adapter changes|AGENTS/SKILL|RUNTIME_BINDING_DRIFT|regenerate/prove non-override|adapter only|adapter conformance|

## 18.4 Supersession / Emergency / Recovery
Superseded revision remains provenance but cannot silently current. Emergency change uses explicit authority path and MUST return post-change evidence/readback/reconciliation. Every event record names first invalidated object, dependency frontier, gate, recovery/re-entry route.

# 19｜Package Derivation / Split / Merge — Replayable Machine Decision

## 19.1 Split Predicate
SHOULD split if any: different canonical owner; independent rollback; materially different security/rights boundary; independent cadence; different lifecycle consumer; independent deploy/release surface; demonstrated context overload harms correctness.

## 19.2 Merge Predicate
SHOULD merge only when all: same owner; same rollback boundary; same consumers; same security boundary; high trace coupling; merge does not exceed context correctness threshold.

## 19.3 Exact `project/package-index.json` Decision Contract
A1-required fields are retained: **owner, rollback boundary, security boundary, consumers, cadence, context_load, decision, rationale**; r2 additionally records graph refs and invalidation trigger for replayability.

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "urn:pipd:doc01:1.1:schema:package-index-decision",
  "type": "object",
  "additionalProperties": false,
  "required": [
    "decision_id",
    "owner",
    "rollback_boundary",
    "security_boundary",
    "consumers",
    "cadence",
    "context_load",
    "decision",
    "rationale",
    "graph_refs",
    "invalidation_trigger"
  ],
  "properties": {
    "decision_id": {
      "type": "string"
    },
    "owner": {
      "type": "string"
    },
    "rollback_boundary": {
      "type": "string"
    },
    "security_boundary": {
      "type": "string"
    },
    "consumers": {
      "type": "array",
      "items": {
        "type": "string"
      }
    },
    "cadence": {
      "type": "string"
    },
    "context_load": {
      "type": "string"
    },
    "decision": {
      "enum": [
        "SPLIT",
        "MERGE",
        "KEEP"
      ]
    },
    "rationale": {
      "type": "string",
      "minLength": 1
    },
    "graph_refs": {
      "type": "array",
      "items": {
        "type": "string"
      }
    },
    "invalidation_trigger": {
      "type": "string"
    }
  }
}
```
**Acceptance:** split/merge semantic predicate + exact machine record both pass. A minimal JSON with only `decision/material_difference` is no longer closure evidence.

# 20｜Vertical Slice Governance

A project is not required to finish every PI/PD package before the first eligible slice executes. Eligibility is slice-scoped.

`SliceEligible = required_PI_dependency_closure_complete ∧ applicable_PI_READY ∧ required_PD_binding_PREDEV_READY ∧ slice_specific_TQAEP_construction_ready ∧ exact_ExecutionAdmission=ADMIT`

Additional constitutional checks apply when slices share a canonical writer, non-partitionable permission/resource, invalidation edge, rollback boundary or unresolved cross-slice contract. In those cases concurrency may be blocked for the coupled scope only.

|Condition|Required?|Owner of fact|Failure route|
|---|---|---|---|
|Required PI dependency closure|Yes|DOC-02 + dependency graph|Keep slice in PI/PD; unaffected slices continue|
|Applicable `PI_READY`|Yes|DOC-02 facts; DOC-01 state semantics|No PD execution path|
|Required PD binding / `PREDEV_READY`|Yes|DOC-03|No admission request|
|Slice TQAEP construction-ready|Yes|DOC-03/04/07|No admission request|
|Exact `ExecutionAdmission=ADMIT`|Yes for first mutation|DOC-05|DENY/HOLD; no mutation|
|All unrelated project packages complete|No|N/A|Must not be invented as global waterfall gate|

```json
{
  "contract_ref": "PIPD-LIFECYCLE-SPEC@1.1.0#VerticalSlice",
  "slice_id": "slice-A",
  "required_pi_dependency_closure_complete": true,
  "pi_ready": true,
  "required_pd_binding_predev_ready": true,
  "slice_tqaep_construction_ready": true,
  "execution_admission": "ADMIT",
  "eligible": true,
  "global_project_completion_required": false
}
```

# 21｜Machine-Readable Constitution / Prose-Machine Equivalence
## 21.1 Canonical Validator Route
Canonical validator route is **named, not silently omitted**: `pipd_validate.py <instance> --kind <pi|pd|evidence|admission|effect> --schema-dir ...`. A1 reference validator uses Python `jsonschema.Draft202012Validator`. Runtime install/pin remains DOC-03/PD/DOC-09 late-bound; DOC-01 requires interface, schema dialect, semantic rule IDs and non-downgrade route-out.
## 21.2 P-15 Three Atomic Requirements
|Atomic|Contract|Machine closure|
|---|---|---|
|`STD-REQ-C5BCA382-C01`|prose promotion predicate has machine equivalent|`requirement-trace.schema.json` + `TEST-C5BCA382/OR-C5BCA382/MUT-A382-01` + DOC01 semantic rules|
|`STD-REQ-C5BCA382-C02`|JSON Schema and/or deterministic validator used|`requirement-trace.schema.json` + `TEST-C5BCA382/OR-C5BCA382/MUT-A382-02` + DOC01 semantic rules|
|`STD-REQ-C5BCA382-C03`|prose-only gate cannot independently promote state|`requirement-trace.schema.json` + `TEST-C5BCA382/OR-C5BCA382/MUT-A382-03` + DOC01 semantic rules|

## 21.3 Machine Objects Embedded in This MD
1. `CommonArtifactMetadataSuperset` (§3).  
2. `PromotionEvaluation` (§6).  
3. `ComplexityBudgetDecision` (§7.15).  
4. `CapabilityBeforeBrandDecision` (§7.16).  
5. `ContextTrustRecord` (§7.17).  
6. canonical ThreatModelRow instances (§14).  
7. package-index decision schema (§19).  
8. canonical 140-row RequirementTrace binding (§25).
## 21.4 Semantic Validator Contract
```text
input: instance + kind + schema_dir + semantic_rule_set
1 validate Draft202012 schema/$id uniqueness
2 normalize identity/authority metadata
3 evaluate DOC01 semantic rules in stable order
4 stop at first failing invariant
5 emit subject/version/hash-bound conformance record
6 never upgrade a claim from parse success alone
```
Required semantic rules include: `DOC01-META-*`, `DOC01-STATE-*`, `DOC01-PROMO-*`, `DOC01-CONST-READY-*`, `DOC01-CLAIM-*`, `DOC01-PKG-*`, `DOC01-THREAT-*`, `DOC01-SBB-*`, `DOC01-COMPLEXITY-*`.
## 21.5 Hollow-Pass Rejection
Schema/validator MUST reject hollow `PI_READY`, hollow `PREDEV_READY`, projection-as-state, claim inflation, missing rollback, stale/wrong-subject evidence and selected-technology silent omission. JSON syntax parse success is **not** conformance.

# 22｜DOC01 Technology / Workflow Denominator — Item-Specific Anti-Degradation
DOC-01 does **not** absorb the 22 project TechnologyAdmission candidates; DOC-02 remains terminal disposition owner. This section covers only items materially required by DOC-01 Constitution/machine interface plus named route-outs that must not disappear.
## 22.1 Currentness Status
- JSON Schema official site: current published version 2020-12 (observed 2026-10-07).  
- BCP 14 collection: RFC 2119 + RFC 8174 (observed 2026-10-07).  
- FIPS 180-4: current published update remains available; NIST has **decided to revise**; current SHA-256 selection impact = none, status=MONITOR.  
- RFC 9557 extends RFC3339; core JSON Schema `date-time` stays RFC3339-compatible unless explicit custom extension.  
- SemVer 2.0.0, RFC8141 remain current references.  
- OWASP Agentic Top 10 2026 is SUPPORT only.
## 22.2 Landing Contracts
### TLC-01 — JSON Schema Draft 2020-12
|Field|Value|
|---|---|
|canonical ID|TLC-01|
|external name|JSON Schema Draft 2020-12|
|internal short name|JSON Schema|
|exact version / version policy|2020-12 current published version|
|source|https://json-schema.org/specification|
|license / rights|Specification/publication terms; project must respect source terms|
|canonical capability|machine schema dialect and validation|
|PIPD owner|DOC-01|
|selected disposition|KEEP|
|why selected|canonical PIPD schema dialect|
|why alternatives rejected|older drafts rejected for new canonical schemas unless migration|
|translation / compression rule|KEEP semantics; do not vendor-authorize|
|local target artifact|canonical schema registry|
|configuration contract|Draft202012 dialect|
|installation / materialization owner|DOC-09/PD tooling owner|
|binding owner|DOC-07 validator binding owner|
|enablement condition|schema registry available + validator current|
|functional test|schema-valid instance|
|negative test|duplicate-$id / hollow gate|
|compatibility test|draft/migration compatibility|
|security test|schema injection/$id collision|
|rollback / uninstall|remove project extension only; core retained|
|residue check|no duplicate ids/residue|
|currentness trigger|new JSON Schema published version or validator incompatibility|
|evidence expectation|schema validation + semantic rule report|
|source_observed_at|2026-10-07T13:36:00+08:00|
|claim ceiling|DOCUMENT_FORMAT_ONLY|

### TLC-02 — BCP 14 / RFC2119 + RFC8174
|Field|Value|
|---|---|
|canonical ID|TLC-02|
|external name|BCP 14 / RFC2119 + RFC8174|
|internal short name|BCP14|
|exact version / version policy|current BCP collection|
|source|https://www.rfc-editor.org/info/bcp14/|
|license / rights|IETF Trust terms|
|canonical capability|normative keyword semantics|
|PIPD owner|DOC-01|
|selected disposition|KEEP|
|why selected|unambiguous MUST/MUST NOT semantics|
|why alternatives rejected|informal lowercase language not treated as BCP14 keyword|
|translation / compression rule|TRANSLATE Chinese equivalents without changing force|
|local target artifact|DOC-01 prose + lint|
|configuration contract|uppercase normative keywords|
|installation / materialization owner|author|
|binding owner|lint/review|
|enablement condition|document build|
|functional test|keyword mapping test|
|negative test|lowercase ambiguous normative phrase|
|compatibility test|language compatibility|
|security test|authority spoof through quoted text|
|rollback / uninstall|remove local translation mapping|
|residue check|no stale alternate meaning|
|currentness trigger|BCP14 collection change|
|evidence expectation|lint evidence|
|source_observed_at|2026-10-07T13:36:00+08:00|
|claim ceiling|NORMATIVE_LANGUAGE_ONLY|

### TLC-03 — SHA-256 / FIPS 180-4
|Field|Value|
|---|---|
|canonical ID|TLC-03|
|external name|SHA-256 / FIPS 180-4|
|internal short name|SHA256|
|exact version / version policy|current published FIPS 180-4; revision decided/monitor|
|source|https://csrc.nist.gov/pubs/fips/180-4/upd1/final|
|license / rights|US gov publication; implementation licenses separate|
|canonical capability|content identity/digest|
|PIPD owner|DOC-01|
|selected disposition|KEEP|
|why selected|widely interoperable content hash|
|why alternatives rejected|SHA-1 excluded; alternative hashes require compatibility decision|
|translation / compression rule|REFERENCE cryptographic identity only|
|local target artifact|artifact/evidence hashes|
|configuration contract|64-hex lowercase/normalized|
|installation / materialization owner|PD/tooling owner|
|binding owner|hash consumer|
|enablement condition|hash materialization available|
|functional test|known digest match|
|negative test|stale/changed bytes mismatch|
|compatibility test|cross-tool digest equality|
|security test|collision/substitution controls|
|rollback / uninstall|recompute/remove stale refs|
|residue check|no stale hash refs|
|currentness trigger|NIST revised FIPS publication|
|evidence expectation|detached readback hash|
|source_observed_at|2026-10-07T13:36:00+08:00|
|claim ceiling|CONTENT_IDENTITY_NOT_SIGNATURE|

### TLC-04 — RFC3339 core + RFC9557 optional IXDTF
|Field|Value|
|---|---|
|canonical ID|TLC-04|
|external name|RFC3339 core + RFC9557 optional IXDTF|
|internal short name|TIME|
|exact version / version policy|RFC3339 core; RFC9557 extension explicit|
|source|https://www.rfc-editor.org/info/rfc9557/|
|license / rights|IETF Trust terms|
|canonical capability|timestamps/currentness|
|PIPD owner|DOC-01|
|selected disposition|ADOPT_WITH_TRANSLATION|
|why selected|core JSON Schema date-time compatibility|
|why alternatives rejected|never assume IXDTF suffix accepted by JSON Schema date-time|
|translation / compression rule|core timestamp RFC3339; additional timezone in separate typed field unless custom format declared|
|local target artifact|metadata/currentness records|
|configuration contract|RFC3339 core + optional timezone field|
|installation / materialization owner|author|
|binding owner|validator binding owner|
|enablement condition|validator compatibility proven|
|functional test|RFC3339 parse|
|negative test|IXDTF in core field rejected unless extension profile|
|compatibility test|validator format test|
|security test|timezone inconsistency test|
|rollback / uninstall|remove optional extension field|
|residue check|no unparsed suffix residue|
|currentness trigger|RFC3339/9557 updates or validator change|
|evidence expectation|timestamp conformance record|
|source_observed_at|2026-10-07T13:36:00+08:00|
|claim ceiling|FORMAT_EXTENSION_EXPLICIT|

### TLC-05 — Semantic Versioning 2.0.0
|Field|Value|
|---|---|
|canonical ID|TLC-05|
|external name|Semantic Versioning 2.0.0|
|internal short name|SemVer|
|exact version / version policy|2.0.0 policy where semver applicable|
|source|https://semver.org/|
|license / rights|CC BY 3.0 on spec site noted by source|
|canonical capability|version compatibility vocabulary|
|PIPD owner|DOC-01|
|selected disposition|REFERENCE|
|why selected|predictable version semantics|
|why alternatives rejected|date/versioned IDs retained where semver not applicable|
|translation / compression rule|do not force semver on legacy/date IDs|
|local target artifact|schema/profile versions|
|configuration contract|SemVer for applicable components|
|installation / materialization owner|owner|
|binding owner|consumer|
|enablement condition|component declares semver applicability|
|functional test|valid semver|
|negative test|invalid/incompatible version|
|compatibility test|migration compatibility|
|security test|version confusion test|
|rollback / uninstall|rollback prior version|
|residue check|no mixed ambiguous version field|
|currentness trigger|SemVer spec update|
|evidence expectation|version parse/migration evidence|
|source_observed_at|2026-10-07T13:36:00+08:00|
|claim ceiling|NO_IMPLICIT_ADOPTION|

### TLC-06 — RFC8141 URN
|Field|Value|
|---|---|
|canonical ID|TLC-06|
|external name|RFC8141 URN|
|internal short name|URN|
|exact version / version policy|RFC8141|
|source|https://www.rfc-editor.org/info/rfc8141/|
|license / rights|IETF Trust terms|
|canonical capability|persistent namespace IDs|
|PIPD owner|DOC-01|
|selected disposition|KEEP|
|why selected|location-independent canonical schema IDs|
|why alternatives rejected|arbitrary example.org final IDs rejected|
|translation / compression rule|KEEP canonical urn namespace|
|local target artifact|schema `$id` / namespace|
|configuration contract|urn:pipd:*|
|installation / materialization owner|schema owner|
|binding owner|validator|
|enablement condition|namespace registered locally and collision-free|
|functional test|URN parse|
|negative test|duplicate/conflicting URN|
|compatibility test|URI/URN compatibility|
|security test|identity collision|
|rollback / uninstall|remove invalid extension namespace|
|residue check|no duplicate id residue|
|currentness trigger|RFC update / namespace migration|
|evidence expectation|extraction manifest|
|source_observed_at|2026-10-07T13:36:00+08:00|
|claim ceiling|IDENTITY_ONLY|

### TLC-07 — OWASP Top 10 for Agentic Applications 2026
|Field|Value|
|---|---|
|canonical ID|TLC-07|
|external name|OWASP Top 10 for Agentic Applications 2026|
|internal short name|OWASP-AGENTIC-2026|
|exact version / version policy|2026 guidance observed|
|source|https://genai.owasp.org/resource/owasp-top-10-for-agentic-applications-for-2026/|
|license / rights|OWASP project terms; SUPPORT only|
|canonical capability|threat-model support|
|PIPD owner|DOC-01|
|selected disposition|REFERENCE|
|why selected|current agentic threat taxonomy support|
|why alternatives rejected|cannot override PIPD threat schema/authority|
|translation / compression rule|translate risks into canonical ThreatModelRow|
|local target artifact|C-14 support mapping|
|configuration contract|support-only|
|installation / materialization owner|security owner|
|binding owner|threat-model owner|
|enablement condition|source current and mapped|
|functional test|mapping coverage|
|negative test|vendor/guidance text treated as authority|
|compatibility test|threat-model compatibility|
|security test|prompt injection/tool abuse fixtures|
|rollback / uninstall|remove support mapping without core loss|
|residue check|no external authority residue|
|currentness trigger|OWASP new edition/update|
|evidence expectation|currentness observation|
|source_observed_at|2026-10-07T13:36:00+08:00|
|claim ceiling|SUPPORT_ONLY|

### TLC-08 — pipd_validate.py canonical semantic validator
|Field|Value|
|---|---|
|canonical ID|TLC-08|
|external name|pipd_validate.py canonical semantic validator|
|internal short name|PIPD-VALIDATOR|
|exact version / version policy|A1 canonical reference route; runtime pin late-bound|
|source|A1 §13/§24.3 local canonical source|
|license / rights|project source rights|
|canonical capability|schema + semantic conformance orchestration|
|PIPD owner|DOC-07 implementation owner; DOC-01 interface owner|
|selected disposition|ROUTE_OUT|
|why selected|deterministic machine equivalence|
|why alternatives rejected|ad-hoc JSON parse or local validator fork without identity|
|translation / compression rule|REFERENCE stable command/interface; no duplicated lifecycle semantics|
|local target artifact|`.pipd/generated/validators/pipd_validate.py` or project canonical projection|
|configuration contract|kind/schema-dir/semantic-rules interface|
|installation / materialization owner|PD/DOC-09 materialization owner|
|binding owner|DOC-07 conformance owner|
|enablement condition|canonical validator materialized and hash-locked in project|
|functional test|positive canonical fixture|
|negative test|hollow PI_READY / wrong subject|
|compatibility test|validator-version compatibility|
|security test|tampered validator/hash drift|
|rollback / uninstall|replace from canonical source|
|residue check|old validator no longer active|
|currentness trigger|source hash/schema/version drift|
|evidence expectation|conformance report|
|source_observed_at|2026-10-07T13:36:00+08:00|
|claim ceiling|NO_RUNTIME_INSTALL_CLAIM|

### TLC-09 — Python jsonschema / Draft202012Validator
|Field|Value|
|---|---|
|canonical ID|TLC-09|
|external name|Python jsonschema / Draft202012Validator|
|internal short name|PY-JSONSCHEMA|
|exact version / version policy|exact package version late-bound in PD|
|source|A1 canonical validator dependency|
|license / rights|package license checked at project admission|
|canonical capability|reference implementation dependency capability|
|PIPD owner|DOC-03/09 runtime binding owner|
|selected disposition|ROUTE_OUT|
|why selected|A1 reference validator dependency|
|why alternatives rejected|DOC-01 must not invent exact target pin|
|translation / compression rule|name dependency + required Draft202012 capability|
|local target artifact|PD dependency lockfile/env|
|configuration contract|Draft202012Validator capability|
|installation / materialization owner|PD owner|
|binding owner|validator binding owner|
|enablement condition|version/license/security/currentness checked|
|functional test|Draft202012 validation fixture|
|negative test|unsupported draft/duplicate $id|
|compatibility test|Python/runtime compatibility|
|security test|dependency advisory/license drift|
|rollback / uninstall|provider exit/re-pin|
|residue check|no stale env residue|
|currentness trigger|package release/advisory|
|evidence expectation|lockfile + test evidence|
|source_observed_at|2026-10-07T13:36:00+08:00|
|claim ceiling|LATE_BOUND|

### TLC-10 — project/package-index.json decision workflow
|Field|Value|
|---|---|
|canonical ID|TLC-10|
|external name|project/package-index.json decision workflow|
|internal short name|PKG-INDEX|
|exact version / version policy|PIPD-LIFECYCLE-SPEC@1.1/A1 fields|
|source|A1 §10.2 local canonical source|
|license / rights|project-owned|
|canonical capability|replayable split/merge decisions|
|PIPD owner|DOC-01|
|selected disposition|KEEP|
|why selected|anti-overengineering derivation record|
|why alternatives rejected|free-form prose-only package rationale|
|translation / compression rule|KEEP exact A1 fields + r2 graph/invalidation refs|
|local target artifact|`.pipd/project/package-index.json`|
|configuration contract|§19 schema|
|installation / materialization owner|package architecture owner|
|binding owner|DOC-01 schema / project owner data|
|enablement condition|decision inputs available|
|functional test|schema + semantic split/merge test|
|negative test|missing owner/rollback/security/consumer/cadence/context|
|compatibility test|package graph compatibility|
|security test|package explosion/silent merge mutation|
|rollback / uninstall|revert decision with lineage|
|residue check|no orphan package edges|
|currentness trigger|package topology/complexity change|
|evidence expectation|decision record + tests|
|source_observed_at|2026-10-07T13:36:00+08:00|
|claim ceiling|DESIGN_ONLY|

## 22.3 Named Route-Out Anti-Degradation
`pipd_validate.py`, Python `jsonschema`, `requirement-trace.schema.json`, `threat-model.schema.json`, `documentation-grounding.schema.json`, and `project/package-index.json` MUST remain named. Correct ownership route-out MUST NOT be implemented as disappearance. Exact runtime pin/install claims remain false until PD/runtime evidence exists.

# 23｜External Capability Translation / Compression / Integration Rules

Imported capability treatment is explicit: `KEEP | TRANSLATE | WRAP | CONFIGURE | COMPOSE | ADAPT | EXTEND | REFERENCE | ROUTE_OUT | REJECT | QUARANTINE`.

For DOC-01 material external choices:
- JSON Schema dialect is **KEEP/REFERENCE** at exact canonical identity;
- BCP14, SemVer, URN, timestamp and SHA standards are **REFERENCE/CONFIGURE** only;
- OWASP agentic guidance is **TRANSLATE → SUPPORT_ONLY** into local threat rows;
- no vendor prompt, SKILL, agent harness, provider SDK or workflow becomes DOC-01 runtime dependency.

Every translation removes external authority, isolates provider assumptions, identifies an internal canonical destination, states validation/rollback/drift route, and preserves the PIPD owner.

## 23.1 External Capability Acceptance Matrix

|Test class|Required behavior|
|---|---|
|Positive|Valid selected standard/profile input is accepted and maps to the expected PIPD field/object.|
|Negative|Malformed/unsupported input is rejected without fallback to permissive interpretation.|
|Edge|Boundary values, empty arrays, version edge cases and timezone/hash/namespace limits behave deterministically.|
|Adversarial|External content cannot alter authority, gain permission, exfiltrate secrets or self-approve.|
|Mutation|Relevant byte/schema/version mutation invalidates the exact affected binding/evidence.|
|Apparent-pass|Tool/provider/schema parse success alone cannot promote lifecycle/claim.|
|Compatibility|Declared patch/minor/major compatibility is verified against consumers.|
|Disable/uninstall|Where executable tooling exists downstream, disabling it must not corrupt canonical semantic records.|
|Rollback|Prior valid standard/profile/pin can be restored only within declared compatibility/identity rules.|
|Residue|No stale adapter/provider/generated copy remains authoritative after removal.|
|Authority-override rejection|External/vendor text that conflicts with PIPD authority is ignored/quarantined.|
|Claim-inflation rejection|An external success signal cannot lift claim ceiling without PIPD evidence/authority.|

## 23.2 Ownership-Preserving Route-Out Rule
For every imported/named capability, DOC-01 records capability, owner, required interface, route-out, anti-degradation rule, and what DOC-01 MUST NOT duplicate. `ROUTE_OUT` is a terminal design disposition, not omission.

# 24｜Destructive / Negative / Edge / Adversarial / Apparent-Pass Fixture Matrix — Stable Identity
A3 stable mutation IDs are primary; local fixture aliases may be added but cannot replace them.
|Atomic|Mutation|Destructive fixture|Expected result|First failing invariant|
|---|---|---|---|---|
|`STD-REQ-F4669FFF-C01`|`MUT-9FFF-01`|missing requirement|FAIL / HOLD / TEMP_CLOSED / DENY as applicable; no promotion|canonical requirement missing/violated: missing requirement|
|`STD-REQ-F4669FFF-C02`|`MUT-9FFF-02`|orphan SPEC|FAIL / HOLD / TEMP_CLOSED / DENY as applicable; no promotion|canonical requirement missing/violated: orphan SPEC|
|`STD-REQ-F4669FFF-C03`|`MUT-9FFF-03`|missing acceptance|FAIL / HOLD / TEMP_CLOSED / DENY as applicable; no promotion|canonical requirement missing/violated: missing acceptance|
|`STD-REQ-F4669FFF-C05`|`MUT-9FFF-05`|stale hash|FAIL / HOLD / TEMP_CLOSED / DENY as applicable; no promotion|canonical requirement missing/violated: stale hash|
|`STD-REQ-F4669FFF-C06`|`MUT-9FFF-06`|wrong subject|FAIL / HOLD / TEMP_CLOSED / DENY as applicable; no promotion|canonical requirement missing/violated: wrong subject|
|`STD-REQ-F4669FFF-C08`|`MUT-9FFF-08`|provider/tool semantic takeover|FAIL / HOLD / TEMP_CLOSED / DENY as applicable; no promotion|canonical requirement missing/violated: provider/tool semantic takeover|
|`STD-REQ-F4669FFF-C11`|`MUT-9FFF-11`|missing rollback|FAIL / HOLD / TEMP_CLOSED / DENY as applicable; no promotion|canonical requirement missing/violated: missing rollback|
|`STD-REQ-F4669FFF-C12`|`MUT-9FFF-12`|false PI_READY|FAIL / HOLD / TEMP_CLOSED / DENY as applicable; no promotion|canonical requirement missing/violated: false PI_READY|
|`STD-REQ-F4669FFF-C13`|`MUT-9FFF-13`|false PREDEV_READY|FAIL / HOLD / TEMP_CLOSED / DENY as applicable; no promotion|canonical requirement missing/violated: false PREDEV_READY|
|`STD-REQ-F4669FFF-C14`|`MUT-9FFF-14`|execution before ADMIT|FAIL / HOLD / TEMP_CLOSED / DENY as applicable; no promotion|canonical requirement missing/violated: execution before ADMIT|
|`STD-REQ-F4669FFF-C15`|`MUT-9FFF-15`|maker self-approval|FAIL / HOLD / TEMP_CLOSED / DENY as applicable; no promotion|canonical requirement missing/violated: maker self-approval|
|`STD-REQ-F4669FFF-C16`|`MUT-9FFF-16`|world-effect false positive|FAIL / HOLD / TEMP_CLOSED / DENY as applicable; no promotion|canonical requirement missing/violated: world-effect false positive|
|`STD-REQ-F4669FFF-C17`|`MUT-9FFF-17`|selected technology silently omitted|FAIL / HOLD / TEMP_CLOSED / DENY as applicable; no promotion|canonical requirement missing/violated: selected technology silently omitted|

Additional apparent-pass fixtures: projection token used as lifecycle state; same-model review mislabeled independent; IXDTF suffix silently accepted as core `date-time`; threat row missing residual risk; package decision missing rollback boundary; SBB `BUILD_MINIMAL` without no-fit proof.

# 25｜DOC01_CANONICAL_ATOMIC_COVERAGE — A3 Stable 140/140 Denominator
**Primary denominator = A3 stable atomic IDs.** r1 local `REQ-*` ledger is demoted to non-authoritative authoring alias and is not used to prove closure. Every row below preserves atomic identity, parent, source line/anchor, exact obligation, owner, canonical object/schema, TEST/ORACLE/mutation and r2 section.
|atomic_id|parent_id|A3 line/anchor|family|exact obligation|owner|canonical object|schema/ref|TEST|ORACLE|mutation|r2 section|status|repair note|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|`STD-REQ-979740C9-C01`|`STD-REQ-979740C9`|`A3:L2047 / 7073`|1. Normative Language / 規範語言|- MUST / SHALL / 必須：不符合即不 conform。|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-979740C9`|`OR-979740C9`|`MUT-40C9-01`|Intro/§1|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-98F459F8-C01`|`STD-REQ-98F459F8`|`A3:L2048 / 7074`|1. Normative Language / 規範語言|- MUST NOT / SHALL NOT / 不得：禁止事項。|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-98F459F8`|`OR-98F459F8`|`MUT-59F8-01`|Intro/§1|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-E2082905-C01`|`STD-REQ-E2082905`|`A3:L2049 / 7075`|1. Normative Language / 規範語言|若專案使用其他語言或本地術語，語意 MUST 不變。|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-E2082905`|`OR-E2082905`|`MUT-2905-01`|Intro/§1|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-B88A6D37-C01`|`STD-REQ-B88A6D37`|`A3:L2051 / 7077`|P-02 Source-Bound Intent Preservation|所有 normative requirement MUST 能追溯到 source / authority / accepted decision。外部研究、README、論壇、工具輸出預設只屬 SUPPORT/DATA，不得自行取得產品或語意 authority。|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-B88A6D37`|`OR-B88A6D37`|`MUT-6D37-01`|§1/§17|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-689DE502-C01`|`STD-REQ-689DE502`|`A3:L2052 / 7078`|P-03 Stable Semantics vs Late-Bound Facts|穩定設計決策 MUST 在 PI 層完成；repo/runtime/provider/version/environment currentness SHOULD 在 PD 層 late-bind。不得因為 runtime facts 尚未存在，就延後所有設計；也不得在 PI 層捏造真實 runtime facts。|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-689DE502`|`OR-689DE502`|`MUT-E502-01`|§7.18|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-C6A9781D-C01`|`STD-REQ-C6A9781D`|`A3:L2054 / 7080`|P-06 Claim Separation|DESIGN_MATERIALIZED != IMPLEMENTED|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-C6A9781D`|`OR-C6A9781D`|`MUT-781D-01`|§9/C-05|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-C6A9781D-C02`|`STD-REQ-C6A9781D`|`A3:L2055 / 7080`|P-06 Claim Separation|SELECTED != INSTALLED|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-C6A9781D`|`OR-C6A9781D`|`MUT-781D-02`|§9/C-05|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-C6A9781D-C03`|`STD-REQ-C6A9781D`|`A3:L2056 / 7080`|P-06 Claim Separation|INSTALLED != BOUND|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-C6A9781D`|`OR-C6A9781D`|`MUT-781D-03`|§9/C-05|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-C6A9781D-C04`|`STD-REQ-C6A9781D`|`A3:L2057 / 7080`|P-06 Claim Separation|BOUND != ENABLED|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-C6A9781D`|`OR-C6A9781D`|`MUT-781D-04`|§9/C-05|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-C6A9781D-C05`|`STD-REQ-C6A9781D`|`A3:L2058 / 7080`|P-06 Claim Separation|TQAEP_COMPLETE != TEST_EXECUTED|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-C6A9781D`|`OR-C6A9781D`|`MUT-781D-05`|§9/C-05|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-C6A9781D-C06`|`STD-REQ-C6A9781D`|`A3:L2059 / 7080`|P-06 Claim Separation|TEST_EXECUTED != VERIFIED|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-C6A9781D`|`OR-C6A9781D`|`MUT-781D-06`|§9/C-05|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-C6A9781D-C07`|`STD-REQ-C6A9781D`|`A3:L2060 / 7080`|P-06 Claim Separation|LOCAL_REVIEW != INDEPENDENT_PASS|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-C6A9781D`|`OR-C6A9781D`|`MUT-781D-07`|§9/C-05|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-C6A9781D-C08`|`STD-REQ-C6A9781D`|`A3:L2061 / 7080`|P-06 Claim Separation|TOOL_SUCCESS != WORLD_EFFECT_CONFIRMED|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-C6A9781D`|`OR-C6A9781D`|`MUT-781D-08`|§9/C-05|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-C6A9781D-C09`|`STD-REQ-C6A9781D`|`A3:L2062 / 7080`|P-06 Claim Separation|PREDEV_READY != EXECUTION_ADMITTED|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-C6A9781D`|`OR-C6A9781D`|`MUT-781D-09`|§9/C-05|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-4AAA061A-C01`|`STD-REQ-4AAA061A`|`A3:L2071 / 7082`|P-09 Complexity Must Earn Complexity|package count earned by complexity|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-4AAA061A`|`OR-4AAA061A`|`MUT-061A-01`|§7.15|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-4AAA061A-C02`|`STD-REQ-4AAA061A`|`A3:L2072 / 7082`|P-09 Complexity Must Earn Complexity|chapter count earned by complexity|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-4AAA061A`|`OR-4AAA061A`|`MUT-061A-02`|§7.15|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-4AAA061A-C03`|`STD-REQ-4AAA061A`|`A3:L2073 / 7082`|P-09 Complexity Must Earn Complexity|gate count earned by risk/assurance|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-4AAA061A`|`OR-4AAA061A`|`MUT-061A-03`|§7.15|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-4AAA061A-C04`|`STD-REQ-4AAA061A`|`A3:L2074 / 7082`|P-09 Complexity Must Earn Complexity|assurance depth earned by authority complexity|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-4AAA061A`|`OR-4AAA061A`|`MUT-061A-04`|§7.15|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-4AAA061A-C05`|`STD-REQ-4AAA061A`|`A3:L2075 / 7082`|P-09 Complexity Must Earn Complexity|side-effect risk included|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-4AAA061A`|`OR-4AAA061A`|`MUT-061A-05`|§7.15|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-4AAA061A-C06`|`STD-REQ-4AAA061A`|`A3:L2076 / 7082`|P-09 Complexity Must Earn Complexity|integration count included|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-4AAA061A`|`OR-4AAA061A`|`MUT-061A-06`|§7.15|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-4AAA061A-C07`|`STD-REQ-4AAA061A`|`A3:L2077 / 7082`|P-09 Complexity Must Earn Complexity|reversibility included|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-4AAA061A`|`OR-4AAA061A`|`MUT-061A-07`|§7.15|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-4AAA061A-C08`|`STD-REQ-4AAA061A`|`A3:L2078 / 7082`|P-09 Complexity Must Earn Complexity|assurance need included|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-4AAA061A`|`OR-4AAA061A`|`MUT-061A-08`|§7.15|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-98BC2330-C01`|`STD-REQ-98BC2330`|`A3:L2080 / 7084`|P-11 Capability-Before-Brand / Search-Before-Build|express need/capability before brand|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-98BC2330`|`OR-98BC2330`|`MUT-2330-01`|§7.16|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-98BC2330-C02`|`STD-REQ-98BC2330`|`A3:L2081 / 7084`|P-11 Capability-Before-Brand / Search-Before-Build|check internal reuse first|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-98BC2330`|`OR-98BC2330`|`MUT-2330-02`|§7.16|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-98BC2330-C03`|`STD-REQ-98BC2330`|`A3:L2082 / 7084`|P-11 Capability-Before-Brand / Search-Before-Build|scout external candidates second|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-98BC2330`|`OR-98BC2330`|`MUT-2330-03`|§7.16|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-98BC2330-C04`|`STD-REQ-98BC2330`|`A3:L2083 / 7084`|P-11 Capability-Before-Brand / Search-Before-Build|normalize candidate identity|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-98BC2330`|`OR-98BC2330`|`MUT-2330-04`|§7.16|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-98BC2330-C05`|`STD-REQ-98BC2330`|`A3:L2084 / 7084`|P-11 Capability-Before-Brand / Search-Before-Build|gap/fit comparison|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-98BC2330`|`OR-98BC2330`|`MUT-2330-05`|§7.16|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-98BC2330-C06`|`STD-REQ-98BC2330`|`A3:L2085 / 7084`|P-11 Capability-Before-Brand / Search-Before-Build|security/license/maturity/maintenance/supply-chain evaluation|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-98BC2330`|`OR-98BC2330`|`MUT-2330-06`|§7.16|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-98BC2330-C07`|`STD-REQ-98BC2330`|`A3:L2086 / 7084`|P-11 Capability-Before-Brand / Search-Before-Build|portability/testability/brownfield/exit evaluation|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-98BC2330`|`OR-98BC2330`|`MUT-2330-07`|§7.16|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-98BC2330-C08`|`STD-REQ-98BC2330`|`A3:L2087 / 7084`|P-11 Capability-Before-Brand / Search-Before-Build|terminal disposition required|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-98BC2330`|`OR-98BC2330`|`MUT-2330-08`|§7.16|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-98BC2330-C09`|`STD-REQ-98BC2330`|`A3:L2088 / 7084`|P-11 Capability-Before-Brand / Search-Before-Build|version/currentness pin required|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-98BC2330`|`OR-98BC2330`|`MUT-2330-09`|§7.16|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-98BC2330-C11`|`STD-REQ-98BC2330`|`A3:L2090 / 7084`|P-11 Capability-Before-Brand / Search-Before-Build|BUILD_MINIMAL only after demonstrated no-fit|`DOC-01`|`TechnologyAdmissionRecord`|`requirement-trace.schema.json`|`TEST-98BC2330`|`OR-98BC2330`|`MUT-2330-11`|§7.16|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-2A89F996-C01`|`STD-REQ-2A89F996`|`A3:L2097 / 7086`|P-14 Segregation of Duties|Maker role independent slot|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-2A89F996`|`OR-2A89F996`|`MUT-F996-01`|§3/§12|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-2A89F996-C02`|`STD-REQ-2A89F996`|`A3:L2098 / 7086`|P-14 Segregation of Duties|Checker role independent slot|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-2A89F996`|`OR-2A89F996`|`MUT-F996-02`|§3/§12|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-2A89F996-C03`|`STD-REQ-2A89F996`|`A3:L2099 / 7086`|P-14 Segregation of Duties|Acceptor role independent slot|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-2A89F996`|`OR-2A89F996`|`MUT-F996-03`|§3/§12|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-2A89F996-C04`|`STD-REQ-2A89F996`|`A3:L2100 / 7086`|P-14 Segregation of Duties|Release Authority independent slot|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-2A89F996`|`OR-2A89F996`|`MUT-F996-04`|§3/§12|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-2A89F996-C05`|`STD-REQ-2A89F996`|`A3:L2101 / 7086`|P-14 Segregation of Duties|Human Approver independent slot|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-2A89F996`|`OR-2A89F996`|`MUT-F996-05`|§3/§12|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-2A89F996-C07`|`STD-REQ-2A89F996`|`A3:L2103 / 7086`|P-14 Segregation of Duties|ASSURED/high-risk Maker/Checker/Acceptor not collapsed|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-2A89F996`|`OR-2A89F996`|`MUT-F996-07`|§3/§12|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-C5BCA382-C01`|`STD-REQ-C5BCA382`|`A3:L2104 / 7087`|P-15 Prose/Machine Gate Equivalence|prose promotion predicate has machine equivalent|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-C5BCA382`|`OR-C5BCA382`|`MUT-A382-01`|§21|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-C5BCA382-C02`|`STD-REQ-C5BCA382`|`A3:L2105 / 7087`|P-15 Prose/Machine Gate Equivalence|JSON Schema and/or deterministic validator used|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-C5BCA382`|`OR-C5BCA382`|`MUT-A382-02`|§21|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-C5BCA382-C03`|`STD-REQ-C5BCA382`|`A3:L2106 / 7087`|P-15 Prose/Machine Gate Equivalence|prose-only gate cannot independently promote state|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-C5BCA382`|`OR-C5BCA382`|`MUT-A382-03`|§21|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-B0C02A64-C01`|`STD-REQ-B0C02A64`|`A3:L2107 / 7088`|5.2 Promotion Rule|required artifacts exist|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-B0C02A64`|`OR-B0C02A64`|`MUT-2A64-01`|§6|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-B0C02A64-C02`|`STD-REQ-B0C02A64`|`A3:L2108 / 7088`|5.2 Promotion Rule|required fields non-placeholder|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-B0C02A64`|`OR-B0C02A64`|`MUT-2A64-02`|§6|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-B0C02A64-C03`|`STD-REQ-B0C02A64`|`A3:L2109 / 7088`|5.2 Promotion Rule|required references resolvable|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-B0C02A64`|`OR-B0C02A64`|`MUT-2A64-03`|§6|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-B0C02A64-C04`|`STD-REQ-B0C02A64`|`A3:L2110 / 7088`|5.2 Promotion Rule|owner/checker/receiver identity correct|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-B0C02A64`|`OR-B0C02A64`|`MUT-2A64-04`|§6|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-B0C02A64-C05`|`STD-REQ-B0C02A64`|`A3:L2111 / 7088`|5.2 Promotion Rule|gate predicate true|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-B0C02A64`|`OR-B0C02A64`|`MUT-2A64-05`|§6|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-B0C02A64-C06`|`STD-REQ-B0C02A64`|`A3:L2112 / 7088`|5.2 Promotion Rule|blocking TT count zero|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-B0C02A64`|`OR-B0C02A64`|`MUT-2A64-06`|§6|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-B0C02A64-C07`|`STD-REQ-B0C02A64`|`A3:L2113 / 7088`|5.2 Promotion Rule|stale dependency count zero|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-B0C02A64`|`OR-B0C02A64`|`MUT-2A64-07`|§6|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-B0C02A64-C08`|`STD-REQ-B0C02A64`|`A3:L2114 / 7088`|5.2 Promotion Rule|permission/admission prerequisites satisfied|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-B0C02A64`|`OR-B0C02A64`|`MUT-2A64-08`|§6|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-B0C02A64-C09`|`STD-REQ-B0C02A64`|`A3:L2115 / 7088`|5.2 Promotion Rule|evidence appropriate for target state|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-B0C02A64`|`OR-B0C02A64`|`MUT-2A64-09`|§6|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-B0C02A64-C10`|`STD-REQ-B0C02A64`|`A3:L2116 / 7088`|5.2 Promotion Rule|prior document claim not substituted for next-stage execution evidence|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-B0C02A64`|`OR-B0C02A64`|`MUT-2A64-10`|§6|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-E0C7F7A0-C01`|`STD-REQ-E0C7F7A0`|`A3:L2117 / 7089`|6. Artifact Identity & Authority Model|artifact_id|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-E0C7F7A0`|`OR-E0C7F7A0`|`MUT-F7A0-01`|§3|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-E0C7F7A0-C02`|`STD-REQ-E0C7F7A0`|`A3:L2118 / 7089`|6. Artifact Identity & Authority Model|artifact_type|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-E0C7F7A0`|`OR-E0C7F7A0`|`MUT-F7A0-02`|§3|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-E0C7F7A0-C03`|`STD-REQ-E0C7F7A0`|`A3:L2119 / 7089`|6. Artifact Identity & Authority Model|subject_id|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-E0C7F7A0`|`OR-E0C7F7A0`|`MUT-F7A0-03`|§3|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-E0C7F7A0-C04`|`STD-REQ-E0C7F7A0`|`A3:L2120 / 7089`|6. Artifact Identity & Authority Model|subject_version|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-E0C7F7A0`|`OR-E0C7F7A0`|`MUT-F7A0-04`|§3|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-E0C7F7A0-C05`|`STD-REQ-E0C7F7A0`|`A3:L2121 / 7089`|6. Artifact Identity & Authority Model|content_hash|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-E0C7F7A0`|`OR-E0C7F7A0`|`MUT-F7A0-05`|§3|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-E0C7F7A0-C06`|`STD-REQ-E0C7F7A0`|`A3:L2122 / 7089`|6. Artifact Identity & Authority Model|authority_refs|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-E0C7F7A0`|`OR-E0C7F7A0`|`MUT-F7A0-06`|§3|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-E0C7F7A0-C07`|`STD-REQ-E0C7F7A0`|`A3:L2123 / 7089`|6. Artifact Identity & Authority Model|canonical_owner|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-E0C7F7A0`|`OR-E0C7F7A0`|`MUT-F7A0-07`|§3|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-E0C7F7A0-C08`|`STD-REQ-E0C7F7A0`|`A3:L2124 / 7089`|6. Artifact Identity & Authority Model|maker|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-E0C7F7A0`|`OR-E0C7F7A0`|`MUT-F7A0-08`|§3|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-E0C7F7A0-C09`|`STD-REQ-E0C7F7A0`|`A3:L2125 / 7089`|6. Artifact Identity & Authority Model|checker|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-E0C7F7A0`|`OR-E0C7F7A0`|`MUT-F7A0-09`|§3|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-E0C7F7A0-C10`|`STD-REQ-E0C7F7A0`|`A3:L2126 / 7089`|6. Artifact Identity & Authority Model|acceptor|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-E0C7F7A0`|`OR-E0C7F7A0`|`MUT-F7A0-10`|§3|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-E0C7F7A0-C14`|`STD-REQ-E0C7F7A0`|`A3:L2130 / 7089`|6. Artifact Identity & Authority Model|extensions|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-E0C7F7A0`|`OR-E0C7F7A0`|`MUT-F7A0-14`|§3|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-E0C7F7A0-C15`|`STD-REQ-E0C7F7A0`|`A3:L2131 / 7089`|6. Artifact Identity & Authority Model|lifecycle_state|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-E0C7F7A0`|`OR-E0C7F7A0`|`MUT-F7A0-15`|§3|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-E0C7F7A0-C16`|`STD-REQ-E0C7F7A0`|`A3:L2132 / 7089`|6. Artifact Identity & Authority Model|claim_ceiling|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-E0C7F7A0`|`OR-E0C7F7A0`|`MUT-F7A0-16`|§3|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-E0C7F7A0-C17`|`STD-REQ-E0C7F7A0`|`A3:L2133 / 7089`|6. Artifact Identity & Authority Model|supersedes|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-E0C7F7A0`|`OR-E0C7F7A0`|`MUT-F7A0-17`|§3|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-E0C7F7A0-C18`|`STD-REQ-E0C7F7A0`|`A3:L2134 / 7089`|6. Artifact Identity & Authority Model|created_at_or_observed_at|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-E0C7F7A0`|`OR-E0C7F7A0`|`MUT-F7A0-18`|§3|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-81C86EBB-C01`|`STD-REQ-81C86EBB`|`A3:L2135 / 7090`|6. Artifact Identity & Authority Model|- 同名不同 bytes MUST 視為不同 revision；|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-81C86EBB`|`OR-81C86EBB`|`MUT-6EBB-01`|§3|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-C25BC6A2-C01`|`STD-REQ-C25BC6A2`|`A3:L2136 / 7091`|6. Artifact Identity & Authority Model|- superseded artifact 可保留 provenance，但 MUST NOT 靜默當 current normative source；|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-C25BC6A2`|`OR-C25BC6A2`|`MUT-C6A2-01`|§3|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-FA7B1B7F-C01`|`STD-REQ-FA7B1B7F`|`A3:L2138 / 7093`|6.1 Common Artifact Metadata Contract|artifact_type machine-readable|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-FA7B1B7F`|`OR-FA7B1B7F`|`MUT-1B7F-01`|§3|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-FA7B1B7F-C02`|`STD-REQ-FA7B1B7F`|`A3:L2139 / 7093`|6.1 Common Artifact Metadata Contract|content_hash machine-readable|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-FA7B1B7F`|`OR-FA7B1B7F`|`MUT-1B7F-02`|§3|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-FA7B1B7F-C06`|`STD-REQ-FA7B1B7F`|`A3:L2143 / 7093`|6.1 Common Artifact Metadata Contract|extensions[] machine-readable|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-FA7B1B7F`|`OR-FA7B1B7F`|`MUT-1B7F-06`|§3|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-FA7B1B7F-C07`|`STD-REQ-FA7B1B7F`|`A3:L2144 / 7093`|6.1 Common Artifact Metadata Contract|ASSURED/high-risk role separation machine-checkable|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-FA7B1B7F`|`OR-FA7B1B7F`|`MUT-1B7F-07`|§3|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-829B7605-C01`|`STD-REQ-829B7605`|`A3:L2146 / 7095`|7.1 Purpose|Lifecycle Constitution 是專案內 PI → PD → Implementation → Verification → Release 的最高施工前流程契約。每個專案 MUST materialize 一份 instance，或明確引用組織級 Constitution 並記錄 project-specific deltas。|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-829B7605`|`OR-829B7605`|`MUT-7605-01`|§2/C-family|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-7B3AB9E9-C01`|`STD-REQ-7B3AB9E9`|`A3:L2147 / 7096`|C-01 Project / Product Identity|project_id/product identity|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-7B3AB9E9`|`OR-7B3AB9E9`|`MUT-B9E9-01`|§7 C-01|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-7B3AB9E9-C02`|`STD-REQ-7B3AB9E9`|`A3:L2148 / 7096`|C-01 Project / Product Identity|subject/version identity|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-7B3AB9E9`|`OR-7B3AB9E9`|`MUT-B9E9-02`|§7 C-01|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-7B3AB9E9-C03`|`STD-REQ-7B3AB9E9`|`A3:L2149 / 7096`|C-01 Project / Product Identity|mission/outcome|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-7B3AB9E9`|`OR-7B3AB9E9`|`MUT-B9E9-03`|§7 C-01|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-7B3AB9E9-C04`|`STD-REQ-7B3AB9E9`|`A3:L2150 / 7096`|C-01 Project / Product Identity|scope boundary|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-7B3AB9E9`|`OR-7B3AB9E9`|`MUT-B9E9-04`|§7 C-01|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-7B3AB9E9-C05`|`STD-REQ-7B3AB9E9`|`A3:L2151 / 7096`|C-01 Project / Product Identity|non-goals|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-7B3AB9E9`|`OR-7B3AB9E9`|`MUT-B9E9-05`|§7 C-01|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-454A6D90-C01`|`STD-REQ-454A6D90`|`A3:L2152 / 7097`|C-02 Authority Stack|current user task priority|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-454A6D90`|`OR-454A6D90`|`MUT-6D90-01`|§7 C-02/§11|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-454A6D90-C02`|`STD-REQ-454A6D90`|`A3:L2153 / 7097`|C-02 Authority Stack|canonical standard/Constitution priority|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-454A6D90`|`OR-454A6D90`|`MUT-6D90-02`|§7 C-02/§11|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-454A6D90-C03`|`STD-REQ-454A6D90`|`A3:L2154 / 7097`|C-02 Authority Stack|accepted project decisions priority|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-454A6D90`|`OR-454A6D90`|`MUT-6D90-03`|§7 C-02/§11|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-454A6D90-C04`|`STD-REQ-454A6D90`|`A3:L2155 / 7097`|C-02 Authority Stack|current PI/PD package priority|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-454A6D90`|`OR-454A6D90`|`MUT-6D90-04`|§7 C-02/§11|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-454A6D90-C05`|`STD-REQ-454A6D90`|`A3:L2156 / 7097`|C-02 Authority Stack|repo-local mechanics priority without semantic override|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-454A6D90`|`OR-454A6D90`|`MUT-6D90-05`|§7 C-02/§11|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-454A6D90-C06`|`STD-REQ-454A6D90`|`A3:L2157 / 7097`|C-02 Authority Stack|external/support sources subordinate|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-454A6D90`|`OR-454A6D90`|`MUT-6D90-06`|§7 C-02/§11|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-5EFF0181-C01`|`STD-REQ-5EFF0181`|`A3:L2158 / 7098`|C-02 Authority Stack|同 rank conflict MUST fail closed，不得 silent merge。|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-5EFF0181`|`OR-5EFF0181`|`MUT-0181-01`|§7 C-02/§11|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-6CCE644F-C01`|`STD-REQ-6CCE644F`|`A3:L2159 / 7099`|C-03 Canonical Ownership|canonical owner|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-6CCE644F`|`OR-6CCE644F`|`MUT-644F-01`|§7 C-03/§12|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-6CCE644F-C02`|`STD-REQ-6CCE644F`|`A3:L2160 / 7099`|C-03 Canonical Ownership|canonical writer|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-6CCE644F`|`OR-6CCE644F`|`MUT-644F-02`|§7 C-03/§12|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-6CCE644F-C03`|`STD-REQ-6CCE644F`|`A3:L2161 / 7099`|C-03 Canonical Ownership|readers/consumers|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-6CCE644F`|`OR-6CCE644F`|`MUT-644F-03`|§7 C-03/§12|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-6CCE644F-C04`|`STD-REQ-6CCE644F`|`A3:L2162 / 7099`|C-03 Canonical Ownership|mutation authority|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-6CCE644F`|`OR-6CCE644F`|`MUT-644F-04`|§7 C-03/§12|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-6CCE644F-C05`|`STD-REQ-6CCE644F`|`A3:L2163 / 7099`|C-03 Canonical Ownership|invalidation trigger|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-6CCE644F`|`OR-6CCE644F`|`MUT-644F-05`|§7 C-03/§12|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-119B9088-C01`|`STD-REQ-119B9088`|`A3:L2164 / 7100`|C-04 Lifecycle States|MUST 使用第 5 節狀態機，或提供 semantically equivalent mapping。|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-119B9088`|`OR-119B9088`|`MUT-9088-01`|§4/§7 C-04|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-EEC45EC3-C01`|`STD-REQ-EEC45EC3`|`A3:L2165 / 7101`|C-05 Claim Rules|MUST 明示哪些 state/claim 不能從文件存在性推導。|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-EEC45EC3`|`OR-EEC45EC3`|`MUT-5EC3-01`|§9/§7 C-05|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-0CB9A2A0-C01`|`STD-REQ-0CB9A2A0`|`A3:L2166 / 7102`|C-09 Tailoring Profile|weight_profile selected LITE/STANDARD/ASSURED|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`STANDARD \\`|`ASSURED\` 或等價 profile。`|`MUT-A2A0-01`|§15/§7 C-09|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-0CB9A2A0-C02`|`STD-REQ-0CB9A2A0`|`A3:L2167 / 7102`|C-09 Tailoring Profile|target_profile selected SYSTEM/SKILL_PLUGIN/AGENT_HARNESS/CUSTOM|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`STANDARD \\`|`ASSURED\` 或等價 profile。`|`MUT-A2A0-02`|§15/§7 C-09|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-0CB9A2A0-C03`|`STD-REQ-0CB9A2A0`|`A3:L2168 / 7102`|C-09 Tailoring Profile|profile_version bound|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`STANDARD \\`|`ASSURED\` 或等價 profile。`|`MUT-A2A0-03`|§15/§7 C-09|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-0CB9A2A0-C04`|`STD-REQ-0CB9A2A0`|`A3:L2169 / 7102`|C-09 Tailoring Profile|extensions[] bound|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`STANDARD \\`|`ASSURED\` 或等價 profile。`|`MUT-A2A0-04`|§15/§7 C-09|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-DD50D72A-C01`|`STD-REQ-DD50D72A`|`A3:L2170 / 7103`|C-10 Definition of Pre-Execution Complete|MUST 明示 project-specific PRE_EXECUTION_ENGINEERING_COMPLETE predicate。|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-DD50D72A`|`OR-DD50D72A`|`MUT-D72A-01`|§7 C-10|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-59D1DD6F-C01`|`STD-REQ-59D1DD6F`|`A3:L2171 / 7104`|C-11 Standard Namespace / Schema Compatibility|The project SHALL bind a schema namespace and version. V1.1 canonical namespace is urn:pipd:canonical-standard:1.1. Project extensions MAY use organization-owned HTTPS URIs or URNs. example.org MUST NOT be used as final canonical identity.|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-59D1DD6F`|`OR-59D1DD6F`|`MUT-DD6F-01`|§16/§7 C-11|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-9E161B60-C01`|`STD-REQ-9E161B60`|`A3:L2172 / 7105`|C-11 Standard Namespace / Schema Compatibility|- superseding schemas MUST state supersedes, supported migration, and backward/forward compatibility.|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-9E161B60`|`OR-9E161B60`|`MUT-1B60-01`|§16/§7 C-11|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-D28A8B60-C01`|`STD-REQ-D28A8B60`|`A3:L2181 / 7108`|C-14 Security Threat Model|threat|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-D28A8B60`|`OR-D28A8B60`|`MUT-8B60-01`|§14|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-D28A8B60-C02`|`STD-REQ-D28A8B60`|`A3:L2182 / 7108`|C-14 Security Threat Model|asset|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-D28A8B60`|`OR-D28A8B60`|`MUT-8B60-02`|§14|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-D28A8B60-C03`|`STD-REQ-D28A8B60`|`A3:L2183 / 7108`|C-14 Security Threat Model|trust boundary|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-D28A8B60`|`OR-D28A8B60`|`MUT-8B60-03`|§14|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-D28A8B60-C04`|`STD-REQ-D28A8B60`|`A3:L2184 / 7108`|C-14 Security Threat Model|abuse case|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-D28A8B60`|`OR-D28A8B60`|`MUT-8B60-04`|§14|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-D28A8B60-C05`|`STD-REQ-D28A8B60`|`A3:L2185 / 7108`|C-14 Security Threat Model|prevention control|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-D28A8B60`|`OR-D28A8B60`|`MUT-8B60-05`|§14|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-D28A8B60-C06`|`STD-REQ-D28A8B60`|`A3:L2186 / 7108`|C-14 Security Threat Model|detection control|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-D28A8B60`|`OR-D28A8B60`|`MUT-8B60-06`|§14|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-D28A8B60-C07`|`STD-REQ-D28A8B60`|`A3:L2187 / 7108`|C-14 Security Threat Model|response control|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-D28A8B60`|`OR-D28A8B60`|`MUT-8B60-07`|§14|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-D28A8B60-C09`|`STD-REQ-D28A8B60`|`A3:L2189 / 7108`|C-14 Security Threat Model|owner|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-D28A8B60`|`OR-D28A8B60`|`MUT-8B60-09`|§14|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-D28A8B60-C10`|`STD-REQ-D28A8B60`|`A3:L2190 / 7108`|C-14 Security Threat Model|residual risk|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-D28A8B60`|`OR-D28A8B60`|`MUT-8B60-10`|§14|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-D28A8B60-C11`|`STD-REQ-D28A8B60`|`A3:L2191 / 7108`|C-14 Security Threat Model|human gate where applicable|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-D28A8B60`|`OR-D28A8B60`|`MUT-8B60-11`|§14|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-D28A8B60-C12`|`STD-REQ-D28A8B60`|`A3:L2192 / 7108`|C-14 Security Threat Model|agent goal hijack|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-D28A8B60`|`OR-D28A8B60`|`MUT-8B60-12`|§14|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-D28A8B60-C13`|`STD-REQ-D28A8B60`|`A3:L2193 / 7108`|C-14 Security Threat Model|tool misuse|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-D28A8B60`|`OR-D28A8B60`|`MUT-8B60-13`|§14|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-D28A8B60-C14`|`STD-REQ-D28A8B60`|`A3:L2194 / 7108`|C-14 Security Threat Model|identity/privilege abuse|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-D28A8B60`|`OR-D28A8B60`|`MUT-8B60-14`|§14|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-D28A8B60-C15`|`STD-REQ-D28A8B60`|`A3:L2195 / 7108`|C-14 Security Threat Model|memory/context poisoning|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-D28A8B60`|`OR-D28A8B60`|`MUT-8B60-15`|§14|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-D28A8B60-C16`|`STD-REQ-D28A8B60`|`A3:L2196 / 7108`|C-14 Security Threat Model|inter-agent trust abuse|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-D28A8B60`|`OR-D28A8B60`|`MUT-8B60-16`|§14|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-D28A8B60-C17`|`STD-REQ-D28A8B60`|`A3:L2197 / 7108`|C-14 Security Threat Model|cascading failure|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-D28A8B60`|`OR-D28A8B60`|`MUT-8B60-17`|§14|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-D28A8B60-C18`|`STD-REQ-D28A8B60`|`A3:L2198 / 7108`|C-14 Security Threat Model|rogue/unauthorized action|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-D28A8B60`|`OR-D28A8B60`|`MUT-8B60-18`|§14|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-D28A8B60-C19`|`STD-REQ-D28A8B60`|`A3:L2199 / 7108`|C-14 Security Threat Model|sensitive-context leakage|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-D28A8B60`|`OR-D28A8B60`|`MUT-8B60-19`|§14|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-F8221F9F-C01`|`STD-REQ-F8221F9F`|`A3:L2300 / 7123`|12. PI_READY Gate|CONSTITUTION_READY=true|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-F8221F9F`|`OR-F8221F9F`|`MUT-1F9F-01`|§8|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-38EB8516-C01`|`STD-REQ-38EB8516`|`A3:L2420 / 7138`|18.1 Extraction Manifest|Each fenced JSON block in §18.2 is independently extractable to the exact filename in its heading. The $id is a URN and has no network resolution dependency. Extraction tools MUST preserve bytes inside the JSON fence, validate Draft 2020-12, and report duplicate $id as a failure.|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-38EB8516`|`OR-38EB8516`|`MUT-8516-01`|§16/§21|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-F4669FFF-C01`|`STD-REQ-F4669FFF`|`A3:L2422 / 7140`|18.4 Destructive Fixtures Required by the Standard|missing requirement|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-F4669FFF`|`OR-F4669FFF`|`MUT-9FFF-01`|§24|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-F4669FFF-C02`|`STD-REQ-F4669FFF`|`A3:L2423 / 7140`|18.4 Destructive Fixtures Required by the Standard|orphan SPEC|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-F4669FFF`|`OR-F4669FFF`|`MUT-9FFF-02`|§24|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-F4669FFF-C03`|`STD-REQ-F4669FFF`|`A3:L2424 / 7140`|18.4 Destructive Fixtures Required by the Standard|missing acceptance|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-F4669FFF`|`OR-F4669FFF`|`MUT-9FFF-03`|§24|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-F4669FFF-C05`|`STD-REQ-F4669FFF`|`A3:L2426 / 7140`|18.4 Destructive Fixtures Required by the Standard|stale hash|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-F4669FFF`|`OR-F4669FFF`|`MUT-9FFF-05`|§24|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-F4669FFF-C06`|`STD-REQ-F4669FFF`|`A3:L2427 / 7140`|18.4 Destructive Fixtures Required by the Standard|wrong subject|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-F4669FFF`|`OR-F4669FFF`|`MUT-9FFF-06`|§24|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-F4669FFF-C08`|`STD-REQ-F4669FFF`|`A3:L2429 / 7140`|18.4 Destructive Fixtures Required by the Standard|provider/tool semantic takeover|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-F4669FFF`|`OR-F4669FFF`|`MUT-9FFF-08`|§24|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-F4669FFF-C11`|`STD-REQ-F4669FFF`|`A3:L2432 / 7140`|18.4 Destructive Fixtures Required by the Standard|missing rollback|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-F4669FFF`|`OR-F4669FFF`|`MUT-9FFF-11`|§24|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-F4669FFF-C12`|`STD-REQ-F4669FFF`|`A3:L2433 / 7140`|18.4 Destructive Fixtures Required by the Standard|false PI_READY|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-F4669FFF`|`OR-F4669FFF`|`MUT-9FFF-12`|§24|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-F4669FFF-C13`|`STD-REQ-F4669FFF`|`A3:L2434 / 7140`|18.4 Destructive Fixtures Required by the Standard|false PREDEV_READY|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-F4669FFF`|`OR-F4669FFF`|`MUT-9FFF-13`|§24|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-F4669FFF-C14`|`STD-REQ-F4669FFF`|`A3:L2435 / 7140`|18.4 Destructive Fixtures Required by the Standard|execution before ADMIT|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-F4669FFF`|`OR-F4669FFF`|`MUT-9FFF-14`|§24|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-F4669FFF-C15`|`STD-REQ-F4669FFF`|`A3:L2436 / 7140`|18.4 Destructive Fixtures Required by the Standard|maker self-approval|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-F4669FFF`|`OR-F4669FFF`|`MUT-9FFF-15`|§24|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-F4669FFF-C16`|`STD-REQ-F4669FFF`|`A3:L2437 / 7140`|18.4 Destructive Fixtures Required by the Standard|world-effect false positive|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-F4669FFF`|`OR-F4669FFF`|`MUT-9FFF-16`|§24|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-F4669FFF-C17`|`STD-REQ-F4669FFF`|`A3:L2438 / 7140`|18.4 Destructive Fixtures Required by the Standard|selected technology silently omitted|`DOC-01`|`TechnologyAdmissionRecord`|`technology-admission.schema.json`|`TEST-F4669FFF`|`OR-F4669FFF`|`MUT-9FFF-17`|§24|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-7894BFB5-C01`|`STD-REQ-7894BFB5`|`A3:L2541 / 7151`|26.2 External Content Is Data|網頁、repo file、issue、prompt、tool output、model output 都可能包含 untrusted instructions；除非它位於已授權 instruction surface，否則 MUST 當 DATA。|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-7894BFB5`|`OR-7894BFB5`|`MUT-BFB5-01`|Intro/§14|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-86CAC54E-C01`|`STD-REQ-86CAC54E`|`A3:L2542 / 7152`|26.4 Agent Memory|persistent memory / context MUST 有 source、scope、expiry/invalidation、trust label。外部內容不得透過 memory 自動升權。|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-86CAC54E`|`OR-86CAC54E`|`MUT-C54E-01`|§7.17|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-44B56684-C01`|`STD-REQ-44B56684`|`A3:L2554 / 7158`|50. Final Normative Statement|project can identify canonical Constitution|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-44B56684`|`OR-44B56684`|`MUT-6684-01`|§28|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-44B56684-C02`|`STD-REQ-44B56684`|`A3:L2555 / 7158`|50. Final Normative Statement|project can prove authority/source binding|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-44B56684`|`OR-44B56684`|`MUT-6684-02`|§28|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-44B56684-C03`|`STD-REQ-44B56684`|`A3:L2556 / 7158`|50. Final Normative Statement|project can show PI_READY predicate|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-44B56684`|`OR-44B56684`|`MUT-6684-03`|§28|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-44B56684-C04`|`STD-REQ-44B56684`|`A3:L2557 / 7158`|50. Final Normative Statement|project can show PD binding/PREDEV_READY predicate|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-44B56684`|`OR-44B56684`|`MUT-6684-04`|§28|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-44B56684-C10`|`STD-REQ-44B56684`|`A3:L2563 / 7158`|50. Final Normative Statement|project can show change/supersession/invalidation|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-44B56684`|`OR-44B56684`|`MUT-6684-10`|§28|`COVERED`|stable identity retained; substantive/machine closure in referenced section|
|`STD-REQ-44B56684-C13`|`STD-REQ-44B56684`|`A3:L2566 / 7158`|50. Final Normative Statement|project can distinguish document materialization from runtime truth|`DOC-01`|`RequirementTrace`|`requirement-trace.schema.json`|`TEST-44B56684`|`OR-44B56684`|`MUT-6684-13`|§28|`COVERED`|stable identity retained; substantive/machine closure in referenced section|

**Closure rule:** acceptance requires exactly 140 DOC-01-owned stable rows and no row with unclassified local substitute identity. `COVERED` means substantive obligation exists in r2 body; a future project instance may still be non-conformant until its own evidence/tests execute.

# 26｜Source-to-Prose / Extraction / Schema Identity Ledger

|Source|Role|Exact substantive surfaces consumed|Anti-drift rule|
|---|---|---|---|
|A0 production instruction|authoring contract|14-state per-state dimensions; C-01..14 dimensions; TLC 26 fields; G-00..G-30|missing dimension cannot be replaced by heading existence|
|A1 blueprint|process design|SBB 15-step workflow; package-index fields; 18-event matrix; validator route|A1 exact retained engineering detail cannot be compressed away|
|A2 canonical standard|normative SSOT|state, metadata, Constitution, threat schema, change rules|no local schema/claim/state override|
|A3 skeleton|stable denominator|140 DOC-01 atomics + stable TEST/ORACLE/MUT IDs|local REQ IDs secondary only|
|A4 DOC-00|navigation/readback|package navigation/claim boundary|cannot reverse-author A1/A2/A3|
|A5/A5b|engineering rationale|minimum-sufficient architecture; shared Constitution principle|support adjudication, no split of canonical lifecycle authority|
|AUDIT|repair controller|B-01..B-04; M-01..M-11; O-01..O-04; A-01..A-20|all findings must map to r2 closure|

## 26.1 Extraction Manifest / Duplicate `$id` Contract
Schema extraction MUST enumerate every fenced canonical schema, parse JSON, collect `$id`, reject duplicates/conflicts, and validate Draft 2020-12 schemas before semantic use. `STD-REQ-38EB8516-C01` closes here and in §21. A duplicate `$id` or unparsable canonical schema ⇒ `TEMP_CLOSED`; it cannot be bypassed by prose agreement.

# 27｜Self-Review / Repair Verification / AUDIT Closure
## 27.1 Finding-by-Finding Closure
|Finding|r2 closure|Author-side status|
|---|---|---|
|B-01 Atomic denominator false closure|§25 140 stable atomics|`REPAIRED_AUTHOR_SIDE`|
|B-02 Prose/Machine Gate Equivalence|§6/§21 schemas + deterministic semantic rules|`REPAIRED_AUTHOR_SIDE`|
|B-03 CommonArtifactMetadata drift/self-nonconformance|front matter + §3 superset|`REPAIRED_AUTHOR_SIDE`|
|B-04 C-01..C-14 full-body depth|§7 full contracts|`REPAIRED_AUTHOR_SIDE`|
|M-01 artifact vs lifecycle claim namespace|front matter separates artifact/materialization from governed subject|`REPAIRED_AUTHOR_SIDE`|
|M-02 14-state per-state authoring|§4 14× state table|`REPAIRED_AUTHOR_SIDE`|
|M-03 canonical ThreatModelRow|§14 canonical fields/rows|`REPAIRED_AUTHOR_SIDE`|
|M-04 package-index machine contract|§19 exact fields/schema|`REPAIRED_AUTHOR_SIDE`|
|M-05 18/18 event matrix|§18 18/18|`REPAIRED_AUTHOR_SIDE`|
|M-06 destructive fixtures stable denominator|§24 13 stable fixtures|`REPAIRED_AUTHOR_SIDE`|
|M-07 TLC per-item 26 fields|§22 item-specific 26-field contracts|`REPAIRED_AUTHOR_SIDE`|
|M-08 validator/tool named route-out|§21/§22 named routes|`REPAIRED_AUTHOR_SIDE`|
|M-09 Complexity 8/8|§7.15 8/8|`REPAIRED_AUTHOR_SIDE`|
|M-10 SBB 10/10|§7.16 10/10|`REPAIRED_AUTHOR_SIDE`|
|M-11 ContextTrustRecord|§7.17 source/scope/expiry/trust|`REPAIRED_AUTHOR_SIDE`|
|O-01 Markdown pipe integrity|§3 escaped enum presentation; parser check|`REPAIRED_AUTHOR_SIDE`|
|O-02 FIPS revision monitor|§22 currentness status monitor|`REPAIRED_AUTHOR_SIDE`|
|O-03 RFC9557/core date-time compatibility|§22 TLC-04 separate typed timezone policy|`REPAIRED_AUTHOR_SIDE`|
|O-04 self-review checker independence|front matter checker=null + author_self_review marker|`REPAIRED_AUTHOR_SIDE`|

## 27.2 Revised Acceptance Gates A-01..A-20
|Gate|Predicate|Author-side result|
|---|---|---|
|`A-01`|A3 DOC-01 stable atomic denominator 140/140 closed or justified route-out|`PASS_AUTHOR_SIDE`|
|`A-02`|No BLOCKER / no unresolved normative MAJOR|`PASS_AUTHOR_SIDE`|
|`A-03`|Metadata superset preserves A2+A3 requirements|`PASS_AUTHOR_SIDE`|
|`A-04`|DOC-01 artifact itself conforms or declares detached-envelope rule|`PASS_AUTHOR_SIDE`|
|`A-05`|C-01..14 each meets A0 full authoring contract|`PASS_AUTHOR_SIDE`|
|`A-06`|P-09 complexity 8/8 materialized|`PASS_AUTHOR_SIDE`|
|`A-07`|P-11 SBB 10/10 materialized at constitution level|`PASS_AUTHOR_SIDE`|
|`A-08`|P-15 machine equivalence has schema + semantic mutation contract|`PASS_AUTHOR_SIDE`|
|`A-09`|14 states have state-specific entry/claim/reentry/invalidation/test contract|`PASS_AUTHOR_SIDE`|
|`A-10`|ThreatModelRows preserve canonical schema fields and agent threats|`PASS_AUTHOR_SIDE`|
|`A-11`|package-index decision matches A1 required fields|`PASS_AUTHOR_SIDE`|
|`A-12`|A1 18-event change matrix retained|`PASS_AUTHOR_SIDE`|
|`A-13`|destructive fixtures reach stable denominator|`PASS_AUTHOR_SIDE`|
|`A-14`|TLC per-item required fields complete|`PASS_AUTHOR_SIDE`|
|`A-15`|validator/tool dependencies named and route-out|`PASS_AUTHOR_SIDE`|
|`A-16`|external currentness refreshed + observed-at|`PASS_AUTHOR_SIDE`|
|`A-17`|Markdown/JSON/schema structural validation PASS|`PASS_AUTHOR_SIDE`|
|`A-18`|claim lint no artifact/lifecycle namespace inflation|`PASS_AUTHOR_SIDE`|
|`A-19`|same-model self-review explicitly non-independent|`PASS_AUTHOR_SIDE`|
|`A-20`|single-MD readback/hash receipt PASS|`PASS_AUTHOR_SIDE`|

## 27.3 Original G-00..G-30 Re-run Rule
The r1 self-review PASS is superseded. r2 gates are recalculated from actual content. G-03/G-04/G-05/G-21/G-22/G-24/G-27 are not inherited; they pass only if post-write scripts verify the stable denominator, dimensions, TLC fields, non-template-specific content, JSON/schema structure and claim lint.
## 27.4 Independent / Human / Runtime Boundary
`PASS_AUTHOR_SIDE` is bounded same-model author-side verification only. It is **NOT** Independent PASS, Human Ratification, target-repo conformance, execution evidence, release, or production proof.

# 28｜Final Normative Statement / Packaging / Claim-Honest Readback

A conforming project can identify the canonical Constitution; prove authority/source binding; show PI_READY predicate; show PD binding/PREDEV_READY predicate; distinguish execution-admission boundary; show permissions/SoD; show change/supersession/invalidation; and distinguish document materialization from runtime truth. DOC-01 itself does not claim project conformance or runtime completion.

## 28.1 r2 Supersession Effect
This r2 **engineeringly integrates, covers and replaces r1 as the current DOC-01 author-side substantive body**. r1 remains provenance only by exact SHA-256 and MUST NOT be silently treated as current. This supersession does not change A1/A2/A3 authority and cannot create Independent/Human/Release/Production status.

## 28.2 Single-MD Rule
All DOC-01-owned semantics required for this revision are recoverable from this one UTF-8 Markdown file. Canonical sibling documents may be referenced for their owned execution/evidence/technology/release details, but DOC-01-owned obligations are not delegated away.

## 28.3 Final Readback Receipt
The actual `byte_count`, `splitlines`, `sha256`, JSON/schema parse counts and placeholder/table checks are produced by the post-write delivery receipt after the final bytes are frozen. The SHA-256 is intentionally **not self-embedded** (to avoid recursive hash mutation); `detached_content_hash_ref` binds the delivery receipt to this exact file.
