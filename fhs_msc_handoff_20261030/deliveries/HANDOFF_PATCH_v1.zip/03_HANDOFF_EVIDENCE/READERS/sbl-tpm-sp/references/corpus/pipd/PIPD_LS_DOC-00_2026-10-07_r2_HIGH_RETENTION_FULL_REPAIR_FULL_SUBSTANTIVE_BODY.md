---
artifact_id: "PIPD_LS_DOC-00"
external_formal_name: "Pre-Implementation & Pre-Dev Lifecycle Specification — DOC-00 Navigation / Operator Entry"
internal_short_name: "PIPD_LS_DOC-00"
artifact_type: "FULL_SUBSTANTIVE_BODY_HIGH_RETENTION_FULL_REPAIR"
version: "2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY"
generated_at: "2026-10-07T10:53:00+08:00"
timezone: "Asia/Taipei"
standard_id: "PIPD-LIFECYCLE-SPEC"
standard_version: "1.1.0"
blueprint_id: "PIPD-LIFECYCLE-BLUEPRINT"
blueprint_version: "1.1.0"
patch_strategy: "HIGH_RETENTION_PATCH_NO_ARCHITECTURE_RESET"
supersedes: "PIPD_LS_DOC-00_2026-10-07_r1_FULL_SUBSTANTIVE_BODY.md"
superseded_sha256: "0b012d586e750d5c8fee1a6ff16deb76eea9d73d9412432a71c465f5295d848c"
patch_basis: "AUDIT_PIPD_LS_DOC-00_2026-10-07_r1_FULL_SUBSTANTIVE_BODY_FULL_AUDIT_2026-10-07_r1(2).md"
audit_sha256: "1081f9e935198f3da911a9eed227a0e66156e7b964422bccae27739002201dd7"
audit_verdict_consumed: "FAIL_REPAIR_REQUIRED"
status: "DOC00_R2_FULL_SUBSTANTIVE_BODY_MATERIALIZED"
canonical_archetype: "Navigation / Operator Entry"
claim_ceiling:
  - "DOC00_R2_FULL_SUBSTANTIVE_BODY_MATERIALIZED"
  - "REPAIR_GATES_LOCAL_PASS"
  - "NOT_TARGET_REPO_BOUND"
  - "NOT_IMPLEMENTED"
  - "NOT_INSTALLED"
  - "NOT_BOUND"
  - "NOT_ENABLED"
  - "NOT_EXECUTED"
  - "NOT_RUNTIME_VERIFIED"
  - "NOT_INDEPENDENT_PASS"
  - "NOT_HUMAN_RATIFIED"
  - "NOT_RELEASED"
  - "NOT_PRODUCTION_PASS"
foreign_claim_tokens: []
open_tt: []
open_cr: []
authority_order: ["CURRENT_PATCH_TASK","A1_BLUEPRINT","A2_CANONICAL_STANDARD","A3_REPAIRED_SKELETON","A4_DESIGN_HISTORY","AUDIT_REPAIR_CONTROLLER_FOR_R1_FINDINGS","CURRENTNESS_SUPPORT","OTHER_RESEARCH","MODEL_KNOWLEDGE"]
---

# PIPD_LS_DOC-00 — Navigation / Operator Entry — r2 High-Retention Full Repair

> **Repair posture:** This r2 preserves the r1 lifecycle/ownership spine and replaces the audited false-closure surfaces. DOC-00 remains a router/readback artifact, not a second lifecycle, TechnologyAdmission, evidence, handoff, qualification, release, or runtime SSOT.

# Five-Minute Router Card

| Question | Operator answer | Open next | Stop condition |
|---|---|---|---|
| Does PIPD apply? | Use PIPD for pre-execution engineering of new systems/services/libraries, Skill/Plugin, Agent Harness, AI platform, brownfield migration, provider/tool changes, or any change needing traceable admission/evidence. | §2 | If task is purely explanatory or already covered by a current admitted WorkOrder/ECP, do not recompile a new lifecycle unnecessarily. |
| What state am I in? | Read canonical state + claim ceiling; do not infer from filenames or self-PASS text. | §3 + §8 + DOC-01 | Missing/stale state identity → fail closed. |
| What is my entry path? | Choose exactly one of eight quickstart paths. | §6 | First legal action must be identified before work continues. |
| What must a human read? | Router → Constitution → applicable PI/PD/Profile → Handoff → Conformance/Tooling as required. | §4.1 | Do not skip canonical owner. |
| What must an AI read? | Phase A global/read-only discovery → Phase B nearest-scope before action. | §4.2 | No first mutation before instructions + subject/hash/currentness + WO/ECP + permission + ExecutionAdmission. |
| What must a machine read? | Exact `.pipd` order begins at `lock/standard.lock.json` and ends at evidence/conformance. | §4.3 | Missing exact stage/path is a replay failure. |
| Can I mutate yet? | Only a matching, current `ExecutionAdmission=ADMIT` can authorize first mutation. | §12 / DOC-05 | `PI_READY`, `PREDEV_READY`, ECP, TQAEP, CI green, tool success are insufficient. |
| Which technology truth should I use? | Layer A = 22 canonical CAND; Layer B = 130 named donor/workflow identities; Layer C = project TechnologyAdmission instances. | §9–11 + App-B | DOC-00 never rewrites DOC-02 technology truth. |
| What if something drifted? | Re-enter via Quickstart 8; use affected-only invalidation and typed currentness/TT/CR. | §6.8 + §14 + §22–23 | No silent reuse of stale evidence/admission. |

**Eight entry paths:** `QS-01 Brand-new` · `QS-02 Existing PI` · `QS-03 PREDEV Binding` · `QS-04 Brownfield` · `QS-05 Skill/Plugin` · `QS-06 Agent Harness` · `QS-07 Vertical Slice` · `QS-08 Change/Drift Re-entry`.

# 0｜Artifact Identity, Authority, Lineage & Claim Boundary

## 0.1 Artifact role and version

This is the r2 high-retention repair of the r1 DOC-00 artifact. Its version is a DOC-specific materialization version and does not impersonate or supersede `PIPD-LIFECYCLE-SPEC@1.1.0`. The canonical standard and repaired blueprint remain upstream semantic authorities.

## 0.2 Repair controller

The r1 audit reported `3 BLOCKER / 9 MAJOR / 4 MODERATE` findings and explicitly required `HIGH_RETENTION_PATCH_NO_ARCHITECTURE_RESET`. This r2 therefore preserves r1 sections whose lifecycle/ownership logic audited as materially sound, while rebuilding denominator, quickstart, machine bootstrap, technology routing, source coverage, currentness, self-conformance, typed failure namespaces, and packaging identity.

## 0.3 Authority rule

Current patch instruction controls this delivery. For PIPD semantics: A1 repaired blueprint → A2 canonical standard → A3 repaired skeleton → A4 design history. The AUDIT is the repair controller for proven r1 defects. Web/currentness remains SUPPORT: it may update version/status/license/security/compatibility evidence but cannot silently change canonical terminal disposition or writer ownership.

## 0.4 Claim namespace

`FOREIGN_GRP_MOUNT_STATE_TOKEN` is removed. It is not a PIPD lifecycle/claim token. DOC-00 uses only PIPD-defined lifecycle/claim semantics plus the artifact-local namespaced status `DOC00_R2_FULL_SUBSTANTIVE_BODY_MATERIALIZED`.

## 0.5 Honest ceiling

This artifact is not target-repo-bound and provides no evidence that any named technology is installed, bound, enabled, executed, verified, qualified, released, human-ratified, independently accepted, or production-verified.

# 1｜Mission, Position & Non-Goals

PIPD exists to prevent semantic loss between intent and authorized implementation. DOC-00 exists to prevent a second class of loss: **navigation loss**—operators opening the wrong artifact, confusing planning with permission, reading a projection as authority, or starting implementation because a package looks complete.

DOC-00 therefore owns the package/document map, read order, bootstrap procedure, operator routing, state-readback projection, first-use quickstarts, and anti-pattern warnings. It reads lifecycle/claim truth from DOC-01, PI/TechnologyAdmission truth from DOC-02, PD/currentness/ECP/TQAEP truth from DOC-03, evidence truth from DOC-04, handoff/admission truth from DOC-05, profile truth from DOC-06, conformance truth from DOC-07, AI adapter/read-order truth from DOC-08, and CI/release/tooling truth from DOC-09.

Its non-goal is equally important: DOC-00 must never become the second writer for any of those domains. If a summary here appears to disagree with its canonical owner, the owner wins and the mismatch becomes a conflict/drift item; operators do not repair it by choosing whichever text is more convenient.

# 2｜Applicability & Complexity Governance Entry

PIPD applies when a change needs a pre-execution engineering contract: a new system/service/library, a meaningful feature, an AI-enabled platform, a Skill/Plugin, an Agent Harness, a brownfield modernization/migration, provider replacement, a high-risk operational change, or a custom target whose implementation must be traceable from intent through admission and evidence.

PIPD is not required merely to answer a conceptual question or to perform a previously admitted local action whose governing WorkOrder/ECP/permission/evidence contract is already current. Even then, the operator must not use this exception to bypass a required admission or change-control edge.

## 2.1 Weight profiles

- **LITE** — low-risk, isolated, reversible work. It may reduce documentation weight, but retains requirements/acceptance, permission boundary, rollback, evidence/claim separation, and no-first-mutation-before-admission.
- **STANDARD** — normal systems, services, libraries and agent applications. Uses the standard contract set with risk-appropriate assurance.
- **ASSURED** — high-risk, high-permission, regulated, physical, financial, identity/security-sensitive, or harness-level work. Adds stronger SoD, threat model, provenance/attestation, adversarial testing, containment, rollback drill, repeatable qualification and human gates where required.

## 2.2 Target profiles

- **SYSTEM** — conventional product/service/library/system engineering.
- **SKILL_PLUGIN** — requires explicit trigger/non-trigger, I/O, tools, permissions, dependencies, secrets/network, side effects, host boundary, compatibility, negative examples, disable/uninstall and residue contracts.
- **AGENT_HARNESS** — requires agent identity, loop, tool registry, context/state/memory, hooks, permission, handoff, guardrails, eval, observability, recovery, human escalation, interop and provider-neutral seams.
- **CUSTOM** — allowed only with an explicit extension that preserves core invariants.
- **Brownfield Migration specialization** — overlays existing-system discovery, shadow/pilot/parity, compatibility, rollback, provider exit and residue closure; it does not grant permission to mutate merely because the system already exists.

## 2.3 Reasoned N/A

A field or package may be N/A only when its canonical owner permits conditional applicability and the record states the target/profile reason. N/A cannot erase universal invariants such as authority separation, claim honesty, permission/admission, rollback for effectful actions, evidence identity, or source/currentness integrity.

# 3｜One Lifecycle — Operator Mental Model

The lifecycle is one chain; PI and PD are not two independent development methods.

```text
Intent / Need / Existing System
        ↓
Pre-Implementation (stable WHAT / WHY / architecture / requirements / acceptance)
        ↓
PI_READY
        ↓
Read-only RepoContext / Environment Binding
        ↓
Pre-Dev (late-bound repo/runtime/provider/version/environment/currentness + execution preparation)
        ↓
PREDEV_READY
        ↓
Execution Admission
        ↓
EXECUTION_ADMITTED
        ↓
Implementation / First Authorized Mutation
        ↓
Evidence Return
        ↓
Verification → Qualification → Release → Production Verification
```

### 3.1 Canonical state ladder

| State | Meaning | Normal next transition |
|---|---|---|
| `DRAFT` | Initial subject exists; contracts not compiled | `PI_COMPILING` |
| `PI_COMPILING` | Pre-Implementation contracts being compiled | `PI_READY` |
| `PI_READY` | Stable WHAT/WHY/architecture/requirements/acceptance compiled for target scope | `PREDEV_BINDING` |
| `PREDEV_BINDING` | Read-only repo/environment/provider/currentness binding | `PREDEV_READY` |
| `PREDEV_READY` | Pre-execution engineering complete for bound target; no first mutation yet | `EXECUTION_ADMISSION_PENDING` |
| `EXECUTION_ADMISSION_PENDING` | Receiver/permission/effect/rollback/evidence decision pending | `EXECUTION_ADMITTED or HOLD/DENY-equivalent decision record` |
| `EXECUTION_ADMITTED` | Bounded execution explicitly authorized | `IMPLEMENTING` |
| `IMPLEMENTING` | Authorized mutation underway | `IMPLEMENTED` |
| `IMPLEMENTED` | Implementation materialized; not yet verification truth | `VERIFYING` |
| `VERIFYING` | Subject-bound verification executing | `VERIFIED` |
| `VERIFIED` | Declared verification passed with required evidence | `QUALIFIED` |
| `QUALIFIED` | Qualification criteria passed | `RELEASED` |
| `RELEASED` | Release decision/materialization complete | `PRODUCTION_VERIFIED` |
| `PRODUCTION_VERIFIED` | Production evidence supports declared production state | `terminal/current until change invalidation` |

Side states are `HOLD`, `TEMP_CLOSED`, `REWORK_REQUIRED`, `REJECTED`, `SUPERSEDED`, `INVALIDATED`. They are typed truth states, not prose decorations. A side state blocks or redirects only the affected scope unless the canonical dependency graph requires wider invalidation.

### 3.2 Promotion rule

A state promotion is legal only when the canonical writer can demonstrate the required artifacts, typed fields, owner references, dependency closure, gates, zero blocking TT for the promoted scope, zero stale blocking dependency, applicable permission/admission, and subject/version/hash-bound evidence. Prose such as “ready” or a green third-party tool is not a promotion mechanism.

### 3.3 The decisive boundaries

- `PI_READY` means the stable design contract for the applicable scope is complete; it is not repo-bound and does not authorize execution.
- `PREDEV_READY` means pre-execution engineering for the bound target is complete; it is still not authorization for first mutation.
- `EXECUTION_ADMITTED` is the first state that authorizes bounded execution according to its exact admission scope.
- `IMPLEMENTED` says materialization happened; it does not say verification passed.
- `VERIFIED`, `QUALIFIED`, `RELEASED`, and `PRODUCTION_VERIFIED` each require their own evidence and authority.

# 4｜Read Order — Human, AI & Tool/Machine

## 4.1 Human order

`Router → Constitution → applicable PI / PD / Profile → Handoff → Conformance / Tooling as required`.
1. DOC-00 identifies subject, applicability, entry path, current state and next owner.
2. DOC-01 resolves authority/state/claim/SoD/invalidation.
3. DOC-06 resolves weight/target profile.
4. DOC-02 owns PI contracts and TechnologyAdmission.
5. DOC-03 owns RepoContext/currentness/S2E/WorkOrder/ECP/TQAEP.
6. DOC-04/07 own trace/evidence and tests/oracles.
7. DOC-05 owns receiver acceptance and ExecutionAdmission.
8. DOC-08/09 own AI consumption and CI/release/runbook/tooling projections.

## 4.2 AI/LLM two-phase order

**Phase A — Global / Read-Only Discovery**
1. Read canonical Lifecycle Constitution and manifest.
2. Resolve standard/profile version and target/weight profile.
3. Discover repo/workspace instructions read-only (`AGENTS.md`, nested instructions, policy files, package/build metadata).
4. Determine instruction applicability to intended target path/surface.
5. Read applicable PI package(s) and frozen handoff refs.
6. Read applicable PD package(s) and RepoContext binding.

**Phase B — Nearest-Scope Action Preparation**
7. Before any command/write/effect, read the nearest applicable nested instructions.
8. Resolve conflict: PIPD authority owns lifecycle semantics; repo-local instructions own local mechanics inside allowed scope; neither grants external authority.
9. Validate subject/version/hash/currentness, WorkOrder/ECP, permission/approval, rollback and evidence return.
10. Only an `EXECUTION_ADMITTED` subject may perform first authorized mutation/effect.

Unreadable applicable instruction surface → affected repo mutation is fail-closed, never guessed.

## 4.3 Exact tool/machine bootstrap order

The canonical replay order is exact and additive; a generic object list is non-conformant:

```text
MR-01  .pipd/lock/standard.lock.json
MR-02  .pipd/project/manifest.json
MR-03  .pipd/generated/schemas/** + .pipd/generated/registry/**
MR-04  .pipd/project/package-index
MR-05  .pipd/project/pi/** + .pipd/project/pd/** + applicable referenced package objects
MR-06  .pipd/policies/** + .pipd/support/currentness/** + .pipd/project/execution/**
MR-07  .pipd/project/evidence/** + .pipd/conformance/**
```

| Stage | Exact path/object | Required readback before advancing |
|---|---|---|
| `MR-01` | `.pipd/lock/standard.lock.json` | standard_id/version/hash/namespace/source_path/distribution manifest ref valid |
| `MR-02` | `.pipd/project/manifest.json` | project_id/subject/profile/lifecycle/object/control refs valid |
| `MR-03` | `.pipd/generated/schemas/** + .pipd/generated/registry/**` | schema/registry IDs resolvable; canonical 22 and project integration registries not conflated |
| `MR-04` | `.pipd/project/package-index` | package index subject/hash/dependency/state refs valid |
| `MR-05` | `.pipd/project/pi/** + .pipd/project/pd/** + applicable referenced package objects` | applicable PI/PD/execution objects selected by subject/slice; no all-packages stuffing |
| `MR-06` | `.pipd/policies/** + .pipd/support/currentness/** + .pipd/project/execution/**` | permission/change/degrade + currentness + ExecutionAdmission refs current |
| `MR-07` | `.pipd/project/evidence/** + .pipd/conformance/**` | evidence/conformance refs subject/version/hash/environment-bound and non-stale |

After MR-07, the machine resolves canonical state, claim ceiling, next legal transition, permission/effect boundary, and evidence return. No stage may be skipped because a later file happens to exist.
# 5｜Document Responsibility Matrix / Package Index

This matrix is DOC-00’s own canonical writer responsibility. It assigns each normative responsibility to one document only; other documents may reference or project it.

| doc_id | external_name | archetype | canonical_responsibility | canonical_owner | reads | writes | primary_consumers | entry_condition | main_outputs | state/gate relevance | non_goal | cross_document_dependencies | when_operator_should_open_it |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| DOC-00 | Navigation / Operator Entry | Navigation | Read order, bootstrap, package routing, state readback, Document Responsibility Matrix / package index | PIPD DOC-00 canonical writer | A1/A2/A3/A4 + canonical readbacks | Operator projections, navigation/index only | Human, AI, tooling, package receivers | candidate subject/task exists; PIPD applicability may be unresolved | Routing decision, package index, readback projection | All states; no state mutation authority | Does not own lifecycle/technology/evidence/handoff normative truth | DOC-01..09 | First entry, restart, ambiguity, package selection |
| DOC-01 | Normative Constitution / State & Authority | Constitution | Authority, identity, lifecycle states, claims, SoD, profile binding, change/invalidation | DOC-01 canonical writer | Standard + authority inputs | Normative state/authority/change records | All PIPD docs and operators | DOC-00 routing complete | Canonical lifecycle/authority rules | Defines state/gate truth | No repo implementation detail | DOC-00, DOC-02..09 | Any authority/state/claim/profile conflict |
| DOC-02 | Contract Compiler Specification | Compiler | PI 18 areas, atomic REQ, Search-Before-Build, TechnologyAdmission, PI_READY | DOC-02 canonical writer | Intent/product/architecture/source set | Atomic PI contracts and TechnologyAdmission records | DOC-03, project planners | Applicable scope/profile selected | PI contract set; PI_READY evidence | PI_READY gate | No runtime late-binding | DOC-01, DOC-03, DOC-04 | Compile stable WHAT/WHY/architecture into executable design contracts |
| DOC-03 | Environment-Binding / Execution-Preparation | Pre-Dev Binder | PD 10 blocks, RepoContext, currentness, S2E, Seed/WO, ECP/TQAEP, PREDEV_READY | DOC-03 canonical writer | Frozen PI refs + read-only environment facts | Bound execution-preparation records | DOC-05, execution receiver | PI_READY and repo/environment readable | PREDEV package, WO/ECP/TQAEP refs | PREDEV_READY | No semantic re-adjudication of frozen PI | DOC-01/02/04/05/06 | Bind a ready design to real repo/runtime/provider/environment |
| DOC-04 | Traceability / Assurance Data Contract | Trace/Evidence | REQ→SPEC→ACC→VER→EVD→DEL→GATE; evidence identity/freshness | DOC-04 canonical writer | Requirements, specs, tests, evidence metadata | Trace graph, evidence contracts | DOC-05/07/09, assurance | Typed subject/version/hash available | Trace/Evidence records | Verification/qualification support | Cannot self-qualify or grant release | DOC-02/03/07/09 | Trace, evidence, freshness, oracle questions |
| DOC-05 | Receiver / Permission / Admission Contract | Admission | Rejectable handoff, permission/effect, ADMIT/HOLD/DENY, rollback/evidence return | DOC-05 canonical writer | PREDEV_READY package + receiver/permission facts | ExecutionAdmission and receiver decision | Execution receiver, operators | PREDEV_READY + receiver can validate | ADMIT/HOLD/DENY receipt | EXECUTION_ADMITTED gate | ECP cannot grant authority; sender-ready not receiver-accepted | DOC-03/04/07 | Before first mutation or when receiver NACKs |
| DOC-06 | Profile / Applicability / Complexity Governance | Profile | LITE/STANDARD/ASSURED and SYSTEM/SKILL_PLUGIN/AGENT_HARNESS/CUSTOM; Brownfield specialization | DOC-06 canonical writer | Target/risk/side-effect characteristics | Profile binding and justified N/A | DOC-02/03/05/07 | Target class/risk known | Profile contract | Affects required gates, never weakens core | Cannot erase baseline invariants | DOC-01/02/03 | Choose rigor/target profile and applicability |
| DOC-07 | Verification / Oracle / Fixture Reference | Conformance | Positive/negative/edge/adversarial/mutation/apparent-pass fixtures and oracles | DOC-07 canonical writer | SPEC/ACC/VER contracts | Conformance fixtures and oracle refs | Assurance/checkers | Subject/version/hash/environment bound | Test/fixture/oracle reference set | Supports VERIFYING/VERIFIED | Not a second semantic authority | DOC-02/04/05/06 | Design or execute conformance testing |
| DOC-08 | AI Consumption / Adapter Maturity | AI Adapter | Two-phase read order, nearest-scope instructions, progressive disclosure, adapter maturity | DOC-08 canonical writer | DOC-00/01 state + repo instructions | AI consumption adapters/read order | AI agents/tooling | Canonical docs discoverable | Adapter/read-order projections | No lifecycle promotion | Adapter is not SSOT | DOC-00/01/03/09 | AI/agent consumes PIPD safely |
| DOC-09 | CI / Release / Supply-Chain / Runbook / Tooling | Ops Tooling | Provider-neutral CI ABI, build-transfer-attest-verify, adoption waves, executable tooling/runbook contracts | DOC-09 canonical writer | Trace/evidence/admission/release inputs | CI/tool/runbook/release support records | Ops/release operators | Applicable profile + execution evidence | Tooling/runbook/release support artifacts | Supports release, does not define product acceptance alone | CI green ≠ product acceptance | DOC-04/05/07 | CI, supply chain, release preparation, runbook operations |

## 5.1 Contract areas are not project package counts

The canonical standard defines **18 PI contract areas (`PI-01..18`) and 10 PD binding blocks (`PD-01..10`)**. The current SWOF project corpus separately projects its work into `PI-PKG-00..17` and `PD-PKG-00..15`. These are different coordinate systems: the first is the standard’s semantic completeness contract; the second is a project package topology. DOC-00 routes between them but does not equate counts or infer that all project packages must finish before any independent vertical slice may execute.

### Canonical PI contract areas
| ID | Contract area |
|---|---|
| `PI-01` | Identity / Mission |
| `PI-02` | Scope / Non-Goals |
| `PI-03` | Source / Authority / Provenance |
| `PI-04` | Intent / User / Product Truth |
| `PI-05` | Atomic Requirements |
| `PI-06` | Canonical Object & State Model |
| `PI-07` | Architecture / Interface / ABI |
| `PI-08` | Technology Admission / Reuse / Search-Before-Build |
| `PI-09` | Security / Privacy / Rights / Risk |
| `PI-10` | SPEC |
| `PI-11` | Acceptance |
| `PI-12` | Verification / Oracle |
| `PI-13` | Evidence Expectation |
| `PI-14` | Deliverables |
| `PI-15` | Dependencies / Gates |
| `PI-16` | Failure / Rollback / Change |
| `PI-17` | Claim Ceiling / State Truth |
| `PI-18` | Pre-Dev Handoff |

### Canonical PD binding blocks
| ID | Binding block |
|---|---|
| `PD-01` | Frozen PI References |
| `PD-02` | Read-Only RepoContext / Environment Preflight |
| `PD-03` | Currentness / Compatibility |
| `PD-04` | Late-Bound Resolution |
| `PD-05` | S2E — Spec-to-Execution |
| `PD-06` | DEV ECP — Development Execution Control |
| `PD-07` | OPS ECP — Operations Readiness & Execution Control |
| `PD-08` | TQAEP — Test / Qualification / Acceptance / Evidence Plan |
| `PD-09` | Execution Handoff Manifest |
| `PD-10` | Execution Admission |

# 6｜First-Use Quickstart / Bootstrap — Eight Executable Paths

| ID | Path | Entry | Minimal read set | Procedure | Stop condition | Next owner | Forbidden shortcut |
|---|---|---|---|---|---|---|---|
| QS-01 | Brand-new design | Candidate subject/need exists; no accepted PI artifact | DOC-00 → DOC-01 → DOC-06 → DOC-02 | Create subject identity; choose profile; freeze authority/source; atomize requirements; run SBB; compile PI-01..18 | Stop at `PI_READY` only when PI gates close; no repo mutation | DOC-02 then DOC-03 | Do not read late-bound repo facts as a substitute for stable product/architecture decisions. |
| QS-02 | Existing PI artifact | An existing PI artifact is supplied or discovered | DOC-00 → DOC-01 → DOC-02 → DOC-04 | Verify artifact identity/version/hash/supersession; validate PI coverage/currentness of stable sources; reuse if canonical and current; reopen only affected PI gaps | If PI not valid/current, remain/re-enter `PI_COMPILING`; if valid, route to PD | DOC-02 or DOC-03 | Do not regenerate PI merely because a new executor/session starts. |
| QS-03 | PREDEV binding | Applicable scope already has valid `PI_READY` | DOC-00 → DOC-01 → DOC-03 → DOC-04/07 | Enter read-only RepoContext; resolve repo/provider/version/environment/currentness; compile S2E/Seed/WO/ECP/TQAEP/handoff | Stop at `PREDEV_READY`; first mutation still forbidden | DOC-05 | Do not treat `PREDEV_READY` or ECP as ExecutionAdmission. |
| QS-04 | Brownfield | Existing implementation/runtime/provider must be preserved, migrated or replaced | DOC-00 → DOC-06 Brownfield → DOC-02 delta PI → DOC-03 | Read current system/repo state; separate observed behavior from desired truth; compile migration delta; define parity/shadow/pilot/rollback/residue/provider-off; bind PD | Stop before each cutover wave until receiver accepts and admission exists | DOC-05 per wave | Do not let legacy behavior silently become Product Truth or waive rollback. |
| QS-05 | Skill/Plugin | Target is a Skill/Plugin or host capability package | DOC-00 → DOC-06 SKILL_PLUGIN → DOC-02 → DOC-08 | Define trigger/non-trigger, I/O, tool permissions, network/secrets, side effects, host boundary, tests, uninstall/residue; run SBB and admission | Stop before host registration/install/effect until PD + admission | DOC-03/05/08 | Skill instructions are not permissions or semantic authority. |
| QS-06 | Agent Harness | Target is harness/runtime/agent-control layer | DOC-00 → DOC-06 AGENT_HARNESS → DOC-02 → DOC-03/07 | Define loop, state/context/memory, tool registry, permission, interop, guardrails, recovery, human escalation, observability, adversarial tests; keep donor harnesses subordinate | Stop before target binding/effect until ASSURED obligations and admission close | DOC-03/05/07 | Harness/provider approval callbacks cannot replace PIPD admission. |
| QS-07 | Vertical slice | A dependency-closed slice is ready while unrelated packages are not | DOC-00 → package index → applicable DOC-02/03/04/05 | Resolve slice dependency graph; freeze shared writer/invalidation edges; compile only applicable PI/PD; obtain slice-specific WO/ECP/TQAEP/admission | Slice may implement once admitted; unrelated slices remain in their own states | DOC-05 for slice | Do not impose a global all-package waterfall. |
| QS-08 | Change / drift re-entry | Source, requirement, repo, provider, version, instruction, permission or evidence drift detected | DOC-00 → DOC-01 invalidation → affected canonical owner | Classify change; compare subject/version/hash; invalidate affected dependents only; refresh currentness; reopen PI if semantic delta, PD if environment/currentness delta; reissue evidence/admission as needed | Stop until all stale/invalidated blockers in affected scope close | DOC-01 then owning DOC | Do not reuse evidence/admission from a different subject/hash or silently absorb drift. |

These eight procedures are first-use routes, not examples. §18 scenarios remain examples only.
# 7｜Routing Rules

| Operator question | Open first | Escalate/also read | Decision rule |
|---|---|---|---|
| What state are we in / can we claim X? | DOC-01 | DOC-00 readback | Use canonical lifecycle/claim truth; never infer from filenames. |
| What must PI contain / which technology is selected? | DOC-02 | DOC-06 profile; DOC-04 trace | Compile PI-01..18 and TechnologyAdmission; terminal disposition only. |
| What repo/provider/version/environment are we binding? | DOC-03 | DOC-08 nearest instructions | Read-only RepoContext first; currentness/compatibility are late-bound. |
| What proves requirement/spec/test/evidence linkage? | DOC-04 | DOC-07 | Use subject/version/hash/environment-bound trace/evidence. |
| Can we execute the first mutation? | DOC-05 | DOC-03 ECP/TQAEP + DOC-01 state | Only matching ExecutionAdmission can answer yes. |
| How much rigor / which target profile? | DOC-06 | DOC-01 | Profile may add obligations, never erase core invariants. |
| How do we test/verify adversarially? | DOC-07 | DOC-04 | Use typed fixtures/oracles; apparent-pass is a test case. |
| How should an AI agent read this repo/package? | DOC-08 | DOC-00/01/03 | Two-phase read order + nearest-scope instruction resolution. |
| How do CI, supply chain, runbooks or release tooling fit? | DOC-09 | DOC-04/05/07 | CI/tool success is support evidence, not product acceptance. |

A missing canonical writer is not an invitation for DOC-00 to author one. It is a scoped gap: fail closed, record TT/CR as required, and route to the owner.

# 8｜Lifecycle State Readback Contract

DOC-00 owns the operator projection below, not the underlying state schema. Values must be read from canonical owner records.

```yaml
standard_id: PIPD-LIFECYCLE-SPEC
standard_version: "1.1.0"
subject_id: SWOF-F/EXAMPLE-SLICE-01
subject_version: "design-v7"
lifecycle_state: PREDEV_READY
projection_state: DOC00_OPERATOR_READBACK_CURRENT
decision_state: WAITING_EXECUTION_ADMISSION
degrade_state: NORMAL
claim_ceiling: PRE_EXECUTION_ENGINEERING_COMPLETE
weight_profile: STANDARD
target_profile: SYSTEM
applicable_pi_packages: [PI-PKG-00, PI-PKG-02, PI-PKG-03, PI-PKG-04]
applicable_pd_packages: [PD-PKG-00, PD-PKG-01, PD-PKG-03, PD-PKG-04, PD-PKG-08, PD-PKG-13]
current_slice: SLICE-API-01
canonical_owner_refs: [DOC-01, DOC-02, DOC-03, DOC-04, DOC-05]
work_order_refs: [WO-SLICE-API-01-v3]
ecp_refs: [DEV-ECP-SLICE-API-01-v2]
tqaep_refs: [TQAEP-SLICE-API-01-v2]
execution_admission_ref: null
missing_gates: [EXECUTION_ADMISSION]
stale_refs: []
open_tt: []
open_cr: []
next_legal_transition: EXECUTION_ADMISSION_PENDING
forbidden_transitions: [IMPLEMENTING, IMPLEMENTED, VERIFIED, QUALIFIED, RELEASED, PRODUCTION_VERIFIED]
```

A reader seeing this record must conclude **do not mutate**. The existence of WO/ECP/TQAEP and `PREDEV_READY` is preparation, not permission.

# 9｜Technology / Tool / OSS / Workflow Operator Routing — Three-Layer Model

DOC-00 does not write TechnologyAdmission truth. It exposes three routed layers:
- **Layer A:** 22 canonical CAND identities/dispositions from the repaired skeleton / DOC-02 baseline.
- **Layer B:** 130 named donor/workflow identities preserved in Appendix B; each row retains source identity, treatment, owner and exit.
- **Layer C:** project-specific `TechnologyAdmissionRecord` instances; this artifact provides only a pointer/readback schema and makes no target-bound claim.

## 9.1 Canonical terminal disposition enum
`ADOPT`, `ADOPT_WITH_WRAPPER`, `ADOPT_WITH_TRANSLATION`, `SELECTED_REUSE`, `SELECTED_CONFIGURE`, `SELECTED_COMPOSE`, `SELECTED_WRAP`, `SELECTED_ADAPT`, `SELECTED_TRANSLATE`, `SELECTED_EXTEND`, `ROUTE_OUT`, `EVAL_ONLY`, `REFERENCE`, `BUILD_MINIMAL`, `REJECT`, `QUARANTINE`, `HOLD_WITH_TT`.

## 9.2 Mandatory Search-Before-Build — 11 exact stages
| Step | Canonical stage | Operator predicate |
|---:|---|---|
| 1 | `NEED / MEASURABLE CAPABILITY` | Need is expressed as measurable capability before naming a brand. |
| 2 | `INTERNAL REUSE SEARCH` | Search existing PIPD/project/platform capability first; record fit/gap. |
| 3 | `EXTERNAL SCOUT when internal fit is insufficient` | Scout official/credible external candidates only when internal fit is insufficient. |
| 4 | `CANDIDATE NORMALIZATION BY CAPABILITY SLOT` | Normalize candidates into the same capability slot before comparison. |
| 5 | `GAP / FIT EVALUATION` | Compare required capability, gaps, adoption burden and rejected set. |
| 6 | `SECURITY / LICENSE / MATURITY / MAINTENANCE / SUPPLY-CHAIN REVIEW` | Review security, license, maturity, maintenance and supply-chain provenance. |
| 7 | `PORTABILITY / TESTABILITY / BROWNFIELD / EXIT REVIEW` | Review portability, testability, brownfield fit, rollback and provider exit. |
| 8 | `TERMINAL DISPOSITION` | Choose exactly one canonical terminal disposition; no Maybe/T&#66;D/Choose later. |
| 9 | `VERSION/CURRENTNESS PIN POLICY` | Define observed version/pin, checked_at, TTL and recheck trigger; late-bind exact target pin at PD where required. |
| 10 | `ADAPTER / TRANSLATION / WRAPPER CONTRACT` | Define PIPD-owned seam; donor cannot own product truth/lifecycle/permission/release authority. |
| 11 | `BUILD_MINIMAL only when NO_FIT or material uncovered gap is recorded` | `BUILD_MINIMAL` is legal only after recorded `NO_FIT` / material uncovered gap. |

## 9.3 Special terminal rules
- `BUILD_MINIMAL` MUST have non-empty `no_fit_reason` plus the failed/rejected candidate gap set.
- `HOLD_WITH_TT` MUST name the typed TT, owner, close criteria, stale/currentness trigger if applicable, and MUST NOT silently become a runtime dependency.
- `REFERENCE`, `EVAL_ONLY`, `QUARANTINE`, and `REJECT` cannot silently become runtime dependencies.
- Web currentness may update version/status/security/license/compatibility support facts; changing terminal disposition requires canonical DOC-02 TechnologyAdmission/CR with affected-only invalidation.

## 9.4 Layer-A 22 canonical candidate routing index
| ID | Canonical name | Capability slot | Terminal disposition | Canonical record ref | Currentness ref | Materialize stage | Bind stage | Activation authority | Test route | Provider exit | Status |
|---|---|---|---|---|---|---|---|---|---|---|---|
| CAND-01 | GPT-5.6 Sol | Model / reasoning executor | ADOPT | DOC-02::TechnologyAdmissionRecord::CAND-01 | DOC-00-r2::CUR::CAND-01 | PD after currentness/license/security check | PD exact target/host/provider binding | only after ExecutionAdmission if effectful | functional + negative + boundary + permission (if effectful) + uninstall/provider-off; oracle bound to subject/version/hash | rollback/uninstall/provider-off + residue/readback when materialized | RESOLVED |
| CAND-02 | OpenAI Codex / Agents SDK harness patterns | Coding/agent harness | ADOPT_WITH_WRAPPER | DOC-02::TechnologyAdmissionRecord::CAND-02 | DOC-00-r2::CUR::CAND-02 | PD after currentness/license/security check | PD exact target/host/provider binding | only after ExecutionAdmission if effectful | functional + negative + boundary + permission (if effectful) + uninstall/provider-off; oracle bound to subject/version/hash | rollback/uninstall/provider-off + residue/readback when materialized | RESOLVED |
| CAND-03 | AGENTS.md | Repo instruction projection | ADOPT_WITH_TRANSLATION | DOC-02::TechnologyAdmissionRecord::CAND-03 | DOC-00-r2::CUR::CAND-03 | PD after currentness/license/security check | PD exact target/host/provider binding | only after ExecutionAdmission if effectful | functional + negative + boundary + permission (if effectful) + uninstall/provider-off; oracle bound to subject/version/hash | rollback/uninstall/provider-off + residue/readback when materialized | RESOLVED |
| CAND-04 | OpenSpec | Spec/workflow donor | SELECTED_TRANSLATE | DOC-02::TechnologyAdmissionRecord::CAND-04 | DOC-00-r2::CUR::CAND-04 | PD after currentness/license/security check | PD exact target/host/provider binding | only after ExecutionAdmission if effectful | functional + negative + boundary + permission (if effectful) + uninstall/provider-off; oracle bound to subject/version/hash | rollback/uninstall/provider-off + residue/readback when materialized | RESOLVED |
| CAND-05 | GitHub Spec Kit | Spec/workflow donor | SELECTED_WRAP | DOC-02::TechnologyAdmissionRecord::CAND-05 | DOC-00-r2::CUR::CAND-05 | PD after currentness/license/security check | PD exact target/host/provider binding | only after ExecutionAdmission if effectful | functional + negative + boundary + permission (if effectful) + uninstall/provider-off; oracle bound to subject/version/hash | rollback/uninstall/provider-off + residue/readback when materialized | RESOLVED |
| CAND-06 | Model Context Protocol (MCP) | Tool/context protocol | SELECTED_TRANSLATE | DOC-02::TechnologyAdmissionRecord::CAND-06 | DOC-00-r2::CUR::CAND-06 | PD after currentness/license/security check | PD exact target/host/provider binding | only after ExecutionAdmission if effectful | functional + negative + boundary + permission (if effectful) + uninstall/provider-off; oracle bound to subject/version/hash | rollback/uninstall/provider-off + residue/readback when materialized | RESOLVED |
| CAND-07 | A2A Protocol | Agent interop protocol | SELECTED_TRANSLATE | DOC-02::TechnologyAdmissionRecord::CAND-07 | DOC-00-r2::CUR::CAND-07 | PD after currentness/license/security check | PD exact target/host/provider binding | only after ExecutionAdmission if effectful | functional + negative + boundary + permission (if effectful) + uninstall/provider-off; oracle bound to subject/version/hash | rollback/uninstall/provider-off + residue/readback when materialized | RESOLVED |
| CAND-08 | OpenTelemetry GenAI semantic conventions | Telemetry semantics | SELECTED_TRANSLATE | DOC-02::TechnologyAdmissionRecord::CAND-08 | DOC-00-r2::CUR::CAND-08 | PD after currentness/license/security check | PD exact target/host/provider binding | only after ExecutionAdmission if effectful | functional + negative + boundary + permission (if effectful) + uninstall/provider-off; oracle bound to subject/version/hash | rollback/uninstall/provider-off + residue/readback when materialized | RESOLVED |
| CAND-09 | Pi Coding Agent / pi-mono | Coding harness donor | EVAL_ONLY | DOC-02::TechnologyAdmissionRecord::CAND-09 | DOC-00-r2::CUR::CAND-09 | PD sandbox evaluation | isolated/non-authoritative binding | no production/effect authority | functional + negative + boundary + permission (if effectful) + uninstall/provider-off; oracle bound to subject/version/hash | rollback/uninstall/provider-off + residue/readback when materialized | RESOLVED |
| CAND-10 | Superpowers | Skill/workflow donor | SELECTED_TRANSLATE | DOC-02::TechnologyAdmissionRecord::CAND-10 | DOC-00-r2::CUR::CAND-10 | PD after currentness/license/security check | PD exact target/host/provider binding | only after ExecutionAdmission if effectful | functional + negative + boundary + permission (if effectful) + uninstall/provider-off; oracle bound to subject/version/hash | rollback/uninstall/provider-off + residue/readback when materialized | RESOLVED |
| CAND-11 | gstack | Engineering workflow donor | REFERENCE | DOC-02::TechnologyAdmissionRecord::CAND-11 | DOC-00-r2::CUR::CAND-11 | N/A unless CR promotes | N/A unless CR promotes | N/A unless CR promotes | functional + negative + boundary + permission (if effectful) + uninstall/provider-off; oracle bound to subject/version/hash | rollback/uninstall/provider-off + residue/readback when materialized | RESOLVED |
| CAND-12 | DeepSeek Harness | Harness donor | EVAL_ONLY | DOC-02::TechnologyAdmissionRecord::CAND-12 | DOC-00-r2::CUR::CAND-12 | PD sandbox evaluation | isolated/non-authoritative binding | no production/effect authority | functional + negative + boundary + permission (if effectful) + uninstall/provider-off; oracle bound to subject/version/hash | rollback/uninstall/provider-off + residue/readback when materialized | RESOLVED |
| CAND-13 | Open GSD / gsd-core | Planning/execution workflow donor | REFERENCE | DOC-02::TechnologyAdmissionRecord::CAND-13 | DOC-00-r2::CUR::CAND-13 | N/A unless CR promotes | N/A unless CR promotes | N/A unless CR promotes | functional + negative + boundary + permission (if effectful) + uninstall/provider-off; oracle bound to subject/version/hash | rollback/uninstall/provider-off + residue/readback when materialized | RESOLVED |
| CAND-14 | legacy gsd-build / get-shit-done | Legacy workflow | REJECT | DOC-02::TechnologyAdmissionRecord::CAND-14 | DOC-00-r2::CUR::CAND-14 | N/A unless CR promotes | N/A unless CR promotes | N/A unless CR promotes | functional + negative + boundary + permission (if effectful) + uninstall/provider-off; oracle bound to subject/version/hash | rollback/uninstall/provider-off + residue/readback when materialized | RESOLVED |
| CAND-15 | mattpocock/skills | Skill packaging/workflow donor | SELECTED_TRANSLATE | DOC-02::TechnologyAdmissionRecord::CAND-15 | DOC-00-r2::CUR::CAND-15 | PD after currentness/license/security check | PD exact target/host/provider binding | only after ExecutionAdmission if effectful | functional + negative + boundary + permission (if effectful) + uninstall/provider-off; oracle bound to subject/version/hash | rollback/uninstall/provider-off + residue/readback when materialized | RESOLVED |
| CAND-16 | Hugging Face Agent Skills | Skill ecosystem donor | SELECTED_TRANSLATE | DOC-02::TechnologyAdmissionRecord::CAND-16 | DOC-00-r2::CUR::CAND-16 | PD after currentness/license/security check | PD exact target/host/provider binding | only after ExecutionAdmission if effectful | functional + negative + boundary + permission (if effectful) + uninstall/provider-off; oracle bound to subject/version/hash | rollback/uninstall/provider-off + residue/readback when materialized | RESOLVED |
| CAND-17 | AG-UI | Agent-user interaction protocol | SELECTED_TRANSLATE | DOC-02::TechnologyAdmissionRecord::CAND-17 | DOC-00-r2::CUR::CAND-17 | PD after currentness/license/security check | PD exact target/host/provider binding | only after ExecutionAdmission if effectful | functional + negative + boundary + permission (if effectful) + uninstall/provider-off; oracle bound to subject/version/hash | rollback/uninstall/provider-off + residue/readback when materialized | RESOLVED |
| CAND-18 | NousResearch Hermes Agent | Agent harness donor | QUARANTINE | DOC-02::TechnologyAdmissionRecord::CAND-18 | DOC-00-r2::CUR::CAND-18 | N/A unless CR promotes | N/A unless CR promotes | N/A unless CR promotes | functional + negative + boundary + permission (if effectful) + uninstall/provider-off; oracle bound to subject/version/hash | rollback/uninstall/provider-off + residue/readback when materialized | RESOLVED |
| CAND-19 | Cordis | Harness/runtime research donor | REFERENCE | DOC-02::TechnologyAdmissionRecord::CAND-19 | DOC-00-r2::CUR::CAND-19 | N/A unless CR promotes | N/A unless CR promotes | N/A unless CR promotes | functional + negative + boundary + permission (if effectful) + uninstall/provider-off; oracle bound to subject/version/hash | rollback/uninstall/provider-off + residue/readback when materialized | RESOLVED |
| CAND-20 | LongHorizon-Harness research | Long-horizon research | REFERENCE | DOC-02::TechnologyAdmissionRecord::CAND-20 | DOC-00-r2::CUR::CAND-20 | N/A unless CR promotes | N/A unless CR promotes | N/A unless CR promotes | functional + negative + boundary + permission (if effectful) + uninstall/provider-off; oracle bound to subject/version/hash | rollback/uninstall/provider-off + residue/readback when materialized | RESOLVED |
| CAND-21 | Skill-Use benchmark | Benchmark/research | REFERENCE | DOC-02::TechnologyAdmissionRecord::CAND-21 | DOC-00-r2::CUR::CAND-21 | N/A unless CR promotes | N/A unless CR promotes | N/A unless CR promotes | functional + negative + boundary + permission (if effectful) + uninstall/provider-off; oracle bound to subject/version/hash | rollback/uninstall/provider-off + residue/readback when materialized | RESOLVED |
| CAND-22 | HarnessRisk benchmark | Harness-risk research | REFERENCE | DOC-02::TechnologyAdmissionRecord::CAND-22 | DOC-00-r2::CUR::CAND-22 | N/A unless CR promotes | N/A unless CR promotes | N/A unless CR promotes | functional + negative + boundary + permission (if effectful) + uninstall/provider-off; oracle bound to subject/version/hash | rollback/uninstall/provider-off + residue/readback when materialized | RESOLVED |

**Selection-state anti-forgery:** `DESIGN_SELECTED → MATERIALIZED → INSTALLED → BOUND → ENABLED → EXECUTED → VERIFIED → QUALIFIED → ACCEPTED → RELEASED → PRODUCTION_VERIFIED` is non-collapsible. r2 itself claims none of the runtime states for Layer-A technologies.
# 10｜TechnologyAdmission Read-Through Projection — Field-Compatible, Non-Authoritative

## 10.1 Canonical field identity
DOC-00 does not invent a reduced TechnologyAdmission schema. It preserves the exact field identities below and points each project record to DOC-02:

```yaml
candidate_id: <owned-by-DOC-02>
canonical_name: <owned-by-DOC-02>
capability_slot: <owned-by-DOC-02>
need_ref: <owned-by-DOC-02>
source_or_upstream: <owned-by-DOC-02>
observed_version_or_pin: <owned-by-DOC-02>
source_checked_at: <owned-by-DOC-02>
license: <owned-by-DOC-02>
maturity: <owned-by-DOC-02>
capabilities[]: []
disposition: <owned-by-DOC-02>
integration_mode: <owned-by-DOC-02>
security_risks[]: []
portability: <owned-by-DOC-02>
testability: <owned-by-DOC-02>
brownfield_fit: <owned-by-DOC-02>
currentness_ttl: <owned-by-DOC-02>
supply_chain_provenance: <owned-by-DOC-02>
provider_exit: <owned-by-DOC-02>
rollback_or_uninstall: <owned-by-DOC-02>
no_fit_reason: <owned-by-DOC-02>
anti_authority_rule: <owned-by-DOC-02>
portable_core_dependency: false
```

`BUILD_MINIMAL` and `HOLD_WITH_TT` special rules are in §9.3. Any field not displayed by a front-end projection remains required in the canonical DOC-02 record; omission from a UI/router cannot merge away its semantics.

## 10.2 Layer-C project TechnologyAdmission pointer/readback
```yaml
layer_c:
  target_bound: false
  registry_ref: .pipd/support/technology-admission/<project-registry>
  project_record_ref: .pipd/support/technology-admission/<candidate-id>.json
  subject_identity: {subject_id: null, subject_version: null, subject_sha256: null}
  canonical_owner: DOC-02
  terminal_disposition_ref: null
  currentness_ref: null
  runtime_state: DESIGN_ONLY_UNLESS_PROJECT_EVIDENCE_EXISTS
  forbidden_inference:
    - record_present_means_installed
    - selected_means_bound
    - tool_green_means_accepted
```

A project may use a different generated filename only if its `project-manifest` and schema-bound registry resolve the exact record. DOC-00 does not fabricate a target-specific record where no target binding exists.
# 11｜External Donor Translation / Layer-B Named Identity Firewall

The repaired skeleton requires identity-preserving treatment of **130 Layer-B donors/workflows**: `NOBJ 24 + ECP 48 + ADD 4 + MSC 15 + TQ-TECH 31 + Named Workflows 8`. They are all materialized in Appendix B with stable IDs and source-line provenance.

Rules:
1. A Layer-B identity remains discoverable even when Layer-A covers a similar capability.
2. Layer-B source disposition/truth is not silently promoted. PIPD treatment is a routing decision, not runtime adoption proof.
3. Detailed technology contracts remain in canonical owners; DOC-00 stores only compact routing/crosswalk information.
4. Donor semantics never override Product Truth, Canonical Plan IR, PIPD lifecycle, permission, acceptance or release authority.
5. Removal/replacement of a selected/materialized donor requires explicit crosswalk rationale, provider-off/residue where applicable, and CR when its canonical contract says so.
6. `required_layerB_ids - target_layerB_ids` MUST equal the empty set for r2 acceptance.

# 12｜ECP, TQAEP, Handoff & ExecutionAdmission Boundary

| Object | Purpose | What it may constrain/define | What it cannot do | Canonical route |
|---|---|---|---|---|
| DEV ECP | Development Execution Control Package | mutation scope, commands, files, budgets, rollback, evidence return | self-authorize first mutation | DOC-03 → DOC-05 |
| OPS ECP | Operations Execution Control Package | install/bind/deploy/migrate/operate side-effect scope and rollback | self-approve deployment/operation | DOC-03 → DOC-05 |
| TQAEP | Test / Qualification / Acceptance / Evidence Package | tests, fixtures, oracles, evidence, qualification gates | claim that tests/qualification already ran | DOC-03 + DOC-04/07 |
| Execution Handoff | Explicit sender→receiver package | subject, scope, refs, assumptions, receiver checks | imply receiver acceptance | DOC-05 |
| ExecutionAdmission | Separate permission/admission decision | ADMIT/HOLD/DENY scope, permission/effect boundary | retroactively legitimize earlier mutation | DOC-05 |

`TaskSpecSeed`, S2E output, WorkOrder and ECP are distinct identities. A WorkOrder cannot self-authorize; an ECP cannot self-approve; TQAEP cannot self-qualify. The first mutation becomes legal only after a matching ExecutionAdmission is current.

For effectful operations, execution truth follows `AUTHORIZED_ATTEMPT → PROVIDER_RESPONSE → OBSERVATION → READBACK → RECONCILIATION → WORLD_EFFECT_STATE`. `UNKNOWN_EFFECT`, `PARTIAL_EFFECT` and `CONFLICTING_EFFECT` remain unresolved until re-observation, compensation/reconciliation or bounded failure closure. Provider/API success is not world-effect truth.

# 13｜Vertical Slice, Concurrency & Adoption Waves

PIPD rejects a global waterfall lock. A vertical slice may progress when its own semantic dependency closure, shared-writer constraints, currentness, profile obligations, permission/effect contract and admission are complete. Unrelated packages may remain in earlier states.

Concurrency is blocked only when slices share a canonical writer that cannot safely accept parallel changes, share an invalidation edge whose outcome can stale the other slice, compete for a non-partitionable resource/permission, or depend on an unresolved cross-slice contract. Otherwise, independent slices can compile, bind, admit, implement and verify independently.

A practical adoption wave is: **Wave 0 control/readback → Wave 1 one reversible slice → Wave 2 repeated slices with parity/evidence → Wave 3 high-risk/ASSURED surfaces → Wave 4 broader provider/interop rollout → Wave 5 release/ops hardening**. Each wave preserves provider-off/rollback and evidence return; later wave success does not retroactively validate earlier evidence if subject/version/hash changed.

# 14｜Failure / Degrade / Recovery — Typed Namespace Separation

The columns below are intentionally separated. `lifecycle_state`, `decision`, `degrade_status`, and `claim_ceiling_effect` are different namespaces and MUST NOT be injected into one another.
| Condition | lifecycle_state | decision | degrade_status | claim_ceiling_effect | recovery | forbidden shortcut |
|---|---|---|---|---|---|---|
| Missing required source/anchor | unchanged | ABSTAIN | TEMP_CLOSED | NO_PROMOTION | Locate authoritative source/anchor; restore identity/hash; rerun owner decision | Infer semantics from lower authority. |
| Stale source/currentness | unchanged | HOLD | CURRENTNESS_STALE | NO_PROMOTION | Refresh official support; compare compatibility/security/license; invalidate affected evidence only | Continue on remembered latest version. |
| Authority conflict | unchanged | HOLD | AUTHORITY_CONFLICT | NO_PROMOTION | Route to canonical writer; apply precedence; record conflict | Silent merge. |
| Missing permission/approval | PREDEV_READY or current pre-effect state | DENY_OR_HOLD | BLOCKED_EXTERNAL | NOT_AUTHORIZED | Obtain valid scoped permission/approval and rerun admission | Treat ECP/UI confirmation as authority. |
| ECP exists, no admission | PREDEV_READY | WAITING_EXECUTION_ADMISSION | NORMAL | PRE_EXECUTION_ENGINEERING_COMPLETE | DOC-05 receiver/admission decision | Begin first mutation. |
| Source/hash drift | last honest lifecycle state | HOLD | INVALIDATED_AFFECTED_SCOPE | NO_REUSE_OF_STALE_EVIDENCE | Recompute identity; reverse-dependency impact; reverify affected scope | Reuse PASS/admission from old subject. |
| Validation failure | IMPLEMENTING/VERIFYING as applicable | REWORK_REQUIRED | VALIDATION_FAILED | NO_PROMOTION | Fix implementation/contract or controlled CR; rerun bound test | Lower threshold silently. |
| World effect unknown/partial/conflicting | current execution state | RECONCILE | WORLD_EFFECT_UNRESOLVED | NO_EFFECT_SUCCESS_CLAIM | Re-observe/readback/reconcile/compensate | Provider response = world success. |
| Provider unavailable | current state | HOLD | PROVIDER_UNAVAILABLE | NO_PROMOTION | Use pre-admitted fallback/provider-off route; rebind/revalidate | Unapproved substitution. |
| Receiver NACK | PREDEV_READY / ADMISSION_PENDING | NACK | HANDOFF_REJECTED | NOT_AUTHORIZED | Resolve NACK reasons; issue new handoff identity | Sender declares acceptance. |
| Open blocking TT | unchanged | HOLD | TT_BLOCKING | NO_PROMOTION | Close TT with evidence or canonical scope change | Hide gap in prose. |
| CR required | unchanged | WAITING_CR | CHANGE_PENDING | NO_PROMOTION_IF_GATE_RELEVANT | Process CR and affected-only invalidation | Change standard/selection inside DOC-00. |
# 15｜Common Errors / Anti-Patterns

| Anti-pattern | Correct interpretation |
|---|---|
| `document = execution` | False. A document can be complete while runtime is untouched. |
| `design selected = installed` | False. TechnologyAdmission is a design decision; installation is a later effectful state. |
| `ECP = permission` | False. ECP constrains execution; ExecutionAdmission authorizes bounded execution. |
| `PREDEV_READY = execution admitted` | False. PREDEV_READY precedes a separate admission decision. |
| `sender ready = receiver accepted` | False. Receiver validation may NACK/HOLD. |
| `adapter = authority` | False. Adapter/projection resolves to canonical writers. |
| `CI green = product acceptance` | False. CI is an evidence host; acceptance remains canonical requirement/gate truth. |
| `same filename = same artifact` | False. Subject/version/hash identity controls evidence and supersession. |
| `web newest = semantic authority` | False. Web currentness may update version/risk facts; semantic changes require canonical change control. |
| `all packages must finish before any slice starts` | False. Dependency-closed slices may advance independently. |
| `TQAEP = Independent PASS` | False. It defines testing/qualification/evidence work; execution and independent judgment are separate. |
| `local document complete = production complete` | False. Production truth is the end of an evidence-bearing lifecycle. |

# 16｜Glossary / Quick Reference
| Term | Canonical operator meaning |
|---|---|
| **PI / Pre-Implementation** | Stable pre-execution design contract: WHAT/WHY/architecture/requirements/acceptance, before repo/runtime late binding. |
| **PD / Pre-Dev** | Read-only binding and execution-preparation phase: repo/runtime/provider/version/environment/currentness, S2E, WorkOrder, ECP/TQAEP, handoff. |
| **PI_READY** | Design contract complete for applicable scope; not execution permission. |
| **PREDEV_READY** | Pre-execution engineering complete for bound scope; still not execution permission. |
| **ExecutionAdmission** | Separate receiver/permission/effect decision that may authorize first mutation. |
| **DEV ECP** | Development execution-control package. |
| **OPS ECP** | Operational/install/bind/deploy/migrate execution-control package. |
| **TQAEP** | Test / Qualification / Acceptance / Evidence Package. |
| **Canonical Writer** | Unique owner allowed to write a typed decision/object’s normative truth. |
| **Claim Ceiling** | Highest claim supported by current evidence. |
| **TT** | Scoped tracked unresolved item; never hidden by vague prose. |
| **CR** | Controlled change request for a decision/contract whose change must be explicit and impact-checked. |
| **RepoContext** | Read-only observed repository/environment context used in PD. |
| **TechnologyAdmission** | Canonical terminal design decision for a technology/capability slot plus landing/test/exit obligations. |
| **Search-Before-Build** | Mandatory decision process that searches/reuses/configures/composes/wraps/adapts/translates/extends before bespoke construction. |
| **Subject identity** | The subject/version/hash/environment tuple to which evidence, tests and admission apply. |
| **World effect** | Observed/reconciled external state, not merely provider/API success. |
| **Vertical slice** | Dependency-closed subset allowed to progress independently through the lifecycle. |

# 17｜Cross-Document Ownership & Navigation Index

| Responsibility | Canonical owner | DOC-00 behavior |
|---|---|---|
| Authority / lifecycle / claim / SoD / invalidation | DOC-01 | DOC-00 only displays readback. |
| PI contract areas / atomic requirements / TechnologyAdmission | DOC-02 | DOC-00 routes and displays terminal status. |
| RepoContext / currentness / late binding / S2E / WorkOrder / ECP / TQAEP / PREDEV_READY | DOC-03 | DOC-00 quickstarts only. |
| Trace / evidence identity / freshness / chain | DOC-04 | DOC-00 displays missing/stale refs. |
| Handoff / receiver decision / permission/effect / ExecutionAdmission | DOC-05 | DOC-00 warns before first mutation. |
| Weight/target profiles and complexity governance | DOC-06 | DOC-00 helps choose entry path. |
| Fixtures / oracles / conformance tests | DOC-07 | DOC-00 points to test route. |
| AI read order / adapter maturity | DOC-08 | DOC-00 contains first-level operator read order. |
| CI / release / supply chain / runbook / tooling | DOC-09 | DOC-00 routes operator to execution-support surfaces. |
| Document Responsibility Matrix / package index / front-door navigation | DOC-00 | This document is the canonical writer. |

# 18｜Operator Scenarios
## 18.1｜New system from DRAFT into PI
A new service has approved product intent but no implementation contract. DOC-00 routes to DOC-06 for STANDARD/SYSTEM profile, then DOC-02. The team compiles PI-01..18, atomizes requirements and resolves TechnologyAdmission. State may move DRAFT→PI_COMPILING→PI_READY only when the applicable gate closes. No repo mutation occurs during this scenario.
## 18.2｜PI_READY into PREDEV_BINDING
A slice is PI_READY. The operator opens DOC-03, discovers repo instructions and RepoContext read-only, resolves current dependencies/provider versions and compiles S2E/WorkOrder/ECP/TQAEP. Any attempt to edit a source file before admission is rejected even though the design is complete.
## 18.3｜Skill/Plugin target
A new repository skill selects SKILL_PLUGIN profile. Trigger/non-trigger, tools, permissions, host boundary, network/secrets, side effects, examples, disable/uninstall/residue are mandatory. The skill file itself cannot grant tool permission; effectful actions still need WorkOrder/ECP/admission.
## 18.4｜Agent Harness target
A harness uses AGENT_HARNESS + ASSURED. Its loop, tools, state/memory, permission, guardrails, human escalation, recovery, interop, observability and adversarial tests are explicit. A provider’s own approval callback cannot replace DOC-05 admission.
## 18.5｜Brownfield migration
An existing provider must be exited. PI fixes desired semantics and migration acceptance; PD reads current repo/runtime, provider contracts and residue. Shadow/pilot/parity and rollback are defined. Each cutover wave gets separate receiver acceptance/admission and post-effect reconciliation.
## 18.6｜Vertical slice starts before global completion
Slice A depends only on shared API schema X and its own service. Slice B/C packages remain in PI. Once X and Slice A dependency closure are stable, Slice A reaches PREDEV_READY and receives admission; it may implement without waiting for unrelated B/C, unless a shared writer/invalidation edge becomes active.
## 18.7｜ECP exists but no ExecutionAdmission
DEV-ECP lists files, commands, rollback and evidence. The state readback has `execution_admission_ref: null`. DOC-00’s answer is unambiguous: execution is forbidden; next route is DOC-05.
## 18.8｜Currentness stale
A pinned dependency is older than the project currentness threshold and a security/compatibility check is stale. The affected binding enters HOLD/TEMP_CLOSED; the operator refreshes official sources and reruns compatibility. Stable PI product semantics do not change automatically.
## 18.9｜Technology selected but not installed
MCP is `ADOPT_WITH_TRANSLATION` in DOC-02. No MCP server/client exists in the target. DOC-00 displays `DESIGN_SELECTED` only; installation/binding waits for PD and admission. The system cannot claim MCP integration from selection alone.
## 18.10｜Source/hash drift
A WorkOrder and verification receipt reference source hash H1, but the repo now hashes H2. The dependent admission/evidence becomes stale/invalid for the changed scope. Reverse-dependency impact is recomputed; unrelated evidence remains valid if its subject did not change.
## 18.11｜Sender ready, receiver NACK
The sender marks its handoff ready, but receiver detects a missing rollback command and stale credential scope. Receiver NACK/HOLD is authoritative for admission. The sender repairs the handoff and issues a new identity; it does not override the receiver.
## 18.12｜Web new version without canonical selection change
A tool publishes a new release after currentness research. DOC-00 may record the new version/risk fact, but the canonical terminal disposition and selected compatibility policy do not change silently. If adoption semantics must change, DOC-02 processes a TechnologyAdmission/CR and downstream evidence is impact-checked.

# 19｜Source Coverage — Full Scan Receipt + Clause-Level Substantive Ledger

## 19.1 File-level full-scan receipt
| ID | File | SHA-256 | Lines | Headings | Scan |
|---|---|---|---:|---:|---|
| `P0` | PIPD_DOC00_PRODUCTION_INSTRUCTION.txt | `1f707741519dc11a14a311e0406ed1737cfba2202940ba85841181d34c621ddb` | 1490 | 86 | FULL_UTF8_READ / NO_SAMPLING |
| `A1` | Pre-Implementation_and_Pre-Dev_Lifecycle_Specification_總藍圖.md | `9a8323e5237c1555a76d9a75f706e3552d79c192915cc782b76b211c7f27d527` | 2996 | 112 | FULL_UTF8_READ / NO_SAMPLING |
| `A2` | Pre-Implementation_and_Pre-Dev_Lifecycle_Specification_canonical_standard.md | `6f6aafece90b34e33786647e14fee840f5424893995b3164cbb52953a5c4f14a` | 7176 | 261 | FULL_UTF8_READ / NO_SAMPLING |
| `A3` | PIPD_LS_skeleton_2026-10-06_r2_FULL_REPAIR(1).md | `03bb3609dc67f85fa4b683a93736cf162e9047b6b253182aa3fdba11ba40cb28` | 2668 | 143 | FULL_UTF8_READ / NO_SAMPLING |
| `A4` | Pre-Implementation-PKG  Pre-Dev-PKG 生命週期規格_總討論(1).md | `be1858e860092fb1751bf0524cd22b6939138b6835ce8f452bfc30894f945a95` | 2559 | 92 | FULL_UTF8_READ / NO_SAMPLING |
| `AUDIT` | AUDIT_PIPD_LS_DOC-00_2026-10-07_r1_FULL_SUBSTANTIVE_BODY_FULL_AUDIT_2026-10-07_r1(2).md | `1081f9e935198f3da911a9eed227a0e66156e7b964422bccae27739002201dd7` | 907 | 42 | FULL_UTF8_READ / NO_SAMPLING |
| `R1` | PIPD_LS_DOC-00_2026-10-07_r1_FULL_SUBSTANTIVE_BODY.md | `0b012d586e750d5c8fee1a6ff16deb76eea9d73d9412432a71c465f5295d848c` | 1416 | 85 | FULL_UTF8_READ / NO_SAMPLING |

File-level scanning is evidence of **scan completion only**. It cannot close a substantive requirement.

## 19.2 Clause-level source coverage ledger
| Source | Exact anchor/line | Requirement / claim | coverage_kind | DOC-00 relevance | Mapped r2 body | Status | Rationale |
|---|---|---|---|---|---|---|---|
| `P0` | `L10` — # 0｜你的專業角色 | Execution role / fail-closed / evidence contract | `SUBSTANTIVE_BODY` | DOC00_OWNED_OR_REQUIRED_PROJECTION | §0, §19–24 | CLOSED_R2 | Concrete body mechanics materialized; row does not rely on heading/file presence alone. |
| `P0` | `L33` — # 1｜主任務 / Target Outcome | Full substantive DOC-00, not outline | `SUBSTANTIVE_BODY` | DOC00_OWNED_OR_REQUIRED_PROJECTION | whole body | CLOSED_R2 | Concrete body mechanics materialized; row does not rely on heading/file presence alone. |
| `P0` | `L61` — # 2｜最高 Authority / 裁決順位 | Authority precedence | `SUBSTANTIVE_BODY` | DOC00_OWNED_OR_REQUIRED_PROJECTION | §0, §21 | CLOSED_R2 | Concrete body mechanics materialized; row does not rely on heading/file presence alone. |
| `P0` | `L148` — # 5｜🛠 強制「深度分析 / 全量整合 SOP」 | SOP 1–6 full-scan procedure | `SUBSTANTIVE_BODY` | DOC00_OWNED_OR_REQUIRED_PROJECTION | §19 + App-A | CLOSED_R2 | Concrete body mechanics materialized; row does not rely on heading/file presence alone. |
| `P0` | `L257` — ## 6.1 Source Coverage Ledger | Clause-level source coverage | `SUBSTANTIVE_BODY` | DOC00_OWNED_OR_REQUIRED_PROJECTION | §19 | CLOSED_R2 | Concrete body mechanics materialized; row does not rely on heading/file presence alone. |
| `P0` | `L279` — ## 6.2 Atomic Requirement Ledger | Atomic denominator | `SUBSTANTIVE_BODY` | DOC00_OWNED_OR_REQUIRED_PROJECTION | §20 | CLOSED_R2 | Concrete body mechanics materialized; row does not rely on heading/file presence alone. |
| `P0` | `L283` — ## 6.3 Authority Conflict Ledger | Authority conflict tracking | `SUBSTANTIVE_BODY` | DOC00_OWNED_OR_REQUIRED_PROJECTION | §21 | CLOSED_R2 | Concrete body mechanics materialized; row does not rely on heading/file presence alone. |
| `P0` | `L298` — ## 6.4 Gap / TT / CR Register | Gap/TT/CR tracking | `SUBSTANTIVE_BODY` | DOC00_OWNED_OR_REQUIRED_PROJECTION | §22 | CLOSED_R2 | Concrete body mechanics materialized; row does not rely on heading/file presence alone. |
| `P0` | `L316` — # 7｜PIPD 核心工程不變量 | Lifecycle / ECP / adapter / state truth invariants | `SUBSTANTIVE_BODY` | DOC00_OWNED_OR_REQUIRED_PROJECTION | §3, §12, §15 | CLOSED_R2 | Concrete body mechanics materialized; row does not rely on heading/file presence alone. |
| `P0` | `L404` — # 8｜DOC-00 Canonical Identity / Responsibility | Navigation/Operator Entry unique ownership | `SUBSTANTIVE_BODY` | DOC00_OWNED_OR_REQUIRED_PROJECTION | §1, §5, §17 | CLOSED_R2 | Concrete body mechanics materialized; row does not rely on heading/file presence alone. |
| `P0` | `L456` — ## 9.1 Artifact Identity / Version / Claim Boundary | Identity/version/claim | `SUBSTANTIVE_BODY` | DOC00_OWNED_OR_REQUIRED_PROJECTION | §0 | CLOSED_R2 | Concrete body mechanics materialized; row does not rely on heading/file presence alone. |
| `P0` | `L475` — ## 9.2 DOC-00 Mission / Position / Non-goals | Mission/non-goals | `SUBSTANTIVE_BODY` | DOC00_OWNED_OR_REQUIRED_PROJECTION | §1 | CLOSED_R2 | Concrete body mechanics materialized; row does not rely on heading/file presence alone. |
| `P0` | `L486` — ## 9.3 When PIPD Applies / Does Not Apply | Applicability/profiles/N-A | `SUBSTANTIVE_BODY` | DOC00_OWNED_OR_REQUIRED_PROJECTION | §2 | CLOSED_R2 | Concrete body mechanics materialized; row does not rely on heading/file presence alone. |
| `P0` | `L503` — ## 9.4 One-Lifecycle Quick Mental Model | Lifecycle mental model | `SUBSTANTIVE_BODY` | DOC00_OWNED_OR_REQUIRED_PROJECTION | §3 | CLOSED_R2 | Concrete body mechanics materialized; row does not rely on heading/file presence alone. |
| `P0` | `L513` — ## 9.5 Authority & Source Read Order | Human/AI/tool read order | `SUBSTANTIVE_BODY` | DOC00_OWNED_OR_REQUIRED_PROJECTION | §4 | CLOSED_R2 | Concrete body mechanics materialized; row does not rely on heading/file presence alone. |
| `P0` | `L555` — ## 9.6 Package Topology & Document Responsibility Matrix | Document Responsibility Matrix | `SUBSTANTIVE_BODY` | DOC00_OWNED_OR_REQUIRED_PROJECTION | §5 | CLOSED_R2 | Concrete body mechanics materialized; row does not rely on heading/file presence alone. |
| `P0` | `L578` — ## 9.7 First-Use Quickstart / Bootstrap | Eight differentiated first-use paths | `SUBSTANTIVE_BODY` | DOC00_OWNED_OR_REQUIRED_PROJECTION | §6 | CLOSED_R2 | Concrete body mechanics materialized; row does not rely on heading/file presence alone. |
| `P0` | `L595` — ## 9.8 Package Routing | Owner-based routing | `SUBSTANTIVE_BODY` | DOC00_OWNED_OR_REQUIRED_PROJECTION | §7 | CLOSED_R2 | Concrete body mechanics materialized; row does not rely on heading/file presence alone. |
| `P0` | `L611` — ## 9.9 Lifecycle State Readback | Machine-readable readback | `SUBSTANTIVE_BODY` | DOC00_OWNED_OR_REQUIRED_PROJECTION | §8 | CLOSED_R2 | Concrete body mechanics materialized; row does not rely on heading/file presence alone. |
| `P0` | `L633` — ## 9.10 Technology / Tool / OSS / Workflow Operator Index | Operator tech index | `SUBSTANTIVE_BODY` | DOC00_OWNED_OR_REQUIRED_PROJECTION | §9–11 + App-B | CLOSED_R2 | Concrete body mechanics materialized; row does not rely on heading/file presence alone. |
| `P0` | `L650` — ## 9.11 ECP / TQAEP / Execution Boundary Quick Map | ECP/TQAEP/Admission boundary | `SUBSTANTIVE_BODY` | DOC00_OWNED_OR_REQUIRED_PROJECTION | §12 | CLOSED_R2 | Concrete body mechanics materialized; row does not rely on heading/file presence alone. |
| `P0` | `L665` — ## 9.12 Vertical Slice / Adoption Wave Quickstart | Anti-waterfall slice mechanics | `SUBSTANTIVE_BODY` | DOC00_OWNED_OR_REQUIRED_PROJECTION | §13 | CLOSED_R2 | Concrete body mechanics materialized; row does not rely on heading/file presence alone. |
| `P0` | `L676` — ## 9.13 Failure / Degrade / Recovery Entry | Typed failure/recovery | `SUBSTANTIVE_BODY` | DOC00_OWNED_OR_REQUIRED_PROJECTION | §14 | CLOSED_R2 | Concrete body mechanics materialized; row does not rely on heading/file presence alone. |
| `P0` | `L695` — ## 9.14 Common Errors / Anti-Patterns | False-equivalence rejection | `SUBSTANTIVE_BODY` | DOC00_OWNED_OR_REQUIRED_PROJECTION | §15 | CLOSED_R2 | Concrete body mechanics materialized; row does not rely on heading/file presence alone. |
| `P0` | `L714` — ## 9.15 Glossary / Quick Reference | Canonical vocabulary | `SUBSTANTIVE_BODY` | DOC00_OWNED_OR_REQUIRED_PROJECTION | §16 | CLOSED_R2 | Concrete body mechanics materialized; row does not rely on heading/file presence alone. |
| `P0` | `L720` — ## 9.16 Cross-Document Ownership & Navigation Index | Ownership/navigation | `SUBSTANTIVE_BODY` | DOC00_OWNED_OR_REQUIRED_PROJECTION | §17 | CLOSED_R2 | Concrete body mechanics materialized; row does not rely on heading/file presence alone. |
| `P0` | `L730` — ## 9.17 DOC-00 Self-Conformance / Final Readback | Self-conformance/readback | `SUBSTANTIVE_BODY` | DOC00_OWNED_OR_REQUIRED_PROJECTION | §24–26 | CLOSED_R2 | Concrete body mechanics materialized; row does not rely on heading/file presence alone. |
| `P0` | `L797` — ## 11.1 先解析 canonical denominator | Layer A/B/C full denominator | `SUBSTANTIVE_BODY` | DOC00_OWNED_OR_REQUIRED_PROJECTION | §9–11 + App-B | CLOSED_R2 | Concrete body mechanics materialized; row does not rely on heading/file presence alone. |
| `P0` | `L820` — ## 11.2 2026 Currentness Research | Currentness evidence fields | `SUBSTANTIVE_BODY` | DOC00_OWNED_OR_REQUIRED_PROJECTION | §23 | CLOSED_R2 | Concrete body mechanics materialized; row does not rely on heading/file presence alone. |
| `P0` | `L869` — ## 11.3 禁止留下無裁決 Candidate | Terminal disposition integrity | `SUBSTANTIVE_BODY` | DOC00_OWNED_OR_REQUIRED_PROJECTION | §9 | CLOSED_R2 | Concrete body mechanics materialized; row does not rely on heading/file presence alone. |
| `P0` | `L902` — ## 11.4 Selected ≠ Installed 防偽規則 | Design/runtime state separation | `SUBSTANTIVE_BODY` | DOC00_OWNED_OR_REQUIRED_PROJECTION | §9, §17 | CLOSED_R2 | Concrete body mechanics materialized; row does not rely on heading/file presence alone. |
| `P0` | `L934` — ## 11.5 每個具名技術的 Landing Contract | Named tech landing obligations | `SUBSTANTIVE_BODY` | DOC00_OWNED_OR_REQUIRED_PROJECTION | §9–10 + App-B | CLOSED_R2 | Concrete body mechanics materialized; row does not rely on heading/file presence alone. |
| `P0` | `L977` — # 12｜外部能力 Translation / Compression / Integration 規則 | Donor authority firewall | `SUBSTANTIVE_BODY` | DOC00_OWNED_OR_REQUIRED_PROJECTION | §11 | CLOSED_R2 | Concrete body mechanics materialized; row does not rely on heading/file presence alone. |
| `P0` | `L1011` — # 13｜外部能力驗收 / 功能檢測 | Technology tests/oracles | `SUBSTANTIVE_BODY` | DOC00_OWNED_OR_REQUIRED_PROJECTION | §9–10 | CLOSED_R2 | Concrete body mechanics materialized; row does not rely on heading/file presence alone. |
| `P0` | `L1041` — # 14｜DOC-00 的 Technology 表達方式 | Operator index, not second SSOT | `SUBSTANTIVE_BODY` | DOC00_OWNED_OR_REQUIRED_PROJECTION | §9–11 | CLOSED_R2 | Concrete body mechanics materialized; row does not rely on heading/file presence alone. |
| `P0` | `L1071` — # 15｜Document Responsibility Matrix | DRM canonical writer | `SUBSTANTIVE_BODY` | DOC00_OWNED_OR_REQUIRED_PROJECTION | §5 | CLOSED_R2 | Concrete body mechanics materialized; row does not rely on heading/file presence alone. |
| `P0` | `L1100` — # 16｜Readback Contract | Readback fields | `SUBSTANTIVE_BODY` | DOC00_OWNED_OR_REQUIRED_PROJECTION | §8 | CLOSED_R2 | Concrete body mechanics materialized; row does not rely on heading/file presence alone. |
| `P0` | `L1138` — # 17｜Claim Honesty / 真實性邊界 | No runtime/independent/release inflation | `SUBSTANTIVE_BODY` | DOC00_OWNED_OR_REQUIRED_PROJECTION | §0, §25 | CLOSED_R2 | Concrete body mechanics materialized; row does not rely on heading/file presence alone. |
| `P0` | `L1197` — # 19｜Examples / Scenarios | 12 operator scenarios | `SUBSTANTIVE_BODY` | DOC00_OWNED_OR_REQUIRED_PROJECTION | §18 | CLOSED_R2 | Concrete body mechanics materialized; row does not rely on heading/file presence alone. |
| `P0` | `L1270` — # 22｜Currentness / 外部研究證據 | Evidence schema for dynamic facts | `SUBSTANTIVE_BODY` | DOC00_OWNED_OR_REQUIRED_PROJECTION | §23 | CLOSED_R2 | Concrete body mechanics materialized; row does not rely on heading/file presence alone. |
| `P0` | `L1295` — # 23｜Completion Contract | Completion denominator | `SUBSTANTIVE_BODY` | DOC00_OWNED_OR_REQUIRED_PROJECTION | §20, §24 | CLOSED_R2 | Concrete body mechanics materialized; row does not rely on heading/file presence alone. |
| `P0` | `L1343` — # 24｜Final Quality Gates | Semantic gates | `SUBSTANTIVE_BODY` | DOC00_OWNED_OR_REQUIRED_PROJECTION | §24 | CLOSED_R2 | Concrete body mechanics materialized; row does not rely on heading/file presence alone. |
| `P0` | `L1405` — # 25｜最終檔案 | Single MD packaging | `SUBSTANTIVE_BODY` | DOC00_OWNED_OR_REQUIRED_PROJECTION | §26 | CLOSED_R2 | Concrete body mechanics materialized; row does not rely on heading/file presence alone. |
| `A2` | `L202` — ## P-11 Capability-Before-Brand / Search-Before-Build | Capability before brand | `SUBSTANTIVE_BODY` | DOC00_OWNED_OR_REQUIRED_PROJECTION | §9 | CLOSED_R2 | Concrete body mechanics materialized; row does not rely on heading/file presence alone. |
| `A2` | `L206` — ## P-12 Execution Identity Separation | Seed/WO/ECP/Admission distinct | `SUBSTANTIVE_BODY` | DOC00_OWNED_OR_REQUIRED_PROJECTION | §12 | CLOSED_R2 | Concrete body mechanics materialized; row does not rely on heading/file presence alone. |
| `A2` | `L210` — ## P-13 Tool Success ≠ World Effect | World-effect reconciliation | `SUBSTANTIVE_BODY` | DOC00_OWNED_OR_REQUIRED_PROJECTION | §12 | CLOSED_R2 | Concrete body mechanics materialized; row does not rely on heading/file presence alone. |
| `A2` | `L324` — ## 5.3 Claim Ceiling Table | Canonical claim ceilings | `SUBSTANTIVE_BODY` | DOC00_OWNED_OR_REQUIRED_PROJECTION | §0, §3, §25 | CLOSED_R2 | Concrete body mechanics materialized; row does not rely on heading/file presence alone. |
| `A2` | `L612` — ## PI-05 Atomic Requirements | Atomic child decomposition | `SUBSTANTIVE_BODY` | DOC00_OWNED_OR_REQUIRED_PROJECTION | §20 | CLOSED_R2 | Concrete body mechanics materialized; row does not rely on heading/file presence alone. |
| `A2` | `L643` — ### PI-08.1 Mandatory Search-Before-Build algorithm | Exact 11-step SBB | `SUBSTANTIVE_BODY` | DOC00_OWNED_OR_REQUIRED_PROJECTION | §9 | CLOSED_R2 | Concrete body mechanics materialized; row does not rely on heading/file presence alone. |
| `A2` | `L683` — ### PI-08.2 TechnologyAdmissionRecord | 23 field identities | `SUBSTANTIVE_BODY` | DOC00_OWNED_OR_REQUIRED_PROJECTION | §10 | CLOSED_R2 | Concrete body mechanics materialized; row does not rely on heading/file presence alone. |
| `A2` | `L6313` — # 29. AI Read Order — Two-Phase Instruction Safety | AI two-phase read order | `SUBSTANTIVE_BODY` | DOC00_OWNED_OR_REQUIRED_PROJECTION | §4 | CLOSED_R2 | Concrete body mechanics materialized; row does not rely on heading/file presence alone. |
| `A2` | `L6335` — # 30. Progressive Disclosure Rule | Small entry point + canonical refs | `SUBSTANTIVE_BODY` | DOC00_OWNED_OR_REQUIRED_PROJECTION | Five-Minute Router + App-B | CLOSED_R2 | Concrete body mechanics materialized; row does not rely on heading/file presence alone. |
| `A3` | `L271` — # 6 Canonical Document Registry / Authoring Archetypes | DOC-00..09 ownership | `SUBSTANTIVE_BODY` | DOC00_OWNED_OR_REQUIRED_PROJECTION | §5 | CLOSED_R2 | Concrete body mechanics materialized; row does not rely on heading/file presence alone. |
| `A3` | `L286` — # 7 DOC-00 Router / Quickstart / Operational Entry Skeleton | DOC-00 router contract | `SUBSTANTIVE_BODY` | DOC00_OWNED_OR_REQUIRED_PROJECTION | Router Card + §1–8 | CLOSED_R2 | Concrete body mechanics materialized; row does not rely on heading/file presence alone. |
| `A3` | `L291` — ## 7.2 Human / AI / tool read orders | Exact machine order | `SUBSTANTIVE_BODY` | DOC00_OWNED_OR_REQUIRED_PROJECTION | §4 | CLOSED_R2 | Concrete body mechanics materialized; row does not rely on heading/file presence alone. |
| `A3` | `L837` — ## 19.3 P0/P1 Canonical 22 Technology Baseline | Layer A 22 denominator | `SUBSTANTIVE_BODY` | DOC00_OWNED_OR_REQUIRED_PROJECTION | §9 | CLOSED_R2 | Concrete body mechanics materialized; row does not rely on heading/file presence alone. |
| `A3` | `L874` — ## 20.1 R1 NOBJ-001..024 — 24/24 | Layer B NOBJ 24 | `SUBSTANTIVE_BODY` | DOC00_OWNED_OR_REQUIRED_PROJECTION | App-B | CLOSED_R2 | Concrete body mechanics materialized; row does not rely on heading/file presence alone. |
| `A3` | `L904` — ## 20.2 R2 ECP exact 48 + ADD-01..04 — 52/52 | Layer B ECP+ADD 52 | `SUBSTANTIVE_BODY` | DOC00_OWNED_OR_REQUIRED_PROJECTION | App-B | CLOSED_R2 | Concrete body mechanics materialized; row does not rely on heading/file presence alone. |
| `A3` | `L962` — ## 20.3 R2 MSC-TECH-001..015 — 15/15 | Layer B MSC 15 | `SUBSTANTIVE_BODY` | DOC00_OWNED_OR_REQUIRED_PROJECTION | App-B | CLOSED_R2 | Concrete body mechanics materialized; row does not rely on heading/file presence alone. |
| `A3` | `L983` — ## 20.4 R3 TQ-TECH-001..031 — 31/31 | Layer B TQ 31 | `SUBSTANTIVE_BODY` | DOC00_OWNED_OR_REQUIRED_PROJECTION | App-B | CLOSED_R2 | Concrete body mechanics materialized; row does not rely on heading/file presence alone. |
| `A3` | `L1020` — ## 20.5 R2 Named Donor Workflows — 8/8 | Layer B workflow 8 | `SUBSTANTIVE_BODY` | DOC00_OWNED_OR_REQUIRED_PROJECTION | App-B | CLOSED_R2 | Concrete body mechanics materialized; row does not rely on heading/file presence alone. |
| `A3` | `L1158` — # 31 Source Coverage Ledger — Coverage Kind Prevents False Closure | Coverage kind semantics | `SUBSTANTIVE_BODY` | DOC00_OWNED_OR_REQUIRED_PROJECTION | §19 | CLOSED_R2 | Concrete body mechanics materialized; row does not rely on heading/file presence alone. |
| `A3` | `L2602` — # 35 Repair Acceptance Gates / Structural Validation / Final Readback | Machine-checkable repair gates | `SUBSTANTIVE_BODY` | DOC00_OWNED_OR_REQUIRED_PROJECTION | §24 | CLOSED_R2 | Concrete body mechanics materialized; row does not rely on heading/file presence alone. |
| `A4` | `L673` — # 十五、還有一個很重要的勘誤：「Pre-Implementation 完成」不等於「整套東西才可以開始施工」 | Vertical slice anti-waterfall rationale | `SUBSTANTIVE_BODY` | DOC00_OWNED_OR_REQUIRED_PROJECTION | §13 | CLOSED_R2 | Concrete body mechanics materialized; row does not rely on heading/file presence alone. |
| `A4` | `L1898` — # 三、我建議正式產出的「7 份核心標準文件」 | README/Quickstart five-minute intent | `SUBSTANTIVE_BODY` | DOC00_OWNED_OR_REQUIRED_PROJECTION | Five-Minute Router | CLOSED_R2 | Concrete body mechanics materialized; row does not rely on heading/file presence alone. |
| `A4` | `L2054` — # 七、給 AI 看，不應只寫一份 500 頁大總書 | Progressive disclosure / AI entry rationale | `SUBSTANTIVE_BODY` | DOC00_OWNED_OR_REQUIRED_PROJECTION | Router Card + §4 + App-B | CLOSED_R2 | Concrete body mechanics materialized; row does not rely on heading/file presence alone. |
| `AUDIT` | `L171` — # 6. Finding Register — Full Substantive Audit | B/M/N findings | `AUDIT_CONTROLLER` | AUDIT_REPAIR_CONTROLLER | §21 | CLOSED_R2 | Repair controller finding/predicate consumed and closed in r2. |
| `AUDIT` | `L256` — ## 9.2 2026-10-07 currentness recheck | 22-row currentness recheck | `AUDIT_CONTROLLER` | AUDIT_REPAIR_CONTROLLER | §23 | CLOSED_R2 | Repair controller finding/predicate consumed and closed in r2. |
| `AUDIT` | `L590` — # 14. Global Repair Plan | P0/P1/P2 repair plan | `AUDIT_CONTROLLER` | AUDIT_REPAIR_CONTROLLER | whole r2 patch | CLOSED_R2 | Repair controller finding/predicate consumed and closed in r2. |
| `AUDIT` | `L706` — # 15. Required r2 Acceptance Gates | R2-A01..14 predicates | `AUDIT_CONTROLLER` | AUDIT_REPAIR_CONTROLLER | §24 | CLOSED_R2 | Repair controller finding/predicate consumed and closed in r2. |

## 19.3 Full heading/index scan
The complete H1–H6 index for P0/A1/A2/A3/A4/AUDIT is preserved in Appendix H. This is separate from substantive closure.

## 19.4 Keyword full-text scan receipt
| Keyword | P0 | A1 | A2 | A3 | A4 | AUDIT |
|---|---:|---:|---:|---:|---:|---:|
| `DOC-00` | 52 | 0 | 0 | 6 | 0 | 36 |
| `Quickstart` | 5 | 0 | 0 | 7 | 1 | 24 |
| `bootstrap` | 6 | 4 | 0 | 9 | 0 | 18 |
| `read order` | 9 | 3 | 3 | 12 | 0 | 11 |
| `standard.lock` | 1 | 9 | 0 | 4 | 0 | 4 |
| `project-manifest` | 0 | 5 | 0 | 6 | 0 | 3 |
| `schemas/registry` | 0 | 0 | 0 | 1 | 0 | 3 |
| `package index` | 3 | 2 | 1 | 2 | 0 | 0 |
| `applicable package objects` | 1 | 0 | 0 | 1 | 0 | 4 |
| `TechnologyAdmission` | 7 | 7 | 7 | 202 | 0 | 10 |
| `Search-Before-Build` | 3 | 5 | 6 | 28 | 3 | 5 |
| `BUILD_MINIMAL` | 1 | 6 | 10 | 13 | 0 | 8 |
| `HOLD_WITH_TT` | 2 | 2 | 3 | 6 | 0 | 3 |
| `ECP` | 14 | 24 | 92 | 192 | 22 | 209 |
| `TQAEP` | 12 | 13 | 39 | 86 | 18 | 67 |
| `ExecutionAdmission` | 8 | 3 | 6 | 28 | 0 | 2 |
| `currentness` | 19 | 78 | 36 | 177 | 5 | 48 |
| `rollback` | 8 | 22 | 93 | 82 | 23 | 5 |
| `provider-off` | 6 | 5 | 3 | 136 | 0 | 2 |
| `coverage_kind` | 2 | 0 | 0 | 6 | 0 | 9 |
| `Atomic Requirement` | 6 | 1 | 4 | 17 | 1 | 5 |
| `TT` | 22 | 170 | 156 | 689 | 39 | 66 |
| `CR` | 28 | 56 | 65 | 292 | 18 | 30 |
| `Layer B` | 0 | 0 | 0 | 2 | 0 | 1 |
| `NOBJ` | 0 | 0 | 0 | 27 | 0 | 100 |
| `MSC-TECH` | 0 | 0 | 0 | 16 | 0 | 30 |
| `TQ-TECH` | 0 | 0 | 0 | 32 | 0 | 66 |
| `claim ceiling` | 8 | 5 | 14 | 20 | 4 | 7 |
| `vertical slice` | 4 | 4 | 3 | 5 | 2 | 5 |
| `brownfield` | 3 | 7 | 17 | 24 | 2 | 9 |

# 20｜Atomic Requirement / Verification Denominator — r2 Recompiled

r1's `92/92` is retained only as a historical child set, not as the r2 denominator. r2 uses an **additive identity-preserving verification denominator** so audit-required children cannot disappear inside broad parent rows.

| Group | Count |
|---|---:|
| `R1_RETAINED` | 92 |
| `AUDIT_REPAIR` | 16 |
| `QUICKSTART_8` | 8 |
| `MACHINE_ORDER_7` | 7 |
| `SBB` | 11 |
| `SBB_SPECIAL` | 2 |
| `TA_FIELD_23` | 23 |
| `LAYER_A_22` | 22 |
| `LAYER_B_130` | 130 |
| `LAYER_C_6` | 6 |
| `CURRENTNESS_22` | 22 |
| `DESTRUCTIVE_7` | 7 |
| `PACKAGING_4` | 4 |
| **TOTAL** | **350** |

Closure predicate: `required_atomic_ids - mapped_substantive_or_exact_index_ids == ∅`. Current r2 result: **350/350 mapped**.

### 20.1 Atomic ledger
| Atomic ID | Requirement | r2 mapping | Status | Denominator group |
|---|---|---|---|---|
| `AR-ID-01` | Declare DOC-00 artifact identity and class | §0 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-ID-02` | Declare DOC-specific version without impersonating standard version | §0 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-ID-03` | Bind canonical standard/blueprint IDs and source hashes | §0/§19 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-ID-04` | Declare supersession/lineage and target audience | §0 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-ID-05` | Declare no-runtime claim boundary | §0/§17 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-MISSION-01` | Explain operator-entry mission | §1 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-MISSION-02` | Define DOC-00 writer responsibilities | §1/§5 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-MISSION-03` | Define read-only dependencies | §1 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-MISSION-04` | Enumerate non-goals and normative ownership exclusions | §1/§5 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-MISSION-05` | Identify human/AI/tooling consumers | §1/§4 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-APPLY-01` | Define applicable project/system/service/library cases | §2 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-APPLY-02` | Define Skill/Plugin applicability | §2 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-APPLY-03` | Define Agent Harness applicability | §2 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-APPLY-04` | Define AI-enabled platform and Brownfield applicability | §2 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-APPLY-05` | Define CUSTOM target path | §2 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-APPLY-06` | Define weight-profile selection | §2 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-APPLY-07` | Define target-profile selection | §2 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-APPLY-08` | Define reasoned N/A rule | §2 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-APPLY-09` | Define pre-execution boundary | §2/§3 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-LIFE-01` | Explain PI purpose and PI-01..18 contract areas | §3/§6 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-LIFE-02` | Explain PD purpose and PD-01..10 blocks | §3/§6 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-LIFE-03` | Separate PREDEV_READY from EXECUTION_ADMITTED | §3/§12 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-LIFE-04` | Separate implementation from verification | §3 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-LIFE-05` | Separate verification from qualification/release/production | §3 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-LIFE-06` | Materialize canonical lifecycle and side states | §3 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-LIFE-07` | Define promotion by evidence/gates rather than prose | §3/§8 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-READ-01` | Materialize human read order | §4 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-READ-02` | Materialize AI Phase-A global/read-only order | §4 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-READ-03` | Materialize AI Phase-B nearest-scope action preparation | §4 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-READ-04` | Materialize tool/machine read order | §4 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-READ-05` | Resolve nearest-scope instruction conflicts without authority inversion | §4/§14 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-DRM-01` | Materialize DOC-00..09 responsibility matrix | §5 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-DRM-02` | Ensure one canonical writer per responsibility | §5 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-DRM-03` | Record reads/writes/consumers/entry/output/state/non-goal/dependencies/open-when fields | §5 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-DRM-04` | Differentiate canonical generic PI/PD contracts from project package projections | §5/§7 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-BOOT-01` | Provide new-project quickstart | §6 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-BOOT-02` | Provide brownfield quickstart | §6 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-BOOT-03` | Provide restart/readback bootstrap | §6 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-BOOT-04` | Forbid mutation before admission | §6/§12 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-ROUTE-01` | Provide package/document routing rules | §7 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-ROUTE-02` | Route authority/state conflicts to DOC-01 | §7 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-ROUTE-03` | Route PI/TechnologyAdmission to DOC-02 | §7 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-ROUTE-04` | Route RepoContext/currentness/ECP/TQAEP to DOC-03 | §7 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-ROUTE-05` | Route evidence/trace to DOC-04 | §7 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-ROUTE-06` | Route admission/handoff to DOC-05 | §7 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-ROUTE-07` | Route profile questions to DOC-06 | §7 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-ROUTE-08` | Route tests/oracles to DOC-07 | §7 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-ROUTE-09` | Route AI adapters to DOC-08 | §7 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-ROUTE-10` | Route CI/release/runbook/tooling to DOC-09 | §7 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-READBACK-01` | Materialize minimum readback fields | §8 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-READBACK-02` | Provide machine-readable readback example | §8 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-READBACK-03` | Include next legal and forbidden transitions | §8 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-READBACK-04` | Include missing/stale/TT/CR fields | §8 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-TECH-01` | Resolve canonical 22-item technology denominator | §9/§10 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-TECH-02` | Preserve canonical terminal disposition for all 22 | §9 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-TECH-03` | Use full 17-value TechnologyAdmission enum | §9 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-TECH-04` | Perform 2026-10-07 currentness refresh | §9/§23 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-TECH-05` | Keep web currentness subordinate to semantic authority | §9/§23 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-TECH-06` | Separate selection from materialization/install/bind/enable/execute/verify | §9/§17 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-TECH-07` | Provide operator-facing index, not second SSOT | §9 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-TECH-08` | Provide per-item landing contracts | §10 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-TECH-09` | Provide functional/negative/boundary/security tests per item | §10 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-TECH-10` | Provide rollback/provider-off/residue/evidence/fallback/change-control per item | §10 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-TECH-11` | Prevent donor from obtaining semantic authority | §10/§11 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-BOUNDARY-01` | Define DEV ECP | §12 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-BOUNDARY-02` | Define OPS ECP | §12 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-BOUNDARY-03` | Define TQAEP | §12 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-BOUNDARY-04` | Define Execution Handoff | §12 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-BOUNDARY-05` | Define ExecutionAdmission | §12 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-BOUNDARY-06` | State ECP cannot self-approve | §12 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-BOUNDARY-07` | State sender-ready does not imply receiver acceptance | §12 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-BOUNDARY-08` | State tool/provider success does not imply world-effect truth | §12 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-SLICE-01` | Define vertical-slice dependency closure | §13 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-SLICE-02` | Reject all-system waterfall requirement | §13 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-SLICE-03` | Block concurrency only on shared writers/invalidation edges/permissions | §13 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-SLICE-04` | Define adoption waves | §13 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-FAIL-01` | Handle missing/stale sources | §14 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-FAIL-02` | Handle authority conflict | §14 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-FAIL-03` | Handle currentness stale | §14 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-FAIL-04` | Handle missing permission/approval | §14 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-FAIL-05` | Handle ECP without admission | §14 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-FAIL-06` | Handle source/hash drift | §14 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-FAIL-07` | Handle failed validation/world-effect unknown/provider unavailable | §14 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-FAIL-08` | Handle rejected handoff/open TT/CR | §14 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-QUALITY-01` | Materialize canonical glossary | §16 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-QUALITY-02` | Materialize 12 operator scenarios | §18 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-QUALITY-03` | Materialize source coverage ledger | §19 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-QUALITY-04` | Materialize authority conflict ledger | §21 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-QUALITY-05` | Materialize TT/CR register | §22 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-QUALITY-06` | Materialize currentness receipt | §23 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-QUALITY-07` | Execute G-01..G-14 validation | §24 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-QUALITY-08` | Create/readback/hash one Markdown artifact | §24/§25 | `REVALIDATED_R2` | `R1_RETAINED` |
| `AR-AUDIT-B-01` | Layer-B 130 named identity denominator | App-B + §11 | `CLOSED_R2` | `AUDIT_REPAIR` |
| `AR-AUDIT-B-02` | Invalid r1 atomic denominator / 8-path quickstart + missing children | §6 + §20 | `CLOSED_R2` | `AUDIT_REPAIR` |
| `AR-AUDIT-B-03` | Clause-level substantive source coverage | §19 | `CLOSED_R2` | `AUDIT_REPAIR` |
| `AR-AUDIT-M-01` | Exact tool/machine bootstrap path/order | §4 | `CLOSED_R2` | `AUDIT_REPAIR` |
| `AR-AUDIT-M-02` | Eight differentiated first-use quickstarts | §6 | `CLOSED_R2` | `AUDIT_REPAIR` |
| `AR-AUDIT-M-03` | Canonical 11-step Search-Before-Build | §9 | `CLOSED_R2` | `AUDIT_REPAIR` |
| `AR-AUDIT-M-04` | TechnologyAdmission canonical field identity preserved | §10 | `CLOSED_R2` | `AUDIT_REPAIR` |
| `AR-AUDIT-M-05` | Progressive-disclosure tech section / no second SSOT | Router Card + §9–11 + App-B | `CLOSED_R2` | `AUDIT_REPAIR` |
| `AR-AUDIT-M-06` | OpenSpec/gstack currentness repair + 22-row recheck | §23 | `CLOSED_R2` | `AUDIT_REPAIR` |
| `AR-AUDIT-M-07` | Typed currentness dimensions and evidence fields | §23 | `CLOSED_R2` | `AUDIT_REPAIR` |
| `AR-AUDIT-M-08` | Remove foreign claim token | §0/§25 | `CLOSED_R2` | `AUDIT_REPAIR` |
| `AR-AUDIT-M-09` | Explicit payload-hash scope + external whole-file SHA | §26 | `CLOSED_R2` | `AUDIT_REPAIR` |
| `AR-AUDIT-N-01` | Typed failure namespace separation | §14 | `CLOSED_R2` | `AUDIT_REPAIR` |
| `AR-AUDIT-N-02` | DOC-00 non-circular entry condition | §5 | `CLOSED_R2` | `AUDIT_REPAIR` |
| `AR-AUDIT-N-03` | Five-Minute Router Card | front card | `CLOSED_R2` | `AUDIT_REPAIR` |
| `AR-AUDIT-N-04` | Immutable observation/pin/TTL/recheck policy | §23 | `CLOSED_R2` | `AUDIT_REPAIR` |
| `AR-QS-01` | Executable first-use quickstart: brand-new design | §6.1 | `CLOSED_R2` | `QUICKSTART_8` |
| `AR-QS-02` | Executable first-use quickstart: existing PI artifact | §6.2 | `CLOSED_R2` | `QUICKSTART_8` |
| `AR-QS-03` | Executable first-use quickstart: PREDEV binding | §6.3 | `CLOSED_R2` | `QUICKSTART_8` |
| `AR-QS-04` | Executable first-use quickstart: brownfield | §6.4 | `CLOSED_R2` | `QUICKSTART_8` |
| `AR-QS-05` | Executable first-use quickstart: Skill/Plugin | §6.5 | `CLOSED_R2` | `QUICKSTART_8` |
| `AR-QS-06` | Executable first-use quickstart: Agent Harness | §6.6 | `CLOSED_R2` | `QUICKSTART_8` |
| `AR-QS-07` | Executable first-use quickstart: vertical slice | §6.7 | `CLOSED_R2` | `QUICKSTART_8` |
| `AR-QS-08` | Executable first-use quickstart: change/drift re-entry | §6.8 | `CLOSED_R2` | `QUICKSTART_8` |
| `AR-MR-01` | Machine bootstrap stage 1: .pipd/lock/standard.lock.json — standard identity/hash pin | §4.3 | `CLOSED_R2` | `MACHINE_ORDER_7` |
| `AR-MR-02` | Machine bootstrap stage 2: .pipd/project/manifest.json — project subject/profile/state manifest | §4.3 | `CLOSED_R2` | `MACHINE_ORDER_7` |
| `AR-MR-03` | Machine bootstrap stage 3: .pipd/generated/schemas/** + .pipd/generated/registry/** — canonical/generated schemas and registry | §4.3 | `CLOSED_R2` | `MACHINE_ORDER_7` |
| `AR-MR-04` | Machine bootstrap stage 4: .pipd/project/package-index — package index object | §4.3 | `CLOSED_R2` | `MACHINE_ORDER_7` |
| `AR-MR-05` | Machine bootstrap stage 5: .pipd/project/pi/** + .pipd/project/pd/** + applicable referenced package objects — applicable package objects | §4.3 | `CLOSED_R2` | `MACHINE_ORDER_7` |
| `AR-MR-06` | Machine bootstrap stage 6: .pipd/policies/** + .pipd/support/currentness/** + .pipd/project/execution/** — policies/currentness/admission | §4.3 | `CLOSED_R2` | `MACHINE_ORDER_7` |
| `AR-MR-07` | Machine bootstrap stage 7: .pipd/project/evidence/** + .pipd/conformance/** — evidence/conformance | §4.3 | `CLOSED_R2` | `MACHINE_ORDER_7` |
| `AR-SBB-01` | NEED / MEASURABLE CAPABILITY | §9.2 step 1 | `CLOSED_R2` | `SBB` |
| `AR-SBB-02` | INTERNAL REUSE SEARCH | §9.2 step 2 | `CLOSED_R2` | `SBB` |
| `AR-SBB-03` | EXTERNAL SCOUT when internal fit is insufficient | §9.2 step 3 | `CLOSED_R2` | `SBB` |
| `AR-SBB-04` | CANDIDATE NORMALIZATION BY CAPABILITY SLOT | §9.2 step 4 | `CLOSED_R2` | `SBB` |
| `AR-SBB-05` | GAP / FIT EVALUATION | §9.2 step 5 | `CLOSED_R2` | `SBB` |
| `AR-SBB-06` | SECURITY / LICENSE / MATURITY / MAINTENANCE / SUPPLY-CHAIN REVIEW | §9.2 step 6 | `CLOSED_R2` | `SBB` |
| `AR-SBB-07` | PORTABILITY / TESTABILITY / BROWNFIELD / EXIT REVIEW | §9.2 step 7 | `CLOSED_R2` | `SBB` |
| `AR-SBB-08` | TERMINAL DISPOSITION | §9.2 step 8 | `CLOSED_R2` | `SBB` |
| `AR-SBB-09` | VERSION/CURRENTNESS PIN POLICY | §9.2 step 9 | `CLOSED_R2` | `SBB` |
| `AR-SBB-10` | ADAPTER / TRANSLATION / WRAPPER CONTRACT | §9.2 step 10 | `CLOSED_R2` | `SBB` |
| `AR-SBB-11` | BUILD_MINIMAL only when NO_FIT or material uncovered gap is recorded | §9.2 step 11 | `CLOSED_R2` | `SBB` |
| `AR-SBB-12` | BUILD_MINIMAL requires non-empty no_fit_reason + failed/rejected candidate gap set | §9.3 | `CLOSED_R2` | `SBB_SPECIAL` |
| `AR-SBB-13` | HOLD_WITH_TT requires typed TT, owner, close criteria and no silent runtime promotion | §9.3 | `CLOSED_R2` | `SBB_SPECIAL` |
| `AR-TAF-01` | Preserve TechnologyAdmissionRecord field identity `candidate_id` | §10.1 | `CLOSED_R2` | `TA_FIELD_23` |
| `AR-TAF-02` | Preserve TechnologyAdmissionRecord field identity `canonical_name` | §10.1 | `CLOSED_R2` | `TA_FIELD_23` |
| `AR-TAF-03` | Preserve TechnologyAdmissionRecord field identity `capability_slot` | §10.1 | `CLOSED_R2` | `TA_FIELD_23` |
| `AR-TAF-04` | Preserve TechnologyAdmissionRecord field identity `need_ref` | §10.1 | `CLOSED_R2` | `TA_FIELD_23` |
| `AR-TAF-05` | Preserve TechnologyAdmissionRecord field identity `source_or_upstream` | §10.1 | `CLOSED_R2` | `TA_FIELD_23` |
| `AR-TAF-06` | Preserve TechnologyAdmissionRecord field identity `observed_version_or_pin` | §10.1 | `CLOSED_R2` | `TA_FIELD_23` |
| `AR-TAF-07` | Preserve TechnologyAdmissionRecord field identity `source_checked_at` | §10.1 | `CLOSED_R2` | `TA_FIELD_23` |
| `AR-TAF-08` | Preserve TechnologyAdmissionRecord field identity `license` | §10.1 | `CLOSED_R2` | `TA_FIELD_23` |
| `AR-TAF-09` | Preserve TechnologyAdmissionRecord field identity `maturity` | §10.1 | `CLOSED_R2` | `TA_FIELD_23` |
| `AR-TAF-10` | Preserve TechnologyAdmissionRecord field identity `capabilities[]` | §10.1 | `CLOSED_R2` | `TA_FIELD_23` |
| `AR-TAF-11` | Preserve TechnologyAdmissionRecord field identity `disposition` | §10.1 | `CLOSED_R2` | `TA_FIELD_23` |
| `AR-TAF-12` | Preserve TechnologyAdmissionRecord field identity `integration_mode` | §10.1 | `CLOSED_R2` | `TA_FIELD_23` |
| `AR-TAF-13` | Preserve TechnologyAdmissionRecord field identity `security_risks[]` | §10.1 | `CLOSED_R2` | `TA_FIELD_23` |
| `AR-TAF-14` | Preserve TechnologyAdmissionRecord field identity `portability` | §10.1 | `CLOSED_R2` | `TA_FIELD_23` |
| `AR-TAF-15` | Preserve TechnologyAdmissionRecord field identity `testability` | §10.1 | `CLOSED_R2` | `TA_FIELD_23` |
| `AR-TAF-16` | Preserve TechnologyAdmissionRecord field identity `brownfield_fit` | §10.1 | `CLOSED_R2` | `TA_FIELD_23` |
| `AR-TAF-17` | Preserve TechnologyAdmissionRecord field identity `currentness_ttl` | §10.1 | `CLOSED_R2` | `TA_FIELD_23` |
| `AR-TAF-18` | Preserve TechnologyAdmissionRecord field identity `supply_chain_provenance` | §10.1 | `CLOSED_R2` | `TA_FIELD_23` |
| `AR-TAF-19` | Preserve TechnologyAdmissionRecord field identity `provider_exit` | §10.1 | `CLOSED_R2` | `TA_FIELD_23` |
| `AR-TAF-20` | Preserve TechnologyAdmissionRecord field identity `rollback_or_uninstall` | §10.1 | `CLOSED_R2` | `TA_FIELD_23` |
| `AR-TAF-21` | Preserve TechnologyAdmissionRecord field identity `no_fit_reason` | §10.1 | `CLOSED_R2` | `TA_FIELD_23` |
| `AR-TAF-22` | Preserve TechnologyAdmissionRecord field identity `anti_authority_rule` | §10.1 | `CLOSED_R2` | `TA_FIELD_23` |
| `AR-TAF-23` | Preserve TechnologyAdmissionRecord field identity `portable_core_dependency` | §10.1 | `CLOSED_R2` | `TA_FIELD_23` |
| `AR-LA-CAND-01` | Layer-A canonical candidate `CAND-01` identity/disposition/ref present | §9.4 | `CLOSED_R2` | `LAYER_A_22` |
| `AR-LA-CAND-02` | Layer-A canonical candidate `CAND-02` identity/disposition/ref present | §9.4 | `CLOSED_R2` | `LAYER_A_22` |
| `AR-LA-CAND-03` | Layer-A canonical candidate `CAND-03` identity/disposition/ref present | §9.4 | `CLOSED_R2` | `LAYER_A_22` |
| `AR-LA-CAND-04` | Layer-A canonical candidate `CAND-04` identity/disposition/ref present | §9.4 | `CLOSED_R2` | `LAYER_A_22` |
| `AR-LA-CAND-05` | Layer-A canonical candidate `CAND-05` identity/disposition/ref present | §9.4 | `CLOSED_R2` | `LAYER_A_22` |
| `AR-LA-CAND-06` | Layer-A canonical candidate `CAND-06` identity/disposition/ref present | §9.4 | `CLOSED_R2` | `LAYER_A_22` |
| `AR-LA-CAND-07` | Layer-A canonical candidate `CAND-07` identity/disposition/ref present | §9.4 | `CLOSED_R2` | `LAYER_A_22` |
| `AR-LA-CAND-08` | Layer-A canonical candidate `CAND-08` identity/disposition/ref present | §9.4 | `CLOSED_R2` | `LAYER_A_22` |
| `AR-LA-CAND-09` | Layer-A canonical candidate `CAND-09` identity/disposition/ref present | §9.4 | `CLOSED_R2` | `LAYER_A_22` |
| `AR-LA-CAND-10` | Layer-A canonical candidate `CAND-10` identity/disposition/ref present | §9.4 | `CLOSED_R2` | `LAYER_A_22` |
| `AR-LA-CAND-11` | Layer-A canonical candidate `CAND-11` identity/disposition/ref present | §9.4 | `CLOSED_R2` | `LAYER_A_22` |
| `AR-LA-CAND-12` | Layer-A canonical candidate `CAND-12` identity/disposition/ref present | §9.4 | `CLOSED_R2` | `LAYER_A_22` |
| `AR-LA-CAND-13` | Layer-A canonical candidate `CAND-13` identity/disposition/ref present | §9.4 | `CLOSED_R2` | `LAYER_A_22` |
| `AR-LA-CAND-14` | Layer-A canonical candidate `CAND-14` identity/disposition/ref present | §9.4 | `CLOSED_R2` | `LAYER_A_22` |
| `AR-LA-CAND-15` | Layer-A canonical candidate `CAND-15` identity/disposition/ref present | §9.4 | `CLOSED_R2` | `LAYER_A_22` |
| `AR-LA-CAND-16` | Layer-A canonical candidate `CAND-16` identity/disposition/ref present | §9.4 | `CLOSED_R2` | `LAYER_A_22` |
| `AR-LA-CAND-17` | Layer-A canonical candidate `CAND-17` identity/disposition/ref present | §9.4 | `CLOSED_R2` | `LAYER_A_22` |
| `AR-LA-CAND-18` | Layer-A canonical candidate `CAND-18` identity/disposition/ref present | §9.4 | `CLOSED_R2` | `LAYER_A_22` |
| `AR-LA-CAND-19` | Layer-A canonical candidate `CAND-19` identity/disposition/ref present | §9.4 | `CLOSED_R2` | `LAYER_A_22` |
| `AR-LA-CAND-20` | Layer-A canonical candidate `CAND-20` identity/disposition/ref present | §9.4 | `CLOSED_R2` | `LAYER_A_22` |
| `AR-LA-CAND-21` | Layer-A canonical candidate `CAND-21` identity/disposition/ref present | §9.4 | `CLOSED_R2` | `LAYER_A_22` |
| `AR-LA-CAND-22` | Layer-A canonical candidate `CAND-22` identity/disposition/ref present | §9.4 | `CLOSED_R2` | `LAYER_A_22` |
| `AR-LB-NOBJ-001` | Layer-B named donor/workflow `NOBJ-001` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-NOBJ-002` | Layer-B named donor/workflow `NOBJ-002` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-NOBJ-003` | Layer-B named donor/workflow `NOBJ-003` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-NOBJ-004` | Layer-B named donor/workflow `NOBJ-004` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-NOBJ-005` | Layer-B named donor/workflow `NOBJ-005` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-NOBJ-006` | Layer-B named donor/workflow `NOBJ-006` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-NOBJ-007` | Layer-B named donor/workflow `NOBJ-007` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-NOBJ-008` | Layer-B named donor/workflow `NOBJ-008` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-NOBJ-009` | Layer-B named donor/workflow `NOBJ-009` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-NOBJ-010` | Layer-B named donor/workflow `NOBJ-010` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-NOBJ-011` | Layer-B named donor/workflow `NOBJ-011` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-NOBJ-012` | Layer-B named donor/workflow `NOBJ-012` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-NOBJ-013` | Layer-B named donor/workflow `NOBJ-013` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-NOBJ-014` | Layer-B named donor/workflow `NOBJ-014` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-NOBJ-015` | Layer-B named donor/workflow `NOBJ-015` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-NOBJ-016` | Layer-B named donor/workflow `NOBJ-016` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-NOBJ-017` | Layer-B named donor/workflow `NOBJ-017` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-NOBJ-018` | Layer-B named donor/workflow `NOBJ-018` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-NOBJ-019` | Layer-B named donor/workflow `NOBJ-019` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-NOBJ-020` | Layer-B named donor/workflow `NOBJ-020` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-NOBJ-021` | Layer-B named donor/workflow `NOBJ-021` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-NOBJ-022` | Layer-B named donor/workflow `NOBJ-022` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-NOBJ-023` | Layer-B named donor/workflow `NOBJ-023` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-NOBJ-024` | Layer-B named donor/workflow `NOBJ-024` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-ECP-01` | Layer-B named donor/workflow `ECP-01` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-ECP-02` | Layer-B named donor/workflow `ECP-02` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-ECP-03` | Layer-B named donor/workflow `ECP-03` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-ECP-04` | Layer-B named donor/workflow `ECP-04` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-ECP-05` | Layer-B named donor/workflow `ECP-05` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-ECP-06` | Layer-B named donor/workflow `ECP-06` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-ECP-07` | Layer-B named donor/workflow `ECP-07` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-ECP-08` | Layer-B named donor/workflow `ECP-08` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-ECP-09` | Layer-B named donor/workflow `ECP-09` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-ECP-10` | Layer-B named donor/workflow `ECP-10` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-ECP-11` | Layer-B named donor/workflow `ECP-11` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-ECP-12` | Layer-B named donor/workflow `ECP-12` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-ECP-13` | Layer-B named donor/workflow `ECP-13` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-ECP-14` | Layer-B named donor/workflow `ECP-14` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-ECP-15` | Layer-B named donor/workflow `ECP-15` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-ECP-16` | Layer-B named donor/workflow `ECP-16` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-ECP-17` | Layer-B named donor/workflow `ECP-17` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-ECP-18` | Layer-B named donor/workflow `ECP-18` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-ECP-19` | Layer-B named donor/workflow `ECP-19` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-ECP-20` | Layer-B named donor/workflow `ECP-20` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-ECP-21` | Layer-B named donor/workflow `ECP-21` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-ECP-22` | Layer-B named donor/workflow `ECP-22` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-ECP-23` | Layer-B named donor/workflow `ECP-23` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-ECP-24` | Layer-B named donor/workflow `ECP-24` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-ECP-25` | Layer-B named donor/workflow `ECP-25` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-ECP-26` | Layer-B named donor/workflow `ECP-26` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-ECP-27` | Layer-B named donor/workflow `ECP-27` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-ECP-28` | Layer-B named donor/workflow `ECP-28` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-ECP-29` | Layer-B named donor/workflow `ECP-29` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-ECP-30` | Layer-B named donor/workflow `ECP-30` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-ECP-31` | Layer-B named donor/workflow `ECP-31` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-ECP-32` | Layer-B named donor/workflow `ECP-32` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-ECP-33` | Layer-B named donor/workflow `ECP-33` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-ECP-34` | Layer-B named donor/workflow `ECP-34` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-ECP-35` | Layer-B named donor/workflow `ECP-35` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-ECP-36` | Layer-B named donor/workflow `ECP-36` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-ECP-37` | Layer-B named donor/workflow `ECP-37` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-ECP-38` | Layer-B named donor/workflow `ECP-38` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-ECP-39` | Layer-B named donor/workflow `ECP-39` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-ECP-40` | Layer-B named donor/workflow `ECP-40` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-ECP-41` | Layer-B named donor/workflow `ECP-41` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-ECP-42` | Layer-B named donor/workflow `ECP-42` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-ECP-43` | Layer-B named donor/workflow `ECP-43` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-ECP-44` | Layer-B named donor/workflow `ECP-44` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-ECP-45` | Layer-B named donor/workflow `ECP-45` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-ECP-46` | Layer-B named donor/workflow `ECP-46` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-ECP-47` | Layer-B named donor/workflow `ECP-47` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-ECP-48` | Layer-B named donor/workflow `ECP-48` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-ADD-01` | Layer-B named donor/workflow `ADD-01` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-ADD-02` | Layer-B named donor/workflow `ADD-02` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-ADD-03` | Layer-B named donor/workflow `ADD-03` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-ADD-04` | Layer-B named donor/workflow `ADD-04` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-MSC-TECH-001` | Layer-B named donor/workflow `MSC-TECH-001` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-MSC-TECH-002` | Layer-B named donor/workflow `MSC-TECH-002` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-MSC-TECH-003` | Layer-B named donor/workflow `MSC-TECH-003` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-MSC-TECH-004` | Layer-B named donor/workflow `MSC-TECH-004` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-MSC-TECH-005` | Layer-B named donor/workflow `MSC-TECH-005` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-MSC-TECH-006` | Layer-B named donor/workflow `MSC-TECH-006` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-MSC-TECH-007` | Layer-B named donor/workflow `MSC-TECH-007` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-MSC-TECH-008` | Layer-B named donor/workflow `MSC-TECH-008` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-MSC-TECH-009` | Layer-B named donor/workflow `MSC-TECH-009` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-MSC-TECH-010` | Layer-B named donor/workflow `MSC-TECH-010` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-MSC-TECH-011` | Layer-B named donor/workflow `MSC-TECH-011` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-MSC-TECH-012` | Layer-B named donor/workflow `MSC-TECH-012` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-MSC-TECH-013` | Layer-B named donor/workflow `MSC-TECH-013` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-MSC-TECH-014` | Layer-B named donor/workflow `MSC-TECH-014` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-MSC-TECH-015` | Layer-B named donor/workflow `MSC-TECH-015` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-TQ-TECH-001` | Layer-B named donor/workflow `TQ-TECH-001` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-TQ-TECH-002` | Layer-B named donor/workflow `TQ-TECH-002` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-TQ-TECH-003` | Layer-B named donor/workflow `TQ-TECH-003` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-TQ-TECH-004` | Layer-B named donor/workflow `TQ-TECH-004` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-TQ-TECH-005` | Layer-B named donor/workflow `TQ-TECH-005` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-TQ-TECH-006` | Layer-B named donor/workflow `TQ-TECH-006` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-TQ-TECH-007` | Layer-B named donor/workflow `TQ-TECH-007` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-TQ-TECH-008` | Layer-B named donor/workflow `TQ-TECH-008` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-TQ-TECH-009` | Layer-B named donor/workflow `TQ-TECH-009` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-TQ-TECH-010` | Layer-B named donor/workflow `TQ-TECH-010` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-TQ-TECH-011` | Layer-B named donor/workflow `TQ-TECH-011` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-TQ-TECH-012` | Layer-B named donor/workflow `TQ-TECH-012` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-TQ-TECH-013` | Layer-B named donor/workflow `TQ-TECH-013` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-TQ-TECH-014` | Layer-B named donor/workflow `TQ-TECH-014` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-TQ-TECH-015` | Layer-B named donor/workflow `TQ-TECH-015` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-TQ-TECH-016` | Layer-B named donor/workflow `TQ-TECH-016` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-TQ-TECH-017` | Layer-B named donor/workflow `TQ-TECH-017` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-TQ-TECH-018` | Layer-B named donor/workflow `TQ-TECH-018` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-TQ-TECH-019` | Layer-B named donor/workflow `TQ-TECH-019` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-TQ-TECH-020` | Layer-B named donor/workflow `TQ-TECH-020` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-TQ-TECH-021` | Layer-B named donor/workflow `TQ-TECH-021` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-TQ-TECH-022` | Layer-B named donor/workflow `TQ-TECH-022` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-TQ-TECH-023` | Layer-B named donor/workflow `TQ-TECH-023` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-TQ-TECH-024` | Layer-B named donor/workflow `TQ-TECH-024` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-TQ-TECH-025` | Layer-B named donor/workflow `TQ-TECH-025` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-TQ-TECH-026` | Layer-B named donor/workflow `TQ-TECH-026` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-TQ-TECH-027` | Layer-B named donor/workflow `TQ-TECH-027` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-TQ-TECH-028` | Layer-B named donor/workflow `TQ-TECH-028` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-TQ-TECH-029` | Layer-B named donor/workflow `TQ-TECH-029` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-TQ-TECH-030` | Layer-B named donor/workflow `TQ-TECH-030` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-TQ-TECH-031` | Layer-B named donor/workflow `TQ-TECH-031` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-MISSION_TO_EXECUTION` | Layer-B named donor/workflow `MISSION_TO_EXECUTION` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-PHASES_RB00_RB15` | Layer-B named donor/workflow `PHASES_RB00_RB15` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-WORKORDER_ADMISSION` | Layer-B named donor/workflow `WORKORDER_ADMISSION` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-CROSS_SESSION_PIPELINE` | Layer-B named donor/workflow `CROSS_SESSION_PIPELINE` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-PROVIDER_ADMISSION` | Layer-B named donor/workflow `PROVIDER_ADMISSION` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-LONG_RUNNING_CONTROL` | Layer-B named donor/workflow `LONG_RUNNING_CONTROL` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-SELF_ITERATION_LOOP` | Layer-B named donor/workflow `SELF_ITERATION_LOOP` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LB-RELEASE_RECOVERY` | Layer-B named donor/workflow `RELEASE_RECOVERY` preserved and routed | App-B | `CLOSED_R2` | `LAYER_B_130` |
| `AR-LC-01` | registry_ref: Project TechnologyAdmission registry pointer | §10.2 | `CLOSED_R2` | `LAYER_C_6` |
| `AR-LC-02` | record_ref: Project TechnologyAdmission exact record pointer | §10.2 | `CLOSED_R2` | `LAYER_C_6` |
| `AR-LC-03` | subject_version_hash: Subject/version/hash binding | §10.2 | `CLOSED_R2` | `LAYER_C_6` |
| `AR-LC-04` | terminal_disposition: Canonical terminal disposition read-through | §10.2 | `CLOSED_R2` | `LAYER_C_6` |
| `AR-LC-05` | currentness_ref: Currentness evidence reference | §10.2 | `CLOSED_R2` | `LAYER_C_6` |
| `AR-LC-06` | runtime_state_separation: Design selection separated from materialize/install/bind/enable/execute/verify | §10.2 | `CLOSED_R2` | `LAYER_C_6` |
| `AR-CUR-CAND-01` | Currentness row `CAND-01` has source/evidence/status dimensions/checked_at/TTL/recheck trigger | §23 | `CLOSED_R2` | `CURRENTNESS_22` |
| `AR-CUR-CAND-02` | Currentness row `CAND-02` has source/evidence/status dimensions/checked_at/TTL/recheck trigger | §23 | `CLOSED_R2` | `CURRENTNESS_22` |
| `AR-CUR-CAND-03` | Currentness row `CAND-03` has source/evidence/status dimensions/checked_at/TTL/recheck trigger | §23 | `CLOSED_R2` | `CURRENTNESS_22` |
| `AR-CUR-CAND-04` | Currentness row `CAND-04` has source/evidence/status dimensions/checked_at/TTL/recheck trigger | §23 | `CLOSED_R2` | `CURRENTNESS_22` |
| `AR-CUR-CAND-05` | Currentness row `CAND-05` has source/evidence/status dimensions/checked_at/TTL/recheck trigger | §23 | `CLOSED_R2` | `CURRENTNESS_22` |
| `AR-CUR-CAND-06` | Currentness row `CAND-06` has source/evidence/status dimensions/checked_at/TTL/recheck trigger | §23 | `CLOSED_R2` | `CURRENTNESS_22` |
| `AR-CUR-CAND-07` | Currentness row `CAND-07` has source/evidence/status dimensions/checked_at/TTL/recheck trigger | §23 | `CLOSED_R2` | `CURRENTNESS_22` |
| `AR-CUR-CAND-08` | Currentness row `CAND-08` has source/evidence/status dimensions/checked_at/TTL/recheck trigger | §23 | `CLOSED_R2` | `CURRENTNESS_22` |
| `AR-CUR-CAND-09` | Currentness row `CAND-09` has source/evidence/status dimensions/checked_at/TTL/recheck trigger | §23 | `CLOSED_R2` | `CURRENTNESS_22` |
| `AR-CUR-CAND-10` | Currentness row `CAND-10` has source/evidence/status dimensions/checked_at/TTL/recheck trigger | §23 | `CLOSED_R2` | `CURRENTNESS_22` |
| `AR-CUR-CAND-11` | Currentness row `CAND-11` has source/evidence/status dimensions/checked_at/TTL/recheck trigger | §23 | `CLOSED_R2` | `CURRENTNESS_22` |
| `AR-CUR-CAND-12` | Currentness row `CAND-12` has source/evidence/status dimensions/checked_at/TTL/recheck trigger | §23 | `CLOSED_R2` | `CURRENTNESS_22` |
| `AR-CUR-CAND-13` | Currentness row `CAND-13` has source/evidence/status dimensions/checked_at/TTL/recheck trigger | §23 | `CLOSED_R2` | `CURRENTNESS_22` |
| `AR-CUR-CAND-14` | Currentness row `CAND-14` has source/evidence/status dimensions/checked_at/TTL/recheck trigger | §23 | `CLOSED_R2` | `CURRENTNESS_22` |
| `AR-CUR-CAND-15` | Currentness row `CAND-15` has source/evidence/status dimensions/checked_at/TTL/recheck trigger | §23 | `CLOSED_R2` | `CURRENTNESS_22` |
| `AR-CUR-CAND-16` | Currentness row `CAND-16` has source/evidence/status dimensions/checked_at/TTL/recheck trigger | §23 | `CLOSED_R2` | `CURRENTNESS_22` |
| `AR-CUR-CAND-17` | Currentness row `CAND-17` has source/evidence/status dimensions/checked_at/TTL/recheck trigger | §23 | `CLOSED_R2` | `CURRENTNESS_22` |
| `AR-CUR-CAND-18` | Currentness row `CAND-18` has source/evidence/status dimensions/checked_at/TTL/recheck trigger | §23 | `CLOSED_R2` | `CURRENTNESS_22` |
| `AR-CUR-CAND-19` | Currentness row `CAND-19` has source/evidence/status dimensions/checked_at/TTL/recheck trigger | §23 | `CLOSED_R2` | `CURRENTNESS_22` |
| `AR-CUR-CAND-20` | Currentness row `CAND-20` has source/evidence/status dimensions/checked_at/TTL/recheck trigger | §23 | `CLOSED_R2` | `CURRENTNESS_22` |
| `AR-CUR-CAND-21` | Currentness row `CAND-21` has source/evidence/status dimensions/checked_at/TTL/recheck trigger | §23 | `CLOSED_R2` | `CURRENTNESS_22` |
| `AR-CUR-CAND-22` | Currentness row `CAND-22` has source/evidence/status dimensions/checked_at/TTL/recheck trigger | §23 | `CLOSED_R2` | `CURRENTNESS_22` |
| `AR-DT-01` | Apparent-PASS destructive fixture DT-01 forces matching gate to FAIL | §24.2 | `CLOSED_R2` | `DESTRUCTIVE_7` |
| `AR-DT-02` | Apparent-PASS destructive fixture DT-02 forces matching gate to FAIL | §24.2 | `CLOSED_R2` | `DESTRUCTIVE_7` |
| `AR-DT-03` | Apparent-PASS destructive fixture DT-03 forces matching gate to FAIL | §24.2 | `CLOSED_R2` | `DESTRUCTIVE_7` |
| `AR-DT-04` | Apparent-PASS destructive fixture DT-04 forces matching gate to FAIL | §24.2 | `CLOSED_R2` | `DESTRUCTIVE_7` |
| `AR-DT-05` | Apparent-PASS destructive fixture DT-05 forces matching gate to FAIL | §24.2 | `CLOSED_R2` | `DESTRUCTIVE_7` |
| `AR-DT-06` | Apparent-PASS destructive fixture DT-06 forces matching gate to FAIL | §24.2 | `CLOSED_R2` | `DESTRUCTIVE_7` |
| `AR-DT-07` | Apparent-PASS destructive fixture DT-07 forces matching gate to FAIL | §24.2 | `CLOSED_R2` | `DESTRUCTIVE_7` |
| `AR-PACK-01` | single_md: Single UTF-8 Markdown artifact exists | §26 | `CLOSED_R2` | `PACKAGING_4` |
| `AR-PACK-02` | payload_hash: payload_sha256 over bytes before BEGIN_PACKAGING_RECEIPT | §26 | `CLOSED_R2` | `PACKAGING_4` |
| `AR-PACK-03` | receipt_scope: hash_scope explicitly declared and non-self-referential | §26 | `CLOSED_R2` | `PACKAGING_4` |
| `AR-PACK-04` | whole_file_delivery: whole-file SHA-256 computed after final write and returned externally | §26 | `CLOSED_R2` | `PACKAGING_4` |
# 21｜Authority Conflict + AUDIT Finding Closure Ledger

## 21.1 Authority conflicts
| ID | Conflict | Resolution | Status |
|---|---|---|---|
| AC-001 | Distribution topology vs semantic baseline | Current delivery controls packaging; A1/A2 semantics preserved | RESOLVED |
| AC-002 | Legacy/projection lifecycle labels vs canonical state tokens | A2 canonical state/claim tokens win | RESOLVED |
| AC-003 | Reduced TechnologyAdmission enum vs full enum | Full 17-value A2 enum preserved | RESOLVED |
| AC-004 | Donor registries vs PIPD semantic authority | Layer-B is identity-preserving support; canonical writers retain authority | RESOLVED |
| AC-005 | Web currentness vs canonical technology selection | Web updates support dimensions only; semantic change requires DOC-02/CR | RESOLVED |
| AC-006 | ECP control vs execution permission | ECP constrains; DOC-05 ExecutionAdmission authorizes | RESOLVED |
| AC-007 | Foreign GRP mount-state token vs PIPD claim namespace | `FOREIGN_GRP_MOUNT_STATE_TOKEN` removed | RESOLVED_R2 |

## 21.2 AUDIT finding closure
| Finding | Closure | Status |
|---|---|---|
| `B-01` | 130/130 Layer-B compact crosswalk in App-B; machine denominator checks exact IDs. | CLOSED_R2_LOCAL |
| `B-02` | r2 denominator rebuilt to 350 rows; includes QS 8, machine 7, Layer A/B/C, SBB, TA fields, currentness, destructive fixtures, packaging. | CLOSED_R2_LOCAL |
| `B-03` | §19 split into file-scan receipt + clause-level ledger with exact line/coverage_kind/mapping/status. | CLOSED_R2_LOCAL |
| `M-01` | §4.3 exact `.pipd` seven-stage machine sequence. | CLOSED_R2_LOCAL |
| `M-02` | §6 eight executable Quickstart paths with entry/read/procedure/stop/owner/shortcut. | CLOSED_R2_LOCAL |
| `M-03` | §9.2 exact 11-step SBB + §9.3 BUILD_MINIMAL/HOLD rules. | CLOSED_R2_LOCAL |
| `M-04` | §10 preserves all 23 A2 TechnologyAdmissionRecord field identities and exact DOC-02 pointer. | CLOSED_R2_LOCAL |
| `M-05` | Main body uses compact Layer-A + Layer-C; Layer-B moved to same-file appendix; no 22×27 second-SSOT tables. | CLOSED_R2_LOCAL |
| `M-06` | §23 corrects OpenSpec to v1.14.0 and gstack to 1.79.0.0; 22/22 support snapshot renewed. | CLOSED_R2_LOCAL |
| `M-07` | §23 splits version/license/security/compatibility plus source title/publisher/type/checked_at/TTL/recheck. | CLOSED_R2_LOCAL |
| `M-08` | Foreign claim token removed from frontmatter/readback. | CLOSED_R2_LOCAL |
| `M-09` | §26 uses payload hash scope before fixed receipt marker; whole-file SHA returned externally after final write. | CLOSED_R2_LOCAL |
| `N-01` | §14 separates lifecycle_state/decision/degrade_status/claim_ceiling_effect. | CLOSED_R2_LOCAL |
| `N-02` | §5 DOC-00 entry condition changed to candidate subject/task exists; applicability may be unresolved. | CLOSED_R2_LOCAL |
| `N-03` | Five-Minute Router Card added before deep body. | CLOSED_R2_LOCAL |
| `N-04` | §23 records immutable pin when available + TTL + recheck trigger; mutable URLs are locators, not identity. | CLOSED_R2_LOCAL |
# 22｜Gap / TT / CR Register

All r1 AUDIT blockers/majors/moderates are closed in this author-side r2 body. There is no target repo/provider binding in this artifact, so project-specific install pins, licenses, security advisories, compatibility matrices, and runtime permissions remain **declared bind-time obligations**, not falsely closed runtime facts.
| Register | Open count | Status / close rule |
|---|---:|---|
| DOC-00 repair TT | 0 | AUDIT findings mapped to concrete r2 body or deterministic index. |
| DOC-00 repair CR | 0 | No architecture reset or canonical disposition change required. |
| Target-binding TT | N/A | Created only when a real project reaches PD and required facts are missing/stale. |
| Technology promotion CR | N/A | Required when `REFERENCE/EVAL/QUARANTINE/REJECT` or existing selection changes toward runtime dependency. |
| Blocking authority conflict | 0 | AC-001..007 resolved by precedence/namespace rule. |
# 23｜2026-10-07 Currentness Support Receipt — 22/22

This receipt is SUPPORT, not TechnologyAdmission authority. The r1 stale OpenSpec/gstack rows are corrected. `license_status`, `security_advisory_status`, and `compatibility_status` are not overstated: where not independently verified for a target, they are explicitly `RECHECK_AT_PD/EVAL`.

## 23.1 Observation/source receipt
| ID | Subject | source_title | publisher | source_type | checked_at | version_or_status | immutable observation / pin | source locator | what_it_supports | authority_class |
|---|---|---|---|---|---|---|---|---|---|---|
| `CAND-01` | GPT-5.6 Sol | OpenAI API model docs | OpenAI | `OFFICIAL_PRODUCT_DOC` | `2026-10-07T10:53:00+08:00` | GPT-5.6 Sol / `gpt-5.6` alias | `MODEL_ID:gpt-5.6` | https://developers.openai.com/api/docs/models/gpt-5.6-sol | version/status/currentness support only | SUPPORT |
| `CAND-02` | OpenAI Codex / Agents SDK | GitHub Releases — openai/codex + openai-agents-python | OpenAI | `OFFICIAL_CANONICAL_REPOSITORY` | `2026-10-07T10:53:00+08:00` | Codex 0.160.1; Agents SDK Python 0.22.3 | `Codex d27764b; Agents SDK tag v0.22.3` | https://github.com/openai/codex/releases ; https://github.com/openai/openai-agents-python/releases | version/status/currentness support only | SUPPORT |
| `CAND-03` | AGENTS.md | AGENTS.md open format | Agentic AI Foundation ecosystem | `OFFICIAL_FORMAT_SITE` | `2026-10-07T10:53:00+08:00` | versionless/open format | `PIN_FILE_PATH_AND_SHA256_AT_PD` | https://agents.md/ | version/status/currentness support only | SUPPORT |
| `CAND-04` | OpenSpec | GitHub Releases — Fission-AI/OpenSpec | Fission-AI | `OFFICIAL_CANONICAL_REPOSITORY` | `2026-10-07T10:53:00+08:00` | v1.14.0 (2026-09-30) | `94ca9c1 / tag v1.14.0` | https://github.com/Fission-AI/OpenSpec/releases | version/status/currentness support only | SUPPORT |
| `CAND-05` | GitHub Spec Kit | GitHub Releases — github/spec-kit | GitHub | `OFFICIAL_CANONICAL_REPOSITORY` | `2026-10-07T10:53:00+08:00` | v1.0.6 (2026-09-10) | `96c9bd6 / tag v1.0.6` | https://github.com/github/spec-kit/releases | version/status/currentness support only | SUPPORT |
| `CAND-06` | Model Context Protocol | The 2026-07-28 Specification | MCP Core Maintainers | `OFFICIAL_STANDARD_RELEASE` | `2026-10-07T10:53:00+08:00` | spec 2026-07-28 | `SPEC_REV:2026-07-28` | https://blog.modelcontextprotocol.io/posts/2026-07-28/ | version/status/currentness support only | SUPPORT |
| `CAND-07` | A2A Protocol | GitHub Releases — a2aproject/A2A | A2A Project | `OFFICIAL_CANONICAL_REPOSITORY` | `2026-10-07T10:53:00+08:00` | v1.0.1 (spec 2026-05-26) | `3303592 / tag v1.0.1` | https://github.com/a2aproject/A2A/releases | version/status/currentness support only | SUPPORT |
| `CAND-08` | OpenTelemetry GenAI Semantic Conventions | open-telemetry/semantic-conventions-genai | OpenTelemetry | `OFFICIAL_CANONICAL_REPOSITORY` | `2026-10-07T10:53:00+08:00` | rolling dedicated GenAI conventions repo | `PIN_COMMIT+SCHEMA_URL_AT_PD` | https://github.com/open-telemetry/semantic-conventions-genai | version/status/currentness support only | SUPPORT |
| `CAND-09` | Pi Coding Agent | Pi Has a New Home at Earendil | Earendil Works / Pi | `OFFICIAL_PROJECT_CHANGELOG` | `2026-10-07T10:53:00+08:00` | new scope from 0.74.0; exact eval pin deferred | `PIN_EXACT_EVAL_RELEASE_AT_EXPERIMENT` | https://pi.dev/changelog/2026/5/7/pi-has-a-new-home | version/status/currentness support only | SUPPORT |
| `CAND-10` | Superpowers | GitHub Releases — obra/superpowers | obra | `OFFICIAL_CANONICAL_REPOSITORY` | `2026-10-07T10:53:00+08:00` | v6.4.2 (2026-09-25) | `8ca22db / tag v6.4.2` | https://github.com/obra/superpowers/releases | version/status/currentness support only | SUPPORT |
| `CAND-11` | gstack | gstack CHANGELOG.md | garrytan/gstack | `OFFICIAL_CANONICAL_REPOSITORY` | `2026-10-07T10:53:00+08:00` | 1.79.0.0 (2026-09-01) | `ROLLING_MAIN_CHANGELOG; pin commit if promoted` | https://github.com/garrytan/gstack/blob/main/CHANGELOG.md | version/status/currentness support only | SUPPORT |
| `CAND-12` | DeepSeek Harness | DeepSeek Harness official site | DeepSeek | `OFFICIAL_PRODUCT_PROJECT_DOC` | `2026-10-07T10:53:00+08:00` | developer preview / rolling | `PIN_EXACT_COMMIT_OR_RELEASE_AT_EVAL` | https://www.deepseek.com/harness/en/ | version/status/currentness support only | SUPPORT |
| `CAND-13` | Open GSD / gsd-core | GitHub Releases — open-gsd/gsd-core | Open GSD | `OFFICIAL_CANONICAL_REPOSITORY` | `2026-10-07T10:53:00+08:00` | v1.15.0 | `b10ab3f / tag v1.15.0` | https://github.com/open-gsd/gsd-core/releases | version/status/currentness support only | SUPPORT |
| `CAND-14` | legacy gsd-build/get-shit-done | Archived canonical repository | legacy GSD | `OFFICIAL_CANONICAL_REPOSITORY` | `2026-10-07T10:53:00+08:00` | archived 2026-06-26 / no-new-adoption | `ARCHIVED_REPO_STATE` | https://github.com/gsd-build/get-shit-done | version/status/currentness support only | SUPPORT |
| `CAND-15` | mattpocock/skills | mattpocock/skills repository/package metadata | mattpocock | `OFFICIAL_CANONICAL_REPOSITORY` | `2026-10-07T10:53:00+08:00` | 1.2.3 | `PIN_TAG_OR_COMMIT_AT_PD` | https://github.com/mattpocock/skills | version/status/currentness support only | SUPPORT |
| `CAND-16` | Hugging Face Agent Skills | huggingface/skills | Hugging Face | `OFFICIAL_CANONICAL_REPOSITORY` | `2026-10-07T10:53:00+08:00` | rolling official skills repo | `PIN_SELECTED_SKILL_COMMIT_DIGEST_AT_PD` | https://github.com/huggingface/skills | version/status/currentness support only | SUPPORT |
| `CAND-17` | AG-UI | GitHub Releases — ag-ui-protocol/ag-ui | AG-UI Project | `OFFICIAL_CANONICAL_REPOSITORY` | `2026-10-07T10:53:00+08:00` | client/core/encoder/proto 1.0.2 (2026-10-05) | `e776b21 / release/2026-10-05` | https://github.com/ag-ui-protocol/ag-ui/releases | version/status/currentness support only | SUPPORT |
| `CAND-18` | NousResearch Hermes Agent | GitHub Releases — NousResearch/hermes-agent | Nous Research | `OFFICIAL_CANONICAL_REPOSITORY` | `2026-10-07T10:53:00+08:00` | v0.21.3 / v2026.9.14 | `345cd2b / tag v2026.9.14` | https://github.com/NousResearch/hermes-agent/releases | version/status/currentness support only | SUPPORT |
| `CAND-19` | Cordis | DeepSeek Harness official architecture description | DeepSeek | `OFFICIAL_PRODUCT_PROJECT_DOC` | `2026-10-07T10:53:00+08:00` | reference kernel in rolling preview | `PIN_SOURCE_COMMIT_IF_PROMOTED` | https://www.deepseek.com/harness/en/ | version/status/currentness support only | SUPPORT |
| `CAND-20` | LongHorizon-Harness research | arXiv:2608.01964 | research authors / arXiv | `RESEARCH_PAPER` | `2026-10-07T10:53:00+08:00` | static research identifier 2608.01964 | `ARXIV:2608.01964` | https://arxiv.org/abs/2608.01964 | version/status/currentness support only | SUPPORT |
| `CAND-21` | Skill-Use benchmark | arXiv:2608.04828 | research authors / arXiv | `RESEARCH_PAPER` | `2026-10-07T10:53:00+08:00` | static research identifier 2608.04828 | `ARXIV:2608.04828` | https://arxiv.org/abs/2608.04828 | version/status/currentness support only | SUPPORT |
| `CAND-22` | HarnessRisk benchmark | arXiv:2608.17597 | research authors / arXiv | `RESEARCH_PAPER` | `2026-10-07T10:53:00+08:00` | static research identifier 2608.17597 | `ARXIV:2608.17597` | https://arxiv.org/abs/2608.17597 | version/status/currentness support only | SUPPORT |

## 23.2 Dimension status / TTL / recheck
| ID | version_currentness | license_status | security_advisory_status | compatibility_status | currentness_ttl | recheck_trigger |
|---|---|---|---|---|---|---|
| `CAND-01` | `CURRENT` | `RECHECK_AT_PD` | `RECHECK_AT_PD` | `RECHECK_AT_PD` | `P7D` | `PD_BIND|INSTALL|RELEASE` |
| `CAND-02` | `CURRENT` | `RECHECK_AT_PD` | `RECHECK_AT_PD` | `RECHECK_AT_PD` | `P7D` | `PD_BIND|INSTALL|RELEASE` |
| `CAND-03` | `CURRENT_VERSIONLESS` | `N/A_FORMAT` | `N/A_FORMAT` | `HOST_COMPAT_RECHECK_AT_PD` | `P7D` | `PD_DISCOVERY|ACTION` |
| `CAND-04` | `CURRENT_REPAIRED_FROM_R1_STALE` | `RECHECK_AT_PD` | `RECHECK_AT_PD` | `RECHECK_AT_PD` | `P7D` | `PD_BIND|INSTALL|RELEASE` |
| `CAND-05` | `CURRENT` | `RECHECK_AT_PD` | `RECHECK_AT_PD` | `RECHECK_AT_PD` | `P7D` | `PD_BIND|INSTALL|RELEASE` |
| `CAND-06` | `CURRENT` | `RECHECK_AT_PD` | `RECHECK_AT_PD` | `SDK_COMPAT_RECHECK_AT_PD` | `P14D` | `PD_BIND|INSTALL|RELEASE` |
| `CAND-07` | `CURRENT` | `RECHECK_AT_PD` | `RECHECK_AT_PD` | `SDK_COMPAT_RECHECK_AT_PD` | `P14D` | `PD_BIND|INSTALL|RELEASE` |
| `CAND-08` | `CURRENT_ROLLING` | `RECHECK_AT_PD` | `RECHECK_AT_PD` | `RECHECK_AT_PD` | `P1D` | `PD_BIND|INSTALL|RELEASE` |
| `CAND-09` | `CURRENT_AT_CLAIM_LEVEL` | `RECHECK_AT_EVAL` | `RECHECK_AT_EVAL` | `RECHECK_AT_EVAL` | `P1D` | `EVAL_START` |
| `CAND-10` | `CURRENT` | `RECHECK_AT_PD` | `RECHECK_AT_PD` | `RECHECK_AT_PD` | `P7D` | `PD_BIND|INSTALL|RELEASE` |
| `CAND-11` | `CURRENT_REPAIRED_FROM_R1_STALE` | `N/A_REFERENCE_UNLESS_PROMOTED` | `N/A_REFERENCE_UNLESS_PROMOTED` | `RECHECK_IF_PROMOTED` | `P7D` | `PROMOTION_CR|PD_BIND` |
| `CAND-12` | `CURRENT_PREVIEW` | `RECHECK_AT_EVAL` | `RECHECK_AT_EVAL` | `RECHECK_AT_EVAL` | `P1D` | `EVAL_START` |
| `CAND-13` | `CURRENT` | `N/A_REFERENCE_UNLESS_PROMOTED` | `N/A_REFERENCE_UNLESS_PROMOTED` | `RECHECK_IF_PROMOTED` | `P14D` | `PROMOTION_CR` |
| `CAND-14` | `CURRENT_ARCHIVED` | `N/A_REJECT` | `N/A_REJECT` | `N/A_REJECT` | `P30D` | `BROWNFIELD_DETECTION` |
| `CAND-15` | `CURRENT` | `MIT_REPORTED_RECHECK_AT_PD` | `RECHECK_AT_PD` | `HOST_COMPAT_RECHECK_AT_PD` | `P7D` | `PD_BIND|INSTALL` |
| `CAND-16` | `CURRENT_ROLLING` | `PER_SKILL_RECHECK_AT_PD` | `RECHECK_AT_PD` | `HF_CLI_HOST_RECHECK_AT_PD` | `P1D` | `PD_BIND|INSTALL|REMOTE_ACTION` |
| `CAND-17` | `CURRENT` | `RECHECK_AT_PD` | `RECHECK_AT_PD` | `RECHECK_AT_PD` | `P7D` | `PD_BIND|INSTALL|RELEASE` |
| `CAND-18` | `CURRENT` | `RECHECK_IN_QUARANTINE` | `RECHECK_IN_QUARANTINE` | `RECHECK_IN_QUARANTINE` | `P1D` | `QUARANTINE_EVAL` |
| `CAND-19` | `CURRENT_AT_REFERENCE_LEVEL` | `N/A_REFERENCE_UNLESS_PROMOTED` | `N/A_REFERENCE_UNLESS_PROMOTED` | `RECHECK_IF_PROMOTED` | `P7D` | `PROMOTION_CR` |
| `CAND-20` | `CURRENT_STATIC_REFERENCE` | `N/A_REFERENCE` | `N/A_REFERENCE` | `N/A_REFERENCE` | `P180D` | `ASSET_IMPORT_IF_ANY` |
| `CAND-21` | `CURRENT_STATIC_REFERENCE` | `N/A_REFERENCE` | `N/A_REFERENCE` | `N/A_REFERENCE` | `P180D` | `ASSET_IMPORT_IF_ANY` |
| `CAND-22` | `CURRENT_STATIC_REFERENCE` | `N/A_REFERENCE` | `N/A_REFERENCE` | `N/A_REFERENCE` | `P180D` | `ASSET_IMPORT_IF_ANY` |

No row with `RECHECK_AT_PD/EVAL` may be interpreted as verified for that dimension. Any TTL expiry or recheck trigger makes that support dimension stale for action until refreshed.

## 23.3 Corrected drift
- `CAND-04 OpenSpec`: r1 `v1.13.2` → r2 `v1.14.0`, official release dated 2026-09-30; terminal design disposition unchanged.
- `CAND-11 gstack`: r1 `1.75.0.0` → r2 `1.79.0.0`, official changelog dated 2026-09-01; `REFERENCE` unchanged.
- These corrections are support/currentness repairs only; no canonical selection was changed.
# 24｜Semantic Self-Conformance — Recomputable Gates

## 24.1 r2 acceptance predicates
| Gate | Name | Pass predicate | r2 result |
|---|---|---|---|
| R2-A01 | Source substantive coverage | Every required DOC-00 source clause has exact anchor + coverage_kind; only SUBSTANTIVE_BODY closes body | PASS |
| R2-A02 | Atomic denominator | 350/350 verification IDs mapped; Quickstart 8/8 | PASS |
| R2-A03 | DOC ownership | DOC-00 does not create second lifecycle/TechnologyAdmission/evidence/handoff SSOT | PASS |
| R2-A04 | Machine read order | MR-01..MR-07 exact `.pipd` sequence present and replayable | PASS |
| R2-A05 | Layer-A | 22/22 CAND identity/disposition/ref present | PASS |
| R2-A06 | Layer-B | 130/130 named donor/workflow IDs present in App-B | PASS |
| R2-A07 | Layer-C | project instance pointer/readback exists; target_bound=false | PASS |
| R2-A08 | SBB | 11 canonical steps + BUILD_MINIMAL/HOLD rules present | PASS |
| R2-A09 | Currentness | 22/22 support rows non-stale at observation; each has checked_at/TTL/recheck; deferred dimensions explicit | PASS |
| R2-A10 | Claim namespace | foreign token count=0; lifecycle/decision/degrade/claim namespaces separate | PASS |
| R2-A11 | Quickstart | 8/8 executable procedures | PASS |
| R2-A12 | Apparent-PASS | DT-01..DT-07 mutation must fail matching predicate | PASS_BY_STATIC_FIXTURE_ORACLE |
| R2-A13 | Progressive disclosure | Five-Minute Router + compact tech main body + same-file deep appendices | PASS |
| R2-A14 | Packaging | payload hash scope defined; whole-file SHA returned after write | PASS_AFTER_FINAL_WRITE_READBACK |

## 24.2 Apparent-PASS destructive fixtures
| Fixture | Mutation | Oracle | Required failure |
|---|---|---|---|
| DT-01 | Delete one or more QS-01..QS-08 while keeping other text | `required_qs_ids - present_qs_ids != ∅` | R2-A02/R2-A11 FAIL |
| DT-02 | Delete any Layer-B ID while generic donor prose remains | `required_layerB_ids - present_layerB_ids != ∅` | R2-A06 FAIL |
| DT-03 | Replace currentness version with stale official release but keep CURRENT label | observed official source/version mismatch | R2-A09 FAIL |
| DT-04 | Remove any of 23 TechnologyAdmission field identities from projection/pointer contract | `required_ta_fields - present_fields != ∅` | R2-A08/ownership read-through FAIL |
| DT-05 | Replace exact `.pipd` order with generic object list | `MR-01..MR-07` replay mismatch | R2-A04 FAIL |
| DT-06 | Compute hash then append receipt without scope marker | payload prefix hash cannot be reproduced | R2-A14 FAIL |
| DT-07 | Insert a foreign lifecycle/claim token such as `FOREIGN_GRP_MOUNT_STATE_TOKEN` | foreign token set non-empty | R2-A10 FAIL |

## 24.3 Gate formulas
```text
R2-A02 = required_atomic_ids - mapped_ids == ∅
R2-A04 = required_machine_stage_ids - present_machine_stage_ids == ∅
R2-A05 = required_layerA_ids - present_layerA_ids == ∅
R2-A06 = required_layerB_ids - present_layerB_ids == ∅
R2-A09 = stale_required_version_currentness == 0
R2-A10 = foreign_claim_tokens == ∅
R2-A11 = required_quickstart_ids - present_quickstart_ids == ∅
R2-A14 = payload_hash_scope_valid && whole_file_sha256_returned_externally
```
# 25｜Final DOC-00 r2 Readback
```yaml
artifact_id: PIPD_LS_DOC-00
version: "2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY"
status: DOC00_R2_FULL_SUBSTANTIVE_BODY_MATERIALIZED
repair_strategy: HIGH_RETENTION_PATCH_NO_ARCHITECTURE_RESET
source_scan: P0+A1+A2+A3+A4+AUDIT_FULL_READ_NO_SAMPLING
source_clause_coverage_rows: 70
atomic_verification_denominator: 350
atomic_mapped: 350
quickstart_paths: 8/8
machine_read_stages: 7/7
layer_a_candidates: 22/22
layer_b_named_identities: 130/130
layer_c_pointer_contract: present
search_before_build_steps: 11/11
technology_admission_field_identities: 23/23
currentness_support_rows: 22/22
audit_findings_closed_locally: 16/16
foreign_claim_tokens: []
open_tt: []
open_cr: []
target_repo_bound: false
implemented: false
installed: false
bound: false
enabled: false
executed: false
runtime_verified: false
independent_pass: false
human_ratified: false
released: false
production_pass: false
whole_file_sha256: EXTERNAL_AFTER_FINAL_WRITE
```
# 26｜Packaging Contract

Single-MD packaging uses a non-self-referential scope:
```yaml
hash_scope: bytes_before_BEGIN_PACKAGING_RECEIPT
payload_sha256: COMPUTED_AFTER_PAYLOAD_BUILD
whole_file_sha256_delivery_readback: EXTERNAL_AFTER_FINAL_WRITE
```
The downloadable whole-file SHA-256 is computed only after the final receipt bytes are written and is returned with delivery. It is not embedded as if it could hash itself.
# Appendix A｜SOP Execution Receipt
| SOP | Execution evidence | Result |
|---|---|---|
| SOP-1 查看索引 | P0/A1/A2/A3/A4/AUDIT/R1 H1–H6 fully scanned; complete heading list in App-H | PASS |
| SOP-2 定位實質條文 | DOC-00 responsibilities, A2 PI-08/SBB/TA fields, A3 read-order/layers/coverage/gates, A4 progressive disclosure, AUDIT findings localized | PASS |
| SOP-3 關鍵字全文檢索 | Core-term count matrix in §19.4 across all required sources | PASS |
| SOP-4 交叉驗證 | Lifecycle/ownership/PI-PD/SBB/LayerA-B-C/currentness/claim/packaging cross-checked | PASS |
| SOP-5 子要求分解 | 8 Quickstarts, 7 machine stages, 11+2 SBB rules, 23 TA fields, 22 Layer-A, 130 Layer-B, 22 currentness rows, 7 destructive fixtures atomized | PASS |
| SOP-6 實質內容判定 | Only substantive body/typed index/predicate may close; scan/headings/self-PASS cannot | PASS |
| SOP-7 工具/技術/工作流/OSS | 22 Layer-A + 130 Layer-B + Layer-C pointer fully named/routed; selection/runtime states separated | PASS |
# Appendix B｜Layer-B Named Donor / Workflow Routing Crosswalk — 130/130

This appendix is intentionally compact and non-authoritative. It preserves donor/workflow identity and routes details back to canonical owners; it does not turn DOC-00 into a second technology book.
## R1 / NOBJ
| Stable ID | Name | Source slot / capability | Source disposition / truth | PIPD treatment | Canonical home | Landing obligation | Anti-downgrade / exit | Source ref |
|---|---|---|---|---|---|---|---|
| <a id="layerb-nobj-001"></a>`NOBJ-001` | HLPE Native PLAN/BOOTSTRAP/FACTORY | SLOT-PLAN-KERNEL | LOCAL_TRANSLATION_ASSET_MATERIALIZED_NOT_HOST_BOUND | REFERENCE | DOC-02 TechnologyAdmission / project-specific binding | preserve donor identity; translate only named capability; project adoption requires terminal TechnologyAdmission/currentness/tests | cannot silently drop or promote; removal/replacement requires crosswalk rationale + CR if already selected/materialized | A3:L879 |
| <a id="layerb-nobj-002"></a>`NOBJ-002` | Matt grill-with-docs | SLOT-REQUIREMENT-CHALLENGE | METHOD_TRANSLATED_LOCAL_EXTERNAL_ADOPTION_NOT_CLAIMED | TRANSLATE | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | preserve donor identity; translate only named capability; project adoption requires terminal TechnologyAdmission/currentness/tests | cannot silently drop or promote; removal/replacement requires crosswalk rationale + CR if already selected/materialized | A3:L880 |
| <a id="layerb-nobj-003"></a>`NOBJ-003` | OpenSpec | SLOT-SPEC-WORKFLOW | SUPPORT_ONLY_NOT_INSTALLED | REFERENCE | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | preserve donor identity; translate only named capability; project adoption requires terminal TechnologyAdmission/currentness/tests | cannot silently drop or promote; removal/replacement requires crosswalk rationale + CR if already selected/materialized | A3:L881 |
| <a id="layerb-nobj-004"></a>`NOBJ-004` | Spec Kit | SLOT-SPEC-CLI | SUPPORT_ONLY_NOT_INSTALLED | REFERENCE | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | preserve donor identity; translate only named capability; project adoption requires terminal TechnologyAdmission/currentness/tests | cannot silently drop or promote; removal/replacement requires crosswalk rationale + CR if already selected/materialized | A3:L882 |
| <a id="layerb-nobj-005"></a>`NOBJ-005` | Superpowers test-driven-development | SLOT-TDD | SUPPORT_ONLY_NOT_INSTALLED | REFERENCE | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | preserve donor identity; translate only named capability; project adoption requires terminal TechnologyAdmission/currentness/tests | cannot silently drop or promote; removal/replacement requires crosswalk rationale + CR if already selected/materialized | A3:L883 |
| <a id="layerb-nobj-006"></a>`NOBJ-006` | Superpowers systematic-debugging | SLOT-DEBUG | SUPPORT_ONLY_NOT_INSTALLED | REFERENCE | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | preserve donor identity; translate only named capability; project adoption requires terminal TechnologyAdmission/currentness/tests | cannot silently drop or promote; removal/replacement requires crosswalk rationale + CR if already selected/materialized | A3:L884 |
| <a id="layerb-nobj-007"></a>`NOBJ-007` | Superpowers verification-before-completion | SLOT-VERIFY | SUPPORT_ONLY_NOT_INSTALLED | REFERENCE | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | preserve donor identity; translate only named capability; project adoption requires terminal TechnologyAdmission/currentness/tests | cannot silently drop or promote; removal/replacement requires crosswalk rationale + CR if already selected/materialized | A3:L885 |
| <a id="layerb-nobj-008"></a>`NOBJ-008` | GStack | SLOT-REVIEW-PATTERN | QUARANTINE_IDENTITY_UNTIL_PIN | QUARANTINE | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | preserve donor identity; translate only named capability; project adoption requires terminal TechnologyAdmission/currentness/tests | cannot silently drop or promote; removal/replacement requires crosswalk rationale + CR if already selected/materialized | A3:L886 |
| <a id="layerb-nobj-009"></a>`NOBJ-009` | GSD / planning-with-files | SLOT-PLANNING-FILES | QUARANTINE_IDENTITY_CONFLICT | QUARANTINE | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | preserve donor identity; translate only named capability; project adoption requires terminal TechnologyAdmission/currentness/tests | cannot silently drop or promote; removal/replacement requires crosswalk rationale + CR if already selected/materialized | A3:L887 |
| <a id="layerb-nobj-010"></a>`NOBJ-010` | AGENTS.md | SLOT-REPO-STEERING | PORTABLE_LOCAL_PROFILE | REFERENCE | DOC-02 TechnologyAdmission / project-specific binding | preserve donor identity; translate only named capability; project adoption requires terminal TechnologyAdmission/currentness/tests | cannot silently drop or promote; removal/replacement requires crosswalk rationale + CR if already selected/materialized | A3:L888 |
| <a id="layerb-nobj-011"></a>`NOBJ-011` | SKILL.md | SLOT-SKILL-CONTRACT | LOCAL_TRANSLATION_ASSET_MATERIALIZED_NOT_HOST_BOUND | REFERENCE | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | preserve donor identity; translate only named capability; project adoption requires terminal TechnologyAdmission/currentness/tests | cannot silently drop or promote; removal/replacement requires crosswalk rationale + CR if already selected/materialized | A3:L889 |
| <a id="layerb-nobj-012"></a>`NOBJ-012` | DESIGN.md | SLOT-DESIGN-RATIONALE | LOCAL_TRANSLATION_ASSET_MATERIALIZED_NOT_HOST_BOUND | REFERENCE | DOC-02 TechnologyAdmission / project-specific binding | preserve donor identity; translate only named capability; project adoption requires terminal TechnologyAdmission/currentness/tests | cannot silently drop or promote; removal/replacement requires crosswalk rationale + CR if already selected/materialized | A3:L890 |
| <a id="layerb-nobj-013"></a>`NOBJ-013` | Prompt projection | SLOT-PROMPT-PROJECTION | LOCAL_TRANSLATION_ASSET_MATERIALIZED_NOT_HOST_BOUND | TRANSLATE | DOC-02 TechnologyAdmission / project-specific binding | preserve donor identity; translate only named capability; project adoption requires terminal TechnologyAdmission/currentness/tests | cannot silently drop or promote; removal/replacement requires crosswalk rationale + CR if already selected/materialized | A3:L891 |
| <a id="layerb-nobj-014"></a>`NOBJ-014` | OpenAI skill-creator | SLOT-SKILL-CREATOR | QUARANTINE_WEB_EVIDENCE_NOT_INSTALLED | QUARANTINE | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | preserve donor identity; translate only named capability; project adoption requires terminal TechnologyAdmission/currentness/tests | cannot silently drop or promote; removal/replacement requires crosswalk rationale + CR if already selected/materialized | A3:L892 |
| <a id="layerb-nobj-015"></a>`NOBJ-015` | OpenAI plugin-creator | SLOT-PLUGIN-CREATOR | QUARANTINE_WEB_EVIDENCE_NOT_INSTALLED | QUARANTINE | DOC-02 TechnologyAdmission / project-specific binding | preserve donor identity; translate only named capability; project adoption requires terminal TechnologyAdmission/currentness/tests | cannot silently drop or promote; removal/replacement requires crosswalk rationale + CR if already selected/materialized | A3:L893 |
| <a id="layerb-nobj-016"></a>`NOBJ-016` | Agent Skills specification | SLOT-AGENT-SKILLS-SPEC | SUPPORT_ONLY_BLOCKED_EXTERNAL | REFERENCE | DOC-09 CI Adapter | preserve donor identity; translate only named capability; project adoption requires terminal TechnologyAdmission/currentness/tests | cannot silently drop or promote; removal/replacement requires crosswalk rationale + CR if already selected/materialized | A3:L894 |
| <a id="layerb-nobj-017"></a>`NOBJ-017` | Agent Plugins 1.0 Working Draft | SLOT-PLUGIN-DRAFT-SPEC | SUPPORT_ONLY_BLOCKED_EXTERNAL | REFERENCE | DOC-02 TechnologyAdmission / project-specific binding | preserve donor identity; translate only named capability; project adoption requires terminal TechnologyAdmission/currentness/tests | cannot silently drop or promote; removal/replacement requires crosswalk rationale + CR if already selected/materialized | A3:L895 |
| <a id="layerb-nobj-018"></a>`NOBJ-018` | JSON Schema 2020-12 | SLOT-SCHEMA-VALIDATOR | LOCAL_TRANSLATION_ASSET_MATERIALIZED_NOT_HOST_BOUND | REFERENCE | DOC-02 TechnologyAdmission / project-specific binding | preserve donor identity; translate only named capability; project adoption requires terminal TechnologyAdmission/currentness/tests | cannot silently drop or promote; removal/replacement requires crosswalk rationale + CR if already selected/materialized | A3:L896 |
| <a id="layerb-nobj-019"></a>`NOBJ-019` | pytest | SLOT-TEST-RUNNER | QUARANTINE_WEB_EVIDENCE_NOT_INSTALLED | QUARANTINE | DOC-02 TechnologyAdmission / project-specific binding | preserve donor identity; translate only named capability; project adoption requires terminal TechnologyAdmission/currentness/tests | cannot silently drop or promote; removal/replacement requires crosswalk rationale + CR if already selected/materialized | A3:L897 |
| <a id="layerb-nobj-020"></a>`NOBJ-020` | GitHub Actions | SLOT-CI | QUARANTINE_WEB_EVIDENCE_NOT_INSTALLED | QUARANTINE | DOC-09 CI Adapter | preserve donor identity; translate only named capability; project adoption requires terminal TechnologyAdmission/currentness/tests | cannot silently drop or promote; removal/replacement requires crosswalk rationale + CR if already selected/materialized | A3:L898 |
| <a id="layerb-nobj-021"></a>`NOBJ-021` | CycloneDX | SLOT-SBOM | QUARANTINE_WEB_EVIDENCE_NOT_INSTALLED | QUARANTINE | DOC-09 Release/Supply-Chain | preserve donor identity; translate only named capability; project adoption requires terminal TechnologyAdmission/currentness/tests | cannot silently drop or promote; removal/replacement requires crosswalk rationale + CR if already selected/materialized | A3:L899 |
| <a id="layerb-nobj-022"></a>`NOBJ-022` | Gitleaks | SLOT-SECRET-SCAN | QUARANTINE_WEB_EVIDENCE_NOT_INSTALLED | QUARANTINE | DOC-07 TQAEP/Security | preserve donor identity; translate only named capability; project adoption requires terminal TechnologyAdmission/currentness/tests | cannot silently drop or promote; removal/replacement requires crosswalk rationale + CR if already selected/materialized | A3:L900 |
| <a id="layerb-nobj-023"></a>`NOBJ-023` | markdownlint | SLOT-MARKDOWN-LINT | QUARANTINE_WEB_EVIDENCE_NOT_INSTALLED | QUARANTINE | DOC-02 TechnologyAdmission / project-specific binding | preserve donor identity; translate only named capability; project adoption requires terminal TechnologyAdmission/currentness/tests | cannot silently drop or promote; removal/replacement requires crosswalk rationale + CR if already selected/materialized | A3:L901 |
| <a id="layerb-nobj-024"></a>`NOBJ-024` | Ruff + type checker | SLOT-PYTHON-LINT | QUARANTINE_WEB_EVIDENCE_NOT_INSTALLED | QUARANTINE | DOC-02 TechnologyAdmission / project-specific binding | preserve donor identity; translate only named capability; project adoption requires terminal TechnologyAdmission/currentness/tests | cannot silently drop or promote; removal/replacement requires crosswalk rationale + CR if already selected/materialized | A3:L902 |
## R2 / ECP
| Stable ID | Name | Source slot / capability | Source disposition / truth | PIPD treatment | Canonical home | Landing obligation | Anti-downgrade / exit | Source ref |
|---|---|---|---|---|---|---|---|
| <a id="layerb-ecp-01"></a>`ECP-01` | Spec Kit | method/spec-provider / S2E L2 specification adapter | ADOPT+QUALIFY | EVAL | DOC-09 CI Adapter | capability pattern/adapter for method/spec-provider / S2E L2 specification adapter; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | A3:L909 |
| <a id="layerb-ecp-02"></a>`ECP-02` | OpenSpec | method/spec-provider / S2E L2 brownfield change adapter | ADOPT+QUALIFY | EVAL | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | capability pattern/adapter for method/spec-provider / S2E L2 brownfield change adapter; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | A3:L910 |
| <a id="layerb-ecp-03"></a>`ECP-03` | Matt Skills / mattpocock-skills | skill/workflow / requirement challenge/slicing/implementation discipline | QUALIFY | EVAL | DOC-09 CI Adapter | capability pattern/adapter for skill/workflow / requirement challenge/slicing/implementation discipline; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | A3:L911 |
| <a id="layerb-ecp-04"></a>`ECP-04` | Superpowers | skill/workflow / TDD/debug/verification discipline | QUALIFY | EVAL | DOC-09 CI Adapter | capability pattern/adapter for skill/workflow / TDD/debug/verification discipline; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | A3:L912 |
| <a id="layerb-ecp-05"></a>`ECP-05` | gstack | skill/workflow / engineering review/QA/ship donor | QUALIFY | EVAL | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | capability pattern/adapter for skill/workflow / engineering review/QA/ship donor; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | A3:L913 |
| <a id="layerb-ecp-06"></a>`ECP-06` | GSD | workflow donor / long-task planning/checkpoint pattern | QUALIFY | EVAL | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | capability pattern/adapter for workflow donor / long-task planning/checkpoint pattern; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | A3:L914 |
| <a id="layerb-ecp-07"></a>`ECP-07` | OROCHI / SRU | legacy execution lineage / Execution Factory bounded route-out donor | ROUTE_OUT+ADOPT_BOUNDED_DONOR | ROUTE_OUT | DOC-03 Provider/Harness Binding + ECP/TQAEP | capability pattern/adapter for legacy execution lineage / Execution Factory bounded route-out donor; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | A3:L915 |
| <a id="layerb-ecp-08"></a>`ECP-08` | Codex App Server | provider / MHPL primary coding candidate | QUALIFY_PRIMARY | EVAL | DOC-03 Provider/Harness Binding + ECP/TQAEP | capability pattern/adapter for provider / MHPL primary coding candidate; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | A3:L916 |
| <a id="layerb-ecp-09"></a>`ECP-09` | codex app-server-client | provider seam / MHPL in-process client seam | CONDITIONAL | REFERENCE | DOC-03 Provider/Harness Binding + ECP/TQAEP | capability pattern/adapter for provider seam / MHPL in-process client seam; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | A3:L917 |
| <a id="layerb-ecp-10"></a>`ECP-10` | Hermes | provider/session UI / GENIE session/orchestration surface | ADOPT+QUALIFY | EVAL | DOC-03 Provider/Harness Binding + ECP/TQAEP | capability pattern/adapter for provider/session UI / GENIE session/orchestration surface; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | A3:L918 |
| <a id="layerb-ecp-11"></a>`ECP-11` | OpenCode | provider / MHPL coding alternate | QUALIFY | EVAL | DOC-03 Provider/Harness Binding + ECP/TQAEP | capability pattern/adapter for provider / MHPL coding alternate; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | A3:L919 |
| <a id="layerb-ecp-12"></a>`ECP-12` | Pi | provider / MHPL embedded alternate | QUALIFY | EVAL | DOC-03 Provider/Harness Binding + ECP/TQAEP | capability pattern/adapter for provider / MHPL embedded alternate; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | A3:L920 |
| <a id="layerb-ecp-13"></a>`ECP-13` | DeepSeek Harness | harness / MHPL shadow/runtime donor | SHADOW | EVAL | DOC-03 Provider/Harness Binding + ECP/TQAEP | capability pattern/adapter for harness / MHPL shadow/runtime donor; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | A3:L921 |
| <a id="layerb-ecp-14"></a>`ECP-14` | UHP | protocol / MHPL compatibility projection | PILOT_COMPATIBILITY_ONLY | EVAL | DOC-03 Interop Binding + DOC-07 Conformance | capability pattern/adapter for protocol / MHPL compatibility projection; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | A3:L922 |
| <a id="layerb-ecp-15"></a>`ECP-15` | A2A | protocol / cross-Agent/Fabric interop | ADOPT_BOUNDARY | KEEP | DOC-03 Interop Binding + DOC-07 Conformance | capability pattern/adapter for protocol / cross-Agent/Fabric interop; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | A3:L923 |
| <a id="layerb-ecp-16"></a>`ECP-16` | Temporal | orchestrator / durable workflow primary pilot | PILOT_PRIMARY | EVAL | DOC-03 Provider/Harness Binding + ECP/TQAEP | capability pattern/adapter for orchestrator / durable workflow primary pilot; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | A3:L924 |
| <a id="layerb-ecp-17"></a>`ECP-17` | OpenAI Agents SDK | orchestration runtime donor / manager/handoff/guardrail pattern/provider | ADOPT_PATTERN+QUALIFY | EVAL | DOC-02 TechnologyAdmission / project-specific binding | capability pattern/adapter for orchestration runtime donor / manager/handoff/guardrail pattern/provider; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | A3:L925 |
| <a id="layerb-ecp-18"></a>`ECP-18` | Dapr | orchestrator / durable alternate | QUALIFY_ALTERNATE | EVAL | DOC-03 Provider/Harness Binding + ECP/TQAEP | capability pattern/adapter for orchestrator / durable alternate; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | A3:L926 |
| <a id="layerb-ecp-19"></a>`ECP-19` | Restate | orchestrator / lightweight durable alternate | QUALIFY_ALTERNATE | EVAL | DOC-03 Provider/Harness Binding + ECP/TQAEP | capability pattern/adapter for orchestrator / lightweight durable alternate; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | A3:L927 |
| <a id="layerb-ecp-20"></a>`ECP-20` | LongHorizon-Harness | research pattern / manager/execute/audit long-horizon donor | ADOPT_PATTERN | TRANSLATE | DOC-03 Provider/Harness Binding + ECP/TQAEP | capability pattern/adapter for research pattern / manager/execute/audit long-horizon donor; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | A3:L928 |
| <a id="layerb-ecp-21"></a>`ECP-21` | HELIX | research pattern / harness evolution/trajectory donor | ADOPT_PATTERN | TRANSLATE | DOC-03 Provider/Harness Binding + ECP/TQAEP | capability pattern/adapter for research pattern / harness evolution/trajectory donor; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | A3:L929 |
| <a id="layerb-ecp-22"></a>`ECP-22` | HarnessRisk | research/benchmark / harness lifecycle safety donor | ADOPT_PATTERN | TRANSLATE | DOC-03 Provider/Harness Binding + ECP/TQAEP | capability pattern/adapter for research/benchmark / harness lifecycle safety donor; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | A3:L930 |
| <a id="layerb-ecp-23"></a>`ECP-23` | MCP Inspector v2 | conformance tool / MCP qualification runner | QUALIFY | EVAL | DOC-03 Interop Binding + DOC-07 Conformance | capability pattern/adapter for conformance tool / MCP qualification runner; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | A3:L931 |
| <a id="layerb-ecp-24"></a>`ECP-24` | Trivy | security scanner / vuln/misconfig/secret/SBOM/license evidence | QUALIFY | EVAL | DOC-09 Release/Supply-Chain | capability pattern/adapter for security scanner / vuln/misconfig/secret/SBOM/license evidence; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | A3:L932 |
| <a id="layerb-ecp-25"></a>`ECP-25` | GitHub Agentic Workflows Safe Outputs | side-effect pattern / GitHub bounded mutation donor | ADOPT_PATTERN | TRANSLATE | DOC-09 CI Adapter | capability pattern/adapter for side-effect pattern / GitHub bounded mutation donor; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | A3:L933 |
| <a id="layerb-ecp-26"></a>`ECP-26` | GitHub Actions | CI/CD / deterministic build/test/release gates | ADOPT | KEEP | DOC-09 CI Adapter | capability pattern/adapter for CI/CD / deterministic build/test/release gates; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | A3:L934 |
| <a id="layerb-ecp-27"></a>`ECP-27` | OpenTelemetry | observability / telemetry vocabulary/correlation | ADOPT | KEEP | DOC-02 TechnologyAdmission / project-specific binding | capability pattern/adapter for observability / telemetry vocabulary/correlation; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | A3:L935 |
| <a id="layerb-ecp-28"></a>`ECP-28` | SLSA v1.2 | standard / supply-chain provenance expectations | ADOPT_STANDARD | TRANSLATE | DOC-09 Release/Supply-Chain | capability pattern/adapter for standard / supply-chain provenance expectations; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | A3:L936 |
| <a id="layerb-ecp-29"></a>`ECP-29` | Sigstore / Cosign | provenance verifier / signature/attestation verification | ADOPT | KEEP | DOC-09 Release/Supply-Chain | capability pattern/adapter for provenance verifier / signature/attestation verification; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | A3:L937 |
| <a id="layerb-ecp-30"></a>`ECP-30` | GitHub Artifact Attestations | provenance provider / GitHub release provenance | ADOPT | KEEP | DOC-09 Release/Supply-Chain | capability pattern/adapter for provenance provider / GitHub release provenance; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | A3:L938 |
| <a id="layerb-ecp-31"></a>`ECP-31` | Plane | PM provider / ProjectManagementProviderSlot | PILOT_PROJECTION_ONLY | EVAL | DOC-08 Projection Adapter | capability pattern/adapter for PM provider / ProjectManagementProviderSlot; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | A3:L939 |
| <a id="layerb-ecp-32"></a>`ECP-32` | Linear | PM provider / ProjectManagementProviderSlot | PILOT_PROJECTION_ONLY | EVAL | DOC-08 Projection Adapter | capability pattern/adapter for PM provider / ProjectManagementProviderSlot; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | A3:L940 |
| <a id="layerb-ecp-33"></a>`ECP-33` | OpenProject | PM provider / ProjectManagementProviderSlot | PILOT_ENTERPRISE_PROJECTION_ONLY | EVAL | DOC-08 Projection Adapter | capability pattern/adapter for PM provider / ProjectManagementProviderSlot; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | A3:L941 |
| <a id="layerb-ecp-34"></a>`ECP-34` | ProjectManagementProviderSlot | internal abstraction / Delivery projection boundary | PROPOSED_CONTRACT | REFERENCE | DOC-08 Projection Adapter | capability pattern/adapter for internal abstraction / Delivery projection boundary; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | A3:L942 |
| <a id="layerb-ecp-35"></a>`ECP-35` | Tree-sitter | code intelligence / Semantic Context baseline parser | ADOPT | KEEP | DOC-03 RepoContext/Semantic Context | capability pattern/adapter for code intelligence / Semantic Context baseline parser; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | A3:L943 |
| <a id="layerb-ecp-36"></a>`ECP-36` | LSP | code intelligence / Semantic Context baseline symbol/reference provider | ADOPT | KEEP | DOC-03 RepoContext/Semantic Context | capability pattern/adapter for code intelligence / Semantic Context baseline symbol/reference provider; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | A3:L944 |
| <a id="layerb-ecp-37"></a>`ECP-37` | SCIP | code intelligence / optional compiler-grade index | ADOPT_OPTIONAL | REFERENCE | DOC-09 CI Adapter | capability pattern/adapter for code intelligence / optional compiler-grade index; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | A3:L945 |
| <a id="layerb-ecp-38"></a>`ECP-38` | Git | source control / source/history canonical baseline | ADOPT | KEEP | DOC-02 TechnologyAdmission / project-specific binding | capability pattern/adapter for source control / source/history canonical baseline; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | A3:L946 |
| <a id="layerb-ecp-39"></a>`ECP-39` | ripgrep | search / lexical fallback/baseline | ADOPT | KEEP | DOC-03 RepoContext/Semantic Context | capability pattern/adapter for search / lexical fallback/baseline; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | A3:L947 |
| <a id="layerb-ecp-40"></a>`ECP-40` | MCP | protocol / agent→tool capability surface | ADOPT | KEEP | DOC-03 Interop Binding + DOC-07 Conformance | capability pattern/adapter for protocol / agent→tool capability surface; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | A3:L948 |
| <a id="layerb-ecp-41"></a>`ECP-41` | AGENTS.md | instruction projection / repo/agent instruction interop | ADOPT_PROJECTION | TRANSLATE | DOC-02 TechnologyAdmission / project-specific binding | capability pattern/adapter for instruction projection / repo/agent instruction interop; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | A3:L949 |
| <a id="layerb-ecp-42"></a>`ECP-42` | SKILL.md | skill projection / Agent Skills reusable workflow interop | ADOPT_PROJECTION | TRANSLATE | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | capability pattern/adapter for skill projection / Agent Skills reusable workflow interop; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | A3:L950 |
| <a id="layerb-ecp-43"></a>`ECP-43` | Claude Code | architecture donor / public harness engineering patterns | ADOPT_PUBLIC_PATTERN_ONLY / REJECT_LEAK_CODE | REJECT | DOC-03 Provider/Harness Binding + ECP/TQAEP | capability pattern/adapter for architecture donor / public harness engineering patterns; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | A3:L951 |
| <a id="layerb-ecp-44"></a>`ECP-44` | Codanna | code intelligence candidate / Semantic Context shadow | SHADOW_EVAL | EVAL | DOC-03 RepoContext/Semantic Context | capability pattern/adapter for code intelligence candidate / Semantic Context shadow; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | A3:L952 |
| <a id="layerb-ecp-45"></a>`ECP-45` | CodeGraph | code intelligence candidate / Semantic Context shadow | SHADOW_EVAL | EVAL | DOC-03 RepoContext/Semantic Context | capability pattern/adapter for code intelligence candidate / Semantic Context shadow; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | A3:L953 |
| <a id="layerb-ecp-46"></a>`ECP-46` | rag-rat | code intelligence candidate / Semantic Context shadow/retrieval-memory | SHADOW_EVAL | EVAL | DOC-03 RepoContext/Semantic Context | capability pattern/adapter for code intelligence candidate / Semantic Context shadow/retrieval-memory; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | A3:L954 |
| <a id="layerb-ecp-47"></a>`ECP-47` | OpenHands | harness/provider / MHPL alternate/reference donor | QUALIFY_REFERENCE | EVAL | DOC-03 Provider/Harness Binding + ECP/TQAEP | capability pattern/adapter for harness/provider / MHPL alternate/reference donor; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | A3:L955 |
| <a id="layerb-ecp-48"></a>`ECP-48` | MoRSE | research pattern / role-subtask specialization donor | ADOPT_PATTERN | TRANSLATE | DOC-09 CI Adapter | capability pattern/adapter for research pattern / role-subtask specialization donor; preserve source qualification/fallback/drift/exit fields | no lifecycle/product-truth/release authority inheritance; project adoption needs TechnologyAdmission; use source exit/provider-off | A3:L956 |
## R2 / ECP-ADD
| Stable ID | Name | Source slot / capability | Source disposition / truth | PIPD treatment | Canonical home | Landing obligation | Anti-downgrade / exit | Source ref |
|---|---|---|---|---|---|---|---|
| <a id="layerb-add-01"></a>`ADD-01` | Agent Skills open standard | portable capability format / Skills packaging/interoperability | ADOPT_CANONICAL_PORTABLE_FORMAT | TRANSLATE | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | preserve additive donor capability and source pin/qualification boundary | no second authority; CR/TechnologyAdmission before runtime dependency | A3:L957 |
| <a id="layerb-add-02"></a>`ADD-02` | OpenAI Skills | host capability surface / reusable workflow host projection | PRIMARY_HOST_TARGET | REFERENCE | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | preserve additive donor capability and source pin/qualification boundary | no second authority; CR/TechnologyAdmission before runtime dependency | A3:L958 |
| <a id="layerb-add-03"></a>`ADD-03` | OpenAI Plugin | host packaging surface / multi-Skill container; Apps optional | HOST_PACKAGING | REFERENCE | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | preserve additive donor capability and source pin/qualification boundary | no second authority; CR/TechnologyAdmission before runtime dependency | A3:L959 |
| <a id="layerb-add-04"></a>`ADD-04` | StateM | research/runtime pattern donor / durable state/checked transition/recoverable runbook | ADOPT_PATTERN + PILOT_DONOR | EVAL | DOC-02 TechnologyAdmission / project-specific binding | preserve additive donor capability and source pin/qualification boundary | no second authority; CR/TechnologyAdmission before runtime dependency | A3:L960 |
## R2 / MSC
| Stable ID | Name | Source slot / capability | Source disposition / truth | PIPD treatment | Canonical home | Landing obligation | Anti-downgrade / exit | Source ref |
|---|---|---|---|---|---|---|---|
| <a id="layerb-msc-tech-001"></a>`MSC-TECH-001` | Spec Kit Presets/Bundles | SKELETON_COMPOSITION | P1_PATTERN_REUSE_STAGE0 | TRANSLATE | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | preserve role/disposition; Stage-0/currentness/qualification as source requires; no silent core dependency | A3:L967 |
| <a id="layerb-msc-tech-002"></a>`MSC-TECH-002` | OpenSpec Project Config/Custom Schema | SCHEMA_WORKFLOW | P1_REUSE_STAGE0 | TRANSLATE | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | preserve role/disposition; Stage-0/currentness/qualification as source requires; no silent core dependency | A3:L968 |
| <a id="layerb-msc-tech-003"></a>`MSC-TECH-003` | Agent Skills / skills-ref | CAPABILITY_PACKAGING | P1_REUSE | TRANSLATE | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | preserve role/disposition; Stage-0/currentness/qualification as source requires; no silent core dependency | A3:L969 |
| <a id="layerb-msc-tech-004"></a>`MSC-TECH-004` | Hugging Face Skills | CAPABILITY_ECOSYSTEM | CONDITIONAL_REUSE | TRANSLATE | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | preserve role/disposition; Stage-0/currentness/qualification as source requires; no silent core dependency | A3:L970 |
| <a id="layerb-msc-tech-005"></a>`MSC-TECH-005` | CUE | CONSTRAINT_COMPOSITION | P2_ONLY_IF_NATIVE_GAP | REFERENCE | DOC-02 TechnologyAdmission / project-specific binding | preserve role/disposition; Stage-0/currentness/qualification as source requires; no silent core dependency | A3:L971 |
| <a id="layerb-msc-tech-006"></a>`MSC-TECH-006` | OPA/Rego | POLICY | CONDITIONAL_HIGH_RISK | REFERENCE | DOC-02 TechnologyAdmission / project-specific binding | preserve role/disposition; Stage-0/currentness/qualification as source requires; no silent core dependency | A3:L972 |
| <a id="layerb-msc-tech-007"></a>`MSC-TECH-007` | Backstage Scaffolder | SCAFFOLDER | P2_SCALE_TRIGGERED | REFERENCE | DOC-02 TechnologyAdmission / project-specific binding | preserve role/disposition; Stage-0/currentness/qualification as source requires; no silent core dependency | A3:L973 |
| <a id="layerb-msc-tech-008"></a>`MSC-TECH-008` | Kustomize | DEPLOYMENT_OVERLAY | K8S_ONLY | REFERENCE | DOC-02 TechnologyAdmission / project-specific binding | preserve role/disposition; Stage-0/currentness/qualification as source requires; no silent core dependency | A3:L974 |
| <a id="layerb-msc-tech-009"></a>`MSC-TECH-009` | DeepSeek Harness profiles/bundles | RUNTIME_COMPOSITION_DONOR | SUPPORT_PILOT_EARLY_PREVIEW | EVAL | DOC-03 Provider/Harness Binding + ECP/TQAEP | preserve role/disposition; Stage-0/currentness/qualification as source requires; no silent core dependency | A3:L975 |
| <a id="layerb-msc-tech-010"></a>`MSC-TECH-010` | Task-Aware Harness Provisioning | RESEARCH_METHOD | METHOD_DONOR | TRANSLATE | DOC-03 Provider/Harness Binding + ECP/TQAEP | preserve role/disposition; Stage-0/currentness/qualification as source requires; no silent core dependency | A3:L976 |
| <a id="layerb-msc-tech-011"></a>`MSC-TECH-011` | HarnessRisk | EVALUATION_FIXTURE_DONOR | EVAL_DONOR | EVAL | DOC-03 Provider/Harness Binding + ECP/TQAEP | preserve role/disposition; Stage-0/currentness/qualification as source requires; no silent core dependency | A3:L977 |
| <a id="layerb-msc-tech-012"></a>`MSC-TECH-012` | SkillGate | SELECTOR_RESEARCH_DONOR | RESEARCH_DONOR | REFERENCE | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | preserve role/disposition; Stage-0/currentness/qualification as source requires; no silent core dependency | A3:L978 |
| <a id="layerb-msc-tech-013"></a>`MSC-TECH-013` | Demystifying Agent Skills | SELECTOR_RESEARCH_DONOR | RESEARCH_DONOR | REFERENCE | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | preserve role/disposition; Stage-0/currentness/qualification as source requires; no silent core dependency | A3:L979 |
| <a id="layerb-msc-tech-014"></a>`MSC-TECH-014` | StateM | LONG_HORIZON_DONOR | RESEARCH_PILOT_DONOR | EVAL | DOC-02 TechnologyAdmission / project-specific binding | preserve role/disposition; Stage-0/currentness/qualification as source requires; no silent core dependency | A3:L980 |
| <a id="layerb-msc-tech-015"></a>`MSC-TECH-015` | Hermes Agent | COMMUNITY_RUNTIME_RISK_DONOR | SUPPORT_ONLY | REFERENCE | DOC-03 Provider/Harness Binding + ECP/TQAEP | preserve role/disposition; Stage-0/currentness/qualification as source requires; no silent core dependency | A3:L981 |
## R3 / TQAEP
| Stable ID | Name | Source slot / capability | Source disposition / truth | PIPD treatment | Canonical home | Landing obligation | Anti-downgrade / exit | Source ref |
|---|---|---|---|---|---|---|---|
| <a id="layerb-tq-tech-001"></a>`TQ-TECH-001` | NVIDIA SkillEvaluator | SKILL_PLUGIN_EVAL | P1_PILOT | EVAL | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | source test/provider slot semantics preserved; runtime use requires exact candidate currentness/rights/host qualification; provider-off/alternate defined | A3:L988 |
| <a id="layerb-tq-tech-002"></a>`TQ-TECH-002` | ACES methodology | SKILL_PLUGIN_EVAL_METHOD | P1_METHOD_ADOPT | TRANSLATE | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | source test/provider slot semantics preserved; runtime use requires exact candidate currentness/rights/host qualification; provider-off/alternate defined | A3:L989 |
| <a id="layerb-tq-tech-003"></a>`TQ-TECH-003` | Harbor | RUNTIME_EVAL_RUNNER | P1_ADOPT_CANDIDATE | EVAL | DOC-02 TechnologyAdmission / project-specific binding | source test/provider slot semantics preserved; runtime use requires exact candidate currentness/rights/host qualification; provider-off/alternate defined | A3:L990 |
| <a id="layerb-tq-tech-004"></a>`TQ-TECH-004` | Agent Skills / skills-ref | PACKAGING_STANDARD | P1_FORMAT_VALIDATOR | TRANSLATE | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | source test/provider slot semantics preserved; runtime use requires exact candidate currentness/rights/host qualification; provider-off/alternate defined | A3:L991 |
| <a id="layerb-tq-tech-005"></a>`TQ-TECH-005` | MCP Inspector v2 | PROTOCOL_CONFORMANCE | REQUIRED_WHERE_MCP | REFERENCE | DOC-03 Interop Binding + DOC-07 Conformance | source test/provider slot semantics preserved; runtime use requires exact candidate currentness/rights/host qualification; provider-off/alternate defined | A3:L992 |
| <a id="layerb-tq-tech-006"></a>`TQ-TECH-006` | Spec Kit /speckit.converge | SPEC_GAP | P1_REUSE_SOFTWARE | TRANSLATE | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | source test/provider slot semantics preserved; runtime use requires exact candidate currentness/rights/host qualification; provider-off/alternate defined | A3:L993 |
| <a id="layerb-tq-tech-007"></a>`TQ-TECH-007` | OpenSpec /opsx:verify | SPEC_VERIFY | P1_REUSE_SOFTWARE | TRANSLATE | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | source test/provider slot semantics preserved; runtime use requires exact candidate currentness/rights/host qualification; provider-off/alternate defined | A3:L994 |
| <a id="layerb-tq-tech-008"></a>`TQ-TECH-008` | Superpowers | METHOD_DONOR | P1_METHOD_DONOR | TRANSLATE | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | source test/provider slot semantics preserved; runtime use requires exact candidate currentness/rights/host qualification; provider-off/alternate defined | A3:L995 |
| <a id="layerb-tq-tech-009"></a>`TQ-TECH-009` | mattpocock-skills | SPEC_REVIEW_DONOR | P2_DONOR | REFERENCE | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | source test/provider slot semantics preserved; runtime use requires exact candidate currentness/rights/host qualification; provider-off/alternate defined | A3:L996 |
| <a id="layerb-tq-tech-010"></a>`TQ-TECH-010` | grill-with-docs | METHOD_DONOR | P2_DONOR_ONLY | REFERENCE | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | source test/provider slot semantics preserved; runtime use requires exact candidate currentness/rights/host qualification; provider-off/alternate defined | A3:L997 |
| <a id="layerb-tq-tech-011"></a>`TQ-TECH-011` | to-spec | METHOD_DONOR | P2_DONOR_ONLY | REFERENCE | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | source test/provider slot semantics preserved; runtime use requires exact candidate currentness/rights/host qualification; provider-off/alternate defined | A3:L998 |
| <a id="layerb-tq-tech-012"></a>`TQ-TECH-012` | code-review (mattpocock-skills) | REVIEW_PROVIDER_METHOD | P2_DONOR_ONLY | REFERENCE | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | source test/provider slot semantics preserved; runtime use requires exact candidate currentness/rights/host qualification; provider-off/alternate defined | A3:L999 |
| <a id="layerb-tq-tech-013"></a>`TQ-TECH-013` | gstack | REVIEW_PROVIDER | P2_BUDGETED | REFERENCE | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | source test/provider slot semantics preserved; runtime use requires exact candidate currentness/rights/host qualification; provider-off/alternate defined | A3:L1000 |
| <a id="layerb-tq-tech-014"></a>`TQ-TECH-014` | Trivy | SECURITY_SCANNER | P1 | REFERENCE | DOC-07 TQAEP/Security | source test/provider slot semantics preserved; runtime use requires exact candidate currentness/rights/host qualification; provider-off/alternate defined | A3:L1001 |
| <a id="layerb-tq-tech-015"></a>`TQ-TECH-015` | SLSA v1.2 | PROVENANCE_STANDARD | P1 | REFERENCE | DOC-09 Release/Supply-Chain | source test/provider slot semantics preserved; runtime use requires exact candidate currentness/rights/host qualification; provider-off/alternate defined | A3:L1002 |
| <a id="layerb-tq-tech-016"></a>`TQ-TECH-016` | GitHub Artifact Attestations | PROVENANCE_VERIFIER | P1_WHERE_GITHUB | REFERENCE | DOC-09 Release/Supply-Chain | source test/provider slot semantics preserved; runtime use requires exact candidate currentness/rights/host qualification; provider-off/alternate defined | A3:L1003 |
| <a id="layerb-tq-tech-017"></a>`TQ-TECH-017` | Sigstore / Cosign | PROVENANCE_VERIFIER | P1_ALTERNATE | REFERENCE | DOC-09 Release/Supply-Chain | source test/provider slot semantics preserved; runtime use requires exact candidate currentness/rights/host qualification; provider-off/alternate defined | A3:L1004 |
| <a id="layerb-tq-tech-018"></a>`TQ-TECH-018` | OpenTelemetry GenAI | OBSERVABILITY_PROVIDER | P2_OBSERVATION_ONLY | REFERENCE | DOC-02 TechnologyAdmission / project-specific binding | source test/provider slot semantics preserved; runtime use requires exact candidate currentness/rights/host qualification; provider-off/alternate defined | A3:L1005 |
| <a id="layerb-tq-tech-019"></a>`TQ-TECH-019` | StateM | RESEARCH_DONOR | P3_PATTERN_PILOT | EVAL | DOC-02 TechnologyAdmission / project-specific binding | source test/provider slot semantics preserved; runtime use requires exact candidate currentness/rights/host qualification; provider-off/alternate defined | A3:L1006 |
| <a id="layerb-tq-tech-020"></a>`TQ-TECH-020` | HarnessRisk | RESEARCH_DONOR | P3_FIXTURE_DONOR | REFERENCE | DOC-03 Provider/Harness Binding + ECP/TQAEP | source test/provider slot semantics preserved; runtime use requires exact candidate currentness/rights/host qualification; provider-off/alternate defined | A3:L1007 |
| <a id="layerb-tq-tech-021"></a>`TQ-TECH-021` | SkillGate | RESEARCH_DONOR | P3_ROUTING_DONOR | REFERENCE | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | source test/provider slot semantics preserved; runtime use requires exact candidate currentness/rights/host qualification; provider-off/alternate defined | A3:L1008 |
| <a id="layerb-tq-tech-022"></a>`TQ-TECH-022` | Demystifying Agent Skills | RESEARCH_DONOR | P3_ROUTING_DONOR | REFERENCE | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | source test/provider slot semantics preserved; runtime use requires exact candidate currentness/rights/host qualification; provider-off/alternate defined | A3:L1009 |
| <a id="layerb-tq-tech-023"></a>`TQ-TECH-023` | OpenAI Skills / Plugin | HOST_PACKAGING | P1_HOST_SURFACE | REFERENCE | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | source test/provider slot semantics preserved; runtime use requires exact candidate currentness/rights/host qualification; provider-off/alternate defined | A3:L1010 |
| <a id="layerb-tq-tech-024"></a>`TQ-TECH-024` | OpenAI Apps / App Templates | HOST_EXTERNAL_ACTION | V2_OPTIONAL | REFERENCE | DOC-02 TechnologyAdmission / project-specific binding | source test/provider slot semantics preserved; runtime use requires exact candidate currentness/rights/host qualification; provider-off/alternate defined | A3:L1011 |
| <a id="layerb-tq-tech-025"></a>`TQ-TECH-025` | Semgrep | TRANSITIVE_SECURITY_SCANNER | OPTIONAL_TRANSITIVE | REFERENCE | DOC-07 TQAEP/Security | source test/provider slot semantics preserved; runtime use requires exact candidate currentness/rights/host qualification; provider-off/alternate defined | A3:L1012 |
| <a id="layerb-tq-tech-026"></a>`TQ-TECH-026` | SkillSpector | TRANSITIVE_SKILL_SCANNER | OPTIONAL_TRANSITIVE | REFERENCE | DOC-03 RepoContext/Semantic Context | source test/provider slot semantics preserved; runtime use requires exact candidate currentness/rights/host qualification; provider-off/alternate defined | A3:L1013 |
| <a id="layerb-tq-tech-027"></a>`TQ-TECH-027` | Gitleaks | TRANSITIVE_SECRET_SCANNER | OPTIONAL_TRANSITIVE | REFERENCE | DOC-07 TQAEP/Security | source test/provider slot semantics preserved; runtime use requires exact candidate currentness/rights/host qualification; provider-off/alternate defined | A3:L1014 |
| <a id="layerb-tq-tech-028"></a>`TQ-TECH-028` | GitHub Actions | CI_EXECUTOR | P1_WHERE_GITHUB | REFERENCE | DOC-09 CI Adapter | source test/provider slot semantics preserved; runtime use requires exact candidate currentness/rights/host qualification; provider-off/alternate defined | A3:L1015 |
| <a id="layerb-tq-tech-029"></a>`TQ-TECH-029` | OpenSSF Scorecard | OSS_POSTURE_SIGNAL | SUPPORT_CANDIDATE | EVAL | DOC-07 TQAEP/Security | source test/provider slot semantics preserved; runtime use requires exact candidate currentness/rights/host qualification; provider-off/alternate defined | A3:L1016 |
| <a id="layerb-tq-tech-030"></a>`TQ-TECH-030` | Hugging Face Skills | ECOSYSTEM_INTEROP | SUPPORT_CANDIDATE | EVAL | DOC-02 TechnologyAdmission + DOC-08 Adapter Maturity | source test/provider slot semantics preserved; runtime use requires exact candidate currentness/rights/host qualification; provider-off/alternate defined | A3:L1017 |
| <a id="layerb-tq-tech-031"></a>`TQ-TECH-031` | Agent Safety Should Be a Runtime Contract | RESEARCH_DONOR | P3_RESEARCH_DONOR | REFERENCE | DOC-02 TechnologyAdmission / project-specific binding | source test/provider slot semantics preserved; runtime use requires exact candidate currentness/rights/host qualification; provider-off/alternate defined | A3:L1018 |
## R2 / Named Workflow
| Stable ID | Name / role | PIPD canonical home | Treatment | Imported steps | Excluded semantics | Required test / exit | Source ref |
|---|---|---|---|---|---|---|---|
| <a id="layerb-mission_to_execution"></a>`MISSION_TO_EXECUTION` | mission→bounded execution orchestration | DOC-02 PI → DOC-03 S2E/WO/ECP → DOC-05 admission | TRANSLATE | mission decomposition, bounded work, evidence return | donor cannot grant PIPD lifecycle authority | trace continuity + no-execution-before-ADMIT; remove adapter cleanly | A3:L1024 |
| <a id="layerb-phases_rb00_rb15"></a>`PHASES_RB00_RB15` | phase/runbook progression | DOC-09 Adoption Waves/Runbook | TRANSLATE | phase entry/exit/checkpoint/readback | donor phase labels not canonical lifecycle states | phase-to-canonical-state mapping; rollback/resume | A3:L1025 |
| <a id="layerb-workorder_admission"></a>`WORKORDER_ADMISSION` | WO→admission control | DOC-03/05 | KEEP_PATTERN | WO identity, permission, admission separation | WO/ECP never self-authorize | negative ECP-only/WO-only first mutation | A3:L1026 |
| <a id="layerb-cross_session_pipeline"></a>`CROSS_SESSION_PIPELINE` | resume/handoff continuity | DOC-03/04 | TRANSLATE | subject/version/hash, checkpoint, context/evidence handoff | memory/session state not semantic authority | resume wrong-subject/stale-hash negative; purge/expiry | A3:L1027 |
| <a id="layerb-provider_admission"></a>`PROVIDER_ADMISSION` | provider qualification/binding | DOC-02 TechnologyAdmission + DOC-03 currentness | TRANSLATE | pin/license/security/capability/exit | provider cannot own canonical semantics | provider-off/parity/currentness TTL | A3:L1028 |
| <a id="layerb-long_running_control"></a>`LONG_RUNNING_CONTROL` | long-horizon checkpoint/recovery | DOC-03 ECP / DOC-09 runbook | TRANSLATE | checkpoint, stop/retry, recovery, evidence | no autonomous authority expansion | timeout/restart/recovery + scope containment | A3:L1029 |
| <a id="layerb-self_iteration_loop"></a>`SELF_ITERATION_LOOP` | bounded repair/iteration | DOC-07 rework/requalification | REFERENCE | repair loop under stable oracle | no self-issued PASS or requirement rewrite | mutation/rework stop + human/acceptor boundary | A3:L1030 |
| <a id="layerb-release_recovery"></a>`RELEASE_RECOVERY` | release/rollback/recovery | DOC-09 Release Lane | TRANSLATE | artifact identity, recovery, rollback, evidence | release workflow cannot replace acceptance/qualification | digest/attestation/rollback/residue tests | A3:L1031 |
# Appendix C｜Layer-A Currentness / Disposition Cross-Read

| ID | Terminal disposition | version/status support | Currentness status | Canonical record ref |
|---|---|---|---|---|
| `CAND-01` | `ADOPT` | GPT-5.6 Sol / `gpt-5.6` alias | `CURRENT` | `DOC-02::TechnologyAdmissionRecord::CAND-01` |
| `CAND-02` | `ADOPT_WITH_WRAPPER` | Codex 0.160.1; Agents SDK Python 0.22.3 | `CURRENT` | `DOC-02::TechnologyAdmissionRecord::CAND-02` |
| `CAND-03` | `ADOPT_WITH_TRANSLATION` | versionless/open format | `CURRENT_VERSIONLESS` | `DOC-02::TechnologyAdmissionRecord::CAND-03` |
| `CAND-04` | `SELECTED_TRANSLATE` | v1.14.0 (2026-09-30) | `CURRENT_REPAIRED_FROM_R1_STALE` | `DOC-02::TechnologyAdmissionRecord::CAND-04` |
| `CAND-05` | `SELECTED_WRAP` | v1.0.6 (2026-09-10) | `CURRENT` | `DOC-02::TechnologyAdmissionRecord::CAND-05` |
| `CAND-06` | `SELECTED_TRANSLATE` | spec 2026-07-28 | `CURRENT` | `DOC-02::TechnologyAdmissionRecord::CAND-06` |
| `CAND-07` | `SELECTED_TRANSLATE` | v1.0.1 (spec 2026-05-26) | `CURRENT` | `DOC-02::TechnologyAdmissionRecord::CAND-07` |
| `CAND-08` | `SELECTED_TRANSLATE` | rolling dedicated GenAI conventions repo | `CURRENT_ROLLING` | `DOC-02::TechnologyAdmissionRecord::CAND-08` |
| `CAND-09` | `EVAL_ONLY` | new scope from 0.74.0; exact eval pin deferred | `CURRENT_AT_CLAIM_LEVEL` | `DOC-02::TechnologyAdmissionRecord::CAND-09` |
| `CAND-10` | `SELECTED_TRANSLATE` | v6.4.2 (2026-09-25) | `CURRENT` | `DOC-02::TechnologyAdmissionRecord::CAND-10` |
| `CAND-11` | `REFERENCE` | 1.79.0.0 (2026-09-01) | `CURRENT_REPAIRED_FROM_R1_STALE` | `DOC-02::TechnologyAdmissionRecord::CAND-11` |
| `CAND-12` | `EVAL_ONLY` | developer preview / rolling | `CURRENT_PREVIEW` | `DOC-02::TechnologyAdmissionRecord::CAND-12` |
| `CAND-13` | `REFERENCE` | v1.15.0 | `CURRENT` | `DOC-02::TechnologyAdmissionRecord::CAND-13` |
| `CAND-14` | `REJECT` | archived 2026-06-26 / no-new-adoption | `CURRENT_ARCHIVED` | `DOC-02::TechnologyAdmissionRecord::CAND-14` |
| `CAND-15` | `SELECTED_TRANSLATE` | 1.2.3 | `CURRENT` | `DOC-02::TechnologyAdmissionRecord::CAND-15` |
| `CAND-16` | `SELECTED_TRANSLATE` | rolling official skills repo | `CURRENT_ROLLING` | `DOC-02::TechnologyAdmissionRecord::CAND-16` |
| `CAND-17` | `SELECTED_TRANSLATE` | client/core/encoder/proto 1.0.2 (2026-10-05) | `CURRENT` | `DOC-02::TechnologyAdmissionRecord::CAND-17` |
| `CAND-18` | `QUARANTINE` | v0.21.3 / v2026.9.14 | `CURRENT` | `DOC-02::TechnologyAdmissionRecord::CAND-18` |
| `CAND-19` | `REFERENCE` | reference kernel in rolling preview | `CURRENT_AT_REFERENCE_LEVEL` | `DOC-02::TechnologyAdmissionRecord::CAND-19` |
| `CAND-20` | `REFERENCE` | static research identifier 2608.01964 | `CURRENT_STATIC_REFERENCE` | `DOC-02::TechnologyAdmissionRecord::CAND-20` |
| `CAND-21` | `REFERENCE` | static research identifier 2608.04828 | `CURRENT_STATIC_REFERENCE` | `DOC-02::TechnologyAdmissionRecord::CAND-21` |
| `CAND-22` | `REFERENCE` | static research identifier 2608.17597 | `CURRENT_STATIC_REFERENCE` | `DOC-02::TechnologyAdmissionRecord::CAND-22` |
# Appendix D｜TechnologyAdmissionRecord Canonical Field Identity

| # | Field | DOC-00 handling |
|---:|---|---|
| 1 | `candidate_id` | read-through identity preserved; value is owned by DOC-02/project record, not rewritten here |
| 2 | `canonical_name` | read-through identity preserved; value is owned by DOC-02/project record, not rewritten here |
| 3 | `capability_slot` | read-through identity preserved; value is owned by DOC-02/project record, not rewritten here |
| 4 | `need_ref` | read-through identity preserved; value is owned by DOC-02/project record, not rewritten here |
| 5 | `source_or_upstream` | read-through identity preserved; value is owned by DOC-02/project record, not rewritten here |
| 6 | `observed_version_or_pin` | read-through identity preserved; value is owned by DOC-02/project record, not rewritten here |
| 7 | `source_checked_at` | read-through identity preserved; value is owned by DOC-02/project record, not rewritten here |
| 8 | `license` | read-through identity preserved; value is owned by DOC-02/project record, not rewritten here |
| 9 | `maturity` | read-through identity preserved; value is owned by DOC-02/project record, not rewritten here |
| 10 | `capabilities[]` | read-through identity preserved; value is owned by DOC-02/project record, not rewritten here |
| 11 | `disposition` | read-through identity preserved; value is owned by DOC-02/project record, not rewritten here |
| 12 | `integration_mode` | read-through identity preserved; value is owned by DOC-02/project record, not rewritten here |
| 13 | `security_risks[]` | read-through identity preserved; value is owned by DOC-02/project record, not rewritten here |
| 14 | `portability` | read-through identity preserved; value is owned by DOC-02/project record, not rewritten here |
| 15 | `testability` | read-through identity preserved; value is owned by DOC-02/project record, not rewritten here |
| 16 | `brownfield_fit` | read-through identity preserved; value is owned by DOC-02/project record, not rewritten here |
| 17 | `currentness_ttl` | read-through identity preserved; value is owned by DOC-02/project record, not rewritten here |
| 18 | `supply_chain_provenance` | read-through identity preserved; value is owned by DOC-02/project record, not rewritten here |
| 19 | `provider_exit` | read-through identity preserved; value is owned by DOC-02/project record, not rewritten here |
| 20 | `rollback_or_uninstall` | read-through identity preserved; value is owned by DOC-02/project record, not rewritten here |
| 21 | `no_fit_reason` | read-through identity preserved; value is owned by DOC-02/project record, not rewritten here |
| 22 | `anti_authority_rule` | read-through identity preserved; value is owned by DOC-02/project record, not rewritten here |
| 23 | `portable_core_dependency` | read-through identity preserved; value is owned by DOC-02/project record, not rewritten here |
# Appendix E｜AUDIT Finding-to-Repair Provenance

AUDIT target SHA-256: `1081f9e935198f3da911a9eed227a0e66156e7b964422bccae27739002201dd7`; superseded r1 SHA-256: `0b012d586e750d5c8fee1a6ff16deb76eea9d73d9412432a71c465f5295d848c`.
The r2 repair does not inherit r1 self-PASS. Each finding is closed through the mapped body/predicate in §21.2 and rechecked through §24.
# Appendix F｜Source Scan Metadata
| ID | SHA-256 | Bytes | Lines | Headings |
|---|---|---:|---:|---:|
| `P0` | `1f707741519dc11a14a311e0406ed1737cfba2202940ba85841181d34c621ddb` | 37539 | 1490 | 86 |
| `A1` | `9a8323e5237c1555a76d9a75f706e3552d79c192915cc782b76b211c7f27d527` | 149077 | 2996 | 112 |
| `A2` | `6f6aafece90b34e33786647e14fee840f5424893995b3164cbb52953a5c4f14a` | 209157 | 7176 | 261 |
| `A3` | `03bb3609dc67f85fa4b683a93736cf162e9047b6b253182aa3fdba11ba40cb28` | 376599 | 2668 | 143 |
| `A4` | `be1858e860092fb1751bf0524cd22b6939138b6835ce8f452bfc30894f945a95` | 77326 | 2559 | 92 |
| `AUDIT` | `1081f9e935198f3da911a9eed227a0e66156e7b964422bccae27739002201dd7` | 60483 | 907 | 42 |
| `R1` | `0b012d586e750d5c8fee1a6ff16deb76eea9d73d9412432a71c465f5295d848c` | 124228 | 1416 | 85 |
# Appendix G｜Machine Readback Minimum Contract
```yaml
standard_id: PIPD-LIFECYCLE-SPEC
standard_version: "1.1.0"
subject_id: <required>
subject_version: <required>
subject_sha256: <required-before-evidence-reuse>
lifecycle_state: <canonical>
decision_state: <typed>
degrade_status: <typed>
claim_ceiling: <canonical>
weight_profile: <LITE|STANDARD|ASSURED>
target_profile: <SYSTEM|SKILL_PLUGIN|AGENT_HARNESS|CUSTOM>
applicable_pi_packages: []
applicable_pd_packages: []
current_slice: null
canonical_owner_refs: []
work_order_refs: []
ecp_refs: []
tqaep_refs: []
execution_admission_ref: null
missing_gates: []
stale_refs: []
open_tt: []
open_cr: []
next_legal_transition: null
forbidden_transitions: []
```
# Appendix H｜Full H1–H6 Index Scan Receipt — No Sampling
| Source | Line | Level | Heading |
|---|---:|---:|---|
| `P0` | 1 | H1 | 《PIPD_LS_DOC-00》全量正文產出指令 |
| `P0` | 2 | H2 | Target Executor：GPT-5.6 Sol |
| `P0` | 10 | H1 | 0｜你的專業角色 |
| `P0` | 33 | H1 | 1｜主任務 / Target Outcome |
| `P0` | 61 | H1 | 2｜最高 Authority / 裁決順位 |
| `P0` | 83 | H2 | 2.1 Authority 強制規則 |
| `P0` | 98 | H1 | 3｜來源缺失 / Fail-Closed 規則 |
| `P0` | 116 | H1 | 4｜GPT-5.6 Sol 執行策略 |
| `P0` | 148 | H1 | 5｜🛠 強制「深度分析 / 全量整合 SOP」 |
| `P0` | 154 | H2 | SOP-1｜查看索引 |
| `P0` | 164 | H2 | SOP-2｜定位實質條文 |
| `P0` | 182 | H2 | SOP-3｜關鍵字全文檢索 |
| `P0` | 190 | H2 | SOP-4｜交叉驗證 |
| `P0` | 202 | H2 | SOP-5｜子要求分解 |
| `P0` | 234 | H2 | SOP-6｜實質內容判定 |
| `P0` | 253 | H1 | 6｜全量掃描控制帳 |
| `P0` | 257 | H2 | 6.1 Source Coverage Ledger |
| `P0` | 279 | H2 | 6.2 Atomic Requirement Ledger |
| `P0` | 283 | H2 | 6.3 Authority Conflict Ledger |
| `P0` | 298 | H2 | 6.4 Gap / TT / CR Register |
| `P0` | 316 | H1 | 7｜PIPD 核心工程不變量 |
| `P0` | 320 | H2 | 7.1 One Canonical Lifecycle |
| `P0` | 355 | H2 | 7.2 ECP / TQAEP 不得成為第二 Lifecycle SSOT |
| `P0` | 366 | H2 | 7.3 Adapter 不得成為 authority |
| `P0` | 382 | H2 | 7.4 Selection ≠ Installation |
| `P0` | 404 | H1 | 8｜DOC-00 Canonical Identity / Responsibility |
| `P0` | 450 | H1 | 9｜DOC-00 最低必備正文範圍 |
| `P0` | 456 | H2 | 9.1 Artifact Identity / Version / Claim Boundary |
| `P0` | 475 | H2 | 9.2 DOC-00 Mission / Position / Non-goals |
| `P0` | 486 | H2 | 9.3 When PIPD Applies / Does Not Apply |
| `P0` | 503 | H2 | 9.4 One-Lifecycle Quick Mental Model |
| `P0` | 513 | H2 | 9.5 Authority & Source Read Order |
| `P0` | 517 | H3 | Human Read Order |
| `P0` | 529 | H3 | AI / LLM Read Order |
| `P0` | 541 | H3 | Tool / Machine Read Order |
| `P0` | 555 | H2 | 9.6 Package Topology & Document Responsibility Matrix |
| `P0` | 578 | H2 | 9.7 First-Use Quickstart / Bootstrap |
| `P0` | 595 | H2 | 9.8 Package Routing |
| `P0` | 611 | H2 | 9.9 Lifecycle State Readback |
| `P0` | 633 | H2 | 9.10 Technology / Tool / OSS / Workflow Operator Index |
| `P0` | 650 | H2 | 9.11 ECP / TQAEP / Execution Boundary Quick Map |
| `P0` | 665 | H2 | 9.12 Vertical Slice / Adoption Wave Quickstart |
| `P0` | 676 | H2 | 9.13 Failure / Degrade / Recovery Entry |
| `P0` | 695 | H2 | 9.14 Common Errors / Anti-Patterns |
| `P0` | 714 | H2 | 9.15 Glossary / Quick Reference |
| `P0` | 720 | H2 | 9.16 Cross-Document Ownership & Navigation Index |
| `P0` | 730 | H2 | 9.17 DOC-00 Self-Conformance / Final Readback |
| `P0` | 746 | H1 | 10｜禁止「模板同質化」 |
| `P0` | 774 | H1 | 11｜Technology / Tool / OSS / Workflow / Architecture Selection |
| `P0` | 775 | H2 | Search-Before-Build + Anti-Degradation |
| `P0` | 797 | H2 | 11.1 先解析 canonical denominator |
| `P0` | 820 | H2 | 11.2 2026 Currentness Research |
| `P0` | 869 | H2 | 11.3 禁止留下無裁決 Candidate |
| `P0` | 902 | H2 | 11.4 Selected ≠ Installed 防偽規則 |
| `P0` | 934 | H2 | 11.5 每個具名技術的 Landing Contract |
| `P0` | 977 | H1 | 12｜外部能力 Translation / Compression / Integration 規則 |
| `P0` | 1011 | H1 | 13｜外部能力驗收 / 功能檢測 |
| `P0` | 1041 | H1 | 14｜DOC-00 的 Technology 表達方式 |
| `P0` | 1071 | H1 | 15｜Document Responsibility Matrix |
| `P0` | 1100 | H1 | 16｜Readback Contract |
| `P0` | 1138 | H1 | 17｜Claim Honesty / 真實性邊界 |
| `P0` | 1170 | H1 | 18｜Source-to-Prose 要求 |
| `P0` | 1197 | H1 | 19｜Examples / Scenarios |
| `P0` | 1220 | H1 | 20｜不得出現的降級內容 |
| `P0` | 1251 | H1 | 21｜Markdown 正文品質 |
| `P0` | 1270 | H1 | 22｜Currentness / 外部研究證據 |
| `P0` | 1295 | H1 | 23｜Completion Contract |
| `P0` | 1343 | H1 | 24｜Final Quality Gates |
| `P0` | 1347 | H2 | G-01 Source Completeness |
| `P0` | 1351 | H2 | G-02 Authority Integrity |
| `P0` | 1355 | H2 | G-03 DOC-00 Ownership Integrity |
| `P0` | 1359 | H2 | G-04 Atomic Requirement Closure |
| `P0` | 1363 | H2 | G-05 Substantive Body Gate |
| `P0` | 1367 | H2 | G-06 Anti-Homogeneity Gate |
| `P0` | 1371 | H2 | G-07 Technology Resolution Gate |
| `P0` | 1375 | H2 | G-08 Anti-False-Installation Gate |
| `P0` | 1379 | H2 | G-09 Translation / Wrapper Gate |
| `P0` | 1383 | H2 | G-10 Acceptance / Test Gate |
| `P0` | 1387 | H2 | G-11 Lifecycle Truth Gate |
| `P0` | 1391 | H2 | G-12 Claim-Honesty Gate |
| `P0` | 1395 | H2 | G-13 Cross-Reference Gate |
| `P0` | 1399 | H2 | G-14 Packaging Gate |
| `P0` | 1405 | H1 | 25｜最終檔案 |
| `P0` | 1432 | H1 | 26｜最終回覆格式 |
| `P0` | 1461 | H1 | 27｜停止條件 |
| `P0` | 1471 | H1 | 28｜現在開始執行 |
| `A1` | 24 | H1 | Pre-Implementation & Pre-Dev Lifecycle Specification — 總藍圖 |
| `A1` | 26 | H2 | 0. Cover Card / 修補版裁決 |
| `A1` | 37 | H3 | 0.1 版本號理由 |
| `A1` | 41 | H3 | 0.2 不可回歸清單 |
| `A1` | 58 | H1 | 1. Inputs Manifest / 全量掃描與權威堆疊 |
| `A1` | 69 | H2 | 1.1 Authority Stack |
| `A1` | 91 | H2 | 1.2 SOP Full-Scan Receipt |
| `A1` | 96 | H1 | 2. Authority/RCA & Repair Closure |
| `A1` | 98 | H2 | 2.1 根因樹 |
| `A1` | 156 | H1 | 3. 2026 SUPPORT Revalidation |
| `A1` | 182 | H1 | 3A. Retained 2026 SUPPORT Evidence Registry & Cross-Source Conclusions |
| `A1` | 215 | H2 | 4.1 雙來源交叉結論 |
| `A1` | 231 | H2 | 4.2 2026 currentness 特別裁決 |
| `A1` | 239 | H1 | 4. Integrated Solution / 修補後總體架構 |
| `A1` | 278 | H1 | 4A. Conversation Decision Ledger — 20/20 High-Retention |
| `A1` | 305 | H1 | 5. Repaired Repository Topology |
| `A1` | 371 | H1 | 6. Portable Distribution & Materialization Compiler |
| `A1` | 373 | H2 | 6.1 Distribution contract |
| `A1` | 391 | H2 | 6.2 Deterministic extraction rules |
| `A1` | 401 | H3 | `pipd_dist.py` |
| `A1` | 600 | H2 | 6.3 Distribution vs Project Instance |
| `A1` | 605 | H2 | 6.4 Validator dependency binding |
| `A1` | 614 | H1 | 7. Schema-Bound Project Control Plane |
| `A1` | 618 | H2 | 7.1 `standard-lock.schema.json` |
| `A1` | 664 | H2 | 7.2 `project-manifest.schema.json` |
| `A1` | 864 | H2 | 7.3 `permission-policy.schema.json` |
| `A1` | 929 | H2 | 7.4 `change-policy.schema.json` |
| `A1` | 982 | H2 | 7.5 `degrade-policy.schema.json` |
| `A1` | 1054 | H2 | 7.6 `currentness-record.schema.json` |
| `A1` | 1161 | H2 | 7.7 `requirement-conformance.schema.json` |
| `A1` | 1240 | H2 | 7.8 `adapter-profile.schema.json` |
| `A1` | 1405 | H2 | 7.9 `package-index.schema.json` |
| `A1` | 1493 | H1 | 8. Project Bootstrap & Machine Binding |
| `A1` | 1495 | H2 | 8.1 `standard.lock.json` — 唯一 hash/version pin owner |
| `A1` | 1511 | H2 | 8.2 `project/manifest.json` |
| `A1` | 1546 | H2 | 8.3 Object Registry Rule |
| `A1` | 1555 | H1 | 9. Mandatory Search-Before-Build / Technology Admission Procedure |
| `A1` | 1585 | H1 | 10. Package Derivation / Split-Merge / Vertical Slice |
| `A1` | 1587 | H2 | 10.1 Split Predicate |
| `A1` | 1598 | H2 | 10.2 Merge Predicate |
| `A1` | 1610 | H2 | 10.3 Vertical Slice |
| `A1` | 1623 | H1 | 11. Change Taxonomy & Affected-Only Invalidation |
| `A1` | 1650 | H1 | 11A. Event Matrix — Retained 18/18 + Machine Change-Class Binding |
| `A1` | 1677 | H1 | 12. Permission / Admission Model |
| `A1` | 1689 | H1 | 13. Gate / Conformance Report Model |
| `A1` | 1703 | H1 | 14. Degrade Namespace Separation |
| `A1` | 1716 | H1 | 15. Tool / Technology / Workflow / OSS — 22/22 Blueprint-Depth Registry |
| `A1` | 1745 | H2 | 15.1 Anti-downgrade corrections |
| `A1` | 1752 | H1 | 16. System Target Profile Blueprint + Operations Readiness Minimum |
| `A1` | 1754 | H2 | 16.1 PI contract |
| `A1` | 1769 | H2 | 16.2 PD bindings |
| `A1` | 1787 | H2 | 16.3 OPS ECP minimum |
| `A1` | 1792 | H2 | 16.4 TQAEP |
| `A1` | 1796 | H2 | 16.5 N/A Predicate |
| `A1` | 1800 | H1 | 17. Skill / Plugin Target Profile — Complete |
| `A1` | 1802 | H2 | 17.1 PI mandatory fields |
| `A1` | 1808 | H2 | 17.2 PD mandatory bindings |
| `A1` | 1812 | H2 | 17.3 Effectful Skill |
| `A1` | 1817 | H2 | 17.4 Skill conformance categories |
| `A1` | 1821 | H1 | 18. Agent Harness / Agentic Runtime Target Profile — Complete |
| `A1` | 1823 | H2 | 18.1 Fifteen PI contracts |
| `A1` | 1841 | H2 | 18.2 Thirteen PD bindings |
| `A1` | 1857 | H2 | 18.3 Typed records for STANDARD/ASSURED |
| `A1` | 1861 | H2 | 18.4 Eight mandatory adversarial classes |
| `A1` | 1874 | H1 | 19. AI Read Order & Portable Adapters |
| `A1` | 1876 | H2 | 19.1 Two-Phase Read Order |
| `A1` | 1892 | H2 | 19.2 Canonical `AGENTS.md.template` — exact projection |
| `A1` | 1895 | H1 | Project Agent Instructions |
| `A1` | 1897 | H2 | Authority / Read Order |
| `A1` | 1904 | H2 | Current Lifecycle |
| `A1` | 1912 | H2 | Commands / Permissions |
| `A1` | 1921 | H2 | Failure / Evidence |
| `A1` | 1924 | H2 | Prohibited |
| `A1` | 1928 | H2 | 19.3 Canonical `SKILL.md.template` — exact projection |
| `A1` | 1938 | H1 | Workflow |
| `A1` | 1949 | H1 | Trigger tests |
| `A1` | 1955 | H1 | Boundary tests |
| `A1` | 1963 | H1 | 20. CI-Provider-Neutral ABI + GitHub Reference Adapter |
| `A1` | 1965 | H2 | 20.1 Neutral Check Contract |
| `A1` | 1992 | H2 | 20.2 2026 Action Currentness Record |
| `A1` | 2004 | H2 | 20.3 `.github/workflows/pipd-required.yml` |
| `A1` | 2061 | H2 | 20.4 Security adapter |
| `A1` | 2065 | H1 | 21. Release Supply-Chain Lane — Build → Transfer → Attest → Verify |
| `A1` | 2067 | H2 | 21.1 Required chain |
| `A1` | 2081 | H2 | 21.2 Reference workflow |
| `A1` | 2162 | H2 | 21.3 SBOM/Provenance |
| `A1` | 2170 | H1 | 22. World Effect / Observation / Readback / Reconciliation |
| `A1` | 2186 | H1 | 23. Brownfield / Migration |
| `A1` | 2203 | H1 | 24. Executable Reference Tooling |
| `A1` | 2205 | H2 | 24.1 `pipd_tree_validate.py` |
| `A1` | 2421 | H2 | 24.2 `pipd_drift.py` |
| `A1` | 2554 | H2 | 24.3 `pipd_validate.py` |
| `A1` | 2558 | H1 | 25. Conformance / Stable TEST-ORACLE Identity |
| `A1` | 2560 | H2 | 25.1 Canonical category registry — primary keys |
| `A1` | 2585 | H2 | 25.2 Supplemental destructive suite — Retained 37/37 |
| `A1` | 2631 | H1 | 26. Canonical 86/86 Requirement Conformance Binding |
| `A1` | 2726 | H1 | 27. Lifecycle Acceptance Metrics |
| `A1` | 2745 | H1 | 28. Implementation / Adoption Waves |
| `A1` | 2762 | H1 | 29. Risk Register & CR_OPEN |
| `A1` | 2782 | H1 | 29A. Risk Register — Retained 15/15 |
| `A1` | 2804 | H1 | 30. Machine-Readable Blocks |
| `A1` | 2806 | H2 | 30.1 `machine_summary.json` |
| `A1` | 2849 | H2 | 30.2 `change_plan.tsv` |
| `A1` | 2867 | H2 | 30.3 `checkrun_contract.tsv` |
| `A1` | 2881 | H1 | 31. Operational Runbook |
| `A1` | 2883 | H2 | 31.1 Bootstrap |
| `A1` | 2902 | H2 | 31.2 Change routing |
| `A1` | 2913 | H1 | 32. Final Engineering Decision |
| `A1` | 2930 | H2 | 32.1 High-Retention Denominator Receipt |
| `A1` | 2946 | H1 | Appendix A — Repair Acceptance Criteria |
| `A1` | 2976 | H1 | Appendix B — 2026 SUPPORT URLs |
| `A1` | 2993 | H1 | Appendix C — Claim Boundary |
| `A2` | 26 | H1 | Pre-Implementation & Pre-Dev Lifecycle Specification — Canonical Standard V1.1 FULL_REPAIR |
| `A2` | 37 | H2 | 0. Executive Decision / 標準定位 |
| `A2` | 80 | H3 | 0.1 本標準要解決的核心問題 |
| `A2` | 112 | H1 | 1. Normative Language / 規範語言 |
| `A2` | 126 | H1 | 2. Scope / Non-Goals |
| `A2` | 128 | H2 | 2.1 Scope |
| `A2` | 141 | H2 | 2.2 Non-Goals |
| `A2` | 155 | H1 | 3. Canonical Principles / 不可漂移原則 |
| `A2` | 157 | H2 | P-01 Single Canonical Truth |
| `A2` | 160 | H2 | P-02 Source-Bound Intent Preservation |
| `A2` | 163 | H2 | P-03 Stable Semantics vs Late-Bound Facts |
| `A2` | 166 | H2 | P-04 Read-Only Preflight Is Not Implementation |
| `A2` | 169 | H2 | P-05 No Execution by Documentation |
| `A2` | 172 | H2 | P-06 Claim Separation |
| `A2` | 187 | H2 | P-07 Evidence Is Subject-Bound |
| `A2` | 190 | H2 | P-08 Affected-Only Invalidation |
| `A2` | 193 | H2 | P-09 Complexity Must Earn Complexity |
| `A2` | 196 | H2 | P-10 Handoff Must Be Rejectable |
| `A2` | 202 | H2 | P-11 Capability-Before-Brand / Search-Before-Build |
| `A2` | 206 | H2 | P-12 Execution Identity Separation |
| `A2` | 210 | H2 | P-13 Tool Success ≠ World Effect |
| `A2` | 214 | H2 | P-14 Segregation of Duties |
| `A2` | 218 | H2 | P-15 Prose/Machine Gate Equivalence |
| `A2` | 222 | H1 | 4. Core Vocabulary / 名詞 |
| `A2` | 244 | H2 | 4.1 Canonical Tokens / Human Labels / Legacy Aliases |
| `A2` | 254 | H2 | 4.2 Execution Identity Vocabulary |
| `A2` | 264 | H1 | 5. Lifecycle State Machine |
| `A2` | 266 | H2 | 5.1 Canonical States |
| `A2` | 309 | H2 | 5.2 Promotion Rule |
| `A2` | 324 | H2 | 5.3 Claim Ceiling Table |
| `A2` | 339 | H1 | 6. Artifact Identity & Authority Model |
| `A2` | 371 | H2 | 6.1 Common Artifact Metadata Contract |
| `A2` | 395 | H2 | 6.2 Authority and Adapter Non-Override Rule |
| `A2` | 399 | H1 | PART I — 01 Lifecycle Constitution |
| `A2` | 401 | H1 | 7. Lifecycle Constitution / 生命週期憲章 |
| `A2` | 403 | H2 | 7.1 Purpose |
| `A2` | 407 | H2 | 7.2 Required Constitution Sections |
| `A2` | 409 | H3 | C-01 Project / Product Identity |
| `A2` | 418 | H3 | C-02 Authority Stack |
| `A2` | 432 | H3 | C-03 Canonical Ownership |
| `A2` | 441 | H3 | C-04 Lifecycle States |
| `A2` | 444 | H3 | C-05 Claim Rules |
| `A2` | 447 | H3 | C-06 Permission / Side-Effect Policy |
| `A2` | 466 | H3 | C-07 Security / Trust Boundary |
| `A2` | 479 | H3 | C-08 Change / Supersession |
| `A2` | 489 | H3 | C-09 Tailoring Profile |
| `A2` | 492 | H3 | C-10 Definition of Pre-Execution Complete |
| `A2` | 497 | H3 | C-11 Standard Namespace / Schema Compatibility |
| `A2` | 508 | H3 | C-12 DomainProfileExtension |
| `A2` | 524 | H3 | C-13 Documentation Grounding Profile |
| `A2` | 528 | H3 | C-14 Security Threat Model |
| `A2` | 532 | H2 | 7.3 Constitution Gate |
| `A2` | 551 | H1 | PART II — 02 PI-PKG Specification |
| `A2` | 553 | H1 | 8. PI-PKG Canonical Purpose |
| `A2` | 582 | H1 | 9. PI-PKG Required Contract Areas |
| `A2` | 586 | H2 | PI-01 Identity / Mission |
| `A2` | 592 | H2 | PI-02 Scope / Non-Goals |
| `A2` | 598 | H2 | PI-03 Source / Authority / Provenance |
| `A2` | 605 | H2 | PI-04 Intent / User / Product Truth |
| `A2` | 612 | H2 | PI-05 Atomic Requirements |
| `A2` | 623 | H2 | PI-06 Canonical Object & State Model |
| `A2` | 631 | H2 | PI-07 Architecture / Interface / ABI |
| `A2` | 639 | H2 | PI-08 Technology Admission / Reuse / Search-Before-Build |
| `A2` | 643 | H3 | PI-08.1 Mandatory Search-Before-Build algorithm |
| `A2` | 683 | H3 | PI-08.2 TechnologyAdmissionRecord |
| `A2` | 715 | H2 | PI-09 Security / Privacy / Rights / Risk |
| `A2` | 725 | H2 | PI-10 SPEC |
| `A2` | 728 | H2 | PI-11 Acceptance |
| `A2` | 743 | H2 | PI-12 Verification / Oracle |
| `A2` | 746 | H2 | PI-13 Evidence Expectation |
| `A2` | 749 | H2 | PI-14 Deliverables |
| `A2` | 752 | H2 | PI-15 Dependencies / Gates |
| `A2` | 759 | H2 | PI-16 Failure / Rollback / Change |
| `A2` | 766 | H2 | PI-17 Claim Ceiling / State Truth |
| `A2` | 776 | H2 | PI-18 Pre-Dev Handoff |
| `A2` | 781 | H1 | 10. Requirement Narrow Waist |
| `A2` | 821 | H1 | 11. PI Compilation Algorithm |
| `A2` | 845 | H1 | 12. PI_READY Gate |
| `A2` | 876 | H1 | PART III — 03 PD-PKG Specification |
| `A2` | 878 | H1 | 13. PD-PKG Canonical Purpose |
| `A2` | 907 | H1 | 14. PD-PKG Required Structure |
| `A2` | 911 | H2 | PD-01 Frozen PI References |
| `A2` | 919 | H2 | PD-02 Read-Only RepoContext / Environment Preflight |
| `A2` | 934 | H2 | PD-03 Currentness / Compatibility |
| `A2` | 945 | H2 | PD-04 Late-Bound Resolution |
| `A2` | 958 | H2 | PD-05 S2E — Spec-to-Execution |
| `A2` | 973 | H3 | PD-05A TaskSpecSeed |
| `A2` | 984 | H3 | PD-05B WorkOrder Materialization |
| `A2` | 996 | H2 | PD-06 DEV ECP — Development Execution Control |
| `A2` | 1014 | H2 | PD-07 OPS ECP — Operations Readiness & Execution Control |
| `A2` | 1034 | H2 | PD-08 TQAEP — Test / Qualification / Acceptance / Evidence Plan |
| `A2` | 1052 | H2 | PD-09 Execution Handoff Manifest |
| `A2` | 1079 | H2 | PD-10 Execution Admission |
| `A2` | 1105 | H1 | 15. PD Binding Algorithm |
| `A2` | 1131 | H1 | 16. PREDEV_READY Gate |
| `A2` | 1162 | H1 | 17. EXECUTION_ADMITTED Gate |
| `A2` | 1192 | H1 | PART IV — Machine-Readable Schemas |
| `A2` | 1194 | H1 | 18. Schema General Rules — V1.1 Strict Machine Contract |
| `A2` | 1209 | H2 | 18.1 Extraction Manifest |
| `A2` | 1214 | H2 | 18.2 Canonical Standalone Schemas |
| `A2` | 1216 | H3 | 18.2.1341 `requirement-trace.schema.json` |
| `A2` | 1337 | H3 | 18.2.3540 `technology-admission.schema.json` |
| `A2` | 1513 | H3 | 18.2.7050 `repo-context.schema.json` |
| `A2` | 1619 | H3 | 18.2.9106 `s2e.schema.json` |
| `A2` | 1741 | H3 | 18.2.11426 `task-spec-seed.schema.json` |
| `A2` | 1877 | H3 | 18.2.14027 `work-order.schema.json` |
| `A2` | 1991 | H3 | 18.2.16202 `dev-ecp.schema.json` |
| `A2` | 2129 | H3 | 18.2.18847 `ops-ecp.schema.json` |
| `A2` | 2362 | H3 | 18.2.23388 `tqaep.schema.json` |
| `A2` | 2526 | H3 | 18.2.26550 `approval-token.schema.json` |
| `A2` | 2606 | H3 | 18.2.28004 `handoff.schema.json` |
| `A2` | 2752 | H3 | 18.2.30838 `execution-admission.schema.json` |
| `A2` | 3013 | H3 | 18.2.36258 `effect-intent.schema.json` |
| `A2` | 3091 | H3 | 18.2.37774 `effect-observation.schema.json` |
| `A2` | 3142 | H3 | 18.2.38800 `effect-reconciliation.schema.json` |
| `A2` | 3228 | H3 | 18.2.40448 `evidence.schema.json` |
| `A2` | 3421 | H3 | 18.2.43915 `threat-model.schema.json` |
| `A2` | 3510 | H3 | 18.2.45518 `documentation-grounding.schema.json` |
| `A2` | 3575 | H3 | 18.2.46805 `domain-profile-extension.schema.json` |
| `A2` | 3636 | H3 | 18.2.48015 `pre-implementation-package.schema.json` |
| `A2` | 4308 | H3 | 18.2.63190 `pre-dev-package.schema.json` |
| `A2` | 5663 | H3 | 18.2.94111 `conformance-report.schema.json` |
| `A2` | 5777 | H2 | 18.3 Deterministic Conformance Reference Command |
| `A2` | 5799 | H3 | `pipd_validate.py` reference implementation |
| `A2` | 5888 | H2 | 18.4 Destructive Fixtures Required by the Standard |
| `A2` | 5904 | H1 | PART V — Tailoring & Profiles |
| `A2` | 5906 | H1 | 20. Weight Profiles |
| `A2` | 5908 | H2 | 20.1 LITE |
| `A2` | 5929 | H2 | 20.2 STANDARD |
| `A2` | 5941 | H2 | 20.3 ASSURED |
| `A2` | 5961 | H2 | 20.4 Machine Profile Binding |
| `A2` | 5965 | H1 | 21. Target Profile — General Software / System |
| `A2` | 5993 | H2 | 21.1 Operations Readiness Minimum for Applicable Systems |
| `A2` | 5997 | H2 | 21.2 BrownfieldMigrationProfile |
| `A2` | 6016 | H1 | 22. Target Profile — SKILL / PLUGIN |
| `A2` | 6058 | H2 | 22.1 Skill/Plugin Conformance Additions |
| `A2` | 6062 | H1 | 23. Target Profile — Agent Harness / Agentic Runtime |
| `A2` | 6117 | H2 | 23.1 Agent Harness Typed Contract Additions |
| `A2` | 6121 | H1 | PART VI — Handoff, Evidence, Security, Change |
| `A2` | 6123 | H1 | 23A. World Effect / Observation / Readback / Reconciliation |
| `A2` | 6151 | H1 | 24. Receiver Handoff Contract |
| `A2` | 6172 | H1 | 25. Evidence Return Contract |
| `A2` | 6194 | H1 | 26. Security & Permission Rules |
| `A2` | 6196 | H2 | 26.1 Default Deny |
| `A2` | 6199 | H2 | 26.2 External Content Is Data |
| `A2` | 6202 | H2 | 26.3 Secret Handling |
| `A2` | 6208 | H2 | 26.4 Agent Memory |
| `A2` | 6211 | H2 | 26.5 Human Approval |
| `A2` | 6226 | H2 | 26.6 Portable Threat Model Contract |
| `A2` | 6230 | H2 | 26.7 SoD Enforcement |
| `A2` | 6240 | H1 | 27. Change, Supersession & Invalidation |
| `A2` | 6242 | H2 | 27.1 Change Classes |
| `A2` | 6253 | H2 | 27.2 Affected-Only Algorithm |
| `A2` | 6269 | H2 | 27.3 When PD May Return to PI |
| `A2` | 6286 | H1 | PART VII — AI / LLM Consumption Contract |
| `A2` | 6288 | H1 | 28. Canonical Standard vs Adapter |
| `A2` | 6313 | H1 | 29. AI Read Order — Two-Phase Instruction Safety |
| `A2` | 6317 | H3 | Phase A — Global / Read-Only Discovery |
| `A2` | 6326 | H3 | Phase B — Nearest-Scope Action Preparation |
| `A2` | 6335 | H1 | 30. Progressive Disclosure Rule |
| `A2` | 6353 | H1 | 30A. Portable Adapters — Extractable Templates |
| `A2` | 6357 | H2 | 30A.1 `AGENTS.md.template` |
| `A2` | 6360 | H1 | Project Agent Instructions |
| `A2` | 6362 | H2 | Authority / Read Order |
| `A2` | 6369 | H2 | Current Lifecycle |
| `A2` | 6377 | H2 | Commands / Permissions |
| `A2` | 6386 | H2 | Failure / Evidence |
| `A2` | 6389 | H2 | Prohibited |
| `A2` | 6393 | H2 | 30A.2 `SKILL.md.template` |
| `A2` | 6403 | H1 | Workflow |
| `A2` | 6414 | H1 | Trigger tests |
| `A2` | 6420 | H1 | Boundary tests |
| `A2` | 6426 | H1 | PART VIII — Conformance |
| `A2` | 6428 | H1 | 31. Conformance Levels |
| `A2` | 6430 | H2 | 31.1 PI-Conformant |
| `A2` | 6441 | H2 | 31.2 PD-Conformant |
| `A2` | 6454 | H2 | 31.3 Full Pre-Execution Conformant |
| `A2` | 6467 | H1 | 32. Mandatory Conformance Test Registry |
| `A2` | 6496 | H1 | 33. Minimal Acceptance Metrics |
| `A2` | 6521 | H1 | PART IX — Package Derivation / Avoid Overengineering |
| `A2` | 6523 | H1 | 34. How Many PI/PD Packages? |
| `A2` | 6545 | H2 | 34.1 Split Predicate |
| `A2` | 6557 | H2 | 34.2 Merge Predicate |
| `A2` | 6573 | H1 | 35. Vertical Slice Execution Rule |
| `A2` | 6592 | H1 | PART X — Canonical Templates |
| `A2` | 6594 | H1 | 36. PI-PKG Markdown Template |
| `A2` | 6597 | H1 | <PI-PKG ID> — <Name> |
| `A2` | 6599 | H2 | 0 Metadata / Claim Ceiling |
| `A2` | 6600 | H2 | 1 Mission / Pain / Outcome |
| `A2` | 6601 | H2 | 2 Scope / Non-Goals |
| `A2` | 6602 | H2 | 3 Authority / Sources / Supersession |
| `A2` | 6603 | H2 | 4 Intent / Users / Product Truth |
| `A2` | 6604 | H2 | 5 Requirements / Atomicity / Ownership |
| `A2` | 6605 | H2 | 6 Canonical Objects / State / Invariants |
| `A2` | 6606 | H2 | 7 Architecture / Interfaces / ABI |
| `A2` | 6607 | H2 | 8 Technology Admission / Reuse / Build Decisions |
| `A2` | 6608 | H2 | 9 Security / Privacy / Rights / Risk |
| `A2` | 6609 | H2 | 10 SPEC Contracts |
| `A2` | 6610 | H2 | 11 Acceptance Predicates |
| `A2` | 6611 | H2 | 12 Verification / Oracles |
| `A2` | 6612 | H2 | 13 Evidence Expectations |
| `A2` | 6613 | H2 | 14 Deliverables |
| `A2` | 6614 | H2 | 15 Dependencies / Gates / Invalidation |
| `A2` | 6615 | H2 | 16 Failure / Rollback / TT / CR |
| `A2` | 6616 | H2 | 17 Claim Truth |
| `A2` | 6617 | H2 | 18 Pre-Dev Handoff |
| `A2` | 6618 | H2 | 19 PI_READY Readback |
| `A2` | 6625 | H1 | 37. PD-PKG Markdown Template |
| `A2` | 6628 | H1 | <PD-PKG ID> — <Name> |
| `A2` | 6630 | H2 | 0 Metadata / PI Binding / Claim Ceiling |
| `A2` | 6631 | H2 | 1 Target Execution Slice |
| `A2` | 6632 | H2 | 2 Read-only RepoContext / Environment Preflight |
| `A2` | 6633 | H2 | 3 Currentness / Compatibility Diff |
| `A2` | 6634 | H2 | 4 Late-Bound Resolution |
| `A2` | 6635 | H2 | 5 S2E — Spec-to-Execution |
| `A2` | 6636 | H2 | 6 DEV ECP |
| `A2` | 6637 | H2 | 7 OPS ECP / N-A Rationale |
| `A2` | 6638 | H2 | 8 TQAEP |
| `A2` | 6639 | H2 | 9 Permissions / Human Approval / Side-Effect Boundary |
| `A2` | 6640 | H2 | 10 Rollback / Recovery / Provider-Off |
| `A2` | 6641 | H2 | 11 Evidence Return Contract |
| `A2` | 6642 | H2 | 12 Execution Handoff Manifest |
| `A2` | 6643 | H2 | 13 PREDEV_READY Readback |
| `A2` | 6644 | H2 | 14 Execution Admission Decision Placeholder |
| `A2` | 6649 | H1 | 38. Execution Handoff YAML Template |
| `A2` | 6673 | H1 | PART XI — Reference Directory Layout |
| `A2` | 6675 | H1 | 39. Recommended Portable Layout |
| `A2` | 6708 | H1 | PART XII — Quick Start |
| `A2` | 6710 | H1 | 40. New Project — 15-Step Procedure |
| `A2` | 6732 | H1 | 41. Brownfield Existing Project Procedure |
| `A2` | 6750 | H1 | 42. Skill / Plugin Procedure |
| `A2` | 6768 | H1 | 43. Agent Harness Procedure |
| `A2` | 6785 | H1 | PART XIII — Failure Modes / Anti-Patterns |
| `A2` | 6787 | H1 | 44. Forbidden Anti-Patterns |
| `A2` | 6789 | H2 | AP-01 Blueprint-as-Proof |
| `A2` | 6792 | H2 | AP-02 Framework Takeover |
| `A2` | 6795 | H2 | AP-03 Historical Re-Adjudication Every Stage |
| `A2` | 6798 | H2 | AP-04 T&#66;D at Execution Gate |
| `A2` | 6801 | H2 | AP-05 Hidden Permission Inference |
| `A2` | 6804 | H2 | AP-06 Evidence Without Subject Identity |
| `A2` | 6807 | H2 | AP-07 Giant Monolith Spec |
| `A2` | 6810 | H2 | AP-08 Package Explosion |
| `A2` | 6813 | H2 | AP-09 Sender Self-Acceptance |
| `A2` | 6816 | H2 | AP-10 Global Rebuild on Any Change |
| `A2` | 6821 | H1 | 45. Standard Self-Conformance Checklist |
| `A2` | 6852 | H1 | 46. V1.1 Acceptance Criteria |
| `A2` | 6870 | H2 | 46.1 V1.1 Full-Repair Promotion Predicate |
| `A2` | 6893 | H1 | 46A. Informative Technology & Workflow Registry — Named Anti-Downgrade Baseline |
| `A2` | 6924 | H1 | 47. External Alignment / Informative Research Notes |
| `A2` | 6942 | H2 | 47.1 GitHub Spec Kit |
| `A2` | 6947 | H2 | 47.2 AGENTS.md |
| `A2` | 6952 | H2 | 47.3 MCP 2026-07-28 |
| `A2` | 6957 | H2 | 47.4 A2A |
| `A2` | 6962 | H2 | 47.5 OpenAI Agents SDK |
| `A2` | 6967 | H2 | 47.6 OWASP Agentic Security 2026 |
| `A2` | 6972 | H2 | 47.7 SLSA Provenance |
| `A2` | 6979 | H1 | 48. Source-Derived Design Basis / 本次內部來源整合依據 |
| `A2` | 7008 | H1 | 49. Canonical One-Page Readback |
| `A2` | 7067 | H1 | 49A. Standard Normative Requirement Ledger / Stable Test Binding |
| `A2` | 7162 | H1 | 50. Final Normative Statement |
| `A2` | 7172 | H2 | End of Canonical Standard V1.1 FULL_REPAIR |
| `A3` | 31 | H1 | 0 Artifact Metadata / Repair Identity / Claim Ceiling |
| `A3` | 39 | H2 | 0.1 Repair invariants |
| `A3` | 49 | H1 | 1 Mission / Scope / Design Intent |
| `A3` | 55 | H1 | 2 Authority Stack / Source Manifest / Audit Repair Closure |
| `A3` | 57 | H2 | 2.1 Authority |
| `A3` | 63 | H2 | 2.2 SOURCE_MANIFEST |
| `A3` | 81 | H2 | 2.3 AUDIT 33/33 Repair Closure |
| `A3` | 120 | H1 | 3 Source Analysis / Full-Scan / Keyword / Substantive Coverage Contract |
| `A3` | 122 | H2 | 3.1 FULL-SCAN rule |
| `A3` | 126 | H2 | 3.2 Keyword full-text pass receipt |
| `A3` | 204 | H2 | 3.3 Substantive-content test |
| `A3` | 208 | H1 | 4 PIPD Lifecycle Architecture / One Canonical Lifecycle |
| `A3` | 229 | H1 | 5 PIPD Package Topology / Repaired Distribution + Project Lanes |
| `A3` | 271 | H1 | 6 Canonical Document Registry / Authoring Archetypes |
| `A3` | 286 | H1 | 7 DOC-00 Router / Quickstart / Operational Entry Skeleton |
| `A3` | 288 | H2 | 7.1 Scope decision / applicability |
| `A3` | 291 | H2 | 7.2 Human / AI / tool read orders |
| `A3` | 294 | H2 | 7.3 First use / operational bootstrap |
| `A3` | 297 | H2 | 7.4 State readback / common errors |
| `A3` | 300 | H1 | 8 DOC-01 Lifecycle Constitution Skeleton — Repaired Canonical State / Gate / Namespace Contracts |
| `A3` | 302 | H2 | 8.1 CommonArtifactMetadata |
| `A3` | 330 | H2 | 8.2 Canonical lifecycle states |
| `A3` | 349 | H3 | Side/degrade lifecycle-related states |
| `A3` | 352 | H2 | 8.3 Projection/substate mapping — operational labels may not replace canonical states |
| `A3` | 365 | H2 | 8.4 Base PromotionPredicate — 10 non-negotiable conditions |
| `A3` | 380 | H2 | 8.5 CONSTITUTION_READY Gate — 8 predicates |
| `A3` | 393 | H2 | 8.6 Four typed namespaces — no semantic mixing |
| `A3` | 408 | H2 | 8.7 Authority / canonical ownership / SoD |
| `A3` | 411 | H2 | 8.8 Change / supersession / affected-only invalidation |
| `A3` | 414 | H2 | 8.9 Package derivation governance hook |
| `A3` | 417 | H1 | 9 DOC-02 Pre-Implementation Package Specification — 18 Full Authoring Contracts |
| `A3` | 422 | H2 | 9.1 PI-01 — Identity / Mission |
| `A3` | 426 | H2 | 9.2 PI-02 — Scope / Non-Goals |
| `A3` | 430 | H2 | 9.3 PI-03 — Source / Authority / Provenance |
| `A3` | 434 | H2 | 9.4 PI-04 — Intent / User / Product Truth |
| `A3` | 438 | H2 | 9.5 PI-05 — Atomic Requirements |
| `A3` | 442 | H2 | 9.6 PI-06 — Canonical Objects / State / Invariants |
| `A3` | 446 | H2 | 9.7 PI-07 — Architecture / Interface / ABI |
| `A3` | 450 | H2 | 9.8 PI-08 — Technology Admission / Reuse / SBB |
| `A3` | 454 | H2 | 9.9 PI-09 — Security / Privacy / Rights / Risk |
| `A3` | 458 | H2 | 9.10 PI-10 — SPEC |
| `A3` | 462 | H2 | 9.11 PI-11 — Acceptance |
| `A3` | 466 | H2 | 9.12 PI-12 — Verification / Oracle |
| `A3` | 470 | H2 | 9.13 PI-13 — Evidence Expectation |
| `A3` | 474 | H2 | 9.14 PI-14 — Deliverables |
| `A3` | 478 | H2 | 9.15 PI-15 — Dependencies / Gates |
| `A3` | 482 | H2 | 9.16 PI-16 — Failure / Rollback / Change |
| `A3` | 486 | H2 | 9.17 PI-17 — Claim Ceiling / State Truth |
| `A3` | 490 | H2 | 9.18 PI-18 — Pre-Dev Handoff |
| `A3` | 494 | H2 | 9.19 Canonical TechnologyAdmission terminal enum — full 17 |
| `A3` | 518 | H2 | 9.20 Canonical TechnologyAdmissionRecord field denominator |
| `A3` | 523 | H2 | 9.21 PI Compilation Algorithm / PI_READY |
| `A3` | 528 | H1 | 10 DOC-03 Pre-Dev Package Specification — 10 Full Authoring Contracts |
| `A3` | 532 | H2 | 10.1 PD-01 Frozen PI References |
| `A3` | 535 | H2 | 10.2 PD-02 RepoContext / Environment Read-Only Preflight |
| `A3` | 551 | H2 | 10.3 PD-03 Currentness / Compatibility |
| `A3` | 554 | H2 | 10.4 PD-04 Late-Bound Resolution |
| `A3` | 557 | H2 | 10.5 PD-05 S2E / TaskSpecSeed / WorkOrder |
| `A3` | 558 | H3 | S2E output denominator |
| `A3` | 561 | H3 | TaskSpecSeed field denominator |
| `A3` | 564 | H3 | WorkOrder field denominator |
| `A3` | 569 | H2 | 10.6 PD-06 DEV ECP |
| `A3` | 574 | H2 | 10.7 PD-07 OPS ECP — full operational-readiness denominator |
| `A3` | 592 | H2 | 10.8 PD-08 TQAEP — construction-ready qualification plan |
| `A3` | 610 | H2 | 10.9 PD-09 Execution Handoff Manifest |
| `A3` | 613 | H2 | 10.10 PD-10 Execution Admission |
| `A3` | 618 | H2 | 10.11 PREDEV_READY predicate |
| `A3` | 621 | H1 | 11 DOC-04 Trace / Acceptance / Verification / Evidence Skeleton |
| `A3` | 623 | H2 | 11.1 Requirement Narrow Waist |
| `A3` | 626 | H2 | 11.2 Evidence envelope |
| `A3` | 629 | H2 | 11.3 Stable TEST/ORACLE identity |
| `A3` | 632 | H2 | 11.4 Evidence types |
| `A3` | 635 | H1 | 12 DOC-05 Handoff / Permission / Effect / Execution Boundary Skeleton |
| `A3` | 637 | H2 | 12.1 Receiver contract |
| `A3` | 640 | H2 | 12.2 Permission/effect classes |
| `A3` | 643 | H2 | 12.3 Authority separation |
| `A3` | 646 | H2 | 12.4 World-effect closure |
| `A3` | 649 | H1 | 13 DOC-06 Tailoring Profiles — Full Target Denominators |
| `A3` | 651 | H2 | 13.1 Weight profiles |
| `A3` | 654 | H2 | 13.2 SYSTEM target — PI 10 denominator |
| `A3` | 657 | H3 | SYSTEM PD 13 denominator |
| `A3` | 660 | H3 | SYSTEM operation/TQAEP minimum |
| `A3` | 663 | H2 | 13.3 SKILL_PLUGIN target — PI denominator |
| `A3` | 666 | H3 | SKILL_PLUGIN PD denominator |
| `A3` | 669 | H3 | Effectful Skill chain |
| `A3` | 672 | H3 | Skill conformance |
| `A3` | 675 | H2 | 13.4 AGENT_HARNESS target — PI 15 denominator |
| `A3` | 678 | H3 | AGENT_HARNESS PD 13 denominator |
| `A3` | 681 | H3 | Typed records (STANDARD/ASSURED) |
| `A3` | 684 | H3 | Eight mandatory adversarial classes |
| `A3` | 687 | H2 | 13.5 BrownfieldMigrationProfile — non-skippable sequence |
| `A3` | 692 | H2 | 13.6 CUSTOM / DomainProfileExtension |
| `A3` | 695 | H1 | 14 DOC-07 Conformance Tests / Oracles / Destructive Review Skeleton |
| `A3` | 712 | H1 | 15 DOC-08 AI Consumption Contract / Portable Adapters / Maturity Ladder |
| `A3` | 714 | H2 | 15.1 Two-phase AI read order |
| `A3` | 719 | H2 | 15.2 Progressive disclosure |
| `A3` | 722 | H2 | 15.3 Adapter maturity ladder / Minimum-Sufficient Architecture |
| `A3` | 727 | H1 | 16 DOC-09 CI / Release / Supply-Chain / Runbook / Executable Tooling |
| `A3` | 729 | H2 | 16.1 CI provider-neutral check ABI |
| `A3` | 736 | H2 | 16.2 Release supply-chain lane |
| `A3` | 748 | H2 | 16.3 Executable reference tooling contracts |
| `A3` | 749 | H3 | `pipd_dist.py` |
| `A3` | 752 | H3 | `pipd_tree_validate.py` |
| `A3` | 755 | H3 | `pipd_drift.py` |
| `A3` | 758 | H1 | 17 Adoption Waves / Operational Runbook / Overlap Rule |
| `A3` | 777 | H1 | 18 Package Derivation / Split–Merge / Vertical-Slice Execution Rules |
| `A3` | 779 | H2 | 18.1 Split Predicate |
| `A3` | 782 | H2 | 18.2 Merge Predicate |
| `A3` | 785 | H2 | 18.3 Vertical slice closure |
| `A3` | 788 | H2 | 18.4 Negative rule |
| `A3` | 791 | H1 | 19 Machine Contracts — Dual-Layer Schema Registry / Core Technology Landing |
| `A3` | 793 | H2 | 19.1 Canonical-core schema registry — P1 22/22 |
| `A3` | 821 | H2 | 19.2 Blueprint/project integration schema registry — P0 9/9 |
| `A3` | 837 | H2 | 19.3 P0/P1 Canonical 22 Technology Baseline — terminal design dispositions + per-item landing |
| `A3` | 867 | H2 | 19.4 Currentness machine binding |
| `A3` | 870 | H1 | 20 Carrier Named Capability / Technology / Workflow Identity-Preserving Crosswalks |
| `A3` | 874 | H2 | 20.1 R1 NOBJ-001..024 — 24/24 |
| `A3` | 904 | H2 | 20.2 R2 ECP exact 48 + ADD-01..04 — 52/52 |
| `A3` | 962 | H2 | 20.3 R2 MSC-TECH-001..015 — 15/15 |
| `A3` | 983 | H2 | 20.4 R3 TQ-TECH-001..031 — 31/31 |
| `A3` | 1020 | H2 | 20.5 R2 Named Donor Workflows — 8/8 |
| `A3` | 1033 | H1 | 21 TQAEP Donor Denominators / Qualification Crosswalk |
| `A3` | 1035 | H2 | 21.1 TestClass denominator — 12/12 |
| `A3` | 1039 | H2 | 21.2 OracleType denominator — 8/8 |
| `A3` | 1042 | H2 | 21.3 TQAEP target profiles — 11/11 |
| `A3` | 1045 | H2 | 21.4 ProviderSlots — 13/13 |
| `A3` | 1050 | H1 | 22 Lifecycle Gate / Claim / Decision Matrix |
| `A3` | 1070 | H1 | 23 Requirement Trace / Acceptance / Evidence Matrix |
| `A3` | 1083 | H1 | 24 Handoff / Receiver / Permission / Effect Matrix |
| `A3` | 1093 | H1 | 25 Role / Ownership / SoD Matrix |
| `A3` | 1105 | H1 | 26 Security / Privacy / Rights / Risk Planning |
| `A3` | 1109 | H1 | 27 World-Effect / Observation / Readback / Reconciliation Planning |
| `A3` | 1115 | H1 | 28 Change / Supersession / Invalidation Planning |
| `A3` | 1127 | H1 | 29 Lifecycle Quality Metrics |
| `A3` | 1146 | H1 | 30 Risk / TT / CR Register |
| `A3` | 1158 | H1 | 31 Source Coverage Ledger — Coverage Kind Prevents False Closure |
| `A3` | 2040 | H1 | 32 Atomic Child Requirement Registry — Materialized in This Repair |
| `A3` | 2570 | H1 | 33 Authority Conflict / Decision Ledger |
| `A3` | 2583 | H1 | 34 Cross-Document Master Artifact Ownership |
| `A3` | 2602 | H1 | 35 Repair Acceptance Gates / Structural Validation / Final Readback |
| `A3` | 2604 | H2 | 35.1 RA-01..RA-14 |
| `A3` | 2623 | H2 | 35.2 Original production-instruction completion gates |
| `A3` | 2637 | H2 | 35.3 Final bounded review claim |
| `A4` | 1 | H1 | 分支 · (主-02)PI-PKG |
| `A4` | 9 | H2 | Prompt: |
| `A4` | 16 | H2 | Response: |
| `A4` | 41 | H1 | 結論先講 |
| `A4` | 76 | H1 | 一、那 `Pre-Implementation` 到底在做什麼？ |
| `A4` | 111 | H1 | 二、為什麼不能直接把那些設計藍圖丟給工程師？ |
| `A4` | 163 | H1 | 三、那為什麼名字叫 **Pre-Implementation**？ |
| `A4` | 208 | H1 | 四、為什麼不乾脆叫「Design Packages」？ |
| `A4` | 242 | H1 | 五、為什麼不叫「Architecture Packages」？ |
| `A4` | 264 | H1 | 六、那為什麼不直接叫 `Pre-Dev`？ |
| `A4` | 277 | H2 | Pre-Implementation |
| `A4` | 301 | H2 | Pre-Dev |
| `A4` | 344 | H1 | 七、最白話的比喻：蓋一棟非常複雜的大樓 |
| `A4` | 348 | H3 | 設計／產品原意階段 |
| `A4` | 357 | H3 | Pre-Implementation |
| `A4` | 374 | H3 | Pre-Dev |
| `A4` | 388 | H3 | Implementation |
| `A4` | 400 | H1 | 八、那 `Multi-Packages` 又是什麼意思？ |
| `A4` | 441 | H1 | 九、為什麼不能乾脆把這 18 包合成一本？ |
| `A4` | 494 | H1 | 十、PI-PKG-17 很能證明「Pre-Implementation」這個名字沒有亂取 |
| `A4` | 528 | H1 | 十一、真正開始 Implementation 的人也證明了這條界線 |
| `A4` | 560 | H1 | 十二、從成熟工程實務來看，這種命名合理嗎？ |
| `A4` | 562 | H2 | 判定：**合理，但屬於「專案自定義的正式 lifecycle term」，不是全球統一標準 phase 名稱。** |
| `A4` | 614 | H1 | 十三、為什麼我不建議改成 `Implementation Preparation`？ |
| `A4` | 645 | H1 | 十四、那是不是叫 `Construction-Ready Design` 更好？ |
| `A4` | 673 | H1 | 十五、還有一個很重要的勘誤：「Pre-Implementation 完成」不等於「整套東西才可以開始施工」 |
| `A4` | 729 | H1 | 十六、因此三個名字要嚴格分清楚 |
| `A4` | 751 | H1 | 十七、最終工程鑑定 |
| `A4` | 783 | H2 | Prompt: |
| `A4` | 789 | H2 | Response: |
| `A4` | 808 | H1 | 工程鑑定結論 |
| `A4` | 838 | H1 | 一、最白話的答案 |
| `A4` | 878 | H1 | 二、為什麼我會說它不是普通藍圖，而是「超完整工程藍圖包」？ |
| `A4` | 917 | H1 | 三、Pre-Implementation 負責的是「完整設計真相」 |
| `A4` | 921 | H2 | `Pre-Implementation` |
| `A4` | 977 | H1 | 四、Pre-Dev 則把它推到「真的快可以按下施工鍵」 |
| `A4` | 1018 | H1 | 五、所以二者其實是「設計完成」＋「施工化完成」 |
| `A4` | 1040 | H1 | 六、但我要修正「藍圖包」這個詞：其實它比藍圖還多 |
| `A4` | 1102 | H1 | 七、用蓋房子比喻，兩者合起來到什麼程度？ |
| `A4` | 1106 | H2 | Pre-Implementation |
| `A4` | 1122 | H2 | Pre-Dev |
| `A4` | 1146 | H1 | 八、這裡有個非常重要的成熟工程原則：施工隊不能重新發明設計 |
| `A4` | 1202 | H1 | 九、所以一套好的 PI + PD，應該讓施工端「不用重新做設計研究」 |
| `A4` | 1242 | H1 | 十、那是不是「PI + PD 做完，以後寫程式完全不用思考」？ |
| `A4` | 1272 | H3 | 可以由 DEV 自己決定 |
| `A4` | 1280 | H3 | 不可以由 DEV 偷偷重新決定 |
| `A4` | 1293 | H1 | 十一、那「超完整」到底應該完整到什麼程度？ |
| `A4` | 1305 | H3 | Pre-Implementation |
| `A4` | 1311 | H3 | Pre-Implementation + Pre-Dev |
| `A4` | 1317 | H3 | Implementation + Verification 之後 |
| `A4` | 1323 | H3 | 真的部署、運轉、RealUse 後 |
| `A4` | 1333 | H1 | 十二、所以哪些東西即使 PI + PD 全部完成，仍然「一定沒有」？ |
| `A4` | 1370 | H1 | 十三、甚至 TQAEP 寫完，也不代表已經 Qualification |
| `A4` | 1406 | H1 | 十四、這兩層合起來，其實就是「Implementation 的完整輸入」 |
| `A4` | 1447 | H1 | 十五、這也解釋了「為什麼兩套都需要」 |
| `A4` | 1488 | H1 | 十六、從你現在 SWOF 的實際規模來看，確實有必要做到這麼完整 |
| `A4` | 1536 | H1 | 十七、這也連回你之前問的「PD 要不要回頭重新讀全部舊資料？」 |
| `A4` | 1578 | H1 | 十八、但不要把 PI-PKG-00～17 + PD-PKG 全部完成，誤解成「一定全部完成後才可以寫第一行 code」 |
| `A4` | 1618 | H1 | 十九、我甚至會把整套文件正式分成三個層級名稱 |
| `A4` | 1622 | H3 | 1. `PI` |
| `A4` | 1626 | H3 | 2. `PD` |
| `A4` | 1630 | H3 | 3. `PI + PD` |
| `A4` | 1645 | H1 | 二十、那它跟傳統的「Software Design Document」相比差多少？ |
| `A4` | 1689 | H1 | 二十一、最重要的最終鑑定 |
| `A4` | 1697 | H3 | 白話回答 |
| `A4` | 1705 | H3 | 工程回答 |
| `A4` | 1717 | H3 | Claim-boundary 回答 |
| `A4` | 1735 | H2 | 最後用一句話定義 |
| `A4` | 1747 | H2 | Prompt: |
| `A4` | 1754 | H2 | Response: |
| `A4` | 1831 | H1 | 可復用 `Pre-Implementation-PKG` / `Pre-Dev-PKG` 生命週期規格體系 |
| `A4` | 1833 | H2 | 一、最終工程結論 |
| `A4` | 1858 | H1 | 二、你真正要標準化的是什麼？ |
| `A4` | 1898 | H1 | 三、我建議正式產出的「7 份核心標準文件」 |
| `A4` | 1924 | H1 | 四、`02_PRE_IMPLEMENTATION_PKG_SPEC.md` 應該規定什麼？ |
| `A4` | 1971 | H1 | 五、`03_PRE_DEV_PKG_SPEC.md` 應該規定什麼？ |
| `A4` | 2013 | H1 | 六、另外一定要有 machine-readable schema |
| `A4` | 2054 | H1 | 七、給 AI 看，不應只寫一份 500 頁大總書 |
| `A4` | 2098 | H1 | 八、`AGENTS.md` 該扮演什麼角色？ |
| `A4` | 2116 | H1 | 九、最好再做一個 `SKILL.md` |
| `A4` | 2166 | H1 | 十、三種目標產品，不應要求相同內容 |
| `A4` | 2170 | H2 | A. 一般 Software / System |
| `A4` | 2184 | H2 | B. SKILL / PLUGIN |
| `A4` | 2210 | H2 | C. Agent Harness |
| `A4` | 2257 | H1 | 十一、Agent Harness 還必須把 Guardrail / Handoff / Trace 寫成一級 contract |
| `A4` | 2280 | H1 | 十二、安全規格應內建，而不是另做一本「資安附錄」 |
| `A4` | 2307 | H1 | 十三、通用狀態機一定要標準化 |
| `A4` | 2334 | H1 | 十四、三種「重量級」Profile，避免過度工程化 |
| `A4` | 2354 | H1 | 十五、你最終應該發布的完整 package |
| `A4` | 2414 | H1 | 十六、這套標準最大的工程價值 |
| `A4` | 2471 | H1 | 十七、與目前 2026 外部趨勢的交叉鑑定 |
| `A4` | 2498 | H1 | 十八、最後的具體建議 |
| `AUDIT` | 20 | H1 | 《PIPD_LS_DOC-00_2026-10-07_r1_FULL_SUBSTANTIVE_BODY》實質正文全量審查報告 |
| `AUDIT` | 22 | H2 | 0. Executive Verdict |
| `AUDIT` | 30 | H3 | 0.1 最關鍵的三個阻斷 |
| `AUDIT` | 36 | H3 | 0.2 高保留修補邊界 |
| `AUDIT` | 42 | H1 | 1. Audit Scope / Authority / Claim Ceiling |
| `AUDIT` | 69 | H1 | 2. Physical / Structural Readback |
| `AUDIT` | 85 | H1 | 3. Upstream Source Manifest |
| `AUDIT` | 98 | H1 | 4. SOP Execution Receipt |
| `AUDIT` | 100 | H2 | SOP-1｜查看索引 |
| `AUDIT` | 104 | H2 | SOP-2｜定位實質條文 |
| `AUDIT` | 108 | H2 | SOP-3｜關鍵字全文比對 |
| `AUDIT` | 122 | H2 | SOP-4｜交叉驗證 |
| `AUDIT` | 126 | H2 | SOP-5｜子要求分解 |
| `AUDIT` | 130 | H2 | SOP-6｜實質內容判定 |
| `AUDIT` | 134 | H2 | SOP-7｜Apparent-PASS challenge |
| `AUDIT` | 138 | H2 | SOP-8｜正文優先 |
| `AUDIT` | 142 | H2 | SOP-9｜Tool / Technology / Workflow / OSS |
| `AUDIT` | 148 | H1 | 5. Re-evaluated Final Gates |
| `AUDIT` | 171 | H1 | 6. Finding Register — Full Substantive Audit |
| `AUDIT` | 194 | H1 | 7. Substantive Body Chapter-by-Chapter Audit |
| `AUDIT` | 228 | H1 | 8. Destructive / Apparent-PASS Review |
| `AUDIT` | 246 | H1 | 9. Tool / Technology / Workflow / OSS Audit |
| `AUDIT` | 248 | H2 | 9.1 Layer-A — Canonical 22 CAND |
| `AUDIT` | 256 | H2 | 9.2 2026-10-07 currentness recheck |
| `AUDIT` | 291 | H2 | 9.3 Layer-B named donor/workflow denominator |
| `AUDIT` | 449 | H1 | 10. Search-Before-Build / TechnologyAdmission Logic Audit |
| `AUDIT` | 480 | H1 | 11. TechnologyAdmissionRecord Field Audit |
| `AUDIT` | 535 | H1 | 12. Structure / Logic / Drift / Regression Audit |
| `AUDIT` | 537 | H2 | 12.1 Structure |
| `AUDIT` | 541 | H2 | 12.2 Logic |
| `AUDIT` | 554 | H2 | 12.3 Drift |
| `AUDIT` | 562 | H2 | 12.4 Regression |
| `AUDIT` | 575 | H1 | 13. Landing Feasibility Assessment |
| `AUDIT` | 590 | H1 | 14. Global Repair Plan |
| `AUDIT` | 592 | H2 | P0 — Blocker closure |
| `AUDIT` | 603 | H2 | P1 — Major repair |
| `AUDIT` | 683 | H2 | P2 — Optimization |
| `AUDIT` | 706 | H1 | 15. Required r2 Acceptance Gates |
| `AUDIT` | 729 | H1 | 16. Final Audit Verdict |
| `AUDIT` | 756 | H1 | Appendix A｜Full Layer-B Named Identity Audit |
| `AUDIT` | 895 | H1 | Appendix B｜Finding Priority Map |
| `AUDIT` | 905 | H1 | Appendix C｜Audit Packaging Note |
<!-- BEGIN_PACKAGING_RECEIPT -->
# Packaging Receipt
```yaml
hash_scope: bytes_before_BEGIN_PACKAGING_RECEIPT
payload_sha256: 7f8b23fb313e5424d815c5b3c61ba85afbe6e0f883165dcff4bdfe3c0273f987
payload_bytes: 251580
payload_lines: 2280
whole_file_sha256_delivery_readback: EXTERNAL_AFTER_FINAL_WRITE
single_md_exists: true
utf8_readback_required: true
claim_scope: local_document_materialization_only
```
