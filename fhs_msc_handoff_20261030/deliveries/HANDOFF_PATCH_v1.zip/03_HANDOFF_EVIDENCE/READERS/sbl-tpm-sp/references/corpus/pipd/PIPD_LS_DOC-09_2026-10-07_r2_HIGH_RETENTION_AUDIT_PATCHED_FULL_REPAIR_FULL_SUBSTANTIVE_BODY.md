---
artifact_id: "PIPD_LS_DOC-09"
external_formal_name: "Pre-Implementation & Pre-Dev Lifecycle Specification — DOC-09 CI / Release / Supply-Chain / Runbook / Executable Tooling"
internal_short_name: "PIPD_LS_DOC-09"
artifact_type: "FULL_SUBSTANTIVE_BODY_HIGH_RETENTION_AUDIT_PATCHED_FULL_REPAIR_CI_RELEASE_SUPPLY_CHAIN_RUNBOOK_EXECUTABLE_TOOLING"
standard_id: "PIPD-LIFECYCLE-SPEC"
standard_version: "1.1.0"
blueprint_id: "PIPD-LIFECYCLE-BLUEPRINT"
blueprint_version: "1.1.0-r2_FULL_REPAIR"
skeleton_id: "PIPD_LS_SKELETON"
skeleton_version: "1.1.0-SKELETON-r2_FULL_REPAIR"
version: "2026-10-07_r2_HIGH_RETENTION_AUDIT_PATCHED_FULL_REPAIR_FULL_SUBSTANTIVE_BODY"
revision: "r2"
generated_at: "2026-10-07T16:14:00+08:00"
timezone: "Asia/Taipei"
status: "DOC09_R2_HIGH_RETENTION_AUDIT_PATCHED_FULL_REPAIR_MATERIALIZED_LOCAL"
materialization_state: "LOCAL_DOCUMENT_MATERIALIZED"
supersedes: "PIPD_LS_DOC-09_2026-10-07_r1_FULL_SUBSTANTIVE_BODY"
supersedes_sha256: "fdf43ed1d0710603cabc17e460acedfe7e21572c4e847d95e4dd52b63f7788fb"
patch_basis: "AUDIT_PIPD_LS_DOC-09_2026-10-07_r1_FULL_SUBSTANTIVE_BODY_FULL_AUDIT_2026-10-07_r1"
patch_mode: "HIGH_RETENTION_FULL_REPAIR_NO_ARCHITECTURE_RESET"
canonical_owner: "PIPD_LS_DOC-09"
root_task_kind: "DESIGN"
claim_ceiling: "LOCAL_REPAIRED_DESIGN_AND_EXECUTABLE_REFERENCE_ASSETS_MATERIALIZED"
runtime_execution: "NOT_EXECUTED"
provider_binding: "NOT_BOUND"
independent_pass: "NOT_CLAIMED"
human_ratification: "NOT_CLAIMED"
release_candidate: "NOT_CLAIMED"
production_pass: "NOT_CLAIMED"
source_read_mode: "FULL_UTF8_READ_NO_SAMPLING"
line_count_method: "Python str.splitlines()"
currentness_observed_at: "2026-10-07"
---

# PIPD_LS_DOC-09 — CI / Release / Supply-Chain / Runbook / Executable Tooling
## r2 High-Retention Audit-Patched Full Repair Full Substantive Body

<a id="doc09-contract"></a>
# 0｜Document Contract / Supersession / Non-Regression

本 r2 以 r1 為 **retained baseline**，依 FULL AUDIT 執行高保留修補；不是 architecture reset。r1 已成立的 Provider-Neutral CI ABI、required-check semantics、artifact digest continuity、A–J waves、evidence identity、fail-closed、affected-only invalidation、SoD 與 provider-off narrow waist全部保留；被 AUDIT 判定為描述性、缺漏、錯指、假 PASS 的部分則由本 r2 工程性整合、覆蓋並取代。

本文件仍只擁有 DOC-09 的 canonical responsibility：**CI / Release / Supply-Chain / Runbook / Executable Tooling**。它不建立第二套 Constitution、不授權 execution、不取代 DOC-00～08 的 canonical ownership，也不把 CI、scanner、SBOM、attestation 或 release workflow 的成功狀態提升為 Product Truth、ExecutionAdmission、Qualification 或 Release Authority 決定。

<a id="doc09-claim"></a>
## 0.1 Claim-Separation Axioms

```text
CI_PASS != PRODUCT_ACCEPTANCE
CI_PASS != EXECUTION_ADMISSION
BUILD_SUCCESS != VERIFICATION_PASS
ATTESTATION_CREATED != ATTESTATION_VERIFIED
ATTESTATION_VERIFIED != FUNCTIONAL_ACCEPTANCE
SBOM_PRESENT != SUPPLY_CHAIN_ACCEPTED
SCANNER_PASS != RELEASE_ACCEPTANCE
RELEASE_WORKFLOW_SUCCESS != RELEASE_AUTHORITY_APPROVAL
TOOL_SUCCESS != WORLD_EFFECT_TRUTH
REFERENCE_BASELINE_PIN != TARGET_RUNTIME_PIN
SELECTED != INSTALLED
INSTALLED != BOUND
BOUND != ENABLED
ENABLED != VERIFIED
```

`LOCAL_REPAIRED_DESIGN_AND_EXECUTABLE_REFERENCE_ASSETS_MATERIALIZED` 只表示本 MD 已包含可 materialize 的 reference assets 與完整設計契約，不表示任何 target repository 已實際安裝、綁定、執行或通過 Independent/Human/Release/Production gate。



<a id="doc09-authority"></a>
# 1｜Authority / Mandatory Source Set / Full-Scan Receipt

## 1.1 Adjudication Order

`Current PATCH instruction > P1 Blueprint > P2 Canonical Standard > P3 Skeleton > P4 Lifecycle Discussion > current DOC-00..08 sibling alignment > accepted donor/control material > external SUPPORT/currentness`.

任何 SUPPORT/currentness 訊號只能改變 pin/currentness/security/compatibility disposition 或開 TT/CR，不得覆寫 P1–P3 lifecycle semantics。

## 1.2 Full Mandatory Source Manifest

|source_id|physical file|identity|SHA-256|bytes|splitlines|priority|class|read status|
|---|---|---|---|---:|---:|---|---|---|
|P1|`Pre-Implementation_and_Pre-Dev_Lifecycle_Specification_總藍圖.md`|PIPD-LIFECYCLE-BLUEPRINT@1.1.0-r2_FULL_REPAIR|`9a8323e5237c1555a76d9a75f706e3552d79c192915cc782b76b211c7f27d527`|149077|2996|P1|CANONICAL_BLUEPRINT|FULL_UTF8_READ / NO_SAMPLING|
|P2|`Pre-Implementation_and_Pre-Dev_Lifecycle_Specification_canonical_standard.md`|PIPD-LIFECYCLE-SPEC@1.1.0|`6f6aafece90b34e33786647e14fee840f5424893995b3164cbb52953a5c4f14a`|209157|7176|P2|CANONICAL_STANDARD|FULL_UTF8_READ / NO_SAMPLING|
|P3|`PIPD_LS_skeleton_2026-10-06_r2_FULL_REPAIR(1).md`|PIPD_LS_SKELETON@1.1.0-SKELETON-r2_FULL_REPAIR|`03bb3609dc67f85fa4b683a93736cf162e9047b6b253182aa3fdba11ba40cb28`|376599|2668|P3|CANONICAL_SKELETON|FULL_UTF8_READ / NO_SAMPLING|
|P4|`Pre-Implementation-PKG  Pre-Dev-PKG 生命週期規格_總討論(1).md`|Lifecycle Design Discussion|`be1858e860092fb1751bf0524cd22b6939138b6835ce8f452bfc30894f945a95`|77326|2559|P4|DESIGN_INTENT|FULL_UTF8_READ / NO_SAMPLING|
|P0-INSTR|`《PIPD_LS_DOC-09》產出指令.txt`|PIPD_LS_DOC-09 Production Instruction|`693e245840f8233c0916b258e21ddf979dff2b983bd5789cb9ca1b565ecf2edd`|46238|2041|P0|TASK_INSTRUCTION_SNAPSHOT|FULL_UTF8_READ / NO_SAMPLING|
|R1|`PIPD_LS_DOC-09_2026-10-07_r1_FULL_SUBSTANTIVE_BODY(2).md`|PIPD_LS_DOC-09@2026-10-07_r1_FULL_SUBSTANTIVE_BODY|`fdf43ed1d0710603cabc17e460acedfe7e21572c4e847d95e4dd52b63f7788fb`|73147|730|PATCH_BASELINE|SUPERSEDED_TARGET|FULL_UTF8_READ / NO_SAMPLING|
|AUDIT|`AUDIT_PIPD_LS_DOC-09_2026-10-07_r1_FULL_SUBSTANTIVE_BODY_FULL_AUDIT_2026-10-07_r1(1).md`|AUDIT_PIPD_LS_DOC-09@2026-10-07_r1|`5baff09737f6745d558b59cf4f73390a91317fd9241279537eecf3b5ea49f19b`|43021|1378|PATCH_CONTROLLER|FULL_AUDIT|FULL_UTF8_READ / NO_SAMPLING|
|D00|`PIPD_LS_DOC-00_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY(1).md`|PIPD_LS_DOC-00|`be3a672ec20aa0e6b5e0e35097fc08de749bfe7f59f827d18e38aef67dd68ea4`|251982|2292|P5|SIBLING_ALIGNMENT|FULL_UTF8_READ / NO_SAMPLING|
|D01|`PIPD_LS_DOC-01_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY(1).md`|PIPD_LS_DOC-01|`b753f2e5cdd5598a818f8a113d57b7f815aeb3f1dfa061ce74c76bb3553ac8c7`|177451|2592|P5|SIBLING_ALIGNMENT|FULL_UTF8_READ / NO_SAMPLING|
|D02|`PIPD_LS_DOC-02_2026-10-07_r2_HIGH_RETENTION_AUDIT_PATCHED_FULL_REPAIR_FULL_SUBSTANTIVE_BODY (1).md`|PIPD_LS_DOC-02|`a021998dd3b63015e89af1dd40e0b413744a69b872da46c6bf5f4d92f7f23d0b`|1306240|18413|P5|SIBLING_ALIGNMENT|FULL_UTF8_READ / NO_SAMPLING|
|D03|`PIPD_LS_DOC-03_2026-10-07_r2_AUDIT_REPAIR_FULL_SUBSTANTIVE_BODY(1).md`|PIPD_LS_DOC-03|`d89d82dcd2c8603ec6b86c5ec8c40845e4594bc181adf5272bd48a3de7c88f0f`|454167|1911|P5|SIBLING_ALIGNMENT|FULL_UTF8_READ / NO_SAMPLING|
|D04|`PIPD_LS_DOC-04_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY(1).md`|PIPD_LS_DOC-04|`fa64d84da3d747b183e4affff62f4d2fb86c80bb5075f5dd933c09b20caeddcf`|181988|4052|P5|SIBLING_ALIGNMENT|FULL_UTF8_READ / NO_SAMPLING|
|D05|`PIPD_LS_DOC-05_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY(1).md`|PIPD_LS_DOC-05|`7b40584540c162cda6debfd09a4c04321416706acdb03a7a3c2b41383dc585f4`|227894|3946|P5|SIBLING_ALIGNMENT|FULL_UTF8_READ / NO_SAMPLING|
|D06|`PIPD_LS_DOC-06_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY(1).md`|PIPD_LS_DOC-06|`20e44ea4dd8e53c9b0a076ce861136bbea86f52687019307f6e995cd9079d303`|405028|3790|P5|SIBLING_ALIGNMENT|FULL_UTF8_READ / NO_SAMPLING|
|D07|`PIPD_LS_DOC-07_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY(1).md`|PIPD_LS_DOC-07|`a68dae1c3670d07bcfa3476a1e37463c534594df5cd65d8dab0dca064b5a9fc1`|689563|12915|P5|SIBLING_ALIGNMENT|FULL_UTF8_READ / NO_SAMPLING|
|D08|`PIPD_LS_DOC-08_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY(2).md`|PIPD_LS_DOC-08|`e46caa7e440392a6cfa7a86421aead5bce8a2a229fec97b133429db6b6748e42`|197972|2501|P5|SIBLING_ALIGNMENT|FULL_UTF8_READ / NO_SAMPLING|

**Full-scan receipt:** `16/16` mounted source artifacts fully decoded as strict UTF-8; aggregate bytes=`4866850`; aggregate line metric=`71960` using exactly `Python str.splitlines()`; sampling=`false`.

## 1.3 Production Instruction Source Binding

The production instruction is now a reproducible first-class source:

```yaml
source_id: P0-INSTR
physical_file: "《PIPD_LS_DOC-09》產出指令.txt"
sha256: "693e245840f8233c0916b258e21ddf979dff2b983bd5789cb9ca1b565ecf2edd"
bytes: 144948
splitlines: 2451
role: "DOC-09 production requirement authority for this repair task"
```

This closes AUDIT G01/§8.3: no Atomic Requirement row refers to an unbound generic `instruction`.

## 1.4 SOP-3 Keyword Full-Text Cross-Check Receipt

|keyword / identity|occurrences across P1/P2/P3/P4/Instruction/R1/AUDIT|result|
|---|---:|---|
|`Provider-Neutral CI`|16|CROSS_CHECKED|
|`RequiredCheck`|3|CROSS_CHECKED|
|`merge_group`|21|CROSS_CHECKED|
|`Build`|219|CROSS_CHECKED|
|`Transfer`|35|CROSS_CHECKED|
|`Attest`|221|CROSS_CHECKED|
|`Verify`|80|CROSS_CHECKED|
|`SBOM`|94|CROSS_CHECKED|
|`SLSA`|32|CROSS_CHECKED|
|`Sigstore`|19|CROSS_CHECKED|
|`Cosign`|18|CROSS_CHECKED|
|`GitHub Actions`|16|CROSS_CHECKED|
|`Trivy`|6|CROSS_CHECKED|
|`Agent Skills`|31|CROSS_CHECKED|
|`Spec Kit`|21|CROSS_CHECKED|
|`Superpowers`|12|CROSS_CHECKED|
|`SCIP`|9|CROSS_CHECKED|
|`MoRSE`|4|CROSS_CHECKED|
|`runbook`|100|CROSS_CHECKED|
|`rollback`|308|CROSS_CHECKED|
|`provider-off`|185|CROSS_CHECKED|
|`currentness`|422|CROSS_CHECKED|
|`Release Authority`|105|CROSS_CHECKED|
|`Gitleaks`|19|CROSS_CHECKED|
|`Scorecard`|41|CROSS_CHECKED|

The keyword scan is not itself acceptance. It is a **denominator discovery control**: every hit family was then inspected at its substantive clause/crosswalk location before inclusion or terminal disposition.

## 1.5 SOP-5 Compound Requirement Decomposition

Compound requirements containing `each / respectively / corresponding / 各有 / 分別 / 對應` are decomposed into independent obligations in:
- `#27 Atomic Requirement Ledger`;
- `#17 Full Technology Records`;
- `#20 Executable Fixture Contracts`;
- `#21 Per-Tool Qualification & Exit Matrix`.

A parent requirement is not CLOSED if any atomic child remains missing, unresolved, or merely named without substantive body.



<a id="doc09-mission"></a>
# 2｜Mission / Design Intent / Scope / Non-Goals

DOC-09 closes the enforcement/transport gap between a lifecycle standard and executable pre-execution/release control. It provides:
1. provider-neutral validation ABI;
2. concrete reference CI adapter proving the ABI;
3. required-check enforcement/readback model;
4. artifact identity continuity across Build→Transfer;
5. SBOM/provenance/attestation creation and independent verification;
6. ReleaseGateInput materialization without self-authorizing RELEASED;
7. deterministic tooling for distribution, tree validation, and drift;
8. operational runbooks, currentness, rollback, uninstall, provider-off, and residue proof.

### In scope
- CI adapter/event/check transport;
- release supply-chain evidence lane;
- validator environment and repository enforcement binding;
- reference workflows;
- tooling source code;
- named donor identity crosswalks and technology selection records;
- executable fixtures and per-tool qualification;
- operator runbooks and release/recovery controls.

### Non-goals
- redefine Product Truth, lifecycle Constitution, state machine, TechnologyAdmission authority, ExecutionAdmission, Evidence Truth, test/oracle ownership, or Release Authority;
- make every donor/tool mandatory;
- claim any target runtime state without subject-bound evidence.



<a id="doc09-sibling"></a>
# 3｜DOC-09 ↔ DOC-00..08 Ownership / Read / Write / Reference Matrix

|Sibling|DOC-09 reads|DOC-09 may emit|Forbidden takeover|
|---|---|---|---|
|DOC-00|navigation/operator entry|deep-links/readback|no second global router|
|DOC-01|states/claims/authority/SoD|state-transition evidence refs / ReleaseGateInput|no Constitution/state-machine authority|
|DOC-02|PI compiler/TechnologyAdmission|tool currentness observations/capability needs|no second technology-admission authority|
|DOC-03|RepoContext/provider/runtime/currentness binding|CI/runner/tool observations|no invented runtime binding|
|DOC-04|trace/evidence truth contract|subject-bound CI/release receipts|no alternate evidence truth model|
|DOC-05|permission/admission|permission requests/status consumption|no execution grant|
|DOC-06|LITE/STANDARD/ASSURED profiles|profile-specific CI/release projection|no profile weakening|
|DOC-07|test/oracle/fixture registry|test invocation and result refs|no conflicting oracle ownership|
|DOC-08|AI consumption/adapter maturity|adapter conformance refs|no adapter authority takeover|

The common Constitution/state machine/claim model remains one canonical lifecycle authority; modularity is by responsibility, not by fragmenting canonical authority.



<a id="doc09-objects"></a>
# 4｜DOC-09 Canonical Object Model

|Object|Purpose|Required minimum|
|---|---|---|
|CIProviderNeutralABI|vendor-neutral validation narrow waist|abi_id/version/command/exit_map/report_schema/subject_binding|
|CIAdapterBinding|project/provider mapping|provider/project/events/runner/pins/permissions/status|
|RequiredCheckContract|merge-enforcement semantics|check_id/trigger/terminal states/skip semantics/timeout/rerun|
|ConformanceRun|one validator run|subject/env/command/exit/report hash/first failing invariant|
|ValidatorEnvironmentBinding|validator runtime reproducibility|runtime/version/dependency lock or container digest/checker/currentness|
|RepositoryEnforcementBinding|required check actual repo enforcement|check name/ruleset-or-protection/readback/merge queue/status|
|ReleaseArtifactStoreBinding|immutable/content-addressed transfer boundary|provider/store/auth/retention/upload/download/digest/provider-off|
|ReleaseSupplyChainRun|Build→Transfer→Attest→Verify→Gate|artifact subject/step receipts/release gate input|
|ArtifactDigestReceipt|immutable artifact boundary identity|name/path/bytes/sha256/producer/time/prior receipt|
|SBOMGeneratorBinding|concrete generator tool binding|tool/version/pin/command/output format/subject/test/oracle|
|SBOMReceipt|SBOM evidence bound to artifact|format/generator/sbom hash/artifact digest/schema validation|
|ProvenanceReceipt|build/source provenance|predicate/builder/source/artifact digest/hash|
|AttestationReceipt|attestation creation fact|attestor/subject/predicate/bundle/time|
|AttestationVerificationReceipt|independent verification result|subject/verifier/policy/identity/result/time|
|ReleaseGateInput|complete decision packet|artifact/functional/supply-chain/currentness/rollback/risk|
|ExecutableToolContract|materializable tool semantics|path/version/hash/dependencies/CLI/exit/tests/uninstall/rebuild|
|ToolQualificationRecord|per-tool adoption closure|install/bind/function/boundary/negative/rollback/uninstall/off/residue/evidence|
|AdoptionWaveState|A–J slice progression|slice/wave/entry/output/evidence/exit/rollback|
|OperationalRunbookStep|bounded operator action|trigger/preconditions/exact command/observation/invariant/claim ceiling/rollback|
|ToolCurrentnessRecord|observed vs selected|version/pin/license/checked_at/TTL/security/compatibility/drift|



<a id="doc09-ci-abi"></a>
# 5｜Provider-Neutral CI ABI

Canonical command:

```bash
python .pipd/tools/pipd_tree_validate.py validate-tree   --root .   --manifest .pipd/project/manifest.json   --report .pipd/conformance/reports/pipd-report.json
```

|Exit|Class|Meaning|
|---:|---|---|
|0|PASS|all applicable checks for exact subject satisfied; still only an input to higher gates|
|2|SCHEMA|schema/distribution structural failure|
|3|SEMANTIC|canonical semantic invariant failure|
|4|CURRENTNESS|stale lock/tool/evidence/currentness|
|5|PERMISSION|permission/admission/security authority missing|
|6|RESOLUTION|required source/ref/provider/subject cannot resolve|
|7|INTERNAL|validator/orchestrator internal failure|

Provider adapters MAY schedule jobs and transport reports. They MUST NOT modify these semantics or reinterpret non-zero results as PASS.



<a id="doc09-required-check"></a>
# 6｜Required-Check Semantics

`SKIPPED / MISSING / STALE / WRONG_SUBJECT / CANCELLED / TIMEOUT` are non-PASS for a required relevant check. A provider-side `success` is accepted only if a current exact-subject canonical conformance report from the expected producer is present and valid.

Relevant-change routing must be deterministic. Path filters are prohibited where they can make a required check silently disappear. Merge queues create a distinct merge-group subject and therefore require the adapter to cover `merge_group` where enabled.



<a id="doc09-action-baseline"></a>
# 7｜P1 Reference Action Baseline + Target Re-Pin

The repair preserves P1 known immutable baselines **without** pretending they are permanently current target bindings.

|action|P1 reference version|P1 full SHA|reference TTL|compatibility note|target project binding|
|---|---|---|---|---|---|
|`actions/checkout`|`v7.0.1`|`3d3c42e5aac5ba805825da76410c181273ba90b1`|168h|GitHub-hosted; self-hosted runner currentness required|LATE_BOUND_REQUIRED after target currentness recheck|
|`actions/setup-python`|`v7.0.0`|`5fda3b95a4ea91299a34e894583c3862153e4b97`|168h|cache disabled in generic template until lock binding|LATE_BOUND_REQUIRED after target currentness recheck|
|`actions/upload-artifact`|`v7.0.1`|`043fb46d1a93c77aae656e7c1c64a875d1fc6a0a`|168h|runner compatibility must be current|LATE_BOUND_REQUIRED after target currentness recheck|
|`actions/download-artifact`|`v8.0.0`|`70fc10c6e5e1ce46ad2ea6f2b72d43f7d47b13c3`|168h|cross-job release artifact handoff|LATE_BOUND_REQUIRED after target currentness recheck|
|`actions/dependency-review-action`|`v5.0.0`|`a1d282b36b6f3519aa1f3fc636f609c47dddb294`|168h|Node24; runner admission required|LATE_BOUND_REQUIRED after target currentness recheck|
|`github/codeql-action`|`v4.38.2`|`2892aa5e19bbd11bc0cff5427e3b750a04d9e3c2`|168h|language binding target-specific|LATE_BOUND_REQUIRED after target currentness recheck|
|`actions/attest`|`v4.2.2`|`1e69f48acb82d1966a394da916b4c1698aa569d6`|168h|requires attestations:write + id-token:write|LATE_BOUND_REQUIRED after target currentness recheck|

Two-level invariant:

```yaml
reference_baseline:
  version: "preserved from P1"
  full_sha: "preserved from P1"
  checked_at: "P1 baseline observation"
project_binding:
  selected_version: "LATE_BOUND_REQUIRED"
  selected_full_sha: "LATE_BOUND_REQUIRED"
  recheck_required: true
  close_before: "PREDEV_READY / affected CI or release wave"
```



<a id="doc09-github-ci"></a>
# 8｜Complete GitHub Reference CI Adapter

The following is the complete P1 reference adapter, retained as an executable materialization asset. It has no `paths:` filter, does not hard-code `main`, includes `merge_group`, installs a hash-locked validator environment, rebuilds deterministic distribution, validates the full tree, and uploads the report even on failure.

**Asset path:** `.github/workflows/pipd-required.yml`

```yaml
name: PIPD Required

on:
  pull_request:
  merge_group:
  workflow_dispatch:

permissions:
  contents: read

concurrency:
  group: pipd-${{ github.workflow }}-${{ github.event.pull_request.number || github.ref }}
  cancel-in-progress: true

jobs:
  pre-execution-gate:
    name: PIPD / pre-execution-gate
    runs-on: ubuntu-latest
    timeout-minutes: 15

    steps:
      - uses: actions/checkout@3d3c42e5aac5ba805825da76410c181273ba90b1 # v7.0.1
        with:
          persist-credentials: false

      - uses: actions/setup-python@5fda3b95a4ea91299a34e894583c3862153e4b97 # v7.0.0
        with:
          python-version: "3.13"

      - name: Install hash-locked validator environment
        run: |
          test -f .pipd/project/toolchain/pipd-validator.requirements.lock
          python -m pip install --disable-pip-version-check             --require-hashes             -r .pipd/project/toolchain/pipd-validator.requirements.lock

      - name: Rebuild deterministic distribution
        run: |
          python .pipd/tools/pipd_dist.py             --standard .pipd/vendor/PIPD-LIFECYCLE-SPEC-1.1.0.md             --expected-sha256 "$(python -c 'import json; print(json.load(open(".pipd/lock/standard.lock.json"))["sha256"])')"             --out .pipd/generated

      - name: Validate complete project tree
        run: |
          python .pipd/tools/pipd_tree_validate.py validate-tree             --root .             --manifest .pipd/project/manifest.json             --report .pipd/conformance/reports/pipd-report.json

      - name: Upload conformance report
        if: always()
        uses: actions/upload-artifact@043fb46d1a93c77aae656e7c1c64a875d1fc6a0a # v7.0.1
        with:
          name: pipd-conformance
          path: .pipd/conformance/reports/pipd-report.json
          if-no-files-found: error
          retention-days: 14
```

Reference workflow materialization does **not** mean the target repo is bound. `RepositoryEnforcementBinding` in §13 must still prove the status context is actually required by the repository/provider.



<a id="doc09-release"></a>
# 9｜Release Supply-Chain Lane / Complete Reference Workflow

Canonical lane:

```text
project-native build
→ artifact path + SHA-256 readback
→ immutable/content-addressed transfer boundary
→ fresh download
→ digest recomputation == build digest
→ SBOM generation bound to same digest
→ attestation creation
→ independent attestation verification
→ ReleaseGateInput
→ separate Release Authority decision
```

**Asset path:** `.github/workflows/pipd-release.yml`

```yaml
name: PIPD Release

on:
  workflow_dispatch:

permissions:
  contents: read

jobs:
  build:
    runs-on: ubuntu-latest
    outputs:
      artifact_sha: ${{ steps.meta.outputs.artifact_sha }}
      artifact_name: ${{ steps.meta.outputs.artifact_name }}

    steps:
      - uses: actions/checkout@3d3c42e5aac5ba805825da76410c181273ba90b1 # v7.0.1
        with:
          persist-credentials: false

      - name: Build through target-bound WorkOrder
        run: |
          test -x .pipd/project/release/build.sh
          .pipd/project/release/build.sh
          test -f .pipd/project/release/output.json

      - id: meta
        name: Read and verify release subject
        run: |
          path="$(python -c 'import json; print(json.load(open(".pipd/project/release/output.json"))["artifact_path"])')"
          test -f "$path"
          sha="$(sha256sum "$path" | awk '{print $1}')"
          echo "artifact_sha=$sha" >> "$GITHUB_OUTPUT"
          echo "artifact_name=$(basename "$path")" >> "$GITHUB_OUTPUT"
          cp "$path" .pipd-release-subject

      - uses: actions/upload-artifact@043fb46d1a93c77aae656e7c1c64a875d1fc6a0a # v7.0.1
        with:
          name: pipd-release-subject
          path: .pipd-release-subject
          if-no-files-found: error

  attest-and-verify:
    needs: build
    runs-on: ubuntu-latest
    permissions:
      contents: read
      id-token: write
      attestations: write

    steps:
      - uses: actions/download-artifact@70fc10c6e5e1ce46ad2ea6f2b72d43f7d47b13c3 # v8.0.0
        with:
          name: pipd-release-subject
          path: release-input

      - name: Verify transferred digest
        env:
          EXPECTED_SHA: ${{ needs.build.outputs.artifact_sha }}
        run: |
          actual="$(sha256sum release-input/.pipd-release-subject | awk '{print $1}')"
          test "$actual" = "$EXPECTED_SHA"

      - uses: actions/attest@1e69f48acb82d1966a394da916b4c1698aa569d6 # v4.2.2
        with:
          subject-path: release-input/.pipd-release-subject

      - name: Read back attestation
        run: |
          gh attestation verify release-input/.pipd-release-subject             -R "$GITHUB_REPOSITORY"             > attestation-verification.txt

      - uses: actions/upload-artifact@043fb46d1a93c77aae656e7c1c64a875d1fc6a0a # v7.0.1
        with:
          name: pipd-attestation-verification
          path: attestation-verification.txt
          if-no-files-found: error

  sbom:
    needs: build
    runs-on: ubuntu-latest
    permissions:
      contents: read
    steps:
      - uses: actions/download-artifact@70fc10c6e5e1ce46ad2ea6f2b72d43f7d47b13c3 # v8.0.0
        with:
          name: pipd-release-subject
          path: release-input

      - name: Generate target-bound CycloneDX SBOM with qualified generator
        env:
          EXPECTED_SHA: ${{ needs.build.outputs.artifact_sha }}
        run: |
          test -f .pipd/project/toolchain/sbom-generator.json
          test -x .pipd/project/toolchain/bin/syft
          actual="$(sha256sum release-input/.pipd-release-subject | awk '{print $1}')"
          test "$actual" = "$EXPECTED_SHA"
          mkdir -p release-evidence
          .pipd/project/toolchain/bin/syft \
            release-input/.pipd-release-subject \
            -o cyclonedx-json=release-evidence/sbom.cdx.json
          test -s release-evidence/sbom.cdx.json

      - uses: actions/upload-artifact@043fb46d1a93c77aae656e7c1c64a875d1fc6a0a # v7.0.1
        with:
          name: pipd-sbom
          path: release-evidence/sbom.cdx.json
          if-no-files-found: error

  release-gate-input:
    needs: [build, attest-and-verify, sbom]
    runs-on: ubuntu-latest
    permissions:
      contents: read
    steps:
      - name: Assert Release Authority remains external to workflow
        run: |
          echo "This job only materializes ReleaseGateInput."
          echo "RELEASED promotion requires a separate authorized decision receipt."

```

The workflow is intentionally unable to self-promote to `RELEASED`. A separate decision receipt from the canonical Release Authority is mandatory.



<a id="doc09-sbom"></a>
# 10｜SBOM / Provenance / SLSA / Attestation

## 10.1 Format and generator separation

- CycloneDX 1.7 JSON is the DOC-09 reference SBOM interchange profile.
- SPDX 3.x is a supported alternate profile.
- A format is not a generator.
- The r2 reference generator profile is **Syft**, but exact target version/digest is `LATE_BOUND_REQUIRED` and MUST pass qualification before use.
- If target policy selects another generator, the `SBOMGeneratorBinding → SBOMReceipt` contract remains unchanged.

Reference command after target-bound Syft is materialized:

```bash
.pipd/project/toolchain/bin/syft   release-input/.pipd-release-subject   -o cyclonedx-json=.pipd/release/sbom.cdx.json
```

## 10.2 SLSA v1.2 crosswalk

`SLSA v1.2` is retained as `REFERENCE / TRANSLATE`, not as a second lifecycle authority. PIPD imports subject/build/source provenance expectations into `ProvenanceReceipt`; excluded semantics include any inference that a provenance statement equals functional acceptance or release authorization.

## 10.3 Receipt separation

```text
SBOMReceipt != ProvenanceReceipt
ProvenanceReceipt != AttestationReceipt
AttestationReceipt != AttestationVerificationReceipt
AttestationVerificationReceipt != FunctionalAcceptance
FunctionalAcceptance != ReleaseAuthorityDecision
```



<a id="doc09-tools"></a>
# 11｜Executable Reference Tooling — Full Materialized Source

These source bodies are high-retention ports from P1. They are not prose substitutes.

## 11.1 `.pipd/tools/pipd_dist.py`

```python
#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json, re
from pathlib import Path
from jsonschema import Draft202012Validator

SCHEMA_HEADING = re.compile(
    rb"(?m)^###\s+18\.2\.\d+\s+`([^`\r\n]+\.schema\.json)`\r?\n\r?\n```json\r?\n"
)
CODE_FENCE_END = re.compile(rb"\r?\n```")

def sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()

def write_bytes(path: Path, payload: bytes) -> dict:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(payload)
    return {"path": path.as_posix(), "sha256": sha256_bytes(payload), "bytes": len(payload)}

def fenced_after(raw: bytes, heading: bytes, fence: bytes) -> bytes:
    start = raw.find(heading)
    if start < 0:
        raise SystemExit(f"ANCHOR_MISSING {heading.decode('utf-8','replace')}")
    start = raw.find(fence, start)
    if start < 0:
        raise SystemExit("FENCE_MISSING")
    payload_start = start + len(fence)
    m = CODE_FENCE_END.search(raw, payload_start)
    if not m:
        raise SystemExit("FENCE_UNCLOSED")
    return raw[payload_start:m.start()]

def section_bytes(raw: bytes, start_heading: bytes, end_heading: bytes) -> bytes:
    s = raw.find(start_heading)
    if s < 0:
        raise SystemExit(f"SECTION_START_MISSING {start_heading!r}")
    e = raw.find(end_heading, s + len(start_heading))
    if e < 0:
        raise SystemExit(f"SECTION_END_MISSING {end_heading!r}")
    return raw[s:e].rstrip() + b"\n"

def parse_md_row(line: str, expected_test_prefix: bool = False):
    cols = [c.strip() for c in line.strip().strip("|").split("|")]
    return cols

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--standard", type=Path, required=True)
    ap.add_argument("--expected-sha256", required=True)
    ap.add_argument("--out", type=Path, required=True)
    args = ap.parse_args()

    raw = args.standard.read_bytes()
    actual = sha256_bytes(raw)
    if actual.lower() != args.expected_sha256.lower():
        raise SystemExit(f"STANDARD_HASH_MISMATCH expected={args.expected_sha256} actual={actual}")
    raw.decode("utf-8", errors="strict")
    out = args.out
    artifacts = []

    artifacts.append(write_bytes(out/"standard"/"CANONICAL_STANDARD.md", raw))

    ids = set()
    schema_count = 0
    pos = 0
    while True:
        m = SCHEMA_HEADING.search(raw, pos)
        if not m:
            break
        name = m.group(1).decode("utf-8")
        payload_start = m.end()
        end = CODE_FENCE_END.search(raw, payload_start)
        if not end:
            raise SystemExit(f"SCHEMA_FENCE_UNCLOSED {name}")
        payload = raw[payload_start:end.start()]
        obj = json.loads(payload.decode("utf-8"))
        Draft202012Validator.check_schema(obj)
        sid = obj.get("$id")
        if not sid or sid in ids:
            raise SystemExit(f"DUPLICATE_OR_MISSING_SCHEMA_ID {name} {sid}")
        ids.add(sid)
        # Canonical contract says no network resolution dependency.
        def walk(x):
            if isinstance(x, dict):
                for k,v in x.items():
                    if k == "$ref" and isinstance(v,str) and not v.startswith("#"):
                        raise SystemExit(f"EXTERNAL_REF {name} {v}")
                    walk(v)
            elif isinstance(x, list):
                for v in x: walk(v)
        walk(obj)
        artifacts.append(write_bytes(out/"schemas"/name, payload))
        schema_count += 1
        pos = end.end()

    if schema_count != 22:
        raise SystemExit(f"SCHEMA_COUNT_MISMATCH expected=22 actual={schema_count}")

    validator = fenced_after(
        raw,
        b"### `pipd_validate.py` reference implementation",
        b"```python\n",
    )
    artifacts.append(write_bytes(out/"validators"/"pipd_validate.py", validator))

    agents = fenced_after(raw, b"## 30A.1 `AGENTS.md.template`", b"```markdown\n")
    skill = fenced_after(raw, b"## 30A.2 `SKILL.md.template`", b"```markdown\n")
    pi_tpl = fenced_after(raw, b"# 36. PI-PKG Markdown Template", b"```markdown\n")
    pd_tpl = fenced_after(raw, b"# 37. PD-PKG Markdown Template", b"```markdown\n")
    handoff = fenced_after(raw, b"# 38. Execution Handoff YAML Template", b"```yaml\n")
    artifacts += [
        write_bytes(out/"adapters"/"AGENTS.md.template", agents),
        write_bytes(out/"adapters"/"skill"/"SKILL.md.template", skill),
        write_bytes(out/"templates"/"PI-PKG.md.template", pi_tpl),
        write_bytes(out/"templates"/"PD-PKG.md.template", pd_tpl),
        write_bytes(out/"templates"/"execution-handoff.yaml.template", handoff),
    ]

    artifacts += [
        write_bytes(out/"profiles"/"SYSTEM.md",
                    section_bytes(raw,b"# 21. Target Profile \xe2\x80\x94 General Software / System",
                                  b"# 22. Target Profile \xe2\x80\x94 SKILL / PLUGIN")),
        write_bytes(out/"profiles"/"SKILL_PLUGIN.md",
                    section_bytes(raw,b"# 22. Target Profile \xe2\x80\x94 SKILL / PLUGIN",
                                  b"# 23. Target Profile \xe2\x80\x94 Agent Harness / Agentic Runtime")),
        write_bytes(out/"profiles"/"AGENT_HARNESS.md",
                    section_bytes(raw,b"# 23. Target Profile \xe2\x80\x94 Agent Harness / Agentic Runtime",
                                  b"# 23A. World Effect / Observation / Readback / Reconciliation")),
    ]

    text = raw.decode("utf-8")
    lines = text.splitlines()

    tests = []
    for line in lines:
        if line.startswith("|") and "TEST-" in line and "OR-" in line:
            cols = parse_md_row(line)
            if len(cols) >= 5 and cols[1].startswith("TEST-") and cols[2].startswith("OR-"):
                if cols[0] in {"Trigger","Non-trigger","Compliance","Boundary","Retrieval","Mutation","Portability"}:
                    tests.append({
                        "category": cols[0], "test_id": cols[1], "oracle_id": cols[2],
                        "fixture": cols[3], "pass_condition": cols[4]
                    })
    if len(tests) != 20:
        raise SystemExit(f"CANONICAL_TEST_REGISTRY_COUNT expected=20 actual={len(tests)}")
    test_bytes=(json.dumps({"standard_version":"1.1.0","count":len(tests),"tests":tests},
                           ensure_ascii=False,indent=2)+"\n").encode()
    artifacts.append(write_bytes(out/"registry"/"canonical-test-registry.json", test_bytes))

    ledger = []
    pat = re.compile(
        r'^\|\s*`(STD-REQ-[^`]+)`\s*\|\s*(.*?)\s*\|\s*(.*?)\s*\|\s*'
        r'`(TEST-[^`]+)`\s*\|\s*`(OR-[^`]+)`\s*\|\s*(.*?)\s*\|$'
    )
    for line in lines:
        if line.startswith("| `STD-REQ-"):
            m = pat.match(line)
            if not m:
                raise SystemExit(f"LEDGER_PARSE_ERROR {line[:120]}")
            ledger.append({
                "requirement_id":m.group(1),"section":m.group(2),"requirement":m.group(3),
                "test_id":m.group(4),"oracle_id":m.group(5),"applicability":m.group(6)
            })
    if len(ledger) != 86 or len({r["requirement_id"] for r in ledger}) != 86:
        raise SystemExit(f"NORMATIVE_LEDGER_COUNT expected=86 actual={len(ledger)}")
    ledger_bytes=(json.dumps({"standard_version":"1.1.0","count":86,"requirements":ledger},
                             ensure_ascii=False,indent=2)+"\n").encode()
    artifacts.append(write_bytes(out/"registry"/"normative-requirements.json", ledger_bytes))

    generic_prompt = """# Generic PIPD LLM Adapter
Read the project Lifecycle Constitution and manifest first. Discover repository instructions read-only before any repository action. Preserve PI/PD/Execution claim separation. Compile or validate PI before PD; bind RepoContext/currentness before PREDEV_READY. S2E and TaskSpecSeed are non-executable. WorkOrder and ECP do not self-authorize. Only a separate EXECUTION_ADMITTED decision authorizes first mutation. Tool/provider success is not world-effect truth; require observation/readback/reconciliation. On missing source, stale subject, wrong permission, missing approval, or unresolved required late-bound fact: fail closed and open a scoped TT. Adapters never override Product Truth, canonical package ownership, claim ceilings, or release authority.
"""
    artifacts.append(write_bytes(out/"adapters"/"GENERIC_LLM_PROMPT.md", generic_prompt.encode("utf-8")))

    manifest = {
        "distribution_id":"PIPD-LIFECYCLE-SPEC-DIST",
        "standard_version":"1.1.0",
        "standard_sha256":actual,
        "schema_count":schema_count,
        "canonical_test_count":len(tests),
        "normative_requirement_count":len(ledger),
        "artifacts":artifacts,
    }
    mb=(json.dumps(manifest,ensure_ascii=False,indent=2)+"\n").encode()
    write_bytes(out/"distribution-manifest.json",mb)
    print(json.dumps({
        "result":"PASS","standard_sha256":actual,"schemas":schema_count,
        "canonical_tests":len(tests),"normative_requirements":len(ledger),
        "artifacts":len(artifacts)+1
    },ensure_ascii=False))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
```

**Author-side syntax check:** PASS.  
**Canonical denominator enforcement retained:** `22/22 schemas`, `20/20 canonical TEST/ORACLE entries`, `86/86 normative requirements`, duplicate/missing identity rejection, manifest hashing and reopen verification.

## 11.2 `.pipd/tools/pipd_tree_validate.py`

```python
#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json, subprocess, sys
from datetime import datetime, timezone, timedelta
from pathlib import Path
from jsonschema import Draft202012Validator

EXIT={"PASS":0,"SCHEMA":2,"SEMANTIC":3,"CURRENTNESS":4,"PERMISSION":5,"RESOLUTION":6,"INTERNAL":7}
KIND_TEST={
    "pi":("TEST-CMP-001","OR-CMP-001"),
    "pd":("TEST-CMP-002","OR-CMP-002"),
    "evidence":("TEST-22E53BD2","OR-22E53BD2"),
    "admission":("TEST-FA8009D5","OR-FA8009D5"),
    "effect":("TEST-2E59E411","OR-2E59E411"),
}

def sha256_path(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()

def load(p: Path):
    return json.loads(p.read_text(encoding="utf-8"))

def validate_json(instance, schema_path: Path):
    schema=load(schema_path)
    Draft202012Validator.check_schema(schema)
    errors=sorted(Draft202012Validator(schema, format_checker=None).iter_errors(instance), key=lambda e:list(e.path))
    if errors:
        e=errors[0]
        raise ValueError(f"{schema_path.name}:{list(e.path)}:{e.message}")

def rel(root: Path, ref: str) -> Path:
    p=(root/ref).resolve()
    rr=root.resolve()
    if rr not in p.parents and p != rr:
        raise ValueError(f"PATH_ESCAPE {ref}")
    return p

def report_payload(manifest, result, exit_code, invariant, tests):
    return {
        "report_id":"PIPD-TREE-CONFORMANCE",
        "standard_version":"1.1.0",
        "subject_ref":manifest["subject_ref"],
        "profile":f'{manifest["weight_profile"]}/{manifest["target_profile"]}',
        "result":result,
        "exit_code":exit_code,
        "first_failing_invariant":invariant,
        "test_results":tests or [{
            "test_id":"TEST-97BCACAC","oracle_id":"OR-97BCACAC",
            "result":"FAIL","detail":"no test results produced"
        }],
        "generated_at":datetime.now(timezone.utc).isoformat().replace("+00:00","Z"),
    }

def finish(root, manifest, report_path, payload, code):
    schema=root/".pipd/generated/schemas/conformance-report.schema.json"
    validate_json(payload,schema)
    report_path.parent.mkdir(parents=True,exist_ok=True)
    report_path.write_text(json.dumps(payload,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    print(json.dumps(payload,ensure_ascii=False))
    return code

def main() -> int:
    ap=argparse.ArgumentParser()
    ap.add_argument("command",choices=["validate-tree"])
    ap.add_argument("--root",type=Path,required=True)
    ap.add_argument("--manifest",type=Path,required=True)
    ap.add_argument("--report",type=Path,required=True)
    args=ap.parse_args()
    root=args.root.resolve()
    tests=[]
    try:
        manifest=load(args.manifest)
        ext=root/".pipd/generated/blueprint-schemas"
        validate_json(manifest,ext/"project-manifest.schema.json")
        tests.append({"test_id":"TEST-28163C14","oracle_id":"OR-28163C14","result":"PASS","detail":"project manifest/profile binding schema valid"})

        lock_path=root/".pipd/lock/standard.lock.json"
        lock=load(lock_path)
        validate_json(lock,ext/"standard-lock.schema.json")
        standard=rel(root,lock["source_path"])
        actual=sha256_path(standard)
        if actual != lock["sha256"]:
            payload=report_payload(manifest,"FAIL",EXIT["CURRENTNESS"],"STANDARD_HASH_MISMATCH",tests+[{
                "test_id":"TEST-B1C9AB85","oracle_id":"OR-B1C9AB85","result":"FAIL","detail":f"expected={lock['sha256']} actual={actual}"
            }])
            return finish(root,manifest,args.report,payload,EXIT["CURRENTNESS"])
        tests.append({"test_id":"TEST-B1C9AB85","oracle_id":"OR-B1C9AB85","result":"PASS","detail":"single locked canonical standard hash verified"})

        # Machine-driving extension controls are schema-bound and consumed here.
        controls=[
            ("permissions_ref","permission-policy.schema.json","TEST-2A89F996","OR-2A89F996"),
            ("change_ref","change-policy.schema.json","TEST-90364E5B","OR-90364E5B"),
            ("degrade_ref","degrade-policy.schema.json","TEST-EEC45EC3","OR-EEC45EC3"),
        ]
        for field,schema_name,test_id,oracle_id in controls:
            obj=load(rel(root,manifest["controls"][field]))
            validate_json(obj,ext/schema_name)
            tests.append({"test_id":test_id,"oracle_id":oracle_id,"result":"PASS","detail":f"{field} schema-bound and consumed"})

        package_index=load(rel(root,manifest["package_index_ref"]))
        validate_json(package_index,ext/"package-index.schema.json")
        tests.append({"test_id":"TEST-4AAA061A","oracle_id":"OR-4AAA061A","result":"PASS","detail":"package split/merge rationale schema-bound and consumed"})

        currentness=load(rel(root,manifest["currentness_ref"]))
        validate_json(currentness,ext/"currentness-record.schema.json")
        now=datetime.now(timezone.utc)
        for row in currentness["records"]:
            if not row["selected"]:
                continue
            checked=datetime.fromisoformat(row["checked_at"].replace("Z","+00:00"))
            expiry=checked+timedelta(hours=row["ttl_hours"])
            if expiry <= now:
                payload=report_payload(manifest,"FAIL",EXIT["CURRENTNESS"],"CURRENTNESS_TTL_EXPIRED",tests+[{
                    "test_id":"TEST-6F8DCD42","oracle_id":"OR-6F8DCD42","result":"FAIL","detail":row["candidate_id"]
                }])
                return finish(root,manifest,args.report,payload,EXIT["CURRENTNESS"])
            if any(row[k]!="PASS" for k in ("security_status","license_status","compatibility_status")):
                payload=report_payload(manifest,"FAIL",EXIT["CURRENTNESS"],"CURRENTNESS_ADMISSION_NOT_PASS",tests+[{
                    "test_id":"TEST-6F8DCD42","oracle_id":"OR-6F8DCD42","result":"FAIL","detail":row["candidate_id"]
                }])
                return finish(root,manifest,args.report,payload,EXIT["CURRENTNESS"])
        tests.append({"test_id":"TEST-6F8DCD42","oracle_id":"OR-6F8DCD42","result":"PASS","detail":"all selected technology currentness records fresh and admitted"})

        # 86/86 canonical ledger identity preservation.
        canonical_registry=load(root/".pipd/generated/registry/normative-requirements.json")
        project_req=load(rel(root,manifest["requirement_conformance_ref"]))
        validate_json(project_req,ext/"requirement-conformance.schema.json")
        expected={r["requirement_id"]:(r["test_id"],r["oracle_id"]) for r in canonical_registry["requirements"]}
        actual_rows={r["requirement_id"]:r for r in project_req["rows"]}
        if set(expected) != set(actual_rows):
            missing=sorted(set(expected)-set(actual_rows))
            extra=sorted(set(actual_rows)-set(expected))
            payload=report_payload(manifest,"FAIL",EXIT["SEMANTIC"],"CANONICAL_REQUIREMENT_LEDGER_IDENTITY",tests+[{
                "test_id":"TEST-97BCACAC","oracle_id":"OR-97BCACAC","result":"FAIL",
                "detail":f"missing={missing} extra={extra}"
            }])
            return finish(root,manifest,args.report,payload,EXIT["SEMANTIC"])
        for rid,(tid,oid) in expected.items():
            row=actual_rows[rid]
            if row["test_id"]!=tid or row["oracle_id"]!=oid:
                payload=report_payload(manifest,"FAIL",EXIT["SEMANTIC"],"CANONICAL_TEST_ORACLE_IDENTITY",tests+[{
                    "test_id":"TEST-97BCACAC","oracle_id":"OR-97BCACAC","result":"FAIL","detail":rid
                }])
                return finish(root,manifest,args.report,payload,EXIT["SEMANTIC"])
            tests.append({
                "test_id":tid,"oracle_id":oid,"result":row["result"],
                "detail":row["rationale"] or rid,
                "requirement_id":rid,
                "applicability":row["applicability"],
                "evidence_ref":row["evidence_refs"],
            })

        # Canonical instance validator: supported ABI only.
        validator=root/".pipd/generated/validators/pipd_validate.py"
        if not validator.is_file():
            payload=report_payload(manifest,"FAIL",EXIT["RESOLUTION"],"CANONICAL_VALIDATOR_MISSING",tests)
            return finish(root,manifest,args.report,payload,EXIT["RESOLUTION"])
        schema_dir=root/".pipd/generated/schemas"

        for obj in manifest["objects"]:
            p=rel(root,obj["path"])
            if not p.is_file():
                payload=report_payload(manifest,"FAIL",EXIT["RESOLUTION"],"OBJECT_MISSING",tests)
                return finish(root,manifest,args.report,payload,EXIT["RESOLUTION"])
            actual_hash=sha256_path(p)
            if actual_hash != obj["sha256"]:
                payload=report_payload(manifest,"FAIL",EXIT["CURRENTNESS"],"OBJECT_HASH_STALE",tests)
                return finish(root,manifest,args.report,payload,EXIT["CURRENTNESS"])

            cmd=[sys.executable,str(validator),str(p),"--kind",obj["kind"],"--schema-dir",str(schema_dir)]
            proc=subprocess.run(cmd,capture_output=True,text=True)
            tid,oid=KIND_TEST[obj["kind"]]
            try:
                native=json.loads((proc.stdout.strip().splitlines() or ["{}"])[-1])
            except json.JSONDecodeError:
                native={"result":"FAIL","first_failing_invariant":"VALIDATOR_OUTPUT_NOT_JSON","detail":proc.stdout+proc.stderr}
            tr={
                "test_id":tid,"oracle_id":oid,
                "result":"PASS" if proc.returncode==0 else "FAIL",
                "detail":f'{obj["path"]}: {native.get("first_failing_invariant") or "PASS"}'
            }
            tests.append(tr)
            if proc.returncode != 0:
                code=proc.returncode if proc.returncode in EXIT.values() else EXIT["INTERNAL"]
                payload=report_payload(manifest,"FAIL",code,native.get("first_failing_invariant") or "CANONICAL_VALIDATOR_FAILURE",tests)
                return finish(root,manifest,args.report,payload,code)

        # Supplemental identity-preservation readback.
        tests.append({"test_id":"TEST-97BCACAC","oracle_id":"OR-97BCACAC","result":"PASS","detail":"86/86 normative requirement identities and stable test/oracle bindings preserved"})
        payload=report_payload(manifest,"PASS",0,None,tests)
        return finish(root,manifest,args.report,payload,0)
    except (FileNotFoundError, json.JSONDecodeError, ValueError) as e:
        # If manifest is unreadable, construct a minimal synthetic subject only for fail-closed report.
        try:
            manifest
        except UnboundLocalError:
            manifest={"subject_ref":{"id":"UNKNOWN","version":"UNKNOWN","hash":"0"*64},"weight_profile":"UNKNOWN","target_profile":"UNKNOWN"}
        payload=report_payload(manifest,"FAIL",EXIT["RESOLUTION"],"TREE_RESOLUTION_FAILURE",tests+[{
            "test_id":"TEST-59414E50","oracle_id":"OR-59414E50","result":"FAIL","detail":str(e)
        }])
        # report schema may itself be unavailable; do not pretend success.
        try:
            return finish(root,manifest,args.report,payload,EXIT["RESOLUTION"])
        except Exception:
            print(json.dumps(payload,ensure_ascii=False))
            return EXIT["RESOLUTION"]

if __name__=="__main__":
    raise SystemExit(main())
```

**Author-side syntax check:** PASS.  
It retains project-manifest/lock/control/currentness/package-index validation, canonical standard hash, `86/86` requirement identity equality, TEST/ORACLE identity, object hash checks, canonical validator dispatch, first-failing invariant and conformance report validation.

## 11.3 `.pipd/tools/pipd_drift.py`

```python
#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json, subprocess
from datetime import datetime, timezone, timedelta
from pathlib import Path

def sha256_path(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()

def load(p: Path):
    return json.loads(p.read_text(encoding="utf-8"))

def canonical_json_hash(obj: dict, omit: str | None = None) -> str:
    x=dict(obj)
    if omit: x.pop(omit,None)
    raw=json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(",",":")).encode()
    return hashlib.sha256(raw).hexdigest()

def git(cwd: Path, *args: str) -> str:
    p=subprocess.run(["git",*args],cwd=cwd,capture_output=True,text=True)
    if p.returncode:
        raise RuntimeError(p.stderr.strip() or "git failed")
    return p.stdout.strip()

def main() -> int:
    ap=argparse.ArgumentParser()
    ap.add_argument("--root",type=Path,required=True)
    ap.add_argument("--manifest",type=Path,required=True)
    args=ap.parse_args()
    root=args.root.resolve()
    manifest=load(args.manifest)
    findings=[]

    lock=load(root/".pipd/lock/standard.lock.json")
    standard=(root/lock["source_path"]).resolve()
    if not standard.exists() or sha256_path(standard)!=lock["sha256"]:
        findings.append({"class":"STANDARD_DRIFT","ref":str(standard)})

    object_docs={}
    for row in manifest["objects"]:
        p=(root/row["path"]).resolve()
        if not p.exists():
            findings.append({"class":"SUBJECT_MISSING","ref":row["path"]})
            continue
        if sha256_path(p)!=row["sha256"]:
            findings.append({"class":"SUBJECT_HASH_DRIFT","ref":row["path"]})
        try:
            object_docs[row["path"]]=load(p)
        except Exception:
            findings.append({"class":"OBJECT_PARSE_FAILURE","ref":row["path"]})

    # PI→PD subject/version/hash binding.
    pi_by_id={}
    for path,obj in object_docs.items():
        if obj.get("artifact_type")=="PRE_IMPLEMENTATION_PACKAGE":
            pi_by_id[obj.get("artifact_id")]=obj
    for path,obj in object_docs.items():
        if obj.get("artifact_type")!="PRE_DEV_PACKAGE":
            continue
        ref=obj.get("pi_ref",{})
        pi=pi_by_id.get(ref.get("id"))
        if pi and (ref.get("version")!=pi.get("version") or ref.get("hash")!=pi.get("content_hash")):
            findings.append({"class":"PI_PD_BINDING_DRIFT","ref":path})
        rc=obj.get("repo_context",{})
        repo_path=(root/rc.get("repo_root",".")).resolve()
        try:
            actual_head=git(repo_path,"rev-parse","HEAD")
            actual_branch=git(repo_path,"rev-parse","--abbrev-ref","HEAD")
            if actual_head!=rc.get("head"):
                findings.append({"class":"REPO_HEAD_DRIFT","ref":path,"expected":rc.get("head"),"actual":actual_head})
            if actual_branch!=rc.get("branch_or_ref"):
                findings.append({"class":"REPO_REF_DRIFT","ref":path,"expected":rc.get("branch_or_ref"),"actual":actual_branch})
        except Exception as e:
            findings.append({"class":"REPO_READBACK_FAILURE","ref":path,"detail":str(e)})
        expected_rc_hash=canonical_json_hash(rc,"content_hash")
        if rc.get("content_hash")!=expected_rc_hash:
            findings.append({"class":"REPO_CONTEXT_CONTENT_HASH_DRIFT","ref":path})
        locks=manifest.get("instruction_locks",{})
        for surf in rc.get("instruction_surfaces",[]):
            sp=(repo_path/surf).resolve()
            if not sp.exists():
                findings.append({"class":"INSTRUCTION_SURFACE_MISSING","ref":surf})
                continue
            expected=locks.get(surf)
            if not expected:
                findings.append({"class":"INSTRUCTION_SURFACE_UNLOCKED","ref":surf})
            elif sha256_path(sp)!=expected:
                findings.append({"class":"INSTRUCTION_SURFACE_DRIFT","ref":surf})

    # Selected technology currentness/security/license/compatibility.
    cur=load(root/manifest["currentness_ref"])
    now=datetime.now(timezone.utc)
    for row in cur["records"]:
        if not row["selected"]: continue
        checked=datetime.fromisoformat(row["checked_at"].replace("Z","+00:00"))
        if checked+timedelta(hours=row["ttl_hours"]) <= now:
            findings.append({"class":"CURRENTNESS_TTL_EXPIRED","ref":row["candidate_id"]})
        for k in ("security_status","license_status","compatibility_status"):
            if row[k]!="PASS":
                findings.append({"class":f'{k.upper()}_NOT_PASS',"ref":row["candidate_id"]})

    # PASS evidence must bind a known current subject hash.
    current_subject_hashes=set()
    for obj in object_docs.values():
        for key in ("content_hash","subject_hash"):
            if isinstance(obj.get(key),str):
                current_subject_hashes.add(obj[key])
    for path,obj in object_docs.items():
        if obj.get("evidence_id") and obj.get("result")=="PASS":
            if obj.get("subject_hash") not in current_subject_hashes:
                findings.append({"class":"EVIDENCE_FOREIGN_OR_STALE_SUBJECT","ref":path})

    result={"result":"PASS" if not findings else "FAIL","finding_count":len(findings),"findings":findings}
    print(json.dumps(result,ensure_ascii=False,indent=2))
    return 0 if not findings else 4

if __name__=="__main__":
    raise SystemExit(main())
```

**Author-side syntax check:** PASS.  
Drift tooling emits affected-only invalidation and MUST NOT rewrite semantic truth or globally invalidate unrelated objects.

## 11.4 ExecutableToolContract

|tool_id|path|version/source|dependencies|CLI|exit model|test fixture|expected output|uninstall/rebuild|
|---|---|---|---|---|---|---|---|---|
|PIPD-DIST|`.pipd/tools/pipd_dist.py`|P1 r2 blueprint embedded source|Python + `jsonschema` through ValidatorEnvironmentBinding|`--standard --expected-sha256 --out`|non-zero fail closed|FIX-D09-001|exact-set manifest/counts|delete generated projection and deterministically rebuild|
|PIPD-TREE|`.pipd/tools/pipd_tree_validate.py`|P1 r2 blueprint embedded source|Python + `jsonschema`; canonical validator asset|`validate-tree --root --manifest --report`|0/2/3/4/5/6/7|FIX-D09-005/007/008/009/017|conformance-report JSON|replace source only with affected requalification|
|PIPD-DRIFT|`.pipd/tools/pipd_drift.py`|P1 r2 blueprint embedded source|Python stdlib + project manifest|tool-defined CLI retained above|non-zero fail closed|FIX-D09-021|affected-only drift graph/report|replace only with parity/affected-only test|



<a id="doc09-validator-env"></a>
# 12｜Validator Runtime / Dependency Binding

The validator environment is a first-class binding. Generic DOC-09 MUST NOT guess a target project package hash.

Target PD MUST choose exactly one:

1. **hash-locked Python environment** using `pip --require-hashes`; or
2. **vendored / attested validator environment or container digest**.

Until one is current, `ValidatorEnvironmentBinding.status = HOLD` and the required CI gate cannot claim supply-chain closure.

Reference lock template:

```text
# .pipd/project/toolchain/pipd-validator.requirements.lock.example
# TEMPLATE ONLY. The target project MUST resolve exact versions and hashes in PD.
# Generate from an admitted environment; do not copy placeholder hashes into an active lock.
jsonschema==<TARGET_BOUND_VERSION> \
    --hash=sha256:<TARGET_BOUND_WHEEL_HASH>
referencing==<TARGET_BOUND_VERSION> \
    --hash=sha256:<TARGET_BOUND_WHEEL_HASH>
rpds-py==<TARGET_BOUND_VERSION> \
    --hash=sha256:<TARGET_BOUND_WHEEL_HASH>
attrs==<TARGET_BOUND_VERSION> \
    --hash=sha256:<TARGET_BOUND_WHEEL_HASH>

```

The `<TARGET_BOUND_*>` markers are intentionally a **template artifact**, not unresolved authoring placeholders in the normative body; activation is blocked until the target PD materializes a separate real lock file with no placeholders.



<a id="doc09-enforcement"></a>
# 13｜Repository Enforcement / Release Artifact Store Bindings

## 13.1 Required check / ruleset binding

```yaml
RepositoryEnforcementBinding:
  required_check_name: "PIPD / pre-execution-gate"
  provider: "GitHub | GitLab | Jenkins | Buildkite | other admitted adapter"
  enforcement_object: "ruleset | branch protection | provider-equivalent"
  exact_target_scope: "LATE_BOUND_REQUIRED"
  merge_queue_enabled: "LATE_BOUND_REQUIRED"
  merge_group_required_when_enabled: true
  readback_command: "provider-specific exact command"
  readback_artifact: ".pipd/conformance/reports/repository-enforcement.json"
  unavailable_route: "CR-011 / TEMP_CLOSED for merge enforcement"
  codeowners_or_reviewer_binding: "CR-012 where required by profile/policy"

```

Reference GitHub readback:

```bash
gh api "repos/$GITHUB_REPOSITORY/rulesets"   > .pipd/conformance/reports/rulesets.json
```

If rulesets are unavailable or organization policy uses branch protection/provider-equivalent enforcement, the binding must identify that enforcement object and produce equivalent readback. Absence is `CR-011` and blocks only merge-enforcement claims.

## 13.2 Release artifact store / registry binding

```yaml
ReleaseArtifactStoreBinding:
  binding_id: "RAB-<project>-<version>"
  provider: "LATE_BOUND_REQUIRED"
  store_or_registry: "LATE_BOUND_REQUIRED"
  project_subject_ref: "required"
  immutable_or_content_addressed: true
  auth_method: "secret handle / OIDC / provider identity; no raw secret in PI"
  retention_policy: "LATE_BOUND_REQUIRED"
  upload_command: "LATE_BOUND_REQUIRED"
  download_command: "LATE_BOUND_REQUIRED"
  digest_algorithm: "sha256"
  digest_equality_required: true
  provider_off:
    replacement_binding_ref: "required before disable"
    residue_check: "required"
  close_criteria:
    - "fresh upload/download digest equality fixture PASS"
    - "auth scope least privilege"
    - "retention/immutability documented"
    - "rollback/provider-off tested"

```

DOC-09 does not universally select a vendor. It does require the slot to be typed, testable, immutable/content-addressed, and provider-off capable before the release lane can close.


<a id="doc09-waves"></a>
# 14｜Adoption Waves A–J
|Wave|Responsibility|Entry|Procedure|Outputs|Owner|Receiver|Exit predicate|Blocking|Evidence|Rollback|Next|
|---|---|---|---|---|---|---|---|---|---|---|---|
|A|Portable distribution materialization / verification|P1/P2/P3 hashes available|run `pipd_dist.py`; verify distribution manifest|distribution + hashes|DOC-09 tooling owner|project control plane|exact manifest readback|hash/schema mismatch|distribution receipt|delete failed materialization; restore prior verified distribution|B|
|B|Standard lock / manifest / policies|Wave A PASS|materialize standard.lock, project manifest, policy refs|lock + manifest|project owner|Constitution compiler|lock/manifest validate|stale/ambiguous source|control receipt|restore prior lock or TEMP_CLOSED|C|
|C|Constitution / profile|project intent + manifest|bind DOC-01 Constitution and DOC-06 profile|CONSTITUTION_READY refs|DOC-01 owner|PI compiler|authority/profile valid|ambiguous authority/profile|constitution receipt|revert invalid projection|D|
|D|First vertical-slice PI|Constitution ready + slice scope|compile applicable PI contract|slice PI_READY|DOC-02/PI owner|PD binder|all applicable requirements terminal|orphan/ambiguous requirement|PI gate evidence|reopen affected PI only|E|
|E|RepoContext / PD binding|PI_READY + real repo/environment|capture RepoContext; bind ECP/TQAEP/provider facts read-only|slice PREDEV_READY|DOC-03/PD owner|CI/admission|binding/currentness closed|stale repo/tool facts|PD binding receipt|recapture/rebind affected slice|F|
|F|Provider-neutral CI / required check|PREDEV_READY + selected CI provider|bind provider adapter to neutral ABI; enforce required check|required CI terminal semantics active|DOC-09 CI owner|handoff/admission|canonical report produced for relevant change|skip/missing/wrong subject|CI receipt|provider-off or disable invalid adapter|G|
|G|Handoff / ExecutionAdmission|PI+PD+TQAEP readiness + CI preflight|assemble handoff; request DOC-05 admission|EXECUTION_ADMITTED iff authority ADMIT|DOC-05 authority|executor|subject-bound ADMIT|missing/invalid approval|admission receipt|DENY/TEMP_CLOSED|H|
|H|Admitted implementation|EXECUTION_ADMITTED|execute bounded WorkOrder/ECP|implementation evidence|executor|DOC-04/DOC-07|within scope; evidence returned|scope/permission violation|execution evidence|rollback bounded changes|I|
|I|TQAEP / effect reconciliation|implementation evidence + fixtures|run verification/qualification; reconcile effects|VERIFIED/QUALIFIED inputs|DOC-07/TQAEP owner|release lane|oracles and evidence satisfied|failed/stale evidence|qualification/effect receipts|rework/rollback affected scope|J|
|J|Build / SBOM / provenance / attest / verify / release gate|qualified subject + release authority path|execute release lane and assemble ReleaseGateInput|release decision input; RELEASED only on authority approval|DOC-09 release owner + Release Authority|operators/consumers|digest continuity + verified attestation + authority decision|mismatch/unverified/missing authority|release receipts|revoke/rollback/invalidated path|change/drift router|

**Overlap rule:** an execution slice that has dependency closure, `PI_READY`, `PREDEV_READY`, TQAEP readiness and exact `ExecutionAdmission=ADMIT` may enter Wave H while other independent slices remain in D/E. A global wait-for-all waterfall is non-conformant unless the dependency/security/rollback graph proves global coupling.


<a id="doc09-runbook"></a>
# 15｜Operational Runbook — Exact Commands + Claim Ceilings

Each step has an explicit claim ceiling so an operator cannot turn an intermediate technical success into a higher lifecycle claim.

|step|trigger|bounded action|reference command|claim ceiling|failure route|
|---|---|---|---|---|---|
|RB-01|bootstrap/standard pin|verify standard.lock hash|`python .pipd/tools/pipd_dist.py --standard .pipd/vendor/PIPD-LIFECYCLE-SPEC-1.1.0.md --expected-sha256 "$(python -c 'import json;print(json.load(open(".pipd/lock/standard.lock.json"))["sha256"])')" --out .pipd/generated`|LOCAL_PREEXECUTION_VALIDATION_ONLY|fail closed; scoped TT/CR|
|RB-02|tree validation|validate exact project subject|`python .pipd/tools/pipd_tree_validate.py validate-tree --root . --manifest .pipd/project/manifest.json --report .pipd/conformance/reports/pipd-report.json`|CONFORMANCE_INPUT_ONLY|fail closed; scoped TT/CR|
|RB-03|drift|compute affected-only invalidation|`python .pipd/tools/pipd_drift.py --root . --manifest .pipd/project/manifest.json --out .pipd/conformance/reports/drift.json`|INVALIDATION_DECISION_INPUT_ONLY|fail closed; scoped TT/CR|
|RB-04|required check|confirm exact required status context|`gh api repos/$REPO/rulesets > .pipd/conformance/reports/rulesets.json`|READBACK_ONLY|fail closed; scoped TT/CR|
|RB-05|merge queue|confirm merge_group trigger when queue enabled|`grep -n 'merge_group' .github/workflows/pipd-required.yml`|READBACK_ONLY|fail closed; scoped TT/CR|
|RB-06|validator env|install hash-locked validator dependencies|`python -m pip install --disable-pip-version-check --require-hashes -r .pipd/project/toolchain/pipd-validator.requirements.lock`|LOCAL_ENV_MATERIALIZATION_ONLY|fail closed; scoped TT/CR|
|RB-07|CI evidence|download/read conformance artifact|`test -s .pipd/conformance/reports/pipd-report.json`|EVIDENCE_PRESENT_NOT_ACCEPTED|fail closed; scoped TT/CR|
|RB-08|build|execute admitted project release build script|`test -x .pipd/project/release/build.sh && .pipd/project/release/build.sh`|BUILD_SUCCESS_ONLY|fail closed; scoped TT/CR|
|RB-09|digest|compute artifact digest|`sha256sum "$(python -c 'import json;print(json.load(open(".pipd/project/release/output.json"))["artifact_path"])')"`|ARTIFACT_IDENTITY_ONLY|fail closed; scoped TT/CR|
|RB-10|transfer|recompute digest after fresh transfer|`sha256sum release-input/.pipd-release-subject`|TRANSFER_INTEGRITY_ONLY|fail closed; scoped TT/CR|
|RB-11|SBOM|run target-bound Syft profile|`test -x .pipd/project/toolchain/bin/syft && .pipd/project/toolchain/bin/syft release-input/.pipd-release-subject -o cyclonedx-json=.pipd/release/sbom.cdx.json`|SBOM_EVIDENCE_ONLY|fail closed; scoped TT/CR|
|RB-12|attest|create GitHub attestation in authorized job|`actions/attest reference workflow step`|ATTESTATION_CREATED_ONLY|fail closed; scoped TT/CR|
|RB-13|verify|verify exact release subject attestation|`gh attestation verify release-input/.pipd-release-subject -R "$GITHUB_REPOSITORY"`|ATTESTATION_VERIFIED_ONLY|fail closed; scoped TT/CR|
|RB-14|release packet|assemble ReleaseGateInput|`python .pipd/project/release/assemble_release_gate.py --subject .pipd-release-subject --out .pipd/release/release-gate-input.json`|RELEASE_DECISION_INPUT_ONLY|fail closed; scoped TT/CR|
|RB-15|release authority|obtain explicit release decision|`NO_AUTOMATIC_COMMAND; separate authorized decision receipt required`|NO_RELEASE_CLAIM_UNTIL_AUTHORITY|fail closed; scoped TT/CR|
|RB-16|rollback|invoke admitted rollback contract|`test -x .pipd/project/release/rollback.sh && .pipd/project/release/rollback.sh`|ROLLBACK_ATTEMPT_ONLY|fail closed; scoped TT/CR|
|RB-17|provider-off|remove provider binding after replacement check path is current|`python .pipd/tools/pipd_tree_validate.py validate-tree --root . --manifest .pipd/project/manifest.json --report .pipd/conformance/reports/provider-off-precheck.json`|NO_PROVIDER_OFF_UNTIL_REPLACEMENT_PASS|fail closed; scoped TT/CR|
|RB-18|residue/readback|verify no stale required contexts/credentials/provider dependencies|`python .pipd/project/release/residue_check.py --out .pipd/conformance/reports/residue.json`|RESIDUE_EVIDENCE_ONLY|fail closed; scoped TT/CR|

### Overlap rule
A slice may advance when its own dependency closure, PI contract, PD bindings, required checks, permissions and evidence obligations are closed. No global waterfall is required; unrelated packages remain unaffected by a slice-local HOLD.



<a id="doc09-donors"></a>
# 16｜Named Donor Identity Crosswalk — Zero Silent Drop

|upstream id|name|capability / slot|DOC-09 disposition|canonical home|imported boundary|excluded semantics|anti-degradation|
|---|---|---|---|---|---|---|---|
|`NOBJ-016`|Agent Skills specification|SLOT-AGENT-SKILLS-SPEC|REFERENCE|DOC-09 CI Adapter|identity/capability contract reference|no lifecycle/product/release authority|NO_SILENT_DROP / replacement requires crosswalk rationale|
|`NOBJ-020`|GitHub Actions|SLOT-CI|REFERENCE_BASELINE|DOC-09 CI Adapter|CI transport/reference adapter|provider status cannot redefine PIPD truth|NO_SILENT_DROP / replacement requires crosswalk rationale|
|`NOBJ-021`|CycloneDX|SLOT-SBOM|REFERENCE_BASELINE|DOC-09 Release/Supply-Chain|SBOM interchange profile|SBOM presence is not acceptance|NO_SILENT_DROP / replacement requires crosswalk rationale|
|`ECP-01`|Spec Kit|S2E L2 specification adapter|EVAL_ONLY|DOC-09 CI Adapter|method/spec-provider integration pattern|no authority inheritance|NO_SILENT_DROP / replacement requires crosswalk rationale|
|`ECP-03`|Matt Skills / mattpocock-skills|requirement challenge/slicing discipline|EVAL_ONLY|DOC-09 CI Adapter|workflow donor identity|no authority inheritance|NO_SILENT_DROP / replacement requires crosswalk rationale|
|`ECP-04`|Superpowers|TDD/debug/verification discipline|EVAL_ONLY|DOC-09 CI Adapter|workflow donor identity|no authority inheritance|NO_SILENT_DROP / replacement requires crosswalk rationale|
|`ECP-24`|Trivy|security scanner|REFERENCE / QUALIFY_BEFORE_USE|DOC-09 Release/Supply-Chain|security evidence signal|scanner PASS not release acceptance|NO_SILENT_DROP / replacement requires crosswalk rationale|
|`ECP-25`|GitHub Agentic Workflows Safe Outputs|bounded mutation pattern|TRANSLATE|DOC-09 CI Adapter|safe-output/side-effect pattern|donor cannot grant execution|NO_SILENT_DROP / replacement requires crosswalk rationale|
|`ECP-26`|GitHub Actions|CI/CD executor|ADOPT_REFERENCE_ADAPTER|DOC-09 CI Adapter|deterministic CI transport|no lifecycle authority|NO_SILENT_DROP / replacement requires crosswalk rationale|
|`ECP-28`|SLSA v1.2|provenance standard|REFERENCE / TRANSLATE|DOC-09 Release/Supply-Chain|provenance expectation crosswalk|standard does not self-verify artifact|NO_SILENT_DROP / replacement requires crosswalk rationale|
|`ECP-29`|Sigstore / Cosign|signature/attestation verification|REFERENCE|DOC-09 Release/Supply-Chain|provider-neutral verification route|not mandatory where GitHub-native path selected|NO_SILENT_DROP / replacement requires crosswalk rationale|
|`ECP-30`|GitHub Artifact Attestations|GitHub provenance provider|ADOPT_REFERENCE_ADAPTER|DOC-09 Release/Supply-Chain|attestation creation/verification transport|attestation != functional acceptance|NO_SILENT_DROP / replacement requires crosswalk rationale|
|`ECP-37`|SCIP|optional compiler-grade index|REFERENCE|DOC-09 CI Adapter|optional code-intelligence input|no CI/release authority|NO_SILENT_DROP / replacement requires crosswalk rationale|
|`ECP-48`|MoRSE|role/subtask specialization donor|TRANSLATE|DOC-09 CI Adapter|research/workflow pattern|no authority expansion|NO_SILENT_DROP / replacement requires crosswalk rationale|
|`TQ-TECH-015`|SLSA v1.2|PROVENANCE_STANDARD|REFERENCE|DOC-09 Release/Supply-Chain|qualification taxonomy identity|no runtime adoption implied|NO_SILENT_DROP / replacement requires crosswalk rationale|
|`TQ-TECH-016`|GitHub Artifact Attestations|PROVENANCE_VERIFIER|REFERENCE|DOC-09 Release/Supply-Chain|qualification taxonomy identity|no runtime adoption implied|NO_SILENT_DROP / replacement requires crosswalk rationale|
|`TQ-TECH-017`|Sigstore / Cosign|PROVENANCE_VERIFIER|REFERENCE|DOC-09 Release/Supply-Chain|qualification taxonomy identity|no runtime adoption implied|NO_SILENT_DROP / replacement requires crosswalk rationale|
|`TQ-TECH-028`|GitHub Actions|CI_EXECUTOR|REFERENCE|DOC-09 CI Adapter|qualification taxonomy identity|no runtime adoption implied|NO_SILENT_DROP / replacement requires crosswalk rationale|
|`PHASES_RB00_RB15`|phase/runbook progression|RUNBOOK|TRANSLATE|DOC-09 Adoption Waves/Runbook|phase entry/exit/checkpoint/readback|phase label is not lifecycle state|NO_SILENT_DROP / replacement requires crosswalk rationale|
|`LONG_RUNNING_CONTROL`|long-horizon checkpoint/recovery|RUNBOOK|TRANSLATE|DOC-09 Runbook|checkpoint/retry/recovery/evidence|no autonomous authority expansion|NO_SILENT_DROP / replacement requires crosswalk rationale|
|`RELEASE_RECOVERY`|release/rollback/recovery|RELEASE|TRANSLATE|DOC-09 Release Lane|artifact identity/recovery/rollback/evidence|workflow cannot replace qualification/release authority|NO_SILENT_DROP / replacement requires crosswalk rationale|

Identity preservation applies to **all** dispositions (`ADOPT`, `REFERENCE`, `TRANSLATE`, `EVAL_ONLY`, `REJECT`, `NOT_APPLICABLE_WITH_RATIONALE`, `QUARANTINE`), not only installed items. Runtime installation/materialization obligations apply only when TechnologyAdmission/PD actually selects an executable item.



<a id="doc09-tech"></a>
# 17｜Full Technology / Tool Decision Records

Every record below satisfies the production-instruction field denominator. A truthful `LATE_BOUND_REQUIRED` value is allowed only when the target project fact cannot be known at generic standard time; it includes the stage and close contract rather than becoming a generic TODO.

### TECH-CI-ABI — PIPD Provider-Neutral CI ABI
```yaml
technology_id: "TECH-CI-ABI"
external_name: "PIPD Provider-Neutral CI ABI"
internal_short_name: "CI-ABI"
capability_slot: "CI_CORE"
need_ref: "AR-D09-004/005"
canonical_home: "DOC-09"
source: "P1 §20.1; P3 DOC-09"
license: "PIPD-owned / N/A"
observed_version: "1.1.0"
selected_version: "1.1.0"
selected_pin_or_digest: "INTERNAL_CANONICAL"
terminal_disposition: "ADOPT"
selection_rationale: "portable narrow waist; providers are adapters"
non_trigger: "provider choice does not change validator semantics"
materialization_stage: "DOC-09 materialized"
bind_stage: "PD binds provider"
activation_authority: "DOC-05/Release Authority remain separate"
translation_or_wrapper: "provider adapter"
config_contract: "command/exit/report schema"
permission_class: "READ_ONLY_VALIDATION by default"
side_effect_class: "NONE unless provider upload/evidence"
tests: "FIX-D09-001,002"
oracle: "OR-D09-001,002"
fallback: "local CLI invocation"
rollback: "remove adapter, keep ABI"
uninstall: "N/A internal"
provider_off: "switch provider adapter"
residue_check: "no provider-owned canonical state"
evidence: "ConformanceRun"
drift_trigger: "ABI version/standard change"
replacement_rule: "breaking change requires standard revision"
checked_at: "2026-10-07 or TARGET_BIND_RECHECK when late-bound"
currentness_ttl: "168h reference default unless stricter target policy"
claim_state: "DESIGN_REFERENCE_ONLY_UNLESS_SUBJECT_BOUND_RUNTIME_EVIDENCE_EXISTS"
```

### TECH-GHA — GitHub Actions
```yaml
technology_id: "TECH-GHA"
external_name: "GitHub Actions"
internal_short_name: "GHA"
capability_slot: "CI_PROVIDER"
need_ref: "AR-D09-006/007"
canonical_home: "DOC-09 CI Adapter"
source: "P1 §20.2–20.3; P3 ECP-26/TQ-TECH-028"
license: "SERVICE + per-action license VERIFY_AT_BIND"
observed_version: "service; P1 action baseline below"
selected_version: "REFERENCE_ADAPTER"
selected_pin_or_digest: "per-action full SHA + target currentness recheck"
terminal_disposition: "ADOPT_WITH_WRAPPER"
selection_rationale: "concrete reference adapter proves neutral ABI"
non_trigger: "non-GitHub project"
materialization_stage: "reference workflow materialized"
bind_stage: "PREDEV_BINDING"
activation_authority: "target repo/org admin config; Release Authority separate"
translation_or_wrapper: "pipd-required.yml/pipd-release.yml"
config_contract: "events, permissions, ruleset/required check"
permission_class: "contents:read; release adds id-token:write/attestations:write"
side_effect_class: "CI artifacts / attestations only in authorized job"
tests: "FIX-D09-003..006"
oracle: "terminal exact-subject required check + report"
fallback: "GitLab/Jenkins/Buildkite route-out"
rollback: "disable workflow only after required-check replacement"
uninstall: "remove workflow after ruleset update"
provider_off: "provider migration preserves check semantics"
residue_check: "ruleset/status contexts/artifacts"
evidence: "workflow run + conformance report + ruleset readback"
drift_trigger: "provider/action/runner/ruleset change"
replacement_rule: "provider adapter must preserve ABI"
checked_at: "2026-10-07 or TARGET_BIND_RECHECK when late-bound"
currentness_ttl: "168h reference default unless stricter target policy"
claim_state: "DESIGN_REFERENCE_ONLY_UNLESS_SUBJECT_BOUND_RUNTIME_EVIDENCE_EXISTS"
```

### TECH-CDX — CycloneDX 1.7 JSON
```yaml
technology_id: "TECH-CDX"
external_name: "CycloneDX 1.7 JSON"
internal_short_name: "CycloneDX"
capability_slot: "SBOM_FORMAT"
need_ref: "AR-D09-010"
canonical_home: "DOC-09 Release/Supply-Chain"
source: "P1 §21.3; P3 NOBJ-021"
license: "SPEC_LICENSE_VERIFY_AT_BIND"
observed_version: "1.7 baseline in P1/AUDIT"
selected_version: "1.7 JSON profile"
selected_pin_or_digest: "schema/profile identity"
terminal_disposition: "ADOPT_REFERENCE_PROFILE"
selection_rationale: "canonical reference interchange profile"
non_trigger: "project policy mandates only SPDX and receiver does not require CycloneDX"
materialization_stage: "Wave J"
bind_stage: "PD/release policy"
activation_authority: "Release policy owner"
translation_or_wrapper: "SBOMReceipt normalization"
config_contract: "format/profile/schema"
permission_class: "read artifact/dependency metadata"
side_effect_class: "creates evidence artifact only"
tests: "FIX-D09-014"
oracle: "same artifact digest + schema valid"
fallback: "SPDX 3.x supported profile"
rollback: "regenerate using approved alternate"
uninstall: "remove generator/profile binding, preserve evidence history"
provider_off: "format migration with consumer compatibility"
residue_check: "old SBOM receipts remain immutable history"
evidence: "SBOMReceipt"
drift_trigger: "schema/profile/consumer requirement"
replacement_rule: "must preserve subject digest and component identity"
checked_at: "2026-10-07 or TARGET_BIND_RECHECK when late-bound"
currentness_ttl: "168h reference default unless stricter target policy"
claim_state: "DESIGN_REFERENCE_ONLY_UNLESS_SUBJECT_BOUND_RUNTIME_EVIDENCE_EXISTS"
```

### TECH-SYFT — Syft
```yaml
technology_id: "TECH-SYFT"
external_name: "Syft"
internal_short_name: "Syft"
capability_slot: "SBOM_GENERATOR"
need_ref: "AUDIT M-12"
canonical_home: "DOC-09 Release/Supply-Chain"
source: "SUPPORT donor in mounted project corpus; selected here only as reference generator profile"
license: "VERIFY_AT_BIND_FROM_OFFICIAL_REPO"
observed_version: "REFERENCE_CANDIDATE; no runtime claim"
selected_version: "TARGET_PROJECT_REVALIDATE"
selected_pin_or_digest: "LATE_BOUND_REQUIRED full binary/container digest"
terminal_disposition: "REFERENCE_GENERATOR_PROFILE / QUALIFY_BEFORE_USE"
selection_rationale: "provides concrete generator tool while keeping format/tool separation"
non_trigger: "target project selects another qualified generator"
materialization_stage: "Wave J after PD currentness"
bind_stage: "PREDEV_BINDING"
activation_authority: "TechnologyAdmission owner; no acceptance authority"
translation_or_wrapper: "SBOMGeneratorBinding → SBOMReceipt"
config_contract: "input artifact + CycloneDX/SPDX output + output path"
permission_class: "read artifact/filesystem only unless target requires more"
side_effect_class: "writes SBOM evidence file"
tests: "FIX-D09-014, FIX-D09-019"
oracle: "known component fixture + schema/digest binding"
fallback: "qualified alternate generator/native dependency export"
rollback: "disable generator, regenerate with alternate"
uninstall: "remove binary/image and cache"
provider_off: "switch generator while preserving SBOMReceipt contract"
residue_check: "purge cache; historical SBOM retained"
evidence: "generator version/digest + command + SBOM hash"
drift_trigger: "release/license/security/output schema"
replacement_rule: "alternate must pass parity and negative fixtures"
checked_at: "2026-10-07 or TARGET_BIND_RECHECK when late-bound"
currentness_ttl: "168h reference default unless stricter target policy"
claim_state: "DESIGN_REFERENCE_ONLY_UNLESS_SUBJECT_BOUND_RUNTIME_EVIDENCE_EXISTS"
```

### TECH-SPDX — SPDX 3.x
```yaml
technology_id: "TECH-SPDX"
external_name: "SPDX 3.x"
internal_short_name: "SPDX"
capability_slot: "SBOM_FORMAT_ALT"
need_ref: "AR-D09-010"
canonical_home: "DOC-09 Release/Supply-Chain"
source: "P1 §21.3"
license: "SPEC_LICENSE_VERIFY_AT_BIND"
observed_version: "3.0/3.0.1 material; 3.1 RC not stable baseline per r1/AUDIT"
selected_version: "REFERENCE_SUPPORTED"
selected_pin_or_digest: "profile identity"
terminal_disposition: "REFERENCE"
selection_rationale: "organization/consumer alternate"
non_trigger: "CycloneDX-only policy"
materialization_stage: "Wave J"
bind_stage: "PD/release policy"
activation_authority: "Release policy owner"
translation_or_wrapper: "SBOMReceipt normalization"
config_contract: "format/profile/schema"
permission_class: "read artifact metadata"
side_effect_class: "evidence file"
tests: "FIX-D09-014"
oracle: "subject/schema validation"
fallback: "CycloneDX 1.7"
rollback: "regenerate"
uninstall: "remove binding"
provider_off: "format migration"
residue_check: "historical receipts"
evidence: "SBOMReceipt"
drift_trigger: "spec/consumer compatibility"
replacement_rule: "preserve subject identity"
checked_at: "2026-10-07 or TARGET_BIND_RECHECK when late-bound"
currentness_ttl: "168h reference default unless stricter target policy"
claim_state: "DESIGN_REFERENCE_ONLY_UNLESS_SUBJECT_BOUND_RUNTIME_EVIDENCE_EXISTS"
```

### TECH-ATTEST — GitHub Artifact Attestations / actions/attest
```yaml
technology_id: "TECH-ATTEST"
external_name: "GitHub Artifact Attestations / actions/attest"
internal_short_name: "GH-Attest"
capability_slot: "ATTESTATION_PROVIDER"
need_ref: "AR-D09-011"
canonical_home: "DOC-09 Release/Supply-Chain"
source: "P1 §20.2/§21.2; P3 ECP-30/TQ-TECH-016"
license: "VERIFY_AT_BIND"
observed_version: "P1 baseline v4.2.2"
selected_version: "v4.2.2 reference baseline"
selected_pin_or_digest: "1e69f48acb82d1966a394da916b4c1698aa569d6 + target recheck"
terminal_disposition: "ADOPT_WITH_WRAPPER"
selection_rationale: "GitHub reference lane"
non_trigger: "non-GitHub or policy-selected alternate"
materialization_stage: "Wave J"
bind_stage: "PD/release binding"
activation_authority: "workflow permission + Release Authority separate"
translation_or_wrapper: "AttestationReceipt"
config_contract: "subject-path/predicate"
permission_class: "id-token:write + attestations:write"
side_effect_class: "external attestation creation"
tests: "FIX-D09-011,012"
oracle: "creation distinct from independent verification"
fallback: "Sigstore/cosign route"
rollback: "invalidate/stop using attestation provider; preserve receipts"
uninstall: "remove action/job after policy update"
provider_off: "change trust provider/policy"
residue_check: "attestation records remain evidence history"
evidence: "AttestationReceipt + VerificationReceipt"
drift_trigger: "action/policy/trust root"
replacement_rule: "subject digest continuity mandatory"
checked_at: "2026-10-07 or TARGET_BIND_RECHECK when late-bound"
currentness_ttl: "168h reference default unless stricter target policy"
claim_state: "DESIGN_REFERENCE_ONLY_UNLESS_SUBJECT_BOUND_RUNTIME_EVIDENCE_EXISTS"
```

### TECH-COSIGN — Sigstore / Cosign
```yaml
technology_id: "TECH-COSIGN"
external_name: "Sigstore / Cosign"
internal_short_name: "cosign"
capability_slot: "PROVENANCE_VERIFIER_ALT"
need_ref: "AR-D09-011"
canonical_home: "DOC-09 Release/Supply-Chain"
source: "P3 ECP-29/TQ-TECH-017; r1 currentness baseline"
license: "VERIFY_AT_BIND"
observed_version: "r1 observed v3.0.5"
selected_version: "REFERENCE_ALTERNATE"
selected_pin_or_digest: "LATE_BOUND_REQUIRED"
terminal_disposition: "REFERENCE"
selection_rationale: "provider-neutral alternate verification path"
non_trigger: "GitHub-native attestation route sufficient"
materialization_stage: "TechnologyAdmission/PD"
bind_stage: "when selected"
activation_authority: "trust policy owner"
translation_or_wrapper: "AttestationVerificationReceipt"
config_contract: "identity/trust policy/subject digest"
permission_class: "network/read trust metadata as admitted"
side_effect_class: "verification only unless signing selected"
tests: "FIX-D09-012"
oracle: "exact subject + signer/policy match"
fallback: "GitHub attestation verify"
rollback: "restore prior verifier policy"
uninstall: "remove binary/config"
provider_off: "switch verifier/trust root"
residue_check: "remove cached trust material as policy requires"
evidence: "verification receipt"
drift_trigger: "release/trust root/security advisory"
replacement_rule: "same verification contract"
checked_at: "2026-10-07 or TARGET_BIND_RECHECK when late-bound"
currentness_ttl: "168h reference default unless stricter target policy"
claim_state: "DESIGN_REFERENCE_ONLY_UNLESS_SUBJECT_BOUND_RUNTIME_EVIDENCE_EXISTS"
```

### TECH-SLSA — SLSA v1.2
```yaml
technology_id: "TECH-SLSA"
external_name: "SLSA v1.2"
internal_short_name: "SLSA"
capability_slot: "PROVENANCE_STANDARD"
need_ref: "AUDIT M-13"
canonical_home: "DOC-09 Release/Supply-Chain"
source: "P3 ECP-28/TQ-TECH-015; AUDIT confirms v1.2 approved"
license: "SPEC_LICENSE_VERIFY_AT_BIND"
observed_version: "v1.2"
selected_version: "REFERENCE_TRANSLATION"
selected_pin_or_digest: "spec version 1.2"
terminal_disposition: "REFERENCE / TRANSLATE"
selection_rationale: "preserve provenance expectation semantics"
non_trigger: "never omitted; applicability of levels/claims is project-specific"
materialization_stage: "design + PD mapping"
bind_stage: "release policy mapping"
activation_authority: "PIPD remains canonical lifecycle authority"
translation_or_wrapper: "SLSA↔ProvenanceReceipt crosswalk"
config_contract: "predicate/provenance requirements"
permission_class: "none by spec itself"
side_effect_class: "none"
tests: "FIX-D09-013"
oracle: "crosswalk preserves subject/builder/source identity"
fallback: "PIPD native provenance contract remains"
rollback: "remove translation only with rationale"
uninstall: "N/A standard reference"
provider_off: "N/A"
residue_check: "crosswalk history"
evidence: "crosswalk record"
drift_trigger: "spec revision"
replacement_rule: "new spec version requires affected-only review"
checked_at: "2026-10-07 or TARGET_BIND_RECHECK when late-bound"
currentness_ttl: "168h reference default unless stricter target policy"
claim_state: "DESIGN_REFERENCE_ONLY_UNLESS_SUBJECT_BOUND_RUNTIME_EVIDENCE_EXISTS"
```

### TECH-TRIVY — Trivy
```yaml
technology_id: "TECH-TRIVY"
external_name: "Trivy"
internal_short_name: "Trivy"
capability_slot: "SECURITY_SCANNER"
need_ref: "P3 ECP-24"
canonical_home: "DOC-09 Release/Supply-Chain + DOC-07"
source: "P3 ECP-24"
license: "VERIFY_AT_BIND"
observed_version: "NOT_PINNED_IN_CORE_SOURCE"
selected_version: "REFERENCE / QUALIFY_BEFORE_USE"
selected_pin_or_digest: "LATE_BOUND_REQUIRED"
terminal_disposition: "REFERENCE"
selection_rationale: "preserve upstream named scanner identity"
non_trigger: "another qualified scanner covers required need"
materialization_stage: "PD if selected"
bind_stage: "TechnologyAdmission"
activation_authority: "DOC-07 oracle/release authority separate"
translation_or_wrapper: "security signal adapter"
config_contract: "scan target/policy/output"
permission_class: "read artifact/filesystem; network only if admitted"
side_effect_class: "evidence only"
tests: "per-tool install/bind/function/boundary/negative/uninstall"
oracle: "known-vuln/misconfig/secret fixtures"
fallback: "qualified alternate scanner"
rollback: "disable check after replacement"
uninstall: "remove binary/image/db"
provider_off: "remove status context and policy reference"
residue_check: "cache/db/status context cleanup"
evidence: "scanner receipt"
drift_trigger: "release/db/security/license"
replacement_rule: "parity + negative qualification"
checked_at: "2026-10-07 or TARGET_BIND_RECHECK when late-bound"
currentness_ttl: "168h reference default unless stricter target policy"
claim_state: "DESIGN_REFERENCE_ONLY_UNLESS_SUBJECT_BOUND_RUNTIME_EVIDENCE_EXISTS"
```

### TECH-GITLEAKS — Gitleaks
```yaml
technology_id: "TECH-GITLEAKS"
external_name: "Gitleaks"
internal_short_name: "Gitleaks"
capability_slot: "SECRET_SCAN"
need_ref: "AR-D09-028"
canonical_home: "DOC-07 + DOC-09"
source: "r1/AUDIT"
license: "VERIFY_AT_BIND"
observed_version: "v8.30.1 observed; audit flags qualification risk"
selected_version: "REFERENCE / QUALIFY_BEFORE_USE"
selected_pin_or_digest: "LATE_BOUND_REQUIRED"
terminal_disposition: "REFERENCE"
selection_rationale: "secret scanning signal only"
non_trigger: "different qualified secret scanner selected"
materialization_stage: "PD if selected"
bind_stage: "TechnologyAdmission"
activation_authority: "scanner never Release Authority"
translation_or_wrapper: "security signal adapter"
config_contract: "rules/baseline/redaction"
permission_class: "read repo; no secret exfiltration"
side_effect_class: "evidence only"
tests: "FIX-D09-015 + known-secret positive fixture"
oracle: "must detect canonical seeded secret; false negative blocks adoption"
fallback: "qualified alternate scanner"
rollback: "disable after replacement"
uninstall: "remove binary/action/rules"
provider_off: "remove required context after replacement"
residue_check: "purge caches/baselines containing sensitive material"
evidence: "qualification + scan receipt"
drift_trigger: "release/security issue/checksum"
replacement_rule: "known-secret fixture mandatory"
checked_at: "2026-10-07 or TARGET_BIND_RECHECK when late-bound"
currentness_ttl: "168h reference default unless stricter target policy"
claim_state: "DESIGN_REFERENCE_ONLY_UNLESS_SUBJECT_BOUND_RUNTIME_EVIDENCE_EXISTS"
```

### TECH-SCORECARD — OpenSSF Scorecard
```yaml
technology_id: "TECH-SCORECARD"
external_name: "OpenSSF Scorecard"
internal_short_name: "Scorecard"
capability_slot: "OSS_POSTURE"
need_ref: "AUDIT M-14"
canonical_home: "DOC-07 + DOC-09"
source: "r1/AUDIT"
license: "VERIFY_AT_BIND"
observed_version: "v5.5.0 observed"
selected_version: "REFERENCE / ADVISORY"
selected_pin_or_digest: "LATE_BOUND_REQUIRED if action used"
terminal_disposition: "EVAL_ONLY / ADVISORY"
selection_rationale: "posture signal; audit flags nested mutable image risk"
non_trigger: "not required by target assurance policy"
materialization_stage: "PD if selected"
bind_stage: "TechnologyAdmission"
activation_authority: "advisory only"
translation_or_wrapper: "posture signal adapter"
config_contract: "checks/output"
permission_class: "read repo; token least privilege"
side_effect_class: "evidence only"
tests: "FIX-D09-016 + nested-runtime dependency review"
oracle: "outer SHA pin alone is insufficient for container action"
fallback: "CLI/container digest pin or omit"
rollback: "disable advisory check"
uninstall: "remove action/config"
provider_off: "remove status context"
residue_check: "report artifacts/status context"
evidence: "qualification + posture receipt"
drift_trigger: "action/nested image/security issue"
replacement_rule: "must close nested runtime dependency immutability"
checked_at: "2026-10-07 or TARGET_BIND_RECHECK when late-bound"
currentness_ttl: "168h reference default unless stricter target policy"
claim_state: "DESIGN_REFERENCE_ONLY_UNLESS_SUBJECT_BOUND_RUNTIME_EVIDENCE_EXISTS"
```

### TECH-JSONSCHEMA — JSON Schema Draft 2020-12 / jsonschema runtime
```yaml
technology_id: "TECH-JSONSCHEMA"
external_name: "JSON Schema Draft 2020-12 / jsonschema runtime"
internal_short_name: "JSONSchema"
capability_slot: "SCHEMA_VALIDATION"
need_ref: "AR-D09-004/013/014"
canonical_home: "DOC-09 tooling"
source: "P1 §6/P2 schemas"
license: "runtime package license VERIFY_AT_BIND"
observed_version: "Draft 2020-12 semantics"
selected_version: "ADOPT; exact runtime package target-bound"
selected_pin_or_digest: "pip --require-hashes lock or vendored container digest"
terminal_disposition: "ADOPT"
selection_rationale: "canonical schema contract"
non_trigger: "none for reference Python validator"
materialization_stage: "Wave A/F"
bind_stage: "ValidatorEnvironmentBinding"
activation_authority: "validator semantics defined by PIPD"
translation_or_wrapper: "pipd validator environment"
config_contract: "schema dir + lock file"
permission_class: "local read only"
side_effect_class: "none"
tests: "FIX-D09-001,017"
oracle: "schema valid + lock integrity"
fallback: "vendored/attested environment"
rollback: "restore prior lock/container"
uninstall: "remove venv/container"
provider_off: "switch validated runtime implementation"
residue_check: "purge stale environment"
evidence: "validator environment receipt"
drift_trigger: "runtime/package/schema semantics"
replacement_rule: "equivalent implementation must pass canonical fixtures"
checked_at: "2026-10-07 or TARGET_BIND_RECHECK when late-bound"
currentness_ttl: "168h reference default unless stricter target policy"
claim_state: "DESIGN_REFERENCE_ONLY_UNLESS_SUBJECT_BOUND_RUNTIME_EVIDENCE_EXISTS"
```

### TECH-ACTION-ACTIONS-CHECKOUT — actions/checkout
```yaml
technology_id: "TECH-ACTION-ACTIONS-CHECKOUT"
external_name: "actions/checkout"
internal_short_name: "checkout"
capability_slot: "GITHUB_ACTION_REFERENCE_BASELINE"
need_ref: "AUDIT M-03"
canonical_home: "DOC-09 CI/Release Adapter"
source: "P1 §20.2"
license: "VERIFY_AT_BIND_FROM_OFFICIAL_REPOSITORY"
observed_version: "v7.0.1"
selected_version: "v7.0.1 reference baseline"
selected_pin_or_digest: "3d3c42e5aac5ba805825da76410c181273ba90b1"
terminal_disposition: "REFERENCE_BASELINE + TARGET_REPIN_REQUIRED"
selection_rationale: "retain known immutable baseline without erasing target revalidation"
non_trigger: "non-GitHub provider"
materialization_stage: "reference workflow"
bind_stage: "PREDEV currentness recheck"
activation_authority: "adapter only"
translation_or_wrapper: "GitHub workflow step"
config_contract: "workflow YAML"
permission_class: "job-specific least privilege"
side_effect_class: "depends on action; attestation action is effectful evidence creation"
tests: "workflow fixture + pin/currentness check"
oracle: "exact full SHA + allowed runner/currentness"
fallback: "approved successor or provider route-out"
rollback: "restore prior admitted pin"
uninstall: "remove step only after dependency/status context review"
provider_off: "remove provider-specific step"
residue_check: "workflow/ruleset/artifact references"
evidence: "currentness + workflow receipt"
drift_trigger: "168h TTL / release/security/runner change"
replacement_rule: "successor requires official-source recheck + affected-only qualification"
checked_at: "2026-10-07 or TARGET_BIND_RECHECK when late-bound"
currentness_ttl: "168h reference default unless stricter target policy"
claim_state: "DESIGN_REFERENCE_ONLY_UNLESS_SUBJECT_BOUND_RUNTIME_EVIDENCE_EXISTS"
```

### TECH-ACTION-ACTIONS-SETUP-PYTHON — actions/setup-python
```yaml
technology_id: "TECH-ACTION-ACTIONS-SETUP-PYTHON"
external_name: "actions/setup-python"
internal_short_name: "setup-python"
capability_slot: "GITHUB_ACTION_REFERENCE_BASELINE"
need_ref: "AUDIT M-03"
canonical_home: "DOC-09 CI/Release Adapter"
source: "P1 §20.2"
license: "VERIFY_AT_BIND_FROM_OFFICIAL_REPOSITORY"
observed_version: "v7.0.0"
selected_version: "v7.0.0 reference baseline"
selected_pin_or_digest: "5fda3b95a4ea91299a34e894583c3862153e4b97"
terminal_disposition: "REFERENCE_BASELINE + TARGET_REPIN_REQUIRED"
selection_rationale: "retain known immutable baseline without erasing target revalidation"
non_trigger: "non-GitHub provider"
materialization_stage: "reference workflow"
bind_stage: "PREDEV currentness recheck"
activation_authority: "adapter only"
translation_or_wrapper: "GitHub workflow step"
config_contract: "workflow YAML"
permission_class: "job-specific least privilege"
side_effect_class: "depends on action; attestation action is effectful evidence creation"
tests: "workflow fixture + pin/currentness check"
oracle: "exact full SHA + allowed runner/currentness"
fallback: "approved successor or provider route-out"
rollback: "restore prior admitted pin"
uninstall: "remove step only after dependency/status context review"
provider_off: "remove provider-specific step"
residue_check: "workflow/ruleset/artifact references"
evidence: "currentness + workflow receipt"
drift_trigger: "168h TTL / release/security/runner change"
replacement_rule: "successor requires official-source recheck + affected-only qualification"
checked_at: "2026-10-07 or TARGET_BIND_RECHECK when late-bound"
currentness_ttl: "168h reference default unless stricter target policy"
claim_state: "DESIGN_REFERENCE_ONLY_UNLESS_SUBJECT_BOUND_RUNTIME_EVIDENCE_EXISTS"
```

### TECH-ACTION-ACTIONS-UPLOAD-ARTIFACT — actions/upload-artifact
```yaml
technology_id: "TECH-ACTION-ACTIONS-UPLOAD-ARTIFACT"
external_name: "actions/upload-artifact"
internal_short_name: "upload-artifact"
capability_slot: "GITHUB_ACTION_REFERENCE_BASELINE"
need_ref: "AUDIT M-03"
canonical_home: "DOC-09 CI/Release Adapter"
source: "P1 §20.2"
license: "VERIFY_AT_BIND_FROM_OFFICIAL_REPOSITORY"
observed_version: "v7.0.1"
selected_version: "v7.0.1 reference baseline"
selected_pin_or_digest: "043fb46d1a93c77aae656e7c1c64a875d1fc6a0a"
terminal_disposition: "REFERENCE_BASELINE + TARGET_REPIN_REQUIRED"
selection_rationale: "retain known immutable baseline without erasing target revalidation"
non_trigger: "non-GitHub provider"
materialization_stage: "reference workflow"
bind_stage: "PREDEV currentness recheck"
activation_authority: "adapter only"
translation_or_wrapper: "GitHub workflow step"
config_contract: "workflow YAML"
permission_class: "job-specific least privilege"
side_effect_class: "depends on action; attestation action is effectful evidence creation"
tests: "workflow fixture + pin/currentness check"
oracle: "exact full SHA + allowed runner/currentness"
fallback: "approved successor or provider route-out"
rollback: "restore prior admitted pin"
uninstall: "remove step only after dependency/status context review"
provider_off: "remove provider-specific step"
residue_check: "workflow/ruleset/artifact references"
evidence: "currentness + workflow receipt"
drift_trigger: "168h TTL / release/security/runner change"
replacement_rule: "successor requires official-source recheck + affected-only qualification"
checked_at: "2026-10-07 or TARGET_BIND_RECHECK when late-bound"
currentness_ttl: "168h reference default unless stricter target policy"
claim_state: "DESIGN_REFERENCE_ONLY_UNLESS_SUBJECT_BOUND_RUNTIME_EVIDENCE_EXISTS"
```

### TECH-ACTION-ACTIONS-DOWNLOAD-ARTIFACT — actions/download-artifact
```yaml
technology_id: "TECH-ACTION-ACTIONS-DOWNLOAD-ARTIFACT"
external_name: "actions/download-artifact"
internal_short_name: "download-artifact"
capability_slot: "GITHUB_ACTION_REFERENCE_BASELINE"
need_ref: "AUDIT M-03"
canonical_home: "DOC-09 CI/Release Adapter"
source: "P1 §20.2"
license: "VERIFY_AT_BIND_FROM_OFFICIAL_REPOSITORY"
observed_version: "v8.0.0"
selected_version: "v8.0.0 reference baseline"
selected_pin_or_digest: "70fc10c6e5e1ce46ad2ea6f2b72d43f7d47b13c3"
terminal_disposition: "REFERENCE_BASELINE + TARGET_REPIN_REQUIRED"
selection_rationale: "retain known immutable baseline without erasing target revalidation"
non_trigger: "non-GitHub provider"
materialization_stage: "reference workflow"
bind_stage: "PREDEV currentness recheck"
activation_authority: "adapter only"
translation_or_wrapper: "GitHub workflow step"
config_contract: "workflow YAML"
permission_class: "job-specific least privilege"
side_effect_class: "depends on action; attestation action is effectful evidence creation"
tests: "workflow fixture + pin/currentness check"
oracle: "exact full SHA + allowed runner/currentness"
fallback: "approved successor or provider route-out"
rollback: "restore prior admitted pin"
uninstall: "remove step only after dependency/status context review"
provider_off: "remove provider-specific step"
residue_check: "workflow/ruleset/artifact references"
evidence: "currentness + workflow receipt"
drift_trigger: "168h TTL / release/security/runner change"
replacement_rule: "successor requires official-source recheck + affected-only qualification"
checked_at: "2026-10-07 or TARGET_BIND_RECHECK when late-bound"
currentness_ttl: "168h reference default unless stricter target policy"
claim_state: "DESIGN_REFERENCE_ONLY_UNLESS_SUBJECT_BOUND_RUNTIME_EVIDENCE_EXISTS"
```

### TECH-ACTION-ACTIONS-DEPENDENCY-REVIEW-ACTION — actions/dependency-review-action
```yaml
technology_id: "TECH-ACTION-ACTIONS-DEPENDENCY-REVIEW-ACTION"
external_name: "actions/dependency-review-action"
internal_short_name: "dependency-review-action"
capability_slot: "GITHUB_ACTION_REFERENCE_BASELINE"
need_ref: "AUDIT M-03"
canonical_home: "DOC-09 CI/Release Adapter"
source: "P1 §20.2"
license: "VERIFY_AT_BIND_FROM_OFFICIAL_REPOSITORY"
observed_version: "v5.0.0"
selected_version: "v5.0.0 reference baseline"
selected_pin_or_digest: "a1d282b36b6f3519aa1f3fc636f609c47dddb294"
terminal_disposition: "REFERENCE_BASELINE + TARGET_REPIN_REQUIRED"
selection_rationale: "retain known immutable baseline without erasing target revalidation"
non_trigger: "non-GitHub provider"
materialization_stage: "reference workflow"
bind_stage: "PREDEV currentness recheck"
activation_authority: "adapter only"
translation_or_wrapper: "GitHub workflow step"
config_contract: "workflow YAML"
permission_class: "job-specific least privilege"
side_effect_class: "depends on action; attestation action is effectful evidence creation"
tests: "workflow fixture + pin/currentness check"
oracle: "exact full SHA + allowed runner/currentness"
fallback: "approved successor or provider route-out"
rollback: "restore prior admitted pin"
uninstall: "remove step only after dependency/status context review"
provider_off: "remove provider-specific step"
residue_check: "workflow/ruleset/artifact references"
evidence: "currentness + workflow receipt"
drift_trigger: "168h TTL / release/security/runner change"
replacement_rule: "successor requires official-source recheck + affected-only qualification"
checked_at: "2026-10-07 or TARGET_BIND_RECHECK when late-bound"
currentness_ttl: "168h reference default unless stricter target policy"
claim_state: "DESIGN_REFERENCE_ONLY_UNLESS_SUBJECT_BOUND_RUNTIME_EVIDENCE_EXISTS"
```

### TECH-ACTION-GITHUB-CODEQL-ACTION — github/codeql-action
```yaml
technology_id: "TECH-ACTION-GITHUB-CODEQL-ACTION"
external_name: "github/codeql-action"
internal_short_name: "codeql-action"
capability_slot: "GITHUB_ACTION_REFERENCE_BASELINE"
need_ref: "AUDIT M-03"
canonical_home: "DOC-09 CI/Release Adapter"
source: "P1 §20.2"
license: "VERIFY_AT_BIND_FROM_OFFICIAL_REPOSITORY"
observed_version: "v4.38.2"
selected_version: "v4.38.2 reference baseline"
selected_pin_or_digest: "2892aa5e19bbd11bc0cff5427e3b750a04d9e3c2"
terminal_disposition: "REFERENCE_BASELINE + TARGET_REPIN_REQUIRED"
selection_rationale: "retain known immutable baseline without erasing target revalidation"
non_trigger: "non-GitHub provider"
materialization_stage: "reference workflow"
bind_stage: "PREDEV currentness recheck"
activation_authority: "adapter only"
translation_or_wrapper: "GitHub workflow step"
config_contract: "workflow YAML"
permission_class: "job-specific least privilege"
side_effect_class: "depends on action; attestation action is effectful evidence creation"
tests: "workflow fixture + pin/currentness check"
oracle: "exact full SHA + allowed runner/currentness"
fallback: "approved successor or provider route-out"
rollback: "restore prior admitted pin"
uninstall: "remove step only after dependency/status context review"
provider_off: "remove provider-specific step"
residue_check: "workflow/ruleset/artifact references"
evidence: "currentness + workflow receipt"
drift_trigger: "168h TTL / release/security/runner change"
replacement_rule: "successor requires official-source recheck + affected-only qualification"
checked_at: "2026-10-07 or TARGET_BIND_RECHECK when late-bound"
currentness_ttl: "168h reference default unless stricter target policy"
claim_state: "DESIGN_REFERENCE_ONLY_UNLESS_SUBJECT_BOUND_RUNTIME_EVIDENCE_EXISTS"
```

### TECH-ACTION-ACTIONS-ATTEST — actions/attest
```yaml
technology_id: "TECH-ACTION-ACTIONS-ATTEST"
external_name: "actions/attest"
internal_short_name: "attest"
capability_slot: "GITHUB_ACTION_REFERENCE_BASELINE"
need_ref: "AUDIT M-03"
canonical_home: "DOC-09 CI/Release Adapter"
source: "P1 §20.2"
license: "VERIFY_AT_BIND_FROM_OFFICIAL_REPOSITORY"
observed_version: "v4.2.2"
selected_version: "v4.2.2 reference baseline"
selected_pin_or_digest: "1e69f48acb82d1966a394da916b4c1698aa569d6"
terminal_disposition: "REFERENCE_BASELINE + TARGET_REPIN_REQUIRED"
selection_rationale: "retain known immutable baseline without erasing target revalidation"
non_trigger: "non-GitHub provider"
materialization_stage: "reference workflow"
bind_stage: "PREDEV currentness recheck"
activation_authority: "adapter only"
translation_or_wrapper: "GitHub workflow step"
config_contract: "workflow YAML"
permission_class: "job-specific least privilege"
side_effect_class: "depends on action; attestation action is effectful evidence creation"
tests: "workflow fixture + pin/currentness check"
oracle: "exact full SHA + allowed runner/currentness"
fallback: "approved successor or provider route-out"
rollback: "restore prior admitted pin"
uninstall: "remove step only after dependency/status context review"
provider_off: "remove provider-specific step"
residue_check: "workflow/ruleset/artifact references"
evidence: "currentness + workflow receipt"
drift_trigger: "168h TTL / release/security/runner change"
replacement_rule: "successor requires official-source recheck + affected-only qualification"
checked_at: "2026-10-07 or TARGET_BIND_RECHECK when late-bound"
currentness_ttl: "168h reference default unless stricter target policy"
claim_state: "DESIGN_REFERENCE_ONLY_UNLESS_SUBJECT_BOUND_RUNTIME_EVIDENCE_EXISTS"
```




<a id="doc09-anti-degrade"></a>
# 18｜Anti-Degradation / Reference Baseline / Target Binding Rules

1. Every named upstream object retains stable identity even when not installed.
2. Known P1 reference versions/full SHAs are never erased merely because target project revalidation is required.
3. `REFERENCE`/`TRANSLATE`/`EVAL_ONLY` records cannot silently disappear.
4. `ADOPT`/`ADOPT_WITH_WRAPPER` items are `NOT_OPTIONAL_AFTER_SELECTION` until an approved replacement passes parity, negative, rollback, uninstall, provider-off and residue checks.
5. No `latest` tag or mutable action tag may replace a known full-SHA baseline without currentness evidence.
6. A provider/action/tool cannot acquire Product Truth, lifecycle state, ExecutionAdmission, Release Authority or world-effect authority through integration.



<a id="doc09-currentness"></a>
# 19｜Currentness / Security Signals / Named CR & Risk Retention

## 19.1 Scorecard nested-runtime rule
A full outer action commit SHA is necessary but not universally sufficient for container actions. If a selected action invokes a nested container/image or mutable runtime dependency, the nested dependency must be digest-reviewed/pinned or the project must use a qualified CLI/container-digest route. Otherwise the item remains advisory or HOLD for ASSURED use.

## 19.2 Gitleaks qualification rule
`v8.30.1` is retained only as an observed reference baseline from the r1/AUDIT context. Before adoption, the exact selected build must pass a seeded known-secret positive fixture and checksum/package integrity verification. Scanner PASS is never a release oracle.

## 19.3 Named CR / Risk Register

|CR/Risk|Status|Closure owner|Close criteria|Blocking scope|
|---|---|---|---|---|
|CR-003 Release artifact store/registry|OPEN_TYPED_SLOT|target PD / release owner|provider/store, immutable/content-addressed guarantee, auth, retention, download, provider-off all bound|release lane only|
|CR-010 Scorecard nested runtime image caveat|OPEN_UNTIL_QUALIFIED|security/tool admission owner|nested image/dependency digest reviewed or CLI/container digest path used|Scorecard adoption only|
|CR-011 GitHub ruleset availability/config|OPEN_UNTIL_READBACK|repo admin / CI adapter owner|required context read back from ruleset/branch protection; unavailable route recorded|merge enforcement only|
|CR-012 CODEOWNERS identities|OPEN_IF_PROFILE_REQUIRES|repo governance owner|exact reviewer identities/team refs bound and current|review/approval gate only|
|CR-VALENV Validator environment lock|OPEN_UNTIL_PD_BIND|validator environment owner|hash-locked pip set or vendored/attested container digest|CI validator only|
|CR-SBOMGEN SBOM generator|OPEN_UNTIL_PD_BIND|release toolchain owner|qualified generator exact version/digest + fixture pass|SBOM evidence only|
|R-007 Mutable nested action runtime|ACTIVE_CONTROLLED|security owner|outer full SHA plus nested dependency/image review|affected action only|
|R-GITLEAKS-8301 Qualification signal|ACTIVE_CONTROLLED|security/test owner|known-secret positive fixture passes selected build|Gitleaks adoption only|
|R-CYCLONEDX-2 Tool support/currentness|WATCH|SBOM owner|target consumers/generator support verified before any future profile migration|SBOM profile only|

## 19.4 Currentness close contract
Every external item resolves:
`official source → observed version → selected version → immutable pin/digest → license → security note → compatibility → checked_at → TTL → recheck trigger → evidence`.


<a id="doc09-security"></a>
# 20｜CI / Release Security Contract
|Threat|Control|Required evidence|Failure|
|---|---|---|---|
|Over-broad token|explicit job-level least privilege; no blanket write|permissions snapshot|PERMISSION_BLOCKED|
|Secret exposure|handles only; no canonical secret values; log redaction|redaction/secret-reference evidence|PERMISSION_BLOCKED|
|OIDC misuse|id-token only in attestation/deploy jobs that need it; subject/audience policy|OIDC policy + attestation identity|PERMISSION_BLOCKED|
|Mutable action tag|full immutable commit SHA at binding|pin ledger|CURRENTNESS_STALE|
|Untrusted PR credential access|separate trusted/untrusted jobs; no release secrets on fork/untrusted context|fork trust policy|PERMISSION_BLOCKED|
|Workflow/script injection|quote/encode untrusted values; avoid direct expression interpolation into shell where unsafe|negative fixture receipt|SEMANTIC_FAILURE|
|Artifact poisoning|immutable transfer + digest recompute|digest receipts|SUPPLY_CHAIN_MISMATCH|
|Cache poisoning|subject/lock-aware keys; do not treat cache as trusted release artifact|cache policy + negative test|SUPPLY_CHAIN_MISMATCH|
|Dependency substitution|lock/pin + dependency review/currentness|dependency evidence|CURRENTNESS_STALE|
|Runner trust drift|runner image/version/labels recorded; compatibility/currentness checked|runner receipt|TOOLCHAIN_INCOMPATIBLE|
|Scanner overclaim|scanner results advisory; release gate consumes lifecycle truth separately|release gate packet|HOLD|
|Release credential abuse|Release Authority separation; environment/protection approval where applicable|approval decision|RELEASE_AUTHORITY_MISSING|

# 20.1 Profile / Applicability Tailoring
|Profile|CI depth|SBOM/attestation|Checker/SoD|Runbook/rollback|
|---|---|---|---|---|
|LITE|single required canonical conformance check plus project tests|SBOM/attestation only when release surface/policy requires; claim separation always retained|maker/checker may be combined only where DOC-01/DOC-06 permit|bounded rollback and provider-off still mandatory|
|STANDARD|full conformance + security/currentness + build/release checks as applicable|SBOM expected for distributable artifacts; provenance/attestation according to selected release profile|independent review SHOULD; release authority separate|documented rollback and incident path|
|ASSURED|full conformance, adversarial/mutation, strict runner/provider/currentness gates|provenance/attestation and release evidence chain required where applicable|independent checker, human gates, explicit SoD|rollback drill, repeatable qualification, stronger evidence retention|

Target profiles `SYSTEM`, `SKILL_PLUGIN`, `AGENT_HARNESS`, `CUSTOM` and brownfield/migration extensions may change depth and concrete tools, but never weaken subject-bound evidence, fail-closed behavior, canonical ownership, ExecutionAdmission, currentness, release-authority separation or `tool success != effect truth`.


<a id="doc09-fixtures"></a>
# 21｜Executable Test / Oracle / Fixture Contracts

The r1 test-design list is upgraded to materializable fixture contracts. Every row has fixture identity/path/hash, executable command, expected exit/machine invariant, cleanup and evidence path.

|fixture_id|purpose|fixture path|SHA-256 of embedded fixture payload|execution command|expected exit|expected machine output|cleanup|evidence path|
|---|---|---|---|---|---:|---|---|---|
|`FIX-D09-001`|distribution exact-set|`fixtures/FIX-D09-001.json`|`44136fa355b3678a1146ad16f7e8649e94fb4fc21fe77e8310c060f61caaff8a`|`python .pipd/tools/pipd_dist.py --standard <std> --expected-sha256 <sha> --out <tmp>`|0|`schemas=22; canonical_tests=20; normative_requirements=86`|remove temp fixture/output|`.pipd/evidence/FIX-D09-001.json`|
|`FIX-D09-002`|required workflow skipped|`fixtures/FIX-D09-002.json`|`d93ee4da6bfead1c809346b1cd480a9d486ebd6ab885c85f306df6ebe8d586d5`|`python .pipd/tests/check_required_status.py fixture.json`|3|`result=FAIL; invariant=REQUIRED_CHECK_NONPASS`|remove temp fixture/output|`.pipd/evidence/FIX-D09-002.json`|
|`FIX-D09-003`|merge_group subject|`fixtures/FIX-D09-003.json`|`27f3f4b28caf16c21c961d032f32daebd4058a0a8573c5d7f387a48c6641a58b`|`python .pipd/tests/check_subject.py fixture.json`|0|`subject=merge-sha`|remove temp fixture/output|`.pipd/evidence/FIX-D09-003.json`|
|`FIX-D09-004`|mutable action tag|`fixtures/FIX-D09-004.json`|`7c91c0696d61363891a044563514c3457ae4b6bf87dfd169c3bebda7c002b644`|`python .pipd/tests/check_action_pins.py fixture.json`|4|`invariant=MUTABLE_ACTION_PIN`|remove temp fixture/output|`.pipd/evidence/FIX-D09-004.json`|
|`FIX-D09-005`|wrong subject report|`fixtures/FIX-D09-005.json`|`ee6a7a0fdf30fb7d1b1a77054b9dbbb0ac232263a78b53cfb273d21dfccd0ad4`|`python .pipd/tests/check_subject.py fixture.json`|3|`invariant=WRONG_SUBJECT`|remove temp fixture/output|`.pipd/evidence/FIX-D09-005.json`|
|`FIX-D09-006`|ruleset missing required context|`fixtures/FIX-D09-006.json`|`84be50bbdc34809bb22d5dec9057a3430775fe4289ffb4aa9f0e21bccf0c5983`|`python .pipd/tests/check_ruleset.py fixture.json`|6|`invariant=REQUIRED_CHECK_NOT_ENFORCED`|remove temp fixture/output|`.pipd/evidence/FIX-D09-006.json`|
|`FIX-D09-007`|stale object hash|`fixtures/FIX-D09-007.json`|`0179aa2b3d8108f0a53153a1874a8134f8b1de9900366fb13fbabec655235405`|`python .pipd/tests/check_hash.py fixture.json`|4|`invariant=OBJECT_HASH_STALE`|remove temp fixture/output|`.pipd/evidence/FIX-D09-007.json`|
|`FIX-D09-008`|expired currentness|`fixtures/FIX-D09-008.json`|`00ff4d706e9380860072e8ee778c42507c89f000f7a8c3d3847c5ffa5f678754`|`python .pipd/tests/check_currentness.py fixture.json`|4|`invariant=CURRENTNESS_TTL_EXPIRED`|remove temp fixture/output|`.pipd/evidence/FIX-D09-008.json`|
|`FIX-D09-009`|missing permission|`fixtures/FIX-D09-009.json`|`5d9ee5ba4a753868bf19f003c96afa3455ae124925838c60435a4ffc33131563`|`python .pipd/tests/check_permission.py fixture.json`|5|`invariant=HIGH_RISK_REQUIRES_TOKEN`|remove temp fixture/output|`.pipd/evidence/FIX-D09-009.json`|
|`FIX-D09-010`|false green without report|`fixtures/FIX-D09-010.json`|`1fa657121efc53653af7ab97480ec96ec3c227a8d172c31ff9efa86bd24ba4ec`|`python .pipd/tests/check_ci_evidence.py fixture.json`|6|`invariant=CANONICAL_REPORT_MISSING`|remove temp fixture/output|`.pipd/evidence/FIX-D09-010.json`|
|`FIX-D09-011`|transfer digest mismatch|`fixtures/FIX-D09-011.json`|`0b65b88f0c1cdfa2b6cf809cea4f0d06e4375485e1759fcd72b6031c5b3ff132`|`python .pipd/tests/check_digest_chain.py fixture.json`|3|`invariant=SUPPLY_CHAIN_MISMATCH`|remove temp fixture/output|`.pipd/evidence/FIX-D09-011.json`|
|`FIX-D09-012`|attestation unverified|`fixtures/FIX-D09-012.json`|`84de64f7ad10eb72c500b0da3f1cb4588972983ec763ebda297966b5ef9e95c8`|`python .pipd/tests/check_attestation.py fixture.json`|3|`invariant=ATTESTATION_UNVERIFIED`|remove temp fixture/output|`.pipd/evidence/FIX-D09-012.json`|
|`FIX-D09-013`|SLSA crosswalk wrong subject|`fixtures/FIX-D09-013.json`|`000868fc4ce017aadcf382680c20f0fd112a2485f1169b6b4e3ada8f96246452`|`python .pipd/tests/check_slsa_crosswalk.py fixture.json`|3|`invariant=PROVENANCE_SUBJECT_MISMATCH`|remove temp fixture/output|`.pipd/evidence/FIX-D09-013.json`|
|`FIX-D09-014`|SBOM wrong subject|`fixtures/FIX-D09-014.json`|`da0a3caf724ea627fe0ac9179411e0b14727e6a68bdfaa043e9a876d13d54773`|`python .pipd/tests/check_sbom.py fixture.json`|3|`invariant=SBOM_SUBJECT_MISMATCH`|remove temp fixture/output|`.pipd/evidence/FIX-D09-014.json`|
|`FIX-D09-015`|Gitleaks seeded secret missed|`fixtures/FIX-D09-015.json`|`7c8568e55f8f90778a635d402a70db5f3381909332c7bcf4fbad7ab3daf53699`|`python .pipd/tests/check_scanner_qualification.py fixture.json`|3|`invariant=SECRET_SCANNER_FALSE_NEGATIVE`|remove temp fixture/output|`.pipd/evidence/FIX-D09-015.json`|
|`FIX-D09-016`|Scorecard nested mutable image|`fixtures/FIX-D09-016.json`|`213641b1a6b30c608a01daf712449facefe375728ee9d7df3ca942deaba8bee8`|`python .pipd/tests/check_nested_runtime.py fixture.json`|4|`invariant=NESTED_RUNTIME_MUTABLE`|remove temp fixture/output|`.pipd/evidence/FIX-D09-016.json`|
|`FIX-D09-017`|validator dependency unpinned|`fixtures/FIX-D09-017.json`|`049b11a9ab8b78d1f2a19fe1c20e134c7fb439a50a823f4444e2aa97a36eecec`|`python .pipd/tests/check_validator_env.py fixture.json`|4|`invariant=VALIDATOR_ENV_UNPINNED`|remove temp fixture/output|`.pipd/evidence/FIX-D09-017.json`|
|`FIX-D09-018`|provider outage|`fixtures/FIX-D09-018.json`|`e6e9339d1e3456f3814915f683860e39f57e3dc3882059474dfe3fff4abc8e67`|`python .pipd/tests/check_provider_off.py fixture.json`|0|`route=fallback; canonical truth preserved`|remove temp fixture/output|`.pipd/evidence/FIX-D09-018.json`|
|`FIX-D09-019`|tool uninstall residue|`fixtures/FIX-D09-019.json`|`b06263c556b39a47b6e0844548e7d4d97c77a74ac39c5f1d89990c5b79b7b855`|`python .pipd/tests/check_residue.py fixture.json`|3|`invariant=UNINSTALL_RESIDUE`|remove temp fixture/output|`.pipd/evidence/FIX-D09-019.json`|
|`FIX-D09-020`|release authority missing|`fixtures/FIX-D09-020.json`|`a3e8139a0a5f4ef886e464d247e2ddd3f3fa152dc69d86bd0a1af14393403aef`|`python .pipd/tests/check_release_gate.py fixture.json`|5|`invariant=RELEASE_AUTHORITY_MISSING`|remove temp fixture/output|`.pipd/evidence/FIX-D09-020.json`|
|`FIX-D09-021`|affected-only invalidation|`fixtures/FIX-D09-021.json`|`ab7ec1443f183227a5053cd7c12d92d82fea449b6dcc95afc110bb6dd41e2c24`|`python .pipd/tests/check_drift_scope.py fixture.json`|0|`pkg:Z remains current`|remove temp fixture/output|`.pipd/evidence/FIX-D09-021.json`|
|`FIX-D09-022`|rollback absent|`fixtures/FIX-D09-022.json`|`85ca8d0d6ffd6260d03e9c94b5bf65ca7ec243186da5795d9035b4348a6620cc`|`python .pipd/tests/check_rollback.py fixture.json`|3|`invariant=ROLLBACK_REQUIRED`|remove temp fixture/output|`.pipd/evidence/FIX-D09-022.json`|
|`FIX-D09-023`|fork gets release secret|`fixtures/FIX-D09-023.json`|`c16c414a225b983f19cc65b1205f4ed7e234630324c6ce38a8db2dfd6127bb27`|`python .pipd/tests/check_fork_trust.py fixture.json`|5|`invariant=UNTRUSTED_RELEASE_CREDENTIAL`|remove temp fixture/output|`.pipd/evidence/FIX-D09-023.json`|
|`FIX-D09-024`|cache poisoning|`fixtures/FIX-D09-024.json`|`34e69bc81c46307ba35a0b21fe341254d730d8f199a73cf40482b726298b8a28`|`python .pipd/tests/check_release_input.py fixture.json`|3|`invariant=UNTRUSTED_RELEASE_INPUT`|remove temp fixture/output|`.pipd/evidence/FIX-D09-024.json`|

The fixture hash is over the exact minimal JSON payload shown by the fixture definition used to generate this ledger. A target materialization tool may write those payloads to the listed paths and MUST verify the hash before execution.



<a id="doc09-tool-qualification"></a>
# 22｜Per-Tool Qualification / Exit Matrix

|tool / capability|installation/materialization|binding|functional|boundary|negative|rollback|uninstall|provider-off|residue|evidence|
|---|---|---|---|---|---|---|---|---|---|---|
|PIPD CI ABI|N/A internal|manifest/ABI version|neutral validator|no provider authority|bad subject/exit mapping|restore previous ABI adapter|N/A|switch adapter|no provider-owned truth|ConformanceRun|
|GitHub Actions|workflow files materialize|ruleset/check binding|required workflow executes|no release secret on untrusted PR|skip/wrong subject/mutable pin|restore previous workflow|remove workflow after ruleset detach|GitLab/Jenkins/Buildkite|status context/ruleset cleanup|workflow+ruleset receipts|
|actions/checkout|full SHA present|workflow step|source checkout|persist-credentials false|mutable tag|restore prior SHA|remove step if no longer needed|provider-native checkout|credentials/worktree|workflow receipt|
|actions/setup-python|full SHA present|Python 3.13 reference|runtime available|lock install required|unlocked dependency install|restore prior SHA/runtime|remove step|vendored container|tool cache|env receipt|
|upload/download-artifact|full SHA present|named artifact|fresh transfer|digest equality required|digest mismatch|restore prior pins|remove after replacement|content-addressed store|retention/artifact refs|digest receipts|
|actions/attest|full SHA present|authorized release job|attestation created|creation != verify|missing id-token/subject mismatch|restore prior pin|remove after trust-policy update|cosign|attestation refs|attestation receipt|
|gh attestation verify|CLI materialized|repo/subject policy|verification succeeds|exact digest/signer policy|wrong owner/digest|restore prior CLI/policy|remove CLI|cosign verify|trust config/cache|verification receipt|
|Syft reference generator|binary/container materialized|SBOMGeneratorBinding|CycloneDX output|no acceptance authority|known component omitted|switch qualified generator|remove binary/image/cache|alternate generator/native export|cache/output paths|SBOMReceipt|
|Gitleaks|qualified package/action|rules/baseline binding|detect known secret|redaction/no release authority|seeded secret missed|switch scanner|remove binary/action/baseline|alternate scanner|cache/baseline/status|qualification receipt|
|OpenSSF Scorecard|qualified CLI/action|posture config|report generated|nested runtime dependencies reviewed|mutable nested image|CLI/container digest or omit|remove action/config|other posture signal|status/report artifact|qualification receipt|

No generic provider-off paragraph may substitute for these tool-specific exit semantics.


<a id="doc09-evidence"></a>
# 23｜Evidence / Readback Contract
Minimum release-grade receipt:
```yaml
evidence_id:
evidence_type:
subject_id:
subject_version:
content_hash:
artifact_digest:
environment:
tool_id:
tool_version:
tool_pin_or_digest:
adapter_id:
adapter_version:
procedure:
command:
exit_code:
expected_result:
actual_result:
first_failing_invariant:
timestamp:
maker_operator:
checker:
oracle_ref:
artifacts:
evidence_hash:
currentness:
invalidated_by: []
```

A PASS that cannot answer “exactly which subject, version, hash, environment, procedure and checker does this prove?” is not release-grade evidence.


<a id="doc09-failure"></a>
# 24｜Failure / Degrade / TT / CR

The r1 generic failure matrix remains valid, but r2 additionally makes named upstream blockers first-class. No generic `TOOL_FAILURE` record may erase CR-003/010/011/012, validator-environment, SBOM-generator, Scorecard nested-runtime or Gitleaks qualification state.

|CR/Risk|Status|Closure owner|Close criteria|Blocking scope|
|---|---|---|---|---|
|CR-003 Release artifact store/registry|OPEN_TYPED_SLOT|target PD / release owner|provider/store, immutable/content-addressed guarantee, auth, retention, download, provider-off all bound|release lane only|
|CR-010 Scorecard nested runtime image caveat|OPEN_UNTIL_QUALIFIED|security/tool admission owner|nested image/dependency digest reviewed or CLI/container digest path used|Scorecard adoption only|
|CR-011 GitHub ruleset availability/config|OPEN_UNTIL_READBACK|repo admin / CI adapter owner|required context read back from ruleset/branch protection; unavailable route recorded|merge enforcement only|
|CR-012 CODEOWNERS identities|OPEN_IF_PROFILE_REQUIRES|repo governance owner|exact reviewer identities/team refs bound and current|review/approval gate only|
|CR-VALENV Validator environment lock|OPEN_UNTIL_PD_BIND|validator environment owner|hash-locked pip set or vendored/attested container digest|CI validator only|
|CR-SBOMGEN SBOM generator|OPEN_UNTIL_PD_BIND|release toolchain owner|qualified generator exact version/digest + fixture pass|SBOM evidence only|
|R-007 Mutable nested action runtime|ACTIVE_CONTROLLED|security owner|outer full SHA plus nested dependency/image review|affected action only|
|R-GITLEAKS-8301 Qualification signal|ACTIVE_CONTROLLED|security/test owner|known-secret positive fixture passes selected build|Gitleaks adoption only|
|R-CYCLONEDX-2 Tool support/currentness|WATCH|SBOM owner|target consumers/generator support verified before any future profile migration|SBOM profile only|

Closure is scoped: a stale Scorecard qualification cannot invalidate unrelated PI Product Truth; a missing artifact store binding blocks only the affected release lane.


<a id="doc09-change"></a>
# 25｜Change / Supersession / Affected-Only Invalidation
Change classes monitored by DOC-09 include standard version/hash, tool/action pin, license, CVE/security posture, CI provider, runner, project manifest, workflow, release artifact, SBOM/provenance/attestation identity and signer/workflow policy.

Algorithm:
1. register changed node with old/new identity and reason;
2. compute reverse dependency frontier;
3. invalidate only nodes whose dependency-edge semantics require recompile/rebind/retest;
4. preserve unrelated nodes and receipts;
5. record `invalidated_by`, prior hash and affected gates;
6. route to TechnologyAdmission, PD rebind, test rerun, CR or Release Authority as appropriate;
7. recompute affected gate status;
8. forbid stale downstream current labels.

Neither “any change → global reset” nor “upstream changed → downstream remains current” is conformant.

<a id="doc09-sod"></a>
# 26｜Roles / SoD / Approval
|Role|DOC-09 duty|May approve own work?|
|---|---|---|
|Maker|authors workflow/tooling/release artifacts|No for Independent PASS; profile policy governs ordinary self-check|
|CI/Tooling Owner|owns neutral ABI implementation/adapters/currentness|cannot grant ExecutionAdmission or Release Authority|
|Security Checker|checks threat/permission/pin/secret/supply-chain controls|must be distinct where ASSURED/high-risk policy requires|
|Independent Checker|independently verifies subject-bound test/evidence|No maker self-assertion|
|Acceptor|accepts contract/functional evidence within assigned authority|not automatically Release Authority|
|Human Approver|issues scoped approval where required|must be subject/scope bound|
|Release Authority|makes final release decision|cannot be replaced by workflow/provider|
|Operator|executes runbook within permission|does not gain authority from tool success|
|Receiver|consumes handoff/release packet|must validate refs/subject before use|


<a id="doc09-provider-off"></a>
# 27｜Provider-Off / Uninstall / Residue

Provider/tool exit follows:

```text
freeze affected mutation
→ inventory canonical objects owned outside provider
→ materialize replacement path
→ run parity + negative + permission + rollback fixtures
→ update required-check/ruleset/trust policy
→ disable old integration
→ revoke provider credentials/tokens
→ remove package/action/workflow/config
→ purge caches/runtime images/local state as policy requires
→ verify no stale status context or hidden dependency remains
→ emit provider-off/residue receipt
```

Historical evidence is not deleted merely because a provider is removed; it remains immutable provenance with supersession/invalidation metadata.

Per-tool details are normative in §22.



<a id="doc09-source-coverage"></a>
# 28｜Source Coverage Ledger

|source family|coverage kind|DOC-09 materialization|
|---|---|---|
|P0 production instruction|NORMATIVE_TASK|source-bound snapshot/hash + atomic/per-tech/test denominators|
|P1 blueprint|NORMATIVE_BLUEPRINT|CI ABI, action baseline, workflows, exact-set tooling, release lane, runbook/risk|
|P2 canonical standard|NORMATIVE_STANDARD|state/claim/profile/schema/evidence/security boundaries|
|P3 skeleton|NORMATIVE_PACKAGE_ARCH|DOC-09 responsibility, named donor/technology/workflow crosswalks|
|P4 lifecycle discussion|DESIGN_INTENT|minimum-sufficient architecture, slice overlap, PD vs DEV boundary|
|DOC-00..08|SIBLING_ALIGNMENT|ownership/read-write-reference matrix; no takeover|
|AUDIT|REPAIR_CONTROLLER|B/M/S/L findings mapped in Appendix A|
|r1|SUPERSEDED_RETAINED_BASELINE|strong architecture retained; false/partial completion claims replaced|



<a id="doc09-atomic"></a>
# 29｜Atomic Requirement Coverage Ledger — Stable Anchor Targets

This ledger deliberately uses **stable HTML anchors**, not mutable section numbers. The build validator resolves every `#doc09-*` target against the final physical Markdown.

|requirement_id|name|source|atomic requirement|owner|body target|SPEC|TEST|ORACLE|gate|evidence|failure state|status|
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|`AR-D09-001`|Authority|P0-INSTR/P1/P2/P3/P4|Authority/read order/full-scan source binding|DOC-09|`#doc09-authority`|`SPEC-D09-AUTH`|`FIX-D09-001`|`OR-D09-001`|SOURCE_GATE|source manifest|RESOLUTION_FAILURE|CLOSED_DESIGN|
|`AR-D09-002`|Claim boundary|P2/P3|CI/release/tool success never self-promotes lifecycle claims|DOC-09|`#doc09-claim`|`SPEC-D09-CLAIM`|`FIX-D09-010`|`OR-D09-010`|CLAIM_GATE|claim receipt|HOLD|CLOSED_DESIGN|
|`AR-D09-003`|Sibling boundary|P3/P5|DOC-09 consumes but does not take over DOC-00..08 authority|DOC-09|`#doc09-sibling`|`SPEC-D09-SIB`|`FIX-D09-005`|`OR-D09-005`|BOUNDARY_GATE|ownership matrix|SEMANTIC_FAILURE|CLOSED_DESIGN|
|`AR-D09-004`|CI ABI|P1/P3|Provider-neutral command/report/exit contract|DOC-09|`#doc09-ci-abi`|`SPEC-D09-CIABI`|`FIX-D09-001`|`OR-D09-001`|CI_GATE|conformance report|SCHEMA_FAILURE|CLOSED_DESIGN|
|`AR-D09-005`|Required check|P1/P3|Skipped/missing/stale required check is non-PASS|DOC-09|`#doc09-required-check`|`SPEC-D09-RCHECK`|`FIX-D09-002`|`OR-D09-002`|MERGE_GATE|required-check receipt|SEMANTIC_FAILURE|CLOSED_DESIGN|
|`AR-D09-006`|Merge queue|P1/P3|merge_group subject validated when queue enabled|DOC-09|`#doc09-github-ci`|`SPEC-D09-GHA`|`FIX-D09-003`|`OR-D09-003`|MERGE_GATE|adapter receipt|SEMANTIC_FAILURE|CLOSED_DESIGN|
|`AR-D09-007`|Action baseline|P1/AUDIT|Known reference full SHAs retained + target re-pin|DOC-09|`#doc09-action-baseline`|`SPEC-D09-PIN`|`FIX-D09-004`|`OR-D09-004`|CURRENTNESS_GATE|pin ledger|CURRENTNESS_STALE|CLOSED_DESIGN|
|`AR-D09-008`|Release chain|P1/P3|Build→Transfer→Attest→Verify→Release Gate|DOC-09|`#doc09-release`|`SPEC-D09-SCL`|`FIX-D09-011`|`OR-D09-011`|RELEASE_GATE|chain receipts|SUPPLY_CHAIN_MISMATCH|CLOSED_DESIGN|
|`AR-D09-009`|Digest continuity|P1/P3|Fresh transfer digest equals build digest|DOC-09|`#doc09-release`|`SPEC-D09-DIGEST`|`FIX-D09-011`|`OR-D09-011`|RELEASE_GATE|digest receipt|SUPPLY_CHAIN_MISMATCH|CLOSED_DESIGN|
|`AR-D09-010`|SBOM generator/format|P1/P3/AUDIT|Concrete generator binding + same artifact subject|DOC-09|`#doc09-sbom`|`SPEC-D09-SBOM`|`FIX-D09-014`|`OR-D09-014`|RELEASE_GATE|SBOMReceipt|SUPPLY_CHAIN_MISMATCH|CLOSED_DESIGN|
|`AR-D09-011`|SLSA/Attestation|P3/AUDIT|SLSA v1.2 crosswalk; create != verify|DOC-09|`#doc09-sbom`|`SPEC-D09-ATTEST`|`FIX-D09-012`|`OR-D09-012`|RELEASE_GATE|verification receipt|ATTESTATION_UNVERIFIED|CLOSED_DESIGN|
|`AR-D09-012`|Release Authority|P1/P2|Workflow cannot self-authorize RELEASED|DOC-09|`#doc09-release`|`SPEC-D09-RA`|`FIX-D09-020`|`OR-D09-020`|RELEASE_GATE|release decision ref|RELEASE_AUTHORITY_MISSING|CLOSED_DESIGN|
|`AR-D09-013`|dist tool|P1/P3/AUDIT|Executable exact-set deterministic distribution|DOC-09|`#doc09-tools`|`SPEC-D09-DIST`|`FIX-D09-001`|`OR-D09-001`|DIST_GATE|distribution manifest|SCHEMA_FAILURE|CLOSED_DESIGN|
|`AR-D09-014`|tree validator|P1/P3/AUDIT|Executable tree/currentness/permission/86-ID validator|DOC-09|`#doc09-tools`|`SPEC-D09-TREE`|`FIX-D09-017`|`OR-D09-017`|CI_GATE|conformance report|SEMANTIC_FAILURE|CLOSED_DESIGN|
|`AR-D09-015`|drift|P1/P3|Executable affected-only invalidation|DOC-09|`#doc09-tools`|`SPEC-D09-DRIFT`|`FIX-D09-021`|`OR-D09-021`|DRIFT_GATE|drift graph|INVALIDATED|CLOSED_DESIGN|
|`AR-D09-016`|Validator environment|P1/AUDIT|hash-locked or vendored/attested validator runtime|DOC-09|`#doc09-validator-env`|`SPEC-D09-VALENV`|`FIX-D09-017`|`OR-D09-017`|CI_GATE|environment receipt|CURRENTNESS_STALE|CLOSED_DESIGN|
|`AR-D09-017`|Repository enforcement|P1/AUDIT|Required check bound to ruleset/branch protection with readback|DOC-09|`#doc09-enforcement`|`SPEC-D09-ENFORCE`|`FIX-D09-006`|`OR-D09-006`|MERGE_GATE|ruleset readback|TEMP_CLOSED|CLOSED_DESIGN|
|`AR-D09-018`|Artifact store|P1/AUDIT|Typed immutable/content-addressed release store slot|DOC-09|`#doc09-enforcement`|`SPEC-D09-STORE`|`FIX-D09-011`|`OR-D09-011`|RELEASE_GATE|store binding|TEMP_CLOSED|CLOSED_DESIGN|
|`AR-D09-019`|Waves|P3|A–J adoption waves preserve overlap semantics|DOC-09|`#doc09-waves`|`SPEC-D09-WAVES`|`FIX-D09-021`|`OR-D09-021`|WAVE_GATE|wave receipt|HOLD|CLOSED_DESIGN|
|`AR-D09-020`|Runbook|P1/P3/AUDIT|Operator steps include exact commands and claim ceilings|DOC-09|`#doc09-runbook`|`SPEC-D09-RUNBOOK`|`FIX-D09-018`|`OR-D09-018`|RUNBOOK_GATE|runbook receipt|HOLD|CLOSED_DESIGN|
|`AR-D09-021`|Named donor denominator|P3/AUDIT|Every DOC-09 mapped donor identity has terminal crosswalk|DOC-09|`#doc09-donors`|`SPEC-D09-DONOR`|`FIX-D09-001`|`OR-D09-001`|TECH_GATE|crosswalk ledger|TEMP_CLOSED|CLOSED_DESIGN|
|`AR-D09-022`|Technology records|Instruction/AUDIT|Every named technology has full field denominator|DOC-09|`#doc09-tech`|`SPEC-D09-TECH`|`FIX-D09-004`|`OR-D09-004`|TECH_GATE|technology record|TEMP_CLOSED|CLOSED_DESIGN|
|`AR-D09-023`|Anti-degradation|Instruction/AUDIT|Identity preserved for ADOPT/REFERENCE/TRANSLATE/EVAL/etc|DOC-09|`#doc09-anti-degrade`|`SPEC-D09-ANTID`|`FIX-D09-001`|`OR-D09-001`|TECH_GATE|crosswalk/readback|INVALIDATED|CLOSED_DESIGN|
|`AR-D09-024`|Currentness security|P1/AUDIT|Scorecard nested runtime + Gitleaks qualification + named CRs retained|DOC-09|`#doc09-currentness`|`SPEC-D09-CURR`|`FIX-D09-015`|`OR-D09-015`|CURRENTNESS_GATE|qualification receipt|CURRENTNESS_STALE|CLOSED_DESIGN|
|`AR-D09-025`|Security/permission|P1/P2/P3|Least privilege, fork trust, untrusted input, no scanner supremacy|DOC-09|`#doc09-security`|`SPEC-D09-SEC`|`FIX-D09-023`|`OR-D09-023`|SECURITY_GATE|security receipt|PERMISSION_BLOCKED|CLOSED_DESIGN|
|`AR-D09-026`|Test fixtures|Instruction/AUDIT|Executable fixture path/hash/command/expected machine output|DOC-09|`#doc09-fixtures`|`SPEC-D09-FIX`|`FIX-D09-024`|`OR-D09-024`|ASSURANCE_GATE|fixture evidence|SEMANTIC_FAILURE|CLOSED_DESIGN|
|`AR-D09-027`|Per-tool qualification|Instruction/AUDIT|Install/bind/function/boundary/negative/uninstall/provider-off|DOC-09|`#doc09-tool-qualification`|`SPEC-D09-QUAL`|`FIX-D09-019`|`OR-D09-019`|TECH_GATE|tool qualification receipt|TEMP_CLOSED|CLOSED_DESIGN|
|`AR-D09-028`|Evidence|P2/D04|Subject/version/hash/env/procedure-bound receipts|DOC-09|`#doc09-evidence`|`SPEC-D09-EVD`|`FIX-D09-005`|`OR-D09-005`|EVIDENCE_GATE|evidence packet|EVIDENCE_STALE|CLOSED_DESIGN|
|`AR-D09-029`|Failure/CR|P1/AUDIT|Named upstream CR/risk rows retained; fail closed|DOC-09|`#doc09-failure`|`SPEC-D09-FAIL`|`FIX-D09-020`|`OR-D09-020`|FAILURE_ROUTER|failure/CR record|TEMP_CLOSED|CLOSED_DESIGN|
|`AR-D09-030`|Change|P1/P2/P3|Affected-only invalidation|DOC-09|`#doc09-change`|`SPEC-D09-CHANGE`|`FIX-D09-021`|`OR-D09-021`|DRIFT_GATE|invalidation record|INVALIDATED|CLOSED_DESIGN|
|`AR-D09-031`|SoD|P2/D01|Maker≠Checker≠Acceptor for ASSURED; Release Authority separate|DOC-09|`#doc09-sod`|`SPEC-D09-SOD`|`FIX-D09-020`|`OR-D09-020`|ASSURED_GATE|role receipt|HOLD|CLOSED_DESIGN|
|`AR-D09-032`|Provider-off|Instruction/P3|Per-tool exit and residue proof|DOC-09|`#doc09-provider-off`|`SPEC-D09-OFF`|`FIX-D09-018`|`OR-D09-018`|EXIT_GATE|provider-off receipt|PROVIDER_UNAVAILABLE|CLOSED_DESIGN|
|`AR-D09-033`|Claim honesty|Instruction/AUDIT|No installed/bound/executed/released claim without evidence|DOC-09|`#doc09-claim`|`SPEC-D09-CLAIM2`|`FIX-D09-010`|`OR-D09-010`|CLAIM_GATE|delivery readback|HOLD|CLOSED_DESIGN|

Closure criteria:
- missing requirement = 0;
- unowned requirement = 0;
- invalid target anchor = 0;
- selected technology without full field denominator = 0;
- executable selected tool without qualification/exit record = 0;
- self-declared runtime/release PASS = 0.



<a id="doc09-acceptance"></a>
# 30｜r2 Repair Acceptance Gates

|Gate|r2 author-side result|Evidence / remaining runtime boundary|
|---|---|---|
|G01 mandatory sources|PASS|P0 instruction now hashed/source-bound; P1–P5/AUDIT/R1 manifest present|
|G02 full UTF-8 no sampling|PASS|strict full reads; line method=`str.splitlines()`|
|G03 authority order|PASS|explicit and unchanged|
|G04 DOC-09 scope|PASS|all DOC-09 donor/tooling/release obligations represented|
|G05 DOC00–08 alignment|PASS|ownership matrix; no takeover|
|G06 atomic closure|PASS|stable anchors + automated anchor resolver|
|G07 neutral CI ABI|PASS|command/report/exit materialized|
|G08 reference CI adapter|PASS_AUTHOR_SIDE|complete P1 workflow embedded; target repository binding remains runtime/PD fact|
|G09 release lane|PASS_AUTHOR_SIDE|complete reference workflow + digest/SBOM/attest/verify path embedded|
|G10 SBOM/provenance/attestation|PASS_AUTHOR_SIDE|generator profile, SLSA, receipts, separation materialized|
|G11 executable tooling|PASS_AUTHOR_SIDE|3 full Python source assets embedded + syntax checked|
|G12 adoption waves|PASS|A–J retained|
|G13 runbook|PASS|18 exact commands/actions + claim ceilings|
|G14 technology dispositions|PASS|full donor crosswalk + full technology records|
|G15 anti-degradation|PASS|identity preservation all dispositions; selected-item non-silent-drop|
|G16 currentness/license strategy|PASS_DESIGN|every record has license/currentness/TTL strategy; target exact facts remain typed late-bound|
|G17 security/permission/SoD|PASS_DESIGN|nested-runtime, fork trust, least privilege, authority separation|
|G18 tests/oracles/fixtures|PASS_AUTHOR_SIDE|24 fixture IDs/paths/hashes/commands/expected machine outputs + per-tool matrix|
|G19 evidence/readback|PASS_DESIGN|subject-bound receipt model; final delivery hash supplied externally|
|G20 failure/TT/CR/rollback|PASS|named CR/risk retention + scoped closure|
|G21 affected-only invalidation|PASS|retained + executable drift source|
|G22 claim honesty|PASS|no target installed/bound/executed/released claims|
|G23 non-template homogeneity|PASS|code/workflow/schema/table/runbook/ledger by responsibility|
|G24 full substantive body|PASS_AUTHOR_SIDE|reference assets are materially embedded, not prose-only|
|G25 single MD|PASS|single Markdown delivery|
|G26 physical readback|PASS_WITH_EXTERNAL_SHA_RECEIPT|final file reopened after write; bytes/splitlines/UTF-8 checked; whole-file SHA cannot truthfully self-embed and is supplied with download response|

No gate above claims Independent PASS, Human Ratification, target repo binding, real CI activation, release execution or production verification.



<a id="doc09-readback"></a>
# 31｜Physical Readback Contract

A cryptographic whole-file SHA-256 cannot be embedded inside the same file while simultaneously remaining the SHA-256 of the final bytes; writing the hash changes those bytes. r1's placeholder was therefore replaced by a **non-self-referential delivery rule**:

1. final MD is written;
2. final MD is reopened as strict UTF-8;
3. `bytes` and `Python str.splitlines()` are measured;
4. replacement-character and forbidden-placeholder checks run;
5. whole-file SHA-256 is computed **after final write**;
6. that SHA-256 is returned as the external delivery receipt accompanying the single MD download.

Embedded readback fields below contain only measurements that can be truthfully self-contained without cryptographic self-reference.

```yaml
artifact_id: PIPD_LS_DOC-09
version: 2026-10-07_r2_HIGH_RETENTION_AUDIT_PATCHED_FULL_REPAIR_FULL_SUBSTANTIVE_BODY
physical_readback_state: AUTHOR_SIDE_REOPENED
line_count_method: "Python str.splitlines()"
bytes: 144948
splitlines: 2451
utf8: PASS
replacement_character_count: 0
forbidden_unresolved_authoring_markers: 0
whole_file_sha256: "EXTERNAL_DELIVERY_RECEIPT_BY_DESIGN"
self_hash_rationale: "SHA-256 of final bytes cannot truthfully be embedded into those same final bytes"
```



<a id="doc09-zero-rediscovery"></a>
# 32｜Receiver Zero-Rediscovery Checklist

Before real provider binding or release execution, receiver answers from this document + target PD facts only:

- WHY: protected lifecycle/release invariant?
- WHAT: exact subject/version/hash?
- WHERE: exact repo/provider/environment?
- HOW: exact command/workflow/tool path?
- ALLOWED SCOPE: permissions/network/secret/action boundaries?
- FORBIDDEN SCOPE: authority this tool/provider cannot acquire?
- ENTRY GATE: TechnologyAdmission/RepoContext/ExecutionAdmission/currentness?
- STOP CONDITION: first failing invariant / HOLD / TT / CR?
- ROLLBACK: exact replacement/rollback/provider-off?
- EXPECTED EVIDENCE: exact receipt/report path?
- RELEASE: separate Release Authority decision present?

If the receiver must rediscover Product Truth, canonical ownership, acceptance semantics or core technology selection, upstream PI/PD closure is defective.



# Appendix A｜AUDIT Finding Closure Matrix

|Audit finding|r2 closure|
|---|---|
|B-01 Physical readback false PASS|No self-hash fiction; splitlines/bytes/UTF-8 are author-side re-read, while final whole-file SHA-256 is delivered as external transport receipt because a cryptographic file cannot truthfully contain its own final hash. G26 uses that external receipt.|
|B-02 Atomic ledger target drift|All requirements now target stable explicit HTML anchors; automated resolver checks every `#doc09-*` target exists.|
|B-03 Tooling not executable|Full fenced source for `pipd_dist.py`, `pipd_tree_validate.py`, `pipd_drift.py`; syntax checked during build; tool contract includes paths/dependencies/exits/tests.|
|M-01 GitHub CI regression|Complete P1 reference workflow restored with full-SHA pins and report upload.|
|M-02 Release workflow regression|Complete P1 Build→Transfer→Attest→Verify workflow restored and extended with SBOM/release-gate input hooks.|
|M-03 exact action pin loss|P1 baseline version+full SHA retained separately from target project currentness re-pin.|
|M-04 donor denominator incomplete|NOBJ/ECP/TQ/workflow DOC-09 identities explicitly crosswalked.|
|M-05 per-tech field denominator|Every technology record has all instruction-required fields plus checked_at/TTL/claim state.|
|M-06 anti-degradation narrow|Identity preservation applies to every terminal disposition; runtime materialization obligations apply only to selected/adopted executable items.|
|M-07 dist denominator|P1 exact 22 schemas / 20 tests / 86 requirements code retained.|
|M-08 tree validator logic|P1 executable tree validator retained, including 86/86 identity and TEST/ORACLE preservation.|
|M-09 validator environment|Hash-locked-or-vendored binding is first-class with lock template and blocking rule.|
|M-10 required check enforcement|RepositoryEnforcementBinding + ruleset/branch-protection readback + CR-011/CR-012 routes.|
|M-11 artifact store slot|ReleaseArtifactStoreBinding typed late-bound contract added.|
|M-12 SBOM generator|Syft reference generator profile + target-bound exact pin/digest and executable command path added.|
|M-13 SLSA v1.2|Explicit REFERENCE/TRANSLATE record and fixture crosswalk added.|
|M-14 Scorecard nested runtime|Nested image/dependency review required; outer action SHA alone is insufficient.|
|M-15 Gitleaks v8.30.1|QUALIFY_BEFORE_USE + seeded-secret positive fixture; never sole release oracle.|
|M-16 named CR/risk retention|CR-003/010/011/012 + validator/SBOM generator + risk rows retained.|
|S-01 malformed currentness table|Replaced by machine-oriented action baseline + technology records; no malformed six-value/five-column table.|
|S-02 section trace drift|Stable anchors replace section numbers.|
|S-03 line-count method|`Python str.splitlines()` is the single declared count method.|
|L-01 baseline vs runtime pin|Two-level `reference_baseline` + `target_project_binding` model.|
|L-02 disposition != adoption contract|Per-item full record + qualification matrix required.|
|L-03 generic provider-off insufficient|Per-tool uninstall/provider-off/residue rules materialized.|


# Appendix B｜Reference Asset Inventory

|asset|embedded status|author-side validation|
|---|---|---|
|`.github/workflows/pipd-required.yml`|MATERIALIZED_IN_MD|retained from P1 baseline|
|`.github/workflows/pipd-release.yml`|MATERIALIZED_IN_MD|retained from P1 + SBOM/release-gate extensions|
|`.pipd/tools/pipd_dist.py`|MATERIALIZED_IN_MD|Python syntax PASS|
|`.pipd/tools/pipd_tree_validate.py`|MATERIALIZED_IN_MD|Python syntax PASS|
|`.pipd/tools/pipd_drift.py`|MATERIALIZED_IN_MD|Python syntax PASS|
|`.pipd/project/toolchain/pipd-validator.requirements.lock.example`|MATERIALIZED_TEMPLATE|activation blocked until target hashes resolved|
|`ReleaseArtifactStoreBinding`|MATERIALIZED_SCHEMA|target provider late-bound by design|
|`RepositoryEnforcementBinding`|MATERIALIZED_SCHEMA|target ruleset/protection late-bound by design|

# Appendix C｜Final Claim Ceiling

```text
PIPD_LS_DOC-09 r2
= HIGH_RETENTION_AUDIT_PATCHED_FULL_REPAIR_FULL_SUBSTANTIVE_BODY
+ LOCAL_EXECUTABLE_REFERENCE_ASSETS_MATERIALIZED
+ SOURCE_BOUND_ATOMIC_TRACE_REPAIRED
+ FULL_NAMED_DONOR_AND_TECHNOLOGY_DESIGN_CLOSURE

!= TARGET_REPOSITORY_BOUND
!= INSTALLED
!= EXECUTED
!= INDEPENDENT_PASS
!= HUMAN_RATIFIED
!= RELEASED
!= PRODUCTION_PASS
```
