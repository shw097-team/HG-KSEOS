---
artifact_id: PIPD_LS_DOC-04
external_formal_name: "Pre-Implementation & Pre-Dev Lifecycle Specification — DOC-04 Traceability / Assurance Data Contract"
internal_short_name: PIPD_LS_DOC-04
artifact_type: FULL_SUBSTANTIVE_BODY_HIGH_RETENTION_FULL_REPAIR
subject_id: "PIPD-LIFECYCLE-SPEC@1.1.0/DOC-04"
version: "2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY"
status: CURRENT
owner: "PIPD_LS_DOC04_CANONICAL_WRITER_ROLE"
source_refs:
  - "P0-INSTR-D04-2026-10-07-r1#appendix-e-p0-instruction-snapshot"
  - "P1-BP@1.1.0-r2_FULL_REPAIR"
  - "P2-STD@1.1.0"
  - "P3-SKL@1.1.0-SKELETON-r2_FULL_REPAIR"
  - "P4-DISC@2026-10-06"
  - "P4-RULE@current-mounted"
  - "P5-DOC00@2026-10-07_r2"
  - "AUDIT-PIPD-LS-DOC04-2026-10-07-R1"
supersedes:
  - artifact: "PIPD_LS_DOC-04_2026-10-07_r1_FULL_SUBSTANTIVE_BODY.md"
    sha256: "ffefd02b35c0e2b5416ac483b43d8e1aaa7ad5db9f5e05c2f2e465da66fc853d"
dependencies:
  - "PIPD-LIFECYCLE-SPEC@1.1.0"
  - "PIPD-LIFECYCLE-BLUEPRINT@1.1.0-r2_FULL_REPAIR"
  - "PIPD_LS_skeleton@1.1.0-SKELETON-r2_FULL_REPAIR"
consumers:
  - "DOC-02 requirement/spec compiler"
  - "DOC-03 Pre-Dev binding compiler"
  - "DOC-05 handoff/effect boundary"
  - "DOC-07 conformance/test/oracle"
  - "DOC-08 AI consumption/adapters"
  - "DOC-09 CI/release/readback"
  - "Human/AI/Tool/Validator consumers"
created_at: "2026-10-07T12:56:00+08:00"
generated_at: "2026-10-07T12:56:00+08:00"
timezone: Asia/Taipei
content_hash: "c7419597bbb4f6698cc443d25c3f8a4c053cc0de73ff6f78f2589989cf6d0a5c"
content_hash_rule: "SHA-256 over final UTF-8/LF artifact bytes after replacing only the top-level content_hash value with 64 ASCII zeroes; no BOM"
weight_profile: STANDARD
target_profile: CUSTOM
profile_version: "1.1.0"
extensions:
  - "PIPD_DOC_COMPONENT_D04_TRACE_ASSURANCE@1"
maker: "GPT-5.6-Sol_AUTHORING_INSTANCE"
checker: "SAME_MODEL_LOCAL_CONFORMANCE_CHECKER"
acceptor: null
release_authority: null
human_approver: null
claim_ceiling: "LOCAL_DOCUMENT_MATERIALIZED_AND_AUTHOR_SIDE_CONFORMANCE_VALIDATED"
standard_id: PIPD-LIFECYCLE-SPEC
standard_version: "1.1.0"
blueprint_id: PIPD-LIFECYCLE-BLUEPRINT
blueprint_version: "1.1.0"
blueprint_revision: "r2_FULL_REPAIR"
repair_mode: "HIGH_RETENTION_FULL_REPAIR_NO_ARCHITECTURE_RESET"
repair_controller:
  artifact_id: "AUDIT-PIPD-LS-DOC04-2026-10-07-R1"
  sha256: "58b3508a6696a7845c3289e66e55c890f79ccc89595f59bbc1cc152cb6d3d127"
  verdict_consumed: "FAIL_REPAIR_REQUIRED"
source_authority_order:
  - "P0 current user PATCH task + embedded P0 production instruction snapshot"
  - "P1 PIPD lifecycle blueprint 1.1.0 r2_FULL_REPAIR"
  - "P2 PIPD canonical standard 1.1.0"
  - "P3 PIPD_LS skeleton 1.1.0-SKELETON-r2_FULL_REPAIR"
  - "P4 lifecycle discussion + canonical-authority engineering ruling"
  - "P5 PIPD_LS_DOC-00 sibling alignment only"
  - "P6 mounted GRP/ECP/TQAEP supporting artifacts"
  - "P7 2026 official external currentness evidence, SUPPORT only"
  - "P8 model prior knowledge"
materialization_status: "DOC04_R2_HIGH_RETENTION_FULL_REPAIR_MATERIALIZED"
runtime_execution: NOT_EXECUTED
independent_pass: NOT_CLAIMED
human_ratification: NOT_CLAIMED
release_status: NOT_RELEASED
production_status: NOT_PRODUCTION_VERIFIED
open_tt: []
open_cr: []
canonical_namespace: "urn:pipd:canonical-standard:1.1"
companion_namespace: "urn:pipd:doc04:1.1:companion"
schema_dialect: "https://json-schema.org/draft/2020-12/schema"
portable_mount_profile:
  id: GRP00_PORTABLE_MOUNT_PROFILE
  version: v2026.08.07-final-r2
  sha256: "64f6998aafd4072cc6cbbe8f8d573339ac095920ee8716e3a7200226fc8822ec"
  source_corpus_manifest_sha256: "6d8be07435675fe654486e8238cd9f80c8176a06336b218ce911228abe9aecfe"
author_side_validation:
  mode: "SAME_MODEL_LOCAL_CONFORMANCE_ONLY"
  independent: false
  runtime_target_execution: false
  claim_rule: "author-side full-scan, companion-validator tests, schema/specimen validation and external delivery readback support document materialization only"
post_write_readback:
  mode: "EXTERNAL_DELIVERY_RECEIPT_REQUIRED_TO_AVOID_SELF_HASH_CIRCULARITY"
  receipt_subject: "PIPD_LS_DOC-04/2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY"
  embedded_self_hash_claim: false
---

# 《PIPD_LS_DOC-04》— Traceability / Assurance Data Contract

> **r2 HIGH_RETENTION FULL_REPAIR** — engineering integration/cover/replace successor to r1. Core narrow-waist architecture retained; audit S1/S2/S3 repair deltas are materialized in-body. No architecture reset, no runtime/Independent/Human/Release/Production claim.

本文件是 `PIPD-LIFECYCLE-SPEC@1.1.0` 的 DOC-04 定案正文級實質規格。它把來源、意圖、父／原子需求、SPEC、Acceptance、Verification/Oracle、Evidence Expectation、Actual Evidence、Deliverable、Gate 與 Pre-Dev binding 編譯成一條**可追溯、可拒收、可失效、可重播、可機器檢查、不可自我證明成功**的 assurance narrow waist。

DOC-04 的核心義務不是「證明系統已成功」，而是確保任何成功、失敗、暫停、N/A、失效與重新驗證，都有**唯一可定位的 subject、版本、hash、責任人、oracle、證據路徑與受影響依賴**。文件 materialization 與 runtime truth 永遠分離。

# 0｜Artifact Identity / Legal Role / Claim Boundary

## 0.1 Canonical responsibility

DOC-04 是以下語意的 canonical writer／contract owner：

- requirement traceability；
- acceptance linkage；
- verification/oracle linkage；
- evidence expectation；
- subject-bound evidence；
- evidence identity、freshness、retention、replay；
- documentation grounding；
- effect observation；
- effect reconciliation data integrity；
- forward/reverse orphan detection；
- assurance data integrity；
- affected-only invalidation / replay semantics；
- deliverable/gate/PD-binding trace closure。

其核心 narrow waist 固定為：

```text
SRC
→ INTENT
→ REQ(parent + atomic child)
→ SPEC
→ ACC
→ VER(TEST / ORACLE)
→ EVD_EXPECTATION
→ EVD
→ DEL
→ GATE
→ PD_BINDING
```

任何把它壓平成 `REQ → TEST → PASS` 的實作均屬 semantic loss，因為 source、acceptance、evidence expectation、deliverable、gate 與 binding 會失去獨立 identity 與 invalidation seam。

## 0.2 Canonical non-goals

DOC-04 **不**擁有：

- product semantic re-adjudication；
- TechnologyAdmission semantic truth；
- RepoContext / S2E / WorkOrder / ECP / TQAEP 的 canonical writing；
- runtime execution authorization；
- `ExecutionAdmission`；
- CI/release tooling ownership；
- release authority；
- Human approval authority；
- Independent Qualification authority；
- runtime、production 或 world-effect success 的自我宣告。

`DOCUMENT_MATERIALIZED`、`IMPLEMENTED`、`TEST_EXECUTED`、`VERIFIED`、`QUALIFIED`、`RELEASED`、`PRODUCTION_VERIFIED` 是不同 claim 層級；本文只 materialize contract 並完成 author-side local conformance/readback。

# 1｜Purpose / Scope / Failure Model

DOC-04 存在是為了消除四類常見工程失真：

1. **semantic-loss**：需求被傳遞成一句自然語言摘要，SPEC、Acceptance 或證據期待被省略；
2. **apparent-pass**：工具退出碼、CI 綠燈、模型自評或 provider `2xx` 被誤升格為產品 acceptance；
3. **evidence-drift**：舊 subject/version/hash 的 evidence 被拿來關閉新版本 gate；
4. **global-or-stale invalidation**：不是「任何改動全部重跑」，就是「上游已變但下游仍假裝 current」。

DOC-04 位於 PI/PD/execution/verification 之間的 assurance data plane。PI 建立 stable semantic contracts；PD 綁定 repo/provider/version/environment 等 late-bound facts；execution 產生 actual observations；DOC-04 定義如何把這些物件串成可機器檢查的 trace 與 evidence graph。它可以宣告某條 trace **完整、current、可驗證**，但不能把「具備證明路徑」偷換成「已經證明成功」。

# 2｜Authority, Source Grounding & No-Source-No-Norm

## 2.1 Conflict resolution order

發生命名漂移、歷史版本差異、重疊或衝突時，使用固定裁決序：

`P0 user task > P1 blueprint > P2 canonical standard > P3 skeleton > P4 discussion/ruling > P5 DOC-00 sibling > P6 mounted supporting artifacts > P7 external currentness SUPPORT > P8 model prior knowledge`。

外部網站、README、repository、研究或模型知識不得取得 PIPD semantic authority。若必要 normative source 缺失或 exact anchor 無法解析，受影響 claim 必須 `ABSTAIN` 或 `TEMP_CLOSED`，並開 scoped TT；不得用一般常識補成 canonical rule。

## 2.2 Frozen source baseline / Reproducible P0 grounding

r2 將 r1 的最高權威 provenance hole 關閉：原始 production instruction 已以**逐位元可重播的內嵌 snapshot** materialize 於 Appendix E，不再只依賴 conversation-local locator。

| Source ID | Artifact | Version / role | Authority | SHA-256 / stable locator |
|---|---|---|---|---|
| `P0-INSTR` | `P0-INSTR-D04-2026-10-07-r1` | original DOC-04 production instruction snapshot | `P0` | normalized-LF snapshot `3bd7ae052fa5279db14d2f0c4bc4b926af3f040712ad1d6de0c5a36b7cda91b2`; source physical bytes `6ebdcaeff40a2e49ff66165ff3a2bfef8ee55db2e0c7273499a2ca60403f31bc` / `#appendix-e-p0-instruction-snapshot` |
| `P0-PATCH` | current user PATCH directive | r2 repair authority | `P0` | materialized as r2 repair intent in front matter + §39; current interaction is authority envelope, not a portable external dependency |
| `P1-BP` | `Pre-Implementation_and_Pre-Dev_Lifecycle_Specification_總藍圖.md` | 1.1.0-r2_FULL_REPAIR | `P1` | `9a8323e5237c1555a76d9a75f706e3552d79c192915cc782b76b211c7f27d527` |
| `P2-STD` | `Pre-Implementation_and_Pre-Dev_Lifecycle_Specification_canonical_standard.md` | 1.1.0 | `P2` | `6f6aafece90b34e33786647e14fee840f5424893995b3164cbb52953a5c4f14a` |
| `P3-SKL` | `PIPD_LS_skeleton_2026-10-06_r2_FULL_REPAIR(1).md` | 1.1.0-SKELETON-r2_FULL_REPAIR | `P3` | `03bb3609dc67f85fa4b683a93736cf162e9047b6b253182aa3fdba11ba40cb28` |
| `P4-DISC` | `Pre-Implementation-PKG  Pre-Dev-PKG 生命週期規格_總討論(1).md` | 2026-10-06 export | `P4` | `be1858e860092fb1751bf0524cd22b6939138b6835ce8f452bfc30894f945a95` |
| `P4-RULE` | `PIPD 「canonical authority／生命週期」工程裁決.md` | current mounted | `P4` | `4ae876f856850e4f657cfb1df9cb926b08bdc353af040c3ecdd92faa651a7dc8` |
| `P5-DOC00` | `PIPD_LS_DOC-00_2026-10-07_r2_HIGH_RETENTION_FULL_REPAIR_FULL_SUBSTANTIVE_BODY(1).md` | 2026-10-07_r2 | `P5` | `be3a672ec20aa0e6b5e0e35097fc08de749bfe7f59f827d18e38aef67dd68ea4` |
| `AUDIT-R1` | `AUDIT_PIPD_LS_DOC-04_2026-10-07_r1_FULL_AUDIT_REPORT(1).md` | repair controller, EVAL not semantic SSOT | adopted by current P0 PATCH | `58b3508a6696a7845c3289e66e55c890f79ccc89595f59bbc1cc152cb6d3d127` |
| `P6-PROFILE` | `PORTABLE_MOUNT_PROFILE.md` | `v2026.08.07-final-r2` | P6 control support | `64f6998aafd4072cc6cbbe8f8d573339ac095920ee8716e3a7200226fc8822ec` |
| `P6-GRP02` | `GRP-02_ARCHITECTURE_AGENT.md` | architecture/agent support | P6 | `a6e840cc9dc9d5969b8438217d981d56efe517cf74322aed6869d4759d9f41c5` |
| `P6-GRP05` | `GRP-05_TOOLCHAIN_PROVIDER.md` | tool/provider/SBB support | P6 | `517e5160d403ee5435104eb45b888042670fb640dac42319b4dd25db9937dddd` |
| `P6-GRP06` | `GRP-06_ASSURANCE_SECURITY.md` | assurance/test/evidence support | P6 | `d4290ef7978864a877beb86a38bd9f019718f7011e50310496d020944ffccca0` |
| `P6-GRP08` | `GRP-08_RUNBOOK_HANDOFF.md` | handoff/evidence-return support | P6 | `7c4653d8bdf726a550ba4e6469cdcdfa78c3251a4252b4a44c98c0f554ab60ff` |
| `P6-GRP09` | `GRP-09_RELEASE.md` | readback/checksum/claim support | P6 | `02985d76b99f4922c2a50456b4ae5b35a46d2987be5e3fd9a646350370937767` |
| `P6-ECP` | `SWOF_ECP_SKILLS_PLUGIN_v2.0.1.md` | ECP supporting carrier | P6 | `eddc399cfe9d4490aaf234bbfc4fa9debe57dfdccc7a01e4d13dd5f9198d4d3f` |
| `P6-TQAEP` | `SWOF_TQAEP_SKILLS_PLUGIN_v2.0.1.md` | TQAEP supporting carrier | P6 | `728b6c6758ff6cb3345ba0dc9e9e8def6c589fd23a164eaabb89bfd1bc12049a` |

### P0 snapshot integrity rule

- Appendix E 的 snapshot bytes（不含外層 `~~~~text` fence）以 UTF-8/LF 計算 SHA-256，MUST 等於 `3bd7ae052fa5279db14d2f0c4bc4b926af3f040712ad1d6de0c5a36b7cda91b2`。
- 若 snapshot hash 不符，所有只由 P0-INSTR 支持的衍生 claim `TEMP_CLOSED`，不得以聊天記憶補洞。
- r2 的 repair controller 是 AUDIT，但 AUDIT 不取得產品/標準 semantic authority；其 finding 只有因 current P0 PATCH 明文採納而成為本次修補義務。

## 2.3 DocumentationGroundingRecord rule

每一個被 DOC-04 升格為 normative dependency 的來源 claim 必須有：

`grounding_id / source_id / source_version / source_hash / exact_locator / grounded_claim / retrieval_method / state / stale_invalidation_trigger`。

Grounding `state` 僅使用 canonical `GROUNDED | ABSTAIN | STALE | TEMP_CLOSED`。`模型知道`、`通常如此`、`README 說過`不是 source grounding。

# 3｜Sibling Ownership Boundary

| Document | Canonical ownership consumed by DOC-04 | DOC-04 may do | DOC-04 must not do |
|---|---|---|---|
| `DOC-00` | router/read order/state readback | provide trace/evidence status for projection | let DOC-00 become second writer |
| `DOC-01` | authority, lifecycle states, claims, SoD, change classes | enforce claim/role/invalidation predicates | redefine Constitution |
| `DOC-02` | PI requirements, atomicity, SPEC semantics, TechnologyAdmission, PI_READY | trace its IDs/versions/hashes | re-adjudicate Product Truth or technology selection |
| `DOC-03` | RepoContext, S2E, Seed/WO/ECP/TQAEP, PREDEV_READY | bind returned evidence to PD subjects | treat preparation object as execution authority |
| `DOC-05` | rejectable handoff, permission/effect intent, admission, rollback | own observation/reconciliation data contract and evidence promotion rule | grant permission or ADMIT |
| `DOC-06` | LITE/STANDARD/ASSURED + target profiles | apply profile-added evidence/test depth | let profile remove portable-core invariants |
| `DOC-07` | test/oracle/fixture reference and destructive verification | bind stable TEST/ORACLE IDs to trace/evidence | become second fixture/oracle catalog |
| `DOC-08` | AI adapter/read-order maturity | expose machine-readable trace for adapters | copy normative truth into prompts |
| `DOC-09` | CI/release/supply-chain/runbook/tooling | accept verified CI/attestation receipts as evidence artifacts | equate CI success with product acceptance |

**Seam rule:** DOC-04 owns *proof-path integrity*；sibling DOCs own the semantics of the objects being proved. A reference may be copied; canonical ownership may not.

# 4｜Requirement Narrow Waist — Node and Edge Contract

## 4.1 Node identity

| Node | Identity source | Canonical writer | Required identity material | Terminal/holding semantics |
|---|---|---|---|---|
| `SRC` | source registry / grounding | source owner + DOC-04 grounding | source ID, version, hash, exact locator, authority | GROUNDED / ABSTAIN / STALE / TEMP_CLOSED |
| `INTENT` | DOC-01/02 product/intent contract | DOC-01/02 | stable ID, owner, source refs, version/hash | CURRENT / SUPERSEDED / INVALIDATED |
| `REQ` | DOC-02 | DOC-02 | parent/child IDs, owner, criticality, applicability | CURRENT / HOLD / NOT_APPLICABLE / SUPERSEDED / INVALIDATED |
| `SPEC` | DOC-02 or owning sibling | owning sibling | stable ID, machine/prose locator, version/hash | CURRENT / HOLD / N/A / SUPERSEDED / INVALIDATED |
| `ACC` | PI contract | owning requirement domain; traced by DOC-04 | stable ID, observable predicate, checker, acceptor | DEFINED / HELD / SUPERSEDED / INVALIDATED |
| `VER` | DOC-07 registry / domain verifier | DOC-07 or domain verifier | TEST ID, ORACLE ID, fixture/method version | DEFINED / NOT_EXECUTED / EXECUTED |
| `EVD_EXPECTATION` | PI/TQAEP planning | DOC-04 data contract + producer domain | evidence type, subject, procedure, freshness, checker | CURRENT / STALE / N/A |
| `EVD` | execution/verification receiver | evidence producer | canonical evidence packet + assurance metadata | PASS / FAIL / HOLD / NOT_EXECUTED / UNKNOWN |
| `DEL` | delivery owner | package/project owner | deliverable ID, completion predicate, hash | CURRENT / INCOMPLETE / STALE |
| `GATE` | Constitution / gate owner | DOC-01/05/07/09 as applicable | denominator, decision owner, blocking class | OPEN / HOLD / CLOSED / DENIED |
| `PD_BINDING` | DOC-03 | DOC-03 | PI ref, repo/env/currentness/frozen refs | CURRENT / STALE / REJECTED |

`RequirementTraceRow` 是 narrow waist 的 canonical row，但 `PD_BINDING` 與 richer evidence metadata 不得被硬塞進 canonical schema 造成第二版本；DOC-04 以 typed companion ledgers + deterministic semantic validator補足，不與 canonical schema 競爭。

## 4.2 Edge invariants

1. 每個 normative `REQ` 必須至少有一個 `SRC` 或合法 inherited source ref。
2. `REQ→SPEC→ACC→VER→EVD_EXPECTATION` 是設計期 closure；`EVD` 是執行後 actual evidence，兩者不得合併。
3. `EVD` 必須回指 owning expectation；foreign evidence 不能靠相似名稱接入。
4. `DEL→GATE→PD_BINDING` 讓 trace 延伸到 receiver 可消費狀態；evidence 不是終點。
5. 每條 forward edge 必須可由 reverse index回溯到 consumed contract。
6. 任何 edge 的 subject/version/hash 改變，只 invalidates 真正 consume 該欄位的 dependents。

# 5｜Parent Requirement → Atomic Child Requirements

複合句只要含「各有、分別、對應、每個、同時、至少 A 與 B」等可獨立驗證義務，就必須先拆成 atomic children。父 requirement 不直接取得 PASS；它的 closure 是孩子集合的 deterministic reduction。

```text
decompose(parent):
  identify independently observable obligations
  create stable child IDs
  bind exactly one canonical owner per child
  bind applicability and criticality
  require SPEC/ACC/VER/EVD_EXPECTATION for each applicable child
  reject empty or circular child set
```

父層 closure：

```text
if any applicable child is INVALIDATED or HOLD:
    parent = HOLD
elif any applicable child lacks SPEC/ACC/VER/EVD_EXPECTATION:
    parent = HOLD + scoped TT
elif every child is NOT_APPLICABLE with accepted typed rationale:
    parent = NOT_APPLICABLE
else:
    parent trace = CURRENT
```

`CURRENT` 只表示 trace contract current，不表示 runtime PASS。若 child-3 semantic contract改變，只 child-3 與 consuming dependents stale；child-1/2 若不 consume該 contract，保持 current。

# 6｜SPEC Linkage Contract

DOC-04 不寫 SPEC 內容；它寫 **SPEC identity、ownership 與 consumption relation**。

- 一個 `REQ` 可映射一或多個 SPEC，前提是每個 SPEC 都有明確 consumed obligation；
- 多個 `REQ` 可共享 SPEC，但不得因共享而失去各自 Acceptance / Evidence expectation；
- `spec_ref` 必須可解析到 canonical owner 的 exact locator；
- SPEC version/hash 改變時，reverse index計算 affected requirements；
- SPEC 缺失不能以 `N/A` 掩蓋；只有 requirement 在 profile/applicability 下真正不適用時才可 N/A；
- orphan SPEC 代表「存在 canonical SPEC 但沒有 requirement consumer」，需分類成 retired/support-only/defect；不得默認忽略；
- machine-consumability 至少要求 stable ID、version/hash、schema/contract locator 或 deterministic prose predicate。

若 DOC-02 已裁決 SPEC semantic truth，DOC-04 只能 consume/pin/reference，不得重寫。

# 7｜Acceptance Contract

`AcceptancePredicate` 是 requirement 的可判定成功／拒收條件。每個重要 requirement 至少包含：

| Field | Contract |
|---|---|
| `acceptance_id` | stable、不可由顯示標題推導 |
| `requirement_ref` | exact parent/atomic requirement |
| `preconditions` | 執行判定前必須成立的條件 |
| `observable_success` | 可由人/工具/複合 oracle觀察的狀態 |
| `negative_predicate` | 明確禁止或必須拒收的狀態 |
| `edge_boundary_predicate` | 邊界/極限條件 |
| `tolerance_confidence` | 數值 tolerance、statistical confidence 或 exact |
| `checker` | 技術檢查責任 slot |
| `acceptor` | 技術/業務 acceptance責任 slot |
| `evidence_expected` | owning EvidenceExpectation refs |
| `profile_criteria` | LITE/STANDARD/ASSURED/target profile增量 |
| `failure_semantics` | FAIL/HOLD/TEMP_CLOSED與第一失敗 invariant |

「看起來正常」「結果合理」「人工確認即可」不是 acceptance predicate。Human judgment 若必要，必須有具體 rubric、輸入、評分尺度、最小通過條件、身份與 timestamp。

# 8｜Verification / Oracle Linkage

DOC-04 把 Acceptance 綁到 `TEST/ORACLE` identity，但不聲稱測試已執行。

每個 verification binding 必須記錄：

- stable `TEST-*` ID；
- stable `OR-*` ID；
- verification method；
- fixture/input identity + version/hash；
- expected observation；
- expected first failing invariant；
- oracle class：`DETERMINISTIC | STATISTICAL | HUMAN | COMPOSITE`；
- execution boundary / required environment；
- requalification trigger；
- oracle version/supersession；
- profile-added test identity與不可移除 core test規則。

若 writer 修改 oracle 以讓自己通過，舊 evidence 必須 stale，且該 writer 的新結果不可被標示為 independent assurance。Profiles 可增加 test，但不得移除 applicable core test；唯一例外是 accepted typed N/A。

# 9｜Evidence Expectation — Plan Before Evidence

`EvidenceExpectation` 是「之後需要什麼證據才能關閉某 predicate」；它與 actual `EVD` 嚴格分離。

最低 typed ledger：

```yaml
expectation_id: EVDX-D04-NORM-001
acceptance_ref: ACC-D04-EXAMPLE-001
verification_ref: TEST-D04-EXAMPLE-001
evidence_type: functional
subject_selector:
  subject_id: SVC-EXAMPLE
  version_policy: exact
  hash_policy: exact_sha256
expected_location: "evidence://functional/SVC-EXAMPLE"
collection_procedure_ref: PROC-D04-EXAMPLE-001
environment_policy: "ENV-PROFILE-EXAMPLE-001"
retention_policy: "PROJECT_PLUS_180D"
freshness_policy: "subject_or_oracle_change_invalidates; max_age=30d"
checker_role: ROLE-CHECKER
replay_requirement: "REPLAYABLE_WITH_PINNED_FIXTURE"
security_privacy_class: INTERNAL
world_effect_requirement: NOT_APPLICABLE
invalidation_triggers:
  - SUBJECT_HASH_CHANGE
  - ORACLE_VERSION_CHANGE
  - PROCEDURE_VERSION_CHANGE
```

此 typed ledger不是新的 `evidence.schema.json`。它是 DOC-04 semantic layer，允許 machine validator檢查 `EVD_EXPECTATION != EVD`：

```text
PLAN_COMPLETE != EXECUTED
TEST_DEFINED != TEST_EXECUTED
EVIDENCE_EXPECTED != EVIDENCE_RETURNED
```

# 10｜Subject-Bound Evidence Packet

## 10.1 Canonical packet denominator

`urn:pipd:canonical-standard:1.1:schema:evidence` 的 `SubjectBoundEvidencePacket` canonical required fields為：

`evidence_id, subject_id, subject_version, subject_hash, fixture_or_input_refs, environment, procedure_ref, expected, actual, oracle, oracle_result, result, timestamp, producer, first_failing_invariant, invalidated_dependents, artifacts`。

Canonical optional fields包括 `checker, approval_ref, effect_reconciliation_ref, rollback_result, residue_result`。`result=PASS` 時 canonical schema要求 non-empty `checker`、`oracle_result=PASS` 且至少一個 hashed artifact。

## 10.2 Assurance metadata overlay without schema fork

Skeleton/本任務還要求 operator、payload ref、test/oracle refs、freshness、retention、replay、effect observation/reconciliation。因 canonical evidence schema `additionalProperties=false`，DOC-04 **不得**偷偷往 canonical packet塞新欄位；r2 改以 keyed companion records保存，並由 §25 的 `DOC04ValidationProfile` 做 cross-object validation。

```yaml
evidence_id: EVD-D04-NORM-001
operator: ROLE-OPERATOR
payload_ref: artifact://evidence/raw-result.json
test_oracle_refs: [TEST-D04-EXAMPLE-001, OR-D04-EXAMPLE-001]
freshness:
  observed_at: "2026-10-07T10:00:00+08:00"
  expires_at: "2026-11-06T10:00:00+08:00"
  state: CURRENT
retention:
  class: PROJECT_PLUS_180D
  minimum_until: "2027-04-05T10:00:00+08:00"
replay:
  mode: PINNED_FIXTURE
  fixture_ref: FIX-D04-EXAMPLE-001
effect_observation_ref: null
reconciliation_ref: null
```

### 10.3 ExecutionEvidenceReturnLedger — executor-grade raw carrier

Canonical `SubjectBoundEvidencePacket` 保存 acceptance/evidence truth；executor 的 raw transport details 由下列 companion ledger承載，不改 canonical 22 schemas：

```yaml
return_id: EVRET-D04-EXAMPLE-001
evidence_id: EVD-D04-EXAMPLE-001
subject_id: SVC-D04-EXAMPLE
subject_version: "1.0.0"
subject_hash: "d3c5bb22f8408c835133db8e0380a741b7ab03f43d4b9154ebbf6435dd4f258f"
operation_id: OP-D04-EXAMPLE-001
action_ref: ACTION-D04-EXAMPLE-001
procedure_ref: PROC-D04-EXAMPLE-001
started_at: "2026-10-07T10:00:00+08:00"
ended_at: "2026-10-07T10:00:03+08:00"
environment: ENV-D04-EXAMPLE-001
producer: ROLE-MAKER
checker: ROLE-CHECKER
command_or_action: "HTTP GET /healthz against pinned local fixture"
exit_or_provider_status: "exit=0 / status=200"
stdout_ref: artifact://d04/example/stdout.txt
stderr_ref: artifact://d04/example/stderr.txt
raw_result_ref: artifact://d04/example/raw-result.json
changed_artifacts:
  - ref: artifact://d04/example/output.json
    sha256: "280db14100b375b4b8d6235149bce126596d6b17133a060ea70a1516f9042125"
changed_effects: []
verification_refs: [TEST-D04-EXAMPLE-001, OR-D04-EXAMPLE-001]
checksums:
  raw_result_sha256: "4df9d61fcd69da43fa68ccf91d01e8abdd4a41d27cfe1b9e55aeb72d216d26ff"
blockers: []
approval_ref: null
rollback_result: NOT_APPLICABLE
residue_result: NONE
```

Hard invariants：

1. `operation_id` 與 `procedure_ref` 分離；同 procedure 可有多次 operation instance。
2. `started_at <= ended_at`，且 execution interval MUST 落在 approval/token validity window（若適用）。
3. stdout/stderr 可為 `NOT_APPLICABLE`，但不可用 summary-only string 取代 raw/verifiable ref。
4. changed artifact/effect inventory 必須 explicit；空集合與 unknown 不同。
5. 此 ledger 不能自行把 action success 提升成 acceptance PASS；promotion 仍需 canonical packet + oracle + applicable effect reconciliation。

# 11｜Evidence Identity / Wrong-Subject Rejection

Evidence eligibility 必須同時滿足：

```text
expected.subject_id      == evidence.subject_id
expected.version_policy  accepts evidence.subject_version
expected.hash_policy     accepts evidence.subject_hash
expected.environment     matches evidence.environment policy
expected.procedure       matches evidence.procedure_ref
required TEST/ORACLE     matches evidence oracle binding
freshness                == CURRENT
approval (if required)   == valid/current
effect reconciliation    == eligible state when effectful
```

以下任一狀況直接拒絕 evidence promotion：

- subject ID 不同；
- version 不同且 policy 要求 exact；
- hash 不同；
- evidence 屬於另一 repo/workspace/provider surface；
- oracle 已 superseded；
- fixture 版本漂移；
- producer/subject自己把無 checker 的結果標成 PASS；
- foreign evidence 只有相同 test name，但 subject identity不同；
- summary-only文本無 raw/verifiable artifact ref；
- effectful operation只有 provider success，沒有 reconciliation receipt。

Reject 必須回傳 `first_failing_invariant`，例如 `EVIDENCE_SUBJECT_HASH_MISMATCH`，而不是只有 `FAIL`。

# 12｜Evidence Freshness / Retention / Replay

## 12.1 Freshness predicate

Evidence freshness 是函數，不是單一 timestamp：

```text
CURRENT(E) =
  subject_identity_current(E)
  AND expectation_current(E)
  AND oracle_current(E)
  AND procedure_current(E)
  AND environment_compatible(E)
  AND not_expired(E)
  AND approval_current_if_required(E)
  AND reconciliation_current_if_effectful(E)
```

任何 constituent stale，只 invalidates consume 它的 dependents。

## 12.2 Retention classes

DOC-04 定義 portable implementation classes（不是 canonical lifecycle state）：

- `EPHEMERAL_DEBUG`：不可用於 release/qualification gate；
- `PROJECT`：至少覆蓋 project active lifecycle；
- `PROJECT_PLUS_N_DAYS`：有明確最低保留日；
- `RELEASE`：至少覆蓋該 release 的 support/rollback horizon；
- `AUDIT`：依組織/法規政策保留，需 privacy/rights review。

Retention 只說「保存多久」，不說「證據一直有效」。Expired semantics與 retained bytes分開。

## 12.3 Replay

Replay contract 必須記錄 fixture/input、procedure、oracle、environment constraints與 nondeterminism policy。對不可重播的人類/外部世界事件，必須保存 immutable observation/readback artifacts、observer identity、timestamp、attestation/signature（若 profile要求）與 `NON_REPLAYABLE_WITH_RATIONALE`；不可假裝 deterministic replay。

# 13｜Stable TEST / ORACLE Identity

Canonical rule：每個 core test 都有 stable `TEST-*` / `OR-*` ID。ID 與顯示名稱、檔名、provider品牌解耦。

| Mutation | Required behavior |
|---|---|
| 測試實作 refactor、語意不變 | ID 可保留；implementation hash更新 |
| acceptance semantics改變 | old oracle superseded；dependent evidence stale |
| oracle threshold改變 | new oracle version；old evidence需 requalification判定 |
| profile增加 test | 新 ID；不可覆蓋 core ID |
| profile企圖移除 core test | 只有 accepted typed N/A 才可；否則 FAIL |
| writer修改 oracle後自評 | 可產 local evidence，但不得標 independent |

Validation report必須輸出第一個失敗 invariant、TEST ID、ORACLE ID、subject identity與 fixture ref。

# 14｜Evidence Type Taxonomy

Evidence type 不只是 label；每型別都有 producer/consumer、最小 payload、freshness、checker、invalidation、replay與 claim ceiling。

| Type | Producer → Consumer | Minimum payload | Freshness / invalidation | Checker / replay | Maximum claim contribution |
|---|---|---|---|---|---|
| static/schema | compiler → schema gate | subject hash, schema ID, validator output | schema/subject change | deterministic checker; replayable | structure conforms only |
| source/grounding | retriever/compiler → doc/trace | source/version/hash/locator/claim | source supersession/hash drift | grounding checker | claim is grounded |
| repo readback | repo reader → PD/gate | repo ref, path, commit/hash, observed state | repo drift | independent readback where required | repo fact observed |
| functional | executor → acceptance | input, actual, expected, oracle | subject/oracle/procedure drift | functional checker | behavior for subject/fixture |
| negative | executor → acceptance | forbidden input/action, rejection observation | policy/oracle drift | negative oracle | rejection works for tested case |
| edge/boundary | evaluator → acceptance | boundary fixture and observation | boundary contract drift | boundary oracle | boundary handled |
| adversarial | red-team/evaluator → assurance | attack fixture, control response | threat/model/control drift | separated checker in ASSURED | adversarial control evidence |
| security/privacy | security process → security gate | threat/control/data class/result | security/currentness drift | security checker | scoped security predicate |
| performance/capacity | perf harness → SLO gate | workload, env, metric series, threshold | code/env/capacity model drift | statistical/deterministic | tested SLO condition |
| parity/migration | migration harness → migration gate | before/after refs, diff, tolerance | source/target change | parity oracle | bounded migration parity |
| operational-readiness | ops checker → PREDEV/release prep | runbook, rollback, alert/readback refs | topology/runbook/provider drift | ops checker | readiness only |
| approval | Human/policy authority → permission gate | token/ref, subject, operation, scope, expiry | expiry/scope/subject change | authority verifier | authorization only |
| provenance/attestation | build/attestation system → supply-chain consumer | subject digest, producer/builder, signed/verified attestation ref | digest/signer/policy drift | signature/policy verifier | provenance/integrity, not product acceptance |
| independent assurance | independent qualifier → assurance/release | independent identity, subject, method, verdict, evidence refs | subject/method drift | independence check | independent qualification only to scope |
| world-effect observation | observer → reconciler | intent, provider response, observation method/state/time | target state/intent drift | observer/readback | observation only |
| reconciliation evidence | reconciler → acceptance/gate | observations, readbacks, oracle, final state | new contradictory observation | separated checker | confirmed/failed/compensated effect state |

# 15｜World Effect Observation

DOC-04 materializes canonical `EffectObservation` data contract：

`observation_id, effect_intent_ref, provider_response_ref, observation_method, observed_state, observed_at, observer`。

Canonical flow固定為：

```text
AUTHORIZED_ATTEMPT
→ PROVIDER_RESPONSE
→ OBSERVATION
→ READBACK
→ RECONCILIATION
→ WORLD_EFFECT_STATE
```

Provider/API/SDK 回傳成功只能建立 `provider_response_ref`，不能直接生成 `CONFIRMED_EFFECT`。Observation 必須來自適當 readback surface；對高風險或 ASSURED profile，readback方法需與造成 effect 的 write path足夠獨立，避免「同一 API 自己說自己成功」。

# 16｜Effect Reconciliation & DOC-05 Seam

Canonical `EffectReconciliationReceipt` 必須包含：

`receipt_id, effect_intent_ref, observation_refs, readback_refs, state, oracle, actual, next_action, checker, timestamp`。

Allowed states：

`UNKNOWN_EFFECT | PARTIAL_EFFECT | CONFLICTING_EFFECT | CONFIRMED_EFFECT | FAILED_EFFECT | COMPENSATED_EFFECT`。

Allowed next actions：

`PROMOTE_EVIDENCE | REOBSERVE | RECONCILE | COMPENSATE | ROLLBACK | FAIL_CLOSED`。

Ownership seam：

- `DOC-05` owns `EffectIntent`, permission, approval, ExecutionAdmission, rollback/compensation authority；
- `DOC-04` owns observation/reconciliation record integrity、evidence promotion eligibility、wrong-subject/freshness rules；
- `DOC-07` may own test/oracle fixture definitions used by reconciliation；
- `DOC-09` may provide provider/CI adapters but不能改變 effect truth model。

只有 `CONFIRMED_EFFECT` 或依 acceptance 明確允許的 `COMPENSATED_EFFECT` 才可支援相應 gate；`UNKNOWN_EFFECT`、`PARTIAL_EFFECT`、`CONFLICTING_EFFECT` 必須保持 unresolved。

# 17｜Documentation Grounding Contract

Canonical `DocumentationGroundingRecord` fields：

`grounding_id, source_id, source_version, source_hash, exact_locator, grounded_claim, retrieval_method, state, stale_invalidation_trigger`。

Grounding validator：

1. source artifact bytes可讀；
2. version/hash與 record一致；
3. exact locator可解析；
4. locator內容實質支援 grounded claim；
5. authority level允許該 claim成為 normative；
6. 若來源是 SUPPORT，只能產 `SUPPORT` consequence，不得改寫 P1/P2 semantics；
7. source superseded/hash drift後，record轉 `STALE`，只 invalidate consuming claims；
8. missing anchor時 `ABSTAIN/TEMP_CLOSED`，不得 raw-volume guess。

DOC-04 的 source ledger與 evidence ledger互相引用，但不能把「文件存在」當成「文件 claim 已 grounded」。

# 18｜Deliverable / Gate / PD-Binding Trace

Trace 必須延伸到 receiver：

```text
EVD → DEL → GATE → PD_BINDING
```

r2 明確分離 **canonical gate namespace** 與 **DOC-04 trace closure namespace**。`gate.owner_state` 永遠是 read-only reference；DOC-04 不再寫入任何本地 pseudo gate state；legacy trace-only closure token僅視為 r1 defect，不得出現在 canonical gate state/result。

```yaml
binding_trace_id: DGB-D04-EXAMPLE-001
requirement_ref: REQ-D04-EXAMPLE-001
evidence_refs: [EVD-D04-NORM-001]
deliverable:
  id: DEL-D04-EXAMPLE-001
  version: "1.0.0"
  hash: "280db14100b375b4b8d6235149bce126596d6b17133a060ea70a1516f9042125"
  completion_predicate: "all required artifacts hashed and resolvable"
gate:
  id: PI-GATE-EXAMPLE-001
  owner: ROLE-GATE-OWNER
  blocking: true
  owner_state_ref: GATE-STATE-READONLY-EXAMPLE-001
trace_closure_state: TRACE_CURRENT
pd_binding:
  consumer: PD-PKG-EXAMPLE
  frozen_refs: [REQ-D04-EXAMPLE-001, SPEC-D04-EXAMPLE-001, ACC-D04-EXAMPLE-001]
  stale_ref_behavior: REJECT_AND_REBIND
  reentry_path: DOC-02_OR_DOC-03_BY_CHANGE_CLASS
```

`trace_closure_state` exact enum：`TRACE_CURRENT | TRACE_STALE | TRACE_BLOCKED | TRACE_NA_ACCEPTED`。它不是 lifecycle gate state；真正 gate state只由 canonical gate owner寫入。Consumer MUST reject any record that places `TRACE_*` tokens inside `gate.state/result` or places gate tokens inside `trace_closure_state`.

# 19｜Forward / Reverse Orphan Scan

雙向掃描分母：

```text
SRC without REQ
REQ without SPEC
SPEC without ACC
ACC without VER
VER without EVD_EXPECTATION
EVD_EXPECTATION without valid evidence path
EVD without owning expectation
DEL without requirement chain
GATE without owned denominator
PD_BINDING without valid upstream trace
```

分類規則：

- normative source obligation無 REQ：`DEFECT_BLOCKING`；
- SUPPORT source未被使用：`NO_DEFECT_SUPPORT_UNUSED`；
- REQ/SPEC/ACC/VER/EVD_EXPECTATION斷鏈：`DEFECT` + scoped TT；
- actual EVD 無 owning expectation：`FOREIGN_OR_ORPHAN_EVIDENCE`，不得 promotion；
- PD binding引用 stale/superseded trace：`TEMP_CLOSED` until rebind；
- 修復後必須重跑 forward + reverse scan，只針對 affected slice。

Orphan scanner必須回傳 node ID、edge type、owner、blocking scope、repair target與 first failing invariant。

# 20｜N/A Contract — Machine-Valid Edge Closure Without Schema Fork

合法 N/A 不是「沒有做」；它是被 authority 接受的 applicability decision。r1 只有 `NARationaleRecord`，但 canonical `requirement-trace.schema.json` 即使 `status=NOT_APPLICABLE` 仍要求 `spec_ref / acceptance_ref / verification_ref / evidence_expectation_ref / deliverable_ref / gate`。r2 以 **typed N/A edge-resolution objects** 關閉此 gap，而不更改 canonical schema。

## 20.1 NARationaleRecord

```yaml
na_id: NA-D04-NORM-001
subject_ref: REQ-D04-EXAMPLE-OPTIONAL-001
profile_ref: PROFILE-LITE
applicability_dimension: world_effect
rationale: "target is read-only documentation compiler and has no external mutation path"
authority: ROLE-PROFILE-AUTHORITY
accepted_at: "2026-10-07T09:30:00+08:00"
consumer_visibility: REQUIRED
reopen_triggers: [SIDE_EFFECT_CLASS_CHANGED, PROFILE_CHANGED, REQUIREMENT_SCOPE_CHANGED]
state: ACCEPTED
```

## 20.2 NAEdgeResolutionRecord

每個 canonical required edge仍保留可解析 identity，但其 object type 是 `NOT_APPLICABLE_EDGE_RESOLUTION`，**不是虛構 SPEC/ACC/VER**：

```yaml
na_edge_id: NA-SPEC-D04-EXAMPLE-001
requirement_ref: REQ-D04-EXAMPLE-OPTIONAL-001
edge_kind: SPEC
resolution_kind: NOT_APPLICABLE_EDGE_RESOLUTION
na_rationale_ref: NA-D04-NORM-001
authority: ROLE-PROFILE-AUTHORITY
accepted_at: "2026-10-07T09:30:00+08:00"
reopen_triggers: [PROFILE_CHANGED, REQUIREMENT_SCOPE_CHANGED]
state: ACCEPTED
```

同一 N/A requirement MUST materialize exactly six resolvable edge records：

`NA-SPEC-* / NA-ACC-* / NA-VER-* / NA-EVDX-* / NA-DEL-* / NA-GATE-*`。

Canonical trace row then remains schema-valid without semantic fabrication：

```yaml
requirement_id: REQ-D04-EXAMPLE-OPTIONAL-001
source_refs: [SRC-D04-EXAMPLE-OPTIONAL-001#clause]
owner: ROLE-REQ-OWNER
spec_ref: NA-SPEC-D04-EXAMPLE-001
acceptance_ref: NA-ACC-D04-EXAMPLE-001
verification_ref: NA-VER-D04-EXAMPLE-001
evidence_expectation_ref: NA-EVDX-D04-EXAMPLE-001
deliverable_ref: NA-DEL-D04-EXAMPLE-001
gate: NA-GATE-D04-EXAMPLE-001
status: NOT_APPLICABLE
version: "1.0.0"
hash: "3e64c6da2e96a4e68e67d92696dfa099b39cba6b720a2eb7baf0ef4da276c20b"
invalidated_by: []
na_rationale: "NA-D04-NORM-001"
```

## 20.3 N/A semantic validator

A `NOT_APPLICABLE` row passes only iff：

1. `na_rationale` resolves to `state=ACCEPTED` with non-empty rationale and authorized profile authority；
2. all six required refs resolve to `NAEdgeResolutionRecord` objects of the expected `edge_kind`；
3. all six records point to the same requirement and same N/A rationale；
4. no required edge points to a normal SPEC/ACC/VER/EVDX/DEL/GATE object while status is N/A；
5. reopen trigger hit ⇒ rationale + six edge records become `STALE` and requirement cannot remain closed；
6. N/A MUST NOT be used to hide missing source, permission, security control, core test, or unresolved authority conflict。

這個 convention 位於 DOC-04 companion namespace；它滿足 canonical schema的 required-reference shape而不 fork `requirement-trace.schema.json`，並由 §35 reference validator實際檢查。

# 21｜Change / Supersession / Affected-Only Invalidation

## 21.1 Change classes consumed from Constitution

`EDITORIAL | NON_BREAKING_CONTRACT | BREAKING_CONTRACT | SECURITY_CURRENTNESS | RUNTIME_BINDING_DRIFT | EMERGENCY_CHANGE`。

DOC-04還必須觀察這些 trigger：source change、acceptance semantic change、oracle change、environment drift、evidence expiry、tool/provider version change、permission/security change、schema change。

## 21.2 Invalidation algorithm

```text
on_change(X):
  resolve old identity and new identity
  mark old X SUPERSEDED/STALE as appropriate
  compute changed semantic fields
  traverse reverse dependency index
  for each dependent D:
      if D consumes any changed field:
          mark D STALE or INVALIDATED
          record invalidation edge and reason
          block only gates depending on D
  preserve unrelated CURRENT siblings
  schedule recompile/rebind/reverify for affected scope
```

禁止兩端錯誤：

- **global invalidation overreach**：一個局部變更迫使全 project重做；
- **stale dependent leak**：上游 contract已變，依賴它的 evidence/gate仍標 current。

# 22｜Segregation of Duties / Assurance Roles

責任 slot：

`Maker | Checker | Acceptor | Human Approver | Independent Qualifier | Release Authority`。

- Maker 建立/修改 artifact或candidate；
- Checker 挑戰 subject與evidence；
- Acceptor 對 technical/business acceptance負責；
- Human Approver只在需要人類/政策權威的 external/high-risk scope授權；
- Independent Qualifier 必須具備真實組織/流程獨立性；
- Release Authority只裁決 release state。

`ASSURED` 或 high-risk package不得 collapse `Maker=Checker=Acceptor`。同模型二次自審、同 process callback、同 writer修改 oracle後再跑，都可以產生 supporting evidence，但不能標 `INDEPENDENT_PASS`。

# 23｜Claim Ceiling / Post-Write Readback Boundary

DOC-04 r2 author-side materialization可宣告：

```text
DOCUMENT_MATERIALIZED
+ SOURCE_BASELINE_FULL_SCAN_COMPLETE
+ CONTRACTS_COMPILED
+ CANONICAL_SPECIMENS_LOCALLY_VALIDATED
+ DOC04_COMPANION_VALIDATOR_LOCALLY_EXECUTED
```

最終 file SHA-256、bytes、lines、UTF-8 decode等 **post-write readback** 必須由檔外 delivery receipt承載，因為把最終 file hash嵌入同一組 bytes會造成 self-reference。本文使用 non-circular `content_hash` rule（將 front-matter `content_hash` value normalize為64個 `0` 後 hash）作 in-band identity；最終 container-file SHA-256 由交付回覆實測並綁定 `artifact_id + version + content_hash`。

明確不等於：

```text
IMPLEMENTED
TEST_EXECUTED_ON_TARGET
VERIFIED_TARGET
QUALIFIED
INDEPENDENT_PASS
HUMAN_RATIFIED
RELEASED
PRODUCTION_VERIFIED
```

同模型 local checker 只可支持 `LOCAL_DOCUMENT_MATERIALIZED_AND_AUTHOR_SIDE_CONFORMANCE_VALIDATED`；不得標 Independent。任何 downstream tool、CI、模型或 provider輸出都不能自行提高 claim ceiling。

# 24｜Profile Applicability / Agentic Trace / Cross-Session / Metrics / Threat Binding

## 24.1 Weight profiles

| Profile | DOC-04 minimum |
|---|---|
| `LITE` | portable-core identity/source/atomic trace/ACC/VER plan/EVD expectation/claim/invalidation；可裁減非適用 depth，但需 typed N/A |
| `STANDARD` | LITE + negative/edge tests、environment binding、freshness/retention/replay、orphan scan、rollback evidence where applicable、evidence-integrity threat model |
| `ASSURED` | STANDARD + distinct maker/checker/acceptor、independent checker slots、adversarial fixtures、provenance/attestation、stronger retention、world-effect independent readback、trace/evidence threat-binding matrix |

## 24.2 Target profiles

- `SYSTEM`：增加 integration/SLO/operability/migration/DR/capacity evidence；
- `SKILL_PLUGIN`：Trigger/Non-trigger/allowed tools/permission/host boundary/uninstall/evidence return；
- `AGENT_HARNESS`：tool/context/state/memory/guardrail/handoff/recovery/checkpoint/human escalation/effect reconciliation，並 MUST 啟用 §24.4 AgentHarnessTraceEvidenceProfile；
- `CUSTOM`：只能新增 constraint/test/evidence，不能削弱 core identity、claim ceiling、permission gate、source binding、subject binding或 affected-only invalidation；
- `Brownfield/Migration`：增加 parity、before/after hash、rollback/provider-off、currentness/rebind evidence。

## 24.3 DomainProfileExtension — exact added-test binding

`DomainProfileExtension` 的 DOC-04 companion projection MUST materialize：

```yaml
extension_id: EXT-D04-EXAMPLE-001
profile_id: org.example.domain-x
inherits_core: PIPD-LIFECYCLE-SPEC@1.1.0
additional_contracts: [CONTRACT-X-001]
additional_risks: [RISK-X-001]
additional_gates: [GATE-X-001]
schema_refs: []
added_tests_or_oracles:
  - TEST-X-001
  - OR-X-001
core_override: false
owner: ROLE-EXTENSION-OWNER
version: "1.0.0"
applicability: "target_profile=CUSTOM"
```

`added_tests_or_oracles[]` MAY add stable IDs; it MUST NOT delete applicable core TEST/ORACLE IDs. Validator compares core registry set with extension effective set and fails `PROFILE_REMOVED_CORE_TEST` on subtraction without accepted typed N/A by profile authority.

## 24.4 AgentHarnessTraceEvidenceProfile

Agent Harness runtime trace is **telemetry candidate data** until它經 subject/oracle/evidence promotion；trace backend或 SDK status不等於 acceptance。

```yaml
profile_id: AGENT-HARNESS-TRACE-EVIDENCE@1
run_identity: [run_id, subject_id, subject_version, subject_hash]
session_identity: [session_id, session_generation, context_digest, trust_label]
trajectory_identity: [trajectory_id, parent_trajectory_ref, checkpoint_ref]
span_identity: [trace_id, span_id, parent_span_id, event_id, monotonic_sequence]
event_classes:
  - MODEL_GENERATION
  - TOOL_CALL
  - TOOL_RESULT
  - HANDOFF_SEND
  - HANDOFF_RECEIVE
  - GUARDRAIL_DECISION
  - MEMORY_READ
  - MEMORY_WRITE
  - CHECKPOINT
  - RECOVERY
  - HUMAN_ESCALATION
  - EFFECT_INTENT
  - EFFECT_OBSERVATION
  - EFFECT_RECONCILIATION
pii_secret_policy:
  classification_required: true
  redact_before_export: true
  raw_secret_capture: FORBIDDEN
  correlation_tokens: OPAQUE_NON_SECRET
sampling_loss_policy:
  acceptance_critical_events: NEVER_SAMPLE
  diagnostic_events: POLICY_BOUND_SAMPLING_ALLOWED
  dropped_event_counter_required: true
  missing_critical_span_behavior: TEMP_CLOSED
telemetry_is_not_acceptance: true
replay:
  required_inputs: [subject_hash, fixture_or_input_refs, model_provider_binding_ref, tool_schema_refs, checkpoint_ref]
retention:
  critical_trace: "project policy + claim/evidence retention"
  diagnostic_trace: "policy-bound shorter retention allowed"
promotion:
  telemetry_event_to_evidence_candidate: "normalize + redact + bind subject/version/hash + test/oracle ref"
  evidence_candidate_to_EVD: "§35 validator + applicable SoD + freshness"
```

Mandatory negative cases：wrong run subject hash；foreign session；missing critical tool result；PII/secret leakage；guardrail event dropped；trajectory sequence fork without reconciliation；trace sampled away while used for PASS；tool success promoted without oracle/effect readback。

Inherited support identities：`CAND-02` OpenAI Codex/Agents SDK harness patterns與 `CAND-08` OpenTelemetry GenAI semantic conventions只作 trace instrumentation/read-through；canonical evidence meaning仍屬 DOC-04。

## 24.5 CROSS_SESSION_PIPELINE — co-owned resume/handoff continuity

```yaml
workflow_id: CROSS_SESSION_PIPELINE
canonical_home: DOC-03/04
resume_packet_id: CSP-D04-EXAMPLE-001
subject_id: SVC-D04-EXAMPLE
subject_version: "1.0.0"
subject_hash: "d3c5bb22f8408c835133db8e0380a741b7ab03f43d4b9154ebbf6435dd4f258f"
from_session_id: SESSION-A
to_session_id: SESSION-B
checkpoint_ref: CHECKPOINT-D04-001
checkpoint_evidence_ref: EVD-D04-CHECKPOINT-001
context_digest: "79183e2808119d294490974a3483036ec787618334328087982348ebbd3fd73b"
context_trust_label: SOURCE_BOUND_REDACTED
issued_at: "2026-10-07T10:00:00+08:00"
expires_at: "2026-10-08T10:00:00+08:00"
purge_after: "2026-10-15T10:00:00+08:00"
resume_preconditions:
  - SUBJECT_HASH_STILL_CURRENT
  - CHECKPOINT_EVIDENCE_CURRENT
  - RECEIVER_INSTRUCTION_SCOPE_RESOLVED
  - NO_REVOKED_APPROVAL_DEPENDENCY
evidence_handback_required: true
```

Hard rejects：`STALE_SUBJECT_HASH`、`FOREIGN_SESSION_CONTEXT`、`EXPIRED_RESUME_PACKET`、`CHECKPOINT_EVIDENCE_STALE`、`TRUST_LABEL_DOWNGRADE`。Session/memory state never becomes semantic authority；purge MUST remove ephemeral context while preserving required hashed evidence references。

## 24.6 ASSURED evidence-integrity threat binding matrix

| Threat ID | Threat / asset / boundary | Abuse case | Prevention | Detection / response | TEST / ORACLE | Owner | Residual risk | Evidence expectation |
|---|---|---|---|---|---|---|---|---|
| `THR-D04-01` | evidence forgery / EVD integrity / executor→reducer | forged PASS packet | subject/hash + hashed artifacts + checker | signature/hash/readback mismatch ⇒ quarantine | `TEST-D04-THR-01` / `OR-D04-THR-01` | Evidence owner | compromised checker | provenance + packet digest |
| `THR-D04-02` | replay / freshness boundary | replay prior-version PASS | freshness/invalidation index | stale version/oracle ⇒ reject | `TEST-D04-THR-02` / `OR-D04-THR-02` | Freshness owner | clock skew | currentness receipt |
| `THR-D04-03` | poisoned grounding / source→compiler | malicious external instruction treated as norm | source authority + content-as-data | locator/hash/authority mismatch ⇒ TEMP_CLOSED | `TEST-D04-THR-03` / `OR-D04-THR-03` | Grounding owner | authorized source compromise | grounding record |
| `THR-D04-04` | parser/schema abuse / validator boundary | schema-valid wrong 64-hex hash | cross-object semantic validator | expectation↔evidence mismatch ⇒ fail | `TEST-D04-THR-04` / `OR-D04-THR-04` | Validator owner | parser zero-day | validator report |
| `THR-D04-05` | confused deputy / approval→executor | valid evidence from unauthorized action | operation/approval scope bind | action outside token ⇒ deny/quarantine | `TEST-D04-THR-05` / `OR-D04-THR-05` | Permission owner seam | stolen valid token | approval + operation ledger |
| `THR-D04-06` | redaction failure / trace export | secret/PII emitted in span | classify+redact before export | DLP/fixture hit ⇒ block evidence export | `TEST-D04-THR-06` / `OR-D04-THR-06` | Trace evidence owner | inference leakage | redaction receipt |
| `THR-D04-07` | cross-session trust leakage | foreign checkpoint resumed | subject/session/context digest bind | wrong-session fixture ⇒ reject + purge | `TEST-D04-THR-07` / `OR-D04-THR-07` | DOC-03/04 seam | stolen checkpoint | resume packet + checkpoint evidence |
| `THR-D04-08` | trajectory tamper / agent trace | events reordered/dropped | monotonic sequence + critical no-sampling | sequence gap ⇒ TEMP_CLOSED | `TEST-D04-THR-08` / `OR-D04-THR-08` | Harness trace owner | backend loss | trace completeness evidence |

此 matrix只擁有**assurance-data integrity** threats；產品安全、權限政策、security control本體仍由 DOC-01/02/05/07 等 canonical owners擁有。

# 24A｜Lifecycle Assurance Metrics — DOC-04-owned minimum

三個 minimum metrics MUST 可由 trace/evidence graph計算，且 denominator 不得用「只算已成功的項目」作弊：

| Metric | Numerator | Denominator | Collection point | Freshness / blocking |
|---|---|---|---|---|
| `trace_completeness` | applicable CURRENT atomic requirements with complete `SRC→REQ→SPEC→ACC→VER→EVDX→DEL→GATE` or valid typed N/A closure | all applicable CURRENT atomic requirements in declared scope | PI compile + every affected change | `<1.0` blocks trace closure for missing slice |
| `acceptance_coverage` | applicable requirements with current AcceptancePredicate + stable verification/oracle binding | all applicable CURRENT requirements requiring acceptance | PI gate / pre-handoff | `<1.0` blocks PI_READY for affected scope |
| `evidence_completeness` | evidence expectations that have eligible current EVD when the target claim requires executed evidence | all due evidence expectations for the claimed lifecycle state | verification/gate time | missing due evidence blocks claim promotion; pre-execution state reports `planned/not-due` separately |

Metric record：

```yaml
metric_id: METRIC-D04-TRACE-COMPLETENESS
subject_scope: PI-SLICE-D04-EXAMPLE
measured_at: "2026-10-07T10:20:00+08:00"
numerator: 12
denominator: 12
value: 1.0
state: CURRENT
source_graph_hash: "d88ef4f58102b9eeb3594dfe79180029d7dad1d6d785d49eb1cf2872018d501d"
blocking_rule: "value < 1.0 => TRACE_BLOCKED"
```

Sibling-owned metrics (`owner_uniqueness`, blocking-TT count, receiver clarification, design rediscovery, rollback readiness, cross-agent semantic agreement)可 read-through消費，但 DOC-04 不奪取 canonical ownership。

# 25｜Machine / Prose Equivalence — Companion Contract + Deterministic Validator Layer

r2 採三層模型，避免把所有語意硬塞進 canonical `evidence.schema.json`：

```text
Layer 1 — canonical packet schemas (22-denominator unchanged)
Layer 2 — DOC-04 companion typed contracts (project-integration namespace)
Layer 3 — deterministic cross-object validators + metrics + first-failing-invariant report
```

## 25.1 Companion typed-contract registry

| Contract | Stable companion ID | Required core fields | Deterministic checks |
|---|---|---|---|
| EvidenceExpectation | `urn:pipd:doc04:1.1:companion:evidence-expectation` | expectation_id, acceptance_ref, verification_ref, subject selector, evidence_type, procedure/env, freshness, retention, checker, replay | expectation owner/subject/oracle resolvable |
| EvidenceAssuranceOverlay | `...:evidence-overlay` | evidence_id, operator, payload_ref, test_oracle_refs, freshness, retention, replay | packet exists; overlay subject inherited; no schema-field injection |
| ExecutionEvidenceReturnLedger | `...:execution-return` | return_id/evidence_id, operation_id/action_ref/procedure_ref, started_at/ended_at, stdout/stderr/raw refs, changed artifacts/effects, checksums, blockers, rollback/residue | interval order, approval window, raw refs, inventory explicit |
| DeliveryGateBindingRow | `...:delivery-gate-binding` | requirement/evidence/deliverable refs, gate ref/owner, trace_closure_state, PD binding | no pseudo gate state; stale refs reject |
| NARationaleRecord | `...:na-rationale` | na_id, subject/profile, rationale, authority, accepted_at, reopen triggers, state | non-empty, authorized, current |
| NAEdgeResolutionRecord | `...:na-edge-resolution` | na_edge_id, requirement_ref, edge_kind, na_rationale_ref, authority, state | six exact edge kinds; same subject/rationale |
| InvalidationRecord | `...:invalidation` | changed subject/fields, reverse dependents, invalidated/preserved, reason | affected-only; unrelated nodes preserved |
| OrphanScanResult | `...:orphan-scan` | direction, scope, orphan rows, result, repair owner | forward+reverse denominator complete |
| AssuranceRoleBinding | `...:sod-binding` | subject, profile, maker/checker/acceptor/IQ/release slots | ASSURED distinctness + independence claim checks |
| TraceClosureReport | `...:trace-closure` | denominator counts, orphans, stale/wrong evidence, blockers, result | metrics match graph; no author hand-filled pass |
| DomainProfileExtensionProjection | `...:domain-profile-extension` | extension_id, profile_id, inherits_core, added contracts/risks/gates/schema refs, added_tests_or_oracles[], core_override | core test set not reduced |
| AgentHarnessTraceEvidenceRecord | `...:agent-harness-trace` | run/session/trajectory/span/event identity, class, subject/hash, redaction/sampling, payload refs | critical events no-sampling; PII/secret policy |
| CrossSessionResumePacket | `...:cross-session-resume` | workflow_id, sessions, subject/hash, checkpoint evidence, context digest/trust, issue/expiry/purge | stale/wrong/expired/trust downgrade reject |
| EvidenceThreatBinding | `...:evidence-threat-binding` | threat, asset, boundary, abuse, prevention/detection/response, TEST/ORACLE, owner, residual risk, EVDX | full C-14 denominator |
| LifecycleAssuranceMetric | `...:metric` | metric_id/scope/time/numerator/denominator/value/state/source_graph_hash | denominator nonzero where applicable; value exact |

`...` 在上表只表示共同 prefix 的人類縮寫；machine registry中的實際 ID MUST 展開為完整 `urn:pipd:doc04:1.1:companion:*`。Canonical schema table §26.1 不允許縮寫。

## 25.2 Prose→machine enforcement map

| Prose predicate | Machine enforcement |
|---|---|
| REQ完整 narrow waist | canonical trace schema + graph resolver |
| PASS EVD subject/hash/checker/artifact | canonical evidence schema + expectation binder |
| wrong-but-valid 64-hex hash | cross-object exact-subject validator |
| N/A合法閉合 | NARationale + six NAEdgeResolution records + semantic validator |
| added profile tests不能刪 core tests | DomainProfileExtension diff validator |
| operation/procedure/time/raw return | ExecutionEvidenceReturnLedger validator |
| provider success不等於 world effect | observation/reconciliation schemas + promotion validator |
| stale dependent invalidated | dependency graph validator |
| Independent claim需真實獨立性 | AssuranceRoleBinding validator |
| Agent trace作 evidence前先 normalize/redact/bind | AgentHarnessTraceEvidenceProfile validator |
| cross-session resume | CrossSessionResumePacket validator |
| trace/acceptance/evidence coverage | LifecycleAssuranceMetric reducer |

## 25.3 Reference CLI contract

Extractable reference command：

```text
python pipd_doc04_validate.py   --graph <doc04-assurance-graph.json>   --canonical-schemas <pipd-schema-dir>   --report <doc04-conformance-report.json>
```

Exit classes：`0=pass, 2=canonical-schema, 3=graph-semantic, 4=freshness/currentness, 5=SoD/permission, 6=resolution/orphan, 7=internal`。Validator MUST emit first failing invariant and MAY emit all failures；higher gate is never inferred from lower check success。

Appendix F contains the extractable deterministic reference implementation. It does not become a 23rd canonical schema or a second lifecycle SSOT。

# 26｜Canonical Schema Alignment & Producer/Consumer Contracts

Canonical namespace：`urn:pipd:canonical-standard:1.1`；dialect：JSON Schema Draft 2020-12。DOC-04不得另建同義 schema取代以下 canonical objects。

## 26.1 Owned / co-owned canonical schemas

| Schema | Canonical `$id` | Producer | Consumer | Key validation | Invalidation |
|---|---|---|---|---|---|
| `requirement-trace.schema.json` | `urn:pipd:canonical-standard:1.1:schema:requirement-trace` | trace compiler from DOC-02 objects | PI gate, PD binder, conformance | required refs; status enum; hash; N/A rationale | source/spec/acc/ver/evidence-expectation/deliverable/gate semantic drift |
| `evidence.schema.json` | `urn:pipd:canonical-standard:1.1:schema:evidence` | execution/verification receiver | DOC-04 validator, DOC-07/05/09 gates | exact subject/version/hash; oracle result; PASS checker/artifact | subject/oracle/procedure/env/approval/effect drift |
| `documentation-grounding.schema.json` | `urn:pipd:canonical-standard:1.1:schema:documentation-grounding` | source retriever/compiler | trace/doc compiler | source/version/hash/locator/state | source mutation/supersession |
| `effect-observation.schema.json` | `urn:pipd:canonical-standard:1.1:schema:effect-observation` | observer/readback adapter | reconciler | intent/response/method/state/time/observer | target/intent/readback drift |
| `effect-reconciliation.schema.json` | `urn:pipd:canonical-standard:1.1:schema:effect-reconciliation` | reconciler/checker | acceptance/gate/evidence promotion | state enum + observation/readback refs + next action | contradictory/new observation or oracle drift |

`effect-reconciliation` 是 DOC-04/DOC-05 seam：DOC-05 owns authorization/intent，DOC-04 owns trace/assurance data integrity。

## 26.2 Cross-referenced sibling schemas

DOC-04必須解析但不得奪權：

`pre-implementation-package.schema.json, pre-dev-package.schema.json, tqaep.schema.json, handoff.schema.json, execution-admission.schema.json, effect-intent.schema.json, conformance-report.schema.json, approval-token.schema.json, repo-context.schema.json`。

Cross-reference用途：

- PI/PD package identity與 lifecycle state；
- TQAEP planned tests/evidence expectations；
- handoff expected evidence；
- execution admission與permission boundary；
- effect intent→observation binding；
- conformance report first-failing-invariant；
- approval token subject/scope/expiry；
- RepoContext environment identity。

## 26.3 Canonical field denominator preservation

Canonical schema若比本 DOC 的 human prose少欄位，不得自行改 canonical schema。缺口用 typed ledger + deterministic validator補足，直到 canonical standard正式版本升級；這避免 schema fork，同時維持 machine/prose equivalence。

# 27｜Technology / Workflow Identity Read-Through & 2026 Currentness

DOC-04 **does not own TechnologyAdmission**。r1 的 `terminal_disposition` 欄位已移除；它曾建立平行 selection vocabulary。r2 將 external items分成：(a) upstream canonical candidate identity read-through；(b) support/adapter observations；(c) 若真正 project adoption，route 到 DOC-02 exact `TechnologyAdmissionRecord` + 17-value disposition enum。

## 27.1 Inherited Technology Identity Crosswalk — CAND-01..22

| Candidate ID | Upstream identity | owned_here | Canonical owner/home | DOC-04 consumption / evidence impact | Anti-degradation | Currentness owner |
|---|---|---:|---|---|---|---|
| `CAND-01` | GPT-5.6 Sol | false | DOC-02 TechnologyAdmission | AI-authored design/review output must retain source/subject refs; same-model review is not independent | model/provider substitution cannot change requirement/evidence semantics | DOC-02/03 |
| `CAND-02` | OpenAI Codex / Agents SDK harness patterns | false | DOC-02/03/05 | tool/handoff/guardrail/runtime trace becomes evidence candidate only after subject/oracle binding | vendor runtime status never grants authority or acceptance | DOC-02/03/09 |
| `CAND-03` | AGENTS.md map/router pattern | false | DOC-08 adapter / repo-local | instruction source/version/hash/precedence is grounding evidence | repo instruction cannot override PIPD SSOT | DOC-03/08 |
| `CAND-04` | OpenSpec | false | DOC-02 TechnologyAdmission | spec workflow outputs must preserve canonical REQ/SPEC/ACC identities | no second lifecycle SSOT | DOC-02/03 |
| `CAND-05` | GitHub Spec Kit | false | DOC-02 TechnologyAdmission | spec/plan/task artifacts are trace inputs, not acceptance proof | workflow labels cannot replace PIPD lifecycle states | DOC-02/03 |
| `CAND-06` | Model Context Protocol (MCP) | false | DOC-02/03 | tool call/tool result evidence binds protocol/profile/tool schema + effect reconciliation where effectful | protocol success != authority/effect truth | DOC-03/09 |
| `CAND-07` | A2A Protocol | false | DOC-02/03 | handoff evidence binds remote identity/task/artifact/trust boundary | remote agent never inherits local authority | DOC-03/05 |
| `CAND-08` | OpenTelemetry GenAI semantic conventions | false | DOC-09 observability / DOC-04 consumer | telemetry spans/events normalized into AgentHarnessTraceEvidenceProfile | telemetry never equals acceptance evidence | DOC-03/09 |
| `CAND-09` | Pi Coding Agent | false | DOC-02 eval only | session/event/extension traces are provider-specific evidence candidates | no second canonical runtime without parity admission | DOC-02/03 |
| `CAND-10` | Superpowers | false | DOC-02/07 | TDD/debug/verify procedures map to stable TEST/ORACLE and raw evidence | methodology cannot rewrite acceptance authority | DOC-02/07 |
| `CAND-11` | gstack | false | DOC-02 reference | review sequencing may emit supporting review evidence | review output not independent qualification | DOC-02/07 |
| `CAND-12` | DeepSeek Harness | false | DOC-02 eval only | harness events/traces require preview currentness and subject binding | preview donor cannot become production authority | DOC-02/03 |
| `CAND-13` | Open GSD / gsd-core | false | DOC-02 reference | planning/review outputs may be grounding/trace support | avoid parallel lifecycle/SSOT | DOC-02/03 |
| `CAND-14` | Legacy gsd-build/get-shit-done | false | DOC-02 reject | provenance-only; no runtime evidence accepted from new dependency use | archived/superseded dependency prohibited | DOC-02 |
| `CAND-15` | mattpocock/skills | false | DOC-02/08 | skill trigger/compliance/boundary evidence binds skill identity/version | skill donor cannot hide tools/permissions | DOC-02/07 |
| `CAND-16` | Hugging Face Agent Skills | false | DOC-02/08 | rights/provenance/host permission + trigger evidence required | dataset/model rights and host permissions must be current | DOC-02/07 |
| `CAND-17` | AG-UI | false | DOC-08 adapter | client/shared-state traces are projection evidence only | UI state is not canonical authority/effect truth | DOC-08/09 |
| `CAND-18` | External NousResearch Hermes Agent | false | DOC-02 quarantine | no evidence promotion while provenance unresolved | quarantine cannot silently become runtime dependency | DOC-02/03 |
| `CAND-19` | Cordis | false | DOC-02 reference | runtime extension traces require adapter identity and subject binding | reference donor cannot create separate canonical runtime | DOC-02/03 |
| `CAND-20` | LongHorizon-Harness research | false | DOC-03/04 reference | checkpoint/recovery/Manage-Execute-Audit patterns feed CROSS_SESSION_PIPELINE evidence | research finding != production proof | DOC-03/07 |
| `CAND-21` | Skill-Use benchmark | false | DOC-07 reference | Trigger/Compliance/Boundary fixtures may populate TQAEP evidence | benchmark never replaces local conformance | DOC-07 |
| `CAND-22` | HarnessRisk benchmark | false | DOC-07 reference | adversarial lifecycle taxonomy feeds evidence-threat fixtures | transferability requires local threat model | DOC-07 |

Rules：

- 22/22 IDs MUST remain visible to downstream compilers；DOC-04不得改名後讓 identity lineage消失。
- `owned_here=false` means DOC-04只讀取 identity/disposition/currentness與 evidence impact；selection仍由 DOC-02/project authority處理。
- Candidate currentness drift may stale an adapter/evidence path；不得反向改寫 PIPD semantic truth。

## 27.2 Named workflow identity crosswalk — 8/8

| Workflow ID | Canonical home | DOC-04 treatment | Evidence/trace role | Anti-degradation |
|---|---|---|---|---|
| `MISSION_TO_EXECUTION` | DOC-02→03→05 | read-through | mission decomposition→bounded work→evidence return | no execution before ADMIT; trace continuity |
| `PHASES_RB00_RB15` | DOC-09 | read-through | phase/checkpoint/readback refs | phase labels never become lifecycle state |
| `WORKORDER_ADMISSION` | DOC-03/05 | read-through | WO identity/permission/admission separation | WO/ECP never self-authorize |
| `CROSS_SESSION_PIPELINE` | DOC-03/04 | **co-owned substantive** | §24.5 resume/checkpoint/context/evidence continuity | wrong subject/stale hash/expiry/purge negatives mandatory |
| `PROVIDER_ADMISSION` | DOC-02/03 | read-through | pin/license/security/capability/exit evidence refs | provider cannot own semantics |
| `LONG_RUNNING_CONTROL` | DOC-03/09 | read-through | checkpoint/stop/retry/recovery evidence | no autonomous authority expansion |
| `SELF_ITERATION_LOOP` | DOC-07 | read-through | rework evidence under stable oracle | no self-issued PASS/requirement rewrite |
| `RELEASE_RECOVERY` | DOC-09 | read-through | artifact identity/rollback/residue refs | release workflow cannot replace acceptance/qualification |

## 27.3 DOC-04 support mechanism observations — not TechnologyAdmission

以下六項**不是 DOC-04 terminal technology decisions**，因此不使用 canonical disposition欄位；只有 target project真的要 bind/runtime depend 時才建立 DOC-02 `TechnologyAdmissionRecord`。

| Support ID | External/support identity | Current observation | DOC-04 role | Admission status / owner route | License/rights + security boundary | Exit / refresh |
|---|---|---|---|---|---|---|
| `SUP-D04-JSONSCHEMA` | JSON Schema Draft 2020-12 | official site仍列 current version為 2020-12 (2026-10-07) | canonical schema dialect already mandated by P2 | `NO_NEW_ADMISSION_DECISION`; validator implementation late-bound via DOC-02/09 | public specification reference; structural validation != semantic acceptance | swap validator behind same dialect; re-run parity on binding/change |
| `SUP-D04-SLSA` | SLSA v1.2 | Approved v1.2 | optional provenance vocabulary adapter | `DOC02_ADMISSION_REQUIRED_IF_ACTIVATED` | provenance strengthens supply-chain trace but not product correctness | adapter removable; recheck on spec release |
| `SUP-D04-INTOTO` | in-toto Attestation Framework v1.2 | latest repo spec v1.2 | optional verified attestation envelope | `DOC02_ADMISSION_REQUIRED_IF_ACTIVATED` | statement existence != trust; verify signer/policy/subject | remove adapter; retain native EVD |
| `SUP-D04-GHATTEST` | GitHub Artifact Attestations / `actions/attest` | v4.2.2 observed Latest; provider adapter | verified provider receipt consumer | DOC-09 adapter + DOC-02 admission for project binding | least privilege, immutable pin, verify subject digest; workflow green != acceptance | provider-off/unbind/rebind; recheck before upgrade/new binding |
| `SUP-D04-JCS` | RFC 8785 JCS | Informational RFC; verified errata 7920/6292 reviewed | optional explicit JSON hash profile only | `DOC02_ADMISSION_REQUIRED_IF_ACTIVATED`; not portable-core dependency | canonicalization != authenticity; Errata 7920 requires `-0` defensive error fixture | versioned hash-profile migration only; recheck errata/status before binding |
| `SUP-D04-PROVO` | W3C PROV-O | stable W3C Recommendation | optional domain provenance mapping | `REFERENCE_ONLY_UNLESS_DOMAIN_ADMISSION` | ontology descriptive; no authorization/acceptance/signature semantics | drop mapping adapter without changing canonical PIPD IDs |

## 27.4 Search-Before-Build read-through for DOC-04-specific needs

| Need ref | Measurable capability | Internal reuse search | External scout role | Fit/gap result | Owner route |
|---|---|---|---|---|---|
| `NEED-D04-01` | validate canonical packet syntax | P2 already mandates JSON Schema 2020-12 | no new schema language needed | full fit via existing canonical dialect | validator implementation admission belongs DOC-02/09 |
| `NEED-D04-02` | provenance/attestation evidence mapping | P2 evidence taxonomy + subject-bound EVD sufficient | SLSA/in-toto/GitHub attest as optional envelopes | optional adapter; no portable-core gap | DOC-02 selection / DOC-09 provider binding |
| `NEED-D04-03` | deterministic JSON canonicalization | byte-hash identity already sufficient by default | JCS evaluated only for explicit target hash profile | no core need; profile-specific optional | DOC-02 if activated |
| `NEED-D04-04` | rich provenance ontology | native trace/evidence graph meets narrow waist | PROV-O considered as domain mapping | over-broad for portable core | domain adapter only |
| `NEED-D04-05` | agent runtime trace normalization | native AgentHarnessTraceEvidenceProfile + CAND-08/CAND-02 read-through | external SDK/telemetry instrumentation optional | semantic contract internal; backend late-bound | DOC-02/03/09 binding |
| `NEED-D04-06` | long-task resume evidence continuity | native CROSS_SESSION_PIPELINE contract | CAND-20 research supports pattern only | internal contract required; no runtime dependency selected | DOC-03/04 semantics; tooling late-bound |

If any row moves from reference/support to actual dependency, the adopter MUST materialize canonical TechnologyAdmissionRecord fields (`candidate_id, canonical_name, capability_slot, need_ref, source_or_upstream, observed_version_or_pin, source_checked_at, license, maturity, capabilities, disposition, integration_mode, security_risks, portability, testability, brownfield_fit, currentness_ttl, supply_chain_provenance, provider_exit, rollback_or_uninstall, no_fit_reason, anti_authority_rule, portable_core_dependency`) and use one exact disposition：`ADOPT | ADOPT_WITH_WRAPPER | ADOPT_WITH_TRANSLATION | SELECTED_REUSE | SELECTED_CONFIGURE | SELECTED_COMPOSE | SELECTED_WRAP | SELECTED_ADAPT | SELECTED_TRANSLATE | SELECTED_EXTEND | ROUTE_OUT | EVAL_ONLY | REFERENCE | BUILD_MINIMAL | REJECT | QUARANTINE | HOLD_WITH_TT`。

## 27.5 Authority barrier

External standards/provider/OSS can provide validation/provenance/attestation/canonicalization/ontology/telemetry mechanisms；they cannot provide or seize PIPD requirement truth、AcceptancePredicate ownership、ExecutionAdmission、Human approval、Independent PASS、Release/Production claim or WorldEffectState meaning。Support success translated into a higher PIPD claim ⇒ `EXTERNAL_SUPPORT_CLAIM_INFLATION` fail-closed。

# 28｜Named Integration Protection Registry

本 registry 保護的是**已在 PIPD 中使用的 integration/translation identity**，不等於 DOC-04 技術選型。凡實際 runtime dependency仍需 DOC-02 TechnologyAdmission + applicable DOC-09 binding。r2 保留 r1 的 translation/compression/rollback/provider-off strengths，但 ownership以 §27 read-through為準。

本 registry 只列 DOC-04 已 terminally decided 且下游可能 materialize 的具名項目。`required_materialization_state` 描述未來責任；它不構成本輪 install/bind/enable 事實。

```yaml
named_integration_protection_registry:
  - integration_id: NIPR-D04-JSONSCHEMA-001
    external_formal_name: "JSON Schema Draft 2020-12"
    internal_short_name: JSONSCHEMA
    selected_version: "Draft 2020-12"
    capability_slot: "canonical structural schema validation"
    canonical_owner: "PIPD canonical standard; DOC-04 consumes/validates owned seam schemas"
    adoption_ref: TID-D04-JSONSCHEMA-001
    terminal_design_disposition: REQUIRED_CANONICAL_DIALECT
    required_materialization_state: "target validator selected and conformance-tested before machine validation is claimed"
    translation_or_compression_contract: TC-D04-JSONSCHEMA-001
    installation_or_distribution_target: "target validator/runtime chosen under PD/DOC-09; specification itself has no install claim"
    binding_target: "requirement-trace/evidence/documentation-grounding/effect-observation/effect-reconciliation validators"
    enablement_condition: "validator proves Draft-2020-12 parity plus PIPD semantic-validator separation"
    functional_acceptance: "all five canonical DOC-04 seam schemas accept valid canonical specimens"
    negative_acceptance: "invalid required field/type/enum/conditional cases are rejected with first failing invariant"
    boundary_acceptance: "additionalProperties=false, N/A conditional, evidence PASS conditional and URI/hash limits are preserved"
    security_acceptance: "untrusted schema/data cannot trigger arbitrary code; validator runs within target security policy"
    evidence_required: "validator version/pin, conformance report, five-schema specimen results, negative fixture results"
    rollback: "swap validator behind same dialect contract and rerun parity suite"
    uninstall_or_provider_exit: "remove validator package/binding without changing canonical schema semantics"
    residue_check: "no stale validator-specific extensions remain in canonical schemas"
    dynamic_reselection_trigger: "validator EOL/security issue/nonconformance or PIPD canonical dialect revision"
    forbidden_degradation: "no unspecified dialect; no schema-valid=accepted shortcut; no silent removal of semantic validators"

  - integration_id: NIPR-D04-SLSA-001
    external_formal_name: "SLSA v1.2 Provenance"
    internal_short_name: SLSA-PROV
    selected_version: "v1.2"
    capability_slot: "optional supply-chain provenance evidence adapter"
    canonical_owner: "DOC-09/provider adapter for implementation; DOC-04 owns evidence eligibility"
    adoption_ref: TID-D04-SLSA-001
    terminal_design_disposition: OPTIONAL_SELECTED_ADAPTER
    required_materialization_state: "SELECTED; NOT_BOUND; NOT_EXECUTED until target provenance source exists"
    translation_or_compression_contract: TC-D04-SLSA-001
    installation_or_distribution_target: "target build/attestation pipeline only when profile requires provenance"
    binding_target: "PIPD provenance/attestation evidence intake"
    enablement_condition: "target profile marks provenance applicable and adapter passes subject/digest/trust parity"
    functional_acceptance: "valid verified provenance maps to subject digest, producer/builder and artifact refs without field loss"
    negative_acceptance: "unverified/wrong-subject/wrong-digest provenance is rejected"
    boundary_acceptance: "provenance never closes functional/product acceptance without its owning ACC/ORACLE"
    security_acceptance: "trust policy, verifier identity, signature/attestation verification and provenance source are explicit"
    evidence_required: "verified provenance receipt + adapter mapping report + negative wrong-subject fixture"
    rollback: "disable adapter; native PIPD evidence remains authoritative"
    uninstall_or_provider_exit: "remove adapter/pipeline dependency and preserve canonical evidence records"
    residue_check: "no SLSA-only field becomes mandatory canonical PIPD field"
    dynamic_reselection_trigger: "SLSA spec change, target provenance provider change, security/trust model change"
    forbidden_degradation: "do not reduce selected adapter to README citation; do not equate provenance with acceptance/Independent PASS"

  - integration_id: NIPR-D04-INTOTO-001
    external_formal_name: "in-toto Attestation Framework"
    internal_short_name: INTOTO-AF
    selected_version: "v1.2 support reference / Statement v1 family"
    capability_slot: "optional portable attestation envelope"
    canonical_owner: "DOC-09 adapter implementation; DOC-04 evidence consumer"
    adoption_ref: TID-D04-INTOTO-001
    terminal_design_disposition: OPTIONAL_SELECTED_ADAPTER
    required_materialization_state: "SELECTED; NOT_INSTALLED; NOT_BOUND; NOT_ENABLED; NOT_EXECUTED"
    translation_or_compression_contract: TC-D04-INTOTO-001
    installation_or_distribution_target: "target attestation verifier only if selected by applicable profile"
    binding_target: "PIPD provenance evidence adapter"
    enablement_condition: "verifier/trust policy pinned; subject digest and predicate mapping pass acceptance"
    functional_acceptance: "verified statement subject/digest/predicate are preserved into evidence artifacts and grounding refs"
    negative_acceptance: "unsigned/untrusted/wrong-subject/wrong-digest statement is rejected"
    boundary_acceptance: "unknown predicate may be retained as opaque artifact but cannot create unsupported PIPD claim"
    security_acceptance: "signature/trust verification, parser hardening and untrusted predicate isolation are enforced"
    evidence_required: "verified statement + verifier result + trust-policy ref + mapping report"
    rollback: "detach envelope adapter and continue with native PIPD evidence"
    uninstall_or_provider_exit: "remove verifier/library/provider binding; preserve exported canonical evidence refs"
    residue_check: "no provider-specific predicate becomes a hidden PIPD authority"
    dynamic_reselection_trigger: "attestation spec/trust mechanism/provider changes"
    forbidden_degradation: "no unverified attestation promotion; no second evidence schema; no authority transfer to predicate producer"

  - integration_id: NIPR-D04-GHATTEST-001
    external_formal_name: "GitHub Artifact Attestations / actions/attest"
    internal_short_name: GH-ATTEST
    selected_version: "support release v4.2.2; immutable execution SHA LATE_BOUND by DOC-09"
    capability_slot: "provider-specific provenance/attestation generation and verification"
    canonical_owner: "DOC-09 CI/provider adapter"
    adoption_ref: TID-D04-GHATTEST-001
    terminal_design_disposition: REFERENCE_PROVIDER_ADAPTER
    required_materialization_state: "NOT_INSTALLED; NOT_BOUND; NOT_ENABLED; NOT_EXECUTED in this artifact"
    translation_or_compression_contract: TC-D04-GHATTEST-001
    installation_or_distribution_target: "GitHub Actions workflow only in an approved target repository"
    binding_target: "DOC-09 adapter output -> DOC-04 provenance evidence intake"
    enablement_condition: "immutable action pin, least-privilege permissions, trusted workflow provenance and verify step all present"
    functional_acceptance: "generated attestation is independently verified against expected subject/repo/workflow policy"
    negative_acceptance: "generated-but-unverified, wrong-repo, wrong-commit, wrong-subject or failed verification cannot be promoted"
    boundary_acceptance: "workflow success or attestation generation alone never closes product acceptance or world-effect gate"
    security_acceptance: "token permissions, workflow source, immutable pin, verifier policy and supply-chain controls pass target security review"
    evidence_required: "workflow ref + immutable action pin + verified attestation receipt + verifier output + subject digest"
    rollback: "disable workflow step/binding and revert to prior qualified attestation path"
    uninstall_or_provider_exit: "remove action/workflow integration, revoke obsolete permissions, export retained evidence, verify residue"
    residue_check: "no stale token/permission/workflow hook or GH-specific claim remains as canonical authority"
    dynamic_reselection_trigger: "provider deprecation, security advisory, new major, repository migration, provider exit decision"
    forbidden_degradation: "no mutable tag as final runtime pin; no generate-without-verify; no green-CI=acceptance claim; no provider lock-in"

  - integration_id: NIPR-D04-JCS-001
    external_formal_name: "RFC 8785 JSON Canonicalization Scheme"
    internal_short_name: JCS
    selected_version: "RFC 8785"
    capability_slot: "optional deterministic JSON serialization before hashing"
    canonical_owner: "target project hash profile; DOC-04 consumes declared identity"
    adoption_ref: TID-D04-JCS-001
    terminal_design_disposition: REFERENCE_ONLY_UNLESS_HASH_PROFILE_EXPLICITLY_ADOPTS
    required_materialization_state: "NOT_BOUND unless target identity policy explicitly selects JCS"
    translation_or_compression_contract: TC-D04-JCS-001
    installation_or_distribution_target: "target hashing utility/library only when explicit profile adopts JCS"
    binding_target: "declared JSON hash profile, not existing file-byte artifact hashes"
    enablement_condition: "versioned hash-profile decision + dual-read/parity plan + migration acceptance"
    functional_acceptance: "semantically identical supported JSON inputs yield deterministic canonical bytes under selected implementation"
    negative_acceptance: "unsupported/non-conforming numeric/string/object cases fail rather than silently normalize differently"
    boundary_acceptance: "existing byte-hashed artifacts retain their original identity and are not silently reinterpreted"
    security_acceptance: "canonicalization is never treated as signature/authentication; hash/trust algorithms remain separate"
    evidence_required: "implementation pin + RFC test vectors/parity + migration/readback evidence when adopted"
    rollback: "restore prior versioned hash profile through explicit migration; preserve old identities/read paths"
    uninstall_or_provider_exit: "remove canonicalizer dependency where no longer applicable after compatibility window"
    residue_check: "no mixed implicit JCS/raw-byte identity without explicit version discriminator"
    dynamic_reselection_trigger: "hash-profile change, implementation incompatibility, relevant RFC errata"
    forbidden_degradation: "no silent reserialization; no mandatory use outside explicit profile; no authenticity claim from canonicalization"
```

## 28.1 Translation / Compression Contract Registry

```yaml
translation_compression_contracts:
  - contract_id: TC-D04-JSONSCHEMA-001
    external_concept: "Draft 2020-12 structural/conditional schema validation"
    pipd_internal_semantic: "canonical schema structural validator under separate semantic validators"
    retained_capability: [type/required/enum/pattern/format/conditional/closed-object validation]
    dropped_capability: ["none from canonical schema semantics; implementation-specific extensions are excluded"]
    forbidden_semantic_leakage: "schema-valid MUST NOT imply accepted, authorized, executed, independently assured, or production-valid"
    canonical_owner: "PIPD canonical standard"
    adapter_or_wrapper: "ValidatorAdapter<Draft2020-12>"
    data_interface_transform: "canonical JSON/YAML instance -> JSON value -> Draft-2020-12 validator result + normalized first-failing-invariant"
    authority_barrier: "validator implementation cannot rewrite canonical schema or acceptance semantics"
    pipd_native_replacement: "requirement/evidence semantic validators and gate owners"
    upgrade_exit_route: "replace validator only after dialect parity and destructive-suite PASS"

  - contract_id: TC-D04-SLSA-001
    external_concept: "SLSA provenance statement and verification context"
    pipd_internal_semantic: "provenance/attestation evidence artifact bound to a PIPD subject"
    retained_capability: [subject digest, producer/builder identity, provenance predicate reference, verification receipt]
    dropped_capability: ["any implication that SLSA level/provenance alone proves product correctness or acceptance"]
    forbidden_semantic_leakage: "SLSA terminology cannot redefine PIPD gate/claim states"
    canonical_owner: "DOC-04 evidence eligibility; DOC-09 adapter implementation"
    adapter_or_wrapper: SlsaProvenanceEvidenceAdapter
    data_interface_transform: "verified provenance -> evidence.artifacts/provenance refs + subject digest cross-check"
    authority_barrier: "external provenance is SUPPORT evidence only"
    pipd_native_replacement: "SubjectBoundEvidencePacket + AcceptancePredicate + gate owner"
    upgrade_exit_route: "detach adapter; keep native evidence and exported raw provenance artifact"

  - contract_id: TC-D04-INTOTO-001
    external_concept: "in-toto Statement subject/predicate envelope"
    pipd_internal_semantic: "optional verified attestation artifact carrying subject digest/predicate ref"
    retained_capability: [subject digest envelope, predicate typing/reference, verification result]
    dropped_capability: ["mandatory dependence on any predicate family", "automatic gate promotion"]
    forbidden_semantic_leakage: "predicate producer cannot become PIPD acceptance authority"
    canonical_owner: "DOC-04 evidence eligibility"
    adapter_or_wrapper: InTotoAttestationEvidenceAdapter
    data_interface_transform: "verified Statement -> evidence artifact + subject digest + opaque/typed predicate ref"
    authority_barrier: "unverified or unsupported predicate remains non-promotable"
    pipd_native_replacement: "SubjectBoundEvidencePacket and provenance evidence taxonomy"
    upgrade_exit_route: "remove adapter without altering PIPD canonical schemas"

  - contract_id: TC-D04-GHATTEST-001
    external_concept: "GitHub-hosted artifact attestation generation/verification"
    pipd_internal_semantic: "provider-specific verified provenance evidence source"
    retained_capability: [workflow/repository/commit context, artifact subject digest, provider verification receipt]
    dropped_capability: ["green workflow as product acceptance", "provider-specific workflow state as canonical PIPD state"]
    forbidden_semantic_leakage: "GitHub provider identity cannot become PIPD authority or ExecutionAdmission"
    canonical_owner: "DOC-09 provider adapter; DOC-04 evidence validator"
    adapter_or_wrapper: GitHubAttestationEvidenceAdapter
    data_interface_transform: "verified provider receipt -> PIPD provenance evidence + environment/provider refs"
    authority_barrier: "provider success remains supporting evidence"
    pipd_native_replacement: "portable evidence contract permits provider exit"
    upgrade_exit_route: "unbind GitHub adapter; rebind another qualified provider and revalidate affected evidence"

  - contract_id: TC-D04-JCS-001
    external_concept: "canonical JSON serialization"
    pipd_internal_semantic: "optional explicit JSON identity/hash preprocessing profile"
    retained_capability: [deterministic canonical JSON bytes]
    dropped_capability: ["use outside declared profile", "authentication/signature semantics"]
    forbidden_semantic_leakage: "JCS output cannot redefine legacy byte identities or establish trust"
    canonical_owner: "target identity/hash profile"
    adapter_or_wrapper: JcsHashProfileAdapter
    data_interface_transform: "JSON value -> RFC8785 canonical bytes -> target-declared hash algorithm"
    authority_barrier: "PIPD evidence subject identity uses whichever versioned identity policy its canonical owner declares"
    pipd_native_replacement: "raw file-byte hashing remains default where already defined"
    upgrade_exit_route: "versioned hash-profile migration with dual-read/parity/rollback"
```

`Compression` 在本文件中只表示把外部功能壓製成 PIPD-native capability slot；不得丟掉 subject identity、verification status、authority barrier、rollback/exit 或 evidence-return requirement。

## 28.2 Integration acceptance denominator

所有真正被 materialize/bind 的上述 adapter，在 enablement 前必須至少通過以下共通 acceptance；個別 registry row 的條件會再收緊分母：

| Acceptance class | Required result |
|---|---|
| positive | expected subject/record可被正確轉譯並由 consumer解析 |
| negative | wrong subject/hash/version/unverified input被拒絕且回 first failing invariant |
| boundary | canonical-owner與adapter-owner的權限邊界不被跨越 |
| edge | empty/min/max/unknown-but-valid extension cases有 deterministic result |
| adversarial/security | forged/untrusted/malformed/privilege-escalating input fail-closed |
| permission | provider/tool所需權限最小化且不可用未核准 token升格 claim |
| provider-off | provider不可用時 canonical PIPD data仍可讀；受影響 adapter功能 TEMP_CLOSED而非語意消失 |
| rollback | 回到前一 qualified binding後受影響 trace/evidence重新驗證 |
| uninstall/residue | 移除後無 stale token/hook/provider-only authority/hidden schema extension |
| semantic parity | translation前後保留 subject/identity/claim ceiling/verification meaning |
| evidence/readback | 產生 hashed readback、版本/pin、環境、validator/oracle result與 invalidated dependents |

只有這些 acceptance 的**實際 evidence**存在且 subject/currentness/SoD有效時，target project才能把 materialization state從 `SELECTED` 推進到 `BOUND/ENABLED/VERIFIED`。本 DOC-04 本輪沒有做這個推進。

# 29｜PIPD_LS_DOC-00 Alignment

DOC-00 的 router/readback與 DOC-04維持以下一致：

- 「What proves requirement/spec/test/evidence linkage? → DOC-04」保持成立；
- DOC-00顯示 missing/stale refs，但不重新計算 DOC-04 semantic truth；
- DOC-00不能成為第二個 trace/evidence writer；
- DOC-04輸出 `CURRENT/HOLD/STALE/INVALIDATED` 等可投影狀態供 DOC-00 readback；
- `PREDEV_READY`、ECP、TQAEP、WorkOrder的存在都不能被 DOC-04解讀成 `ExecutionAdmission`；
- CI/tool success只是 supporting evidence，除非 acceptance owner明確綁定且 evidence subject/currentness有效；
- vertical slice可以在自己的 dependency closure穩定後獨立 trace/bind/invalidate，不建立「所有 PI/PD 全完成才能施工」的 global waterfall lock。

# 30｜Worked Engineering Cases

以下皆是**規格示例，不是 runtime evidence**。示例 IDs 用於展示 deterministic trace behavior。

## 30.1 Case A — Normal Requirement Trace

需求：API 回應 P95 必須低於 250 ms，且超限時不得被「平均值正常」掩蓋。

```text
SRC-PERF-001#SLO
→ INTENT-FAST-API-001
→ REQ-PERF-001(parent)
→ REQ-PERF-001-C01(P95 < 250ms)
→ SPEC-PERF-001(load profile + percentile definition)
→ ACC-PERF-001(P95 < 250ms over pinned fixture)
→ TEST-PERF-001 / OR-PERF-001
→ EVDX-PERF-001
→ EVD-PERF-001(subject/version/hash bound)
→ DEL-PERF-001
→ GATE-PERF-001
→ PD-BIND-PERF-001
```

若 evidence subject/hash、fixture、environment、oracle皆 match且 current，trace可標 `CURRENT` 並讓 gate owner消費；DOC-04仍不宣稱 production SLO已達成，因 evidence只支援該 subject/fixture/environment。

## 30.2 Case B — Orphan Detection

`REQ-SEC-014` 已建立，但 `spec_ref` 空缺。Scanner輸出：

```yaml
orphan_id: ORPH-REQ-SEC-014
node_ref: REQ-SEC-014
missing_edge: REQ_TO_SPEC
classification: DEFECT
blocking_scope: GATE-SECURITY-SLICE-A
first_failing_invariant: REQ_REQUIRES_SPEC_OR_ACCEPTED_NA
repair_owner: ROLE-SECURITY-SPEC-OWNER
next_state: TEMP_CLOSED
```

修復 SPEC 後只重跑 `REQ-SEC-014` 的 forward/reverse closure與其 dependents，不重跑不相關 slice。

## 30.3 Case C — Stale Evidence

`SVC-A@1.4.2` hash從 `d3c5bb22f8408c835133db8e0380a741b7ab03f43d4b9154ebbf6435dd4f258f` 改變。舊 `EVD-A-008`即使 test name相同也轉 `STALE`；依賴它的 `DEL-A`/`GATE-A`被 invalidate。不 consume `SVC-A` 的 sibling `GATE-B`保持 current。

## 30.4 Case D — Wrong-Subject Evidence

`TEST-AUTH-009` 在 `service-auth-staging` PASS，工程師嘗試用同一報告關閉 `service-auth-production` gate。因 `subject_id` 不同，validator回：

`EVIDENCE_WRONG_SUBJECT → REJECT → no gate promotion`。

## 30.5 Case E — World Effect

付款退款 API回 `200`：

```text
provider_response=200
observation missing
→ UNKNOWN_EFFECT
→ readback ledger
→ observation: refund absent
→ reconciliation: FAILED_EFFECT
→ next_action: RECONCILE/COMPENSATE
```

只有 readback確認 ledger/account實際狀態後才能 promotion；HTTP成功不能直接變 `CONFIRMED_EFFECT`。

## 30.6 Case F — ASSURED SoD

Maker編寫 migration、執行 dry-run並產 evidence。若 Maker同時是唯一 Checker/Acceptor，`ASSURED` validator回 `SOD_MAKER_CHECKER_ACCEPTOR_COLLAPSE`。可保留 Maker evidence，但 gate需另一個符合獨立性要求的 Checker/Acceptor。

## 30.7 Case G — Legitimate vs Illegitimate N/A

合法：read-only documentation compiler的 `world_effect_reconciliation` 在 LITE profile經 authority接受為 N/A，並有 side-effect-class變更時 reopen trigger。  
非法：因沒有建立 security test就把 `security_test=N/A`。後者是 missing masquerading as N/A，必須 FAIL。

# 31｜Machine-Readable Specimens

本節 specimen 是可供實作者直接理解 shape/validator behavior 的具體例子；它們不是 target execution evidence。

## 31.1 RequirementTraceRow

```yaml
requirement_id: REQ-D04-EXAMPLE-001
source_refs:
  - SRC-D04-EXAMPLE-001#clause-7
owner: ROLE-REQ-OWNER
spec_ref: SPEC-D04-EXAMPLE-001
acceptance_ref: ACC-D04-EXAMPLE-001
verification_ref: TEST-D04-EXAMPLE-001
evidence_expectation_ref: EVDX-D04-EXAMPLE-001
deliverable_ref: DEL-D04-EXAMPLE-001
gate: GATE-D04-EXAMPLE-001
status: CURRENT
version: "1.0.0"
hash: "a1172047fe64277db0224d91dcb9697838c014a0cf2ec060e0cb0dad1eae1a9b"
invalidated_by: []
na_rationale: null
```

## 31.2 EvidenceExpectation

```yaml
expectation_id: EVDX-D04-EXAMPLE-001
subject:
  id: SVC-D04-EXAMPLE
  version: "1.0.0"
  hash: "d3c5bb22f8408c835133db8e0380a741b7ab03f43d4b9154ebbf6435dd4f258f"
evidence_type: functional
expected_location: "evidence://d04/example/functional"
collection_procedure_ref: PROC-D04-EXAMPLE-001
environment: ENV-D04-EXAMPLE-001
retention: PROJECT_PLUS_180D
freshness:
  max_age_days: 30
  invalidate_on_subject_change: true
  invalidate_on_oracle_change: true
checker: ROLE-CHECKER
replay_requirement: PINNED_FIXTURE
security_privacy_class: INTERNAL
world_effect_requirement: NOT_APPLICABLE
```

## 31.3 SubjectBoundEvidencePacket — canonical schema shape

```yaml
evidence_id: EVD-D04-SPECIMEN-001
subject_id: SVC-D04-EXAMPLE
subject_version: "1.0.0"
subject_hash: "d3c5bb22f8408c835133db8e0380a741b7ab03f43d4b9154ebbf6435dd4f258f"
fixture_or_input_refs:
  - FIX-D04-EXAMPLE-001
environment: ENV-D04-EXAMPLE-001
procedure_ref: PROC-D04-EXAMPLE-001
expected: "response status=200 and schema valid"
actual: "response status=200 and schema valid"
oracle: OR-D04-EXAMPLE-001
oracle_result: PASS
result: PASS
timestamp: "2026-10-07T10:00:00+08:00"
producer: ROLE-MAKER
checker: ROLE-CHECKER
first_failing_invariant: null
invalidated_dependents: []
approval_ref: null
effect_reconciliation_ref: null
artifacts:
  - ref: "artifact://d04/example/raw-result.json"
    sha256: "280db14100b375b4b8d6235149bce126596d6b17133a060ea70a1516f9042125"
rollback_result: null
residue_result: null
```

## 31.4 DocumentationGroundingRecord

```yaml
grounding_id: GND-D04-EXAMPLE-001
source_id: SRC-D04-EXAMPLE-001
source_version: "1.0.0"
source_hash: "6024efc14b65d2f6208a7a1fa99a530573db4c09ebc87e7fff42b31487faa719"
exact_locator: "section://requirements/authentication#password-reset"
grounded_claim: "Password reset requires authenticated one-time recovery challenge."
retrieval_method: FILES_FIRST_EXACT_LOCATOR
state: GROUNDED
stale_invalidation_trigger: "source version/hash or exact locator content changes"
```

## 31.5 EffectObservation

```yaml
observation_id: OBS-D04-EXAMPLE-001
effect_intent_ref: INTENT-EFFECT-D04-001
provider_response_ref: PROVIDER-RESP-D04-001
observation_method: "independent readback endpoint"
observed_state: "target record exists with expected immutable ID"
observed_at: "2026-10-07T10:05:00+08:00"
observer: ROLE-OBSERVER
```

## 31.6 EffectReconciliationReceipt

```yaml
receipt_id: RECON-D04-EXAMPLE-001
effect_intent_ref: INTENT-EFFECT-D04-001
observation_refs:
  - OBS-D04-EXAMPLE-001
readback_refs:
  - READBACK-D04-EXAMPLE-001
state: CONFIRMED_EFFECT
oracle: OR-EFFECT-D04-001
actual: "observed target state equals intended state"
next_action: PROMOTE_EVIDENCE
checker: ROLE-EFFECT-CHECKER
timestamp: "2026-10-07T10:06:00+08:00"
```

## 31.7 InvalidationRecord

```yaml
invalidation_id: INV-D04-EXAMPLE-001
changed_subject:
  id: SPEC-D04-EXAMPLE-001
  old_version: "1.0.0"
  new_version: "1.1.0"
change_class: NON_BREAKING_CONTRACT
changed_fields:
  - response_timeout_ms
reverse_dependents_examined:
  - ACC-D04-EXAMPLE-001
  - TEST-D04-EXAMPLE-001
  - EVD-D04-EXAMPLE-001
invalidated:
  - TEST-D04-EXAMPLE-001
  - EVD-D04-EXAMPLE-001
preserved_current:
  - REQ-D04-EXAMPLE-002
reason: "only dependents consuming response_timeout_ms are stale"
recorded_at: "2026-10-07T10:10:00+08:00"
```

## 31.8 OrphanScanResult

```yaml
scan_id: ORPHSCAN-D04-EXAMPLE-001
direction: FORWARD_AND_REVERSE
subject_scope: PI-SLICE-D04-EXAMPLE
orphans:
  - node_ref: REQ-D04-ORPHAN-001
    missing_edge: REQ_TO_SPEC
    classification: DEFECT
    blocking_scope: GATE-D04-EXAMPLE-SECURITY
    first_failing_invariant: REQ_REQUIRES_SPEC_OR_ACCEPTED_NA
result: FAIL
repair_owner: ROLE-SPEC-OWNER
```

## 31.9 NARationaleRecord

```yaml
na_id: NA-D04-EXAMPLE-001
subject_ref: REQ-D04-WORLD-EFFECT-001
profile_ref: PROFILE-LITE-READONLY
rationale: "read-only artifact compiler has no external mutation path in this profile"
authority: ROLE-PROFILE-AUTHORITY
accepted_at: "2026-10-07T09:30:00+08:00"
consumer_visibility: REQUIRED
reopen_triggers:
  - SIDE_EFFECT_CLASS_CHANGED
  - PROFILE_CHANGED
state: ACCEPTED
```

## 31.10 AssuranceRoleBinding

```yaml
binding_id: SOD-D04-EXAMPLE-001
subject_ref: PI-SLICE-D04-EXAMPLE
profile: ASSURED
maker: ROLE-MAKER-A
checker: ROLE-CHECKER-B
acceptor: ROLE-ACCEPTOR-C
human_approver: ROLE-HUMAN-D
independent_qualifier: ROLE-IQ-E
release_authority: ROLE-RELEASE-F
independence_assertion:
  maker_checker_distinct: true
  maker_acceptor_distinct: true
  independent_qualifier_organizationally_distinct: true
state: VALID
```

## 31.11 TraceClosureReport

```yaml
report_id: TRACE-CLOSURE-D04-EXAMPLE-001
subject_scope: PI-SLICE-D04-EXAMPLE
profile: STANDARD
denominator:
  applicable_atomic_requirements: 12
  trace_complete: 12
  acceptance_bound: 12
  verification_bound: 12
  evidence_expectations_bound: 12
forward_orphans: 0
reverse_orphans: 0
stale_evidence: 0
wrong_subject_evidence: 0
blocking_tt: 0
gate_ref: GATE-D04-EXAMPLE-001
result: TRACE_CONTRACT_CURRENT
claim_ceiling: "trace/evidence contract current; no runtime execution claim"
```


## 31.12 ExecutionEvidenceReturnLedger

```yaml
return_id: EVRET-D04-SPECIMEN-001
evidence_id: EVD-D04-SPECIMEN-001
operation_id: OP-D04-EXAMPLE-001
action_ref: ACTION-D04-EXAMPLE-001
procedure_ref: PROC-D04-EXAMPLE-001
started_at: "2026-10-07T10:00:00+08:00"
ended_at: "2026-10-07T10:00:03+08:00"
stdout_ref: artifact://d04/example/stdout.txt
stderr_ref: artifact://d04/example/stderr.txt
raw_result_ref: artifact://d04/example/raw-result.json
changed_artifacts: []
changed_effects: []
blockers: []
rollback_result: NOT_APPLICABLE
residue_result: NONE
```

## 31.13 DomainProfileExtensionProjection

```yaml
extension_id: EXT-D04-SPECIMEN-001
profile_id: org.example.domain-x-specimen
inherits_core: PIPD-LIFECYCLE-SPEC@1.1.0
added_tests_or_oracles: [TEST-X-001, OR-X-001]
core_override: false
```

## 31.14 AgentHarnessTraceEvidenceRecord

```yaml
trace_id: TRACE-D04-AGENT-SPECIMEN-001
span_id: SPAN-D04-TOOL-SPECIMEN-001
run_id: RUN-D04-SPECIMEN-001
session_id: SESSION-D04-SPECIMEN-001
trajectory_id: TRAJ-D04-SPECIMEN-001
event_id: EVT-D04-SPECIMEN-001
event_class: TOOL_RESULT
subject_id: SVC-D04-EXAMPLE
subject_version: "1.0.0"
subject_hash: "d3c5bb22f8408c835133db8e0380a741b7ab03f43d4b9154ebbf6435dd4f258f"
pii_redaction_state: PASS
sampling_state: NOT_SAMPLED_CRITICAL
payload_ref: artifact://d04/trace/tool-result.json
test_oracle_refs: [TEST-D04-AGENT-001, OR-D04-AGENT-001]
evidence_candidate_state: ELIGIBLE_FOR_NORMALIZATION
```

## 31.15 CrossSessionResumePacket

```yaml
workflow_id: CROSS_SESSION_PIPELINE
resume_packet_id: CSP-D04-SPECIMEN-001
subject_id: SVC-D04-EXAMPLE
subject_version: "1.0.0"
subject_hash: "d3c5bb22f8408c835133db8e0380a741b7ab03f43d4b9154ebbf6435dd4f258f"
from_session_id: SESSION-SPECIMEN-A
to_session_id: SESSION-SPECIMEN-B
checkpoint_ref: CHECKPOINT-D04-SPECIMEN-001
checkpoint_evidence_ref: EVD-D04-CHECKPOINT-SPECIMEN-001
context_digest: "79183e2808119d294490974a3483036ec787618334328087982348ebbd3fd73b"
context_trust_label: SOURCE_BOUND_REDACTED
issued_at: "2026-10-07T10:00:00+08:00"
expires_at: "2026-10-08T10:00:00+08:00"
purge_after: "2026-10-15T10:00:00+08:00"
```

## 31.16 LifecycleAssuranceMetric

```yaml
metric_id: METRIC-D04-SPECIMEN-TRACE-COMPLETENESS
subject_scope: PI-SLICE-D04-EXAMPLE
measured_at: "2026-10-07T10:20:00+08:00"
numerator: 12
denominator: 12
value: 1.0
state: CURRENT
source_graph_hash: "d88ef4f58102b9eeb3594dfe79180029d7dad1d6d785d49eb1cf2872018d501d"
blocking_rule: "value < 1.0 => TRACE_BLOCKED"
```

# 32｜Verification / Destructive Test Registry for DOC-04

| Class | Fixture / mutation | Expected | First failing invariant |
|---|---|---|---|

| `NORMAL` | well-formed full trace | `PASS` | `NONE` |

| `NEGATIVE` | REQ missing SPEC | `FAIL` | `REQ_REQUIRES_SPEC_OR_ACCEPTED_NA` |

| `EDGE` | all children N/A with accepted rationales | `PASS` | `NONE` |

| `BOUNDARY` | LITE profile attempts remove subject hash binding | `FAIL` | `PROFILE_CANNOT_WEAKEN_CORE_EVIDENCE_IDENTITY` |

| `ADVERSARIAL` | maker injects self-authored independent_pass flag | `FAIL` | `INDEPENDENCE_MUST_BE_EXTERNALLY_ESTABLISHED` |

| `MUTATION` | remove VER from CURRENT trace | `FAIL` | `TRACE_VERIFICATION_REF_REQUIRED` |

| `APPARENT_PASS` | CI green but acceptance evidence absent | `FAIL` | `CI_SUCCESS_NOT_PRODUCT_ACCEPTANCE` |

| `STALE_EVIDENCE` | evidence TTL expired | `FAIL` | `EVIDENCE_FRESHNESS_EXPIRED` |

| `WRONG_SUBJECT` | same test, different subject ID | `FAIL` | `EVIDENCE_WRONG_SUBJECT` |

| `WRONG_HASH` | same subject ID/version, different hash | `FAIL` | `EVIDENCE_SUBJECT_HASH_MISMATCH` |

| `ORPHAN_REQ` | REQ has no SPEC edge | `FAIL` | `REQ_REQUIRES_SPEC_OR_ACCEPTED_NA` |

| `ORPHAN_SPEC` | SPEC has no owning requirement/explicit support disposition | `FAIL` | `SPEC_ORPHAN_UNDISPOSITIONED` |

| `ORPHAN_ACC` | ACC has no requirement owner | `FAIL` | `ACCEPTANCE_ORPHAN` |

| `SELF_APPROVAL` | ASSURED maker=checker=acceptor | `FAIL` | `SOD_MAKER_CHECKER_ACCEPTOR_COLLAPSE` |

| `FOREIGN_EVIDENCE` | evidence expectation belongs to another requirement | `FAIL` | `EVIDENCE_EXPECTATION_OWNERSHIP_MISMATCH` |

| `PROVIDER_SUCCESS_WITHOUT_EFFECT_OBSERVATION` | HTTP 200 only | `FAIL` | `PROVIDER_SUCCESS_CANNOT_CONFIRM_WORLD_EFFECT` |

| `GLOBAL_INVALIDATION_OVERREACH` | unrelated sibling invalidated | `FAIL` | `AFFECTED_ONLY_INVALIDATION_VIOLATED` |

| `STALE_DEPENDENT_NOT_INVALIDATED` | changed SPEC leaves consuming evidence current | `FAIL` | `STALE_DEPENDENT_LEAK` |

| `PROFILE_REMOVES_CORE_TEST` | profile drops mandatory TEST ID without accepted N/A | `FAIL` | `PROFILE_CORE_TEST_REMOVAL_FORBIDDEN` |

| `DOCUMENT_MATERIALIZED_CLAIMED_AS_VERIFIED` | document existence raises VERIFIED claim | `FAIL` | `CLAIM_CEILING_EXCEEDED` |

Validator MUST return the first failing invariant and subject identity. A bare `FAIL` is non-conformant because it不能支援 deterministic repair、TT routing或 regression replay。


### 32.1 r2 blocking-gap mutation fixtures

| Test ID | Mutation | Expected first failing invariant |
|---|---|---|
| `TEST-D04-R2-001` | change EVD subject_hash to a different but valid 64-hex value | `EVIDENCE_SUBJECT_HASH_MISMATCH` |
| `TEST-D04-R2-002` | N/A row omits one of six NA edge resolutions | `NA_REQUIRED_EDGE_RESOLUTION_MISSING` |
| `TEST-D04-R2-003` | profile extension removes a core TEST ID | `PROFILE_REMOVED_CORE_TEST` |
| `TEST-D04-R2-004` | ExecutionEvidenceReturnLedger has `ended_at < started_at` | `EXECUTION_INTERVAL_INVALID` |
| `TEST-D04-R2-005` | trace uses foreign `session_id/context_digest` | `FOREIGN_SESSION_CONTEXT` |
| `TEST-D04-R2-006` | critical Agent Harness event sampled/dropped | `CRITICAL_TRACE_EVENT_MISSING` |
| `TEST-D04-R2-007` | evidence threat row lacks TEST/ORACLE or EVDX | `THREAT_BINDING_INCOMPLETE` |
| `TEST-D04-R2-008` | `TRACE_CURRENT` token written into gate state/result | `GATE_TRACE_NAMESPACE_COLLISION` |
| `TEST-D04-R2-009` | JCS-bound target accepts JSON negative zero `-0` without defensive error | `JCS_ERRATA_7920_NEGATIVE_ZERO_NOT_REJECTED` |
| `TEST-D04-R2-010` | one of CAND-01..22 or 8 workflow IDs disappears from inherited crosswalk | `NAMED_IDENTITY_ANTI_DEGRADATION_FAIL` |

# 33｜Source Coverage Ledger / Atomic Requirement Closure — r2 Recomputed

r2 不接受作者手填 `33/33` 作為 closure evidence。分母固定由 repaired Skeleton/AUDIT 提供；local checker只在**實質正文 anchor存在、必要 token/contract可解析、且無 r1 finding regression**時輸出 PASS。

## 33.1 Repaired-Skeleton DOC-04 source units — 29/29

| Source locator | Mapped unit | r2 substantive landing | Result |
|---|---|---|---|
| `P0:182` | Retained 2026 SUPPORT Evidence Registry & Cross-Source Conclusions | §27/§34 inherited IDs + currentness | PASS |
| `P0:1921` | Failure / Evidence | §9–23/Appendix B/C | PASS |
| `P0:2558` | Conformance / Stable TEST-ORACLE Identity | §13/§32 | PASS |
| `P0:2946` | Appendix A — Repair Acceptance Criteria | Appendix D external receipt contract + delivery receipt | PASS |
| `P1:187` | P-07 Evidence Is Subject-Bound | §10–12 | PASS |
| `P1:728` | PI-11 Acceptance | §7 | PASS |
| `P1:743` | PI-12 Verification / Oracle | §8/§13 | PASS |
| `P1:746` | PI-13 Evidence Expectation | §9 | PASS |
| `P1:1216` | requirement-trace.schema.json | §26/§31 | PASS |
| `P1:3228` | evidence.schema.json | §10/§26/§31 | PASS |
| `P1:6121` | PART VI — Handoff, Evidence, Security, Change | §18–24.6 | PASS |
| `P1:6172` | 25. Evidence Return Contract | §10.3/§31.12 | PASS |
| `P1:6386` | Failure / Evidence | §11–23 | PASS |
| `P1:6496` | 33. Minimal Acceptance Metrics | §24A | PASS |
| `P1:6610` | 11 Acceptance Predicates | §7 | PASS |
| `P1:6611` | 12 Verification / Oracles | §8/§13 | PASS |
| `P1:6612` | 13 Evidence Expectations | §9 | PASS |
| `P1:6641` | 11 Evidence Return Contract | §10.3 | PASS |
| `P1:6804` | AP-06 Evidence Without Subject Identity | §11/§32 | PASS |
| `P1:6813` | AP-09 Sender Self-Acceptance | §22/§32 | PASS |
| `P1:6852` | 46. V1.1 Acceptance Criteria | §25/§35 | PASS |
| `P2:1317` | Implementation + Verification 之後 | §23 | PASS |
| `P2:2257` | Agent Harness Guardrail / Handoff / Trace | §24.4/§24.5 | PASS |
| `INSTR:358` | Trace / Evidence | whole document | PASS |
| `INSTR:999` | DOC-04 Trace / Acceptance / Verification / Evidence Specification | whole document | PASS |
| `INSTR:1122` | DOC-07 Conformance Tests / Oracles / Examples | §3/§13/§32 | PASS |
| `INSTR:1531` | 19.5 Acceptance | §28.2 | PASS |
| `INSTR:2024` | DOC-04 Trace / Acceptance / Evidence Spec Skeleton | §4–26 | PASS |
| `INSTR:2036` | Requirement Trace / Acceptance / Evidence Matrix | §4/§31 | PASS |

Local result：`29 PASS / 0 PARTIAL / 0 FAIL`。這是本 artifact 的 author-side conformance result，不是 independent assurance。

## 33.2 DOC-04 atomic requirement ledger — 33/33 after substantive repair

| Atomic ID | Parent | Area | Atomic obligation | TEST | ORACLE | r2 substantive ref | Result |
|---|---|---|---|---|---|---|---|
| `STD-REQ-79A6948B-C01` | `STD-REQ-79A6948B` | P-07 Evidence Is Subject-Bound | evidence.subject bound | `TEST-79A6948B` | `OR-79A6948B` | §10–12 | COVERED_R2_VALIDATED |
| `STD-REQ-79A6948B-C02` | `STD-REQ-79A6948B` | P-07 Evidence Is Subject-Bound | evidence.version bound | `TEST-79A6948B` | `OR-79A6948B` | §10–12 | COVERED_R2_VALIDATED |
| `STD-REQ-79A6948B-C03` | `STD-REQ-79A6948B` | P-07 Evidence Is Subject-Bound | evidence.content_hash bound | `TEST-79A6948B` | `OR-79A6948B` | §10–12 | COVERED_R2_VALIDATED |
| `STD-REQ-79A6948B-C04` | `STD-REQ-79A6948B` | P-07 Evidence Is Subject-Bound | evidence.environment bound | `TEST-79A6948B` | `OR-79A6948B` | §10–12 | COVERED_R2_VALIDATED |
| `STD-REQ-79A6948B-C05` | `STD-REQ-79A6948B` | P-07 Evidence Is Subject-Bound | evidence.operator_or_checker bound | `TEST-79A6948B` | `OR-79A6948B` | §10–12 | COVERED_R2_VALIDATED |
| `STD-REQ-79A6948B-C06` | `STD-REQ-79A6948B` | P-07 Evidence Is Subject-Bound | evidence.timestamp bound | `TEST-79A6948B` | `OR-79A6948B` | §10–12 | COVERED_R2_VALIDATED |
| `STD-REQ-79A6948B-C07` | `STD-REQ-79A6948B` | P-07 Evidence Is Subject-Bound | evidence.procedure bound | `TEST-79A6948B` | `OR-79A6948B` | §10–12 | COVERED_R2_VALIDATED |
| `STD-REQ-79A6948B-C08` | `STD-REQ-79A6948B` | P-07 Evidence Is Subject-Bound | wrong subject/version/hash evidence rejected | `TEST-79A6948B` | `OR-79A6948B` | §10–12 | COVERED_R2_VALIDATED |
| `STD-REQ-10C6C743-C05` | `STD-REQ-10C6C743` | C-12 DomainProfileExtension | added_tests_or_oracles[] | `TEST-10C6C743` | `OR-10C6C743` | §24.3/§31.13/§35 | COVERED_R2_VALIDATED |
| `STD-REQ-90364E5B-C01` | `STD-REQ-90364E5B` | C-12 DomainProfileExtension | [STD-REQ-EXT-001] A domain extension MUST NOT weaken or override core identity separation, claim ceilings, permission gates, source binding, evidence subject binding, or affected-only invalidation. | `TEST-90364E5B` | `OR-90364E5B` | §24 | COVERED_R2_VALIDATED |
| `STD-REQ-D28A8B60-C08` | `STD-REQ-D28A8B60` | C-14 Security Threat Model | test/oracle | `TEST-D28A8B60` | `OR-D28A8B60` | §24.6/§32.1/§35 | COVERED_R2_VALIDATED |
| `STD-REQ-F4669FFF-C04` | `STD-REQ-F4669FFF` | 18.4 Destructive Fixtures Required by the Standard | fake evidence | `TEST-F4669FFF` | `OR-F4669FFF` | §32 | COVERED_R2_VALIDATED |
| `STD-REQ-3CA02A9C-C18` | `STD-REQ-3CA02A9C` | 22. Target Profile — SKILL / PLUGIN | Evidence return | `TEST-3CA02A9C` | `OR-3CA02A9C` | §24 | COVERED_R2_VALIDATED |
| `STD-REQ-B5C7D219-C12` | `STD-REQ-B5C7D219` | 22.1 Skill/Plugin Conformance Additions | evidence return | `TEST-B5C7D219` | `OR-B5C7D219` | §24 | COVERED_R2_VALIDATED |
| `STD-REQ-2E59E411-C01` | `STD-REQ-2E59E411` | 23A. World Effect / Observation / Readback / Reconciliation | [STD-REQ-EFFECT-001] Tool/API exit code, HTTP success, SDK return, or provider acknowledgement MUST NOT directly yield CONFIRMED_EFFECT. Effectful profiles require a reconciliation receipt before effect evidence can close an acceptance gate. | `TEST-2E59E411` | `OR-2E59E411` | §15–16 | COVERED_R2_VALIDATED |
| `STD-REQ-D4FB7180-C10` | `STD-REQ-D4FB7180` | 24. Receiver Handoff Contract | EVIDENCE expected | `TEST-D4FB7180` | `OR-D4FB7180` | §18/§29 | COVERED_R2_VALIDATED |
| `STD-REQ-22E53BD2-C01` | `STD-REQ-22E53BD2` | 25. Evidence Return Contract | subject/version/hash | `TEST-22E53BD2` | `OR-22E53BD2` | §9–14 | COVERED_R2_VALIDATED |
| `STD-REQ-22E53BD2-C02` | `STD-REQ-22E53BD2` | 25. Evidence Return Contract | environment | `TEST-22E53BD2` | `OR-22E53BD2` | §9–14 | COVERED_R2_VALIDATED |
| `STD-REQ-22E53BD2-C03` | `STD-REQ-22E53BD2` | 25. Evidence Return Contract | operation/procedure | `TEST-22E53BD2` | `OR-22E53BD2` | §10.3/§31.12/§35 | COVERED_R2_VALIDATED |
| `STD-REQ-22E53BD2-C04` | `STD-REQ-22E53BD2` | 25. Evidence Return Contract | operator | `TEST-22E53BD2` | `OR-22E53BD2` | §9–14 | COVERED_R2_VALIDATED |
| `STD-REQ-22E53BD2-C05` | `STD-REQ-22E53BD2` | 25. Evidence Return Contract | checker | `TEST-22E53BD2` | `OR-22E53BD2` | §9–14 | COVERED_R2_VALIDATED |
| `STD-REQ-22E53BD2-C06` | `STD-REQ-22E53BD2` | 25. Evidence Return Contract | start/end time | `TEST-22E53BD2` | `OR-22E53BD2` | §10.3/§31.12/§35 | COVERED_R2_VALIDATED |
| `STD-REQ-22E53BD2-C07` | `STD-REQ-22E53BD2` | 25. Evidence Return Contract | raw result | `TEST-22E53BD2` | `OR-22E53BD2` | §9–14 | COVERED_R2_VALIDATED |
| `STD-REQ-22E53BD2-C08` | `STD-REQ-22E53BD2` | 25. Evidence Return Contract | test/oracle refs | `TEST-22E53BD2` | `OR-22E53BD2` | §9–14 | COVERED_R2_VALIDATED |
| `STD-REQ-22E53BD2-C09` | `STD-REQ-22E53BD2` | 25. Evidence Return Contract | effect observation | `TEST-22E53BD2` | `OR-22E53BD2` | §9–14 | COVERED_R2_VALIDATED |
| `STD-REQ-22E53BD2-C10` | `STD-REQ-22E53BD2` | 25. Evidence Return Contract | reconciliation status | `TEST-22E53BD2` | `OR-22E53BD2` | §9–14 | COVERED_R2_VALIDATED |
| `STD-REQ-22E53BD2-C11` | `STD-REQ-22E53BD2` | 25. Evidence Return Contract | rollback/residue if applicable | `TEST-22E53BD2` | `OR-22E53BD2` | §9–14 | COVERED_R2_VALIDATED |
| `STD-REQ-22E53BD2-C12` | `STD-REQ-22E53BD2` | 25. Evidence Return Contract | retention/freshness metadata | `TEST-22E53BD2` | `OR-22E53BD2` | §9–14 | COVERED_R2_VALIDATED |
| `STD-REQ-7CD1E5E6-C01` | `STD-REQ-7CD1E5E6` | 26.7 SoD Enforcement | ASSURED/high-risk packages MUST NOT collapse Maker=Checker=Acceptor. Same-model or same-process review may be useful evidence but MUST NOT be labeled independent unless organizational independence is actually established. | `TEST-7CD1E5E6` | `OR-7CD1E5E6` | §22 | COVERED_R2_VALIDATED |
| `STD-REQ-97BCACAC-C01` | `STD-REQ-97BCACAC` | 32. Mandatory Conformance Test Registry | Every test has stable TEST/ORACLE IDs. Profiles MAY add tests but MUST NOT remove applicable core tests without an explicit N/A rationale accepted by the profile authority. | `TEST-97BCACAC` | `OR-97BCACAC` | §13/§32 | COVERED_R2_VALIDATED |
| `STD-REQ-44B56684-C06` | `STD-REQ-44B56684` | 50. Final Normative Statement | project can show requirement trace closure | `TEST-44B56684` | `OR-44B56684` | §33 | COVERED_R2_VALIDATED |
| `STD-REQ-44B56684-C09` | `STD-REQ-44B56684` | 50. Final Normative Statement | project can show evidence subject binding | `TEST-44B56684` | `OR-44B56684` | §33 | COVERED_R2_VALIDATED |
| `STD-REQ-44B56684-C12` | `STD-REQ-44B56684` | 50. Final Normative Statement | project can show conformance TEST/ORACLE results appropriate to claim | `TEST-44B56684` | `OR-44B56684` | §33 | COVERED_R2_VALIDATED |

r1 audit 的 4 個非 PASS row 已以 substantive contracts閉合：

- `STD-REQ-10C6C743-C05` → §24.3 `added_tests_or_oracles[]`；
- `STD-REQ-D28A8B60-C08` → §24.6 threat→TEST/ORACLE/EVDX matrix；
- `STD-REQ-22E53BD2-C03` → §10.3 `operation_id/action_ref/procedure_ref`；
- `STD-REQ-22E53BD2-C06` → §10.3 `started_at/ended_at`。

## 33.3 Machine-generated local closure receipt

```yaml
validator_id: DOC04-R2-REPAIR-CHECK
validator_version: "2.0.0"
atomic_denominator: 33
pass: 33
partial: 0
fail: 0
skeleton_source_units_denominator: 29
skeleton_source_units_pass: 29
candidate_identity_crosswalk: "22/22"
workflow_identity_crosswalk: "8/8"
blocking_audit_findings_closed: "7/7"
major_audit_findings_closed: "6/6"
minor_audit_findings_closed: "3/3"
claim_scope: AUTHOR_SIDE_LOCAL_CONFORMANCE_ONLY
```

This receipt is regenerated during post-build validation; it is not permission, Independent PASS, Human Ratification, Release or Production truth。

# 34｜Currentness Support Registry & Authority Barrier

| Support ID | Official source | Checked | Currentness conclusion | PIPD authority |
|---|---|---|---|---|
| `SUP-D04-JSONSCHEMA` | `json-schema.org/specification` | 2026-10-07 | official site states current version is 2020-12 | SUPPORT; dialect already mandated by P1/P2 |
| `SUP-D04-SLSA` | `slsa.dev/spec/v1.2/` | 2026-10-07 | v1.2 Approved | SUPPORT provenance adapter only |
| `SUP-D04-INTOTO` | in-toto attestation official repository spec | 2026-10-07 | latest spec advertises v1.2 | SUPPORT attestation adapter only |
| `SUP-D04-GH-ATTEST` | GitHub Artifact Attestations / `actions/attest` releases | 2026-10-07 | v4.2.2 observed Latest; verification still required | SUPPORT/provider-specific, DOC-09-owned |
| `SUP-D04-JCS` | RFC 8785 + RFC Editor Errata | 2026-10-07 | Informational RFC; verified technical Errata 7920 and editorial 6292 reviewed | optional hash-profile reference only |
| `SUP-D04-PROVO` | W3C PROV-O | 2026-10-07 | W3C Recommendation, stable reference | domain mapping only |

### JCS errata acceptance fixture

If a target project activates JCS：

- it MUST record RFC 8785 + current verified errata in its admission/currentness record；
- fixture `TEST-D04-R2-009` MUST reject or stop processing on JSON Number `-0` per verified Errata 7920 defensive guidance；
- old byte-hash identities MUST NOT be silently reinterpreted through JCS；
- canonicalization alone MUST NOT be treated as authentication/signature/trust proof。

External currentness drift only stales the corresponding adapter/currentness record；it never rewrites PIPD normative semantics。

# 35｜DOC-04 Deterministic Conformance Algorithms

## 35.1 Trace closure validator

```text
validate_trace(req, graph):
  validate canonical RequirementTraceRow schema
  assert source_refs resolve and are current or valid inherited refs
  assert exactly-one canonical requirement owner
  if req.status == NOT_APPLICABLE:
      validate_NA_binding(req, graph)   # six typed NA edge resolutions
  else:
      resolve SPEC/ACC/VER/EVDX/DEL/GATE as normal typed objects
  run forward + reverse orphan scan
  calculate trace_completeness / acceptance_coverage
  return first failing invariant or TRACE_CONTRACT_CURRENT
```

## 35.2 Evidence promotion validator

```text
promote(evidence, expectation, execution_return, overlay):
  validate canonical evidence schema
  assert exact expectation↔subject/version/hash match
  assert operation/procedure/environment/fixture match
  assert started_at <= ended_at and approval scope/time if applicable
  assert oracle current; freshness current; checker present when PASS
  assert raw result/checksum/effect inventory requirements satisfied
  if effectful: require eligible reconciliation receipt
  assert no active invalidation edge
  return ELIGIBLE_FOR_GATE_CONSUMPTION
```

`ELIGIBLE_FOR_GATE_CONSUMPTION` != gate PASS。

## 35.3 N/A validator

```text
validate_NA_binding(req, graph):
  assert req.na_rationale resolves to ACCEPTED rationale
  expected = {SPEC, ACC, VER, EVD_EXPECTATION, DEL, GATE}
  resolve six req refs
  assert each is NAEdgeResolutionRecord
  assert edge_kind set == expected
  assert same requirement_ref and na_rationale_ref
  assert authority current and no reopen trigger active
```

## 35.4 Profile/test-set validator

```text
validate_profile_extension(ext, core_tests):
  assert ext.core_override == false
  effective = core_tests UNION ext.added_tests_or_oracles
  assert core_tests subset effective
```

## 35.5 Agent/cross-session validator

```text
validate_resume(packet, current_subject):
  assert workflow_id == CROSS_SESSION_PIPELINE
  assert packet.subject/version/hash == current_subject
  assert checkpoint evidence current
  assert context trust label not downgraded
  assert now <= expires_at
  assert purge policy declared

validate_agent_trace(trace):
  assert critical event classes are unsampled
  assert PII/secret redaction state valid
  assert monotonic sequence / parent span continuity
  assert telemetry candidate is not direct PASS
```

## 35.6 Evidence threat/SoD/effect validators

- C-14 row incomplete → `THREAT_BINDING_INCOMPLETE`；
- ASSURED maker/checker/acceptor collapse → `SOD_COLLAPSE`；
- same-model checker claiming independent → `FALSE_INDEPENDENCE_CLAIM`；
- provider success without observation/reconciliation when effectful → `WORLD_EFFECT_UNCONFIRMED`；
- reverse dependency not consuming changed fields MUST remain CURRENT；global invalidation overreach → `INVALIDATION_SCOPE_OVERREACH`。

## 35.7 Reference implementation

Appendix F 的 `pipd_doc04_validate.py` is the extractable executable reference for the cross-object rules above。Canonical schema validation remains delegated to extracted P2 Draft 2020-12 schemas；the companion validator never edits canonical objects。

# 36｜Author-Side Coverage / Repair Claim Audit

本節只記錄 r2 document construction/local validation；不是 independent assurance。

```yaml
repair_controller: AUDIT-PIPD-LS-DOC04-2026-10-07-R1
superseded_r1_sha256: ffefd02b35c0e2b5416ac483b43d8e1aaa7ad5db9f5e05c2f2e465da66fc853d
p0_instruction_snapshot_sha256: 3bd7ae052fa5279db14d2f0c4bc4b926af3f040712ad1d6de0c5a36b7cda91b2
canonical_responsibility_coverage: "all retained r1 core responsibilities + audit repair deltas"
skeleton_doc04_source_units: "29/29 author-side PASS after repair"
atomic_requirement_coverage: "33/33 author-side PASS after repair"
canonical_schema_specimens: "5/5 locally schema-validated during build"
companion_validator_selftest: "POSITIVE_PASS_AND_NEGATIVE_INTERVAL_REJECTED_AS_EXPECTED"
p0_snapshot_integrity: "HASH_REPLAY_PASS"
companion_machine_contracts: MATERIALIZED
na_machine_closure: MATERIALIZED_AND_LOCALLY_TESTED
execution_evidence_return: MATERIALIZED
lifecycle_metrics: MATERIALIZED
agent_harness_trace_contract: MATERIALIZED
cross_session_pipeline: MATERIALIZED
assured_threat_binding: MATERIALIZED
inherited_candidate_crosswalk: "22/22"
inherited_workflow_crosswalk: "8/8"
technology_parallel_disposition_vocabulary: REMOVED
canonical_gate_namespace_collision: REMOVED
full_canonical_schema_urns: RESTORED
jcs_verified_errata_review: MATERIALIZED
blocking_audit_findings_closed: "7/7 author-side"
major_audit_findings_closed: "6/6 author-side"
minor_audit_findings_closed: "3/3 author-side"
open_tt: 0
open_cr: 0
independent_assurance: NOT_EXECUTED
human_ratification: NOT_EXECUTED
runtime_target_validation: NOT_EXECUTED
release_status: NOT_RELEASED
production_status: NOT_PRODUCTION_VERIFIED
```

`33/33` 等 closure數字只能由 build/check script重算後更新；不得從「作者寫了 COVERED」本身推導。若 post-build scanner重算不符，本節 MUST 被降級並重新出檔。

# 37｜Operational Handoff / Consumer Read Order

Downstream Human/AI/Tool/Validator消費順序：

1. 讀 DOC-01 claim/state/authority；
2. 讀 DOC-02 requirement/SPEC/TechnologyAdmission；
3. 讀 DOC-03 PD binding/TQAEP/RepoContext；
4. 讀 DOC-04 trace/evidence contracts；
5. 需要 permission/effect/admission時轉 DOC-05；
6. 需要 profile applicability時轉 DOC-06；
7. 需要 fixture/oracle details時轉 DOC-07；
8. 需要 CI/release/provider adapters時轉 DOC-09。

Receiver若看到 missing/stale/wrong-subject/wrong-permission refs，必須 NACK affected slice；不得回頭重判整個歷史 corpus，除非 DOC-01 change rules要求 return-to-PI。

# 38｜Final Normative Statement

一個 PIPD project只有在能對 applicable atomic requirements展示完整且 current 的：

`SRC → INTENT → REQ → SPEC → ACC → VER → EVD_EXPECTATION → EVD → DEL → GATE → PD_BINDING`

並且 evidence能證明自己的 subject/version/hash/environment/procedure/oracle、所有 stale/foreign/self-approved/apparent-pass狀態被拒絕、effectful operations有 observation/reconciliation、profiles沒有削弱 portable core、changes只 affected-only invalidate時，才具備 DOC-04 所定義的 **traceability / assurance data integrity**。

這個完整性仍然只是 lifecycle proof infrastructure。它不能自行產生 execution authority、Independent PASS、Human ratification、release或production truth。

# 39｜r2 PATCH Authority & AUDIT Finding Closure Matrix

本節 materialize current P0 PATCH 的 repair contract，並提供 AUDIT finding → substantive repair → local validation 的 stable locator。它是 **repair trace**，不是 Independent PASS。每一列的 `AUTHOR_SIDE_CLOSED_LOCAL` 只表示本 r2 bytes 已包含指定 repair 且已由本地 deterministic checks 重算；外部 checker、Human、runtime、release 狀態仍依 front matter claim ceiling。

| Finding | Required repair | r2 substantive landing | Local validation / closure |
|---|---|---|---|
| `AUD-D04-S1-001` | Canonical artifact metadata | front matter / §0 | CommonArtifactMetadata denominator + non-circular `content_hash_rule`; `AUTHOR_SIDE_CLOSED_LOCAL` |
| `AUD-D04-S1-002` | Reproducible P0 grounding | §2.2 + Appendix E | physical source SHA + LF-normalized immutable snapshot SHA replay; `AUTHOR_SIDE_CLOSED_LOCAL` |
| `AUD-D04-S1-003` | Remove parallel technology disposition / restore SBB lineage | §27.1–§27.5 | 22 inherited CAND IDs + canonical TechnologyAdmission read-through + exact 17 disposition barrier; `AUTHOR_SIDE_CLOSED_LOCAL` |
| `AUD-D04-S1-004` | Machine/prose equivalence for companion ledgers | §25 + §35 + Appendix F | typed companion registry + deterministic graph validator + positive/negative self-test; `AUTHOR_SIDE_CLOSED_LOCAL` |
| `AUD-D04-S1-005` | Machine-valid N/A binding | §20 + §31.9 + §35.3 | six typed `NAEdgeResolutionRecord` edge kinds + semantic validator, no canonical schema fork; `AUTHOR_SIDE_CLOSED_LOCAL` |
| `AUD-D04-S1-006` | Repair false 33/33 | §24.3/§24.6/§10.3 + §33 | all four prior non-pass atomics now have substantive fields/contracts; denominator recomputed 33/33; `AUTHOR_SIDE_CLOSED_LOCAL` |
| `AUD-D04-S1-007` | Actual post-write readback | Appendix D + external delivery receipt | final file SHA/bytes/lines MUST be returned after final write; no self-hash circularity; closure only when delivery receipt is emitted |
| `AUD-D04-S2-001` | Lifecycle assurance metrics | §24A + §31.16 | `trace_completeness`, `acceptance_coverage`, `evidence_completeness` exact numerator/denominator/freshness/blocking semantics; `AUTHOR_SIDE_CLOSED_LOCAL` |
| `AUD-D04-S2-002` | Agent Harness trace/evidence | §24.4 + §31.14 + §35.5 | run/session/trajectory/span/event + PII/secret redaction + loss/sampling + evidence promotion; `AUTHOR_SIDE_CLOSED_LOCAL` |
| `AUD-D04-S2-003` | Named technology/workflow anti-degradation | §27.1–§27.2 | `CAND-01..22` 22/22 and workflow IDs 8/8; `CROSS_SESSION_PIPELINE` fully expanded; `AUTHOR_SIDE_CLOSED_LOCAL` |
| `AUD-D04-S2-004` | Executor-grade evidence-return carrier | §10.3 + §31.12 | operation/action, interval, stdout/stderr/status, changed artifacts/effects, checksums, blockers, approval, rollback/residue; `AUTHOR_SIDE_CLOSED_LOCAL` |
| `AUD-D04-S2-005` | ASSURED evidence-threat binding | §24.6 + §35.6 | C-14 denominator bound to stable TEST/ORACLE/EVDX for trace/evidence integrity threats; `AUTHOR_SIDE_CLOSED_LOCAL` |
| `AUD-D04-S2-006` | Remove pseudo gate state namespace collision | §18 | `trace_closure_state` separated from read-only canonical gate owner state; `AUTHOR_SIDE_CLOSED_LOCAL` |
| `AUD-D04-S3-001` | Full canonical schema URNs | §26.1 | all five URNs written in full; `AUTHOR_SIDE_CLOSED_LOCAL` |
| `AUD-D04-S3-002` | Full example SHA-256 | §30 Case C | 64-hex identity, no ellipsis/truncation; `AUTHOR_SIDE_CLOSED_LOCAL` |
| `AUD-D04-S3-003` | JCS verified errata | §34 + §32.1 | RFC 8785 errata review includes verified technical Errata 7920 negative-zero fixture; `AUTHOR_SIDE_CLOSED_LOCAL` |

## 39.1 Current PATCH non-regression contract

r2 MUST satisfy all of the following simultaneously:

1. retain r1 narrow waist, parent→atomic reduction, ACC/VER/ORACLE separation, EVD expectation/actual separation, subject-bound evidence, freshness/replay, world-effect reconciliation, affected-only invalidation, SoD, claim ceiling, sibling boundaries, worked cases and five canonical specimens；
2. close all 7 S1 + 6 S2 + 3 S3 AUDIT findings without architecture reset；
3. execute index review → substantive locator → keyword full-text scan → cross-validation → compound-child decomposition → substantive-body test → named-tool/technology/workflow anti-degradation；
4. preserve canonical owner boundaries: DOC-04 owns legal evidence consumption semantics, not sibling technology selection or release implementation；
5. forbid restoration of r1 apparent-pass claims unless denominators are recomputed from the final r2 bytes；
6. emit one final Markdown file plus an **external post-write ReadbackReceipt** bound to its final SHA-256/bytes/lines。

Any later edit that invalidates one of these predicates invalidates this repair closure and requires affected-only revalidation.

# Appendix A｜Canonical Schema Field Denominators

## A.1 `requirement-trace.schema.json`

Required：`requirement_id, source_refs, owner, spec_ref, acceptance_ref, verification_ref, evidence_expectation_ref, deliverable_ref, gate, status, version, hash, invalidated_by`。`status=NOT_APPLICABLE` 時 `na_rationale`必須 non-empty。

## A.2 `evidence.schema.json`

Required：`evidence_id, subject_id, subject_version, subject_hash, fixture_or_input_refs, environment, procedure_ref, expected, actual, oracle, oracle_result, result, timestamp, producer, first_failing_invariant, invalidated_dependents, artifacts`。PASS requires checker + oracle PASS + at least one hashed artifact。

## A.3 `documentation-grounding.schema.json`

Required：`grounding_id, source_id, source_version, source_hash, exact_locator, grounded_claim, retrieval_method, state, stale_invalidation_trigger`。

## A.4 `effect-observation.schema.json`

Required：`observation_id, effect_intent_ref, provider_response_ref, observation_method, observed_state, observed_at, observer`。

## A.5 `effect-reconciliation.schema.json`

Required：`receipt_id, effect_intent_ref, observation_refs, readback_refs, state, oracle, actual, next_action, checker, timestamp`；state/next_action enum必須遵循 canonical standard。

# Appendix B｜First-Failing-Invariant Registry

| Invariant ID | Meaning | Default disposition |
|---|---|---|
| `REQ_REQUIRES_SPEC_OR_ACCEPTED_NA` | applicable REQ缺 SPEC | TEMP_CLOSED + TT |
| `ACCEPTANCE_PREDICATE_UNCHECKABLE` | acceptance不可觀察/不可判定 | FAIL |
| `TRACE_VERIFICATION_REF_REQUIRED` | trace缺 VER | FAIL |
| `EVIDENCE_EXPECTATION_MISSING` | VER無 evidence expectation | FAIL |
| `EVIDENCE_WRONG_SUBJECT` | subject ID mismatch | REJECT |
| `EVIDENCE_SUBJECT_HASH_MISMATCH` | subject hash mismatch | REJECT |
| `EVIDENCE_FRESHNESS_EXPIRED` | evidence超出 freshness policy | STALE |
| `EVIDENCE_EXPECTATION_OWNERSHIP_MISMATCH` | foreign/orphan evidence | REJECT |
| `PROVIDER_SUCCESS_CANNOT_CONFIRM_WORLD_EFFECT` | transport/provider success被升格 | FAIL_CLOSED |
| `SOD_MAKER_CHECKER_ACCEPTOR_COLLAPSE` | ASSURED/high-risk SoD collapse | FAIL |
| `PROFILE_CORE_TEST_REMOVAL_FORBIDDEN` | profile移除 core test無合法 N/A | FAIL |
| `AFFECTED_ONLY_INVALIDATION_VIOLATED` | 無關 dependents被 invalidated | FAIL |
| `STALE_DEPENDENT_LEAK` | consuming dependent未 stale | FAIL |
| `CLAIM_CEILING_EXCEEDED` | document/support evidence被升格 | FAIL |
| `GROUNDING_EXACT_LOCATOR_MISSING` | source無 exact locator | ABSTAIN/TEMP_CLOSED |

# Appendix C｜No-Silent-Degradation Rules

後續 implementation / adapter / CI integration不得：

- 將 `EVD_EXPECTATION` 與 actual `EVD` 合併成單一「evidence」欄；
- 省略 subject version/hash；
- 以 test name替代 stable TEST/ORACLE ID；
- 以 provider response替代 world-effect observation；
- 以 CI綠燈替代 product acceptance；
- 以同模型 self-review替代 Independent Qualifier；
- 以 N/A替代 missing；
- 因 profile較輕量而移除 core source/evidence/claim/invalidation invariants；
- 將 DOC-04 schema fork成 provider-specific第二套 canonical truth；
- 變更一個局部 subject時全域重跑；
- 上游改變後沿用 stale dependent evidence；
- 把 `SELECTED` 說成 `INSTALLED/BOUND/ENABLED/EXECUTED`；
- 把本文 materialization說成 runtime verification/release/production。

# Appendix D｜Artifact Readback Contract / External Receipt Rule

## D.1 Required post-write checks

封裝後對單一 Markdown實際執行：UTF-8 strict decode；bytes；line count；SHA-256；first/last heading；required section presence；duplicate object-definition ID scan；unfinished-marker / unresolved-placeholder scan；empty section；canonical specimen validation；r2 repair token checks；claim ceiling scan。

## D.2 Non-circular identity

- in-band `content_hash` uses the top-level normalization rule stated in front matter；
- final container-file SHA-256 MUST be computed after the very last byte is written；
- final container-file SHA-256 MUST NOT be inserted back into the same bytes；otherwise the file changes and the value ceases to be final；
- therefore the final readback receipt is an **external delivery receipt** containing `artifact_id, version, content_hash, final_file_sha256, bytes, lines, UTF-8 result, structural checks, validation summary`。

The external receipt is required before delivery may say post-write readback is complete；it still does not constitute Independent PASS。

<a id="appendix-e-p0-instruction-snapshot"></a>
# Appendix E｜P0 Production Instruction Immutable Snapshot

```yaml
snapshot_id: P0-INSTR-D04-2026-10-07-r1
source_role: ORIGINAL_DOC04_PRODUCTION_INSTRUCTION
source_physical_sha256: "6ebdcaeff40a2e49ff66165ff3a2bfef8ee55db2e0c7273499a2ca60403f31bc"
normalization: "decode UTF-8 strict; normalize CRLF/CR to LF; preserve all other code points and final-text semantics"
encoding: UTF-8
line_endings: LF
normalized_snapshot_sha256: "3bd7ae052fa5279db14d2f0c4bc4b926af3f040712ad1d6de0c5a36b7cda91b2"
bytes: 36341
lines: 1646
replay_rule: "hash the exact LF-normalized text inside the following tilde fence, excluding the opening/closing fence lines"
```

~~~~text
# 《PIPD_LS_DOC-04》定案正文級全量產出指令
## Target Model：GPT-5.6 Sol

你必須一次性完成《Pre-Implementation & Pre-Dev Lifecycle Specification》（以下簡稱 `PIPD_LS`）之 **`PIPD_LS_DOC-04`** 的全量研究、設計展開、定案正文撰寫、驗證、封裝與單一 Markdown 檔交付。

你的最終任務不是提出建議、摘要、骨架、章節草案或待辦事項，而是直接產出：

> **定案正文級、全量展開、完整可執行、可被 Human／AI／Tool／Validator 實際消費的《PIPD_LS_DOC-04》單一 `.md` 文件。**

完成後必須建立實際 Markdown 檔案並提供下載點。

---

# 0｜執行角色

執行本任務時，**不得沿用「PROMPT 工程師」、「專業 AI/LLM PROMPT 工程師」或本指令作者的角色。**

你現在必須依 `PIPD_LS_DOC-04` 的 canonical responsibility，切換為以下整合型專家角色：

**Primary Role**

> **Pre-Implementation & Pre-Dev Lifecycle Specification — Traceability & Assurance Data Contract Chief Architect**

並同時具備以下專業責任：

- PIPD Lifecycle Specification Architect
- Requirements Traceability Architect
- Acceptance Contract Architect
- Verification & Oracle Contract Engineer
- Evidence Architecture / Evidence Governance Engineer
- Assurance Data Contract Architect
- Source Grounding / Provenance Engineer
- JSON Schema / Machine Contract Engineer
- Conformance & Deterministic Validation Architect
- State / Invalidation / Freshness Governance Architect
- World-Effect Observation & Reconciliation Architect
- Segregation-of-Duties / Independent Assurance Architect
- Claim-Honesty / Fail-Closed Gatekeeper
- Documentation Architecture / Source-to-Prose Compiler

你的角色目標是：

> 把上游 PIPD 的 requirement、SPEC、acceptance、verification、evidence expectation、actual evidence、deliverable、gate 與 Pre-Dev binding 編譯為一套 **唯一、可追溯、可驗證、可失效、可重播、可機器檢查、不可自我證明成功** 的 Traceability / Assurance Data Contract。

---

# 1｜最高任務目標

你必須以：

`《Pre-Implementation_and_Pre-Dev_Lifecycle_Specification_總藍圖》`

作為最高上位設計藍圖，完整執行、展開並落地以下來源對 `PIPD_LS_DOC-04` 的全部規劃：

1. `Pre-Implementation_and_Pre-Dev_Lifecycle_Specification_總藍圖`
2. `Pre-Implementation_and_Pre-Dev_Lifecycle_Specification_canonical_standard`
3. `PIPD_LS_skeleton`
4. `Pre-Implementation-PKG  Pre-Dev-PKG 生命週期規格_總討論`
5. `PIPD「canonical authority／生命週期」工程裁決`
6. `PIPD_LS_DOC-00`，僅作 sibling alignment、router/readback、cross-DOC consistency 參照
7. 本次任務明文要求
8. 其他已掛載、且與 DOC-04 直接相關的 PIPD／ECP／TQAEP／SDLC_PRW_HLPE supporting artifacts
9. 2026 最新外部官方資料、標準、官方 repository、release notes、技術文件與研究，只能作 currentness／技術驗證／SUPPORT，不得反客為主成為 PIPD semantic authority

最終產出：

> **《PIPD_LS_DOC-04 — Traceability / Assurance Data Contract》**

必須是完整 substantive body，而非 Skeleton。

---

# 2｜Authority / 裁決順位

發生衝突、重疊、歷史版本差異、命名漂移或語義不一致時，嚴格採用以下裁決順位：

```text
P0  本次使用者明文任務要求
↓
P1  Pre-Implementation_and_Pre-Dev_Lifecycle_Specification_總藍圖
↓
P2  Pre-Implementation_and_Pre-Dev_Lifecycle_Specification_canonical_standard
↓
P3  PIPD_LS_skeleton
↓
P4  PIPD 生命週期規格_總討論 / canonical authority 工程裁決
↓
P5  PIPD_LS_DOC-00 sibling alignment reference
↓
P6  其他已掛載內部 supporting artifacts
↓
P7  2026 外部官方／標準／研究／repository currentness evidence
↓
P8  模型既有知識
```

強制規則：

- 上位來源已有明確裁決時，下位來源不得覆寫。
- 下位來源只能補充上位來源沒有定義、且補充內容不造成衝突之部分。
- 不得把外部網站、README、論壇、模型知識升格為 PIPD normative truth。
- 不得因自己認為「更合理」而靜默改寫上游原意。
- 發現真正衝突時，必須保留高位語義並明示 conflict disposition。
- 缺少必要來源時，不得腦補成 canonical rule；受影響範圍標示 `ABSTAIN / TEMP_CLOSED / TT`。
- `PIPD_LS_DOC-00` 是 navigation/operator sibling，不得取得 DOC-04 canonical ownership。

---

# 3｜GPT-5.6 Sol 執行模式

這是一個長上下文、跨文件、規格編譯、衝突裁決與 assurance-contract 任務。

若目前介面允許選擇 reasoning effort：

> 優先使用 **High**；若提供更高且適合此任務的層級，可使用更高層級。

若介面沒有該設定，不得假裝已設定。

執行策略：

- outcome-first；
- source-bound；
- full-corpus；
- no-sampling；
- files-first；
- search-before-build；
- evidence-first；
- fail-closed；
- claim-honest；
- high-retention；
- zero-silent-loss；
- affected-only invalidation；
- capability-before-brand；
- machine/prose equivalence。

不要要求我逐步確認，也不要把工作拆回給我。

若資料已存在於本頁對話、附件、Project Files 或掛載內容中，直接讀取使用。

---

# 4｜全量來源處理：禁止抽查

`PIPD_LS_DOC-04` 的產出全過程，必須完整執行以下 **「深度分析／全量整合標準與 SOP」**。

## SOP-1｜查看索引

先讀取所有指定來源的：

- artifact metadata
- version
- supersedes
- authority
- source manifest
- TOC / headings
- schema registry
- requirement registry
- appendix / ledger / decision register

不得只讀首頁或摘要。

## SOP-2｜定位實質條文

針對 DOC-04 的每個責任，找到真正 substantive clauses，而不是只採索引或標題。

至少定位：

- Requirement Trace
- Atomic Requirement
- SPEC
- Acceptance
- Verification
- Oracle
- Evidence Expectation
- Evidence
- Deliverable
- Gate
- PD Binding
- Documentation Grounding
- Evidence Identity
- Freshness
- Retention
- Replay
- Invalidation
- World Effect Observation
- Effect Reconciliation
- Maker / Checker / Acceptor
- Independent Assurance
- Claim Ceiling
- TT / TEMP_CLOSED
- N/A
- Conformance
- first failing invariant

## SOP-3｜關鍵字全文檢索

針對來源中核心名詞做全文檢索。

不得因為第一個搜尋結果已找到相似句子就停止。

必須檢查同一概念是否：

- 在其他章節有補充條件；
- 在 schema 中有額外 required fields；
- 在 appendix 有穩定 ID；
- 在 sibling DOC 有 consumer/producer boundary；
- 在 Blueprint / Standard / Skeleton 有不同層級的責任描述。

## SOP-4｜交叉驗證

每個重大規範至少完成：

```text
上位藍圖
↕
Canonical Standard
↕
Skeleton
↕
Design History
↕
DOC-00 / sibling boundary
↕
Machine schema / validator requirement
```

不得只依單一來源產出。

## SOP-5｜子要求分解

任何含：

- 各有
- 分別
- 每一
- 對應
- 以及
- 同時
- 包含
- 必須具備
- 至少
- 依情況
- and / each / respectively / all

的複合規範，都必須拆成 atomic child requirements。

父要求部分完成，不得視為全部完成。

## SOP-6｜實質內容判定

只有以下狀態才算「已覆蓋」：

> 正文已存在足以讓 downstream Human／AI／Tool 執行、驗證、拒收或判斷失效的具體契約。

下列不算實質覆蓋：

- 只有標題；
- 只有一句原則；
- 只有「應考慮」；
- 只有「依需求」；
- 只有「後續補充」；
- 只有 TODO / TBD；
- 只有 generic checklist；
- 只有來源連結；
- 只有 schema 名稱而沒有 semantic contract；
- 只說「參考 DOC-X」但沒有本 DOC 應承擔的內容。

---

# 5｜先建立 Source Coverage Ledger，再寫正文

在正式撰寫前，於內部工作流程建立完整 `DOC04_SOURCE_COVERAGE_LEDGER`。

每條至少包含：

```yaml
source_id:
source_artifact:
source_version:
authority_level:
exact_locator:
source_clause_summary:
doc04_owned_obligation:
atomic_children:
target_section:
machine_contract_ref:
conflict_status:
coverage_status:
```

`coverage_status` 僅允許：

```text
COVERED
N_A_WITH_RATIONALE
ABSTAIN
TEMP_CLOSED
CONFLICT_RESOLVED_BY_AUTHORITY
```

不得用 `RELATED`、`PARTIAL_ENOUGH`、`ASSUMED` 等模糊狀態冒充 closure。

---

# 6｜DOC-04 Canonical Identity

DOC-04 必須保持以下 canonical identity：

```yaml
artifact_id: PIPD_LS_DOC-04
canonical_archetype: Traceability / Assurance Data Contract
standard_id: PIPD-LIFECYCLE-SPEC
standard_version: 1.1.0
blueprint_id: PIPD-LIFECYCLE-BLUEPRINT
canonical_responsibility:
  - requirement traceability
  - acceptance linkage
  - verification/oracle linkage
  - evidence expectation
  - subject-bound evidence
  - evidence identity
  - evidence freshness
  - documentation grounding
  - effect observation
  - effect reconciliation data contract
  - orphan detection
  - assurance data integrity
  - invalidation/replay semantics
canonical_non_goal:
  - self qualification
  - self approval
  - runtime execution authorization
  - execution admission
  - product semantic re-adjudication
  - technology admission ownership
  - CI/release ownership
```

核心 narrow waist 必須完整保留：

```text
SRC
→ INTENT
→ REQ(parent + atomic child)
→ SPEC
→ ACC
→ VER(TEST / ORACLE)
→ EVD_EXPECTATION
→ EVD
→ DEL
→ GATE
→ PD_BINDING
```

不得縮短成：

```text
REQ → TEST → PASS
```

或任何會丟失 source、acceptance、evidence expectation、deliverable、gate、binding 的簡化鏈。

---

# 7｜DOC-04 與 sibling DOC 的 ownership boundary

必須明確定義並全文維持：

- `DOC-01`：Authority / lifecycle / claim / SoD / change-invalidation policy owner。
- `DOC-02`：PI contract / Atomic REQ / TechnologyAdmission owner。
- `DOC-03`：RepoContext / currentness / late-binding / S2E / WorkOrder / ECP / TQAEP owner。
- **`DOC-04`：Traceability / Assurance Data Contract owner。**
- `DOC-05`：Handoff / receiver / permission / effect authorization / ExecutionAdmission owner。
- `DOC-06`：profile / applicability / complexity governance owner。
- `DOC-07`：verification fixture / oracle / conformance-test reference owner。
- `DOC-08`：AI consumption / adapter maturity owner。
- `DOC-09`：CI / release / supply-chain / runbook / tooling owner。
- `DOC-00`：navigation / operator entry / state readback owner。

DOC-04 可以引用 sibling 的 canonical object，但不得複製其 ownership 成第二 SSOT。

---

# 8｜DOC-04 必須全量展開的正文領域

你必須先依上游來源還原 canonical heading tree。

若上游已有固定章節名稱／順序，以其為準。

以下是 **最低責任分母**，不是限制上限；不得以四個 Skeleton 小節直接充當最終全文。

## 8.1 Artifact Identity / Version / Legal Role / Claim Boundary

完整定義：

- artifact identity；
- external formal name；
- internal short name；
- version；
- supersedes；
- source baseline；
- standard/blueprint binding；
- lifecycle/legal role；
- claim ceiling；
- materialization status；
- forbidden claims。

若目前沒有既存 `DOC-04`：

- 建立第一版 substantive body；
- 使用執行當日 `Asia/Taipei` 日期；
- revision 從 `r1` 開始。

若已有 DOC-04：

- 先做 diff；
- 使用 next revision；
- 必須記錄 `supersedes` 與舊版 hash；
- 不得失去舊版仍有效內容。

## 8.2 Purpose / Scope / Non-Goals

明確說明 DOC-04：

- 為何存在；
- 解決什麼 semantic-loss / apparent-pass / evidence-drift 問題；
- 在 PI / PD / execution / verification 中位於哪裡；
- 哪些內容由 DOC-04 寫；
- 哪些內容絕對不由 DOC-04 寫。

## 8.3 Authority & Source Grounding

完整落地：

- authority model；
- exact source locator；
- source/version/hash；
- grounded claim；
- retrieval method；
- grounding state；
- stale invalidation trigger；
- source mutation / supersession 行為；
- external SUPPORT 隔離；
- no-source-no-norm。

必須對齊 `DocumentationGroundingRecord`。

## 8.4 Requirement Narrow Waist

完整定義：

```text
SRC → INTENT → REQ → SPEC → ACC → VER → EVD_EXPECTATION → EVD → DEL → GATE → PD_BINDING
```

不得只是畫圖。

必須定義：

- 每一 node identity；
- producer；
- canonical writer；
- consumer；
- required refs；
- forward edge；
- reverse edge；
- version；
- hash；
- status；
- invalidation；
- N/A semantics；
- terminal states。

## 8.5 Parent Requirement → Atomic Child Requirements

完整規範：

- compound decomposition；
- child identity；
- child owner；
- child criticality；
- applicability；
- parent closure algorithm；
- partial-child-pass 不得把 parent 判 PASS；
- child orphan scan；
- changed-child affected-only invalidation。

必須明確處理：

> 「各有／分別／對應／每個／同時」等複合要求。

## 8.6 SPEC Linkage Contract

定義：

- REQ→SPEC 一對一／一對多／多對一規則；
- SPEC canonical owner；
- version/hash；
- cross-DOC reference；
- machine-consumability；
- N/A rationale；
- orphan SPEC detection；
- supersession propagation。

不得重新取得 DOC-02 SPEC semantic ownership。

## 8.7 Acceptance Contract

完整定義 `AcceptancePredicate`：

- stable ACC ID；
- requirement ref；
- preconditions；
- observable success；
- negative predicate；
- edge/boundary predicate；
- tolerance/confidence；
- checker；
- acceptor；
- evidence expected；
- profile-specific criteria；
- fail/halt semantics。

禁止：

> 「結果合理」、「看起來正常」、「人工確認即可」

這類不可驗證 acceptance。

## 8.8 Verification / Oracle Linkage

完整規範：

- stable TEST ID；
- stable ORACLE ID；
- verification method；
- fixture identity；
- expected observation；
- expected first failing invariant；
- deterministic / statistical / human / composite oracle；
- future execution boundary；
- requalification trigger；
- oracle versioning；
- test/oracle supersession；
- profile-added test handling。

DOC-04 不得自稱測試已執行。

## 8.9 Evidence Expectation

完整定義：

- evidence type；
- subject；
- subject version；
- subject hash；
- expected location；
- collection procedure；
- environment；
- retention；
- freshness / TTL；
- checker；
- replay requirement；
- security/privacy classification；
- world-effect evidence when applicable；
- invalidation trigger。

必須嚴格區分：

```text
EVD_EXPECTATION != EVD
PLAN_COMPLETE != EXECUTED
TEST_DEFINED != TEST_EXECUTED
```

## 8.10 Subject-Bound Evidence Packet

完整落地 `SubjectBoundEvidencePacket`。

至少保留 canonical required semantics：

```text
evidence_id
subject_id
subject_version
subject_hash
fixture_or_input_refs
environment
procedure_ref
expected
actual
oracle
oracle_result
result
timestamp
producer
first_failing_invariant
invalidated_dependents
artifacts
```

並補足 Standard / Skeleton 要求的：

```text
operator
checker
payload_ref
test_oracle_refs
freshness
retention
replay
effect_observation
reconciliation
```

若 prose 與 schema 分母不同，必須以 authority hierarchy 進行保留式整合，不得任意刪欄。

## 8.11 Evidence Identity / Wrong-Subject Rejection

完整定義拒絕規則：

- wrong subject；
- wrong version；
- wrong hash；
- foreign environment；
- stale evidence；
- wrong procedure；
- untrusted producer；
- missing checker；
- replay mismatch；
- evidence reused across incompatible subject；
- sibling artifact evidence substitution；
- provider success substituted for observed effect。

## 8.12 Evidence Freshness / Retention / Replay

完整定義：

- TTL / freshness class；
- immutable vs refreshable evidence；
- retention duration/policy；
- replay prerequisites；
- stale transition；
- invalidation；
- archival；
- supersession；
- provenance chain；
- revalidation；
- affected dependents。

不要用固定 TTL 猜測所有 evidence；若上游未定義固定值，建立 typed policy / profile rule。

## 8.13 Stable TEST / ORACLE Identity

必須將 stable identity 寫成工程規格：

- ID permanence；
- semantic versioning；
- hash；
- fixture binding；
- oracle contract；
- expected first failing invariant；
- supersession；
- backward compatibility；
- mutation test；
- profile extension；
- core test不可被 profile 靜默移除。

## 8.14 Evidence Type Taxonomy

至少全量處理：

- static/schema evidence；
- source/grounding evidence；
- repo readback；
- functional evidence；
- negative evidence；
- edge/boundary evidence；
- adversarial evidence；
- security/privacy evidence；
- performance/capacity evidence；
- parity/migration evidence；
- operational-readiness evidence；
- approval evidence；
- provenance/attestation；
- independent assurance；
- world-effect observation；
- reconciliation evidence。

每種類型不得只列名字。

必須定義：

- producer；
- consumer；
- minimum payload；
- freshness；
- checker；
- invalidation；
- replay；
- claim ceiling。

## 8.15 World Effect Observation

完整落地 `EffectObservation`：

```text
observation_id
effect_intent_ref
provider_response_ref
observation_method
observed_state
observed_at
observer
```

強制區分：

```text
AUTHORIZED_ATTEMPT
→ PROVIDER_RESPONSE
→ OBSERVATION
→ READBACK
→ RECONCILIATION
→ WORLD_EFFECT_STATE
```

Provider/API 回傳成功不得直接升格為世界狀態成功。

## 8.16 Effect Reconciliation

完整落地 `EffectReconciliationReceipt`：

```text
receipt_id
effect_intent_ref
observation_refs
readback_refs
state
oracle
actual
next_action
checker
timestamp
```

至少支持：

```text
UNKNOWN_EFFECT
PARTIAL_EFFECT
CONFLICTING_EFFECT
CONFIRMED_EFFECT
FAILED_EFFECT
COMPENSATED_EFFECT
```

並定義：

- reobserve；
- reconcile；
- compensate；
- fail-close；
- promote evidence；
- affected invalidation。

DOC-04 與 DOC-05 之間必須寫出 ownership seam。

## 8.17 Documentation Grounding Contract

完整落地：

```text
grounding_id
source_id
source_version
source_hash
exact_locator
grounded_claim
retrieval_method
state
stale_invalidation_trigger
```

`state` 至少處理：

```text
GROUNDED
ABSTAIN
STALE
TEMP_CLOSED
```

不得將「模型知道」當 grounded source。

## 8.18 Deliverable / Gate / PD-Binding Trace

Trace 不得在 Evidence 截止。

必須繼續到：

```text
EVD → DEL → GATE → PD_BINDING
```

完整定義：

- deliverable identity；
- completion predicate；
- gate owner；
- gate result；
- blocking/non-blocking；
- PD consumer；
- frozen refs；
- stale ref behavior；
- re-entry path。

## 8.19 Forward / Reverse Orphan Scan

必須建立雙向掃描規則：

```text
SRC without REQ
REQ without SPEC
SPEC without ACC
ACC without VER
VER without EVD_EXPECTATION
EVD_EXPECTATION without valid evidence path
EVD without owning expectation
DEL without requirement chain
GATE without owned denominator
PD_BINDING without valid upstream trace
```

並定義 defect / TT / TEMP_CLOSED 分流。

## 8.20 N/A Contract

任何 N/A 必須：

- typed；
- subject-bound；
- profile-aware；
- rationale non-empty；
- authority accepted；
- consumer visible；
- reversible on applicability change；
- 不得拿 N/A 掩蓋 missing。

## 8.21 Change / Supersession / Invalidation

完整設計：

- semantic change；
- source change；
- acceptance semantics change；
- oracle change；
- environment drift；
- evidence expiry；
- tool/provider version change；
- permission/security change；
- schema change。

採 **affected-only invalidation**：

- 不得全域無差別重跑；
- 也不得上游改變後沿用 stale dependent evidence。

## 8.22 SoD / Checker / Acceptor / Independent Assurance

明確區分：

```text
Maker
Checker
Acceptor
Human Approver
Independent Qualifier
Release Authority
```

不得：

- Maker 自己產 evidence 後自稱 Independent PASS；
- Writer 自己修改 oracle 後以新 oracle 證明自己 PASS；
- 工具 callback 自動等同 Human acceptance。

## 8.23 Claim Ceiling

完整寫出：

```text
DOCUMENT_MATERIALIZED
≠ IMPLEMENTED
≠ TEST_EXECUTED
≠ VERIFIED
≠ QUALIFIED
≠ RELEASED
≠ PRODUCTION_VERIFIED
```

DOC-04 自身完成，只能證明：

> DOC-04 substantive contract 已 materialize／readback／local conformance 到實際已執行之程度。

不得因本文完整就聲稱 target implementation、qualification 或 production 已完成。

## 8.24 Profile Applicability

完整對應：

```text
LITE
STANDARD
ASSURED
SYSTEM
SKILL_PLUGIN
AGENT_HARNESS
CUSTOM
Brownfield / Migration when applicable
```

Profile 可以：

- 增加 evidence depth；
- 增加 test class；
- 增加 checker；
- 增加 retention；
- 增加 world-effect verification。

不得移除 portable-core invariants。

## 8.25 Machine / Prose Equivalence

每一重要 prose predicate 必須能落到：

- JSON Schema；
- deterministic validator；
- typed ledger；
- oracle；
- gate predicate；

之一或多個。

不得存在：

> prose 說必須，但 machine validator 永遠不可能檢查

的假規範。

---

# 9｜必須對齊的 Canonical Schemas

DOC-04 至少必須完整引用、解釋、落地並建立 producer/consumer/validation/invalidation contract：

```text
requirement-trace.schema.json
evidence.schema.json
documentation-grounding.schema.json
effect-observation.schema.json
effect-reconciliation.schema.json
```

同時必須正確交叉引用、但不得奪取 sibling ownership：

```text
pre-implementation-package.schema.json
pre-dev-package.schema.json
tqaep.schema.json
handoff.schema.json
execution-admission.schema.json
effect-intent.schema.json
conformance-report.schema.json
approval-token.schema.json
```

Canonical namespace 必須尊重：

```text
urn:pipd:canonical-standard:1.1
```

Schema 規劃必須保持 Draft 2020-12 相容性。

不得任意創建第二套同義 schema 並與 canonical schema 競爭。

---

# 10｜Technology / Tool / OSS / Method / Workflow Selection

對 DOC-04 真正需要：

- 整合；
- 使用；
- 當基座；
- 壓製；
- 轉譯；
- 導入；

的內外部：

- tools；
- OSS；
- standards；
- schemas；
- provenance mechanisms；
- validation frameworks；
- workflow；
- architecture；
- PROMPT；
- SKILLS；
- roles；
- evidence/attestation components；

必須進行正式 Technology / Integration Decision。

但必須遵守 ownership：

> DOC-04 不得重新裁決 DOC-02 已擁有的 TechnologyAdmission semantic truth，也不得取得 DOC-09 CI/tooling canonical ownership。

若上游已完成選型：

> consume / pin / reference，不得重新發明候選清單。

若 DOC-04 執行落地需要一項尚未 terminally decided 的專屬能力：

必須執行：

```text
Need / measurable capability
→ Internal reuse search
→ External scout when needed
→ Fit / gap
→ Security / privacy
→ License / rights
→ Maturity
→ Supply-chain provenance
→ Portability
→ Testability
→ Brownfield fit
→ Provider exit
→ Rollback / uninstall
→ Final terminal disposition
```

不得停留在：

```text
CANDIDATE
MAY USE
CONSIDER
TO BE DECIDED
TBD
```

---

# 11｜2026 Currentness Research

只要涉及外部工具、標準、library、GitHub project、protocol、provider 或方法論，你必須進行截至執行當日的最新 web research。

資料優先順序：

```text
Official specification / standards body
→ Official product documentation
→ Official GitHub repository / releases
→ Maintainer documentation
→ Primary research
→ High-quality technical secondary sources
→ Community evidence
```

每一 material external choice 至少記錄：

```yaml
canonical_external_name:
internal_short_name:
selected_version_or_pin:
checked_at:
official_source:
license_or_rights:
maturity:
security_status:
integration_mode:
terminal_disposition:
why_selected:
rejected_alternatives:
translation_or_wrapper:
rollback_or_exit:
currentness_ttl_or_refresh_rule:
```

Web research 只能：

- 驗證 currentness；
- 支援技術選型；
- 驗證版本、license、maintenance、security、compatibility；
- 找出更佳 implementation mechanism。

不得改寫 PIPD normative semantics。

若無法使用 Web：

> 對需要 currentness 的項目標示 `CURRENTNESS_UNVERIFIED`，不得假裝已查證。

---

# 12｜選型「落地防降級」與具名保護

凡 DOC-04 需要採用的外部項目，必須建立：

> **Named Integration Protection Registry**

每列至少包含：

```yaml
external_formal_name:
internal_short_name:
selected_version:
capability_slot:
canonical_owner:
adoption_ref:
terminal_design_disposition:
required_materialization_state:
translation_or_compression_contract:
installation_or_distribution_target:
binding_target:
enablement_condition:
functional_acceptance:
negative_acceptance:
boundary_acceptance:
security_acceptance:
evidence_required:
rollback:
uninstall_or_provider_exit:
residue_check:
dynamic_reselection_trigger:
forbidden_degradation:
```

其中 `forbidden_degradation` 必須明示禁止：

- 從已定案選型退回 unspecified candidate；
- 後續 implementation 因方便而完全略過；
- 只引用 README 而未整合；
- 無 translation / adapter contract；
- 無 acceptance；
- 無 rollback；
- 無 provider exit；
- 無 evidence return。

但是：

> **設計定案 ≠ 已安裝。**

若本輪沒有真實執行 install/bind/enable：

必須誠實標示：

```text
SELECTED / PINNED / REQUIRED_FOR_MATERIALIZATION
NOT_INSTALLED
NOT_BOUND
NOT_ENABLED
NOT_EXECUTED
```

不得為了「防降級」而偽稱已安裝。

真正的 anti-degradation 是：

> **把下游必須 materialize / install / translate / bind / test / enable 的責任與驗收寫死，而不是偽造 runtime truth。**

---

# 13｜外部項目的 Translation / Compression / Acceptance

凡導入外部 method/tool/OSS/workflow/architecture/Prompt/Skill/Role，必須定義：

## Translation Contract

- 外部概念；
- PIPD internal semantic；
- 保留語意；
- 排除語意；
- canonical owner；
- adapter/wrapper；
- data/interface transform；
- authority barrier。

## Compression Contract

「壓製」不得代表簡化到失真。

必須說明：

- retained capability；
- dropped capability；
- forbidden semantic leakage；
- PIPD-native replacement；
- upgrade / exit route。

## Acceptance

至少具有：

- 正向功能檢測；
- negative；
- boundary；
- edge；
- adversarial/security；
- permission；
- provider-off；
- rollback；
- uninstall/residue；
- semantic parity；
- evidence/readback。

---

# 14｜PIPD_LS_DOC-00 Alignment

DOC-04 必須適當對齊現行 `PIPD_LS_DOC-00`。

至少驗證：

- DOC-00 routing 中「What proves requirement/spec/test/evidence linkage? → DOC-04」保持成立；
- DOC-00 stale/missing refs readback 與 DOC-04 freshness/invalidation semantics 一致；
- DOC-00 不成為 DOC-04 第二 writer；
- DOC-04 輸出的狀態可被 DOC-00 readback；
- `PREDEV_READY`、ECP、TQAEP、WorkOrder 的存在不得被 DOC-04 解讀為 ExecutionAdmission；
- CI/tool success 只能成為 supporting evidence，不等於 product acceptance；
- vertical slice 可獨立 trace / bind / invalidate，不建立全域 waterfall lock。

---

# 15｜禁止「模板同質化」

DOC-04 各章節／子章節不得採：

> 定位 → 原則 → 輸入 → 輸出 → 驗收

同一組固定句型機械複製。

必須依內容使用真正適合的工程形態：

- contract；
- state machine；
- schema；
- matrix；
- trace graph；
- evidence envelope；
- registry；
- policy；
- algorithm；
- lifecycle；
- decision table；
- failure branch；
- conformance rule；
- worked example；
- machine-readable specimen。

完成全文後執行 **Title-Swap Test**：

> 如果兩個章節交換標題後大部分正文仍成立，即判定 `TEMPLATE_HOMOGENIZATION_FAIL`，必須重寫。

---

# 16｜必備工程案例

為避免 DOC-04 成為抽象標準，正文必須包含至少數個完整 trace worked examples，並覆蓋不同 archetype。

至少包含：

### Case A｜Normal Requirement Trace

```text
Source
→ Parent REQ
→ Atomic REQ
→ SPEC
→ ACC
→ TEST/ORACLE
→ EVD_EXPECTATION
→ EVD
→ DEL
→ GATE
→ PD_BINDING
```

### Case B｜Orphan Detection

展示 orphan REQ / SPEC / ACC 如何：

```text
FAIL
→ TT
→ affected scope TEMP_CLOSED
→ repair
→ revalidation
```

### Case C｜Stale Evidence

subject/version/hash 任一改變後：

```text
previous EVD
→ STALE
→ affected dependents invalidated
→ unaffected sibling remains current
```

### Case D｜Wrong-Subject Evidence

同類測試結果但 subject 不同，必須拒絕。

### Case E｜World Effect

```text
Provider says success
→ observation absent
→ UNKNOWN_EFFECT
→ reobserve/readback
→ reconciliation
→ final WorldEffectState
```

### Case F｜ASSURED SoD

Maker 不能同時扮演唯一 Independent Checker / Acceptor。

### Case G｜N/A

展示合法 N/A 與 illegitimate missing-as-N/A 的差異。

---

# 17｜Machine-Readable Specimens

正文必須包含可直接供下游實作者使用的 machine-readable examples。

至少提供：

- RequirementTraceRow；
- EvidenceExpectation；
- SubjectBoundEvidencePacket；
- DocumentationGroundingRecord；
- EffectObservation；
- EffectReconciliationReceipt；
- InvalidationRecord；
- OrphanScanResult；
- NARationaleRecord；
- AssuranceRoleBinding；
- TraceClosureReport。

不得使用：

```text
<fill here>
TODO
TBD
...
etc.
```

當值確實只能由 target project later-bind 時，使用合法型別，例如：

```text
LATE_BOUND
BLOCKED_EXTERNAL
NOT_APPLICABLE
TEMP_CLOSED
```

並提供 owner / close criteria / evidence required。

---

# 18｜Verification / Destructive Tests

在 DOC-04 交付前，至少對本 DOC 自身設計以下 conformance / destructive cases：

```text
NORMAL
NEGATIVE
EDGE
BOUNDARY
ADVERSARIAL
MUTATION
APPARENT_PASS
STALE_EVIDENCE
WRONG_SUBJECT
WRONG_HASH
ORPHAN_REQ
ORPHAN_SPEC
ORPHAN_ACC
SELF_APPROVAL
FOREIGN_EVIDENCE
PROVIDER_SUCCESS_WITHOUT_EFFECT_OBSERVATION
GLOBAL_INVALIDATION_OVERREACH
STALE_DEPENDENT_NOT_INVALIDATED
PROFILE_REMOVES_CORE_TEST
DOCUMENT_MATERIALIZED_CLAIMED_AS_VERIFIED
```

Validator／oracle 必須能指出：

> **first failing invariant**

不得只回 `FAIL`。

---

# 19｜全域品質要求

最終正文必須同時滿足：

```text
FULL-CORPUS
NO-SAMPLING
FILES-FIRST
SOURCE-BOUND
HIGH-RETENTION
ZERO-SILENT-LOSS
NO-ARCHITECTURE-RESET
FAIL-CLOSED
CLAIM-HONEST
MACHINE-READABLE
HUMAN-READABLE
AI-READABLE
CONSTRUCTION-READY
REJECTABLE
REPLAYABLE
INVALIDATABLE
VERSIONED
SUBJECT-BOUND
AFFECTED-ONLY-INVALIDATION
```

並禁止：

- Skeleton masquerading as final；
- summary masquerading as substantive body；
- generic AI prose；
- undocumented assumptions；
- invented runtime facts；
- self-certified PASS；
- TODO / TBD；
- arbitrary duplication of sibling authority；
- candidate leakage where terminal design decision is required；
- unversioned external integration；
- unnamed tool references；
- empty acceptance；
- empty oracle；
- blanket global invalidation；
- claim inflation。

---

# 20｜正文完成後的 Coverage Audit

正式封裝前必須進行一次全文自我審查，但不得把模型自審冒充 independent assurance。

至少檢查：

```yaml
canonical_responsibility_coverage:
source_clause_coverage:
atomic_requirement_coverage:
schema_coverage:
forward_trace_orphans:
reverse_trace_orphans:
sibling_boundary_conflicts:
duplicate_canonical_writers:
unresolved_placeholders:
unnamed_integrations:
nonterminal_tool_decisions:
missing_acceptance:
missing_oracles:
missing_evidence_expectations:
wrong_claims:
template_homogenization:
unsupported_external_currentness:
open_tt:
open_cr:
```

任何 blocker 未關閉：

- 不得宣稱完整 PASS；
- 可完成文件，但必須誠實保留 TT/TEMP_CLOSED；
- 不得把「文件已產出」等同「所有 lifecycle gate 已通過」。

---

# 21｜文件本身的最低 Metadata

最終 Markdown 開頭必須具有可機器讀取 metadata。

至少包含：

```yaml
artifact_id: PIPD_LS_DOC-04
external_formal_name: "Pre-Implementation & Pre-Dev Lifecycle Specification — DOC-04 Traceability / Assurance Data Contract"
internal_short_name: PIPD_LS_DOC-04
artifact_type: FULL_SUBSTANTIVE_BODY
version:
generated_at:
timezone: Asia/Taipei
standard_id: PIPD-LIFECYCLE-SPEC
standard_version: "1.1.0"
blueprint_id: PIPD-LIFECYCLE-BLUEPRINT
blueprint_version: "1.1.0"
source_authority_order:
supersedes:
canonical_archetype: "Traceability / Assurance Data Contract"
claim_ceiling:
materialization_status:
runtime_execution:
independent_pass:
human_ratification:
release_status:
production_status:
open_tt:
open_cr:
```

不得預填不存在的 PASS。

---

# 22｜最終文件格式

最終 `PIPD_LS_DOC-04` 必須：

- 使用標準 UTF-8 Markdown；
- H1/H2/H3 結構清楚；
- 長表格應可辨讀；
- schema/example 使用 fenced code blocks；
- ID 使用 inline code；
- contract、algorithm、state machine 適當圖文化／表格化；
- 不以超長無分段 prose 取代工程結構；
- 不以大量表格取代必要的設計說明；
- 章節之間具明確 producer/consumer 關聯。

---

# 23｜單一 MD 封裝與下載

完成正文後，必須建立實際單一 Markdown 檔。

建議 canonical filename：

```text
PIPD_LS_DOC-04_<YYYY-MM-DD>_r1_FULL_SUBSTANTIVE_BODY.md
```

若已有先前 DOC-04 revision，使用下一 revision 並記錄 supersession。

完成寫檔後必須重新 readback：

```text
filename
UTF-8 decode
bytes
line count
SHA-256
first heading
last heading
required section presence
duplicate ID scan
TODO/TBD scan
empty section scan
```

不得只在聊天中貼 Markdown 後聲稱「已打包」。

必須真正建立檔案。

---

# 24｜最終回覆格式

任務全部完成後，聊天回覆保持簡潔，只輸出：

```markdown
《PIPD_LS_DOC-04》已完成。

- Artifact: `PIPD_LS_DOC-04`
- Version: `<actual-version>`
- SHA-256: `<actual-sha256>`
- Bytes: `<actual-bytes>`
- Lines: `<actual-lines>`
- Claim ceiling: `<actual-honest-claim-ceiling>`

[下載《PIPD_LS_DOC-04》](<actual-download-link>)
```

若存在未關閉 TT / TEMP_CLOSED，必須在 `Claim ceiling` 後如實附上，不得隱藏。

---

# 25｜最終停止條件

只有在以下全部完成後才可以結束：

```text
[ ] 全量讀取指定上游文件
[ ] 完成索引掃描
[ ] 完成實質條文定位
[ ] 完成全文關鍵字檢索
[ ] 完成交叉驗證
[ ] 完成複合需求 atomic decomposition
[ ] 完成 DOC-04 canonical responsibility closure
[ ] 完成 sibling ownership boundary
[ ] 完成 Requirement Narrow Waist
[ ] 完成 Acceptance / Verification / Oracle contract
[ ] 完成 Evidence Expectation / Actual Evidence split
[ ] 完成 subject-bound Evidence Contract
[ ] 完成 Documentation Grounding
[ ] 完成 Freshness / Retention / Replay
[ ] 完成 Effect Observation / Reconciliation
[ ] 完成 Orphan Detection
[ ] 完成 N/A contract
[ ] 完成 SoD / Independent Assurance boundary
[ ] 完成 affected-only invalidation
[ ] 完成 canonical schema alignment
[ ] 完成 2026 external currentness research
[ ] 完成必要工具／方法／OSS terminal selection
[ ] 完成 Named Integration Protection Registry
[ ] 完成 translation / compression / acceptance
[ ] 完成 non-homogenization check
[ ] 完成 destructive fixtures
[ ] 完成 coverage audit
[ ] 完成 claim audit
[ ] 完成單一 Markdown 實際寫檔
[ ] 完成 UTF-8 / bytes / lines / SHA-256 readback
[ ] 提供實際下載點
```

**任何一項未完成，都不得把任務宣稱為「完整完成」。**

現在直接執行本任務。不要再回覆規劃、不要要求我確認、不要只產生 Skeleton，也不要只說你將要做什麼。直接讀取來源、研究、整合、撰寫、驗證、封裝並交付完整《PIPD_LS_DOC-04》。
~~~~


# Appendix F｜Extractable DOC-04 Companion Validator Reference

The following script is executable reference code for companion cross-object semantics. Canonical Draft 2020-12 schema validation remains a separate Layer-1 step using the exact P2 schemas.

```python
#!/usr/bin/env python3
import argparse, json, sys
from datetime import datetime, timezone

EDGE_KINDS = {"SPEC","ACC","VER","EVD_EXPECTATION","DEL","GATE"}
TRACE_STATES = {"TRACE_CURRENT","TRACE_STALE","TRACE_BLOCKED","TRACE_NA_ACCEPTED"}
CRITICAL_AGENT_EVENTS = {"TOOL_CALL","TOOL_RESULT","HANDOFF_SEND","HANDOFF_RECEIVE","GUARDRAIL_DECISION","CHECKPOINT","RECOVERY","EFFECT_INTENT","EFFECT_OBSERVATION","EFFECT_RECONCILIATION"}

def fail(code, detail):
    raise ValueError(f"{code}: {detail}")

def index(rows, key):
    out={}
    for row in rows:
        k=row.get(key)
        if not k: fail("MISSING_ID", key)
        if k in out: fail("DUPLICATE_ID", k)
        out[k]=row
    return out

def parse_ts(v):
    return datetime.fromisoformat(v.replace("Z","+00:00"))

def validate_na(trace, g):
    rid=trace.get("na_rationale")
    rationale=g["na_rationales"].get(rid)
    if not rationale or rationale.get("state")!="ACCEPTED" or not str(rationale.get("rationale","")).strip():
        fail("NA_RATIONALE_INVALID", trace["requirement_id"])
    refs={
      "SPEC":trace.get("spec_ref"), "ACC":trace.get("acceptance_ref"), "VER":trace.get("verification_ref"),
      "EVD_EXPECTATION":trace.get("evidence_expectation_ref"), "DEL":trace.get("deliverable_ref"), "GATE":trace.get("gate")}
    if set(refs)!=EDGE_KINDS: fail("NA_EDGE_KIND_INTERNAL_ERROR", trace["requirement_id"])
    seen=set()
    for kind, ref in refs.items():
        row=g["na_edges"].get(ref)
        if not row: fail("NA_REQUIRED_EDGE_RESOLUTION_MISSING", f"{kind}:{ref}")
        if row.get("edge_kind")!=kind or row.get("resolution_kind")!="NOT_APPLICABLE_EDGE_RESOLUTION":
            fail("NA_EDGE_RESOLUTION_TYPE_MISMATCH", ref)
        if row.get("requirement_ref")!=trace["requirement_id"] or row.get("na_rationale_ref")!=rid:
            fail("NA_EDGE_RESOLUTION_BINDING_MISMATCH", ref)
        if row.get("state")!="ACCEPTED": fail("NA_EDGE_NOT_ACCEPTED", ref)
        seen.add(kind)
    if seen!=EDGE_KINDS: fail("NA_EDGE_SET_INCOMPLETE", trace["requirement_id"])

def validate_execution_return(r):
    if not r.get("operation_id") or not r.get("procedure_ref"): fail("OPERATION_PROCEDURE_BINDING_MISSING", r.get("return_id"))
    if parse_ts(r["ended_at"]) < parse_ts(r["started_at"]): fail("EXECUTION_INTERVAL_INVALID", r.get("return_id"))
    for k in ("stdout_ref","stderr_ref","raw_result_ref"):
        if k not in r: fail("RAW_EVIDENCE_REF_MISSING", f"{r.get('return_id')}:{k}")
    if "changed_artifacts" not in r or "changed_effects" not in r: fail("CHANGE_INVENTORY_MISSING", r.get("return_id"))

def validate_profile_extension(ext, core_tests):
    if ext.get("core_override") is not False: fail("CORE_OVERRIDE_FORBIDDEN", ext.get("extension_id"))
    added=set(ext.get("added_tests_or_oracles",[]))
    effective=set(ext.get("effective_tests_or_oracles", list(core_tests|added)))
    if not core_tests.issubset(effective): fail("PROFILE_REMOVED_CORE_TEST", ext.get("extension_id"))

def validate_gate_binding(row):
    s=row.get("trace_closure_state")
    if s not in TRACE_STATES: fail("TRACE_CLOSURE_STATE_INVALID", row.get("binding_trace_id"))
    gate=row.get("gate",{})
    if "result" in gate or "state" in gate: fail("GATE_TRACE_NAMESPACE_COLLISION", row.get("binding_trace_id"))

def validate_agent_trace(r):
    if r.get("event_class") in CRITICAL_AGENT_EVENTS and r.get("sampling_state") not in {"NOT_SAMPLED_CRITICAL","FULL_FIDELITY"}:
        fail("CRITICAL_TRACE_EVENT_MISSING", r.get("event_id"))
    if r.get("pii_redaction_state") not in {"PASS","NOT_APPLICABLE"}: fail("TRACE_REDACTION_INVALID", r.get("event_id"))
    if r.get("evidence_candidate_state")=="PASS": fail("TELEMETRY_DIRECT_PASS_FORBIDDEN", r.get("event_id"))

def validate_resume(r, subjects):
    if r.get("workflow_id")!="CROSS_SESSION_PIPELINE": fail("WORKFLOW_ID_MISMATCH", r.get("resume_packet_id"))
    sub=subjects.get(r.get("subject_id"))
    if not sub or sub.get("version")!=r.get("subject_version") or sub.get("hash")!=r.get("subject_hash"):
        fail("STALE_SUBJECT_HASH", r.get("resume_packet_id"))
    if r.get("from_session_id")==r.get("to_session_id"): fail("FOREIGN_SESSION_CONTEXT", r.get("resume_packet_id"))
    if parse_ts(r["expires_at"]) < parse_ts(r["issued_at"]): fail("EXPIRED_RESUME_PACKET", r.get("resume_packet_id"))
    if not r.get("purge_after"): fail("PURGE_POLICY_MISSING", r.get("resume_packet_id"))

def validate_sod(r):
    if r.get("profile")=="ASSURED":
        vals=[r.get("maker"),r.get("checker"),r.get("acceptor")]
        if None in vals or len(set(vals))<3: fail("SOD_COLLAPSE", r.get("binding_id"))
        if r.get("independent_qualifier") in {r.get("maker"),r.get("checker"),r.get("acceptor")}:
            fail("FALSE_INDEPENDENCE_CLAIM", r.get("binding_id"))

def validate_threat(r):
    req=("threat","asset","trust_boundary","abuse_case","prevention","detection","response","test_ref","oracle_ref","owner","residual_risk","evidence_expectation_ref")
    if any(not r.get(k) for k in req): fail("THREAT_BINDING_INCOMPLETE", r.get("threat_id"))

def validate_graph(doc):
    g={
      "na_rationales":index(doc.get("na_rationales",[]),"na_id"),
      "na_edges":index(doc.get("na_edges",[]),"na_edge_id")}
    for t in doc.get("traces",[]):
        if t.get("status")=="NOT_APPLICABLE": validate_na(t,g)
    for r in doc.get("execution_returns",[]): validate_execution_return(r)
    core=set(doc.get("core_tests_or_oracles",[]))
    for r in doc.get("profile_extensions",[]): validate_profile_extension(r,core)
    for r in doc.get("gate_bindings",[]): validate_gate_binding(r)
    for r in doc.get("agent_traces",[]): validate_agent_trace(r)
    subjects=index(doc.get("subjects",[]),"subject_id")
    for r in doc.get("cross_session_packets",[]): validate_resume(r,subjects)
    for r in doc.get("role_bindings",[]): validate_sod(r)
    for r in doc.get("threat_bindings",[]): validate_threat(r)
    return {"result":"PASS","first_failing_invariant":None}

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--graph",required=True)
    ap.add_argument("--report",required=True)
    ap.add_argument("--canonical-schemas",required=False)
    a=ap.parse_args()
    try:
        doc=json.load(open(a.graph,"r",encoding="utf-8"))
        rep=validate_graph(doc); code=0
    except (ValueError,KeyError,TypeError) as e:
        rep={"result":"FAIL","first_failing_invariant":str(e)}; code=3
    with open(a.report,"w",encoding="utf-8") as f: json.dump(rep,f,ensure_ascii=False,indent=2)
    return code
if __name__=="__main__": sys.exit(main())
```


# Appendix G｜Full-Scan / Repair Receipt Manifest

r2 build consumed and full-text scanned the following required corpus, with no sampling：

| ID | Artifact | SHA-256 | Full-scan role |
|---|---|---|---|
| `P1-BP` | Lifecycle Specification 總藍圖 | `9a8323e5237c1555a76d9a75f706e3552d79c192915cc782b76b211c7f27d527` | index/authority/technology/profile/readback blueprint |
| `P2-STD` | Canonical Standard 1.1.0 | `6f6aafece90b34e33786647e14fee840f5424893995b3164cbb52953a5c4f14a` | normative clauses/schemas/metrics/CAND registry |
| `P3-SKL` | Repaired Skeleton | `03bb3609dc67f85fa4b683a93736cf162e9047b6b253182aa3fdba11ba40cb28` | DOC-04 responsibility/33 atomic/29 source units/8 workflows |
| `P4-DISC` | Lifecycle discussion | `be1858e860092fb1751bf0524cd22b6939138b6835ce8f452bfc30894f945a95` | design intent/Agent Harness/handoff boundaries |
| `P4-RULE` | canonical authority engineering ruling | `4ae876f856850e4f657cfb1df9cb926b08bdc353af040c3ecdd92faa651a7dc8` | minimum-sufficient architecture / no over-splitting |
| `P5-DOC00` | DOC-00 r2 | `be3a672ec20aa0e6b5e0e35097fc08de749bfe7f59f827d18e38aef67dd68ea4` | sibling router/readback/claim alignment |
| `P0-INSTR` | production instruction immutable snapshot | `3bd7ae052fa5279db14d2f0c4bc4b926af3f040712ad1d6de0c5a36b7cda91b2` | task contract |
| `AUDIT-R1` | destructive audit | `58b3508a6696a7845c3289e66e55c890f79ccc89595f59bbc1cc152cb6d3d127` | repair controller |
| `TARGET-R1` | superseded DOC-04 r1 | `ffefd02b35c0e2b5416ac483b43d8e1aaa7ad5db9f5e05c2f2e465da66fc853d` | high-retention baseline |

Keyword full-text pass included at minimum：`Trace, Evidence, Acceptance, Verification, Oracle, Grounding, Effect, Reconciliation, Invalidation, Orphan, SoD, Technology, Tool, Workflow, Currentness, Provenance, Attestation, Agent Harness, CROSS_SESSION_PIPELINE, DomainProfileExtension, added_tests_or_oracles, Evidence Return, N/A, Threat Model, readback, Minimal Acceptance Metrics`。

Compound requirements containing “各有／分別／對應” were reduced to atomic obligations before closure；the authoritative DOC-04 denominator remains the repaired Skeleton/AUDIT 33-row set, not keyword occurrence count。
