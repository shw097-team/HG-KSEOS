import argparse, json
from pathlib import Path
try:
    from .core import read_clause
except ImportError:
    from core import read_clause

if __name__=='__main__':
    p=argparse.ArgumentParser(description='Offline source-bound progressive reader')
    p.add_argument('source_id'); p.add_argument('line_from',type=int); p.add_argument('line_to',type=int)
    p.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1])
    a=p.parse_args()
    print(json.dumps(read_clause(a.root,a.source_id,a.line_from,a.line_to),ensure_ascii=False,indent=2))
