# FHS-MSC Skeleton+Spine r2修補候選

這是本輪實寫17冊正文＋5證據附錄＋作者端測試的本機文件候選。請從[INDEX](INDEX.md)讀相應功能正文，再讀[覆蓋實數](COVERAGE_REPORT.md)及[26項修補閉環](REPAIR_CLOSURE_REPORT.md)。來源/ABI/Host/Checker/Release的受影HOLD見E04；未用文件代替原生權限或收據。

本輪已使用本機sbl-tpm-sp入口/setup/產品/系統/程序/handoff及八PIPD技能，實際調用原plugin scripts/core.py做24DOC corpus、risk mapping、planned TQAEP、affected-work、GHP-01本機交付等檢查，raw在plugin_invocation.json。不是正式Canonical PI/PD/Permit/Independent PASS。

可重跑 `python -B tools/validate.py`（需Python jsonschema、markdown-it-py、PyYAML）；只寫本輸出03_TESTS_AND_READBACK，不修改原來源或Repo。Zip按實存檔封裝，checksum清單排除自身和封裝檔以避免自指；外層zip另有sha256。



## Revision2：實際CLI Raw與96格語義Oracle補強

前版原始封存保留於prior_seal.json；本版不是以891個形狀/靜態檢查宣稱全部domain語義已通過。新實跑原SBL source module 27次，每次--data-dir都在私有work WriteSet，涵蓋POS、duplicate/empty/unknown拒收且state無diff、新PID持久化、兩entrypoint parity、remove回空，以及uninstall保留foreign sentinel。未安裝Host，未操作正式user store、HGK/Hermes或Issuer。

96格新增可執行domain與oracle-specific negative fixtures，現讀回679項作者端檢查PASS、0FAIL；正向格結果為50 PASS_LOCAL_ORACLE＋46 HOLD。HOLD包括原校準/Human或Judge Reader缺件、性能門檻未綁和沒有兩版本升級資格。這些不是96 Native Case PASS；source module/27 process Raw亦不能替代其他Host、W18正式普通Goal或受保護Checker。

完整case-specific JSON與實際輸出在oracle96_semantic_fixtures_v2.json、oracle96_verification_v2.json；source/runtime邊界見BODY-07的R2-07-C39與verification_scope_revision2.md。原Goal/17冊/26 Findings和所有分母維持，不因本輪聚焦F-21而縮減。
