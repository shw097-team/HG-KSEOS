"""Author-side document/fixture checks only. Never calls a native effect, issuer or checker.

Run from the deliverable root: python -B tools/validate.py
"""
from pathlib import Path
import json,re,hashlib,copy,sys,time,collections,urllib.parse
from markdown_it import MarkdownIt
from jsonschema import Draft202012Validator
import yaml
ROOT=Path(__file__).resolve().parent.parent;DATA=ROOT/'03_TESTS_AND_READBACK'
def load(n):return json.loads((DATA/n).read_text(encoding='utf-8'))
def sha(b):return hashlib.sha256(b).hexdigest()
def put(n,obj):(DATA/n).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
def require(ok,code):
    if not ok:raise ValueError(code)
def accepted(fn,*args):
    try:return {'decision':'ACCEPT_DESIGN_FIXTURE','value':fn(*args)}
    except ValueError as e:return {'decision':'REJECT','first_fail':str(e)}
def topology(g):
    nodes={r['id'] for r in g['nodes']};require(len(nodes)==22,'DAG_DENOMINATOR');indeg={n:0 for n in nodes};edges=[]
    for e in g['typed_edges']:
        require(e['from'] in nodes and e['to'] in nodes,'DAG_UNKNOWN_NODE');indeg[e['to']]+=1;edges.append((e['from'],e['to']))
    queue=sorted(n for n,k in indeg.items() if k==0);order=[]
    while queue:
        n=queue.pop(0);order.append(n)
        for a,b in edges:
            if a==n:
                indeg[b]-=1
                if indeg[b]==0:queue.append(b);queue.sort()
    require(len(order)==22,'DAG_CYCLE')
    require(order.index('WP-FHS-17')<order.index('WP-FHS-06'),'BOOTSTRAP_DEPENDENCY_INVERSION')
    return order
def effect_guard(tier,effect,grant=False,shadow=False,operation='read'):
    require(not (tier=='L1' and effect not in ['NONE','SOURCE_READ']),'DENY_EFFECT_MISMATCH')
    require(not(shadow and operation in ['build_wheel','send_w3_packet','write']),'W2_SHADOW_WRITE_DENY')
    require(effect not in ['REPO_WRITE','HOST_OP','USER_OP','REMOTE_WRITE','RELEASE'] or grant,'MISSING_ORIGINAL_ADMISSION')
    return 'SCOPED_DESIGN_ALLOWED'
def edge_guard(spec,payload):
    require(payload.get('type_tag')==spec['type_tag'],'NACK_WRONG_DOMAIN_SCHEMA')
    require(set(spec['required_fields'])<=set(payload),'REQUIRED_FIELD_MISSING')
    require(payload.get('receiver')==spec['consumer'],'RECEIVER_MISMATCH')
    if spec['edge_id']=='AC-E12':require(payload.get('maker')!=payload.get('checker'),'SELF_ACCEPTANCE_DENY')
    return 'SHAPE_ONLY_NEVER_NATIVE_ACK'
def brand_guard(obs):
    require(obs.get('brand')=='SBL' and obs.get('swof_identity')!='SBL','BRAND_IDENTITY_COLLISION')
    require(not obs.get('sbl_is_genie_writer'),'SWOF_IDENTITY_COLLISION');return 'DOMAIN_BRAND_ASSERTION'
def u03_guard(matrix):
    require({(x['sp'],x['action']) for x in matrix}=={(s,a) for s in ['TPM','Commander','Challenge'] for a in ['install','load','invoke']},'SP_ACTION_MATRIX_INCOMPLETE')
    return len(matrix)
def cell_guard(spec,raw):
    for k in ['id','kind','mode','host','legacy_provider_token']:require(raw.get(k)==spec[k],'CROSS_HOST_OR_CELL_EVIDENCE')
    require(not(spec['provider_off_candidate'] and raw.get('provider_network_calls',0)>0),'PROVIDER_OFF_NETWORK_DENY')
    return 'DESIGN_SCOPE_ONLY_PROVIDER_MAP_STILL_OWNER_HOLD'
def default_guard(record):
    require(record['product_decision']=='MANDATED_DEFAULT','DEFAULT_PROMISE_REGRESSION')
    require(record['install_state'] in ['NOT_OBSERVED','INSTALLED','ABSENT_CONFIRMED'],'INSTALL_STATE_INVALID')
    return 'DEFAULT_PRESERVED_ACTIVATION_NOT_PROVEN'
def asset_guard(record,operation):
    t=record['asset_type_candidate'];d=record['original_disposition'].upper()
    require(not(operation=='install' and ('REJECT' in d or t in ['REJECT','DEFER','METHOD_ONLY','FORMAT'])),'ASSET_TYPE_OR_DISPOSITION_DENY')
    require(not(operation=='replace_issuer' or operation=='second_queue'),'CONTROL_PLANE_COLLISION')
    return 'RECIPE_ONLY_NO_INSTALLATION'
def r15_guard(record,source_record):
    require(record['product_normative_requirement']==source_record['original_requirement'],'R15_PRODUCT_MEANING_LOST')
    require(record['b1_applicability']==source_record['b1_applicability'],'B1_DISPOSITION_CHANGED')
    return 'ORTHOGONAL_PRODUCT_AND_B1'
def slot_guard(edge,ecp):
    require(ecp==edge['ecp_route'],'SLOT_EFFECT_ECP_MISMATCH');require(len(edge['tqaep_case_ids'])==4,'TQAEP_CASE_GAP');return 'TRACE_EDGE_BOUND_DESIGN'
def runner_guard(binding):
    entry=binding.get('runner_entry');require(isinstance(entry,dict),'RUNNER_NOT_BOUND')
    required=['case_id','source_sha','runner_sha','input_schema_id','raw_schema_id','call_signature','oracle_sha','host','checker_reader_ref']
    require(all(entry.get(k) for k in required),'RUNNER_SIGNATURE_INCOMPLETE')
    require(entry['case_id']==binding['case_id'],'RUNNER_CASE_MISMATCH')
    require(not any(str(v).startswith(('BIND_','RETRIEVE_')) for v in entry.values()),'PLACEHOLDER_IS_NOT_BINDING')
    # The author-side checker has no trusted native Reader and cannot manufacture live acceptance.
    raise ValueError('TRUSTED_NATIVE_REGISTRY_READER_REQUIRED')
def normal_guard(obs):
    require(obs['pid']!=obs['previous_pid'] and obs['fresh_session'],'FRESH_PID_REQUIRED')
    require(not obs['b1_long_prompt'] and not obs['test_only_binding'] and obs['formal_profile'],'NORMAL_MODE_NOT_QUALIFIED')
    require(obs['required_lanes']<=obs['served_lanes'],'REQUIRED_LANE_NOT_SERVED');return 'NORMAL_CONTRACT_FIXTURE_ONLY'
def runtime_guard(state,event):
    require(event['lease_generation']==state['lease_generation'],'LEASE_FENCING_DENY')
    if state['effect_status']=='UNKNOWN':require(event['action']=='reconcile','EFFECT_REPLAY_DENY')
    return 'RECONCILE_REQUIRED' if state['effect_status']=='UNKNOWN' else 'NO_EFFECT_MODEL_STEP'
def commander_guard(obs):
    require(obs['producer']!='sbl-commander-sp','LEGACY_COMMANDER_DISABLED')
    require(not obs['requires_own_workorder'],'BOOTSTRAP_DEPENDENCY_INVERSION')
    require(obs['proposal_only'],'PROPOSAL_NOT_NATIVE_WORKORDER');return 'PORTABLE_GUIDE_PROPOSAL'
def oracle_guard(spec,obs):
    require(obs['case_id']==spec['case_id'] and obs['oracle_type']==spec['oracle_type'],'ORACLE_CELL_MISMATCH')
    require(set(spec['fixture_schema'])<=set(obs),'ORACLE_INPUT_UNBOUND')
    return 'INPUT_SHAPE_ONLY_NOT_ORACLE_EXECUTION'
def close_guard(effect,obs):
    if effect=='SOURCE_READ':require(obs.get('world_diff')==0,'READ_ONLY_WORLD_DIFF');return 'READ_COMPLETE_NO_EFFECT_RECEIPT'
    require(obs.get('effect_status')!='UNKNOWN' or obs.get('next_action')=='reconcile','UNKNOWN_EFFECT_CANNOT_CLOSE')
    require(obs.get('residue_scan') is not None,'RESIDUE_SCAN_MISSING');return 'EFFECT_CLOSE_MODEL_ONLY'
def markdown_issues(files=None):
    md=MarkdownIt('commonmark').enable('table');issues=[]
    for p in files or sorted(ROOT.rglob('*.md')):
        raw=p.read_bytes()
        try:t=raw.decode('utf-8','strict')
        except UnicodeDecodeError:issues.append([str(p),'UTF8']);continue
        if b'\r' in raw:issues.append([str(p),'CRLF'])
        if not t.strip():issues.append([str(p),'EMPTY'])
        if p.parent.name=='01_BODY':
            front=re.match(r'^---\n(.*?)\n---\n',t,re.S)
            if not front:issues.append([str(p),'FRONTMATTER'])
            else:
                f=yaml.safe_load(front.group(1));req=['artifact_id','formal_name','short_name','version','source_set_hash_or_pending','intended_consumer','owner_role','design_status','claim_ceiling','supersession_scope','AUDIT_F_IDs']
                if not all(k in f for k in req):issues.append([str(p),'FRONTMATTER_FIELDS'])
        tokens=md.parse(t);fences=[]
        for tok in tokens:
            if tok.type=='fence':
                if tok.info.strip()=='json':
                    try:json.loads(tok.content)
                    except json.JSONDecodeError as e:issues.append([str(p),'JSON',tok.map,str(e)])
            if tok.type=='inline':
                for child in tok.children or []:
                    if child.type in ['link_open','image']:
                        dest=child.attrGet('href') or child.attrGet('src')
                        if dest and not re.match(r'^[a-zA-Z]+:',dest):
                            target,_,anchor=urllib.parse.unquote(dest).partition('#');q=(p.parent/target).resolve() if target else p
                            if not q.exists():issues.append([str(p),'BROKEN_LINK',dest])
                            if not q.is_relative_to(ROOT.resolve()):issues.append([str(p),'ESCAPING_LINK',dest])
        ncols=None;inside=False
        for i,line in enumerate(t.splitlines(),1):
            if re.match(r'^\s*(```|~~~)',line):inside=not inside
            if line.startswith('|') and not inside:
                n=len(re.split(r'(?<!\\)\|',line))-2
                if ncols is not None and n!=ncols:issues.append([str(p),'TABLE_COLUMNS',i,n,ncols])
                ncols=n
                if line.count('`')%2:issues.append([str(p),'BACKTICK',i])
            else:ncols=None
        if inside:issues.append([str(p),'UNCLOSED_FENCE'])
    return issues

def run():
    start=time.perf_counter();results=[]
    def check(case,expected,fn,scope='AUTHOR_STATIC'):
        tick=time.perf_counter()
        try:actual=fn();status='PASS' if actual==expected else 'FAIL'
        except Exception as e:actual={'exception':type(e).__name__,'message':str(e)};status='FAIL'
        results.append({'case_id':case,'scope':scope,'expected':expected,'actual':actual,'status':status,'elapsed_ms':round((time.perf_counter()-tick)*1000,3)})
    def decision(fn,*args):return accepted(fn,*args)['decision']
    def reject(fn,*args):return decision(fn,*args)=='REJECT'
    graph=load('wp_graph.json');edges=load('acceptance_edges15.json');children=load('children149.json');cells=load('cells192.json');u03=load('u03_nine_subtests.json');sets=load('asset_sets.json');r15=load('r15_atoms949.json');slots=load('b1_edges31.json');binds=load('runner_bindings.json');schemas=load('native_schema_fixtures.json');cli=load('cli_probes.json');oracles=load('challenge96.json')
    check('F-01-POS',True,lambda:decision(effect_guard,'L2','REPO_WRITE',True)=='ACCEPT_DESIGN_FIXTURE')
    check('F-01-NEG',True,lambda:reject(effect_guard,'L1','REPO_WRITE',True))
    body_text='\n'.join(p.read_text(encoding='utf-8') for p in (ROOT/'01_BODY').glob('*.md'))
    check('F-01-ALL-BODIES-LEGACY-WRITE-NEG',True,lambda:'L1 有界隔離 Red/Patch/Green' not in body_text and 'L1_ONLY_IF_ALLOWED' not in body_text)
    def edge_payload(e):return {'type_tag':e['type_tag'],**{k:'STATIC-'+k for k in e['required_fields']},'receiver':e['consumer'],'maker':'maker-fixture','checker':'different-fixture'}
    for e in edges:
        check(e['edge_id']+'-POS',True,lambda e=e:decision(edge_guard,e,edge_payload(e))=='ACCEPT_DESIGN_FIXTURE')
        foreign=edge_payload(edges[6])
        check(e['edge_id']+'-WRONG-DOMAIN',True,lambda e=e,f=foreign:reject(edge_guard,e,{**f,'type_tag':'WRONG-'+e['type_tag']}))
    check('F-02-POS',True,lambda:len({tuple(e['required_fields']) for e in edges})==15)
    check('F-02-NEG',True,lambda:reject(edge_guard,edges[11],edge_payload(edges[6])))
    check('F-02-SELF-SIGN',True,lambda:reject(edge_guard,edges[11],{**edge_payload(edges[11]),'maker':'same','checker':'same'}))
    plugin_pi=load('plugin_pi_input_schema.json');v=Draft202012Validator(plugin_pi)
    pi={'intent':{'subject_id':'INTENT-'+'a'*16,'content_hash':'a'*64},'profile':'ASSURED','atoms':[{'req_id':'REQ-INTENT','source_clause':'source:l1','owner':'PIPD-EC','acceptance_cue':'concrete fixture','risk_guard':'no effect'}],'goal':'make bounded specification'}
    check('F-03-POS',True,lambda:not list(v.iter_errors(pi)))
    check('F-03-NEG',True,lambda:bool(list(v.iter_errors({**pi,'_profile_meta':{}}))))
    check('F-04-POS',22,lambda:len(topology(graph)))
    cycle=copy.deepcopy(graph);cycle['typed_edges'].append({'from':'WP-FHS-06','to':'WP-FHS-17','type':'MUTATION'})
    check('F-04-NEG',True,lambda:reject(topology,cycle))
    check('F-05-POS',True,lambda:decision(brand_guard,{'brand':'SBL','swof_identity':'SWOF','sbl_is_genie_writer':False})=='ACCEPT_DESIGN_FIXTURE' and len(children)==149)
    check('F-05-NEG',True,lambda:reject(brand_guard,{'brand':'SWOF','swof_identity':'SBL','sbl_is_genie_writer':True}))
    for c in children:
        check(c['id']+'-SPEC-CONTEXT',True,lambda c=c:all(c.get(k) for k in ['parent_full','fragment','positive_behavior','negative_mutation','first_fail','source']) and c['positive_behavior']!=c['negative_mutation'])
    check('F-06-POS',9,lambda:u03_guard(u03));check('F-06-NEG',True,lambda:reject(u03_guard,[r for r in u03 if r['sp']=='TPM']))
    check('F-07-POS',192,lambda:len({(c['kind'],c['mode'],c['host'],c['legacy_provider_token']) for c in cells}))
    for c in cells:
        raw={**{k:c[k] for k in ['id','kind','mode','host','legacy_provider_token']},'provider_network_calls':0}
        check('CELL-'+c['id']+'-POS',True,lambda c=c,raw=raw:decision(cell_guard,c,raw)=='ACCEPT_DESIGN_FIXTURE')
        check('CELL-'+c['id']+'-FOREIGN-HOST',True,lambda c=c,raw=raw:reject(cell_guard,c,{**raw,'host':'FOREIGN_HOST'}))
    check('F-07-NEG',True,lambda:reject(cell_guard,cells[2],{**cells[2],'host':'Hermes Agent'}))
    check('F-08-POS',True,lambda:decision(effect_guard,'L0','LOCAL_DRAFT_WRITE',True,False,'build_wheel')=='ACCEPT_DESIGN_FIXTURE')
    check('F-08-NEG',True,lambda:reject(effect_guard,'L1','SOURCE_READ',False,True,'build_wheel'))
    check('F-09-POS',True,lambda:all(decision(default_guard,r)=='ACCEPT_DESIGN_FIXTURE' for r in sets['Default30']))
    check('F-09-NEG',True,lambda:reject(default_guard,{**sets['Default30'][0],'product_decision':'OPTIONAL'}))
    check('F-09-ALL-BODIES-ABSENCE-NEG',True,lambda:'NOT_INSTALLED_NOT_VERIFIED' not in body_text)
    check('F-10-POS',386,lambda:sum(bool(r['build_or_use_recipe'] and r['domain_original']) for r in sets['TECH386']))
    rejected=next((r for r in sets['TECH386'] if r['asset_type_candidate']=='REJECT'),{**sets['TECH386'][0],'asset_type_candidate':'REJECT','original_disposition':'REJECT'})
    check('F-10-NEG',True,lambda:reject(asset_guard,rejected,'install'))
    check('TECH-ALL-REJECT-TYPED',True,lambda:all(r['asset_type_candidate']=='REJECT' for r in sets['TECH386'] if 'REJECT' in r['original_disposition'].upper()))
    check('DEFAULT-FUNCTIONAL-ASSET-TYPES',True,lambda:all(next(r for r in sets['Default30'] if r['name']==n)['asset_type_candidate']==t for n,t in [('Semgrep','CLI'),('CodeQL','CLI'),('DocETL','LIBRARY'),('AGENTS.md','FORMAT')]))
    check('F-11-POS',24,lambda:len({r['id'] for r in sets['Donor24']}))
    check('F-11-NEG',True,lambda:reject(asset_guard,{**sets['Donor24'][0],'asset_type_candidate':'METHOD_ONLY'},'install'))
    for s in schemas:
        v2=Draft202012Validator(s['schema']);n=s['contract']
        check('SCHEMA-'+n+'-POS',True,lambda s=s,v2=v2:not list(v2.iter_errors(s['positive'])))
        check('SCHEMA-'+n+'-MISSING',True,lambda s=s,v2=v2:bool(list(v2.iter_errors(s['missing']))))
        check('SCHEMA-'+n+'-UNKNOWN',True,lambda s=s,v2=v2:bool(list(v2.iter_errors(s['unknown']))))
    check('F-12-POS',19,lambda:len({s['schema']['$id'] for s in schemas}))
    check('F-12-NEG',True,lambda:all(bool(list(Draft202012Validator(s['schema']).iter_errors(s['unknown']))) for s in schemas))
    check('F-13-POS',13,lambda:sum(r['case']=='help' and r['exit']==0 and r['verb']!='compile-cc' for r in cli))
    check('F-13-NEG',True,lambda:all(r['exit']!=0 for r in cli if r['case']=='invalid'))
    check('CLI13-14-CONFLICT-DETECTED',14,lambda:len({r['verb'] for r in cli}))
    resolution=load('source_resolution.json');r15_source=next(r for r in resolution if r['alias']=='SRC-L-022')['candidates'][0]
    original_text=Path(r15_source['path']).read_text(encoding='utf-8-sig')
    original_r15={}
    for m in re.finditer(r'^#### (R15-\d{3})｜([^\n]+)\n(.*?)(?=^#### R15-|^## 4\.|\Z)',original_text,re.M|re.S):
        uid,description,clause=m.groups();disposition=next((x for x in ['B1_REQUIRED','CONDITIONAL','FULL_PRODUCT_DEFERRED'] if x in clause),'SOURCE_HOLD')
        original_r15[uid]={'original_requirement':description,'b1_applicability':disposition,'original_clause':clause.strip()}
    check('F-14-POS',949,lambda:sum(decision(r15_guard,r,original_r15[r['id']])=='ACCEPT_DESIGN_FIXTURE' for r in r15))
    check('F-14-NEG',True,lambda:reject(r15_guard,{**r15[1],'product_normative_requirement':'OPTIONAL_ALL_DEFERRED'},original_r15[r15[1]['id']]))
    for atom in r15:
        original=original_r15[atom['id']]
        check(atom['id']+'-ACTUAL-SOURCE-CLAUSE',True,lambda a=atom,o=original:a['original_requirement']==o['original_requirement'] and a['original_clause'].strip()==o['original_clause'] and a['b1_applicability']==o['b1_applicability'])
        check(atom['id']+'-PRODUCT-REGRESSION-NEG',True,lambda a=atom,o=original:reject(r15_guard,{**a,'product_normative_requirement':'DROPPED_OR_OPTIONAL'},o))
    check('F-15-POS',True,lambda:len(slots)==31 and len({r['atom_id'] for r in slots})==27 and all(decision(slot_guard,r,r['ecp_route'])=='ACCEPT_DESIGN_FIXTURE' for r in slots))
    ops=next(r for r in slots if r['required_effect']=='HOST_OP');check('F-15-NEG',True,lambda:reject(slot_guard,ops,'DEV ECP'))
    check('F-16-POS',282,lambda:sum(reject(runner_guard,r) for r in binds))
    check('F-16-NEG',True,lambda:reject(runner_guard,{**binds[0],'runner_entry':'BIND_FROM_NATIVE'}))
    obs={'pid':2002,'previous_pid':1001,'fresh_session':True,'b1_long_prompt':False,'test_only_binding':False,'formal_profile':True,'required_lanes':{'PLAN'},'served_lanes':{'PLAN'}}
    check('F-17-POS',True,lambda:decision(normal_guard,obs)=='ACCEPT_DESIGN_FIXTURE');check('F-17-NEG',True,lambda:reject(normal_guard,{**obs,'test_only_binding':True}))
    ux_start=time.perf_counter();ledger={};metrics={'owner_prompts':0,'ready_progress':0,'retries':0};key=('subject','source','scope','epoch','Q1')
    def ask_once():
        if key not in ledger:ledger[key]='known answer';metrics['owner_prompts']+=1
        return ledger[key]
    ask_once();before=metrics['owner_prompts'];ask_once();metrics['second_round_prompts']=metrics['owner_prompts']-before
    states={'A':'PARK_ISSUER','B':'READY_SOURCE_READ','C':'READY_LOCAL_DRAFT'}
    metrics['ready_progress']=sum(s.startswith('READY') for s in states.values())
    metrics['elapsed_ms']=round((time.perf_counter()-ux_start)*1000,4)
    check('F-18-POS',True,lambda:metrics['second_round_prompts']==0 and metrics['ready_progress']==2)
    check('F-18-NEG',True,lambda:sum(s=='READY' for s in {'A':'PARK','B':'WAIT','C':'WAIT'}.values())==0 and metrics['ready_progress']>0)
    state={'effect_status':'UNKNOWN','lease_generation':8}
    check('F-19-POS',True,lambda:decision(runtime_guard,state,{'action':'reconcile','lease_generation':8})=='ACCEPT_DESIGN_FIXTURE')
    check('F-19-NEG',True,lambda:reject(runtime_guard,state,{'action':'replay','lease_generation':8}))
    check('LEASE-OLD-GENERATION-NEG',True,lambda:reject(runtime_guard,state,{'action':'reconcile','lease_generation':7}))
    cmd={'producer':'nonlegacy native PLAN Reader','requires_own_workorder':False,'proposal_only':True}
    check('F-20-POS',True,lambda:decision(commander_guard,cmd)=='ACCEPT_DESIGN_FIXTURE');check('F-20-NEG',True,lambda:reject(commander_guard,{**cmd,'producer':'sbl-commander-sp'}))
    for c in oracles:
        obs={'case_id':c['case_id'],'oracle_type':c['oracle_type'],**{k:'SHAPE_FIXTURE_NOT_RAW' for k in c['fixture_schema']}}
        check(c['case_id']+'-POS-SHAPE',True,lambda c=c,obs=obs:decision(oracle_guard,c,obs)=='ACCEPT_DESIGN_FIXTURE')
        check(c['case_id']+'-NEG-MISSING',True,lambda c=c,obs=obs:reject(oracle_guard,c,{k:v for k,v in obs.items() if k!=c['fixture_schema'][0]}))
    check('F-21-POS',96,lambda:len({(r['test_class'],r['oracle_type']) for r in oracles}))
    check('F-21-NEG',True,lambda:reject(oracle_guard,oracles[0],{'case_id':oracles[1]['case_id'],'oracle_type':oracles[1]['oracle_type']}))
    required=['README.md','INDEX.md','MANIFEST.md','COVERAGE_REPORT.md','REPAIR_CLOSURE_REPORT.md']+[f'02_EVIDENCE_APPENDICES/{n}' for n in ['E01_SOURCE_MANIFEST_AND_SEARCH.md','E02_REQUIREMENT_TRACE_AND_DENOMINATORS.md','E03_ABI_SCHEMAS_AND_FIXTURE_AUDIT.md','E04_CONFLICT_RCA_ADOPTION_AND_HOLDS.md','E05_QA_READBACK_AND_CLAIM_CEILING.md']]
    files={p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file()}
    check('F-22-POS',True,lambda:set(required)<=files)
    missing=files-{'02_EVIDENCE_APPENDICES/E03_ABI_SCHEMAS_AND_FIXTURE_AUDIT.md'};check('F-22-NEG',True,lambda:not set(required)<=missing)
    issues=markdown_issues();put('document_parse_issues.json',issues)
    check('F-23-POS',[],lambda:issues)
    check('F-23-NEG',True,lambda:'| bad `inline |'.count('`')%2==1)
    short='\n'.join(p.read_text(encoding='utf-8') for p in (ROOT/'01_BODY').glob('0[01]_*.md'));phrase='本版全22卡各自材料化'
    check('F-24-POS',True,lambda:short.count(phrase)<=1)
    check('F-24-NEG',True,lambda:(phrase*3).count(phrase)>1)
    aliases=load('source_alias_resolution.json');check('F-25-POS',True,lambda:all(r['status']=='READBACK_OK' and r['clause_sha256_lf'] and r['source_path'] for r in aliases))
    check('F-25-NEG',True,lambda:sha(b'altered clause')!=aliases[0]['clause_sha256_lf'])
    check('F-26-POS',True,lambda:decision(close_guard,'SOURCE_READ',{'world_diff':0})=='ACCEPT_DESIGN_FIXTURE')
    check('F-26-NEG',True,lambda:reject(close_guard,'HOST_OP',{'effect_status':'UNKNOWN','next_action':'delete_journal','residue_scan':[]}))
    # Physical source readback detects byte drift, not semantic approval.
    source_status=[]
    for r in load('source_manifest.json'):
        try:actual=sha(Path(r['path']).read_bytes());status='UNCHANGED' if actual==r['sha256'] else 'DRIFT'
        except OSError as e:actual=str(e);status='UNREADABLE'
        source_status.append({'path':r['path'],'expected_sha256':r['sha256'],'actual_sha256':actual,'status':status})
    put('source_recheck.json',source_status);check('SOURCE-BYTES-UNCHANGED',True,lambda:all(r['status']=='UNCHANGED' for r in source_status))
    # Separate the hard denominators rather than adding orthogonal sets.
    actuals={'body17':len(list((ROOT/'01_BODY').glob('*.md'))),'child149':len(children),'r15_atoms949':len(r15),'cell192':len(cells),'native20':len(sets['Native20']),'default30':len(sets['Default30']),'donor24':len(sets['Donor24']),'method25':len(sets['Method25']),'tech386':len(sets['TECH386']),'contracts19':len(schemas),'PI27':len({r['atom_id'] for r in slots}),'slot31':len(slots),'parent120':sum(r['case_id'].startswith(('TQ-B1-','TQ-GWO-')) for r in binds),'B1child124':sum(r['case_id'].startswith('TQ-CHILD-') for r in binds),'node38':sum(r['case_id'].startswith('B1-N') for r in binds),'wp22':len(graph['nodes']),'edge15':len(edges),'challenge96':len(oracles)}
    for k,n in actuals.items():expected=int(re.search(r'(\d+)$',k).group(1));check('DENOM-'+k,expected,lambda n=n:n)
    distribution=collections.Counter(r['b1_applicability'] for r in r15);check('R15-B1-DISTRIBUTION',{'B1_REQUIRED':66,'CONDITIONAL':254,'FULL_PRODUCT_DEFERRED':629},lambda:dict(distribution))
    report={'schema':'AUTHOR.StaticValidationReport/1','command':[sys.executable,'-B',str(Path(__file__).resolve())],'scope':'AUTHOR_STATIC_FIXTURES_ONLY','native_execution':'NATIVE_NOT_RUN','independent_checker':'NOT_RUN','release':'NOT_RUN','results':results,'passed':sum(r['status']=='PASS' for r in results),'failed':sum(r['status']=='FAIL' for r in results),'elapsed_seconds':round(time.perf_counter()-start,4),'owner_metrics_model':metrics,'denominators':actuals,'source_files_rechecked':len(source_status),'claim_ceiling':'MECHANICAL_DOCUMENT_AND_DESIGN_GUARD_CHECKS; NOT_FULL_NATIVE_OR_INDEPENDENT_ACCEPTANCE'}
    put('static_validation_result.json',report)
    rows=['# 當期作者端靜態測試','',f'實跑 {len(results)} 項；PASS={report["passed"]}；FAIL={report["failed"]}；elapsed={report["elapsed_seconds"]}秒。','',f'命令：{sys.executable} -B tools/validate.py','', '這些測試驗文件、source bytes、schema形狀、設計拒收器與局部狀態模型。149業務語義的實機結果、192 Host matrix、96真Oracle與282 B1 Native均未執行；不能把作者fixture當Native Raw或獨立PASS。','','| Case | result | expected | actual |','|---|---|---|---|']
    for r in results:rows.append('| '+r['case_id']+' | '+r['status']+' | '+str(r['expected']).replace('|','&#124;')+' | '+str(r['actual']).replace('|','&#124;')+' |')
    (DATA/'static_validation_result.md').write_text('\n'.join(rows)+'\n',encoding='utf-8',newline='\n')
    (DATA/'test_matrix.md').write_text('\n'.join(rows)+'\n',encoding='utf-8',newline='\n')
    print(json.dumps({'passed':report['passed'],'failed':report['failed'],'failures':[r for r in results if r['status']=='FAIL'],'scope':report['scope']},ensure_ascii=False,indent=2));return 1 if report['failed'] else 0
if __name__=='__main__':raise SystemExit(run())
