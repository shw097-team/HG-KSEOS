from pathlib import Path
import json,hashlib,sys,copy,time
from author_oracles import evaluate
ROOT=Path(__file__).resolve().parent.parent;DATA=ROOT/'03_TESTS_AND_READBACK'
def load(n):return json.loads((DATA/n).read_text(encoding='utf-8'))
def sha(b):return hashlib.sha256(b).hexdigest()
def main():
    pairs=load('oracle96_semantic_fixtures_v2.json');specs={r['case_id']:r for r in load('challenge96.json')};actual=load('isolated_actual_cli.json');events={r['case_id']:r for r in actual['results']};results=[];tick=time.perf_counter()
    def test(case,expected,fn):
        try:value=fn();status='PASS' if value==expected else 'FAIL'
        except Exception as e:value=type(e).__name__+':'+str(e);status='FAIL'
        results.append({'case_id':case,'expected':expected,'actual':value,'status':status})
    for event in actual['results']:
        test(event['case_id']+'-RAW-HASH',event['stdout_sha256'],lambda e=event:sha(e['stdout'].encode('utf-8')))
        test(event['case_id']+'-JSON-READBACK',event['parsed'],lambda e=event:json.loads(e['stdout']))
        test(event['case_id']+'-WRITESET',True,lambda e=event:Path(e['argv'][5]).resolve().is_relative_to(Path(actual['write_set']).resolve()))
    for p in pairs:
        spec=copy.deepcopy(specs[p['case_id']]);spec['domain_first_fail']='DOMAIN_'+spec['test_class']+'_INVARIANT'
        for typ,key,expected in [('POS','positive',p['expected_positive_verdict']),('NEG-DOMAIN','negative_domain','DENY'),('NEG-ORACLE','negative_oracle','DENY')]:
            test(p['case_id']+'-'+typ,expected,lambda s=spec,p=p,key=key:evaluate(s,p[key])['verdict'])
        test(p['case_id']+'-ACTUAL-RAW-REFS',True,lambda p=p:all(ref in events for ref in p['positive']['actual_raw_refs']))
        foreign=copy.deepcopy(p['positive']);foreign['case_id']='AC-C39-FOREIGN-CASE'
        test(p['case_id']+'-FOREIGN-CASE','DENY',lambda s=spec,f=foreign:evaluate(s,f)['verdict'])
        escalated=copy.deepcopy(p['positive']);escalated['claim_native_pass']=True
        test(p['case_id']+'-AUTHOR-RAW-ESCALATION','DENY',lambda s=spec,f=escalated:evaluate(s,f)['verdict'])
        if spec['oracle_type']=='COMPOSITE' and spec['test_class'] not in ['UPGRADE']:
            fake=copy.deepcopy(p['positive']);fake['oracle']['state']['observed_state']={'changed':'world'}
            test(p['case_id']+'-COMPOSITE-PROXY','DENY',lambda s=spec,f=fake:evaluate(s,f)['verdict'])
        if spec['oracle_type']=='STATISTICAL' and spec['test_class']!='UPGRADE':
            fake=copy.deepcopy(p['positive']);fake['oracle']['owner_threshold']=0;fake['oracle']['approval_receipt']='MAKER_ASSERTED_PASS'
            test(p['case_id']+'-FAKE-CALIBRATION','HOLD',lambda s=spec,f=fake:evaluate(s,f)['verdict'])
    summary={'scope':'AUTHOR_LOCAL_ORACLE_ENGINE_AND_ACTUAL_PRIVATE_CLI_RAW; NOT_NATIVE_QUALIFICATION','passed':sum(r['status']=='PASS' for r in results),'failed':sum(r['status']=='FAIL' for r in results),'results':results,'elapsed_seconds':round(time.perf_counter()-tick,5),'oracle_cells':len(pairs),'actual_cli_process_invocations':len(actual['results']),'positive_cell_verdicts':{v:sum(p['actual_positive']['verdict']==v for p in pairs) for v in ['PASS_LOCAL_ORACLE','HOLD','DENY']},'native_case_pass':0,'independent_verdict':'NOT_RUN'}
    (DATA/'oracle96_verification_v2.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
    md=['# 96格Oracle第二輪實測','',f'作者端引擎檢查PASS={summary["passed"]}、FAIL={summary["failed"]}；讀回27次私有資料CLI實跑Raw。','',f'96格正向結果：{summary["positive_cell_verdicts"]}。288個POS/domain-NEG/oracle-NEG加上Raw hash/JSON/WriteSet、跨case、越級claim、composite proxy及假校準破壞性測試。','', 'HOLD表示原校準、Human/Judge Reader、兩版本升級或性能門檻尚未綁定。PASS_LOCAL_ORACLE也僅是作者端演算法與此隔離CLI例；不宣稱不同Host、B1/Hermes、W18正常模式、Protected Checker或Release。','','| Case | expected | actual | status |','|---|---|---|---|']
    for r in results:md.append('| '+' | '.join(str(r[k]).replace('|','&#124;').replace('\n','<br>') for k in ['case_id','expected','actual','status'])+' |')
    (DATA/'oracle96_verification_v2.md').write_text('\n'.join(md)+'\n',encoding='utf-8',newline='\n')
    print(json.dumps({k:v for k,v in summary.items() if k!='results'},ensure_ascii=False,indent=2));return 1 if summary['failed'] else 0
if __name__=='__main__':raise SystemExit(main())
