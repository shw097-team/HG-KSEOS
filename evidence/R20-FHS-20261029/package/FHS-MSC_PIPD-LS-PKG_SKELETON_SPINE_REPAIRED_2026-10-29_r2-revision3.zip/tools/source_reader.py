"""Read a pinned local source alias and an inclusive line slice. No mutation."""
from pathlib import Path
import json,hashlib,sys
root=Path(__file__).resolve().parent.parent
def main():
    aliases=json.loads((root/'03_TESTS_AND_READBACK/source_alias_map.json').read_text(encoding='utf-8'))
    alias=sys.argv[1];start=int(sys.argv[2]);end=int(sys.argv[3]) if len(sys.argv)>3 else start
    row=aliases.get(alias)
    if not row:raise ValueError('SOURCE_HOLD: '+alias)
    p=Path(row['path']);raw=p.read_bytes();digest=hashlib.sha256(raw).hexdigest()
    if digest!=row['sha256']:raise ValueError('SOURCE_DRIFT: '+alias)
    ls=raw.decode('utf-8-sig').splitlines()
    if not 1<=start<=end<=len(ls) or end-start>=250:raise ValueError('LINE_RANGE_INVALID_OR_OVER_250')
    excerpt='\n'.join(ls[start-1:end]);print(json.dumps({'alias':alias,'path':str(p),'source_sha256':digest,'line_from':start,'line_to':end,'clause_sha256_lf':hashlib.sha256(excerpt.encode()).hexdigest(),'status':'READBACK_ONLY_NOT_AUTHORITY'},ensure_ascii=False))
    for i in range(start,end+1):print(f'{i}: {ls[i-1]}')
if __name__=='__main__':
    sys.stdout.reconfigure(encoding='utf-8')
    try:main()
    except (ValueError,OSError,KeyError,IndexError) as e:print(json.dumps({'status':'SOURCE_HOLD','first_fail':str(e)},ensure_ascii=False));sys.exit(2)
