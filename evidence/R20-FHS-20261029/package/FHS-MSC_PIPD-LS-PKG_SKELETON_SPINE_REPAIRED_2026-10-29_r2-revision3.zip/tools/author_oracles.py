"""Executable author-side oracle candidates. No native receipt, permission or authority is issued.

The Reader consumes an actual isolated CLI observation plus deliberately bad fixtures.
PASS_LOCAL_ORACLE is never a protected verdict and cannot be submitted as one.
"""
import json,hashlib
def digest(value):return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def outcome(verdict,code,case):return {'verdict':verdict,'first_fail':code,'case_id':case,'claim_ceiling':'AUTHOR_LOCAL_ORACLE_ONLY','native_execution':'NOT_RUN'}
class Deny(ValueError):pass
def need(condition,code):
    if not condition:raise Deny(code)
def domain_predicate(kind,d):
    """Each TestClass uses a different source-domain predicate, not a field-present test."""
    if kind=='POS':return d['exit']==0 and d['ok'] is True and d['title']==d['requested_title'] and d['count']==1
    if kind=='NEG':return d['exit']==3 and d['code']=='SBL_E_DUPLICATE_TITLE' and d['before']==d['after']
    if kind=='EDGE':return d['exit']==2 and d['code']=='SBL_E_EMPTY_TITLE' and d['before']==d['after']
    if kind=='SEC':return d['exit']==5 and d['code']=='SBL_E_FOREIGN_FILES' and d['foreign_before']==d['foreign_after'] and d['store_before']==d['store_after']
    if kind=='MUT':return d['original_count']==1 and d['mutated_count']!=d['original_count'] and d['mutant_verdict']=='DENY_COUNT_MISMATCH'
    if kind=='PERF':return d['sample_count']>0 and len(d['elapsed_ms'])==d['sample_count'] and all(x>=0 for x in d['elapsed_ms']) and d['all_exit_zero']
    if kind=='RECOVERY':return d['writer_pid']!=d['reader_pid'] and d['added_id']==d['listed_id'] and d['post_count']==1 and d['restart_replayed_effect_count']==0
    if kind=='ROLLBACK':return d['remove_exit']==0 and d['before_items']==d['after_items']==[] and d['removed_id']==d['added_id']
    if kind=='UNINSTALL':return d['exit']==0 and d['uninstalled'] is True and not d['owned_dir_exists'] and d['foreign_dir_exists'] and d['foreign_preserved']
    if kind=='UPGRADE':return d['from_version']!=d['to_version'] and d['from_schema'] and d['to_schema'] and d['roundtrip_compatible'] and d['rollback_raw_ref']
    if kind=='PARITY':return d['surface_a']!=d['surface_b'] and d['pid_a']!=d['pid_b'] and d['canonical_a']==d['canonical_b']
    if kind=='JOURNEY':return d['stages']==['empty','add','visible_list','remove','empty'] and all(x==0 for x in d['exits']) and d['visible_fuo_title']==d['requested_title'] and d['final_count']==0
    raise Deny('UNKNOWN_TEST_CLASS')
def evaluate(spec,fixture):
    case=spec['case_id']
    try:
        need(fixture['case_id']==case,'FOREIGN_CASE_RECEIPT')
        need(fixture['test_class']==spec['test_class'] and fixture['oracle_type']==spec['oracle_type'],'TEST_CLASS_OR_ORACLE_MISMATCH')
        need(fixture['source_sha']==spec['source']['file_sha256'],'SOURCE_DRIFT')
        need(fixture['scope']=='AUTHOR_ISOLATED_CLI','WRONG_EXECUTION_SCOPE')
        need(not fixture.get('claim_native_pass',False),'AUTHOR_RAW_IS_NOT_NATIVE_PASS')
        if spec['test_class']=='UPGRADE' and fixture.get('source_context_unbound'):
            need(not fixture.get('claims_upgraded',False),'UPGRADE_PASS_WITHOUT_DISTINCT_VERSIONS')
            return outcome('HOLD','UPGRADE_TWO_VERSION_BINDING_REQUIRED',case)
        good=domain_predicate(spec['test_class'],fixture['domain'])
        need(good,spec['domain_first_fail'])
        o=fixture['oracle'];typ=spec['oracle_type']
        if typ=='DETERMINISTIC':
            need(o['expected'] is True and o['observed']==good,'DETERMINISTIC_VALUE_MISMATCH')
        elif typ=='STATE_READBACK':
            need(bool(o['actual_raw_refs']) and o['read_scope']=='same_private_store','STATE_READER_SCOPE_MISMATCH')
            need(o['expected_state']==o['observed_state'],'STATE_READBACK_MISMATCH')
        elif typ=='PROPERTY':
            need(isinstance(o['seed'],int) and o['cases'],'PROPERTY_GENERATOR_UNBOUND')
            need(all(domain_predicate(spec['test_class'],v) for v in o['cases']),'PROPERTY_COUNTEREXAMPLE')
            need(o['all_raw_refs_bound'],'PROPERTY_RAW_REF_UNBOUND')
        elif typ=='REFERENCE_OUTPUT':
            need(digest(o['reference'])==o['reference_sha256'],'REFERENCE_PIN_CHANGED')
            need(o['observed']==o['reference'],'REFERENCE_OUTPUT_MISMATCH')
        elif typ=='STATISTICAL':
            need(bool(o['dataset_sha256']) and o['sample_values'],'STATISTICAL_DATASET_MISSING')
            # Source-bound calibrated policy is unavailable; an author-entered threshold cannot confer it.
            return outcome('HOLD','ORIGINAL_CALIBRATED_THRESHOLD_READER_REQUIRED',case)
        elif typ=='SEMANTIC_JUDGE':
            need(bool(o['rubric_sha256']) and bool(o['judge_model_pin']),'SEMANTIC_JUDGE_INPUT_UNBOUND')
            return outcome('HOLD','ORIGINAL_HUMAN_CALIBRATION_AND_JUDGE_READER_REQUIRED',case)
        elif typ=='HUMAN':
            need(o.get('decision_actor')!='maker','MAKER_IS_NOT_HUMAN_DECISION')
            return outcome('HOLD','ORIGINAL_HUMAN_DECISION_READER_REQUIRED',case)
        elif typ=='COMPOSITE':
            need(o['ordering']==['domain','deterministic','state'],'COMPOSITE_ORDER_MISMATCH')
            need(set(o['hard_components'])=={'domain','deterministic','state'},'COMPOSITE_HARD_COMPONENT_MISSING')
            computed={'domain':good,'deterministic':o['deterministic']['expected'] is True and o['deterministic']['observed']==good,'state':o['state']['expected_state']==o['state']['observed_state']}
            need(o['components']==computed,'COMPOSITE_COMPONENT_PROXY')
            need(all(computed.values()),'COMPOSITE_HARD_FAIL')
        else:raise Deny('UNKNOWN_ORACLE_TYPE')
        if spec['test_class']=='PERF':return outcome('HOLD','PERFORMANCE_SOURCE_THRESHOLD_NOT_BOUND',case)
        return outcome('PASS_LOCAL_ORACLE','NONE',case)
    except (Deny,KeyError,TypeError,ValueError) as e:return outcome('DENY',str(e) or type(e).__name__,case)
