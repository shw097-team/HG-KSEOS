# 覆蓋實數與可宣稱上限

實寫17/17正文、5/5附錄。來源full-byte/heading/keyword掃描172檔；歷史來源SHA匹配54/55（缺SRC-L-009）。2106/2106可辨line locator已解析到真physical file SHA及LF slice hash。重讀原來源bytes仍unchanged，詳source_recheck.json。

當期作者端檢測2789/2789 PASS、0 FAIL；只代表檔案/分母/Schema形狀/拒收器與局部狀態模型。149的實機業務、192 Host適配、96真Oracle與282 B1 Native不因這些fixture變PASS。

| set | 設計record實數 | 作者端已驗 | 真Native/獨立 |
|---|---|---|---|
| SBL base DOC | 14 | identity/必要設計欄/來源/專用拒收範圍 | NOT_RUN |
| PIPD base DOC | 10 | identity/必要設計欄/來源/專用拒收範圍 | NOT_RUN |
| B1 DOC | 9 | identity/必要設計欄/來源/專用拒收範圍 | NOT_RUN |
| body books | 17 | identity/必要設計欄/來源/專用拒收範圍 | NOT_RUN |
| SBL Child | 149 | identity/必要設計欄/來源/專用拒收範圍 | NOT_RUN |
| R15 atoms | 949 | identity/必要設計欄/來源/專用拒收範圍 | NOT_RUN |
| KindModeHostProvider | 192 | identity/必要設計欄/來源/專用拒收範圍 | NOT_RUN |
| Native20 | 20 | identity/必要設計欄/來源/專用拒收範圍 | NOT_RUN |
| Default30 | 30 | identity/必要設計欄/來源/專用拒收範圍 | NOT_RUN |
| Donor24 | 24 | identity/必要設計欄/來源/專用拒收範圍 | NOT_RUN |
| Method25 | 25 | identity/必要設計欄/來源/專用拒收範圍 | NOT_RUN |
| TECH386 | 386 | identity/必要設計欄/來源/專用拒收範圍 | NOT_RUN |
| Canonical Contract | 19 | identity/必要設計欄/來源/專用拒收範圍 | NOT_RUN |
| original CLI verb | 13 | identity/必要設計欄/來源/專用拒收範圍 | NOT_RUN |
| discovered CLI parser verb | 14 | identity/必要設計欄/來源/專用拒收範圍 | NOT_RUN |
| B1 PI Atom | 27 | identity/必要設計欄/來源/專用拒收範圍 | NOT_RUN |
| B1 PD Slot | 31 | identity/必要設計欄/來源/專用拒收範圍 | NOT_RUN |
| B1 Parent | 120 | identity/必要設計欄/來源/專用拒收範圍 | NOT_RUN |
| B1 Child | 124 | identity/必要設計欄/來源/專用拒收範圍 | NOT_RUN |
| B1 Node | 38 | identity/必要設計欄/來源/專用拒收範圍 | NOT_RUN |
| WP | 22 | identity/必要設計欄/來源/專用拒收範圍 | NOT_RUN |
| AC Edge | 15 | identity/必要設計欄/來源/專用拒收範圍 | NOT_RUN |
| H4 | 12 | identity/必要設計欄/來源/專用拒收範圍 | NOT_RUN |
| SEAM | 11 | identity/必要設計欄/來源/專用拒收範圍 | NOT_RUN |
| Challenge Cell | 96 | identity/必要設計欄/來源/專用拒收範圍 | NOT_RUN |
| W18 E33-E42 | 10 | identity/必要設計欄/來源/專用拒收範圍 | NOT_RUN |
| NormalMode NM01-NM03 | 3 | identity/必要設計欄/來源/專用拒收範圍 | NOT_RUN |

R15 949 B1投影=66 REQUIRED/254 CONDITIONAL/629 FULL_PRODUCT_DEFERRED；不是Full Product完成度。五技術集合不相加。當期CLI module發現14verb，13原verb help/invalid均實測，額外compile-cc保留ABI_HOLD。19schema通過syntax fixture，不保證其內層{}的domain語義。

F-ID結案={'CLOSED_AUTHOR_STATIC': 18, 'NATIVE_BIND_HOLD': 7, 'SOURCE_HOLD': 1}。全部26有設計修補與專項fixture，18作者端閉合、7 Native binding HOLD、1 source/label HOLD。FULL_DOCUMENT_STATIC_PASS、INDEPENDENT_CASE_PASS、WORLD_EFFECT、RELEASED皆不宣稱。下一合法動作見E04各Owner/受影scope/resume predicate；其他合法READY照常前進。



## Revision2：實際CLI Raw與96格語義Oracle補強

前版原始封存保留於prior_seal.json；本版不是以891個形狀/靜態檢查宣稱全部domain語義已通過。新實跑原SBL source module 27次，每次--data-dir都在私有work WriteSet，涵蓋POS、duplicate/empty/unknown拒收且state無diff、新PID持久化、兩entrypoint parity、remove回空，以及uninstall保留foreign sentinel。未安裝Host，未操作正式user store、HGK/Hermes或Issuer。

96格新增可執行domain與oracle-specific negative fixtures，現讀回679項作者端檢查PASS、0FAIL；正向格結果為50 PASS_LOCAL_ORACLE＋46 HOLD。HOLD包括原校準/Human或Judge Reader缺件、性能門檻未綁和沒有兩版本升級資格。這些不是96 Native Case PASS；source module/27 process Raw亦不能替代其他Host、W18正式普通Goal或受保護Checker。

完整case-specific JSON與實際輸出在oracle96_semantic_fixtures_v2.json、oracle96_verification_v2.json；source/runtime邊界見BODY-07的R2-07-C39與verification_scope_revision2.md。原Goal/17冊/26 Findings和所有分母維持，不因本輪聚焦F-21而縮減。
