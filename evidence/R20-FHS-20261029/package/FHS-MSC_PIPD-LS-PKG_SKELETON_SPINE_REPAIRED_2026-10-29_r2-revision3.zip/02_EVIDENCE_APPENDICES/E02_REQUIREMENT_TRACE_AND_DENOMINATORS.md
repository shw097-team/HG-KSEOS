# E02 需求Trace與獨立分母

| set | count | claim |
|---|---|---|
| SBL base DOC | 14 | STRUCTURAL_PARSE_ONLY；Native執行另列 |
| PIPD base DOC | 10 | STRUCTURAL_PARSE_ONLY；Native執行另列 |
| B1 DOC | 9 | STRUCTURAL_PARSE_ONLY；Native執行另列 |
| body books | 17 | STRUCTURAL_PARSE_ONLY；Native執行另列 |
| SBL Child | 149 | STRUCTURAL_PARSE_ONLY；Native執行另列 |
| R15 atoms | 949 | STRUCTURAL_PARSE_ONLY；Native執行另列 |
| KindModeHostProvider | 192 | STRUCTURAL_PARSE_ONLY；Native執行另列 |
| Native20 | 20 | STRUCTURAL_PARSE_ONLY；Native執行另列 |
| Default30 | 30 | STRUCTURAL_PARSE_ONLY；Native執行另列 |
| Donor24 | 24 | STRUCTURAL_PARSE_ONLY；Native執行另列 |
| Method25 | 25 | STRUCTURAL_PARSE_ONLY；Native執行另列 |
| TECH386 | 386 | STRUCTURAL_PARSE_ONLY；Native執行另列 |
| Canonical Contract | 19 | STRUCTURAL_PARSE_ONLY；Native執行另列 |
| original CLI verb | 13 | STRUCTURAL_PARSE_ONLY；Native執行另列 |
| discovered CLI parser verb | 14 | STRUCTURAL_PARSE_ONLY；Native執行另列 |
| B1 PI Atom | 27 | STRUCTURAL_PARSE_ONLY；Native執行另列 |
| B1 PD Slot | 31 | STRUCTURAL_PARSE_ONLY；Native執行另列 |
| B1 Parent | 120 | STRUCTURAL_PARSE_ONLY；Native執行另列 |
| B1 Child | 124 | STRUCTURAL_PARSE_ONLY；Native執行另列 |
| B1 Node | 38 | STRUCTURAL_PARSE_ONLY；Native執行另列 |
| WP | 22 | STRUCTURAL_PARSE_ONLY；Native執行另列 |
| AC Edge | 15 | STRUCTURAL_PARSE_ONLY；Native執行另列 |
| H4 | 12 | STRUCTURAL_PARSE_ONLY；Native執行另列 |
| SEAM | 11 | STRUCTURAL_PARSE_ONLY；Native執行另列 |
| Challenge Cell | 96 | STRUCTURAL_PARSE_ONLY；Native執行另列 |
| W18 E33-E42 | 10 | STRUCTURAL_PARSE_ONLY；Native執行另列 |
| NormalMode NM01-NM03 | 3 | STRUCTURAL_PARSE_ONLY；Native執行另列 |

R15 B1適用：{'B1_REQUIRED': 66, 'FULL_PRODUCT_DEFERRED': 629, 'CONDITIONAL': 254}。Full Product原義與B1投影分開，629不代表Full Product已完成或Optional。149 child有Parent全文和業務POS/NEG；192有Host/Provider/Mode差異與NoFit，Provider legacy label矛盾不默改。

27→31逐邊和TQAEP Cases在b1_edges31.json；282 CaseSpec與RunnerBinding分物保留。無真runner的282/282一律NATIVE_NOT_RUN，不冒CASE_PASS。每大表的exact source與原clause都保存在machine record，正文直接提供行為規格。
