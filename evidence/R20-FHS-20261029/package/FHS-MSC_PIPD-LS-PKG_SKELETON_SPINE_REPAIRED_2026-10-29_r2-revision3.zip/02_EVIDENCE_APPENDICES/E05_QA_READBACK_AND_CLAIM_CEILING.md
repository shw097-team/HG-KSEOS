# E05 當期QA回讀與claim ceiling

已實跑作者端靜態檢測：2789/2789 PASS、0 FAIL；命令與expected/actual/elapsed在static_validation_result.json。首次Red三項（GENIEProjectionRef巢狀required fixture、回讀報告連結生成次序、r15分母鍵解析）已修；全文回歸另找到body10的legacy L1寫標籤及body08的未觀察/未安裝混用，亦已修並新增跨17冊NEG。Red/patch來源hash與本輪Green均有實存檔。

17冊/5附錄與根檔以strict UTF8/LF/Markdown table parser、JSON fence、relative links實測；2106line locator切片readback、172原來源bytes重讀、四Repo HEAD與工作樹status SHA前後相同。JSON/JSONL/Python語法與ZIP逐檔SHA會在seal readback再做一次；封裝readback存外層deliverable，不為hash清單自指造假。

19Schema syntax不是domain證明；13help不是13功能執行（當期parser另有第14個compile-cc）；149業務、192 Host、96原Oracle與282 B1 Native均NATIVE_NOT_RUN。原Spine Registered evidence不保證subject-bound，差額在BODY06/07及E04；不能借作者guard聲稱原生已修好。

修補狀態=18 CLOSED_AUTHOR_STATIC＋7 NATIVE_BIND_HOLD＋1 SOURCE_HOLD。原清冊54/55來源SHA匹配，缺SRC-L-009。FULL_DOCUMENT_STATIC_PASS不宣稱；獨立Checker/Owner ratification/Release均NOT_RUN。每項下一合法動作與resume predicate在holds.json/E04，缺件只PARK受影scope，合法READY繼續。



## Revision2：實際CLI Raw與96格語義Oracle補強

前版原始封存保留於prior_seal.json；本版不是以891個形狀/靜態檢查宣稱全部domain語義已通過。新實跑原SBL source module 27次，每次--data-dir都在私有work WriteSet，涵蓋POS、duplicate/empty/unknown拒收且state無diff、新PID持久化、兩entrypoint parity、remove回空，以及uninstall保留foreign sentinel。未安裝Host，未操作正式user store、HGK/Hermes或Issuer。

96格新增可執行domain與oracle-specific negative fixtures，現讀回679項作者端檢查PASS、0FAIL；正向格結果為50 PASS_LOCAL_ORACLE＋46 HOLD。HOLD包括原校準/Human或Judge Reader缺件、性能門檻未綁和沒有兩版本升級資格。這些不是96 Native Case PASS；source module/27 process Raw亦不能替代其他Host、W18正式普通Goal或受保護Checker。

完整case-specific JSON與實際輸出在oracle96_semantic_fixtures_v2.json、oracle96_verification_v2.json；source/runtime邊界見BODY-07的R2-07-C39與verification_scope_revision2.md。原Goal/17冊/26 Findings和所有分母維持，不因本輪聚焦F-21而縮減。
