# E03 ABI與Fixture稽核

原PIPD Repo讀回19 native Schema `$id/required/additionalProperties=false`與原SHA；可重跑的payload在native_schema_fixtures.json。內層大量`{}`欄位沒有domain constraint，因此syntax正例不能證明permission/hash/Oracle/Checker身份。BODY-02逐contract補不同Reader invariant，原Writer實機綁定仍ABI_HOLD。

13原verb的help exit0與invalid flag nonzero實測在cli_probes.json；另讀到compile-cc第14個verb，保留ABI_HOLD_CLI_13_14。binaryOrigin是source module Python入口；未宣稱installed CLI或原Registry在現役Host已Loaded。對原四Repo只讀HEAD/status/remote/main；local HEAD均不等main，未fetch/merge/部署。

AC-E01–15的type_tag是AUTHOR Reader投影，非新native `$id`；LeaseCAS與ProtectedVerdict不允互換。Challenge96的STATISTICAL/SEMANTIC_JUDGE/HUMAN缺校準或原決議只HOLD。CaseSpec、Expected Raw與Actual Raw分開；本輪只作者端靜態拒收，未產生Native Raw或受保護簽章。
