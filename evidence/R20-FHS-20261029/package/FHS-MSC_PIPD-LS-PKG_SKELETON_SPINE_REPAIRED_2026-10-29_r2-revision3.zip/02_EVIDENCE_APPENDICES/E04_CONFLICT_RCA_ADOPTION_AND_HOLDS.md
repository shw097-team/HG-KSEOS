# E04 衝突、Repo現況與受影HOLD

| class | affected scope | owner | next legal action | resume predicate |
|---|---|---|---|---|
| SOURCE | SRC-L-009 v1產出指令 | 原設計來源Owner | 提供該版本bytes或確認由已指定thin+AUDIT替代本輪repair控制 | exact SHA/heading讀回或明確Owner supersession |
| SOURCE | 149 child inherited context fragment / B1九個UNRESOLVED Node | 原SBL/PIPD Clause Owner | 讀回原Parent/fragment/Node來源並ratify相容mapping | 原source/Owner決議可讀，不靠候選自簽 |
| ABI | 13原verb vs 當期14 parser | PIPD CLI Owner | 判定compile-cc版本相容/alias及13原verb承諾 | 具版本/原Owner決議/roundtrip正反 |
| ABI | 19 Schema內層{}與native EffectClass value set未ratify | PIPD Registry/ECP Owner | 將domain semantic Reader與原Registry兼容綁定；enum由原Owner裁定 | 原Writer semantic fixture及ACK，非schema-only PASS |
| ABI | DOC07 ↔ legacy DOC03、12risk→9context | 原PIPD Oracle/Profile Owner | 提供loss ledger/alias migration與roundtrip | 原Writer ACK與原語義/否定scope保全 |
| ABI | 192 legacy ON/OFF label與ProviderOff含義矛盾 | SBL Product＋各Host Owner | 確認原raw token到boolean映射；重測provider禁止外呼 | Owner映射+本Host POS/NEG |
| HOST | Fabric Active/Loaded/Consumer、HGK Issuer/Wake/Lease/NormalMode | 原Fabric/HGK/Hermes/Host Owner | 唯讀當期原Registry/module origin/loaded SHA，再依原OPS准入最小needed子圖 | 當期同Subject/Scope/Epoch原Consumer ACK/真Raw |
| HOST | Default30/Donor24/Method25/TECH386 upstream pin/license/適用Host | 原Tech/License/Host Owner | 依每ID BuildOrUseRecipe補pin/license/manifest/help，純方法不造installer | 該ID原Need/Owner/Host binding，NOT_OBSERVED不冒ABSENT |
| HOST | B1 282 RunnerBindings | 每case原Runner/Oracle Owner | 原Registry以case_id/source/Host解析signature與raw schema | 同case/候選/Host的真Runner Raw |
| CHECKER | 不同受保護principal | 原Checker Owner | 原protected Reader核identity及Raw/oracle，真實執行 | 原Checker本輪簽章receipt；Maker/模型角色不可替 |
| RELEASE | 正式Publisher/GHP-02 | 原Publisher | 只在原發行授權成立後發布與readback | 正式signature/channel/readback；本輪只有本機文件交付 |

## 四Repo與main只讀比較

| Repo | local HEAD | status entries | GitHub main HEAD | interpretation |
|---|---|---|---|---|
| HG-KSEOS | 47e10b48c9c36fc90165e79719653678b82e599d | 493 | f6dfb1e57162dc3868dc488482d249fc095eb429 | HEAD≠main；Repo可讀≠Live Loaded |
| SBL | 826ca066a1c2df2976c0d402018b79e1c79a444f | 58836 | fd62537a7ba29c3f2905fe42ddde9534674405d7 | HEAD≠main；Repo可讀≠Live Loaded |
| Fabric | fffcb98bf8063e04f3fad2c726eb43fd70336d04 | 54 | 316b691460638bdf38475c2c58aaad406aa6eb4f | HEAD≠main；Repo可讀≠Live Loaded |
| PIPD | 995c7ad0c69a05a0c5cf6528155a62020ce31f87 | 25584 | f6335a94157c61da75d92121d14c43feb413e981 | HEAD≠main；Repo可讀≠Live Loaded |

未改原Repo/source/history/Policy/Queue/Issuer/Checker/Publisher。untracked/dirty狀態由原工作樹持有；原raw status只保留本輪work，不把58k untracked的內容或狀態當本次生成。其他合法READY不受上表全部HOLD牽連。

## 當期Native源碼新增的界面差額

resolve_acceptance的原docstring明示registered evidence不保證subject-bound。原Evidence/Checker Owner需補兼容binding與foreign-evidence NEG，未完成前AC-E09/12/13受影HOLD；不得以作者guard冒稱現役Native已能拒收。Spine源碼真state enum與候選READY/UNKNOWN/generation/Wake不能默等價，詳BODY-06/07及native_interfaces.json。
