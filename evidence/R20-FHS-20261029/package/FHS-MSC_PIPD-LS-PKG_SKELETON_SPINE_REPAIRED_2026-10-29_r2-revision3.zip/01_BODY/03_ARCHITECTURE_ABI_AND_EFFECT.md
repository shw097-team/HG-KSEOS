---
artifact_id: FHS-MSC-R2-BODY-03
formal_name: Architecture ABI、正交效果與受影拒收
short_name: BODY-03
version: 2026-10-29-r2-revision2
source_set_hash_or_pending: f86b217ae3c3ee28183570f4bf3d4f08d4d00e9b86d1de1a641a630f8682d1a1
intended_consumer: 原領域 Owner 與下游 Reader
owner_role: 作者端規格修補者；原 Domain Writer 不移轉
design_status: SOURCE_BOUND_REPAIR_CANDIDATE
claim_ceiling: AUTHOR_STATIC_ONLY; NATIVE_NOT_RUN; CHECKER_NOT_RUN; RELEASE_NOT_RUN
supersession_scope: 本輪作者候選revision2；保留前版封存；不取代任何原Canonical Writer版本
AUDIT_F_IDs:
- F-01
- F-02
- F-03
- F-08
- F-26
---

# Architecture ABI、正交效果與受影拒收

## R2-03-EFFECT：效果與退出按類處理

| EffectClass | tier | permission_basis | Done | rollback/compensation/residue |
|---|---|---|---|---|
| SOURCE_READ | L1 | 原唯讀 ACL/read scope | 讀取 hash/時間/來源及讀取錯誤；world diff=0 | 丟棄快照重讀；不要求 Permit 或卸載收據 |
| LOCAL_DRAFT_WRITE | L0 | 明列隔離 output root 的使用者授權 | 新檔 UTF8/LF/hash/readback；原來源 hash 不變 | 回復本輪 preimage 或刪本輪新檔；不刪他人產物 |
| REPO_WRITE | L2 | DEV ECP + exact WriteSet + 原 HGK admission | pre/post HEAD/diff/test/raw/受影 residue | 原 preimage inverse patch；HEAD 漂移先停，不能 reset 他人變更 |
| HOST_OP | L3 | OPS ECP + Host Owner/Issuer + nonce/TTL/epoch | 真 Host LoadedSHA/consumer ACK/卸載或復原 readback | 原 Host restore/unload；UNKNOWN 先 reconcile，殘留列表交 Owner |
| USER_OP | L3 | USER ECP + 本使用者資料 scope | user store pre/post digest + 新 PID 讀回 | 受權逆操作或補償資料；保留 operation journal |
| REMOTE_WRITE | L3 | REMOTE ECP + 原遠端 principal scope | 遠端 object id/version/ACK/readback | 原服務 inverse 或補償；已被讀取的資料標 residue |
| RELEASE | L4 | 原 Publisher/GHP-02 + 受保護 Checker | release id/signature/實際 channel readback | 由原 Publisher 撤回或新版更正；歷史收據不可抹除 |

`NONE` 只做記憶體計算；無 Permission/Receipt 欄時標 NA(no effect)，不能強迫捏造 token。LOCAL_DRAFT_WRITE 可以是 L0 隔離產物；Repo/product build 若有源碼/工具變更必為 L2。SWOF_W2_SHADOW_NO_WRITE 只有 SOURCE_READ，build 必另開 PRODUCT_BUILD_LOCAL subject，不能共用 Shadow grant。

## R2-03-ABI：五個 typed handoff

1. Source/Intent/Profile → PI：原 Intake/Source/Profile Writer 供應 source digest、atoms、profile；PI Writer 消費 strict schema。副檔存十二軸風險與原 27/149 映射；禁止注入 `_profile_meta`。DOC07 ↔ legacy DOC03、12→9 未 Owner 綁定時只此 promotion HOLD。
2. PI → PD：原 Binder 以真 root/HEAD/index/untracked/ACL/reparse 產 RepoContext；PI 語義不能隨 Host 改寫。HEAD 變動 → `PD_BIND_STALE`；重新讀回，不擴 WriteSet。
3. PD → ConstructionContract + DEV ECP：exact repo files/preimage、expected_changes、tests、rollback 分開交原 Construction/ECP Writer。ECP payload 不等於 HGK Permit。
4. PD → OPS ECP：Host/User/Remote/Release 必拆不同 scope 與 receiver；nonce/TTL/epoch/principal 由真 Issuer 綁。DEV credential 送 Host install → `WRONG_EFFECT_GRANT`。
5. PlannedTQAEP → Checker request：receipt-free 計畫只列 case/oracle/fixtures；原受保護 Reader 解析 Raw、確認不同 principal 才可簽 verdict。Maker 的 expected/fixture 不得轉成 actual raw。

本輪已讀的 native Schema、required、strict unknown 欄拒收與 CLI 實測在 [BODY-02](02_PIPD_LIFECYCLE_AND_TPM.md)。這些是 Repo schema readback，不是 Windows LoadedRegistry ACK。外層 source trace sidecar 只與 payload hash 關聯，不塞進原 strict payload。

## R2-03-SUBJECT：跨域訊息關聯

設計 sidecar 必具 subject_id/source_manifest_sha/candidate_sha/producer/consumer/schema_ref/payload_sha/effect_class/observed_at。接收端先驗 hash/currentness/schema，再驗 authority，最後做 domain predicate；順序錯誤不得靠 generic ACK 補救。ACK 應含 consumer identity、原 schema version、接收 payload hash；NACK 應含 first_fail/affected_scope/next_legal_action/resume_predicate。這是 Reader 設計，非新 native `$id`。

POS：AC-E07 Lease object 只交 SharedSpine CAS；AC-E12 只收 checker run request / protected receipt。NEG：Lease object 交 verdict reader → `NACK_WRONG_DOMAIN_SCHEMA`。Owner 缺 Registry 時此邊 ABI_BIND_HOLD，其他已綁 Reader 可進行。失敗撤本輪 adapter candidate；對 UNKNOWN native effect 只 reconcile，不擦 Journal。

## 歷史來源標籤PD06的讀取

原草案03的PD06保留為PIPD章節locator別名，不是新schema或獨立gate；Reader必由PIPD來源冊的exact path/SHA/heading解析，不把PD06與本包PD-06 Slot混同。若相同字串對應多條來源，回ALIAS_AMBIGUOUS並要求該引用附完整namespace。
