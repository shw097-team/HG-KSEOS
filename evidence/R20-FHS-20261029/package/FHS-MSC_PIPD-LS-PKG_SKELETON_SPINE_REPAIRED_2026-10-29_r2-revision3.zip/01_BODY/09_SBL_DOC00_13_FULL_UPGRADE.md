---
artifact_id: FHS-MSC-R2-BODY-09
formal_name: SBL DOC00–13 與149 Child完整業務升級
short_name: BODY-09
version: 2026-10-29-r2-revision2
source_set_hash_or_pending: f86b217ae3c3ee28183570f4bf3d4f08d4d00e9b86d1de1a641a630f8682d1a1
intended_consumer: 原領域 Owner 與下游 Reader
owner_role: 作者端規格修補者；原 Domain Writer 不移轉
design_status: SOURCE_BOUND_REPAIR_CANDIDATE
claim_ceiling: AUTHOR_STATIC_ONLY; NATIVE_NOT_RUN; CHECKER_NOT_RUN; RELEASE_NOT_RUN
supersession_scope: 本輪作者候選revision2；保留前版封存；不取代任何原Canonical Writer版本
AUDIT_F_IDs:
- F-05
- F-06
---

# SBL DOC00–13 與149 Child完整業務升級

## R2-09-CHILD：149 個 contextual child 的業務 Oracle

短fragment保留原字串，不假造完整新source。每child必在完整Parent否定作用域下讀取；以下POS是可見行為，NEG是反例，不能僅因ChildOutcome欄位存在PASS。所有Child須同subject/source/candidate；資料欄位檢查只是先決。原Owner對fragment解釋尚未ratify的SOURCE_CONTEXT_FRAGMENT_OWNER_HOLD維持，文件可給出候選業務predicate但不冒正式RequirementAtom。

Trigger：SBL相應產品功能被要求時；producer是原產品/Host/Native實作，consumer是該Child的原Owner/TQAEP Reader。輸入來源/goal或Host raw→執行下列特定行為→輸出本child Outcome+actual raw ref；effect按該功能分類，PI/PD/OPS/DEV與受保護Checker界線見BODY-02/03。NO_EFFECT的Reader不要求不存在的Permit。

Parent合格必要求全部適用child各自的Oracle；相同短fragment如Profile在U41與U42有不同authority，不能共用收據。失敗只PARK本child受影錐；退出由原Owner依EffectClass回退，原source與既有合法工作保留；resume需同scope新Raw/版本currentness。
### U01.1｜SBL 是獨立品牌

- Parent原句：SBL 是獨立品牌，名稱不與 SWOF GENIE Lifecycle 混同
- Source：SRC-L-041:L834；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3676@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：SBL_PRODUCT_OWNER / DOC-01。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `產品顯示品牌為SBL` → DomainOutcome(child=U01.1,predicate,actual_raw_sha,result,first_fail)。
- POS：產品顯示品牌為SBL；NEG：顯示為SWOF → DOMAIN_U01_1_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U01.2｜名稱不

- Parent原句：SBL 是獨立品牌，名稱不與 SWOF GENIE Lifecycle 混同
- Source：SRC-L-041:L835；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3677@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：SBL_PRODUCT_OWNER / DOC-01。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `名稱解析SBL與SWOF為不同identity` → DomainOutcome(child=U01.2,predicate,actual_raw_sha,result,first_fail)。
- POS：名稱解析SBL與SWOF為不同identity；NEG：SBL名稱alias指向SWOF → DOMAIN_U01_2_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U01.3｜SWOF GENIE Lifecycle 混同 (L5504)

- Parent原句：SBL 是獨立品牌，名稱不與 SWOF GENIE Lifecycle 混同
- Source：SRC-L-041:L836；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3678@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：SBL_PRODUCT_OWNER / DOC-01。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `GENIE Lifecycle權威不由SBL接管` → DomainOutcome(child=U01.3,predicate,actual_raw_sha,result,first_fail)。
- POS：GENIE Lifecycle權威不由SBL接管；NEG：SBL成GENIE canonical writer → DOMAIN_U01_3_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U02.1｜SBL 有 TPM-SP

- Parent原句：SBL 有 TPM-SP、Commander-SP、External Challenge-SP 三個獨立 SP
- Source：SRC-L-041:L837；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3679@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：SBL_ARCHITECT_OWNER / DOC-01。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `TPM有獨立入口與邊界` → DomainOutcome(child=U02.1,predicate,actual_raw_sha,result,first_fail)。
- POS：TPM有獨立入口與邊界；NEG：TPM併入Commander credential → DOMAIN_U02_1_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U02.2｜Commander-SP

- Parent原句：SBL 有 TPM-SP、Commander-SP、External Challenge-SP 三個獨立 SP
- Source：SRC-L-041:L838；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3680@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：SBL_ARCHITECT_OWNER / DOC-01。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `Commander獨立只讀會話` → DomainOutcome(child=U02.2,predicate,actual_raw_sha,result,first_fail)。
- POS：Commander獨立只讀會話；NEG：Commander寫Target Repo → DOMAIN_U02_2_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U02.3｜External Challenge-SP 三個獨立 SP (L5505)

- Parent原句：SBL 有 TPM-SP、Commander-SP、External Challenge-SP 三個獨立 SP
- Source：SRC-L-041:L839；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3681@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：SBL_ARCHITECT_OWNER / DOC-01。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `Challenge獨立frozen readset會話` → DomainOutcome(child=U02.3,predicate,actual_raw_sha,result,first_fail)。
- POS：Challenge獨立frozen readset會話；NEG：Maker同會話自審 → DOMAIN_U02_3_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U03.1｜Web GPT 三 SP 各自可真正安裝

- Parent原句：Web GPT 三 SP 各自可真正安裝、掛載、調用
- Source：SRC-L-041:L840；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3682@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：SBL_ARCHITECT_OWNER / DOC-01。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `TPM/Commander/Challenge各有本Host安裝Raw` → DomainOutcome(child=U03.1,predicate,actual_raw_sha,result,first_fail)。
- POS：TPM/Commander/Challenge各有本Host安裝Raw；NEG：只安裝TPM → DOMAIN_U03_1_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U03.2｜掛載

- Parent原句：Web GPT 三 SP 各自可真正安裝、掛載、調用
- Source：SRC-L-041:L841；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3683@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：SBL_ARCHITECT_OWNER / DOC-01。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `三SP各有fresh-session loaded SHA` → DomainOutcome(child=U03.2,predicate,actual_raw_sha,result,first_fail)。
- POS：三SP各有fresh-session loaded SHA；NEG：磁碟存在當loaded → DOMAIN_U03_2_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U03.3｜調用 (L5506)

- Parent原句：Web GPT 三 SP 各自可真正安裝、掛載、調用
- Source：SRC-L-041:L842；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3684@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：SBL_ARCHITECT_OWNER / DOC-01。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `三SP各有trigger/nontrigger/卸載後不觸發Raw` → DomainOutcome(child=U03.3,predicate,actual_raw_sha,result,first_fail)。
- POS：三SP各有trigger/nontrigger/卸載後不觸發Raw；NEG：借一SP invocation給其餘 → DOMAIN_U03_3_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U04.1｜TPM-SP 保留 PIPD-LS-SP 原標準和 Repo

- Parent原句：TPM-SP 保留 PIPD-LS-SP 原標準和 Repo，並可讓原用戶單獨使用
- Source：SRC-L-041:L843；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3685@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：TPM_PRODUCT_PIPD_OWNER / DOC-01。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `PIPD原Repo/標準與Writer持續可讀` → DomainOutcome(child=U04.1,predicate,actual_raw_sha,result,first_fail)。
- POS：PIPD原Repo/標準與Writer持續可讀；NEG：重建第二PIPD Compiler → DOMAIN_U04_1_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U04.2｜並可讓原用戶單獨使用 (L5507)

- Parent原句：TPM-SP 保留 PIPD-LS-SP 原標準和 Repo，並可讓原用戶單獨使用
- Source：SRC-L-041:L844；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3686@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：TPM_PRODUCT_PIPD_OWNER / DOC-01。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `原PIPD用戶不用SBL wrapper仍能獨立使用` → DomainOutcome(child=U04.2,predicate,actual_raw_sha,result,first_fail)。
- POS：原PIPD用戶不用SBL wrapper仍能獨立使用；NEG：強制先裝SBL Stack → DOMAIN_U04_2_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U05.1｜TPM-SP Product Manager 釐清 JTBD

- Parent原句：TPM-SP Product Manager 釐清 JTBD、FUO、MVP／Non-goals
- Source：SRC-L-041:L845；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3687@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：TPM_PRODUCT_PIPD_OWNER / DOC-01。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `JTBD連結persona/pain與可見工作結果` → DomainOutcome(child=U05.1,predicate,actual_raw_sha,result,first_fail)。
- POS：JTBD連結persona/pain與可見工作結果；NEG：把工具清單當JTBD → DOMAIN_U05_1_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U05.2｜FUO

- Parent原句：TPM-SP Product Manager 釐清 JTBD、FUO、MVP／Non-goals
- Source：SRC-L-041:L846；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3688@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：TPM_PRODUCT_PIPD_OWNER / DOC-01。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `FUO為使用者可取用成果且有ACC` → DomainOutcome(child=U05.2,predicate,actual_raw_sha,result,first_fail)。
- POS：FUO為使用者可取用成果且有ACC；NEG：只有文件計數 → DOMAIN_U05_2_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U05.3｜MVP

- Parent原句：TPM-SP Product Manager 釐清 JTBD、FUO、MVP／Non-goals
- Source：SRC-L-041:L847；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3689@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：TPM_PRODUCT_PIPD_OWNER / DOC-01。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `MVP邊界列必要功能與驗收` → DomainOutcome(child=U05.3,predicate,actual_raw_sha,result,first_fail)。
- POS：MVP邊界列必要功能與驗收；NEG：把Full Product全項灌入首切片 → DOMAIN_U05_3_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U05.4｜Non-goals (L5508)

- Parent原句：TPM-SP Product Manager 釐清 JTBD、FUO、MVP／Non-goals
- Source：SRC-L-041:L848；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3690@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：TPM_PRODUCT_PIPD_OWNER / DOC-01。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `non-goals可拒超範圍請求` → DomainOutcome(child=U05.4,predicate,actual_raw_sha,result,first_fail)。
- POS：non-goals可拒超範圍請求；NEG：non-goal被默當必做 → DOMAIN_U05_4_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U06.1｜TPM-SP Systems Engineer 建模 Domain

- Parent原句：TPM-SP Systems Engineer 建模 Domain、NFR、Architecture、ADR
- Source：SRC-L-041:L849；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3691@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：TPM_PRODUCT_PIPD_OWNER / DOC-01。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `Domain模型有實體/關係/所有權` → DomainOutcome(child=U06.1,predicate,actual_raw_sha,result,first_fail)。
- POS：Domain模型有實體/關係/所有權；NEG：多Owner同寫同物件 → DOMAIN_U06_1_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U06.2｜NFR

- Parent原句：TPM-SP Systems Engineer 建模 Domain、NFR、Architecture、ADR
- Source：SRC-L-041:L850；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3692@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：TPM_PRODUCT_PIPD_OWNER / DOC-01。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `NFR有來源條款與測量方式` → DomainOutcome(child=U06.2,predicate,actual_raw_sha,result,first_fail)。
- POS：NFR有來源條款與測量方式；NEG：未校準數值冒SLA → DOMAIN_U06_2_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U06.3｜Architecture

- Parent原句：TPM-SP Systems Engineer 建模 Domain、NFR、Architecture、ADR
- Source：SRC-L-041:L851；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3693@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：TPM_PRODUCT_PIPD_OWNER / DOC-01。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `Architecture seam有producer/consumer/effect` → DomainOutcome(child=U06.3,predicate,actual_raw_sha,result,first_fail)。
- POS：Architecture seam有producer/consumer/effect；NEG：只有架構圖無reader → DOMAIN_U06_3_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U06.4｜ADR (L5509)

- Parent原句：TPM-SP Systems Engineer 建模 Domain、NFR、Architecture、ADR
- Source：SRC-L-041:L852；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3694@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：TPM_PRODUCT_PIPD_OWNER / DOC-01。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `ADR保留選項/理由/被拒替代` → DomainOutcome(child=U06.4,predicate,actual_raw_sha,result,first_fail)。
- POS：ADR保留選項/理由/被拒替代；NEG：先選型後補造決議 → DOMAIN_U06_4_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U07.1｜TPM-SP Technical Program Manager 建任務 DAG

- Parent原句：TPM-SP Technical Program Manager 建任務 DAG、里程碑、風險、交接
- Source：SRC-L-041:L853；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3695@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：TPM_PRODUCT_PIPD_OWNER / DOC-01。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `DAG拓樸可排序且無環` → DomainOutcome(child=U07.1,predicate,actual_raw_sha,result,first_fail)。
- POS：DAG拓樸可排序且無環；NEG：注入06到17反向依賴 → DOMAIN_U07_1_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U07.2｜里程碑

- Parent原句：TPM-SP Technical Program Manager 建任務 DAG、里程碑、風險、交接
- Source：SRC-L-041:L854；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3696@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：TPM_PRODUCT_PIPD_OWNER / DOC-01。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `里程碑有可見輸出與依賴` → DomainOutcome(child=U07.2,predicate,actual_raw_sha,result,first_fail)。
- POS：里程碑有可見輸出與依賴；NEG：只列日期無交付物 → DOMAIN_U07_2_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U07.3｜風險

- Parent原句：TPM-SP Technical Program Manager 建任務 DAG、里程碑、風險、交接
- Source：SRC-L-041:L855；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3697@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：TPM_PRODUCT_PIPD_OWNER / DOC-01。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `風險含trigger/owner/回復` → DomainOutcome(child=U07.3,predicate,actual_raw_sha,result,first_fail)。
- POS：風險含trigger/owner/回復；NEG：高風險無責任Owner → DOMAIN_U07_3_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U07.4｜交接 (L5510)

- Parent原句：TPM-SP Technical Program Manager 建任務 DAG、里程碑、風險、交接
- Source：SRC-L-041:L856；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3698@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：TPM_PRODUCT_PIPD_OWNER / DOC-01。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `handoff有exact subject/hash/next action` → DomainOutcome(child=U07.4,predicate,actual_raw_sha,result,first_fail)。
- POS：handoff有exact subject/hash/next action；NEG：只交長Prompt無來源 → DOMAIN_U07_4_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U08.1｜TPM-SP Quick

- Parent原句：TPM-SP Quick/Guided/Critical 依難度動態問答
- Source：SRC-L-041:L857；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3699@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：TPM_PRODUCT_PIPD_OWNER / DOC-01。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `Quick重用已知答覆直接形成候選` → DomainOutcome(child=U08.1,predicate,actual_raw_sha,result,first_fail)。
- POS：Quick重用已知答覆直接形成候選；NEG：重問已知Goal → DOMAIN_U08_1_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U08.2｜Guided

- Parent原句：TPM-SP Quick/Guided/Critical 依難度動態問答
- Source：SRC-L-041:L858；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3700@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：TPM_PRODUCT_PIPD_OWNER / DOC-01。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `Guided只問會改FUO的缺項` → DomainOutcome(child=U08.2,predicate,actual_raw_sha,result,first_fail)。
- POS：Guided只問會改FUO的缺項；NEG：要求重上傳內建DOC → DOMAIN_U08_2_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U08.3｜Critical 依難度動態問答 (L5511)

- Parent原句：TPM-SP Quick/Guided/Critical 依難度動態問答
- Source：SRC-L-041:L859；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3701@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：TPM_PRODUCT_PIPD_OWNER / DOC-01。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `Critical對未知效果與Owner衝突升級` → DomainOutcome(child=U08.3,predicate,actual_raw_sha,result,first_fail)。
- POS：Critical對未知效果與Owner衝突升級；NEG：把高風險降到Quick → DOMAIN_U08_3_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U09.1｜TPM 使用 BMAD 引導和主動 Help

- Parent原句：TPM 使用 BMAD 引導和主動 Help／教練式探索
- Source：SRC-L-041:L860；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3702@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：TPM_PRODUCT_PIPD_OWNER / DOC-01。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `Help根據目前缺口給具體下一步` → DomainOutcome(child=U09.1,predicate,actual_raw_sha,result,first_fail)。
- POS：Help根據目前缺口給具體下一步；NEG：固定每輪重貼全部治理 → DOMAIN_U09_1_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U09.2｜教練式探索 (L5512)

- Parent原句：TPM 使用 BMAD 引導和主動 Help／教練式探索
- Source：SRC-L-041:L861；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3703@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：TPM_PRODUCT_PIPD_OWNER / DOC-01。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `教練式探索把假設與事實分開` → DomainOutcome(child=U09.2,predicate,actual_raw_sha,result,first_fail)。
- POS：教練式探索把假設與事實分開；NEG：用猜測填Owner決議 → DOMAIN_U09_2_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U10.1｜TPM 使用 Matt Grilling

- Parent原句：TPM 使用 Matt Grilling/Domain Modeling/Spec/Tickets 分工
- Source：SRC-L-041:L862；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3704@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：TPM_PRODUCT_PIPD_OWNER / DOC-01。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `Matt方法以已知資料跳過重問` → DomainOutcome(child=U10.1,predicate,actual_raw_sha,result,first_fail)。
- POS：Matt方法以已知資料跳過重問；NEG：把方法字串當已調用 → DOMAIN_U10_1_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U10.2｜Domain Modeling

- Parent原句：TPM 使用 Matt Grilling/Domain Modeling/Spec/Tickets 分工
- Source：SRC-L-041:L863；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3705@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：TPM_PRODUCT_PIPD_OWNER / DOC-01。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `Domain Modeling產領域界線` → DomainOutcome(child=U10.2,predicate,actual_raw_sha,result,first_fail)。
- POS：Domain Modeling產領域界線；NEG：混合Product與Runtime Writer → DOMAIN_U10_2_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U10.3｜Spec

- Parent原句：TPM 使用 Matt Grilling/Domain Modeling/Spec/Tickets 分工
- Source：SRC-L-041:L864；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3706@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：TPM_PRODUCT_PIPD_OWNER / DOC-01。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `Spec有ACC/NEG與來源` → DomainOutcome(child=U10.3,predicate,actual_raw_sha,result,first_fail)。
- POS：Spec有ACC/NEG與來源；NEG：只有需求標題 → DOMAIN_U10_3_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U10.4｜Tickets 分工 (L5513)

- Parent原句：TPM 使用 Matt Grilling/Domain Modeling/Spec/Tickets 分工
- Source：SRC-L-041:L865；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3707@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：TPM_PRODUCT_PIPD_OWNER / DOC-01。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `Ticket連結DAG/Owner/DoD` → DomainOutcome(child=U10.4,predicate,actual_raw_sha,result,first_fail)。
- POS：Ticket連結DAG/Owner/DoD；NEG：無Consumer任務進READY → DOMAIN_U10_4_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U11.1｜TPM 保留來源

- Parent原句：TPM 保留來源／Assumptions／Decision Ledger
- Source：SRC-L-041:L866；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3708@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：TPM_PRODUCT_PIPD_OWNER / DOC-01。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `每規範claim回到原source SHA/line` → DomainOutcome(child=U11.1,predicate,actual_raw_sha,result,first_fail)。
- POS：每規範claim回到原source SHA/line；NEG：無來源宣稱canonical → DOMAIN_U11_1_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U11.2｜Assumptions

- Parent原句：TPM 保留來源／Assumptions／Decision Ledger
- Source：SRC-L-041:L867；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3709@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：TPM_PRODUCT_PIPD_OWNER / DOC-01。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `Assumption有待驗狀態與owner` → DomainOutcome(child=U11.2,predicate,actual_raw_sha,result,first_fail)。
- POS：Assumption有待驗狀態與owner；NEG：假設冒原Owner已決 → DOMAIN_U11_2_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U11.3｜Decision Ledger (L5514)

- Parent原句：TPM 保留來源／Assumptions／Decision Ledger
- Source：SRC-L-041:L868；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3710@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：TPM_PRODUCT_PIPD_OWNER / DOC-01。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `Decision保留原處置與變更理由` → DomainOutcome(child=U11.3,predicate,actual_raw_sha,result,first_fail)。
- POS：Decision保留原處置與變更理由；NEG：REJECT被默改SELECTED → DOMAIN_U11_3_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U12.1｜TPM 實際編譯相容 PIPD PI 規格包 (L5515)

- Parent原句：TPM 實際編譯相容 PIPD PI 規格包
- Source：SRC-L-041:L869；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3711@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：TPM_PRODUCT_PIPD_OWNER / DOC-01。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `原PI Writer以strict input編譯並ACK相同語義與trace` → DomainOutcome(child=U12.1,predicate,actual_raw_sha,result,first_fail)。
- POS：原PI Writer以strict input編譯並ACK相同語義與trace；NEG：TPM候選自稱canonical PI → DOMAIN_U12_1_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U13.1｜TPM 實際編譯 PD 環境

- Parent原句：TPM 實際編譯 PD 環境／施工準備包
- Source：SRC-L-041:L870；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3712@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：TPM_PRODUCT_PIPD_OWNER / DOC-01。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `PD Binder從真root/HEAD讀回RepoContext` → DomainOutcome(child=U13.1,predicate,actual_raw_sha,result,first_fail)。
- POS：PD Binder從真root/HEAD讀回RepoContext；NEG：呼叫者自填HEAD當事實 → DOMAIN_U13_1_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U13.2｜施工準備包 (L5516)

- Parent原句：TPM 實際編譯 PD 環境／施工準備包
- Source：SRC-L-041:L871；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3713@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：TPM_PRODUCT_PIPD_OWNER / DOC-01。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `施工準備含scope/preimage/tests/rollback` → DomainOutcome(child=U13.2,predicate,actual_raw_sha,result,first_fail)。
- POS：施工準備含scope/preimage/tests/rollback；NEG：PD候選當permission → DOMAIN_U13_2_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U14.1｜TPM 具名

- Parent原句：TPM 具名對應 OPS ECP、DEV ECP 分別
- Source：SRC-L-041:L872；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3714@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：TPM_PRODUCT_PIPD_OWNER / DOC-01。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `每effect具名指向一個適用ECP` → DomainOutcome(child=U14.1,predicate,actual_raw_sha,result,first_fail)。
- POS：每effect具名指向一個適用ECP；NEG：泛稱ONE ECP而混兩權限 → DOMAIN_U14_1_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U14.2｜OPS ECP

- Parent原句：TPM 具名對應 OPS ECP、DEV ECP 分別
- Source：SRC-L-041:L873；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3715@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：TPM_PRODUCT_PIPD_OWNER / DOC-01。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `Host/User/Remote用各OPS scope與原Issuer` → DomainOutcome(child=U14.2,predicate,actual_raw_sha,result,first_fail)。
- POS：Host/User/Remote用各OPS scope與原Issuer；NEG：DEV grant拿去Host install → DOMAIN_U14_2_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U14.3｜DEV ECP

- Parent原句：TPM 具名對應 OPS ECP、DEV ECP 分別
- Source：SRC-L-041:L874；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3716@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：TPM_PRODUCT_PIPD_OWNER / DOC-01。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `Repo patch只在DEV exact WriteSet` → DomainOutcome(child=U14.3,predicate,actual_raw_sha,result,first_fail)。
- POS：Repo patch只在DEV exact WriteSet；NEG：用OPS grant寫任意Repo → DOMAIN_U14_3_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U14.4｜(L5517)

- Parent原句：TPM 具名對應 OPS ECP、DEV ECP 分別
- Source：SRC-L-041:L875；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3717@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：TPM_PRODUCT_PIPD_OWNER / DOC-01。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `OPS與DEV分開且同subject無失真` → DomainOutcome(child=U14.4,predicate,actual_raw_sha,result,first_fail)。
- POS：OPS與DEV分開且同subject無失真；NEG：省略ECP分流負例 → DOMAIN_U14_4_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U15.1｜TPM 具名 TQAEP 測試

- Parent原句：TPM 具名 TQAEP 測試／驗收／Evidence 包
- Source：SRC-L-041:L876；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3718@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：TPM_PRODUCT_PIPD_OWNER / DOC-01。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `TQAEP每原子有POS/NEG/Oracle` → DomainOutcome(child=U15.1,predicate,actual_raw_sha,result,first_fail)。
- POS：TQAEP每原子有POS/NEG/Oracle；NEG：以全包一次PASS代逐原子 → DOMAIN_U15_1_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U15.2｜驗收

- Parent原句：TPM 具名 TQAEP 測試／驗收／Evidence 包
- Source：SRC-L-041:L877；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3719@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：TPM_PRODUCT_PIPD_OWNER / DOC-01。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `真Checker不同credential執行` → DomainOutcome(child=U15.2,predicate,actual_raw_sha,result,first_fail)。
- POS：真Checker不同credential執行；NEG：Maker自簽PASS → DOMAIN_U15_2_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U15.3｜Evidence 包 (L5518)

- Parent原句：TPM 具名 TQAEP 測試／驗收／Evidence 包
- Source：SRC-L-041:L878；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3720@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：TPM_PRODUCT_PIPD_OWNER / DOC-01。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `Evidence expectation與actual raw分離` → DomainOutcome(child=U15.3,predicate,actual_raw_sha,result,first_fail)。
- POS：Evidence expectation與actual raw分離；NEG：BIND_FROM_NATIVE文字當Raw → DOMAIN_U15_3_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U16.1｜Commander 是獨立會話

- Parent原句：Commander 是獨立會話、不能改 Target Repo
- Source：SRC-L-041:L879；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3721@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：CAPC_COMMANDER_OWNER / DOC-04。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `Commander session與Maker執行會話分開` → DomainOutcome(child=U16.1,predicate,actual_raw_sha,result,first_fail)。
- POS：Commander session與Maker執行會話分開；NEG：同會話冒獨立Commander → DOMAIN_U16_1_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U16.2｜不能改 Target Repo (L5519)

- Parent原句：Commander 是獨立會話、不能改 Target Repo
- Source：SRC-L-041:L880；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3722@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：CAPC_COMMANDER_OWNER / DOC-04。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `Commander讀Target Repo無mutation` → DomainOutcome(child=U16.2,predicate,actual_raw_sha,result,first_fail)。
- POS：Commander讀Target Repo無mutation；NEG：Guide直接apply repo patch → DOMAIN_U16_2_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U17.1｜Commander 完整理解凍結 PI

- Parent原句：Commander 完整理解凍結 PI/PD／ECP／TQAEP
- Source：SRC-L-041:L881；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3723@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：CAPC_COMMANDER_OWNER / DOC-04。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `凍結PI的全原子與hash被Reader核對` → DomainOutcome(child=U17.1,predicate,actual_raw_sha,result,first_fail)。
- POS：凍結PI的全原子與hash被Reader核對；NEG：只讀PI摘要 → DOMAIN_U17_1_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U17.2｜PD

- Parent原句：Commander 完整理解凍結 PI/PD／ECP／TQAEP
- Source：SRC-L-041:L882；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3724@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：CAPC_COMMANDER_OWNER / DOC-04。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `PD currentness與scope實讀` → DomainOutcome(child=U17.2,predicate,actual_raw_sha,result,first_fail)。
- POS：PD currentness與scope實讀；NEG：借舊RepoContext → DOMAIN_U17_2_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U17.3｜ECP

- Parent原句：Commander 完整理解凍結 PI/PD／ECP／TQAEP
- Source：SRC-L-041:L883；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3725@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：CAPC_COMMANDER_OWNER / DOC-04。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `DEV/OPS ECP按effect分路理解` → DomainOutcome(child=U17.3,predicate,actual_raw_sha,result,first_fail)。
- POS：DEV/OPS ECP按effect分路理解；NEG：把ECP等同Permit → DOMAIN_U17_3_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U17.4｜TQAEP (L5520)

- Parent原句：Commander 完整理解凍結 PI/PD／ECP／TQAEP
- Source：SRC-L-041:L884；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3726@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：CAPC_COMMANDER_OWNER / DOC-04。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `TQAEP Oracle/Raw/Checker界線保留` → DomainOutcome(child=U17.4,predicate,actual_raw_sha,result,first_fail)。
- POS：TQAEP Oracle/Raw/Checker界線保留；NEG：expected fixture當actual verdict → DOMAIN_U17_4_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U18.1｜Commander 使用既有 C0–C9 Compiler

- Parent原句：Commander 使用既有 C0–C9 Compiler，非第二 Compiler
- Source：SRC-L-041:L885；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3727@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：CAPC_COMMANDER_OWNER / DOC-04。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `原C0-C9 Compiler路線可識別` → DomainOutcome(child=U18.1,predicate,actual_raw_sha,result,first_fail)。
- POS：原C0-C9 Compiler路線可識別；NEG：Guide自行代編formal包 → DOMAIN_U18_1_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U18.2｜非第二 Compiler (L5521)

- Parent原句：Commander 使用既有 C0–C9 Compiler，非第二 Compiler
- Source：SRC-L-041:L886；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3728@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：CAPC_COMMANDER_OWNER / DOC-04。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `單一Canonical PIPD Writer不變` → DomainOutcome(child=U18.2,predicate,actual_raw_sha,result,first_fail)。
- POS：單一Canonical PIPD Writer不變；NEG：另建並行Compiler → DOMAIN_U18_2_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U19.1｜Commander 產生可貼入本地 Hermes 的「薄 Prompt」 (L5522)

- Parent原句：Commander 產生可貼入本地 Hermes 的「薄 Prompt」
- Source：SRC-L-041:L887；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3729@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：CAPC_COMMANDER_OWNER / DOC-04。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `薄Prompt只帶subject/source/ref與下一合法步驟` → DomainOutcome(child=U19.1,predicate,actual_raw_sha,result,first_fail)。
- POS：薄Prompt只帶subject/source/ref與下一合法步驟；NEG：長Prompt混入自造許可 → DOMAIN_U19_1_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U20.1｜HGK 複查 PD03 RepoContext

- Parent原句：HGK 複查 PD03 RepoContext／PD04 WorkOrder／ONE ECP／ExecutionBinding
- Source：SRC-L-041:L888；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3730@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：HGK_FABRIC_OWNER / DOC-04。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `PD03 root/HEAD/index/untracked重新核對` → DomainOutcome(child=U20.1,predicate,actual_raw_sha,result,first_fail)。
- POS：PD03 root/HEAD/index/untracked重新核對；NEG：只信歷史README → DOMAIN_U20_1_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U20.2｜PD04 WorkOrder

- Parent原句：HGK 複查 PD03 RepoContext／PD04 WorkOrder／ONE ECP／ExecutionBinding
- Source：SRC-L-041:L889；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3731@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：HGK_FABRIC_OWNER / DOC-04。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `PD04 WO在真Receiver得到ACK` → DomainOutcome(child=U20.2,predicate,actual_raw_sha,result,first_fail)。
- POS：PD04 WO在真Receiver得到ACK；NEG：candidate直接enqueue → DOMAIN_U20_2_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U20.3｜ONE ECP

- Parent原句：HGK 複查 PD03 RepoContext／PD04 WorkOrder／ONE ECP／ExecutionBinding
- Source：SRC-L-041:L890；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3732@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：HGK_FABRIC_OWNER / DOC-04。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `每次效果選唯一適用ECP` → DomainOutcome(child=U20.3,predicate,actual_raw_sha,result,first_fail)。
- POS：每次效果選唯一適用ECP；NEG：同effect混DEV和OPS → DOMAIN_U20_3_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U20.4｜ExecutionBinding (L5523)

- Parent原句：HGK 複查 PD03 RepoContext／PD04 WorkOrder／ONE ECP／ExecutionBinding
- Source：SRC-L-041:L891；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3733@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：HGK_FABRIC_OWNER / DOC-04。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `ExecutionBinding同lease/nonce/epoch/scope` → DomainOutcome(child=U20.4,predicate,actual_raw_sha,result,first_fail)。
- POS：ExecutionBinding同lease/nonce/epoch/scope；NEG：借別WorkID binding → DOMAIN_U20_4_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U21.1｜HGK TPM Profile 接收 PIPD並複用既有 Document

- Parent原句：HGK TPM Profile 接收 PIPD並複用既有 Document/Intake 工程能力
- Source：SRC-L-041:L892；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3734@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：HGK_FABRIC_OWNER / DOC-04。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `HGK TPM使用既有Document能力讀PIPD` → DomainOutcome(child=U21.1,predicate,actual_raw_sha,result,first_fail)。
- POS：HGK TPM使用既有Document能力讀PIPD；NEG：新增第二文件canonical store → DOMAIN_U21_1_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U21.2｜Intake 工程能力 (L5524)

- Parent原句：HGK TPM Profile 接收 PIPD並複用既有 Document/Intake 工程能力
- Source：SRC-L-041:L893；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3735@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：HGK_FABRIC_OWNER / DOC-04。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `既有Intake保持source/authority guard` → DomainOutcome(child=U21.2,predicate,actual_raw_sha,result,first_fail)。
- POS：既有Intake保持source/authority guard；NEG：跳Intake直接effect → DOMAIN_U21_2_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U22.1｜HGK Commander Profile 接收 Prompt

- Parent原句：HGK Commander Profile 接收 Prompt/Handoff並控制任務路由
- Source：SRC-L-041:L894；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3736@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：HGK_FABRIC_OWNER / DOC-04。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `HGK Commander讀薄Prompt引用並驗hash` → DomainOutcome(child=U22.1,predicate,actual_raw_sha,result,first_fail)。
- POS：HGK Commander讀薄Prompt引用並驗hash；NEG：把Prompt字串當signed WO → DOMAIN_U22_1_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U22.2｜Handoff並控制任務路由 (L5525)

- Parent原句：HGK Commander Profile 接收 Prompt/Handoff並控制任務路由
- Source：SRC-L-041:L895；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3737@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：HGK_FABRIC_OWNER / DOC-04。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `Handoff走原route/PLAN CAS` → DomainOutcome(child=U22.2,predicate,actual_raw_sha,result,first_fail)。
- POS：Handoff走原route/PLAN CAS；NEG：Guide建立第二queue → DOMAIN_U22_2_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U23.1｜HGK Challenge

- Parent原句：HGK Challenge/AO Profile 接收 Finding＋本地 Local Verification
- Source：SRC-L-041:L896；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3738@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：HGK_FABRIC_OWNER / DOC-04。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `Challenge只產source-bound advisory Finding` → DomainOutcome(child=U23.1,predicate,actual_raw_sha,result,first_fail)。
- POS：Challenge只產source-bound advisory Finding；NEG：Challenge自頒Permit → DOMAIN_U23_1_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U23.2｜AO Profile 接收 Finding＋本地 Local Verification (L5526)

- Parent原句：HGK Challenge/AO Profile 接收 Finding＋本地 Local Verification
- Source：SRC-L-041:L897；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3739@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：HGK_FABRIC_OWNER / DOC-04。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `AO原Receiver讀Finding並由本地真Checker驗` → DomainOutcome(child=U23.2,predicate,actual_raw_sha,result,first_fail)。
- POS：AO原Receiver讀Finding並由本地真Checker驗；NEG：advisory直接升protected PASS → DOMAIN_U23_2_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U24.1｜HGK 呼叫 Fabric 所治理的既有 FAR

- Parent原句：HGK 呼叫 Fabric 所治理的既有 FAR/FDA，非另建
- Source：SRC-L-041:L898；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3740@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：HGK_FABRIC_OWNER / DOC-04。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `FAR走Fabric原治理route與budget` → DomainOutcome(child=U24.1,predicate,actual_raw_sha,result,first_fail)。
- POS：FAR走Fabric原治理route與budget；NEG：啟動未准入第二研究控制器 → DOMAIN_U24_1_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U24.2｜FDA

- Parent原句：HGK 呼叫 Fabric 所治理的既有 FAR/FDA，非另建
- Source：SRC-L-041:L899；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3741@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：HGK_FABRIC_OWNER / DOC-04。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `FDA走原Effect Admission` → DomainOutcome(child=U24.2,predicate,actual_raw_sha,result,first_fail)。
- POS：FDA走原Effect Admission；NEG：GUI動作繞過OPS scope → DOMAIN_U24_2_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U24.3｜非另建 (L5527)

- Parent原句：HGK 呼叫 Fabric 所治理的既有 FAR/FDA，非另建
- Source：SRC-L-041:L900；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3742@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：HGK_FABRIC_OWNER / DOC-04。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `既有FAR/FDA Owner不被adapter取代` → DomainOutcome(child=U24.3,predicate,actual_raw_sha,result,first_fail)。
- POS：既有FAR/FDA Owner不被adapter取代；NEG：供應商SDK冒Issuer → DOMAIN_U24_3_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U25.1｜HGK 合法受限施工

- Parent原句：HGK 合法受限施工、Build、Test、Repair、Checkpoint
- Source：SRC-L-041:L901；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3743@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：HGK_FABRIC_OWNER / DOC-04。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `施工只在受權scope且原Issuer有效` → DomainOutcome(child=U25.1,predicate,actual_raw_sha,result,first_fail)。
- POS：施工只在受權scope且原Issuer有效；NEG：跨root mutation → DOMAIN_U25_1_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U25.2｜Build

- Parent原句：HGK 合法受限施工、Build、Test、Repair、Checkpoint
- Source：SRC-L-041:L902；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3744@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：HGK_FABRIC_OWNER / DOC-04。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `Build保存input/output/exit並在隔離scope` → DomainOutcome(child=U25.2,predicate,actual_raw_sha,result,first_fail)。
- POS：Build保存input/output/exit並在隔離scope；NEG：PREW3只讀域寫wheel → DOMAIN_U25_2_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U25.3｜Test

- Parent原句：HGK 合法受限施工、Build、Test、Repair、Checkpoint
- Source：SRC-L-041:L903；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3745@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：HGK_FABRIC_OWNER / DOC-04。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `Test逐case保存actual Raw` → DomainOutcome(child=U25.3,predicate,actual_raw_sha,result,first_fail)。
- POS：Test逐case保存actual Raw；NEG：只列test ID當執行 → DOMAIN_U25_3_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U25.4｜Repair

- Parent原句：HGK 合法受限施工、Build、Test、Repair、Checkpoint
- Source：SRC-L-041:L904；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3746@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：HGK_FABRIC_OWNER / DOC-04。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `Repair遵first_fail最小錐與原Oracle` → DomainOutcome(child=U25.4,predicate,actual_raw_sha,result,first_fail)。
- POS：Repair遵first_fail最小錐與原Oracle；NEG：改Oracle門檻求綠 → DOMAIN_U25_4_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U25.5｜Checkpoint (L5528)

- Parent原句：HGK 合法受限施工、Build、Test、Repair、Checkpoint
- Source：SRC-L-041:L905；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3747@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：HGK_FABRIC_OWNER / DOC-04。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `Checkpoint包含operation/cursor/residue可resume` → DomainOutcome(child=U25.5,predicate,actual_raw_sha,result,first_fail)。
- POS：Checkpoint包含operation/cursor/residue可resume；NEG：unknown effect刪journal重試 → DOMAIN_U25_5_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U26.1｜施工到 GitHub 的 Source Candidate exact SHA (L5529)

- Parent原句：施工到 GitHub 的 Source Candidate exact SHA
- Source：SRC-L-041:L906；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3748@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：EXTERNAL_ASSURANCE_OWNER / DOC-11。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `遠端Source Candidate exact commit SHA真讀回` → DomainOutcome(child=U26.1,predicate,actual_raw_sha,result,first_fail)。
- POS：遠端Source Candidate exact commit SHA真讀回；NEG：本地工作樹hash冒遠端commit → DOMAIN_U26_1_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U27.1｜Evidence Commit exact SHA 必須

- Parent原句：Evidence Commit exact SHA 必須與 Source SHA 分開
- Source：SRC-L-041:L907；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3749@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：EXTERNAL_ASSURANCE_OWNER / DOC-11。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `Evidence Commit單獨immutable commit SHA` → DomainOutcome(child=U27.1,predicate,actual_raw_sha,result,first_fail)。
- POS：Evidence Commit單獨immutable commit SHA；NEG：把log路徑當commit SHA → DOMAIN_U27_1_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U27.2｜Source SHA 分開 (L5530)

- Parent原句：Evidence Commit exact SHA 必須與 Source SHA 分開
- Source：SRC-L-041:L908；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3750@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：EXTERNAL_ASSURANCE_OWNER / DOC-11。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `Source/Evidence SHA不同物件角色且trace相連` → DomainOutcome(child=U27.2,predicate,actual_raw_sha,result,first_fail)。
- POS：Source/Evidence SHA不同物件角色且trace相連；NEG：將兩SHA互換 → DOMAIN_U27_2_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U28.1｜External Challenge 是另一新對話

- Parent原句：External Challenge 是另一新對話與唯讀 Frozen Readset
- Source：SRC-L-041:L909；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3751@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：EXTERNAL_ASSURANCE_OWNER / DOC-11。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `Challenge新會話對固定candidate/evidence hash` → DomainOutcome(child=U28.1,predicate,actual_raw_sha,result,first_fail)。
- POS：Challenge新會話對固定candidate/evidence hash；NEG：moving branch被當frozen → DOMAIN_U28_1_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U28.2｜唯讀 Frozen Readset (L5531)

- Parent原句：External Challenge 是另一新對話與唯讀 Frozen Readset
- Source：SRC-L-041:L910；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3752@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：EXTERNAL_ASSURANCE_OWNER / DOC-11。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `Frozen Readset只讀且hash重算不變` → DomainOutcome(child=U28.2,predicate,actual_raw_sha,result,first_fail)。
- POS：Frozen Readset只讀且hash重算不變；NEG：Reviewer修改subject後出PASS → DOMAIN_U28_2_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U29.1｜External Challenge 逐條對照 PI

- Parent原句：External Challenge 逐條對照 PI/PD requirements/oracles/evidence
- Source：SRC-L-041:L911；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3753@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：EXTERNAL_ASSURANCE_OWNER / DOC-11。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `逐PI atom與原source對照` → DomainOutcome(child=U29.1,predicate,actual_raw_sha,result,first_fail)。
- POS：逐PI atom與原source對照；NEG：只對總表數量 → DOMAIN_U29_1_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U29.2｜PD requirements

- Parent原句：External Challenge 逐條對照 PI/PD requirements/oracles/evidence
- Source：SRC-L-041:L912；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3754@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：EXTERNAL_ASSURANCE_OWNER / DOC-11。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `逐PD scope/currentness對照` → DomainOutcome(child=U29.2,predicate,actual_raw_sha,result,first_fail)。
- POS：逐PD scope/currentness對照；NEG：過期HEAD照收 → DOMAIN_U29_2_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U29.3｜oracles

- Parent原句：External Challenge 逐條對照 PI/PD requirements/oracles/evidence
- Source：SRC-L-041:L913；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3755@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：EXTERNAL_ASSURANCE_OWNER / DOC-11。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `每Oracle版本與predicate校驗` → DomainOutcome(child=U29.3,predicate,actual_raw_sha,result,first_fail)。
- POS：每Oracle版本與predicate校驗；NEG：以相似Oracle互借 → DOMAIN_U29_3_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U29.4｜evidence (L5532)

- Parent原句：External Challenge 逐條對照 PI/PD requirements/oracles/evidence
- Source：SRC-L-041:L914；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3756@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：EXTERNAL_ASSURANCE_OWNER / DOC-11。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `每raw同candidate可重算且獨立身份` → DomainOutcome(child=U29.4,predicate,actual_raw_sha,result,first_fail)。
- POS：每raw同candidate可重算且獨立身份；NEG：foreign host raw替代 → DOMAIN_U29_4_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U30.1｜Challenge 產出正式相容的 Review Finding

- Parent原句：Challenge 產出正式相容的 Review Finding／報告
- Source：SRC-L-041:L915；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3757@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：EXTERNAL_ASSURANCE_OWNER / DOC-11。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `Finding含command/exit/raw SHA/重現` → DomainOutcome(child=U30.1,predicate,actual_raw_sha,result,first_fail)。
- POS：Finding含command/exit/raw SHA/重現；NEG：未重現猜測當confirmed defect → DOMAIN_U30_1_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U30.2｜報告 (L5533)

- Parent原句：Challenge 產出正式相容的 Review Finding／報告
- Source：SRC-L-041:L916；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3758@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：EXTERNAL_ASSURANCE_OWNER / DOC-11。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `報告列scope/not_covered/claim ceiling` → DomainOutcome(child=U30.2,predicate,actual_raw_sha,result,first_fail)。
- POS：報告列scope/not_covered/claim ceiling；NEG：自封Production PASS → DOMAIN_U30_2_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U31.1｜Commander 接 Evidence

- Parent原句：Commander 接 Evidence + Findings，計算最小修補錐
- Source：SRC-L-041:L917；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3759@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：CAPC_COMMANDER_OWNER / DOC-11。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `Evidence讀raw/hash/owner` → DomainOutcome(child=U31.1,predicate,actual_raw_sha,result,first_fail)。
- POS：Evidence讀raw/hash/owner；NEG：讀摘要代理raw → DOMAIN_U31_1_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U31.2｜Findings

- Parent原句：Commander 接 Evidence + Findings，計算最小修補錐
- Source：SRC-L-041:L918；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3760@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：CAPC_COMMANDER_OWNER / DOC-11。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `Finding帶first_fail和受影consumer` → DomainOutcome(child=U31.2,predicate,actual_raw_sha,result,first_fail)。
- POS：Finding帶first_fail和受影consumer；NEG：無定位就全包重寫 → DOMAIN_U31_2_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U31.3｜計算最小修補錐 (L5534)

- Parent原句：Commander 接 Evidence + Findings，計算最小修補錐
- Source：SRC-L-041:L919；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3761@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：CAPC_COMMANDER_OWNER / DOC-11。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `最小RepairCone只包含受影依賴` → DomainOutcome(child=U31.3,predicate,actual_raw_sha,result,first_fail)。
- POS：最小RepairCone只包含受影依賴；NEG：未受影READY也PARK → DOMAIN_U31_3_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U32.1｜修補生成新 Candidate

- Parent原句：修補生成新 Candidate／Evidence，不覆蓋前版
- Source：SRC-L-041:L920；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3762@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：EVOLUTION_EVIDENCE_OWNER / DOC-11。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `新Candidate明示supersedes且新SHA` → DomainOutcome(child=U32.1,predicate,actual_raw_sha,result,first_fail)。
- POS：新Candidate明示supersedes且新SHA；NEG：直接覆蓋舊candidate → DOMAIN_U32_1_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U32.2｜Evidence

- Parent原句：修補生成新 Candidate／Evidence，不覆蓋前版
- Source：SRC-L-041:L921；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3763@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：EVOLUTION_EVIDENCE_OWNER / DOC-11。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `新Evidence指向新candidate與原test` → DomainOutcome(child=U32.2,predicate,actual_raw_sha,result,first_fail)。
- POS：新Evidence指向新candidate與原test；NEG：借前輪Raw → DOMAIN_U32_2_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U32.3｜不覆蓋前版 (L5535)

- Parent原句：修補生成新 Candidate／Evidence，不覆蓋前版
- Source：SRC-L-041:L922；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3764@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：EVOLUTION_EVIDENCE_OWNER / DOC-11。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `舊版候選與證據保持immutable` → DomainOutcome(child=U32.3,predicate,actual_raw_sha,result,first_fail)。
- POS：舊版候選與證據保持immutable；NEG：清理舊失敗Raw → DOMAIN_U32_3_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U33.1｜外部 Challenge 按高必要性

- Parent原句：外部 Challenge 按高必要性／低 CP 值建議停止
- Source：SRC-L-041:L923；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3765@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：EXTERNAL_ASSURANCE_OWNER / DOC-11。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `高必要性缺陷仍有明確修補需求` → DomainOutcome(child=U33.1,predicate,actual_raw_sha,result,first_fail)。
- POS：高必要性缺陷仍有明確修補需求；NEG：忽略P0因成本高 → DOMAIN_U33_1_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U33.2｜低 CP 值建議停止 (L5536)

- Parent原句：外部 Challenge 按高必要性／低 CP 值建議停止
- Source：SRC-L-041:L924；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3766@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：EXTERNAL_ASSURANCE_OWNER / DOC-11。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `低CP延伸由原Owner決定停損` → DomainOutcome(child=U33.2,predicate,actual_raw_sha,result,first_fail)。
- POS：低CP延伸由原Owner決定停損；NEG：Reviewer自行擴大無界研究 → DOMAIN_U33_2_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U34.1｜正式 Owner

- Parent原句：正式 Owner/Human 決定結案，不由 Challenge 自許可
- Source：SRC-L-041:L925；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3767@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：EXTERNAL_ASSURANCE_OWNER / DOC-11。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `正式Owner讀證據後裁定該scope` → DomainOutcome(child=U34.1,predicate,actual_raw_sha,result,first_fail)。
- POS：正式Owner讀證據後裁定該scope；NEG：Maker替Owner批准 → DOMAIN_U34_1_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U34.2｜Human 決定結案

- Parent原句：正式 Owner/Human 決定結案，不由 Challenge 自許可
- Source：SRC-L-041:L926；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3768@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：EXTERNAL_ASSURANCE_OWNER / DOC-11。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `Human有可review的具體結果再決定` → DomainOutcome(child=U34.2,predicate,actual_raw_sha,result,first_fail)。
- POS：Human有可review的具體結果再決定；NEG：只給Plan要Human簽 → DOMAIN_U34_2_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U34.3｜不由 Challenge 自許可 (L5537)

- Parent原句：正式 Owner/Human 決定結案，不由 Challenge 自許可
- Source：SRC-L-041:L927；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3769@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：EXTERNAL_ASSURANCE_OWNER / DOC-11。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `Challenge建議不能自行許可` → DomainOutcome(child=U34.3,predicate,actual_raw_sha,result,first_fail)。
- POS：Challenge建議不能自行許可；NEG：advisory轉signed verdict → DOMAIN_U34_3_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U35.1｜內部 Loop A Fast Repair

- Parent原句：內部 Loop A Fast Repair、Loop B Local Closure、Loop C External Challenge
- Source：SRC-L-041:L928；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3770@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：HGK_FABRIC_OWNER / DOC-11。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `Loop A bounded快修保存RedGreen` → DomainOutcome(child=U35.1,predicate,actual_raw_sha,result,first_fail)。
- POS：Loop A bounded快修保存RedGreen；NEG：未repro直接廣改 → DOMAIN_U35_1_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U35.2｜Loop B Local Closure

- Parent原句：內部 Loop A Fast Repair、Loop B Local Closure、Loop C External Challenge
- Source：SRC-L-041:L929；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3771@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：HGK_FABRIC_OWNER / DOC-11。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `Loop B原本地Checker獨立閉合` → DomainOutcome(child=U35.2,predicate,actual_raw_sha,result,first_fail)。
- POS：Loop B原本地Checker獨立閉合；NEG：同Maker自證 → DOMAIN_U35_2_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U35.3｜Loop C External Challenge (L5538)

- Parent原句：內部 Loop A Fast Repair、Loop B Local Closure、Loop C External Challenge
- Source：SRC-L-041:L930；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3772@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：HGK_FABRIC_OWNER / DOC-11。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `Loop C新會話frozen挑戰` → DomainOutcome(child=U35.3,predicate,actual_raw_sha,result,first_fail)。
- POS：Loop C新會話frozen挑戰；NEG：沿用Maker session冒獨立 → DOMAIN_U35_3_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U36.1｜有界 self-research

- Parent原句：有界 self-research/review/repair/retest/iteration/evolution
- Source：SRC-L-041:L931；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3773@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：EVOLUTION_EVIDENCE_OWNER / DOC-11。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `research有need/source/time/attempt budget` → DomainOutcome(child=U36.1,predicate,actual_raw_sha,result,first_fail)。
- POS：research有need/source/time/attempt budget；NEG：無界爬資料 → DOMAIN_U36_1_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U36.2｜review

- Parent原句：有界 self-research/review/repair/retest/iteration/evolution
- Source：SRC-L-041:L932；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3774@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：EVOLUTION_EVIDENCE_OWNER / DOC-11。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `review讀固定SHA並留finding` → DomainOutcome(child=U36.2,predicate,actual_raw_sha,result,first_fail)。
- POS：review讀固定SHA並留finding；NEG：review中改subject → DOMAIN_U36_2_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U36.3｜repair

- Parent原句：有界 self-research/review/repair/retest/iteration/evolution
- Source：SRC-L-041:L933；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3775@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：EVOLUTION_EVIDENCE_OWNER / DOC-11。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `repair有exact write scope與preimage` → DomainOutcome(child=U36.3,predicate,actual_raw_sha,result,first_fail)。
- POS：repair有exact write scope與preimage；NEG：擴scope避失敗 → DOMAIN_U36_3_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U36.4｜retest

- Parent原句：有界 self-research/review/repair/retest/iteration/evolution
- Source：SRC-L-041:L934；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3776@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：EVOLUTION_EVIDENCE_OWNER / DOC-11。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `retest用原Oracle與同candidate` → DomainOutcome(child=U36.4,predicate,actual_raw_sha,result,first_fail)。
- POS：retest用原Oracle與同candidate；NEG：改threshold → DOMAIN_U36_4_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U36.5｜iteration

- Parent原句：有界 self-research/review/repair/retest/iteration/evolution
- Source：SRC-L-041:L935；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3777@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：EVOLUTION_EVIDENCE_OWNER / DOC-11。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `iteration保留每輪版本與budget止損；evolution候選另准入` → DomainOutcome(child=U36.5,predicate,actual_raw_sha,result,first_fail)。
- POS：iteration保留每輪版本與budget止損；evolution候選另准入；NEG：循環自提升法位 → DOMAIN_U36_5_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U37.1｜Dogfood 發現的失敗轉回退回歸

- Parent原句：Dogfood 發現的失敗轉回退回歸／研究與候選，而非自改 Oracle
- Source：SRC-L-041:L936；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3778@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：EVOLUTION_EVIDENCE_OWNER / DOC-11。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `dogfood失敗加入原回歸集` → DomainOutcome(child=U37.1,predicate,actual_raw_sha,result,first_fail)。
- POS：dogfood失敗加入原回歸集；NEG：刪舊NEG → DOMAIN_U37_1_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U37.2｜研究

- Parent原句：Dogfood 發現的失敗轉回退回歸／研究與候選，而非自改 Oracle
- Source：SRC-L-041:L937；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3779@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：EVOLUTION_EVIDENCE_OWNER / DOC-11。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `研究只追first_fail受影源` → DomainOutcome(child=U37.2,predicate,actual_raw_sha,result,first_fail)。
- POS：研究只追first_fail受影源；NEG：無界補工具 → DOMAIN_U37_2_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U37.3｜候選

- Parent原句：Dogfood 發現的失敗轉回退回歸／研究與候選，而非自改 Oracle
- Source：SRC-L-041:L938；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3780@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：EVOLUTION_EVIDENCE_OWNER / DOC-11。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `新演化candidate保留Owner決議` → DomainOutcome(child=U37.3,predicate,actual_raw_sha,result,first_fail)。
- POS：新演化candidate保留Owner決議；NEG：直接替換Active → DOMAIN_U37_3_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U37.4｜而非自改 Oracle (L5540)

- Parent原句：Dogfood 發現的失敗轉回退回歸／研究與候選，而非自改 Oracle
- Source：SRC-L-041:L939；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3781@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：EVOLUTION_EVIDENCE_OWNER / DOC-11。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `Oracle不由Maker自行更改` → DomainOutcome(child=U37.4,predicate,actual_raw_sha,result,first_fail)。
- POS：Oracle不由Maker自行更改；NEG：降低threshold讓測例過 → DOMAIN_U37_4_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U38.1｜Self Dogfood 對 SBL 自己的真實 Repo code

- Parent原句：Self Dogfood 對 SBL 自己的真實 Repo code/test/rollback
- Source：SRC-L-041:L940；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3782@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：EVOLUTION_EVIDENCE_OWNER / DOC-11。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `Self dogfood真SBL repo code/current HEAD` → DomainOutcome(child=U38.1,predicate,actual_raw_sha,result,first_fail)。
- POS：Self dogfood真SBL repo code/current HEAD；NEG：fixture repo冒真SBL → DOMAIN_U38_1_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U38.2｜test

- Parent原句：Self Dogfood 對 SBL 自己的真實 Repo code/test/rollback
- Source：SRC-L-041:L941；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3783@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：EVOLUTION_EVIDENCE_OWNER / DOC-11。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `真test runner exit/raw同candidate` → DomainOutcome(child=U38.2,predicate,actual_raw_sha,result,first_fail)。
- POS：真test runner exit/raw同candidate；NEG：README PASS冒run → DOMAIN_U38_2_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U38.3｜rollback (L5541)

- Parent原句：Self Dogfood 對 SBL 自己的真實 Repo code/test/rollback
- Source：SRC-L-041:L942；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3784@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：EVOLUTION_EVIDENCE_OWNER / DOC-11。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `rollback回復preimage且無越域residue` → DomainOutcome(child=U38.3,predicate,actual_raw_sha,result,first_fail)。
- POS：rollback回復preimage且無越域residue；NEG：reset他人未追蹤變更 → DOMAIN_U38_3_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U39.1｜Cross Dogfood 對 SWOF 的相容工作

- Parent原句：Cross Dogfood 對 SWOF 的相容工作，正式 Wave/Owner 准入
- Source：SRC-L-041:L943；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3785@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：HGK_FABRIC_OWNER / DOC-11。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `Cross dogfood走SWOF原相容contract` → DomainOutcome(child=U39.1,predicate,actual_raw_sha,result,first_fail)。
- POS：Cross dogfood走SWOF原相容contract；NEG：SBL自行宣稱W3 ready → DOMAIN_U39_1_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U39.2｜正式 Wave

- Parent原句：Cross Dogfood 對 SWOF 的相容工作，正式 Wave/Owner 准入
- Source：SRC-L-041:L944；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3786@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：HGK_FABRIC_OWNER / DOC-11。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `SWOF Wave實際Gate成立` → DomainOutcome(child=U39.2,predicate,actual_raw_sha,result,first_fail)。
- POS：SWOF Wave實際Gate成立；NEG：W2 shadow當W3 → DOMAIN_U39_2_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U39.3｜Owner 准入 (L5542)

- Parent原句：Cross Dogfood 對 SWOF 的相容工作，正式 Wave/Owner 准入
- Source：SRC-L-041:L945；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3787@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：HGK_FABRIC_OWNER / DOC-11。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `原Owner admission指向同scope` → DomainOutcome(child=U39.3,predicate,actual_raw_sha,result,first_fail)。
- POS：原Owner admission指向同scope；NEG：借別Wave grant → DOMAIN_U39_3_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U40.1｜SBL

- Parent原句：SBL 與 PRE-W3 僅過渡 Shadow，不阻塞正式 PRE-W3
- Source：SRC-L-041:L946；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3788@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：HGK_FABRIC_OWNER / DOC-11。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `SBL保持獨立產品與SWOF過渡適配` → DomainOutcome(child=U40.1,predicate,actual_raw_sha,result,first_fail)。
- POS：SBL保持獨立產品與SWOF過渡適配；NEG：SBL接管SWOF lifecycle → DOMAIN_U40_1_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U40.2｜PRE-W3 僅過渡 Shadow

- Parent原句：SBL 與 PRE-W3 僅過渡 Shadow，不阻塞正式 PRE-W3
- Source：SRC-L-041:L947；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3789@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：HGK_FABRIC_OWNER / DOC-11。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `PRE-W3只讀frozen readset且world diff0` → DomainOutcome(child=U40.2,predicate,actual_raw_sha,result,first_fail)。
- POS：PRE-W3只讀frozen readset且world diff0；NEG：Shadow發W3 packet → DOMAIN_U40_2_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U40.3｜不阻塞正式 PRE-W3 (L5543)

- Parent原句：SBL 與 PRE-W3 僅過渡 Shadow，不阻塞正式 PRE-W3
- Source：SRC-L-041:L948；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3790@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：HGK_FABRIC_OWNER / DOC-11。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `受影Shadow HOLD不阻正式PRE-W3其他READY` → DomainOutcome(child=U40.3,predicate,actual_raw_sha,result,first_fail)。
- POS：受影Shadow HOLD不阻正式PRE-W3其他READY；NEG：Global waterfall → DOMAIN_U40_3_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U41.1｜W3

- Parent原句：W3／W4／W5 的角色回流 SWOF 正式 OS Team／Profile／能力
- Source：SRC-L-041:L949；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3791@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：HGK_FABRIC_OWNER / DOC-12。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `W3路由回正式SWOF Owner/Gate` → DomainOutcome(child=U41.1,predicate,actual_raw_sha,result,first_fail)。
- POS：W3路由回正式SWOF Owner/Gate；NEG：SBL proposal直接W3 → DOMAIN_U41_1_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U41.2｜W4

- Parent原句：W3／W4／W5 的角色回流 SWOF 正式 OS Team／Profile／能力
- Source：SRC-L-041:L950；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3792@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：HGK_FABRIC_OWNER / DOC-12。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `W4角色回正式OS Team` → DomainOutcome(child=U41.2,predicate,actual_raw_sha,result,first_fail)。
- POS：W4角色回正式OS Team；NEG：便攜SP自封W4 principal → DOMAIN_U41_2_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U41.3｜W5 的角色回流 SWOF 正式 OS Team

- Parent原句：W3／W4／W5 的角色回流 SWOF 正式 OS Team／Profile／能力
- Source：SRC-L-041:L951；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3793@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：HGK_FABRIC_OWNER / DOC-12。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `W5能力延續正式Team的phase gate` → DomainOutcome(child=U41.3,predicate,actual_raw_sha,result,first_fail)。
- POS：W5能力延續正式Team的phase gate；NEG：用W3資格替W5 → DOMAIN_U41_3_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U41.4｜Profile

- Parent原句：W3／W4／W5 的角色回流 SWOF 正式 OS Team／Profile／能力
- Source：SRC-L-041:L952；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3794@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：HGK_FABRIC_OWNER / DOC-12。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `正式Profile version/loaded SHA真讀回` → DomainOutcome(child=U41.4,predicate,actual_raw_sha,result,first_fail)。
- POS：正式Profile version/loaded SHA真讀回；NEG：fixture profile充正式 → DOMAIN_U41_4_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U41.5｜能力 (L5544)

- Parent原句：W3／W4／W5 的角色回流 SWOF 正式 OS Team／Profile／能力
- Source：SRC-L-041:L953；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3795@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：HGK_FABRIC_OWNER / DOC-12。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `能力必經原Registry具體consumer ACK` → DomainOutcome(child=U41.5,predicate,actual_raw_sha,result,first_fail)。
- POS：能力必經原Registry具體consumer ACK；NEG：name-only當能力已啟用 → DOMAIN_U41_5_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U42.1｜SBL 能出 Skill

- Parent原句：SBL 能出 Skill/Plugin/Agent／Profile/Agent OS/AI System
- Source：SRC-L-041:L954；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3796@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：SBL_PRODUCT_OWNER / DOC-12。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `Skill有manifest/load/trigger/nontrigger/unload` → DomainOutcome(child=U42.1,predicate,actual_raw_sha,result,first_fail)。
- POS：Skill有manifest/load/trigger/nontrigger/unload；NEG：copy-only → DOMAIN_U42_1_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U42.2｜Plugin

- Parent原句：SBL 能出 Skill/Plugin/Agent／Profile/Agent OS/AI System
- Source：SRC-L-041:L955；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3797@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：SBL_PRODUCT_OWNER / DOC-12。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `Plugin有Host權限與version readback` → DomainOutcome(child=U42.2,predicate,actual_raw_sha,result,first_fail)。
- POS：Plugin有Host權限與version readback；NEG：不支援Host卻假PASS → DOMAIN_U42_2_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U42.3｜Agent

- Parent原句：SBL 能出 Skill/Plugin/Agent／Profile/Agent OS/AI System
- Source：SRC-L-041:L956；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3798@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：SBL_PRODUCT_OWNER / DOC-12。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `Agent有tool allowlist/budget/stop` → DomainOutcome(child=U42.3,predicate,actual_raw_sha,result,first_fail)。
- POS：Agent有tool allowlist/budget/stop；NEG：無界自治loop → DOMAIN_U42_3_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U42.4｜Profile

- Parent原句：SBL 能出 Skill/Plugin/Agent／Profile/Agent OS/AI System
- Source：SRC-L-041:L957；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3799@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：SBL_PRODUCT_OWNER / DOC-12。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `Profile有applicability/loaded SHA` → DomainOutcome(child=U42.4,predicate,actual_raw_sha,result,first_fail)。
- POS：Profile有applicability/loaded SHA；NEG：selected當loaded → DOMAIN_U42_4_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U42.5｜Agent OS

- Parent原句：SBL 能出 Skill/Plugin/Agent／Profile/Agent OS/AI System
- Source：SRC-L-041:L958；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3800@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：SBL_PRODUCT_OWNER / DOC-12。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `Agent OS與AI System各有正式lifecycle/部署接受；不能以規劃冒實作` → DomainOutcome(child=U42.5,predicate,actual_raw_sha,result,first_fail)。
- POS：Agent OS與AI System各有正式lifecycle/部署接受；不能以規劃冒實作；NEG：以Agent demo冒完整AI System → DOMAIN_U42_5_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U43.1｜支援 GENIE

- Parent原句：支援 GENIE/GENIE.md 的正式 SWOF 關係不可混同
- Source：SRC-L-041:L959；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3801@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：SBL_PRODUCT_OWNER / DOC-12。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `GENIE原canonical owner不被SBL取代` → DomainOutcome(child=U43.1,predicate,actual_raw_sha,result,first_fail)。
- POS：GENIE原canonical owner不被SBL取代；NEG：SBL自建GENIE generator authority → DOMAIN_U43_1_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U43.2｜GENIE.md 的正式 SWOF 關係不可混同 (L5546)

- Parent原句：支援 GENIE/GENIE.md 的正式 SWOF 關係不可混同
- Source：SRC-L-041:L960；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3802@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：SBL_PRODUCT_OWNER / DOC-12。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `GENIE.md版本read refs與SWOF正式關係可驗` → DomainOutcome(child=U43.2,predicate,actual_raw_sha,result,first_fail)。
- POS：GENIE.md版本read refs與SWOF正式關係可驗；NEG：任意GENIE.md冒原生部署 → DOMAIN_U43_2_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U44.1｜提供可操作的新手 E2E 第一有用成果（FUO） (L5547)

- Parent原句：提供可操作的新手 E2E 第一有用成果（FUO）
- Source：SRC-L-041:L961；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3803@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：SBL_PRODUCT_OWNER / DOC-12。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `新手普通Goal得到可操作FUO與退出；無需B1長Prompt` → DomainOutcome(child=U44.1,predicate,actual_raw_sha,result,first_fail)。
- POS：新手普通Goal得到可操作FUO與退出；無需B1長Prompt；NEG：只交表格與計數 → DOMAIN_U44_1_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U45.1｜實作「不是重造輪子」的 24 NOBJ 名稱

- Parent原句：實作「不是重造輪子」的 24 NOBJ 名稱/狀態/准入
- Source：SRC-L-041:L962；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3804@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：TOOL_REGISTRY_OWNER / DOC-12。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `24 NOBJ原名/身份逐筆對讀` → DomainOutcome(child=U45.1,predicate,actual_raw_sha,result,first_fail)。
- POS：24 NOBJ原名/身份逐筆對讀；NEG：湊24不同工具 → DOMAIN_U45_1_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U45.2｜狀態

- Parent原句：實作「不是重造輪子」的 24 NOBJ 名稱/狀態/准入
- Source：SRC-L-041:L963；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3805@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：TOOL_REGISTRY_OWNER / DOC-12。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `原REJECT/DEFER/REFERENCE狀態不被改寫` → DomainOutcome(child=U45.2,predicate,actual_raw_sha,result,first_fail)。
- POS：原REJECT/DEFER/REFERENCE狀態不被改寫；NEG：全改ADOPT → DOMAIN_U45_2_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U45.3｜准入 (L5548)

- Parent原句：實作「不是重造輪子」的 24 NOBJ 名稱/狀態/准入
- Source：SRC-L-041:L964；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3806@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：TOOL_REGISTRY_OWNER / DOC-12。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `license/pin/need/原Owner准入後才採用` → DomainOutcome(child=U45.3,predicate,actual_raw_sha,result,first_fail)。
- POS：license/pin/need/原Owner准入後才採用；NEG：未准入自動install → DOMAIN_U45_3_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U46.1｜保留

- Parent原句：保留 /1 vs /2 版本與兩個 Validator 的不相容
- Source：SRC-L-041:L965；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3807@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：TOOL_REGISTRY_OWNER / DOC-12。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `兩版本來源與validator各保留` → DomainOutcome(child=U46.1,predicate,actual_raw_sha,result,first_fail)。
- POS：兩版本來源與validator各保留；NEG：合併成單一/最新字串 → DOMAIN_U46_1_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U46.2｜1 vs

- Parent原句：保留 /1 vs /2 版本與兩個 Validator 的不相容
- Source：SRC-L-041:L966；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3808@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：TOOL_REGISTRY_OWNER / DOC-12。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `v1送v1 validator需符合v1 shape` → DomainOutcome(child=U46.2,predicate,actual_raw_sha,result,first_fail)。
- POS：v1送v1 validator需符合v1 shape；NEG：拿v2 receipt認證v1 → DOMAIN_U46_2_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U46.3｜2 版本

- Parent原句：保留 /1 vs /2 版本與兩個 Validator 的不相容
- Source：SRC-L-041:L967；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3809@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：TOOL_REGISTRY_OWNER / DOC-12。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `v2送v2 validator需符合v2 shape` → DomainOutcome(child=U46.3,predicate,actual_raw_sha,result,first_fail)。
- POS：v2送v2 validator需符合v2 shape；NEG：靜默丟v2欄位 → DOMAIN_U46_3_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U46.4｜兩個 Validator 的不相容 (L5549)

- Parent原句：保留 /1 vs /2 版本與兩個 Validator 的不相容
- Source：SRC-L-041:L968；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3810@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：TOOL_REGISTRY_OWNER / DOC-12。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `不相容時出版本NACK與受影migration` → DomainOutcome(child=U46.4,predicate,actual_raw_sha,result,first_fail)。
- POS：不相容時出版本NACK與受影migration；NEG：無損失表直接跨版 → DOMAIN_U46_4_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U47.1｜Open-source License

- Parent原句：Open-source License/NOTICE/SBOM/Secret/Dependency 所有正式 Gate
- Source：SRC-L-041:L969；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3811@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：SBL_RELEASE_OWNER / DOC-12。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `License義務與採納source pin一致` → DomainOutcome(child=U47.1,predicate,actual_raw_sha,result,first_fail)。
- POS：License義務與採納source pin一致；NEG：未知license照裝 → DOMAIN_U47_1_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U47.2｜NOTICE

- Parent原句：Open-source License/NOTICE/SBOM/Secret/Dependency 所有正式 Gate
- Source：SRC-L-041:L970；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3812@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：SBL_RELEASE_OWNER / DOC-12。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `NOTICE包含來源歸屬與必要聲明` → DomainOutcome(child=U47.2,predicate,actual_raw_sha,result,first_fail)。
- POS：NOTICE包含來源歸屬與必要聲明；NEG：剝除原歸屬 → DOMAIN_U47_2_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U47.3｜SBOM

- Parent原句：Open-source License/NOTICE/SBOM/Secret/Dependency 所有正式 Gate
- Source：SRC-L-041:L971；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3813@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：SBL_RELEASE_OWNER / DOC-12。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `SBOM component/pin/subject可回算` → DomainOutcome(child=U47.3,predicate,actual_raw_sha,result,first_fail)。
- POS：SBOM component/pin/subject可回算；NEG：名單冒SBOM → DOMAIN_U47_3_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U47.4｜Secret

- Parent原句：Open-source License/NOTICE/SBOM/Secret/Dependency 所有正式 Gate
- Source：SRC-L-041:L972；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3814@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：SBL_RELEASE_OWNER / DOC-12。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `Secret scan命中必擋受影發行且不印secret` → DomainOutcome(child=U47.4,predicate,actual_raw_sha,result,first_fail)。
- POS：Secret scan命中必擋受影發行且不印secret；NEG：忽略secret hit → DOMAIN_U47_4_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U47.5｜Dependency 所有正式 Gate (L5550)

- Parent原句：Open-source License/NOTICE/SBOM/Secret/Dependency 所有正式 Gate
- Source：SRC-L-041:L973；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3815@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：SBL_RELEASE_OWNER / DOC-12。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `Dependency供應鏈/漏洞Gate按原Policy與證據` → DomainOutcome(child=U47.5,predicate,actual_raw_sha,result,first_fail)。
- POS：Dependency供應鏈/漏洞Gate按原Policy與證據；NEG：CI綠就當Release → DOMAIN_U47_5_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U48.1｜產品三模式的 Required Gate

- Parent原句：產品三模式的 Required Gate/Forbidden Gate 逐項編譯
- Source：SRC-L-041:L974；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3816@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：ARCHITECT_ASSURANCE_OWNER / DOC-12。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `三Mode每項Required Gate按need逐項編譯` → DomainOutcome(child=U48.1,predicate,actual_raw_sha,result,first_fail)。
- POS：三Mode每項Required Gate按need逐項編譯；NEG：Standalone強制全SWOF Gate → DOMAIN_U48_1_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U48.2｜Forbidden Gate 逐項編譯 (L5551)

- Parent原句：產品三模式的 Required Gate/Forbidden Gate 逐項編譯
- Source：SRC-L-041:L975；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3817@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：ARCHITECT_ASSURANCE_OWNER / DOC-12。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `Forbidden Gate在該Mode被實際拒絕` → DomainOutcome(child=U48.2,predicate,actual_raw_sha,result,first_fail)。
- POS：Forbidden Gate在該Mode被實際拒絕；NEG：Shadow允world effect → DOMAIN_U48_2_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U49.1｜反過度工程 Overengineering Index

- Parent原句：反過度工程 Overengineering Index 與停損
- Source：SRC-L-041:L976；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3818@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：SBL_PRODUCT_OWNER / DOC-12。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `Overengineering Index依來源指標與需求差額計算` → DomainOutcome(child=U49.1,predicate,actual_raw_sha,result,first_fail)。
- POS：Overengineering Index依來源指標與需求差額計算；NEG：自造閾值當Owner標準 → DOMAIN_U49_1_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U49.2｜停損 (L5552)

- Parent原句：反過度工程 Overengineering Index 與停損
- Source：SRC-L-041:L977；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3819@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：SBL_PRODUCT_OWNER / DOC-12。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `達停損條件保留未關閉需求與合法resume` → DomainOutcome(child=U49.2,predicate,actual_raw_sha,result,first_fail)。
- POS：達停損條件保留未關閉需求與合法resume；NEG：停損宣告所有需求PASS → DOMAIN_U49_2_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U50.1｜提供 workflow

- Parent原句：提供 workflow / script / config、機器 JSON/TSV
- Source：SRC-L-041:L978；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3820@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：ARCHITECT_ASSURANCE_OWNER / DOC-12。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `workflow步驟可按受權scope執行並有退出` → DomainOutcome(child=U50.1,predicate,actual_raw_sha,result,first_fail)。
- POS：workflow步驟可按受權scope執行並有退出；NEG：純敘事無步驟 → DOMAIN_U50_1_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U50.2｜script

- Parent原句：提供 workflow / script / config、機器 JSON/TSV
- Source：SRC-L-041:L979；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3821@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：ARCHITECT_ASSURANCE_OWNER / DOC-12。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `script具input/exit與無效輸入拒收` → DomainOutcome(child=U50.2,predicate,actual_raw_sha,result,first_fail)。
- POS：script具input/exit與無效輸入拒收；NEG：腳本有名無實體 → DOMAIN_U50_2_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U50.3｜config

- Parent原句：提供 workflow / script / config、機器 JSON/TSV
- Source：SRC-L-041:L980；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3822@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：ARCHITECT_ASSURANCE_OWNER / DOC-12。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `config可驗schema/version且有rollback` → DomainOutcome(child=U50.3,predicate,actual_raw_sha,result,first_fail)。
- POS：config可驗schema/version且有rollback；NEG：改Active未有OPS ECP → DOMAIN_U50_3_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U50.4｜機器 JSON

- Parent原句：提供 workflow / script / config、機器 JSON/TSV
- Source：SRC-L-041:L981；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3823@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：ARCHITECT_ASSURANCE_OWNER / DOC-12。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `JSON可parse且維持所有原ID/否定scope` → DomainOutcome(child=U50.4,predicate,actual_raw_sha,result,first_fail)。
- POS：JSON可parse且維持所有原ID/否定scope；NEG：只匯出成功列 → DOMAIN_U50_4_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

### U50.5｜TSV (L5553)

- Parent原句：提供 workflow / script / config、機器 JSON/TSV
- Source：SRC-L-041:L982；SHA `43a0a7ed26d2adf9c2803062032019ccb6acce27cebb49af4d37c3cd4b0a3a2f`；歷史locator：SBL_PIPD-LS-PKG_全DOC藍圖(8).md:L3824@8e8327dbc53be8a1722d1cd5cdafd240cd9bb358218efaae13689827b80986cb；Owner/Consumer：ARCHITECT_ASSURANCE_OWNER / DOC-12。
- 輸入→變換→typed output：本parent的domain stimulus＋同Host原始觀測→驗 `TSV欄位escape/行數/ID與JSON roundtrip一致` → DomainOutcome(child=U50.5,predicate,actual_raw_sha,result,first_fail)。
- POS：TSV欄位escape/行數/ID與JSON roundtrip一致；NEG：分隔符破壞列 → DOMAIN_U50_5_VIOLATION。不能用sibling或欄位存在代替。
- Native state：DESIGN_DEFINED_NATIVE_NOT_RUN；下一合法動作：原Owner綁本域Runner與Oracle後取得真Raw；退出/重入按上文effect分流，不能改Parent或Oracle求綠。

## R2-09-U03：三SP×三動作九子測（原ID不改）

每條先查本Host支援的真installer/loader/trigger。移除後不得觸發；非相關目標不得誤觸發；未支援Web Host只報HOST_HOLD，不偷換Codex成功。
| subtest_id | POS | NEG/first_fail | expected raw |
|---|---|---|---|
| U03.1@TPM | TPM 本身在此Host install 可讀回；invoke含trigger/nontrigger/卸載後不觸發 | 借TPM或其它SP的install Raw給TPM / SP_ACTION_EVIDENCE_MISMATCH | ['host_identity', 'sp_manifest_sha', 'fresh_session_id', 'install_observation'] |
| U03.1@Commander | Commander 本身在此Host install 可讀回；invoke含trigger/nontrigger/卸載後不觸發 | 借TPM或其它SP的install Raw給Commander / SP_ACTION_EVIDENCE_MISMATCH | ['host_identity', 'sp_manifest_sha', 'fresh_session_id', 'install_observation'] |
| U03.1@Challenge | Challenge 本身在此Host install 可讀回；invoke含trigger/nontrigger/卸載後不觸發 | 借TPM或其它SP的install Raw給Challenge / SP_ACTION_EVIDENCE_MISMATCH | ['host_identity', 'sp_manifest_sha', 'fresh_session_id', 'install_observation'] |
| U03.2@TPM | TPM 本身在此Host load 可讀回；invoke含trigger/nontrigger/卸載後不觸發 | 借TPM或其它SP的load Raw給TPM / SP_ACTION_EVIDENCE_MISMATCH | ['host_identity', 'sp_manifest_sha', 'fresh_session_id', 'load_observation'] |
| U03.2@Commander | Commander 本身在此Host load 可讀回；invoke含trigger/nontrigger/卸載後不觸發 | 借TPM或其它SP的load Raw給Commander / SP_ACTION_EVIDENCE_MISMATCH | ['host_identity', 'sp_manifest_sha', 'fresh_session_id', 'load_observation'] |
| U03.2@Challenge | Challenge 本身在此Host load 可讀回；invoke含trigger/nontrigger/卸載後不觸發 | 借TPM或其它SP的load Raw給Challenge / SP_ACTION_EVIDENCE_MISMATCH | ['host_identity', 'sp_manifest_sha', 'fresh_session_id', 'load_observation'] |
| U03.3@TPM | TPM 本身在此Host invoke 可讀回；invoke含trigger/nontrigger/卸載後不觸發 | 借TPM或其它SP的invoke Raw給TPM / SP_ACTION_EVIDENCE_MISMATCH | ['host_identity', 'sp_manifest_sha', 'fresh_session_id', 'invoke_observation'] |
| U03.3@Commander | Commander 本身在此Host invoke 可讀回；invoke含trigger/nontrigger/卸載後不觸發 | 借TPM或其它SP的invoke Raw給Commander / SP_ACTION_EVIDENCE_MISMATCH | ['host_identity', 'sp_manifest_sha', 'fresh_session_id', 'invoke_observation'] |
| U03.3@Challenge | Challenge 本身在此Host invoke 可讀回；invoke含trigger/nontrigger/卸載後不觸發 | 借TPM或其它SP的invoke Raw給Challenge / SP_ACTION_EVIDENCE_MISMATCH | ['host_identity', 'sp_manifest_sha', 'fresh_session_id', 'invoke_observation'] |

## 保留14冊的功能Producer/Consumer路由


# SBL DOC00–13 原功能升級、149 Child 與 192 Cell

> **效力**：本檔為 `BODY-09` 的來源約束施工設計候選，保留來源章節的原 ID、Decision、POS/NEG、HOLD；尚不是任何正式 PI/PD/ECP/Permit/WorkOrder/Checker Verdict 或 Release。凡提及 `PROPOSED` 的 ABI，需由原 Owner／Host Registry 真正綁定。

## 10. SBL DOC00–13 全部原功能群的工程性整合覆蓋（原 ID 不改）

每張以下卡是現行 v2 的 **功能群施工投影**，不代替原 SBL-DOC 之每個 REQ 原文；`PRESERVE` 表示義務照舊、`REPLACE` 只替換不合法的跨域接線、`CONDITIONAL` 保留 Host/Mode/效力，不將未取得原件解讀為已不存在。每個 source atom 要透過 `source_id + original_req_id + clause_hash → functional_group_id → WorkPackage → POS/NEG → Actual Consumer` 建立 Trace；若原 atom 尚未定位，保留 `ATOM_TRACE_HOLD`，不可用群組文字宣稱 949 個逐子語義全閉合。

### 10.1 DOC 功能群的輸入、真產物、Reader 與 Test

| 原 SBL DOC / 原不可降級群 | 原使用者目標與輸入→變換→具名產物／真正 Consumer | 修補實作與受影工卡、POS / NEG / Exit |
|---|---|---|

| SBL-DOC00 **OperatorEntry/DocumentRoute** (PRESERVE+BOUNDARY_REPLACE) | 讀者選 Kind/Mode/Host、確認 14 冊版本與兩 PIPD namespace→LegalNextAction/SourceView；全員。 | 按 Writer 及 Source SHA dispatch，已取得 14 docs 顯示 current，缺可恢復 SourceErrorEnvelope；Producer/Writer 仍依 SRC-SBL-00 原權限；Consumer 施工 WP-FHS-00/15；POS 錯 Domain 同號被 DENY，真 Source 選對；NEG 以 SBL-DOC07 當 PIPD Oracle→NACK_WRONG_NAMESPACE；Exit 只撤受影新 adapter/保留原義與先前合法部署。 |

| SBL-DOC01 **UserIntent/50Parent149Child** (PRESERVE+BOUNDARY_REPLACE) | Goal+JTBD/FUO、persona/50 parent/149 children→UserJourney/ProductSpec/可用 Kind；TPM/User。 | 每個 child 的 Source/ACC_POS/ACC_NEG/Kind 導到真正 CLI/Skill/Agent Outcome；Producer/Writer 仍依 SRC-SBL-01 原權限；Consumer 施工 WP-FHS-15/20；POS CLI 真操作/Skill 真觸發/Agent 真受限；NEG 僅有 DOC 成功卻缺可安裝物→FUO_NOT_DELIVERED；Exit 只撤受影新 adapter/保留原義與先前合法部署。 |

| SBL-DOC02 **SourceBoundSPEC** (PRESERVE+BOUNDARY_REPLACE) | SourceClause/KnownAnswer/Architecture choice→Product/Architecture/ProgramSPEC 候選；TPM/PIPD Intake。 | 每個 SPEC atom 有 Actor/Source/Owner/ACC+NEG，保留原 SPEC identity 並經 K3 讀回；Producer/Writer 仍依 SRC-SBL-02 原權限；Consumer 施工 WP-FHS-01/15；POS 同來源不重複提問、正負測試都具體；NEG 忘記 source_lexicon/冒 PI→SPEC_SCHEMA_NACK；Exit 只撤受影新 adapter/保留原義與先前合法部署。 |

| SBL-DOC03 **RequirementProjection/NativePI** (PRESERVE+BOUNDARY_REPLACE) | 149 Child/266 NativePI 區域欄→逐 atom Loss/Trace/Owner/SchemaProjection；PIPD DOC02。 | 266 個區域欄放 proposal sidecar，不擅自注入 P4 5 REQ enum；Producer/Writer 仍依 SRC-SBL-03 原權限；Consumer 施工 WP-FHS-01/05；POS roundtrip 保持 149 IDs 不減、原 source polarity；NEG _profile_meta/未知 required 進 PI→PI_SCHEMA_NACK；Exit 只撤受影新 adapter/保留原義與先前合法部署。 |

| SBL-DOC04 **OneCore3SP6Modules** (PRESERVE+BOUNDARY_REPLACE) | Source Goal→M01 Intake→M02 SPEC→M03 Route→M04 BuildBridge→M05 Verify→M06 Repair；原三 SP。 | 維持三真 principal/Permission 分隔與 C12–15/C37，18 Stage 由 §6 實作；Producer/Writer 仍依 SRC-SBL-04 原權限；Consumer 施工 WP-FHS-04/15；POS 每模組 DTO/sourceSHA 下一站可讀；NEG 共享 SharedCore 被解讀共享 credential→SOD_NACK；Exit 只撤受影新 adapter/保留原義與先前合法部署。 |

| SBL-DOC05 **RepoContext/PD/ECP** (PRESERVE+BOUNDARY_REPLACE) | 真 RepoHEAD/index/untracked/reparse/WriteSet→PD/Construction/DEV或OPS ECP；PIPD/HGK。 | Repo/Host/User/Remote 五效果分離，原 preimage/unknown at-most-once 不變；Producer/Writer 仍依 SRC-SBL-05 原權限；Consumer 施工 WP-FHS-05/06；POS 已受權 Repo 內可逆 patch、Host 不偷寫；NEG **/path traverse/zero preimage→ECP_SCOPE_NACK；Exit 只撤受影新 adapter/保留原義與先前合法部署。 |

| SBL-DOC06 **TechnologyAdmission/Donor** (PRESERVE+BOUNDARY_REPLACE) | 386 原技術/24 Donor Slot/25 Method/30 Defaults→OriginalDisposition+AssetBindingCard；TechnologyAdmission Owner。 | 原 ID 清單已在 §9 逐名，其 license/Host/MethodOnly 分路安裝；Producer/Writer 仍依 SRC-SBL-06 原權限；Consumer 施工 WP-FHS-13/16；POS Default 不降 optional，Host 真的 loaded才 Enabled；NEG REJECT/DEFER 被假裝 Mandatory→TECH_POLICY_REGRESSION；Exit 只撤受影新 adapter/保留原義與先前合法部署。 |

| SBL-DOC07 **Trust/Permission** (PRESERVE+BOUNDARY_REPLACE) | Scope/TTL/Epoch/SID/ACL/OwnerGrant→PermissionIntent/ReadScope；HGK Receiver。 | L0/L1/Native world 分層，真正 Issuer 逐 subject nonce 讀回；Producer/Writer 仍依 SRC-SBL-07 原權限；Consumer 施工 WP-FHS-03/17；POS wrong key/expired permit 只拒受影 effect；NEG 讀文件需要 administrator→OVERGOVERNANCE_NACK；Exit 只撤受影新 adapter/保留原義與先前合法部署。 |

| SBL-DOC08 **Challenge/SBL-R08-07** (PRESERVE+BOUNDARY_REPLACE) | SBL E00–E10 FrozenReadset/POS NEG/CheckerRef→ChallengeFinding/TQAEP Reader。 | 保留 C22/C39/C40/C42，Native Checker inbox write 與 portable read only 區分；AC-E01..15 另見 §11；Producer/Writer 仍依 SRC-SBL-08 原權限；Consumer 施工 WP-FHS-09/21；POS Maker/Checker credential 分離，同 SHA 獨立 raw；NEG 同 Maker key 判 IndependentPASS→TQ_SOD；Exit 只撤受影新 adapter/保留原義與先前合法部署。 |

| SBL-DOC09 **Evidence/Trace/Claim** (PRESERVE+BOUNDARY_REPLACE) | Source→OutputRaw→EvidenceExpectation→ClaimLedger→Delivery/ClaimCeiling；Checker/Owner。 | 動態 evidence freshness/SubjectSHA/operation_id/reader ACK 逐項 join；Producer/Writer 仍依 SRC-SBL-09 原權限；Consumer 施工 WP-FHS-09/19；POS stale raw invalidated，非相同 subject 不借證；NEG CI 綠直接宣稱 NativePASS→FALSE_GREEN；Exit 只撤受影新 adapter/保留原義與先前合法部署。 |

| SBL-DOC10 **BuilderKnowledge/4Host** (PRESERVE+BOUNDARY_REPLACE) | GENIEMAKER/HLPE/OROCHI/RAG＋HostCaps→CLI/Skill/Agent BuildOutput；User。 | 四 Host 現役 Loader 各自安裝/觸發/卸載，Method-only 不裝 binary；Producer/Writer 仍依 SRC-SBL-10 原權限；Consumer 施工 WP-FHS-11/20；POS fresh host build/install/trigger/uninstall；NEG 未知 Host Flag 亂填→HOST_NOFIT；Exit 只撤受影新 adapter/保留原義與先前合法部署。 |

| SBL-DOC11 **NativeSWOF/3Modes** (PRESERVE+BOUNDARY_REPLACE) | STANDALONE/PREW3_SHADOW/SWOF_CONNECTED + G00–G12→ModePlan/AllowedEffect；HGK/SWOF。 | W3 依 SWOF 真 Registry/Owner Gate，PREW3 zero world-effect；Producer/Writer 仍依 SRC-SBL-11 原權限；Consumer 施工 WP-FHS-02/06/20；POS Shadow 不落世界、W3 有效 Consumer ACK；NEG W2 討論當 W3 Permit→W3_DENIED；Exit 只撤受影新 adapter/保留原義與先前合法部署。 |

| SBL-DOC12 **LaunchPrompt/184Atoms58Roles** (PRESERVE+BOUNDARY_REPLACE) | 原 184 instruction atoms/58 roles/23 SchemaDefs→SourcePrompt/Host trigger manifest。 | 按 Host Reader capability 做最小 Goal 入口、ProviderOff/ColdStart/NoUpload；Producer/Writer 仍依 SRC-SBL-12 原權限；Consumer 施工 WP-FHS-11/12/15；POS 正常新 PID 無 B1 Prompt、unrelated skill nontrigger；NEG Prompt 汙染授權或重上傳內建 DOC→PROMPT_DEPENDENCY；Exit 只撤受影新 adapter/保留原義與先前合法部署。 |

| SBL-DOC13 **DogfoodEvolve/16Moments** (PRESERVE+BOUNDARY_REPLACE) | 16 user moments、F01–25、GJ、FAR budget→Acceptance/StopResume/EvolutionCandidate。 | W18 原 E-ID 不變；B1≠UAT≠Release；每 RepairCone 需源與真 Red/Green；Producer/Writer 仍依 SRC-SBL-13 原權限；Consumer 施工 WP-FHS-10/12/18；POS reentry 不重播 Done，checked case raw 可回溯；NEG 自舉成功文字=正式被接受→CLAIM_ESCALATION；Exit 只撤受影新 adapter/保留原義與先前合法部署。 |
