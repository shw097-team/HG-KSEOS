---
artifact_id: FHS-MSC-R2-BODY-06
formal_name: FHS-EXECUTE 與 Hermes 恢復契約
short_name: BODY-06
version: 2026-10-29-r2-revision2
source_set_hash_or_pending: f86b217ae3c3ee28183570f4bf3d4f08d4d00e9b86d1de1a641a630f8682d1a1
intended_consumer: 原領域 Owner 與下游 Reader
owner_role: 作者端規格修補者；原 Domain Writer 不移轉
design_status: SOURCE_BOUND_REPAIR_CANDIDATE
claim_ceiling: AUTHOR_STATIC_ONLY; NATIVE_NOT_RUN; CHECKER_NOT_RUN; RELEASE_NOT_RUN
supersession_scope: 本輪作者候選revision2；保留前版封存；不取代任何原Canonical Writer版本
AUDIT_F_IDs:
- F-19
---

# FHS-EXECUTE 與 Hermes 恢復契約

## R2-06-REDUCER：proposal 到原 HGK 狀態的讀取契約

先以原 HGK module origin/schema SHA/serializer/reducer enum 做讀回，建立 proposal→native map。map 結果只有 EXACT_NATIVE、COMPAT_ADAPTER、UNSUPPORTED、ABI_BIND_HOLD；不以自行定義字串直接送 reducer。READY、LEASED 等下文是設計狀態，真事件 enum 以該 probe 綁定。

事件輸入 `work_id,event_id,expected_revision,lease_generation,worker_pid,operation_id,source_sha,policy_epoch`。PLAN 候選由原 Writer admitted 後才能進原 Queue；CAS(expected_revision) 只允許一 Worker claim。Claim→執行前記 operation intent；取得 Raw world readback 才提交 EFFECT_KNOWN。timeout 落 UNKNOWN，禁止同 nonce 重發；先以 operation_id 對 world reader 查 commit/partial/no-effect/unknown，NO_EFFECT 證明成立後才由 Issuer 決定新 nonce。部分效果以獨立 compensation ECP 修復，原 residue 不得刪。

READY>0 時 wake 只送原 Hermes wake endpoint。ACK 需 cursor/revision，Worker startup Raw 需新 PID、process origin、loaded profile、lease generation。wake timeout 可重送同 idempotent wake event，不可把效果一起重播。restart 由原 Journal cursor 恢復；generation 過期 Worker 的 Raw 只作觀測，不能 commit。READY=0 時等待原 wake，不部署新的 MissionController。

POS：Worker A intent 後 crash，新 PID B 先 reconcile 原 operation，再消費不同未完成工作；NEG：A lease generation=7，B 已升=8，A commit → LEASE_FENCING_DENY。POS：work X issuer 缺件 PARK，Y read-only READY 被服務；NEG：全 Queue WAIT → GLOBAL_OVERBLOCKING。

綁定步驟：原 HGK/Hermes Owner 讀目前 reducer/Wake API schema 與 help → 保存 module path+SHA+enum → 以 no-effect fixture 驗 serializer/CAS → 將同 Subject OPS ECP 交原 Issuer。未有本輪 Runtime Raw 一律 NATIVE_NOT_RUN。退出只關閉本輪 proposed mapping；已 admitted 舊 work 繼續依原 receipt，不重編 PI/PD。

## 保留的領域實質設計（修補表格語法與狀態字樣）


# FHS-EXECUTE／Hermes 持久 Worker 與有界修復

> **效力**：本檔為 `BODY-06` 的來源約束施工設計候選，保留來源章節的原 ID、Decision、POS/NEG、HOLD；尚不是任何正式 PI/PD/ECP/Permit/WorkOrder/Checker Verdict 或 Release。凡提及 `PROPOSED` 的 ABI，需由原 Owner／Host Registry 真正綁定。

### 4.3 FHS-EXECUTE + Hermes / Code Worker

**FHS-EXECUTE** 是 HGK 已接納 WorkOrder 的執行合約：從既有 SharedSpine 單一狀態 reducer 選 `READY`, check `PolicyEpoch`, CAS claim Lease、記 pinned Worker executable/served model、受限 WriteSet 調 Codex/OpenCode approved worker、持久 stdout/stderr/raw、世界狀態比對、Checkpoint、ACK/HOLD。**正常重試**只對可證 idempotent 的 no-effect action；**已消耗世界效果**重試採 `UNKNOWN_EFFECT→readback/reconcile→新有權動作`，不能把 max retry 參數當 OS effect 合法性。**POS** Worker 被 Kill 後在不同 PID、相同 Work ID 合法恢復而無重複 effect；**NEG** 心跳範例／本地 dispatcher mock 不能宣稱真 Hermes 已載入。[SRC-FEX:§2–8][SRC-W18:W02/W15]
### 13.5 Golden Journey POS/NEG/SEC/EDGE 原生 Runner 約束

| Journey / 原用戶可見成果 | 原生 Runner/證據（執行前須現役發現） | 反證與退出 |
|---|---|---|
| GJ-CLI | fresh host 安裝 wheel/bin→help/add/list/remove/uninstall；raw binarySHA/exit/stdout/stderr/user_result | 不認識子命令非零、資料超 ACL DENY、卸載無殘留；不把文字示範當 install。 |
| GJ-SKILL | 每個 Host 的 Loader Registry、適用與無關 prompt、loadedSHA、卸載新 PID | 非觸發或未裝都不得變成技能在場。 |
| GJ-SIMPLE_AGENT | one allowed tool+budget+grant 正向成功，撤銷後不再 effect | 不受限 agent/permission escalation/timeout 新 nonce replay DENY。 |
| GJ-TPM→PI→PD | K0..K3 +18 stages→正式 Writer raw/Trace/PIPD ECP；Owner與Reader分離 | 無 source 造 Native PI，12v9/Oracle collision 暗自修正 DENY。 |
| GJ-PLAN→EXECUTE | A/B合法 Proposal→Real Issuer→SharedSpine Lease→Hermes actual PID/Worker→WorldRaw | cycle/duplicate job/unknown effect replay/stale lease/new issuer 全 NACK。 |
| GJ-CHALLENGE | A/B/C分立，CaseSpec POS+NEG H4/SEAM 應用性，Different principal Protected AO | 只有自評/自簽禁止 Independent PASS。 |
| GJ-B1 | 27/31/120/124/38 分群+三 GWO/G-A/G-B 的原 Native Writer Raw | Repo claim不能代這次 Windows Live；各 Gate 獨立判。 |
| GJ-W18 | NM01–03/E33–E42 新 PID Default Profile；required/served、工具實 invoked、非觸發 | 仍需 B1 專用 long prompt、test-only binding、偷 fallback 各判失敗。 |
| GJ-RELEASE | 原 Publisher/Owner 真簽與 rollout/readback（不在本輪） | CI/PR/Markdown sealed 不等同 Signed Release。 |

**可判斷的驗收層級**：`DESIGN_SPECIFIED`, `STATIC_SCHEMA_VERIFIED`, `INSTALLED`, `HOST_LOADED`, `INVOKED`, `WORLD_EFFECT_READBACK`, `INDEPENDENT_CHECKER_VERDICT`, `OWNER_RATIFIED`, `RELEASED` 分開；本設計只把 Case/Owner/expected Raw 定義好，沒有親自執行 Windows 或獨立 AO。[SRC-PIPD-07/09]

## 任務狀態與 at-most-once effect

核心執行狀態 `PLAN_CANDIDATE→ADMITTED→READY→LEASED→RUNNING→WORLD_READBACK_PENDING→CHECKER_PENDING→ACCEPTED/REPAIR/PARKED` 為此文件提案閱讀詞，真 reducer enum 必以 Host 註冊為準。Hermes 必存 Journal／Lease generation／WorkItem id／Subject/Epoch／Cursor／first_fail／raw byte hash；Codex CLI 只能在 Hermes 委派的 scope/permission 中工作，不變成 Scheduler。

`UNKNOWN/TIMEOUT` 情況必先透過 current operation_id 查實際 World state：若已受效，記原 Receipt 及 Oracle，不重發；若未受效且 Permit 已 consumed，回原 Issuer 新判准；若無法判定，PARK 並要求真 Readback，不能以 retry budget 偷重播。CAS/Lease stale worker 不能提交新的世界變更。

FAR 的 `first_fail→minimal diff→red/green→raw→rechallenge` 需受限修補預算 `time/attempts/write_set/impact`；Fix 修改 Oracle/Threshold 或嘗試憑證提升即 FAIL_SECURITY。允許相互獨立的 L0/L1 work 續行。

## 領域 v2 精確補強條款（保留正式原域 Writer，非 Native 生效證據）


### 領域回源段 1：`FHS-EXECUTE_藍圖_2026-10-28_v2_HIGH_RETENTION_FULL_SUBSTANTIVE_AUDIT_REPAIR.md:L86–L263`

> 本段原生設計來源，高保留嵌入供下游逐條實作；如需更改正式 Policy/Schema/Gate，應回原 Domain Writer 決策。

## §3｜反循環 Native E2E：EffectClass 分流、Route-before-Spawn、現役 Singleton

```mermaid
flowchart TD
    A[One Goal or already admitted package] --> B{Intake state}
    B -->|READ ONLY| RO[Authorized Source Reader no effect Permit]
    B -->|EXISTING| P[Direct PIPD Reader reuse]
    B -->|NEW GOAL| Q[TPM Proposal to PIPD original Writer only if needed]
    Q --> P
    P --> S{Legal SBL PLAN ABI?}
    S -->|NO| X[PARK affected proposal cards only]
    S -->|YES| D[One approved PlanRevision]
    D --> E{Effect Class}
    E -->|READ_ONLY| RO
    E -->|REPO DEV| F[DEV ECP plus scoped repo Admission]
    E -->|HOST USER POLICY| G[OPS ECP plus HGK Native Issuer Receiver ACL Permit]
    F --> H[CAP BOOT required slots + ROUTE BIND STATIC]
    G --> H
    H --> I[HGK SharedSpine READY CAS lease and fencing]
    I --> J[Hermes real OS PID and actual selected method/model]
    J --> K[Effect journal and world before-after readback]
    K --> L[Checkpoint frozen evidence and protected independent checker]
    L --> M{FirstFail?}
    M -->|NO| N[Verified subgraph or partial deliverable]
    M -->|YES| O[KnownFix then bounded FAR or distinct FDA trigger]
    O -->|valid scoped repair only| J
    O -->|no authority| X
    RO --> N
```

**消除兩個依賴環**：`CAP-BOOT` 在任何 Consumer 前建本輪 *必需* Native/Portable Slot；`ROUTE_BIND_STATIC` 先核 Required/Selected 的政策與可用方法（可做 L1 無效果 probe），才放行具效果 Worker。真正 `Served`/工具往返 raw **由真 dispatch產生**，派工前**不要求先取得同一派工的 Live Served Receipt**。Live Served/Checker 是派工結果的獨立 qualification，不得憑預期 `required` 充 `served`。`CAP-SWAP-QUALIFY` 晚期做跨版，不是第一個 installer。

**Singleton 部署**：HGK 仍唯一 Registry/Resolver/Trust/Issuer/Receiver/SharedSpine，Fabric 的 Policy Stage/Active/Loaded/Consumer 不在 FEX 改寫，Hermes 是唯一 Durable Mission Executor，Codex 是合法 scoped Worker，PIPD 仍唯一 canonical compiler，SBL PLAN 唯一 TaskDAG producer。FEX 僅接口 consumer/adapters，不建立新 scheduler、DB、service、TLS trust anchor 或可自簽第二 queue。

### 3.1 實際 T00～T11 轉移契約（欄位不能互代）

| Edge | 真 Producer→Consumer | Preconditions/Effect | 成功 Raw 和受影拒收／恢復 |
|---|---|---|---|
| T00 | User/TPM→Source/PIPD Reader | Goal+Source or valid admitted Package | IntakeDecision 六分支；no Source→read-only QuestionDelta |
| T01 | PIPD Original Compiler→FEX Reader | schema_id/digest/source_sha/subject_sha/stage | Existing package reuse/affected rebind；portable Markdown NACK |
| T02 | SBL licensed PLAN ABI→HGK | A/B 合法提案+single revision+DAG | PlanProposalRef；禁 Legacy Commander / absent ABI affected PARK |
| T03 | HGK Read/Effect Admission → WorkState | ReadOnly: ACL/ReadScope；DEV: scoped Repo ECP/Admit；Host/User: OPS ECP+real Issuer/Permit；Policy/Release separately | READ_SCOPE_DENIED != EFFECT_PERMIT_DENIED；錯 key/nonce/TTL/revoke/ACL spawn 前拒 |
| T04 | SharedSpine→Hermes | CAP-BOOT + route static + READY/Dependencies + CAS lease | lease_id,generation,fence；舊 generation DENY |
| T05 | Hermes→authorized Codex/Worker | real executable SHA, selected policy, permissions, WriteSet, no unbound required methods | pid,process_start,served call/actual method raw；NoFit affected PARK |
| T06 | Receiver/Worker→EffectJournal | operation_id,idempotency_scope,preimage,nonce,epoch | prepared/effect observation; timeout→UNKNOWN_EFFECT，不重發 consumed nonce |
| T07 | Domain Reader→Hermes | actual resource/version/source+same operation | before/after bytes+sha, side effects；CLI exit0 ≠ world effect |
| T08 | Hermes→SharedSpine | journal+current generation/readback SHA | durable cursor/checkpoint；crash before ack reconcile |
| T09 | Frozen subject→Protected Checker | different principal/credential, immutable oracle+raw | signed verdict or CHECKER_UNAVAILABLE，Maker 只 SELF_TESTED |
| T10 | Native reducer→SBL/Hermes deliverable | all applicable state resolved or explicit partial holds | PARTIAL_DELIVERABLE vs TERMINAL_QUALIFIED，Release separate |
| T11 | FirstFail→KnownFix/FAR/FDA→Dev Repair | true bounded cone, new scope when needed | red/patch/green/world recheck/checker/resume same card；budget/unsafe PARK |

**受影權限決定（法位回原 Writer）**：`READ_ONLY_PROBE` 真 Read Scope 足夠、不得要求無關 Effect Permit；`REPOSITORY_WRITE` 真 DEV ECP + current RepoContext + Native/OS scope；`HOST_OPERATIONS` 與 `USER_DATA` OPS ECP/OS ACL+HGK Permit 各自獨立，不得借 REPO token；`PolicyChange` Fabric Owner Stage/Activate + HGK receiver 真生效；`Release` Publisher/Owner 另行決策。無當期有效 Writer Gate 只停真正受影子圖。

**Origin-bound idempotency**：Operation ID/nonce/fencing/Lease 格式以現役 HGK/Receiver 為準；本文件提的 `H(mission,subject,operation,scope,policy_epoch)` 只是索引候選，不可變成新 canonical Key Schema。同步 `SourceSHA/SubjectSHA/PolicyEpoch/GrantVersion/PermissionScope/OS Principal/CheckOracle`；收到 late ack 要核 generation、resource true effect state，任何 ambiguous `UNKNOWN_EFFECT` 先 read-world/reconcile，未知不得 `retry`，跨 PID 不重播 irreversible effect。

## §4｜Typed ABI 的安全示例、錯誤、Compatibility 邊界（AUD-006/019）

下列**只是一個無效力提案 envelope**，不是 JSON Schema、正式 PIPD 原件或 Issuer Permit；不用 JSON Schema `$schema` 字段（v1 同名值非 URI），`schema_id` 只是提案註記。Host Adapter 必綁現役 Schema URI／ABI 及 Owner 簽署後轉成原生型別，提交前禁止 `BIND_*` placeholders、null signer、null policy epoch、`generation=0` 靜態 placeholder。

```json
{
  "schema_id": "FEX.EXECUTION-ENVELOPE/2-PROPOSED-NOT-ADMITTED",
  "architecture_spine_id": "FHS-MSC-MASTER-BLUEPRINT-2026-10-28-vNEXT-02-AUDIT-REPAIR",
  "source_ref": "EXAMPLE_ONLY_NOT_SUBMITTABLE",
  "subject_ref": "EXAMPLE_ONLY_NOT_SUBMITTABLE",
  "producer_original_writer_ref": null,
  "canonical_pipd_refs": {"pi": null, "pd": null, "dev_ecp": null, "ops_ecp": null, "tqaep": null},
  "policy": {"epoch": null, "active_sha": null, "loaded_sha": null},
  "work": {"workorder_ref": null, "effect_class": "READ_ONLY_PROBE", "plan_revision": null},
  "effect_admission": {"required": false, "native_permit_ref": null, "read_scope_ref": null},
  "dispatch": {"lease_ref": null, "generation": null, "os_pid": null},
  "effect": {"operation_id": null, "world_before_sha": null, "world_after_sha": null, "state": "NOT_EXECUTED"},
  "verification": {"oracle_ref": null, "independent_checker_receipt": null},
  "claim_ceiling": "NON_EXECUTABLE_DESIGN_EXAMPLE"
}
```

**負例**：用樣例直接呼叫 `pipd validate`、HGK WorkOrder、Hermes Spawn 或 Model Router 應 `PROPOSED_ABI_NONEXECUTABLE / ORIGINAL_WRITER_UNBOUND`；不得把 `READ_ONLY_PROBE` 中 permit_ref null 當缺權錯誤，但仍須 ReadScope 真授權，且任何 EffectClass 不可消費 null Permit；未查 CLI 真參數不以示例 command 發 live effect。

| 類型 | 精確 NACK/下一合法步驟 | 受影範圍 |
|---|---|---|
| READ_SCOPE_DENIED | 無 L1 ACL，停止該讀取 probe，回現役 ReadScope Owner | only corresponding Reader |
| EFFECT_PERMIT_DENIED | Native Permit revoked/expired/wrong scope/nonce/SID；不能 Spawn | affected native card |
| CANONICAL_WRITER_UNBOUND | Portable draft/PI/PD 非正式；送 PIPD Original Writer | package consumer |
| ORACLE_UNBOUND / PROFILE_AXIS_UNMAPPED | 需 signed/versioned Oracle adapter 與 Loss Ledger，先 fixture | affected formal TQAEP/PI |
| PLAN_ENTRY_UNBOUND | 禁舊 Commander；A/B contract lookup + Owner disposition | proposal-dependent cards |
| CAPABILITY_HOLD | Selected 未 pin/Install/Loaded/Invoke，保留產品義務、僅停 Trigger consumer | selected slot consumers |
| ROUTE_NOFIT | Required/Selected/Served 不匹配，禁止隱藏 fallback | affected lane/card |
| STALE_GENERATION/UNKNOWN_EFFECT | fence old actor、讀 Journal/World 再決定重入 | affected operation |
| CHECKER_NOT_INDEPENDENT | Maker 可改 verdict/同 Principal/無 Raw；正式 PASS 不成立 | acceptance claim |
| RELEASE_NOT_AUTHORIZED | 未 Owner/Publisher 與有效 SourceFreeze，禁止 release，但不阻 L0/L1/L2 | only release path |

## §5｜PIPD 五件與 Oracle/Profile 無損映射、PD late binding（AUD-009/010）

**正式五件不同 Writer Stage**：`PI` 的 atomic requirements/SourceFreeze/Oracle refs；`PD` 的 `RepoContext+HEAD+index/untracked/reparse+platform`; `DEV ECP` 限 Repo Writeset/preimage/rollback；`OPS ECP` 限 Host/User/Policy/Trust/Remote effect；`TQAEP` 只定義 Oracle/fixtures/Runner/Checker expectation，`PLANNED ≠ EXECUTED ≠ INDEPENDENT_PASS`。`ConstructionContract` 是 PIPD Original Writer versioned 中介資料，既不是 FEX 自編 Compiler 也不是 HGK Permit。已正式受准入包若版本一致，直接 reuse，禁止重跑整套 PIPD 造成治理過載。

### 5.1 DOC-07 Oracle Writer vs legacy DOC-03 ABI：雙分支實質可測

原 Canonical Authoring Owner = **PIPD DOC-07**；現有 P4 0.1.1 `acceptance.oracle_source` 歷史字串=`DOC-03 DOMAIN_ORACLES`，目前 `CR-ORACLE-001_OPEN`。必由 PIPD Owner 提供 `OriginalOracleRef{writer_id=DOC07,subject,source_clause_sha,oracle_sha,version,checker_expectation}` → `SignedAlias{from_legacy,canonical_ref,issuer_original_writer,adapter_version,schema_digest,approved_on,scope}` → `CompilerInput.acceptance.oracle_source` + **trace_hash** → `TQAEP.Oracle/FixtureVerfier` 的全鏈 readback。雙向比 `OriginalWriterID/source_clause_sha/subject_sha/oracle_ref/schema_digest`；若尚無 alias，Branch B `ORACLE_UNBOUND` 只 HOLD 受影的 *正式* compiler/TQAEP/Native acceptance，不妨 L1/已無相依合法工程。

| Fixture | 輸入（皆為示意、不得提交） | 輸出/預期（Designer’s Oracle） | 反證 |
|---|---|---|---|
| FEX-PIPD-O-POS | 真 DOC07 Source clause SHA=X，Owner 批准 legacy alias 原/新版與 schema digest，P4 receipt bind same subject S | canonical oracle ref X→legacy field→TQAEP verifier X，roundtrip equality+Reader validity | 禁用「DOC03 字串相同」當 signed alias |
| FEX-PIPD-O-NEG | DOC07 Subject S1，legacy alias S2 或 source clause sha drift/unsigned mapping | ORACLE_UNBOUND, no accepted TQAEP/no effect; Preserve PI/PD unimpacted source | 不准拿歷史 CI green bypass |

### 5.2 DOC06 十二校準風險軸 vs P4 九輸入 enums：LossLedger

Original DOC06 12 個 calibrated complexity axes 與已安裝 P4 輸入 shape 9 enums **是兩個不同維度**，不能以先後欄位數相減即認為原義相等。必逐軸 `axis_id,calibration_version,original_value,risk,owner,source_locator → mapped_p4_enum_or_extension,explicit_rationale,loss_kind,derivation_sha,checker_test`；**12/12 行都必存在**，`unmapped_high_risk>0` 或 `loss_kind=SEMANTIC_LOSS_UNAPPROVED` → `PROFILE_AXIS_UNMAPPED`，不刪風險。沒有 PIPD Owner 當期原版 12 個軸名/9 枚舉 schema 原件時保持 `AXIS_NAME_BIND_HOLD`，不得用臆造欄名填映射。

| Fixture | 輸入 | 預期 Reader 結果 |
|---|---|---|
| FEX-PIPD-P-POS | 12 個真 DOC06 axis each original value+source/owner，P4 9 官方 enum 的 owner-approved crosswalk+extension；每個 high risk 保留成風險限制與附加 Oracle | 12/12 trace complete；9 enum strictly typed；loss ledger 逐項回源；仍需真 original compiler 才可算 native |
| FEX-PIPD-P-NEG | 12 中第 k 個 HIGH risk 無 P4 表示又沒有 extension/Owner reason，或指定 enum 超出 parser schema | PROFILE_AXIS_UNMAPPED, affected formal stage HOLD；no silent default to LOW |

**Reader 狀態階梯**：`DECLARED → APPLICABLE → RUNNER_BOUND (registry ABI/sha/ACL) → EXECUTED (exit/raw bytes) → WORLD_VERIFIED (if effect) → INDEPENDENT_VERIFIED (true principal)`。Original Writer 僅對當期權威簽 canonical; PIPD v1 preview 的 13 CLI/19 schema 不代表本機版本相容。`reasoned_N/A` 一筆至少 `original_clause/trigger_proof/owner/version/evidence/next_reentry`。相同已受准入包未變直接消費；PD Repo HEAD 漂移只 rebind RepoContext、受影 ECP/fixtures，不重寫 PI 原義。

## §6｜Hermes 持久自動化、單人 Owner、Grant/撤銷、Partial Delivery（AUD-012/020/021）

### 6.1 真自動與可回復，不是「同個聊天繼續」

`READY (genuine HGK WorkCard) → atomic CAS lease/generation/fence → Hermes dispatcher persistent wakeup → true OS process PID (binary+SID+start-time) → approved provider/method real invoke → EffectJournal prepare→real world effect→readback/reconcile→Native checkpoint→Protected Checker→eligible reducer`。執行器不持有 Issuer 私鑰，外部 Worker 不能自行把 lease 延展成 Permit。終端 Chat UI 關閉、Worker kill、OS 重啟都不能隱性關閉 SharedSpine 任務；由現役合法 Wakeup/lease reaper 接手，以**新 PID**恢復，先核舊 generation/Nonce/World，再選重試或讀取已產生的效果。`UNKNOWN_EFFECT` 不重播 consumed nonce。

### 6.2 Owner StandingGrant：只有現役 HGK Original Writer 寫得進，Hermes 只讀快取

1. `owner,principal,scope_sha,allowed_effect_class,subject,policy_epoch,max_risk,valid_until,revoke_version,decision_receipt_sha` 由現役 HGK 授權 Registry/Original Writer 真簽；任何過大/無期限/超 Scope 的授權不可當立法設計。
2. `DecisionDedupKey = H(mission|question|subject|scope|effect|risk|policy_epoch|grant_version)` 為 FEX **Reader 索引**，不是信任憑證。由原生 Registry 持久保存合法 Grant Reference/revoke counter；Hermes cache 包含 last validated epoch/receipt，fresh OS PID 重入必 reload 真 Writer State。
3. 新會話同 subject/scope/epoch/TTL → 原 Grant Reader 命中，`owner_prompt_count=0` 且保留 evidence；不同 risk/scope/new Policy Epoch/revoke_version → invalidate cache，Effect 立即拒，直到獲新合法範圍的 OwnerDecisionPack。Maker 無權延展 TTL、篡改撤銷版本或使 Owner 問題無限重複。
4. `OwnerDecisionPack{current_grant_ref,difference/first_fail,scope,why,options,smallest_approval_needed,what_can_continue,expiry,return_gate}` 只生成**一次去重**的必要問題；Owner 決定不得由模型/Adapter 的簽名假代。需要 OS elevation 只在確有該 Effect Class 時問，不要求 L0/L1 通通 Administrator。
5. POS：同 Mission 重啟三次、不同 OS PID、真 registry grant 仍有效，重複問 0 次；NEG：revoke/TTL/new epoch 即拒受影 effect，獨立 B/C 正常推進；`read_scope` 不隨 effect grant 撤銷自動提升。

### 6.3 部分成功 Reducer/Stop Rule

| 觀測狀態（FEX view 非取代 HGK enum） | 真含義及輸出 | 應再喚醒/可用結果 | 不能做 |
|---|---|---|---|
| RUNNING | 存在 eligible leased Worker 或新 phase | 維持原 Native wakeup + checkpoint | chat end = done |
| WAITING_PERMISSION | 特定子圖缺 Effect grant，A PARK | 保存 FirstFail/OwnerDecision；B/C 照跑 | Global HOLD |
| WAITING_BINDING | 缺 ABI/Source/HostSlot，非認定 Host 壞 | W00 discovery/Owner bind 後只喚受影子圖 | 假設已故障或 invented stub |
| NO_ELIGIBLE_READY | 沒有可派工卡，但可能有 PARK/Unknown/依賴 | durable watch/reentry trigger；回報精確等待集合 | 認定 Terminal |
| PARTIAL_DELIVERABLE | 無相依的 WorkCard 已完成且有 Raw、另一些卡受影 HOLD | 用戶收到 bounded output + uncompleted list + next decision；State 保留 | PARTIAL→MISSION_COMPLETE 偷升 |
| TERMINAL_NOFIT | 原 Owner 接受特定 no-fit/Reasoned N/A，無 unresolved required card | 有權終局裁決与 source/policy readback | 普通 NoFit 直接自簽停案 |
| TERMINAL_QUALIFIED | 所有當期適用 required 卡有 exact result/受保護 checker，READY/RUNNING/UNKNOWN=0、合規的 N/A/Owner dispositions | 原生 Gate 合格可交付；正式 Release 仍獨立 | 棄掉非完成卡、改寫原 B1 Gate |

**Reducer 演算法設計規格**：每次根據現役 SharedSpine current snapshot 而非自寫第二 DB，計 `applicable,eligible_ready,running,parked_permission,parked_binding,unknown_effect,verified,accepted_NA` 的明確分母與集合；必要條件有 `unknown_effect==0`、`eligible_ready==0`、`running==0`、`required_unresolved==0`、`same_source/subject/epoch/oracle` 才提出 `TERMINAL_QUALIFIED`。`PARK(A)` 對 DAG 中 *依賴 A* 的節點受影，**不依賴 A** 的 B/C 必在 Owner 指定公平 tick bound 內真取得 lease。State enum 的實際寫回格式需 HGK Owner/Host current schema 對照；沒有就保持 view/read-only，不自建 status writer。

## §7｜FirstFail→KnownFix/FAR 與 FDA 各自原生路徑；四序列≥三輪故障（AUD-011/012/013）

### 7.1 Research Advisor 不是 Native Domain Adapter

**FAR**（Fabric Autonomous Research，Source 專項 U24.1）：只在已具名且有真 Raw 的 `FIRST_FAIL` 與現存 KnownFix `exact/compatible` 無命中時，依 approved budget、source freshness/License/PII 只讀研究，輸出 `ResearchHypothesis,SourceRefs,Tradeoff,ProposedRepair,confidence,first_fail_link`；不 mint Permit/Trust Root、不更動 PolicyActive、不替 Checker簽 PASS。KnownFix 命中應直接用已准入 scoped DEV cone，FAR 的「未呼叫」是正確 nontrigger，而非未完成。

**FDA**（Fabric Desktop Automation／Fabric domain-specific 原生介面，Source 專項 U24.2；**不是 FAR 別名**）：由 Fabric Domain Owner 指定 `domain_event,source_snapshot,host_surface,action_class,current_loader_version,ACL,allowed_effects`；只有透過現有 Fabric/HGK registered Native receiver/OS input gate 才作實際 Desktop/Host Automation，讀取真視窗/物件前後像、window/session/SID、action receipt/Readback，並在錯窗口/foreground drift/未授權 scope `FDA_NATIVE_DENY`。無可定位的當期 FDA Owner/ABI/Host process→`FDA_NATIVE_BIND_HOLD`，可繼續 L0/L1/非 FDA Worker；不可用網頁截圖或 FAR 結果假裝 FDA 效果，**不得另造 FDA Control Service**。U24.3 沿用原有 Policy/Issue/SharedSpine 而非新佇列。

| Trigger/producer | Consumer/真權限 | POS/NEG/first_fail | 回復／退出 |
|---|---|---|---|
| KNOWN_FIX_EXACT Source+Repro+same risk | Hermes DEV admitted Worker | 真 Red old SHA+minimal diff+Green new SHA+Readback+Checker；版本錯拒 | 原 WorkOrder resume，同一 Mission |
| FAR_NEEDED KnownFix miss/risk exceeded | Fabric FAR Research Reader | Source-bound hypothesis+candidate raw；NEG 無 fresh source/研究私自寫 Repo | 有權修補先新 ECP；超 budget PARK |
| FDA_DOMAIN_TRIGGERED Fabric Native event | Fabric/HGK FDA Receiver + actual scoped OS ACL | 真 domain element/action readback+session SID；NEG wrong foreground/Trust/Window | 受影 read-world 後補償另有 Permit；missing ABI HOLD |
| IRREVERSIBLE_EFFECT disputed state | Owner/Domain Receiver | STOP independent readback；NEG timeout redrive consumed nonce | 新補償 ECP + new legal admission (不重用原 nonce) |

### 7.2 一個 FirstFail 的完整修復閉環

`capture original Source/Subject/Policy/RepoHEAD/Raw → reproducible RED failing on old SHA → KnownFix exact compare or bounded FAR → minimal RepairCone + exact WriteSet + current DEV/OPS Admission → apply one reversible patch → GREEN on new SHA → real World/Repo/Host readback → protected same-subject Checker → resume original lease/WorkOrder`。不同結果 `NOT_RUN / BLOCKED_MISSING_BINDING / KNOWN_FAILED / NOFIT / VERIFIED` 不混淆；timeout/partial ACK 不屬安全重送。當類型是 FDA Native Effect，需 FDA Owner Native 授權；FAR 資料建議不能代替實施控制。

### 7.3 長期自動化故障注入 `FEX-T-DUR-MULTI`：每種序列至少 **3 輪**

| Seq | 每輪精確注入點 | 必核 raw 操作 | 預期禁止與回復 |
|---|---|---|---|
| DUR-A | Worker 在 Effect Prepare 前 kill | original PID、lease generation、journal no effect、world preimage、successor **new PID** | 若確定 effect 未發生，原生 admissible retry；old PID fenced |
| DUR-B | Effect 已實施、Ack 未達 Hermes 時 kill/timeout | operation_id,nonce,resource after SHA,Receiver journal,lease,successor PID | 後繼者應讀 after 已 applied、不重新 effect；duplicate_effect=0 |
| DUR-C | Ack 已有但 checkpoint 前 kill/serialize interrupt | durable ack vs checkpoint cursor、new PID 的 check/readback、same Source Epoch | 回復 checkpoint 不造第二 apply；stale_generation_commit=0 |
| DUR-D | lease TTL expiry，舊 Worker 後返回 + concurrent B/C | lease CAS old/new gen, old Worker late ack, ready_age B/C, owner prompt count | 舊 gen commit DENY；B/C 獨立推進；未知 effect reconcile |

**計數分母**：四序列×至少三輪（**12 個有真 OS PID 的 Round**；不能用 12 個純 fixture 當 Native），每輪 `trial_id,subject_sha,policy_epoch,real_pid_before/after,Lease/generation,nonce,operation,world before/after,checker_raw,exit/error,elapsed_ms,owner_prompts,independent_BC_progress`。每輪核 `duplicate_effect_count=0`, `stale_gen_commit_count=0`, `B/C unblocked progress=true`; 三輪以不同時序交錯/timeout/partial ack 可重現。`max_lease_ttl,crash_recovery_p95,MAX_RETRIES,latency_budget` 不假造數值，必 Owner measured baseline+same hardware/model/risk 時才設定，否則 `MEASUREMENT_BASELINE_HOLD`。試圖重送 consumed nonce 應 Native DENY，不是重新算 PASS。

### 7.4 `FEX-T-GB-01` 外援撤銷→原生恢復（不另造 G-C）

原 G-B 原體系 ID、Gate/Owner 不改。測序：真 helper token revoke 及 revocation_version 讀回 → 試舊外援 Actor/credential 的下一個 Spawn **必在 effect 前 NACK** → 原 Hermès/HGK SharedSpine 保留 READY 卡 → legitimate native successor **不同 OS PID/Session** 取得新准入 scope/lease → 實際 world readback → 原獨立 Checker principal 查 same Subject/Epoch → 紀錄 no duplicated effect/ready aging and signed raw。任缺件只 `G-B_NATIVENESS_UNVERIFIED`，不能將 B1 Repo historical PASS 當本次 G-B PASS。

## R2-06-ACTUAL-SOURCE：當期HGK Spine源碼接口

已實讀 `C:\Projects\Agent_Workspace\HG-KSEOS\src\hg_kseos\spine.py`，SHA `f99a402123f39b8ceaad9372aeec0555628ba643950a5c99a4c917fd9e6d6dcd`。以下是當期工作樹AST讀回，未匯入模組、未開世界資料庫、未調用任何mutation。

| source symbol:line | actual signature | actual source guard/readback |
|---|---|---|
| _open:60 | self | return connection |
| acquire_lease:128 | self, resource_id: str, holder: str, token: str, ttl_seconds: int=300 | raise LeaseConflict(f"ERR_DUAL_WRITER:{resource_id}:{existing['holder']}") |
| release_lease:148 | self, resource_id: str, holder: str, token: str | """Release a lease and return a typed receipt.; raise LeaseConflict(f"ERR_LEASE_RELEASE_AUTH:{resource_id}"); return {"schema": "HGK-LEASE-RELEASE/1", "released": True, "resource_id": resource_id, |
| _assert_lease:165 | self, connection: sqlite3.Connection, resource_id: str, holder: str, token: str | raise LeaseConflict(f"ERR_LEASE_REQUIRED:{resource_id}"); raise LeaseConflict(f"ERR_LEASE_EXPIRED:{resource_id}") |
| transition_requirement:215 | self, requirement_id: str, to_state: str, actor: str, token: str, expected_version: int, evidence_ref: str, idempotency_key: str, payload: dict[str, Any] &#124; None=None | raise InvariantViolation(f"ERR_REQUIREMENT_UNKNOWN:{requirement_id}"); return dict(duplicate) &#124; {"idempotent_replay": True}; raise StaleState(; if to_state not in allowed:; raise InvariantViolation(f"ERR_ILLEGAL_TRANSITION:{prior['state']}->{to_state}"); raise StaleState(f"ERR_CONCURRENT_UPDATE:{requirement_id}"); return {"event_id": event_id, "resulting_version": resulting_version, "to_state": to_state} |
| resolve_acceptance:460 | self, acceptance_id: str, *, verdict: str, evidence_ref: str, actor: str, token: str, expected_version: int, idempotency_key: str, requirement_id: str &#124; None=None, payload: dict[str, Any] &#124; None=None | raise InvariantViolation(f"ERR_ACCEPTANCE_VERDICT:{verdict}"); raise InvariantViolation("ERR_ACCEPTANCE_CRITICAL_FIELD_MISSING"); raise InvariantViolation("ERR_ACCEPTANCE_SUBJECT_BINDING_REQUIRED"); raise InvariantViolation(f"ERR_ACCEPTANCE_UNKNOWN:{acceptance_id}"); raise InvariantViolation(; raise InvariantViolation(f"ERR_ACCEPTANCE_EVIDENCE_UNKNOWN:{evidence_ref}"); raise InvariantViolation(; return {"event_id": spent["event_id"], "resulting_version": spent["resulting_version"],; if from_state not in TRANSITIONS["acceptance"] or verdict not in \; raise InvariantViolation(f"ERR_ACCEPTANCE_ILLEGAL_TRANSITION:{from_state}->{verdict}"); live_version = 0 if from_state == "NOT_RUN" else 1; raise StaleState(; raise StaleState(f"ERR_ACCEPTANCE_CONCURRENT_UPDATE:{acceptance_id}"); return {"event_id": event_id, "resulting_version": live_version + 1, |

`TRANSITIONS`實際task states含DRAFT/ADMITTED/RUNNING/REPAIR/VERIFIED/PACKAGED/REJECTED/FAILED/CANCELLED；requirement另有CANDIDATE/FROZEN/IMPLEMENTED/VERIFIED/REPAIR/ACCEPTED/REJECTED/ROLLED_BACK；acceptance為NOT_RUN→PASS或FAIL。這三套不得互換。概念READY是dependency+admission可執行predicate，不能寫成這份Native enum。

Proposal→native設計綁定：PLAN_CANDIDATE只對應DRAFT候選，真Admission後才是ADMITTED；worker start要原task transition合法至RUNNING；無法直接對應的UNKNOWN effect、lease_generation、WakeEndpoint維持Adapter ABI_HOLD，不以自造欄位塞原serializer。source acquire_lease實際signature是resource_id/holder/token/ttl_seconds，不宣稱它已具本候選generation欄。expected_version/idempotency_key是transition_requirement原參數；重試必照原API及world reconciliation。

POS設計：同resource有效holder/token與expected_version才能transit，duplicate idempotency_key回原event。NEG：dual writer→ERR_DUAL_WRITER；wrong holder/token→ERR_LEASE_REQUIRED；expired→ERR_LEASE_EXPIRED；錯to_state→ERR_ILLEGAL_TRANSITION；version drift→StaleState。這些是源碼guard讀回，沒有當期World Raw就不是執行結果。Wake/Runtime原Owner需提供現役endpoint和loadedSHA後才解除受影ABI_HOLD。
