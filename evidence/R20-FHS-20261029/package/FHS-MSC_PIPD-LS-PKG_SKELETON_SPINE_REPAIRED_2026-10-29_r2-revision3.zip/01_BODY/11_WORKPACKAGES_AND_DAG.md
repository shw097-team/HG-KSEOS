---
artifact_id: FHS-MSC-R2-BODY-11
formal_name: 22 WorkPackage 的 typed DAG、Done 與回復
short_name: BODY-11
version: 2026-10-29-r2-revision2
source_set_hash_or_pending: f86b217ae3c3ee28183570f4bf3d4f08d4d00e9b86d1de1a641a630f8682d1a1
intended_consumer: 原領域 Owner 與下游 Reader
owner_role: 作者端規格修補者；原 Domain Writer 不移轉
design_status: SOURCE_BOUND_REPAIR_CANDIDATE
claim_ceiling: AUTHOR_STATIC_ONLY; NATIVE_NOT_RUN; CHECKER_NOT_RUN; RELEASE_NOT_RUN
supersession_scope: 本輪作者候選revision2；保留前版封存；不取代任何原Canonical Writer版本
AUDIT_F_IDs:
- F-01
- F-04
- F-26
---

# 22 WorkPackage 的 typed DAG、Done 與回復

## R2-11-GRAPH：22 WP 與兩條合法起跑

DISCOVERY 都是 SOURCE_READ，不要求 effect receipt。WP17 的 Host install 僅走既有 Issuer+installer（WP02/03），不能依賴 WP06；WP06 要求 needed capability qualified 後才啟動首 effect。若既有 admitted work 的同 scope receipt 有效，直接 resume 原 Queue，不重走這個新包 DAG。

### WP-FHS-00｜Source/Host Discovery

- Trigger/input：普通 Goal/當期唯讀發現。
- tier/effect：L1/SOURCE_READ；permission：原唯讀 ACL/read scope。
- 轉換：Source/Host Discovery 依本冊已列 typed input/output 完成專用轉換
- typed output/consumer：SourceManifest+RepoContext → 原領域 Consumer（缺 Registry 為 ABI_BIND_HOLD）。
- WriteSet：空，world diff=0。
- Done：讀取 hash/時間/來源及讀取錯誤；world diff=0；本 WP 的 SourceManifest+RepoContext 不可用 sibling receipt 代用。
- POS：根路徑/HEAD/index/untracked/bytes SHA當期可讀。NEG：README或junction別名冒真root → `WP-FHS-00.FIRST_FAIL` / `ROOT_CURRENTNESS_NOT_PROVEN`；只停受影card。
- rollback/exit：丟棄快照重讀；不要求 Permit 或卸載收據；resume：重讀前提與 preimage，重新准入受影 scope。

### WP-FHS-01｜Authority/Oracle/Profile

- Trigger/input：WP-FHS-00 的同 Scope 產物；原 receipt 有效可重用。
- tier/effect：L1/SOURCE_READ；permission：原唯讀 ACL/read scope。
- 轉換：Authority/Oracle/Profile 依本冊已列 typed input/output 完成專用轉換
- typed output/consumer：AuthorityConflictLedger+Oracle/ProfileBinding → 原領域 Consumer（缺 Registry 為 ABI_BIND_HOLD）。
- WriteSet：空，world diff=0。
- Done：讀取 hash/時間/來源及讀取錯誤；world diff=0；本 WP 的 AuthorityConflictLedger+Oracle/ProfileBinding 不可用 sibling receipt 代用。
- POS：原Authority/Oracle/Profile衝突被明列而未偷偷promotion。NEG：九enum直接當十二軸分數 → `WP-FHS-01.FIRST_FAIL` / `PROFILE_OR_ORACLE_BIND_HOLD`；只停受影card。
- rollback/exit：丟棄快照重讀；不要求 Permit 或卸載收據；resume：重讀前提與 preimage，重新准入受影 scope。

### WP-FHS-02｜Fabric Policy Consumer

- Trigger/input：WP-FHS-01 的同 Scope 產物；原 receipt 有效可重用。
- tier/effect：L3/HOST_OP；permission：OPS ECP + Host Owner/Issuer + nonce/TTL/epoch。
- 轉換：Fabric Policy Consumer 依本冊已列 typed input/output 完成專用轉換
- typed output/consumer：PolicyLoadedConsumerACK → 原領域 Consumer（缺 Registry 為 ABI_BIND_HOLD）。
- WriteSet：原 Owner 晚綁 exact 檔案/Host target；禁止 **、..、跨 root；未綁不得 effect。
- Done：真 Host LoadedSHA/consumer ACK/卸載或復原 readback；本 WP 的 PolicyLoadedConsumerACK 不可用 sibling receipt 代用。
- POS：Source/Stage/Approve/Active/Loaded/Consumer各自hash同scope。NEG：Stage文件冒Loaded ACK → `WP-FHS-02.FIRST_FAIL` / `POLICY_NOT_LOADED`；只停受影card。
- rollback/exit：原 Host restore/unload；UNKNOWN 先 reconcile，殘留列表交 Owner；resume：重讀前提與 preimage，重新准入受影 scope。

### WP-FHS-03｜HGK Registry/Issuer

- Trigger/input：WP-FHS-01 的同 Scope 產物；原 receipt 有效可重用。
- tier/effect：L3/HOST_OP；permission：OPS ECP + Host Owner/Issuer + nonce/TTL/epoch。
- 轉換：HGK Registry/Issuer 依本冊已列 typed input/output 完成專用轉換
- typed output/consumer：IssuerReceiverBinding → 原領域 Consumer（缺 Registry 為 ABI_BIND_HOLD）。
- WriteSet：原 Owner 晚綁 exact 檔案/Host target；禁止 **、..、跨 root；未綁不得 effect。
- Done：真 Host LoadedSHA/consumer ACK/卸載或復原 readback；本 WP 的 IssuerReceiverBinding 不可用 sibling receipt 代用。
- POS：原Receiver/Issuer registry同epoch與scope。NEG：候選ECP冒Permit → `WP-FHS-03.FIRST_FAIL` / `ISSUER_BINDING_INVALID`；只停受影card。
- rollback/exit：原 Host restore/unload；UNKNOWN 先 reconcile，殘留列表交 Owner；resume：重讀前提與 preimage，重新准入受影 scope。

### WP-FHS-04｜Hermes Durable Runtime

- Trigger/input：WP-FHS-00 的同 Scope 產物；原 receipt 有效可重用。
- tier/effect：L3/HOST_OP；permission：OPS ECP + Host Owner/Issuer + nonce/TTL/epoch。
- 轉換：Hermes Durable Runtime 依本冊已列 typed input/output 完成專用轉換
- typed output/consumer：WakeLeaseRuntimeBinding → 原領域 Consumer（缺 Registry 為 ABI_BIND_HOLD）。
- WriteSet：原 Owner 晚綁 exact 檔案/Host target；禁止 **、..、跨 root；未綁不得 effect。
- Done：真 Host LoadedSHA/consumer ACK/卸載或復原 readback；本 WP 的 WakeLeaseRuntimeBinding 不可用 sibling receipt 代用。
- POS：原Journal/Wake/Lease schema及checkpoint可讀。NEG：新增第二Queue或舊generation commit → `WP-FHS-04.FIRST_FAIL` / `RUNTIME_LEASE_BINDING_DENY`；只停受影card。
- rollback/exit：原 Host restore/unload；UNKNOWN 先 reconcile，殘留列表交 Owner；resume：重讀前提與 preimage，重新准入受影 scope。

### WP-FHS-05｜PIPD Native Compiler

- Trigger/input：WP-FHS-01 的同 Scope 產物；原 receipt 有效可重用。
- tier/effect：L0/LOCAL_DRAFT_WRITE；permission：明列隔離 output root 的使用者授權。
- 轉換：PIPD Native Compiler 依本冊已列 typed input/output 完成專用轉換
- typed output/consumer：PI/PD/DEV-OPS候選 → 原領域 Consumer（缺 Registry 為 ABI_BIND_HOLD）。
- WriteSet：原 Owner 晚綁 exact 檔案/Host target；禁止 **、..、跨 root；未綁不得 effect。
- Done：新檔 UTF8/LF/hash/readback；原來源 hash 不變；本 WP 的 PI/PD/DEV-OPS候選 不可用 sibling receipt 代用。
- POS：PI語義/PD scope/DEV-OPS分路與strict input一致。NEG：sidecar塞strict payload或expected當Raw → `WP-FHS-05.FIRST_FAIL` / `PIPD_FORMAL_PROMOTION_HOLD`；只停受影card。
- rollback/exit：回復本輪 preimage 或刪本輪新檔；不刪他人產物；resume：重讀前提與 preimage，重新准入受影 scope。

### WP-FHS-06｜Legal First Reversible Slice

- Trigger/input：WP-FHS-02, WP-FHS-03, WP-FHS-04, WP-FHS-05, WP-FHS-17 的同 Scope 產物；原 receipt 有效可重用。
- tier/effect：L2/REPO_WRITE；permission：DEV ECP + exact WriteSet + 原 HGK admission。
- 轉換：Legal First Reversible Slice 依本冊已列 typed input/output 完成專用轉換
- typed output/consumer：最小可逆Repo diff+Raw → 原領域 Consumer（缺 Registry 為 ABI_BIND_HOLD）。
- WriteSet：原 Owner 晚綁 exact 檔案/Host target；禁止 **、..、跨 root；未綁不得 effect。
- Done：pre/post HEAD/diff/test/raw/受影 residue；本 WP 的 最小可逆Repo diff+Raw 不可用 sibling receipt 代用。
- POS：needed capability qualified後在exact Repo scope取得可逆diff/Raw。NEG：WP17尚未具能力就發首effect → `WP-FHS-06.FIRST_FAIL` / `FIRST_EFFECT_CAPABILITY_MISSING`；只停受影card。
- rollback/exit：原 preimage inverse patch；HEAD 漂移先停，不能 reset 他人變更；resume：重讀前提與 preimage，重新准入受影 scope。

### WP-FHS-07｜Native PLAN Commander A/B/C

- Trigger/input：WP-FHS-01, WP-FHS-15 的同 Scope 產物；原 receipt 有效可重用。
- tier/effect：L0/LOCAL_DRAFT_WRITE；permission：明列隔離 output root 的使用者授權。
- 轉換：Native PLAN Commander A/B/C 依本冊已列 typed input/output 完成專用轉換
- typed output/consumer：PlanRevisionProposal+CAS ACK → 原領域 Consumer（缺 Registry 為 ABI_BIND_HOLD）。
- WriteSet：原 Owner 晚綁 exact 檔案/Host target；禁止 **、..、跨 root；未綁不得 effect。
- Done：新檔 UTF8/LF/hash/readback；原來源 hash 不變；本 WP 的 PlanRevisionProposal+CAS ACK 不可用 sibling receipt 代用。
- POS：A只讀/B隔離proposal使用原PLAN CAS Reader。NEG：要求先有同WO permit才能規劃或呼叫legacy SP → `WP-FHS-07.FIRST_FAIL` / `COMMANDER_BOOTSTRAP_INVERSION`；只停受影card。
- rollback/exit：回復本輪 preimage 或刪本輪新檔；不刪他人產物；resume：重讀前提與 preimage，重新准入受影 scope。

### WP-FHS-08｜FHS Execute Worker

- Trigger/input：WP-FHS-06, WP-FHS-07 的同 Scope 產物；原 receipt 有效可重用。
- tier/effect：L3/HOST_OP；permission：OPS ECP + Host Owner/Issuer + nonce/TTL/epoch。
- 轉換：FHS Execute Worker 依本冊已列 typed input/output 完成專用轉換
- typed output/consumer：WorkerEffectRaw+JournalCursor → 原領域 Consumer（缺 Registry 為 ABI_BIND_HOLD）。
- WriteSet：原 Owner 晚綁 exact 檔案/Host target；禁止 **、..、跨 root；未綁不得 effect。
- Done：真 Host LoadedSHA/consumer ACK/卸載或復原 readback；本 WP 的 WorkerEffectRaw+JournalCursor 不可用 sibling receipt 代用。
- POS：已admitted WorkID單一lease以Worker真PID完成本operation。NEG：timeout同nonce盲replay → `WP-FHS-08.FIRST_FAIL` / `EFFECT_REPLAY_DENY`；只停受影card。
- rollback/exit：原 Host restore/unload；UNKNOWN 先 reconcile，殘留列表交 Owner；resume：重讀前提與 preimage，重新准入受影 scope。

### WP-FHS-09｜Challenge/Protected AO

- Trigger/input：WP-FHS-08, WP-FHS-21 的同 Scope 產物；原 receipt 有效可重用。
- tier/effect：L1/SOURCE_READ；permission：原唯讀 ACL/read scope。
- 轉換：Challenge/Protected AO 依本冊已列 typed input/output 完成專用轉換
- typed output/consumer：ProtectedCheckerRequest/Receipt（需另一主體） → 原領域 Consumer（缺 Registry 為 ABI_BIND_HOLD）。
- WriteSet：空，world diff=0。
- Done：讀取 hash/時間/來源及讀取錯誤；world diff=0；本 WP 的 ProtectedCheckerRequest/Receipt（需另一主體） 不可用 sibling receipt 代用。
- POS：真Raw與原Oracle交不同principal受保護Reader。NEG：Maker自簽PASS或借sibling verdict → `WP-FHS-09.FIRST_FAIL` / `SELF_ACCEPTANCE_DENY`；只停受影card。
- rollback/exit：丟棄快照重讀；不要求 Permit 或卸載收據；resume：重讀前提與 preimage，重新准入受影 scope。

### WP-FHS-10｜B1 3 GWO & G-A/G-B

- Trigger/input：WP-FHS-09, WP-FHS-20 的同 Scope 產物；原 receipt 有效可重用。
- tier/effect：L3/HOST_OP；permission：OPS ECP + Host Owner/Issuer + nonce/TTL/epoch。
- 轉換：B1 3 GWO & G-A/G-B 依本冊已列 typed input/output 完成專用轉換
- typed output/consumer：三GWO各自Raw+G-A/G-B → 原領域 Consumer（缺 Registry 為 ABI_BIND_HOLD）。
- WriteSet：原 Owner 晚綁 exact 檔案/Host target；禁止 **、..、跨 root；未綁不得 effect。
- Done：真 Host LoadedSHA/consumer ACK/卸載或復原 readback；本 WP 的 三GWO各自Raw+G-A/G-B 不可用 sibling receipt 代用。
- POS：Fabric/HGK/SBL三GWO各自effect與G-A/G-B證據。NEG：一個GWO冒其餘兩個 → `WP-FHS-10.FIRST_FAIL` / `GWO_EVIDENCE_JOIN_INCOMPLETE`；只停受影card。
- rollback/exit：原 Host restore/unload；UNKNOWN 先 reconcile，殘留列表交 Owner；resume：重讀前提與 preimage，重新准入受影 scope。

### WP-FHS-11｜Portable Host Dogfood

- Trigger/input：WP-FHS-05, WP-FHS-16 的同 Scope 產物；原 receipt 有效可重用。
- tier/effect：L3/HOST_OP；permission：OPS ECP + Host Owner/Issuer + nonce/TTL/epoch。
- 轉換：Portable Host Dogfood 依本冊已列 typed input/output 完成專用轉換
- typed output/consumer：三SP逐Host loaded/invoked raw → 原領域 Consumer（缺 Registry 為 ABI_BIND_HOLD）。
- WriteSet：原 Owner 晚綁 exact 檔案/Host target；禁止 **、..、跨 root；未綁不得 effect。
- Done：真 Host LoadedSHA/consumer ACK/卸載或復原 readback；本 WP 的 三SP逐Host loaded/invoked raw 不可用 sibling receipt 代用。
- POS：每Portable SP的Host install/load/invoke/nontrigger/remove。NEG：一SP安裝receipt當三SP9/9 → `WP-FHS-11.FIRST_FAIL` / `HOST_SP_MATRIX_INCOMPLETE`；只停受影card。
- rollback/exit：原 Host restore/unload；UNKNOWN 先 reconcile，殘留列表交 Owner；resume：重讀前提與 preimage，重新准入受影 scope。

### WP-FHS-12｜W18 Normal Mode

- Trigger/input：WP-FHS-10, WP-FHS-11 的同 Scope 產物；原 receipt 有效可重用。
- tier/effect：L3/HOST_OP；permission：OPS ECP + Host Owner/Issuer + nonce/TTL/epoch。
- 轉換：W18 Normal Mode 依本冊已列 typed input/output 完成專用轉換
- typed output/consumer：新PID普通Goal E33-E42 Raw → 原領域 Consumer（缺 Registry 為 ABI_BIND_HOLD）。
- WriteSet：原 Owner 晚綁 exact 檔案/Host target；禁止 **、..、跨 root；未綁不得 effect。
- Done：真 Host LoadedSHA/consumer ACK/卸載或復原 readback；本 WP 的 新PID普通Goal E33-E42 Raw 不可用 sibling receipt 代用。
- POS：新PID普通Goal正式Profile/ToolAutoSelect/真served且test-only移除。NEG：B1專用Prompt或test plugin充NormalMode → `WP-FHS-12.FIRST_FAIL` / `NORMAL_MODE_NOT_QUALIFIED`；只停受影card。
- rollback/exit：原 Host restore/unload；UNKNOWN 先 reconcile，殘留列表交 Owner；resume：重讀前提與 preimage，重新准入受影 scope。

### WP-FHS-13｜CAP On-Demand + HotSwap

- Trigger/input：WP-FHS-16, WP-FHS-17 的同 Scope 產物；原 receipt 有效可重用。
- tier/effect：L3/HOST_OP；permission：OPS ECP + Host Owner/Issuer + nonce/TTL/epoch。
- 轉換：CAP On-Demand + HotSwap 依本冊已列 typed input/output 完成專用轉換
- typed output/consumer：CAP gap/HotSwap parity+readback → 原領域 Consumer（缺 Registry 為 ABI_BIND_HOLD）。
- WriteSet：原 Owner 晚綁 exact 檔案/Host target；禁止 **、..、跨 root；未綁不得 effect。
- Done：真 Host LoadedSHA/consumer ACK/卸載或復原 readback；本 WP 的 CAP gap/HotSwap parity+readback 不可用 sibling receipt 代用。
- POS：needed CAP走原route且替代Parity同原功能。NEG：熱替代Issuer或以選型當invoke → `WP-FHS-13.FIRST_FAIL` / `CAPABILITY_PARITY_NOT_PROVEN`；只停受影card。
- rollback/exit：原 Host restore/unload；UNKNOWN 先 reconcile，殘留列表交 Owner；resume：重讀前提與 preimage，重新准入受影 scope。

### WP-FHS-14｜Release/Retire Candidate

- Trigger/input：WP-FHS-09, WP-FHS-19 的同 Scope 產物；原 receipt 有效可重用。
- tier/effect：L4/RELEASE；permission：原 Publisher/GHP-02 + 受保護 Checker。
- 轉換：Release/Retire Candidate 依本冊已列 typed input/output 完成專用轉換
- typed output/consumer：ReleaseCandidate+原Publisher receipt → 原領域 Consumer（缺 Registry 為 ABI_BIND_HOLD）。
- WriteSet：原 Owner 晚綁 exact 檔案/Host target；禁止 **、..、跨 root；未綁不得 effect。
- Done：release id/signature/實際 channel readback；本 WP 的 ReleaseCandidate+原Publisher receipt 不可用 sibling receipt 代用。
- POS：供應鏈+受保護驗收+原Publisher/GHP-02實際readback。NEG：CI/作者檔案封裝冒Release → `WP-FHS-14.FIRST_FAIL` / `RELEASE_NOT_AUTHORIZED`；只停受影card。
- rollback/exit：由原 Publisher 撤回或新版更正；歷史收據不可抹除；resume：重讀前提與 preimage，重新准入受影 scope。

### WP-FHS-15｜TPM Corpus & SPEC 18Stage

- Trigger/input：WP-FHS-00 的同 Scope 產物；原 receipt 有效可重用。
- tier/effect：L0/LOCAL_DRAFT_WRITE；permission：明列隔離 output root 的使用者授權。
- 轉換：TPM Corpus & SPEC 18Stage 依本冊已列 typed input/output 完成專用轉換
- typed output/consumer：三SPEC+18stage trace → 原領域 Consumer（缺 Registry 為 ABI_BIND_HOLD）。
- WriteSet：原 Owner 晚綁 exact 檔案/Host target；禁止 **、..、跨 root；未綁不得 effect。
- Done：新檔 UTF8/LF/hash/readback；原來源 hash 不變；本 WP 的 三SPEC+18stage trace 不可用 sibling receipt 代用。
- POS：24 base docs真hash Reader與18 Stage三SPEC具來源。NEG：要求重新上傳內建DOC或T4/T5自升正式 → `WP-FHS-15.FIRST_FAIL` / `TPM_SOURCE_STAGE_GUARD`；只停受影card。
- rollback/exit：回復本輪 preimage 或刪本輪新檔；不刪他人產物；resume：重讀前提與 preimage，重新准入受影 scope。

### WP-FHS-16｜Donor/Method Slot Translation

- Trigger/input：WP-FHS-00 的同 Scope 產物；原 receipt 有效可重用。
- tier/effect：L0/LOCAL_DRAFT_WRITE；permission：明列隔離 output root 的使用者授權。
- 轉換：Donor/Method Slot Translation 依本冊已列 typed input/output 完成專用轉換
- typed output/consumer：24slot/25method壓製候選 → 原領域 Consumer（缺 Registry 為 ABI_BIND_HOLD）。
- WriteSet：原 Owner 晚綁 exact 檔案/Host target；禁止 **、..、跨 root；未綁不得 effect。
- Done：新檔 UTF8/LF/hash/readback；原來源 hash 不變；本 WP 的 24slot/25method壓製候選 不可用 sibling receipt 代用。
- POS：24槽/25方法依原disposition產特定輸出且方法不假installer。NEG：REFERENCE_ONLY自動安裝 → `WP-FHS-16.FIRST_FAIL` / `DONOR_METHOD_DISPOSITION_DENY`；只停受影card。
- rollback/exit：回復本輪 preimage 或刪本輪新檔；不刪他人產物；resume：重讀前提與 preimage，重新准入受影 scope。

### WP-FHS-17｜CAP-BOOT Native Occupants

- Trigger/input：WP-FHS-00, WP-FHS-02, WP-FHS-03 的同 Scope 產物；原 receipt 有效可重用。
- tier/effect：L3/HOST_OP；permission：OPS ECP + Host Owner/Issuer + nonce/TTL/epoch。
- 轉換：CAP-BOOT Native Occupants 依本冊已列 typed input/output 完成專用轉換
- typed output/consumer：needed能力最小HostOccupant+loaded ACK → 原領域 Consumer（缺 Registry 為 ABI_BIND_HOLD）。
- WriteSet：原 Owner 晚綁 exact 檔案/Host target；禁止 **、..、跨 root；未綁不得 effect。
- Done：真 Host LoadedSHA/consumer ACK/卸載或復原 readback；本 WP 的 needed能力最小HostOccupant+loaded ACK 不可用 sibling receipt 代用。
- POS：現有Issuer合法installer先建needed occupant再驗LoadedSHA。NEG：依WP06才准WP17形成循環 → `WP-FHS-17.FIRST_FAIL` / `CAP_BOOT_DEPENDENCY_INVERSION`；只停受影card。
- rollback/exit：原 Host restore/unload；UNKNOWN 先 reconcile，殘留列表交 Owner；resume：重讀前提與 preimage，重新准入受影 scope。

### WP-FHS-18｜FAR Bounded Repair & Incident

- Trigger/input：WP-FHS-08 的同 Scope 產物；原 receipt 有效可重用。
- tier/effect：L2/REPO_WRITE；permission：DEV ECP + exact WriteSet + 原 HGK admission。
- 轉換：FAR Bounded Repair & Incident 依本冊已列 typed input/output 完成專用轉換
- typed output/consumer：BoundedRepairDiff+RedGreen+residue → 原領域 Consumer（缺 Registry 為 ABI_BIND_HOLD）。
- WriteSet：原 Owner 晚綁 exact 檔案/Host target；禁止 **、..、跨 root；未綁不得 effect。
- Done：pre/post HEAD/diff/test/raw/受影 residue；本 WP 的 BoundedRepairDiff+RedGreen+residue 不可用 sibling receipt 代用。
- POS：first_fail最小cone在原Oracle Red→Patch→Green且budget有界。NEG：擴scope/改Oracle或刪舊失敗Raw → `WP-FHS-18.FIRST_FAIL` / `REPAIR_SCOPE_DENY`；只停受影card。
- rollback/exit：原 preimage inverse patch；HEAD 漂移先停，不能 reset 他人變更；resume：重讀前提與 preimage，重新准入受影 scope。

### WP-FHS-19｜CI/Supply Chain & Requal

- Trigger/input：WP-FHS-00 的同 Scope 產物；原 receipt 有效可重用。
- tier/effect：L1/SOURCE_READ；permission：原唯讀 ACL/read scope。
- 轉換：CI/Supply Chain & Requal 依本冊已列 typed input/output 完成專用轉換
- typed output/consumer：CI/License/NOTICE/SBOM掃描Raw → 原領域 Consumer（缺 Registry 為 ABI_BIND_HOLD）。
- WriteSet：空，world diff=0。
- Done：讀取 hash/時間/來源及讀取錯誤；world diff=0；本 WP 的 CI/License/NOTICE/SBOM掃描Raw 不可用 sibling receipt 代用。
- POS：license/NOTICE/SBOM/dependency/secret輸出與同candidate可回算。NEG：未執行掃描以名字充通過 → `WP-FHS-19.FIRST_FAIL` / `SUPPLY_CHAIN_EVIDENCE_MISSING`；只停受影card。
- rollback/exit：丟棄快照重讀；不要求 Permit 或卸載收據；resume：重讀前提與 preimage，重新准入受影 scope。

### WP-FHS-20｜CLI/Agent/Host Kind Matrix

- Trigger/input：WP-FHS-05, WP-FHS-16 的同 Scope 產物；原 receipt 有效可重用。
- tier/effect：L3/HOST_OP；permission：OPS ECP + Host Owner/Issuer + nonce/TTL/epoch。
- 轉換：CLI/Agent/Host Kind Matrix 依本冊已列 typed input/output 完成專用轉換
- typed output/consumer：192Cell適用/NoFit/Host Raw → 原領域 Consumer（缺 Registry 為 ABI_BIND_HOLD）。
- WriteSet：原 Owner 晚綁 exact 檔案/Host target；禁止 **、..、跨 root；未綁不得 effect。
- Done：真 Host LoadedSHA/consumer ACK/卸載或復原 readback；本 WP 的 192Cell適用/NoFit/Host Raw 不可用 sibling receipt 代用。
- POS：192組合每Host/Mode/Provider具本cell Raw或明確NoFit。NEG：Hermes Raw借Claude/DeepSeek → `WP-FHS-20.FIRST_FAIL` / `HOST_CELL_EVIDENCE_FOREIGN`；只停受影card。
- rollback/exit：原 Host restore/unload；UNKNOWN 先 reconcile，殘留列表交 Owner；resume：重讀前提與 preimage，重新准入受影 scope。

### WP-FHS-21｜Challenge 96/H4/SEAM Coverage

- Trigger/input：WP-FHS-01 的同 Scope 產物；原 receipt 有效可重用。
- tier/effect：L1/SOURCE_READ；permission：原唯讀 ACL/read scope。
- 轉換：Challenge 96/H4/SEAM Coverage 依本冊已列 typed input/output 完成專用轉換
- typed output/consumer：96Cell/H4/SEAM原Oracle計畫 → 原領域 Consumer（缺 Registry 為 ABI_BIND_HOLD）。
- WriteSet：空，world diff=0。
- Done：讀取 hash/時間/來源及讀取錯誤；world diff=0；本 WP 的 96Cell/H4/SEAM原Oracle計畫 不可用 sibling receipt 代用。
- POS：96cell及H4/SEAM按原predicate/校準逐格Reader可判。NEG：同一generic fixture聲稱全部已實測 → `WP-FHS-21.FIRST_FAIL` / `ORACLE_CELL_NOT_PROVEN`；只停受影card。
- rollback/exit：丟棄快照重讀；不要求 Permit 或卸載收據；resume：重讀前提與 preimage，重新准入受影 scope。

## 可解析 adjacency

```json
{
  "schema": "AUTHOR.DesignTypedDAG/1",
  "native_authority": false,
  "nodes": [
    {
      "id": "WP-FHS-00",
      "name": "Source/Host Discovery",
      "phase": "DESIGN_OR_BIND",
      "tier": "L1",
      "effect_class": "SOURCE_READ",
      "depends_on": [],
      "output": "SourceManifest+RepoContext",
      "permission_basis": "原唯讀 ACL/read scope",
      "write_set": [],
      "native_status": "NATIVE_NOT_RUN",
      "positive": "根路徑/HEAD/index/untracked/bytes SHA當期可讀",
      "negative": "README或junction別名冒真root",
      "first_fail": "WP-FHS-00.FIRST_FAIL:ROOT_CURRENTNESS_NOT_PROVEN"
    },
    {
      "id": "WP-FHS-01",
      "name": "Authority/Oracle/Profile",
      "phase": "DESIGN_OR_BIND",
      "tier": "L1",
      "effect_class": "SOURCE_READ",
      "depends_on": [
        "WP-FHS-00"
      ],
      "output": "AuthorityConflictLedger+Oracle/ProfileBinding",
      "permission_basis": "原唯讀 ACL/read scope",
      "write_set": [],
      "native_status": "NATIVE_NOT_RUN",
      "positive": "原Authority/Oracle/Profile衝突被明列而未偷偷promotion",
      "negative": "九enum直接當十二軸分數",
      "first_fail": "WP-FHS-01.FIRST_FAIL:PROFILE_OR_ORACLE_BIND_HOLD"
    },
    {
      "id": "WP-FHS-02",
      "name": "Fabric Policy Consumer",
      "phase": "DESIGN_OR_BIND",
      "tier": "L3",
      "effect_class": "HOST_OP",
      "depends_on": [
        "WP-FHS-01"
      ],
      "output": "PolicyLoadedConsumerACK",
      "permission_basis": "OPS ECP + Host Owner/Issuer + nonce/TTL/epoch",
      "write_set": [
        "BIND_EXACT_BY_ORIGINAL_OWNER"
      ],
      "native_status": "NATIVE_NOT_RUN",
      "positive": "Source/Stage/Approve/Active/Loaded/Consumer各自hash同scope",
      "negative": "Stage文件冒Loaded ACK",
      "first_fail": "WP-FHS-02.FIRST_FAIL:POLICY_NOT_LOADED"
    },
    {
      "id": "WP-FHS-03",
      "name": "HGK Registry/Issuer",
      "phase": "DESIGN_OR_BIND",
      "tier": "L3",
      "effect_class": "HOST_OP",
      "depends_on": [
        "WP-FHS-01"
      ],
      "output": "IssuerReceiverBinding",
      "permission_basis": "OPS ECP + Host Owner/Issuer + nonce/TTL/epoch",
      "write_set": [
        "BIND_EXACT_BY_ORIGINAL_OWNER"
      ],
      "native_status": "NATIVE_NOT_RUN",
      "positive": "原Receiver/Issuer registry同epoch與scope",
      "negative": "候選ECP冒Permit",
      "first_fail": "WP-FHS-03.FIRST_FAIL:ISSUER_BINDING_INVALID"
    },
    {
      "id": "WP-FHS-04",
      "name": "Hermes Durable Runtime",
      "phase": "DESIGN_OR_BIND",
      "tier": "L3",
      "effect_class": "HOST_OP",
      "depends_on": [
        "WP-FHS-00"
      ],
      "output": "WakeLeaseRuntimeBinding",
      "permission_basis": "OPS ECP + Host Owner/Issuer + nonce/TTL/epoch",
      "write_set": [
        "BIND_EXACT_BY_ORIGINAL_OWNER"
      ],
      "native_status": "NATIVE_NOT_RUN",
      "positive": "原Journal/Wake/Lease schema及checkpoint可讀",
      "negative": "新增第二Queue或舊generation commit",
      "first_fail": "WP-FHS-04.FIRST_FAIL:RUNTIME_LEASE_BINDING_DENY"
    },
    {
      "id": "WP-FHS-05",
      "name": "PIPD Native Compiler",
      "phase": "DESIGN_OR_BIND",
      "tier": "L0",
      "effect_class": "LOCAL_DRAFT_WRITE",
      "depends_on": [
        "WP-FHS-01"
      ],
      "output": "PI/PD/DEV-OPS候選",
      "permission_basis": "明列隔離 output root 的使用者授權",
      "write_set": [
        "BIND_EXACT_BY_ORIGINAL_OWNER"
      ],
      "native_status": "NATIVE_NOT_RUN",
      "positive": "PI語義/PD scope/DEV-OPS分路與strict input一致",
      "negative": "sidecar塞strict payload或expected當Raw",
      "first_fail": "WP-FHS-05.FIRST_FAIL:PIPD_FORMAL_PROMOTION_HOLD"
    },
    {
      "id": "WP-FHS-06",
      "name": "Legal First Reversible Slice",
      "phase": "FIRST_EFFECT",
      "tier": "L2",
      "effect_class": "REPO_WRITE",
      "depends_on": [
        "WP-FHS-02",
        "WP-FHS-03",
        "WP-FHS-04",
        "WP-FHS-05",
        "WP-FHS-17"
      ],
      "output": "最小可逆Repo diff+Raw",
      "permission_basis": "DEV ECP + exact WriteSet + 原 HGK admission",
      "write_set": [
        "BIND_EXACT_BY_ORIGINAL_OWNER"
      ],
      "native_status": "NATIVE_NOT_RUN",
      "positive": "needed capability qualified後在exact Repo scope取得可逆diff/Raw",
      "negative": "WP17尚未具能力就發首effect",
      "first_fail": "WP-FHS-06.FIRST_FAIL:FIRST_EFFECT_CAPABILITY_MISSING"
    },
    {
      "id": "WP-FHS-07",
      "name": "Native PLAN Commander A/B/C",
      "phase": "DESIGN_OR_BIND",
      "tier": "L0",
      "effect_class": "LOCAL_DRAFT_WRITE",
      "depends_on": [
        "WP-FHS-01",
        "WP-FHS-15"
      ],
      "output": "PlanRevisionProposal+CAS ACK",
      "permission_basis": "明列隔離 output root 的使用者授權",
      "write_set": [
        "BIND_EXACT_BY_ORIGINAL_OWNER"
      ],
      "native_status": "NATIVE_NOT_RUN",
      "positive": "A只讀/B隔離proposal使用原PLAN CAS Reader",
      "negative": "要求先有同WO permit才能規劃或呼叫legacy SP",
      "first_fail": "WP-FHS-07.FIRST_FAIL:COMMANDER_BOOTSTRAP_INVERSION"
    },
    {
      "id": "WP-FHS-08",
      "name": "FHS Execute Worker",
      "phase": "DESIGN_OR_BIND",
      "tier": "L3",
      "effect_class": "HOST_OP",
      "depends_on": [
        "WP-FHS-06",
        "WP-FHS-07"
      ],
      "output": "WorkerEffectRaw+JournalCursor",
      "permission_basis": "OPS ECP + Host Owner/Issuer + nonce/TTL/epoch",
      "write_set": [
        "BIND_EXACT_BY_ORIGINAL_OWNER"
      ],
      "native_status": "NATIVE_NOT_RUN",
      "positive": "已admitted WorkID單一lease以Worker真PID完成本operation",
      "negative": "timeout同nonce盲replay",
      "first_fail": "WP-FHS-08.FIRST_FAIL:EFFECT_REPLAY_DENY"
    },
    {
      "id": "WP-FHS-09",
      "name": "Challenge/Protected AO",
      "phase": "QUALIFY",
      "tier": "L1",
      "effect_class": "SOURCE_READ",
      "depends_on": [
        "WP-FHS-08",
        "WP-FHS-21"
      ],
      "output": "ProtectedCheckerRequest/Receipt（需另一主體）",
      "permission_basis": "原唯讀 ACL/read scope",
      "write_set": [],
      "native_status": "NATIVE_NOT_RUN",
      "positive": "真Raw與原Oracle交不同principal受保護Reader",
      "negative": "Maker自簽PASS或借sibling verdict",
      "first_fail": "WP-FHS-09.FIRST_FAIL:SELF_ACCEPTANCE_DENY"
    },
    {
      "id": "WP-FHS-10",
      "name": "B1 3 GWO & G-A/G-B",
      "phase": "QUALIFY",
      "tier": "L3",
      "effect_class": "HOST_OP",
      "depends_on": [
        "WP-FHS-09",
        "WP-FHS-20"
      ],
      "output": "三GWO各自Raw+G-A/G-B",
      "permission_basis": "OPS ECP + Host Owner/Issuer + nonce/TTL/epoch",
      "write_set": [
        "BIND_EXACT_BY_ORIGINAL_OWNER"
      ],
      "native_status": "NATIVE_NOT_RUN",
      "positive": "Fabric/HGK/SBL三GWO各自effect與G-A/G-B證據",
      "negative": "一個GWO冒其餘兩個",
      "first_fail": "WP-FHS-10.FIRST_FAIL:GWO_EVIDENCE_JOIN_INCOMPLETE"
    },
    {
      "id": "WP-FHS-11",
      "name": "Portable Host Dogfood",
      "phase": "QUALIFY",
      "tier": "L3",
      "effect_class": "HOST_OP",
      "depends_on": [
        "WP-FHS-05",
        "WP-FHS-16"
      ],
      "output": "三SP逐Host loaded/invoked raw",
      "permission_basis": "OPS ECP + Host Owner/Issuer + nonce/TTL/epoch",
      "write_set": [
        "BIND_EXACT_BY_ORIGINAL_OWNER"
      ],
      "native_status": "NATIVE_NOT_RUN",
      "positive": "每Portable SP的Host install/load/invoke/nontrigger/remove",
      "negative": "一SP安裝receipt當三SP9/9",
      "first_fail": "WP-FHS-11.FIRST_FAIL:HOST_SP_MATRIX_INCOMPLETE"
    },
    {
      "id": "WP-FHS-12",
      "name": "W18 Normal Mode",
      "phase": "QUALIFY",
      "tier": "L3",
      "effect_class": "HOST_OP",
      "depends_on": [
        "WP-FHS-10",
        "WP-FHS-11"
      ],
      "output": "新PID普通Goal E33-E42 Raw",
      "permission_basis": "OPS ECP + Host Owner/Issuer + nonce/TTL/epoch",
      "write_set": [
        "BIND_EXACT_BY_ORIGINAL_OWNER"
      ],
      "native_status": "NATIVE_NOT_RUN",
      "positive": "新PID普通Goal正式Profile/ToolAutoSelect/真served且test-only移除",
      "negative": "B1專用Prompt或test plugin充NormalMode",
      "first_fail": "WP-FHS-12.FIRST_FAIL:NORMAL_MODE_NOT_QUALIFIED"
    },
    {
      "id": "WP-FHS-13",
      "name": "CAP On-Demand + HotSwap",
      "phase": "DESIGN_OR_BIND",
      "tier": "L3",
      "effect_class": "HOST_OP",
      "depends_on": [
        "WP-FHS-16",
        "WP-FHS-17"
      ],
      "output": "CAP gap/HotSwap parity+readback",
      "permission_basis": "OPS ECP + Host Owner/Issuer + nonce/TTL/epoch",
      "write_set": [
        "BIND_EXACT_BY_ORIGINAL_OWNER"
      ],
      "native_status": "NATIVE_NOT_RUN",
      "positive": "needed CAP走原route且替代Parity同原功能",
      "negative": "熱替代Issuer或以選型當invoke",
      "first_fail": "WP-FHS-13.FIRST_FAIL:CAPABILITY_PARITY_NOT_PROVEN"
    },
    {
      "id": "WP-FHS-14",
      "name": "Release/Retire Candidate",
      "phase": "QUALIFY",
      "tier": "L4",
      "effect_class": "RELEASE",
      "depends_on": [
        "WP-FHS-09",
        "WP-FHS-19"
      ],
      "output": "ReleaseCandidate+原Publisher receipt",
      "permission_basis": "原 Publisher/GHP-02 + 受保護 Checker",
      "write_set": [
        "BIND_EXACT_BY_ORIGINAL_OWNER"
      ],
      "native_status": "NATIVE_NOT_RUN",
      "positive": "供應鏈+受保護驗收+原Publisher/GHP-02實際readback",
      "negative": "CI/作者檔案封裝冒Release",
      "first_fail": "WP-FHS-14.FIRST_FAIL:RELEASE_NOT_AUTHORIZED"
    },
    {
      "id": "WP-FHS-15",
      "name": "TPM Corpus & SPEC 18Stage",
      "phase": "DESIGN_OR_BIND",
      "tier": "L0",
      "effect_class": "LOCAL_DRAFT_WRITE",
      "depends_on": [
        "WP-FHS-00"
      ],
      "output": "三SPEC+18stage trace",
      "permission_basis": "明列隔離 output root 的使用者授權",
      "write_set": [
        "BIND_EXACT_BY_ORIGINAL_OWNER"
      ],
      "native_status": "NATIVE_NOT_RUN",
      "positive": "24 base docs真hash Reader與18 Stage三SPEC具來源",
      "negative": "要求重新上傳內建DOC或T4/T5自升正式",
      "first_fail": "WP-FHS-15.FIRST_FAIL:TPM_SOURCE_STAGE_GUARD"
    },
    {
      "id": "WP-FHS-16",
      "name": "Donor/Method Slot Translation",
      "phase": "DESIGN_OR_BIND",
      "tier": "L0",
      "effect_class": "LOCAL_DRAFT_WRITE",
      "depends_on": [
        "WP-FHS-00"
      ],
      "output": "24slot/25method壓製候選",
      "permission_basis": "明列隔離 output root 的使用者授權",
      "write_set": [
        "BIND_EXACT_BY_ORIGINAL_OWNER"
      ],
      "native_status": "NATIVE_NOT_RUN",
      "positive": "24槽/25方法依原disposition產特定輸出且方法不假installer",
      "negative": "REFERENCE_ONLY自動安裝",
      "first_fail": "WP-FHS-16.FIRST_FAIL:DONOR_METHOD_DISPOSITION_DENY"
    },
    {
      "id": "WP-FHS-17",
      "name": "CAP-BOOT Native Occupants",
      "phase": "HOST_INSTALL_IF_AUTHORIZED",
      "tier": "L3",
      "effect_class": "HOST_OP",
      "depends_on": [
        "WP-FHS-00",
        "WP-FHS-02",
        "WP-FHS-03"
      ],
      "output": "needed能力最小HostOccupant+loaded ACK",
      "permission_basis": "OPS ECP + Host Owner/Issuer + nonce/TTL/epoch",
      "write_set": [
        "BIND_EXACT_BY_ORIGINAL_OWNER"
      ],
      "native_status": "NATIVE_NOT_RUN",
      "positive": "現有Issuer合法installer先建needed occupant再驗LoadedSHA",
      "negative": "依WP06才准WP17形成循環",
      "first_fail": "WP-FHS-17.FIRST_FAIL:CAP_BOOT_DEPENDENCY_INVERSION"
    },
    {
      "id": "WP-FHS-18",
      "name": "FAR Bounded Repair & Incident",
      "phase": "DESIGN_OR_BIND",
      "tier": "L2",
      "effect_class": "REPO_WRITE",
      "depends_on": [
        "WP-FHS-08"
      ],
      "output": "BoundedRepairDiff+RedGreen+residue",
      "permission_basis": "DEV ECP + exact WriteSet + 原 HGK admission",
      "write_set": [
        "BIND_EXACT_BY_ORIGINAL_OWNER"
      ],
      "native_status": "NATIVE_NOT_RUN",
      "positive": "first_fail最小cone在原Oracle Red→Patch→Green且budget有界",
      "negative": "擴scope/改Oracle或刪舊失敗Raw",
      "first_fail": "WP-FHS-18.FIRST_FAIL:REPAIR_SCOPE_DENY"
    },
    {
      "id": "WP-FHS-19",
      "name": "CI/Supply Chain & Requal",
      "phase": "DESIGN_OR_BIND",
      "tier": "L1",
      "effect_class": "SOURCE_READ",
      "depends_on": [
        "WP-FHS-00"
      ],
      "output": "CI/License/NOTICE/SBOM掃描Raw",
      "permission_basis": "原唯讀 ACL/read scope",
      "write_set": [],
      "native_status": "NATIVE_NOT_RUN",
      "positive": "license/NOTICE/SBOM/dependency/secret輸出與同candidate可回算",
      "negative": "未執行掃描以名字充通過",
      "first_fail": "WP-FHS-19.FIRST_FAIL:SUPPLY_CHAIN_EVIDENCE_MISSING"
    },
    {
      "id": "WP-FHS-20",
      "name": "CLI/Agent/Host Kind Matrix",
      "phase": "QUALIFY",
      "tier": "L3",
      "effect_class": "HOST_OP",
      "depends_on": [
        "WP-FHS-05",
        "WP-FHS-16"
      ],
      "output": "192Cell適用/NoFit/Host Raw",
      "permission_basis": "OPS ECP + Host Owner/Issuer + nonce/TTL/epoch",
      "write_set": [
        "BIND_EXACT_BY_ORIGINAL_OWNER"
      ],
      "native_status": "NATIVE_NOT_RUN",
      "positive": "192組合每Host/Mode/Provider具本cell Raw或明確NoFit",
      "negative": "Hermes Raw借Claude/DeepSeek",
      "first_fail": "WP-FHS-20.FIRST_FAIL:HOST_CELL_EVIDENCE_FOREIGN"
    },
    {
      "id": "WP-FHS-21",
      "name": "Challenge 96/H4/SEAM Coverage",
      "phase": "QUALIFY",
      "tier": "L1",
      "effect_class": "SOURCE_READ",
      "depends_on": [
        "WP-FHS-01"
      ],
      "output": "96Cell/H4/SEAM原Oracle計畫",
      "permission_basis": "原唯讀 ACL/read scope",
      "write_set": [],
      "native_status": "NATIVE_NOT_RUN",
      "positive": "96cell及H4/SEAM按原predicate/校準逐格Reader可判",
      "negative": "同一generic fixture聲稱全部已實測",
      "first_fail": "WP-FHS-21.FIRST_FAIL:ORACLE_CELL_NOT_PROVEN"
    }
  ],
  "typed_edges": [
    {
      "from": "WP-FHS-00",
      "to": "WP-FHS-01",
      "type": "DATA_OR_ADMISSION",
      "predicate": "needed_scope_only; existing_valid_binding_reusable"
    },
    {
      "from": "WP-FHS-01",
      "to": "WP-FHS-02",
      "type": "DATA_OR_ADMISSION",
      "predicate": "needed_scope_only; existing_valid_binding_reusable"
    },
    {
      "from": "WP-FHS-01",
      "to": "WP-FHS-03",
      "type": "DATA_OR_ADMISSION",
      "predicate": "needed_scope_only; existing_valid_binding_reusable"
    },
    {
      "from": "WP-FHS-00",
      "to": "WP-FHS-04",
      "type": "DATA_OR_ADMISSION",
      "predicate": "needed_scope_only; existing_valid_binding_reusable"
    },
    {
      "from": "WP-FHS-01",
      "to": "WP-FHS-05",
      "type": "DATA_OR_ADMISSION",
      "predicate": "needed_scope_only; existing_valid_binding_reusable"
    },
    {
      "from": "WP-FHS-02",
      "to": "WP-FHS-06",
      "type": "DATA_OR_ADMISSION",
      "predicate": "needed_scope_only; existing_valid_binding_reusable"
    },
    {
      "from": "WP-FHS-03",
      "to": "WP-FHS-06",
      "type": "DATA_OR_ADMISSION",
      "predicate": "needed_scope_only; existing_valid_binding_reusable"
    },
    {
      "from": "WP-FHS-04",
      "to": "WP-FHS-06",
      "type": "DATA_OR_ADMISSION",
      "predicate": "needed_scope_only; existing_valid_binding_reusable"
    },
    {
      "from": "WP-FHS-05",
      "to": "WP-FHS-06",
      "type": "DATA_OR_ADMISSION",
      "predicate": "needed_scope_only; existing_valid_binding_reusable"
    },
    {
      "from": "WP-FHS-17",
      "to": "WP-FHS-06",
      "type": "CAPABILITY",
      "predicate": "needed_scope_only; existing_valid_binding_reusable"
    },
    {
      "from": "WP-FHS-01",
      "to": "WP-FHS-07",
      "type": "DATA_OR_ADMISSION",
      "predicate": "needed_scope_only; existing_valid_binding_reusable"
    },
    {
      "from": "WP-FHS-15",
      "to": "WP-FHS-07",
      "type": "DATA_OR_ADMISSION",
      "predicate": "needed_scope_only; existing_valid_binding_reusable"
    },
    {
      "from": "WP-FHS-06",
      "to": "WP-FHS-08",
      "type": "DATA_OR_ADMISSION",
      "predicate": "needed_scope_only; existing_valid_binding_reusable"
    },
    {
      "from": "WP-FHS-07",
      "to": "WP-FHS-08",
      "type": "DATA_OR_ADMISSION",
      "predicate": "needed_scope_only; existing_valid_binding_reusable"
    },
    {
      "from": "WP-FHS-08",
      "to": "WP-FHS-09",
      "type": "DATA_OR_ADMISSION",
      "predicate": "needed_scope_only; existing_valid_binding_reusable"
    },
    {
      "from": "WP-FHS-21",
      "to": "WP-FHS-09",
      "type": "DATA_OR_ADMISSION",
      "predicate": "needed_scope_only; existing_valid_binding_reusable"
    },
    {
      "from": "WP-FHS-09",
      "to": "WP-FHS-10",
      "type": "DATA_OR_ADMISSION",
      "predicate": "needed_scope_only; existing_valid_binding_reusable"
    },
    {
      "from": "WP-FHS-20",
      "to": "WP-FHS-10",
      "type": "DATA_OR_ADMISSION",
      "predicate": "needed_scope_only; existing_valid_binding_reusable"
    },
    {
      "from": "WP-FHS-05",
      "to": "WP-FHS-11",
      "type": "DATA_OR_ADMISSION",
      "predicate": "needed_scope_only; existing_valid_binding_reusable"
    },
    {
      "from": "WP-FHS-16",
      "to": "WP-FHS-11",
      "type": "DATA_OR_ADMISSION",
      "predicate": "needed_scope_only; existing_valid_binding_reusable"
    },
    {
      "from": "WP-FHS-10",
      "to": "WP-FHS-12",
      "type": "DATA_OR_ADMISSION",
      "predicate": "needed_scope_only; existing_valid_binding_reusable"
    },
    {
      "from": "WP-FHS-11",
      "to": "WP-FHS-12",
      "type": "DATA_OR_ADMISSION",
      "predicate": "needed_scope_only; existing_valid_binding_reusable"
    },
    {
      "from": "WP-FHS-16",
      "to": "WP-FHS-13",
      "type": "DATA_OR_ADMISSION",
      "predicate": "needed_scope_only; existing_valid_binding_reusable"
    },
    {
      "from": "WP-FHS-17",
      "to": "WP-FHS-13",
      "type": "CAPABILITY",
      "predicate": "needed_scope_only; existing_valid_binding_reusable"
    },
    {
      "from": "WP-FHS-09",
      "to": "WP-FHS-14",
      "type": "DATA_OR_ADMISSION",
      "predicate": "needed_scope_only; existing_valid_binding_reusable"
    },
    {
      "from": "WP-FHS-19",
      "to": "WP-FHS-14",
      "type": "DATA_OR_ADMISSION",
      "predicate": "needed_scope_only; existing_valid_binding_reusable"
    },
    {
      "from": "WP-FHS-00",
      "to": "WP-FHS-15",
      "type": "DATA_OR_ADMISSION",
      "predicate": "needed_scope_only; existing_valid_binding_reusable"
    },
    {
      "from": "WP-FHS-00",
      "to": "WP-FHS-16",
      "type": "DATA_OR_ADMISSION",
      "predicate": "needed_scope_only; existing_valid_binding_reusable"
    },
    {
      "from": "WP-FHS-00",
      "to": "WP-FHS-17",
      "type": "DATA_OR_ADMISSION",
      "predicate": "needed_scope_only; existing_valid_binding_reusable"
    },
    {
      "from": "WP-FHS-02",
      "to": "WP-FHS-17",
      "type": "DATA_OR_ADMISSION",
      "predicate": "needed_scope_only; existing_valid_binding_reusable"
    },
    {
      "from": "WP-FHS-03",
      "to": "WP-FHS-17",
      "type": "DATA_OR_ADMISSION",
      "predicate": "needed_scope_only; existing_valid_binding_reusable"
    },
    {
      "from": "WP-FHS-08",
      "to": "WP-FHS-18",
      "type": "DATA_OR_ADMISSION",
      "predicate": "needed_scope_only; existing_valid_binding_reusable"
    },
    {
      "from": "WP-FHS-00",
      "to": "WP-FHS-19",
      "type": "DATA_OR_ADMISSION",
      "predicate": "needed_scope_only; existing_valid_binding_reusable"
    },
    {
      "from": "WP-FHS-05",
      "to": "WP-FHS-20",
      "type": "DATA_OR_ADMISSION",
      "predicate": "needed_scope_only; existing_valid_binding_reusable"
    },
    {
      "from": "WP-FHS-16",
      "to": "WP-FHS-20",
      "type": "DATA_OR_ADMISSION",
      "predicate": "needed_scope_only; existing_valid_binding_reusable"
    },
    {
      "from": "WP-FHS-01",
      "to": "WP-FHS-21",
      "type": "DATA_OR_ADMISSION",
      "predicate": "needed_scope_only; existing_valid_binding_reusable"
    }
  ]
}
```

注入 WP06→WP17 形成 06↔17 時必 DAG_CYCLE；把 WP17 的 discovery 誤依首效果收據必 BOOTSTRAP_DEPENDENCY_INVERSION。所有 Host/Release Case 本輪 NATIVE_NOT_RUN，圖的作者端測試不生成任何真 permit。
