---
artifact_id: FHS-MSC-R2-BODY-01
formal_name: Product、Architecture、Program SPEC 與權威主幹
short_name: BODY-01
version: 2026-10-29-r2-revision2
source_set_hash_or_pending: f86b217ae3c3ee28183570f4bf3d4f08d4d00e9b86d1de1a641a630f8682d1a1
intended_consumer: 原領域 Owner 與下游 Reader
owner_role: 作者端規格修補者；原 Domain Writer 不移轉
design_status: SOURCE_BOUND_REPAIR_CANDIDATE
claim_ceiling: AUTHOR_STATIC_ONLY; NATIVE_NOT_RUN; CHECKER_NOT_RUN; RELEASE_NOT_RUN
supersession_scope: 本輪作者候選revision2；保留前版封存；不取代任何原Canonical Writer版本
AUDIT_F_IDs:
- F-01
- F-18
- F-24
---

# Product、Architecture、Program SPEC 與權威主幹

## R2-01-SPEC：三份 SPEC 的不同消費結果

Product SPEC：單人 OWNER 輸入 goal/source/known_answers，PM 將 Persona/Pain/JTBD 轉為可見 FUO、MVP、non_goals、ACC/NEG。FUO 必是使用者能取用的成果，例如普通「整理來源後產待審變更規格」得到 source-bound SpecDelta；不得以檔案數當 FUO。Consumer 是 PIPD Intake/原產品 Owner；POS 原需求每一否定作用域有來源；NEG 把「不得混同 SWOF」改成「等同 SWOF」必拒 `PRODUCT_POLARITY_LOSS`。

Architecture SPEC：SE 讀 Product SPEC、既有 RepoContext 和權威表，劃 Domain/ABI/NFR/ADR。每個 seam 記單一 writer、reader、輸入/輸出版本、trust boundary、effect class 和 first_fail。Consumer 為原架構 Owner/PIPD Binder；POS 同一 effect 只有原 Issuer；NEG 用 adapter 增設 Issuer、Queue、Policy 或 Checker → `AUTHORITY_COLLISION`。

Program SPEC：TPgM 消費上述兩份 SPEC，以每 WP exact output/typed dependency、風險、Done、rollback、resume 組合法 DAG。Consumer 為原 Native PLAN；POS SOURCE_READ 能獨立完成，不待 effect permit；NEG WP17 待 WP06、而 WP06 又待 WP17 → `DAG_CYCLE`。22 WP 唯一實體在 [BODY-11](11_WORKPACKAGES_AND_DAG.md)。

## R2-01-AUTHORITY：三 SP、六模組與 Owner

TPM 對 Goal Intake/Specification/Program proposal 負責；Guide 支援 Routing/Planning proposal；Governed Execution Interface 只轉交原 PIPD/Fabric/HGK；Evidence/Verification 支援 frozen-readset Challenge；Bounded Evolution 將 first_fail 送原 Maker repair。這是職能視角，不能當不同 OS principal。

Master 決定跨域意圖，Domain v2 決定該域設計，SBL DOC00–13 保留原產品義務，PIPD DOC00–09 保留 formal Writer。Fabric Policy、HGK Issuer、SharedSpine、Checker、Publisher 的真 registry/ACL 不受文稿改寫。三 SP 各自 install/load/invoke 九子測在 [BODY-09](09_SBL_DOC00_13_FULL_UPGRADE.md)。舊 SBL Commander-SP 僅作歷史來源；現役路線只能使用非 legacy Producer 或正確 `C PARK`。

## R2-01-EXAMPLE：普通 Goal 到候選與退出

輸入「為此既有產品加入離線來源查詢」：PM 指定離線可查 source locator 是 FUO；SE 指定 SOURCE_READ、provider_off=true、不新建 Authority DB；TPgM 產唯讀 source probe 和隔離 spec 卡。輸出三 SPEC + trace + unresolved bindings，交原 PIPD Intake。若沒有原 Writer ACK，狀態為 SPEC_CANDIDATE；使用者仍可讀 SPEC，只有 PI promotion HOLD。NEG：未找到 CLI 就聲稱 PI_COMPILED 或擅 install 三十套工具 → `CLAIM_ESCALATION/UNNEEDED_EFFECT`。退出僅撤本輪隔離候選，保留來源及既有 admitted work。
