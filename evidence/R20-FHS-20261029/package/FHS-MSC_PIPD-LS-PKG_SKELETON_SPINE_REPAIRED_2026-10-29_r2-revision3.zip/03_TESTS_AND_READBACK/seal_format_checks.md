# 封裝格式回讀

全實存檔strict UTF8/LF；JSON 40檔parse、JSONL 174300行parse、Python 4檔AST parse，issues=0。Markdown/link/JSON fences以最後static_validation_result為準；本格式檢查不替代domain與Native。
