# Frozen candidate的作者端反證範圍

候選17冊集合SHA：`5acb33e3b129effa5801d2ed6fcf43a5a6314028ee8ae18251d8280e2a2a401d`。已讀sbl-external-challenge-sp規範，但作者與Maker相同，沒有distinct protected signer，因此沒有宣稱獨立Challenge PASS。實際反證由tools/validate.py對固定文稿的資料、source和注入mutation執行，raw在static_validation_result.json。

未覆蓋：149真業務執行、192 Host/Provider、96原Oracle實際運行、282 B1 Native、Windows當期LoadedPolicy/Issuer、W18正常新PID與protected Checker/Release。這些是明確的NOT_RUN，不以模型角色扮演補收據。
