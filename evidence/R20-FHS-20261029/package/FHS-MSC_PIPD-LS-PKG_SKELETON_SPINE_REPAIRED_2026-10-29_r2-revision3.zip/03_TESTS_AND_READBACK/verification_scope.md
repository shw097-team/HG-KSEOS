# 本輪驗證的精確作用域

AUTHOR_STATIC_FIXTURES_ONLY：真實執行了Python檢查器，但多數POS/NEG是規格拒收器、Oracle input形狀或局部模型；不是Native操作。891項不能換算為149/949/192/386的全產品實機成功率。每個分母的設計record與未執行狀態分列COVERAGE_REPORT。

作者端literal loss-map lost IDs=0、Child Parent全文遺失=0、R15原需求字串遺失=0，只證明字面守恆；原條款Owner語義裁決與獨立核驗不能由此推出。原來源、Repo、Policy、Registry、Hermes Queue、Checker/Publisher均未被本輪修改。
