# Revision2驗證邊界

## Revision2：實際CLI Raw與96格語義Oracle補強

前版原始封存保留於prior_seal.json；本版不是以891個形狀/靜態檢查宣稱全部domain語義已通過。新實跑原SBL source module 27次，每次--data-dir都在私有work WriteSet，涵蓋POS、duplicate/empty/unknown拒收且state無diff、新PID持久化、兩entrypoint parity、remove回空，以及uninstall保留foreign sentinel。未安裝Host，未操作正式user store、HGK/Hermes或Issuer。

96格新增可執行domain與oracle-specific negative fixtures，現讀回679項作者端檢查PASS、0FAIL；正向格結果為50 PASS_LOCAL_ORACLE＋46 HOLD。HOLD包括原校準/Human或Judge Reader缺件、性能門檻未綁和沒有兩版本升級資格。這些不是96 Native Case PASS；source module/27 process Raw亦不能替代其他Host、W18正式普通Goal或受保護Checker。

完整case-specific JSON與實際輸出在oracle96_semantic_fixtures_v2.json、oracle96_verification_v2.json；source/runtime邊界見BODY-07的R2-07-C39與verification_scope_revision2.md。原Goal/17冊/26 Findings和所有分母維持，不因本輪聚焦F-21而縮減。
